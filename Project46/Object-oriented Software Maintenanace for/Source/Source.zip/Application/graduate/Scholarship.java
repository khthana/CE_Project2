package graduate;

import java.util.*;
public class Scholarship {
  private long id;
  private String name;
  private long year;
  private ScholarshipGroup group;
  private double money;
  private int no;
  private int interval;
  private int exception;
  private ScholarshipDB sdb = new ScholarshipDB();
  //Constructor
  public Scholarship() {
  }
  public Scholarship(long id){
    this.setID(id);
  }
  //getMethod
  public long getID(){
    return this.id;
  }
  public String getName(){
    return this.name;
  }
  public long getYear(){
    return this.year;
  }
  public ScholarshipGroup getGroup(){
    return this.group;
  }
  public double getMoney(){
    return this.money;
  }
  public int getNo(){
    return this.no;
  }
  public int getInterval(){
    return this.interval;
  }
  public int getException(){
    return this.exception;
  }
  //setMethod
  public void setID(long id){
    this.id = id;
  }
  public void setName(String name){
    this.name = name;
  }
  public void setYear(long year){
    this.year = year;
  }
  public void setGroup(ScholarshipGroup group){
      this.group = group;
  }
  public void setMoney(double money){
    this.money = money;
  }
  public void setNo(int no){
    this.no = no;
  }
  public void setInterval(int interval){
    this.interval = interval;
  }
  public void setException(int ex){
    this.exception = ex;
  }
  //Business Method
  public Vector retrieveScholarship(){
    return sdb.retrieveScholarship();
  }
  public boolean insertScholarship(Scholarship ss){
    return sdb.insertScholarship(ss);
  }
  public boolean updateScholarship(Scholarship ss){
    return sdb.updateScholarship(ss);
  }
  public boolean deleteScholarship(Scholarship ss){
    return sdb.deleteScholarship(ss);
  }
  public String toString(){
    return this.getName();
  }
}