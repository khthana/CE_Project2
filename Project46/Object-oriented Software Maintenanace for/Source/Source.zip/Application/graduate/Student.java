package graduate;

import java.util.*;
public class Student {
  private String studentID;
  private Prename prename;
  private String studentEname;
  private String studentTname;
  private String password;
  private String email;
  private int degree;
  private int studentType;
  private int studyGroup;
  private int status;
  private int registerStatus;
  private boolean approved;
  private boolean debtStatus;
  private boolean libraryStatus;
  private boolean nationalStatus;
  private int paymentCondition;
  private int noSupportTerm;
  private Major major;
  private Minor minor;
  private Location location;
  private Date adoptDate;
  private Semester entranceSemester;
  private Date entranceDate;
  private Semester leaveSemester;
  private Date leaveDate;
  private Professor professor;
  private Thesis thesis;
  private Date birthday;
  private String religion;
  private String race;
  private String nationality;
  private String gender;
  private Occupation occupation;
  private double salary;
  private String oldInstitute;
  private String oldDegree;
  private double oldGPA;
  private int oldLeaveYear;
  private String registerAddress;
  private String registerTel;
  private String recentAddress;
  private String recentTel;
  private String fatherName;
  private Occupation fatherOccupation;
  private String motherName;
  private Occupation motherOccupation;
  private String coupleName;
  private Occupation coupleOccupation;
  private int children;
  private String parentName;
  private String relation;
  private String parentAddress;
  private String parentTel;
  //------------------------------------------------------------------------------------------------------------------------------------------------------
  private StudentDB studentDB = new StudentDB();
  private Vector scholarshipVector = new Vector();
  private Vector debtVector = new Vector();
  private Vector registrationVector = new Vector();
  private Vector currentRegisterVector = new Vector();
  private Vector costVector = new Vector();
  private int total = 0;
  private double totalCredit = 0;
  private double totalNoncredit = 0.0;
  private double totalAudit = 0.0;
  private double totalThesis = 0.0;
  //Constuctor
  public Student() {
  }
  public Student(String studentID){
    this.setStudentID(studentID);
  }
  //getMethod
  public String getStudentID(){
    return this.studentID;
  }
  public Prename getPrename(){
    return this.prename;
  }
  public String getStudentEname(){
    return this.studentEname;
  }
  public String getStudentTname(){
    return this.studentTname;
  }
  public String getPassword(){
    return this.password;
  }
  public String getEmail(){
    return this.email;
  }
  public int getDegree(){
    return this.degree;
  }
  public int getStudentType(){
    return this.studentType;
  }
  public int getStudyGroup(){
    return this.studyGroup;
  }
  public int getStatus(){
    return this.status;
  }
  public int getRegisterStatus(){
    return this.registerStatus;
  }
  public boolean getApproved(){
    return this.approved;
  }
  public boolean getDebtStatus(){
    return this.debtStatus;
  }
  public boolean getLibraryStatus(){
    return this.libraryStatus;
  }
  public boolean getNationalStatus(){
    return this.nationalStatus;
  }
  public int getPaymentCondition(){
    return this.paymentCondition;
  }
  public int getNoSupportTerm(){
    return this.noSupportTerm;
  }
  public Major getMajor(){
    return this.major;
  }
  public Minor getMinor(){
    return this.minor;
  }
  public Location getLocation(){
    return this.location;
  }
  public Date getAdoptDate(){
    return this.adoptDate;
  }
  public Semester getEntraceSemester(){
    return this.entranceSemester;
  }
  public Date getEntraceDate(){
    return this.entranceDate;
  }
  public Semester getLeaveSemester(){
    return this.leaveSemester;
  }
  public Date getLeaveDate(){
    return this.leaveDate;
  }
  public Professor getProfessor(){
    return this.professor;
  }
  public Thesis getThesis(){
    return this.thesis;
  }
  public Date getBirthday(){
    return this.birthday;
  }
  public String getReligion(){
    return this.religion;
  }
  public String getRace(){
    return this.race;
  }
  public String getNationality(){
    return this.nationality;
  }
  public String getGender(){
    return this.gender;
  }
  public Occupation getOccupation(){
    return this.occupation;
  }
  public double getSalary(){
    return this.salary;
  }
  public String getOldInstitute(){
    return this.oldInstitute;
  }
  public String getOldDegree(){
    return this.oldDegree;
  }
  public double getOldGPA(){
    return this.oldGPA;
  }
  public int getOldLeaveYear(){
    return this.oldLeaveYear;
  }
  public String getRegisterAddess(){
    return this.registerAddress;
  }
  public String getRegisterTel(){
    return this.registerTel;
  }
  public String getRecentAddress(){
    return this.recentAddress;
  }
  public String getRecentTel(){
    return this.recentTel;
  }
  public String getFatherName(){
    return this.fatherName;
  }
  public Occupation getFatherOccupation(){
    return this.fatherOccupation;
  }
  public String getMotherName(){
    return this.motherName;
  }
  public Occupation getMotherOccupation(){
    return this.motherOccupation;
  }
  public String getCoupleName(){
    return this.coupleName;
  }
  public Occupation getCoupleOccupation(){
    return this.coupleOccupation;
  }
  public int getChildren(){
    return this.children;
  }
  public String getParentName(){
    return this.parentName;
  }
  public String getRelation(){
    return this.relation;
  }
  public String getParentAddress(){
    return this.parentAddress;
  }
  public String getParentTel(){
    return this.parentTel;
  }
  public Vector getCurrentRegistration(){
    return this.currentRegisterVector;
  }
  //setMethod
  public void setStudentID(String studentID){
    this.studentID = studentID;
  }
  public void setPrename(Prename prename){
    this.prename = prename;
  }
  public void setStudentEname(String ename){
    this.studentEname = ename;
  }
  public void setStudentTname(String tname){
    this.studentTname = tname;
  }
  public void setPassword(String password){
    this.password = password;
  }
  public void setEmail(String email){
    this.email = email;
  }
  public void setDegree(int degree){
    this.degree = degree;
  }
  public void setStudentType(int studentType){
    this.studentType = studentType;
  }
  public void setStudyGroup(int studyGroup){
    this.studyGroup = studyGroup;
  }
  public void setStatus(int status){
    this.status = status;
  }
  public void setRegisterStatus(int registerStatus){
    this.registerStatus = registerStatus;
  }
  public void setApproved(boolean approved){
    this.approved = approved;
  }
  public void setDebtStatus(boolean debtStatus){
    this.debtStatus = debtStatus;
  }
  public void setLibraryStatus(boolean libraryStatus){
    this.libraryStatus = libraryStatus;
  }
  public void setNationalStatus(boolean nationalStatus){
    this.nationalStatus = nationalStatus;
  }
  public void setPaymentCondition(int paymentCondition){
    this.paymentCondition = paymentCondition;
  }
  public void setNoSupportTerm(int no){
    this.noSupportTerm = no;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void setMinor(Minor minor){
    this.minor = minor;
  }
  public void setLocation(Location l){
    this.location = l;
  }
  public void setAdoptDate(Date adoptDate){
    this.adoptDate = adoptDate;
  }
  public void setEntraceSemester(Semester entrance){
    this.entranceSemester = entrance;
  }
  public void setEntranceDate(Date entranceDate){
    this.entranceDate = entranceDate;
  }
  public void setLeaveSemester(Semester leave){
    this.leaveSemester = leave;
  }
  public void setLeaveDate(Date leave){
    this.leaveDate = leave;
  }
  public void setProfessor(Professor prof){
    this.professor = prof;
  }
  public void setThesis(Thesis thesis){
    this.thesis = thesis;
  }
  public void setBirthday(Date birthday){
    this.birthday = birthday;
  }
  public void setReligion(String religion){
    this.religion = religion;
  }
  public void setRace(String race){
    this.race = race;
  }
  public void setNationality(String nationality){
    this.nationality = nationality;
  }
  public void setGender(String sex){
    this.gender = sex;
  }
  public void setOccupation(Occupation occ){
    this.occupation = occ;
  }
  public void setSalary(double salary){
    this.salary = salary;
  }
  public void setOldInstitute(String oldInstitute){
    this.oldInstitute = oldInstitute;
  }
  public void setOldDegree(String oldDegree){
    this.oldDegree = oldDegree;
  }
  public void setOldGPA(double oldGPA){
    this.oldGPA = oldGPA;
  }
  public void setOldLeaveYear(int leaveYear){
    this.oldLeaveYear = leaveYear;
  }
  public void setRegisterAddress(String registerAddress){
    this.registerAddress = registerAddress;
  }
  public void setRegisterTel(String registerTel){
    this.registerTel = registerTel;
  }
  public void setRecentAddress(String recentAddr){
    this.recentAddress = recentAddr;
  }
  public void setRecentTel (String recentTel){
    this.recentTel = recentTel;
  }
  public void setFatherName(String fname){
    this.fatherName = fname;
  }
  public void setFatherOccupation(Occupation  focc){
    this.fatherOccupation = focc;
  }
  public void setMotherName(String mname){
    this.motherName = mname;
  }
  public void setMotherOccupation(Occupation mocc){
    this.motherOccupation = mocc;
  }
  public void setCoupleName(String cname){
    this.coupleName = cname;
  }
  public void setCoupleOccupation(Occupation cocc){
    this.coupleOccupation = cocc;
  }
  public void setChildren(int no){
    this.children = no;
  }
  public void setParentName(String pname){
    this.parentName = pname;
  }
  public void setRelation(String relation){
    this.relation = relation;
  }
  public void setParentAddress(String pAddr){
    this.parentAddress = pAddr;
  }
  public void setParentTel(String pTel){
    this.parentTel = pTel;
  }
  //Business Method
  //---------------------------------------------------------------------scholarshipVector-------------------------------------------------------------
  public void addScholarship(Scholarship ss){
    scholarshipVector.addElement(ss);
  }
  public void setScholarship(Vector ss){
    scholarshipVector = ss;
  }
  public Enumeration retrieveScholarship(){
    return scholarshipVector.elements();
  }
  public Scholarship retrieveScholarship(long sID){
    Enumeration e = retrieveScholarship();
    while (e.hasMoreElements()){
      Scholarship s = (Scholarship)e.nextElement();
      if (s.getID() == sID)
        return s;
    }
    return null;
  }
  //-------------------------------------------------------------------------debtVector------------------------------------------------------------------
  public void addDebt(Debt d){
    debtVector.addElement(d);
  }
  public void setDebt(Vector d){
    debtVector = d;
  }
  public Enumeration retrieveDebt(){
    return debtVector.elements();
  }
  public Debt retrieveDebt(long dID){
    Enumeration e = retrieveDebt();
    while (e.hasMoreElements()){
      Debt d = (Debt)e.nextElement();
      if (d.getDebtID() == dID)
        return d;
    }
    return null;
  }
  //---------------------------------------------------------------------registrationVector----------------------------------------------------------
  public void addRegistration(Registration r){
    registrationVector.addElement(r);
  }
  public void setRegistration(Vector r){
    registrationVector = r;
  }
  public Enumeration retrieveRegistration(){
    return registrationVector.elements();
  }
  public Registration retrieveRegistration(long regis){
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
        Registration registration = (Registration)e.nextElement();
        if (registration.getRegistrationID() == regis)
          return registration;
    }
    return null;
  }
  //-------------------------------------------------------------------current Registration Vector------------------------------------------------
  public void addCurrentRegistration(Registration r){
    currentRegisterVector.addElement(r);
  }
  public void setCurrentRegistration(Vector r){
    currentRegisterVector = r;
  }
  public void clearCurrentRegistration(){
    currentRegisterVector = new Vector();
  }
  public Enumeration retrieveCurrentRegistration(){
    return currentRegisterVector.elements();
  }
  //Registration---------------------------------------------------------------------------------------------------------------------------------------
  public boolean verifyUsername(String user,String pass){
    return studentDB.verifyUsername(user,pass);
  }
  public Student retrieveStudent(Student student){
    Vector studentVector = studentDB.retrieveStudent(student);
    Enumeration e = studentVector.elements();
    if (!e.hasMoreElements()) return null;
    return (Student)e.nextElement();
  }
  public Faculty retrieveFaculty(){
    return studentDB.retrieveFaculty();
  }
  public Department retrieveDepartment(){
    return studentDB.retrieveDepartment();
  }
  public Major retrieveMajor(){
    return studentDB.retrieveMajor();
  }
  public boolean insertStudent(Student student){
    return studentDB.insertStudent(student);
  }
  public boolean updateStudent(Student student){
    return studentDB.updateStudent(student);
  }
  public boolean updateStudentForWeb(Student student){
    return studentDB.updateStudentForWeb(student);
  }
  public boolean checkPrerequisite(Subject prerequisite){
    Vector pre = prerequisite.getPrerequisite();
    Enumeration e = pre.elements();
    if (!e.hasMoreElements()) return false;
    Enumeration regEnum = registrationVector.elements();
    while (e.hasMoreElements()){
      Subject p = (Subject)e.nextElement();
      while (regEnum.hasMoreElements()){
        Registration r = (Registration)regEnum.nextElement();
        if (r.getSection().getSubject().getSubjectID().equals(p.getSubjectID()))
          return false;
      }
    }
    return true;
  }
  //ConvertGrade-------------------------------------------------------------------------------------------------------------------------------------
  public double convertGrade(String apha){
    apha = apha.trim();
    if (apha.equals("A")) return 4.00;
    else if (apha.equals("B+")) return 3.50;
    else if (apha.equals("B")) return 3.00;
    else if (apha.equals("C+")) return 2.50;
    else if (apha.equals("C")) return 2.00;
    else if (apha.equals("D+")) return 1.50;
    else if (apha.equals("D")) return 1.00;
    else if (apha.equals("F")) return 0.00;
    else return -1;
  }
  //GetCredit-------------------------------------------------------------------------------------------------------------------------------------------
  public Vector getCredit(){
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getType().trim().equals("Cr") && r.getRegisterType().getRegisterTypeID() != 1) v.addElement(r);
    }
    return v;
  }
  //GetNonCredit-------------------------------------------------------------------------------------------------------------------------------------
  public Vector getNonCredit(){
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getType().trim().equals("Nc") && r.getRegisterType().getRegisterTypeID() != 1) v.addElement(r);
    }
    return v;
  }
  //GetAudit-------------------------------------------------------------------------------------------------------------------------------------------
  public Vector getAudit(){
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getType().trim().equals("Ad") && r.getRegisterType().getRegisterTypeID() != 1) v.addElement(r);
    }
    return v;
  }
  //getCreditGECplus-------------------------------------------------------------------------------------------------------------------
  public Vector getCreditGECplus(){
    Vector v = new Vector();
    Enumeration e = getCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (convertGrade(r.getGrade()) >= 2.50) v.addElement(r);
    }
    return v;
  }
  //calculateCredit-------------------------------------------------------------------------------------------------------------------
  public double calculateCredit(){
    double sum=0.0;
    int total=0;
    Enumeration e = getCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      String g = r.getGrade().trim();
      int credit = r.getSection().getSubject().getCredit();
      if (g.equals("A") || g.equals("B+") || g.equals("B") || g.equals("C+") ||g.equals("C") ||
          g.equals("D+") || g.equals("D") || g.equals("F"))
      {
        sum += convertGrade(g)*credit;
        total += credit;
      }
    }
    return sum/total;
  }
  //getCreditLessThanCplus-------------------------------------------------------------------------------------------------------------------
  public Vector getCreditLTCplus(){
    Vector v = new Vector();
    Enumeration e = getCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (convertGrade(r.getGrade()) < 2.50) v.addElement(r);
    }
    return v;
  }
  //calculateNonCredit-------------------------------------------------------------------------------------------------------------------
  public double calculateNonCredit(){
    double sum=0.0;
    int total=0;
    Enumeration e = getNonCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      String g = r.getGrade().trim();
      int credit = r.getSection().getSubject().getCredit();
      if (g.equals("A") || g.equals("B+") || g.equals("B") || g.equals("C+") ||g.equals("C") ||
          g.equals("D+") || g.equals("D") || g.equals("F"))
      {
        sum += convertGrade(g)*credit;
        total += credit;
      }
    }
    return sum/total;
  }
  //getNonCreditGECplus-------------------------------------------------------------------------------------------------------------------
  public Vector getNonCreditGECplus(){
    Vector v = new Vector();
    Enumeration e = getNonCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (convertGrade(r.getGrade()) >= 2.50) v.addElement(r);
    }
    return v;
  }
  //getNonCreditLessThenCplus------------------------------------------------------------------------------------------------------------
  public Vector getNonCreditLTCplus(){
    Vector v = new Vector();
    Enumeration e = getNonCredit().elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (convertGrade(r.getGrade()) < 2.50) v.addElement(r);
    }
    return v;
  }
  //getIncomplete---------------------------------------------------------------------------------------------------------------------------------
  public Vector getIncomplete(){
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getGrade().trim().equals("I") && r.getSection().getSubject().getGroup().getGroup() != 1) v.addElement(r);
    }
    return v;
  }
  //isNewStudent--------------------------------------------------------------------------------------------------------------------------------
  public boolean isNewStudent(Semester currentSemester){
    int year = currentSemester.getYear() -2500 - Integer.parseInt(this.getStudentID().substring(0,2));
    if (year == 0 && currentSemester.getSemesterID() == this.getEntraceSemester().getSemesterID()) return true;
    else return false;
  }
  //getYearLimit--------------------------------------------------------------------------------------------------------------------------------
  public int getYearLimit(){
    switch (degree){
      case 1: return 5;
      case 2 : return 8;
      case 3 : return 5;
      case 4 : return 8;
      default : return 5;
    }
  }
  //getPreviousSemester--------------------------------------------------------------------------------------------------------------------------------
  public Semester getPreviousSemester(Semester currentSemester){
    int sem,year;
    sem = (currentSemester.getSemester()-1 == 0)?2:(currentSemester.getSemester()-1);
    year = (currentSemester.getSemester()-1 == 0)?(currentSemester.getYear()-1):currentSemester.getYear();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration s = (Registration)e.nextElement();
      if (s.getSemester().getSemester() == sem && s.getSemester().getYear() == year) return  s.getSemester() ;
    }
    return null;
  }
  //getLastRegistration--------------------------------------------------------------------------------------------------------------------------------
  public Vector getPreviousRegistration(Semester lastSemester) {
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getSemester().getSemesterID() == lastSemester.getSemesterID()) v.addElement(r);
    }
    return v;
  }
  //checkLastRegistration--------------------------------------------------------------------------------------------------------------------------------
  public boolean checkPreviousRegistration(Semester currentSemester){
    Semester sem = getPreviousSemester(currentSemester);
    Enumeration e = getPreviousRegistration(sem).elements();
    if (!e.hasMoreElements()) return false;
    Registration r = (Registration)e.nextElement();
    if (!e.hasMoreElements() && r.getRegisterType().getRegisterTypeID() == 5) return true;
    do
    {
      Registration reg = (Registration)e.nextElement();
      if (reg.getRegisterType().getRegisterTypeID() == 5) return true;
    } while (e.hasMoreElements());
    return false;
  }
  //getRemainingSemester--------------------------------------------------------------------------------------------------------------------------------
  public int getRemainingSemester(Semester currentSemester){
    int endSemester,endYear,tmps,tmpy,result;
    tmps = this.getEntraceSemester().getSemester();
    tmpy = this.getEntraceSemester().getYear();
    endSemester = (tmps == 1)?2:1;
    endYear = (tmps == 1)?tmpy+getYearLimit()-1:tmpy+getYearLimit();
    tmps = currentSemester.getSemester();
    tmpy = currentSemester.getYear();
    if (endSemester < tmps)
      result = (endYear - tmpy)*2;
    else if (endSemester == tmps)
      result = (endYear - tmpy)*2+1;
    else
      result = (endYear - tmpy + 1)*2;
    return result;
  }
  //checkSectionConflict--------------------------------------------------------------------------------------------------------------------------------
  public boolean checkSectionConflict(){
    Enumeration e = currentRegisterVector.elements();
    if (!e.hasMoreElements()) return false;
    Registration ck = (Registration)e.nextElement();
    if (!e.hasMoreElements()) return true;
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if ((r.getSection().getDay() == ck.getSection().getDay() &&
           r.getSection().getBeginTime().equals(ck.getSection().getBeginTime())) ||
          (r.getSection().getFinalDate().equals(ck.getSection().getFinalDate()) &&
           r.getSection().getFinalBtime().equals(ck.getSection().getFinalBtime()))) return false;
    }
    return true;
  }
  public boolean checkSectionConflict(Section section){
    Enumeration e = currentRegisterVector.elements();
    if (!e.hasMoreElements()) return false;
    Registration s = (Registration)e.nextElement();
    while (e.hasMoreElements()){
      s = (Registration)e.nextElement();
      if ((s.getSection().getDay() == section.getDay() &&
          s.getSection().getBeginTime().equals(section.getBeginTime())) ||
         (s.getSection().getFinalDate().equals(section.getFinalDate()) &&
          s.getSection().getFinalBtime().equals(section.getFinalBtime()))) return true;
    }
    return false;
  }
  public boolean checkSubjectConflict(Subject subject){
    Enumeration e = currentRegisterVector.elements();
    while (e.hasMoreElements()){
      Registration sub = (Registration)e.nextElement();
      if (sub.getSection().getSubject().getSubjectID().equals(subject.getSubjectID())) return true;
    }
    return false;
  }
  //sumRegistrationUnit--------------------------------------------------------------------------------------------------------------------------------
  public int sumRegistrationUnit(){
    int result=0;
    Enumeration e = currentRegisterVector.elements();
    if (!e.hasMoreElements()) return 0;
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      result += r.getSection().getSubject().getCredit();
    }
    return result;
  }
  //getCost------------------------------------------------------------------------------------------------------------------------------------------------
  public Cost getCost(int i){
    return (Cost)costVector.elementAt(i-1);
  }
  public void InitCost(){
    Cost cost = new Cost();
    costVector = cost.retrieveCost();
  }
  public double calculateCost(){
    Enumeration e = currentRegisterVector.elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      String type = r.getType().trim();
      if (type.equals("Cr")){
        totalCredit += r.getSection().getSubject().getCredit() * ((getCost(4) != null)?getCost(4).getValue():0.0);
      }
      else if (type.equals("Nc")) {
        totalNoncredit += r.getSection().getSubject().getCredit() * ((getCost(7) != null)?getCost(7).getValue():0.0);
      }
      else if (type.equals("Ad")) {
        totalAudit += r.getSection().getSubject().getCredit() * ((getCost(6) != null)?getCost(6).getValue():0.0);
      }
      else if (r.getSection().getSubject().getGroup().getGroup() == 1){
        totalThesis += r.getSection().getSubject().getCredit() * ((getCost(5) != null)?getCost(5).getValue():0.0);
      }
    }
    return totalCredit + totalNoncredit + totalAudit + totalThesis;
  }
  public double getTotalCredit(){
    return this.totalCredit;
  }
  public double getTotalNoncredit(){
    return this.totalNoncredit;
  }
  public double getTotalAudit(){
    return this.totalAudit;
  }
  public double getTotalThesis(){
    return this.totalThesis;
  }

  public double getSupport(){
    Support sup = new  Support();
    Vector v = sup.retrieveSupport(this.getMajor(),this.getStudyGroup(),this.getStudentType(),
                                   this.getLocation().getLocationID(),this.getNationalStatus());
    Enumeration e = v.elements();
    if (!e.hasMoreElements()) return 0.0;
    else return ((Support)e.nextElement()).getMoney();
  }

  public boolean checkCourseWorkComplete(Vector course,Vector register){
    Enumeration courseEnum = course.elements();
    Enumeration registerEnum = register.elements();
    while (courseEnum.hasMoreElements()){
      CourseUnit courseUnit = (CourseUnit)courseEnum.nextElement();
      if (courseUnit.getGroup().getGroup() != 1) {
        while (registerEnum.hasMoreElements()) {
          CourseUnit registerUnit = (CourseUnit) registerEnum.nextElement();
          if (courseUnit.getGroup().getGroup() ==
              registerUnit.getGroup().getGroup()) {
            if (courseUnit.getGroupUnit() > registerUnit.getGroupUnit())
              return false;
          }
        }
      }
    }
    return true;
  }

  public Vector retrieveRegistrationPerSemester(Semester semester){
    Vector v = new Vector();
    Enumeration e = retrieveRegistration();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      if (r.getSemester().getSemesterID() == semester.getSemesterID())
        v.addElement(r);
    }
    return v;
  }

  public double calculateCredit(Vector v){
    double sum=0.0;
    int total=0;
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      String g = r.getGrade().trim();
      int credit = r.getSection().getSubject().getCredit();
      if ((g.equals("A") || g.equals("B+") || g.equals("B") || g.equals("C+") ||g.equals("C") ||
          g.equals("D+") || g.equals("D") || g.equals("F")) && r.getType().trim().equals("Cr"))
      {
        sum += convertGrade(g)*credit;
        total += credit;
      }
    }
    this.total = total;
    return sum/total;
  }

  public int getAllCredit(){
    return this.total;
  }
}
