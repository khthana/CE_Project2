package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class CourseUI extends JFrame {
  BorderLayout borderLayout1 = new BorderLayout();
  Border border1;
  Border border2;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();
  Border border3;
  Border border4;
  BorderLayout borderLayout5 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  BorderLayout borderLayout6 = new BorderLayout();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout7 = new BorderLayout();
  BorderLayout borderLayout8 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("�дѺ");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  JPanel jPanel8 = new JPanel();
  JButton jButton3 = new JButton();
  JScrollPane jScrollPane2 = new JScrollPane();
  JPanel jPanel9 = new JPanel();
  BorderLayout borderLayout10 = new BorderLayout();
  JButton jButton4 = new JButton();
  JSplitPane jSplitPane2 = new JSplitPane();
  BorderLayout borderLayout11 = new BorderLayout();
  JPanel jPanel10 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  BorderLayout borderLayout13 = new BorderLayout();
  DefaultMutableTreeNode root2 = new DefaultMutableTreeNode("����Ԫ�");
  DefaultTreeModel treeModel2 = new DefaultTreeModel(root2);
  JTree jTree2 = new JTree(treeModel2);

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------
  CourseMainUI courseMainUI = null;
  Major major = null;
  Border border5;
  Border border6;
  Subject subject = new Subject();
  Section section = new Section();
  Semester semester = new Semester();
  boolean canAdd = false;
  CourseMasterUI courseMasterUI = new CourseMasterUI();
  CoursePhDUI coursePhDUI = new CoursePhDUI();
  CourseUnitUI courseUnitUI = new CourseUnitUI();
  SubjectUI subjectUI = new SubjectUI(this);
  SectionUI sectionUI = new SectionUI(this);
  BoxLayout2 boxLayout21 = new BoxLayout2();
  BoxLayout2 boxLayout22 = new BoxLayout2();

  public CourseUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public CourseUI(CourseMainUI courseMainUI) {
    try {
      this.courseMainUI = courseMainUI;
      this.major = courseMainUI.getMajor();
      courseMasterUI.setMajor(this.major);
      coursePhDUI.setMajor(this.major);
      courseUnitUI.setMajor(this.major);
      courseUnitUI.initial();
      subjectUI.setMajor(this.major);
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    border5 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(165, 163, 151));
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    border2 = BorderFactory.createEmptyBorder(10,5,5,5);
    border3 = BorderFactory.createEmptyBorder(10,5,5,5);
    border4 = BorderFactory.createEmptyBorder(5,5,5,5);
    this.getContentPane().setLayout(borderLayout1);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setSize(new Dimension(800, 601));
    this.setTitle("��ѡ�ٵ�/����Ԫ�");
    jPanel1.setLayout(borderLayout2);
    jPanel3.setLayout(borderLayout4);
    jPanel1.setBorder(border3);
    jPanel1.setPreferredSize(new Dimension(600, 550));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setPreferredSize(new Dimension(590, 540));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setPreferredSize(new Dimension(590, 540));
    jPanel2.setLayout(borderLayout5);
    jTabbedPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTabbedPane1.setPreferredSize(new Dimension(600, 550));
    jPanel4.setLayout(borderLayout6);
    jSplitPane1.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jSplitPane1.setPreferredSize(new Dimension(590, 540));
    jPanel5.setLayout(borderLayout7);
    jPanel6.setLayout(borderLayout8);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setPreferredSize(new Dimension(590, 540));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setPreferredSize(new Dimension(200, 530));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setPreferredSize(new Dimension(190, 530));
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTree1.setMaximumSize(new Dimension(190, 530));
    jTree1.setPreferredSize(new Dimension(150, 480));
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setPreferredSize(new Dimension(380, 530));
    jPanel8.setLayout(boxLayout21);
    jButton3.setText("ź");
    jButton3.addActionListener(new CourseUI_jButton3_actionAdapter(this));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setMaximumSize(new Dimension(100, 25));
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane2.setPreferredSize(new Dimension(190, 530));
    jScrollPane2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel9.setLayout(borderLayout13);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel9.setPreferredSize(new Dimension(590, 540));
    jButton4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton4.setMaximumSize(new Dimension(100, 25));
    jButton4.setPreferredSize(new Dimension(80, 25));
    jButton4.setToolTipText("");
    jButton4.setText("����");
    jButton4.addActionListener(new CourseUI_jButton4_actionAdapter(this));
    jSplitPane2.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    jSplitPane2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jSplitPane2.setPreferredSize(new Dimension(590, 540));
    jPanel10.setLayout(borderLayout11);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel10.setPreferredSize(new Dimension(200, 580));
    jPanel11.setLayout(boxLayout22);
    jPanel12.setLayout(flowLayout2);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel13.setLayout(borderLayout10);
    jPanel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel13.setPreferredSize(new Dimension(380, 530));
    jTree2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTree2.setMaximumSize(new Dimension(190, 530));
    jTree2.setPreferredSize(new Dimension(150, 480));
    jPanel8.setPreferredSize(new Dimension(380, 530));
    jPanel11.setPreferredSize(new Dimension(380, 530));
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    this.getContentPane().add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jTabbedPane1,  BorderLayout.CENTER);
    jTabbedPane1.add(jPanel2,   "��ѡ�ٵ�");
    jPanel2.add(jPanel4,  BorderLayout.CENTER);
    jPanel4.add(jSplitPane1, BorderLayout.CENTER);
    jSplitPane1.add(jPanel5, JSplitPane.TOP);
    jPanel5.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jSplitPane1.add(jPanel6, JSplitPane.BOTTOM);
    jPanel6.add(jPanel8,  BorderLayout.CENTER);
    jTabbedPane1.add(jPanel3,   "����Ԫ�");
    jPanel3.add(jPanel9,  BorderLayout.CENTER);
    jPanel9.add(jSplitPane2, BorderLayout.CENTER);
    jPanel10.add(jScrollPane2, BorderLayout.CENTER);
    jScrollPane2.getViewport().add(jTree2, null);
    jPanel10.add(jPanel12, BorderLayout.SOUTH);
    jPanel12.add(jButton4, null);
    jPanel12.add(jButton3, null);
    jSplitPane2.add(jPanel13, JSplitPane.BOTTOM);
    jPanel13.add(jPanel11, BorderLayout.CENTER);
    jSplitPane2.add(jPanel10, JSplitPane.TOP);
    createTree();
    createSubjectTree();
    jPanel8.add(courseMasterUI, null);
    jPanel8.add(courseUnitUI, null);
    jPanel8.add(coursePhDUI, null);
    coursePhDUI.setVisible(true);
    courseMasterUI.setVisible(false);
    courseUnitUI.setVisible(false);
    jPanel11.add(sectionUI, null);
    jPanel11.add(subjectUI, null);
    sectionUI.setVisible(false);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());
    jTree2.addTreeSelectionListener(new TreeSelectionListener2());
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode) jTree1.getLastSelectedPathComponent();
      String str;
      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String){
        str = (String)nodeInfo;
        coursePhDUI.setVisible(false);
        courseMasterUI.setVisible(false);
        courseUnitUI.setVisible(false);
        if (str.trim().equals("�͡")){
          coursePhDUI.setVisible(true);
          coursePhDUI.showUI(major);
        }
        else if (str.trim().equals("�")){
          courseMasterUI.setVisible(true);
          courseMasterUI.showUI(major);
        }
        else if (str.trim().equals("Ẻ��� 1 ����ԭ���")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(1);
        }
        else if (str.trim().equals("Ẻ��� 1 ����ԭ�ҵ��")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(2);
        }
        else if (str.trim().equals("Ẻ��� 2 ����ԭ���")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(3);
        }
        else if (str.trim().equals("Ẻ��� 2 ����ԭ�ҵ��")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(4);
        }
        else if (str.trim().equals("Ἱ �1")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(5);
        }
        else if (str.trim().equals("Ἱ �2")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(6);
        }
        else if (str.trim().equals("Ἱ �")){
          courseUnitUI.setVisible(true);
          courseUnitUI.showUI(7);
        }
      }
    }
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener2 implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode) jTree2.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String){
        canAdd = true;
      }
      else if (nodeInfo instanceof Subject){
        canAdd = true;
        subject = (Subject)nodeInfo;
        subjectUI.setVisible(true);
        sectionUI.setVisible(false);
        subjectUI.showUI(subject);
      }
      else if (nodeInfo instanceof Section){
        canAdd = false;
        DefaultMutableTreeNode subjectNode  = (DefaultMutableTreeNode)node1.getParent();
        subject = (Subject)subjectNode.getUserObject();
        section = (Section)nodeInfo;
        subjectUI.setVisible(false);
        sectionUI.setVisible(true);
        sectionUI.showUI(section);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void clearTree(){
    root.removeAllChildren();
    treeModel.reload();
  }
  public void addNode(Object obj){
      DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree2.getSelectionPath().getLastPathComponent();
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
      DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
      if (canAdd) {
        int newIndex = lastItem.getChildCount();
        treeModel2.insertNodeInto(newNode, lastItem, newIndex);
      }
      else {
        int newIndex = parent.getIndex(lastItem);
        treeModel2.insertNodeInto(newNode, parent, newIndex+1);
      }
      jTree2.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void updateNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree2.getSelectionPath().getLastPathComponent();
    lastItem.setUserObject(obj);
    jTree2.repaint();
  }
  public void createTree() {
      DefaultMutableTreeNode degree = null ;
      DefaultMutableTreeNode pt = null;
      DefaultMutableTreeNode mbn = null;
      String[] deg ={"A�͡","BẺ��� 1 ����ԭ���","BẺ��� 1 ����ԭ�ҵ��","BẺ��� 2 ����ԭ���","BẺ��� 2 ����ԭ�ҵ��",
          "A�","BἹ �1","BἹ �2","BἹ �"};

      for(int i=0; i<deg.length; i++){
              char linetype = deg[i].charAt(0);
              switch(linetype) {
                 case 'A':
                   degree = new DefaultMutableTreeNode(deg[i].substring(1));
                   root.add(degree);
                   break;
                 case 'B':
                   if(degree != null) {
                       degree.add(pt = new DefaultMutableTreeNode(deg[i].substring(1)));
                   }
                   break;
                 case 'C':
                   if(pt != null) {
                       pt.add(mbn = new DefaultMutableTreeNode(deg[i].substring(1)));
                   }
                   break;
                 case 'D':
                   if(mbn != null) {
                       mbn.add(new DefaultMutableTreeNode(deg[i].substring(1)));
                   }
                   break;
                 default:
                   break;
              }
            }
            jTree1.expandRow(0);
  }

  public void createSubjectTree(){
    Database.connect();
    DefaultMutableTreeNode subjectNode = null;
    DefaultMutableTreeNode sectionNode = null;

    Vector subjectVector = subject.retrieveSubject(major);
    Enumeration subjectEnum = subjectVector.elements();
    while (subjectEnum.hasMoreElements()){
      Subject subj = (Subject)subjectEnum.nextElement();
      subjectNode = new DefaultMutableTreeNode(subj);
      root2.add(subjectNode);

      Vector sectionVector = section.retrieveSection(subj);
      Enumeration sectionEnum = sectionVector.elements();
      while (sectionEnum.hasMoreElements()){
        Section sec = (Section)sectionEnum.nextElement();
        sectionNode = new DefaultMutableTreeNode(sec);
        subjectNode.add(sectionNode);
      }
    }

    Database.disconnect();
    jTree2.expandRow(0);
  }

  void jButton4_actionPerformed(ActionEvent e) {//Add Button
    DefaultMutableTreeNode node1 = (DefaultMutableTreeNode) jTree2.getLastSelectedPathComponent();

    if (node1 == null) return;
    Object nodeInfo = node1.getUserObject();
    if (nodeInfo instanceof String){
      subjectUI.addSubject(subject);
      subjectUI.setVisible(true);
      sectionUI.setVisible(false);
    }
    else if (nodeInfo instanceof Subject || nodeInfo instanceof Section){
      sectionUI.addSection(subject);
      subjectUI.setVisible(false);
      sectionUI.setVisible(true);
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) jTree2.getSelectionPath().getLastPathComponent();
    if (currentNode == null) return;
    Object nodeInfo = currentNode.getUserObject();
    if (currentNode != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode) currentNode.
          getParent();
      if (currentNode.isLeaf() && parent != null){
        if (nodeInfo instanceof Subject) {
          complete = subjectUI.removeSubject(subject);
        }
        else if (nodeInfo instanceof Section) {
          complete = sectionUI.removeSection(section);
        }
        if (complete) treeModel2.removeNodeFromParent(currentNode);
      }
    }
  }
}

class CourseUI_jButton4_actionAdapter implements java.awt.event.ActionListener {
  CourseUI adaptee;

  CourseUI_jButton4_actionAdapter(CourseUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class CourseUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  CourseUI adaptee;

  CourseUI_jButton3_actionAdapter(CourseUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}