package graduate;

import java.util.*;
public class Payment {
  private RegisterType registerType;
  private Cost cost;
  private PaymentDB paymentDB = new PaymentDB();
  private int nos;
  //Constructor
  public Payment() {
  }
  //getMethod
  public RegisterType getRegisterType(){
    return this.registerType;
  }
  public Cost getCost(){
    return this.cost;
  }
  public int getNos(){
    return this.nos;
  }
  //setMethod
  public void setRegisterType(RegisterType r){
    this.registerType = r;
  }
  public void setCost(Cost cost){
    this.cost = cost;
  }
  public void setNos(int nos){
    this.nos = nos;
  }
  public Vector retrievePayment(){
    return paymentDB.retrievePaymentAll();
  }
  public double retrievePayment(RegisterType registerType,int status){
    return paymentDB.retrievePayment(registerType,status);
  }
  public boolean insertPayment(Payment p){
    return paymentDB.insertPayment(p);
  }
/*  public boolean updatePayment(Payment p){
    return paymentDB.updatePayment(p);
  }*/
  public boolean deletePayment(Payment p){
    return paymentDB.deletePayment(p);
  }
}