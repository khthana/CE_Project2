package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class MinorUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel2 = new JPanel();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  FlowLayout flowLayout5 = new FlowLayout();
  JPanel jPanel19 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  JTextField minorEnameText = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel10 = new JPanel();
  JLabel jLabel2 = new JLabel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JTextField minorTnameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  FlowLayout flowLayout4 = new FlowLayout();
  JTextField minorIDText = new JTextField();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel16 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  JButton clearText = new JButton();
  //--------------------------------------------------------------------------------------------------------------------------------------------------------------
  JPanel generalPanel = null;
  Major major = null;
  Minor minor = null;
  boolean newRecord = false;

  public MinorUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public MinorUI(JPanel general) {
    try {
      jbInit();
      generalPanel = general;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel4.setBorder(null);
    jPanel4.setOpaque(true);
    jPanel4.setPreferredSize(new Dimension(440, 180));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 200));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "��������´ᢹ��Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel2.setBorder(titledBorder1);
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("����ᢹ��Ԫ� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setText("����ᢹ��Ԫ�[�] :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    minorEnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    minorEnameText.setPreferredSize(new Dimension(380, 22));
    minorEnameText.setText("");
    flowLayout2.setAlignment(FlowLayout.LEFT);
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(4);
    gridLayout1.setVgap(5);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("����ᢹ��Ԫ�[�] :");
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(4);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setOpaque(true);
    jPanel12.setPreferredSize(new Dimension(440, 120));
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    flowLayout3.setAlignment(FlowLayout.LEFT);
    minorTnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    minorTnameText.setPreferredSize(new Dimension(380, 22));
    minorTnameText.setText("");
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 120));
    flowLayout4.setAlignment(FlowLayout.LEFT);
    minorIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    minorIDText.setOpaque(true);
    minorIDText.setPreferredSize(new Dimension(380, 22));
    minorIDText.setText("");
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    jPanel16.setPreferredSize(new Dimension(161, 35));
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setLayout(flowLayout1);
    flowLayout1.setVgap(15);
    flowLayout1.setHgap(5);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new MinorUI_saveButton_actionAdapter(this));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearText.setText("������");
    clearText.addActionListener(new MinorUI_clearText_actionAdapter(this));
    clearText.setPreferredSize(new Dimension(80, 25));
    clearText.setMaximumSize(new Dimension(100, 25));
    clearText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(jPanel4, null);
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel9.add(jPanel17, null);
    jPanel17.add(minorIDText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(minorTnameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(minorEnameText, null);
    jPanel4.add(jPanel16, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearText, null);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
  }
  public void showUI(Minor minor){
    newRecord = false;
    this.minor = minor;
    minorIDText.setText(minor.getMinorID());
    minorTnameText.setText(minor.getTname());
    minorEnameText.setText(minor.getEname());
  }
  public void clear(){
    minorIDText.setText("");
    minorEnameText.setText("");
    minorTnameText.setText("");
  }
  public void clearText_actionPerformed(ActionEvent e) {
    clear();
  }
  public void addMinor(Major major){
    newRecord = true;
    this.major = major;
    clear();
  }
  public boolean removeMinor(Minor minor){
    Database.connect();
    boolean complete = this.minor.deleteMinor(minor);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }
  void saveButton_actionPerformed(ActionEvent e) {
    Database.connect();
    Minor minor = new Minor();
    minor.setMinorID(minorIDText.getText());
    minor.setEname(minorEnameText.getText());
    minor.setTname(minorTnameText.getText());
    minor.setMajor(this.major);
    if (newRecord) {
      if (minor.insertMinor(minor)) ((GeneralUI)generalPanel).addNode(4,minor);
    }
    else {
      if (minor.updateMinor(this.minor,minor)); ((GeneralUI)generalPanel).updateNode(minor);
    }
    Database.disconnect();
  }
}

class MinorUI_clearText_actionAdapter implements java.awt.event.ActionListener {
  MinorUI adaptee;

  MinorUI_clearText_actionAdapter(MinorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearText_actionPerformed(e);
  }
}

class MinorUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  MinorUI adaptee;

  MinorUI_saveButton_actionAdapter(MinorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}