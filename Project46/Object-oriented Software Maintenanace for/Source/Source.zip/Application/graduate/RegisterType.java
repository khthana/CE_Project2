package graduate;

import java.util.*;
public class RegisterType {
  private long registerTypeID;
  private  String registerTypeName;
  private RegisterTypeDB registerTypeDB = new RegisterTypeDB();
  //Constructor
  public RegisterType() {
  }
  public RegisterType(long id){
    this.setRegisterTypeID(id);
  }
  public RegisterType(String name){
    this.setRegisterTypeName(name);
  }
  public RegisterType(long id, String name){
    this.setRegisterTypeID(id);
    this.setRegisterTypeName(name);
  }
  //getMethod
  public long getRegisterTypeID(){
    return this.registerTypeID;
  }
  public String getRegisterTypeName(){
    return this.registerTypeName;
  }
  //setMethod
  public void setRegisterTypeID(long registerTypeID){
    this.registerTypeID = registerTypeID;
  }
  public void setRegisterTypeName(String registerTypeName){
    this.registerTypeName = registerTypeName;
  }
  public Vector retrieveRegisterType(){
    return registerTypeDB.retrieveRegisterType();
  }
  public boolean insertRegisterType(RegisterType rt){
    return registerTypeDB.insertRegisterType(rt);
  }
  public boolean updateRegisterType(RegisterType rt){
    return registerTypeDB.updateRegisterType(rt);
  }
  public boolean deleteRegisterType(RegisterType rt){
    return registerTypeDB.deleteRegisterType(rt);
  }
}