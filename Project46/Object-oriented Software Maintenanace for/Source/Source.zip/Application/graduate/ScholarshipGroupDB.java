package graduate;

import java.sql.*;
import java.util.*;
public class ScholarshipGroupDB {
  public ScholarshipGroupDB() {
  }
  public Vector retrieveScholarShipGroup(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM ScholarshipGroup ORDER BY ScholarshipGroupName";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          ScholarshipGroup scholarshipGroup = new ScholarshipGroup();
          scholarshipGroup.setSgroupID(rs.getInt("ScholarshipGroupID"));
          scholarshipGroup.setSgroupName(rs.getString("ScholarshipGroupName"));
          v.addElement(scholarshipGroup);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;

  }
  public boolean insertScholarshipGroup(ScholarshipGroup scholarshipGroup){
    String query = "INSERT INTO ScholarshipGroup(ScholarshipGroupName) ";
    query += "VALUES('" + scholarshipGroup.getSgroupName() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateScholarshipGroup(ScholarshipGroup scholarshipGroup){
    String query = "UPDATE ScholarshipGroup SET ";
    query += "ScholarshipGroupName = '" + scholarshipGroup.getSgroupName() + "' ";
    query += "WHERE ScholarshipGroupID = " + scholarshipGroup.getSgroupID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteScholarshipGroup(ScholarshipGroup scholarshipGroup){
    String query = "DELETE FROM ScholarshipGroup WHERE ScholarshipGroupID = '" + scholarshipGroup.getSgroupID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ScholarshipGroupDB db = new ScholarshipGroupDB();
    ScholarshipGroup s = new ScholarshipGroup(1,"TTTT");
//    db.updateScholarshipGroup(s);
    Vector v = db.retrieveScholarShipGroup();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      ScholarshipGroup ss = (ScholarshipGroup)e.nextElement();
      System.out.println(ss.getSgroupID() + " " + ss.getSgroupName());
    }
    Database.disconnect();
  }

}