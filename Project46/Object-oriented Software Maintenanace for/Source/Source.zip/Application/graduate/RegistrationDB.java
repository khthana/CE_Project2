package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class RegistrationDB {
  public RegistrationDB() {
  }
  public Vector retrieveRegistration(Student student){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,s.SubjectID,s.SubjectEname,s.SubjectTname,s.GroupID,s.Credit,c.Sec,c.Status,sem.*,rt.* ";
        query += "FROM Registration r,Subject s,Section c,Semester sem,RegisterType rt,Student stud WHERE ";
        query += "r.SectionID = c.SectionID AND c.SubjectID = s.SubjectID AND ";
        query += "r.RegisterTypeID = rt.RegisterTypeID AND r.SemesterID = sem.SemesterID AND ";
        query += "r.StudentID = stud.StudentID AND stud.Status = 1 AND ";
        query += "r.StudentID = '" + student.getStudentID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Registration reg = new Registration(rs.getLong("RegistrationID"));
          reg.setStudent(student);
          Subject subject = new Subject();
          subject.setSubjectID(rs.getString("SubjectID"));
          subject.setSubjectEname(rs.getString("SubjectEname"));
          subject.setSubjectTname(rs.getString("SubjectTname"));
          subject.setGroup(new Group(rs.getLong("GroupID")));
          subject.setCredit(rs.getInt("Credit"));
          Section section = new Section();
          section.setSubject(subject);
          section.setSec(rs.getInt("Sec"));
          section.setStatus(rs.getBoolean("Status"));
          subject.addSection(section);
          reg.setSection(section);
          Semester semester = new Semester();
          semester.setSemesterID(rs.getLong("SemesterID"));
          semester.setYear(rs.getInt("Year"));
          semester.setSemester(rs.getInt("SemesterNo"));
          semester.setSemesterType(rs.getInt("SemesterType"));
          semester.setCurrentSemester(rs.getBoolean("CurrentSemester"));
          reg.setSemester(semester);
          RegisterType registerType = new RegisterType();
          registerType.setRegisterTypeID(rs.getLong("RegisterTypeID"));
          registerType.setRegisterTypeName(rs.getString("RegisterType"));
          reg.setRegisterType(registerType);
          reg.setType(rs.getString("Type"));
          reg.setGrade(rs.getString("Grade"));
          reg.setPayDate(rs.getDate("payDate"));
          Registrar re = new Registrar();
          reg.setRegistrar(re);
          v.addElement(reg);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }

  public Vector retrieveRegistration(Section sec){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,s.StudentID,s.StudentTname,s.StudentEname FROM Registration r,Student s ";
        query += "WHERE r.StudentID = s.StudentID and r.SectionID = " + sec.getSectionID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Student stud = new Student();
          stud.setStudentID(rs.getString("StudentID"));
          stud.setStudentTname(rs.getString("StudentEname"));
          stud.setStudentTname(rs.getString("StudentTname"));
          Registration reg = new Registration(rs.getLong("RegistrationID"));
          reg.setStudent(stud);
          reg.setType(rs.getString("Type"));
          reg.setGrade(rs.getString("Grade"));
          v.addElement(reg);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveSemesterRegistered(Student student){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Semester WHERE SemesterID in (SELECT r.SemesterID FROM Semester s,Registration r ";
        query += "WHERE r.SemesterID = s.SemesterID AND r.StudentID = '" + student.getStudentID() + "' ";
        query += "GROUP BY r.SemesterID)";
        ResultSet rs = Database.getResultSet(query);

          while(rs.next()){
            Semester semester = new Semester();
            semester.setSemesterID(rs.getLong("SemesterID"));
            semester.setYear(rs.getInt("Year"));
            semester.setSemester(rs.getInt("SemesterNo"));
            semester.setSemesterType(rs.getInt("SemesterType"));
            v.addElement(semester);
          }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean isRegistered(Student student,Subject subject){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Registration r WHERE r.StudentID = '" + student.getStudentID() + "' AND ";
        query += "(r.Grade='A' Or r.Grade='B+' Or r.Grade='B' Or ";
        query += "r.Grade='C+' Or r.Grade='S' Or r.Grade='O' Or r.Grade='G' Or r.Grade='P') And r.Type='Cr' AND ";
        query += "SectionID in (Select SectionID FROM Section where SubjectID = '" + subject.getSubjectID() + "')";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          return true;
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return  false;
  }
  public boolean isPrerequisiteRegistered(Student student,Subject subject){
    Vector v = new Vector();
    try
    {
        String query = "SELECT count(*) as studied FROM Registration r WHERE r.StudentID = '" + student.getStudentID() + "' AND ";
        query += "(r.Grade='A' Or r.Grade='B+' Or r.Grade='B' Or ";
        query += "r.Grade='C+' Or r.Grade='S' Or r.Grade='O' Or r.Grade='G' Or r.Grade='P') And r.Type='Cr' AND ";
        query += "SectionID in (Select SectionID FROM Section where SubjectID in (SELECT PrerequisiteID FROM ";
        query += "Prerequisite WHERE SubjectID = '" + subject.getSubjectID() + "'))";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          int studied = rs.getInt("studied");
          if (studied > 0)
          return true;
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return  false;
  }
  public Vector retrieveRegistration(Student student,Semester semester,RegisterType regt){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,s.SubjectID,s.SubjectEname,s.SubjectTname,s.GroupID,s.Credit,c.* ";
        query += "FROM Registration r,Subject s,Section c,Student stud WHERE ";
        query += "r.SectionID = c.SectionID AND c.SubjectID = s.SubjectID AND ";
        query += "r.StudentID = stud.StudentID AND stud.Status = 1 AND ";
        query += "r.RegisterTypeID = " + regt.getRegisterTypeID() + " AND ";
        query += "r.StudentID = '" + student.getStudentID() + "' AND r.SemesterID = " + semester.getSemesterID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Registration reg = new Registration(rs.getLong("RegistrationID"));
          reg.setStudent(student);
          Subject subject = new Subject();
          subject.setSubjectID(rs.getString("SubjectID"));
          subject.setSubjectEname(rs.getString("SubjectEname"));
          subject.setSubjectTname(rs.getString("SubjectTname"));
          subject.setGroup(new Group(rs.getLong("GroupID")));
          subject.setCredit(rs.getInt("Credit"));
          Section section = new Section();
          section.setSubject(subject);
          section.setStatus(rs.getBoolean("Status"));
          section.setSec(rs.getInt("Sec"));
          section.setFinalBtime(rs.getString("FinalBtime"));
          section.setFinalDate(rs.getDate("FinalDate"));
          section.setFinalEtime(rs.getString("FinalEtime"));
          section.setFinalRoom(rs.getString("FinalRoom"));
          subject.addSection(section);
          reg.setSection(section);
          reg.setSemester(semester);
          reg.setRegisterType(regt);
          reg.setType(rs.getString("Type"));
          reg.setGrade(rs.getString("Grade"));
          reg.setPayDate(rs.getDate("payDate"));
          Registrar re = new Registrar();
          reg.setRegistrar(re);
          v.addElement(reg);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public int countTermRegisted(Student student){
    int i = 0;
  try
  {
    String query = "SELECT semesterid FROM registration WHERE registertypeid in (2,3,4,7,8,9) AND ";
    query += "StudentID = '" + student.getStudentID() + "' GROUP BY semesterid";
    ResultSet rs = Database.getResultSet(query);
    while(rs.next()){
      i++;
    }
  }
  catch(SQLException sqlex)
  {
      System.out.println(sqlex.toString());
  }
  return i;
}
  public Vector retrieveGroupedCourseWork(Student student){
    Vector v = new Vector();
    try
    {
      String query = "SELECT sum(s.Credit) AS SumCredit, s.GroupID, sg.GroupName ";
      query += "FROM Registration AS r, Section AS sec, Subject AS s, SubjectGroup AS sg ";
      query += "WHERE r.SectionID=sec.SectionID And sec.SubjectID=s.SubjectID And ";
      query += "s.GroupID=sg.GroupID And (r.Grade='A' Or r.Grade='B+' Or r.Grade='B' Or ";
      query += "r.Grade='C+' Or r.Grade='S' Or r.Grade='O' Or r.Grade='G' Or r.Grade='P') And r.Type='Cr' ";
      query += "And StudentID= '" + student.getStudentID() + "' ";
      query +="GROUP BY s.GroupID, sg.GroupName";

      ResultSet rs = Database.getResultSet(query);

      while(rs.next()){
        CourseUnit cu = new CourseUnit();
        cu.setGroup(new Group(rs.getLong("GroupID"),rs.getString("GroupName")));
        cu.setGroupUnit(rs.getInt("SumCredit"));
        v.addElement(cu);
      }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertRegistration(Registration registration){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Registration(StudentID,SectionID,SemesterID,RegisterTypeID,";
    query += "Type,Grade,PayDate,RegistrarID)";
    query += "VALUES('"+ registration.getStudent().getStudentID() + "' , " + registration.getSection().getSectionID();
    query += ", " + registration.getSemester().getSemesterID() + "," + registration.getRegisterType().getRegisterTypeID();
    query += ", '" + registration.getType() + "','" + registration.getGrade() + "','" + formatter.format(registration.getPayDate()) + "'";
    query += ", '" +  registration.getRegistrar().getRegistrarID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateRegistration(Registration registration){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Registration SET ";
/*    query += "StudentID = '" + registration.getStudent().getStudentID() + "', ";
    query += "SectionID = " + registration.getSection().getSectionID() + ", ";
    query += "SemesterID = " + registration.getSemester().getSemesterID() + ", ";
    query += "RegisterTypeID = " + registration.getRegisterType().getRegisterTypeID() + ", ";*/
    query += "Type = '" + registration.getType() + "', ";
    query += "Grade = '" + registration.getGrade() + "' ";
/*    query += "PayDate = '" + formatter.format(registration.getPayDate()) + "', ";
    query += "RegistrarID = '" + registration.getRegistrar().getRegistrarID() + "' ";*/
    query += "WHERE RegistrationID = " + registration.getRegistrationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteRegistration(Registration registration){
    String query = "DELETE FROM Registration WHERE RegistrationID = " + registration.getRegistrationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect();
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    RegistrationDB db = new RegistrationDB();
    Registration r = new Registration(1);
    r.setStudent(new Student("001"));
    r.setSection(new Section(2));
    r.setSemester(new Semester(1));
    r.setRegisterType(new RegisterType(2));
    r.setType("Cr");
    GregorianCalendar g = new GregorianCalendar(2004,0,1);
    java.util.Date d = g.getTime();
    r.setPayDate(d);
    r.setRegistrar(new Registrar("001"));
//    System.out.print(db.isRegistered(new Student("001"),new Subject("00100000")));
    System.out.print(db.countTermRegisted(new Student("001")));
    Database.disconnect();
  }

}