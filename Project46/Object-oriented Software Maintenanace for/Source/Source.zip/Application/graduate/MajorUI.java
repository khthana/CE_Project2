package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;

public class MajorUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel2 = new JPanel();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  FlowLayout flowLayout5 = new FlowLayout();
  JPanel jPanel19 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel25 = new JPanel();
  JTextField majorEnameText = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  GridLayout gridLayout1 = new GridLayout();
  JPanel jPanel10 = new JPanel();
  JLabel jLabel2 = new JLabel();
  BorderLayout borderLayout8 = new BorderLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel17 = new JPanel();
  FlowLayout flowLayout3 = new FlowLayout();
  JTextField majorTnameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  FlowLayout flowLayout4 = new FlowLayout();
  JTextField majorIDText = new JTextField();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel16 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  JPanel generalPanel = null;
//-------------------------------------------------------------------------------------------------------------------------------------------------------------
  Department department= null;
  Major major = null;
  boolean newRecord = false;

  public MajorUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public MajorUI(JPanel general) {
    try {
      jbInit();
      generalPanel = general;
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel4.setBorder(null);
    jPanel4.setPreferredSize(new Dimension(440, 240));
    jPanel4.setRequestFocusEnabled(true);
    jPanel4.setLayout(boxLayout22);
    jPanel4.setLayout(boxLayout22);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 250));
    jPanel2.setLayout(boxLayout21);
    titledBorder6 = new TitledBorder(null, "��������´�Ң��Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(10,10,10,10));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 11));
    jPanel2.setBorder(titledBorder1);
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel19.setLayout(flowLayout4);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel19.setPreferredSize(new Dimension(350, 32));
    jPanel19.setRequestFocusEnabled(true);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setPreferredSize(new Dimension(62, 16));
    jLabel1.setText("�����Ң��Ԫ� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setMaximumSize(new Dimension(100, 16));
    jLabel3.setOpaque(true);
    jLabel3.setText("�����Ң��Ԫ�[�] :");
    jPanel25.setLayout(borderLayout8);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorEnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorEnameText.setPreferredSize(new Dimension(380, 22));
    majorEnameText.setText("");
    flowLayout2.setAlignment(FlowLayout.LEFT);
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(4);
    gridLayout1.setVgap(5);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setOpaque(false);
    jLabel2.setText("�����Ң��Ԫ�[�] :");
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(4);
    gridLayout2.setVgap(5);
    jPanel12.setLayout(flowLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(440, 220));
    jPanel18.setLayout(flowLayout3);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setPreferredSize(new Dimension(300, 32));
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    flowLayout3.setAlignment(FlowLayout.LEFT);
    majorTnameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorTnameText.setPreferredSize(new Dimension(380, 22));
    majorTnameText.setText("");
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(440, 120));
    flowLayout4.setAlignment(FlowLayout.LEFT);
    majorIDText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorIDText.setOpaque(true);
    majorIDText.setPreferredSize(new Dimension(380, 22));
    majorIDText.setToolTipText("");
    majorIDText.setText("");
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(400, 120));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    jPanel16.setLayout(flowLayout1);
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel16.setPreferredSize(new Dimension(161, 35));
    flowLayout1.setVgap(15);
    flowLayout1.setHgap(5);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new MajorUI_saveButton_actionAdapter(this));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    clearButton.setText("������");
    clearButton.addActionListener(new MajorUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(jPanel4, null);
    jPanel4.add(jPanel12, null);
    jPanel12.add(jPanel25, null);
    jPanel25.add(jPanel6, BorderLayout.CENTER);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel9.add(jPanel17, null);
    jPanel17.add(majorIDText, null);
    jPanel9.add(jPanel18, null);
    jPanel18.add(majorTnameText, null);
    jPanel9.add(jPanel19, null);
    jPanel19.add(majorEnameText, null);
    jPanel4.add(jPanel16, null);
    jPanel16.add(saveButton, null);
    jPanel16.add(clearButton, null);
    jPanel10.add(jLabel1, null);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
  }
  public void showUI(Major major){
    newRecord = false;
    this.major = major;
    majorIDText.setText(major.getMajorID());
    majorTnameText.setText(major.getTname());
    majorEnameText.setText(major.getEname());
  }
  public void clear(){
    majorIDText.setText("");
    majorEnameText.setText("");
    majorTnameText.setText("");
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
  public boolean removeMajor(Major major){
    Database.connect();
    boolean complete = this.major.deleteMajor(major);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }
  public void addMajor(Department department){
    newRecord = true;
    this.department = department;
    clear();
  }
  void saveButton_actionPerformed(ActionEvent e) {
    Database.connect();
    Major major = new Major();
    major.setMajorID(majorIDText.getText());
    major.setEname(majorEnameText.getText());
    major.setTname(majorTnameText.getText());
    major.setDepartment(this.department);
    if (newRecord) {
      if (major.insertMajor(major)) ((GeneralUI)generalPanel).addNode(3,major);
    }
    else {
      if (major.updateMajor(this.major,major)) ((GeneralUI)generalPanel).updateNode(major);
    }
    Database.disconnect();
  }
}

class MajorUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  MajorUI adaptee;

  MajorUI_clearButton_actionAdapter(MajorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class MajorUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  MajorUI adaptee;

  MajorUI_saveButton_actionAdapter(MajorUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}