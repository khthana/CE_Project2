package graduate;

import java.sql.*;
import java.util.*;
public class SubjectDB {
  public SubjectDB() {
  }
  public Vector retrieveSubject(Major major){
    Vector v = new Vector();
    try
    {
        String query = "SELECT g.*,s.* FROM SubjectGroup g,Subject s WHERE ";
        query += "g.GroupID = s.GroupID AND s.MajorID = '" + major.getMajorID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Subject subject = new Subject();
          subject.setSubjectID(rs.getString("SubjectID"));
          subject.setSubjectEname(rs.getString("SubjectEname"));
          subject.setSubjectTname(rs.getString("SubjectTname"));
          Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
          subject.setGroup(g);
          subject.setSubjectType(rs.getInt("SubjectType"));
          subject.setCredit(rs.getInt("Credit"));
          subject.setLecture(rs.getInt("Lecture"));
          subject.setPractice(rs.getInt("Practice"));
          subject.setResearch(rs.getInt("Research"));
          subject.setEdescription(rs.getString("EDescription"));
          subject.setTdescription(rs.getString("TDescription"));
          subject.setMajor(major);
          v.addElement(subject);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Subject retrieveSubject(Subject subject){
    Subject sub = new Subject();
    try
    {
        String query = "SELECT s.SubjectID,s.SubjectEname,s.SubjectTname,sec.SectionID,sec.Sec ";
        query += "FROM Subject s,Section sec WHERE ";
        query += "s.SubjectID = sec.SubjectID AND s.SubjectID = '"+ subject.getSubjectID() + "'";
        ResultSet rs = Database.getResultSet(query);

        if (rs.next()){
          sub.setSubjectID(rs.getString("SubjectID"));
          sub.setSubjectEname(rs.getString("SubjectEname"));
          sub.setSubjectTname(rs.getString("SubjectTname"));
          Section sec = new Section();
          sec.setSubject(sub);
          sec.setSectionID(rs.getLong("SectionID"));
          sec.setSec(rs.getInt("Sec"));
          sub.addSection(sec);

          while(rs.next()){
            Section sect = new Section();
            sect.setSubject(sub);
            sect.setSectionID(rs.getLong("SectionID"));
            sect.setSec(rs.getInt("Sec"));
            sub.addSection(sect);
          }
        }
        else return null;
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return sub;
  }
  public Vector retrieveSubjectInDifMajor(String sub,Major major){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Subject WHERE SubjectID = '" + sub + "' AND ";
      query += "MajorID in (SELECT MajorID  FROM Department d,Major m WHERE d.DepartmentID = m.DepartmentID AND ";
      query += "FacultyID in (SELECT f.FacultyID FROM Faculty AS f, Department AS d, Major AS m ";
      query += "WHERE f.FacultyID=d.FacultyID AND d.DepartmentID=m.DepartmentID AND ";
      query += "m.MajorID='" + major.getMajorID() + "'))";
      ResultSet rs = Database.getResultSet(query);

      while(rs.next()){
          Subject subject = new Subject();
          subject.setSubjectID(rs.getString("SubjectID"));
          subject.setSubjectEname(rs.getString("SubjectEname"));
          subject.setSubjectTname(rs.getString("SubjectTname"));
          Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
          subject.setGroup(g);
          subject.setSubjectType(rs.getInt("SubjectType"));
          subject.setCredit(rs.getInt("Credit"));
          subject.setLecture(rs.getInt("Lecture"));
          subject.setPractice(rs.getInt("Practice"));
          subject.setResearch(rs.getInt("Research"));
          subject.setEdescription(rs.getString("EDescription"));
          subject.setTdescription(rs.getString("TDescription"));
          subject.setMajor(new Major(rs.getString("MajorID")));
          v.addElement(subject);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveSubject(String subj,Major major){
    Vector v = new Vector();
    try
    {
        String query = "SELECT g.*,s.* FROM SubjectGroup g,Subject s WHERE ";
        query += "g.GroupID = s.GroupID AND s.SubjectID = '" + subj + "' AND majorID = '" + major.getMajorID() + "'";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Subject subject = new Subject();
          subject.setSubjectID(rs.getString("SubjectID"));
          subject.setSubjectEname(rs.getString("SubjectEname"));
          subject.setSubjectTname(rs.getString("SubjectTname"));
          Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
          subject.setGroup(g);
          subject.setSubjectType(rs.getInt("SubjectType"));
          subject.setCredit(rs.getInt("Credit"));
          subject.setLecture(rs.getInt("Lecture"));
          subject.setPractice(rs.getInt("Practice"));
          subject.setResearch(rs.getInt("Research"));
          subject.setEdescription(rs.getString("EDescription"));
          subject.setTdescription(rs.getString("TDescription"));
          subject.setMajor(new Major(rs.getString("MajorID")));
          v.addElement(subject);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveSubjectForWeb(Major major){
  Vector v = new Vector();
  try
  {
    String query = "SELECT g.*,s.* FROM SubjectGroup g,Subject s WHERE ";
    query += "g.GroupID = s.GroupID AND s.MajorID = '" + major.getMajorID() + "'";
    ResultSet rs = Database.getResultSet(query);

    while(rs.next()){
      Subject subject = new Subject();
      subject.setSubjectID(rs.getString("SubjectID"));
      subject.setSubjectEname(rs.getString("SubjectEname"));
      subject.setCredit(rs.getInt("Credit"));
      v.addElement(subject);
    }
  }
  catch(SQLException sqlex)
  {
      System.out.println(sqlex.toString());
  }
  return v;
}
  public Vector retrieveSubjectForReview(Major major){
  Vector v = new Vector();
  try
  {
    String query = "SELECT g.*,s.* FROM SubjectGroup g,Subject s WHERE ";
    query += "g.GroupID = s.GroupID AND (SELECT count(*) FROM Section sec WHERE s.SubjectID = sec.SubjectID) > 0 AND ";
    query += "s.MajorID = '" + major.getMajorID() + "'";
    ResultSet rs = Database.getResultSet(query);

    while(rs.next()){
      Subject subject = new Subject();
      subject.setSubjectID(rs.getString("SubjectID"));
      subject.setSubjectEname(rs.getString("SubjectEname"));
      subject.setCredit(rs.getInt("Credit"));
      subject.setLecture(rs.getInt("Lecture"));
      subject.setPractice(rs.getInt("Practice"));
      subject.setResearch(rs.getInt("Research"));
      v.addElement(subject);
    }
  }
  catch(SQLException sqlex)
  {
      System.out.println(sqlex.toString());
  }
  return v;
}


  public Vector retrievePrerequisite(Subject sub){
    Vector v = new Vector();
    try
    {
      String query = "SELECT s.SubjectID,s.SubjectEname FROM Subject s WHERE ";
      query += "s.SubjectID in (SELECT PrerequisiteID FROM Prerequisite p WHERE ";
      query += "p.SubjectID = '" + sub.getSubjectID() + "')";
      ResultSet rs = Database.getResultSet(query);

      while(rs.next()){
        Subject subject = new Subject();
        subject.setSubjectID(rs.getString("SubjectID"));
        subject.setSubjectEname(rs.getString("SubjectEname"));
        v.addElement(subject);
      }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrievePrerequisiteAll(Subject sub){
    Vector v = new Vector();
    try
    {
      String query = "SELECT s.*,g.* FROM Subject s, SubjectGroup g WHERE subject.GroupID = g.GroupID AND ";
      query += "s.SubjectID in (SELECT PrerequisiteID FROM Prerequisite p WHERE ";
      query += "p.SubjectID = '" + sub.getSubjectID() + "')";
      ResultSet rs = Database.getResultSet(query);

      while(rs.next()){
        Subject subject = new Subject();
        subject.setSubjectID(rs.getString("PrerequisiteID"));
        subject.setSubjectEname(rs.getString("SubjectEname"));
        subject.setSubjectTname(rs.getString("SubjectTname"));
        Group g = new Group(rs.getLong("GroupID"),rs.getString("GroupName"));
        subject.setGroup(g);
        subject.setSubjectType(rs.getInt("SubjectType"));
        subject.setCredit(rs.getInt("Credit"));
        subject.setLecture(rs.getInt("Lecture"));
        subject.setPractice(rs.getInt("Practice"));
        subject.setResearch(rs.getInt("Research"));
        subject.setEdescription(rs.getString("EDescription"));
        subject.setTdescription(rs.getString("TDescription"));
        v.addElement(subject);
      }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertSubject(Subject subject){
    String query = "INSERT INTO Subject(SubjectID,SubjectEname,SubjectTname,GroupID,";
    query += "SubjectType,Credit,Lecture,Practice,Research,EDescription,TDescription,MajorID) ";
    query += "VALUES('"+ subject.getSubjectID() + "' , '" + subject.getSubjectEname() + "' , '" + subject.getSubjectTname() + "'";
    query += ", " + subject.getGroup().getGroup() + "," + subject.getSubjectType() + "," + subject.getCredit();
    query += ", " + subject.getLecture() + "," + subject.getPractice() + "," + subject.getResearch();
    query += ", '" + subject.getEdescription() + "','" + subject.getTdescription() + "','" + subject.getMajor().getMajorID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean insertPrerequisite(Subject subject,Subject pre){
    String query = "INSERT INTO Prerequisite(SubjectID,PrerequisiteID) VALUES('" + subject.getSubjectID() + "'";
    query += ",'" + pre.getSubjectID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateSubject(Subject old,Subject subject){
    String query = "UPDATE Subject SET ";
    query += "SubjectID = '" + subject.getSubjectID() + "', ";
    query += "SubjectEname = '" + subject.getSubjectEname() + "', ";
    query += "SubjectTname = '" + subject.getSubjectTname() + "', ";
    query += "GroupID = " + subject.getGroup().getGroup() + ", ";
    query += "SubjectType = " + subject.getSubjectType() + ", ";
    query += "Credit = " + subject.getCredit() + ", ";
    query += "Lecture = " + subject.getLecture() + ", ";
    query += "Practice = " + subject.getPractice() + ", ";
    query += "Research = " + subject.getResearch() + ", ";
    query += "EDescription = '" + subject.getEdescription() + "', ";
    query += "TDescription = '" + subject.getTdescription() + "' ,";
    query += "MajorID = '" + subject.getMajor().getMajorID() + "' ";
    query +=  "WHERE SubjectID = '" + old.getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean updatePrerequisite(Subject subject,Subject opre,Subject npre){
    String query = "UPDATE Prerequisite SET ";
    query += "SubjectID = '" + subject.getSubjectID() + "', ";
    query += "PrerequisiteID = '" + npre.getSubjectID() + "' ";
    query += "WHERE SubjectID = '" + subject.getSubjectID() + "' AND PrerequisiteID = '" + opre.getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteSubject(Subject subject){
    String query = "DELETE FROM Subject WHERE SubjectID = '" + subject.getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deletePrerequisite(Subject subject,Subject pre){
    String query = "DELETE FROM Prerequisite WHERE SubjectID = '" + subject.getSubjectID() + "' AND ";
    query = "PrerequisiteID = '" + pre.getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deletePrerequisiteAll(Subject subject){
    String query = "DELETE FROM Prerequisite WHERE SubjectID = '" + subject.getSubjectID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    //Prerequisite Test--------------------------------------------------------------------------------
    SubjectDB db = new SubjectDB();
    Subject s = new Subject("002");
//    db.insertPrerequisite(s,new Subject("003"));
//    db.updatePrerequisite(s,new Subject("003"),new Subject("004"));
    Vector v = db.retrievePrerequisite(s);
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Subject ss = (Subject)e.nextElement();
      System.out.println(ss.getSubjectID());
    }
    //Subject Test------------------------------------------------------------------------------------
/*    SubjectDB db = new SubjectDB();
    Subject s = new Subject();
    s.setSubjectID("004");
    s.setSubjectEname("Electronic");
    s.setSubjectTname("Electronica");
    s.setGroup(new Group(1));
    s.setSubjectType(1);
    s.setCredit(3);
    s.setLecture(0);
    s.setPractice(3);
    s.setResearch(0);
    s.setEdescription("asdssfasasfasfafafaf");
    s.setTdescription("asddddddddddddddd");
    s.setMajor(new Major("001"));
//    db.updateSubject(s);

    Vector v = db.retrieveSubject(new Major("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Subject ss = (Subject)e.nextElement();
      System.out.print(ss.getSubjectID() + " " + ss.getSubjectEname() + " " + ss.getSubjectTname() + " " + ss.getGroup().getGroupName());
      System.out.print(" " + ss.getSubjectType() + " " + ss.getCredit() + " " + ss.getLecture() + " " + ss.getPractice() + " " + ss.getResearch());
      System.out.println(" " + ss.getEdescription() + " " + ss.getTdescription() + " " + ss.getMajor().getMajorID());
    }*/
    Database.disconnect();
  }
}