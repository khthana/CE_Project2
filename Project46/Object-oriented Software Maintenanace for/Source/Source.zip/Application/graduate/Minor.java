package graduate;

import java.util.*;
public class Minor {
  private String minorID;
  private String ename;
  private String tname;
  private Major major;
  private MinorDB minorDB = new MinorDB();
  //Constructor
  public Minor() {
  }
  public Minor(String minorID){
    this.setMinorID(minorID);
  }
  public Minor(String minorID,String minorTname){
    this.setMinorID(minorID);
    this.setTname(minorTname);
  }
  //getMethod
  public String getMinorID(){
    return this.minorID;
  }
  public String getEname(){
    return this.ename;
  }
  public String getTname(){
    return this.tname;
  }
  public Major getMajor(){
    return this.major;
  }
  //setMethod
  public void setMinorID(String minorID){
    this.minorID = minorID;
  }
  public void setEname(String ename){
    this.ename = ename;
  }
  public void setTname(String tname){
    this.tname = tname;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  //Business Method
  public Vector retrieveMinorAll(Major major){
    Vector v = minorDB.retrieveMinorAll(major);
    major.setMinor(v);
    return v;
  }
  public Vector retrieveMinor(Major major){
    Vector v = minorDB.retrieveMinor(major);
    major.setMinor(v);
    return v;
  }
  public Minor retrieveMinor(String minorID){
    return minorDB.retrieveMinor(minorID);
  }
  public boolean insertMinor(Minor minor){
    return minorDB.insertMinor(minor);
  }
  public boolean updateMinor(Minor oldminor,Minor minor){
    return minorDB.updateMinor(oldminor,minor);
  }
  public boolean deleteMinor(Minor minor){
    return minorDB.deleteMinor(minor);
  }
  public String toString(){
    return "ᢹ��Ԫ�" + this.getTname();
  }
}