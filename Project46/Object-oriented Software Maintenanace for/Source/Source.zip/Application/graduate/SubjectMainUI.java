package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;

public class SubjectMainUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JButton jButton2 = new JButton();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JButton jButton1 = new JButton();
  BorderLayout borderLayout2 = new BorderLayout();
  FlowLayout flowLayout3 = new FlowLayout();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPanel jPanel110 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel10 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  JLabel jLabel2 = new JLabel();
  JComboBox majorCombo = new JComboBox();
  FlowLayout flowLayout7 = new FlowLayout();
  GridLayout gridLayout2 = new GridLayout();
  JPanel jPanel30 = new JPanel();
  JComboBox departmentCombo = new JComboBox();
  FlowLayout flowLayout6 = new FlowLayout();
  JPanel jPanel17 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  JComboBox facultyCombo = new JComboBox();
  JPanel jPanel9 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  BorderLayout borderLayout4 = new BorderLayout();
  //--------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Faculty faculty = new Faculty();
  Department department = new Department();
  Major major = new Major();

  public SubjectMainUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    this.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setMinimumSize(new Dimension(88, 145));
    this.setPreferredSize(new Dimension(450, 220));
    jPanel1.setLayout(boxLayout22);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton2.setText("��ŧ");
    jPanel4.setLayout(flowLayout3);
    jPanel3.setLayout(borderLayout2);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton1.setToolTipText("");
    jButton1.setText("¡��ԡ");
    flowLayout3.setHgap(20);
    flowLayout3.setVgap(10);
    jPanel12.setLayout(borderLayout5);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel12.setMinimumSize(new Dimension(88, 120));
    jPanel12.setPreferredSize(new Dimension(350, 220));
    jPanel7.setLayout(borderLayout4);
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel4.setText("�Ң��Ԫ� :");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel3.setText("�Ҥ�Ԫ� :");
    jPanel110.setLayout(flowLayout6);
    jPanel110.setPreferredSize(new Dimension(320, 32));
    jPanel110.setMaximumSize(new Dimension(32767, 32767));
    jPanel110.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    flowLayout2.setAlignment(FlowLayout.LEFT);
    jPanel10.setLayout(gridLayout2);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setForeground(Color.black);
    jPanel10.setMinimumSize(new Dimension(65, 120));
    jPanel10.setOpaque(true);
    jPanel10.setPreferredSize(new Dimension(90, 120));
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(0);
    gridLayout1.setRows(6);
    gridLayout1.setVgap(5);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setText("��� :");
    majorCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    majorCombo.setMinimumSize(new Dimension(26, 21));
    majorCombo.setPreferredSize(new Dimension(270, 22));
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(5);
    gridLayout2.setColumns(1);
    gridLayout2.setHgap(0);
    gridLayout2.setRows(6);
    gridLayout2.setVgap(5);
    jPanel30.setLayout(flowLayout7);
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel30.setPreferredSize(new Dimension(67, 32));
    departmentCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    departmentCombo.setPreferredSize(new Dimension(270, 22));
    departmentCombo.addActionListener(new SubjectMainUI_departmentCombo_actionAdapter(this));
    flowLayout6.setAlignment(FlowLayout.LEFT);
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel17.setMaximumSize(new Dimension(32767, 32767));
    jPanel17.setPreferredSize(new Dimension(320, 32));
    jPanel17.setLayout(flowLayout2);
    jPanel6.setLayout(borderLayout9);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 120));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(380, 200));
    facultyCombo.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    facultyCombo.setPreferredSize(new Dimension(270, 22));
    facultyCombo.addActionListener(new SubjectMainUI_facultyCombo_actionAdapter(this));
    jPanel9.setLayout(gridLayout1);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setMaximumSize(new Dimension(32767, 32767));
    jPanel9.setPreferredSize(new Dimension(270, 22));
    jPanel9.setRequestFocusEnabled(true);
    jPanel9.setToolTipText("");
    jPanel9.setVerifyInputWhenFocusTarget(true);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.add(jPanel7, null);
    jPanel4.add(jButton2, null);
    jPanel4.add(jButton1, null);
    jPanel7.add(jPanel12, BorderLayout.NORTH);
    jPanel12.add(jPanel11,  BorderLayout.SOUTH);
    jPanel11.add(jPanel6, null);
    jPanel9.add(jPanel17, null);
    jPanel17.add(facultyCombo, null);
    jPanel9.add(jPanel30, null);
    jPanel30.add(departmentCombo, null);
    jPanel9.add(jPanel110, null);
    jPanel110.add(majorCombo, null);
    jPanel7.add(jPanel3,  BorderLayout.CENTER);
    jPanel3.add(jPanel4, BorderLayout.NORTH);
    jPanel6.add(jPanel10, BorderLayout.WEST);
    jPanel6.add(jPanel9, BorderLayout.CENTER);
    jPanel10.add(jLabel2, null);
    jPanel10.add(jLabel3, null);
    jPanel10.add(jLabel4, null);
    this.add(jPanel1, BorderLayout.CENTER);
    addFaculty();
  }
public void addFaculty(){
    Database.connect();
    Vector v = faculty.retrieveFacultyAll();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Faculty fac = (Faculty)e.nextElement();
      facultyCombo.addItem(fac);
    }
    Database.disconnect();
  }

  public void facultyCombo_actionPerformed(ActionEvent ea) {
    Faculty fac = (Faculty)facultyCombo.getSelectedItem();
    departmentCombo.removeAllItems();
    if (fac != null){
    Database.connect();
    Vector v = department.retrieveDepartmentAll(fac);
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Department d = (Department)e.nextElement();
      departmentCombo.addItem(d);
    }
    Database.disconnect();
   }
  }

  void departmentCombo_actionPerformed(ActionEvent ea) {
    Department dep = (Department)departmentCombo.getSelectedItem();
    majorCombo.removeAllItems();
    if (dep != null){
      Database.connect();
      Vector v = major.retrieveMajorAll(dep);
      Enumeration e = v.elements();
      while (e.hasMoreElements()){
        Major maj = (Major)e.nextElement();
        majorCombo.addItem(maj);
      }
      Database.disconnect();
    }
  }
}

class SubjectMainUI_facultyCombo_actionAdapter implements java.awt.event.ActionListener {
  SubjectMainUI adaptee;

  SubjectMainUI_facultyCombo_actionAdapter(SubjectMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.facultyCombo_actionPerformed(e);
  }
}

class SubjectMainUI_departmentCombo_actionAdapter implements java.awt.event.ActionListener {
  SubjectMainUI adaptee;

  SubjectMainUI_departmentCombo_actionAdapter(SubjectMainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.departmentCombo_actionPerformed(e);
  }
}