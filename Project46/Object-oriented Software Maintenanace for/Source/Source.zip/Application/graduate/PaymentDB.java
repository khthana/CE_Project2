package graduate;

import java.sql.*;
import java.util.*;
public class PaymentDB {
  public PaymentDB() {
  }
  public Vector retrievePaymentAll(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT r.*,c.*,p.* FROM RegisterType r,Cost c,Payment p ";
        query += "WHERE r.RegisterTypeID = p.RegisterTypeID AND c.CostID = p.CostID";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Payment p = new Payment();
          Cost c = new Cost();
          RegisterType r = new RegisterType();
          c.setCostID(rs.getLong("CostID"));
          c.setCostName(rs.getString("CostName"));
          c.setValue(rs.getDouble("Val"));
          r.setRegisterTypeID(rs.getLong("RegisterTypeID"));
          r.setRegisterTypeName(rs.getString("RegisterType"));
          p.setCost(c);
          p.setRegisterType(r);
          p.setNos(rs.getInt("NOS"));
          v.addElement(p);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public double retrievePayment(RegisterType registerType,int status){
    try
    {
        String query = "SELECT sum(c.val) AS sumpayment FROM Cost c,Payment p ";
        query += "WHERE c.CostID = p.CostID AND p.RegisterTypeID = " + registerType.getRegisterTypeID() + " AND ";
        query += "p.NOS = " + status;
        ResultSet rs = Database.getResultSet(query);
        while(rs.next()){
          return rs.getDouble("sumpayment");
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return 0.0;
  }
  public boolean insertPayment(Payment payment){
     String query = "INSERT INTO Payment(RegisterTypeID,CostID,NOS) ";
     query += "VALUES("+ payment.getRegisterType().getRegisterTypeID()+ " , " + payment.getCost().getCostID();
     query += ", " + payment.getNos() + ")";
     if (Database.update(query) !=0 ) return true;
     return false;
   }
   public boolean updatePayment(Payment oldPay,Payment newPay){
     String query = "UPDATE Payment SET ";
     query += "RegisterTypeID = " + newPay.getRegisterType().getRegisterTypeID() + ", ";
     query += "CostID = " + newPay.getCost().getCostID() + ", ";
     query += "NOS = " + newPay.getNos() + " ";
     query += "WHERE RegisterTypeID = " + oldPay.getRegisterType().getRegisterTypeID() + " AND ";
     query += "CostID = " + oldPay.getCost().getCostID() + " AND ";
     query += "NOS = " + oldPay.getNos();

     if (Database.update(query) != 0) return true;
     return false;
   }
   public boolean deletePayment(Payment payment){
     String query = "DELETE FROM Payment ";
/*     query += "WHERE RegisterTypeID = '" + payment.getRegisterType().getRegisterTypeID() + "' AND ";
     query += "CostID = '" + payment.getCost().getCostID() + "' AND ";
     query += "NOS = '" + payment.getNos() + "'";*/
     if (Database.update(query) != 0) return true;
     return false;
   }

   public static void main(String[] args){
     Database.connect("jdbc:odbc:Graduate","Admin","123");
     PaymentDB db = new PaymentDB();
     Payment p = new Payment();
     p.setCost(new Cost(1));
     p.setRegisterType(new RegisterType(1));
     p.setNos(1);

     Payment pp = new Payment();
     pp.setCost(new Cost(1));
     pp.setRegisterType(new RegisterType(1));
     pp.setNos(2);

//     db.updatePayment(p,pp);

/*     Vector v = db.retrievePaymentAll();
     Enumeration e = v.elements();
     while (e.hasMoreElements()){
       Payment m = (Payment)e.nextElement();
       System.out.println(m.getCost().getCostID() + " " + m.getRegisterType().getRegisterTypeName()+ " " + m.getNos());
     }*/
     Database.disconnect();
   }

}