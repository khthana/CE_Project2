package graduate;

import java.sql.*;
import java.util.*;
public class ScholarshipDB {
  public ScholarshipDB() {
  }
  public Vector retrieveScholarship(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT s.*,g.* FROM Scholarship s,ScholarshipGroup g WHERE ";
        query +=  "s.ScholarshipGroupID = g.ScholarshipGroupID ORDER BY ScholarshipName";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Scholarship s = new Scholarship();
          s.setID(rs.getLong("ScholarshipID"));
          s.setName(rs.getString("ScholarshipName"));
          s.setYear(rs.getLong("ScholarshipYear"));
          ScholarshipGroup g = new ScholarshipGroup(rs.getLong("ScholarshipGroupID"),rs.getString("ScholarshipGroupName"));
          s.setGroup(g);
          s.setMoney(rs.getDouble("ScholarshipMoney"));
          s.setNo(rs.getInt("ScholarshipNo"));
          s.setInterval(rs.getInt("Interval"));
          s.setException(rs.getInt("Exception"));
          v.addElement(s);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;

  }
  public boolean insertScholarship(Scholarship scholarship){
    String query = "INSERT INTO Scholarship(ScholarshipName,ScholarshipGroupID,ScholarshipMoney,ScholarshipYear,ScholarshipNo,Interval,Exception) ";
    query += "VALUES('"+ scholarship.getName() + "' , " + scholarship.getGroup().getSgroupID() + " , " + scholarship.getMoney();
    query += ", " + scholarship.getYear();
    query += ", " + scholarship.getNo() + "," + scholarship.getInterval() + "," + scholarship.getException() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateScholarship(Scholarship scholarship){
    String query = "UPDATE Scholarship SET ";
    query += "ScholarshipName = '" + scholarship.getName() + "', ";
    query += "ScholarshipGroupID = " + scholarship.getGroup().getSgroupID() + ", ";
    query += "ScholarshipMoney = " + scholarship.getMoney() + ", ";
    query += "ScholarshipYear = " + scholarship.getYear() + ", ";
    query += "ScholarshipNo = " + scholarship.getNo() + ", ";
    query += "Interval = " + scholarship.getInterval() + ", ";
    query += "Exception = " + scholarship.getException()+ " ";
    query += "WHERE ScholarshipID = " + scholarship.getID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteScholarship(Scholarship scholarship){
    String query = "DELETE FROM Scholarship WHERE ScholarshipID = " + scholarship.getID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ScholarshipDB db = new ScholarshipDB();
    Scholarship s = new Scholarship();
    s.setID(1);
    s.setName("Test");
    s.setGroup(new ScholarshipGroup(1));
    s.setMoney(20000);
    s.setInterval(2);
    s.setException(2);
    db.updateScholarship(s);
//    db.updateScholarshipGroup(s);
/*    Vector v = db.retrieveScholarShipGroup();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      ScholarshipGroup ss = (ScholarshipGroup)e.nextElement();
      System.out.println(ss.getSgroupID() + " " + ss.getSgroupName());
    }*/
    Database.disconnect();
  }

}