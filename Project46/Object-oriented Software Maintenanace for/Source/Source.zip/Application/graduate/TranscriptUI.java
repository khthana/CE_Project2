package graduate;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.io.File;
import javax.swing.border.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.*;
import java.util.*;

//SAX
import org.xml.sax.InputSource;

//Avalon
import org.apache.avalon.framework.ExceptionUtil;
import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.logger.ConsoleLogger;

//FOP
import org.apache.fop.apps.Driver;
import org.apache.fop.apps.FOPException;
import org.apache.fop.messaging.MessageHandler;
import com.borland.jbcl.layout.*;


public class TranscriptUI extends JPanel {
  CompoundBorder titledBorder2;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  private FileWriter writer;
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JLabel jLabel2 = new JLabel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel3 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabel1 = new JLabel();
  JTextField idText = new JTextField();
  JPanel jPanel2 = new JPanel();
  JTextField tprenameText = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField tnameText = new JTextField();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel4 = new JLabel();
  FlowLayout flowLayout3 = new FlowLayout();
  JTextField eprenameText = new JTextField();
  JLabel jLabel5 = new JLabel();
  JTextField enameText = new JTextField();
  JPanel jPanel5 = new JPanel();
  FlowLayout flowLayout4 = new FlowLayout();
  JLabel jLabel6 = new JLabel();
  JTextField facultyText = new JTextField();
  JLabel jLabel7 = new JLabel();
  JTextField birthdayText = new JTextField();
  JPanel jPanel6 = new JPanel();
  FlowLayout flowLayout5 = new FlowLayout();
  JLabel jLabel8 = new JLabel();
  JTextField departmentText = new JTextField();
  JLabel jLabel9 = new JLabel();
  JTextField entranceText = new JTextField();
  JPanel jPanel7 = new JPanel();
  FlowLayout flowLayout6 = new FlowLayout();
  JLabel jLabel10 = new JLabel();
  JTextField majorText = new JTextField();
  JLabel jLabel11 = new JLabel();
  JTextField leaveText = new JTextField();
  JPanel jPanel8 = new JPanel();
  FlowLayout flowLayout7 = new FlowLayout();
  JLabel jLabel12 = new JLabel();
  JTextField subjectText = new JTextField();
  JLabel jLabel13 = new JLabel();
  JTextField planText = new JTextField();
  JPanel jPanel9 = new JPanel();
  JLabel jLabel14 = new JLabel();
  FlowLayout flowLayout8 = new FlowLayout();
  JTextField thesisText = new JTextField();
  JPanel jPanel10 = new JPanel();
  FlowLayout flowLayout9 = new FlowLayout();
  JLabel jLabel15 = new JLabel();
  JTextField commentText = new JTextField();
  JPanel jPanel11 = new JPanel();
  FlowLayout flowLayout10 = new FlowLayout();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  Border border1;
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  //---------------------------------------------------------------------------------------------------------------------------------------------------------------
  Student student = new Student();
  Vector registrationVector = new Vector();
  public TranscriptUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder6 = new TitledBorder(null, "�����ŷ�ҹʤ�Ի��",  TitledBorder.LEFT, TitledBorder.TOP);
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));

    this.setLayout(borderLayout1);
    jPanel1.setLayout(verticalFlowLayout1);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setMaximumSize(new Dimension(90, 15));
    jLabel2.setPreferredSize(new Dimension(90, 22));
    jLabel2.setText("�ӹ�˹�Ҫ���");
    jPanel3.setLayout(flowLayout2);
    flowLayout1.setAlignment(FlowLayout.LEFT);
    flowLayout1.setHgap(10);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setMaximumSize(new Dimension(90, 15));
    jLabel1.setPreferredSize(new Dimension(90, 22));
    jLabel1.setText("���ʹѡ�֡��");
    idText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    idText.setPreferredSize(new Dimension(100, 21));
    idText.setText("");
    idText.addActionListener(new TranscriptUI_idText_actionAdapter(this));
    jPanel2.setLayout(flowLayout1);
    flowLayout2.setAlignment(FlowLayout.LEFT);
    flowLayout2.setHgap(10);
    tprenameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tprenameText.setPreferredSize(new Dimension(100, 21));
    tprenameText.setText("");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setMaximumSize(new Dimension(70, 22));
    jLabel3.setPreferredSize(new Dimension(70, 22));
    jLabel3.setText("����-���ʡ��");
    tnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tnameText.setPreferredSize(new Dimension(310, 21));
    tnameText.setText("");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setMaximumSize(new Dimension(90, 15));
    jLabel4.setPreferredSize(new Dimension(90, 22));
    jLabel4.setText("Initial");
    jPanel4.setLayout(flowLayout3);
    flowLayout3.setAlignment(FlowLayout.LEFT);
    flowLayout3.setHgap(10);
    eprenameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    eprenameText.setPreferredSize(new Dimension(100, 21));
    eprenameText.setText("");
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setMaximumSize(new Dimension(70, 22));
    jLabel5.setPreferredSize(new Dimension(70, 22));
    jLabel5.setText("Name");
    enameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    enameText.setPreferredSize(new Dimension(310, 21));
    enameText.setText("");
    jPanel5.setLayout(flowLayout4);
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setMaximumSize(new Dimension(90, 15));
    jLabel6.setPreferredSize(new Dimension(90, 22));
    jLabel6.setText("���");
    flowLayout4.setAlignment(FlowLayout.LEFT);
    flowLayout4.setHgap(10);
    facultyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setPreferredSize(new Dimension(200, 21));
    facultyText.setText("");
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setMaximumSize(new Dimension(80, 22));
    jLabel7.setPreferredSize(new Dimension(80, 22));
    jLabel7.setText("�ѹ�Դ");
    birthdayText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    birthdayText.setPreferredSize(new Dimension(100, 21));
    birthdayText.setText("");
    jPanel6.setLayout(flowLayout5);
    flowLayout5.setAlignment(FlowLayout.LEFT);
    flowLayout5.setHgap(10);
    jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel8.setMaximumSize(new Dimension(90, 15));
    jLabel8.setPreferredSize(new Dimension(90, 22));
    jLabel8.setText("�Ҥ�Ԫ�");
    departmentText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    departmentText.setPreferredSize(new Dimension(200, 21));
    departmentText.setText("");
    jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel9.setMaximumSize(new Dimension(80, 22));
    jLabel9.setPreferredSize(new Dimension(80, 22));
    jLabel9.setText("�ѹ����֡��");
    entranceText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    entranceText.setPreferredSize(new Dimension(100, 21));
    entranceText.setText("");
    jPanel7.setLayout(flowLayout6);
    jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel10.setMaximumSize(new Dimension(90, 15));
    jLabel10.setPreferredSize(new Dimension(90, 22));
    jLabel10.setText("�Ң��Ԫ�");
    flowLayout6.setAlignment(FlowLayout.LEFT);
    flowLayout6.setHgap(10);
    majorText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorText.setPreferredSize(new Dimension(200, 21));
    majorText.setText("");
    jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel11.setMaximumSize(new Dimension(80, 22));
    jLabel11.setPreferredSize(new Dimension(80, 22));
    jLabel11.setText("�ѹ������֡��");
    leaveText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    leaveText.setPreferredSize(new Dimension(100, 21));
    leaveText.setText("");
    jPanel8.setLayout(flowLayout7);
    flowLayout7.setAlignment(FlowLayout.LEFT);
    flowLayout7.setHgap(10);
    jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel12.setMaximumSize(new Dimension(90, 15));
    jLabel12.setPreferredSize(new Dimension(90, 22));
    jLabel12.setText("�Ԫ��͡");
    subjectText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    subjectText.setPreferredSize(new Dimension(200, 21));
    subjectText.setText("");
    jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel13.setMaximumSize(new Dimension(80, 22));
    jLabel13.setPreferredSize(new Dimension(80, 22));
    jLabel13.setText("Ἱ");
    planText.setPreferredSize(new Dimension(200, 21));
    planText.setText("");
    jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel14.setMaximumSize(new Dimension(90, 15));
    jLabel14.setPreferredSize(new Dimension(90, 22));
    jLabel14.setRequestFocusEnabled(true);
    jLabel14.setText("��Ǣ���Է�ҹԾ���");
    jPanel9.setLayout(flowLayout8);
    flowLayout8.setAlignment(FlowLayout.LEFT);
    flowLayout8.setHgap(10);
    thesisText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    thesisText.setPreferredSize(new Dimension(500, 21));
    thesisText.setText("");
    jPanel10.setLayout(flowLayout9);
    flowLayout9.setAlignment(FlowLayout.LEFT);
    flowLayout9.setHgap(10);
    jLabel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel15.setMaximumSize(new Dimension(90, 15));
    jLabel15.setPreferredSize(new Dimension(90, 22));
    jLabel15.setText("�����˵�");
    commentText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    commentText.setPreferredSize(new Dimension(500, 21));
    commentText.setText("");
    jPanel11.setLayout(flowLayout10);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("�����");
    jButton1.addActionListener(new TranscriptUI_jButton1_actionAdapter(this));
    flowLayout10.setAlignment(FlowLayout.CENTER);
    flowLayout10.setHgap(10);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("������");
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder2);
    this.setBorder(border1);
    jRadioButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton1.setSelected(true);
    jRadioButton1.setText("��ԭ���");
    jRadioButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton2.setText("��ԭ���͡");
    jPanel11.add(jButton2, null);
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel2.add(jLabel1, null);
    jPanel2.add(idText, null);
    jPanel2.add(jRadioButton1, null);
    jPanel2.add(jRadioButton2, null);
    jPanel1.add(jPanel2, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jLabel2, null);
    jPanel3.add(tprenameText, null);
    jPanel3.add(jLabel3, null);
    jPanel3.add(tnameText, null);
    jPanel1.add(jPanel4, null);
    jPanel4.add(jLabel4, null);
    jPanel4.add(eprenameText, null);
    jPanel4.add(jLabel5, null);
    jPanel4.add(enameText, null);
    jPanel1.add(jPanel5, null);
    jPanel5.add(jLabel6, null);
    jPanel5.add(facultyText, null);
    jPanel5.add(jLabel7, null);
    jPanel5.add(birthdayText, null);
    jPanel1.add(jPanel6, null);
    jPanel6.add(jLabel8, null);
    jPanel6.add(departmentText, null);
    jPanel6.add(jLabel9, null);
    jPanel6.add(entranceText, null);
    jPanel1.add(jPanel7, null);
    jPanel7.add(jLabel10, null);
    jPanel7.add(majorText, null);
    jPanel7.add(jLabel11, null);
    jPanel7.add(leaveText, null);
    jPanel1.add(jPanel8, null);
    jPanel8.add(jLabel12, null);
    jPanel8.add(subjectText, null);
    jPanel8.add(jLabel13, null);
    jPanel8.add(planText, null);
    jPanel1.add(jPanel9, null);
    jPanel9.add(jLabel14, null);
    jPanel9.add(thesisText, null);
    jPanel1.add(jPanel10, null);
    jPanel10.add(jLabel15, null);
    jPanel10.add(commentText, null);
    jPanel1.add(jPanel11, null);
    jPanel11.add(jButton1, null);
    buttonGroup1.add(jRadioButton1);
    buttonGroup1.add(jRadioButton2);
  }

  public void convertFO2PDF(File fo, File pdf) throws IOException, FOPException {

      //Construct driver
      Driver driver = new Driver();

      //Setup logger
      Logger logger = new ConsoleLogger(ConsoleLogger.LEVEL_INFO);
      driver.setLogger(logger);
      MessageHandler.setScreenLogger(logger);

      //Setup Renderer (output format)
      driver.setRenderer(Driver.RENDER_PDF);

      //Setup output
      OutputStream out = new java.io.FileOutputStream(pdf);
      try {
          driver.setOutputStream(out);

          //Setup input
          InputStream in = new java.io.FileInputStream(fo);
          try {
              driver.setInputSource(new InputSource(in));

              //Process FO
              driver.run();
          } finally {
              in.close();
          }
      } finally {
          out.close();
      }
  }

  public void showPDF(String file){
    Runtime ed = Runtime.getRuntime();
    try{
      ed.exec("C:\\Program Files\\Adobe\\Acrobat 5.0\\Acrobat\\Acrobat " + file);
    }
    catch (Exception e1){
      System.out.print("Error : " + e1);
    }
  }

  public void convert2PDF(String inFile,String outFile){
    //Setup directories
    try{
      File fofile = new File(inFile);
      File pdffile = new File(outFile);
/*      File baseDir = new File("C:\\");

      File outDir = new File(baseDir, "out");
      outDir.mkdirs();

      //Setup input and output files
      File fofile = new File(baseDir, inFile);
      File pdffile = new File(outDir, outFile);*/

      convertFO2PDF(fofile, pdffile);
    }
    catch (Exception ef){
      System.out.println("ERROR : " + ef);
    }
  }

/*  generateTranscript("C:\\out\\transcript.fo");
  convert2PDF("C:\\out\\transcript.fo","C:\\out\\transcript.pdf");
  showPDF("C:\\out\\transcript.pdf");*/

  void jButton1_actionPerformed(ActionEvent e) {
    generateTranscript("C:\\fop-0.20.5\\tss.fo");
    convert2PDF("C:\\fop-0.20.5\\tss.fo","C:\\fop-0.20.5\\tss.pdf");
    showPDF("C:\\fop-0.20.5\\tss.pdf");
  }

  public void generateTranscript(String file){
    try{
      Database.connect();
      Registration registration = new Registration();
      File fileName = new File(file);
      writer = new FileWriter(fileName);
      String str = "<?xml version=\"1.0\" encoding=\"utf-8\"?> " + "\n" +
       "<fo:root xmlns:fo=\"http://www.w3.org/1999/XSL/Format\"> " + "\n" +

        "<!-- defines the layout master -->" + "\n" +
        "<fo:layout-master-set>" + "\n" +
          "<fo:simple-page-master master-name=\"first\" " + "\n" +
                                 "page-height=\"29.7cm\" " + "\n" +
                                 "page-width=\"21cm\" " + "\n" +
                                 "margin-top=\"0.5cm\" " + "\n" +
                                 "margin-bottom=\"0.5cm\" " + "\n" +
                                 "margin-left=\"0.5cm\" "+ "\n" +
                                 "margin-right=\"0.5cm\"> " + "\n" +
            "<fo:region-body margin-top=\"0cm\" margin-bottom=\"0cm\" />" + "\n" +
            "<fo:region-before extent=\"0cm\" /> " + "\n" +
            "<fo:region-after extent=\"0cm\" /> " + "\n" +
          "</fo:simple-page-master> " + "\n" +
        "</fo:layout-master-set> " + "\n" +

        "<!-- starts actual layout -->" + "\n" +
        "<fo:page-sequence master-reference=\"first\">" + "\n" +

        "<fo:flow flow-name=\"xsl-region-body\"> " + "\n" +

            "<!-- this defines a title level 1-->" + "\n" +
            "<fo:block font-size=\"18pt\" " + "\n" +
                  "font-family=\"sans-serif\" " + "\n" +
                  "font-weight = \"bold\" " + "\n" +
                  "line-height=\"24pt\" " + "\n" +
                  "space-after.optimum=\"0pt\" " + "\n" +
                  "background-color=\"white\" " + "\n" +
                  "color=\"black\" " + "\n" +
                  "text-align=\"center\" " + "\n" +
                  "padding-top=\"3pt\"> " + "\n" +
              "KING MONGKUT'S INSTITUTE OF TECHNOLOGY LADGRABANG" + "\n" +
            "</fo:block>" + "\n" +

            "<fo:block font-size=\"18pt\" " + "\n" +
                  "font-family=\"sans-serif\" " + "\n" +
                  "font-weight = \"bold\" " + "\n" +
                  "line-height=\"24pt\" " + "\n" +
                  "space-after.optimum=\"15pt\" " + "\n" +
                  "background-color=\"white\" " + "\n" +
                  "color=\"black\" " + "\n" +
                  "text-align=\"center\" " + "\n" +
                  "padding-top=\"3pt\"> " + "\n" +
              "BANGKOK THAILAND" + "\n" +
            "</fo:block>" + "\n" +

            "<fo:block font-size=\"12pt\" " + "\n" +
                  "font-family=\"sans-serif\" " + "\n" +
                  "line-height=\"24pt\" " + "\n" +
                  "space-after.optimum=\"40pt\" " + "\n" +
                  "background-color=\"white\" " + "\n" +
                  "color=\"black\" " + "\n" +
                  "text-align=\"center\" " + "\n" +
                  "padding-top=\"3pt\"> " + "\n" +
              "SCHOOL OF GRADUATE STUDIES" + "\n" +
            "</fo:block>" + "\n" +

          "<!-- table start -->" + "\n" +
          "<fo:table table-layout=\"fixed\"> " + "\n" +
            "<fo:table-column column-width=\"0.2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"9.8cm\"/> " + "\n" +
            "<fo:table-column column-width=\"0.2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"9.3cm\"/> " + "\n" +
            "<fo:table-body> " + "\n" +
              "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell>"+ "\n" +
                        "<fo:table-cell > " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"bold\"> " + "\n" +
                              "Name : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              student.getPrename().getEprename().toUpperCase() + " " + student.getStudentEname().toUpperCase() +
                              "</fo:inline></fo:block></fo:table-cell>" + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell > " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"bold\"> " + "\n" +
                              "Record No. : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              student.getStudentID() +
                              "</fo:inline></fo:block></fo:table-cell> " + "\n" +
              "</fo:table-row > " + "\n" +
              "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell>" + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell>" + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell>" + "\n" +
                "<fo:table-cell >" + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"bold\"> " + "\n" +
                              "Degree : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " +"\n" +
                              ((student.getDegree() > 4)?student.getMajor().getMasterEname():student.getMajor().getPhDEname()) +
                              "</fo:inline></fo:block></fo:table-cell>" + "\n" +
              "</fo:table-row>" + "\n" +
              "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block font-size=\"8pt\" font-family=\"sans-serif\"  font-weight = \"bold\"> " + "\n" +
                              "Date of Birth : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              birthdayText.getText() +
                              "</fo:inline></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block font-size=\"8pt\" font-family=\"sans-serif\"  font-weight = \"bold\"> " + "\n" +
                              "Program : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              subjectText.getText() +
                              "</fo:inline></fo:block></fo:table-cell> " + "\n" +
              "</fo:table-row> " + "\n" +
              "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block font-size=\"8pt\" font-family=\"sans-serif\"  font-weight = \"bold\"> " + "\n" +
                              "Date of Admission : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              entranceText.getText() +
                              "</fo:inline></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block font-size=\"8pt\" font-family=\"sans-serif\"  font-weight = \"bold\"> " + "\n" +
                              "Date of Graduation : <fo:inline font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"normal\"> " + "\n" +
                              leaveText.getText() +
                              "</fo:inline></fo:block></fo:table-cell> " + "\n" +
              "</fo:table-row> " + "\n" +
                "</fo:table-body> " + "\n" +
          "</fo:table> " + "\n" +
          "<!-- table end --> " + "\n" +

            "<fo:block font-size=\"18pt\" " + "\n" +
                  "font-family=\"sans-serif\" " + "\n" +
                  "line-height=\"24pt\" " + "\n" +
                  "space-after.optimum=\"5pt\" " + "\n" +
                  "background-color=\"white\" " + "\n" +
                  "color=\"black\" " + "\n" +
                  "text-align=\"center\" " + "\n" +
                  "padding-top=\"3pt\"> " + "\n" +
            "</fo:block> " + "\n" +

          "<!-- table start --> " + "\n" +
          "<fo:table table-layout=\"fixed\"> " + "\n" +
            "<fo:table-column column-width=\"2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"5.6cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"5.3cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.1cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.1cm\"/> " + "\n" +
                "<fo:table-body> " + "\n" +

                      "<fo:table-row  height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" display-align=\"center\" border-left-width = \"0.5pt\" " + "\n" +
                              "border-left-style = \"solid\" border-top-width = \"0.5pt\" border-top-style = \"solid\" border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">CODE</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">COURSE TITLE</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                               "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">CREDIT</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                               "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">GRADE</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                               "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" border-left-width = \"0.5pt\" border-left-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">CODE</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                               "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">COURSE TITLE</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                               "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">CREDIT</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-top-width = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                              "border-bottom-width  = \"0.5pt\" border-bottom-style = \"solid\" border-right-width = \"0.5pt\" border-right-style = \"solid\" display-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">GRADE</fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n";

  //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  int showCredit = 0;
  int ite = 0;
  Vector conVector = new Vector();
  Vector termVector = registration.retrieveSemesterRegistered(student);
  Enumeration termEnum = termVector.elements();
  while (termEnum.hasMoreElements()){
    ite++;
    Semester s1 = (Semester)termEnum.nextElement();
    str += "<fo:table-row height=\"0.8cm\"> " + "\n" +
    "<fo:table-cell border-left-width = \"0.5pt\" border-left-style = \"solid\"><fo:block></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell  display-align=\"center\"> " + "\n" +
                  "<fo:block  font-size=\"8pt\" font-family=\"sans-serif\" text-decoration = \"underline\"> ";
              if (s1.getSemester() == 1){
                str += "1st Semester ";
              }
              else if (s1.getSemester() == 2){
                str += "2nd Semester ";
              }
              else if (s1.getSemester() == 3){
                str += "3rd Semester ";
              }
    str += s1.getYear() + "</fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell border-left-width = \"0.5pt\" border-left-style = \"solid\"><fo:block></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell display-align=\"center\"> " + "\n" +
                  "<fo:block  font-size=\"8pt\" font-family=\"sans-serif\" text-decoration = \"underline\"></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
    "<fo:table-cell border-right-width = \"0.5pt\" border-right-style = \"solid\"><fo:block></fo:block></fo:table-cell> " + "\n" +
    "</fo:table-row> " + "\n";

    Vector termRegisVector = student.retrieveRegistrationPerSemester(s1);
    Enumeration termRegisEnum = termRegisVector.elements();
    while (termRegisEnum.hasMoreElements()){
      ite++;
      Registration r2 = (Registration)termRegisEnum.nextElement();
      String sub = r2.getSection().getSubject().getSubjectEname();
      str += "<fo:table-row height=\"0.5cm\"> " +
          "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-left-width = \"0.5pt\" border-left-style = \"solid\"> " +
                        "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">" + r2.getSection().getSubject().getSubjectID() + "</fo:block></fo:table-cell> " +
          "<fo:table-cell > " +
                        "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">" + sub + "</fo:block></fo:table-cell> " +
          "<fo:table-cell text-align=\"center\" vertical-align=\"middle\"> " +
                        "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">" + r2.getSection().getSubject().getCredit()+"</fo:block></fo:table-cell> " +
          "<fo:table-cell text-align=\"center\" vertical-align=\"middle\"> " +
                        "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">"+ r2.getGrade() +"</fo:block></fo:table-cell> " +
          "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-left-width = \"0.5pt\" border-left-style = \"solid\"> " +
                        "<fo:block></fo:block></fo:table-cell> " +
          "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " +
          "<fo:table-cell><fo:block></fo:block></fo:table-cell> " +
          "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-right-width = \"0.5pt\" border-right-style = \"solid\"> " +
                        "<fo:block></fo:block></fo:table-cell> " +
                "</fo:table-row> " ;
    }

    Vector tempVector = student.retrieveRegistrationPerSemester(s1);
    double totalGPS = student.calculateCredit(tempVector);
    showCredit += student.getAllCredit();
    conVector.addAll(tempVector);
    ite++;
    DecimalFormat format = new DecimalFormat("0.00");
    str += "<fo:table-row height=\"0.5cm\"> " +  "\n" +
        "<fo:table-cell number-columns-spanned = \"4\" text-align=\"center\" vertical-align=\"middle\" " +  "\n" +
               "border-right-width = \"0.5pt\" border-right-style = \"solid\" border-left-width = \"0.5pt\" border-left-style = \"solid\"> " +  "\n" +
               "<fo:block font-size=\"8pt\" font-family=\"sans-serif\"> GPS : " + format.format(totalGPS) +  "\n" +
               " GPA : " + format.format(student.calculateCredit(conVector)) + "</fo:block></fo:table-cell> " +  "\n" +
         "<fo:table-cell text-align=\"center\" vertical-align=\"middle\" border-left-width = \"0.5pt\" border-left-style=\"solid\" "+  "\n" +
         "border-right-width = \"0.5pt\" border-right-style = \"solid\" number-columns-spanned = \"4\"> " +  "\n" +
               "<fo:block></fo:block></fo:table-cell> " +  "\n" +
       "</fo:table-row> " +  "\n";
  }

  if (ite < 25) {
    for(int i=ite;i<=25;i++){
      str += "<fo:table-row height=\"0.5cm\"> " + "\n" +
      "<fo:table-cell border-left-width = \"0.5pt\" border-left-style = \"solid\" " + "\n" +
                    "number-columns-spanned = \"4\"><fo:block></fo:block></fo:table-cell> " + "\n" +
      "<fo:table-cell number-columns-spanned = \"4\" text-align=\"center\" vertical-align=\"middle\" " + "\n" +
                    "border-right-width = \"0.5pt\" border-right-style = \"solid\" border-left-width = \"0.5pt\" border-left-style = \"solid\"> " + "\n" +
                    "<fo:block></fo:block></fo:table-cell> " + "\n" +
            "</fo:table-row> " + "\n";
    }
  }
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                str += "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell border-left-width = \"0.5pt\" border-left-style = \"solid\" " + "\n" +
                              "number-columns-spanned = \"4\"><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell number-columns-spanned = \"4\" text-align=\"center\" vertical-align=\"middle\" " + "\n" +
                              "border-right-width = \"0.5pt\" border-right-style = \"solid\" border-left-width = \"0.5pt\" border-left-style = \"solid\"> " + "\n" +
                              "<fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                        "<fo:table-row height=\"0.2cm\"> " + "\n" +
                "<fo:table-cell border-top-width  = \"0.5pt\" border-top-style = \"solid\" " + "\n" +
                              "number-columns-spanned = \"8\"><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                "</fo:table-body> " + "\n" +
          "</fo:table> " + "\n" +
          "<!-- table end --> " + "\n" +

          "<!-- table start --> " + "\n" +
          "<fo:table table-layout=\"fixed\"> " + "\n" +
            "<fo:table-column column-width=\"2.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"0.6cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.9cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"0.6cm\"/> " + "\n" +
            "<fo:table-column column-width=\"2.1cm\"/> " + "\n" +
            "<fo:table-column column-width=\"0.8cm\"/> " + "\n" +
            "<fo:table-column column-width=\"4.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"5cm\"/> " + "\n" +

                "<fo:table-body> " + "\n" +

                      "<fo:table-row  height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">Grading System</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">A</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Excellent</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">4.00</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">D+</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Below Avg.</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">1.50</fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell number-columns-spanned = \"2\" text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\" font-weight = \"bold\"> " + "\n" +
                                      "Certified true copy. Not valid without seal.</fo:block></fo:table-cell>" + "\n" +
                      "</fo:table-row>" + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">B+</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Very Good</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">3.50</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">D</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Pass</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">1.00</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row  height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">B</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Good</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">3.00</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">F</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Failure.</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">0.00</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell number-columns-spanned = \"2\" text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\"> " + "\n" +
                                      "Date Issued .............................</fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">C+</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Above Avg.</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">2.50</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">S</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Satistactory</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row height=\"0.5cm\">  " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">C</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Average</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">2.00</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">U</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">: Unsatistactory</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell number-columns-spanned = \"3\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">GPS = Grade Point Semester</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell number-columns-spanned = \"4\" text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">GPA = Grade Point Average</fo:block></fo:table-cell> " + "\n" +
                       "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">.......................................</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">...................................</fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                "</fo:table-body> " + "\n" +
          "</fo:table> " + "\n" +
          "<!-- table end --> " + "\n" +

            "<fo:block font-size=\"18pt\" " + "\n" +
                  "font-family=\"sans-serif\" " + "\n" +
                  "line-height=\"24pt\" " + "\n" +
                  "space-after.optimum=\"5pt\" " + "\n" +
                  "background-color=\"white\" " + "\n" +
                  "color=\"black\" " + "\n" +
                  "text-align=\"center\" " + "\n" +
                  "padding-top=\"3pt\"> " + "\n" +
            "</fo:block> " + "\n" +

          "<!-- table start --> " + "\n" +
          "<fo:table table-layout=\"fixed\"> " + "\n" +
            "<fo:table-column column-width=\"2.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.8cm\"/> " + "\n" +
            "<fo:table-column column-width=\"2.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"3.2cm\"/> " + "\n" +
            "<fo:table-column column-width=\"4.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"5cm\"/> " + "\n" +

                "<fo:table-body> " + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">Ad = Audit</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">NC = Non-Credit</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">W = Withdraw</fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"7pt\" font-family=\"sans-serif\">Miss Supanee Sompan</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"7pt\" font-family=\"sans-serif\">Asst.Prof.Dr.Boonwat Attachoo</fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell number-columns-spanned = \"2\"> " + "\n" +
                "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">Grading system for Thesis</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                "</fo:table-body> " + "\n" +
          "</fo:table> " + "\n" +
          "<!-- table end --> " + "\n" +

          "<!-- table start --> " + "\n" +
          "<fo:table table-layout=\"fixed\"> " + "\n" +
            "<fo:table-column column-width=\"2.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"2.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"1.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"3.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"4.5cm\"/> " + "\n" +
            "<fo:table-column column-width=\"5cm\"/> " + "\n" +

                "<fo:table-body>" + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">O: Outstanding</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">G : Good</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">I : Incomplete</fo:block></fo:table-cell> " + "\n" +
                        "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">REGISTRAR</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell text-align=\"center\"> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">DEAN</fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                      "<fo:table-row height=\"0.5cm\"> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">F: Fail</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell> " + "\n" +
                              "<fo:block font-size=\"8pt\" font-family=\"sans-serif\">P : Pass</fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                "<fo:table-cell ><fo:block></fo:block></fo:table-cell> " + "\n" +
                      "</fo:table-row> " + "\n" +

                "</fo:table-body> " + "\n" +
          "</fo:table> " + "\n" +
          "<!-- table end --> " + "\n" +

              "</fo:flow> " + "\n" +
        "</fo:page-sequence> " + "\n" +
      "</fo:root>" ;

     writer.write(str);
      writer.flush();
      writer.close();
      Database.disconnect();
    }
    catch (Exception ef){
      System.out.println("ERROR : " + ef);
    }
  }

  void idText_actionPerformed(ActionEvent ea) {
    if (idText.getText().equals("")) {
      JOptionPane.showMessageDialog(this,"��س�������ʹѡ�֡��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
    }
    Database.connect();
    Registration registration = new Registration();
    student = student.retrieveStudent(new Student(idText.getText().trim()));
    registrationVector = registration.retrieveRegistration(student);
    Database.disconnect();

    Enumeration e = registrationVector.elements();
    while (e.hasMoreElements()){
      Registration r = (Registration)e.nextElement();
      System.out.println(r.getSection().getSubject().getSubjectEname() +" " + r.getGrade());
    }
    SimpleDateFormat formatter = new SimpleDateFormat("MMMM d,yyyy");
    tprenameText.setText(student.getPrename().getTPrename());
    tnameText.setText(student.getStudentTname());
    eprenameText.setText(student.getPrename().getEprename());
    enameText.setText(student.getStudentEname());
    facultyText.setText(student.getMajor().getDepartment().getFaculty().getEname());
    departmentText.setText(student.getMajor().getDepartment().getEname());
    majorText.setText(student.getMajor().getEname());
    if (student.getBirthday() == null) birthdayText.setText("");
    else birthdayText.setText(formatter.format(student.getBirthday()));
    if (student.getEntraceDate() == null) entranceText.setText("");
    else entranceText.setText(formatter.format(student.getEntraceDate()));
    if (student.getLeaveDate() == null) leaveText.setText("");
    else leaveText.setText(student.getLeaveDate().toString());

  }
}

class TranscriptUI_idText_actionAdapter implements java.awt.event.ActionListener {
  TranscriptUI adaptee;

  TranscriptUI_idText_actionAdapter(TranscriptUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.idText_actionPerformed(e);
  }
}

class TranscriptUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  TranscriptUI adaptee;

  TranscriptUI_jButton1_actionAdapter(TranscriptUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}