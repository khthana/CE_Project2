package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RegistrationChangeUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JTextField typeText = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField degreeText = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField nameText = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField studentIDText = new JTextField();
  JPanel jPanel2 = new JPanel();
  JTextField majorText = new JTextField();
  JTextField facultyText = new JTextField();
  JLabel jLabel5 = new JLabel();
  TitledBorder titledBorder1;
  JPanel jPanel4 = new JPanel();
  JPanel jPanel3 = new JPanel();
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  JPanel jPanel7 = new JPanel();
  JRadioButton jRadioButton3 = new JRadioButton();
  JPanel jPanel8 = new JPanel();
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  BorderLayout borderLayout2 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  JButton jButton2 = new JButton();
  JButton jButton1 = new JButton();
  //--------------------------------------------------------------------------------------------------------------------------------------------------------------
  int pastRow = 0;
  int selectedRow = 0;
  int pastColumn = 0;
  int selectedColumn = 0;
  Student student = new Student();
  Semester semester = new Semester();
  boolean canRegister = false;
  boolean newStudent = false;
  boolean edit = false;
  Vector registrationVector = new Vector();
  Vector tempVector = new Vector();
  Vector tempVector2 = new Vector();
  Vector subjectVector = new Vector();
  Vector vr = new Vector();
  Vector editv = new Vector();
  int normMaxCredit = 15;
  int normMinCredit = 9;
  int summerMaxCredit = 6;
  JButton changeButton = new JButton();
  //---------------------------------------------

  public RegistrationChangeUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�ѡ�֡��");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"����Ԫҷ��ŧ����¹����");
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"����Ԫҷ��١����¹");
    titledBorder3.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(null);
    typeText.setBounds(new Rectangle(113, 97, 111, 24));
    typeText.setText("");
    typeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("���");
    jLabel4.setBounds(new Rectangle(233, 66, 34, 15));
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("���ʹѡ�֡��");
    jLabel1.setBounds(new Rectangle(15, 30, 75, 15));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setText("�дѺ��ԭ��");
    jLabel3.setBounds(new Rectangle(15, 66, 84, 15));
    degreeText.setBounds(new Rectangle(113, 61, 111, 24));
    degreeText.setText("");
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("����-���ʡ��");
    jLabel2.setBounds(new Rectangle(233, 30, 72, 15));
    nameText.setEnabled(true);
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setText("");
    nameText.setBounds(new Rectangle(305, 25, 203, 24));
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("�������ѡ�֡��");
    jLabel6.setBounds(new Rectangle(15, 102, 89, 15));
    studentIDText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setText("");
    studentIDText.setBounds(new Rectangle(113, 25, 111, 24));
    studentIDText.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        studentIDText_actionPerformed(e);
      }
    });
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder1);
    jPanel2.setDebugGraphicsOptions(0);
    jPanel2.setBounds(new Rectangle(18, 14, 524, 144));
    jPanel2.setLayout(null);
    majorText.setEnabled(true);
    majorText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorText.setText("");
    majorText.setBounds(new Rectangle(305, 97, 203, 24));
    facultyText.setBounds(new Rectangle(305, 61, 203, 24));
    facultyText.setText("");
    facultyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setEnabled(true);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�Ң��Ԫ�");
    jLabel5.setBounds(new Rectangle(233, 102, 66, 15));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setPreferredSize(new Dimension(5, 5));
    jPanel4.setBounds(new Rectangle(13, 22, 660, 130));
    jPanel4.setLayout(borderLayout2);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder2);
    jPanel3.setPreferredSize(new Dimension(5, 5));
    jPanel3.setBounds(new Rectangle(20, 172, 680, 164));
    jPanel3.setLayout(null);

    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setBounds(new Rectangle(276, 395, 186, 35));
    jRadioButton3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton3.setText("�Ҿѡ");
    jRadioButton3.setBounds(new Rectangle(26, 96, 91, 23));
    jPanel8.setLayout(null);
    jPanel8.setBounds(new Rectangle(552, 15, 150, 143));
    jPanel8.setBorder(titledBorder3);
    jPanel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton1.setSelected(true);
    jRadioButton1.setText("����");
    jRadioButton1.setBounds(new Rectangle(26, 29, 91, 23));
    jRadioButton2.setBounds(new Rectangle(26, 62, 91, 23));
    jRadioButton2.setText("�ѡ����Ҿ");
    jRadioButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
    }
        ,
        new String[] {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Object.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean[] {
          true, false, false, true, true
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setRowSelectionAllowed(true);
    jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        jTable1_mouseClicked(e);
      }
    });
    jTable1.setCellSelectionEnabled(false);
    jTable1.setColumnSelectionAllowed(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(75, 128));
    jTable1.setPreferredSize(new Dimension(375, 404));
    jTable1.setMaximumSize(new Dimension(2147483647, 128));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY((float) 0.5);
    jTable1.setAlignmentX((float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);
    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    JComboBox comboBox = new JComboBox();
    comboBox.addItem("Cr");
    comboBox.addItem("Nc");
    comboBox.addItem("Ad");
    TableColumn typeColumn = jTable1.getColumn("Cr/Nc/Au");
    typeColumn.setCellEditor(new DefaultCellEditor(comboBox));

//Ask to be notified of selection changes.
    ListSelectionModel rowSM = jTable1.getSelectionModel();
    rowSM.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //Ignore extra messages.
        if (e.getValueIsAdjusting())
          return;

        ListSelectionModel lsm = (ListSelectionModel) e.getSource();
        if (lsm.isSelectionEmpty()) {
          //no rows are selected
        }
        else {
          //selectedRow is selected
          pastRow = selectedRow;
          selectedRow = lsm.getMinSelectionIndex();
        }
      }
    });
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setPreferredSize(new Dimension(454, 404));
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("������");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("�ѹ�֡");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    changeButton.setBounds(new Rectangle(34, 342, 126, 24));
    changeButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    changeButton.setText("����¹");
    changeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        changeButton_actionPerformed(e);
      }
    });
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(jLabel1, null);
    jPanel2.add(nameText, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(facultyText, null);
    jPanel2.add(degreeText, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(studentIDText, null);
    jPanel2.add(typeText, null);
    jPanel2.add(jLabel6, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(majorText, null);
    jPanel1.add(changeButton, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jPanel4, null);
    jPanel4.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTable1, null);
    jPanel7.add(jButton1, null);
    jPanel7.add(jButton2, null);
    jPanel1.add(jPanel7, null);
    jPanel1.add(jPanel8, null);
    jPanel8.add(jRadioButton1, null);
    jPanel8.add(jRadioButton3, null);
    jPanel8.add(jRadioButton2, null);
    jPanel1.add(jPanel2, null);
    buttonGroup1.add(jRadioButton1);
    buttonGroup1.add(jRadioButton2);
    buttonGroup1.add(jRadioButton3);

    Database.connect();
    this.semester = semester.retrieveCurrentSemester();
    Database.disconnect();
  }
  public void retrieveRegistrationRegistered(Student student) {
    Database.connect();
    Registration r = new Registration();
    vr = r.retrieveRegistration(student,semester,new RegisterType(1));
    if (vr.isEmpty()) {
      vr = r.retrieveRegistration(student,semester,new RegisterType(2));
      if (vr.isEmpty()) {
        Database.disconnect();
        return;
      }
    }

    Enumeration e = vr.elements();
    int i = 0;
    while (e.hasMoreElements()){
      Registration reg = (Registration)e.nextElement();
      jTable1.getModel().setValueAt(reg.getSection().getSubject().getSubjectID(),i,0);
      jTable1.getModel().setValueAt(reg.getSection().getSubject().getSubjectTname(),i,1);
      jTable1.getModel().setValueAt(new Integer(reg.getSection().getSubject().getCredit()),i,2);
      jTable1.getModel().setValueAt(new Integer(reg.getSection().getSec()),1,3);
      jTable1.getModel().setValueAt(reg.getType(),i,4);
      subjectVector.addElement(reg.getSection().getSubject());
      i++;
    }

    Database.disconnect();
  }
  public void clearRow(int i){
//    jTable1.getModel().setValueAt(null,i,0);
    jTable1.getModel().setValueAt(null,i,1);
    jTable1.getModel().setValueAt(null,i,2);
    jTable1.getModel().setValueAt(new Integer(1),pastRow,3);
    jTable1.getModel().setValueAt(null,i,4);
  }

  public void clearRow() {
    jTable1.getModel().setValueAt(null,pastRow,1);
    jTable1.getModel().setValueAt(null,pastRow,2);
    jTable1.getModel().setValueAt(new Integer(1),pastRow,3);
    jTable1.getModel().setValueAt(null,pastRow,4);
  }
  //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  public void clearTable(){
    for(int i=0;i<jTable1.getRowCount();i++)
      for(int j=0;j<jTable1.getColumnCount();j++) {
        if (j!=3) jTable1.setValueAt(null,i,j);
        else jTable1.setValueAt(new Integer(1),i,j);
      }
  }

  void studentIDText_actionPerformed(ActionEvent e) {//StudentID TextField
    Database.connect();
    student = student.retrieveStudent(new Student(studentIDText.getText()));
    Database.disconnect();
    //---------------------------------------------------------------------retrieve Registration-----------------------------------------------------------------------
    retrieveRegistrationRegistered(student);
    nameText.setText(student.getStudentTname());
    degreeText.setText(String.valueOf(student.getDegree()));
    facultyText.setText(student.getMajor().getDepartment().getFaculty().getTname());
    typeText.setText(String.valueOf(student.getStudentType()));
    majorText.setText(student.getMajor().getTname());
    if (student.getStatus() != 1) {
      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getRegisterStatus() != 1){
      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getDebtStatus()){
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ�����Թ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getLibraryStatus()) {
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ˹ѧ�����ͧ��ش","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    canRegister = true;
    if (registrationVector != null) newStudent = true;
  }

  public Section findSection(String subjectID,int sec){
    Enumeration e = subjectVector.elements();
    while (e.hasMoreElements()){
      Subject subject = (Subject)e.nextElement();
      if (subject.getSubjectID().equals(subjectID.trim())) {
        return subject.getSection(sec);
      }
    }
    return null;
  }

  void jButton1_actionPerformed(ActionEvent e) { //Save Button
    boolean complete = false;
    Database.connect();
    student.setCurrentRegistration(new Vector());
    Enumeration subEnum = tempVector.elements();
    if (!subEnum.hasMoreElements()){
      JOptionPane.showMessageDialog(this,"��س�������������Ԫ�㹵��ҧ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }

    for (int i=0;subEnum.hasMoreElements();i++){
      String subjectID = (String)jTable1.getModel().getValueAt(i,0);
      String sint = (String)jTable1.getModel().getValueAt(i,3).toString();
      String type = (String)jTable1.getModel().getValueAt(i,4);
      int si = Integer.parseInt(sint);

      if (subjectID != null && (sint == null || type == null)){
        JOptionPane.showMessageDialog(this,"��س����������������ó�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      Subject subject = (Subject)subEnum.nextElement();
      Registration registered = new Registration();
      if (registered.isRegistered(student,subject)){
        JOptionPane.showMessageDialog(this,"��ҹ��ŧ����Ԫҹ��������","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (subject.checkPrerequisite(subject) && !registered.isPrerequisiteRegistered(student,subject)){
        JOptionPane.showMessageDialog(this,"������Ԫҷ���ͧ���¹�ҡ�͹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
//      Section section = findSection(subjectID,si);
      Section section = subject.getSection(si);
      if (student.checkSectionConflict(section)){
        JOptionPane.showMessageDialog(this,"�������¹���������ͺ���ѹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (!section.checkAvailable()){
        String str = "����Ԫ�" + section.getSubject().getSubjectTname() + " �硪�� " + section.getSec() + "\n";
        str += "�չѡ�֡��ŧ�ú�ӹǹ����";
        JOptionPane.showMessageDialog(this,str,"��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
/*      int credit = subject.getCredit() + student.sumRegistrationUnit();
      if (semester.getSemesterType() == 1){
        if (credit > normMaxCredit) {
          JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե����ҡ�Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
      else {
        if (credit > summerMaxCredit) {
          JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե����ҡ�Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
      }*/

      Registration r = new Registration();
      r.setStudent(this.student);
      r.setSection(section);
      r.setSemester(semester);
      r.setRegisterType(new RegisterType(2));
      r.setType(type);
      r.setGrade("X");
      r.setPayDate(new java.util.Date());
      r.setRegistrar(new Registrar());
      student.addCurrentRegistration(r);
    }

/*    if (semester.getSemesterType() == 1){
      if (student.sumRegistrationUnit() < normMinCredit){
        JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե��������Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
    }*/
    //insert into Registration Table------------------------------------------------------------------------------------------------------------------------------

    Vector regVector = student.getCurrentRegistration();
    Enumeration regEnum = regVector.elements();
    while (regEnum.hasMoreElements()){
      Registration reg = (Registration)regEnum.nextElement();
      reg.getSection().incrementStudent(reg.getSection());
      complete = reg.insertRegistration(reg);
    }
    Enumeration tempe = editv.elements();
    while (tempe.hasMoreElements()){
      Registration reg = (Registration)tempe.nextElement();
      if (reg != null) complete = reg.deleteRegistration(reg);
    }
    if (complete){
      JOptionPane.showMessageDialog(this,"�ӡ�úѳ�֡���º��������","ʶҹС�÷ӧҹ",JOptionPane.INFORMATION_MESSAGE);
    }
    Database.disconnect();
  }

  void jButton2_actionPerformed(ActionEvent e) { //Clear Button
    clearTable();
  }

  void jTable1_mouseClicked(MouseEvent e) {
    if (edit){
      Subject subject = new Subject();
      String str = new String();
      boolean del = (e.getModifiers() & InputEvent.CTRL_MASK) ==
          InputEvent.CTRL_MASK;
      boolean press = (e.getModifiers() & InputEvent.BUTTON1_MASK) ==
          InputEvent.BUTTON1_MASK;
      TableColumnModel columnModel = jTable1.getColumnModel();
      pastColumn = selectedColumn;
      selectedColumn = columnModel.getColumnIndexAtX(e.getX());
      if (selectedColumn == 0) {
        pastRow = selectedRow;
        if (del) {
          for (int j = 0; j < jTable1.getColumnCount(); j++) { //CTRL + Single Click = Delete
            if (j != 3)
              jTable1.setValueAt(null, selectedRow, j);
            else
              jTable1.setValueAt(new Integer(1), selectedRow, j);
          }
        }
      }

      for (int i = 0; i < jTable1.getColumnCount(); i++) {
        if (pastRow > 0 && jTable1.getModel().getValueAt(pastRow - 1, i) == null) {
          JOptionPane.showMessageDialog(this, "��سҡ�͡���������ú",
                                        "��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
      if (pastColumn == 0)
        str = (String) jTable1.getModel().getValueAt(pastRow, pastColumn);
      if (str == null)
        return;
      if (press && selectedRow == pastRow && selectedColumn == 1) {
        Database.connect();
        subject = subject.retrieveSubject(str.trim(), student.getMajor());
        Database.disconnect();

        if (subject == null) {
          JOptionPane.showMessageDialog(this,"���������Ԫҹ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          clearRow();
          return;
        }
        if (subject.getSection() == null) {
          JOptionPane.showMessageDialog(this, "������硪��", "��ͼԴ��Ҵ",
                                        JOptionPane.ERROR_MESSAGE);
          clearRow();
          return;
        }

        boolean find = false;
        Enumeration subEnum = subjectVector.elements();
        while (subEnum.hasMoreElements()) {
          Subject sub = (Subject) subEnum.nextElement();
          if (sub.getSubjectID().equals(subject.getSubjectID())) {
            find = true;
            break;
          }
        }

        if (find) {
          JOptionPane.showMessageDialog(this, "����ԪҪ��", "��ͼԴ��Ҵ",
                                        JOptionPane.ERROR_MESSAGE);
          return;
        }
        else {
          subjectVector.addElement(subject);
          tempVector.addElement(subject);
          jTable1.getModel().setValueAt(subject.getSubjectTname(), pastRow, 1);
          jTable1.getModel().setValueAt(new Integer(subject.getCredit()),
                                        pastRow, 2);
        }
      }
    }
  }

  public Subject findSubject(String sub){
    Enumeration es = subjectVector.elements();
    while (es.hasMoreElements()){
      Subject s = (Subject)es.nextElement();
      if (s.getSubjectID().equals(sub)) return s;
    }
    return null;
  }

  void changeButton_actionPerformed(ActionEvent e) {
    String s = (String)jTable1.getModel().getValueAt(selectedRow,0);
    Subject subj = findSubject(s.trim());
    tempVector2.addElement(subj);
    clearRow(selectedRow);
    edit = true;
    Enumeration re = vr.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      if (r.getSection().getSubject().equals(subj)){
        editv.addElement(r);
      }
    }
  }
}