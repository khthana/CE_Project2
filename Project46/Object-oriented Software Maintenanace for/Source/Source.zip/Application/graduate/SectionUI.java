package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class SectionUI extends JPanel {
  String[] day = {"�ѹ���","�ѧ���","�ظ","����ʺ��","�ء��","�����","�ҷԵ��"};
  String[] date = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
  "21","22","23","24","25","26","27","28","29","30","31"};
  String[] month = {"���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�",
  "��Ȩԡ�¹","�ѹ�Ҥ�"};
  CompoundBorder titledBorder7;
  TitledBorder titledBorder6;
  BorderLayout borderLayout1 = new BorderLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  Border border1;
  TitledBorder titledBorder5;
  Border border2;
  Border border3;
  JPanel jPanel4 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JButton jButton2 = new JButton();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel116 = new JLabel();
  JRadioButton yesRadio = new JRadioButton();
  JComboBox monthCombo = new JComboBox(month);
  JLabel jLabel115 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField finalBText = new JTextField();
  JTextField finalEText = new JTextField();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel2 = new JLabel();
  JRadioButton firstRadio = new JRadioButton();
  JTextField studyRoomText = new JTextField();
  JButton saveButton = new JButton();
  JTextField startText = new JTextField();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel114 = new JLabel();
  JTextField registerText = new JTextField();
  JLabel jLabel117 = new JLabel();
  JRadioButton secondRadio = new JRadioButton();
  JLabel jLabel113 = new JLabel();
  JTextField finishText = new JTextField();
  JLabel jLabel111 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel112 = new JLabel();
  JRadioButton noRadio = new JRadioButton();
  JComboBox dateCombo = new JComboBox(date);
  JPanel jPanel7 = new JPanel();
  JPanel jPanel1 = new JPanel();
  JTextField beText = new JTextField();
  JButton clearButton = new JButton();
  JPanel jPanel6 = new JPanel();
  JTextField finalRoomText = new JTextField();
  JComboBox dayCombo = new JComboBox(day);
  JTextField secText = new JTextField();
  JRadioButton summerRadio = new JRadioButton();
  JLabel jLabel110 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JTextField noText = new JTextField();
  Border border4;
//-------------------------------------------------------------------------------------------------------------------------------------------------------------
  Subject subject;
  Section section;
  boolean newRecord = false;
  CourseUI courseUI;
  JLabel jLabel1 = new JLabel();
  JTextField degreeText = new JTextField();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  ButtonGroup buttonGroup2 = new ButtonGroup();

  public SectionUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public SectionUI(CourseUI courseUI) {
    try {
      this.courseUI = courseUI;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�ѹ�����ͺ");
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�ѹ�������¹");
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�Ҥ����֡�ҷ���Դ");
    titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�ӹǹ�ѡ�֡��");
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(165, 163, 151));
    titledBorder5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�ѹ�������¹");
    border4 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder3.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder4.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder6 = new TitledBorder(null, "�硪��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder7 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    border3 = BorderFactory.createCompoundBorder(titledBorder6,BorderFactory.createEmptyBorder(5,5,5,5));
    this.setLayout(borderLayout1);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setPreferredSize(new Dimension(380, 530));
    jPanel4.setLayout(borderLayout2);
    jButton2.setBounds(new Rectangle(272, 24, 199, 24));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setText("�Ҩ�������͹");
    jButton2.addActionListener(new SectionUI_jButton2_actionAdapter(this));
    jLabel12.setBounds(new Rectangle(41, 29, 46, 15));
    jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel12.setText("�礪�蹷��");
    jLabel116.setBounds(new Rectangle(200, 20, 75, 24));
    jLabel116.setText("��ͧ���¹");
    jLabel116.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel116.setRequestFocusEnabled(true);
    yesRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    yesRadio.setText("��");
    yesRadio.setBounds(new Rectangle(147, 97, 49, 23));
    monthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    monthCombo.setBounds(new Rectangle(172, 24, 122, 25));
    jLabel115.setBounds(new Rectangle(10, 49, 75, 24));
    jLabel115.setText("�����");
    jLabel115.setToolTipText("");
    jLabel115.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setText("�ѹ���¹");
    jLabel3.setBounds(new Rectangle(11, 22, 75, 24));
    finalBText.setBounds(new Rectangle(67, 56, 117, 25));
    finalBText.setOpaque(true);
    finalBText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finalBText.setPreferredSize(new Dimension(300, 25));
    finalBText.setText("");
    finalEText.setText("");
    finalEText.setPreferredSize(new Dimension(300, 25));
    finalEText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finalEText.setOpaque(true);
    finalEText.setBounds(new Rectangle(221, 56, 117, 25));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder1);
    jPanel3.setBounds(new Rectangle(39, 293, 434, 138));
    jPanel3.setLayout(null);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("��");
    jLabel2.setBounds(new Rectangle(310, 26, 17, 24));
    firstRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    firstRadio.setSelected(true);
    firstRadio.setText("�Ҥ����֡�ҷ�� 1");
    firstRadio.setBounds(new Rectangle(24, 27, 126, 23));
    studyRoomText.setText("");
    studyRoomText.setPreferredSize(new Dimension(300, 25));
    studyRoomText.setOpaque(true);
    studyRoomText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyRoomText.setBounds(new Rectangle(259, 20, 120, 24));
    saveButton.setBounds(new Rectangle(193, 446, 63, 25));
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new SectionUI_saveButton_actionAdapter(this));
    startText.setText("");
    startText.setPreferredSize(new Dimension(300, 25));
    startText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    startText.setOpaque(true);
    startText.setBounds(new Rectangle(66, 49, 120, 24));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder7);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(462, 550));
    jPanel2.setLayout(null);
    jLabel114.setBounds(new Rectangle(196, 63, 22, 15));
    jLabel114.setText("�֧");
    jLabel114.setToolTipText("");
    jLabel114.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    registerText.setBounds(new Rectangle(174, 58, 64, 28));
    registerText.setText("");
    registerText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel117.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel117.setToolTipText("");
    jLabel117.setText("����ش");
    jLabel117.setBounds(new Rectangle(197, 51, 75, 24));
    secondRadio.setBounds(new Rectangle(24, 59, 128, 23));
    secondRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    secondRadio.setText("�Ҥ����֡�ҷ�� 2");
    jLabel113.setBounds(new Rectangle(26, 101, 105, 15));
    jLabel113.setToolTipText("");
    jLabel113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel113.setRequestFocusEnabled(true);
    jLabel113.setText("��͡�ӹǹ�ѡ�֡��");
    finishText.setBounds(new Rectangle(259, 50, 120, 24));
    finishText.setOpaque(true);
    finishText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finishText.setPreferredSize(new Dimension(300, 25));
    finishText.setText("");
    jLabel111.setBounds(new Rectangle(23, 30, 124, 15));
    jLabel111.setToolTipText("");
    jLabel111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel111.setRequestFocusEnabled(true);
    jLabel111.setText("�ӹǹ�ѡ�֡�ҷ���Ѻ");
    jLabel19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel19.setToolTipText("");
    jLabel19.setText("�����ͺ");
    jLabel19.setBounds(new Rectangle(12, 62, 49, 15));
    jLabel16.setBounds(new Rectangle(132, 31, 36, 15));
    jLabel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel16.setText("��͹");
    jLabel112.setText("�ӹǹ�ѡ�֡�ҷ��ŧ����¹");
    jLabel112.setRequestFocusEnabled(true);
    jLabel112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel112.setToolTipText("");
    jLabel112.setBounds(new Rectangle(23, 64, 154, 15));
    noRadio.setBounds(new Rectangle(193, 97, 57, 23));
    noRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    noRadio.setSelected(true);
    noRadio.setText("�����");
    dateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    dateCombo.setBounds(new Rectangle(67, 24, 51, 25));
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setBorder(titledBorder4);
    jPanel7.setBounds(new Rectangle(206, 57, 267, 136));
    jPanel7.setLayout(null);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder5);
    jPanel1.setBounds(new Rectangle(40, 198, 433, 90));
    jPanel1.setLayout(null);
    beText.setBounds(new Rectangle(328, 21, 71, 28));
    beText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    beText.setText("");
    clearButton.setBounds(new Rectangle(261, 446, 63, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    clearButton.setText("������");
    clearButton.addActionListener(new SectionUI_clearButton_actionAdapter(this));
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setBorder(titledBorder3);
    jPanel6.setBounds(new Rectangle(41, 56, 160, 137));
    jPanel6.setLayout(null);
    finalRoomText.setBounds(new Rectangle(67, 92, 119, 25));
    finalRoomText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finalRoomText.setOpaque(true);
    finalRoomText.setPreferredSize(new Dimension(300, 25));
    finalRoomText.setText("");
    dayCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    dayCombo.setBounds(new Rectangle(67, 21, 120, 24));
    secText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    secText.setText("");
    secText.setBounds(new Rectangle(90, 24, 50, 24));
    summerRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    summerRadio.setText("�ҤĴ���͹");
    summerRadio.setBounds(new Rectangle(24, 91, 105, 23));
    jLabel110.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel110.setText("��ͧ�ͺ");
    jLabel110.setBounds(new Rectangle(12, 99, 97, 15));
    jLabel15.setBounds(new Rectangle(12, 31, 45, 15));
    jLabel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel15.setRequestFocusEnabled(true);
    jLabel15.setText("�ѹ�ͺ");
    noText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    noText.setText("");
    noText.setBounds(new Rectangle(174, 27, 64, 28));
    jPanel4.setBorder(border4);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("��鹻շ�����¹");
    jLabel1.setBounds(new Rectangle(148, 24, 57, 24));
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    degreeText.setText("");
    degreeText.setBounds(new Rectangle(210, 24, 50, 25));
    this.add(jPanel4,  BorderLayout.CENTER);
    jPanel4.add(jPanel2,  BorderLayout.CENTER);
    jPanel1.add(jLabel3, null);
    jPanel1.add(dayCombo, null);
    jPanel1.add(startText, null);
    jPanel1.add(jLabel115, null);
    jPanel1.add(studyRoomText, null);
    jPanel1.add(jLabel116, null);
    jPanel1.add(jLabel117, null);
    jPanel1.add(finishText, null);
    jPanel2.add(jButton2, null);
    jPanel2.add(jLabel12, null);
    jPanel2.add(secText, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(degreeText, null);
    jPanel2.add(clearButton, null);
    jPanel2.add(saveButton, null);
    jPanel2.add(jPanel3, null);
    jPanel6.add(firstRadio, null);
    jPanel6.add(secondRadio, null);
    jPanel6.add(summerRadio, null);
    jPanel2.add(jPanel7, null);
    jPanel3.add(jLabel15, null);
    jPanel3.add(jLabel19, null);
    jPanel3.add(jLabel110, null);
    jPanel3.add(finalBText, null);
    jPanel3.add(dateCombo, null);
    jPanel3.add(finalRoomText, null);
    jPanel3.add(monthCombo, null);
    jPanel3.add(finalEText, null);
    jPanel3.add(beText, null);
    jPanel3.add(jLabel2, null);
    jPanel3.add(jLabel16, null);
    jPanel2.add(jPanel6, null);
    jPanel7.add(registerText, null);
    jPanel7.add(jLabel111, null);
    jPanel7.add(jLabel112, null);
    jPanel7.add(noText, null);
    jPanel7.add(jLabel113, null);
    jPanel7.add(yesRadio, null);
    jPanel7.add(noRadio, null);
    jPanel2.add(jPanel1, null);
    jPanel3.add(jLabel114, null);
    buttonGroup1.add(firstRadio);
    buttonGroup1.add(secondRadio);
    buttonGroup1.add(summerRadio);
    buttonGroup2.add(yesRadio);
    buttonGroup2.add(noRadio);
  }
  public void addSection(Subject subject){
    this.subject = subject;
    newRecord = true;
    clear();
  }
  public boolean removeSection(Section section){
    Database.connect();
    boolean complete = section.deleteSection(section);
    Database.disconnect();
    if (complete) {
      clear();
      return true;
    }
    return false;
  }
  public void showUI(Section section){
    newRecord = false;
    this.section = section;
    secText.setText(Integer.toString(section.getSec()));
    degreeText.setText(Integer.toString(section.getLevel()));
    noText.setText(Integer.toString(section.getMax()));
    registerText.setText(Integer.toString(section.getCurent()));
    if (section.getLock()){
      yesRadio.setSelected(true);
    }
    else{
      noRadio.setSelected(true);
    }
    dayCombo.setSelectedIndex(section.getDay());
    studyRoomText.setText(section.getRoom());
    startText.setText(section.getBeginTime());
    finishText.setText(section.getEndTime());
    int day = section.getFinalDate().getDate();
    int month = section.getFinalDate().getMonth();
    int year = section.getFinalDate().getYear()+1900+543;
    setSelectedName(dateCombo,Integer.toString(day));
    setSelectedName(monthCombo,Integer.toString(month));
    beText.setText(Integer.toString(year));
    finalBText.setText(section.getFinalBtime());
    finalEText.setText(section.getFinalEtime());
    finalRoomText.setText(section.getFinalRoom());
  }
  public void setSelectedName(JComboBox cb, String name)
  {
     for (int i = 0;i < cb.getItemCount();++i)
     {
        String item = (String)cb.getItemAt(i);
        if (item.equals(name))
        {
           cb.setSelectedItem(item);
           return;
        }
     }
  }

  public void clear(){
    secText.setText("");
    degreeText.setText("");
    noText.setText("");
    registerText.setText("");
    yesRadio.setSelected(true);
    dayCombo.setSelectedItem(null);
    studyRoomText.setText("");
    startText.setText("");
    finishText.setText("");
    dateCombo.setSelectedItem(null);
    monthCombo.setSelectedItem(null);
    beText.setText("");
    finalBText.setText("");
    finalEText.setText("");
    finalRoomText.setText("");
  }

  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Database.connect();
    Section section = new Section();
    section.setSec(Integer.parseInt(secText.getText()));
    section.setLevel(Integer.parseInt(degreeText.getText()));
    Semester semester = new Semester();
    semester = semester.retrieveCurrentSemester();
    section.setSemeter(semester);
    section.setMax(Integer.parseInt(noText.getText()));
    section.setCurrent(Integer.parseInt(registerText.getText()));
    section.setLock(yesRadio.isSelected());
    section.setDay(dayCombo.getSelectedIndex());
    section.setRoom(studyRoomText.getText());
    section.setBeginTime(startText.getText());
    section.setEndTime(finishText.getText());
    int date = dateCombo.getSelectedIndex() + 1;
    int month = monthCombo.getSelectedIndex();
    int year = Integer.parseInt(beText.getText())-543;
    GregorianCalendar g = new GregorianCalendar(year,month,date);
    java.util.Date d = g.getTime();
    section.setFinalDate(d);
    section.setFinalBtime(finalBText.getText());
    section.setFinalEtime(finalEText.getText());
    section.setFinalRoom(finalRoomText.getText());
    section.setSubject(this.subject);
    if (newRecord) {
      complete = section.insertSection(section);
      if (complete) courseUI.addNode(section);
    }
    else {
      complete = section.updateSection(this.section,section);
      if (complete) courseUI.updateNode(section);
    }
    Database.disconnect();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    boolean packFrame = false;
    SectionProfessorUI frame = new SectionProfessorUI();
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }
}

class SectionUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  SectionUI adaptee;

  SectionUI_saveButton_actionAdapter(SectionUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class SectionUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  SectionUI adaptee;

  SectionUI_jButton2_actionAdapter(SectionUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class SectionUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  SectionUI adaptee;

  SectionUI_clearButton_actionAdapter(SectionUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}