package graduate;

import java.util.*;
public class Plan {
  private long planID;
  private CourseStructure courseStructure;
  private int yearNumber;
  private int semester;
  private String subjectID;
  private String subjectEname;
  private String SubjectTname;
  private int SubjectType;
  private int credit;
  private int lecture;
  private int practice;
  private int research;
  private PlanDB planDB = new PlanDB();
  //Constructor
  public Plan() {
  }
  public Plan(long id){
    this.setPlanID(id);
  }
  //getMethod
  public long getPlanID(){
    return this.planID;
  }
  public CourseStructure getCourseStructure(){
    return this.courseStructure;
  }
  public int getYearNumber(){
    return this.yearNumber;
  }
  public int getSemester(){
    return this.semester;
  }
  public String getSubjectID(){
    return this.subjectID;
  }
  public String getSubjectEname(){
    return this.subjectEname;
  }
  public String getSubjectTname(){
    return this.SubjectTname;
  }
  public int getSubjectType(){
    return this.SubjectType;
  }
  public int getCredit(){
    return this.credit;
  }
  public int getLecture(){
    return this.lecture;
  }
  public int getPractice(){
    return this.practice;
  }
  public int getResearch(){
    return this.research;
  }
  //setMethod
  public void setPlanID(long pid){
    this.planID = pid;
  }
  public void setCourseStructure(CourseStructure cs){
    this.courseStructure = cs;
  }
  public void setYearNumber(int yn){
    this.yearNumber = yn;
  }
  public void setSemester(int semester){
    this.semester = semester;
  }
  public void setSubjectID(String id){
    this.subjectID = id;
  }
  public void setSubjectEname(String ename){
    this.subjectEname = ename;
  }
  public void setSubjectTname(String tname){
    this.SubjectTname = tname;
  }
  public void setSubjectType(int type){
    this.SubjectType = type;
  }
  public void setCredit(int cr){
    this.credit = cr;
  }
  public void setLecture(int lt){
    this.lecture = lt;
  }
  public void setPractice(int p){
    this.practice = p;
  }
  public void setResearch(int r){
    this.research = r;
  }
  //Business Method
  public Vector retrievePlanAll(CourseStructure cs){
    return planDB.retrievePlanAll(cs);
  }
  public boolean insertPlan(Plan p){
    return planDB.insertPlan(p);
  }
  public boolean updatePlan(Plan p){
    return planDB.updatePlan(p);
  }
  public boolean deletePlan(Plan p){
    return planDB.deletePlan(p);
  }
}