package graduate;

import java.util.*;
import java.io.*;

public class Subject {
  private String subjectID;
  private String subjectEname;
  private String SubjectTname;
  private Group group;
  private int SubjectType;
  private int credit;
  private int lecture;
  private int practice;
  private int research;
  private String eDescription;
  private String tDescription;
  private Major major;
  private SubjectDB subjectDB = new SubjectDB();
  private Vector sectionVector = new Vector();
  private Vector  prerequisiteVector = new Vector();
  //Constructor
  public Subject() {
  }
  public Subject(String id){
    this.setSubjectID(id);
  }
  //getMethod
  public String getSubjectID(){
    return this.subjectID;
  }
  public String getSubjectEname(){
    return this.subjectEname;
  }
  public String getSubjectTname(){
    return this.SubjectTname;
  }
  public Group getGroup(){
    return this.group;
  }
  public int getSubjectType(){
    return this.SubjectType;
  }
  public int getCredit(){
    return this.credit;
  }
  public int getLecture(){
    return this.lecture;
  }
  public int getPractice(){
    return this.practice;
  }
  public int getResearch(){
    return this.research;
  }
  public String getEdescription(){
    return this.eDescription;
  }
  public String getTdescription(){
    return this.tDescription;
  }
  public Major getMajor(){
    return this.major;
  }
  public Vector getPrerequisite(){
    return  this.prerequisiteVector;
  }
  public Vector getSection(){
    Enumeration e = this.sectionVector.elements();
    if (!e.hasMoreElements()) return null;
    return this.sectionVector;
  }
  public Section getSection(int sec){
    Vector v = getSection();
    if (v != null){
     Enumeration e =  v.elements();
     while (e.hasMoreElements()){
       Section s = (Section)e.nextElement();
       if (s.getSec() == sec) return s;
     }
    }
    return null;
  }
  //setMethod
  public void setSubjectID(String id){
    this.subjectID = id;
  }
  public void setSubjectEname(String ename){
    this.subjectEname = ename;
  }
  public void setSubjectTname(String tname){
    this.SubjectTname = tname;
  }
  public void setGroup(Group g){
    this.group = g;
  }
  public void setSubjectType(int type){
    this.SubjectType = type;
  }
  public void setCredit(int cr){
    this.credit = cr;
  }
  public void setLecture(int lt){
    this.lecture = lt;
  }
  public void setPractice(int p){
    this.practice = p;
  }
  public void setResearch(int r){
    this.research = r;
  }
  public void setEdescription(String edes){
    this.eDescription = edes;
  }
  public void setTdescription(String tdes){
    this.tDescription = tdes;
  }
  public void setMajor(Major major){
    this.major = major;
  }
  //Business Method
  //-------------------------------------------------------------------------sectionVector--------------------------------------------------------------------
  public void addSection(Section section){
    sectionVector.addElement(section);
  }
  public void setSection(Vector section){
    sectionVector = section;
  }
  public Enumeration retrieveSection(){
    return sectionVector.elements();
  }
  public Section retrieveSection(long sectionID){
    Enumeration e = retrieveSection();
    while (e.hasMoreElements()){
      Section section = (Section)e.nextElement();
      if (section.getSectionID() == sectionID)
        return section;
    }
    return null;
  }
  //-----------------------------------------------------------------------prerequisiteVector---------------------------------------------------------------
  public void addPrerequisite(Subject  subject){
    prerequisiteVector.addElement(subject);
  }
  public void setPrerequisite(Vector subject){
    prerequisiteVector = subject;
  }
  public Enumeration retrievePrerequisite(){
    return prerequisiteVector.elements();
  }
  public Subject retrievePrerequisite(String subjectID){
    Enumeration e = retrievePrerequisite();
    while (e.hasMoreElements()){
      Subject subject = (Subject)e.nextElement();
      if (subject.getSubjectID().equals(subjectID))
        return subject;
    }
    return null;
  }
  //-------------------------------------------------------------------------Access Layer------------------------------------------------------------------
  public Vector retrieveSubject(Major major){
    return subjectDB.retrieveSubject(major);
  }
  public Subject retrieveSubject(Subject subject){
   return subjectDB.retrieveSubject(subject);
  }
  public Subject retrieveSubject(String subject,Major major){
    Vector v = subjectDB.retrieveSubject(subject,major);
    Enumeration e = v.elements();
    if (!e.hasMoreElements()) return null;
    Section sec = new Section();
    Subject sub = (Subject)e.nextElement();
    sub.setSection(sec.retrieveSection(sub));
    sub.setPrerequisite(retrievePrerequisite(sub));
    return sub;
  }
  public Vector retrieveSubjectForWeb(Major major){
    return subjectDB.retrieveSubjectForWeb(major);
  }
  public Vector retrieveSubjectForReview(Major major){
    return subjectDB.retrieveSubjectForReview(major);
  }
  public Subject retrieveSubjectInDifMajor(String subject,Major major){
    Vector v = subjectDB.retrieveSubjectInDifMajor(subject,major);
    Enumeration e = v.elements();
    if (!e.hasMoreElements()) return null;
    Section sec = new Section();
    while (e.hasMoreElements()){
      Subject sub = (Subject)e.nextElement();
      this.sectionVector = sec.retrieveSection(sub);
      this.prerequisiteVector = retrievePrerequisite(sub);
    }
    return (Subject)e.nextElement();
  }
  public Vector retrievePrerequisite(Subject subject){
    Vector v = subjectDB.retrievePrerequisite(subject);
    subject.setPrerequisite(v);
    return v;
  }
  public boolean checkPrerequisite(Subject subject){
    Vector v = subjectDB.retrievePrerequisite(subject);
    if (v.isEmpty()) return  false;
    return true;
  }
  public Vector retrievePrerequisiteAll(Subject subject){
    Vector v = subjectDB.retrievePrerequisiteAll(subject);
    subject.setPrerequisite(v);
    return v;
  }
  public boolean insertSubject(Subject subject){
    return subjectDB.insertSubject(subject);
  }
  public boolean insertPrerequisite(){
    Enumeration e = retrievePrerequisite();
    while (e.hasMoreElements()){
      Subject subject = (Subject)e.nextElement();
      subjectDB.insertPrerequisite(this,subject);
    }
    return true;
  }
  public boolean updateSubject(Subject old,Subject subject){
    return subjectDB.updateSubject(old,subject);
  }
  public boolean deleteSubject(Subject subject){
    return subjectDB.deleteSubject(subject);
  }
  public String toString(){
    return this.getSubjectTname();
  }
  public void writeAllSubjectToJavaScriptFile(Major major)
  {
      String subId = "var subjectId = new Array(";
      String subName = "var subjectName = new Array(";
      String subCredit = "var subjectCredit = new Array(";

      Vector v = subjectDB.retrieveSubjectForWeb(major);
      Enumeration e = v.elements();

      while(e.hasMoreElements())
      {
          Subject s = (Subject)e.nextElement();

          subId = subId + "\"" + s.getSubjectID() + "\",";
          subName = subName + "\"" + s.getSubjectEname() + "\",";
          subCredit = subCredit + "\"" + s.getCredit() + "\",";
      }

      subId = subId.substring(0,subId.length()-1) + "); ";
      subName = subName.substring(0,subName.length()-1) + "); ";
      subCredit = subCredit.substring(0,subCredit.length()-1) + "); ";

      PrintToFile pf = new PrintToFile();
      pf.getDataToOutFile(subId + " " + subName + " " + subCredit, "C:\\graduate\\defaultroot\\Script\\Script.js");
  }
}