package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.table.*;

public class GradeRecordUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  CompoundBorder titledBorder2;
  TitledBorder titledBorder5;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabel1 = new JLabel();
  JTextField nameText = new JTextField();
  JLabel jLabel2 = new JLabel();
  JComboBox secCombo = new JComboBox();
  JButton jButton1 = new JButton();
  JPanel jPanel3 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JTextField idText = new JTextField();
  //-----------------------------------------------------------------------------------------------------------------------------------------------------------------
  Vector vr = new Vector();

  public GradeRecordUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder6 = new TitledBorder(null, "����ô�ѡ�֡�ҵ������Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));

    titledBorder5 = new TitledBorder(null, "����Ԫ�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder5,new EmptyBorder(5,5,5,5));

    this.setLayout(borderLayout1);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(flowLayout1);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder1);
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder2);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("�����Ԫ�");
    flowLayout1.setAlignment(FlowLayout.LEFT);
    flowLayout1.setHgap(10);
    nameText.setEnabled(false);
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setPreferredSize(new Dimension(300, 21));
    nameText.setSelectionStart(0);
    nameText.setText("");
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("�硪ѹ");
    secCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    secCombo.setPreferredSize(new Dimension(50, 21));
    secCombo.addActionListener(new GradeRecordUI_secCombo_actionAdapter(this));
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setActionCommand("");
    jButton1.setText("������");
    jButton1.addActionListener(new GradeRecordUI_jButton1_actionAdapter(this));
    jPanel3.setLayout(borderLayout3);
    jPanel4.setLayout(flowLayout2);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("������");
    jButton2.addActionListener(new GradeRecordUI_jButton2_actionAdapter(this));
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton3.setMaximumSize(new Dimension(80, 25));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("��ŧ");
    jButton3.addActionListener(new GradeRecordUI_jButton3_actionAdapter(this));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setRowHeight(18);
    idText.setPreferredSize(new Dimension(100, 21));
    idText.setText("");
    idText.addActionListener(new GradeRecordUI_idText_actionAdapter(this));
    idText.addActionListener(new GradeRecordUI_idText_actionAdapter(this));
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(jLabel1, null);
    jPanel2.add(idText, null);
    jPanel2.add(nameText, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(secCombo, null);
    jPanel2.add(jButton1, null);
    jPanel1.add(jPanel3,  BorderLayout.CENTER);
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    jPanel4.add(jButton3, null);
    jPanel4.add(jButton2, null);
    jScrollPane1.getViewport().add(jTable1, null);

    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setRowSelectionAllowed(true);
    jTable1.getTableHeader().setReorderingAllowed(false);
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
        , {null, null, null,null}
    }
        ,
        new String[] {
        "���ʹѡ�֡��", "����-���ʡ��", "�ô", "������"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Object.class
      };
      boolean[] canEdit = new boolean[] {
          false, false, true, false
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setColumnSelectionAllowed(false);
    jTable1.setCellSelectionEnabled(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(0, 0));
    jTable1.setMaximumSize(new Dimension(0, 0));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY( (float) 0.5);
    jTable1.setAlignmentX( (float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);
  }

  void idText_actionPerformed(ActionEvent e) {
    Database.connect();
    String str = idText.getText();
    Subject subject = new Subject(str);
    subject = subject.retrieveSubject(subject);
    if (subject == null){
      JOptionPane.showMessageDialog(this,"���������Ԫҹ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    nameText.setText(subject.getSubjectTname());
    secCombo.removeAllItems();
    Enumeration secEnum = subject.getSection().elements();
    while (secEnum.hasMoreElements()){
      Section sec = (Section)secEnum.nextElement();
      secCombo.addItem(sec);
    }
    Database.disconnect();
  }

  void secCombo_actionPerformed(ActionEvent e) {
    if (secCombo.getSelectedItem() != null){
      Database.connect();
      Registration rg = new Registration();
      vr = rg.retrieveRegistration((Section)secCombo.getSelectedItem());
      Object obj[][] = new Object[vr.size()][4];
      Enumeration eRegis = vr.elements();
      int row = 0;
      while (eRegis.hasMoreElements()){
        Registration r = (Registration)eRegis.nextElement();
        obj[row][0] = r.getStudent().getStudentID();
        obj[row][1] = r.getStudent().getStudentTname();
        obj[row][2] = (r.getGrade().equals("X") || r.getGrade().equals("") || r.getGrade() == null)?"":r.getGrade();
        obj[row][3] = r.getType();
        row++;
      }
      String[] columnHeader = {
          "�����Ԫ�", "�����Ԫ�", "�ô","������"};

      jTable1.setModel(new javax.swing.table.DefaultTableModel(obj,columnHeader));
      JComboBox comboBox = new JComboBox();
      comboBox.addItem("A");
      comboBox.addItem("B+");
      comboBox.addItem("B");
      comboBox.addItem("C+");
      comboBox.addItem("C");
      comboBox.addItem("D+");
      comboBox.addItem("D");
      comboBox.addItem("F");
      comboBox.addItem("W");
      comboBox.addItem("I");
      comboBox.addItem("S");
      comboBox.addItem("U");
      TableColumn typeColumn = jTable1.getColumn("�ô");
      typeColumn.setCellEditor(new DefaultCellEditor(comboBox));
      Database.disconnect();
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    idText.setText("");
    nameText.setText("");
    secCombo.removeAllItems();
  }

  void jButton2_actionPerformed(ActionEvent e) {

  }

  void jButton3_actionPerformed(ActionEvent e) {
    int i =0;
    Enumeration re = vr.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      String str = (String)jTable1.getModel().getValueAt(i++,2);
      if (str == null || str.equals("")){
        JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      r.setGrade(str);
    }
    boolean complete = false;
    Database.connect();
    re = vr.elements();
    while (re.hasMoreElements()){
      Registration r = (Registration)re.nextElement();
      complete = r.updateRegistration(r);
    }
    if (complete) {
      JOptionPane.showMessageDialog(this,"�ӡ�úѹ�֡���º��������","ʶҹС�÷ӧҹ",JOptionPane.INFORMATION_MESSAGE);
    }
    Database.disconnect();
  }
}

class GradeRecordUI_idText_actionAdapter implements java.awt.event.ActionListener {
  GradeRecordUI adaptee;

  GradeRecordUI_idText_actionAdapter(GradeRecordUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.idText_actionPerformed(e);
  }
}

class GradeRecordUI_secCombo_actionAdapter implements java.awt.event.ActionListener {
  GradeRecordUI adaptee;

  GradeRecordUI_secCombo_actionAdapter(GradeRecordUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.secCombo_actionPerformed(e);
  }
}

class GradeRecordUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  GradeRecordUI adaptee;

  GradeRecordUI_jButton1_actionAdapter(GradeRecordUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class GradeRecordUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  GradeRecordUI adaptee;

  GradeRecordUI_jButton2_actionAdapter(GradeRecordUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class GradeRecordUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  GradeRecordUI adaptee;

  GradeRecordUI_jButton3_actionAdapter(GradeRecordUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}