package graduate;

public class Prerequisite {
  private Subject subject;
  private Subject PreSubject;
  //Constructor
  public Prerequisite() {
  }
  //getMethod
  public Subject getSubject(){
    return this.subject;
  }
  public Subject getPreSubject(){
    return this.PreSubject;
  }
  //setMethod
  public void setSubject(Subject sub){
    this.subject = sub;
  }
  public void SetPreSubject(Subject pre){
    this.PreSubject = pre;
  }

}