package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class EtcUI extends JPanel {
  Border loweredBorder;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JPanel switchPanel = new JPanel();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("��� �");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  Border border1;
  //--------------------------------------------------------------------------------------------------------------------------------------
  LocationUI locationUI = new LocationUI(this);
  OccupationUI occupationUI = new OccupationUI(this);
  PrenameUI prenameUI = new PrenameUI(this);
  ScholarshipGroupUI ssgUI = new ScholarshipGroupUI(this);
  SubjectGroupUI sgUI = new SubjectGroupUI(this);

  Location location = new Location();
  Occupation occupation = new Occupation();
  Prename prename = new Prename();
  ScholarshipGroup ssg = new ScholarshipGroup();
  Group group = new Group();

  int currentNode = 0;
  boolean canAdd = false;
  JScrollPane jScrollPane1 = new JScrollPane();
  JTree jTree1 = new JTree(treeModel);

  public EtcUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    loweredBorder = BorderFactory.createEmptyBorder(5,5,5,5);
    jButton2.setText("����");
    jButton2.addActionListener(new EtcUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new EtcUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border1);
    jPanel1.setPreferredSize(new Dimension(622, 500));
    switchPanel.setLayout(boxLayout22);
    switchPanel.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    switchPanel.setBorder(loweredBorder);
    switchPanel.setPreferredSize(new Dimension(472, 462));
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(loweredBorder);
    jPanel3.setPreferredSize(new Dimension(175, 462));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setBorder(null);
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jPanel3.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jSplitPane1.add(switchPanel, JSplitPane.RIGHT);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());

    switchPanel.add(locationUI);
    switchPanel.add(occupationUI);
    switchPanel.add(prenameUI);
    switchPanel.add(ssgUI);
    switchPanel.add(sgUI);

    occupationUI.setVisible(false);
    prenameUI.setVisible(false);
    ssgUI.setVisible(false);
    sgUI.setVisible(false);

    createTree();
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();
      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String) {
        canAdd = true;
        String s = (String)nodeInfo;
        if (s.equals("�ٹ�����¹")){
          setPanelVisible(1);
          currentNode = 1;
          location = new Location();
          ((LocationUI)locationUI).showUI(location);
        }
        else if (s.equals("�Ҫվ")){
          setPanelVisible(2);
          currentNode = 2;
          occupation = new Occupation();
          ((OccupationUI)occupationUI).showUI(occupation);
        }
        else if (s.equals("�ӹ�˹�Ҫ���")){
          setPanelVisible(3);
          currentNode = 3;
          prename = new Prename();
          ((PrenameUI)prenameUI).showUI(prename);
        }
        else if (s.equals("�������ع����֡��")){
          setPanelVisible(4);
          currentNode = 4;
          ssg = new ScholarshipGroup();
          ((ScholarshipGroupUI)ssgUI).showUI(ssg);
        }
        else {
          setPanelVisible(5);
          currentNode = 5;
          group = new Group();
          ((SubjectGroupUI)sgUI).showUI(group);
        }
      }
      else canAdd = false;
      if (nodeInfo instanceof Location){
        setPanelVisible(1);
        currentNode = 1;
        location = (Location)nodeInfo;
        ((LocationUI)locationUI).showUI(location);
      }
      else if (nodeInfo instanceof Occupation){
        setPanelVisible(2);
        currentNode = 2;
        occupation = (Occupation)nodeInfo;
        ((OccupationUI)occupationUI).showUI(occupation);
      }
      else if (nodeInfo instanceof Prename){
        setPanelVisible(3);
        currentNode = 3;
        prename = (Prename)nodeInfo;
        ((PrenameUI)prenameUI).showUI(prename);
      }
      else if (nodeInfo instanceof ScholarshipGroup){
        setPanelVisible(4);
        currentNode = 4;
        ssg = (ScholarshipGroup)nodeInfo;
        ((ScholarshipGroupUI)ssgUI).showUI(ssg);
      }
      else if (nodeInfo instanceof Group){
        setPanelVisible(5);
        currentNode = 5;
        group = (Group)nodeInfo;
        ((SubjectGroupUI)sgUI).showUI(group);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void setPanelVisible(int panel){
    locationUI.setVisible(false);
    occupationUI.setVisible(false);
    prenameUI.setVisible(false);
    ssgUI.setVisible(false);
    sgUI.setVisible(false);
    if (panel==1) locationUI.setVisible(true);
    else if (panel==2) occupationUI.setVisible(true);
    else if (panel==3) prenameUI.setVisible(true);
    else if (panel==4) ssgUI.setVisible(true);
    else if (panel==5) sgUI.setVisible(true);
  }
  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode node = createNode("�ٹ�����¹");
    root.add(node);
    Vector v = location.retrieveLocation();
    Enumeration e = v.elements();
    while (e.hasMoreElements()) {
      Location obj = (Location) e.nextElement();
      node.add(new DefaultMutableTreeNode(obj));
    }

    node = createNode("�Ҫվ");
    root.add(node);
    v = occupation.retrieveOccupation();
    e = v.elements();
    while (e.hasMoreElements()) {
      Occupation obj = (Occupation) e.nextElement();
      node.add(new DefaultMutableTreeNode(obj));
    }

    node = createNode("�ӹ�˹�Ҫ���");
    root.add(node);
    v = prename.retrievePrename();
    e = v.elements();
    while (e.hasMoreElements()) {
      Prename obj = (Prename) e.nextElement();
      node.add(new DefaultMutableTreeNode(obj));
    }

    node = createNode("�������ع����֡��");
    root.add(node);
    v = ssg.retrieveScholarshipGroup();
    e = v.elements();
    while (e.hasMoreElements()) {
      ScholarshipGroup obj = (ScholarshipGroup) e.nextElement();
      node.add(new DefaultMutableTreeNode(obj));
    }

    node = createNode("��Ǵ�Ԫ�");
    root.add(node);
    v = group.retrieveGroup();
    e = v.elements();
    while (e.hasMoreElements()) {
      Group obj = (Group) e.nextElement();
      node.add(new DefaultMutableTreeNode(obj));
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }

  public DefaultMutableTreeNode createNode(String str){
      return  new DefaultMutableTreeNode(str);
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }

  public void updateNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    lastItem.setUserObject(obj);
    jTree1.repaint();
  }
  void jButton2_actionPerformed(ActionEvent e) {
    switch (currentNode){
      case 1:
        ((LocationUI)locationUI).addLocation();
        break;
      case 2:
        ((OccupationUI)occupationUI).addOccupation();
        break;
      case 3:
        ((PrenameUI)prenameUI).addprename();
        break;
      case 4:
        ((ScholarshipGroupUI)ssgUI).addScholarshipGroup();
        break;
      case 5:
        ((SubjectGroupUI)sgUI).addGroup();
        break;
      default: break;
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Location) {
          complete = ((LocationUI)locationUI).removeLocation((Location)obj);
        }
        else if (obj instanceof Occupation) {
         complete = ((OccupationUI)occupationUI).removeOccupation((Occupation)obj);
        }
        else if (obj instanceof Prename) {
          complete = ((PrenameUI)prenameUI).removePrename((Prename)obj);
        }
        else if (obj instanceof ScholarshipGroup) {
          complete = ((ScholarshipGroupUI)ssgUI).removeScholarshipGroup((ScholarshipGroup)obj);
        }
        else if (obj instanceof Group) {
          complete = ((SubjectGroupUI)sgUI).removeGroup((Group)obj);
        }
        if (complete) treeModel.removeNodeFromParent(node);
      }
    }
  }
}

class EtcUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  EtcUI adaptee;

  EtcUI_jButton2_actionAdapter(EtcUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class EtcUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  EtcUI adaptee;

  EtcUI_jButton3_actionAdapter(EtcUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}
