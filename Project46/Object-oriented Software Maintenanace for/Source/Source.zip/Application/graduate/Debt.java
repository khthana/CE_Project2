package graduate;

import java.util.*;
public class Debt {
  private long debtID;
  private double money;
  private boolean type;
  private double balance;
  private Date debtDate;
  private Student student;
  private DebtDB debtDB = new DebtDB();
  //Constructor
  public Debt() {
  }
  public Debt(long id){
    this.setDebtID(id);
  }
  //getMethod
  public long getDebtID(){
    return this.debtID;
  }
  public double getMoney(){
    return this.money;
  }
  public boolean getType(){
    return this.type;
  }
  public double getBalance(){
    return this.balance;
  }
  public Date getDebtDate(){
    return this.debtDate;
  }
  public Student getStudent(){
    return this.student;
  }
  //setMethod
  public void setDebtID(long debtid){
    this.debtID = debtid;
  }
  public void setMoney(double money){
    this.money = money;
  }
  public void setType(boolean type){
    this.type = type;
  }
  public void setBalance(double balance){
    this.balance = balance;
  }
  public void setDebtDeate(Date dd){
    this.debtDate = dd;
  }
  public void setStudent(Student s){
    this.student = s;
  }
  //Business Method
  public Vector retrieveDebtAll(Student student){
    return debtDB.retrieveDebt(student);
  }
  public boolean insertDebt(Debt debt){
    return debtDB.insertDebt(debt);
  }
  public boolean updateDebt(Debt debt){
    return debtDB.updateDebt(debt);
  }
  public boolean deleteDebt(Debt debt){
    return debtDB.deleteDebt(debt);
  }
}