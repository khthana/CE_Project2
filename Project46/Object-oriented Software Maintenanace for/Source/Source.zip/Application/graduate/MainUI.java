package graduate;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class MainUI extends JFrame {
  JPanel contentPane;
  JMenuBar jMenuBar1 = new JMenuBar();
  JMenu jMenuFile = new JMenu();
  JToolBar jToolBar = new JToolBar();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  ImageIcon image1;
  ImageIcon image2;
  ImageIcon image3;
  BorderLayout borderLayout1 = new BorderLayout();
  JMenuItem generalMnu = new JMenuItem();
  JMenuItem structureMnu = new JMenuItem();
  JMenuItem studentMnu = new JMenuItem();
  JMenuItem scholarshipMnu = new JMenuItem();
  JMenuItem etcMnu = new JMenuItem();
  JMenuItem professorMnu = new JMenuItem();
  JMenuItem registrarMnu = new JMenuItem();
  JMenuItem jMenuFileExit = new JMenuItem();
  JMenu jMenu1 = new JMenu();
  JMenuItem costMnu = new JMenuItem();
  JMenuItem supportMnu = new JMenuItem();
  JMenu jMenu2 = new JMenu();
  JMenuItem appointMnu = new JMenuItem();
  JMenuItem registrationMnu = new JMenuItem();
  JMenuItem addSubjectMnu = new JMenuItem();
  JMenuItem changeMnu = new JMenuItem();
  JMenu jMenu3 = new JMenu();
  JMenuItem transcriptMnu = new JMenuItem();
  JMenu jMenu4 = new JMenu();
  JMenuItem gradeStudentMnu = new JMenuItem();
  JMenuItem gradeSubjectMnu = new JMenuItem();
  JMenu jMenu5 = new JMenu();
  JMenuItem jMenuItem18 = new JMenuItem();
  JMenuItem jMenuItem19 = new JMenuItem();
  JMenuItem jMenuItem20 = new JMenuItem();
  JMenuItem jMenuItem21 = new JMenuItem();
  JMenuItem jMenuItem22 = new JMenuItem();
  JMenuItem jMenuItem23 = new JMenuItem();
  JMenuItem jMenuItem24 = new JMenuItem();
  JMenuItem jMenuItem25 = new JMenuItem();
  JMenuItem jMenuItem26 = new JMenuItem();
  JMenuItem jMenuItem27 = new JMenuItem();
  JMenuItem jMenuItem28 = new JMenuItem();
  JMenuItem jMenuItem29 = new JMenuItem();
  JMenuItem jMenuItem30 = new JMenuItem();
  JMenuItem jMenuItem31 = new JMenuItem();
  JMenuItem jMenuHelpAbout = new JMenuItem();
  JMenu jMenuHelp = new JMenu();
  TitledBorder titledBorder1;
  JPanel content = new JPanel();
  JLabel statusBar = new JLabel();
  JMenuItem dropMnu = new JMenuItem();

  //Construct the frame
  public MainUI() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    image1 = new ImageIcon(graduate.MainUI.class.getResource("openFile.png"));
    image2 = new ImageIcon(graduate.MainUI.class.getResource("closeFile.png"));
    image3 = new ImageIcon(graduate.MainUI.class.getResource("help.png"));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    contentPane.setLayout(borderLayout1);
    this.setContentPane(contentPane);
    this.setDefaultCloseOperation(HIDE_ON_CLOSE);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setTitle("�к����ʹ�Ⱥѳ�Ե�Է�����");
    jMenuFile.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuFile.setText("������");
    jButton1.setIcon(image1);
    jButton1.setToolTipText("Open File");
    jButton2.setIcon(image2);
    jButton2.setToolTipText("Close File");
    jButton3.setIcon(image3);
    jButton3.setToolTipText("Help");
    generalMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    generalMnu.setText("�����ŷ����");
    generalMnu.addActionListener(new MainUI_generalMnu_actionAdapter(this));
    structureMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    structureMnu.setText("�ç���ҧ��ѡ�ٵ�");
    structureMnu.addActionListener(new MainUI_structureMnu_actionAdapter(this));
    studentMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentMnu.setText("�ѡ�֡��");
    studentMnu.addActionListener(new MainUI_studentMnu_actionAdapter(this));
    scholarshipMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    scholarshipMnu.setText("�ع����֡��");
    scholarshipMnu.addActionListener(new MainUI_scholarshipMnu_actionAdapter(this));
    etcMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    etcMnu.setText("��� �");
    etcMnu.addActionListener(new MainUI_etcMnu_actionAdapter(this));
    professorMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    professorMnu.setToolTipText("");
    professorMnu.setMnemonic('0');
    professorMnu.setText("�Ҩ����");
    professorMnu.addActionListener(new MainUI_professorMnu_actionAdapter(this));
    registrarMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    registrarMnu.setText("���˹�ҷ��");
    registrarMnu.addActionListener(new MainUI_registrarMnu_actionAdapter(this));
    jMenuFileExit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuFileExit.setToolTipText("");
    jMenuFileExit.setText("�͡�ҡ�����");
    jMenuFileExit.addActionListener(new MainUI_jMenuFileExit_actionAdapter(this));
    jMenu1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenu1.setText("��������");
    costMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    costMnu.setText("��Ҹ�����������֡��");
    costMnu.addActionListener(new MainUI_costMnu_actionAdapter(this));
    supportMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    supportMnu.setText("�ԹʹѺʹع/�Թ�ش˹ع����֡��");
    supportMnu.addActionListener(new MainUI_supportMnu_actionAdapter(this));
    jMenu2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenu2.setText("ŧ����¹");
    appointMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    appointMnu.setText("��˹�����");
    appointMnu.addActionListener(new MainUI_appointMnu_actionAdapter(this));
    registrationMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    registrationMnu.setText("ŧ����¹");
    registrationMnu.addActionListener(new MainUI_registrationMnu_actionAdapter(this));
    addSubjectMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    addSubjectMnu.setText("��������Ԫ�");
    addSubjectMnu.addActionListener(new MainUI_addSubjectMnu_actionAdapter(this));
    changeMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    changeMnu.setText("����¹����Ԫ�");
    changeMnu.addActionListener(new MainUI_changeMnu_actionAdapter(this));
    jMenu3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenu3.setText("�š�����¹");
    transcriptMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    transcriptMnu.setText("��ҹʤ�Ի��");
    transcriptMnu.addActionListener(new MainUI_transcriptMnu_actionAdapter(this));
    jMenu4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenu4.setText("��͡�ô");
    gradeStudentMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    gradeStudentMnu.setText("���ʹѡ�֡��");
    gradeStudentMnu.addActionListener(new MainUI_gradeStudentMnu_actionAdapter(this));
    gradeSubjectMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    gradeSubjectMnu.setText("����Ԫ�");
    gradeSubjectMnu.addActionListener(new MainUI_gradeSubjectMnu_actionAdapter(this));
    jMenu5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenu5.setText("��§ҹ");
    jMenuItem18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem18.setText("㺵�Ǩ�ͺ�ô");
    jMenuItem18.addActionListener(new MainUI_jMenuItem18_actionAdapter(this));
    jMenuItem19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem19.setText("�͹��ѵԼš�����¹");
    jMenuItem19.addActionListener(new MainUI_jMenuItem19_actionAdapter(this));
    jMenuItem20.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem20.setText("���§ҹ�š�����¹");
    jMenuItem20.addActionListener(new MainUI_jMenuItem20_actionAdapter(this));
    jMenuItem21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem21.setText("���ŧ����¹��Ш��ѹ");
    jMenuItem22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem22.setText("��ª��͹ѡ�֡�� (�Ѻ�����Թ)");
    jMenuItem23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem23.setText("��ª��͹ѡ�֡�� (���ŧ����¹)");
    jMenuItem24.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem24.setText("��ª��͹ѡ�֡�� (�������Թ)");
    jMenuItem25.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem25.setText("�ѡ�֡�� (�Ҩ�������֡��/�Ǻ����Է�ҹԾ���)");
    jMenuItem26.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem26.setText("��繪��� (����Ԫ�)");
    jMenuItem27.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem27.setText("㺻�͹��ṹ (����Ԫ�)");
    jMenuItem28.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem28.setText("㺻�͹��ṹ (�Է�ҹԾ���)");
    jMenuItem29.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem29.setText("��ػ�ӹǹ�Թ�ѡ�֡��ŧ����¹ (����Ԫ�)");
    jMenuItem30.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem30.setText("��ػ�ӹǹ�ѡ�֡�� (�Ҩ�������֡��)");
    jMenuItem31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuItem31.setText("��ػ�ӹǹ�ѡ�֡��ŧ����¹");
    jMenuHelpAbout.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuHelpAbout.setText("����ǡѺ�����");
    jMenuHelpAbout.addActionListener(new MainUI_jMenuHelpAbout_actionAdapter(this));
    jMenuHelp.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jMenuHelp.setText("���������");
    jMenuBar1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    contentPane.setBackground(SystemColor.control);
    statusBar.setText(" ");
    content.setBorder(BorderFactory.createEtchedBorder());
    dropMnu.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    dropMnu.setText("�͹����Ԫ�");
    dropMnu.addActionListener(new MainUI_dropMnu_actionAdapter(this));
    jToolBar.add(jButton1);
    jToolBar.add(jButton2);
    jToolBar.add(jButton3);
    jMenuFile.add(generalMnu);
    jMenuFile.add(structureMnu);
    jMenuFile.add(studentMnu);
    jMenuFile.add(scholarshipMnu);
    jMenuFile.add(etcMnu);
    jMenuFile.addSeparator();
    jMenuFile.add(professorMnu);
    jMenuFile.add(registrarMnu);
    jMenuFile.addSeparator();
    jMenuFile.add(jMenuFileExit);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenu1);
    jMenuBar1.add(jMenu2);
    jMenuBar1.add(jMenu3);
    jMenuBar1.add(jMenu5);
    jMenuBar1.add(jMenuHelp);
    this.setJMenuBar(jMenuBar1);
    contentPane.add(jToolBar, BorderLayout.NORTH);
    contentPane.add(content,  BorderLayout.CENTER);
    contentPane.add(statusBar,  BorderLayout.SOUTH);
    jMenu1.add(costMnu);
    jMenu1.add(supportMnu);
    jMenu2.add(appointMnu);
    jMenu2.add(registrationMnu);
    jMenu2.add(addSubjectMnu);
    jMenu2.add(changeMnu);
    jMenu2.add(dropMnu);
    jMenu3.add(jMenu4);
    jMenu3.add(transcriptMnu);
    jMenu4.add(gradeStudentMnu);
    jMenu4.add(gradeSubjectMnu);
    jMenu5.add(jMenuItem18);
    jMenu5.add(jMenuItem19);
    jMenu5.add(jMenuItem20);
    jMenu5.addSeparator();
    jMenu5.add(jMenuItem21);
    jMenu5.add(jMenuItem22);
    jMenu5.add(jMenuItem23);
    jMenu5.add(jMenuItem24);
    jMenu5.add(jMenuItem25);
    jMenu5.add(jMenuItem26);
    jMenu5.add(jMenuItem27);
    jMenu5.add(jMenuItem28);
    jMenu5.add(jMenuItem29);
    jMenu5.add(jMenuItem30);
    jMenu5.add(jMenuItem31);
    jMenuHelp.add(jMenuHelpAbout);
    jToolBar.setVisible(false);
    statusBar.setVisible(false);
  }
  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  //Help | About action performed
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }
  void showInternalFrame(String title,JPanel panel){
    JDialog dialog  = new JDialog(this,false);
    dialog.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    dialog.setTitle(title);
    dialog.getContentPane().add(panel);
    dialog.setBounds(0,0,760,550);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension dialogSize = dialog.getSize();
    if (dialogSize.height > screenSize.height) {
      dialogSize.height = screenSize.height;
    }
    if (dialogSize.width > screenSize.width) {
      dialogSize.width = screenSize.width;
    }
    dialog.setLocation((screenSize.width - dialogSize.width) / 2, (screenSize.height - dialogSize.height) / 2);
    dialog.show();

/*    JInternalFrame inframe = new JInternalFrame();
    inframe.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    inframe.setTitle(title);
    desktop.add(inframe);
    inframe.getContentPane().add(panel);
    inframe.setBounds(0,0,760,550);
    inframe.setIconifiable(false);
    inframe.setClosable(true);
    inframe.setResizable(false);
    inframe.show();*/
  }
  void jMenuHelpAbout_actionPerformed(ActionEvent e) {
//Help About MenuItem


  }
//General MenuItem
  void generalMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("�����ŷ����",new GeneralUI());
  }
//Student MenuItem
  void studentMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("�ѡ�֡��",new StudentUI());
  }
//etc MenuItem
  void etcMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("��� �",new EtcUI());
  }
//Professor MenuItem
  void professorMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("�Ҩ����",new ProfessorUI());
  }
//Registrar MenuItem
  void registrarMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("���˹�ҷ��",new RegistrarUI());
  }
//Cost MenuItem
  void costMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("��Ҹ�����������֡��",new CostUI());
  }
//Schedule MenuItem
  void appointMnu_actionPerformed(ActionEvent e) {
//    showInternalFrame("��˹�����",new ScheduleUI());
    boolean packFrame = false;
    SemesterUI frame = new SemesterUI(this,"�Ҥ����֡��/�ա���֡��",true);
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
//Registration MenuItem
  void registrationMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("ŧ����¹",new RegistrationAddUI());
  }
//Add subject MenuItem
  void addSubjectMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("��������Ԫ�",new RegistrationAddUI());
  }
//Change subject MenuItem
  void changeMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("����¹����Ԫ�",new RegistrationChangeUI());
  }
//Remove subject MenuItem
  void dropMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("�͹����Ԫ�",new RegistrationRemoveUI());
  }
//Grade - Student MenuItem
  void gradeStudentMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("����ô�ѡ�֡��",new GradeStudentUI());
  }
//Grade - Subject MenuItem
  void gradeSubjectMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("����ô�ѡ�֡�� - ����Ԫ�",new GradeRecordUI());
  }
//Transcript MenuItem
  void transcriptMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("��ҹʤ�Ի��",new TranscriptUI());
  }

  void scholarshipMnu_actionPerformed(ActionEvent e) {
    showInternalFrame("�ع����֡��",new ScholarshipUI());
  }

  void structureMnu_actionPerformed(ActionEvent e) {
//    showInternalFrame("test",new SubjectMainUI());
    boolean packFrame = false;
    CourseMainUI frame = new CourseMainUI();
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  void jMenuItem18_actionPerformed(ActionEvent e) {
//    showInternalFrame("test",new SectionUI());
    boolean packFrame = false;
    LoginUI frame = new LoginUI(this,"ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ",true);
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  void jMenuItem19_actionPerformed(ActionEvent e) {
    showInternalFrame("test",new StudentUI());
  }

  void jMenuItem20_actionPerformed(ActionEvent e) {
    boolean packFrame = false;
    CourseUI frame = new CourseUI();
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }


  void supportMnu_actionPerformed(ActionEvent e) {
    boolean packFrame = false;
    SupportUI frame = new SupportUI(this,"�Թ�ش˹ع����/�Թ��������֡��",true);
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
}

class MainUI_jMenuFileExit_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_jMenuFileExit_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuFileExit_actionPerformed(e);
  }
}

class MainUI_jMenuHelpAbout_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_jMenuHelpAbout_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuHelpAbout_actionPerformed(e);
  }
}

class MainUI_generalMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_generalMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.generalMnu_actionPerformed(e);
  }
}

class MainUI_studentMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_studentMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.studentMnu_actionPerformed(e);
  }
}

class MainUI_etcMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_etcMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.etcMnu_actionPerformed(e);
  }
}

class MainUI_professorMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_professorMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.professorMnu_actionPerformed(e);
  }
}

class MainUI_registrarMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_registrarMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.registrarMnu_actionPerformed(e);
  }
}

class MainUI_costMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_costMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.costMnu_actionPerformed(e);
  }
}

class MainUI_appointMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_appointMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.appointMnu_actionPerformed(e);
  }
}

class MainUI_registrationMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_registrationMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.registrationMnu_actionPerformed(e);
  }
}

class MainUI_addSubjectMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_addSubjectMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.addSubjectMnu_actionPerformed(e);
  }
}

class MainUI_changeMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_changeMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.changeMnu_actionPerformed(e);
  }
}

class MainUI_dropMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_dropMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.dropMnu_actionPerformed(e);
  }
}

class MainUI_gradeStudentMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_gradeStudentMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.gradeStudentMnu_actionPerformed(e);
  }
}

class MainUI_gradeSubjectMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_gradeSubjectMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.gradeSubjectMnu_actionPerformed(e);
  }
}

class MainUI_transcriptMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_transcriptMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.transcriptMnu_actionPerformed(e);
  }
}

class MainUI_scholarshipMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_scholarshipMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.scholarshipMnu_actionPerformed(e);
  }
}

class MainUI_structureMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_structureMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.structureMnu_actionPerformed(e);
  }
}

class MainUI_jMenuItem18_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_jMenuItem18_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem18_actionPerformed(e);
  }
}

class MainUI_jMenuItem19_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_jMenuItem19_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem19_actionPerformed(e);
  }
}

class MainUI_jMenuItem20_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_jMenuItem20_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem20_actionPerformed(e);
  }
}

class MainUI_supportMnu_actionAdapter implements java.awt.event.ActionListener {
  MainUI adaptee;

  MainUI_supportMnu_actionAdapter(MainUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.supportMnu_actionPerformed(e);
  }
}