package graduate;

import java.util.*;
public class ThesisProfessor {
  private Professor professor;
  private Thesis thesis;
  private boolean control;
  private ThesisProfessorDB tpDB = new ThesisProfessorDB();
  //Constructor
  public ThesisProfessor() {
  }
  //getMethod
  public Professor getProfessor(){
    return this.professor;
  }
  public Thesis getThesis(){
    return this.thesis;
  }
  public boolean getControl(){
    return this.control;
  }
  //setMethod
  public void setProfessor(Professor professor){
    this.professor = professor;
  }
  public void setThesis(Thesis thesis){
    this.thesis = thesis;
  }
  public void setControl(boolean control){
    this.control = control;
  }
  public Vector retrieveThesisProfessor(Thesis thesis){
    Vector v = tpDB.retrieveThesisProfessor(thesis);
    thesis.setThesisProfessor(v);
    return  v;
  }
  public boolean insertThesisProfessor(ThesisProfessor tp){
    return tpDB.insertThesisProfessor(tp);
  }
  public boolean updateThesisProfessor(ThesisProfessor old,ThesisProfessor nw){
    return tpDB.updateThesisProfessor(old,nw);
  }
  public boolean deleteThesisProfessor(ThesisProfessor tp){
    return tpDB.deleteThesisProfessor(tp);
  }
}