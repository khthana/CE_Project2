package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class ScheduleUI extends JFrame {
  String[] date = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
  "21","22","23","24","25","26","27","28","29","30","31"};
  String[] month = {"���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�",
  "��Ȩԡ�¹","�ѹ�Ҥ�"};
  BorderLayout borderLayout1 = new BorderLayout();
  BoxLayout2 boxLayout24 = new BoxLayout2();
  JScrollPane jScrollPane2 = new JScrollPane();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel13 = new JPanel();
  BorderLayout borderLayout6 = new BorderLayout();
  JSplitPane jSplitPane2 = new JSplitPane();
  JPanel jPanel14 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel16 = new JPanel();
  BorderLayout borderLayout9 = new BorderLayout();
  BorderLayout borderLayout10 = new BorderLayout();
  BoxLayout2 boxLayout25 = new BoxLayout2();
  JButton saveButton1 = new JButton();
  JPanel jPanel17 = new JPanel();
  JButton clearButton1 = new JButton();
  JPanel jPanel18 = new JPanel();
  JPanel jPanel19 = new JPanel();
  BorderLayout borderLayout11 = new BorderLayout();
  BoxLayout2 boxLayout26 = new BoxLayout2();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("���ҧ��˹�����");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JPanel switchPanel1 = new JPanel();
  Border border1;
  Border border2;
  Border border3;
  Border border4;
  TitledBorder titledBorder1;
  Border border5;
  JLabel jLabel1 = new JLabel();
  JComboBox finishMonthCombo = new JComboBox(month);
  JComboBox finishDateCombo = new JComboBox(date);
  JTextField finishBeText = new JTextField();
  JComboBox startMonthCombo = new JComboBox(month);
  JLabel jLabel2 = new JLabel();
  JComboBox startDateCombo = new JComboBox(date);
  JTextField startBeText = new JTextField();
  JTree jTree1 = new JTree(treeModel);
  //----------------------------------------------------------------------------------------------------------------------------------------------------------
  Semester semester = new Semester();
  Appointment currentApp = new Appointment();
  Vector appointmentVector = new Vector();
  boolean newRecord = false;
  boolean canAdd = false;
  int currentRegisterType = 0;

  public ScheduleUI() {
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ScheduleUI(int term,int year) {
    try {
      retrieveAppointment(term,year);
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    border3 = BorderFactory.createEmptyBorder(5,5,5,5);
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder1 = new TitledBorder(border4,"���ҧ����");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border5 = BorderFactory.createCompoundBorder(titledBorder1,BorderFactory.createEmptyBorder(5,5,5,5));
    jScrollPane2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane2.setPreferredSize(new Dimension(240, 440));
    boxLayout24.setAxis(BoxLayout.Y_AXIS);
    this.getContentPane().setLayout(borderLayout1);
    jPanel11.setPreferredSize(new Dimension(400, 50));
    jPanel11.setLayout(boxLayout25);
    jPanel12.setLayout(borderLayout10);
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel12.setBorder(border2);
    jPanel12.setPreferredSize(new Dimension(220, 450));
    jPanel12.setRequestFocusEnabled(true);
    jPanel13.setLayout(flowLayout2);
    jPanel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel14.setBorder(border5);
    jPanel14.setMaximumSize(new Dimension(32767, 32767));
    jPanel14.setPreferredSize(new Dimension(400, 150));
    jPanel14.setLayout(boxLayout26);
    jPanel16.setLayout(borderLayout6);
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel16.setPreferredSize(new Dimension(400, 150));
    boxLayout25.setAxis(BoxLayout.Y_AXIS);
    saveButton1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton1.setMaximumSize(new Dimension(100, 25));
    saveButton1.setPreferredSize(new Dimension(80, 25));
    saveButton1.setText("�ѹ�֡");
    saveButton1.addActionListener(new ScheduleUI_saveButton1_actionAdapter(this));
    jPanel17.setLayout(borderLayout11);
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel17.setMinimumSize(new Dimension(141, 35));
    jPanel17.setPreferredSize(new Dimension(400, 100));
    clearButton1.setText("������");
    clearButton1.addActionListener(new ScheduleUI_clearButton1_actionAdapter(this));
    clearButton1.setPreferredSize(new Dimension(80, 25));
    clearButton1.setMaximumSize(new Dimension(100, 25));
    clearButton1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel18.setLayout(borderLayout9);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel18.setBorder(border1);
    jPanel19.setLayout(null);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel19.setDebugGraphicsOptions(0);
    jPanel19.setDoubleBuffered(true);
    jPanel19.setMinimumSize(new Dimension(78, 20));
    jPanel19.setOpaque(true);
    jPanel19.setPreferredSize(new Dimension(400, 22));
    boxLayout26.setAxis(BoxLayout.Y_AXIS);
    switchPanel1.setLayout(boxLayout24);
    switchPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    switchPanel1.setBorder(border3);
    switchPanel1.setPreferredSize(new Dimension(400, 460));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("�ѹ�������");
    jLabel1.setBounds(new Rectangle(10, 8, 43, 15));
    finishDateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finishDateCombo.setPreferredSize(new Dimension(50, 21));
    finishDateCombo.setPopupVisible(false);
    finishDateCombo.setBounds(new Rectangle(85, 34, 50, 21));
    finishMonthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finishMonthCombo.setPreferredSize(new Dimension(150, 21));
    finishMonthCombo.setBounds(new Rectangle(145, 34, 150, 21));
    finishBeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    finishBeText.setMinimumSize(new Dimension(6, 21));
    finishBeText.setPreferredSize(new Dimension(80, 21));
    finishBeText.setText("");
    finishBeText.setBounds(new Rectangle(305, 34, 80, 21));
    flowLayout2.setAlignment(FlowLayout.CENTER);
    startMonthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    startMonthCombo.setPreferredSize(new Dimension(150, 21));
    startMonthCombo.setBounds(new Rectangle(145, 5, 150, 21));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("�ѹ����ش");
    jLabel2.setBounds(new Rectangle(10, 37, 41, 15));
    startDateCombo.setPopupVisible(false);
    startDateCombo.setBounds(new Rectangle(85, 5, 50, 21));
    startDateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    startDateCombo.setPreferredSize(new Dimension(50, 21));
    startBeText.setText("");
    startBeText.setBounds(new Rectangle(305, 5, 80, 21));
    startBeText.setPreferredSize(new Dimension(80, 21));
    startBeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    startBeText.setMinimumSize(new Dimension(6, 21));
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTree1.setMaximumSize(new Dimension(230, 200));
    jTree1.setMinimumSize(new Dimension(0, 0));
    jTree1.setPreferredSize(new Dimension(0, 0));
    jPanel11.add(jPanel19, null);
    jPanel19.add(jLabel1, null);
    jPanel19.add(jLabel2, null);
    jPanel19.add(finishBeText, null);
    jPanel19.add(startDateCombo, null);
    jPanel19.add(startMonthCombo, null);
    jPanel19.add(startBeText, null);
    jPanel19.add(finishDateCombo, null);
    jPanel19.add(finishMonthCombo, null);
    jPanel16.add(jPanel17,  BorderLayout.SOUTH);
    jPanel17.add(jPanel13, BorderLayout.NORTH);
    jPanel16.add(jPanel11,  BorderLayout.CENTER);
    jPanel13.add(saveButton1, null);
    jPanel13.add(clearButton1, null);
    jSplitPane2.add(jPanel12, JSplitPane.LEFT);
    jSplitPane2.add(switchPanel1, JSplitPane.RIGHT);
    switchPanel1.add(jPanel14, null);
    jPanel14.add(jPanel16, null);
    jPanel12.add(jScrollPane2, BorderLayout.CENTER);
    jScrollPane2.getViewport().add(jTree1, null);
    this.getContentPane().add(jPanel18, BorderLayout.NORTH);
    jPanel18.add(jSplitPane2, BorderLayout.CENTER);
    this.setSize(new Dimension(600,500));
    this.setTitle("���ҧ��˹�����");
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTree1.addTreeSelectionListener(new TreeSelectionListener());
    createTree();
    clear();
  }

  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String) {
        String str = (String)nodeInfo;
        if (str.equals("���ҧ��˹�����")) currentRegisterType = 0;
        else if (str.equals("ŧ����¹��ǧ˹��")) currentRegisterType =1;
        else if (str.equals("ŧ����¹����")) currentRegisterType = 2;
        else if (str.equals("��Ҫ�� 1 �ѻ����")) currentRegisterType =3;
        else if (str.equals("��Ҫ�� 2 �ѻ����")) currentRegisterType =4;
        else if (str.equals("ŧ����¹�Ҿѡ")) currentRegisterType =5;
        else if (str.equals("ŧ����¹�ѡ����Ҿ")) currentRegisterType =6;
        else if (str.equals("��������Ԫ�")) currentRegisterType =7;
        else if (str.equals("����¹����Ԫ�")) currentRegisterType =8;
        else if (str.equals("�͹����Ԫ�")) currentRegisterType =9;

        if (currentRegisterType != 0) showUI();
      }
    }
  }
  public void showUI(){
    Enumeration e = appointmentVector.elements();
    while (e.hasMoreElements()){
      Appointment app = (Appointment)e.nextElement();
      if (app.getRegisterType().getRegisterTypeID() == currentRegisterType) {
        int day = app.getFromDate().getDate();
        int month = app.getFromDate().getMonth();
        int year = app.getFromDate().getYear()+1900+543;
        startDateCombo.setSelectedIndex(day-1);
        startMonthCombo.setSelectedIndex(month);
        startBeText.setText(Integer.toString(year));

        day = app.getToDate().getDate();
        month = app.getToDate().getMonth();
        year = app.getToDate().getYear()+1900+543;
        finishDateCombo.setSelectedIndex(day-1);
        finishMonthCombo.setSelectedIndex(month);
        finishBeText.setText(Integer.toString(year));
        newRecord = false;
        currentApp = app;
        return;
      }
    }
    newRecord = true;
    clear();
  }

  public void clear(){
    startDateCombo.setSelectedItem(null);
    startMonthCombo.setSelectedItem(null);
    startBeText.setText("");
    finishDateCombo.setSelectedItem(null);
    finishMonthCombo.setSelectedItem(null);
    finishBeText.setText("");
  }

  public void retrieveAppointment(int sem,int year){
    Database.connect();
    boolean complete = false;
    semester.setSemester(sem);
    semester.setYear(year);
    semester = semester.retrieveSemester(semester);

    if (semester == null) {
      semester = new Semester();
      semester.setSemester(sem);
      semester.setYear(year);
      semester.setSemesterType((year==1 || year == 2)?1:0);
      semester.setCurrentSemester(true);
      complete = semester.insertSemester(semester);
    }
    else {
      semester.setCurrentSemester(true);
      complete = semester.updateSemester(semester);
    }
    semester = semester.retrieveCurrentSemester();

    Appointment appointment = new Appointment();
    appointmentVector = appointment.retrieveAppointment(semester);
    Database.disconnect();

  }
  public void createTree() {
      DefaultMutableTreeNode dateNode = null ;
      String[] deg ={"ŧ����¹��ǧ˹��","ŧ����¹����","��Ҫ�� 1 �ѻ����","��Ҫ�� 2 �ѻ����","ŧ����¹�Ҿѡ","ŧ����¹�ѡ����Ҿ"
          ,"��������Ԫ�","����¹����Ԫ�","�͹����Ԫ�"};

      for(int i=0; i<deg.length; i++){
       dateNode = new DefaultMutableTreeNode(deg[i]);
       root.add(dateNode);
     }
     jTree1.expandRow(0);
  }

  void clearButton1_actionPerformed(ActionEvent e) {
    clear();
  }

  void saveButton1_actionPerformed(ActionEvent e) {
    boolean complete = false;
    int syear = 0;
    int fyear = 0;
    try{
      syear = Integer.parseInt(startBeText.getText());
      fyear = Integer.parseInt(finishBeText.getText());
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ա���֡���繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (startDateCombo.getSelectedItem() == null || startMonthCombo.getSelectedItem() == null ||
        finishDateCombo.getSelectedItem() == null || finishMonthCombo.getSelectedItem() == null){
      JOptionPane.showMessageDialog(this, "��س������������ú��ǹ",
                                    "��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);
      return;
    }
    Appointment app = new Appointment();
    app.setSemester(this.semester);
    app.setRegisterType(new RegisterType(currentRegisterType));
    int date = startDateCombo.getSelectedIndex() + 1;
    int month = startMonthCombo.getSelectedIndex();
    int year = Integer.parseInt(startBeText.getText());
    GregorianCalendar g = new GregorianCalendar(year,month,date);
    java.util.Date d = g.getTime();
    app.setFromDate(d);

    date = finishDateCombo.getSelectedIndex() + 1;
    month = finishMonthCombo.getSelectedIndex();
    year = Integer.parseInt(finishBeText.getText());
    g = new GregorianCalendar(year,month,date);
    d = g.getTime();
    app.setToDate(d);

    Database.connect();
    if (newRecord){
      complete = app.insertAppointment(app);
    }
    else {
      complete = app.updateAppointment(currentApp,app);
      appointmentVector.remove(currentApp);
    }
    appointmentVector.addElement(app);
    Database.disconnect();
  }
}

class ScheduleUI_clearButton1_actionAdapter implements java.awt.event.ActionListener {
  ScheduleUI adaptee;

  ScheduleUI_clearButton1_actionAdapter(ScheduleUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton1_actionPerformed(e);
  }
}

class ScheduleUI_saveButton1_actionAdapter implements java.awt.event.ActionListener {
  ScheduleUI adaptee;

  ScheduleUI_saveButton1_actionAdapter(ScheduleUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton1_actionPerformed(e);
  }
}