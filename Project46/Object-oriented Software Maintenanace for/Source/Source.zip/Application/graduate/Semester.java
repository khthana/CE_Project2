package graduate;

import java.util.*;

public class Semester {
  private long semeterID;
  private int  year;
  private int semester;
  private int semesterType;
  private boolean currentSemester;
  private SemesterDB semesterDB = new SemesterDB();
  //Constructor
  public Semester() {
  }
  public Semester(long id){
    this.setSemesterID(id);
  }
  //getMethod
  public long getSemesterID(){
    return  this.semeterID;
  }
  public int getYear(){
    return this.year;
  }
  public int getSemester(){
    return this.semester;
  }
  public int getSemesterType(){
    return this.semesterType;
  }
  public boolean getCurrentSemester(){
    return this.currentSemester;
  }
  //setMethod
  public void setSemesterID(long semesterid){
    this.semeterID = semesterid;
  }
  public void setYear(int y){
    this.year = y;
  }
  public void setSemester(int s){
    this.semester = s;
  }
  public void setSemesterType(int st){
    this.semesterType = st;
  }
  public void setCurrentSemester(boolean cs){
    this.currentSemester = cs;
  }
  //Business Method
  public Semester retrieveCurrentSemester(){
    Vector semVector = semesterDB.retrieveCurrentSemester();
    Enumeration e = semVector.elements();
    if (!e.hasMoreElements()) return null;
    Semester sem = (Semester)e.nextElement();
    return sem;
  }
  public Semester retrieveSemester(long sid){
    return semesterDB.retrieveSemester(sid);
  }
  public Semester retrieveSemester(Semester semester){
   return semesterDB.retrieveSemester(semester);
  }
  public boolean insertSemester(Semester s){
    return semesterDB.insertSemester(s);
  }
  public boolean updateSemester(Semester s){
    return semesterDB.updateSemester(s);
  }
  public boolean deleteSemester(Semester s){
    return semesterDB.deleteSemester(s);
  }
}