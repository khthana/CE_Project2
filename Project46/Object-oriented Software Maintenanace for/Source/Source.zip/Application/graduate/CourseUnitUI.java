package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.awt.event.*;

public class CourseUnitUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  BorderLayout borderLayout3 = new BorderLayout();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel1 = new JLabel();
  Border border1;
  Border border2;
  TitledBorder titledBorder1;
  JTextField totalUnitText = new JTextField();
  JPanel jPanel4 = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  JPanel jPanel5 = new JPanel();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  BorderLayout borderLayout4 = new BorderLayout();
//-----------------------------------------------------------------------------------------------------------------------------------------------------------
  CourseUI courseUI;
  Major major;
  int degree;
  boolean newRecord = false;
  Vector courseStructureVector = new Vector();
  Vector courseUnitVector = new Vector();
  Vector groupVector = new Vector();

  public CourseUnitUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�ç���ҧ��ѡ�ٵ�");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(borderLayout3);
    jPanel3.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setMaximumSize(new Dimension(80, 15));
    jLabel1.setPreferredSize(new Dimension(80, 15));
    jLabel1.setText("˹��¡Ե���");
    jLabel1.setBounds(new Rectangle(8, 2, 71, 23));
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(border1);
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder1);
    totalUnitText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    totalUnitText.setToolTipText("");
    totalUnitText.setText("");
    totalUnitText.setBounds(new Rectangle(91, 2, 114, 23));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setMinimumSize(new Dimension(1, 1));
    jPanel3.setPreferredSize(new Dimension(300, 40));
    jPanel4.setLayout(borderLayout4);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    saveButton.setMaximumSize(new Dimension(80, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new CourseUnitUI_saveButton_actionAdapter(this));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    clearButton.setMaximumSize(new Dimension(80, 25));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setText("������");
    clearButton.addActionListener(new CourseUnitUI_clearButton_actionAdapter(this));
    jPanel5.setLayout(flowLayout1);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setPreferredSize(new Dimension(476, 400));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    flowLayout1.setAlignment(FlowLayout.CENTER);
    jTable1.setRowHeight(20);
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(jPanel3, BorderLayout.NORTH);
    jPanel3.add(totalUnitText, null);
    jPanel3.add(jLabel1, null);
    jPanel2.add(jPanel4,  BorderLayout.CENTER);
    jPanel4.add(jScrollPane1, BorderLayout.CENTER);
    jPanel2.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(saveButton, null);
    jPanel5.add(clearButton, null);
    jScrollPane1.getViewport().add(jTable1, null);
    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setRowSelectionAllowed(true);
    jTable1.getTableHeader().setReorderingAllowed(false);
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
        , {null, null}
    }
        ,
        new String[] {
        "��Ǵ�Ԫ�", "˹��¡Ե"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean[] {
          false, true
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setColumnSelectionAllowed(false);
    jTable1.getColumn("��Ǵ�Ԫ�").setPreferredWidth(300);
    jTable1.setCellSelectionEnabled(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(0, 0));
    jTable1.setMaximumSize(new Dimension(0, 0));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY( (float) 0.5);
    jTable1.setAlignmentX( (float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);
  }

  public void initial(){
    CourseStructure cs = new CourseStructure();
    CourseUnit cu = new CourseUnit();
    Group group = new Group();
    Database.connect();
    courseStructureVector = cs.retrieveCourseStructureAll(this.major);
    courseUnitVector = cu.retrieveCourseUnit(this.major);
    groupVector = group.retrieveGroup();
    Database.disconnect();
  }
  public void fillGroup(){
    int i = 0;
    Enumeration e = groupVector.elements();
    while (e.hasMoreElements()){
      Group g = (Group)e.nextElement();
      jTable1.getModel().setValueAt(g,i,0);
      jTable1.getModel().setValueAt(new Integer(0),i++,1);
    }
  }
  public void clearTable(){
    for (int i=0;i<jTable1.getRowCount();i++)
      for (int j=0;j<jTable1.getColumnCount();j++)
        jTable1.getModel().setValueAt(null,i,j);
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void showUI(int degree){
    this.degree = degree;
    Enumeration csEnum = courseStructureVector.elements();
    CourseStructure cs = new CourseStructure();
    boolean out = false;
    while (csEnum.hasMoreElements() && !out){
      cs = (CourseStructure)csEnum.nextElement();
      if (cs.getDegree().getDegreeID() == degree)
        out = true;
    }
    if (out) {
      totalUnitText.setText(Integer.toString(cs.getTotalUnit()));
    }
    else{
      totalUnitText.setText("0");
    }

    out = false;
    Enumeration cuEnum = courseUnitVector.elements();
    while (cuEnum.hasMoreElements() && !out){
      CourseUnit cu = (CourseUnit)cuEnum.nextElement();
        if (cu.getDegree().getDegreeID() == degree) out = true;
    }
    clearTable();
    if (!out){
      fillGroup();
    }
    else {
      int i = 0;
      cuEnum = courseUnitVector.elements();
      while (cuEnum.hasMoreElements()){
        CourseUnit cu = (CourseUnit)cuEnum.nextElement();
        if (cu.getDegree().getDegreeID() == degree){
          jTable1.getModel().setValueAt(cu.getGroup(),i,0);
          jTable1.getModel().setValueAt(new Integer(cu.getGroupUnit()),i++,1);
        }
      }
    }
  }

  void clearButton_actionPerformed(ActionEvent e) {
    totalUnitText.setText("");
    fillGroup();
  }

  void saveButton_actionPerformed(ActionEvent e) {
    Database.connect();
    //-------------------------------------------------------------------------CourseStructure Save----------------------------------------------------
    Enumeration csEnum = courseStructureVector.elements();
    CourseStructure cs = new CourseStructure();
    boolean out = false;
    while (csEnum.hasMoreElements() && !out){
      cs = (CourseStructure)csEnum.nextElement();
      if (cs.getDegree().getDegreeID() == degree)
        out = true;
    }
    if (out) {
      cs.setTotalUnit(Integer.parseInt(totalUnitText.getText()));
      cs.updateCourseStructure(cs);
    }
    else{
      CourseStructure cssave = new CourseStructure();
      cssave.setDegree(new Degree(this.degree));
      cssave.setMajor(this.major);
      cssave.setTotalUnit(Integer.parseInt(totalUnitText.getText()));
      cssave.insertCourseStructure(cssave);
    }
    //------------------------------------------------------------------------CourseUnit Save-----------------------------------------------------------
    CourseUnit cu = new CourseUnit();
    cu.setDegree(new Degree(this.degree));
    cu.setMajor(this.major);
    cu.deleteCourseUnit(cu);
    for(int i=0;i<jTable1.getRowCount();i++){
      Group g = (Group)jTable1.getModel().getValueAt(i,0);
      if (g==null) break;
      String unit = jTable1.getModel().getValueAt(i,1).toString();
      cu = new CourseUnit();
      cu.setDegree(new Degree(this.degree));
      cu.setGroup(g);
      int u = Integer.parseInt(unit);
      cu.setGroupUnit(u);
      cu.setMajor(this.major);
      cu.insertCourseUnit(cu);
    }
    Database.disconnect();
  }
}

class CourseUnitUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  CourseUnitUI adaptee;

  CourseUnitUI_clearButton_actionAdapter(CourseUnitUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class CourseUnitUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  CourseUnitUI adaptee;

  CourseUnitUI_saveButton_actionAdapter(CourseUnitUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}