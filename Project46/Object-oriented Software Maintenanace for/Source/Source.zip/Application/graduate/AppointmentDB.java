package graduate;

import java.sql.*;
import java.util.*;
import java.text.*;
public class AppointmentDB {
  public AppointmentDB() {
  }
  public Vector retrieveAppointmentAll(Semester semester){
    Vector v = new Vector();
    try
    {
        String query = "SELECT a.*,s.*,r.* FROM Appointment a,Semester s,RegisterType r ";
        query += "WHERE a.SemesterID = s.SemesterID AND ";
        query += "r.RegisterTypeID = a.RegisterTypeID AND a.SemesterID = " + semester.getSemesterID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Appointment app = new Appointment();
          app.setFromDate(rs.getDate("FromDate"));
          app.setToDate(rs.getDate("ToDate"));
          RegisterType r = new RegisterType();
          r.setRegisterTypeID(rs.getLong("RegisterTypeID"));
          r.setRegisterTypeName(rs.getString("RegisterType"));
          app.setSemester(semester);
          app.setRegisterType(r);
          v.addElement(app);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Appointment retrieveAppointment(Semester semester,RegisterType regis){
    try
    {
        String query = "SELECT a.*,s.*,r.* FROM Appointment a,Semester s,RegisterType r ";
        query += "WHERE a.SemesterID = s.SemesterID AND ";
        query += "r.RegisterTypeID = a.RegisterTypeID AND a.SemesterID = " + semester.getSemesterID();
        query += " AND a.RegisterTypeID = " + regis.getRegisterTypeID();
        ResultSet rs = Database.getResultSet(query);

        Appointment app = new Appointment();
        while(rs.next()){
          app.setFromDate(rs.getDate("FromDate"));
          app.setToDate(rs.getDate("ToDate"));
          RegisterType r = new RegisterType();
          r.setRegisterTypeID(rs.getLong("RegisterTypeID"));
          r.setRegisterTypeName(rs.getString("RegisterType"));
          app.setSemester(semester);
          app.setRegisterType(r);
          return app;
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return null;
  }
  public boolean insertAppointment(Appointment appointment){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "INSERT INTO Appointment(RegisterTypeID,SemesterID,FromDate,ToDate) ";
    query +=  "VALUES("+ appointment.getRegisterType().getRegisterTypeID() + "," + appointment.getSemester().getSemesterID();
    query +=  ", '" + formatter.format(appointment.getFromDate()) + "','" + formatter.format(appointment.getToDate()) + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateAppointment(Appointment oldAppoint,Appointment newAppoint){
    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    String query = "UPDATE Appointment SET ";
    query += "RegisterTypeID = " + newAppoint.getRegisterType().getRegisterTypeID() + ", ";
    query += "SemesterID = " + newAppoint.getSemester().getSemesterID() + ", ";
    query += "FromDate = '" + formatter.format(newAppoint.getFromDate()) + "', ";
    query += "ToDate = '" + formatter.format(newAppoint.getToDate()) + "' ";
    query += "WHERE RegisterTypeID = " + oldAppoint.getRegisterType().getRegisterTypeID() + " AND ";
    query += "SemesterID = " + oldAppoint.getSemester().getSemesterID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteAppointment(Appointment appointment){
    String query = "DELETE FROM Appointment ";
    query += "WHERE RegisterTypeID = " + appointment.getRegisterType().getRegisterTypeID() + " AND ";
    query += "SemesterID = " + appointment.getSemester().getSemesterID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    AppointmentDB db = new AppointmentDB();
    Appointment a = new Appointment();
    a.setRegisterType(new RegisterType(1));
    a.setSemester(new Semester(2));
    Appointment aa = new Appointment();
    aa.setRegisterType(new RegisterType(1));
    aa.setSemester(new Semester(3));

//    a.updateAppointment(a,aa);
    Vector v = db.retrieveAppointmentAll(new Semester(1));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Appointment m = (Appointment)e.nextElement();
      System.out.println(m.getRegisterType().getRegisterTypeName() + m.getSemester().getSemesterID());
    }
    Database.disconnect();
  }

}