package graduate;

import java.util.*;
public class Thesis {
  private long thesisID;
  private String thesisEname;
  private String thesisTname;
  private Date startDate;
  private Date finishDate;
  private Student student;
  private Vector thesisProfVector = new Vector();
  private ThesisDB thesisDB = new ThesisDB();
  //Constructor
  public Thesis() {
  }
  public Thesis(long id){
    this.setThesisID(id);
  }
  //getMethod
  public long getThesisID(){
    return this.thesisID;
  }
  public String getThesisEname(){
    return this.thesisEname;
  }
  public String getThesisTname(){
    return this.thesisTname;
  }
  public Date getStartDate(){
    return this.startDate;
  }
  public Date getFinishDate(){
    return this.finishDate;
  }
  public Student getStudent(){
    return this.student;
  }
  //setMethod
  public void setThesisID(long id){
    this.thesisID = id;
  }
  public void setThesisEname(String ename){
    this.thesisEname = ename;
  }
  public void setThesisTname(String tname){
    this.thesisTname = tname;
  }
  public void setStartDate(Date s){
    this.startDate = s;
  }
  public void setFinishDate(Date f){
    this.finishDate = f;
  }
  public void setStudent(Student student){
    this.student = student;
  }
  //Business Method
  public void addThesisProfessor(ThesisProfessor tp){
    thesisProfVector.addElement(tp);
  }
  public void setThesisProfessor(Vector tp){
    thesisProfVector = tp;
  }
  public Enumeration retrieveThesisProfessor(){
    return thesisProfVector.elements();
  }
  public Thesis retrieveThesis(Student student){
    return thesisDB.retrieveThesis(student);
  }
  public Thesis retrieveThesis(Student student,long thesisID){
     return thesisDB.retrieveThesis(student,thesisID);
   }
  public boolean insertThesis(Thesis thesis){
    return thesisDB.insertThesis(thesis);
  }
  public boolean updateThesis(Thesis thesis){
    return thesisDB.updateThesis(thesis);
  }
  public boolean deleteThesis(Thesis thesis){
    return thesisDB.deleteThesis(thesis);
  }
}