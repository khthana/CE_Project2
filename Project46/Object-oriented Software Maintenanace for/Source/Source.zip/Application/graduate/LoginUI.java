package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.border.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class LoginUI extends JDialog {
  CompoundBorder titledBorder2;
  TitledBorder titledBorder1;
  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel4 = new JPanel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  Border border1;
  JPanel jPanel5 = new JPanel();
  JLabel jLabel2 = new JLabel();
  JTextField idText = new JTextField();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel2 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel3 = new JPanel();
  JPasswordField passText = new JPasswordField();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();

  public LoginUI(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public LoginUI() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(null, "��سҷӡ����͡�Թ�����������к�",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder1,new EmptyBorder(5,5,5,5));
    border1 = BorderFactory.createEmptyBorder(10,10,10,10);
    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("¡��ԡ");
    jButton1.addActionListener(new LoginUI_jButton1_actionAdapter(this));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("��ŧ");
    jButton2.addActionListener(new LoginUI_jButton2_actionAdapter(this));
    panel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    panel1.setBorder(border1);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder2);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setMaximumSize(new Dimension(60, 15));
    jLabel2.setPreferredSize(new Dimension(60, 15));
    jLabel2.setText("���ʼ�ҹ");
    idText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    idText.setPreferredSize(new Dimension(150, 25));
    idText.setText("");
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setMaximumSize(new Dimension(60, 15));
    jLabel1.setPreferredSize(new Dimension(60, 15));
    jLabel1.setText("���ͼ����");
    jPanel2.setLayout(flowLayout1);
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setMaximumSize(new Dimension(60, 15));
    jPanel2.setPreferredSize(new Dimension(60, 31));
    jPanel3.setLayout(flowLayout2);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setLayout(verticalFlowLayout1);
    flowLayout2.setAlignment(FlowLayout.CENTER);
    flowLayout1.setAlignment(FlowLayout.CENTER);
    passText.setPreferredSize(new Dimension(150, 25));
    verticalFlowLayout1.setAlignment(VerticalFlowLayout.MIDDLE);
    getContentPane().add(panel1);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    jPanel4.add(jButton2, null);
    jPanel4.add(jButton1, null);
    jPanel1.add(jPanel5,  BorderLayout.CENTER);
    jPanel2.add(jLabel2, null);
    jPanel2.add(passText, null);
    jPanel5.add(jPanel3, null);
    jPanel3.add(jLabel1, null);
    jPanel3.add(idText, null);
    jPanel5.add(jPanel2, null);
    this.setSize(new Dimension(450, 250));
  }

  void jButton1_actionPerformed(ActionEvent e) {
    System.exit(0);
//    dispose();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    String id = idText.getText();
    String pw = new String(passText.getPassword());
    Database.connect();
    Registrar r = new Registrar();
    r.setRegistrarID(id);
    r.setPassword(pw);
    boolean valid = r.validate(r);
    Database.disconnect();
    if (!valid){
      JOptionPane.showMessageDialog(this,"username ���� password �Դ��سҡ�͡����","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    dispose();
  }
}

class LoginUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  LoginUI adaptee;

  LoginUI_jButton1_actionAdapter(LoginUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class LoginUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  LoginUI adaptee;

  LoginUI_jButton2_actionAdapter(LoginUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}