package graduate;

import java.sql.*;
import java.util.*;
public class DegreeDB {
  public DegreeDB() {
  }
  public Vector retrieveDegreeAll(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT * FROM Degree ORDER BY DegreeID";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Degree degree = new Degree();
          degree.setDegreeID(rs.getLong("DegreeID"));
          degree.setDegreeLevel(rs.getBoolean("DegreeLevel"));
          degree.setPt(rs.getBoolean("PT"));
          degree.setMbn(rs.getBoolean("MBN"));
          v.addElement(degree);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertDegree(Degree degree){
    String query = "INSERT INTO Degree(DegreeLevel,PT,MBN) ";
    query += "VALUES("+ degree.getDegreeLevel() + " , " + degree.getPt() + " , " + degree.getMbn() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateDegree(Degree degree){
    String query = "UPDATE Degree SET ";
    query += "DegreeLevel = " + degree.getDegreeLevel() + ", ";
    query += "PT = " + degree.getPt() + ", ";
    query += "MBN = " + degree.getMbn() + " ";
    query += "WHERE DegreeID = " + degree.getDegreeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteDegree(Degree degree){
    String query = "DELETE FROM Degree WHERE DegreeID = " + degree.getDegreeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    DegreeDB gdb = new DegreeDB();
    Degree g = new Degree(5,true,true,true);
    gdb.updateDegree(g);
/*    Vector v = gdb.retrieveDegreeAll();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Degree m1 = (Degree)e.nextElement();
      System.out.println(m1.getDegreeID() + " " + m1.getDegreeLevel() + " " + m1.getPt() + " " + m1.getMbn());
    }*/
    Database.disconnect();
  }
}