package graduate;

import java.util.*;
public class Major {
  private String majorID;
  private String ename;
  private String tname;
  private Department department;
  private String masterEname;
  private String masterTname;
  private String masterEabbr;
  private String masterTabbr;
  private String phDEname;
  private String phDTname;
  private String phDEabbr;
  private String phDTabbr;
  private MajorDB majorDB = new MajorDB();
  private Vector minorVector = new Vector();
  private Vector subjectVector = new Vector();
  private Vector courseStructureVector = new Vector();
  private Vector courseUnitVector = new Vector();
  private Vector supportVector = new Vector();

  //Constructor
  public Major() {
  }
  public Major(String majorid){
    this.setMajorID(majorid);
  }
  public Major(String majorid,String majorTname){
    this.setMajorID(majorid);
    this.setTname(majorTname);
  }
  //getMethod
  public String getMajorID(){
    return this.majorID;
  }
  public String getEname(){
    return this.ename;
  }
  public String getTname(){
    return this.tname;
  }
  public Department getDepartment(){
    return this.department;
  }
  public String getMasterEname(){
    return this.masterEname;
  }
  public String getMasterTname(){
    return this.masterTname;
  }
  public String getMasterEabbr(){
    return this.masterEabbr;
  }
  public String getMasterTabbr(){
    return this.masterTabbr;
  }
  public String getPhDEname(){
    return this.phDEname;
  }
  public String getPhDTname(){
    return this.phDTname;
  }
  public String getPhDEabbr(){
    return this.phDEabbr;
  }
  public String getPhDTabbr(){
    return this.phDTabbr;
  }
  //setMethod
  public void setMajorID(String majorID){
    this.majorID = majorID;
  }
  public void setEname(String ename){
    this.ename = ename;
  }
  public void setTname(String tname){
    this.tname = tname;
  }
  public void setDepartment(Department department){
    this.department = department;
  }
  public void setMasterEname(String courseEname){
    this.masterEname = courseEname;
  }
  public void setMasterTname(String courseTname){
    this.masterTname = courseTname;
  }
  public void setMasterEabbr(String courseEabbr){
    this.masterEabbr= courseEabbr;
  }
  public void setMasterTabbr(String courseTabbr){
    this.masterTabbr = courseTabbr;
  }
  public void setPhDEname(String courseEname){
    this.phDEname = courseEname;
  }
  public void setPhDTname(String courseTname){
    this.phDTname = courseTname;
  }
  public void setPhDEabbr(String courseEabbr){
    this.phDEabbr = courseEabbr;
  }
  public void setPhDTabbr(String courseTabbr){
    this.phDTabbr = courseTabbr;
  }
  //Business Method
  //---------------------------------------------------------------------------MinorVector--------------------------------------------------------------------
  public void addMinor(Minor minor){
    minorVector.addElement(minor);
  }
  public void setMinor(Vector minorVec){
    minorVector = minorVec;
  }
  public Enumeration retrieveMinor(){
    return minorVector.elements();
  }
  public Minor retrieveMinor(String minorID){
    Enumeration e = retrieveMinor();
    while (e.hasMoreElements()){
      Minor minor = (Minor)e.nextElement();
      if (minor.getMinorID().equals(minorID))
        return minor;
    }
    return null;
  }
  //---------------------------------------------------------------------------SubjectVector-------------------------------------------------------------------
  public void addSubject(Subject subject){
    subjectVector.addElement(subject);
  }
  public void setSubject(Vector subject){
    subjectVector = subject;
  }
  public Enumeration retrieveSubject(){
    return subjectVector.elements();
  }
  public Subject retrieveSubject(String subjectID){
    Enumeration e = retrieveSubject();
    while (e.hasMoreElements()){
      Subject subject = (Subject)e.nextElement();
      if (subject.getSubjectID().equals(subjectID))
        return subject;
    }
    return null;
  }
  //---------------------------------------------------------------------CourseStructureVector-------------------------------------------------------------
  public void addCourseStructure(CourseStructure cs){
    courseStructureVector.addElement(cs);
  }
  public void setCourseStructure(Vector cstruct){
    courseStructureVector = cstruct;
  }
  public Enumeration retrieveCourseStructure(){
    return courseStructureVector.elements();
  }
  public CourseStructure retrieveCourseStructure(long csID){
    Enumeration e = retrieveCourseStructure();
    while (e.hasMoreElements()){
      CourseStructure cs = (CourseStructure)e.nextElement();
      if (cs.getCourseStructureID() == csID)
        return cs;
    }
    return null;
  }
  //------------------------------------------------------------------------CourseUnitVector-----------------------------------------------------------------
  public void addCourseUnit(CourseUnit cu){
    courseUnitVector.addElement(cu);
  }
  public void setCourseUnit(Vector cu){
    courseUnitVector = cu;
  }
  public Enumeration retrieveCourseUnit(){
    return courseUnitVector.elements();
  }
  public CourseUnit retrieveCourseUnit(long gID,long dID){
    Enumeration e = retrieveCourseUnit();
    while (e.hasMoreElements()){
      CourseUnit cu = (CourseUnit)e.nextElement();
      if (cu.getGroup().getGroup() == gID && cu.getDegree().getDegreeID() == dID)
        return cu;
    }
    return null;
  }
  //---------------------------------------------------------------------------SupportVector-------------------------------------------------------------------
  public void addSupport(Support sup){
    supportVector.addElement(sup);
  }
  public void setSupport(Vector sup){
    supportVector = sup;
  }
  public Enumeration retrieveSupport(){
    return supportVector.elements();
  }
  public Support retrieveSupport(long supportID){
    Enumeration e = retrieveSupport();
    while (e.hasMoreElements()){
      Support sp = (Support)e.nextElement();
      if (sp.getSupportID() == supportID)
        return sp;
    }
    return null;
  }
  //---------------------------------------------------------------------------Access Layer--------------------------------------------------------------------
  public Vector retrieveMajorAll(Department dep){
    Vector v = majorDB.retrieveMajorAll(dep);
    dep.setMajor(v);
    return v;
  }
  public Vector retrieveMajor(Department dep){
    Vector v = majorDB.retrieveMajor(dep);
    dep.setMajor(v);
    return v;
  }
  public Major retrieveMajor(String majorID) {
    return majorDB.retrieveMajor(majorID);
  }
  public boolean insertMajor(Major major){
    return majorDB.insertMajor(major);
  }
  public boolean updateMajor(Major oldmajor,Major major){
    return majorDB.updateMajor(oldmajor,major);
  }
  public boolean deleteMajor(Major major){
    return majorDB.deleteMajor(major);
  }
  public String toString(){
    return "�Ң��Ԫ�" + this.getTname();
  }
}