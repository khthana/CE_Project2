package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class RegistrationAddUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel5 = new JLabel();
  JPanel jPanel2 = new JPanel();
  TitledBorder titledBorder1;
  JLabel jLabel1 = new JLabel();
  JTextField studentIDText = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField nameText = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField degreeText = new JTextField();
  JLabel jLabel4 = new JLabel();
  JTextField facultyText = new JTextField();
  JTextField majorText = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField typeText = new JTextField();
  JPanel jPanel3 = new JPanel();
  TitledBorder titledBorder2;
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JPanel jPanel6 = new JPanel();
  TitledBorder titledBorder3;
  JRadioButton normRadio = new JRadioButton();
  JRadioButton stableRadio = new JRadioButton();
  JRadioButton restRadio = new JRadioButton();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTable jTable1 = new JTable();
  BorderLayout borderLayout2 = new BorderLayout();
  //------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Student student = new Student();
  Date currentDate = new Date();
  Semester semester = new Semester();
  boolean canRegister = false;
  boolean newStudent = false;
  Vector registrationVector = new Vector();
  Vector tempVector = new Vector();
  Vector subjectVector = new Vector();
  int selectedRow = 0;
  int selectedColumn = 0;
  int pastRow = 0;
  int pastColumn = 0;
  int normMaxCredit = 15;
  int normMinCredit = 9;
  int summerMaxCredit = 6;
  //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
  public RegistrationAddUI() {
    try {
      jbInit();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 165, 165)), "�ѡ�֡��");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 165, 165)), "��¡���Ԫ�");
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.
        white, new Color(165, 163, 151)), "ŧ����¹");
    titledBorder3.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(null);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("�Ң��Ԫ�");
    jLabel5.setBounds(new Rectangle(233, 100, 79, 15));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder1);
    jPanel2.setBounds(new Rectangle(38, 19, 524, 144));
    jPanel2.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("���ʹѡ�֡��");
    jLabel1.setBounds(new Rectangle(15, 32, 75, 15));
    studentIDText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setText("");
    studentIDText.setBounds(new Rectangle(113, 27, 111, 24));
    studentIDText.addActionListener(new
        RegistrationAddUI_studentIDText_actionAdapter(this));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("����-���ʡ��");
    jLabel2.setBounds(new Rectangle(233, 32, 72, 15));
    nameText.setEnabled(true);
    nameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nameText.setText("");
    nameText.setBounds(new Rectangle(305, 27, 203, 24));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setText("�дѺ��ԭ��");
    jLabel3.setBounds(new Rectangle(15, 66, 84, 15));
    degreeText.setBounds(new Rectangle(113, 61, 111, 24));
    degreeText.setText("");
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("���");
    jLabel4.setBounds(new Rectangle(233, 66, 34, 15));
    facultyText.setBounds(new Rectangle(305, 61, 203, 24));
    facultyText.setText("");
    facultyText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyText.setEnabled(true);
    majorText.setEnabled(true);
    majorText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorText.setText("");
    majorText.setBounds(new Rectangle(305, 95, 203, 24));
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("�������ѡ�֡��");
    jLabel6.setBounds(new Rectangle(15, 100, 89, 15));
    typeText.setBounds(new Rectangle(113, 95, 111, 24));
    typeText.setText("");
    typeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder2);
    jPanel3.setPreferredSize(new Dimension(5, 5));
    jPanel3.setBounds(new Rectangle(39, 168, 684, 262));
    jPanel3.setLayout(null);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setPreferredSize(new Dimension(5, 5));
    jPanel4.setBounds(new Rectangle(24, 22, 637, 218));
    jPanel4.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setMinimumSize(new Dimension(10, 10));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setBounds(new Rectangle(88, 479, 459, 35));
    jButton1.setBounds(new Rectangle(325, 443, 63, 25));
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setText("�ѹ�֡");
    jButton1.addActionListener(new RegistrationAddUI_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(393, 443, 63, 25));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setText("������");
    jButton2.addActionListener(new RegistrationAddUI_jButton2_actionAdapter(this));
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setBorder(titledBorder3);
    jPanel6.setBounds(new Rectangle(572, 19, 150, 144));
    jPanel6.setLayout(null);
    normRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    normRadio.setSelected(true);
    normRadio.setText("����");
    normRadio.setBounds(new Rectangle(26, 29, 91, 23));
    stableRadio.setBounds(new Rectangle(26, 62, 91, 23));
    stableRadio.setText("�ѡ����Ҿ");
    stableRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    restRadio.setBounds(new Rectangle(26, 96, 91, 23));
    restRadio.setText("�Ҿѡ");
    restRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jScrollPane1.setMaximumSize(new Dimension(32767, 32767));
    jScrollPane1.setPreferredSize(new Dimension(454, 404));
    jTable1.setMaximumSize(new Dimension(32767, 32767));
    jTable1.setMinimumSize(new Dimension(454, 404));
    jTable1.setPreferredSize(new Dimension(454, 404));
    jTable1.setRowHeight(20);
    jTable1.addMouseListener(new RegistrationAddUI_jTable1_mouseAdapter(this));
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(jLabel1, null);
    jPanel2.add(nameText, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(facultyText, null);
    jPanel2.add(degreeText, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(studentIDText, null);
    jPanel2.add(typeText, null);
    jPanel2.add(jLabel6, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(majorText, null);
    jPanel1.add(jButton2, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jPanel4, null);
    jPanel4.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTable1, null);
    jPanel1.add(jPanel6, null);
    jPanel6.add(normRadio, null);
    jPanel6.add(restRadio, null);
    jPanel6.add(stableRadio, null);
    jPanel1.add(jPanel5, null);
    jPanel1.add(jPanel2, null);
    buttonGroup1.add(normRadio);
    buttonGroup1.add(stableRadio);
    buttonGroup1.add(restRadio);
    jTable1.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif",
        0, 13));
    jTable1.setIntercellSpacing(new Dimension(0, 0));
    jTable1.setRowSelectionAllowed(true);
    jTable1.getTableHeader().setReorderingAllowed(false);
    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object[][] { {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
        , {null, null, null, "1", null}
    }
        ,
        new String[] {
        "�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�礪��", "Cr/Nc/Au"
    }
        ) {
      Class[] types = new Class[] {
          java.lang.Object.class, java.lang.Object.class, java.lang.Object.class,
          java.lang.Integer.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean[] {
          true, false, false, true, true
      };

      public Class getColumnClass(int columnIndex) {
        return types[columnIndex];
      }

      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
      }
    });
    jTable1.setColumnSelectionAllowed(false);
    jTable1.setCellSelectionEnabled(false);
    jTable1.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
    jTable1.setAutoCreateColumnsFromModel(true);
    jTable1.setVerifyInputWhenFocusTarget(true);
    jTable1.setToolTipText("");
    jTable1.setMinimumSize(new Dimension(0, 0));
    jTable1.setMaximumSize(new Dimension(0, 0));
    jTable1.setDoubleBuffered(false);
    jTable1.setDebugGraphicsOptions(0);
    jTable1.setAutoscrolls(true);
    jTable1.setAlignmentY( (float) 0.5);
    jTable1.setAlignmentX( (float) 0.5);
    jTable1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTable1.setEnabled(true);

    JComboBox comboBox = new JComboBox();
    comboBox.addItem("Cr");
    comboBox.addItem("Nc");
    comboBox.addItem("Ad");
    TableColumn typeColumn = jTable1.getColumn("Cr/Nc/Au");
    typeColumn.setCellEditor(new DefaultCellEditor(comboBox));

//Ask to be notified of selection changes.
    ListSelectionModel rowSM = jTable1.getSelectionModel();
    rowSM.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //Ignore extra messages.
        if (e.getValueIsAdjusting())
          return;

        ListSelectionModel lsm = (ListSelectionModel) e.getSource();
        if (lsm.isSelectionEmpty()) {
          //no rows are selected
        }
        else {
          //selectedRow is selected
          pastRow = selectedRow;
          selectedRow = lsm.getMinSelectionIndex();
        }
      }
    });
    Database.connect();
    this.semester = semester.retrieveCurrentSemester();
    Database.disconnect();
  }

  public void retrieveRegistrationRegistered(Student student) {
    Database.connect();
    Registration r = new Registration();
    Vector vr = r.retrieveRegistration(student,semester,new RegisterType(1));
    if (vr.isEmpty()) {
      vr = r.retrieveRegistration(student,semester,new RegisterType(2));
      if (vr.isEmpty()) {
        Database.disconnect();
        return;
      }
    }

    Enumeration e = vr.elements();
    int i = 0;
    while (e.hasMoreElements()){
      Registration reg = (Registration)e.nextElement();
      jTable1.getModel().setValueAt(reg.getSection().getSubject().getSubjectID(),i,0);
      jTable1.getModel().setValueAt(reg.getSection().getSubject().getSubjectTname(),i,1);
      jTable1.getModel().setValueAt(new Integer(reg.getSection().getSubject().getCredit()),i,2);
      jTable1.getModel().setValueAt(new Integer(reg.getSection().getSec()),1,3);
      jTable1.getModel().setValueAt(reg.getType(),i,4);
      subjectVector.addElement(reg.getSection().getSubject());
      i++;
    }

    Database.disconnect();
  }
  void studentIDText_actionPerformed(ActionEvent e) {
    Database.connect();
    student = student.retrieveStudent(new Student(studentIDText.getText()));
    Database.disconnect();
    //---------------------------------------------------------------------retrieve Registration-----------------------------------------------------------------------
    if (student ==null){
      JOptionPane.showMessageDialog(this,"����չѡ�֡�����ʹ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    retrieveRegistrationRegistered(student);
    nameText.setText(student.getStudentTname());
    if (student.getDegree() > 5) degreeText.setText("��ԭ���");
    else degreeText.setText("��ԭ���͡");
    facultyText.setText(student.getMajor().getDepartment().getFaculty().getTname());
    if (student.getStudentType() == 1) typeText.setText("�ѡ�֡�����ѭ");
    else typeText.setText("�ѡ�֡�ҷ��ͧ���¹");
    majorText.setText(student.getMajor().getTname());
    if (student.getStatus() != 1) {
      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getRegisterStatus() != 1){

      JOptionPane.showMessageDialog(this,"ʶҹТͧ�ѡ�֡�ҵ͹����������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getDebtStatus()){
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ�����Թ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student.getLibraryStatus()) {
      JOptionPane.showMessageDialog(this,"�ѡ�֡�Ҥ�ҧ˹ѧ�����ͧ��ش","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    canRegister = true;
    if (registrationVector != null) newStudent = true;

  }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  void jTable1_mouseClicked(MouseEvent e) {
    Subject subject = new Subject();
    String str = new String();
    boolean del = (e.getModifiers() & InputEvent.CTRL_MASK) == InputEvent.CTRL_MASK;
    boolean press = (e.getModifiers() & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK;
    TableColumnModel columnModel = jTable1.getColumnModel();
    pastColumn = selectedColumn;
    selectedColumn = columnModel.getColumnIndexAtX(e.getX());
    if (selectedColumn == 0) {
      pastRow = selectedRow;
      if (del) {
        for(int j=0;j<jTable1.getColumnCount();j++)  { //CTRL + Single Click = Delete
          if (j != 3)
            jTable1.setValueAt(null, selectedRow, j);
          else
            jTable1.setValueAt(new Integer(1), selectedRow, j);
        }
      }
    }

    for (int i=0;i<jTable1.getColumnCount(); i++){
      if (pastRow >0 && jTable1.getModel().getValueAt(pastRow-1,i) == null){
        JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
    }
    if (pastColumn==0)  str = (String)jTable1.getModel().getValueAt(pastRow,pastColumn);
    if (str == null) return;
    if (press && selectedRow==pastRow && selectedColumn==1){
      Database.connect();
      subject = subject.retrieveSubject(str.trim() ,student.getMajor());
      Database.disconnect();

      if (subject == null) {
        JOptionPane.showMessageDialog(this,"���������Ԫҹ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        clearRow();
        return;
      }
      if (subject.getSection() == null) {
        JOptionPane.showMessageDialog(this,"������硪��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        clearRow();
        return;
      }
      boolean find = false;
      Enumeration subEnum = subjectVector.elements();
      while (subEnum.hasMoreElements()){
        Subject sub = (Subject)subEnum.nextElement();
        if (sub.getSubjectID().equals(subject.getSubjectID())) {
          find = true;
          break;
        }
      }

      if (find) {
        JOptionPane.showMessageDialog(this,"����ԪҪ��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      else {
        subjectVector.addElement(subject);
        jTable1.getModel().setValueAt(subject.getSubjectTname(),pastRow,1);
        jTable1.getModel().setValueAt(new Integer(subject.getCredit()),pastRow,2);
      }
    }
  }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  public void clearRow() {
    jTable1.getModel().setValueAt(null,pastRow,1);
    jTable1.getModel().setValueAt(null,pastRow,2);
    jTable1.getModel().setValueAt(new Integer(1),pastRow,3);
    jTable1.getModel().setValueAt(null,pastRow,4);
  }
  //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
  public void clearTable(){
    for(int i=0;i<jTable1.getRowCount();i++)
      for(int j=0;j<jTable1.getColumnCount();j++) {
        if (j!=3) jTable1.setValueAt(null,i,j);
        else jTable1.setValueAt(new Integer(1),i,j);
      }
  }
  void jButton2_actionPerformed(ActionEvent e) {
    clearTable();
    subjectVector = new Vector();
  }

  public Section findSection(String subjectID,int sec){
    Enumeration e = subjectVector.elements();
    while (e.hasMoreElements()){
      Subject subject = (Subject)e.nextElement();
      if (subject.getSubjectID().equals(subjectID.trim())) {
        return subject.getSection(sec);
      }
    }
    return null;
  }
  public Vector calculateCost(){
    Vector costv = new Vector();
    Database.connect();
    Registration registration = new Registration();
    double totalCost = 0.00f;
    int countTerm = 0;
    countTerm = registration.countTermRegisted(student);
    boolean newStudent = student.isNewStudent(semester);
    int condition = student.getPaymentCondition();

    student.InitCost();
    if (condition == 1 || condition == 2 || condition == 3 || condition == 6) {
//-----------------------------------------UNIT------------------------------------------------------------------------------------------------------------------------------------
      if (condition == 1 || condition ==3){ //normal + support exception
              totalCost += student.calculateCost();
              if (student.getTotalCredit() != 0.0){
                 Cost c = new Cost();
                  c.setCostName("���ŧ����¹����Ԫ�");
                  c.setValue(student.getTotalCredit());
                  costv.add(c);
              }
              else if (student.getTotalNoncredit() != 0.0){
                Cost c = new Cost();
                 c.setCostName("���ŧ����¹����Ԫ��дѺ��ԭ�ҵ��");
                 c.setValue(student.getTotalNoncredit());
                 costv.add(c);
              }
              else if (student.getTotalAudit() != 0.0){
                Cost c = new Cost();
                c.setCostName("���ŧ����¹����֡�����������ѧ");
                c.setValue(student.getTotalAudit());
                costv.add(c);
              }
              else if (student.getTotalThesis() != 0.0){
                Cost c = new Cost();
                 c.setCostName("���ŧ����¹�Է�ҹԾ���");
                 c.setValue(student.getTotalThesis());
                 costv.add(c);
              }
      }
//-------------------------------------NewStudent---------------------------------------------------------------------------------------------------------------------------------
      if (newStudent && countTerm == 0){
              for(int i=0;i<4;i++){
                      double newstud = student.getCost(i+17).getValue();
                      totalCost += newstud;
                      Cost c = new Cost();
                       c.setCostName(student.getCost(i+17).getCostName());
                       c.setValue(newstud);
                       costv.add(c);
              }
      }
//-------------------------------------Maintenance Cost-----------------------------------------------------------------------------------------------------------------------
      double institute = student.getCost(12).getValue();
      totalCost += institute;
      Cost ins = new Cost();
       ins.setCostName(student.getCost(12).getCostName());
       ins.setValue(institute);
       costv.add(ins);
       if (semester.getSemesterType() == 1){
          double library = student.getCost(13).getValue();
          totalCost += library;
          Cost l = new Cost();
           l.setCostName(student.getCost(13).getCostName());
           l.setValue(library);
           costv.add(l);
          double health = student.getCost(15).getValue();
          totalCost += health;
          Cost h = new Cost();
           h.setCostName(student.getCost(15).getCostName());
           h.setValue(health);
           costv.add(h);
      }
      else {
          double library = student.getCost(14).getValue();
          totalCost += library;
          Cost ls = new Cost();
           ls.setCostName(student.getCost(14).getCostName());
           ls.setValue(library);
           costv.add(ls);
          double health = student.getCost(16).getValue();
          totalCost += health;
          Cost h = new Cost();
           h.setCostName(student.getCost(16).getCostName());
           h.setValue(health);
           costv.add(h);
     }
//-------------------------------------SUPPORT---------------------------------------------------------------------------------------------------------------------------------
      if (condition == 1 || condition ==2) { //normal + unit exception
        if (countTerm < student.getNoSupportTerm()){
          double sup = student.getSupport();
          totalCost += sup;
          if (student.getStudyGroup() == 1){
            Cost c = new Cost();
            c.setCostName("�Թ�����������֡��");
            c.setValue(sup);
            costv.add(c);
          }
          else {
            Cost c = new Cost();
            c.setCostName("�Թ�ش˹ع����֡��");
            c.setValue(sup);
            costv.add(c);
        }
      }
    }
  }
  Cost c = new Cost();
  c.setCostName("����ӹǹ�Թ����ͧ����");
  c.setValue(totalCost);
  costv.add(c);
  Database.disconnect();
  return costv;
}
//-------------------------------------------------------------------------Registration------------------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {//Save
    boolean complete = false;
    Database.connect();
    if (normRadio.isSelected()){
      student.clearCurrentRegistration();
      Enumeration subEnum = subjectVector.elements();
      if (!subEnum.hasMoreElements()){
        JOptionPane.showMessageDialog(this,"��س�������������Ԫ�㹵��ҧ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }

      for (int i=0;subEnum.hasMoreElements();i++){
        String subjectID = (String)jTable1.getModel().getValueAt(i,0);
        String sint = (String)jTable1.getModel().getValueAt(i,3).toString();
        String type = (String)jTable1.getModel().getValueAt(i,4);
        int si = Integer.parseInt(sint);

        if (subjectID != null && (sint == null || type == null)){
          JOptionPane.showMessageDialog(this,"��س����������������ó�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
        Subject subject = (Subject)subEnum.nextElement();
        Registration registered = new Registration();
        if (registered.isRegistered(student,subject)){
          JOptionPane.showMessageDialog(this,"��ҹ��ŧ����Ԫҹ��������","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
        if (subject.checkPrerequisite(subject) && !registered.isPrerequisiteRegistered(student,subject)){
          JOptionPane.showMessageDialog(this,"������Ԫҷ���ͧ���¹�ҡ�͹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
        Section section = findSection(subjectID,si);
        if (student.checkSectionConflict(section)){
          JOptionPane.showMessageDialog(this,"�������¹���������ͺ���ѹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
         if (!section.checkAvailable()){
          String str = "����Ԫ�" + section.getSubject().getSubjectTname() + " �硪�� " + section.getSec() + "\n";
          str += "�չѡ�֡��ŧ�ú�ӹǹ����";
          JOptionPane.showMessageDialog(this,str,"��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
        int credit = subject.getCredit() + student.sumRegistrationUnit();
        if (semester.getSemesterType() == 1){
          if (credit > normMaxCredit) {
            JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե����ҡ�Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
            return;
          }
        }
        else {
          if (credit > summerMaxCredit) {
            JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե����ҡ�Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
            return;
          }
        }
        Registration r = new Registration();
        r.setStudent(this.student);
        r.setSection(section);
        r.setSemester(semester);
        r.setRegisterType(new RegisterType(2));
        r.setType(type);
        r.setGrade("X");
        r.setPayDate(currentDate);
        r.setRegistrar(new Registrar());
        student.addCurrentRegistration(r);
      }

      if (semester.getSemesterType() == 1){
        if (student.sumRegistrationUnit() < normMinCredit){
          JOptionPane.showMessageDialog(this,"�ӹǹ˹��¡Ե��������Թ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
      //insert into Registration Table------------------------------------------------------------------------------------------------------------------------------
      Vector regVector = student.getCurrentRegistration();
      Enumeration regEnum = regVector.elements();
      while (regEnum.hasMoreElements()){
        Registration reg = (Registration)regEnum.nextElement();
        reg.getSection().incrementStudent(reg.getSection());
        reg.insertRegistration(reg);
      }
      Database.disconnect();
      Vector costv = calculateCost();

      boolean packFrame = false;
      CostPaidUI frame = new CostPaidUI(null,"�������·���ͧ����",true,costv);
      if (packFrame) {
        frame.pack();
      }
      else {
        frame.validate();
      }
      //Center the window
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = frame.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
      frame.setVisible(true);
    }
    //-------------------------------------------------------------------Rest Registration------------------------------------------------------------------------
    else if (restRadio.isSelected()){
      Database.connect();
      if (student.getStatus() != 1) {
        JOptionPane.showMessageDialog(this,"ʶҹ�Ҿ�ͧ�ѡ�֡�� �������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (student.getRegisterStatus() != 1) {
        JOptionPane.showMessageDialog(this,"ʶҹС�͹���ŧ����¹�ͧ�ѡ�֡�� �������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      Appointment appointment = new Appointment();
      Registration r = new Registration();
      Semester semester = new Semester();
      Vector v = r.retrieveRegistration(student);
      semester = semester.retrieveCurrentSemester();
      System.out.print(semester.getSemesterID());
      int count = r.countTermRegisted(student);
      boolean lastTerm = student.checkPreviousRegistration(semester);
      double grade = student.calculateCredit();
      boolean inTime = appointment.checkInTime(new RegisterType(5),semester);

      if (inTime){
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ����ش����ŧ����¹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (count == 0) {
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ�ѧ��������¹�ҡ�͹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (lastTerm){
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ�Ҥ����֡�ҷ���ҹ����ӡ��ŧ����¹�Ҿѡ����"
                                      ,"��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (grade < 3.00) {
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ�ô���¡��� 3.00","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      Registration rs = new Registration();
      rs.setStudent(this.student);
      rs.setSection(new Section());
      rs.setSemester(semester);
      rs.setRegisterType(new RegisterType(5));
      rs.setType("X");
      rs.setGrade("X");
      rs.setPayDate(currentDate);
      rs.setRegistrar(new Registrar());
      boolean completes = rs.insertRegistration(rs);
      if (completes) {
        JOptionPane.showMessageDialog(this,"�ӡ�úѳ�֡���º��������","ʶҹС�÷ӧҹ",JOptionPane.INFORMATION_MESSAGE);
      }
      Database.disconnect();
/*      Vector regis = r.retrieveGroupedCourseWork(student);
      CourseUnit cu = new CourseUnit();
      Vector course = cu.retrieveCourseUnit(student.getMajor(),new Degree(student.getDegree()));
      boolean completeCourse = student.checkCourseWorkComplete(course,regis);
      if (completeCourse) {
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ŧ����¹����ԪҤú����","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }*/

    }
    //----------------------------------------------------------------------stable Registration------------------------------------------------------------------
    else if (stableRadio.isSelected()){
      Database.connect();
      if (student.getStatus() != 1) {
        JOptionPane.showMessageDialog(this,"ʶҹ�Ҿ�ͧ�ѡ�֡�� �������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (student.getRegisterStatus() != 1) {
        JOptionPane.showMessageDialog(this,"ʶҹС�͹���ŧ����¹�ͧ�ѡ�֡�� �������öŧ����¹��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      Appointment appointment = new Appointment();
      Registration r = new Registration();
      Semester semester = new Semester();
      Vector v = r.retrieveRegistration(student);
      semester = semester.retrieveCurrentSemester();
      System.out.print(semester.getSemesterID());
      int count = r.countTermRegisted(student);
      boolean lastTerm = student.checkPreviousRegistration(semester);
      double grade = student.calculateCredit();
      boolean inTime = appointment.checkInTime(new RegisterType(5),semester);

      if (inTime){
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ����ش����ŧ����¹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (count == 0) {
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ���ͧ�ҡ�ѧ��������¹�ҡ�͹","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }
      Registration rs = new Registration();
      rs.setStudent(this.student);
      rs.setSection(new Section());
      rs.setSemester(semester);
      rs.setRegisterType(new RegisterType(6));
      rs.setType("X");
      rs.setGrade("X");
      rs.setPayDate(currentDate);
      rs.setRegistrar(new Registrar());
      boolean completes = rs.insertRegistration(rs);
      if (completes) {
        JOptionPane.showMessageDialog(this,"�ӡ�úѳ�֡���º��������","ʶҹС�÷ӧҹ",JOptionPane.INFORMATION_MESSAGE);
      }
      Database.disconnect();
/*      Registration r = new Registration();
      Vector regis = r.retrieveGroupedCourseWork(student);
      CourseUnit cu = new CourseUnit();
      Vector course = cu.retrieveCourseUnit(student.getMajor(),new Degree(student.getDegree()));
      boolean completeCourse = student.checkCourseWorkComplete(course,regis);
      if (!completeCourse) {
        JOptionPane.showMessageDialog(this,"�������öŧ����¹�� ŧ����¹����Ԫ��ѧ���ú�����ѡ�ٵ�","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
        return;
      }*/
    }
  }
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class RegistrationAddUI_studentIDText_actionAdapter implements java.awt.event.ActionListener {
  RegistrationAddUI adaptee;

  RegistrationAddUI_studentIDText_actionAdapter(RegistrationAddUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.studentIDText_actionPerformed(e);
  }
}

class RegistrationAddUI_jTable1_mouseAdapter extends java.awt.event.MouseAdapter {
  RegistrationAddUI adaptee;

  RegistrationAddUI_jTable1_mouseAdapter(RegistrationAddUI adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseClicked(MouseEvent e) {
    adaptee.jTable1_mouseClicked(e);
  }
}

class RegistrationAddUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  RegistrationAddUI adaptee;

  RegistrationAddUI_jButton2_actionAdapter(RegistrationAddUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class RegistrationAddUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  RegistrationAddUI adaptee;

  RegistrationAddUI_jButton1_actionAdapter(RegistrationAddUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}