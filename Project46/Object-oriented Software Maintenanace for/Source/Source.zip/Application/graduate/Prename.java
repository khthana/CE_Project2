package graduate;

import java.util.*;
public class Prename {
  private int prenameID;
  private String ePrename;
  private String tPrename;
  private PrenameDB prenameDB = new PrenameDB();
  //Constructor
  public Prename() {
  }
  public Prename(int id){
    this.setPrenameID(id);
  }
  public Prename(String ePren,String tPren){
    this.setEPrename(ePren);
    this.setTPrename(tPren);
  }
  public Prename(int pren,String ePren,String tPren){
    this.setPrenameID(pren);
    this.setEPrename(ePren);
    this.setTPrename(tPren);
  }
  //getMethod
  public int getPrenameID(){
    return this.prenameID;
  }
  public String getEprename(){
    return  this.ePrename;
  }
  public String getTPrename(){
    return  this.tPrename;
  }
  //setMethod
  public void setPrenameID(int prenameID){
    this.prenameID = prenameID;
  }
  public void setEPrename(String ePrename){
    this.ePrename = ePrename;
  }
  public void setTPrename(String tPrename){
    this.tPrename = tPrename;
  }
  public Vector retrievePrename(){
    return prenameDB.retrievePrename();
  }
  public boolean insertPrename(Prename p){
    return prenameDB.insertPrename(p);
  }
  public boolean updatePrename(Prename p){
    return prenameDB.updatePrename(p);
  }
  public boolean deletePrename(Prename p){
    return prenameDB.deletePrename(p);
  }
  public String toString(){
    return this.getTPrename() ;
  }

}