package graduate;

import java.sql.*;
import java.util.*;
public class MinorDB {
  public MinorDB() {
  }
  public Vector retrieveMinorAll(Major major){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Minor WHERE MajorID = '" + major.getMajorID() + "' ORDER BY MinorTName";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Minor minor = new Minor();
          minor.setMinorID(rs.getString("MinorID"));
          minor.setEname(rs.getString("MinorEname"));
          minor.setTname(rs.getString("MinorTname"));
          minor.setMajor(major);
          v.addElement(minor);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveMinor(Major major){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Minor WHERE MajorID = '" + major.getMajorID() + "' ORDER BY MinorTname";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Minor minor = new Minor();
          minor.setMinorID(rs.getString("MinorID"));
          minor.setTname(rs.getString("MinorTname"));
          minor.setMajor(major);
          v.addElement(minor);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Minor retrieveMinor(String minorID){
    Minor minor = new Minor();
    try {
      String query = "SELECT * FROM Minor WHERE MinorID = '" + minorID + "' ORDER BY MinorTname";
      ResultSet rs = Database.getResultSet(query);

      while (rs.next()) {
        minor.setMinorID(rs.getString("MinorID"));
        minor.setEname(rs.getString("MinorEname"));
        minor.setTname(rs.getString("MinorTname"));
      }
    }
    catch (SQLException sqlex) {
      System.out.println(sqlex.toString());
    }
    return minor;
  }
  public boolean insertMinor(Minor minor){
    String query = "INSERT INTO Minor(MinorID,MinorEname,MinorTname,MajorID) ";
    query += "VALUES('"+ minor.getMinorID() + "' , '" + minor.getEname() + "' , '" + minor.getTname() + "'";
    query += ", '" + minor.getMajor().getMajorID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateMinor(Minor oldminor,Minor minor){
    String query = "UPDATE Minor SET ";
    query += "MinorID = '" + minor.getMinorID() + "', ";
    query += "MinorEname = '" + minor.getEname() + "', ";
    query += "MinorTname = '" + minor.getTname() + "', ";
    query += "MajorID = '" + minor.getMajor().getMajorID() + "' ";
    query += "WHERE MinorID = '" + oldminor.getMinorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteMinor(Minor minor){
    String query = "DELETE FROM Minor WHERE MinorID = '" + minor.getMinorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    MinorDB m = new MinorDB();
/*    Minor m = new Minor();
    m.setMinorID("002");
    m.setEname("ts");
    m.setTname("Test");
    m.setMajor(new Major("001"));
    m.updateMinor(m);*/
    Vector v = m.retrieveMinorAll(new Major("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Minor m1 = (Minor)e.nextElement();
      System.out.println(m1.getMinorID()+ " " + m1.getEname());
    }
    Database.disconnect();
  }

}