package graduate;

import java.util.*;
public class ScholarshipGroup {
  private long sgroupID;
  private String sgroupName;
  private ScholarshipGroupDB sp = new ScholarshipGroupDB();
  //Constructor
  public ScholarshipGroup() {
  }
  public ScholarshipGroup(long id){
    this.setSgroupID(id);
  }
  public ScholarshipGroup(String name){
    this.setSgroupName(name);
  }
  public ScholarshipGroup(long id,String name){
    setSgroupID(id);
    setSgroupName(name);
  }
  //getMethod
  public long getSgroupID(){
    return this.sgroupID;
  }
  public String getSgroupName(){
    return this.sgroupName;
  }
  //setMethod
  public void setSgroupID(long groupid){
    this.sgroupID = groupid;
  }
  public void setSgroupName(String groupName){
    this.sgroupName = groupName;
  }
  public Vector retrieveScholarshipGroup(){
    return sp.retrieveScholarShipGroup();
  }
  public boolean insertScholarshipGroup(ScholarshipGroup sg){
    return sp.insertScholarshipGroup(sg);
  }
  public boolean updateScholarshipGroup(ScholarshipGroup sg){
    return sp.updateScholarshipGroup(sg);
  }
  public boolean deleteScholarshipGroup(ScholarshipGroup sg){
    return sp.deleteScholarshipGroup(sg);
  }
  public String toString(){
    return this.getSgroupName();
  }
}