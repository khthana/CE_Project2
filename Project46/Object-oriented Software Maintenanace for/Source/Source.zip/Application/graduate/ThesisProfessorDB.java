package graduate;

import java.sql.*;
import java.util.*;
public class ThesisProfessorDB {
  public ThesisProfessorDB() {
  }
  public Vector retrieveThesisProfessor(Thesis thesis){
    Vector v = new Vector();
    try
    {
        String query = "SELECT p.*,t.*,tp.* FROM Prename p,Professor t,ThesisProfessor tp WHERE ";
        query += "p.PrenameID = t.PrenameID AND t.ProfessorID = tp.ProfessorID AND ThesisID = " + thesis.getThesisID();
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          ThesisProfessor thepro = new ThesisProfessor();
          thepro.setThesis(thesis);
          Professor prof = new Professor();
          prof.setProfessorID(rs.getString("ProfessorID"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          prof.setPrename(p);
          prof.setEprofessorName(rs.getString("EprofessorName"));
          prof.setTprofessorName(rs.getString("TProfessorName"));
          prof.setPassword(rs.getString("Password"));
          prof.setPosition(rs.getString("Position"));
          thepro.setProfessor(prof);
          thepro.setControl(rs.getBoolean("Control"));
          v.addElement(thepro);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }

  public boolean insertThesisProfessor(ThesisProfessor thesisProfessor){
    String query = "INSERT INTO ThesisProfessor(ThesisID,ProfessorID,Control) ";
    query += "VALUES('" + thesisProfessor.getThesis().getThesisID()+ "'";
    query += ",'" + thesisProfessor.getProfessor().getProfessorID() + "'," + thesisProfessor.getControl() + ")";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateThesisProfessor(ThesisProfessor oldThesisProfessor,ThesisProfessor newThesisProfessor){
    String query = "UPDATE ThesisProfessor SET ";
    query += "ThesisID = '" + newThesisProfessor.getThesis().getThesisID() + "', ";
    query += "ProfessorID = '" + newThesisProfessor.getProfessor().getProfessorID()+ "', ";
    query += "Control = " + newThesisProfessor.getControl() + " ";
    query += "WHERE ThesisID = " + oldThesisProfessor.getThesis().getThesisID() + " AND ";
    query += "ProfessorID = '" + oldThesisProfessor.getProfessor().getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteThesisProfessor(ThesisProfessor thesisProfessor){
    String query = "DELETE FROM ThesisProfessor ";
    query += "WHERE ThesisID = " + thesisProfessor.getThesis().getThesisID() + " AND ";
    query += "ProfessorID = '" + thesisProfessor.getProfessor().getProfessorID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }

  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    ThesisProfessorDB db = new ThesisProfessorDB();
    ThesisProfessor t = new ThesisProfessor();
    t.setProfessor(new Professor("002"));
    t.setThesis(new Thesis(1));
    t.setControl(true);
    ThesisProfessor tt = new ThesisProfessor();
   tt.setProfessor(new Professor("002"));
   tt.setThesis(new Thesis(1));
   tt.setControl(false);

//    db.updateThesisProfessor(t,tt);
   Vector v = db.retrieveThesisProfessor(new Thesis(1));
   Enumeration e = v.elements();
   while (e.hasMoreElements()){
     ThesisProfessor tp = (ThesisProfessor)e.nextElement();
     System.out.println(tp.getThesis().getThesisID() + " " + tp.getProfessor().getProfessorID() + " " + tp.getControl());
   }
    Database.disconnect();
  }

}