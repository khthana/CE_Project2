package graduate;

import java.sql.*;
import java.util.*;
public class DepartmentDB {
  public DepartmentDB() {
  }
  public Vector retrieveDepartmentAll(Faculty fac){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Department WHERE FacultyID = '" + fac.getFacultyID() + "' ORDER BY DepartmentTname";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Department dep = new Department();
          dep.setDepartmentID(rs.getString("DepartmentID"));
          dep.setEname(rs.getString("DepartmentEname"));
          dep.setTname(rs.getString("DepartmentTname"));
          dep.setFaculty(fac);
          v.addElement(dep);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveDepartment(Faculty fac){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Department WHERE FacultyID = '" + fac.getFacultyID() + "' ORDER BY DepartmentTname";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Department dep = new Department();
          dep.setDepartmentID(rs.getString("DepartmentID"));
          dep.setTname(rs.getString("DepartmentTname"));
          dep.setFaculty(fac);
          v.addElement(dep);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertDepartment(Department department){
    String query = "INSERT INTO Department(DepartmentID,DepartmentEname,DepartmentTname,FacultyID)";
    query +=  "VALUES('"+ department.getDepartmentID() + "' , '" + department.getEname() + "' , '" + department.getTname() + "'";
    query +=  ", '" + department.getFaculty().getFacultyID() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateDepartment(Department oldDep,Department department){
    String query = "UPDATE Department SET ";
    query +=  "DepartmentID = '" + department.getDepartmentID() + "', ";
    query +=  "DepartmentEname = '" + department.getEname() + "', ";
    query +=  "DepartmentTname = '" + department.getTname() + "' ";
//    query +=  "FacultyID = '" + department.getFaculty().getFacultyID() + "' ";
    query +=  "WHERE DepartmentID = '" + oldDep.getDepartmentID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteDepartment(Department department){
    String query = "DELETE FROM Department WHERE DepartmentID = '" + department.getDepartmentID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    DepartmentDB db = new DepartmentDB();
    Vector v = db.retrieveDepartmentAll(new Faculty("001"));
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Department d = (Department)e.nextElement();
      System.out.println(d.getDepartmentID() + " " + d.getEname() + " " + d.getTname() + " " + d.getFaculty().getFacultyID());
    }
    Database.disconnect();
  }

}