package graduate;

import java.sql.*;
import java.util.*;
public class FacultyDB {
  //Constructor
  public FacultyDB() {
  }
  public Vector retrieveFacultyAll(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT f.*,p.* FROM Faculty f,Prename p WHERE f.PrenameID = p.PrenameID ORDER BY FacultyTname";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Faculty faculty = new Faculty();
          faculty.setFacultyID(rs.getString("FacultyID"));
          faculty.setEname(rs.getString("FacultyEname"));
          faculty.setTname(rs.getString("FacultyTname"));
          Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
          faculty.setPrename(p);
          faculty.setDeanEname(rs.getString("DeanEname"));
          faculty.setDeanTname(rs.getString("DeanTname"));
          faculty.setPosition(rs.getString("Position"));
          faculty.setApprover(rs.getString("Approver"));
          v.addElement(faculty);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Vector retrieveFaculty(){
    Vector v = new Vector();
    try
    {
        String query = "SELECT FacultyID,FacultyTname FROM Faculty ORDER BY FacultyTname";
        ResultSet rs = Database.getResultSet(query);

        while(rs.next())
        {
          Faculty faculty = new Faculty();
          faculty.setFacultyID(rs.getString("FacultyID"));
          faculty.setTname(rs.getString("FacultyTname"));
          v.addElement(faculty);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }

    return v;
  }
  public Faculty retrieveFaculty(String fac){
    Faculty faculty = new Faculty();
    try
    {
      String query = "SELECT f.*,p.* FROM Faculty f,Prename p WHERE f.PrenameID = p.PrenameID AND ";
      query +=  "FacultyID = '" + fac + "' ORDER BY FacultyTname";
      ResultSet rs = Database.getResultSet(query);

      while(rs.next())
      {
        faculty.setFacultyID(rs.getString("FacultyID"));
        faculty.setEname(rs.getString("FacultyEname"));
        faculty.setTname(rs.getString("FacultyTname"));
        Prename p = new Prename(rs.getInt("PrenameID"),rs.getString("EPrename"),rs.getString("TPrename"));
        faculty.setPrename(p);
        faculty.setDeanEname(rs.getString("DeanEname"));
        faculty.setDeanTname(rs.getString("DeanTname"));
        faculty.setPosition(rs.getString("Position"));
        faculty.setApprover(rs.getString("Approver"));
      }

    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return faculty;
  }
  public boolean insertFaculty(Faculty faculty){
    String query = "INSERT INTO Faculty(FacultyID,FacultyEname,FacultyTname,PrenameID,DeanEname,DeanTname,Position,Approver) ";
    query += "VALUES('"+ faculty.getFacultyID() + "' , '" + faculty.getEname() + "' , '" + faculty.getTname() + "'";
    query += ", " + faculty.getPrename().getPrenameID() + ",'" + faculty.getDeanEname() + "','" + faculty.getTname() + "'";
    query += ", '" + faculty.getPosition() + "','" + faculty.getApprover() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateFaculty(Faculty oldfaculty,Faculty newfaculty){
    String query = "UPDATE Faculty SET ";
    query += "FacultyID = '" + newfaculty.getFacultyID() + "', ";
    query += "FacultyEname = '" + newfaculty.getEname() + "', ";
    query += "FacultyTname = '" + newfaculty.getTname() + "', ";
    query += "PrenameID = " + newfaculty.getPrename().getPrenameID() + ", ";
    query += "DeanEname = '" + newfaculty.getDeanEname() + "', ";
    query += "DeanTname = '" + newfaculty.getDeanTname() + "', ";
    query += "Position = '" + newfaculty.getPosition() + "', ";
    query += "Approver = '" + newfaculty.getApprover() + "' ";
    query += "WHERE FacultyID = '" + oldfaculty.getFacultyID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteFaculty(Faculty faculty){
    String query = "DELETE FROM Faculty WHERE FacultyID = '" + faculty.getFacultyID() + "'";
    if (Database.update(query) != 0) return true;
    return false;
  }

  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    FacultyDB fac = new FacultyDB();
    Faculty f = new Faculty();
    Prename p = new Prename();
    f.setFacultyID("003");
    f.setEname("Engineering");
    f.setTname("���ǡ�����ʵúѳ�Ե");
    p.setPrenameID(1);
    f.setPrename(p);
    f.setDeanEname("TestDeanEname");
    f.setDeanTname("�������");
    f.setPosition("�����");
    f.setApprover("aaaa");

//    fac.updateFaculty(f);
    Database.disconnect();
  }
}