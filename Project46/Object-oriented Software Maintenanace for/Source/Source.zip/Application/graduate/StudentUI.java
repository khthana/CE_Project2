package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;

public class StudentUI extends JPanel {
  String[] date = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20",
  "21","22","23","24","25","26","27","28","29","30","31"};
  String[] month = {"���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�",
  "��Ȩԡ�¹","�ѹ�Ҥ�"};
  String[] deg ={"Ẻ��� 1 ���","Ẻ��� 1 �����","Ẻ��� 2 ���","Ẻ��� 2 �����",
          "Ἱ �1","Ἱ �2","Ἱ �"};
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  TitledBorder titledBorder5;
  TitledBorder titledBorder6;
  TitledBorder titledBorder7;
  TitledBorder titledBorder8;
  TitledBorder titledBorder9;
  TitledBorder titledBorder10;
  TitledBorder titledBorder11;
  TitledBorder titledBorder12;
  TitledBorder titledBorder13;
  TitledBorder titledBorder14;
  TitledBorder titledBorder15;
  TitledBorder titledBorder16;
  TitledBorder titledBorder17;
  TitledBorder titledBorder18;
  TitledBorder titledBorder19;
  Border border1;
  TitledBorder titledBorder20;
  TitledBorder titledBorder21;
  TitledBorder titledBorder22;
  TitledBorder titledBorder23;
  TitledBorder titledBorder24;
  TitledBorder titledBorder25;
  TitledBorder titledBorder26;
  TitledBorder titledBorder27;
  TitledBorder titledBorder28;
  BorderLayout borderLayout3 = new BorderLayout();
  JRadioButton normalTypeRadio = new JRadioButton();
  JLabel jLabel42 = new JLabel();
  JRadioButton statusRadio5 = new JRadioButton();
  JComboBox departmentCombo = new JComboBox();
  JPanel jPanel36 = new JPanel();
  JComboBox facultyCombo = new JComboBox();
  JTextField studentIDText = new JTextField();
  JLabel jLabel43 = new JLabel();
  JPanel jPanel37 = new JPanel();
  JComboBox majorCombo = new JComboBox();
  JLabel jLabel44 = new JLabel();
  JPanel jPanel38 = new JPanel();
  JLabel jLabel45 = new JLabel();
  JPanel jPanel39 = new JPanel();
  JComboBox minorCombo = new JComboBox();
  JPanel jPanel40 = new JPanel();
  JLabel jLabel46 = new JLabel();
  JRadioButton statusRadio2 = new JRadioButton();
  JPanel jPanel41 = new JPanel();
  JPanel jPanel42 = new JPanel();
  JLabel jLabel47 = new JLabel();
  JComboBox tprenameCombo = new JComboBox();
  JTextField eprenameText = new JTextField();
  JLabel jLabel48 = new JLabel();
  JLabel jLabel49 = new JLabel();
  JRadioButton statusRadio4 = new JRadioButton();
  JLabel jLabel50 = new JLabel();
  JRadioButton statusRadio3 = new JRadioButton();
  JPanel jPanel43 = new JPanel();
  JRadioButton statusRadio1 = new JRadioButton();
  JTextField enameText = new JTextField();
  JRadioButton testTypeRadio = new JRadioButton();
  JTextField tnameText = new JTextField();
  JPanel jPanel44 = new JPanel();
  JTextField outYearText = new JTextField();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JPanel jPanel26 = new JPanel();
  JRadioButton insemesterRadio1 = new JRadioButton();
  JTextField detailYearText = new JTextField();
  JLabel jLabel210 = new JLabel();
  JTextField inbeText = new JTextField();
  JComboBox inMonthCombo = new JComboBox(month);
  JLabel jLabel35 = new JLabel();
  JComboBox coupleOccupationCombo = new JComboBox();
  JRadioButton insemesterRadio3 = new JRadioButton();
  JComboBox inDateCombo = new JComboBox(date);
  JTextField recentAddrText = new JTextField();
  JTextField outbeText = new JTextField();
  JPanel jPanel27 = new JPanel();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JRadioButton paymentRadio1 = new JRadioButton();
  JComboBox detailOccupationCombo = new JComboBox();
  JRadioButton jRadioButton112 = new JRadioButton();
  JLabel jLabel111 = new JLabel();
  JLabel jLabel37 = new JLabel();
  JRadioButton insemesterRadio2 = new JRadioButton();
  BoxLayout2 boxLayout23 = new BoxLayout2();
  JPanel jPanel7 = new JPanel();
  JTextField thesisText = new JTextField();
  JPanel jPanel34 = new JPanel();
  JTextField childrenText = new JTextField();
  JPanel jPanel28 = new JPanel();
  JTextField yearText = new JTextField();
  JLabel jLabel34 = new JLabel();
  JComboBox detailMonthCombo = new JComboBox(month);
  FlowLayout flowLayout4 = new FlowLayout();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel26 = new JLabel();
  JComboBox thesisProfCombo1 = new JComboBox();
  JPanel jPanel31 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel20 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel25 = new JPanel();
  JComboBox thesisProfCombo2 = new JComboBox();
  JLabel jLabel32 = new JLabel();
  JComboBox thesisProfCombo3 = new JComboBox();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel24 = new JLabel();
  JPanel jPanel24 = new JPanel();
  JComboBox detailDateCombo = new JComboBox(date);
  JComboBox outDateCombo = new JComboBox(date);
  JPanel jPanel5 = new JPanel();
  JComboBox professorCombo = new JComboBox();
  JTextField salaryText = new JTextField();
  JComboBox locationCombo = new JComboBox();
  JComboBox momOccupationCombo = new JComboBox();
  JLabel jLabel19 = new JLabel();
  JPanel jPanel8 = new JPanel();
  JComboBox scholarshipCombo1 = new JComboBox();
  JPanel jPanel22 = new JPanel();
  JLabel jLabel11 = new JLabel();
  JRadioButton paymentRadio3 = new JRadioButton();
  JComboBox dadOccupationCombo = new JComboBox();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel25 = new JLabel();
  JPanel jPanel17 = new JPanel();
  JPanel jPanel18 = new JPanel();
  JRadioButton paymentRadio6 = new JRadioButton();
  JLabel jLabel36 = new JLabel();
  JPanel jPanel21 = new JPanel();
  JComboBox outMonthCombo = new JComboBox(month);
  JRadioButton paymentRadio5 = new JRadioButton();
  JLabel jLabel28 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JPanel jPanel20 = new JPanel();
  JPanel jPanel15 = new JPanel();
  JLabel jLabel27 = new JLabel();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel23 = new JPanel();
  JLabel jLabel10 = new JLabel();
  JTextField termText = new JTextField();
  JTextField parentTelText = new JTextField();
  JPanel jPanel32 = new JPanel();
  JPanel jPanel16 = new JPanel();
  JPanel jPanel19 = new JPanel();
  JLabel jLabel40 = new JLabel();
  JTextField instituteText = new JTextField();
  JPanel jPanel13 = new JPanel();
  JTextField parentText = new JTextField();
  JPanel jPanel9 = new JPanel();
  JLabel jLabel14 = new JLabel();
  JTextField religionText = new JTextField();
  JPanel jPanel33 = new JPanel();
  JTextField parentAddrText = new JTextField();
  JLabel jLabel114 = new JLabel();
  JPanel jPanel30 = new JPanel();
  JLabel jLabel38 = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel12 = new JPanel();
  JLabel jLabel113 = new JLabel();
  JTextField degreeText = new JTextField();
  JLabel jLabel16 = new JLabel();
  JTextField nationalityText = new JTextField();
  JRadioButton maleRadio = new JRadioButton();
  JLabel jLabel18 = new JLabel();
  JPanel jPanel35 = new JPanel();
  JLabel jLabel17 = new JLabel();
  JPanel jPanel1 = new JPanel();
  JRadioButton outsemesterRadio2 = new JRadioButton();
  JPanel jPanel6 = new JPanel();
  JLabel jLabel29 = new JLabel();
  JComboBox scholarshipCombo2 = new JComboBox();
  JLabel jLabel39 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JPanel jPanel14 = new JPanel();
  JTextField coupleText = new JTextField();
  JTextField gpaText = new JTextField();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JRadioButton paymentRadio4 = new JRadioButton();
  JLabel jLabel33 = new JLabel();
  JTextField raceText = new JTextField();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField registerTelText = new JTextField();
  JTextField recentTelText = new JTextField();
  JLabel jLabel30 = new JLabel();
  JRadioButton paymentRadio2 = new JRadioButton();
  JTextField momText = new JTextField();
  JRadioButton femaleRadio = new JRadioButton();
  JPanel jPanel11 = new JPanel();
  JRadioButton outsemesterRadio3 = new JRadioButton();
  JTextField dadText = new JTextField();
  BorderLayout borderLayout2 = new BorderLayout();
  JLabel jLabel112 = new JLabel();
  JTextField registerAddrText = new JTextField();
  JPanel jPanel29 = new JPanel();
  JRadioButton jRadioButton12 = new JRadioButton();
  JRadioButton outsemesterRadio1 = new JRadioButton();
  JLabel jLabel110 = new JLabel();
  JLabel jLabel31 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JTextField inYearText = new JTextField();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel45 = new JPanel();
  JButton saveButton = new JButton();
  JButton clearButton = new JButton();
  Border border2;
  JLabel jLabel51 = new JLabel();
  BorderLayout borderLayout5 = new BorderLayout();
  Border border3;
  BorderLayout borderLayout6 = new BorderLayout();
  JScrollPane jScrollPane1 = new JScrollPane();
  JRadioButton preRadio2 = new JRadioButton();
  JRadioButton preRadio3 = new JRadioButton();
  JRadioButton preRadio6 = new JRadioButton();
  JRadioButton preRadio7 = new JRadioButton();
  JPanel jPanel2 = new JPanel();
  JRadioButton preRadio4 = new JRadioButton();
  JRadioButton preRadio5 = new JRadioButton();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JRadioButton preRadio8 = new JRadioButton();
  JRadioButton preRadio9 = new JRadioButton();
  JRadioButton preRadio1 = new JRadioButton();
  JCheckBox bookCheckBox = new JCheckBox();
  JCheckBox interCheckBox = new JCheckBox();
  JTextField relationText = new JTextField();
  JComboBox degreeTypeCombo = new JComboBox(deg);
  JRadioButton phDRadio = new JRadioButton();
  JRadioButton masterRadio = new JRadioButton();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  ButtonGroup buttonGroup2 = new ButtonGroup();
  ButtonGroup buttonGroup3 = new ButtonGroup();
  Border border4;
  TitledBorder titledBorder29;
  ButtonGroup buttonGroup4 = new ButtonGroup();
  ButtonGroup buttonGroup5 = new ButtonGroup();
  ButtonGroup buttonGroup6 = new ButtonGroup();
  ButtonGroup buttonGroup7 = new ButtonGroup();
  ButtonGroup buttonGroup8 = new ButtonGroup();
  ButtonGroup buttonGroup9 = new ButtonGroup();
  JScrollPane jScrollPane2 = new JScrollPane();
  JPanel jPanel46 = new JPanel();
  BorderLayout borderLayout7 = new BorderLayout();
  VerticalFlowLayout verticalFlowLayout2 = new VerticalFlowLayout();
  JRadioButton studyGroupRadio5 = new JRadioButton();
  JRadioButton studyGroupRadio3 = new JRadioButton();
  JRadioButton studyGroupRadio4 = new JRadioButton();
  JRadioButton studyGroupRadio1 = new JRadioButton();
  JRadioButton studyGroupRadio2 = new JRadioButton();
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Student student = new Student();
  boolean newRecord = false;
  Vector facultyVector = new Vector();
  Border border5;
  TitledBorder titledBorder30;
  Border border6;
  TitledBorder titledBorder31;

  public StudentUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�дѺ");
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"ʶҹ�Ҿ");
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165)),"�����������������¹");
    titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"����-���ʡ��");
    titledBorder5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�ѧ�Ѵ");
    titledBorder7 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"������֡�� ����Ҿ �������͡");
    titledBorder9 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�ع����֡��");
    titledBorder10 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"���");
    titledBorder11 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"������֡�� ����Ҿ ���� ���͡");
    titledBorder12 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�Ҩ������Ǻ����Է�ҹԾ���");
    titledBorder13 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"��������´");
    titledBorder14 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"ʶҹ�֡�����");
    titledBorder15 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"��");
    titledBorder16 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�������Ѩ�غѹ");
    titledBorder17 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�������Ѩ�غѹ");
    titledBorder19 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�Դ�-��ô�");
    border1 = BorderFactory.createLineBorder(Color.black,2);
    titledBorder20 = new TitledBorder(border1,"������Ѩ�غѹ");
    titledBorder21 = new TitledBorder("");
    titledBorder22 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"���������������");
    titledBorder23 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"�������Ѩ�غѹ");
    titledBorder24 = new TitledBorder("");
    titledBorder25 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"��黡��ͧ");
    titledBorder26 = new TitledBorder("");
    titledBorder27 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"���͹䢡�è����Թ");
    titledBorder28 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"ʶҹС�͹ŧ����¹");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 165, 165));
    titledBorder29 = new TitledBorder(border4,"�������ѡ�֡��");
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder30 = new TitledBorder(border5,"����֡��");
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder31 = new TitledBorder(border6,"�������");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder2.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder3.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder4.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder7.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder9.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder10.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder11.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder12.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder13.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder14.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder15.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder16.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder17.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder19.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder20.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder21.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder22.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder23.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder24.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder25.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder26.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder27.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder28.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder29.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder30.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    titledBorder31.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    border3 = BorderFactory.createEmptyBorder(5,5,5,5);
    this.setLayout(borderLayout3);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setOpaque(true);
    this.setPreferredSize(new Dimension(760, 700));
    normalTypeRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    normalTypeRadio.setToolTipText("");
    normalTypeRadio.setSelected(true);
    normalTypeRadio.setText("���ѭ");
    normalTypeRadio.setBounds(new Rectangle(10, 24, 70, 23));
    jLabel42.setBounds(new Rectangle(13, 112, 48, 22));
    jLabel42.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel42.setText("ᢧ�Ԫ�");
    statusRadio5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    statusRadio5.setText("��Ѻ��Ҿ");
    statusRadio5.setBounds(new Rectangle(105, 42, 85, 23));
    departmentCombo.setBounds(new Rectangle(67, 53, 205, 25));
    departmentCombo.addActionListener(new StudentUI_departmentCombo_actionAdapter(this));
    departmentCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel36.setLayout(null);
    jPanel36.setBounds(new Rectangle(164, 104, 311, 155));
    jPanel36.setDebugGraphicsOptions(0);
    jPanel36.setBorder(titledBorder4);
    jPanel36.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    facultyCombo.setBounds(new Rectangle(67, 21, 205, 25));
    facultyCombo.addActionListener(new StudentUI_facultyCombo_actionAdapter(this));
    facultyCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studentIDText.setText("");
    studentIDText.setBounds(new Rectangle(11, 41, 111, 24));
    studentIDText.addActionListener(new StudentUI_studentIDText_actionAdapter(this));
    jLabel43.setText("�Ң��Ԫ�");
    jLabel43.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel43.setBounds(new Rectangle(13, 86, 48, 22));
    jPanel37.setLayout(null);
    jPanel37.setBounds(new Rectangle(271, 9, 99, 93));
    jPanel37.setDebugGraphicsOptions(0);
    jPanel37.setBorder(titledBorder29);
    jPanel37.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    majorCombo.setBounds(new Rectangle(67, 85, 205, 25));
    majorCombo.addActionListener(new StudentUI_majorCombo_actionAdapter(this));
    jLabel44.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel44.setText("���ʹѡ�֡��");
    jLabel44.setBounds(new Rectangle(11, 14, 89, 28));
    jPanel38.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel38.setBorder(titledBorder1);
    jPanel38.setDebugGraphicsOptions(0);
    jPanel38.setBounds(new Rectangle(161, 8, 106, 95));
    jPanel38.setLayout(null);
    jLabel45.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel45.setText("�ӹ�˹�� (�)");
    jLabel45.setBounds(new Rectangle(10, 26, 77, 22));
    jPanel39.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel39.setBorder(titledBorder3);
    jPanel39.setDebugGraphicsOptions(0);
    jPanel39.setBounds(new Rectangle(371, 9, 201, 93));
    jPanel39.setLayout(borderLayout7);
    minorCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    minorCombo.setBounds(new Rectangle(67, 116, 205, 25));
    jPanel40.setLayout(null);
    jPanel40.setBounds(new Rectangle(478, 104, 286, 155));
    jPanel40.setDebugGraphicsOptions(0);
    jPanel40.setBorder(titledBorder5);
    jPanel40.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel46.setText("�Ҥ�Ԫ�");
    jLabel46.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel46.setBounds(new Rectangle(13, 56, 48, 22));
    statusRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    statusRadio2.setText("������֡��");
    statusRadio2.setBounds(new Rectangle(16, 42, 84, 23));
    jPanel41.setLayout(null);
    jPanel42.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel42.setBorder(titledBorder2);
    jPanel42.setDebugGraphicsOptions(0);
    jPanel42.setBounds(new Rectangle(574, 9, 194, 93));
    jPanel42.setLayout(null);
    jLabel47.setText("���");
    jLabel47.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel47.setBounds(new Rectangle(13, 27, 48, 22));
    tprenameCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tprenameCombo.setBounds(new Rectangle(13, 52, 69, 25));
    tprenameCombo.addActionListener(new StudentUI_tprenameCombo_actionAdapter(this));
    eprenameText.setBounds(new Rectangle(13, 111, 69, 24));
    eprenameText.setText("");
    eprenameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel48.setBounds(new Rectangle(10, 86, 77, 22));
    jLabel48.setText("�ӹ�˹�� (�)");
    jLabel48.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel49.setText("����-���ʡ�� (�)");
    jLabel49.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel49.setBounds(new Rectangle(96, 86, 100, 22));
    statusRadio4.setBounds(new Rectangle(105, 19, 77, 23));
    statusRadio4.setText("���͡");
    statusRadio4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel50.setBounds(new Rectangle(97, 26, 100, 22));
    jLabel50.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel50.setText("����-���ʡ�� (�)");
    statusRadio3.setBounds(new Rectangle(16, 66, 98, 23));
    statusRadio3.setText("����Ҿ");
    statusRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel43.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel43.setBorder(BorderFactory.createLoweredBevelBorder());
    jPanel43.setDebugGraphicsOptions(0);
    jPanel43.setBounds(new Rectangle(11, 81, 149, 178));
    jPanel43.setLayout(borderLayout5);
    statusRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    statusRadio1.setToolTipText("");
    statusRadio1.setSelected(true);
    statusRadio1.setText("���ѧ�֡��");
    statusRadio1.setBounds(new Rectangle(16, 19, 90, 23));
    enameText.setBounds(new Rectangle(97, 111, 205, 24));
    enameText.setText("");
    enameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    testTypeRadio.setBounds(new Rectangle(10, 55, 81, 23));
    testTypeRadio.setText("���ͧ���¹");
    testTypeRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tnameText.setText("");
    tnameText.setBounds(new Rectangle(97, 52, 204, 24));
    jPanel41.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel41.setMinimumSize(new Dimension(1, 1));
    jPanel41.setPreferredSize(new Dimension(700, 260));
    outYearText.setText("");
    outYearText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outYearText.setBounds(new Rectangle(78, 121, 84, 28));
    jPanel26.setBounds(new Rectangle(10, 148, 737, 130));
    jPanel26.setBorder(titledBorder23);
    jPanel26.setDebugGraphicsOptions(0);
    jPanel26.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel26.setLayout(null);
    insemesterRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    insemesterRadio1.setSelected(true);
    insemesterRadio1.setText("��");
    insemesterRadio1.setBounds(new Rectangle(15, 29, 70, 23));
    detailYearText.setBounds(new Rectangle(90, 94, 84, 28));
    detailYearText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    detailYearText.setText("");
    jLabel210.setBounds(new Rectangle(22, 39, 70, 15));
    jLabel210.setText("���ͤ������");
    jLabel210.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    inbeText.setBounds(new Rectangle(78, 22, 84, 28));
    inbeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    inbeText.setText("");
    inMonthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    inMonthCombo.setBounds(new Rectangle(40, 90, 122, 25));
    jLabel35.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel35.setText("����-���ʡ��");
    jLabel35.setBounds(new Rectangle(20, 37, 84, 15));
    coupleOccupationCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    coupleOccupationCombo.setBounds(new Rectangle(100, 63, 122, 25));
    insemesterRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    insemesterRadio3.setText("Ĵ���͹");
    insemesterRadio3.setBounds(new Rectangle(15, 93, 70, 23));
    inDateCombo.setBounds(new Rectangle(111, 61, 51, 25));
    inDateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    recentAddrText.setText("");
    recentAddrText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    recentAddrText.setBounds(new Rectangle(158, 31, 510, 28));
    outbeText.setBounds(new Rectangle(78, 22, 84, 28));
    outbeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outbeText.setText("");
    jPanel27.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel27.setBorder(titledBorder19);
    jPanel27.setBounds(new Rectangle(26, 8, 321, 195));
    jPanel27.setLayout(null);
    jLabel23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel23.setText("�ô���������");
    jLabel23.setBounds(new Rectangle(28, 116, 108, 15));
    jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel9.setText("�Ҩ�������֡��");
    jLabel9.setBounds(new Rectangle(7, 40, 107, 27));
    paymentRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio1.setSelected(true);
    paymentRadio1.setText("����");
    paymentRadio1.setBounds(new Rectangle(28, 27, 188, 23));
    detailOccupationCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    detailOccupationCombo.setBounds(new Rectangle(223, 31, 122, 25));
    jRadioButton112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton112.setText("����");
    jRadioButton112.setBounds(new Rectangle(28, 27, 188, 23));
    jLabel111.setBounds(new Rectangle(188, 36, 59, 15));
    jLabel111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel111.setText("�Ҫվ");
    jLabel37.setBounds(new Rectangle(20, 71, 79, 15));
    jLabel37.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel37.setToolTipText("");
    jLabel37.setText("��������ѹ��");
    insemesterRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    insemesterRadio2.setToolTipText("");
    insemesterRadio2.setText("����");
    insemesterRadio2.setBounds(new Rectangle(15, 63, 65, 23));
    boxLayout23.setAxis(BoxLayout.Y_AXIS);
    jPanel7.setLayout(null);
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setPreferredSize(new Dimension(614, 400));
    thesisText.setBounds(new Rectangle(116, 81, 223, 24));
    thesisText.setText("");
    thesisText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel34.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel34.setBorder(titledBorder28);
    jPanel34.setBounds(new Rectangle(480, 20, 257, 223));
    jPanel34.setLayout(borderLayout6);
    childrenText.setBounds(new Rectangle(100, 94, 203, 24));
    childrenText.setText("");
    childrenText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel28.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel28.setBounds(new Rectangle(377, 0, 377, 484));
    jPanel28.setLayout(null);
    yearText.setBounds(new Rectangle(136, 147, 55, 24));
    yearText.setText("");
    yearText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel34.setBounds(new Rectangle(22, 65, 79, 20));
    jLabel34.setText("�Ҫվ�������");
    jLabel34.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    detailMonthCombo.setBounds(new Rectangle(52, 63, 122, 25));
    detailMonthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel8.setText("2 :");
    jLabel8.setBounds(new Rectangle(14, 77, 34, 15));
    jLabel21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel21.setText("����ʶҺѹ");
    jLabel21.setBounds(new Rectangle(28, 41, 69, 15));
    jLabel26.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel26.setText("�������Ѿ��");
    jLabel26.setBounds(new Rectangle(74, 78, 84, 15));
    thesisProfCombo1.setBounds(new Rectangle(98, 31, 215, 25));
    thesisProfCombo1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel31.setBorder(titledBorder25);
    jPanel31.setBounds(new Rectangle(31, 26, 521, 191));
    jPanel31.setLayout(null);
    jPanel4.setLayout(borderLayout1);
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel4.setMinimumSize(new Dimension(251, 41));
    jPanel4.setPreferredSize(new Dimension(614, 400));
    jLabel20.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel20.setText("��");
    jLabel20.setBounds(new Rectangle(22, 96, 17, 24));
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("�ٹ�������¹");
    jLabel1.setBounds(new Rectangle(7, 18, 95, 15));
    jPanel25.setLayout(null);
    jPanel25.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel25.setBorder(titledBorder22);
    jPanel25.setBounds(new Rectangle(10, 10, 737, 130));
    thesisProfCombo2.setBounds(new Rectangle(98, 64, 214, 25));
    thesisProfCombo2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel32.setText("�Ҫվ��ô�");
    jLabel32.setBounds(new Rectangle(22, 136, 80, 15));
    thesisProfCombo3.setBounds(new Rectangle(98, 100, 213, 25));
    thesisProfCombo3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setLayout(borderLayout2);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(border3);
    jPanel3.setPreferredSize(new Dimension(760, 400));
    jLabel24.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel24.setText("�ա���֡�ҷ�診");
    jLabel24.setBounds(new Rectangle(28, 152, 109, 15));
    jPanel24.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel24.setBorder(titledBorder15);
    jPanel24.setDebugGraphicsOptions(0);
    jPanel24.setBounds(new Rectangle(216, 106, 126, 126));
    jPanel24.setLayout(null);
    detailDateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    detailDateCombo.setBounds(new Rectangle(123, 31, 51, 25));
    outDateCombo.setBounds(new Rectangle(111, 61, 51, 25));
    outDateCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setLayout(null);
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel5.setOpaque(true);
    jPanel5.setPreferredSize(new Dimension(614, 400));
    professorCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    professorCombo.setBounds(new Rectangle(116, 42, 224, 25));
    salaryText.setText("");
    salaryText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    salaryText.setBounds(new Rectangle(261, 61, 84, 28));
    locationCombo.setBounds(new Rectangle(89, 13, 329, 25));
    locationCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    momOccupationCombo.setBounds(new Rectangle(100, 129, 122, 25));
    momOccupationCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel19.setBounds(new Rectangle(10, 67, 115, 15));
    jLabel19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel19.setRequestFocusEnabled(true);
    jLabel19.setText("�ѹ���");
    jPanel8.setLayout(null);
    jPanel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel8.setPreferredSize(new Dimension(614, 400));
    scholarshipCombo1.setBounds(new Rectangle(31, 35, 146, 25));
    scholarshipCombo1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel22.setBorder(titledBorder13);
    jPanel22.setBounds(new Rectangle(9, 10, 356, 248));
    jPanel22.setLayout(null);
    jLabel11.setBounds(new Rectangle(31, 29, 95, 27));
    jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel11.setText("�Ҩ���� (1)");
    paymentRadio3.setBounds(new Rectangle(28, 75, 188, 23));
    paymentRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio3.setText("¡����ԹʹѺʹع");
    dadOccupationCombo.setBounds(new Rectangle(100, 63, 122, 25));
    dadOccupationCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel7.setText("1 :");
    jLabel7.setBounds(new Rectangle(14, 40, 34, 15));
    jLabel25.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel25.setToolTipText("");
    jLabel25.setText("�������");
    jLabel25.setBounds(new Rectangle(74, 42, 40, 15));
    jPanel17.setLayout(null);
    jPanel17.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel17.setBounds(new Rectangle(17, 10, 346, 484));
    jPanel18.setLayout(null);
    jPanel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel18.setBounds(new Rectangle(377, 0, 377, 484));
    paymentRadio6.setBounds(new Rectangle(29, 155, 174, 23));
    paymentRadio6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio6.setText("¡��鹤��˹��¡Ե/�ԹʹѺʹع");
    jLabel36.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel36.setText("�����ԹʹѺʹع");
    jLabel36.setBounds(new Rectangle(6, 39, 101, 15));
    jPanel21.setLayout(null);
    outMonthCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outMonthCombo.setBounds(new Rectangle(40, 90, 122, 25));
    paymentRadio5.setBounds(new Rectangle(28, 128, 188, 23));
    paymentRadio5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio5.setText("¡��鹷����� (���������)");
    jLabel28.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel28.setToolTipText("");
    jLabel28.setText("�������");
    jLabel28.setBounds(new Rectangle(74, 42, 40, 15));
    jLabel22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel22.setText("�زԡ���֡��");
    jLabel22.setBounds(new Rectangle(28, 75, 86, 15));
    jPanel20.setLayout(null);
    jPanel15.setLayout(null);
    jPanel15.setBounds(new Rectangle(172, 14, 96, 135));
    jPanel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel15.setBorder(titledBorder10);
    jLabel27.setBounds(new Rectangle(74, 78, 84, 15));
    jLabel27.setText("�������Ѿ��");
    jLabel27.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel10.setLayout(null);
    jPanel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel10.setPreferredSize(new Dimension(614, 400));
    jPanel23.setBounds(new Rectangle(1, 10, 351, 250));
    jPanel23.setLayout(null);
    jPanel23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel23.setBorder(titledBorder14);
    jLabel10.setBounds(new Rectangle(7, 79, 112, 27));
    jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel10.setText("��Ǣ���Է�ҹԾ���");
    termText.setText("");
    termText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    termText.setBounds(new Rectangle(104, 32, 62, 28));
    parentTelText.setText("");
    parentTelText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    parentTelText.setBounds(new Rectangle(103, 136, 137, 28));
    jPanel32.setLayout(boxLayout23);
    jPanel32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel32.setBorder(null);
    jPanel32.setPreferredSize(new Dimension(760, 400));
    jPanel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel16.setBorder(titledBorder11);
    jPanel16.setBounds(new Rectangle(283, 43, 276, 164));
    jPanel16.setLayout(null);
    jPanel19.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel19.setBorder(titledBorder12);
    jPanel19.setBounds(new Rectangle(2, 13, 347, 170));
    jPanel19.setLayout(null);
    jLabel40.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel40.setToolTipText("");
    jLabel40.setText("���");
    jLabel40.setBounds(new Rectangle(184, 39, 40, 15));
    instituteText.setBounds(new Rectangle(136, 36, 203, 24));
    instituteText.setText("");
    instituteText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel13.setBorder(titledBorder30);
    jPanel13.setBounds(new Rectangle(7, 43, 274, 164));
    jPanel13.setLayout(null);
    parentText.setBounds(new Rectangle(103, 32, 223, 24));
    parentText.setText("");
    parentText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel9.setLayout(null);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel9.setPreferredSize(new Dimension(614, 400));
    jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel14.setText("��ʹ�");
    jLabel14.setBounds(new Rectangle(22, 139, 59, 15));
    religionText.setText("");
    religionText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    religionText.setBounds(new Rectangle(90, 133, 84, 28));
    jPanel33.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel33.setBorder(titledBorder27);
    jPanel33.setBounds(new Rectangle(244, 20, 229, 224));
    jPanel33.setLayout(null);
    parentAddrText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    parentAddrText.setText("");
    parentAddrText.setBounds(new Rectangle(103, 103, 392, 24));
    jLabel114.setText("��͹");
    jLabel114.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel114.setBounds(new Rectangle(22, 68, 45, 15));
    jPanel30.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel30.setMaximumSize(new Dimension(32767, 32767));
    jPanel30.setBounds(new Rectangle(11, 44, 215, 484));
    jPanel30.setLayout(null);
    jLabel38.setBounds(new Rectangle(20, 108, 42, 15));
    jLabel38.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel38.setText("�������");
    jPanel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel12.setBorder(titledBorder10);
    jPanel12.setBounds(new Rectangle(172, 14, 94, 135));
    jPanel12.setLayout(null);
    jLabel113.setText("�ѹ���");
    jLabel113.setRequestFocusEnabled(true);
    jLabel113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel113.setBounds(new Rectangle(22, 37, 115, 15));
    degreeText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    degreeText.setText("");
    degreeText.setBounds(new Rectangle(136, 70, 204, 24));
    jLabel16.setBounds(new Rectangle(22, 212, 59, 15));
    jLabel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel16.setText("�ѭ�ҵ�");
    nationalityText.setText("");
    nationalityText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    nationalityText.setBounds(new Rectangle(90, 203, 84, 28));
    maleRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    maleRadio.setSelected(true);
    maleRadio.setText("���");
    maleRadio.setBounds(new Rectangle(28, 26, 87, 23));
    jLabel18.setBounds(new Rectangle(10, 67, 115, 15));
    jLabel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel18.setRequestFocusEnabled(true);
    jLabel18.setText("�ѹ���");
    jPanel35.setLayout(null);
    jPanel35.setBounds(new Rectangle(0, 0, 229, 224));
    jPanel35.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel35.setBorder(titledBorder27);
    jLabel17.setBounds(new Rectangle(10, 95, 45, 15));
    jLabel17.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel17.setText("��͹");
    jPanel1.setLayout(flowLayout4);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setPreferredSize(new Dimension(760, 400));
    jPanel1.setInputVerifier(null);
    outsemesterRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outsemesterRadio2.setToolTipText("");
    outsemesterRadio2.setText("����");
    outsemesterRadio2.setBounds(new Rectangle(15, 63, 73, 23));
    jPanel6.setLayout(boxLayout22);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel6.setPreferredSize(new Dimension(614, 400));
    jLabel29.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel29.setText("�Դ�");
    jLabel29.setBounds(new Rectangle(22, 39, 40, 15));
    scholarshipCombo2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    scholarshipCombo2.setBounds(new Rectangle(31, 72, 146, 25));
    jLabel39.setBounds(new Rectangle(20, 143, 81, 15));
    jLabel39.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel39.setText("�������Ѿ��");
    jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel6.setText("�ա���֡��");
    jLabel6.setBounds(new Rectangle(10, 27, 86, 15));
    jPanel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel14.setBorder(titledBorder9);
    jPanel14.setBounds(new Rectangle(560, 43, 186, 164));
    jPanel14.setLayout(null);
    coupleText.setBounds(new Rectangle(100, 34, 203, 24));
    coupleText.setText("");
    coupleText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    gpaText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    gpaText.setText("");
    gpaText.setBounds(new Rectangle(136, 111, 55, 24));
    jTabbedPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jTabbedPane1.setPreferredSize(new Dimension(614, 400));
    jTabbedPane1.setRequestFocusEnabled(true);
    jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel5.setText("��");
    jLabel5.setBounds(new Rectangle(10, 124, 17, 24));
    jLabel4.setBounds(new Rectangle(10, 124, 17, 24));
    jLabel4.setText("��");
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel12.setText("�Ԣ�");
    jLabel12.setBounds(new Rectangle(31, 63, 95, 27));
    jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel12.setText("�Ҩ���� (2)");
    paymentRadio4.setBounds(new Rectangle(28, 102, 188, 23));
    paymentRadio4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio4.setText("¡��鹷�����");
    jLabel33.setBounds(new Rectangle(22, 99, 75, 15));
    jLabel33.setText("�ӹǹ�ص�");
    jLabel33.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    raceText.setText("");
    raceText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    raceText.setBounds(new Rectangle(90, 170, 84, 28));
    jLabel13.setBounds(new Rectangle(31, 99, 95, 27));
    jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel13.setText("�Ҩ���� (3)");
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setText("�ա���֡��");
    jLabel3.setBounds(new Rectangle(10, 27, 86, 15));
    registerTelText.setBounds(new Rectangle(158, 66, 137, 28));
    registerTelText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    registerTelText.setText("");
    recentTelText.setBounds(new Rectangle(158, 66, 137, 28));
    recentTelText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    recentTelText.setText("");
    jLabel30.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel30.setText("��ô�");
    jLabel30.setBounds(new Rectangle(22, 99, 40, 15));
    paymentRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    paymentRadio2.setText("¡��鹤��˹��¡Ե");
    paymentRadio2.setBounds(new Rectangle(28, 48, 188, 23));
    momText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    momText.setText("");
    momText.setBounds(new Rectangle(100, 94, 203, 24));
    femaleRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    femaleRadio.setText("˭ԧ");
    femaleRadio.setBounds(new Rectangle(28, 68, 90, 23));
    jPanel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel11.setForeground(Color.black);
    jPanel11.setPreferredSize(new Dimension(614, 400));
    jPanel11.setLayout(null);
    outsemesterRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outsemesterRadio3.setText("Ĵ���͹");
    outsemesterRadio3.setBounds(new Rectangle(15, 93, 69, 23));
    dadText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    dadText.setText("");
    dadText.setBounds(new Rectangle(100, 34, 203, 24));
    jLabel112.setBounds(new Rectangle(185, 68, 59, 15));
    jLabel112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel112.setRequestFocusEnabled(true);
    jLabel112.setText("�Թ��͹");
    registerAddrText.setText("");
    registerAddrText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    registerAddrText.setBounds(new Rectangle(158, 31, 510, 28));
    jPanel29.setLayout(null);
    jPanel29.setBounds(new Rectangle(18, 9, 325, 195));
    jPanel29.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel29.setBorder(titledBorder31);
    jRadioButton12.setBounds(new Rectangle(28, 49, 188, 23));
    jRadioButton12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jRadioButton12.setText("¡��鹤��˹��¡Ե");
    outsemesterRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    outsemesterRadio1.setSelected(true);
    outsemesterRadio1.setText("��");
    outsemesterRadio1.setBounds(new Rectangle(15, 29, 72, 23));
    jLabel110.setBounds(new Rectangle(10, 95, 45, 15));
    jLabel110.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel110.setText("��͹");
    jLabel31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel31.setText("�Ҫվ�Դ�");
    jLabel31.setBounds(new Rectangle(22, 65, 77, 20));
    jLabel15.setBounds(new Rectangle(22, 177, 59, 15));
    jLabel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel15.setText("���ͪҵ�");
    inYearText.setText("");
    inYearText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    inYearText.setBounds(new Rectangle(78, 121, 84, 28));
    jPanel44.setLayout(borderLayout4);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    saveButton.setMaximumSize(new Dimension(80, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setSelected(false);
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new StudentUI_saveButton_actionAdapter(this));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    clearButton.setMaximumSize(new Dimension(80, 25));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setText("������");
    clearButton.addActionListener(new StudentUI_clearButton_actionAdapter(this));
    jPanel45.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel20.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel44.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio2.setText("�������������¹");
    preRadio3.setText("�͹˹��¡Ե");
    preRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio6.setText("Retire");
    preRadio6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio7.setText("���¹�ú�����ѡ�ٵ�");
    preRadio4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio4.setText("�š�����¹�������ó� (�Դ I )");
    preRadio5.setText("Probation");
    preRadio5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio5.setToolTipText("");
    jPanel2.setLayout(verticalFlowLayout1);
    preRadio8.setText("��ҧ���Ф��ŧ����¹ (������) ������");
    preRadio8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio9.setText("��ҧ�����Թ���ʹѺʹع/�Թ�ش˹ع");
    preRadio9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    preRadio1.setSelected(true);
    preRadio1.setText("����");
    bookCheckBox.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    bookCheckBox.setActionCommand("jCheckBox1");
    bookCheckBox.setText("��ҧ˹ѧ�����ͧ��ش");
    bookCheckBox.setBounds(new Rectangle(30, 80, 175, 23));
    interCheckBox.setBounds(new Rectangle(30, 105, 175, 23));
    interCheckBox.setText("�繹ѡ�֡�ҵ�ҧ�ҵ�");
    interCheckBox.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    interCheckBox.setActionCommand("jCheckBox1");
    relationText.setBounds(new Rectangle(103, 64, 137, 28));
    relationText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    relationText.setText("");
    phDRadio.setText("�͡");
    phDRadio.setBounds(new Rectangle(6, 21, 94, 23));
    phDRadio.addActionListener(new StudentUI_phDRadio_actionAdapter(this));
    phDRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    phDRadio.setSelected(true);
    masterRadio.setText("�");
    masterRadio.setBounds(new Rectangle(6, 44, 94, 24));
    masterRadio.addActionListener(new StudentUI_masterRadio_actionAdapter(this));
    masterRadio.setToolTipText("");
    masterRadio.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    degreeTypeCombo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    degreeTypeCombo.setBounds(new Rectangle(11, 68, 84, 21));
    jPanel46.setLayout(verticalFlowLayout2);
    studyGroupRadio5.setText("��ѡ�ٵùҹҪҵ�");
    studyGroupRadio5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyGroupRadio5.setToolTipText("");
    studyGroupRadio5.setActionCommand("��ѡ�ٵùҹҪҵ�");
    studyGroupRadio3.setText("�Ҥ����� (�����-�ҷԵ��)");
    studyGroupRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyGroupRadio3.setToolTipText("");
    studyGroupRadio4.setToolTipText("");
    studyGroupRadio4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyGroupRadio4.setText("�Ҥ����� (�͡�����Ҫ���)");
    studyGroupRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyGroupRadio1.setToolTipText("");
    studyGroupRadio1.setSelected(true);
    studyGroupRadio1.setText("�Ҥ����");
    studyGroupRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    studyGroupRadio2.setText("�Ҥ����");
    this.add(jPanel41, BorderLayout.NORTH);
    jPanel41.add(jPanel43, null);
    jPanel43.add(jLabel51, BorderLayout.NORTH);
    jPanel41.add(studentIDText, null);
    jPanel41.add(jLabel44, null);
    jPanel41.add(jPanel36, null);
    jPanel36.add(jLabel45, null);
    jPanel36.add(tprenameCombo, null);
    jPanel36.add(enameText, null);
    jPanel36.add(jLabel50, null);
    jPanel36.add(tnameText, null);
    jPanel36.add(jLabel49, null);
    jPanel36.add(jLabel48, null);
    jPanel36.add(eprenameText, null);
    jPanel38.add(degreeTypeCombo, null);
    jPanel38.add(masterRadio, null);
    jPanel38.add(phDRadio, null);
    jPanel41.add(jPanel42, null);
    jPanel42.add(statusRadio1, null);
    jPanel42.add(statusRadio3, null);
    jPanel42.add(statusRadio2, null);
    jPanel41.add(jPanel39, null);
    jPanel41.add(jPanel37, null);
    jPanel37.add(testTypeRadio, null);
    jPanel37.add(normalTypeRadio, null);
    jPanel41.add(jPanel40, null);
    jPanel40.add(jLabel46, null);
    jPanel40.add(jLabel43, null);
    jPanel40.add(jLabel42, null);
    jPanel40.add(jLabel47, null);
    jPanel40.add(facultyCombo, null);
    jPanel40.add(departmentCombo, null);
    jPanel40.add(minorCombo, null);
    jPanel40.add(majorCombo, null);
    jPanel41.add(jPanel38, null);
    this.add(jPanel44,  BorderLayout.CENTER);
    jPanel44.add(jPanel32, BorderLayout.CENTER);
    jPanel32.add(jPanel1, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(jTabbedPane1,  BorderLayout.CENTER);
    jPanel17.add(professorCombo, null);
    jPanel17.add(thesisText, null);
    jPanel17.add(jLabel9, null);
    jPanel17.add(jLabel10, null);
    jPanel5.add(jPanel18, null);
    jPanel18.add(jPanel19, null);
    jPanel5.add(jPanel17, null);
    jPanel19.add(thesisProfCombo2, null);
    jPanel19.add(jLabel11, null);
    jPanel19.add(thesisProfCombo1, null);
    jPanel19.add(jLabel12, null);
    jPanel19.add(thesisProfCombo3, null);
    jPanel19.add(jLabel13, null);
    jTabbedPane1.add(jPanel4, "�����š���֡��");
    jTabbedPane1.add(jPanel5, "�Է�ҹԾ���");
    jPanel4.add(jPanel11, BorderLayout.NORTH);
    jPanel14.add(jLabel8, null);
    jPanel14.add(jLabel7, null);
    jPanel14.add(scholarshipCombo1, null);
    jPanel14.add(scholarshipCombo2, null);
    jPanel13.add(jLabel3, null);
    jPanel13.add(jLabel18, null);
    jPanel13.add(jLabel17, null);
    jPanel13.add(jLabel4, null);
    jPanel13.add(inDateCombo, null);
    jPanel13.add(inMonthCombo, null);
    jPanel13.add(inYearText, null);
    jPanel13.add(inbeText, null);
    jPanel13.add(jPanel12, null);
    jPanel12.add(insemesterRadio3, null);
    jPanel12.add(insemesterRadio2, null);
    jPanel12.add(insemesterRadio1, null);
    jPanel16.add(jLabel6, null);
    jPanel16.add(jLabel19, null);
    jPanel16.add(jLabel110, null);
    jPanel16.add(jLabel5, null);
    jPanel16.add(outDateCombo, null);
    jPanel16.add(outMonthCombo, null);
    jPanel16.add(outYearText, null);
    jPanel16.add(outbeText, null);
    jPanel16.add(jPanel15, null);
    jPanel15.add(outsemesterRadio3, null);
    jPanel15.add(outsemesterRadio2, null);
    jPanel15.add(outsemesterRadio1, null);
    jPanel11.add(jPanel14, null);
    jPanel11.add(jPanel13, null);
    jPanel11.add(jLabel1, null);
    jPanel11.add(locationCombo, null);
    jPanel11.add(jPanel16, null);
    jTabbedPane1.add(jPanel6, "����ѵԹѡ�֡��");
    jPanel23.add(jLabel22, null);
    jPanel23.add(jLabel21, null);
    jPanel23.add(jLabel24, null);
    jPanel23.add(jLabel23, null);
    jPanel23.add(instituteText, null);
    jPanel23.add(degreeText, null);
    jPanel23.add(gpaText, null);
    jPanel23.add(yearText, null);
    jPanel6.add(jPanel20, null);
    jPanel20.add(jPanel22, null);
    jPanel6.add(jPanel21, null);
    jPanel21.add(jPanel23, null);
    jPanel22.add(jLabel16, null);
    jPanel22.add(jLabel15, null);
    jPanel22.add(jLabel14, null);
    jPanel22.add(jLabel20, null);
    jPanel22.add(jLabel114, null);
    jPanel22.add(jLabel113, null);
    jPanel22.add(detailDateCombo, null);
    jPanel22.add(detailMonthCombo, null);
    jPanel22.add(detailYearText, null);
    jPanel22.add(religionText, null);
    jPanel22.add(raceText, null);
    jPanel22.add(nationalityText, null);
    jPanel22.add(jLabel111, null);
    jPanel22.add(jLabel112, null);
    jPanel22.add(detailOccupationCombo, null);
    jPanel22.add(salaryText, null);
    jPanel22.add(jPanel24, null);
    jPanel24.add(maleRadio, null);
    jPanel24.add(femaleRadio, null);
    jTabbedPane1.add(jPanel7, "�������ѡ�֡��");
    jPanel26.add(jLabel28, null);
    jPanel26.add(jLabel27, null);
    jPanel26.add(recentAddrText, null);
    jPanel26.add(recentTelText, null);
    jPanel7.add(jPanel25, null);
    jPanel7.add(jPanel26, null);
    jPanel25.add(jLabel25, null);
    jPanel25.add(jLabel26, null);
    jPanel25.add(registerAddrText, null);
    jPanel25.add(registerTelText, null);
    jTabbedPane1.add(jPanel8, "�������Ǣ�ͧ");
    jPanel27.add(jLabel29, null);
    jPanel27.add(jLabel31, null);
    jPanel27.add(jLabel30, null);
    jPanel27.add(momText, null);
    jPanel27.add(dadOccupationCombo, null);
    jPanel27.add(momOccupationCombo, null);
    jPanel27.add(dadText, null);
    jPanel27.add(jLabel32, null);
    jPanel8.add(jPanel28, null);
    jPanel28.add(jPanel29, null);
    jPanel8.add(jPanel27, null);
    jPanel29.add(jLabel210, null);
    jPanel29.add(jLabel34, null);
    jPanel29.add(jLabel33, null);
    jPanel29.add(childrenText, null);
    jPanel29.add(coupleOccupationCombo, null);
    jPanel29.add(coupleText, null);
    jTabbedPane1.add(jPanel9, "��黡��ͧ");
    jPanel9.add(jPanel31, null);
    jPanel31.add(jLabel35, null);
    jPanel31.add(jLabel37, null);
    jPanel31.add(jLabel38, null);
    jPanel31.add(jLabel39, null);
    jPanel31.add(parentText, null);
    jPanel31.add(parentAddrText, null);
    jPanel31.add(parentTelText, null);
    jPanel31.add(relationText, null);
    jTabbedPane1.add(jPanel10, "���ŧ����¹");
    jPanel10.add(jPanel33, null);
    jPanel33.add(paymentRadio1, null);
    jPanel33.add(jPanel35, null);
    jPanel35.add(jRadioButton112, null);
    jPanel35.add(paymentRadio2, null);
    jPanel35.add(paymentRadio3, null);
    jPanel35.add(paymentRadio4, null);
    jPanel35.add(paymentRadio5, null);
    jPanel35.add(paymentRadio6, null);
    jPanel33.add(jRadioButton12, null);
    jPanel2.add(preRadio1, null);
    jPanel2.add(preRadio2, null);
    jPanel2.add(preRadio3, null);
    jPanel2.add(preRadio4, null);
    jPanel2.add(preRadio5, null);
    jPanel2.add(preRadio6, null);
    jPanel2.add(preRadio7, null);
    jPanel2.add(preRadio8, null);
    jPanel2.add(preRadio9, null);
    jPanel10.add(jPanel30, null);
    jPanel30.add(termText, null);
    jPanel30.add(jLabel40, null);
    jPanel30.add(jLabel36, null);
    jPanel10.add(jPanel34, null);
    jPanel34.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jPanel2, null);
    this.add(jPanel45,  BorderLayout.SOUTH);
    jPanel45.add(saveButton, null);
    jPanel45.add(clearButton, null);
    jPanel30.add(bookCheckBox, null);
    jPanel30.add(interCheckBox, null);
    buttonGroup1.add(phDRadio);
    buttonGroup1.add(masterRadio);
    buttonGroup2.add(normalTypeRadio);
    buttonGroup2.add(testTypeRadio);
    buttonGroup4.add(statusRadio1);
    buttonGroup4.add(statusRadio2);
    buttonGroup4.add(statusRadio3);
    buttonGroup4.add(statusRadio4);
    buttonGroup4.add(statusRadio5);
    buttonGroup5.add(insemesterRadio1);
    buttonGroup5.add(insemesterRadio2);
    buttonGroup5.add(insemesterRadio3);
    buttonGroup6.add(outsemesterRadio1);
    buttonGroup6.add(outsemesterRadio2);
    buttonGroup6.add(outsemesterRadio3);
    buttonGroup7.add(maleRadio);
    buttonGroup7.add(femaleRadio);
    buttonGroup8.add(paymentRadio1);
    buttonGroup8.add(paymentRadio2);
    buttonGroup8.add(paymentRadio3);
    buttonGroup8.add(paymentRadio4);
    buttonGroup8.add(paymentRadio5);
    buttonGroup8.add(paymentRadio6);
    buttonGroup9.add(preRadio1);
    buttonGroup9.add(preRadio2);
    buttonGroup9.add(preRadio3);
    buttonGroup9.add(preRadio4);
    buttonGroup9.add(preRadio5);
    buttonGroup9.add(preRadio6);
    buttonGroup9.add(preRadio7);
    buttonGroup9.add(preRadio8);
    buttonGroup9.add(preRadio9);
    jPanel39.add(jScrollPane2,  BorderLayout.CENTER);
    jScrollPane2.getViewport().add(jPanel46, null);
    jPanel46.add(studyGroupRadio1, null);
    jPanel46.add(studyGroupRadio2, null);
    jPanel46.add(studyGroupRadio3, null);
    jPanel46.add(studyGroupRadio4, null);
    jPanel46.add(studyGroupRadio5, null);
    jPanel42.add(statusRadio4, null);
    jPanel42.add(statusRadio5, null);
    buttonGroup3.add(studyGroupRadio1);
    buttonGroup3.add(studyGroupRadio2);
    buttonGroup3.add(studyGroupRadio3);
    buttonGroup3.add(studyGroupRadio4);
    buttonGroup3.add(studyGroupRadio5);
    initialize();
  }
  public void clear(){
    clearCombo();
    clearRadio();
    clearTextBox();
  }
  public void initialize(){
    displayDegreeCombo();
    Database.connect();
    //----------------------------------------------------------------------Prename Combo---------------------------------------------------------------------
    Prename prename = new Prename();
    Vector v = prename.retrievePrename();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Prename pre  = (Prename)e.nextElement();
      tprenameCombo.addItem(pre);
    }
    //------------------------------------------------------------------------Location Combo-------------------------------------------------------------------
    Location location = new Location();
    v = location.retrieveLocation();
    e = v.elements();
    while (e.hasMoreElements()){
      Location loc = (Location)e.nextElement();
      locationCombo.addItem(loc);
    }
    //----------------------------------------------------------------------Scholarship Combo----------------------------------------------------------------
    Scholarship scholarship = new Scholarship();
    v = scholarship.retrieveScholarship();
    e = v.elements();
    while (e.hasMoreElements()){
      Scholarship ss = (Scholarship)e.nextElement();
      scholarshipCombo1.addItem(ss);
      scholarshipCombo2.addItem(ss);
    }
    //-----------------------------------------------------------------------Occupation Combo----------------------------------------------------------------
    Occupation occupation = new Occupation();
    v = occupation.retrieveOccupation();
    e = v.elements();
    while (e.hasMoreElements()){
      Occupation occ = (Occupation)e.nextElement();
      detailOccupationCombo.addItem(occ);
      dadOccupationCombo.addItem(occ);
      momOccupationCombo.addItem(occ);
      coupleOccupationCombo.addItem(occ);
    }
    //------------------------------------------------------------------------Faculty Combo----------------------------------------------------------------------
    Faculty faculty = new Faculty();
    Department department = new Department();
    Major major = new Major();
    Minor minor = new Minor();
    facultyVector = faculty.retrieveFaculty();
    Enumeration facultyEnum = facultyVector.elements();
    while (facultyEnum.hasMoreElements()){
      Faculty fac = (Faculty)facultyEnum.nextElement();
      facultyCombo.addItem(fac);
      Vector departmentVector = department.retrieveDepartment(fac);
      Enumeration departmentEnum = departmentVector.elements();
      while (departmentEnum.hasMoreElements()){
        Department dep = (Department)departmentEnum.nextElement();
        departmentCombo.addItem(dep);
        Vector majorVector = major.retrieveMajor(dep);
        Enumeration majorEnum = majorVector.elements();
        while (majorEnum.hasMoreElements()){
          Major maj = (Major)majorEnum.nextElement();
          majorCombo.addItem(maj);
          Vector minorVector = minor.retrieveMinor(maj);
          Enumeration minorEnum = minorVector.elements();
          while (minorEnum.hasMoreElements()){
            Minor min = (Minor)minorEnum.nextElement();
            minorCombo.addItem(min);
          }
        }
      }
    }
    clearCombo();
    Database.disconnect();
  }

  public void clearCombo(){
    inDateCombo.setSelectedItem(null);
    inMonthCombo.setSelectedItem(null);
    outDateCombo.setSelectedItem(null);
    outMonthCombo.setSelectedItem(null);
    detailDateCombo.setSelectedItem(null);
    detailMonthCombo.setSelectedItem(null);
    tprenameCombo.setSelectedItem(null);
    locationCombo.setSelectedItem(null);
    scholarshipCombo1.setSelectedItem(null);
    scholarshipCombo2.setSelectedItem(null);
    detailOccupationCombo.setSelectedItem(null);
    dadOccupationCombo.setSelectedItem(null);
    momOccupationCombo.setSelectedItem(null);
    coupleOccupationCombo.setSelectedItem(null);
    facultyCombo.setSelectedItem(null);
    departmentCombo.setSelectedItem(null);
    majorCombo.setSelectedItem(null);
    minorCombo.setSelectedItem(null);
  }
  public void clearRadio(){
    phDRadio.setSelected(true);
    displayDegreeCombo();
    normalTypeRadio.setSelected(true);
    studyGroupRadio1.setSelected(true);;
    statusRadio1.setSelected(true);
    insemesterRadio1.setSelected(true);
    outsemesterRadio1.setSelected(true);
    maleRadio.setSelected(true);
    paymentRadio1.setSelected(true);
    preRadio1.setSelected(true);
  }
  public void clearTextBox(){
    studentIDText.setText("");
    tnameText.setText("");
    eprenameText.setText("");
    enameText.setText("");
//    adoptDateText.setText("");
    inbeText.setText("");
    outbeText.setText("");
    inYearText.setText("");
    outYearText.setText("");
    thesisText.setText("");
    detailYearText.setText("");
    religionText.setText("");
    raceText.setText("");
    nationalityText.setText("");
    salaryText.setText("");
    instituteText.setText("");
    degreeText.setText("");
    gpaText.setText("");
    yearText.setText("");
    registerAddrText.setText("");
    registerTelText.setText("");
    recentAddrText.setText("");
    recentTelText.setText("");
    dadText.setText("");
    momText.setText("");
    coupleText.setText("");
    childrenText.setText("");
    parentText.setText("");
    relationText.setText("");
    parentAddrText.setText("");
    termText.setText("");
  }
  public void displayDegreeCombo(){
    degreeTypeCombo.removeAllItems();
    if (phDRadio.isSelected()){
      for (int i=0;i<4; i++){
        degreeTypeCombo.addItem(deg[i]);
      }
    }
    else {
      for (int i=4;i<7;i++){
        degreeTypeCombo.addItem(deg[i]);
      }
    }
  }
  public void setSelectedCombo(JComboBox cb,Object obj){
    for (int i=0; i<cb.getItemCount(); ++i){
      if (obj instanceof Prename){
        Prename item = (Prename)cb.getItemAt(i);
        Prename objItem = (Prename)obj;
        if (item.getTPrename().trim().equals(objItem.getTPrename())){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof String){
        String item = (String)cb.getItemAt(i);
        String objItem = (String)obj;
        if (item.trim().equals(objItem)){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Location){
       Location item = (Location)cb.getItemAt(i);
       Location objItem = (Location)obj;
       if (item.getLocationID() == objItem.getLocationID())
       {
          cb.setSelectedItem(item);
          return;
       }
      }
      else if (obj instanceof Scholarship){
        Scholarship item = (Scholarship)cb.getItemAt(i);
        Scholarship objItem = (Scholarship)obj;
        if (item.getID() == objItem.getID()){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Occupation){
        Occupation item = (Occupation)cb.getItemAt(i);
        Occupation objItem = (Occupation)obj;
        if (item.getOccupationID() == objItem.getOccupationID()){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Faculty){
        Faculty item = (Faculty)cb.getItemAt(i);
        Faculty objItem = (Faculty)obj;
        if (item.getFacultyID().trim().equals(objItem.getFacultyID())){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Department){
        Department item = (Department)cb.getItemAt(i);
        Department objItem = (Department)obj;
        if (item.getDepartmentID().trim().equals(objItem.getDepartmentID())){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Major){
        Major item = (Major)cb.getItemAt(i);
        Major objItem = (Major)obj;
        if (item.getMajorID().trim().equals(objItem.getMajorID())){
          cb.setSelectedItem(item);
          return;
        }
      }
      else if (obj instanceof Minor){
        Minor item = (Minor)cb.getItemAt(i);
        Minor objItem = (Minor)obj;
        if (item.getMinorID().trim().equals(objItem.getMinorID())){
          cb.setSelectedItem(item);
          return;
        }
      }
    }
  }
  public void setDegreeRadio(Student student){
    int degree = student.getDegree();
    switch (degree){
      case 1: case 2: case 3: case 4:
        phDRadio.setSelected(true);
        break;
      case 5: case 6: case 7:
        masterRadio.setSelected(true);
        break;
      default : break;
    }
    displayDegreeCombo();
    setSelectedCombo(degreeTypeCombo,deg[degree-1]);
  }

  void studentIDText_actionPerformed(ActionEvent e) {
    Database.connect();
    student = student.retrieveStudent(new Student(studentIDText.getText().trim()));
    Database.disconnect();

    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    if (student == null) {
      newRecord = true;
      clear();
      JOptionPane.showConfirmDialog(this,"��������ʹѡ�֡�ҹ�� ��ͧ������������Źѡ�֡�����������","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (student != null){
      newRecord = false;
      setDegreeRadio(student);

      int studentType = student.getStudentType();
      if (studentType == 1)
        normalTypeRadio.setSelected(true);
      else
        testTypeRadio.setSelected(true);

      int studyGroup = student.getStudyGroup();
      switch (studyGroup){
        case 1: studyGroupRadio1.setSelected(true); break;
        case 2: studyGroupRadio2.setSelected(true); break;
        case 3: studyGroupRadio3.setSelected(true); break;
        case 4: studyGroupRadio4.setSelected(true); break;
        case 5: studyGroupRadio5.setSelected(true); break;
        default: break;
      }

      int status = student.getStatus();
      switch (status){
        case 1: statusRadio1.setSelected(true); break;
        case 2: statusRadio2.setSelected(true); break;
        case 3: statusRadio3.setSelected(true); break;
        case 4: statusRadio4.setSelected(true); break;
        case 5: statusRadio5.setSelected(true); break;
        default: break;
      }

      setSelectedCombo(tprenameCombo,student.getPrename());
      tnameText.setText(student.getStudentTname());
      eprenameText.setText(student.getPrename().getEprename());
      enameText.setText(student.getStudentEname());

      setSelectedCombo(majorCombo,student.getMajor());
      setSelectedCombo(minorCombo,student.getMinor());
      setSelectedCombo(departmentCombo,student.getMajor().getDepartment());
      setSelectedCombo(facultyCombo,student.getMajor().getDepartment().getFaculty());

      setSelectedCombo(locationCombo,student.getLocation());
/*      if (student.getAdoptDate() == null) adoptDateText.setText("");
      else adoptDateText.setText(formatter.format(student.getAdoptDate()));*/
      if (student.getEntraceDate() != null) {
        int date = student.getEntraceDate().getDate();
        int month = student.getEntraceDate().getMonth();
        int year = student.getEntraceDate().getYear() + 1900 + 543+543;
        setSelectedCombo(inDateCombo, Integer.toString(date));
        inMonthCombo.setSelectedIndex(month);
        inbeText.setText(Integer.toString(year));
      }

      int date = student.getEntraceSemester().getYear() ;
      inYearText.setText(Integer.toString(date));

      if (student.getLeaveDate() != null){
        int day = student.getLeaveDate().getDate();
        int month = student.getLeaveDate().getMonth();
        int year = student.getLeaveDate().getYear()+1900+543;
        setSelectedCombo(outDateCombo,Integer.toString(day));
        outMonthCombo.setSelectedIndex(month);
        outbeText.setText(Integer.toString(year));
        date = student.getLeaveSemester().getYear();
        outYearText.setText(Integer.toString(date));
      }

      if (student.getBirthday() != null){
        int day = student.getBirthday().getDate();
        int month = student.getBirthday().getMonth();
        int year = student.getBirthday().getYear()+1900+543+543 ;
        setSelectedCombo(detailDateCombo,Integer.toString(day));
        detailMonthCombo.setSelectedIndex(month);
        detailYearText.setText(Integer.toString(year));
      }

      if (student.getOccupation() != null)
        setSelectedCombo(detailOccupationCombo,student.getOccupation());
      religionText.setText(student.getReligion());
      raceText.setText(student.getRace());
      nationalityText.setText(student.getNationality());
      salaryText.setText(Double.toString(student.getSalary()));
      if (student.getGender() == null || student.getGender().trim().equals(""))
        maleRadio.setSelected(true);
      if (student.getGender(). trim().equals("m"))
        maleRadio.setSelected(true);
      else
        femaleRadio.setSelected(true);
      instituteText.setText(student.getOldInstitute());
      degreeText.setText(student.getOldDegree());
      gpaText.setText(Double.toString(student.getOldGPA()));
      yearText.setText(Integer.toString(student.getOldLeaveYear()));
      registerAddrText.setText(student.getRegisterAddess());
      registerTelText.setText(student.getRegisterTel());
      recentAddrText.setText(student.getRecentAddress());
      recentTelText.setText(student.getRecentTel());
      dadText.setText(student.getFatherName());
      if (student.getFatherOccupation() != null)
        setSelectedCombo(dadOccupationCombo,student.getFatherOccupation());
      momText.setText(student.getMotherName());
      if (student.getMotherOccupation() != null)
        setSelectedCombo(momOccupationCombo,student.getMotherOccupation());
      coupleText.setText(student.getCoupleName());
      if (student.getCoupleOccupation() != null)
        setSelectedCombo(coupleOccupationCombo,student.getCoupleOccupation());
      childrenText.setText(Integer.toString(student.getChildren()));
      parentText.setText(student.getParentName());
      relationText.setText(student.getRelation());
      parentAddrText.setText(student.getParentAddress());
      parentTelText.setText(student.getParentTel());
      termText.setText(Integer.toString(student.getNoSupportTerm()));
      bookCheckBox.setSelected(student.getLibraryStatus());
      interCheckBox.setSelected(student.getNationalStatus());

      int pay = student.getPaymentCondition();
      switch (pay){
        case 1: paymentRadio1.setSelected(true); break;
        case 2: paymentRadio2.setSelected(true); break;
        case 3: paymentRadio3.setSelected(true); break;
        case 4: paymentRadio4.setSelected(true); break;
        case 5: paymentRadio5.setSelected(true); break;
        case 6: paymentRadio6.setSelected(true); break;
        default : break;
      }

      int pre = student.getRegisterStatus();
      switch (pre){
        case 1: preRadio1.setSelected(true); break;
        case 2: preRadio2.setSelected(true); break;
        case 3: preRadio3.setSelected(true); break;
        case 4: preRadio4.setSelected(true); break;
        case 5: preRadio5.setSelected(true); break;
        case 6: preRadio6.setSelected(true); break;
        case 7: preRadio7.setSelected(true); break;
        case 8: preRadio8.setSelected(true); break;
        case 9: preRadio9.setSelected(true); break;
        default : break;
      }
    }
  }

  void phDRadio_actionPerformed(ActionEvent e) {
    displayDegreeCombo();
  }

  void masterRadio_actionPerformed(ActionEvent e) {
    displayDegreeCombo();
  }

  void facultyCombo_actionPerformed(ActionEvent e) {
    Faculty faculty = (Faculty)facultyCombo.getSelectedItem();
    if (faculty != null){
      departmentCombo.removeAllItems();
      Enumeration depEnum = faculty.retrieveDepartment();
      while (depEnum.hasMoreElements()){
        Department dep = (Department)depEnum.nextElement();
        departmentCombo.addItem(dep);
      }
    }
  }

  void departmentCombo_actionPerformed(ActionEvent e) {
    Department department = (Department)departmentCombo.getSelectedItem();
    if (department != null){
      majorCombo.removeAllItems();
      Enumeration majorEnum = department.retrieveMajor();
      while (majorEnum.hasMoreElements()){
        Major major = (Major)majorEnum.nextElement();
        majorCombo.addItem(major);
      }
    }
  }

  void majorCombo_actionPerformed(ActionEvent e) {
    Major major = (Major)majorCombo.getSelectedItem();
    if (major != null){
      minorCombo.removeAllItems();
      Enumeration minorEnum = major.retrieveMinor();
      while (minorEnum.hasMoreElements()){
        Minor min = (Minor)minorEnum.nextElement();
        minorCombo.addItem(min);
      }
    }
  }

  void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }

  void saveButton_actionPerformed(ActionEvent e) { //SAVE BUTTON
    boolean complete = false;
    Student student = new Student();

    student.setStudentID(studentIDText.getText().trim());
    boolean out = false;
    for (int i=0;i<7&& !out;i++){
      String str = (String)degreeTypeCombo.getSelectedItem();
      if (str.equals(deg[i])) {
          out = true;
          student.setDegree(i+1);
      }
    }

    if (normalTypeRadio.isSelected()){
      student.setStudentType(1);
    }
    else {
      student.setStudentType(2);
    }

    if (studyGroupRadio1.isSelected())
      student.setStudyGroup(1);
    else if (studyGroupRadio2.isSelected())
      student.setStudyGroup(2);
    else if (studyGroupRadio3.isSelected())
      student.setStudyGroup(3);
    else if (studyGroupRadio4.isSelected())
      student.setStudyGroup(4);
    else if (studyGroupRadio5.isSelected())
      student.setStudyGroup(5);

    if (statusRadio1.isSelected())
      student.setStatus(1);
    else if (statusRadio2.isSelected())
      student.setStatus(2);
    else if (statusRadio3.isSelected())
      student.setStatus(3);
    else if (statusRadio4.isSelected())
      student.setStatus(4);
    else if (statusRadio5.isSelected())
      student.setStatus(5);

    if (tprenameCombo.getSelectedItem() == null) {
      JOptionPane.showMessageDialog(this,"��س����͡�ӹ�˹�Ҫ���","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    student.setPrename((Prename)tprenameCombo.getSelectedItem());
    student.setStudentTname(tnameText.getText());
    student.setStudentEname(enameText.getText());
    student.setMajor((Major)majorCombo.getSelectedItem());
    Minor minor = (Minor)minorCombo.getSelectedItem();
    if (minor != null) student.setMinor(minor);
    else student.setMinor(new Minor());
    Location location = (Location)locationCombo.getSelectedItem();
    if (location != null) student.setLocation(location);
    else student.setLocation(new Location());

    if (inDateCombo.getSelectedItem() != null && outMonthCombo.getSelectedItem() != null && !inbeText.getText().equals("")){
      int date = inDateCombo.getSelectedIndex() + 1;
      int month = inMonthCombo.getSelectedIndex();
      int year = Integer.parseInt(inbeText.getText())+543;
      GregorianCalendar g = new GregorianCalendar(year,month,date);
      java.util.Date d = g.getTime();
      student.setEntranceDate(d);
    }
    student.setEntraceSemester(new Semester());
    if (inDateCombo.getSelectedItem() != null && outMonthCombo.getSelectedItem() != null && !inbeText.getText().equals("")){
      int date = outDateCombo.getSelectedIndex() + 1;
      int month = outMonthCombo.getSelectedIndex();
      int year = Integer.parseInt(outbeText.getText()) +543;
      GregorianCalendar g = new GregorianCalendar(year, month, date);
      java.util.Date d = g.getTime();
      student.setLeaveDate(d);
    }
    student.setLeaveSemester(new Semester());
    if (detailDateCombo.getSelectedItem() != null && detailMonthCombo.getSelectedItem() != null && !detailYearText.getText().equals("")){
      int date = detailDateCombo.getSelectedIndex() + 1;
      int month = detailMonthCombo.getSelectedIndex();
      int year = Integer.parseInt(detailYearText.getText()) + 543;
      GregorianCalendar g = new GregorianCalendar(year, month, date);
      java.util.Date d = g.getTime();
      student.setBirthday(d);
    }

    student.setReligion(religionText.getText());
    student.setRace(raceText.getText());
    student.setNationality(nationalityText.getText());
    if (detailOccupationCombo.getSelectedItem() != null);
    student.setOccupation((Occupation)detailOccupationCombo.getSelectedItem());
//    student.setSalary(Double.parseDouble(salaryText.getText()));
    if (maleRadio.isSelected())
      student.setGender("m");
    else
      student.setGender("F");
    student.setOldInstitute(instituteText.getText());
    student.setOldDegree(degreeText.getText());
//    student.setOldGPA(Double.parseDouble(gpaText.getText()));
    student.setOldInstitute(yearText.getText());;
    student.setRegisterAddress(registerAddrText.getText());
    student.setRegisterTel(registerTelText.getText());
    student.setRecentAddress(recentAddrText.getText());
    student.setRecentTel(recentTelText.getText());
    student.setFatherName(dadText.getText());
    if (dadOccupationCombo.getSelectedItem() != null)
      student.setFatherOccupation((Occupation)dadOccupationCombo.getSelectedItem());
    else student.setFatherOccupation(new Occupation());
    student.setMotherName(momText.getText());
    if (momOccupationCombo.getSelectedItem() != null)
      student.setMotherOccupation((Occupation)momOccupationCombo.getSelectedItem());
    else student.setMotherOccupation(new Occupation());
    student.setCoupleName(coupleText.getText());
    if (coupleOccupationCombo.getSelectedItem() != null)
      student.setCoupleOccupation((Occupation)coupleOccupationCombo.getSelectedItem());
    else student.setCoupleOccupation(new Occupation());
//    student.setChildren(Integer.parseInt(childrenText.getText()));
    student.setParentName(parentText.getText());
    student.setRelation(relationText.getText());
    student.setParentAddress(parentAddrText.getText());
    student.setParentTel(parentTelText.getText());

    try {
//      student.setNoSupportTerm(Integer.parseInt(termText.getText()));
    }
    catch (NumberFormatException ne){
      JOptionPane.showMessageDialog(this,"��س����������繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
    }

    student.setLibraryStatus(bookCheckBox.isSelected());
    student.setNationalStatus(interCheckBox.isSelected());

    if (paymentRadio1.isSelected())
      student.setPaymentCondition(1);
    else if (paymentRadio2.isSelected())
      student.setPaymentCondition(2);
    else if (paymentRadio3.isSelected())
      student.setPaymentCondition(3);
    else if (paymentRadio4.isSelected())
      student.setPaymentCondition(4);
    else if (paymentRadio5.isSelected())
      student.setPaymentCondition(5);
    else if (paymentRadio6.isSelected())
      student.setPaymentCondition(6);

    if (preRadio1.isSelected())
      student.setRegisterStatus(1);
    else if (preRadio2.isSelected())
      student.setRegisterStatus(2);
    else if (preRadio3.isSelected())
      student.setRegisterStatus(3);
    else if (preRadio4.isSelected())
      student.setRegisterStatus(4);
    else if (preRadio5.isSelected())
      student.setRegisterStatus(5);
    else if (preRadio6.isSelected())
      student.setRegisterStatus(6);
    else if (preRadio7.isSelected())
      student.setRegisterStatus(7);
    else if (preRadio8.isSelected())
      student.setRegisterStatus(8);
    else if (preRadio9.isSelected())
      student.setRegisterStatus(9);

    Database.connect();
    if (newRecord) complete = student.insertStudent(student);
    else complete = student.updateStudent(student);
    Database.disconnect();
  }

  void tprenameCombo_actionPerformed(ActionEvent e) {
    if (tprenameCombo.getSelectedItem() != null){
      Prename p = (Prename)tprenameCombo.getSelectedItem();
      eprenameText.setText(p.getEprename());
    }
  }
}

class StudentUI_phDRadio_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_phDRadio_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.phDRadio_actionPerformed(e);
  }
}

class StudentUI_masterRadio_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_masterRadio_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.masterRadio_actionPerformed(e);
  }
}

class StudentUI_facultyCombo_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_facultyCombo_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.facultyCombo_actionPerformed(e);
  }
}

class StudentUI_departmentCombo_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_departmentCombo_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.departmentCombo_actionPerformed(e);
  }
}

class StudentUI_majorCombo_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_majorCombo_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.majorCombo_actionPerformed(e);
  }
}

class StudentUI_studentIDText_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_studentIDText_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.studentIDText_actionPerformed(e);
  }
}

class StudentUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_clearButton_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class StudentUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_saveButton_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}

class StudentUI_tprenameCombo_actionAdapter implements java.awt.event.ActionListener {
  StudentUI adaptee;

  StudentUI_tprenameCombo_actionAdapter(StudentUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.tprenameCombo_actionPerformed(e);
  }
}