package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SemesterUI extends JDialog {
  CompoundBorder titledBorder3;
  CompoundBorder titledBorder2;
  TitledBorder titledBorder6;
  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JRadioButton termRadio1 = new JRadioButton();
  JRadioButton termRadio2 = new JRadioButton();
  JRadioButton termRadio3 = new JRadioButton();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder5;
  CompoundBorder titledBorder4;
  JPanel jPanel3 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField beText = new JTextField();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel jPanel4 = new JPanel();
  JButton jButton1 = new JButton();
  FlowLayout flowLayout2 = new FlowLayout();
  ButtonGroup buttonGroup1 = new ButtonGroup();
  JButton jButton2 = new JButton();
  Border border1;
  //----------------------------------------------------------------------------------------------------------------------------------------------

  public SemesterUI(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SemesterUI() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(5,5,5,5);

    titledBorder6 = new TitledBorder(null, "�Ҥ����֡��/�ա���֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder3 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));

    titledBorder5 = new TitledBorder(null, "�Ҥ����֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder5.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder4 = new CompoundBorder(titledBorder5,new EmptyBorder(5,5,5,5));

    titledBorder1 = new TitledBorder(null, "�ա���֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder2 = new CompoundBorder(titledBorder5,new EmptyBorder(5,5,5,5));

    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(verticalFlowLayout1);
    termRadio1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    termRadio1.setToolTipText("");
    termRadio1.setSelected(true);
    termRadio1.setText("�Ҥ����֡�ҷ�� 1");
    termRadio2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    termRadio2.setText("�Ҥ����֡�ҷ�� 2");
    termRadio3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    termRadio3.setText("�ҤĴ���͹");
    panel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    panel1.setBorder(border1);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(titledBorder3);
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder4);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("�ա���֡�ҷ��");
    beText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    beText.setPreferredSize(new Dimension(80, 21));
    beText.setText("");
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.setBorder(titledBorder2);
    jPanel3.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.LEFT);
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setMinimumSize(new Dimension(80, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("��ŧ");
    jButton1.addActionListener(new SemesterUI_jButton1_actionAdapter(this));
    jPanel4.setLayout(flowLayout2);
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setMinimumSize(new Dimension(80, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setSelected(false);
    jButton2.setText("¡��ԡ");
    jButton2.addActionListener(new SemesterUI_jButton2_actionAdapter(this));
    jPanel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    getContentPane().add(panel1);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, BorderLayout.NORTH);
    jPanel2.add(termRadio1, null);
    jPanel2.add(termRadio2, null);
    jPanel2.add(termRadio3, null);
    jPanel1.add(jPanel3,  BorderLayout.CENTER);
    jPanel3.add(jLabel1, null);
    jPanel3.add(beText, null);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    jPanel4.add(jButton1, null);
    buttonGroup1.add(termRadio1);
    buttonGroup1.add(termRadio2);
    buttonGroup1.add(termRadio3);
    jPanel4.add(jButton2, null);
    this.setSize(new Dimension(300, 379));
  }

  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    int sem;
    int value;
    if (termRadio1.isSelected()) sem = 1;
    else if (termRadio2.isSelected()) sem = 2;
    else sem = 3;
    String str = beText.getText();
    if (str.equals("")) {
      JOptionPane.showMessageDialog(this,"��س����ա���֡��","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    try{
      value = Integer.parseInt(str);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ա���֡���繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    boolean packFrame = false;
    this.dispose();
    ScheduleUI frame = new ScheduleUI(sem,value);
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
}

class SemesterUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  SemesterUI adaptee;

  SemesterUI_jButton2_actionAdapter(SemesterUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class SemesterUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  SemesterUI adaptee;

  SemesterUI_jButton1_actionAdapter(SemesterUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}