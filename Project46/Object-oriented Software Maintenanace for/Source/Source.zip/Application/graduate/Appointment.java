package graduate;

import java.util.*;
public class Appointment {
  private Date fromDate;
  private Date toDate;
  private RegisterType registerType;
  private Semester semester;
  private AppointmentDB aDB = new AppointmentDB();
  //Constructor
  public Appointment() {
  }
  //getMethod
  public RegisterType getRegisterType(){
      return this.registerType;
  }
  public Semester getSemester(){
    return this.semester;
  }
  public Date getFromDate(){
    return this.fromDate;
  }
  public Date getToDate(){
    return this.toDate;
  }

  //setMethod
  public void setRegisterType(RegisterType registerType){
    this.registerType = registerType;
  }
  public void setSemester(Semester semester){
    this.semester = semester;
  }
  public void setFromDate(Date fromdate){
    this.fromDate = fromdate;
  }
  public void setToDate(Date todate){
    this.toDate = todate;
  }

  //Business Method
  public Vector retrieveAppointment(Semester semester){
    return aDB.retrieveAppointmentAll(semester);
  }
  public Appointment retrieveAppointment(Semester semester, RegisterType register){
    return aDB.retrieveAppointment(semester,register);
  }
  public boolean insertAppointment(Appointment appointment){
    return aDB.insertAppointment(appointment);
  }
  public boolean updateAppointment(Appointment appointment,Appointment newAppointment){
    return aDB.updateAppointment(appointment,newAppointment);
  }
  public boolean deleteAppointment(Appointment appointment){
    return aDB.deleteAppointment(appointment);
  }
  public boolean checkInTime(RegisterType registerType,Semester currentSemester){
    Appointment a = aDB.retrieveAppointment(currentSemester,registerType);
    if (a == null) return true;
    Date d = new Date();
    if (a.equals(d)) return false;
    if (a.getFromDate().before(d) &&  a.getToDate().after(d))  return false;
    return true;
  }
}