package graduate;

import java.util.*;
public class Location {
  private long locationID;
  private String locationName;
  private LocationDB locationDB = new LocationDB();
  //Constructor
  public Location() {
  }
  public Location(long id){
    this.setLocationID(id);
  }
  public Location(String name){
      this.setLocationName(name);
  }
  public Location(long id,String name){
    this.setLocationID(id);
    this.setLocationName(name);
  }
  //getMethod
  public long getLocationID(){
    return this.locationID;
  }
  public String getLocationName(){
    return this.locationName;
  }
  //setMethod
  public void setLocationID(long locationID){
    this.locationID = locationID;
  }
  public void setLocationName(String locationName){
    this.locationName = locationName;
  }
  public Vector retrieveLocation(){
    return locationDB.retrieveLocation();
  }
    public Location retrieveLocation(long loc){
      return locationDB.retrieveLocation(loc);
    }
  public boolean insertLocation(Location l){
    return locationDB.insertLocation(l);
  }
  public boolean updateLocation(Location l){
    return locationDB.updateLocation(l);
  }
  public boolean deleteLocation(Location l){
    return locationDB.deleteLocation(l);
  }
  public String toString(){
    return this.getLocationName();
  }
}