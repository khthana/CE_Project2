package graduate;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

public class CoursePhDUI extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JTextField enameText = new JTextField();
  JTextField tnameText = new JTextField();
  JTextField eabbrText = new JTextField();
  JTextField tabbrText = new JTextField();
  Border border1;
  TitledBorder titledBorder1;
  Border border2;
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
  Major major;

  public CoursePhDUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"��ѡ�ٵû�ԭ���͡");
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    border2 = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder1.setTitleFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(borderLayout2);
    jPanel2.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel1.setText("������ѡ�ٵ� [�] :");
    jLabel1.setBounds(new Rectangle(10, 24, 115, 23));
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel2.setText("������ѡ�ٵ� [�] :");
    jLabel2.setBounds(new Rectangle(10, 53, 115, 23));
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setToolTipText("");
    jLabel3.setText("������� [�] :");
    jLabel3.setBounds(new Rectangle(10, 83, 115, 23));
    jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel4.setText("������� [�] :");
    jLabel4.setBounds(new Rectangle(10, 112, 115, 23));
    enameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    enameText.setBounds(new Rectangle(108, 24, 281, 23));
    tnameText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tnameText.setBounds(new Rectangle(108, 53, 281, 23));
    eabbrText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    eabbrText.setBounds(new Rectangle(108, 83, 281, 23));
    tabbrText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    tabbrText.setBounds(new Rectangle(108, 112, 281, 23));
    jPanel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel2.setBorder(titledBorder1);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel1.setBorder(border2);
    this.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setBounds(new Rectangle(231, 153, 73, 25));
    jButton1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton1.setMaximumSize(new Dimension(80, 25));
    jButton1.setMinimumSize(new Dimension(69, 25));
    jButton1.setPreferredSize(new Dimension(80, 25));
    jButton1.setText("�ѹ�֡");
    jButton1.addActionListener(new CoursePhDUI_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(315, 153, 73, 25));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jButton2.setMaximumSize(new Dimension(80, 25));
    jButton2.setMinimumSize(new Dimension(69, 25));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setText("������");
    jButton2.addActionListener(new CoursePhDUI_jButton2_actionAdapter(this));
    this.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jPanel2,  BorderLayout.CENTER);
    jPanel2.add(eabbrText, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(enameText, null);
    jPanel2.add(tabbrText, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(tnameText, null);
    jPanel2.add(jButton1, null);
    jPanel2.add(jButton2, null);
  }
  public void setMajor(Major major){
    this.major = major;
  }
  public void showUI(Major major){
    if (major.getPhDEname() == null || major.getPhDEname().equals("null")) enameText.setText("");
    else enameText.setText(major.getPhDEname());
    if (major.getPhDTname() == null || major.getPhDTname().equals("null")) tnameText.setText("");
    else tnameText.setText(major.getPhDTname());
    if (major.getPhDEabbr() == null || major.getPhDEabbr().equals("null")) eabbrText.setText("");
    else eabbrText.setText(major.getPhDEabbr());
    if (major.getPhDTabbr() == null || major.getPhDTabbr().equals("null")) tabbrText.setText("");
    else tabbrText.setText(major.getPhDTabbr());
  }
  public void clear(){
    enameText.setText("");
    tnameText.setText("");
    eabbrText.setText("");
    tabbrText.setText("");
  }
  void jButton2_actionPerformed(ActionEvent e) {
    clear();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    boolean complete = false;
    this.major.setPhDEname(enameText.getText());
    this.major.setPhDTname(tnameText.getText());
    this.major.setPhDEabbr(eabbrText.getText());
    this.major.setPhDTabbr(tabbrText.getText());
    Database.connect();
    complete = major.updateMajor(this.major,this.major);
    Database.disconnect();
  }
}

class CoursePhDUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  CoursePhDUI adaptee;

  CoursePhDUI_jButton2_actionAdapter(CoursePhDUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class CoursePhDUI_jButton1_actionAdapter implements java.awt.event.ActionListener {
  CoursePhDUI adaptee;

  CoursePhDUI_jButton1_actionAdapter(CoursePhDUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}