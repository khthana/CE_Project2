package graduate;

import java.util.*;
public class Cost {
  private long costID;
  private  String costName;
  private double value;
  private CostDB costDB = new CostDB();
  //Constructor
  public Cost() {
  }
  public Cost(long id){
    this.setCostID(id);
  }
  public Cost(String name,double val){
    this.setCostName(name);
    this.setValue(val);
  }
  public Cost(long id,String name,double val){
    this.setCostID(id);
    this.setCostName(name);
    this.setValue(val);
  }
  //getMethod
  public long getCostID(){
    return this.costID;
  }
  public String getCostName(){
    return this.costName;
  }
  public double getValue(){
    return this.value;
  }
  //setMethod
  public void setCostID(long costID){
    this.costID = costID;
  }
  public void setCostName(String costName){
    this.costName = costName;
  }
  public void setValue(double value){
    this.value = value;
  }
  //Business Method
  public Vector retrieveCost(){
    return costDB.retrieveCost();
  }
  public boolean insertCost(Cost cost){
    return costDB.insertCost(cost);
  }
  public boolean updateCost(Cost cost){
    return costDB.updateCost(cost);
  }
  public boolean deleteCost(Cost cost){
    return costDB.deleteCost(cost);
  }
  public String toString(){
    return this.getCostName();
  }

}