package graduate;

import java.sql.*;
import java.util.*;
public class GroupDB {
  public GroupDB() {
  }
  public Vector retrieveGroup(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM SubjectGroup ORDER BY GroupName";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Group group = new Group();
          group.setGroupID(rs.getLong("GroupID"));
          group.setGroupName(rs.getString("GroupName"));
          v.addElement(group);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertGroup(Group group){
    String query = "INSERT INTO SubjectGroup(GroupName) ";
    query += "VALUES('" + group.getGroupName() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateGroup(Group group){
    String query = "UPDATE SubjectGroup SET ";
    query += "GroupName = '" + group.getGroupName() + "' ";
    query += "WHERE GroupID = " + group.getGroup();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteGroup(Group group){
    String query = "DELETE FROM SubjectGroup WHERE GroupID = " + group.getGroup();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    GroupDB gdb = new GroupDB();
    Group g = new Group(4,"�ԪҺѧ�Ѻ1");
    gdb.updateGroup(g);
/*    Vector v = gdb.retrieveGroup();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Group m1 = (Group)e.nextElement();
      System.out.println(m1.getGroup() + " " + m1.getGroupName());
    }*/
    Database.disconnect();
  }

}