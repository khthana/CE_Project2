package graduate;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import java.awt.event.*;
import java.util.*;

public class CostUI extends JPanel {
  CompoundBorder titledBorder1;
  TitledBorder titledBorder6;
  Border loweredBorder;
  BorderLayout borderLayout1 = new BorderLayout();
  JButton jButton2 = new JButton();
  BoxLayout2 boxLayout22 = new BoxLayout2();
  JButton jButton3 = new JButton();
  JPanel jPanel1 = new JPanel();
  JPanel switchPanel = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel jPanel3 = new JPanel();
  JSplitPane jSplitPane1 = new JSplitPane();
  JPanel jPanel5 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("��Ҹ�����������֡��");
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  Border border1;
  BoxLayout2 boxLayout23 = new BoxLayout2();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel10 = new JPanel();
  JLabel jLabel2 = new JLabel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel jPanel2 = new JPanel();
  BorderLayout borderLayout7 = new BorderLayout();
  JButton saveButton = new JButton();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel jPanel8 = new JPanel();
  JButton clearButton = new JButton();
  JPanel jPanel7 = new JPanel();
  JTextField costNameText = new JTextField();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JTextField valueText = new JTextField();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  JPanel jPanel9 = new JPanel();
  JLabel jLabel3 = new JLabel();
  //-----------------------------------------------------------------------------------------------------------------------------------------------------------
  Cost cost = new Cost();
  Cost currentCost = null;
  boolean newRecord = false;
  boolean canAdd = false;
  JTree jTree1 = new JTree(treeModel);

  public CostUI() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEmptyBorder(10,5,5,5);
    loweredBorder = BorderFactory.createEmptyBorder(5,5,5,5);
    titledBorder6 = new TitledBorder(null, "��Ҹ�����������֡��",  TitledBorder.LEFT, TitledBorder.TOP);
    titledBorder6.setTitleFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    titledBorder1 = new CompoundBorder(titledBorder6,new EmptyBorder(5,5,5,5));
    jButton2.setText("����");
    jButton2.addActionListener(new CostUI_jButton2_actionAdapter(this));
    jButton2.setPreferredSize(new Dimension(80, 25));
    jButton2.setMaximumSize(new Dimension(100, 50));
    jButton2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setLayout(borderLayout1);
    boxLayout22.setAxis(BoxLayout.Y_AXIS);
    jButton3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jButton3.setMaximumSize(new Dimension(100, 50));
    jButton3.setPreferredSize(new Dimension(80, 25));
    jButton3.setText("ź");
    jButton3.addActionListener(new CostUI_jButton3_actionAdapter(this));
    jPanel1.setLayout(borderLayout2);
    jPanel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel1.setBorder(border1);
    jPanel1.setPreferredSize(new Dimension(622, 500));
    switchPanel.setLayout(boxLayout22);
    switchPanel.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    switchPanel.setBorder(loweredBorder);
    switchPanel.setPreferredSize(new Dimension(472, 462));
    jScrollPane1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setLayout(borderLayout3);
    jPanel3.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel3.setBorder(loweredBorder);
    jPanel3.setPreferredSize(new Dimension(175, 462));
    jPanel5.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    this.setBorder(null);
    boxLayout23.setAxis(BoxLayout.Y_AXIS);
    jPanel4.setPreferredSize(new Dimension(400, 50));
    jPanel4.setLayout(boxLayout23);
    jLabel1.setText("���ͤ�Ҹ������� :");
    jLabel1.setPreferredSize(new Dimension(80, 16));
    jLabel1.setMinimumSize(new Dimension(62, 16));
    jLabel1.setMaximumSize(new Dimension(100, 16));
    jLabel1.setDoubleBuffered(false);
    jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel10.setLayout(flowLayout1);
    jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jLabel2.setDoubleBuffered(false);
    jLabel2.setMaximumSize(new Dimension(100, 16));
    jLabel2.setMinimumSize(new Dimension(62, 16));
    jLabel2.setPreferredSize(new Dimension(80, 16));
    jLabel2.setText("�ӹǹ�Թ :");
    jLabel2.setBounds(new Rectangle(0, 0, 80, 25));
    jPanel2.setBorder(titledBorder1);
    jPanel2.setMaximumSize(new Dimension(32767, 32767));
    jPanel2.setPreferredSize(new Dimension(400, 150));
    jPanel2.setLayout(boxLayout21);
    saveButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    saveButton.setMaximumSize(new Dimension(100, 25));
    saveButton.setPreferredSize(new Dimension(80, 25));
    saveButton.setText("�ѹ�֡");
    saveButton.addActionListener(new CostUI_saveButton_actionAdapter(this));
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    jPanel8.setLayout(borderLayout4);
    jPanel8.setPreferredSize(new Dimension(400, 150));
    clearButton.setText("������");
    clearButton.addActionListener(new CostUI_clearButton_actionAdapter(this));
    clearButton.setPreferredSize(new Dimension(80, 25));
    clearButton.setMaximumSize(new Dimension(100, 25));
    clearButton.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel7.setLayout(borderLayout5);
    jPanel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel7.setMinimumSize(new Dimension(141, 35));
    jPanel7.setPreferredSize(new Dimension(400, 100));
    costNameText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    costNameText.setOpaque(true);
    costNameText.setPreferredSize(new Dimension(300, 22));
    costNameText.setText("");
    jPanel6.setLayout(null);
    jPanel6.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel6.setDebugGraphicsOptions(0);
    jPanel6.setDoubleBuffered(true);
    jPanel6.setMinimumSize(new Dimension(78, 20));
    jPanel6.setOpaque(true);
    jPanel6.setPreferredSize(new Dimension(400, 22));
    valueText.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    valueText.setOpaque(true);
    valueText.setPreferredSize(new Dimension(300, 22));
    valueText.setToolTipText("");
    valueText.setText("");
    valueText.setBounds(new Rectangle(80, 0, 85, 25));
    boxLayout21.setAxis(BoxLayout.Y_AXIS);
    jPanel9.setPreferredSize(new Dimension(400, 22));
    jPanel9.setOpaque(true);
    jPanel9.setMinimumSize(new Dimension(78, 20));
    jPanel9.setDoubleBuffered(true);
    jPanel9.setDebugGraphicsOptions(0);
    jPanel9.setFont(new java.awt.Font("Microsoft Sans Serif",0, 13));
    jPanel9.setLayout(borderLayout7);
    jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jLabel3.setRequestFocusEnabled(true);
    jLabel3.setText(" �ҷ");
    jLabel3.setBounds(new Rectangle(174, 0, 85, 25));
    jTree1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 13));
    jPanel3.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(jTree1, null);
    jPanel3.add(jPanel5, BorderLayout.SOUTH);
    jPanel5.add(jButton2, null);
    jPanel5.add(jButton3, null);
    jSplitPane1.add(switchPanel, JSplitPane.RIGHT);
    switchPanel.add(jPanel2, null);
    jPanel2.add(jPanel8, null);
    jPanel10.add(saveButton, null);
    jPanel10.add(clearButton, null);
    jPanel8.add(jPanel4, BorderLayout.NORTH);
    jPanel8.add(jPanel7, BorderLayout.CENTER);
    jPanel7.add(jPanel10, BorderLayout.NORTH);
    jPanel6.add(valueText, null);
    jPanel6.add(jLabel2, null);
    jPanel6.add(jLabel3, null);
    jPanel4.add(jPanel9, null);
    jPanel4.add(jPanel6, null);
    jPanel9.add(costNameText, BorderLayout.CENTER);
    jPanel9.add(jLabel1, BorderLayout.WEST);
    jSplitPane1.add(jPanel3, JSplitPane.LEFT);
    this.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jSplitPane1, BorderLayout.CENTER);
    jTree1.addTreeSelectionListener(new TreeSelectionListener());

    createTree();
  }
  //TreeSelectionListener-------------------------------------------------------------------------------------------------------------------------
  class TreeSelectionListener implements javax.swing.event.TreeSelectionListener
  {
    public void valueChanged(TreeSelectionEvent e)
    {
      DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)jTree1.getLastSelectedPathComponent();

      if (node1 == null) return;
      Object nodeInfo = node1.getUserObject();
      if (nodeInfo instanceof String) canAdd = true;
      else canAdd =false;
      if (nodeInfo instanceof Cost){
        currentCost = (Cost)nodeInfo;
        showUI(currentCost);
      }
    }
  }
//CreateTree----------------------------------------------------------------------------------------------------------------------------------------
  public void showUI(Cost cost){
    newRecord = false;
    costNameText.setText(cost.getCostName());
    valueText.setText(String.valueOf(cost.getValue()));
  }
  public void createTree() {
    Database.connect();
    DefaultMutableTreeNode costNode = null;

    Vector costVector = cost.retrieveCost();
    Enumeration costEnum = costVector.elements();
    while (costEnum.hasMoreElements()) {
      Cost c = (Cost) costEnum.nextElement();
      costNode = new DefaultMutableTreeNode(c);
      root.add(costNode);
    }
    Database.disconnect();
    jTree1.expandRow(0);
  }
  public void addNode(Object obj){
    DefaultMutableTreeNode lastItem = (DefaultMutableTreeNode)jTree1.getSelectionPath().getLastPathComponent();
    DefaultMutableTreeNode parent = (DefaultMutableTreeNode)lastItem.getParent();
    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(obj);
    if (canAdd) {
      int newIndex = lastItem.getChildCount();
      treeModel.insertNodeInto(newNode, lastItem, newIndex);
    }
    else {
      int newIndex = parent.getIndex(lastItem);
      treeModel.insertNodeInto(newNode, parent, newIndex+1);
    }
    jTree1.scrollPathToVisible(new TreePath(newNode.getPath()));
  }
  public void clear(){
    costNameText.setText("");
    valueText.setText("");
  }
  public void clearButton_actionPerformed(ActionEvent e) {
    clear();
  }

  void saveButton_actionPerformed(ActionEvent e) {
    boolean complete = false;
    Cost cost = new Cost();
    if (costNameText.getText().equals("") || valueText.getText().equals("")){
      JOptionPane.showMessageDialog(this,"��سҡ�͡���������ú��ǹ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    cost.setCostName(costNameText.getText());
    double value=0.0;
    try{
      value = Double.parseDouble(valueText.getText());
      cost.setValue(value);
    }
    catch (NumberFormatException ex){
      JOptionPane.showMessageDialog(this,"��س����ӹǹ�Թ�繵���Ţ","��ͼԴ��Ҵ",JOptionPane.ERROR_MESSAGE);
      return;
    }
    Database.connect();
    if (newRecord) {
      complete = cost.insertCost(cost);
      if (complete) addNode(cost);
    }
    else {
      cost.setCostID(this.currentCost.getCostID());
      complete = cost.updateCost(cost);
      if (complete) currentCost = cost;
    }
    Database.disconnect();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    newRecord = true;
    clear();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    boolean complete = false;
    DefaultMutableTreeNode node = (DefaultMutableTreeNode) jTree1.getSelectionPath().getLastPathComponent();
    if (node != null) {
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
      Object obj = node.getUserObject();
      if (node.isLeaf() && parent != null){
        if (obj instanceof  Cost) {
          Cost del = (Cost)obj;
          Database.connect();
          complete = del.deleteCost(del);
          Database.disconnect();
        }
        if (complete) {
          treeModel.removeNodeFromParent(node);
          clear();
        }
      }
    }
  }
}

class CostUI_clearButton_actionAdapter implements java.awt.event.ActionListener {
  CostUI adaptee;

  CostUI_clearButton_actionAdapter(CostUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.clearButton_actionPerformed(e);
  }
}

class CostUI_saveButton_actionAdapter implements java.awt.event.ActionListener {
  CostUI adaptee;

  CostUI_saveButton_actionAdapter(CostUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.saveButton_actionPerformed(e);
  }
}


class CostUI_jButton3_actionAdapter implements java.awt.event.ActionListener {
  CostUI adaptee;

  CostUI_jButton3_actionAdapter(CostUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class CostUI_jButton2_actionAdapter implements java.awt.event.ActionListener {
  CostUI adaptee;

  CostUI_jButton2_actionAdapter(CostUI adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}
