package graduate;

import java.sql.*;
import java.util.*;
public class LocationDB {
  public LocationDB() {
  }
  public Vector retrieveLocation(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM Location ORDER BY LocationName";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          Location location = new Location();
          location.setLocationID(rs.getInt("LocationID"));
          location.setLocationName(rs.getString("LocationName"));
          v.addElement(location);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public Location retrieveLocation(long loc){
    Location l = new Location();
    try
    {
        String query = "SELECT * FROM Location WHERE LocationID = " + loc;
        ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          l.setLocationID(rs.getLong("LocationID"));
          l.setLocationName(rs.getString("LocationName"));
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return l;
  }
  public boolean insertLocation(Location location){
    String query = "INSERT INTO Location(LocationName) ";
    query += "VALUES('" + location.getLocationName() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateLocation(Location location){
    String query = "UPDATE Location SET ";
    query += "LocationName = '" + location.getLocationName() + "' ";
    query += "WHERE LocationID = " + location.getLocationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteLocation(Location location){
    String query = "DELETE FROM Location WHERE LocationID = " + location.getLocationID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    LocationDB gdb = new LocationDB();
    Location g = new Location(2,"�����");
//    gdb.updateLocation(g);
    Vector v = gdb.retrieveLocation();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      Location m1 = (Location)e.nextElement();
      System.out.println(m1.getLocationID() + " " + m1.getLocationName());
    }
    Database.disconnect();
  }

}