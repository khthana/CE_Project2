package graduate;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2547</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Signin extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=MS874";
  //Initialize global variables
  public void init(ServletConfig config) throws ServletException {
    super.init(config);
  }
  public void validate(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    String username = request.getParameter("username");
    if (username == null) {
      username = "";
    }
    String password = request.getParameter("password");
    if (password == null) {
      password = "";
    }

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession(true);

    Database.connect();
    Student student = new Student();

    if(student.verifyUsername(request.getParameter("username"), request.getParameter("password")))
    {
      Student stu = new Student();
      stu = stu.retrieveStudent(new Student(request.getParameter("username")));

      session.setAttribute("StudentInfo", stu);
      session.setAttribute("ISLOGIN", "true");
      response.sendRedirect("/jsp/MainPage.jsp");
    }
    else
    {
      response.sendRedirect("/jsp/LoginPage.jsp?error=true");
    }
    Database.disconnect();
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    validate(request,response);
  }
  //Clean up resources
  public void destroy() {
  }
}
