package graduate;

import java.sql.*;
import java.util.*;
public class RegisterTypeDB {
  public RegisterTypeDB() {
  }
  public Vector retrieveRegisterType(){
    Vector v = new Vector();
    try
    {
      String query = "SELECT * FROM RegisterType ORDER BY RegisterTypeID";
      ResultSet rs = Database.getResultSet(query);

        while(rs.next()){
          RegisterType registerType = new RegisterType();
          registerType.setRegisterTypeID(rs.getInt("RegisterTypeID"));
          registerType.setRegisterTypeName(rs.getString("RegisterType"));
          v.addElement(registerType);
        }
    }
    catch(SQLException sqlex)
    {
        System.out.println(sqlex.toString());
    }
    return v;
  }
  public boolean insertRegisterType(RegisterType registerType){
    String query = "INSERT INTO RegisterType(RegisterType) ";
    query += "VALUES('" + registerType.getRegisterTypeName() + "')";
    if (Database.update(query) !=0 ) return true;
    return false;
  }
  public boolean updateRegisterType(RegisterType registerType){
    String query = "UPDATE RegisterType SET ";
    query += "RegisterType = '" + registerType.getRegisterTypeName() + "' ";
    query += "WHERE RegisterTypeID = " + registerType.getRegisterTypeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public boolean deleteRegisterType(RegisterType registerType){
    String query = "DELETE FROM RegisterType WHERE RegisterTypeID = " + registerType.getRegisterTypeID();
    if (Database.update(query) != 0) return true;
    return false;
  }
  public static void main(String[] args){
    Database.connect("jdbc:odbc:Graduate","Admin","123");
    RegisterTypeDB rdb = new RegisterTypeDB();
    RegisterType r = new RegisterType(1,"ŧ����¹��ǧ˹��");
//    rdb.updateRegisterType(r);
    Vector v = rdb.retrieveRegisterType();
    Enumeration e = v.elements();
    while (e.hasMoreElements()){
      RegisterType m1 = (RegisterType)e.nextElement();
      System.out.println(m1.getRegisterTypeID() + " " + m1.getRegisterTypeName());
    }
    Database.disconnect();
  }

}