package graduate;

import java.util.*;
public class Degree {
  private long degreeID;
  private boolean degreeLevel;
  private boolean pt;
  private boolean mbn;
  private DegreeDB degreeDB = new DegreeDB();
  //Constructor
  public Degree() {
  }
  public Degree(long id){
    this.setDegreeID(id);
  }
  public Degree(boolean degreeLevel,boolean pt,boolean mbn){
    this.setDegreeLevel(degreeLevel);
    this.setPt(pt);;
    this.setMbn(mbn);
  }
  public Degree(long degreeID,boolean degreeLevel,boolean pt,boolean mbn){
    this.setDegreeID(degreeID);
    this.setDegreeLevel(degreeLevel);
    this.setPt(pt);;
    this.setMbn(mbn);
  }
  //getMethod
  public long getDegreeID(){
    return this.degreeID;
  }
  public boolean getDegreeLevel(){
    return this.degreeLevel;
  }
  public boolean getPt(){
    return this.pt;
  }
  public boolean getMbn(){
    return this.mbn;
  }
  //setMethod
  public void setDegreeID(long degreeID){
    this.degreeID  = degreeID;
  }
  public void setDegreeLevel(boolean degreeLevel){
    this.degreeLevel = degreeLevel;
  }
  public void setPt(boolean pt){
    this.pt = pt;
  }
  public void setMbn(boolean mbn){
    this.mbn = mbn;
  }
  //Business Method
  public Vector retrieveDegreeAll(){
    return degreeDB.retrieveDegreeAll();
  }
  public boolean insertDegree(Degree degree){
    return degreeDB.insertDegree(degree);
  }
  public boolean updateDegree(Degree degree){
    return degreeDB.updateDegree(degree);
  }
  public boolean deleteDegree(Degree degree){
    return degreeDB.deleteDegree(degree);
  }
}