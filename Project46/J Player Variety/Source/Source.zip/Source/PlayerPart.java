package control;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import javax.media.*;
import java.util.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.*;

import javax.swing.event.*;
import javax.media.protocol.*;
import javax.media.format.*;
import javax.media.control.*;
import javax.media.datasink.*;

public class PlayerPart extends JFrame{
  private Container container;
  private  Player player;
  private Component visualMedia,mediaControl;
  private  File mediaFile,file;
  private URL fileURL;

  private boolean Checked = false;
  private boolean checkMpeg ;

  private String extension[] = {"MPG","mpg","wav","WAV","mp3","MP3","au","AU","aiff","AIFF","mid","MID"};


  public PlayerPart(Container c){
    super("Playing Media");
    container =  c;
    Manager.setHint( Manager.LIGHTWEIGHT_RENDERER,
         Boolean.TRUE );
  }
  public PlayerPart(){}
  public void showErrorMessage(String error){
    JOptionPane.showMessageDialog(this,error,"Error",JOptionPane.ERROR_MESSAGE);
  }
  //-----------------Return is Mpeg or not ---------------------------------------
   public void setIsMpeg(boolean mpg){
      checkMpeg = mpg;
   }
//------------------------------------------------------------------------------
  public File[] getFile(){


    JFileChooser fileChooser = new JFileChooser("c://JPV");
    fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
    fileChooser.getChoosableFileFilters();
    fileChooser.setMultiSelectionEnabled(true);
    //Set FileFilter
    MFilefilter filter = new MFilefilter();
    fileChooser.setFileFilter(filter);
    for (int i=0;i<11;i++){
    filter.addExtension(extension[i]);
    }
    filter.getDescription();
    fileChooser.setFileFilter(filter);
    //Set Icon for specific file type
    MFileView fileView = new MFileView();
    fileView.addIcon(extension[0],new ImageIcon("a.gif"));
    fileView.addIcon(extension[1],new ImageIcon("a.gif"));
    fileView.addIcon(extension[2],new ImageIcon("b.gif"));
    fileView.addIcon(extension[3],new ImageIcon("b.gif"));
    fileView.addIcon(extension[4],new ImageIcon("c.gif"));
    fileView.addIcon(extension[5],new ImageIcon("c.gif"));
    fileView.addIcon(extension[6],new ImageIcon("d.gif"));
    fileView.addIcon(extension[7],new ImageIcon("d.gif"));
    fileView.addIcon(extension[8],new ImageIcon("e.gif"));
    fileView.addIcon(extension[9],new ImageIcon("e.gif"));
    fileView.addIcon(extension[10],new ImageIcon("f.gif"));
    fileView.addIcon(extension[11],new ImageIcon("f.gif"));
    fileChooser.setFileView(fileView);

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.CANCEL_OPTION)
      return null;
    else
      return fileChooser.getSelectedFiles();
  }

  public String getMediaLocation(){
      String input = JOptionPane.showInputDialog(
         this, "Enter URL" );
      // if user presses OK with no input
      if ( input != null && input.length() == 0 )
         return null;

      return input;
   }
   public boolean makePlayer(String mediaLocation){
   if(player != null)
     removePlayerComponent();
   MediaLocator mediaLocator = new MediaLocator(mediaLocation);

   if(mediaLocator == null) {
     showErrorMessage("Error opening file");
     return false;
   }
   try{
     player = Manager.createPlayer(mediaLocator);
     player.addControllerListener(new PlayerEventHandler());
     player.realize();
     System.out.println("player.realize");

     Checked = true;
     return Checked;
   }
   catch (NoPlayerException noPlayerException) {
     noPlayerException.printStackTrace();
     return false;
   }
   catch (IOException ioException){
     ioException.printStackTrace();
     return false;
   }
  }
   public void removePlayerComponent(){
    if(visualMedia != null)
      container.remove(visualMedia);
    if(mediaControl != null)
      container.remove(mediaControl);
    player.close();
    container.repaint();
   }
  public void getMediaComponents(){
    visualMedia = player.getVisualComponent();
    if (visualMedia != null)
     container.add(visualMedia,BorderLayout.CENTER);
     mediaControl = player.getControlPanelComponent();


    if (mediaControl != null)
      mediaControl.setSize(1018,20);
      container.add(mediaControl,BorderLayout.NORTH);
      container.repaint();
  }
  public void getMediaComponentsformpg(){
  visualMedia = player.getVisualComponent();
  if (visualMedia != null)

   visualMedia.setSize(1018,605);//For the first time to show video monitor
   visualMedia.setLocation(0,20);
   container.add(visualMedia,BorderLayout.CENTER);
   mediaControl = player.getControlPanelComponent();

  if (mediaControl != null)
   // mediaControl.setSize(390,20);
    mediaControl.setSize(1018,30);
    container.add(mediaControl,BorderLayout.NORTH);
    container.repaint();

  }
  public class PlayerEventHandler extends ControllerAdapter {
    public void realizeComplete(RealizeCompleteEvent realizeDoneEvent){
      player.prefetch();
      System.out.println("prefetch realizeDoneEvent :"+realizeDoneEvent);
    }
    public void prefetchComplete(PrefetchCompleteEvent prefetchDoneEvent){

      if (checkMpeg){
      getMediaComponentsformpg();
      }
      else{
            getMediaComponents();
      }
      validate();
      player.start();
      if (prefetchDoneEvent instanceof PrefetchCompleteEvent){
      Checked = true;
      }
    }
    public void endOfMedia(EndOfMediaEvent mediaEndEvent){
      if (mediaEndEvent instanceof EndOfMediaEvent){
      player.setMediaTime(new Time(0));
      player.stop();
      removePlayerComponent();
      }
    }
  }
  public class MFilefilter extends FileFilter{
    private Hashtable h = new Hashtable();
    public boolean accept(File f){
      if (f.isDirectory())
        return true;
   String n = f.getName();
   int i = n.lastIndexOf('.');
      if (i>0&&i<n.length()-1){
     String e = n.substring(i+1);
     if (e != null && h.get(e) != null)
       return true;
   }
   return false;
 }
 public String getDescription(){return "Video and Audio File";}
 public void addExtension(String e){h.put(e,this);}
  }
  public class MFileView extends FileView{
    private Hashtable ic = new Hashtable();
    public String getExtension(File f){
      String n = f.getName();
      if ( n!= null ){
        int i = n.lastIndexOf('.');
        if (i<0) return null;
        return n.substring(i+1);
      }
      return null;
    }
    public void addIcon(String e,Icon i){ic.put(e,i);}
    public Icon getIcon(File f){
      String e = getExtension(f);
      if (e!= null)
        return (Icon) ic.get(e);
      return null;
    }
  }

}
