package control;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import javax.media.*;
import java.util.*;

import javax.swing.event.*;
import javax.swing.border.*;
import javax.media.protocol.*;
import javax.media.format.*;
import javax.media.control.*;
import javax.media.datasink.*;

public class CopyPart extends JFrame{
  private File file,filerec;
  private String songname = null,detect;
  private JProgressBar jp;

  public CopyPart(){}

  public void openFile(String n){
  JFileChooser fileChooser = new JFileChooser("c://JPV");
  fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
  fileChooser.setDialogTitle(n);
  int result = fileChooser.showOpenDialog(this);
  if (result == JFileChooser.CANCEL_OPTION)
    file = null;
  else
    file = fileChooser.getSelectedFile();

  filerec = file;
  file = null;
  manageString();
  }
  public void manageString(){
    String f1,f2;
          f1 = ".dat";
          f2 = ".DAT";
    int lengname;
          detect = filerec.toString();
          lengname = detect.length();
    //get file to string then get string to char and compare .dat/.DAT //
    char buf[] = new char[4];
          detect.getChars(lengname-4,lengname,buf,0);
          String tmp = new String(buf);

        //System.out.println(buf);
        System.out.println(tmp);
        if (tmp.equals(f1)||tmp.equals(f2))
            { System.out.println("OK...File is correct.");
      }
        else {System.out.println("File is not correct.");
        JOptionPane.showMessageDialog(null,"File is not correct.");
        return;
        }
  }
  public void setSong(){
//--------------To Show input of songname---------------------------------------
    songname = JOptionPane.showInputDialog("Enter name of media : ");
    songname = songname+".mpg";
    System.out.println(detect);
    System.out.println(songname);
//-------------Set directory of destination file------------------------------
    String tmp= new String("c:\\JPV");
    System.out.println("tmp :"+tmp);
    String tmp1 = new String("\\");
    tmp = tmp + tmp1;
    System.out.println("tmp :"+tmp);

//---------Execution   Program------------------------------------------------
    try
    {
      Runtime rt = Runtime.getRuntime();
      Process p = rt.exec("dat2mpg"+" "+detect+" "+tmp+songname);
      System.out.println("dat2mpg"+" "+detect+" "+tmp+songname);
      p.waitFor();
      if(p.exitValue() != 0)
        System.out.println("Failed???");
      else {System.out.println("Successfully executed !!!");
      JOptionPane.showMessageDialog(null,"Reccord Complete...");}
    }
    catch(Exception ex)
    {
      System.out.println("error");
    }
  }

}