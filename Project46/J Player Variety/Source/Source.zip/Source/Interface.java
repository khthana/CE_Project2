package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import javax.media.*;
import java.util.*;

import javax.swing.event.*;
import javax.swing.border.*;
import javax.media.protocol.*;
import javax.media.format.*;
import javax.media.control.*;
import javax.media.datasink.*;

public class Interface extends JFrame {
  //Variable declarations
  //**************************
  //       JComponents      //
  //**************************
  private Container display;
  private JPanel buttonPanel,listPanel;
  private JButton Play,Stop,Capture,Copy,FromURL,PlayRec;
  private JMenuBar menubar;
  private JMenu menuFile,menuView,menuPlay,menuAbout,submenutaskbar,submenuscreen;
  private JMenu subDevice,subFormat;
  private ButtonGroup taskGroup,fullGroup,deviceGroup,formatGroup;
  private JList songList;
  private JScrollPane songScroll;

  //**************************
  //         Objects        //
  //**************************
  private PlayerPart playerPart,toStop,toPlay;
  private RecordingPart setting,toRecord;
  private CopyPart toCopy;
  //**************************
  //         Others        //
  //**************************
  private File mediaFile[] = new File[20] ;
  private URL fileURL;
  private boolean Close;
  private String songFile[] = new String[40];
  private int i=1,playList=0;
private String directory = "c://JPV";
  //Record filed--------------------
  private RecordingPart processor;
  private Processor process;
  private boolean checkrec = false;
 //---------------------------------
  public Interface(){
     super("J Player Variety");
     display = getContentPane();
     File f = new File(directory);
     f.mkdir();

//------------------------------------------------------------------------------
//                  add MenuBar
//------------------------------------------------------------------------------
        menubar = new JMenuBar();
        menuFile = new JMenu("File");
        menuView = new JMenu("View");
        menuPlay = new JMenu("Play");
        menuAbout = new JMenu("About");
//-----------Create MenuItem to MenuFile----------------------------------------
        //========================Action for Open File menu=====================
        JMenuItem OpenFile = new JMenuItem("Open File..");
        OpenFile.addActionListener(
          new ActionListener(){
            public void actionPerformed(ActionEvent event){
              PlayerPart playerPart = new PlayerPart(display);


         mediaFile = playerPart.getFile();
         for(int c=0;c<=mediaFile.length;c++){
         if (mediaFile[c] != null){

           try{
           fileURL = mediaFile[c].toURL();
           songFile[i] = fileURL.toString();
           i++;
           }
           catch(MalformedURLException badURL){
             badURL.printStackTrace();
             playerPart.showErrorMessage("Bad URL");
           }
           toPlay = playerPart;
           display.repaint();
         }
        }

            }
          }
        );
        OpenFile.setMnemonic('O');
        menuFile.add(OpenFile);
        //********************//
        menuFile.addSeparator();
        //*******************//
        //=====================-End Action for Open File menu===================
        JMenuItem clear = new JMenuItem("Clear List");
        clear.addActionListener(
            new ActionListener(){
          public void actionPerformed(ActionEvent event){
            for(int a=1;a<=songFile.length;a++){
            songFile[a] = null;
            display.repaint();
            }
          }
            }
            );
            clear.setMnemonic('c');
            menuFile.add(clear);
        //========================Action for Exit menu==========================
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(
            new ActionListener(){
            public void actionPerformed(ActionEvent event)
                { System.exit(0);
                }
        }
        );
        exit.setMnemonic('x');
        menuFile.add(exit);
        menuFile.setMnemonic('F');
        //========================End Action for Exit menu======================
//-----------Create MenuItem to MenuPlay----------------------------------------
        JMenuItem play = new JMenuItem("Play");
        play.setMnemonic('l');
        play.addActionListener(
            new ActionListener(){
            public void actionPerformed(ActionEvent event)
                { playAction();
                }
        }
        );

        menuPlay.add(play);
//------------------------------------------------------------------------------
        JMenuItem stop = new JMenuItem("Stop");
        stop.setMnemonic('t');
        stop.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent event)
                { stopAction();
                }
        }
        );

        menuPlay.add(stop);
//------------------------------------------------------------------------------
        menuPlay.addSeparator();
        JMenu subRecord = new JMenu("Record");

        JMenuItem setRecord = new JMenuItem("Enable Recording");
        setRecord.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent event){
              RecordingPart setting = new RecordingPart();
              setting.RecordSetting();
              toRecord = setting;
            }
        }
        );
     //==============End Action for Setting>Record>Save to File menu============
        setRecord.setMnemonic('s');
        subRecord.add(setRecord);
        subRecord.addSeparator();
        JMenuItem record = new JMenuItem(">>Record without song");
        record.addActionListener(new ActionListener(){
         public void actionPerformed(ActionEvent event)
             { captureAction();
             }
        }
        );

        record.setMnemonic('e');
        subRecord.add(record);
//------------------------------------------------------------------------------
        JMenuItem recordWithSong = new JMenuItem(">>Record with song");
        recordWithSong.addActionListener(new ActionListener(){
         public void actionPerformed(ActionEvent event)
             { playAction();
               captureAction();
             }
        }
        );

        recordWithSong.setMnemonic('w');
        subRecord.add(recordWithSong);
        menuPlay.add(subRecord);
//------------------------------------------------------------------------------
        JMenuItem copy = new JMenuItem("Copy");
        copy.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent event)
              { copyAction();
              }
         }
         );

        copy.setMnemonic('o');
        menuPlay.add(copy);
//------------------------------------------------------------------------------

        menuPlay.setMnemonic('P');
//------------------------------------------------------------------------------
//-----------Create MenuItem to MenuSetting-------------------------------------

        menuAbout.setMnemonic('a');
     //================ Action for Setting>About menu============
       JMenuItem subAbout = new JMenuItem("About");
       subAbout.addActionListener( new ActionListener(){
         public void actionPerformed(ActionEvent event){
        JOptionPane.showMessageDialog(null,"            J Player Variety\n"+
                                           "Advisor : Dr.Surin Kititornkul\n"+
                                           "              Presented by\n"+
                                           "         Panumas Wongsalert\n"+
                                           "     Wipawee Wishayashakorn\n"+
                                           "Faculty of Computer Engineering\n"+
                                           "                   KMITL\n",
                                           "J Player Variety",JOptionPane.WARNING_MESSAGE);


    }
}
);
        subAbout.setMnemonic('a');
        menuAbout.add(subAbout);


    //==============End Action for Setting>About menu============
//------------------------------------------------------------------------------
//                         Add JMenu to JMenubar
//------------------------------------------------------------------------------
        menubar.add(menuFile);
        menubar.add(menuPlay);
        menubar.add(menuAbout);

        menubar.isBorderPainted();
        setJMenuBar(menubar);

//------------------------------------------------------------------------------
//                            End Of Menu Bar
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                      JList Panel display list of file selected.            //
//------------------------------------------------------------------------------
        songFile[0] = new String("List of Songs...");
        songList = new JList(songFile);
        songList.setVisibleRowCount(3);
        songList.setFixedCellHeight(15);
        songList.setFixedCellWidth(200);

        songList.setSelectionBackground(Color.orange);
        songList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        songScroll = new JScrollPane(songList);
        MouseListener mouseListener = new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            int index = songList.locationToIndex(e.getPoint());
            System.out.println("Double clicked on Item " + index);
            playAction();
        }
          }
        };
        songList.addMouseListener(mouseListener);

        songList.addListSelectionListener(new ListSelectionListener(){
          public void valueChanged(ListSelectionEvent event){
            int a = 0;
            a = songList.getSelectedIndex();
            playList = a;

          }
        }
        );

//------------------------------------------------------------------------------
//                       End of list.                                         //
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//               Panel for playing capabilities = "buttonPanel"
//------------------------------------------------------------------------------
    //====="buttonPanel"====
    buttonPanel = new JPanel();
    buttonPanel.setBackground(Color.black);      //add Panel Part1 to Container
    display.add(buttonPanel,BorderLayout.SOUTH);//Position of buttons

    //Decorate Buttons style
    Border b = new BevelBorder(BevelBorder.RAISED);

   /////Play Button/////
    Icon Iplay = new ImageIcon("play.gif");
    Play = new JButton(Iplay);
    Play.setToolTipText("Play file");
    Play.setBackground(Color.white);
    Play.setBorder(b);
    //==============Action for Play button=====================
    Play.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent event){
      playAction();
      }
    });
    //==============Action for Play and Record button==============
    //=============================================================
    // Play and Record
    Icon IplayRec = new ImageIcon("playrecord.gif");
    PlayRec = new JButton(IplayRec);
    PlayRec.setToolTipText("Play and Record your voice.");
    PlayRec.setBackground(Color.white);
    PlayRec.setBorder(b);
    //==============Action for Play button=====================
    PlayRec.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent event){
      playAction();
      captureAction();
      }
    });

    //==============END Action for Play and Record button=====================

    /////Stop Button/////
    Icon Istop = new ImageIcon("stop.gif");
    Stop = new JButton(Istop);
    Stop.setToolTipText("Stop.");
    Stop.setBackground(Color.white);
    Stop.setBorder(b);
    //================= Action for Stop button=====================
    Stop.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent event){
      stopAction();
      }
    });
    //==============END Action for Stop button=====================

    //Capture button >>> Record sound and Save file
    Icon Icapture = new ImageIcon("record.gif");
    Capture = new JButton(Icapture);
    Capture.setToolTipText("Record your voice and save.");
    Capture.setBorder(b);
    Capture.setBackground(Color.white);
    //================Action for Capture button====================
    Capture.addActionListener(
      new ActionListener(){
            public void actionPerformed(ActionEvent event){
            captureAction();
            }
      }
      );
    //================End Action for Capture button================


    /////Copy button ////
    //>>> copy file from CD,Rename and save to system.
    Icon Icopy = new ImageIcon("copy.gif");
    Copy = new JButton(Icopy);
    Copy.setToolTipText("Copy Media file into your system");
    Copy.setBorder(b);
    Copy.setBackground(Color.white);
    //=================== Action for Copy button===================
    Copy.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
          copyAction();
       }
    });
    //==================End Action for Copy button=================

    //===================END Action for OpenURL====================
    buttonPanel.add(Play);
    buttonPanel.add(PlayRec);
    buttonPanel.add(Stop);
    buttonPanel.add(Capture);
    buttonPanel.add(Copy);;
    buttonPanel.add(songScroll);




    setSize(1024,738);
    setVisible(true);
  }


//------------------------------------------------------------------------------
//---------------Play Action Part-----------------------------------------------
  public void playAction(){
    boolean Stop = false;
      System.out.println("songFile[playList] ="+songFile[playList]);
 //---------Return .MPG or not--------------------------------------------------
      String mpg1,mpg2,mpg3;
        mpg1 = ".mpg";
        mpg2 = ".MPG";
        mpg3 = ".mpeg";
  int lengname;
  String  detect;
        detect = songFile[playList].toString();
        lengname = detect.length();
  //get file to string then get string to char and compare .mpg/.MPG //
  char checkmpg[] = new char[4];
        detect.getChars(lengname-4,lengname,checkmpg,0);
        String tmp1 = new String(checkmpg);
        System.out.println("tmp1 ="+tmp1);

       if (tmp1.equals(mpg1)||tmp1.equals(mpg2)||tmp1.equals(mpg3))
          {toPlay.setIsMpeg(true); }
      else {toPlay.setIsMpeg(false);}



 //-----------------------------------------------------------------------------
      Stop = toPlay.makePlayer(songFile[playList]);
      Close = Stop;
      toStop = toPlay;


  }
//------------------------------------------------------------------------------

//---------------Stop Action Part-----------------------------------------------
  public void stopAction(){
    if (Close){
    toStop.removePlayerComponent();
          System.out.println("That's right.");}


    if(checkrec){
    process.stop();
    process.close();
    checkrec = false;
    System.out.println ( "checkrec = "+checkrec);
    System.out.println ( "Capture closed." );
    }
    else System.out.println("Bad Action");



  }
//------------------------------------------------------------------------------
  private DataSink dataSink;
//---------------Capture Action Part--------------------------------------------
  public void captureAction(){
    System.out.println ( "Capture open." );
    process = toRecord.getprocess();
    dataSink = toRecord.getdatasink();

    checkrec = true;
    System.out.println("checkrec = "+checkrec);
  }

//------------------------------------------------------------------------------
//---------------Copy Action Part-----------------------------------------------
  public void copyAction(){
    CopyPart toCopy = new CopyPart();
          toCopy.openFile("Search File *.dat for Record to Karaoke Temp.");
            toCopy.setSong();
  }
//------------------------------------------------------------------------------

 public static void main(String args[]){
   Interface application = new Interface();
   application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}