package control;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.media.*;
import java.util.*;

import javax.swing.event.*;
import javax.media.protocol.*;
import javax.media.format.*;
import javax.media.control.*;
import javax.media.datasink.*;

public class RecordingPart extends JFrame {
  private Vector deviceList;
  private Component saveProgress;
  private Format formats[],selectedFormat;
  private FormatControl formatControls[];
  private CaptureDeviceInfo deviceInfo;
  private DataSource inSource,outSource;
  private Processor processor;
  private DataSink dataSink;
 ///////////////////////////////////////////////
 ///////////==Check File Output to Record///////
  private boolean checkfile = false;
  private File saveFile,temp;
  private MediaLocator tempsavelocator,saveLocator;
 ///////////////////////////////////////////////
public void RecordingPart(){}
  // initialize and configure capture device
public void RecordSetting(){
   // put available devices' information into vector
   deviceList =  CaptureDeviceManager.getDeviceList( null );

   // if no devices found, display error message
   if ( ( deviceList == null ) || ( deviceList.size() == 0 ) ) {
      showErrorMessage( "No capture devices found!" );
      return;
   }

   // array of device names
   String deviceNames[] = new String[ deviceList.size() ];

   // store all device names into array of
   // string for display purposes
      int i = 0;
      deviceInfo = ( CaptureDeviceInfo ) deviceList.elementAt( i );
      deviceNames[ i ] = deviceInfo.getName();

      System.out.println(deviceNames[i]);

   // get device information of selected device
   deviceInfo = ( CaptureDeviceInfo )
                   deviceList.elementAt(0);

   formats = deviceInfo.getFormats();

   // if previous capture device opened, disconnect it
   if ( inSource != null )
      inSource.disconnect();

   // obtain device and set its format
   try {
      // create data source from MediaLocator of device
      inSource = Manager.createDataSource(
         deviceInfo.getLocator() );

      // get format setting controls for device
      formatControls = ( ( CaptureDevice )
         inSource ).getFormatControls();

      // get user's desired device format setting
      selectedFormat = formats[1];
      System.out.println(selectedFormat);
      if ( selectedFormat == null )
         return;

      setDeviceFormat( selectedFormat );
//************************************************
      captureSaveFile();

   }  // end try

   // unable to find DataSource from MediaLocator
   catch ( NoDataSourceException noDataException ) {
      noDataException.printStackTrace();
   }

   // device connection error
   catch ( IOException ioException ) {
      ioException.printStackTrace();
   }

}  // end method actionPeformed


// pop up error messages
public void showErrorMessage( String error )
{
  JOptionPane.showMessageDialog( this, error, "Error",
     JOptionPane.ERROR_MESSAGE );
}
// get selected device vector index
 public int getSelectedDeviceIndex( String[] names )
 {
    // get device name from dialog box of device choices
    String name = ( String ) JOptionPane.showInputDialog(
       this, "Select a device:", "Device Selection",
       JOptionPane.QUESTION_MESSAGE,
       null, names, names[ 0 ] );

    // if format selected, get index of name in array names
    if ( name != null )
       return Arrays.binarySearch( names, name );

    // else return bad selection value
    else
       return -1;
}
// return user-selected format for device
public Format getSelectedFormat( Format[] showFormats )
{
return ( Format ) JOptionPane.showInputDialog( this,
   "Select a format: ", "Format Selection",
   JOptionPane.QUESTION_MESSAGE,
   null, showFormats, null );
}
// set output format of device-captured media
public void setDeviceFormat( Format currentFormat )
{
 // set desired format through all format controls
 for ( int i = 0; i < formatControls.length; i++ ) {

    // make sure format control is configurable
    if ( formatControls[ i ].isEnabled() ) {

       formatControls[ i ].setFormat( currentFormat );

       System.out.println (
          "Presentation output format currently set as "+
          formatControls[ i ].getFormat() );
    }

 }  // end for loop
}
// process captured media and save to file
public void captureSaveFile()
{
 // array of desired saving formats supported by tracks
 Format outFormats[] = new Format[ 1 ];

 outFormats[ 0 ] = selectedFormat;

 // file output format
 FileTypeDescriptor outFileType =
    new FileTypeDescriptor( FileTypeDescriptor.MPEG_AUDIO );

 // set up and start processor and monitor capture
 try {

    // create processor from processor model
    // of specific data source, track output formats,
    // and file output format
    processor = Manager.createRealizedProcessor(
       new ProcessorModel( inSource, outFormats,
          outFileType ) );

    // try to make a data writer for media output
    if ( !makeDataWriter() )
       return;

 }  // end try

 // no processor could be found for specific
 // data source
 catch ( NoProcessorException processorException ) {
    processorException.printStackTrace();
 }

 // unable to realize through
 // createRealizedProcessor method
 catch ( CannotRealizeException realizeException ) {
    realizeException.printStackTrace();
 }

 // device connection error
 catch ( IOException ioException ) {
    ioException.printStackTrace();
 }

}  // end method captureSaveFile

// method initializing media file writer
public boolean makeDataWriter()
{
     if(!checkfile){
        saveFile = getSaveFile();
        temp = saveFile;
        if ( saveFile == null ) return false;}
       else{saveFile = temp;}
     System.out.println("checkfile = "+checkfile);
     System.out.println("file = "+saveFile);

// get output data source from processor
outSource = processor.getDataOutput();

if ( outSource == null ) {
  showErrorMessage( "No output from processor!" );
  return false;
}

// start data writing process
try {

  // create new MediaLocator from saveFile URL
  saveLocator =new MediaLocator ( saveFile.toURL()+".mp3" );
  tempsavelocator = saveLocator;
  // create DataSink from output data source
  // and user-specified save destination file
  dataSink = Manager.createDataSink(
     outSource, saveLocator );

  // register a DataSinkListener for DataSinkEvents
  dataSink.addDataSinkListener(

     // anonymous inner class to handle DataSinkEvents
     new DataSinkListener () {

        // if end of media, close data writer
        public void dataSinkUpdate(
           DataSinkEvent dataEvent )
        {
           // if capturing stopped, close DataSink
           if ( dataEvent instanceof EndOfStreamEvent )
              dataSink.close();
        }

     }  // end DataSinkListener

  ); // end call to method addDataSinkListener

  // start saving
  dataSink.open();
  dataSink.start();

}  // end try

// DataSink could not be found for specific
// save file and data source
catch ( NoDataSinkException noDataSinkException ) {
  noDataSinkException.printStackTrace();
  return false;
}

// violation while acessing MediaLocator
// destination
catch ( SecurityException securityException ) {
  securityException.printStackTrace();
  return false;
}

// problem opening and starting DataSink
catch ( IOException ioException ) {
  ioException.printStackTrace();
  return false;
}

return true;

}  // end method MakeDataWriter

// get desired file for saved captured media
public File getSaveFile()
{

JFileChooser fileChooser = new JFileChooser("c://JPV");

fileChooser.setFileSelectionMode(
JFileChooser.FILES_AND_DIRECTORIES);

int result = fileChooser.showSaveDialog( this );

if ( result == JFileChooser.CANCEL_OPTION )
 return null;

else
 return fileChooser.getSelectedFile();
}


  public Processor getprocess()
  { if(!checkfile){
    processor.start();
    checkfile = true;}
    else{
    processor.start();
    }
    return processor;
  }
  public DataSink getdatasink(){
    return dataSink;
  }

}
