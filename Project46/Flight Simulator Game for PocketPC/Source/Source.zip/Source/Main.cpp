//--------------------------------------------------------------------------------------
// Main.cpp source file
// Created by Diesel Application Wizard v:1.31
// Copyright (c) 2000-2003 Inmar Software Ltd.
//
// Date: 4.10.2003
//
// FSPPC Application main function and DieselEngine Initialization
//  
//--------------------------------------------------------------------------------------

#include "FSPPCApp.h"
#include "resource.h"



// Application 'main' function
int DieselMain()
{
	// Initialize DieselEngine
	FSPPCApp *pApp = NULL;
	{
		DE_RETVAL		res = DE_OK;

		pApp = SAFE_NEW(FSPPCApp);
		if (pApp == NULL)
		{
			// out of memory
			return -1;
		}


		// set the application title. this text shows
		// on application main window and OS tasklist
		pApp->SetAppTitle(_T("Flight X sim PPC"));

		// Set Application resource IDs here
		// First parameter:		menu resource identifier
		// Second parameter:	icon resource identifier
		// Third parameter:		acceleration resource identifier
		pApp->SetResources(0, IDI_APPICON, 0);

		// initialize the display mode structure
		// in DirectX builds, if engine is initialized
		// to windowed mode, 'iRefresh' and 'iBPP' members
		// of structure has no meaning.
		SDE_DISPLAYMODE		mode;

		// use target device default display mode.
		// get device display modes, first mode is devices
		// default fullscreen mode, exept on desktop PC, which
		// supports multiple fullscreen display modes.
		CDieselArray<SDE_DISPLAYMODE> displaymodes;
		pApp->GetDisplayModes(&displaymodes);
		mode = displaymodes.GetAt(0);
		displaymodes.Clear();

		// reset display mode values on desktop PC
		// Change these to run in different resolution
		// or window size.

		mode.bWindowed = FALSE;	//Full screen mode when on PPC
		#ifdef DE_PC
		mode.iWidth = 640;
		mode.iHeight = 480;
		mode.iRefresh = 0;
		mode.dwFlags = 0;
		mode.bWindowed = FALSE;
		#endif
		

		// try to change the iBPP member to 8.
		// DieselEngine uses full color emulation to
		// produce full support of features with 8 bit surfaces.
		// the value 0 selects devices native bits per pixel
		// value (16 on desktop PC)
		mode.iBPP = 0;
		

		// uncomment this to run in windowed mode.
		// Note, that DesktopPC DEBUG builds are
		// forced to windowed mode.
		//mode.bWindowed = TRUE;

		// following flags are used on dwFlags member of the
		// display mode structure
		// DE_WINDOWLOCKED	- application window cannot be resized
		// DE_FORCEHARDWARE -	(DirectX specific) starts the engine
		//						only if hardware display device is found
		//						( this flags is usually only for debugging)
		// DE_FORCESOFTWARE -	(DirectX specific) starts engine
		//						without hardware support
		//						( this flags is usually only for debugging)
		//
		// Uncomment following line to lock the window size.
		// When window size is locked, user cannot change
		// window size.

		mode.dwFlags |= DE_WINDOWLOCKED;
		mode.dwFlags |= DE_FORCESOFTWARE;



		// Startup the engine. If derived class OnInitDone function failed,
		// return value is passed here
		// First parameter:		The display device identifier
		//						Use IDieselApplication 'GetDisplayDevices'
		//						function to retreive all installed devices
		// Second parameter:	The display mode structure
		res = pApp->Startup(NULL, &mode);
		if (res != DE_OK)
		{
			// failed to start application
			// either the OnInitDone function returned
			// error, or IDieselApplication object failed 
			// to initialize.
			SAFE_DELETE(pApp);
			CDieselSafeMemory::CheckMemoryLeaks();
			return 0;
		}
	}

	// start pumping messages
	// DieselApplication function 'Run' returns
	// the last message value from os message pump
	int ret = 0;
	ret = pApp->Run();
	SAFE_DELETE(pApp);
	CDieselSafeMemory::CheckMemoryLeaks();
	return ret;
}



// The WIN32 main function
#ifdef WIN32
int PASCAL WinMain(		HINSTANCE hInstance,
						HINSTANCE hPrevInstance,
						TCHAR *pCmdLine,
						int nCmdShow)
{
	return DieselMain();
}

#endif	// #ifdef WIN32


