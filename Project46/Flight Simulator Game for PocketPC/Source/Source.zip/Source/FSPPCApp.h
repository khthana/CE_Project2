//----------------------------------------------------------------------
// SPPCApp.h: interface for the FSPPCApp class.
// Date: 4.10.2003
//
// Created by Diesel Application Wizard v:1.31
// Copyright (c) 2000-2003 Inmar Software Ltd.
//
//----------------------------------------------------------------------



#ifndef __FSPPCAPP_H__
#define __FSPPCAPP_H__


#include <Diesel.h>
#include <DieselGraphics.h>
#include <Diesel3D.h>
#include <Diesel3DScene.h>
#include <Diesel3DObjectGenerator.h>
#include <Diesel3DParticleEmitter.h>
#include <DieselInput.h>
//network include
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>


class FSPPCApp : public IDieselApplication  
{
public:
	// construction & destruction
	FSPPCApp();
	virtual ~FSPPCApp();
	void OnFlip();
	DE_RETVAL OnInitDone();
	void OnExit();
	void OnMouseButton(DWORD dwButton, LONG x, LONG y);
	void OnKeyDown(DWORD dwKey);
	void CreateObject(double ,double*,float,float,float spacing,int height_factor);
	void PrepareObject(double &,double* Vertex_list,char* InputFilename);
	void CreateOceanA(double GridAmount,float x_start,float y_start,float spacing,float height);
	void CreateOceanB(double GridAmount,float x_start,float y_start,float spacing,float height);
	void ViewCockpit();
	bool HitMountain(double* Vertex_list,int width,float spacing,float current_x,float current_y,float current_sky,int height_factor);
	bool HitTest(float a,float b,float c,float x,float y,float z);
	void InterpolateMaterialColor(CDiesel3DMaterial *pMat, CDiesel3DColor &col1, CDiesel3DColor &col2, float &fMul);
	bool TimeUp(double &time_input,double time_compare, double time_increse);
	int DecreseBar(int max_pos,int min_pos,int max_value,int current_value);
	float Calculate_Accel(float plane_speed,int engine_percent,float weight);
	float Fuel_Consume(int engine_percent);
	bool Is_Target_Locked();
	void Homing_Adjust();
	void Homing_Adjust2();
	float SetExplodeParticle(float x, float y, float z);
	bool BulletTime;
	double BulletTimeDelay;
	void ShowEnemyDamage(float x,float y,float z,float SmokeSize);
	void ShowEnemyCrash(float x,float y,float z);
	void ShowMyCrash(float x,float y,float z);
	bool IsEmitterOtherBusy;
	void SetJetStream(bool status,int step=1);//step 1=low 3=max
	bool IsVisibleJetStream();
	void EnemySetPos(float x,float y, float z);
	void EnemySetDirSpeed(float dirX,float dirY, float dirZ, float speed);
	void MakeMovementList();
	bool IsShouldNextPoint(int currentPoint);
	void EnemyManipulate();
	void EnemyMissileManipulate();
	bool ServerCreate(char*);
	bool ServerAccept();
	bool ServerSend(char* msg);
	bool ServerRecv(char* msg);
	void ServerClose();
	bool ClientCreate(char* IP,char* Port);
	bool ClientConnect();
	bool ClientSend(char* msg);
	bool ClientRecv(char* msg);
	void ClientClose();

	void long_s(char *s,long l);
	void int_s(char *s,int i);
	int s_long(char *s);
	long s_int(char *s);
	void encode(char *s,int x1,char x2,char x3,long x,long y,long z);
	void decode(char *s,int &x1,char &x2,char &x3,long &x,long &y,long &z);

	void EnemyDir(float x,float y,float z);
	void EnemyMissileDir(float x,float y,float z);

	


private:
	CDieselWriter				m_Writer;
	CDieselWriter				m_WriterRed;
	CDiesel3DVertexBuffer		m_Vertices;
	CDiesel3DIndexBuffer		m_Indices;
	
	
	CDiesel3DDevice				m_3DDevice;			
	CDiesel3DScene				m_Scene;			//main scene, use to handle object
	CDieselSurface				m_srfBillboard;		//Serface 
	
	
	//CDiesel3DObject				*m_pObj;			//use to control each object
	IDiesel3DObject				*m_pObjPlane;
	IDiesel3DObject				*m_pObjPlane2;
	IDiesel3DObject				*m_pObjField;
	IDiesel3DObject				*m_pObjMissile;
	IDiesel3DObject				*m_pObjMissile2;
	//CDiesel3DObject				*m_Plane3;
	//IDiesel3DObject				*m_pObjPlane3;
	//IDiesel3DObject				*m_pObjPlane4;
	
	CDiesel3DParticleEmitter	*m_pEmitter;		// pointer to the particle-emitter.
	CDiesel3DParticleEmitter	*m_pEmitter2;		// pointer to the particle-emitter.
	CDiesel3DParticleEmitter	*m_pEmitterPlaneA;		// pointer to the particle-emitter.
	CDiesel3DParticleEmitter	*m_pEmitterPlaneB;		// pointer to the particle-emitter.
	CDiesel3DParticleEmitter	m_EmitterExplode;
	CDiesel3DParticleEmitter	m_EmitterOther;
	float ExplodeParticlePlane;	
	double ExplodeTime;
	CDiesel3DVertexBuffer		m_VerticesA;
	CDiesel3DIndexBuffer		m_IndicesA;
	CDiesel3DVertexBuffer		m_VerticesB;
	CDiesel3DIndexBuffer		m_IndicesB;
	bool flag_useA;
	bool flag_useB;
	
	CDieselMediaPack			m_mpMyPack;				// mediapack
	CDiesel3DLight				*m_pLight;
	


	int				m_iXpos[22];			// picture positions
	int				m_iYpos[22];
	CDieselSurface	m_srfPic[22];		// 3 surfaces for our pictures
	
	

	bool test;
	bool test2;


	float	m_fAngle;
	float	m_fRotationX;
	float	m_fRotationY;
	float	m_fRotationZ;
	float lightVal;

	bool	ClickOut;
	int iPosX,iPosY;
	DWORD dwTime;	


	CDiesel3DCamera				m_Camera;
	void CreateGround();
	void CreateCameraAnimation(CDiesel3DCamera *pCam);
	void InitCamera();

	CDiesel3DObject				m_3DObject;
	
	CDiesel3DMaterial			m_Material;
	CDiesel3DMaterial			m_Material_Ocean;
	
	CDiesel3DColor				m_cColor1;
	CDiesel3DColor				m_cColor2;
	float						m_fColorMul;

	double listy[32761];//181*181

	//---------- Airplane parameter
	float roll_angle;
	float plane_speed;
	float missile_speed;
	int engine_percent;
	//bool show_cockpit;
	bool left_wing;
	
	
	double missile_btn_time;
	bool draw_missile_btn;
	int missile_amount;
	int missile_amount_all;
	float missile_view_angle;
	float missile_view_distance1;
	float missile_view_distance2;
	bool missile_target_locked;

	double EnemyRespawnTime;
	double EnemyFireTime;

	double ToggleTime1;
	bool BlinkOn1;

	double ToggleTime2;
	bool BlinkOn2;

	double ShowDamageTime;

	float fuel_amount,fuel_amount_all;

	int camera_view;
	
	bool Deploy_camera;
	CDieselVector3 Deploy_camera_pos; //use by "External View2"
	CDieselVector3 Gravity_Vec,Float_Vec;
	bool Is_Float;
	CDieselVector3 DistanceBetween;
	int MyPlaneHealth,EnemyHealth,MyPlaneHealth_all;

	int GameMenu;

	int currentList;
	CDieselVector3 EnemyMoveList_Pos[50];
	CDieselVector3 EnemyMoveList_Dir[50];
	float EnemyMoveList_Speed[50];

	float PlaneWeight;


	double UpdatePosTime;
	double UpdateDirTime;
	double UpdateMissilePosTime;
	double UpdateMissileDirTime;	


	//float hy,hp,ey,ep;
	//--------- for network connection (server)
	WSADATA wsda;					// Structure to store information returned from WSAStartup
	int iPort, iAddrLen;
	SOCKET sListen, sClient;       // Our TCP socket handle
	SOCKADDR_IN addr,remote_addr;	// The local interface,// The address of the connecting host
	timeval timeout;

	//--------- for network connection (client)

	SOCKET sockConnect,retConnect;
	int connection_state;
	double seq_number;
	char serverIP[16];
	int serverIPcounter;
	char msg_recv[30];
		
};

#endif // ifndef __SPPCAPP_H__

