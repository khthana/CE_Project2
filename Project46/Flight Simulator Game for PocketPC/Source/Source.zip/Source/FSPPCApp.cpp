#include "FSPPCApp.h"
#include "windows.h"
#include "winbase.h"
//#include "winsock2.h"
//#include "stdio.h"
//#include "stdlib.h"
#include "time.h"

#ifdef WIN32
#define KEY_RETURN	VK_RETURN
#define KEY_UP		VK_UP
#define KEY_DOWN	VK_DOWN
#define KEY_RIGHT	VK_RIGHT
#define KEY_LEFT	VK_LEFT
#define KEY_SPACE	VK_SPACE
#define DEG90		1.5707963267948965923f
#define DEG180		PI
#define	DEG270		4.7123889803846897769f
#define DEG360		6.2831853071795863692f
#define	RADTODEG_DIV2 28.647889756541161432325
#endif
#define DEFAULT_BUFFER      2048

//----------------------------------------------------------------------
//
// Construction/Destruction
//
//----------------------------------------------------------------------

FSPPCApp::FSPPCApp()
{
	m_fRotationX = 0.0;
	m_fRotationY = 0.0;
	m_fRotationZ = 0.0;
	m_fAngle = 0.0;
	lightVal=0.1f;
	ClickOut=false;
	test = false;
	test2=false;
	flag_useA=false;
	flag_useB=false;
	plane_speed=0.0f;
	missile_speed=0.0f;
	engine_percent=0;
	//show_cockpit=true;
	
	left_wing=true;

	missile_amount_all=20;
	missile_amount=missile_amount_all;
	fuel_amount_all=30000.0f;
	fuel_amount=fuel_amount_all;
	
	
	missile_btn_time=0.0;
	draw_missile_btn=false;

	camera_view=1;//1=int, 2=ext1, 3= ext2, 4=attack view
	missile_view_angle=0.0f;
	missile_view_distance1=0.5f;
	missile_view_distance2=0.5f;
	missile_target_locked=false;

	Deploy_camera=false;
	Gravity_Vec.Set(0.0f,-5.0f,0.0f);
	//Gravity_Vec.Set(0.0f,0.0f,0.0f);
	Float_Vec.Set(0.0f,5.0f,0.0f);
	Is_Float=false;
	ExplodeParticlePlane=0.0f;

	BulletTime=false;
	BulletTimeDelay=0;
	MyPlaneHealth_all=5;
	MyPlaneHealth=MyPlaneHealth_all;
	EnemyHealth=2;

	IsEmitterOtherBusy=false;
	
	EnemyRespawnTime=0.0f;
	EnemyFireTime=0.0f;

	GameMenu=0;//0=first screen, 1=play menu select, 2=netplay menu select, 3=help menu select , 4=exit menu select
	currentList=0;

	BlinkOn1=true;
	BlinkOn2=true;
	ShowDamageTime=100;
	PlaneWeight=0.0f;

	connection_state=0;
	seq_number=0;
	serverIPcounter=0;


	UpdatePosTime=0;
	UpdateDirTime=0;
	UpdateMissilePosTime=0;
	UpdateMissileDirTime=0;	


}

FSPPCApp::~FSPPCApp()
{
}


//----------------------------------------------------------------------
// OnInitDone()
//----------------------------------------------------------------------
DE_RETVAL FSPPCApp::OnInitDone()
{
	
	DE_RETVAL	answer = DE_OK;				//use to take return condition	
	//===== initialize the 3d device
	DWORD dwFlags = 0;
	dwFlags |= DE_CREATEZBUFFER;
	dwFlags |= DE_FORCESOFTWARE;
	//dwFlags |= DE_FP_TRANSFORMATION;		//** to improve performance **

	SDE_SURFACEDESC		desc;			// structure to hold our surface information
	desc.dwFlags = DE_SYSTEMMEMORY;		// create the surface in system memory, faster to read/write
										// when using some exotic 'Blt' functions
	desc.eFormat = eDE_COMPATIBLE;		// eDE_COMPATIBLE creates the surface in same format with the backbuffer
	desc.iHeight = 0;					// use the dimensions defined in files
	desc.iWidth = 0;


	answer = m_3DDevice.Startup(dwFlags);
	if (answer != DE_OK)	return answer;
	
	

	//===== initialize the scene
	m_Scene.Startup();
	
	//double listy[961];
	//double listy[3721];
	//double listy[32761];//181*181
	//double listy[130321];
	double gmm;
	PrepareObject(gmm,listy,"island_180.txt");
	CreateObject(gmm,listy,0,0,15.0f,30);
	
	
	//===== Load mediapackage
	// file -> pointer to file -> Scene load from pointer
	TCHAR path[MAX_PATH];
	BuildFilepath(path, _T("myPack.dmp"));	// in PPC, want full path for file location
	answer = m_mpMyPack.Startup(path);		// set m_mpMyPack to handle "dump file"
	if (answer != DE_OK){
		MsgBox(	_T("Error"),_T("not found \"myPack.dmp\""));
		return answer;
	}
	
	//---------- load image
	//-----------load cockpit---------------
	answer = m_srfPic[0].LoadFromPack( &m_mpMyPack, "cockpit.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"cockpit.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[0]=0;
	m_iYpos[0]=113;
	m_srfPic[0].SetAutoColorKey();

	//---------- load guage ADI ----------------
	answer = m_srfPic[1].LoadFromPack( &m_mpMyPack, "adi.bmp", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"adi.bmp\" in \"myPack.dmp\" "));
		return answer;
	}
	//m_iXpos[1]=91;m_iYpos[1]=193;//point of top-left of image
	m_iXpos[1]=120;m_iYpos[1]=222;//center for rotate
	m_srfPic[1].SetAutoColorKey();

	//----------- load font --------------------
	answer = m_srfPic[2].LoadFromPack( &m_mpMyPack, "font.bmp",0,&desc);
	if(answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"font.bmp\" in \"myPack.dmp\" "));
		return answer;
	}
	m_Writer.Startup(&m_srfPic[2], -1, 10);
	
	//------------load shield ------------------
	answer = m_srfPic[3].LoadFromPack( &m_mpMyPack, "shield2.gif",0,&desc);
	if(answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"shield.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[3]=78;
	m_iYpos[3]=116;
	m_srfPic[3].SetAutoColorKey();
	//------------ load arrow -----------------
	answer = m_srfPic[4].LoadFromPack( &m_mpMyPack, "arrow.gif",0,&desc);
	if(answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"arrow.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[4]=8;
	m_iYpos[4]=156;//initial position
	m_srfPic[4].SetAutoColorKey();

	//----------- load Radar ---------------
	answer = m_srfPic[5].LoadFromPack( &m_mpMyPack, "radar.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"radar.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[5]=68;m_iYpos[5]=221;//center for rotate
	m_srfPic[5].SetAutoColorKey();

	//----------- load fire_btn ---------------
	answer = m_srfPic[6].LoadFromPack( &m_mpMyPack, "fire_btn.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"fire_btn.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[6]=166;m_iYpos[6]=216;//center for rotate

	//----------- load below_bar ---------------
	answer = m_srfPic[7].LoadFromPack( &m_mpMyPack, "below_bar.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"below_bar.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[7]=0;m_iYpos[7]=305;//center for rotate

	//----------- load below_bar diable---------------
	answer = m_srfPic[8].LoadFromPack( &m_mpMyPack, "below_bar_disable.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"below_bar_disable.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[8]=134;m_iYpos[8]=307;//center for rotate

	//----------- load bar M
	answer = m_srfPic[9].LoadFromPack( &m_mpMyPack, "bar_a.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"bar_a.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[9]=165;m_iYpos[9]=219;//center for rotate
	//----------- load bar H
	answer = m_srfPic[10].LoadFromPack( &m_mpMyPack, "bar_b.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"bar_b.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[10]=178;m_iYpos[10]=219;//center for rotate
	//----------- load bar F
	answer = m_srfPic[11].LoadFromPack( &m_mpMyPack, "bar_f.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"bar_f.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[11]=191;m_iYpos[11]=219;//center for rotate

	//----------- load throttle 
	answer = m_srfPic[12].LoadFromPack( &m_mpMyPack, "throttle_bar.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"throttle_bar.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[12]=88;m_iYpos[12]=279;//center for rotate

	//----------- load Ok_Lock target warning screen
	answer = m_srfPic[13].LoadFromPack( &m_mpMyPack, "ok_lock.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"ok_lock.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[13]=89;m_iYpos[13]=134;//center for rotate

	//----------- load FirstScreen
	answer = m_srfPic[14].LoadFromPack( &m_mpMyPack, "firstscreen.jpg", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"firstscreen.jpg\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[14]=0;m_iYpos[14]=0;//center for rotate

	//----------- load Help Screen
	answer = m_srfPic[15].LoadFromPack( &m_mpMyPack, "helpscreen.jpg", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"helpscreen.jpg\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[15]=0;m_iYpos[15]=0;//center for rotate

	//----------- load arrow
	answer = m_srfPic[16].LoadFromPack( &m_mpMyPack, "arrow.bmp", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"arrow.bmp\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[16]=150;m_iYpos[16]=249;//center for rotate

	//----------- load Red font--------------------
	answer = m_srfPic[17].LoadFromPack( &m_mpMyPack, "fontred.gif",0,&desc);
	if(answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"fontred.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_WriterRed.Startup(&m_srfPic[17], -1, 10);

	//----------- warning 
	answer = m_srfPic[18].LoadFromPack( &m_mpMyPack, "warning.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"warning.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[18]=0;m_iYpos[18]=0;
	m_srfPic[18].SetAutoColorKey();

	//----------- warning 2
	answer = m_srfPic[19].LoadFromPack( &m_mpMyPack, "warning2.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"warning2.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[19]=0;m_iYpos[19]=0;
	m_srfPic[19].SetAutoColorKey();

	//----------- Exit button (netplay screen)
	answer = m_srfPic[20].LoadFromPack( &m_mpMyPack, "exit.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"exit.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[20]=194;m_iYpos[20]=304;
	m_srfPic[20].SetAutoColorKey();

	//----------- Num pad -----------
	answer = m_srfPic[21].LoadFromPack( &m_mpMyPack, "numpad.gif", 0, &desc );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"numpad.gif\" in \"myPack.dmp\" "));
		return answer;
	}
	m_iXpos[21]=75;m_iYpos[21]=85;
	


	
	




	//----- Load model
/*	answer = m_Scene.LoadFromPack( &m_mpMyPack, "3D_ObjSJP");	//load object from file to m_Scene
	if (answer != DE_OK){
		MsgBox(	_T("Error"),_T("not found \"3D_ObjSJP\" in \"myPack.dmp\" "));
		return answer;
	}
*/	answer = m_Scene.LoadFromPack( &m_mpMyPack, "F16");	//load object from file to m_Scene
	if (answer != DE_OK){
		MsgBox(	_T("Error"),_T("not found \"F16\" in \"myPack.dmp\" "));
		return answer;
	}
	answer = m_Scene.LoadFromPack( &m_mpMyPack, "F22");
	if (answer != DE_OK){
		MsgBox( _T("Error"),_T("not found \"F22\" in \"myPack.dmp\" "));
		return answer;
	}

	answer = m_Scene.LoadFromPack( &m_mpMyPack, "field");
	if (answer != DE_OK){
		MsgBox( _T("Error"),_T("not found \"field\" in \"myPack.dmp\" "));
		return answer;
	}

	answer = m_Scene.LoadFromPack( &m_mpMyPack, "missile");
	if (answer != DE_OK){
		MsgBox(	_T("Error"),_T("not found \"missile\" in \"myPack.dmp\" "));
		return answer;
	}

	answer = m_Scene.LoadFromPack( &m_mpMyPack, "missile2");
	if (answer != DE_OK){
		MsgBox(	_T("Error"),_T("not found \"missile2\" in \"myPack.dmp\" "));
		return answer;
	}
	//load surface
	SDE_SURFACEDESC desc2;
	desc2.iWidth = 256;	// force surface to 256x256
	desc2.iHeight = 256;
	desc2.eFormat = eDE_COMPATIBLE;
	desc2.dwFlags = DE_TEXTURE;
	answer = m_srfBillboard.LoadFromPack( &m_mpMyPack, "explosion.jpg",0, &desc2 );
	if (answer != DE_OK)
	{
		MsgBox( _T("Error"),_T("not found \"explosion.jpg\" in \"myPack.dmp\" "));
		return answer;
	}
	m_mpMyPack.Shutdown();				//close after use

	//-------get Pointer form scene
/*	m_pObjPlane = m_Scene.FindObject( "SJP", m_Scene.GetRootObject() );
	if (m_pObjPlane == NULL){
		MsgBox(_T("Error"),_T("not found \"SJP\" object from scene"));
	}
	
*/	m_pObjPlane = m_Scene.FindObject( "F16", m_Scene.GetRootObject() );
	if (m_pObjPlane == NULL){
		MsgBox(_T("Error"),_T("not found \"F16\" object from scene"));
	}


	m_pObjPlane2 = m_Scene.FindObject( "F22", m_Scene.GetRootObject() );
	if (m_pObjPlane2 ==NULL){
		MsgBox(_T("Error"),_T("not found \"F22\" object from scene"));
	}
	
	m_pObjField = m_Scene.FindObject( "field", m_Scene.GetRootObject() );
	if (m_pObjField ==NULL){
		MsgBox(_T("Error"),_T("not found \"field\" object from scene"));
	}
	
	m_pObjMissile = m_Scene.FindObject( "missile", m_Scene.GetRootObject() );
	if (m_pObjMissile ==NULL){
		MsgBox(_T("Error"),_T("not found \"missile\" object from scene"));
	}
	m_pObjMissile->SetVisible(FALSE);

	m_pObjMissile2 = m_Scene.FindObject( "missile2", m_Scene.GetRootObject() );
	if (m_pObjMissile2 ==NULL){
		MsgBox(_T("Error"),_T("not found \"missile2\" object from scene"));
	}
	m_pObjMissile2->SetVisible(FALSE);


	m_Scene.OptimizeAllVertexBuffers();

	//====== Set Missile Particle
	//m_3DDevice.SetTexture(3, &m_srfBillboard);
	//m_3DDevice.SetTextureState(3, eDE_TEXTURESTATE_);

	m_srfBillboard.SetSubFrames(64,64);			// size of one frame.
	m_pEmitter = SAFE_NEW(CDiesel3DParticleEmitter);
	m_pEmitter->Startup(200, eDE_PARTICLE3DTYPE_BILLBOARD1, NULL, &m_srfBillboard);

	m_pObjMissile->AddChild(m_pEmitter);

	m_pEmitter->SetVisible(FALSE);

	CDieselVector3 epos, edir;
	SDE_PARTICLE3D_EMIT emit;
	
	//----------- smoke type 1 ---- ( jet smoke ) ---------
	/*emit.fDirectionSpread = 1.0f;
	emit.fPositionSpread = 0.5f;
	emit.fSize = 1.0f;
	emit.fSizeSpread = 1.0f;
	emit.fLifeTime = 0.3f;
	emit.fLifeTimeSpread = 0.3f;

	epos.Set(0.0f, 0.0f, -1.0f);
	edir.Set(0.0f, 0.0f, -5.0f);

	m_pEmitter->SetContEmit( 20.0f, epos, edir, emit);*/

	//----------- smoke type 2 ---- ( homing missile smoke ) ---------
	emit.fDirectionSpread = 0.0f;
	emit.fPositionSpread = 0.0f;
	emit.fSize = 1.0f;
	emit.fSizeSpread = 1.0f;
	emit.fLifeTime = 7.0f;
	emit.fLifeTimeSpread = 1.3f;
	epos.Set(0.0f, 0.0f, -1.0f);
	edir.Set(0.0f, 0.0f, 0.0f);
	m_pEmitter->SetContEmit( 20.0f, epos, edir, emit);
	//------------------------------------------------

	//----------- enemy missile particle ----------------
	m_pEmitter2 = SAFE_NEW(CDiesel3DParticleEmitter);
	m_pEmitter2->Startup(200, eDE_PARTICLE3DTYPE_BILLBOARD1, NULL, &m_srfBillboard);

	m_pObjMissile2->AddChild(m_pEmitter2);

	m_pEmitter2->SetVisible(FALSE);
	m_pEmitter2->SetContEmit( 20.0f, epos, edir, emit);
	
	//------------------------------------------------
	
	//====== Set Plane Particle (jet stream) =======
	m_pEmitterPlaneA = SAFE_NEW(CDiesel3DParticleEmitter);
	m_pEmitterPlaneA->Startup(200, eDE_PARTICLE3DTYPE_BILLBOARD1, NULL, &m_srfBillboard);

	m_pObjPlane->AddChild(m_pEmitterPlaneA);
	SetJetStream(FALSE);

	//       another wing
	m_pEmitterPlaneB = SAFE_NEW(CDiesel3DParticleEmitter);
	m_pEmitterPlaneB->Startup(200, eDE_PARTICLE3DTYPE_BILLBOARD1, NULL, &m_srfBillboard);

	m_pObjPlane->AddChild(m_pEmitterPlaneB);

	m_pEmitterPlaneB->SetVisible(FALSE);//<<----------------- another wing
	
	emit.fDirectionSpread = 0.0f;
	emit.fPositionSpread = 0.0f;
	emit.fSize = 1.0f;
	emit.fSizeSpread = 0.3f;
	emit.fLifeTime = 7.0f;
	emit.fLifeTimeSpread = 1.3f;
	epos.Set(-1.0f, 0.0f, -1.0f);
	edir.Set(0.0f, 0.0f, 0.0f);
	m_pEmitterPlaneB->SetContEmit( 20.0f, epos, edir, emit);
	//------------------------------------------------

	//====== Set Other Particle=======
	//m_EmitterOther.SetType(
	m_EmitterOther.Startup(200,eDE_PARTICLE3DTYPE_BILLBOARD1, NULL, &m_srfBillboard);
	m_EmitterOther.SetVisible(FALSE);
	
	//====== Set Explode Particle ============
	m_EmitterExplode.Startup(20, eDE_PARTICLE3DTYPE_PYRAMID, NULL, NULL);
	//ExplodeParticlePlane = SetExplodeParticle(80.0f,60.0f,-400.0f);
	m_EmitterExplode.SetVisible(FALSE);
	//------------------------------------------------
	

	//===== Set Light
	m_pLight = SAFE_NEW(CDiesel3DLight);

	CDieselVector3 dir(1.0f,-1.0f,0.5f);
	dir.Normalize();
	m_pLight->SetDirectional(dir,//Pos
		CDiesel3DColor(0.0f,0.0f, 0.0f, 0.0f),//amp
		CDiesel3DColor(1.0f,1.0f, 1.0f, 0.0f),//dif
		CDiesel3DColor(0.0f,0.0f, 0.0f, 0.0f));//spe
	m_3DDevice.SetLight(0,m_pLight);
	m_3DDevice.LightEnable(0,TRUE);

	InitCamera();

	// set some 3d device states
	m_3DDevice.SetAmbientLight(CDiesel3DColor(0.4f,0.4f, 0.4f, 1.0f));
	m_3DDevice.SetSpecular(FALSE);
	m_3DDevice.SetAlpha(FALSE);
	m_3DDevice.SetZBuffering(TRUE);

	m_pObjPlane->GetLocalMatrix().SetPos(CDieselVector3(80.0f,8.0f,-650.0f));


	

	//MakeMovementList();

	/*m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3(1000.0f,250.0f,-1000.0f));
	m_pObjPlane2->SetVelocity(CDieselVector3(0.0f,0.0f,-1.0f));//initial direction*/
	m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3(1000.0f,250.0f,-1000.0f));
	m_pObjPlane2->SetVelocity(CDieselVector3(-1.0f,0.0f,0.0f));//initial direction
	
	/*float x=(float)RandFloat(0.0f,1.0f)*2000.0f;
	float y=(floatRandFloat(0.0f,1.0f)*200.0f;
	float z=RandFloat(0.0f, 2000.0f);
	m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3(x,y,-z));*/

	m_pObjField->GetLocalMatrix().SetPos(CDieselVector3(80.0f,5.0f,-600.0f));
	m_pObjMissile->GetLocalMatrix().SetPos(CDieselVector3(2.0f,60.0f,1.0f));
	

	m_3DDevice.SetFogParams(CDiesel3DColor(0.9f,0.9f,1.0f,1.0f),500.0f);
	m_3DDevice.SetFog(true);

	return DE_OK;
}

// initialize the camera object
void FSPPCApp::InitCamera()
{
	//below 2 command equivalent to SetTransform(eDE_MATRIX_CAMERA, &m_mWorld);
	m_Camera.SetWorldPos(CDieselVector3(0.0f, 0.0f, -120.0f));
	m_Camera.SetView();

	//equivalent to CDiesel3DCamera::SetProjectionParams.
	m_Camera.Startup(60*DEGTORAD,	//fov
					(float)m_srfBack.GetHeight() / (float)m_srfBack.GetWidth(), //Aspect ratio
					1.0f,//nearplane
					1000.0f);//farplane

	m_Camera.SetProjection();//equivalent to SetTransform(eDE_MATRIX_PROJECTION, &m_mProjection);

	
}
void FSPPCApp::OnExit()
{
	m_3DObject.Shutdown();
	m_EmitterExplode.Shutdown();
	m_EmitterOther.Shutdown();

	for(int i=0;i<=21;i++){
		m_srfPic[i].Release();
	}
	// release object resources
	m_Vertices.Shutdown();
	m_Indices.Shutdown();
	m_VerticesA.Shutdown();
	m_IndicesA.Shutdown();
	m_VerticesB.Shutdown();
	m_IndicesB.Shutdown();

	SAFE_DELETE(m_pLight);
	m_Writer.Shutdown();
	m_WriterRed.Shutdown();	
	m_srfBillboard.Release();

	m_Scene.Shutdown();
	m_3DDevice.Shutdown();
	//if(connection_state>=1&&connection_state<=4){//if server create
		ServerClose();
	//}else if(connection_state>=11&&connection_state<=15){//if client create
		ClientClose();
	//}
}




//----------------------------------------------------------------------
// Updating
//----------------------------------------------------------------------
void FSPPCApp::OnFlip()
{	m_EmitterOther.Update(m_fFrameTime, 0);

	// ====== show emiter explode ========
	m_EmitterExplode.Update(m_fFrameTime, 0);

	// set some artificial gravity for particles
	CDieselVector3 gravity(0.0f, -500.0f, 0.0f);
	m_EmitterExplode.Gravity(gravity, m_fFrameTime);

	// set the collision space.
	// collision space is like invisible barrier what particles
	// cannot pass.
	// collision space is presented as matrix where matrix up
	// vector is the collision plane normal.
	// so, identity matrix is a plane normal pointing straight up.
	// changing the matrix position changes the collision plane position
	CDieselMatrix4 mat;
	mat.Identity();
	// move the collision plane down by "ExplodeParticlePlane" variable
	mat.m31 = ExplodeParticlePlane;

	// check the particle collisions to space
	// first parameter:		collision plane matrix
	// second parameter:	particle bounce multiplier.
	//						normally this value is negative
	//						setting the positive bounce will
	//						increase the particle speed on collision
	// third parameter:		particle de-acceleration multiplier on collision
	//						particle velocity is multiplied with this value
	//						on collision.
	m_EmitterExplode.CollisionSpace(mat, -0.1f, 0.1f);
	//==============================================================

	
	
	m_3DObject.Update(m_fFrameTime, 0);
	m_3DDevice.ClearZBuffer(0.96f);//1.0 =furthest, 0.0=closest
	//m_3DDevice.ClearRenderTarget(0x008A9FE2);
	m_3DDevice.ClearRenderTarget(0x00000000);

	if (m_3DDevice.BeginScene() == DE_OK)
	{
		// TODO: Add your rendering code here...
		m_Scene.Render();

		m_3DObject.Render(0);

		if(m_pObjMissile->IsVisible()){
			m_pEmitter->SetVisible(TRUE);
			m_pEmitter->Render(0);// render the particles
			m_pEmitter->SetVisible(FALSE);// set visible back to FALSE
			
		}
		if(m_pObjMissile2->IsVisible()){
			m_pEmitter2->SetVisible(TRUE);
			m_pEmitter2->Render(0);// render the particles
			m_pEmitter2->SetVisible(FALSE);// set visible back to FALSE
		}

		m_pEmitterPlaneA->Render(0);
		m_pEmitterPlaneB->Render(0);
		
		m_EmitterOther.Render(0);
		m_EmitterExplode.Render(0);

		m_3DDevice.EndScene();
		//InterpolateMaterialColor(&m_Material, m_cColor1, m_cColor2, m_fColorMul);
	}

	if(GameMenu==0){//if first screen
		//draw first screen
		m_srfBack.BltFast( m_iXpos[14], m_iYpos[14], &m_srfPic[14], NULL, NULL );
		//draw arrow pointer
		m_srfBack.BltFast( m_iXpos[16], m_iYpos[16], &m_srfPic[16], NULL, DE_BLTSRCCOLORKEY );
	}else if(GameMenu==2){//if netplay
		m_3DDevice.ClearRenderTarget(0x00cccccc);
		m_srfBack.BltFast( m_iXpos[20], m_iYpos[20], &m_srfPic[20], NULL, DE_BLTSRCCOLORKEY );
		
		char TxtScreen[MAXCHAR];
		
		
		
		switch(connection_state){
		case 0:{//show "select your type"
			sprintf(TxtScreen, "SELECTE YOUR TYPE\n\n\n[ SERVER ]\n\n[ CLIENT ]",0);
			m_WriterRed.WriteText(40,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 1:{//select server
			if(ServerCreate("2000")){
				connection_state=2;
			}else{
				sprintf(TxtScreen, "Server create failed!\nplease restart and try again.",0);
				m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
			break;
			   }
		case 2:{//already select server, waiting for connection
			if(ServerAccept()){
				connection_state=3;
			}else{
				sprintf(TxtScreen, "Server create OK!\nplease waiting for connection....",0);
				m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
			break;
			   }
		case 3:{//connection ok, please push "OK" button
			sprintf(TxtScreen, "Connection Complete!\npress OK to start game\n\n[ OK ]",0);
			m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);

			//GameMenu=0;
			break;
				}
		case 4:{//already push "OK" button
			//make random start position
			m_pObjPlane->GetLocalMatrix().SetPos(CDieselVector3(800.0f,250.0f,-1350.0f));
			Is_Float=true;
			plane_speed=25.0f;
			EnemyHealth=5;
			GameMenu=1;
			break;
			   }
		case 11:{
			sprintf(TxtScreen, "Enter server IP address!",0);
			m_WriterRed.WriteText(31,12,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			m_WriterRed.WriteText(75,63,&m_srfBack, serverIP,DE_BLTSRCCOLORKEY);
			sprintf(TxtScreen, "[ OK ]",0);
			m_WriterRed.WriteText(96,211,&m_srfBack,TxtScreen,DE_BLTSRCCOLORKEY);
			m_srfBack.BltFast( m_iXpos[21], m_iYpos[21], &m_srfPic[21], NULL, NULL );

			break;
				}
		case 12:{//enter IP address and already OK
			if(ClientCreate(serverIP,"2000")){
				connection_state=13;
			}else{
				sprintf(TxtScreen, "Fail to connection!\nrestart and retry again..",0);
				m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
			break;
				}
		case 13:{//wait for connect to server
			if(ClientConnect()){
				connection_state=14;				
			}else{
				sprintf(TxtScreen, "Waiting to connect Server!\nplease be patient",0);
				m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
			break;
				}
		case 14:{//can connection to server, wait for OK button
			sprintf(TxtScreen, "Connection Complete!\npress OK to start game\n\n[ OK ]",0);
			m_WriterRed.WriteText(2,10,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
				}
		case 15:{//already push OK button
			//make random start position
			m_pObjPlane->GetLocalMatrix().SetPos(CDieselVector3(900.0f,250.0f,-1350.0f));
			Is_Float=true;
			plane_speed=25.0f;
			EnemyHealth=5;
			GameMenu=1;
			break;
				}
		}
		m_Scene.Update();
	}else if(GameMenu==3){
		m_srfBack.BltFast( m_iXpos[15], m_iYpos[15], &m_srfPic[15], NULL, NULL );
	}else if(GameMenu==1){//if playing mode
		//----------------- Playing game :BEGIN------------------
		CDieselMatrix4 MatAct1,MatAct2;
		
		if(Is_Float){
			//auto roll-back
			CDieselVector3 RefRight,RefDir;float roll_angle_test,pitch_angle_test;
			RefRight=m_pObjPlane->GetWorldMatrix().GetRight();
			RefDir=m_pObjPlane->GetWorldMatrix().GetDir();
			
			roll_angle_test=(float)asin(RefRight.y/RefRight.Length());
			roll_angle_test*=RADTODEG;
			if((roll_angle_test)>2){//2 is roll-angle treshold for pilot-autoturnback,
				MatAct1.RotationAxis(RefDir,-4.0f*m_fFrameTime*DEGTORAD);
				m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			}else if((roll_angle_test)<-2){
				MatAct1.RotationAxis(RefDir,+4.0f*m_fFrameTime*DEGTORAD);
				m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			}

			//auto pitch
			pitch_angle_test=(float)asin(RefDir.y/RefDir.Length());
			pitch_angle_test*=RADTODEG;
			if((pitch_angle_test)>2){
				MatAct1.RotationAxis(RefRight,4.0f*m_fFrameTime*DEGTORAD);
				m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			}else if((pitch_angle_test)<-2){
				MatAct1.RotationAxis(RefRight,-4.0f*m_fFrameTime*DEGTORAD);
				m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			}
			
		}	

		CDieselVector3 direction1,temp;
		direction1=m_pObjPlane->GetLocalMatrix().GetPos();
		if(Is_Float){
			//Gravity and Float Effect 
			temp=Gravity_Vec;
			temp.Mul(m_fFrameTime);
			direction1.Add(temp);//direction for Gravity
		}
		temp=Float_Vec;//float_vec changed by Calculate_Accel function (relative to speed)
		temp.Mul(m_fFrameTime);
		direction1.Add(temp);//direction for Floating_fly value

		m_pObjPlane->GetLocalMatrix().SetPos(direction1);//take effect(gravity,float) to plane

		//calculate weight of plane
		PlaneWeight=(0.1f*missile_amount)+(fuel_amount/10000.0f);

		//change speed relative to engine_percent
		if(fuel_amount>0){
			plane_speed=Calculate_Accel(plane_speed,engine_percent,PlaneWeight);
		}else{
			plane_speed=Calculate_Accel(plane_speed,0,0);
			engine_percent=0;
		}

		//more gravity when nohealth (for falling down)
		if(MyPlaneHealth<=0){
			Gravity_Vec.Set(0.0f,-30.0f,0.0f);
		}

		if(plane_speed>17){
			SetJetStream(TRUE,3);
		}else if(plane_speed>13){
			SetJetStream(TRUE,2);
		}else if(plane_speed>2){
			SetJetStream(TRUE,1);
		}else{
			SetJetStream(FALSE);
		}
		
		
		//limit flying range in y-axis (if higher then 600 it have down Float_Vec)
		if(m_pObjPlane->GetWorldMatrix().GetPos().y>600)Float_Vec.Set(0.0f,-16.0f,0.0f);
		
		//decrese fuel, relative to engine_percent
		fuel_amount=fuel_amount-(Fuel_Consume(engine_percent)*m_fFrameTime);
		if(fuel_amount<0)fuel_amount=0;
		//decrese Fuel Bar
		m_iYpos[11]=DecreseBar(219,247,(int)fuel_amount_all,(int)fuel_amount);

		
		//Force direction when Start game (force to strength when not floating)
		if(Is_Float)
			direction1=m_pObjPlane->GetLocalMatrix().GetDir();//if float then they can fly
		else
			direction1.Set(0.0f,0.0f,1.0f);//if not float, they go strength
		
		m_pObjPlane->SetVelocity(direction1);
		m_pObjPlane->SetSpeed(plane_speed);
		
		EnemyManipulate();
		EnemyMissileManipulate();
		
		//set missile speed if it visible
		if(m_pObjMissile->IsVisible()){
			missile_speed=20+(plane_speed/2);//missile_speed is relatively to plane_speed
			direction1=m_pObjMissile->GetLocalMatrix().GetDir();
			m_pObjMissile->SetVelocity(direction1);
			m_pObjMissile->SetSpeed(missile_speed);
		}else{
			m_pObjMissile->SetSpeed(0);//stop missile
		}

		

		m_Scene.Update();

		//************* Place camera at bird's eye view *************
		//Method1 : MakeLookAt, easy but automatic to much
		//Method2 : SetTransform, hard but manual setting
		CDieselVector3 VecPos,VecDir,VecRight,VecEyePoint,VecUpOfObj,VecRightOfObj,RefPos;
	/*
		//-----------Method1: MakeLookAt-----------------
		VecPos = m_pObjPlane->GetWorldMatrix().GetPos(); //VecPos have Position of plane
		VecDir = m_pObjPlane->GetWorldMatrix().GetDir(); //VecDir have Direction of plane
		VecUpOfObj = m_pObjPlane->GetWorldMatrix().GetUp();
		VecRightOfObj = m_pObjPlane->GetWorldMatrix().GetRight();
		
		VecUpOfObj.SetLength(30.0f);
		VecDir.SetLength(60.0f);
		VecRightOfObj.SetLength(00.0f);

		VecPos.Add(VecUpOfObj);//Step up
		VecEyePoint=VecPos;
		VecPos.Sub(VecDir);//Step back
		VecPos.Add(VecRightOfObj);//Step right
		
		MatAct1.Identity();
		MatAct1.MakeLookAt(VecPos,VecEyePoint);
		m_Camera.SetViewMatrix(MatAct1);
		m_Camera.SetView();
	*/

		//-------------Method2: Manual Setting -----------
		RefPos=m_pObjPlane->GetWorldMatrix().GetPos();

	//		RefPos=VecPos;
		
		MatAct1 = m_pObjPlane->GetWorldMatrix();
		VecPos=MatAct1.GetPos();				//vecpos = plane position

		switch(camera_view){
		case 1:{//cockpit
			m_3DDevice.SetTransform(eDE_MATRIX_CAMERA, &MatAct1);
			ViewCockpit();
			break;
		   }
		case 2:{//ext 1
			/*//catch on enemy flying
			VecPos=m_pObjPlane2->GetWorldMatrix().GetPos();
			VecPos.y=VecPos.y+40.0f;
			VecPos.z=VecPos.z-0.1f;
				
			MatAct1.MakeLookAt(VecPos,m_pObjPlane2->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			*/

			VecDir=MatAct1.GetDir();
			VecUpOfObj=MatAct1.GetUp();
			VecDir.SetLength(9.0f);//9
			VecUpOfObj.SetLength(3.0f);//3
			VecPos.Sub(VecDir);
			VecPos.Add(VecUpOfObj);
			MatAct1.SetPos(VecPos);
			m_3DDevice.SetTransform(eDE_MATRIX_CAMERA, &MatAct1);
			break;
		   }
		case 23:{//zoom view
			VecDir=MatAct1.GetDir();
			VecUpOfObj=MatAct1.GetUp();
			VecRight=MatAct1.GetRight();
			VecDir.SetLength(5.0f);
			VecUpOfObj.SetLength(1.0f);
			VecRight.SetLength(1.0f);
			VecPos.Sub(VecDir);
			VecPos.Add(VecUpOfObj);
			VecPos.Add(VecRight);
			MatAct1.SetPos(VecPos);
			m_3DDevice.SetTransform(eDE_MATRIX_CAMERA, &MatAct1);
			break;
			}
		case 22:{//side view
			VecUpOfObj=MatAct1.GetUp();
			VecRight=MatAct1.GetRight();

			VecUpOfObj.SetLength(2.0f);
			VecRight.SetLength(4.7f);

			VecPos.Add(VecUpOfObj);
			VecPos.Add(VecRight);
			MatAct1.MakeLookAt(VecPos,m_pObjPlane->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			break;
				}
		case 21:{//top view
			VecDir=MatAct1.GetDir();
			VecUpOfObj=MatAct1.GetUp();
			VecRight=MatAct1.GetRight();

			VecDir.SetLength(-3.0f);//120
			VecUpOfObj.SetLength(2.0f);
			VecRight.SetLength(0.0f);

			
			VecPos.Add(VecDir);
			VecPos.Add(VecUpOfObj);
			VecPos.Add(VecRight);
			MatAct1.MakeLookAt(VecPos,m_pObjPlane->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			break;
			}
		case 24:{//front
			VecDir=MatAct1.GetDir();
			VecUpOfObj=MatAct1.GetUp();
			VecRight=MatAct1.GetRight();

			VecDir.SetLength(3.0f);//120
			VecUpOfObj.SetLength(1.0f);
			VecRight.SetLength(0.0f);

			
			VecPos.Add(VecDir);
			VecPos.Add(VecUpOfObj);
			VecPos.Add(VecRight);
			MatAct1.MakeLookAt(VecPos,m_pObjPlane->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			break;

				}
		case 3:{//ext2
			if(!Deploy_camera){
				VecDir=MatAct1.GetDir();
				VecUpOfObj=MatAct1.GetUp();
				VecRight=MatAct1.GetRight();
			
				if(m_pObjPlane->IsVisible()){
					float random_value=RandFloat(0.0f, 1.0f);
					//float random_value=0.0f;
					if(random_value<0.25f){
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(-4);
						VecRight.SetLength(-4);
					}else if(random_value>=0.25f&&random_value<0.5f){
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(-1);
						VecRight.SetLength(2);
					}else if(random_value>=0.5f&&random_value<0.75f){
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(3);
						VecRight.SetLength(2);
					}else{
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(6);
						VecRight.SetLength(-3);
					}
				}	
				VecPos.Add(VecDir);
				VecPos.Add(VecUpOfObj);
				VecPos.Add(VecRight);
				Deploy_camera_pos=VecPos;
				Deploy_camera=true;
			}
							
			MatAct1.MakeLookAt(Deploy_camera_pos,m_pObjPlane->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			break;
			}
		case 4:{
			if(m_pObjMissile->IsVisible()){
				MatAct1 = m_pObjMissile->GetWorldMatrix();
				VecPos=MatAct1.GetPos();			//if out of plane --> missile camera
			
				VecDir=MatAct1.GetDir();
				VecUpOfObj=MatAct1.GetUp();
				VecRight=MatAct1.GetRight();
				VecDir.SetLength(6.0f);//120
				VecUpOfObj.SetLength(1.5f);//30
				VecRight.SetLength(1.0f);
		
				VecPos.Sub(VecDir);
				VecPos.Add(VecUpOfObj);
				VecPos.Add(VecRight);
				MatAct1.SetPos(VecPos);
				m_3DDevice.SetTransform(eDE_MATRIX_CAMERA, &MatAct1);
			}else if(!BulletTime){
				camera_view=1;
			}else{
				camera_view=6;
			}
			break;
		   }
		case 41:{
			if(m_pObjMissile->IsVisible()){
				if(!Deploy_camera){
					MatAct1 = m_pObjMissile->GetWorldMatrix();
					VecPos=MatAct1.GetPos();

					VecDir=MatAct1.GetDir();
					VecUpOfObj=MatAct1.GetUp();
					VecRight=MatAct1.GetRight();
			
					if(missile_target_locked){
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(4);
						VecRight.SetLength(6);
					}else{
						VecDir.SetLength(30);
						VecUpOfObj.SetLength(1);
						VecRight.SetLength(2);
					}
		
					VecPos.Add(VecDir);
					VecPos.Add(VecUpOfObj);
					VecPos.Add(VecRight);
					Deploy_camera_pos=VecPos;
					Deploy_camera=true;
				}
							
				MatAct1.MakeLookAt(Deploy_camera_pos,m_pObjMissile->GetWorldMatrix().GetPos());
				m_Camera.SetViewMatrix(MatAct1);
				m_Camera.SetView();
			}else if(!BulletTime){
				camera_view=1;
			}else{
				camera_view=6;
			}
			break;
			}
		case 42:{
			if(m_pObjMissile->IsVisible()){
				MatAct1 = m_pObjMissile->GetWorldMatrix();
				VecPos=MatAct1.GetPos();			//if out of plane --> missile camera
			
				VecDir=MatAct1.GetDir();
				VecUpOfObj=MatAct1.GetUp();
				VecRight=MatAct1.GetRight();
				VecDir.SetLength(3);//120
				VecUpOfObj.SetLength(missile_view_distance1);//30
				VecRight.SetLength(missile_view_distance2);
		
				VecPos.Sub(VecDir);
				VecPos.Add(VecUpOfObj);
				VecPos.Add(VecRight);
							

				MatAct1.MakeLookAt(VecPos,m_pObjMissile->GetWorldMatrix().GetPos());
				m_Camera.SetViewMatrix(MatAct1);
				m_Camera.SetView();

			}else if(!BulletTime){
				camera_view=1;
			}else{
				camera_view=6;
			}
			break;
			}
		case 5:{//CRASH view camera
			CDieselVector3 Temp;
			Temp.Set(VecPos.x+100.0f,VecPos.y+100.0f,VecPos.z+100.0f);
			MatAct1.MakeLookAt(Temp,m_pObjPlane->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			//MsgBox(	_T("crash"),_T("crash"));
			//camera_view=NULL;
			ShowMyCrash(VecPos.x,VecPos.y,VecPos.z);		
			break;
			}
		case 6:{//enemy CRASH view camera
			CDieselVector3 Temp=m_pObjPlane2->GetLocalMatrix().GetPos();
			Temp.Set(Temp.x+20.0f,Temp.y+20.0f,Temp.z+20.0f);
			MatAct1.MakeLookAt(Temp,m_pObjPlane2->GetWorldMatrix().GetPos());
			m_Camera.SetViewMatrix(MatAct1);
			m_Camera.SetView();
			break;
			}
		case 7:{//enemy missile view
			if(m_pObjMissile2->IsVisible()){
				MatAct1 = m_pObjMissile2->GetWorldMatrix();
				VecPos=MatAct1.GetPos();
			
				VecDir=MatAct1.GetDir();
				VecUpOfObj=MatAct1.GetUp();
				VecRight=MatAct1.GetRight();
				VecDir.SetLength(9);//120
				VecUpOfObj.SetLength(2);//30
				VecRight.SetLength(1);
		
				VecPos.Sub(VecDir);
				VecPos.Add(VecUpOfObj);
				VecPos.Add(VecRight);
							

				MatAct1.MakeLookAt(VecPos,m_pObjMissile2->GetWorldMatrix().GetPos());
				m_Camera.SetViewMatrix(MatAct1);
				m_Camera.SetView();
			}else{
				camera_view=1;
			}
			break;
			}
		}	
		
		
		//check MyPlane and the mountain when MyPlane is Visible
		if(m_pObjPlane->IsVisible()&&HitMountain(listy,180,15.0f,RefPos.x,RefPos.z,RefPos.y,30)){
	//		MsgBox(	_T("HIT"),_T("HIT"));
	//		Shutdown();
			m_pObjPlane->SetVisible(FALSE);
			Is_Float=false;
			plane_speed=0.0f;
			engine_percent=0;
			camera_view=5;//CRASH VIEW
			m_EmitterExplode.SetVisible(TRUE);
			ExplodeTime=0.0f;
			ExplodeParticlePlane = SetExplodeParticle(RefPos.x, RefPos.y, RefPos.z);		
		}

		CDieselVector3 RefMissilePos=m_pObjMissile->GetWorldMatrix().GetPos();
		
		//check Missile and the Mountain
		if(m_pObjMissile->IsVisible()&&HitMountain(listy,180,15.0f,RefMissilePos.x,RefMissilePos.z,RefMissilePos.y,30)){
	//		MsgBox(	_T("MissileHIT"),_T("HIT"));
	//		Shutdown();
			m_pObjMissile->SetVisible(FALSE);
			m_EmitterExplode.SetVisible(TRUE);
			//m_EmitterExplode.StopContEmit();
			ExplodeTime=0.0f;//reset time-counter
			ExplodeParticlePlane = SetExplodeParticle(RefMissilePos.x, RefMissilePos.y, RefMissilePos.z);		
		}		

		//======= check missile hit Enemy =======
		CDieselVector3 RefEPos=m_pObjPlane2->GetWorldMatrix().GetPos();
		if(HitTest(RefMissilePos.x,RefMissilePos.y,RefMissilePos.z,RefEPos.x,RefEPos.y,RefEPos.z)){
			BulletTimeDelay=0;
			BulletTime=true;
			if(EnemyHealth>0){
				EnemyHealth-=1;
				char tell_hit[30];
				encode(tell_hit,1,'e',' ',0,0,0);
				if(connection_state==4){
					ServerSend(tell_hit);
				}else if(connection_state==15){
					ClientSend(tell_hit);
				}				
			}
			m_pObjMissile->SetVisible(FALSE);
			m_pObjMissile->GetLocalMatrix().SetPos(CDieselVector3(0.0f,-100.0f,0.0f));//hidden missile underground (initial effect from missile)
		}
		if(EnemyHealth<=1&&!IsEmitterOtherBusy){
			ShowEnemyDamage(RefEPos.x,RefEPos.y,RefEPos.z,1.0f);
			//ShowEnemyDamage(80,0,-400);
		}



		//position for create ocean
		float top_region=-800.0f;
		float bottom_region=-1900.0f;
		float left_region=800.0f;
		float right_region=1900.0f;

		float ocean_point=31;
		float ocean_tile_width=180;//total width = point-1 * tile_width
		
		//-------- don't modify below value, plz modify above to make good view
		if(!flag_useA){
			if(RefPos.z>top_region){
				CreateOceanA(ocean_point,RefPos.x-(((ocean_point-1) * ocean_tile_width)/2),((ocean_point-1) * ocean_tile_width)-5,ocean_tile_width,0);//gridamount,x,y,spacing,height
				flag_useA=true;
				//MsgBox(	_T("Create"),_T("TOP CREATE"));
			}else{
				if(RefPos.z<bottom_region){
					CreateOceanA(ocean_point,RefPos.x-(((ocean_point-1) * ocean_tile_width)/2),-2695,ocean_tile_width,0);
					flag_useA=true;
				//	MsgBox(	_T("Create"),_T("BOTTOM CREATE"));
				}
			}
		}else{
			if(RefPos.z<=top_region&&RefPos.z>=bottom_region){
				flag_useA=false;
				m_VerticesA.Shutdown();
				m_IndicesA.Shutdown();
				//MsgBox(	_T("Create"),_T("top-bottom CLOSE"));
			}
		}

		if(!flag_useB){
			if(RefPos.x<left_region){
				CreateOceanB(ocean_point,-(((ocean_point-1) * ocean_tile_width)-5),RefPos.z+(((ocean_point-1) * ocean_tile_width)/2),ocean_tile_width,0);
				flag_useB=true;
				//MsgBox(	_T("Create"),_T("LEFT CREATE"));
			}else{
				if(RefPos.x>right_region && !flag_useB){
					CreateOceanB(ocean_point,2695,RefPos.z+(((ocean_point-1) * ocean_tile_width)/2),ocean_tile_width,0);
					flag_useB=true;
				//	MsgBox(	_T("Create"),_T("RIGHT CREATE"));
				}
			}
		}else{
			if(RefPos.x>=left_region && RefPos.x<=right_region){
				flag_useB=false;
				m_VerticesB.Shutdown();
				m_IndicesB.Shutdown();
				//MsgBox(	_T("Create"),_T("left-right CLOSE"));
			}
		}
		
		/*if(camera_view==1){
			ViewCockpit();
		}*/

		if(m_pObjMissile->IsVisible()&&!TimeUp(missile_btn_time,2,m_fFrameTime))
			draw_missile_btn=true;
		else{
			draw_missile_btn=false;
			//m_pObjMissile->SetVisible(FALSE);
		}
		if(m_EmitterExplode.IsVisible()&&TimeUp(ExplodeTime,10,m_fFrameTime)){
			//m_EmitterExplode.SetVisible(FALSE);
			m_EmitterExplode.StopContEmit();
		}

		if(BulletTime&&TimeUp(BulletTimeDelay,20,m_fFrameTime)){
			BulletTime=false;
			m_EmitterOther.StopContEmit();
		}

		//random respawn position and direction , rotate ralative to direction
		MatAct1.Identity();//for reference

		if(!m_pObjPlane2->IsVisible()&&TimeUp(EnemyRespawnTime,5,m_fFrameTime)){

			float posrespawn = (float) ((RandFloat(0.0f, 1.0f)*1500.0f)+100.0f);
			m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3(posrespawn,250.0f,-1000.0f));
			m_pObjPlane2->GetLocalMatrix().SetUp(MatAct1.GetUp());
			
			posrespawn = RandFloat(0.0f,1.0f);
			if(posrespawn <0.25){//direction x+
				m_pObjPlane2->SetVelocity(CDieselVector3(1.0f,0.0f,0.0f));//initial direction1
				m_pObjPlane2->GetLocalMatrix().SetDir(MatAct1.GetRight());
				m_pObjPlane2->GetLocalMatrix().SetRight(-(MatAct1.GetDir()));
			}else if(posrespawn<0.5){//direction z+
				m_pObjPlane2->SetVelocity(CDieselVector3(0.0f,0.0f,1.0f));//initial direction2
				m_pObjPlane2->GetLocalMatrix().SetDir(MatAct1.GetDir());
				m_pObjPlane2->GetLocalMatrix().SetRight(MatAct1.GetRight());
			}else if(posrespawn <0.75){//direction z-
				m_pObjPlane2->SetVelocity(CDieselVector3(0.0f,0.0f,-1.0f));//initial direction3
				m_pObjPlane2->GetLocalMatrix().SetDir(-(MatAct1.GetDir()));
				m_pObjPlane2->GetLocalMatrix().SetRight(-(MatAct1.GetRight()));
			}else{//direction x-
				m_pObjPlane2->SetVelocity(CDieselVector3(-1.0f,0.0f,0.0f));//initial direction3
				m_pObjPlane2->GetLocalMatrix().SetDir(-(MatAct1.GetRight()));
				m_pObjPlane2->GetLocalMatrix().SetRight(MatAct1.GetDir());
			}

			EnemyHealth=2;
			m_pObjPlane2->SetVisible(TRUE);
		}

		//draw below_bar
		m_srfBack.BltFast( m_iXpos[ 7 ], m_iYpos[ 7 ], &m_srfPic[ 7 ], NULL, NULL );
		

		if(!m_pObjMissile->IsVisible())//if not fire, disable AtckView btn
			m_srfBack.BltFast( m_iXpos[ 8 ], m_iYpos[ 8 ], &m_srfPic[ 8 ], NULL, NULL );
		if(!Is_Float)//if not float, disable ExView2 btn
			m_srfBack.BltFast( m_iXpos[ 8 ]-45, m_iYpos[ 8 ], &m_srfPic[ 8 ], NULL, NULL );

		char TxtScreen[256];
		switch(camera_view){
		case 1:{
			sprintf(TxtScreen, "IntView",0);
			m_Writer.WriteText(8,307,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 21:
		case 22:
		case 23:
		case 2:{
			sprintf(TxtScreen, "ExView1",0);
			m_Writer.WriteText(51,307,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 3:{
			sprintf(TxtScreen, "ExView2",0);
			m_Writer.WriteText(94,307,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 4:
		case 41:
		case 42:{
			sprintf(TxtScreen, "AtckView",0);
			m_Writer.WriteText(137,307,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			if(camera_view==42){
				sprintf(TxtScreen, "Press up, down, left, right to change view",0);
				m_Writer.WriteText(5,5,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
			break;
				}
		case 5:{//your crash		
			sprintf(TxtScreen, "You Lose",0);
			m_Writer.WriteText(94,200,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 6:{//enemy hit
			if(EnemyHealth>0){
				sprintf(TxtScreen, "Target Hit!!",0);
			}else{
				sprintf(TxtScreen, "Enemy Down!!",0);
			}
			m_Writer.WriteText(94,200,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			break;
			   }
		case 7:{//enemy missile view
			m_iXpos[19]=181;m_iYpos[19]=308;
			m_srfBack.BltFast(m_iXpos[19], m_iYpos[19], &m_srfPic[19],NULL,DE_BLTSRCCOLORKEY);
			break;
			   }
			
		case NULL:{			
			
			sprintf(TxtScreen, "Menu",0);
			m_Writer.WriteText(216,307,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			
			break;
			   }
		
		}

		/*sprintf(TxtScreen, "Fuel %f",fuel_amount);
		m_Writer.WriteText(179,173,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);*/
		
		DistanceBetween=m_pObjPlane->GetWorldMatrix().GetPos();
		DistanceBetween.Sub(m_pObjPlane2->GetWorldMatrix().GetPos());
		if(camera_view==1){//show Enemy distance & Enemy Down screen
			if(EnemyHealth>0){//if not down
				sprintf(TxtScreen, "%.f",DistanceBetween.Length());
				//m_Writer.WriteText(179,173,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
				m_Writer.WriteText(187,202,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}else{
				sprintf(TxtScreen, "-----",NULL);
				m_Writer.WriteText(187,202,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			}
		}
		//------------------
		/*bool asdf=Is_Target_Locked();
		if(asdf){
			sprintf(TxtScreen, "LOCK",NULL);
			m_Writer.WriteText(7,60,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
		}else{
			sprintf(TxtScreen, "----",NULL);
			m_Writer.WriteText(7,60,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
		}
		*/

		//sprintf(TxtScreen, "hp %f ep %f\nhy %f ey %f",hp,ep,hy,ey);
		//m_Writer.WriteText(10,90,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
		
		//adjust missile when it lock-target
		if(missile_target_locked){
			Homing_Adjust();
		}



		if(TimeUp(ToggleTime2,0.5,m_fFrameTime)){
			ToggleTime2=0;
			BlinkOn2=!BlinkOn2;
		}
		
		if(m_pObjMissile2->IsVisible()){
			CDieselVector3 BetweenMeAndMissile;
			BetweenMeAndMissile=m_pObjPlane->GetWorldMatrix().GetPos();
			BetweenMeAndMissile.Sub(m_pObjMissile2->GetWorldMatrix().GetPos());
			if(connection_state!=4&&connection_state!=15){
				Homing_Adjust2();
			}
			
			if(BlinkOn2){
				sprintf(TxtScreen, "MISSILE WARNING\n      %.f",BetweenMeAndMissile.Length());
			}else{
				sprintf(TxtScreen, "               \n      %.f",BetweenMeAndMissile.Length());
			}
			m_WriterRed.WriteText(51,3,&m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);
			
			if(camera_view!=7){
				m_iXpos[18]=181;m_iYpos[18]=308;
				m_srfBack.BltFast(m_iXpos[18], m_iYpos[18], &m_srfPic[18],NULL,DE_BLTSRCCOLORKEY);
			}
			
		}
		if(!TimeUp(ShowDamageTime,5.0f,m_fFrameTime)&&BlinkOn2){
			sprintf(TxtScreen,"DAMAGE!",NULL);
			m_WriterRed.WriteText(86,95,&m_srfBack,TxtScreen,DE_BLTSRCCOLORKEY);
		}

		
		//******* send own status to other ********
		//ref value
		CDieselVector3 RefDir;
		RefDir=	m_pObjPlane->GetWorldMatrix().GetDir();
		
		//message code protocol
		//input: 
		//			[ int seq_number (reserve) | char type_code | char (reserve) | long x | long y | long z ]
		//output:  is a string 
		//			[ seq_num*4char | type_code*1char | (reserver)*1char | sign*1char + value*5char | sign*1char + value*5char  sign*1char + value*5char ]
		//meaning:
		//			type_code:	a = tell position
		//						b = tell heading direction
		//						c = tell missile position
		//						d = tell missile heading
		//						e = tell enemy has damage
		char tell_pos[30];
		encode(tell_pos,1,'a',' ',(long)RefPos.x,(long)RefPos.y,(long)RefPos.z);//tell position
		//----------------------------------------
		char tell_dir[30];float absx,absy,absz;
		if(RefDir.x>0)
			absx=RefDir.x;
		else
			absx= -1*RefDir.x;
		if(RefDir.y>0)
			absy=RefDir.y;
		else
			absy= -1*RefDir.y;
		if(RefDir.z>0)
			absz=RefDir.z;
		else
			absz= -1*RefDir.z;
			
		if(absx>=absy&&absx>=absz){//x direction
			if(RefDir.x>=0)//x+
				encode(tell_dir,1,'b',' ',1,0,0);
			else//x-
				encode(tell_dir,1,'b',' ',-1,0,0);
		}else if(absy>=absx&&absy>=absz){//y direction
			if(RefDir.y>=0)//y+
				encode(tell_dir,1,'b',' ',0,1,0);
			else//y-
				encode(tell_dir,1,'b',' ',0,-1,0);
		}else{//z direction
			if(RefDir.z>=0)//z+
				encode(tell_dir,1,'b',' ',0,0,1);
			else//z-
				encode(tell_dir,1,'b',' ',0,0,-1);
		}

		if(connection_state==4){
			if(TimeUp(UpdatePosTime,0.1,m_fFrameTime)){
				UpdatePosTime=0;
				ServerSend(tell_pos);
			}
			if(TimeUp(UpdateDirTime,1.0,m_fFrameTime)){
				UpdateDirTime=0;
				ServerSend(tell_dir);
			}
		}else if(connection_state==15){
			if(TimeUp(UpdatePosTime,0.1,m_fFrameTime)){
				UpdatePosTime=0;
				ClientSend(tell_pos);
			}
			if(TimeUp(UpdateDirTime,1.0,m_fFrameTime)){
				UpdateDirTime=0;
				ClientSend(tell_dir);
			}	
			
		}

		//******* send missile status to other ********
		if(m_pObjMissile->IsVisible()&&(connection_state==4||connection_state==15)){//if visible, sent missile pos
						
			CDieselVector3 RefM2Dir,RefM2Pos;
			RefM2Dir= m_pObjMissile->GetWorldMatrix().GetDir();
			RefM2Pos= m_pObjMissile->GetWorldMatrix().GetPos();

			char tell_m2pos[30];
			encode(tell_m2pos,1,'c',' ',(long)RefM2Pos.x,(long)RefM2Pos.y,(long)RefM2Pos.z);//tell missile position

			char tell_m2dir[30];
			if(RefM2Dir.x>0)
				absx=RefM2Dir.x;
			else
				absx= -1*RefM2Dir.x;
			if(RefM2Dir.y>0)
				absy=RefM2Dir.y;
			else
				absy= -1*RefM2Dir.y;
			if(RefM2Dir.z>0)
				absz=RefM2Dir.z;
			else
				absz= -1*RefM2Dir.z;
				
			if(absx>=absy&&absx>=absz){//x direction
				if(RefM2Dir.x>=0)//x+
					encode(tell_m2dir,1,'d',' ',1,0,0);
				else//x-
					encode(tell_m2dir,1,'d',' ',-1,0,0);
			}else if(absy>=absx&&absy>=absz){//y direction
				if(RefM2Dir.y>=0)//y+
					encode(tell_m2dir,1,'d',' ',0,1,0);
				else//y-
					encode(tell_m2dir,1,'d',' ',0,-1,0);
			}else{//z direction
				if(RefM2Dir.z>=0)//z+
					encode(tell_m2dir,1,'d',' ',0,0,1);
				else//z-
					encode(tell_m2dir,1,'d',' ',0,0,-1);
			}

			if(connection_state==4){
				if(TimeUp(UpdateMissilePosTime,0.05,m_fFrameTime)){
					UpdateMissilePosTime=0;
					ServerSend(tell_m2pos);
				}
				if(TimeUp(UpdateMissileDirTime,1,m_fFrameTime)){
					UpdateMissileDirTime=0;
					ServerSend(tell_m2dir);
				}

				
			}else if(connection_state==15){
				if(TimeUp(UpdateMissilePosTime,0.05,m_fFrameTime)){
					UpdateMissilePosTime=0;
					ClientSend(tell_m2pos);
					
				}
				if(TimeUp(UpdateMissileDirTime,1,m_fFrameTime)){
					UpdateMissileDirTime=0;
					ClientSend(tell_m2dir);
				}
			}

		}
		//----------------- Playing game :END------------------
	}

}

//----------------------------------------------------------------------
// Overrided Message handlers
//----------------------------------------------------------------------

void FSPPCApp::OnKeyDown(DWORD dwKey)
{
	CDieselMatrix4 MatAct1;
	CDieselVector3 AroundAxis,AroundAxis2,AroundAxis3;
	MatAct1.Identity();
	switch(dwKey){
	case KEY_DOWN:{
		if(GameMenu==1){//if in game playing
			if(camera_view==42){//if view missile then control camera
				if(missile_view_distance1>=-15.0f)
					missile_view_distance1-=0.1f;
			}else{
				if(plane_speed>8){
					Is_Float=true;
					AroundAxis=m_pObjPlane->GetWorldMatrix().GetRight();
					MatAct1.RotationAxis(AroundAxis,-1*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					//m_pObjPlane->Update(m_fFrameTime,NULL);
				}else{
					CDieselVector3 RefDir;float pitch_angle; //calculate pitch angle for picth up-down before take-off
					RefDir=m_pObjPlane->GetWorldMatrix().GetDir();
					pitch_angle=(float)asin(RefDir.y/RefDir.Length());
					
					if((pitch_angle*RADTODEG)<4){//if pitch is low, then they can pitch-up
						AroundAxis=m_pObjPlane->GetWorldMatrix().GetRight();
						MatAct1.RotationAxis(AroundAxis,-1*DEGTORAD);
						m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					}
				}
			}
		}else if(GameMenu==0){//on first screen
			if(m_iYpos[16]<300)m_iYpos[16]+=17;
		}else if(GameMenu==3){//on help screen
			GameMenu=0;//move to first screen
		}

		break;
			   }
	case KEY_UP:{
		if(GameMenu==1){//if in game playing
			if(camera_view==42){//if view missile then control camera
				if(missile_view_distance1<=15.0f)
					missile_view_distance1+=0.1f;
			}else{
				if(Is_Float){
					AroundAxis=m_pObjPlane->GetWorldMatrix().GetRight();
					MatAct1.RotationAxis(AroundAxis,1*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					//m_pObjPlane->Update(m_fFrameTime,NULL);
				}else{
					CDieselVector3 RefDir;float pitch_angle; //calculate pitch angle for picth up-down before take-off
					RefDir=m_pObjPlane->GetWorldMatrix().GetDir();
					pitch_angle=(float)asin(RefDir.y/RefDir.Length());
					
					if((pitch_angle*RADTODEG)>-4){//if pitch is high, then they can pitch-down
						AroundAxis=m_pObjPlane->GetWorldMatrix().GetRight();
						MatAct1.RotationAxis(AroundAxis,1*DEGTORAD);
						m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					}
				}
			}
		}else if(GameMenu==0){
			if(m_iYpos[16]>249)m_iYpos[16]-=17;
		}else if(GameMenu==3){//on help screen
			GameMenu=0;//move to first screen
		}
		break;
				 }
	case KEY_LEFT:{
		if(GameMenu==1){
			if(camera_view==42){//if view missile then control camera
				if(missile_view_distance2>=-15.0f)
					missile_view_distance2-=0.1f;
			}else{	//else control plane
				if(Is_Float){
					//turn left & head up & roll 
					AroundAxis=m_pObjPlane->GetWorldMatrix().GetDir();
					AroundAxis2=m_pObjPlane->GetWorldMatrix().GetUp();
					AroundAxis3=m_pObjPlane->GetWorldMatrix().GetRight();
					
					MatAct1.RotationAxis(AroundAxis2,-((plane_speed)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);

					MatAct1.RotationAxis(AroundAxis,+((plane_speed)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
									
					MatAct1.RotationAxis(AroundAxis3,-((plane_speed/2.0f)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					
				}else{
					CDieselVector3 RefRight;float roll_angle_test; //calculate roll angle for roll up-down before take-off
					RefRight=m_pObjPlane->GetWorldMatrix().GetRight();
					roll_angle_test=(float)asin(RefRight.y/RefRight.Length());

					if((roll_angle_test*RADTODEG)<4){//if roll is low, then they can roll-left
						//roll_angle=roll_angle+1.0f;
						AroundAxis=m_pObjPlane->GetWorldMatrix().GetDir();
						MatAct1.RotationAxis(AroundAxis,+1*DEGTORAD);
						m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					}
					
				}
			}
		}else if(GameMenu==3){//on help screen
			GameMenu=0;//move to first screen
		}
		break;
				 }
	case KEY_RIGHT:{
		if(GameMenu==1){
			if(camera_view==42){//if view missile then control camera
				if(missile_view_distance2<=15.0f)
					missile_view_distance2+=0.1f;
			}else{
				if(Is_Float){
								
					AroundAxis=m_pObjPlane->GetWorldMatrix().GetDir();
					AroundAxis2=m_pObjPlane->GetWorldMatrix().GetUp();
					AroundAxis3=m_pObjPlane->GetWorldMatrix().GetRight();
					
					MatAct1.RotationAxis(AroundAxis2,+((plane_speed)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);

					MatAct1.RotationAxis(AroundAxis,-((plane_speed)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
									
					MatAct1.RotationAxis(AroundAxis3,-((plane_speed/2.0f)*m_fFrameTime)*DEGTORAD);
					m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
				}else{
					CDieselVector3 RefRight;float roll_angle_test; //calculate roll angle for roll up-down before take-off
					RefRight=m_pObjPlane->GetWorldMatrix().GetRight();
					roll_angle_test=(float)asin(RefRight.y/RefRight.Length());
					
					if((roll_angle_test*RADTODEG)>-4){//if roll is low, then they can roll-right
						//roll_angle=roll_angle-1.0f;
						AroundAxis=m_pObjPlane->GetWorldMatrix().GetDir();
						MatAct1.RotationAxis(AroundAxis,-1*DEGTORAD);
						m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
					}
					
				}		
			}
		}else if(GameMenu==3){//on help screen
			GameMenu=0;//move to first screen
		}
		break;
				  }
	case KEY_SPACE:{
		//roll_angle=roll_angle-10.0f;
		AroundAxis=m_pObjPlane->GetWorldMatrix().GetUp();
		MatAct1.RotationAxis(AroundAxis,-10*DEGTORAD);
		m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
		//m_pObjPlane->Update(m_fFrameTime,NULL);		
		break;
				  }
	case KEY_RETURN:{
		if(GameMenu==0){//on start screen and press enter
			switch(m_iYpos[16]){
			case 249:{GameMenu=1;break;}//change to playing mode
			case 266:{GameMenu=2;break;}//change to netplay mode
			case 283:{GameMenu=3;break;}//change to helping screen
			case 300:{GameMenu=4;Shutdown();break;}//change to exit
			}			
		}else if(GameMenu==1){//if in game play
			AroundAxis=m_pObjPlane->GetWorldMatrix().GetUp();
			MatAct1.RotationAxis(AroundAxis,+10*DEGTORAD);
			m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
		}else if(GameMenu==3){//on help screen
			GameMenu=0;//move to first screen
		}
		
		break;
		}
	}
	
}

void FSPPCApp::OnMouseButton(DWORD dwButton, LONG x, LONG y)
{	
	//MsgBox("AS","!@");
	switch (dwButton){
	case 0:{
		if(GameMenu==1){
			CDieselMatrix4 MatAct1;
			//fire button
			if(x >= 166 && x <= 182 && y >= 216 && y <= 232 &&(camera_view==1)&&!draw_missile_btn&&(missile_amount>0)){ 
				missile_amount--;
				m_iYpos[9]=DecreseBar(219,247,missile_amount_all,missile_amount);
				missile_btn_time=0;
				

				m_pObjMissile->SetVisible(TRUE);
				CDieselVector3 plane_pos,plane_dir,plane_up,plane_right,wing_pos;
				plane_pos=m_pObjPlane->GetLocalMatrix().GetPos();
				plane_dir=m_pObjPlane->GetLocalMatrix().GetDir();
				plane_up=m_pObjPlane->GetLocalMatrix().GetUp();
				plane_right=m_pObjPlane->GetLocalMatrix().GetRight();

				m_pObjMissile->GetLocalMatrix().SetDir(plane_dir);
				m_pObjMissile->GetLocalMatrix().SetPos(plane_pos);
				m_pObjMissile->GetLocalMatrix().SetUp(plane_up);
				m_pObjMissile->GetLocalMatrix().SetRight(plane_right);
				missile_target_locked=false;//initial new value
				missile_target_locked=Is_Target_Locked();//test target locked (for homing missile);
				



				/*if(missile_target_locked){//uncomment here for test target-locked
					char t1[253];
					sprintf(t1, "LOCK",NULL);
					MsgBox(	_T("HIT"),_T(t1));
				}else{
					char t1[253];
					sprintf(t1, "not LOCK",NULL);
					MsgBox(	_T("HIT"),_T(t1));
				}*/
			}

			//press below bar
			if(y>=305){
				if(x<=44&&camera_view!=5) camera_view=1;//if not crash & just press button 1(int view)
				else if(x<=88&&camera_view!=5){////if not crash & just press button 2(extview1)
					switch(camera_view){
					case 2:camera_view=21;break;//21=zoom view
					case 21:camera_view=22;break;//22= side view
					case 22:camera_view=23;break;//23 =top view 
					case 23:camera_view=24;break;//23 =front view 
					default:camera_view=2;break;//normal view
					}
				}else if(x<=132&&Is_Float&&camera_view!=5){//if not crash and click external view 2, Deploy Camera
					camera_view=3;
					Deploy_camera=false;
				}else if(x<=176&&camera_view!=5){//if not crash & just press button 4 (atck view)
					switch(camera_view){
					case 4:{
						camera_view=41;Deploy_camera=false;break;}
					case 41:{
						camera_view=42;break;}
					default:{
						camera_view=4;break;}
					}							
				}else if(x<=194&&camera_view!=5){//enemy missile view
					camera_view=7;
				}else if(x>194){//click Menu Button
					GameMenu=0;
				}
			}

			if(x>=78 && x<=114 && y>=240 && y<=289){//if control throttle
				if(y>=(m_iYpos[12]+7)&&fuel_amount>0){//throttle down
					if(engine_percent!=0)m_iYpos[12]+=7;//move throttle bar
					switch(engine_percent){
						case 120:{engine_percent=100;break;}
						case 100:{engine_percent=80;break;}
						case 80:{engine_percent=60;break;}
						case 60:{engine_percent=0;break;}
					}
					
				}else{//throttle up
					if(engine_percent!=120&&fuel_amount>0)m_iYpos[12]-=7;//move throttle bar
					switch(engine_percent){
						case 100:{engine_percent=120;break;}
						case 80:{engine_percent=100;break;}
						case 60:{engine_percent=80;break;}
						case 0:{engine_percent=60;break;}

					}
					
				}
			}
		}else if(GameMenu==0){//on start screen
			if(x>=150 && x<=230 && y>=249 && y<=310){//if click at menu
				if(y<=266){//click play
					m_iYpos[16]=249;GameMenu=1;//shift select-arrow and change mode
				}else if(y<=283){//click netplay
					m_iYpos[16]=266;GameMenu=2;
				}else if(y<=300){//click help
					m_iYpos[16]=283;GameMenu=3;
				}else{//click exit
					m_iYpos[16]=300;GameMenu=4;Shutdown();
				}
			}
		}else if(GameMenu==3){//on helping screen
			GameMenu=0;
		}else if(GameMenu==2){//net play screen
			if(y>=305 && x>=194 ){
				GameMenu=0;
			}else if(connection_state==0&&x>=36 && x<=126 &&y>=55 && y<=112){//press server or client
				if(y<=80){//select server type
					connection_state=1;
				}else{//select client type
					connection_state=11;
				}
			}else if(connection_state==3&&x<=55&&y>=54&&y<=77){
				connection_state=4;
			}else if(connection_state==11&&x>=75&&x<=165&&y>=85&&y<=205){//numpad push
				if(y<115&&serverIPcounter<15){//pad 1-3 & not full
					if(x<105)//pad 1
						serverIP[serverIPcounter++]='1';
					else if(x<135)//pad 2
						serverIP[serverIPcounter++]='2';
					else //pad 3
						serverIP[serverIPcounter++]='3';
				}else if(y<145&&serverIPcounter<15){//4-6
					if(x<105)//pad4
						serverIP[serverIPcounter++]='4';
					else if(x<135)//pad 5
						serverIP[serverIPcounter++]='5';
					else//pad 6
						serverIP[serverIPcounter++]='6';
				}else if(y<175&&serverIPcounter<15){//7-9
					if(x<105)//pad7
						serverIP[serverIPcounter++]='7';
					else if(x<135)//pad 8
						serverIP[serverIPcounter++]='8';
					else//pad 9
						serverIP[serverIPcounter++]='9';
				}else{// backspace, zero,dot
					if(x<105){//back space
						if(serverIPcounter>0)serverIPcounter--;
						serverIP[serverIPcounter]=' ';
					}else if(x<135&&serverIPcounter<15)//0
						serverIP[serverIPcounter++]='0';
					else if(serverIPcounter<15)//dot
						serverIP[serverIPcounter++]='.';
				}				
			}else if(connection_state==11&&x>=96&&x<=146&&y>=211&&y<=225){//press ok
				connection_state=12;
			}else if(connection_state==14&&x<=55&&y>=54&&y<=77){
				connection_state=15;
			}
		}


		
/*		if(y<110){
			MatAct1.RotateXYZ(-10*DEGTORAD,0.0f,0.0f);
			m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			m_pObjPlane->Update(m_fFrameTime,NULL);		
			
		}
		else if(y>220){
			MatAct1.RotateXYZ(10*DEGTORAD,0.0f,0.0f);
			m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			m_pObjPlane->Update(m_fFrameTime,NULL);		
		}
		else if(x<64){
			MatAct1.RotateXYZ(0.0f,-10*DEGTORAD,0.0f);
			m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			m_pObjPlane->Update(m_fFrameTime,NULL);					
		}
		else if(x>160){	
			MatAct1.RotateXYZ(0.0f,10*DEGTORAD,0.0f);
			m_pObjPlane->GetLocalMatrix().Mul3x3(m_pObjPlane->GetLocalMatrix(),MatAct1);
			m_pObjPlane->Update(m_fFrameTime,NULL);		
		}
		else{
			int answer = MessageBox(NULL,_T("Do you want to Exit?"),_T("Exit"),MB_OKCANCEL|MB_ICONQUESTION|MB_DEFBUTTON2);
			if (answer == IDOK){
				Shutdown();
			}
		}
*/
		break;}
	case 1:{ //right btn
		/*if (lightVal <= 0.9f){
			
			test= !test;
			lightVal+=0.1f;
			m_Scene.Update();
			m_3DDevice.SetAmbientLight(CDiesel3DColor(lightVal,lightVal, lightVal, lightVal));		
		}*/
		//show_cockpit= !show_cockpit;
		break;}
	case 2:{//middle btn
		Shutdown();
		if (lightVal>=0.1f){
			test= !test;
			lightVal-=0.1f;
			m_Scene.Update();
			m_3DDevice.SetAmbientLight(CDiesel3DColor(lightVal,lightVal, lightVal, lightVal));
			
		}
		break;}
	}

}
void FSPPCApp::PrepareObject(double &GridAmount,double* Vertex_list,char* InputFilename)
{
	CDieselFile	m_FileHandle;
	DE_RETVAL	answer = DE_OK;
	
	TCHAR path[MAX_PATH];
	TCHAR buffer[10];
	//read Ground Part1
	BuildFilepath(path, _T(InputFilename));	// in PPC, want full path for file location
	answer=m_FileHandle.OpenFromFile(path,DE_FILE_READ);
	if (answer!=DE_OK){
		if(answer==DE_OUTOFMEMORY)
			MsgBox(	_T("Error"),_T("Out of Memory"));
		if(answer==DE_FILENOTFOUND)
			MsgBox(	_T("Error"),_T(InputFilename));
		Shutdown();
	}
	int i;
	for(i=0;i<10;i++)buffer[i]='\0';
	m_FileHandle.Read(buffer,4);
	//MsgBox(	_T("ok"),_T(buffer));
	GridAmount=atof(buffer);
	
	for(i=0;i<(GridAmount*GridAmount);i++){
		m_FileHandle.Read(buffer,8);
		Vertex_list[i] = atof(buffer);
	}
	//MsgBox(	_T("ok"),_T("Loaded OK"));
	m_FileHandle.Close();
}


void FSPPCApp::CreateObject(double GridAmount,double* Vertex_list_input,float x_start,float y_start,float spacing,int height_factor)
{
	// num of vertices on grid that we create
	int gridx = (int)GridAmount;
	int gridy = (int)GridAmount;
	
	int i;
	int j;

	if (m_Vertices.Startup(NULL, gridx*gridy, eDE_VERTEXTYPE_TC1) != DE_OK)
		return;

	CDiesel3DVertex *pVert = (CDiesel3DVertex*)m_Vertices.Lock();
	if (pVert == NULL)
		return;

	// generate the vertex grid
	int k=0;
	for (i=0; i<gridy; i++)
	{
		for (j=0; j<gridx; j++)
		{
			// set the vertex coordinate
			pVert->x = x_start + (j*spacing);
			pVert->z = y_start - (i*spacing);
			// some random values to z
			pVert->y = (float)Vertex_list_input[k++]*(height_factor);
			// set normal to zero, we'll compute the normals later
			pVert->nx = 0.0f;
			pVert->ny = 0.0f;
			pVert->nz = 0.0f;
			pVert->tu = 0.0f;
			pVert->tv = 0.0f;

			pVert++;
		}
	}
	//m_Vertices.Translate(300.0f, 0.0f, 0.0f);
	m_Vertices.Unlock();

	if (m_Indices.Startup(NULL, (gridx-1)*(gridy-1)*6, eDE_IBTYPE_WORD) != DE_OK)
		return;

	// lock the index buffer to gain access to indices
	WORD *pInd = (WORD*)m_Indices.Lock();
	if (pInd == NULL)
		return;

	// set the indices.
	// we'll be using single triangle list
	// to render the vertex buffer
	for (i=0; i<gridy-1; i++)
	{
		for (int j=0; j<gridx-1; j++)
		{
			WORD tmp = (WORD)(i*gridx+j);

			pInd[0] = tmp;
			pInd[1] = tmp+1;
			pInd[2] = tmp+1+gridx;

			pInd[3] = tmp+1+gridx;
			pInd[4] = tmp+gridx;
			pInd[5] = tmp;
			pInd += 6;
		}
	}

	m_Indices.Unlock();


	CDieselArray<CDiesel3DIndexBuffer*> arrInd;
	arrInd.Add(&m_Indices);
	m_Vertices.ComputeNormals(&arrInd);
	m_Vertices.Optimize();
	arrInd.Clear();

	CDiesel3DFaceMesh *pFace = SAFE_NEW(CDiesel3DFaceMesh);
	if (pFace == NULL)
		return;

	pFace->Startup(		&m_Indices,
						&m_Vertices,
						&m_Material,
						&m_3DObject.GetWorldMatrix(),
						eDE_PRIMTYPE_TRIANGLELIST);
	m_3DObject.AddFaceMesh(pFace);
	// set the material diffuse starting color...
	m_cColor1 = CDiesel3DColor(0.0f, 1.0f, 0.0f, 1.0f);
	// ...which will interpolate to this random color
	// on main loop
	m_cColor2 = CDiesel3DColor(	RandFloat(0.0f, 1.0f),
								RandFloat(0.0f, 1.0f),
								RandFloat(0.0f, 1.0f),
								1.0f);
	// color interpolation multiplier
	// init to 0
	m_fColorMul = 0.0f;
	// set the 3d object material colors
	m_Material.m_cAmbient = CDiesel3DColor(0.2f, 0.2f, 0.2f, 1.0f);
	m_Material.m_cDiffuse = m_cColor1;
	m_Material.m_cSpecular = CDiesel3DColor(1.0f, 1.0f, 1.0f, 1.0f);
	m_Material.m_cEmissive = CDiesel3DColor(0.0f, 0.0f, 0.0f, 0.0f);
	// set the material shiness
	// set this along with the material specular color to
	// 0 to disable specular lighting of material
	m_Material.m_fShiness = 10.0f;
}
void FSPPCApp::InterpolateMaterialColor(CDiesel3DMaterial *pMat, CDiesel3DColor &col1, CDiesel3DColor &col2, float &fMul)
{
	if (fMul > 1.0f)
	{
		// reset the multiplier
		fMul = 0.0f;
		col1 = col2;
		// get new random color
		col2 = CDiesel3DColor(	RandFloat(0.0f, 1.0f),
								RandFloat(0.0f, 1.0f),
								RandFloat(0.0f, 1.0f),
								1.0f);
	}

	// linearly interpolate the materials diffuse color
	pMat->m_cDiffuse.Lerp(col1, col2, fMul);
	
	// add the multiplier
	fMul += m_fFrameTime * 0.5f;
}

bool FSPPCApp::HitMountain(double* Vertex_list,int no_tile,float each_width,float curr_x,float curr_y,float curr_sky,int height_factor){
	
	if((curr_x<0) || curr_x>(no_tile*each_width)){
		//out of mountain
		if(curr_sky>0.0f)
			return false;//false=hot hit
		else
//			MsgBox(	_T("HIT"),_T("out of range X"));
			return true;//true = hit
	}
	if((curr_y>0) || curr_y<(-no_tile*each_width)){
		//out of mountain
		if(curr_sky>0.0f)
			return false;
		else
//			MsgBox(	_T("HIT"),_T("out of range Y"));
			return true;//hit mountain
	}
	int tile_pos_x=(int)floor(curr_x/each_width);
	int tile_pos_y=(int)floor(-curr_y/each_width);
	double avg_height = (Vertex_list[(tile_pos_y*(no_tile+1))+tile_pos_x]+Vertex_list[(tile_pos_y*(no_tile+1))+tile_pos_x+1]+Vertex_list[((tile_pos_y+1)*(no_tile+1))+tile_pos_x]+Vertex_list[((tile_pos_y+1)*(no_tile+1))+tile_pos_x+1])/4;
	avg_height=avg_height*height_factor;
	if(curr_sky<avg_height){
		//char TxtScreen[256];
		//sprintf(TxtScreen, "OK %f",avg_height);
		//MsgBox(	_T("HIT"),_T(TxtScreen));
		return true;//true = hitting
	}
	else
		return false;//not hitting
	
}

void FSPPCApp::CreateOceanA(double GridAmount,float x_start,float y_start,float spacing,float height)
{
	// num of vertices on grid that we create
	int gridx = (int)GridAmount;
	int gridy = (int)GridAmount;
	
	int i;
	int j;

	if (m_VerticesA.Startup(NULL, gridx*gridy, eDE_VERTEXTYPE_TC1) != DE_OK)
		return;

	CDiesel3DVertex *pVert = (CDiesel3DVertex*)m_VerticesA.Lock();
	if (pVert == NULL)
		return;

	// generate the vertex grid
	int k=0;
	for (i=0; i<gridy; i++)
	{
		for (j=0; j<gridx; j++)
		{
			// set the vertex coordinate
			pVert->x = (j*spacing);
			pVert->z = -(i*spacing);
			// some random values to z
			pVert->y = height;
			// set normal to zero, we'll compute the normals later
			pVert->nx = 0.0f;
			pVert->ny = 0.0f;
			pVert->nz = 0.0f;
			pVert->tu = 0.0f;
			pVert->tv = 0.0f;

			pVert++;
		}
	}
	m_VerticesA.Translate(x_start, 0.0f,y_start);
	m_VerticesA.Unlock();

	if (m_IndicesA.Startup(NULL, (gridx-1)*(gridy-1)*6, eDE_IBTYPE_WORD) != DE_OK)
		return;

	// lock the index buffer to gain access to indices
	WORD *pInd = (WORD*)m_IndicesA.Lock();
	if (pInd == NULL)
		return;

	// set the indices.
	// we'll be using single triangle list
	// to render the vertex buffer
	for (i=0; i<gridy-1; i++)
	{
		for (int j=0; j<gridx-1; j++)
		{
			WORD tmp = (WORD)(i*gridx+j);

			pInd[0] = tmp;
			pInd[1] = tmp+1;
			pInd[2] = tmp+1+gridx;

			pInd[3] = tmp+1+gridx;
			pInd[4] = tmp+gridx;
			pInd[5] = tmp;
			pInd += 6;
		}
	}

	m_IndicesA.Unlock();


	CDieselArray<CDiesel3DIndexBuffer*> arrInd;
	arrInd.Add(&m_IndicesA);
	m_VerticesA.ComputeNormals(&arrInd);
	m_VerticesA.Optimize();
	arrInd.Clear();

	CDiesel3DFaceMesh *pFace = SAFE_NEW(CDiesel3DFaceMesh);
	if (pFace == NULL)
		return;

	pFace->Startup(		&m_IndicesA,
						&m_VerticesA,
						&m_Material,
						&m_3DObject.GetWorldMatrix(),
						eDE_PRIMTYPE_TRIANGLELIST);
	m_3DObject.AddFaceMesh(pFace);
	// set the material diffuse starting color...
}
void FSPPCApp::ViewCockpit(){
	CDieselVector3 RefPos,RefDir,RefRight,RefUp;
	CDieselMatrix4 MatAct1;
	MatAct1 = m_pObjPlane->GetWorldMatrix();
	RefPos=MatAct1.GetPos();
	RefRight=MatAct1.GetRight();
	RefUp=MatAct1.GetUp();
	RefDir=MatAct1.GetDir();

	float roll_angle;
	float pitch_angle;
	pitch_angle=(float)asin(RefDir.y/RefDir.Length());
	
	if(RefUp.y>=0){
		if(RefRight.y>=0){
			roll_angle=(float)asin(RefRight.y/RefRight.Length());
		}else{
			roll_angle=(float)((DEG360)+asin(RefRight.y/RefRight.Length()));
		}
		
		//------ 0 - 180 ------------------
		/*if(RefDir.y>=0){
			pitch_angle=(float)asin(RefDir.y/RefDir.Length());
		}else{
			pitch_angle=(float)((DEG360)+asin(RefDir.y/RefDir.Length()));
		}*/
	}else{
		if(RefRight.y>=0){
			roll_angle=(float)(DEG90+(DEG90-asin(RefRight.y/RefRight.Length())));
		}else{
			roll_angle=(float)((DEG180)-asin(RefRight.y/RefRight.Length()));
		}
		
		//-------180 - 360 ------------------------
		/*if(RefDir.y>=0){
			pitch_angle=(float)(DEG90+(DEG90-asin(RefDir.y/RefDir.Length())));
		}else{
			pitch_angle=(float)((DEG180)-asin(RefDir.y/RefDir.Length()));
		}*/

	}

	CDieselVector3 RefMissilePos=m_pObjMissile->GetWorldMatrix().GetPos();
	
	float enemy_angle,heading_angle;
	//find angle between enemy and myplane
	CDieselVector3 RefEPos=m_pObjPlane2->GetWorldMatrix().GetPos();
	if(RefPos.z<=RefEPos.z){
		if(RefPos.x<=RefEPos.x){//quardrand 1
			enemy_angle=(float)(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x)));
		}else{//quardrand 2
			enemy_angle=(float)(DEG180+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
		}
	}else{
		if(RefPos.x<=RefEPos.x){//quardrand 4
			enemy_angle=(float)(DEG360+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
		}else{//quardrand 3
			enemy_angle=(float)(DEG180+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
		}		
	}

	//find angle direction of myplane
	if(RefDir.z>=0){
		if(RefDir.x>=0){//quardrand1
			heading_angle=(float)(atan(RefDir.z/RefDir.x));
		}else{//quardrand 2
			heading_angle=(float)(DEG180+(atan(RefDir.z/RefDir.x)));
		}
	}else{
		if(RefDir.x>=0){//quardrand4
			heading_angle=(float)(DEG360+(atan(RefDir.z/RefDir.x)));
		}else{//quardrand 3
			heading_angle=(float)(DEG180+(atan(RefDir.z/RefDir.x)));
		}
	}
	//==============================================================
	/*char Tn[256];
	sprintf(Tn, "z-plane, me=%f enemy=%f\n",heading_angle*RADTODEG, enemy_angle*RADTODEG);
	m_Writer.WriteText(10, 100, &m_srfBack, Tn, DE_BLTSRCCOLORKEY);*/
	//==============================================================

	float radar_angle;
	if(RefUp.y>=0){
		radar_angle=enemy_angle-heading_angle;
	}else{
		radar_angle=(DEG270+(DEG90-(enemy_angle-heading_angle)));
	}

	float radar_length;
	CDieselVector3 temppy;
	temppy=RefEPos;
	temppy.Sub(RefPos);
	radar_length=temppy.Length();
	if(radar_length>1500.0f)//radar reach range
		radar_length=15+10;	//15(max) +10(minimum for BltRotate) = 25 <--- stretch for radar
	else
		radar_length=((radar_length/1500)*15)+10;//(0-15)+10(minimum for BltRotate) = 10-25 <--- stretch for radar



	char TxtScreen[256];
	//draw FPS
	//sprintf(TxtScreen, "MyPosition -> %.f , %.f , %.f\nE-Position -> %.f , %.f , %.f\nMissile-Pos-> %.f , %.f , %.f\ndiff:%f\nFps: %.f",RefPos.x,RefPos.y,RefPos.z,RefEPos.x,RefEPos.y,RefEPos.z,RefMissilePos.x,RefMissilePos.y,RefMissilePos.z,radar_length,GetFps());
	//m_Writer.WriteText(0, 0, &m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);

	//draw text for pitch angle
	sprintf(TxtScreen, "%.f",pitch_angle*RADTODEG);
	m_Writer.WriteText(2, 100, &m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);	
	//draw text for Altitude
	sprintf(TxtScreen, "%.f",RefPos.y);
	m_Writer.WriteText(224, 100, &m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);	
	

	//draw shield
	m_srfBack.BltFast(m_iXpos[3], m_iYpos[3], &m_srfPic[3],NULL,DE_BLTHALFALPHA);

	//draw arrow for Pitch Angle
	m_iYpos[4]= (int)(156-(pitch_angle*RADTODEG_DIV2));
	m_srfBack.BltFast(m_iXpos[4], m_iYpos[4], &m_srfPic[4],NULL,DE_BLTSRCCOLORKEY);

	//draw arrow for Altitude meter
	m_iYpos[4]= (int)(201-(RefPos.y/6.666));//scale =90 --> limit/constant = 90, if use limit at 600 then constant = 6.66
	m_srfBack.BltFast(231, m_iYpos[4], &m_srfPic[4],NULL,DE_BLTSRCCOLORKEY|DE_BLTFLIPX);

	//draw ADI
	m_srfBack.BltRotate( m_iXpos[ 1 ], m_iYpos[ 1 ], &m_srfPic[ 1 ],roll_angle, 41, DE_BLTSRCCOLORKEY );

	
	//blink "warning" on-off for 1 sec
	if(TimeUp(ToggleTime1,0.5,m_fFrameTime)){
		ToggleTime1=0;
		BlinkOn1=!BlinkOn1;
	}
	//draw bar M, H, F
	m_srfBack.BltFast( m_iXpos[ 9 ], m_iYpos[ 9 ], &m_srfPic[ 9 ], NULL, NULL );
	//if low missile (left 10%), warning low missile
	if(BlinkOn1&&missile_amount<=missile_amount_all*0.1f){
		m_srfBack.BltFast(164, 249, &m_srfPic[18],NULL,DE_BLTSRCCOLORKEY);
	}
	m_srfBack.BltFast( m_iXpos[ 10], m_iYpos[ 10], &m_srfPic[ 10], NULL, NULL );
	//if low health (left < 2), warning low health
	if(BlinkOn1&&MyPlaneHealth<=2){
		m_srfBack.BltFast(177, 249, &m_srfPic[18],NULL,DE_BLTSRCCOLORKEY);
	}
	m_srfBack.BltFast( m_iXpos[ 11], m_iYpos[ 11], &m_srfPic[ 11], NULL, NULL );
	//if low fuel (left <10%), warning low fuel
	if(BlinkOn1&&fuel_amount<=fuel_amount_all*0.1f){
		m_srfBack.BltFast(190, 249, &m_srfPic[18],NULL,DE_BLTSRCCOLORKEY);
	}
	

	//draw cockpit
	m_srfBack.BltFast( m_iXpos[ 0 ], m_iYpos[ 0 ], &m_srfPic[ 0 ], NULL, DE_BLTSRCCOLORKEY );

	//draw text for Speed
	sprintf(TxtScreen, "%.f",plane_speed);
	m_Writer.WriteText(61, 250, &m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);	

	//draw text for Engine
	sprintf(TxtScreen, "%d",engine_percent);
	m_Writer.WriteText(61, 270, &m_srfBack, TxtScreen, DE_BLTSRCCOLORKEY);	

	//draw radar pointer if visible
	if(m_pObjPlane2->IsVisible())
		m_srfBack.BltRotate( m_iXpos[ 5 ], m_iYpos[ 5 ], &m_srfPic[ 5 ],(DEG360-radar_angle),(int)radar_length, DE_BLTSRCCOLORKEY);

	//draw fire_btn
	if(draw_missile_btn){
		m_srfBack.BltFast( m_iXpos[ 6 ], m_iYpos[ 6 ], &m_srfPic[ 6 ], NULL, DE_BLTSRCCOLORKEY );
	}

	//draw thorttle bar
	m_srfBack.BltFast( m_iXpos[12], m_iYpos[12], &m_srfPic[12], NULL, NULL);

	//draw ok_locked screen
	bool TestTarget=Is_Target_Locked();
	if(TestTarget){
		m_srfBack.BltFast(m_iXpos[13], m_iYpos[13], &m_srfPic[13],NULL,DE_BLTSRCCOLORKEY);
	}

	
	
}
void FSPPCApp::CreateOceanB(double GridAmount,float x_start,float y_start,float spacing,float height)
{
	// num of vertices on grid that we create
	int gridx = (int)GridAmount;
	int gridy = (int)GridAmount;
	
	int i;
	int j;

	if (m_VerticesB.Startup(NULL, gridx*gridy, eDE_VERTEXTYPE_TC1) != DE_OK)
		return;

	CDiesel3DVertex *pVert = (CDiesel3DVertex*)m_VerticesB.Lock();
	if (pVert == NULL)
		return;

	// generate the vertex grid
	int k=0;
	for (i=0; i<gridy; i++)
	{
		for (j=0; j<gridx; j++)
		{
			// set the vertex coordinate
			pVert->x = x_start + (j*spacing);
			pVert->z = y_start - (i*spacing);
			// some random values to z
			pVert->y = height;
			// set normal to zero, we'll compute the normals later
			pVert->nx = 0.0f;
			pVert->ny = 0.0f;
			pVert->nz = 0.0f;
			pVert->tu = 0.0f;
			pVert->tv = 0.0f;

			pVert++;
		}
	}
	//m_Vertices.Translate(300.0f, 0.0f, 0.0f);
	m_VerticesB.Unlock();

	if (m_IndicesB.Startup(NULL, (gridx-1)*(gridy-1)*6, eDE_IBTYPE_WORD) != DE_OK)
		return;

	// lock the index buffer to gain access to indices
	WORD *pInd = (WORD*)m_IndicesB.Lock();
	if (pInd == NULL)
		return;

	// set the indices.
	// we'll be using single triangle list
	// to render the vertex buffer
	for (i=0; i<gridy-1; i++)
	{
		for (int j=0; j<gridx-1; j++)
		{
			WORD tmp = (WORD)(i*gridx+j);

			pInd[0] = tmp;
			pInd[1] = tmp+1;
			pInd[2] = tmp+1+gridx;

			pInd[3] = tmp+1+gridx;
			pInd[4] = tmp+gridx;
			pInd[5] = tmp;
			pInd += 6;
		}
	}

	m_IndicesB.Unlock();


	CDieselArray<CDiesel3DIndexBuffer*> arrInd;
	arrInd.Add(&m_IndicesB);
	m_VerticesB.ComputeNormals(&arrInd);
	m_VerticesB.Optimize();
	arrInd.Clear();

	CDiesel3DFaceMesh *pFace = SAFE_NEW(CDiesel3DFaceMesh);
	if (pFace == NULL)
		return;

	pFace->Startup(		&m_IndicesB,
						&m_VerticesB,
						&m_Material,
						&m_3DObject.GetWorldMatrix(),
						eDE_PRIMTYPE_TRIANGLELIST);
	m_3DObject.AddFaceMesh(pFace);
	// set the material diffuse starting color...
}
bool FSPPCApp::TimeUp(double &time_input,double time_compare, double time_increse){
	if(time_input>=time_compare)
		return true;
	else{
		time_input+=time_increse;
		return false;
	}
}

int FSPPCApp::DecreseBar(int max_pos,int min_pos,int max_value, int current_value){
//return by position on screen that relative to value
	int x;
	x=(int)(min_pos-((min_pos-max_pos)*((float)current_value/(float)max_value)));
	return x;
}

float FSPPCApp::Calculate_Accel(float plane_speed,int engine_percent,float weight){
	switch(engine_percent){
	case 0:{
		if(plane_speed>0)//decrese speed
			plane_speed*=0.9920f;
		else
			plane_speed=0;
		Float_Vec.Set(0.0f,0.0f,0.0f);
		break;}		
	case 60:{
		if(plane_speed<10+(5-weight)){
			if(plane_speed<2.0f)plane_speed=2.0f;
			plane_speed*=1.002f;//increse speed
		}else
			plane_speed*=0.9990f;//decrese speed
		if(Is_Float)Float_Vec.Set(0.0f,(4.2f-weight/10),0.0f);
		break;}
		
	case 80:{
		if(plane_speed<14+(5-weight)){
			if(plane_speed<=2.0f)plane_speed=2.2f;
			plane_speed*=1.003f;//increse speed
		}else
			plane_speed*=0.9994f;//decrese speed
		if(Is_Float)Float_Vec.Set(0.0f,(4.5f-weight/10),0.0f);
		break;}
	case 100:{
		if(plane_speed<18+(5-weight)){
			if(plane_speed<=2.0f)plane_speed=2.4f;
			plane_speed*=1.004f;//increse speed
		}else
			plane_speed*=0.9996f;//decrese speed
		if(Is_Float)Float_Vec.Set(0.0f,(5.0f-weight/10),0.0f);
		break;}
	case 120:{
		if(plane_speed<25+(4-weight)){
			if(plane_speed<=2.0f)plane_speed=2.6f;
			plane_speed*=1.006f;//increse speed
		}else
			plane_speed*=0.9998f;//decrese speed
		if(Is_Float)Float_Vec.Set(0.0f,(5.4f-weight/10),0.0f);
		break;}
	}
	
	return plane_speed;
}

float FSPPCApp::Fuel_Consume(int engine_percent){
	//formula: (Fuel_all/Fuel_consume)/60 = flight time(in minute)
	//example:  (20000/10)/60 --> 33 min.
	//		 :  (20000/50)/60 --> 6.6 min.
	float fuel_amount;
	switch(engine_percent){
	case 60:{
		fuel_amount=10.0f;
		break;}
	case 80:{
		fuel_amount=20.0f;
		break;}
	case 100:{
		fuel_amount=30.0f;
		break;}
	case 120:{
		fuel_amount=50.0f;
		break;}
	}
	return fuel_amount;
}

bool FSPPCApp::Is_Target_Locked(){
	if(DistanceBetween.Length()<=250.0f){
		float enemy_angle_pitch,enemy_angle_yaw,heading_angle_pitch,heading_angle_yaw;
		//only pitch & yaw because we not count on Roll-angle
		CDieselVector3 RefEPos=m_pObjPlane2->GetWorldMatrix().GetPos();
		CDieselVector3 RefDir=m_pObjPlane->GetWorldMatrix().GetDir();
		CDieselVector3 RefPos=m_pObjPlane->GetWorldMatrix().GetPos();
		//--------- pitch --------------
		heading_angle_pitch=(float)asin(RefDir.y/RefDir.Length());
		CDieselVector3 pitch_enemy;
		pitch_enemy=RefEPos;
		pitch_enemy.Sub(RefPos);
		enemy_angle_pitch=(float)asin(pitch_enemy.y/pitch_enemy.Length());

		//--------- yaw --------------
		//find angle between enemy and myplane
		if(RefPos.z<=RefEPos.z){
			if(RefPos.x<=RefEPos.x){//quardrand 1
				enemy_angle_yaw=(float)(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x)));
			}else{//quardrand 2
				enemy_angle_yaw=(float)(DEG180+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
			}
		}else{
			if(RefPos.x<=RefEPos.x){//quardrand 4
				enemy_angle_yaw=(float)(DEG360+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
			}else{//quardrand 3
				enemy_angle_yaw=(float)(DEG180+(atan((RefEPos.z-RefPos.z)/(RefEPos.x-RefPos.x))));
			}		
		}

		//find angle direction of myplane
		if(RefDir.z>=0){
			if(RefDir.x>=0){//quardrand1
				heading_angle_yaw=(float)(atan(RefDir.z/RefDir.x));
			}else{//quardrand 2
				heading_angle_yaw=(float)(DEG180+(atan(RefDir.z/RefDir.x)));
			}
		}else{
			if(RefDir.x>=0){//quardrand4
				heading_angle_yaw=(float)(DEG360+(atan(RefDir.z/RefDir.x)));
			}else{//quardrand 3
				heading_angle_yaw=(float)(DEG180+(atan(RefDir.z/RefDir.x)));
			}
		}
		heading_angle_yaw*=RADTODEG;
		heading_angle_pitch*=RADTODEG;
		enemy_angle_yaw*=RADTODEG;
		enemy_angle_pitch*=RADTODEG;
		//hy=heading_angle_yaw;hp=heading_angle_pitch;ey=enemy_angle_yaw;ep=enemy_angle_pitch;
		//******************
		//place below code in "onflip" loop to show value this thing
		/*char Tn[256];
		sprintf(Tn, "x-plane, me=%f enemy=%f\nz-plane, me=%f enemy=%f\n",heading_angleX, enemy_angleX,heading_angleZ, enemy_angleZ);
		m_Writer.WriteText(10, 100, &m_srfBack, Tn, DE_BLTSRCCOLORKEY);*/
		//*********************
		float testYaw=heading_angle_yaw-enemy_angle_yaw;
		if(testYaw<0.0f)testYaw*=-1;//make positive value
		float testPitch=heading_angle_pitch-enemy_angle_pitch;
		if(testPitch<0.0f)testPitch*=-1;//make positive value
		float testAngle;//use to dicision angle for lock-target;
		if(DistanceBetween.Length()>12.0f)
			testAngle=5.0f;
		else
			testAngle=2.0f;

		if(testPitch<=testAngle && testYaw<=testAngle)
			return true;//ok, target locked
		else
			return false;//no, target too much angle, not locked
	}else
		return false;//out of range, not locked
}
void FSPPCApp::Homing_Adjust(){
	float missile_eye_range=10.0f;//value for missile detect range
	float missile_eye_range_min=2.0f;//threshold value for prevent missile spike-move
	float missile_curve=20.0f;//value for missile that can be turn
	

	//========= pitch finding (find missile pitch VS pitch to enemy =========
	CDieselVector3 RefMDir=m_pObjMissile->GetWorldMatrix().GetDir();
	CDieselVector3 RefMPos=m_pObjMissile->GetWorldMatrix().GetPos();
	float missile_angle_pitch=(float)asin(RefMDir.y/RefMDir.Length());//got pitch-angle of missile direction

	CDieselVector3 vec_enemy=m_pObjPlane2->GetWorldMatrix().GetPos();
	vec_enemy.Sub(RefMPos);//tranform coordinate (pitch enemy is relatively to missile)
	float enemy_angle_pitch=(float)asin(vec_enemy.y/vec_enemy.Length());//go pitch-angle of missilepos-pitch-to-enemy

	missile_angle_pitch*=RADTODEG;
	enemy_angle_pitch*=RADTODEG;
	
	float testPitch=missile_angle_pitch-enemy_angle_pitch;//value of differrent-angle
	if(testPitch<0.0f)testPitch*=(-1);//make positive value for compare
	
	
	CDieselMatrix4 MatAct1;
	CDieselVector3 RefMRight=m_pObjMissile->GetWorldMatrix().GetRight();
	//------now, adjust pitch if eye_range can be reach
	if(testPitch<=missile_eye_range&&testPitch>missile_eye_range_min){//if differrent is in range of misile & more than treshold (prevent missile up-down-up-down) 
		if(missile_angle_pitch>enemy_angle_pitch){//if missile to high angle, then down
			MatAct1.RotationAxis(RefMRight,missile_curve*m_fFrameTime*DEGTORAD);
		}else{//if missile to low angle, then up
			MatAct1.RotationAxis(RefMRight,-missile_curve*m_fFrameTime*DEGTORAD);
		}
		m_pObjMissile->GetLocalMatrix().Mul3x3(m_pObjMissile->GetLocalMatrix(),MatAct1);
	}

	//======== yaw finding (find missile yaw VS yaw to enemy =======
	CDieselVector3 RefEPos=m_pObjPlane2->GetWorldMatrix().GetPos();

	//find angle between enemy and missile (yaw to enemy)
	float enemy_angle_yaw,missile_angle_yaw;
	if(RefMPos.z<=RefEPos.z){
		if(RefMPos.x<=RefEPos.x){//quardrand 1
			enemy_angle_yaw=(float)(atan((RefEPos.z-RefMPos.z)/(RefEPos.x-RefMPos.x)));
		}else{//quardrand 2
			enemy_angle_yaw=(float)(DEG180+(atan((RefEPos.z-RefMPos.z)/(RefEPos.x-RefMPos.x))));
		}
	}else{
		if(RefMPos.x<=RefEPos.x){//quardrand 4
			enemy_angle_yaw=(float)(DEG360+(atan((RefEPos.z-RefMPos.z)/(RefEPos.x-RefMPos.x))));
		}else{//quardrand 3
			enemy_angle_yaw=(float)(DEG180+(atan((RefEPos.z-RefMPos.z)/(RefEPos.x-RefMPos.x))));
		}		
	}
	//find angle direction of missile (missile yaw)
	if(RefMDir.z>=0){
		if(RefMDir.x>=0){//quardrand1
			missile_angle_yaw=(float)(atan(RefMDir.z/RefMDir.x));
		}else{//quardrand 2
			missile_angle_yaw=(float)(DEG180+(atan(RefMDir.z/RefMDir.x)));
		}
	}else{
		if(RefMDir.x>=0){//quardrand4
			missile_angle_yaw=(float)(DEG360+(atan(RefMDir.z/RefMDir.x)));
		}else{//quardrand 3
			missile_angle_yaw=(float)(DEG180+(atan(RefMDir.z/RefMDir.x)));
		}
	}

	missile_angle_yaw*=RADTODEG;
	enemy_angle_yaw*=RADTODEG;
	float testYaw=missile_angle_yaw-enemy_angle_yaw;//value of differrent-angle
	if(testYaw<0.0f)testYaw*=(-1);//make positive value for compare
	//------now, adjust yaw if eye_range can be reach
	CDieselVector3 RefMUp=m_pObjMissile->GetWorldMatrix().GetUp();
	if(testYaw<=missile_eye_range&&testYaw>missile_eye_range_min){//if differrent is in range of misile & more than treshold (prevent missile left-right-left-right) 
		if(missile_angle_yaw>enemy_angle_yaw){//if missile too left, then right
			MatAct1.RotationAxis(RefMUp,missile_curve*m_fFrameTime*DEGTORAD);
		}else{//if missile too right , then left
			MatAct1.RotationAxis(RefMUp,-missile_curve*m_fFrameTime*DEGTORAD);
		}
		m_pObjMissile->GetLocalMatrix().Mul3x3(m_pObjMissile->GetLocalMatrix(),MatAct1);
	}
}

float FSPPCApp::SetExplodeParticle(float atX,float atY ,float atZ){
	CDieselVector3 epos, edir;
	SDE_PARTICLE3D_EMIT emit;
	// create material for particles
	CDiesel3DMaterial mat;
	mat.m_cDiffuse = CDiesel3DColor(0.0f, 1.0f, 0.0f, 1.0f);
	mat.m_cAmbient = CDiesel3DColor(0.6f, 0.6f, 0.6f, 1.0f);
	mat.m_cSpecular = CDiesel3DColor(1.0f, 1.0f, 1.0f, 1.0f);
	mat.m_cEmissive = CDiesel3DColor(0.0f, 0.0f, 0.0f, 1.0f);
	mat.m_fShiness = 0.0f;
	m_EmitterExplode.SetMaterial(mat);
	emit.fDirectionSpread = 30.0f;
	emit.fPositionSpread =12.0f;
	emit.fLifeTime = 1.0f;
	emit.fLifeTimeSpread = 2.0f;
	emit.fSize = 0.5f;
	emit.fSizeSpread = 3.0f;
	emit.fWeight = 0.5f;
	epos.Set(atX,atY,atZ);
	edir.Set(0.0f, 50.0f, 0.0f);
	// first parameter:			number of particles to emit per second
	m_EmitterExplode.SetContEmit(30.0f, epos, edir, emit);
	return atY;
}


bool FSPPCApp::HitTest(float ax,float ay,float az,float bx,float by,float bz){
	CDieselVector3 ObjA,ObjB;
	ObjA.Set(ax,ay,az);ObjB.Set(bx,by,bz);
	ObjA.Sub(ObjB);
	if(ObjA.Length()<=1.0f)
		return true;
	else
		return false;
}

void FSPPCApp::ShowEnemyDamage(float x,float y,float z,float SmokeSize){
		CDieselVector3 epos, edir;
		SDE_PARTICLE3D_EMIT emit;
		emit.fDirectionSpread = 10.0f;
		emit.fPositionSpread = 2.0f;
		emit.fSize = SmokeSize;
		emit.fSizeSpread = 5.0f;
		emit.fLifeTime = 5.0f;
		emit.fLifeTimeSpread = 0.5f;

		epos.Set(x,y,z);
		edir.Set(0.0f, 3.0f, 0.0f);

		m_EmitterOther.StopContEmit();		
		m_EmitterOther.SetVisible(TRUE);
		m_EmitterOther.SetContEmit( 5.0f, epos, edir, emit);
}

void FSPPCApp::ShowMyCrash(float x,float y,float z){
	IsEmitterOtherBusy=true;
	CDieselVector3 epos, edir;
	SDE_PARTICLE3D_EMIT emit;
	emit.fDirectionSpread = 10.0f;
	emit.fPositionSpread = 10.0f;
	emit.fSize = 5.0f;
	emit.fSizeSpread = 10.0f;
	emit.fLifeTime = 2.3f;
	emit.fLifeTimeSpread = 0.3f;

	epos.Set(x,y,z);
	edir.Set(0.0f, 20.0f, 0.0f);
	m_EmitterOther.StopContEmit();
	m_EmitterOther.SetVisible(TRUE);
	m_EmitterOther.SetContEmit( 50.0f, epos, edir, emit);
}

void FSPPCApp::ShowEnemyCrash(float x,float y,float z){
	CDieselVector3 epos, edir;
	SDE_PARTICLE3D_EMIT emit;
	emit.fDirectionSpread = 10.0f;
	emit.fPositionSpread = 10.0f;
	emit.fSize = 5.0f;
	emit.fSizeSpread = 10.0f;
	emit.fLifeTime = 2.3f;
	emit.fLifeTimeSpread = 0.3f;

	epos.Set(x,y,z);
	edir.Set(0.0f, 20.0f, 0.0f);
	m_EmitterOther.StopContEmit();
	m_EmitterOther.SetVisible(TRUE);
	m_EmitterOther.SetContEmit( 50.0f, epos, edir, emit);
}

void FSPPCApp::SetJetStream(bool status,int step){
	CDieselVector3 epos, edir;
	SDE_PARTICLE3D_EMIT emit;
	m_pEmitterPlaneA->SetVisible(status);
	switch(step){
	case 1:{//low jet stream
		emit.fDirectionSpread = 1.0f;
		emit.fPositionSpread = 0.0f;
		emit.fSize = 0.9f;
		emit.fSizeSpread = 0.7f;
		emit.fLifeTime = 0.5f;
		emit.fLifeTimeSpread = 0.3f;
		break;
		   }
	case 2:{
		emit.fDirectionSpread = 0.0f;
		emit.fPositionSpread = 0.0f;
		emit.fSize = 1.0f;
		emit.fSizeSpread = 0.6f;
		emit.fLifeTime = 4.6f;
		emit.fLifeTimeSpread = 1.0f;
		break;
		   }
	case 3:{
		emit.fDirectionSpread = 0.0f;
		emit.fPositionSpread = 0.0f;
		emit.fSize = 1.6f;
		emit.fSizeSpread = 0.8f;
		emit.fLifeTime = 5.0f;
		emit.fLifeTimeSpread = 1.3f;
		break;
		   }
	}
	
	epos.Set(0.0f, 0.0f, -2.0f);
	edir.Set(0.0f, 0.0f, 0.0f);
	m_pEmitterPlaneA->StopContEmit();
	m_pEmitterPlaneA->SetContEmit( 40.0f, epos, edir, emit);
}

bool FSPPCApp::IsVisibleJetStream(){
	if(m_pEmitterPlaneA->IsVisible())
		return true;
	else
		return false;
}


void FSPPCApp::EnemySetPos(float x,float y, float z){
	m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3(x,y,z));
}
void FSPPCApp::EnemySetDirSpeed(float dirX,float dirY, float dirZ, float speed){
	CDieselVector3 direction1;
	direction1.Set(dirX,dirY,dirZ);
	m_pObjPlane2->SetVelocity(direction1);
	m_pObjPlane2->SetSpeed(speed);
}

void FSPPCApp::MakeMovementList(){
	srand( (unsigned)time( NULL ) );//Random Seed by time
	int posx,posy,posz,speed;
	

	for(int i=0;i<50;i++){
		for(int j=0;j<3;j++){
			posx=rand();
			posx=(posx%1100)+800;

			posy=rand();
			posy=(posy%300)+200;

			posz=rand();
			posz=(posz%1100)+800;posz=posz*-1;
			if(j==2){//last time of random, make too high pos
				posy=400;
			}
			if(!HitMountain(listy,180,15.0f,(float)posx,(float)posz,(float)posy,30)){
				j=3;//if not hit mountain , quit loop
			}
		}
		
		EnemyMoveList_Pos[i].x=(float)posx;
		EnemyMoveList_Pos[i].y=(float)posy;
		EnemyMoveList_Pos[i].z=(float)posz;

		speed=rand();speed=(speed%10)+8;
		EnemyMoveList_Speed[i]=(float)speed;

	}
	/*CDieselVector3 temp;
	for(i=0;i<49;i++){
		temp.x=EnemyMoveList_Pos[i+1].x-EnemyMoveList_Pos[i].x;
		temp.y=EnemyMoveList_Pos[i+1].y-EnemyMoveList_Pos[i].y;
		temp.z=EnemyMoveList_Pos[i+1].z-EnemyMoveList_Pos[i].z;
		temp.Normalize();
		EnemyMoveList_Dir[i].x=temp.x;
		EnemyMoveList_Dir[i].y=temp.y;
		EnemyMoveList_Dir[i].z=temp.z;
	}*/
}

bool FSPPCApp::IsShouldNextPoint(int currentPoint){
	
	bool x_beyond=false;
	bool y_beyond=false;
	bool z_beyond=false;
	CDieselVector3 Epos=m_pObjPlane2->GetLocalMatrix().GetPos();
	CDieselVector3 Edir=m_pObjPlane2->GetLocalMatrix().GetDir();
	if(Edir.x>0){//if x positive
		if(Epos.x>EnemyMoveList_Pos[currentPoint+1].x)x_beyond=true;//if position beyond target
		
	}else{
		if(Epos.x<EnemyMoveList_Pos[currentPoint+1].x)x_beyond=true;
	}

	if(Edir.y>0){//if y positive
		if(Epos.y>EnemyMoveList_Pos[currentPoint+1].y)y_beyond=true;
	}else{
		if(Epos.y<EnemyMoveList_Pos[currentPoint+1].y)y_beyond=true;
	}

	if(Edir.z>0){//if z positive
		if(Epos.z>EnemyMoveList_Pos[currentPoint+1].z)z_beyond=true;
	}else{
		if(Epos.z<EnemyMoveList_Pos[currentPoint+1].z)z_beyond=true;
	}

	if(x_beyond && y_beyond && z_beyond){//if beyond nextpoint
		char xx[200];
		sprintf(xx, "current point %d \nthispoint x %.f y %.f z %.f \ntopoint x %.f y %.f z %.f",currentList+1,EnemyMoveList_Pos[currentList+1].x,EnemyMoveList_Pos[currentList+1].y,EnemyMoveList_Pos[currentList+1].z,EnemyMoveList_Pos[currentList+2].x,EnemyMoveList_Pos[currentList+2].y,EnemyMoveList_Pos[currentList+2].z);
		MsgBox(	_T("change"),_T(xx));
		
		
		return true;
	}else{
		return false;
	}
}

void FSPPCApp::EnemyManipulate(){
		//set enemy speed&direction
		CDieselVector3 direction1,temp;
		if(EnemyHealth>0){//if not die, fly around
			
			//----- connect to server type?
			if(connection_state==4){
				int seq_num;char type_code,dir_code;long long_x,long_y,long_z;
				if(ServerRecv(msg_recv)){
		
					decode(msg_recv,seq_num,type_code,dir_code,long_x,long_y,long_z);

					if(type_code=='a'){//if set pos
						m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3((float)long_x,(float)long_y,(float)long_z));				
					}else if(type_code=='b'){//if set dir
						EnemyDir((float)long_x,(float)long_y,(float)long_z);
					}else if(type_code=='c'){//if set missile pos
						m_pObjMissile2->SetVisible(TRUE);
						m_pObjMissile2->GetLocalMatrix().SetPos(CDieselVector3((float)long_x,(float)long_y,(float)long_z));

					}else if(type_code=='d'){//if set missile dir
						EnemyMissileDir((float)long_x,(float)long_y,(float)long_z);
					}else if(type_code=='e'){//has damage!!! by enemyshoot
						ShowDamageTime=0;
						if(MyPlaneHealth>0)MyPlaneHealth--;
					}

				}
				
			}else if(connection_state==15){
				int seq_num;char type_code,dir_code;long long_x,long_y,long_z;
				if(ClientRecv(msg_recv)){
					//m_Writer.WriteText(0,20,&m_srfBack,msg_recv,DE_BLTSRCCOLORKEY);
					decode(msg_recv,seq_num,type_code,dir_code,long_x,long_y,long_z);
					if(type_code=='a'){//if set pos
						m_pObjPlane2->GetLocalMatrix().SetPos(CDieselVector3((float)long_x,(float)long_y,(float)long_z));
					}else if(type_code=='b'){//if set dir
						EnemyDir((float)long_x,(float)long_y,(float)long_z);
					}else if(type_code=='c'){//if set missile pos
						m_pObjMissile2->SetVisible(TRUE);
						m_pObjMissile2->GetLocalMatrix().SetPos(CDieselVector3((float)long_x,(float)long_y,(float)long_z));
					}else if(type_code=='d'){//if set missile dir
						EnemyMissileDir((float)long_x,(float)long_y,(float)long_z);
					}
				}
				
			}else{
				//============ Auto Flying ================
				//check position for map bounce
				temp=m_pObjPlane2->GetLocalMatrix().GetPos();
				
				if(temp.x<0){
					temp.x=0;//reset prevent spike-bounce
					m_pObjPlane2->GetLocalMatrix().SetPos(temp);

					float xpositive=(float)RandFloat(0.0f,1.0f);
					float zdirection=(float)RandFloat(-1.0f,1.0f);
					direction1.Set(xpositive,0.0f,zdirection);
					direction1.Normalize();
					m_pObjPlane2->SetVelocity(direction1);//go to desired direction

					CDieselMatrix4 MatAct1,MatAct2;
					MatAct2.Identity();
					MatAct1.RotateY((DEGTORAD*90)-(float)asin(direction1.z));//rotate object relative to direction

					m_pObjPlane2->GetLocalMatrix().Mul3x3(MatAct2,MatAct1);

				}else if(temp.x>2700){
					temp.x=2700;//reset prevent bounce
					m_pObjPlane2->GetLocalMatrix().SetPos(temp);
					float xnegative=(float)RandFloat(-1.0f,0.0f);
					float zdirection=(float)RandFloat(-1.0f,1.0f);
					direction1.Set(xnegative,0.0f,zdirection);
					direction1.Normalize();
					m_pObjPlane2->SetVelocity(direction1);//go to desired direction
					
					/*
					char t1[253];
					sprintf(t1, "%f",RADTODEG*asin(direction1.z));
					MsgBox(	_T("HIT"),_T(t1));
					*/

					CDieselMatrix4 MatAct1,MatAct2;
					MatAct2.Identity();

					MatAct1.RotateY((float)asin(direction1.z)-(DEGTORAD*90));//rotate object relative to direction
					m_pObjPlane2->GetLocalMatrix().Mul3x3(MatAct2,MatAct1);
					
				}

				if(temp.z>0){
					temp.z=0;//reset prevent bounce
					m_pObjPlane2->GetLocalMatrix().SetPos(temp);

					float znegative=(float)RandFloat(-1.0f,0.0f);
					float xdirection=(float)RandFloat(-1.0f,1.0f);
					direction1.Set(xdirection,0.0f,znegative);
					direction1.Normalize();
					m_pObjPlane2->SetVelocity(direction1);//go to desired direction

					CDieselMatrix4 MatAct1,MatAct2;
					MatAct2.Identity();

					MatAct1.RotateY((float)acos(direction1.x)+(DEGTORAD*90.0f));//rotate object relative to direction
					m_pObjPlane2->GetLocalMatrix().Mul3x3(MatAct2,MatAct1);

				}else if(temp.z<-2700){
					temp.z=-2700;//reset prevent bounce
					m_pObjPlane2->GetLocalMatrix().SetPos(temp);

					float xdirection=(float)RandFloat(-1.0f,1.0f);
					float zpositive=(float)RandFloat(0.0f,1.0f);
					direction1.Set(xdirection,0.0f,zpositive);
					direction1.Normalize();
					m_pObjPlane2->SetVelocity(direction1);//go to desired direction

					CDieselMatrix4 MatAct1,MatAct2;
					MatAct2.Identity();

					
					MatAct1.RotateY((float)-(acos(direction1.x)-(DEGTORAD*90)));//rotate object relative to direction
					m_pObjPlane2->GetLocalMatrix().Mul3x3(MatAct2,MatAct1);
				}
				m_pObjPlane2->SetSpeed(14);
				//====== end: Auto Flying =====================
			}//===end: select server || client ||  autopilot =======
			
		}else{//enemy health = 0
			CDieselVector3 temppos=m_pObjPlane2->GetLocalMatrix().GetPos();
			ShowEnemyDamage(temppos.x,temppos.y,temppos.z,5.0f);
			
			//check Ground Attack of Enemy plane
			temp=m_pObjPlane2->GetLocalMatrix().GetPos();
			if(HitMountain(listy,180,15.0f,temp.x,temp.z,temp.y,30)){//if ground attack then invisible			
				direction1.Set(0.0f,0.0f,0.0f);//stop plane
				m_pObjPlane2->SetVelocity(direction1);
				m_pObjPlane2->SetSpeed(0.0f);
				
				if(m_pObjPlane2->IsVisible()){//off plane
					m_pObjPlane2->SetVisible(FALSE);
					//show explode
					ExplodeTime=0.0f;
					ExplodeParticlePlane = SetExplodeParticle(temppos.x, temppos.y, temppos.z);
					m_EmitterExplode.SetVisible(TRUE);
					EnemyRespawnTime=0.0f;
				}
			}else{//if not ground attack, fly down through (untill ground attack)
				direction1.Set(0.0f,-1.0f,0.0f);
				m_pObjPlane2->SetVelocity(direction1);
				m_pObjPlane2->SetSpeed(15.0f);
			}
		}		

}

void FSPPCApp::EnemyMissileManipulate(){
	if(m_pObjMissile2->IsVisible()){
		if(connection_state!=4&&connection_state!=15){//if not multiplayer
			m_pObjMissile2->SetVelocity(m_pObjMissile2->GetLocalMatrix().GetDir());
			m_pObjMissile2->SetSpeed(30);
		}

		CDieselVector3 RefMissilePos=m_pObjMissile2->GetWorldMatrix().GetPos();
		//check Missile and the Mountain
		if(m_pObjMissile2->IsVisible()&&HitMountain(listy,180,15.0f,RefMissilePos.x,RefMissilePos.z,RefMissilePos.y,30)){
			m_pObjMissile2->SetVisible(FALSE);
			m_EmitterExplode.SetVisible(TRUE);
			ExplodeTime=0.0f;//reset time-counter
			ExplodeParticlePlane = SetExplodeParticle(RefMissilePos.x, RefMissilePos.y, RefMissilePos.z);		
		}

		//======= check missile hit ME=======
		CDieselVector3 RefMyPos=m_pObjPlane->GetWorldMatrix().GetPos();
		if(HitTest(RefMissilePos.x,RefMissilePos.y,RefMissilePos.z,RefMyPos.x,RefMyPos.y,RefMyPos.z)){
			if(MyPlaneHealth>0){//if have health
				MyPlaneHealth-=1;
				m_iYpos[10]=DecreseBar(219,247,MyPlaneHealth_all,MyPlaneHealth);
				ShowDamageTime=0;
			}
			m_pObjMissile2->SetVisible(FALSE);
			m_pObjMissile2->GetLocalMatrix().SetPos(CDieselVector3(0.0f,-100.0f,0.0f));//hidden missile underground (initial effect from missile)
		}
		//delete missile if out of range
		CDieselVector3	DistanceMissileAndMe;
		DistanceMissileAndMe =m_pObjPlane->GetWorldMatrix().GetPos();
		DistanceMissileAndMe.Sub(m_pObjMissile2->GetWorldMatrix().GetPos());
		if(DistanceMissileAndMe.Length()>550.0f)m_pObjMissile2->SetVisible(FALSE);
	}else{//if not fire or hit
		m_pObjMissile2->SetSpeed(0);//stop missile
		
		if(connection_state!=4&&connection_state!=15){//if not multiplayer
			//---------- auto firing timer  && distance calculator
			CDieselVector3	DistanceEnemyAndMe;
			DistanceEnemyAndMe =m_pObjPlane->GetWorldMatrix().GetPos();
			DistanceEnemyAndMe.Sub(m_pObjPlane2->GetWorldMatrix().GetPos());

			//if in range && have life && in time
			if(DistanceEnemyAndMe.Length()<500.0f&&DistanceEnemyAndMe.Length()>0&&EnemyHealth>0&&TimeUp(EnemyFireTime,7,m_fFrameTime)){
				EnemyFireTime=0;
				/*char t1[253];
				sprintf(t1, "%f",DistanceEnemyAndMe.Length());
				MsgBox(	_T("HIT"),_T(t1));*/
				
				CDieselMatrix4 MatAct1;
				MatAct1.Identity();//for reference
			
				CDieselVector3 epos=m_pObjPlane2->GetWorldMatrix().GetPos();
				CDieselVector3 mypos=m_pObjPlane->GetWorldMatrix().GetPos();
				CDieselVector3 difvec=epos;
				difvec.Sub(mypos);
				if(abs((int)difvec.x)>abs((int)difvec.y)){//if x axis more than y axis
					if(mypos.x>epos.x){//if myplane on x+
						m_pObjMissile2->GetLocalMatrix().SetDir(MatAct1.GetRight());
						m_pObjMissile2->GetLocalMatrix().SetRight(-(MatAct1.GetDir()));
					}else{//myplane on x-
						m_pObjMissile2->GetLocalMatrix().SetDir(-(MatAct1.GetRight()));
						m_pObjMissile2->GetLocalMatrix().SetRight(MatAct1.GetDir());
					}
				}else{
					if(mypos.z>epos.z){//if myplane on z+
						m_pObjMissile2->GetLocalMatrix().SetDir(MatAct1.GetDir());
						m_pObjMissile2->GetLocalMatrix().SetRight(MatAct1.GetRight());
					}else{
						m_pObjMissile2->GetLocalMatrix().SetDir(-(MatAct1.GetDir()));
						m_pObjMissile2->GetLocalMatrix().SetRight(-(MatAct1.GetRight()));
					}
				}
				m_pObjMissile2->GetLocalMatrix().SetPos(epos);
				m_pObjMissile2->GetLocalMatrix().SetUp(MatAct1.GetUp());

				m_pObjMissile2->SetVisible(TRUE);//on missile
			}
		}



	}

	
}

void FSPPCApp::Homing_Adjust2(){
	float missile_eye_range=140.0f;//value for missile detect range
	float missile_eye_range_min=2.0f;//threshold value for prevent missile spike-move
	float missile_curve=50.0f;//value for missile that can be turn
	

	//========= pitch finding (find missile pitch VS pitch to me =========
	CDieselVector3 RefMDir=m_pObjMissile2->GetWorldMatrix().GetDir();
	CDieselVector3 RefMPos=m_pObjMissile2->GetWorldMatrix().GetPos();
	float missile_angle_pitch=(float)asin(RefMDir.y/RefMDir.Length());//got pitch-angle of missile direction

	CDieselVector3 vec_me=m_pObjPlane->GetWorldMatrix().GetPos();
	vec_me.Sub(RefMPos);//tranform coordinate (pitch me is relatively to missile)
	float me_angle_pitch=(float)asin(vec_me.y/vec_me.Length());//go pitch-angle of missilepos-pitch-to-me

	missile_angle_pitch*=RADTODEG;
	me_angle_pitch*=RADTODEG;
	
	float testPitch=missile_angle_pitch-me_angle_pitch;//value of differrent-angle
	if(testPitch<0.0f)testPitch*=(-1);//make positive value for compare
	
	
	CDieselMatrix4 MatAct1;
	CDieselVector3 RefMRight=m_pObjMissile2->GetWorldMatrix().GetRight();
	//------now, adjust pitch if eye_range can be reach
	if(testPitch<=missile_eye_range&&testPitch>missile_eye_range_min){//if differrent is in range of misile & more than treshold (prevent missile up-down-up-down) 
		if(missile_angle_pitch>me_angle_pitch){//if missile to high angle, then down
			MatAct1.RotationAxis(RefMRight,missile_curve*m_fFrameTime*DEGTORAD);
		}else{//if missile to low angle, then up
			MatAct1.RotationAxis(RefMRight,-missile_curve*m_fFrameTime*DEGTORAD);
		}
		m_pObjMissile2->GetLocalMatrix().Mul3x3(m_pObjMissile2->GetLocalMatrix(),MatAct1);
	}

	//======== yaw finding (find missile yaw VS yaw to me =======
	CDieselVector3 RefMePos=m_pObjPlane->GetWorldMatrix().GetPos();

	//find angle between me and missile (yaw to me)
	float me_angle_yaw,missile_angle_yaw;
	if(RefMPos.z<=RefMePos.z){
		if(RefMPos.x<=RefMePos.x){//quardrand 1
			me_angle_yaw=(float)(atan((RefMePos.z-RefMPos.z)/(RefMePos.x-RefMPos.x)));
		}else{//quardrand 2
			me_angle_yaw=(float)(DEG180+(atan((RefMePos.z-RefMPos.z)/(RefMePos.x-RefMPos.x))));
		}
	}else{
		if(RefMPos.x<=RefMePos.x){//quardrand 4
			me_angle_yaw=(float)(DEG360+(atan((RefMePos.z-RefMPos.z)/(RefMePos.x-RefMPos.x))));
		}else{//quardrand 3
			me_angle_yaw=(float)(DEG180+(atan((RefMePos.z-RefMPos.z)/(RefMePos.x-RefMPos.x))));
		}		
	}
	//find angle direction of missile (missile yaw)
	if(RefMDir.z>=0){
		if(RefMDir.x>=0){//quardrand1
			missile_angle_yaw=(float)(atan(RefMDir.z/RefMDir.x));
		}else{//quardrand 2
			missile_angle_yaw=(float)(DEG180+(atan(RefMDir.z/RefMDir.x)));
		}
	}else{
		if(RefMDir.x>=0){//quardrand4
			missile_angle_yaw=(float)(DEG360+(atan(RefMDir.z/RefMDir.x)));
		}else{//quardrand 3
			missile_angle_yaw=(float)(DEG180+(atan(RefMDir.z/RefMDir.x)));
		}
	}

	missile_angle_yaw*=RADTODEG;
	me_angle_yaw*=RADTODEG;
	float testYaw=missile_angle_yaw-me_angle_yaw;//value of differrent-angle
	if(testYaw<0.0f)testYaw*=(-1);//make positive value for compare
	//------now, adjust yaw if eye_range can be reach
	CDieselVector3 RefMUp=m_pObjMissile2->GetWorldMatrix().GetUp();
	if(testYaw<=missile_eye_range&&testYaw>missile_eye_range_min){//if differrent is in range of misile & more than treshold (prevent missile left-right-left-right) 
		if(missile_angle_yaw>me_angle_yaw){//if missile too left, then right
			MatAct1.RotationAxis(RefMUp,missile_curve*m_fFrameTime*DEGTORAD);
		}else{//if missile too right , then left
			MatAct1.RotationAxis(RefMUp,-missile_curve*m_fFrameTime*DEGTORAD);
		}
		m_pObjMissile2->GetLocalMatrix().Mul3x3(m_pObjMissile2->GetLocalMatrix(),MatAct1);
	}
}


bool FSPPCApp::ServerCreate(char* port){
	// Check arguments
	if(strcmp(port, "")==0)
	{
		MsgBox("Error!","Please enter port");
		return false;
	}
	// Get the remote port
	iPort = atoi(port);
	if(iPort<0 || iPort>65563)   // 0 < iPort < 65563
	{
		MsgBox("Error!","Invalid port number!");
		return false;
	}
                          
	// Load version 1.1 of Winsock
	WSAStartup(MAKEWORD(1,1), &wsda);
	sListen = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	if(sListen == SOCKET_ERROR)
	{
		MsgBox("Error!","Socket listen failed!");		
		return false;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(iPort);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);          // Listen on any interface
	int ret = bind(sListen, (struct sockaddr *) &addr, sizeof(addr));
	if(ret == SOCKET_ERROR)
	{
		MsgBox("Error!","Bind port failed!");
		return false;
	}
	ret = listen(sListen, 10);        // Backlog 10
	if(ret == SOCKET_ERROR)
	{
		MsgBox("Error!","Listening failed!");
		return false;
	}
	return true;
}


bool FSPPCApp::ServerAccept(){
	//variable for make non-blocking
	int s; // s is where the data is stored from the select function
	int nfds=NULL; // This is used for Compatibility
	fd_set conn; // Setup the read variable for the Select function
	timeout.tv_sec=0; // Set the timeout to 0 for Non Blocking
	timeout.tv_usec=0;
	FD_ZERO(&conn); // Set the data in conn to nothing
	FD_SET(sListen, &conn); // Tell it to get the data from the Listening Socket
	s = select(nfds, &conn, NULL, NULL, &timeout); // Is there any data coming in?
	if(s>0){
		iAddrLen = sizeof(remote_addr);
		sClient = accept(sListen, (struct sockaddr *) &remote_addr, &iAddrLen);
		if(sClient == SOCKET_ERROR){
			MsgBox("Error!","Accept connection failed!");
			return false;
		}else
			return true;
	}
	return false;
}

bool FSPPCApp::ServerSend(char* x){
	//strcpy(szRepMessage, MESSAGE);
	char szRepMessage[128];          // Store the reply message
	int iMessageLen;
	strcpy(szRepMessage, x);
	iMessageLen = strlen(szRepMessage);
	// Send data
	int ret = send(sClient, szRepMessage, iMessageLen, 0);
	if(ret == SOCKET_ERROR)
	{
		//MsgBox("Error!","Send failed!");
		return false;
	}
	return true;
}

bool FSPPCApp::ServerRecv(char* msg){

	char szInBuffer[128];
	int iBufferLen;
	int ret;                        // Return values
	fd_set conn;
	FD_ZERO(&conn);
	FD_SET(sClient, &conn);
	timeout.tv_sec=0; // Used for Timeout
	timeout.tv_usec=0;
	//int nfds;
	int sockinput = select(sClient, &conn, NULL, NULL, &timeout); // Is there any data coming in?
	if(sockinput>0){
		ret = recv(sClient, szInBuffer, sizeof(szInBuffer), 0);
		if(ret == SOCKET_ERROR){
			//MsgBox("Error!","Receive failed!");
			return false;
		}
		iBufferLen = ret;         // recv() returns the number of bytes read
		szInBuffer[iBufferLen] = '\0'; // convert to cstring
		strcpy(msg,szInBuffer);
		return true;
	}	
	return false;
}

void FSPPCApp::ServerClose(){
	closesocket(sClient);
}

void FSPPCApp::ClientClose(){
	closesocket(sockConnect);
	WSACleanup();
}


bool FSPPCApp::ClientCreate(char* IP,char* Port){
	char szAddress[64];
	int iPort;

	strcpy(szAddress, IP);
	iPort = atoi(Port);
	if(iPort<0 || iPort>65563){
		MsgBox("Error","Invalid Port Number");
		return false;
	}

	// Load version 1.1 of Winsock
	WSAStartup(MAKEWORD(1,1), &wsda);
	// Create a TCP socket
	
	sockConnect = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	// Error?
	if(sockConnect == SOCKET_ERROR){
		MsgBox("Error!","Client socket failed!");		
		return false;
	}
	// Fill in the host information
	addr.sin_family = AF_INET;
	addr.sin_port = htons(iPort);
	addr.sin_addr.s_addr = inet_addr(szAddress);
	return true;

	
}

bool FSPPCApp::ClientConnect(){
	retConnect = connect(sockConnect, (struct sockaddr *) &addr, sizeof(addr));
	if(retConnect == SOCKET_ERROR){
		return false;
	}else{
		return true;
	}

}
bool FSPPCApp::ClientSend(char* msg){
	char szMessage[128];
	int iMessageLen;
	strcpy(szMessage, msg);
	iMessageLen = strlen(szMessage);
	int test = send(sockConnect, szMessage, iMessageLen, 0);
	if(test == SOCKET_ERROR){
		//MsgBox("Error","Error to send");
		return false;
	}else{
		return true;
	}
}

bool FSPPCApp::ClientRecv(char* msg){
	char szInBuffer[128];
	int iBufferLen ;
	int ret;                        // Return values
	fd_set conn;
	FD_ZERO(&conn);
	FD_SET(sockConnect, &conn);
	timeout.tv_sec=0; // Used for Timeout
	timeout.tv_usec=0;
	int test = select(sockConnect, &conn, NULL, NULL, &timeout); // Is there any data coming in?
	if(test>0){
		ret=0;
		int i=0;
		ret = recv(sockConnect, szInBuffer, sizeof(szInBuffer), 0);
		if(ret == SOCKET_ERROR){
			//MsgBox("Error","Client Receive Error");
			return false;
		}
		iBufferLen = ret;         // recv() returns the number of bytes read
		szInBuffer[iBufferLen] = '\0'; // convert to cstring
		strcpy(msg,szInBuffer);
		return true;
	}
	return false;
}


void FSPPCApp::long_s(char *s,long l){
	_ltoa( l, s, 10 );
	if (strlen(s)<6){
		int x= strlen(s);
		int i;
		for(i=x;i<=5;i++){
			s[i]='x';
		}
	}
}

void FSPPCApp::int_s(char *s,int i){
	_itoa( i, s, 10 );
	if (strlen(s)<4){
		int x= strlen(s);
		int v;
		for(v=x;v<=3;v++){
			s[v]='x';
		}
	}
}

int FSPPCApp::s_long(char *s){
	return atol( s );
}

long FSPPCApp::s_int(char *s){
	return atoi( s );
}

void FSPPCApp::encode(char *s,int x1,char x2,char x3,long x,long y,long z){
	char tm1[4];
	char tm2[6];
    int_s(tm1,x1);
	
	s[0]=tm1[0];
	s[1]=tm1[1];
	s[2]=tm1[2];
	s[3]=tm1[3];
	

	s[4]=x2;
	s[5]=x3;
	
	long_s(tm2,x);
    s[6]=tm2[0];
	s[7]=tm2[1];
	s[8]=tm2[2];
	s[9]=tm2[3];
	s[10]=tm2[4];
	s[11]=tm2[5];

	long_s(tm2,y);
	s[12]=tm2[0];
	s[13]=tm2[1];
	s[14]=tm2[2];
	s[15]=tm2[3];
	s[16]=tm2[4];
	s[17]=tm2[5];

	
	long_s(tm2,z);
	s[18]=tm2[0];
	s[19]=tm2[1];
	s[20]=tm2[2];
	s[21]=tm2[3];
	s[22]=tm2[4];
	s[23]=tm2[5];
    s[24]='\0';
}

void FSPPCApp::decode(char *s,int &x1,char &x2,char &x3,long &x,long &y,long &z)
{
	char tm1[4];
	char tm2[6];
	
	tm1[0]=s[0];
	tm1[1]=s[1];
	tm1[2]=s[2];
	tm1[3]=s[3];

	x1=s_int(tm1);
	x2=s[4];
	x3=s[5];
    
	tm2[0]=s[6];
	tm2[1]=s[7];
	tm2[2]=s[8];
	tm2[3]=s[9];
	tm2[4]=s[10];
	tm2[5]=s[11];
	
	x= s_long(tm2);

	tm2[0]=s[12];
	tm2[1]=s[13];
	tm2[2]=s[14];
	tm2[3]=s[15];
	tm2[4]=s[16];
	tm2[5]=s[17];
	
	y= s_long(tm2);

	tm2[0]=s[18];
	tm2[1]=s[19];
	tm2[2]=s[20];
	tm2[3]=s[21];
	tm2[4]=s[22];
	tm2[5]=s[23];
	
	z= s_long(tm2);
}




void FSPPCApp::EnemyDir(float x,float y,float z){
	
	if(x==1){//head x+
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(1.0f,0.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(0.0f,0.0f,-1.0f));
	}else if(x==-1){//head x-
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(-1.0f,0.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(0.0f,0.0f,1.0f));
	}else if(y==1){//head y+
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,0.0f,-1.0f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else if(y==-1){//head y-
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,-1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,0.0f,0.1f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else if(z==1){//head z
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,0.0f,1.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else{//head -z
		m_pObjPlane2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,0.0f,-1.0f));
		m_pObjPlane2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjPlane2->GetLocalMatrix().SetRight(CDieselVector3(-1.0f,0.0f,0.0f));
	}
}

void FSPPCApp::EnemyMissileDir(float x,float y,float z){
	if(x==1){//head x+
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(1.0f,0.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(0.0f,0.0f,-1.0f));
	}else if(x==-1){//head x-
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(-1.0f,0.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(0.0f,0.0f,1.0f));
	}else if(y==1){//head y+
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,0.0f,-1.0f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else if(y==-1){//head y-
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,-1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,0.0f,0.1f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else if(z==1){//head z
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,0.0f,1.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(1.0f,0.0f,0.0f));
	}else{//head -z
		m_pObjMissile2->GetLocalMatrix().SetDir(CDieselVector3(0.0f,0.0f,-1.0f));
		m_pObjMissile2->GetLocalMatrix().SetUp(CDieselVector3(0.0f,1.0f,0.0f));
		m_pObjMissile2->GetLocalMatrix().SetRight(CDieselVector3(-1.0f,0.0f,0.0f));
	}
}