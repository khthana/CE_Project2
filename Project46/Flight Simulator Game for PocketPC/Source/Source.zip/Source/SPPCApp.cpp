//----------------------------------------------------------------------
// SPPCApp.cpp: implementation of the FSPPCApp class.
//
// Created by Diesel Application Wizard v:1.31
// Copyright (c) 2000-2003 Inmar Software Ltd.
//
//----------------------------------------------------------------------

#include "SPPCApp.h"


//----------------------------------------------------------------------
//
// Construction/Destruction
//
//----------------------------------------------------------------------

FSPPCApp::FSPPCApp()
{
}

FSPPCApp::~FSPPCApp()
{

}


//----------------------------------------------------------------------
// OnInitDone()
// Called by DieselEngine, when all initialization is done.
// If return value is FAILED, engine will clean up and close.
// Return value of this function is passed to 'Startup' function
// called at main.cpp
//----------------------------------------------------------------------
DE_RETVAL FSPPCApp::OnInitDone()
{
	DE_RETVAL		res = DE_OK;

	DWORD dwFlags = 0;
	dwFlags |= DE_CREATEZBUFFER;
	dwFlags |= DE_FORCESOFTWARE;

	res = m_3DDevice.Startup(dwFlags);
	if (res != DE_OK)
		return res;

	m_Scene.Startup();

	// set the camera matrix (back 20 units on z-axis)
	// Unlike Direct3D, Diesel3D handles the camera matrix
	// exactly the same way as world matrices. That way
	// same animation functions can be used with 3d objects
	// and 3D camera. You can also add camera as a
	// child object to another to easily follow any object.
	CDieselMatrix4 matCamera;
	matCamera.Identity();
	matCamera.m32 = -30.0f;
	m_3DDevice.SetTransform(eDE_MATRIX_CAMERA, &matCamera);

	// set the camera projection
	// set the projection to:
	// 65 degrees field of view
	// application back buffer height / back buffer width aspect ratio
	// 1.0 near plane
	// 500.0 farplane
	matCamera.MakePerspective(65*DEGTORAD, (float)m_srfBack.GetHeight() / (float)m_srfBack.GetWidth(), 1.0f, 500.0f);
	m_3DDevice.SetTransform(eDE_MATRIX_PROJECTION, &matCamera);

	return DE_OK;
}


// OnExit()
// Called by DieselEngine, just before it cleans up
// this is good place to clean up your resources
void FSPPCApp::OnExit()
{
	m_Scene.Shutdown();
	m_3DDevice.Shutdown();
}




//----------------------------------------------------------------------
//
// Updating
//
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// OnFlip()
// Application main loop
//----------------------------------------------------------------------
void FSPPCApp::OnFlip()
{
	m_Scene.Update();

	// Clear the render target & z-buffer.
	// Clearing the z-buffer to value 1.0 means clearing it
	// to the furthest possible value. Value 0.0 is the closest
	// possible value.
	// The CDiesel3DDevice::ClearRenderTarget function takes
	// 32 bit full color parameter regardless of the display mode.
	m_3DDevice.ClearZBuffer(1.0f);
	m_3DDevice.ClearRenderTarget(0x00555555);

	if (m_3DDevice.BeginScene() == DE_OK)
	{
		// TODO: Add your rendering code here...
		m_Scene.Render();
		m_3DDevice.EndScene();
	}


	// Value returned by IDieselApplication::GetFrameTime is time
	// elapsed since last frame in seconds.
	// So, if value is 0.05, application is running on 20 fps
	// use the IDieselApplication::GetFps function to retreive the current
	// frames per second value.
	// The value returned by DieselApplication::GetFrameTime is used as
	// multiplier everywhere when timing is needed.
	// It is best to use this value to all timing issues. Therefore
	// it is easy to slow down or accelerate the entire application.

	// The IDieselApplication::GetDWordFrameTime returns constantly increasing
	// time value in milliseconds. The start value of this time depends on
	// operating system.
}



//----------------------------------------------------------------------
//
// Overrided Message handlers
//
//----------------------------------------------------------------------



