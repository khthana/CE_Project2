// SerialAnalyzerDlg.h : header file
//

#if !defined(AFX_SERIALANALYZERDLG_H__6D38B58C_B296_4E66_9F33_AD33B3AF3B72__INCLUDED_)
#define AFX_SERIALANALYZERDLG_H__6D38B58C_B296_4E66_9F33_AD33B3AF3B72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSerialAnalyzerDlg dialog

class CSerialAnalyzerDlg : public CDialog
{
// Construction
public:
	CSerialAnalyzerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSerialAnalyzerDlg)
	enum { IDD = IDD_SERIALANALYZER_DIALOG };
	CComboBox	m_stop;
	CComboBox	m_parity;
	CComboBox	m_data;
	CComboBox	m_bitpersec;
	CButton	m_start;
	CComboBox	m_channel;
	CComboBox	m_trigger;
	CComboBox	m_rate;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSerialAnalyzerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSerialAnalyzerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	virtual void OnCancel();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERIALANALYZERDLG_H__6D38B58C_B296_4E66_9F33_AD33B3AF3B72__INCLUDED_)
