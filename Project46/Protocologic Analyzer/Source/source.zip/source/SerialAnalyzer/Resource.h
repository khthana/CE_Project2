//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SerialAnalyzer.rc
//
#define IDD_SERIALANALYZER_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_LRATE                       1000
#define IDC_LTRIGGERCONDITION           1001
#define IDC_LCHANNEL                    1002
#define IDSTART                         1003
#define IDC_LDATA                       1006
#define IDC_LBITPERSEC                  1007
#define IDC_LPARITY                     1008
#define IDC_LSTOP                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
