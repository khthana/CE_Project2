; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CSerialAnalyzerDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "SerialAnalyzer.h"

ClassCount=2
Class1=CSerialAnalyzerApp
Class2=CSerialAnalyzerDlg

ResourceCount=4
Resource2=IDR_MAINFRAME
Resource3=IDD_SERIALANALYZER_DIALOG
Resource4=IDD_SERIALANALYZER_DIALOG (English (U.S.))

[CLS:CSerialAnalyzerApp]
Type=0
HeaderFile=SerialAnalyzer.h
ImplementationFile=SerialAnalyzer.cpp
Filter=N

[CLS:CSerialAnalyzerDlg]
Type=0
HeaderFile=SerialAnalyzerDlg.h
ImplementationFile=SerialAnalyzerDlg.cpp
Filter=D
LastObject=IDSTART



[DLG:IDD_SERIALANALYZER_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CSerialAnalyzerDlg

[DLG:IDD_SERIALANALYZER_DIALOG (English (U.S.))]
Type=1
Class=CSerialAnalyzerDlg
ControlCount=20
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,button,1342177287
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352
Control7=IDC_LRATE,combobox,1344339970
Control8=IDC_LTRIGGERCONDITION,combobox,1344339970
Control9=IDC_LCHANNEL,combobox,1344339970
Control10=IDSTART,button,1342242816
Control11=IDCANCEL,button,1342242816
Control12=IDC_LDATA,combobox,1344340226
Control13=IDC_LBITPERSEC,combobox,1344339970
Control14=IDC_LPARITY,combobox,1344340226
Control15=IDC_LSTOP,combobox,1344340226
Control16=IDC_STATIC,static,1342308352
Control17=IDC_STATIC,static,1342308352
Control18=IDC_STATIC,static,1342308352
Control19=IDC_STATIC,static,1342308352
Control20=IDC_STATIC,button,1342177287

