// SerialAnalyzerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SerialAnalyzer.h"
#include "SerialAnalyzerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

s32 runing;
int getDatasizeValue(int index);
long getBitpersecValue(int index);
int getParityValue(int index);
int getStopbitValue(int index);
double getClkspeedValue(int index);
int getChannelselValue(int index);


/////////////////////////////////////////////////////////////////////////////
// CSerialAnalyzerDlg dialog

CSerialAnalyzerDlg::CSerialAnalyzerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSerialAnalyzerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSerialAnalyzerDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSerialAnalyzerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSerialAnalyzerDlg)
	DDX_Control(pDX, IDC_LSTOP, m_stop);
	DDX_Control(pDX, IDC_LPARITY, m_parity);
	DDX_Control(pDX, IDC_LDATA, m_data);
	DDX_Control(pDX, IDC_LBITPERSEC, m_bitpersec);
	DDX_Control(pDX, IDSTART, m_start);
	DDX_Control(pDX, IDC_LCHANNEL, m_channel);
	DDX_Control(pDX, IDC_LTRIGGERCONDITION, m_trigger);
	DDX_Control(pDX, IDC_LRATE, m_rate);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSerialAnalyzerDlg, CDialog)
	//{{AFX_MSG_MAP(CSerialAnalyzerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDSTART, OnStart)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSerialAnalyzerDlg message handlers

BOOL CSerialAnalyzerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_rate.SetCurSel(0);
	m_trigger.SetCurSel(0);
	m_channel.SetCurSel(0);
	m_bitpersec.SetCurSel(2);
	m_data.SetCurSel(3);
	m_parity.SetCurSel(0);
	m_stop.SetCurSel(0);
	
	runing=0;
	SetTimer(1,1600,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSerialAnalyzerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSerialAnalyzerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSerialAnalyzerDlg::OnStart() 
{
	// TODO: Add your control notification handler code here
	if(runing==0){
		clk_speed=m_rate.GetCurSel();
		trg_type=0; //m_combo2.GetCurSel();
		trg_cond=m_trigger.GetCurSel();
		trg_sel=m_channel.GetCurSel();
		probe1();
		runing=1;
		m_start.SetWindowText("Stop");
	}
	else{
		
		runing=0;
		m_start.SetWindowText("Start");
	}
	//exit(0);

			datasize=getDatasizeValue(m_data.GetCurSel());
			bitpersec=getBitpersecValue(m_bitpersec.GetCurSel());
			//bitpersec=9600;
			stopbit=getStopbitValue(m_stop.GetCurSel());
			paritybit=getParityValue(m_parity.GetCurSel());
			clkspeed=getClkspeedValue(m_rate.GetCurSel());
			//clkspeed=100*1000;
			channelsel=getChannelselValue(m_channel.GetCurSel());
	//serial_analyzer(2);
	//save_serial_file("./demo.txt");
	
}

void CSerialAnalyzerDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
	exit(-1);
}


void CSerialAnalyzerDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(runing){
		if (probe2())
		{
			runing=0;
			m_start.SetWindowText("Start");
			//datasize=m_data.GetItemData(m_data.GetCurSel());
			datasize=getDatasizeValue(m_data.GetCurSel());
			bitpersec=getBitpersecValue(m_bitpersec.GetCurSel());
			stopbit=getStopbitValue(m_stop.GetCurSel());
			paritybit=getParityValue(m_parity.GetCurSel());
			clkspeed=getClkspeedValue(m_rate.GetCurSel());
			channelsel=getChannelselValue(m_channel.GetCurSel());
			exit(0);
		}

	}
	CDialog::OnTimer(nIDEvent);
}

int getDatasizeValue(int index)
{
	switch(index)
	{
	case 0:return 5;
	case 1:return 6;
	case 2:return 7;
	case 3:return 8;
	default:return -1;
	}
}

long getBitpersecValue(int index)
{
	switch(index)
	{
	case 0:return 2400;
	case 1:return 4800;
	case 2:return 9600;
	case 3:return 19200;
	case 4:return 38400;
	case 5:return 57600;
	case 6:return 115200;
	case 7:return 230400;
	case 8:return 460800;
	case 9:return 921600;
	default:return -1;
	}
}

int getParityValue(int index)
{
	switch(index)
	{
	case 0:return 0;
	case 1:return 1;
	default:return -1;
	}
}

int getStopbitValue(int index)
{
	switch(index)
	{
	case 0:return 1;
	case 1:return 2;
	default:return -1;
	}
}

double getClkspeedValue(int index)
{
	switch(index)
	{
	case 0:return 100*1000*1000;
	case 1:return 50*1000*1000;
	case 2:return 25*1000*1000;
	case 3:return 16.6*1000*1000;
	case 4:return 12.5*1000*1000;
	case 5:return 10*1000*1000;
	case 6:return 8.3*1000*1000;
	case 7:return 5*1000*1000;
	case 8:return 3.84*1000*1000;
	case 9:return 2*1000*1000;
	case 10:return 1*1000*1000;
	case 11:return 500*1000;
	case 12:return 100*1000;
	case 13:return 10*1000;
	case 14:return 1*1000;
	default:return -1;

	}
}

int getChannelselValue(int index)
{
	switch(index)
	{
	case 0:return 1;
	case 1:return 2;
	case 2:return 3;
	case 3:return 4;
	case 4:return 5;
	case 5:return 6;
	case 6:return 7;
	case 7:return 8;
	case 8:return 9;
	case 9:return 10;
	case 10:return 11;
	case 11:return 12;
	default:return -1;

	}
}
