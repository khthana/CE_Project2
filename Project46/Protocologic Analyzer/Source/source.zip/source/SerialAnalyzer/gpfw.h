#define	GPFW_CPIPE	0		
#define	GPFW_WPIPE	1	
#define	GPFW_RPIPE	8

#define	GPFW_DIR	0x00
#define	GPFW_SET	0x10
#define	GPFW_GET	0x20
#define	GPFW_WRITE	0x30
#define	GPFW_READ	0x40
#define	GPFW_BWRITE	0x50
#define	GPFW_BREAD	0x60
#define	GPFW_BUS	0xf0
#define	LGFW_GETBAD	0x70