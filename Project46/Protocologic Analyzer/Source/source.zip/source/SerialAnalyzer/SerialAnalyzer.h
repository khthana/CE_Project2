// SerialAnalyzer.h : main header file for the SERIALANALYZER application
//

#if !defined(AFX_SERIALANALYZER_H__ED828ECD_5ECF_40FE_A7CE_EAE415A5C0AB__INCLUDED_)
#define AFX_SERIALANALYZER_H__ED828ECD_5ECF_40FE_A7CE_EAE415A5C0AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short int u16;
typedef signed short int s16;
typedef unsigned int u32;
typedef signed int s32;

#define	SAMPLES		(1024*128)		//4Mbit PBSRAM

struct _probe_def{
	s8	name[13];
	s32	n;
	u8	sel[32];
};

extern unsigned char fw_bin[];
extern u8 ram_buf[];
extern struct _probe_def probe_def[];
extern s32 probe_n;
extern s32 clk_speed,trg_type,trg_cond,trg_sel;
extern int datasize,stopbit,paritybit,channelsel;
extern long bitpersec;
extern double clkspeed;

void logiana_init();

void probe1();
s32 probe2();
void save_vcd(char * filename);
int save_serial_file(char *filename);
void serial_analyzer(char *filename,int channel);

/////////////////////////////////////////////////////////////////////////////
// CSerialAnalyzerApp:
// See SerialAnalyzer.cpp for the implementation of this class
//

class CSerialAnalyzerApp : public CWinApp
{
public:
	CSerialAnalyzerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSerialAnalyzerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSerialAnalyzerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERIALANALYZER_H__ED828ECD_5ECF_40FE_A7CE_EAE415A5C0AB__INCLUDED_)
