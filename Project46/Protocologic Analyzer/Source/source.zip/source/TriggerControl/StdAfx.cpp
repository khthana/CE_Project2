// stdafx.cpp : source file that includes just the standard includes
//	TriggerControl.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



