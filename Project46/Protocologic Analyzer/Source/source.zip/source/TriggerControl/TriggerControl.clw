; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CTriggerControlDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "TriggerControl.h"

ClassCount=2
Class1=CTriggerControlApp
Class2=CTriggerControlDlg

ResourceCount=3
Resource2=IDD_TRIGGERCONTROL_DIALOG
Resource1=IDR_MAINFRAME
Resource3=IDD_TRIGGERCONTROL_DIALOG (English (U.S.))

[CLS:CTriggerControlApp]
Type=0
HeaderFile=TriggerControl.h
ImplementationFile=TriggerControl.cpp
Filter=N
LastObject=CTriggerControlApp

[CLS:CTriggerControlDlg]
Type=0
HeaderFile=TriggerControlDlg.h
ImplementationFile=TriggerControlDlg.cpp
Filter=D
LastObject=IDSTART
BaseClass=CDialog
VirtualFilter=dWC



[DLG:IDD_TRIGGERCONTROL_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CTriggerControlDlg

[DLG:IDD_TRIGGERCONTROL_DIALOG (English (U.S.))]
Type=1
Class=CTriggerControlDlg
ControlCount=11
Control1=IDSTART,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352
Control7=IDC_LRATE,combobox,1344339970
Control8=IDC_STATIC,button,1342177287
Control9=IDC_LTRIGGERCONDITION,combobox,1344339970
Control10=IDC_STATIC,static,1342308352
Control11=IDC_LCHANNEL,combobox,1344339970

