// TriggerControlDlg.h : header file
//

#if !defined(AFX_TRIGGERCONTROLDLG_H__199EB9E1_DA65_402C_9C85_B35C208A4C56__INCLUDED_)
#define AFX_TRIGGERCONTROLDLG_H__199EB9E1_DA65_402C_9C85_B35C208A4C56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTriggerControlDlg dialog

class CTriggerControlDlg : public CDialog
{
// Construction
public:
	CTriggerControlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTriggerControlDlg)
	enum { IDD = IDD_TRIGGERCONTROL_DIALOG };
	CComboBox	m_trigger;
	CComboBox	m_channel;
	CComboBox	m_rate;
	CButton	m_start;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTriggerControlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTriggerControlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIGGERCONTROLDLG_H__199EB9E1_DA65_402C_9C85_B35C208A4C56__INCLUDED_)
