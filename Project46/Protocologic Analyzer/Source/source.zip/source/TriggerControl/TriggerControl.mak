# Microsoft Developer Studio Generated NMAKE File, Based on TriggerControl.dsp
!IF "$(CFG)" == ""
CFG=TriggerControl - Win32 Debug
!MESSAGE No configuration specified. Defaulting to TriggerControl - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "TriggerControl - Win32 Release" && "$(CFG)" != "TriggerControl - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TriggerControl.mak" CFG="TriggerControl - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TriggerControl - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "TriggerControl - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TriggerControl - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\TriggerControl.exe"


CLEAN :
	-@erase "$(INTDIR)\ctrl.obj"
	-@erase "$(INTDIR)\cusb.obj"
	-@erase "$(INTDIR)\fw.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TriggerControl.obj"
	-@erase "$(INTDIR)\TriggerControl.pch"
	-@erase "$(INTDIR)\TriggerControl.res"
	-@erase "$(INTDIR)\TriggerControlDlg.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\TriggerControl.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\TriggerControl.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x41e /fo"$(INTDIR)\TriggerControl.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TriggerControl.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\TriggerControl.pdb" /machine:I386 /out:"$(OUTDIR)\TriggerControl.exe" 
LINK32_OBJS= \
	"$(INTDIR)\ctrl.obj" \
	"$(INTDIR)\cusb.obj" \
	"$(INTDIR)\fw.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\TriggerControl.obj" \
	"$(INTDIR)\TriggerControlDlg.obj" \
	"$(INTDIR)\TriggerControl.res"

"$(OUTDIR)\TriggerControl.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "TriggerControl - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\TriggerControl.exe"


CLEAN :
	-@erase "$(INTDIR)\ctrl.obj"
	-@erase "$(INTDIR)\cusb.obj"
	-@erase "$(INTDIR)\fw.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TriggerControl.obj"
	-@erase "$(INTDIR)\TriggerControl.pch"
	-@erase "$(INTDIR)\TriggerControl.res"
	-@erase "$(INTDIR)\TriggerControlDlg.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\TriggerControl.exe"
	-@erase "$(OUTDIR)\TriggerControl.ilk"
	-@erase "$(OUTDIR)\TriggerControl.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\TriggerControl.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x41e /fo"$(INTDIR)\TriggerControl.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TriggerControl.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\TriggerControl.pdb" /debug /machine:I386 /out:"$(OUTDIR)\TriggerControl.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\ctrl.obj" \
	"$(INTDIR)\cusb.obj" \
	"$(INTDIR)\fw.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\TriggerControl.obj" \
	"$(INTDIR)\TriggerControlDlg.obj" \
	"$(INTDIR)\TriggerControl.res"

"$(OUTDIR)\TriggerControl.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("TriggerControl.dep")
!INCLUDE "TriggerControl.dep"
!ELSE 
!MESSAGE Warning: cannot find "TriggerControl.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "TriggerControl - Win32 Release" || "$(CFG)" == "TriggerControl - Win32 Debug"
SOURCE=.\ctrl.cpp

"$(INTDIR)\ctrl.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\TriggerControl.pch"


SOURCE=.\cusb.cpp

"$(INTDIR)\cusb.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\TriggerControl.pch"


SOURCE=.\fw.cpp

"$(INTDIR)\fw.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\TriggerControl.pch"


SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "TriggerControl - Win32 Release"

CPP_SWITCHES=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\TriggerControl.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\TriggerControl.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TriggerControl - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\TriggerControl.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\TriggerControl.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\TriggerControl.cpp

"$(INTDIR)\TriggerControl.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\TriggerControl.pch"


SOURCE=.\TriggerControl.rc

"$(INTDIR)\TriggerControl.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\TriggerControlDlg.cpp

"$(INTDIR)\TriggerControlDlg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\TriggerControl.pch"



!ENDIF 

