#include "stdafx.h"
#include "TriggerControl.h"
#include "TriggerControlDlg.h"

#include "cusb.h"
#include "gpfw.h"

u8 buf[1024*64];
u8 ram_buf[SAMPLES*4];
HANDLE dh;
s32 clk_speed,trg_type,trg_cond,trg_sel;
u16 bad_data;
s32 now_pos;

void set_reg(u8 n,u8 val){
	u8 buf[64];
	if(n==0){
		buf[0]=GPFW_WRITE;
	}
	else{
		buf[0]=GPFW_WRITE|0x02;
	}
	buf[1]=val;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,2);
}

void logiana_init(){
#if 0
	FILE *fp;
	fp=fopen("c:\\chameleon_usb\\logiana\\fw\\bulktest.bix","rb");
	fread(fw_bin,1,0x1000,fp);
	fclose(fp);
#endif
	
	if(cusb_init(0,&dh,fw_bin,(s8 *)"LGFW",(s8 *)"V100")){
		AfxMessageBox("Not found Logic Analyzer");
	}

	buf[0]=GPFW_DIR | 0x07;
	buf[1]=GPFW_SET | 0x00;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,2);
}

void probe1(){
	//P_CLK_SEL <= "0000"(7-4)
	//P_TRG_TYPE <= "00"(1-0)
	set_reg(0,(clk_speed << 4)|(trg_type));
	//P_TRG_COND <= "00"(7-6)
	//P_TRG_SEL <= "0000"(5-2)
	set_reg(1,(trg_cond << 6)|(trg_sel << 2));

	//Turn LED ON
	buf[0]=GPFW_SET|0x04;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,1);
}

s32 probe2(){
	u8 run;
	buf[0]=GPFW_GET|0x04;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,1);
	usb_bulk_read(&dh,GPFW_RPIPE,&run,1);
	if((run & 0x08)==0){
		return(0);				
	}

	buf[0]=GPFW_BREAD|0x06;
	buf[1]=(u8)(SAMPLES*4);
	buf[2]=(u8)((SAMPLES*4)/64);
	buf[3]=(u8)(((SAMPLES*4)/64)>>8);
	usb_bulk_write(&dh,GPFW_CPIPE,buf,4);
	usb_bulk_read(&dh,GPFW_RPIPE,ram_buf,SAMPLES*4);

	buf[0]=LGFW_GETBAD;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,1);
	usb_bulk_read(&dh,GPFW_RPIPE,(u8*)&bad_data,2);

	memset(ram_buf,0,bad_data*8);

	//Test Saving file
	FILE* fp;
	fp=fopen("temp.dat","wb");
	fwrite(ram_buf,1,SAMPLES*4,fp);
	fclose(fp);

	fp=fopen("temp.dat","rb");
	fread(ram_buf,1,SAMPLES*4,fp);
	fclose(fp);

	save_vcd("./noname.vcd");

	//Turn LED Off
	buf[0]=GPFW_SET|0x00;
	usb_bulk_write(&dh,GPFW_CPIPE,buf,1);

	return(1);
}

struct _probe_def probe_def[64];

s32 probe_n;

s32 mgets(s8 *s,s32 len,s8 **f){
	s32 i;
	for(i=0;i<len;){
		if(**f==0x0a){
			s[i++]=**f;
			(*f)++;
			break;
		}
		if(**f==0x00){
			break;
		}
		s[i++]=**f;
		(*f)++;
	}
	s[i]=0;
	return(i);
}


void def_anal(s8 *def){
	s8 s[1024],*ss;
	s32 i,j;
	for(i=0;;){
		if(mgets(s,1023,&def)==NULL) break;
		if(strncmp((const char *)s,"#SYSPARM",8)==0){
			ss=(signed char *)strtok((char*)s+8," ,\t");
			clk_speed=(s32)strtol((const char *)ss,NULL,10);
			ss=(signed char *)strtok(NULL," ,\t");
			trg_type=(s32)strtol((const char *)ss,NULL,10);
			ss=(signed char *)strtok(NULL," ,\t");
			trg_cond=(s32)strtol((const char *)ss,NULL,10);
			ss=(signed char *)strtok(NULL," ,\t");
			trg_sel=(s32)strtol((const char *)ss,NULL,10);
			ss=(signed char *)strtok(NULL," ,\t");
			bad_data=(u16)strtol((const char *)ss,NULL,10);
			ss=(signed char *)strtok(NULL," ,\t");
			now_pos=(s32)strtol((const char *)ss,NULL,10);
		}
		else if(s[0]!=';'){
			strtok((char*)s," ,\t");
			memcpy(probe_def[i].name,s,12);
			probe_def[i].name[12]=0;
			for(j=0;j<32;j++){
				ss=(signed char *)strtok(NULL," ,\t");
				if((ss==NULL)||(*ss==0x0d)) break;
				probe_def[i].sel[j]=(u8)strtol((char*)ss,NULL,10);
			}
			probe_def[i].n=j;
			i++;
		}
	}
	probe_n=i;
}


/***********************************************************************************/
// File
FILE *vcdout;					//Output file buffer
//FILE *fbuf;							// Input file buffer
char str[100];					//strinf buffer
int i,j;									//use in for loop
double	times;								//time stamp counter
int	ch;									//channel
double time_factor=0;
char time_base[5];
//unsigned char  buffer[SAMPLES*4];		//Input from file
unsigned char  byte_cmp;							//working byte for compare
unsigned int lastvalue[32];				//last change value
unsigned int temp;								//temporary

// Stick with non-whitespace chars.  The character itself is arbitrary.
unsigned char channel[32]={'A','B','C','D','E','F','G','H','I','J',
														'K','L','M','N','O','P','Q','R','S','T',
														'U','V','W','X','Y','Z','a','b','c','d','e','f'};

// Functions for dumping to VCD file.
void vcd_header     (FILE *vcdout); // Standard header
void vcd_startvars  (FILE *vcdout);
void vcd_endvars    (FILE *vcdout);

void save_vcd (char * filename) 
{
   // Open VCD file as a normal ASCII text file for writing.
   //
	vcdout = fopen (filename, "w");
   if (!vcdout) {
      printf ("\nError opening VCD file.");
      return;
	}

   // Always call this.
   vcd_header    (vcdout);
   
   // List every variable to be dumped in here along with its
   // identifying tag character.
   //
   vcd_startvars (vcdout);

   for (i=0;i<32;i++)
   {
	   sprintf(str,"Channel%d",i+1);
	   fprintf (vcdout, "\n$var reg       1 %c   %s   $end", channel[i], str);
//	   vcd_addvar(vcdout, "test", channel[i]);
   }

   vcd_endvars(vcdout);
   //dumpvars

   for (i=0;i<32;i++)
   {
	   lastvalue[i]=0;				//init last value change =0
	   sprintf(str,"\n0%c",channel[i]);
	   fprintf(vcdout,"%s",str);
   }

	fprintf (vcdout, "\n$end");

   // OK.  Start doing C code..
   //
	
////      
      // Dump variables to VCD file.  Dump them all at once, although the VCD
      // file can indicate any number at any time.
      //
	
	//write first time stamp and value to file for avoid array index out of bound in following loop
	times=time_factor;
	ch=0;
		for (j=0x060018;j<0x060019;j++)
		{
		byte_cmp=ram_buf[j];
		temp=byte_cmp&0x01?1:0;
		if (temp!=lastvalue[ch+0])
		{
			lastvalue[ch+0]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+0]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x02?1:0;
		if (temp!=lastvalue[ch+1])
		{
			lastvalue[ch+1]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+1]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x04?1:0;
		if (temp!=lastvalue[ch+2])
		{
			lastvalue[ch+2]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+2]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x08?1:0;
		if (temp!=lastvalue[ch+3])
		{
			lastvalue[ch+3]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+3]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x10?1:0;
		if (temp!=lastvalue[ch+4])
		{
			lastvalue[ch+4]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+4]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x20?1:0;
		if (temp!=lastvalue[ch+5])
		{
			lastvalue[ch+5]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+5]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x40?1:0;
		if (temp!=lastvalue[ch+6])
		{
			lastvalue[ch+6]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+6]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x80?1:0;
		if (temp!=lastvalue[ch+7])
		{
			lastvalue[ch+7]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+7]);
			fprintf (vcdout, "%s",str);
		}
		
		ch+=8;
		}

//Loop for change binary data into vcd format
	times+=time_factor;
	ch=0;
	for (i=0x06001c;i<sizeof(ram_buf);i+=4)
	{ 
		if (sizeof(ram_buf)-i!=4 && !(ram_buf[i]^ram_buf[i-4] || ram_buf[i+1]^ram_buf[i-3] || ram_buf[i+2]^ram_buf[i-2] || ram_buf[i+3]^ram_buf[i-1]))
		{
			times+=time_factor;
			continue;
		}
		else
		{
		ch=0;
		sprintf(str,"\n#%.2f", times);
		times+=time_factor;
		fprintf (vcdout,"%s",str);
		for (j=i;j<i+4;j++)
		{
		byte_cmp=ram_buf[j];
		temp=byte_cmp&0x01?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+0])
		{
			lastvalue[ch+0]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+0]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x02?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+1])
		{
			lastvalue[ch+1]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+1]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x04?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+2])
		{
			lastvalue[ch+2]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+2]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x08?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+3])
		{
			lastvalue[ch+3]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+3]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x10?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+4])
		{
			lastvalue[ch+4]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+4]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x20?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+5])
		{
			lastvalue[ch+5]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+5]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x40?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+6])
		{
			lastvalue[ch+6]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+6]);
			fprintf (vcdout, "%s",str);
		}

		temp=byte_cmp&0x80?1:0;
		if (sizeof(ram_buf)-i==4 || temp!=lastvalue[ch+7])
		{
			lastvalue[ch+7]=temp;
			sprintf(str,"\n%c%c",(temp)+48, channel[ch+7]);
			fprintf (vcdout, "%s",str);
		}
		
		ch+=8;
		}
		}
	}
         
   // Good enough.  Close file.
   fclose (vcdout);
//   fclose (fbuf);
   
}


void vcd_header (FILE *vcdout)
{	
    struct tm *tm_ptr;
    time_t the_time;
    char currenttime[20];

	switch(clk_speed)
	{
	case 0 :
			time_factor=10;
			sprintf(time_base,"ns");
		break;
	case 1 :
			time_factor=20;
			sprintf(time_base,"ns"); 
		break;
	case 2 :
			time_factor=40;
			sprintf(time_base,"ns");
		break;
	case 3 :
			time_factor=60.24096;
			sprintf(time_base,"ns");
		break;
	case 4 :
			time_factor=80;
			sprintf(time_base,"ns");
		break;
	case 5 :
			time_factor=100;
			sprintf(time_base,"ns");
		break;
	case 6 :
			time_factor=120.48193;
			sprintf(time_base,"ns");
		break;
	case 7 :
			time_factor=200;
			sprintf(time_base,"ns");
		break;
	case 8 :
			time_factor=260;
			sprintf(time_base,"ns");
		break;
	case 9 :
			time_factor=500;
			sprintf(time_base,"ns");
		break;
	case 10 :
			time_factor=1;
			sprintf(time_base,"us");
		break;
	case 11 :
			time_factor=2;
			sprintf(time_base,"us");
		break;
	case 12 :
			time_factor=10;
			sprintf(time_base,"us");
		break;
	case 13 :
			time_factor=100;
			sprintf(time_base,"us");
		break;
	case 14 :
			time_factor=1;
			sprintf(time_base,"ms");
		break;
	default :
			time_factor=1;
			sprintf(time_base,"s");
		break;
	}

    (void) time(&the_time);
    tm_ptr = localtime(&the_time);
    strftime(currenttime,256,"%d %B %Y\t%H:%M:%S",tm_ptr);

   fprintf (vcdout, "\n$date");
   fprintf (vcdout, "\n    %s",currenttime);
   fprintf (vcdout, "\n$end");
   fprintf (vcdout, "\n$version");
   fprintf (vcdout, "\n    Protocologic Analyzer 1.0");
   fprintf (vcdout, "\n$end");
   fprintf (vcdout, "\n$timescale");
   fprintf (vcdout, "\n     1%s",time_base);
   fprintf (vcdout, "\n$end");
}

// The next 3 functions build up the part of the VCD file that specifies
// each variable, its width, index ranges and a special tag char.
// This example sticks with dumping 32-bit integers.  Obviously, in Verilog, we
// are allowed arbitrary widths and index ranges.
//
// Call this function at the beginning of the declarations.
//
void vcd_startvars (FILE *vcdout)
{
   fprintf (vcdout, "\n$scope module Protocologic $end");
}

// Call this one at the end.
//
void vcd_endvars (FILE *vcdout)
{
   fprintf (vcdout, "\n$upscope $end");
   fprintf (vcdout, "\n$enddefinitions $end");
   fprintf (vcdout,"\n#0");
   fprintf (vcdout, "\n$dumpvars");
}
