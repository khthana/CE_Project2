// TriggerControlDlg.cpp : implementation file
//
#include "stdafx.h"
#include "TriggerControl.h"
#include "TriggerControlDlg.h"
#include <winioctl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//CScrollBar *hbar,*vbar;
s32 runing;

/////////////////////////////////////////////////////////////////////////////
// CTriggerControlDlg dialog

CTriggerControlDlg::CTriggerControlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTriggerControlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTriggerControlDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTriggerControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTriggerControlDlg)
	DDX_Control(pDX, IDC_LTRIGGERCONDITION, m_trigger);
	DDX_Control(pDX, IDC_LCHANNEL, m_channel);
	DDX_Control(pDX, IDC_LRATE, m_rate);
	DDX_Control(pDX, IDSTART, m_start);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTriggerControlDlg, CDialog)
	//{{AFX_MSG_MAP(CTriggerControlDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDSTART, OnStart)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTriggerControlDlg message handlers

BOOL CTriggerControlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_rate.SetCurSel(0);
	m_trigger.SetCurSel(0);
	m_channel.SetCurSel(0);
	
	runing=0;
	SetTimer(1,1600,NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTriggerControlDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTriggerControlDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTriggerControlDlg::OnStart() 
{
	// TODO: Add your control notification handler code here
	if(runing==0){
		clk_speed=m_rate.GetCurSel();
		trg_type=0; 
		trg_cond=m_trigger.GetCurSel();
		trg_sel=m_channel.GetCurSel();
		probe1();
		runing=1;
		m_start.SetWindowText("Stop");
	}
	else{

		runing=0;
		m_start.SetWindowText("Start");
		//exit(0);
	}
	
}

void CTriggerControlDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	if(runing){
	 if (probe2())
	 {
		runing=0;
		m_start.SetWindowText("Start");
		exit(0);
	 }

	}
	CDialog::OnTimer(nIDEvent);
}


void CTriggerControlDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	//CDialog::OnCancel();
	exit(-1);
}
