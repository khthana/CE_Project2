//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TriggerControl.rc
//
#define IDD_TRIGGERCONTROL_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_LRATE                       1003
#define IDC_LTRIGGERCONDITION           1004
#define IDC_LCHANNEL                    1005
#define IDSTART                         1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
