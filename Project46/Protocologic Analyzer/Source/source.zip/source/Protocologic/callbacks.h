#include <gtk/gtk.h>


void
on_bStart_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_bSaveVCDFile_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_bSerialStart_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_bSerialSaveVCD_clicked              (GtkButton       *button,
                                        gpointer         user_data);
