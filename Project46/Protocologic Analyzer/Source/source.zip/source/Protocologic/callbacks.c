#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_bStart_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
	/*
	if(runing==0)
	{
		
		clk_speed=m_rate.GetCurSel();
		trg_type=0; //m_combo2.GetCurSel();
		trg_cond=m_trigger.GetCurSel();
		trg_sel=m_channel.GetCurSel();
		probe1();
		runing=1;
		m_start.SetWindowText("Stop");
	}
	else{
		//���蒆�~
		runing=0;
		m_start.SetWindowText("Start");
	}
	*/
}


void
on_bSaveVCDFile_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bSerialStart_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bSerialSaveVCD_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}

