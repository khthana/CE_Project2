package image_jtab;

import java.awt.*;

public class Segmentation {

    protected int MAX_X = 0;
    protected int MAX_Y = 0;
    protected MRectangle m_Rec;
    protected int[][] m_Dat;

    private int COUNT = 0;
    private Point[] m_Visitted;
    private int m_Lower, m_Upper;

    public Segmentation ( int[][] dat, int lower, int upper, int MAX_X, int MAX_Y ) {
        this.MAX_X = MAX_X;
        this.MAX_Y = MAX_Y;
        this.m_Dat = dat;
        this.m_Lower = lower;
        this.m_Upper = upper;
    }

    public MRectangle segment ( int x, int y ) {
        m_Rec = new MRectangle ( MAX_X, MAX_Y, 0, 0 );
        m_Visitted = new Point[ MAX_X * MAX_Y ];
        COUNT = 0;
        seg ( x, y );
        return m_Rec;
    }

    private void seg ( int x, int y ) {
        if ( isPointValid ( new Point ( x, y ) ) == false ) {
            return; // Out bound
        }
        if ( isVisitted ( new Point ( x, y ) ) == true ) {
            return; // Visitted
        }

        m_Visitted[ COUNT++ ] = new Point ( x, y );

        if ( m_Dat[ x ][ y ] < m_Lower || m_Dat [ x ][ y ] > m_Upper ) {
            return;
        }

        setRectangle ( new Point ( x, y ) );
        seg ( x - 1, y );
        seg ( x - 1, y - 1 );
        seg ( x - 1, y + 1 );
        seg ( x, y - 1 );
        seg ( x, y + 1 );
        seg ( x + 1, y );
        seg ( x + 1, y - 1 );
        seg ( x + 1, y + 1 );
    }

    private boolean isVisitted ( Point p ) {
        for ( int i = 0; i < COUNT; i++ ) {
            if ( p.equals ( m_Visitted[ i ] ) == true ) {
                return true;
            }
        }
        return false;
    }

    // Set the m_Rectangle
    private void setRectangle ( Point p ) {
        m_Rec.x1 = ( p.x < m_Rec.x1 ) ? p.x : m_Rec.x1;
        m_Rec.x2 = ( p.x > m_Rec.x2 ) ? p.x : m_Rec.x2;
        m_Rec.y1 = ( p.y < m_Rec.y1 ) ? p.y : m_Rec.y1;
        m_Rec.y2 = ( p.y > m_Rec.y2 ) ? p.y : m_Rec.y2;
    }

    // Check the point is in the coordinate.
    private boolean isPointValid ( Point p ) {
        if ( p.x < 0 || p.x >= this.MAX_X ) {
            return false;
        }
        if ( p.y < 0 || p.y >= this.MAX_Y ) {
            return false;
        }
        return true;
    }
}
