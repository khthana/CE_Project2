package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Other_Line {
  public Other_Line() {
  }

    int Mean_Other( BufferedImage im,int w,int h ) {
      int part_one =0,part_two=0,part_three=0,part_four=0;
      MRectangle r= new MRectangle();
      int c_num=0;
      int pos_x=0;
      int x1 =0;
      int a=0;
      int b,w1,h1,h2=0,w2=0;
      int b1=0,b2=0;
      int ans_note=0;
      Find_Point fp = new Find_Point(im);
      if ( h%2 == 1 ) {
              h2 = h+1;
      }
      else {
              h2 = h;
      }
      if ( w%2 == 1 ) {
              w2 = w + 1;
      }
      else {
              w2 = w;
      }

      int count=0;
      int line=0;
      for ( int x=0;  x<w; x++ ) {
              for ( int y=0; y<h; y++ ) {
                      b = im.getRGB(x,y) & 0xFF;
                      if ( b == 0x00 ) {
                              count++;
                      }
              }
              if ( count >= (60*h)/100 ) {
                      if (x1 == x) {
                              line++;
                              pos_x = x;
                      } else {
                              if (x - x1 != 1) {
                                      x1 = x;
                                      line++;
                                      pos_x = x;
                              } else {
                                      if ( x1 == 0 ) {
                                              line++;
                                              pos_x = x;
                                      }
                                      x1 = x;
                              }
                      }
              }
              count=0;
      }
      //System.out.println("pos_x " + pos_x);
      for (int i = 0; i < h2/2; i++) {
              if ( pos_x <=(w-3) ){
                   b = im.getRGB(pos_x + 1, i) & 0xFF;
                   b1 = im.getRGB(pos_x + 2, i) & 0xFF;
                   b2 = im.getRGB(pos_x + 3, i) & 0xFF;
              }
              else {
                      b = im.getRGB(pos_x + 1, i) & 0xFF;
                      b1 = 0x00;
                      b2 = 0x00;
              }
              //System.out.println("b " + b + " " + "b1 " + b1 + " " + "b2 " + b2);
              if (b == 0x00 && b1 == 0x00 && b2 == 0x00) {
                      if ( a == i ) {
                              c_num++;
                              a = i;
                      }
                      else {
                              if ( (i-a) != 1 ) {
                                      c_num++;
                                      a = i;
                              }
                              else {
                                      if ( a == 0 ) {
                                              c_num++;
                                      }
                                      a = i;
                              }
                      }
              }
      }
      for ( int i=h2/2; i<h; i++ ) {
              for (int j = 0; j < pos_x-1; j++) {
                      b = im.getRGB(j, i) & 0xFF;
                      if (b == 0x00) {
                              if (r.x1 == 0) {
                                      r.x1 = j;
                              } else {
                                      if (r.x1 > j) {
                                              r.x1 = j;
                                      }
                              }
                              if (r.x2 == 0) {
                                      r.x2 = j;
                              } else {
                                      if (r.x2 < j) {
                                              r.x2 = j;
                                      }
                              }
                              if (r.y1 == 0) {
                                      r.y1 = i;
                              } else {
                                      if (r.y1 > i) {
                                              r.y1 = i;
                                      }
                              }
                              if (r.y2 == 0) {
                                      r.y2 = i;
                              } else {
                                      if (r.y2 < i) {
                                              r.y2 = i;
                                      }
                              }
                      }
              }
      }

      w1 = r.x2-r.x1;
      h1 = r.y2-r.y1;
      if ( h1%2 == 1 ) {
              h1 = h1+1;
      }
      if ( w1%2 == 1 ) {
              w1 = w1 + 1;
      }
      w1 = (w1/2) + r.x1;
      h1 = ( h1/2) + r.y1;
      b = im.getRGB(w1, h1) & 0xFF;
      if ( fp.part_one == 0 && fp.part_two == 1 && fp.part_three == 1 && fp.part_four == 1 && b != 0xFF ) {
              if ( c_num == 1 ) {
                      ans_note = 9;
              }
              else if ( c_num == 2 ) {
                      ans_note = 10;
              }
              else if ( c_num == 3 ) {
                      ans_note = 26;
              }
              else {
                      ans_note = 0;
              }
      }
      return ans_note;
        }
}