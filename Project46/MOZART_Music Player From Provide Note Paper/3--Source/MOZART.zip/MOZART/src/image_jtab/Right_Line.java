package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Right_Line {
  public Right_Line() {
  }

  int Mean_Right( BufferedImage im,int w,int h)  {
          MRectangle r = new MRectangle();
          int b, w1, h1, h2 = 0, w2 = 0;
          int pos_x=0;
          int ans_note = 0;
          int x1 =0;
          Find_Point fp = new Find_Point(im);
          if (h % 2 == 1) {
                  h2 = h + 1;
          } else {
                  h2 = h;
          }
          if (w % 2 == 1) {
                  w2 = w + 1;
          } else {
                  w2 = w;
          }
          //System.out.println("w2 " + w2 + "h2 " + h2);
          int count=0;
          int line=0;
          for ( int x=0;  x<w; x++ ) {
                  for ( int y=0; y<h; y++ ) {
                          b = im.getRGB(x,y) & 0xFF;
                          if ( b == 0x00 ) {
                                  count++;
                          }
                  }
                  if ( count >= (60*h)/100 ) {
                          if (x1 == x) {
                                  line++;
                                  pos_x = x;
                          } else {
                                  if (x - x1 != 1) {
                                          x1 = x;
                                          line++;
                                          pos_x = x;
                                  } else {
                                          if ( x1 == 0 ) {
                                                  line++;
                                                  pos_x = x;
                                          }
                                      x1 = x;
                              }
                      }
              }
              count=0;
      }

          if (fp.part_one == 0 && fp.part_two == 1) {
                  for (int i = h2/2; i < h; i++) {
                          for (int j = 0; j < pos_x-1; j++) {
                                  b = im.getRGB(j, i) & 0xFF;
                                  if (b == 0x00) {
                                          if (r.x1 == 0) {
                                                  r.x1 = j;
                                          } else {
                                                  if (r.x1 > j) {
                                                          r.x1 = j;
                                                  }
                                          }
                                          if (r.x2 == 0) {
                                                  r.x2 = j;
                                          } else {
                                                  if (r.x2 < j) {
                                                          r.x2 = j;
                                                  }
                                          }
                                          if (r.y1 == 0) {
                                                  r.y1 = i;
                                          } else {
                                                  if (r.y1 > i) {
                                                          r.y1 = i;
                                                  }
                                          }
                                          if (r.y2 == 0) {
                                                  r.y2 = i;
                                          } else {
                                                  if (r.y2 < i) {
                                                          r.y2 = i;
                                                  }
                                          }
                                  }
                          }
                  }
                  //System.out.println("r.x1 " + r.x1 + "r.x2 " + r.x2);
                 // System.out.println("r.y1 " + r.y1 + "r.y2 " + r.y2);
                  w1 = r.x2 - r.x1;
                  h1 = r.y2 - r.y1;
                  if (h1 % 2 == 1) {
                          h1 = h1 + 1;
                  }
                  if (w1 % 2 == 1) {
                          w1 = w1 + 1;
                  }
                  w1 = (w1/2) + r.x1;
                  h1 = ( h1/2) + r.y1;
                  int b1;
                 // System.out.println("w1 " + w1 + "h1 " + h1);
                  b = im.getRGB(w1, h1) & 0xFF;
                  b1 = im.getRGB(w1-1, h1) & 0xFF;
                  if (b == 0xFF || b1 == 0xFF) {
                          ans_note = 8;
                  }
                  else if ( b == 0x00 )
                  {
                          ans_note = 7;
                  }
                  else {
                          ans_note = 0;
                  }
          }
          return ans_note;
  }
}