package image_jtab;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;
import java.lang.*;
import java.util.*;


public class NoteSearcher {

    private Segmentation m_Seg = null;
    private Vector m_Result = null;

    // Only one Constructor.
    public NoteSearcher ( BufferedImage im )
    {
        int X = im.getWidth();
        int Y = im.getHeight();
        int [][] dat = new int [X][Y];
        for ( int j=0; j < Y; j ++ )
            for ( int i=0; i < X; i ++ ) {
                dat [ i ][ j ] = 0xFF & im.getRGB( i, j );
            }
        m_Seg = new Segmentation ( dat, 0x00, 0x00, X, Y );
    }

    // Seach all note in the image, that return vector of MRectangle.
    public Vector searchAll ( )
    {
        m_Result = new Vector ( );
        for ( int j=0; j < this.m_Seg.MAX_Y; j ++ )
            for ( int i=0; i < this.m_Seg.MAX_X; i ++ ) {
                if ( m_Seg.m_Dat[ i ][ j ] == 0x00 ) {
                    if ( this.isVisitted( i, j ) == false ) {
                        this.m_Result.addElement( search ( i, j ) );
                    }
                }
            }

        return m_Result;
    }


    // Search a note at the position.
    public MRectangle search ( int x, int y )
    {
        return this.m_Seg.segment( x, y );
    }

    // Is pixel vissitted.
    private boolean isVisitted ( int x, int y )
    {
        for ( int i=0; i<this.m_Result.size(); i++ ) {
            MRectangle rec = ( MRectangle ) this.m_Result.elementAt( i );
            if ( rec != null && rec.isInside( x, y ) == true )
                return true;
        }
        return false;
    }
}
