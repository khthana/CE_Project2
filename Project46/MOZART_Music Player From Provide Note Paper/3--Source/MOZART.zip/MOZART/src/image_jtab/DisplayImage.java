package image_jtab;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.ImageIcon.*;
import osbaldeston.image.BMP;
import java.awt.image.*;
import java.util.*;

public class DisplayImage extends JTabbedPane implements MouseListener {
        public Image image1;
        public Vector tab_image;
        public Vector tab_byte;
        public DisplayImage () {
                super();
                addMouseListener(this);
                tab_image = new Vector();
                tab_byte = new Vector();
        }

        public void addTab(String title, Component component) {
                this.addTab(title, component, null);
        }

        public void addTab(String title, Component component, Icon extraIcon) {
                super.addTab(title, new Close_Tab(extraIcon), component);
        }

        public void addBufferedImage(BufferedImage bufImage) {
                int w = bufImage.getWidth();
                int h = bufImage.getHeight();
                BufferedImage im = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                Graphics2D g2 = im.createGraphics();
                g2.drawImage(bufImage, 0, 0, null);
                tab_image.addElement(im);
        }

        public void addArrayMusicBytes(Vector b) {
                tab_byte.addElement(b);
        }

        public void mouseClicked(MouseEvent e) {
                int tabNumber=getUI().tabForCoordinate(this, e.getX(), e.getY());
                if (tabNumber < 0) return;
                Rectangle rect=((Close_Tab)getIconAt(tabNumber)).getBounds();
                if (rect.contains(e.getX(), e.getY())) {
                        //the tab is being closed
                        this.removeTabAt(tabNumber);
                        tab_image.removeElementAt(tabNumber);
                        //System.out.println("tab " + tabNumber);
                        if ( tab_byte.size() != 0 && (tab_byte.size()) - tabNumber == 1) {
                                tab_byte.removeElementAt(tabNumber);
                        }
                }
        }

        public void mouseEntered(MouseEvent e) {}
        public void mouseExited(MouseEvent e) {}
        public void mousePressed(MouseEvent e) {}
        public void mouseReleased(MouseEvent e) {}
}
