package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Find_Point
{
        public int part_one;
        public int part_two;
        public int part_three;
        public int part_four;

        public Find_Point()
        {
                part_one = 0;
                part_two = 0;
                part_three = 0;
                part_four = 0;
        }

        public Find_Point(BufferedImage im)
        {
                int b;
                int w;
                int h;
                int h1=0,w1=0;
                w = im.getWidth();
                h = im.getHeight();
                if ( h%2 == 1 ) {
                        h1 = h-1;
                }
                else {
                        h1 = h;
                }
                if ( w%2 == 1 ) {
                        w1 = w - 1;
                }
                else {
                        w1 = w;
                }

                Vector v = new Vector();
                int count =0;
                int left=0,right=0;
                for ( int i=0; i<w; i++ ) {
                        for ( int j=0; j<h; j++ ) {
                                b = im.getRGB(i,j) & 0xFF;
                                if ( b == 0x00 ) {
                                        count++;
                                }
                        }
                        if ( count >= (60*h)/100) {
                                v.addElement(new Integer(i));
                        }
                        count=0;
                }

                Integer i1;
                if ( v.size() != 0 ) {
                        if (v.size() == 1) {
                                i1 = (Integer) v.elementAt(0);
                                left = i1.intValue();
                                right = i1.intValue();
                        }
                        else {
                                i1 = (Integer) v.elementAt(0);
                                left = i1.intValue();
                                i1 = (Integer) v.elementAt(v.size()-1);
                                right = i1.intValue();
                        }
                }

                for ( int x=0; x<left; x++ ) {
                        for ( int y=0; y<h1/2; y++ ) {
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        part_one = 1;
                                }
                        }
                }
                for ( int x=0; x<left; x++ ) {
                        for ( int y=h1/2; y<h; y++ ) {
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        part_two = 1;
                                }
                        }
                }
                for ( int x=right+1; x<w; x++ ) {
                        for ( int y=0; y<h1/2; y++ ) {
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        part_three = 1;
                                }
                        }
                }
                for ( int x=right+1; x<w; x++ ) {
                        for ( int y=h1/2; y<h; y++ ) {
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        part_four = 1;
                                }
                        }
                }
                //System.out.println("left " + left + " " + "right " + right);
               // System.out.println("part " + part_one + part_two + part_three + part_four);
        }
}