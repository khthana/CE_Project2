package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Left_Line {

  public Left_Line() {
  }

  int Mean_Left( BufferedImage im,int w,int h ) {
    int b,w1=0,h1=0,h2=0,w2=0;
    int b2,b3;
//    int pos_x=0;
    int x1=0;
    int a = 0;
    int c_num = 0;
    int ans_note=0;
    MRectangle r= new MRectangle();
    Find_Point fp = new Find_Point(im);
    if ( h%2 == 1 ) {
            h2 = h+1;
    }
    else {
            h2 = h;
    }
    if ( w%2 == 1 ) {
            w2 = w + 1;
    }
    else {
            w2 = w;
    }

    int count=0;
//    int line=0;
    for ( int x=0;  x<w; x++ ) {
            for ( int y=0; y<h; y++ ) {
                    b = im.getRGB(x,y) & 0xFF;
                    if ( b == 0x00 ) {
                            count++;
                    }
            }
            if ( count >= (60*h)/100 ) {
                    x1 = x;
            }
        count=0;
}

    //System.out.println("w2 " + w + "h2 " + h + "pos_x" +x1);
    if ( x1 <= 4) {
            for (int i = h2 / 2; i < h; i++) {
                    b = im.getRGB(x1 + 1, i) & 0xFF;
                    b2 = im.getRGB(x1+2,i) & 0xFF;
                    b3 = im.getRGB(x1+3,i) & 0xFF;
                    if (b == 0x00 && b2 == 0x00 && b3 == 0x00) {
                            if ( a == i ) {
                                    c_num++;
                                    a = i;
                            }
                            else {
                                    if ( (i-a) != 1 ) {
                                            c_num++;
                                            a = i;
                                    }
                                    else {
                                            if ( a == 0 ) {
                                                    c_num++;
                                            }
                                            a = i;
                                    }
                            }
                    }
            }
    }

    if ( fp.part_four == 0  && fp.part_three == 1) {              //find area black colour
      for ( int i=0; i<=h2/2; i++ ) {
        for ( int j=x1+1; j<w; j++ ) {
          b = im.getRGB(j,i) & 0xFF;
            if ( b == 0x00 ) {
              if ( r.x1 == 0 ) {
                r.x1 = j;
              }
              else {
                if (r.x1 > j) {
                  r.x1 = j;
                }
              }
              if ( r.x2 == 0 ) {
                r.x2 = j;
              }
              else {
                if (r.x2 < j) {
                  r.x2 = j;
                }
              }
              if ( r.y1 == 0 ) {
                r.y1 = i;
              }
              else {
                if (r.y1 > i) {
                  r.y1 = i;
                }
              }
              if ( r.y2 == 0 ) {
                r.y2 = i;
              }
              else {
                if (r.y2 < i) {
                  r.y2 = i;
                }
              }
            }
        }
      }
      //System.out.println("r.x1 " + r.x1 + "r.x2 " + r.x2);
      //System.out.println("r.y1 " + r.y1 + "r.y2 " + r.y2);
      w1 = r.x2-r.x1;
      h1 = r.y2-r.y1;
      if ( w1%2 == 1 ) {
              w1 = w1+1;
      }
      if ( h1%2 == 1) {
              h1 = h1+1;
      }
      int b1;
      int c1,c2,c3;
     // System.out.println("w1 " + w1 + "h1 " + h1);
          b = im.getRGB(w1/2,h1/2) & 0xFF;
          b1 = im.getRGB(w1/2-1,h1/2) & 0xFF;
          c1 = im.getRGB(w1/2-1,h1/2-1) & 0xFF;
          c2 = im.getRGB(w1/2+1,h1/2) & 0xFF;
          c3 = im.getRGB(w1/2+1,h1/2+1) & 0xFF;
        //  System.out.println("b " + b);
          if ( b == 0xFF || b1 == 0xFF || c1 == 0xFF || c2 == 0xFF || c3 == 0xFF) {
                  ans_note = 3;
          }
          else if  ( b == 0x00 && b1 == 0x00 ) {
                  ans_note = 2;
          }
          else {
                  ans_note = 0;
          }
      }
      else if ( fp.part_four == 1 && fp.part_three == 1 ) {
              if ( c_num == 1 ) {
                ans_note = 4;
              }
              else if ( c_num == 2 ) {
                ans_note = 5;
              }
              else if ( c_num == 3 ) {
                ans_note = 27;
              }
              else {
                      ans_note = 0;
              }
      }
      else {
              ans_note = 0;
      }
/*      else if ( fp.part_four == 1 && fp.part_three == 0 ) {
              ans_note = 6;
      }*/
      //System.out.println("c_num " + c_num);
      return ans_note;
  }
}