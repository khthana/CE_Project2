package image_jtab;

import java.util.*;
import java.lang.*;
import java.awt.image.*;
import java.awt.*;

public class Find_Angle
{
        public double theta;
        private Vector  vec;

        public Find_Angle()
        {
        }

        public void angle(BufferedImage im1) {
                int w,h;
                double conv = 3.1415926535/180.0;
                int b;
                int z[][];
                int tmax,tmval;
                int center_x,center_y,r,omega,rmax;
                BufferedImage im = null;
                w = im1.getWidth();
                h = im1.getHeight();
                center_x = w/2;
                center_y = h/2;
                rmax = (int) (Math.sqrt((double)(w*w )+ (h*h)) /2 );
                z = new int [180][2*rmax+1];
                int[] p = new int[w * h];
                im1.getRGB(0, 0, w, h, p, 0, w);
                im = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                im.setRGB(0, 0, w, h, p, 0, w);
                for (int i = 0; i < p.length; i++) {
                        b = p[i] & 0xFF;
                        b = (b < 0xE2) ? 0 : 0x00FFFFFF;
                        p[i] = b;
                }
                im.setRGB(0, 0, w, h, p, 0, w);

                w = im.getWidth();
                h = im.getHeight();
                center_x = w/2;
                center_y = h/2;
                rmax = (int) (Math.sqrt((double)(w*w )+ (h*h)) /2 );
                z = new int [180][2*rmax+1];
                vec = new Vector();

                int b1,b2,b3,b4;
                int  kx=0,ky=0;
                int count=0;
                double delta;

                for ( r=0; r<2*rmax+1; r++ ) {
                        for ( omega=0; omega<180; omega++ ) {
                                z[omega][r] = 0;
                        }
                }
                tmax=0;
                tmval=0;
                for ( int y=0; y<h; y++ ) {
                        for ( int x=0; x<w; x++ ) {
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        for ( omega=0; omega<180; omega++ ) {
                                                r =(int)((y-center_y) * Math.sin((double)(Math.toRadians(omega))) +  (x-center_x) * Math.cos((double)(Math.toRadians(omega))));
                                                z[omega][rmax+r] = z[omega][rmax+r]  + 1;
                                        }
                                }
                        }
                }
                for ( int i=0; i<180; i++ ) {
                        for ( int j=0; j<2*rmax+1; j++ ) {
                                if ( z[i][j] > tmval ) {
                                                tmval = z[i][j];
                                                tmax = i;
                                        }
                                }
                        }

//test
                        double omega1=0.0;
                        int z1[][];
                        z1 = new int[10][2*rmax+1];
                        for ( r=0; r<2*rmax+1; r++ ) {
                                for ( int i=0; i<10; i++) {
                                        z1[i][r] = 0;
                                }
                        }

                        for ( int y=0; y<h; y++ ) {
                                for ( int x=0; x<w; x++ ) {
                                        b = im.getRGB(x,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                for ( int i=0; i<10; i++) {
                                                        omega1 = (double)tmax + ((double)i/(double)10);
                                                        r =(int)((y-center_y) * Math.sin((double)(Math.toRadians(omega1))) +  (x-center_x) * Math.cos((double)(Math.toRadians(omega1))));
                                                        z1[i][rmax+r] = z1[i][rmax+r]  + 1;
                                                }
                                        }
                                }
                        }
                        int tmax1=0;
                        tmval=0;
                        for ( int i=0; i<10; i++ ) {
                                for ( int j=0; j<2*rmax+1; j++ ) {
                                        if ( z1[i][j] > tmval ) {
                                                        tmval = z1[i][j];
                                                        tmax1 = i;
                                                }
                                        }
                                }
                        omega1 = (double)tmax + ((double)tmax1/(double)10);

                        this.theta = (double)90 - omega1;
        }
}