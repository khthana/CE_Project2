package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;
import java.awt.*;

public class Delete_Noise {
        public Delete_Noise() {
        }

BufferedImage Clear_Noise ( BufferedImage im ) {
                int w,h;
                int b;
                int kernel[] = new int[9];
                w = im.getWidth(null);
                h = im.getHeight(null);
                BufferedImage buftmp = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                for ( int y=0; y<h; y++ ) {
                        for ( int x=0; x<w; x++ ) {
                                if ( x-1 < 0 || y-1 < 0 ) {
                                        kernel[0] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[0] = 1;
                                        }
                                        else {
                                                kernel[0] = 0;
                                        }
                                }
                                if ( y-1 < 0 ) {
                                        kernel[1] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[1] = 1;
                                        }
                                        else {
                                                kernel[1] = 0;
                                        }
                                }
                                if ( y-1 < 0  || x+1 >=w) {
                                        kernel[2] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[2] = 1;
                                        }
                                        else {
                                                kernel[2] = 0;
                                        }
                                }
                                if ( x-1 < 0 ) {
                                         kernel[3] = 0;
                                 }
                                 else {
                                         b = im.getRGB(x-1,y) & 0xFF;
                                         if ( b == 0x00 ) {
                                                 kernel[3] = 1;
                                         }
                                         else {
                                                 kernel[3] = 0;
                                         }
                                 }

                                          b = im.getRGB(x,y) & 0xFF;
                                          if ( b == 0x00 ) {
                                                  kernel[4] = 1;
                                          }
                                          else {
                                                  kernel[4] = 0;
                                          }

                                          if ( x+1 >= w ) {
                                                   kernel[5] = 0;
                                           }
                                           else {
                                                   b = im.getRGB(x+1,y) & 0xFF;
                                                   if ( b == 0x00 ) {
                                                           kernel[5] = 1;
                                                   }
                                                   else {
                                                           kernel[5] = 0;
                                                   }
                                           }
                                           if ( x-1 < 0 || y+1 >= h) {
                                                    kernel[6] = 0;
                                            }
                                            else {
                                                    b = im.getRGB(x-1,y+1) & 0xFF;
                                                    if ( b == 0x00 ) {
                                                            kernel[6] = 1;
                                                    }
                                                    else {
                                                            kernel[6] = 0;
                                                    }
                                            }
                                            if ( y+1 >= h ) {
                                                     kernel[7] = 0;
                                             }
                                             else {
                                                     b = im.getRGB(x,y+1) & 0xFF;
                                                     if ( b == 0x00 ) {
                                                             kernel[7] = 1;
                                                     }
                                                     else {
                                                             kernel[7] = 0;
                                                     }
                                             }
                                             if ( x+1 >= w || y+1>= h) {
                                                      kernel[8] = 0;
                                              }
                                              else {
                                                      b = im.getRGB(x+1,y+1) & 0xFF;
                                                      if ( b == 0x00 ) {
                                                              kernel[8] = 1;
                                                      }
                                                      else {
                                                              kernel[8] = 0;
                                                      }
                                              }
                                              b = im.getRGB(x,y) & 0xFF;
                                              if ( b == 0x00 ) {
                                                      if ( kernel[0] == 1 && kernel[1] == 1 && kernel[3] == 1 && kernel[2] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 && kernel[8] == 0) {
                                                              buftmp.setRGB(x, y, 0xFFFFFF);
                                                      }
                                                      else if ( kernel[0] == 0 && kernel[1] == 1 && kernel[3] == 0 && kernel[2] == 1 && kernel[5] ==  1 && kernel[6] == 0 && kernel[7] == 0 && kernel[8] == 0 ) {
                                                              buftmp.setRGB(x, y, 0xFFFFFF);
                                                      }
                                                      else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[3] == 1 && kernel[2] == 0 && kernel[5] == 0 && kernel[6] == 1 && kernel[7] == 1 && kernel[8] == 0 ) {
                                                              buftmp.setRGB(x, y, 0xFFFFFF);
                                                      }
                                                      else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[3] == 0 && kernel[2] == 0 && kernel[5] == 1 && kernel[6] == 0 && kernel[7] == 1 && kernel[8] == 1) {
                                                              buftmp.setRGB(x, y, 0xFFFFFF);
                                                      }
                                                      else {
                                                              buftmp.setRGB(x,y,0x00);
                                                      }
                                              }
                                              else {
                                              buftmp.setRGB(x,y,0xFFFFFF);
                                              }
                        }
                }
                return  buftmp;
        }

BufferedImage Clear_Noise1 ( BufferedImage im ) {
                int w,h;
                int b;
                int kernel[] = new int[25];
                w = im.getWidth(null);
                h = im.getHeight(null);
                BufferedImage buftmp = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                for ( int y=0;  y<h; y++ ) {
                        for ( int x=0; x<w; x++ ) {
                                if ( x-2 <0 || y-2 < 0 ) {
                                        kernel[0] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[0] = 1;
                                        }
                                        else {
                                                kernel[0] = 0;
                                        }
                                }
                                 if ( x-1 <0 || y-2 < 0 ) {
                                         kernel[1] = 0;
                                 }
                                 else {
                                         b = im.getRGB(x-1,y-2) & 0xFF;
                                         if ( b == 0x00 ) {
                                                 kernel[1] = 1;
                                         }
                                         else {
                                                 kernel[1] = 0;
                                         }
                                 }
                                         if ( y-2 < 0 ) {
                                                 kernel[2] = 0;
                                         }
                                         else {
                                                 b = im.getRGB(x,y-2) & 0xFF;
                                                 if ( b == 0x00 ) {
                                                         kernel[2] = 1;
                                                 }
                                                 else {
                                                         kernel[2] = 0;
                                                 }
                                         }
                                         if ( x+1 >=w || y-2 < 0 ) {
                                                 kernel[3] = 0;
                                         }
                                         else {
                                                 b = im.getRGB(x+1,y-2) & 0xFF;
                                                 if ( b == 0x00 ) {
                                                         kernel[3] = 1;
                                                 }
                                                 else {
                                                         kernel[3] = 0;
                                                 }
                                         }
                                         if ( x+2 >=w || y-2 < 0 ) {
                                                kernel[4] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+2,y-2) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[4] = 1;
                                                }
                                                else {
                                                        kernel[4] = 0;
                                                }
                                        }
                                        if ( x-2 < 0 || y-1 < 0 ) {
                                                kernel[5] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-2,y-1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[5] = 1;
                                                }
                                                else {
                                                        kernel[5] = 0;
                                                }
                                        }
                                        if ( x-1 < 0 || y-1 < 0 ) {
                                                kernel[6] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-1,y-1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[6] = 1;
                                                }
                                                else {
                                                        kernel[6] = 0;
                                                }
                                        }
                                        if ( y-1 < 0 ) {
                                                kernel[7] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x,y-1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[7] = 1;
                                                }
                                                else {
                                                        kernel[7] = 0;
                                                }
                                        }
                                        if ( x+1 >=w || y-1 < 0 ) {
                                                kernel[8] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+1,y-1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[8] = 1;
                                                }
                                                else {
                                                        kernel[8] = 0;
                                                }
                                        }
                                        if ( x+2 >=w || y-1 < 0 ) {
                                                kernel[9] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+2,y-1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[9] = 1;
                                                }
                                                else {
                                                        kernel[9] = 0;
                                                }
                                        }
                                        if ( x-2 < 0 ) {
                                                kernel[10] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-2,y) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[10] = 1;
                                                }
                                                else {
                                                        kernel[10] = 0;
                                                }
                                        }
                                        if ( x-1 < 0 ) {
                                                kernel[11] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-1,y) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[11] = 1;
                                                }
                                                else {
                                                        kernel[11] = 0;
                                                }
                                        }
                                        b = im.getRGB(x,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[12] = 1;
                                        }
                                        else {
                                                kernel[12] = 0;
                                        }
                                        if ( x+1 >= w ) {
                                                kernel[13] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+1,y) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[13] = 1;
                                                }
                                                else {
                                                        kernel[13] = 0;
                                                }
                                        }
                                        if ( x+2 >= w ) {
                                                kernel[14] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+2,y) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[14] = 1;
                                                }
                                                else {
                                                        kernel[14] = 0;
                                                }
                                        }
                                        if ( x-2 < 0 || y+1 >= h ) {
                                                kernel[15] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-2,y+1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[15] = 1;
                                                }
                                                else {
                                                        kernel[15] = 0;
                                                }
                                        }
                                        if ( x-1 < 0 || y+1 >= h ) {
                                                kernel[16] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-1,y+1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[16] = 1;
                                                }
                                                else {
                                                        kernel[16] = 0;
                                                }
                                        }
                                        if ( y+1 >= h ) {
                                                kernel[17] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x,y+1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[17] = 1;
                                                }
                                                else {
                                                        kernel[17] = 0;
                                                }
                                        }
                                        if ( x+1 >= w || y+1 >= h ) {
                                                kernel[18] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+1,y+1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[18] = 1;
                                                }
                                                else {
                                                        kernel[18] = 0;
                                                }
                                        }
                                        if ( x+2 >= w || y+1 >= h ) {
                                                kernel[19] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x+2,y+1) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[19] = 1;
                                                }
                                                else {
                                                        kernel[19] = 0;
                                                }
                                        }
                                        if ( x-2 < 0 || y+2 >= h ) {
                                                kernel[20] = 0;
                                        }
                                        else {
                                                b = im.getRGB(x-2,y+2) & 0xFF;
                                                if ( b == 0x00 ) {
                                                        kernel[20] = 1;
                                                }
                                                else {
                                                        kernel[20] = 0;
                                                }
                                        }
                                        if ( x-1 < 0 || y+2 >= h ) {
                                                 kernel[21] = 0;
                                         }
                                         else {
                                                 b = im.getRGB(x-1,y+2) & 0xFF;
                                                 if ( b == 0x00 ) {
                                                         kernel[21] = 1;
                                                 }
                                                 else {
                                                         kernel[21] = 0;
                                                 }
                                         }
                                         if ( y+2 >= h ) {
                                                  kernel[22] = 0;
                                          }
                                          else {
                                                  b = im.getRGB(x,y+2) & 0xFF;
                                                  if ( b == 0x00 ) {
                                                          kernel[22] = 1;
                                                  }
                                                  else {
                                                          kernel[22] = 0;
                                                  }
                                          }
                                          if ( x+1 >= w || y+2 >= h ) {
                                                   kernel[23] = 0;
                                           }
                                           else {
                                                   b = im.getRGB(x+1,y+2) & 0xFF;
                                                   if ( b == 0x00 ) {
                                                           kernel[23] = 1;
                                                   }
                                                   else {
                                                           kernel[23] = 0;
                                                   }
                                           }
                                           if ( x+2 >= w || y+2 >= h ) {
                                                    kernel[24] = 0;
                                            }
                                            else {
                                                    b = im.getRGB(x+2,y+2) & 0xFF;
                                                    if ( b == 0x00 ) {
                                                            kernel[24] = 1;
                                                    }
                                                    else {
                                                            kernel[24] = 0;
                                                    }
                                            }
                                            int one=0,zero=0;
                                            for ( int i=0; i<24; i++ ) {
                                                    if ( kernel[i] == 1 ) {
                                                            one++;
                                                    }
                                                    else {
                                                            zero++;
                                                    }
                                            }

                                            if ( (im.getRGB(x,y)& 0xFF) == 0x00 ) {
                                                    //five 1
                                                    if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 1 && kernel[6] == 1 && kernel[7] == 1 &&
                                                              kernel[8] == 1 && kernel[9] == 1 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 1 && kernel[16] == 1 &&
                                                              kernel[17] == 1 && kernel[18] == 1 && kernel[19] == 1 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    //four
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 1 && kernel[6] == 1 && kernel[7] == 1 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 1 &&
                                                              kernel[8] == 1 && kernel[9] == 1 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 1 && kernel[16] == 1 &&
                                                              kernel[17] == 1 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 1 && kernel[18] == 1 && kernel[19] == 1 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    //three
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 1 && kernel[6] == 1 && kernel[7] == 1 &&
                                                              kernel[8] == 1 && kernel[9] == 0 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 1 && kernel[7] == 1 &&
                                                              kernel[8] == 1 && kernel[9] == 1 && kernel[10] == 0 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 1 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 0 && kernel[15] == 1 && kernel[16] == 1 &&
                                                              kernel[17] == 1 && kernel[18] == 1 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 1 &&
                                                              kernel[13] == 1 && kernel[14] == 1 && kernel[15] == 0 && kernel[16] == 1 &&
                                                              kernel[17] == 1 && kernel[18] == 1 && kernel[19] == 1 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    //two
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 1 && kernel[7] == 1 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 1 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 1 &&
                                                              kernel[8] == 1 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 1 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 1 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 1 &&
                                                              kernel[17] == 1 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 1 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 1 && kernel[18] == 1 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 1 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                              kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                              kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                              kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                              kernel[17] == 1 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                              kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }

                                                    /*else if ( kernel[7] == 1  && kernel[17] == 0 )  {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[17] == 1  && kernel[7] == 0 ) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }*/
                                                    else if ( kernel[7] == 1  && kernel[17] == 0 && kernel[2] == 0)  {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else if ( kernel[17] == 1  && kernel[7] == 0 && kernel[22] == 0) {
                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                    }
                                                    else {
                                                            buftmp.setRGB(x, y, 0x00);
                                                    }
                                            }
                                            else {
                                                    buftmp.setRGB(x,y,0xFFFFFF);
                                            }
                                    }
                            }
                            return  buftmp;
        }

        BufferedImage Clear_Noise2 ( BufferedImage im ) {  //ź noise ����բ�Ҵ 1 �ԡ�� ��ǹ͹
                int w,h;
                int b;
                int kernel[] = new int[9];
                w = im.getWidth(null);
                h = im.getHeight(null);
                BufferedImage buftmp = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                for ( int y=0; y<h; y++ ) {
                        for ( int x=0; x<w; x++ ) {
                                if ( x-1 < 0 || y-1 < 0 ) {
                                        kernel[0] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[0] = 1;
                                        }
                                        else {
                                                kernel[0] = 0;
                                        }
                                }
                                if ( y-1 < 0 ) {
                                        kernel[1] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[1] = 1;
                                        }
                                        else {
                                                kernel[1] = 0;
                                        }
                                }
                                if ( y-1 < 0  || x+1 >=w) {
                                        kernel[2] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[2] = 1;
                                        }
                                        else {
                                                kernel[2] = 0;
                                        }
                                }
                                if ( x-1 < 0 ) {
                                        kernel[3] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[3] = 1;
                                        }
                                        else {
                                                kernel[3] = 0;
                                        }
                                }

                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        kernel[4] = 1;
                                }
                                else {
                                        kernel[4] = 0;
                                }

                                if ( x+1 >= w ) {
                                        kernel[5] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[5] = 1;
                                        }
                                        else {
                                                kernel[5] = 0;
                                        }
                                }
                                if ( x-1 < 0 || y+1 >= h) {
                                        kernel[6] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[6] = 1;
                                        }
                                        else {
                                                kernel[6] = 0;
                                        }
                                }
                                if ( y+1 >= h ) {
                                        kernel[7] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[7] = 1;
                                        }
                                        else {
                                                kernel[7] = 0;
                                        }
                                }
                                if ( x+1 >= w || y+1>= h) {
                                        kernel[8] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[8] = 1;
                                        }
                                        else {
                                                kernel[8] = 0;
                                        }
                                }
                                int one=0,zero=0;
                                for ( int i=0; i<9; i++ ) {
                                        if ( kernel[i] == 1 ) {
                                                one++;
                                        }
                                        else {
                                                zero++;
                                        }
                                }
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        if ( kernel[1] == 1 || kernel[7] == 1 ) {
                                                buftmp.setRGB(x, y, 0x00);
                                        }
                                        else {
                                                buftmp.setRGB(x,y,0xFFFFFF);
                                        }
                                }

                                else {
                                        buftmp.setRGB(x,y,0xFFFFFF);
                                }
                        }
                }
                return  buftmp;
        }

        BufferedImage Clear_Noise3 ( BufferedImage im ) {
                int w,h;
                int b;
                int kernel[] = new int[25];
                w = im.getWidth(null);
                h = im.getHeight(null);
                BufferedImage buftmp = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                for ( int y=0;  y<h; y++ ) {
                        for ( int x=0; x<w; x++ ) {
                                if ( x-2 <0 || y-2 < 0 ) {
                                        kernel[0] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[0] = 1;
                                        }
                                        else {
                                                kernel[0] = 0;
                                        }
                                }
                                if ( x-1 <0 || y-2 < 0 ) {
                                        kernel[1] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[1] = 1;
                                        }
                                        else {
                                                kernel[1] = 0;
                                        }
                                }
                                if ( y-2 < 0 ) {
                                        kernel[2] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[2] = 1;
                                        }
                                        else {
                                                kernel[2] = 0;
                                        }
                                }
                                if ( x+1 >=w || y-2 < 0 ) {
                                        kernel[3] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[3] = 1;
                                        }
                                        else {
                                                kernel[3] = 0;
                                        }
                                }
                                if ( x+2 >=w || y-2 < 0 ) {
                                        kernel[4] = 0;
                                }
                                else {
                                        b = im.getRGB(x+2,y-2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[4] = 1;
                                        }
                                        else {
                                                kernel[4] = 0;
                                        }
                                }
                                if ( x-2 < 0 || y-1 < 0 ) {
                                        kernel[5] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[5] = 1;
                                        }
                                        else {
                                                kernel[5] = 0;
                                        }
                                }
                                if ( x-1 < 0 || y-1 < 0 ) {
                                        kernel[6] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[6] = 1;
                                        }
                                        else {
                                                kernel[6] = 0;
                                        }
                                }
                                if ( y-1 < 0 ) {
                                        kernel[7] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[7] = 1;
                                        }
                                        else {
                                                kernel[7] = 0;
                                        }
                                }
                                if ( x+1 >=w || y-1 < 0 ) {
                                        kernel[8] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[8] = 1;
                                        }
                                        else {
                                                kernel[8] = 0;
                                        }
                                }
                                if ( x+2 >=w || y-1 < 0 ) {
                                        kernel[9] = 0;
                                }
                                else {
                                        b = im.getRGB(x+2,y-1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[9] = 1;
                                        }
                                        else {
                                                kernel[9] = 0;
                                        }
                                }
                                if ( x-2 < 0 ) {
                                        kernel[10] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[10] = 1;
                                        }
                                        else {
                                                kernel[10] = 0;
                                        }
                                }
                                if ( x-1 < 0 ) {
                                        kernel[11] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[11] = 1;
                                        }
                                        else {
                                                kernel[11] = 0;
                                        }
                                }
                                b = im.getRGB(x,y) & 0xFF;
                                if ( b == 0x00 ) {
                                        kernel[12] = 1;
                                }
                                else {
                                        kernel[12] = 0;
                                }
                                if ( x+1 >= w ) {
                                        kernel[13] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[13] = 1;
                                        }
                                        else {
                                                kernel[13] = 0;
                                        }
                                }
                                if ( x+2 >= w ) {
                                        kernel[14] = 0;
                                }
                                else {
                                        b = im.getRGB(x+2,y) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[14] = 1;
                                        }
                                        else {
                                                kernel[14] = 0;
                                        }
                                }
                                if ( x-2 < 0 || y+1 >= h ) {
                                        kernel[15] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[15] = 1;
                                        }
                                        else {
                                                kernel[15] = 0;
                                        }
                                }
                                if ( x-1 < 0 || y+1 >= h ) {
                                        kernel[16] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[16] = 1;
                                        }
                                        else {
                                                kernel[16] = 0;
                                        }
                                }
                                if ( y+1 >= h ) {
                                        kernel[17] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[17] = 1;
                                        }
                                        else {
                                                kernel[17] = 0;
                                        }
                                }
                                if ( x+1 >= w || y+1 >= h ) {
                                        kernel[18] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[18] = 1;
                                        }
                                        else {
                                                kernel[18] = 0;
                                        }
                                }
                                if ( x+2 >= w || y+1 >= h ) {
                                        kernel[19] = 0;
                                }
                                else {
                                        b = im.getRGB(x+2,y+1) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[19] = 1;
                                        }
                                        else {
                                                kernel[19] = 0;
                                        }
                                }
                                if ( x-2 < 0 || y+2 >= h ) {
                                        kernel[20] = 0;
                                }
                                else {
                                        b = im.getRGB(x-2,y+2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[20] = 1;
                                        }
                                        else {
                                                kernel[20] = 0;
                                        }
                                }
                                if ( x-1 < 0 || y+2 >= h ) {
                                        kernel[21] = 0;
                                }
                                else {
                                        b = im.getRGB(x-1,y+2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[21] = 1;
                                        }
                                        else {
                                                kernel[21] = 0;
                                        }
                                }
                                if ( y+2 >= h ) {
                                        kernel[22] = 0;
                                }
                                else {
                                        b = im.getRGB(x,y+2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[22] = 1;
                                        }
                                        else {
                                                kernel[22] = 0;
                                        }
                                }
                                if ( x+1 >= w || y+2 >= h ) {
                                        kernel[23] = 0;
                                }
                                else {
                                        b = im.getRGB(x+1,y+2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[23] = 1;
                                        }
                                        else {
                                                kernel[23] = 0;
                                        }
                                }
                                if ( x+2 >= w || y+2 >= h ) {
                                        kernel[24] = 0;
                                }
                                else {
                                        b = im.getRGB(x+2,y+2) & 0xFF;
                                        if ( b == 0x00 ) {
                                                kernel[24] = 1;
                                        }
                                        else {
                                                kernel[24] = 0;
                                        }
                                }
                                int one=0,zero=0;
                                for ( int i=0; i<24; i++ ) {
                                        if ( kernel[i] == 1 ) {
                                                one++;
                                        }
                                        else {
                                                zero++;
                                        }
                                }

                                if ( (im.getRGB(x,y)& 0xFF) == 0x00 ) {
                                        if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                             kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 1 &&
                                             kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                             kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                             kernel[17] == 0 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                             kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                buftmp.setRGB(x,y,0xFFFFFF);
                                        }
                                        else if ( kernel[0] == 0 && kernel[1] == 0 && kernel[2] == 0 && kernel[3] == 0 &&
                                                  kernel[4] == 0 && kernel[5] == 0 && kernel[6] == 0 && kernel[7] == 0 &&
                                                  kernel[8] == 0 && kernel[9] == 0 && kernel[10] == 0 && kernel[11] == 0 &&
                                                  kernel[13] == 0 && kernel[14] == 0 && kernel[15] == 0 && kernel[16] == 0 &&
                                                  kernel[17] == 1 && kernel[18] == 0 && kernel[19] == 0 && kernel[20] == 0 &&
                                                  kernel[21] == 0 && kernel[22] == 0 && kernel[23] == 0 && kernel[24] == 0 ) {
                                                buftmp.setRGB(x,y,0xFFFFFF);
                                        }
                                        /*else if ( kernel[7] == 1  && kernel[17] == 0 )  {
                                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                                    }
                                                                    else if ( kernel[17] == 1  && kernel[7] == 0 ) {
                                                                            buftmp.setRGB(x,y,0xFFFFFF);
                                                                    }*/
                                        else {
                                                buftmp.setRGB(x, y, 0x00);
                                        }
                                }
                                else {
                                        buftmp.setRGB(x,y,0xFFFFFF);
                                }
                        }
                }
                return  buftmp;
        }
}