package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Sort_Note
{
        private Vector note_sort;
        private Vector pos_sort;
        private MRectangle rec;

        public Sort_Note()
        {
        }

        public void sort( Vector note,Vector position,Vector pos_y ) {
                Vector pos_tmp = new Vector();
                pos_tmp = position;
                note_sort = new Vector();
                pos_sort = new Vector();
                Vector vmain = new Vector();
                Vector vposmain = new Vector();
                int line_size=0;
                int line_add=0;
                int y1=0,y2=0;
                line_size = pos_y.size() / 5 ;  //keep amount of staff
                if ( pos_y.size() != 0 ) {
                        Integer tmp1 = (Integer) pos_y.elementAt(4);
                        y1 = tmp1.intValue();
                        Integer tmp2 = (Integer) pos_y.elementAt(5);
                        y2 = tmp2.intValue();
                        line_add = (y2 - y1) / 2; // ������ҧ�����ҧ��÷Ѵ 5 ���
                }
                Vector vsub;
                Vector vpossub;
                //System.out.println("line size " + line_size + " " + "note size " + note.size());
                for ( int i=0; i<line_size; i++ ) {
                        vsub = new Vector();
                        vpossub = new Vector();
                        y1 = i*5;
                        y2 = y1+4;
                        Integer ytmp1 = (Integer)pos_y.elementAt(y1);
                        y1 = ytmp1.intValue();
                        Integer ytmp2 = (Integer)pos_y.elementAt(y2);
                        y2 = ytmp2.intValue();
                        y1 = y1 - line_add;
                        y2 = y2 + line_add;
                        //System.out.println("y1 mmm" + y1 + " " + "y2 " + y2);
                        for (int j= 0; j< note.size(); j++) {
                                rec = (MRectangle) pos_tmp.elementAt(j);
                                if ( rec.y1 > y1 && rec.y2 < y2 ) {  // add note and position near bound
                                        vsub.addElement(note.elementAt(j));
                                        vpossub.addElement(pos_tmp.elementAt(j));
                                }
                        }
                        //System.out.println("vsub " + vsub.size() + " " + "vpossub " + vpossub.size());
                        vmain.addElement(vsub);
                        vposmain.addElement(vpossub);
                }
                //System.out.println("vmain " + vmain.size() + " " + "vpos " + vposmain.size());

                for ( int m=0; m<vmain.size(); m++ ) {
                       sort_all( (Vector)vmain.elementAt(m),(Vector)vposmain.elementAt(m) );
                }
                //print note
                //System.out.println("size note " + note_sort.size());
                /*for ( int i=0; i<note_sort.size(); i++ ) {
                        Integer i1;
                        int i2;
                        i1 = (Integer)note_sort.elementAt(i);
                        i2 = i1.intValue();
                        System.out.println("note sort" + i2);
                }*/
        }

        Vector Get_Notesort()
        {
                return note_sort;
        }

        Vector Get_Possort()
        {
                return pos_sort;
        }

        public void sort_all( Vector vec,Vector pos) {
                int num1,num2;
                MRectangle r1 = new MRectangle();
                MRectangle r2 = new MRectangle();
                //System.out.println("vec.size " + vec.size() + " " + "pos " + pos.size());
                /*for ( int m=0; m<vec.size(); m++ ) {
                        r1 = (MRectangle)pos.elementAt(m);
                        System.out.println("rold x1 " + r1.x1 + " " + "x2 " + r1.x2 + " " + "y1 " + r1.y1 + " " + "y2 " + r1.y2);
                }*/
                for ( int i=0; i<vec.size(); i++ ) {
                        r1 = (MRectangle)pos.elementAt(i);
                        for ( int j=i+1; j<vec.size(); j++ ) {
                                r2 = (MRectangle)pos.elementAt(j);
                                if (r1.x1 > r2.x1) {
                                        Integer vtmp,vtmp1;
                                        MRectangle ptmp,ptmp1;
                                        vtmp = (Integer)vec.elementAt(i);
                                        ptmp = (MRectangle)pos.elementAt(i);
                                        vtmp1 = (Integer)vec.elementAt(j);
                                        ptmp1 = (MRectangle)pos.elementAt(j);

                                        vec.removeElementAt(i);
                                        pos.removeElementAt(i);
                                        vec.insertElementAt(vtmp1, i);
                                        pos.insertElementAt(ptmp1, i);

                                        vec.removeElementAt(j);
                                        pos.removeElementAt(j);
                                        vec.insertElementAt(vtmp, j);
                                        pos.insertElementAt(ptmp, j);
                                        r1 = (MRectangle)pos.elementAt(i);
                                }
                                else if ( r1.x1 == r2.x1 && r1.y1 > r2.y1 ) {
                                        Integer vtmp,vtmp1;
                                        MRectangle ptmp,ptmp1;
                                        vtmp = (Integer)vec.elementAt(i);
                                        ptmp = (MRectangle)pos.elementAt(i);
                                        vtmp1 = (Integer)vec.elementAt(j);
                                        ptmp1 = (MRectangle)pos.elementAt(j);

                                        vec.removeElementAt(i);
                                        pos.removeElementAt(i);
                                        vec.insertElementAt(vtmp1, i);
                                        pos.insertElementAt(ptmp1, i);

                                        vec.removeElementAt(j);
                                        pos.removeElementAt(j);
                                        vec.insertElementAt(vtmp, j);
                                        pos.insertElementAt(ptmp, j);
                                        r1 = (MRectangle)pos.elementAt(i);
                                }
                        }
                }
                int t1;
                Integer t2;
                /*for ( int i=0; i<vec.size(); i++ ) {
                        r1 = (MRectangle) pos.elementAt(i);
                        t2 = (Integer)vec.elementAt(i);
                        t1 = t2.intValue();
                        System.out.print("r1 new  x1 " + r1.x1 + " " + "x2 " + r1.x2 + " " + "y1 " + r1.y1 + " " + "y2 " + r1.y2 );
                        System.out.println(" " + "note " + t1);
                }*/

                for ( int i=0; i<vec.size(); i++ ) {
                        note_sort.addElement(vec.elementAt(i));
                        pos_sort.addElement(pos.elementAt(i));
                }
        }
}