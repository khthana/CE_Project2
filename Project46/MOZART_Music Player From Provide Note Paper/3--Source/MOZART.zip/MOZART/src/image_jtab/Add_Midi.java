package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Add_Midi
{
        public int note_signature;
        public int note_gain;
        public byte note_midi[];
        public char sound;
        public int count;
        public int count_track;
        private int size;
        private int tempo1;
        private int tempo2;
        private int tempo3;

        public Add_Midi(int size)
        {
                note_signature = 4;
                note_gain = 4;
                count = 0;
                count_track = 1;        //amount all track
                this.size = size;
                tempo1 = 0x07;
                tempo2 = 0xA1;
                tempo3 = 0x20;
        }


        public void add_head() {
                this.note_midi = new byte[this.size+41];
                note_midi[count++] = 0x4D;
                note_midi[count++] = 0x54;
                note_midi[count++] = 0x68;
                note_midi[count++] = 0x64;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x06;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x01;
                note_midi[count++] = 0x00;
                note_midi[count++] = (byte)count_track;       //amount of track
                note_midi[count++] = 0x01;
                note_midi[count++] = 0x08;
                note_midi[count++] = 0x4D;
                note_midi[count++] = 0x54;
                note_midi[count++] = 0x72;
                note_midi[count++] = 0x6B;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x13;
                //note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = (byte)0xFF;
                note_midi[count++] = 0x58;
                note_midi[count++] = 0x04;
                note_midi[count++] = (byte)note_signature;         //time signature
                note_midi[count++] = (byte)(note_gain/2);         //gain
                note_midi[count++] = 0x24;
                note_midi[count++] = 0x08;
                note_midi[count++] = 0x00;
                note_midi[count++] = (byte)0xFF;
                /*note_midi[count++] = 0x59;
                note_midi[count++] = 0x02;
                note_midi[count++] = (byte)0xFF;
                note_midi[count++] = 0x00;
                note_midi[count++] = 0x00;
                note_midi[count++] = (byte)0xFF;*/
                note_midi[count++] = 0x51;
                note_midi[count++] = 0x03;
                note_midi[count++] = (byte)tempo1;  //tempo
                note_midi[count++] = (byte)tempo2;  //tempo
                note_midi[count++] = (byte)tempo3;  //tempo
                note_midi[count++] = 0x00;
                note_midi[count++] = (byte)0xFF;
                note_midi[count++] = 0x2F;
                note_midi[count++] = 0x00;
        }

        public void midi_music(int count_track,int signature,int gain,int length,Vector b,Vector tempo) {
                this.count_track = count_track+1;
                this.note_gain = gain;
                this.note_signature = signature;
                Integer i1;
                i1 = (Integer)tempo.elementAt(0);
                tempo1 = i1.intValue();
                i1 = (Integer)tempo.elementAt(1);
                tempo2 = i1.intValue();
                i1 = (Integer)tempo.elementAt(2);
                tempo3 = i1.intValue();

                this.add_head();
                int stop = b.size();
                for ( int i=0; i<stop; i++ ) {
                         Byte bb = (Byte)b.elementAt(i);
                         byte b1 = bb.byteValue();
                        note_midi[count++] = b1;
                }
        }
}