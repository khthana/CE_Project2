package image_jtab;

public class MRectangle {
    public int x1, x2;
    public int y1, y2;

    public MRectangle ()
    {
        x1 = 0;
        x2 = 0;
        y1 = 0;
        y2 = 0;
    }

    public MRectangle ( int x1, int y1, int x2, int y2 )
    {
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
    }

    public boolean Equal ( MRectangle r )
    {
        if ( x1 == r.x1 && x2 == r.x2 && y1 == r.y1 && y2 == r.y2 ) {
            return true;
        }
        return false;
    }

    public boolean isInside ( int x, int y )
    {
        if ( x >= x1 && x <= x2 && y >= y1 && y <= y2 )
            return true;
        return false;
    }

    public String toString ()
    {
        return "[" + x1 + "," + y1 + "][" + x2 + "," + y2 + "]";
    }
}
