package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Track_Gclef
{
        public int note_signature;
        public int note_gain;
        public Vector note_midi;
        public String sound;
        public int count;
        public Vector pflat;
        public Vector psharp;
        public int num_first;
        public int num_second;
        public int w, h;
        public int tmp_sound;
        public int count1;
        public int type_music;
        public int music;
        public int count_music;
        public int track_play;
        public int track_stop;
        private int sig;

        public Track_Gclef()
        {
                note_signature = 4;
                note_midi = new Vector();
                note_gain = 4;
                count = 0;
                type_music = 192;     //co
                count_music = 1;       //amount byte all midi
                track_play = 0x90;
                track_stop = 0x80;
                sig = 0;
        }

        public void array_midi( Vector vnote,Vector vpos,Vector vsound,Vector vstaff,BufferedImage im,int number,int music){
                int cc = 0x90;
                int cc1 = 0x80;
                int cc2 = 0xC0;
                this.music = music;
                pflat = new Vector();
                psharp = new Vector();
                count_byte(vnote);
                count_music = (count_music*count1) + (count_music*8);
                //System.out.println("count music " + count_music);
                //number = 0; //test
                //System.out.println("number Gclef " + number);
                track_play =cc + number;
                track_stop = cc1 + number;
                type_music = cc2 + number;
                this.add_track();
                this.add_subtrack(vnote, vpos, vsound, vstaff, im);
        }

        public void add_track() {
                note_midi.addElement(new Byte((byte)0x4D));
                note_midi.addElement(new Byte((byte)0x54));
                note_midi.addElement(new Byte((byte)0x72));
                note_midi.addElement(new Byte((byte)0x6B));
                note_midi.addElement(new Byte((byte)0x00));
                note_midi.addElement(new Byte((byte)0x00));
                note_midi.addElement(new Byte((byte)num_first));
                note_midi.addElement(new Byte((byte)num_second));
                note_midi.addElement(new Byte((byte)0x00));
                note_midi.addElement(new Byte((byte)type_music));
                note_midi.addElement(new Byte((byte)this.music));
                note_midi.addElement(new Byte((byte)0x00));
        }

        public void add_subtrack (Vector vnote,Vector vpos,Vector vsound,Vector vstaff,BufferedImage im) {
                int center=0;
                int p[];
                BufferedImage im1=null;
                int tmp;
                Integer t1;
                int cc=0;
                int b;
                int x1=0;
                int y1=0,y2=0;
                for (int i = 0; i < vnote.size(); i++) {
                        int line=0;
                        MRectangle rec = (MRectangle) vpos.elementAt(i);
                        t1 = (Integer) vnote.elementAt(i);
                        tmp = t1.intValue();
                        //System.out.println("tmp " + tmp);
                        w = (rec.x2 - rec.x1) + 2;
                        h = (rec.y2 - rec.y1) + 2;
                                //System.out.println("rec midi x1 " + rec.x1 + " " + "x2 " + rec.x2 + " " + "y1 " + rec.y1 + " " + "y2 " + rec.y2);

                                if (rec != null && w != 0) {
                                        p = new int[w * h];
                                        im.getRGB(rec.x1 - 1, rec.y1 - 1, w, h, p, 0, w);
                                        im1 = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
                                        im1.setRGB(0, 0, w, h, p, 0, w);
                                }

                                if ( tmp == 20 || tmp == 21 || tmp == 22 || tmp == 23 ){
                                        if ( sig == 0 ) {
                                                if ( tmp == 20 ) {
                                                        note_signature = 2;
                                                }
                                                else if ( tmp == 21 ) {
                                                        note_signature = 3;
                                                }
                                                else if ( tmp == 22 ) {
                                                        note_signature = 4;
                                                }
                                                else if ( tmp == 23 ) {
                                                        note_signature =6;
                                                }
                                                sig=1;
                                        }
                                        else if ( sig== 1 ) {
                                                 if ( tmp == 20 ) {
                                                         note_gain = 2;
                                                 }
                                                 else if ( tmp == 21 ) {
                                                         note_gain = 3;
                                                 }
                                                 else if ( tmp == 22 ) {
                                                         note_gain = 4;
                                                 }
                                                 else if ( tmp == 23 ) {
                                                         note_gain =6;
                                                 }
                                                 sig = 2;
                                         }
                                }
                                else if (tmp >= 2 && tmp <= 5) {
                                        for (int x = 0; x < w; x++) {
                                                for (int y = 0; y < h; y++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                cc++;
                                                        }
                                                }
                                                if (cc >= (60 * h) / 100) {
                                                        x1 = x;
                                                }
                                                cc = 0;
                                        }
                                        int yy = (40*h)/100;
                                        for (int y = 0; y < yy; y++) {
                                                for (int x = x1 + 3; x < w; x++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y1 = y;
                                                                y = h;
                                                                break;
                                                        }
                                                }
                                        }
                                        for (int y = yy; y > 0; y--) {
                                                for (int x = x1 + 3; x < w; x++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y2 = y;
                                                                y =  0;
                                                                break;
                                                        }
                                                }
                                        }
                                        center = (y2 - y1)/2 + rec.y1;
                                } else if (tmp == 6) {
                                        for (int x = 0; x < w; x++) {
                                                for (int y = 0; y < h; y++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                cc++;
                                                        }
                                                }
                                                if (cc >= (60 * h) / 100) {
                                                        x1 = x;
                                                }
                                                cc = 0;
                                        }
                                        int yy = (60*h)/100;
                                        for (int y = yy; y < h; y++) {
                                                for (int x = x1 + 2; x < w; x++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y1 = y;
                                                                y = h;
                                                                break;
                                                        }
                                                }
                                        }
                                        for (int y = h - 1; y > yy; y--) {
                                                for (int x = x1 + 2; x < w; x++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y2 = y;
                                                                y = 0;
                                                                break;
                                                        }
                                                }
                                        }
                                        center = rec.y2 - (y2 - y1)/2;
                                }
                                else if (tmp >= 7 && tmp <= 10) {
                                        for (int x = w-1; x >0; x--) {
                                                for (int y = 0; y < h; y++) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                cc++;
                                                        }
                                                }
                                                if (cc >= (60 * h) / 100) {
                                                        x1 = x;
                                                }
                                                cc = 0;
                                        }
                                        int yy = (60*h)/100;
                                        for (int y = yy; y < h; y++) {
                                                for (int x = x1-2; x >0; x--) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y1 = y;
                                                                y = h;
                                                                break;
                                                        }
                                                }
                                        }
                                        for (int y = h - 1; y > yy; y--) {
                                                for (int x = x1-2; x >0; x--) {
                                                        b = im1.getRGB(x, y) & 0xFF;
                                                        if (b == 0x00) {
                                                                y2 = y;
                                                                y=0;
                                                                break;
                                                        }
                                                }
                                        }
                                        center = rec.y2 - (y2 - y1)/2;
                                }
                                else if ( tmp == 19 ) {
                                        center = rec.y2;
                                }
                                else if ( tmp == 15 ) {
                                        center = rec.y1;
                                }
                                else if( tmp == 1 ) {
                                        center = rec.y1 + ((rec.y2 - rec.y1)+1)/2;
                                }
                                else {
                                        center = 0;
                                }
                                //System.out.println("center " + center);

                                for ( int m=0; m<vstaff.size(); m++ ) {
                                        Integer tmp1 = (Integer)vstaff.elementAt(m);
                                        Character c;
                                        line = tmp1.intValue();

                                        if ( tmp >= 1 && tmp <= 5 ) {
                                                if ( center == line || (center-1) == line || (center+1) == line ) {
                                                         sound = (String)vsound.elementAt(m);
                                                        break;
                                                }
                                        }
                                        else if ( tmp >= 7 && tmp <=10 ) {
                                                if ( center == line || (center-1) == line || (center+1) == line ) {
                                                        sound = (String)vsound.elementAt(m);
                                                        break;
                                                }
                                        }
                                        else if ( tmp == 6 ) {
                                                if ( center == line || (center-1) == line || (center+1) == line ) {
                                                        pflat.addElement(new Integer(line));
                                                        break;
                                                }
                                        }
                                        else if ( tmp == 12 ) {
                                                if ( center == line || (center-1) == line || (center+1) == line ) {
                                                        psharp.addElement(new Integer(line));
                                                        break;
                                                }
                                        }
                                        else if ( tmp == 13 ) {
                                                if ( center == line || (center-1) == line || (center+1) == line ) {
                                                        if ( psharp != null ) {
                                                                for (int n = 0; n < psharp.size(); n++) {
                                                                        Integer ii = (Integer) psharp.elementAt(n);
                                                                        int i1= ii.intValue();
                                                                        if ( i1 == line ) {
                                                                                psharp.removeElementAt(n);
                                                                        }
                                                                }
                                                        }
                                                        if ( pflat != null ) {
                                                                for (int n = 0; n < pflat.size(); n++) {
                                                                        Integer ii = (Integer) pflat.elementAt(n);
                                                                        int i1= ii.intValue();
                                                                        if ( i1 == line ) {
                                                                                pflat.removeElementAt(n);
                                                                        }
                                                                }
                                                        }
                                                        break;
                                                }
                                        }
                                }
                                int tmp1=0;
                                switch ( tmp ) {
                                case 1:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        this.find_sound();
                                        this.find_sf(line);
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x60));
                                        note_midi.addElement(new Byte((byte)0x8C));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 2: case 7:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        this.find_sound();
                                        this.find_sf(line);          //sharp and flat
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x60));
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)0x84));
                                                note_midi.addElement(new Byte((byte)0x40));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)0x83));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 3: case 8:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        this.find_sound();
                                        this.find_sf(line);
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x60));
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)0x89));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)0x86));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 4: case 9:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        this.find_sound();
                                        this.find_sf(line);
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x60));
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)0x82));
                                                note_midi.addElement(new Byte((byte)0x20));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)0x81));
                                                note_midi.addElement(new Byte((byte)0x40));
                                        }
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 5: case 10:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        this.find_sound();
                                        this.find_sf(line);
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x60));
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)0x81));
                                                note_midi.addElement(new Byte((byte)0x10));
                                        }
                                        else {
                                                //note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x60));
                                        }
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)tmp_sound));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 15:
                                        note_midi.addElement(new Byte((byte)track_play));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x8C));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)track_stop));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        note_midi.addElement(new Byte((byte)0x00));
                                        break;
                                case 19:
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x89));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x86));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        break;
                                case 11:
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x84));
                                                note_midi.addElement(new Byte((byte)0x40));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x83));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        break;
                                case 17:
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x82));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x81));
                                                note_midi.addElement(new Byte((byte)0x40));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        break;
                                case 18:
                                        if ( (i+1) < vnote.size() ) {
                                                t1 = (Integer) vnote.elementAt(i + 1);
                                                tmp1 = t1.intValue();
                                        }
                                        if ( tmp1 == 16 ) {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x81));
                                                note_midi.addElement(new Byte((byte)0x10));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        else {
                                                note_midi.addElement(new Byte((byte)track_play));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                //note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x60));
                                                note_midi.addElement(new Byte((byte)track_stop));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                                note_midi.addElement(new Byte((byte)0x00));
                                        }
                                        break;
                                }
                        }
                        //note_midi.addElement(new Byte((byte)0x00));
                        note_midi.addElement(new Byte((byte)0xFF));
                        note_midi.addElement(new Byte((byte)0x2F));
                        note_midi.addElement(new Byte((byte)0x00));
        }

        public void find_sound() {
                if ( sound == null )
                        return ;
                         if( sound.equals("bh2")) {
                                 tmp_sound = 95;
                         }
                         else if( sound.equals("ah2")) {
                                 tmp_sound = 93;
                         }
                         else if( sound.equals("gh2")) {
                                 tmp_sound = 91;
                         }
                         else if( sound.equals("fh2")) {
                                 tmp_sound = 89;
                         }
                         else if( sound.equals("eh2")) {
                                 tmp_sound = 88;
                         }
                         else if( sound.equals("dh2")) {
                                 tmp_sound = 86;
                         }
                         else if( sound.equals("ch2")) {
                                 tmp_sound = 84;
                         }
                         else if( sound.equals("bh1")) {
                                 tmp_sound = 83;
                         }
                         else if( sound.equals("ah1")) {
                                 tmp_sound = 81;
                         }
                         else if( sound.equals("gh1")) {
                                 tmp_sound = 79;
                         }
                         else if( sound.equals("fh1")) {
                                 tmp_sound = 77;
                         }
                         else if( sound.equals("eh1")) {
                                 tmp_sound = 76;
                         }
                         else if( sound.equals("dh1")) {
                                 tmp_sound = 74;
                         }
                         else if( sound.equals("ch1")) {
                                 tmp_sound = 72;
                         }
                         else if( sound.equals("bm")) {
                                 tmp_sound = 71;
                         }
                         else if( sound.equals("am")) {
                                 tmp_sound = 69;
                         }
                         else if( sound.equals("gm")) {
                                 tmp_sound = 67;
                         }
                         else if( sound.equals("fm")) {
                                 tmp_sound = 65;
                         }
                         else if( sound.equals("em")) {
                                 tmp_sound = 64;
                         }
                         else if( sound.equals("dm")) {
                                tmp_sound = 62;
                         }
                         else if( sound.equals("cm")) {
                                 tmp_sound = 60;
                         }
                         else if( sound.equals("bl1")) {
                                 tmp_sound = 59;
                         }
                         else if( sound.equals("al1")) {
                                 tmp_sound = 57;
                         }
                         else if( sound.equals("gl1")) {
                                 tmp_sound = 55;
                         }
                         else if( sound.equals("fl1")) {
                                 tmp_sound = 53;
                         }
                         else if( sound.equals("el1")) {
                                 tmp_sound = 52;
                         }
                         else if( sound.equals("dl1")) {
                                 tmp_sound = 50;
                         }
                         else if( sound.equals("cl1")) {
                                 tmp_sound = 48;
                         }
                         else {
                                 System.out.println("no sound");
                         }
                 }

         public void find_sf(int line1) {
                 if (psharp != null && this.tmp_sound != 64  && this.tmp_sound != 52 && this.tmp_sound != 76 && this.tmp_sound != 88) {
                         for (int n = 0; n < psharp.size(); n++) {
                                 Integer ii = (Integer) psharp.elementAt(n);
                                 int i1 = ii.intValue();
                                 if (i1 == line1) {
                                         tmp_sound = tmp_sound + 1;
                                 }
                         }
                 }
                 if (pflat != null && this.tmp_sound != 65 && this.tmp_sound != 53 && this.tmp_sound != 77 && this.tmp_sound != 89) {
                         for (int n = 0; n < pflat.size(); n++) {
                                 Integer ii = (Integer) pflat.elementAt(n);
                                 int i1 = ii.intValue();
                                 if (i1 == line1) {
                                         tmp_sound = tmp_sound - 1;
                                 }
                         }
                 }
                 //System.out.println("tmp sound " + sound + " " + tmp_sound);
         }

         public void count_byte(Vector vec) {
                 int count_all=0;
                 String num_first1;
                 String num_second1;
                 for ( int m=0; m<vec.size(); m++ ) {
                         Integer v = (Integer)vec.elementAt(m);
                         int v1 = v.intValue();
                         if ( v1 >= 1 && v1 <= 4 ) {
                                 count_all = count_all + 9;
                         }
                         else if ( v1 == 5 || v1 == 10 ) {
                                 count_all = count_all + 8;
                         }
                         else if ( v1 >=7 && v1 <= 9 ) {
                                 count_all = count_all + 9;
                         }
                         else if ( v1  == 15 || v1 == 19 || v1 == 17 || v1 == 18 || v1 == 11) {
                                 count_all = count_all + 9;
                         }
                 }
                 count_all = count_all + 7;
                 count1 = count_all;
                 //System.out.println("count_all " + count_all);
                 int ans=0,borrow=0;
                 String tmp;
                 ans = count_all / 16;
                 borrow = count_all % 16;
                 switch(borrow) {
                 case 10:
                         tmp = "A";
                         break;
                 case 11:
                         tmp = "B";
                         break;
                 case 12:
                         tmp = "C";
                         break;
                 case 13:
                         tmp = "D";
                         break;
                 case 14:
                         tmp = "E";
                         break;
                 case 15:
                         tmp = "F";
                         break;
                 default:
                         tmp = "" + borrow;
                         break;
                 }
                 num_second1 = tmp;
                 count_all = ans;
                 ans = count_all / 16;
                 borrow = count_all % 16;
                 switch(borrow) {
                 case 10:
                         tmp = "A";
                         break;
                 case 11:
                         tmp = "B";
                         break;
                 case 12:
                         tmp = "C";
                         break;
                 case 13:
                         tmp = "D";
                         break;
                 case 14:
                         tmp = "E";
                         break;
                 case 15:
                         tmp = "F";
                         break;
                 default:
                         tmp = ""  + borrow;
                         break;
                 }
                 num_second1 = num_second1 + tmp;
                 count_all = ans;
                 ans = count_all / 16;
                 borrow = count_all % 16;
                 switch(borrow) {
                 case 10:
                         tmp = "A";
                         break;
                 case 11:
                         tmp = "B";
                         break;
                 case 12:
                         tmp = "C";
                         break;
                 case 13:
                         tmp = "D";
                         break;
                 case 14:
                         tmp = "E";
                         break;
                 case 15:
                         tmp = "F";
                         break;
                 default:
                         tmp = "" + borrow;
                         break;
                 }
                 num_first1 = tmp;
                 count_all = ans;
                 ans = count_all / 16;
                 borrow = count_all % 16;
                 switch(borrow) {
                 case 10:
                         tmp = "A";
                         break;
                 case 11:
                         tmp = "B";
                         break;
                 case 12:
                         tmp = "C";
                         break;
                 case 13:
                         tmp = "D";
                         break;
                 case 14:
                         tmp = "E";
                         break;
                 case 15:
                         tmp = "F";
                         break;
                 default:
                         tmp = "" + borrow;
                         break;
                 }
                 num_first1 = num_first1 + tmp;

                 int tmp1=0;
                 for ( int m=0; m<2; m++ ) {
                         switch (num_first1.charAt(m)) {
                                 case 'A':
                                         tmp1 = 10;
                                         break;
                                 case 'B':
                                         tmp1 = 11;
                                         break;
                                 case 'C':
                                         tmp1 = 12;
                                         break;
                                 case 'D':
                                         tmp1 = 13;
                                         break;
                                 case 'E':
                                         tmp1 = 14;
                                         break;
                                 case 'F':
                                         tmp1 = 15;
                                         break;
                                 default:
                                         tmp1 = num_first1.charAt(m) - 48;
                                         break;
                         }
                         if ( m == 0 ) {
                                 num_first = tmp1;
                                // System.out.println("number " + tmp1);
                         }
                         else if ( m == 1 ) {
                                 num_first = (tmp1*16) + num_first;
                                 //System.out.println("number " + tmp1);
                         }
                 }

                 for ( int m=0; m<2; m++ ) {
                         switch (num_second1.charAt(m)) {
                                 case 'A':
                                         tmp1 = 10;
                                         break;
                                 case 'B':
                                         tmp1 = 11;
                                         break;
                                 case 'C':
                                         tmp1 = 12;
                                         break;
                                 case 'D':
                                         tmp1 = 13;
                                         break;
                                 case 'E':
                                         tmp1 = 14;
                                         break;
                                 case 'F':
                                         tmp1 = 15;
                                         break;
                                 default:
                                         tmp1 = num_second1.charAt(m) - 48;
                                         break;
                         }
                         if ( m == 0 ) {
                                 num_second = tmp1;
                                 //System.out.println("number " + tmp1);
                         }
                         else if ( m == 1 ) {
                                 num_second = (tmp1*16) + num_second;
                                // System.out.println("number " + tmp1);
                         }
                 }
                 /*System.out.println("numf " + num_first1.charAt(1));
                 System.out.println("numf " + num_first1.charAt(0));
                 System.out.println("numf " + num_second1.charAt(1));
                 System.out.println("numf " + num_second1.charAt(0));
                 System.out.println("num " + num_first1 + num_second1);
                 System.out.println("num1 " + num_first + ":"  + num_second);*/
         }

}