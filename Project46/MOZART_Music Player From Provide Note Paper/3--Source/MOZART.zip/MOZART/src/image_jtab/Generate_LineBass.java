package image_jtab;

import java.util.*;
import java.lang.*;
import java.awt.image.*;
import java.awt.*;

public class Generate_LineBass
{
        public Vector legger_line;
        public Vector staff_line;
        public Vector sound_line;
        public int amount_legger;
        public String state;
        public String state_tmp;
        public int count_sound;
        public int start;
        public int stop;
        public Generate_LineBass()

        {
                amount_legger = 7;       //line out of bound line stuff
                count_sound = 0;
                start = 0;
                stop = 0;
        }

        public void staff_pos( Vector vec ) {
                staff_line = new Vector();
                sound_line = new Vector();
                int size = vec.size();
                int count = size/5;
                int y1=0,y2=0;
                int c1=0,c2=0;
                int width_line;
                Integer tmp1 = (Integer)vec.elementAt(0);
                y1 = tmp1.intValue();
                Integer tmp2 = (Integer)vec.elementAt(1);
                y2 = tmp2.intValue();
                width_line = ((y2-y1)+1)/2;
                for ( int i=0; i<count; i++ ) {
                        c1 = i*5;
                        c2 = c1+4;
                        Integer ytmp1 = (Integer)vec.elementAt(c1);
                        y1 = ytmp1.intValue();
                        Integer ytmp2 = (Integer)vec.elementAt(c2);
                        y2 = ytmp2.intValue();
                        int y_st;
                        y_st = y1;
                        for ( int m=0; m<this.amount_legger; m++ ) {     //add legger line top
                                y_st = y_st - width_line;
                                staff_line.addElement(new Integer(y_st));
                        }
                        for ( int m=0; m<staff_line.size(); m++ ) {          //sort line
                                int n1=0,n2=0;
                                Integer r1 = (Integer)staff_line.elementAt(m);
                                n1 = r1.intValue();
                                for ( int j=m+1; j<staff_line.size(); j++ ) {
                                        Integer r2 = (Integer)staff_line.elementAt(j);
                                        n2 = r2.intValue();
                                        if ( n1 > n2 ) {
                                                Integer vtmp,vtmp1;
                                                vtmp = (Integer)staff_line.elementAt(m);
                                                vtmp1 = (Integer)staff_line.elementAt(j);

                                                staff_line.removeElementAt(m);
                                                staff_line.insertElementAt(vtmp1,m);

                                                staff_line.removeElementAt(j);
                                                staff_line.insertElementAt(vtmp, j);
                                                r1 = (Integer)staff_line.elementAt(m);
                                        }
                                }
                        }
                        //System.out.println("c1 " + c1 + " " + "c2 " + c2);
                        for ( int m=c1; m<=c2; m++ ) {                           //add line
                                tmp1 = (Integer)vec.elementAt(m);
                                int yy = tmp1.intValue();
                                staff_line.addElement(new Integer(yy));
                                if ( m != c2 ) {
                                        yy = yy + width_line;
                                        staff_line.addElement(new Integer(yy));
                                }
                        }
                        int y_end;
                        y_end = y2;
                        for ( int m=0; m<this.amount_legger; m++ ) {     //add legger line lower
                                y_end = y_end + width_line;
                                staff_line.addElement(new Integer(y_end));
                        }

                        //add sound
                        int count1 = this.amount_legger;
                        state_tmp = "bl1";
                        //System.out.println("state begin " + state_tmp);
                        this.add_up(count1);
                        state = state_tmp;
                        stop = 9 + (2* this.amount_legger);
                       // System.out.println("start " + start + " " + "stop " + stop);
                        this.add_down();
                }
                for ( int i=0; i<staff_line.size(); i++ ) {
                        Integer i1 = (Integer)staff_line.elementAt(i);
                        int i2 = i1.intValue();
                        //System.out.print("staff_line " + i2);
                        String s = (String) sound_line.elementAt(i);
                       // System.out.println("sound_line " + s);
                }
        }

        public void add_down () {
                //System.out.println("state1 " + state);
               for ( int m=0; m< stop; m++ ) {
                       if ( state.equals("ch1")) {
                               state = "bm";
                               sound_line.addElement(state);
                       }
                       else if ( state.equals("bm")) {
                               state = "am";
                               sound_line.addElement(state);
                       }
                       else if ( state.equals("am")) {
                                 state = "gm";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("gm")) {
                                 state = "fm";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("fm")) {
                                 state = "em";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("em")) {
                                 state = "dm";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("dm")) {
                                 state = "cm";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("cm")) {
                                 state = "bl1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("bl1")) {
                               state = "al1";
                               sound_line.addElement(state);
                       }
                       else if ( state.equals("al1")) {
                                 state = "gl1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("gl1")) {
                                 state = "fl1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("fl1")) {
                                 state = "el1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("el1")) {
                                 state = "dl1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("dl1")) {
                                 state = "cl1";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("cl1")) {
                                 state = "bl2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("bl2")) {
                               state = "al2";
                               sound_line.addElement(state);
                       }
                       else if ( state.equals("al2")) {
                                 state = "gl2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("gl2")) {
                                 state = "fl2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("fl2")) {
                                 state = "el2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("el2")) {
                                 state = "dl2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("dl2")) {
                                 state = "cl2";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("cl2")) {
                                 state = "bl3";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("bl3")) {
                               state = "al3";
                               sound_line.addElement(state);
                       }
                       else if ( state.equals("al3")) {
                                 state = "gl3";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("gl3")) {
                                 state = "fl3";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("fl3")) {
                                 state = "el3";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("el3")) {
                                 state = "dl3";
                                 sound_line.addElement(state);
                       }
                       else if ( state.equals("dl3")) {
                                 state = "cl3";
                                 sound_line.addElement(state);
                       }
               }
               //System.out.println("state " + state);
       }

        public void add_up(int stop) {
                for ( int m=0; m< stop; m++ ) {
                        if ( state_tmp.equals("bl1")) {
                                state_tmp = "cm";
                        }
                        else if ( state_tmp.equals("cm")) {
                                state_tmp = "dm";
                        }
                        else if ( state_tmp.equals("dm")) {
                                  state_tmp = "em";
                        }
                        else if ( state_tmp.equals("em")) {
                                  state_tmp = "fm";
                        }
                        else if ( state_tmp.equals("fm")) {
                                  state_tmp = "gm";
                        }
                        else if ( state_tmp.equals("gm")) {
                                  state_tmp = "am";
                        }
                        else if ( state_tmp.equals("am")) {
                                  state_tmp = "bm";
                        }
                        else if ( state_tmp.equals("bm")) {
                                  state_tmp = "ch1";
                        }
                }
               // System.out.println("state_tmp " + state_tmp);
        }
        public Vector get_legger() {
                return legger_line;
        }

        public Vector get_staff() {
                return staff_line;
        }

        public Vector get_sound() {
                return sound_line;
        }
}