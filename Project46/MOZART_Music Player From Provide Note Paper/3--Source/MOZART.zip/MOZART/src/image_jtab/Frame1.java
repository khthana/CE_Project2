package image_jtab;

import java.text.DecimalFormat;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import osbaldeston.image.BMP;
import java.awt.image.*;
import java.util.*;
import java.awt.color.*;
import java.io.*;
import java.awt.geom.*;
import com.mullassery.imaging.java2d.*;
import javax.sound.midi.*;
import java.applet.*;
import java.net.*;

public class Frame1
        extends JFrame {
        AudioClip sound1;
        Sequence currentSound;
        Sequencer player;
        File file;
        JPanel contentPane;
        JButton jimage = new JButton();
        TitledBorder titledBorder1;
        BMP bmp;
        Image image;
        ImageFilter i1;
        Image image1[] = new Image[10];
        String musical[] = { "Acoustic Grand Piano","Electric Grand Piano","Acoustic Guitar","Acoustic Bass","Electric Bass",
                                      "Violin","Trumpet","Flute","Music Box" };
        ImageIcon i, im;
        String tempo[] = { "Tempo 30 Bpm","Tempo 60 Bpm","Tempo 90 Bpm","Tempo 120 Bpm","Tempo 150 Bpm","Tempo 180 Bpm",
                                    "Tempo 210 Bpm","Tempo 240 Bpm" };
        int num = 1;
        int num_tmp;
        int num_d;
        int line_capacity=0;
        JLabel l1 = null;
        public Position_y py = new Position_y();
        BufferedImage bufImage = null; //Construct the frame
        BufferedImage buftmp = null;
        Detect_Note detectNote = new Detect_Note();
        Manage_Image mi;
        JPanel jPanel1 = new JPanel();
        DisplayImage tp = new DisplayImage();
        int w; //for keep width image
        int h; //for keep height image
        int count_image = 0;
        int result_note;
        int width_line = 0;
        double angle=0;
        Vector vec;
        Vector note1;
        Vector posnote1;
        private int line_count[];
        JPanel jPanel2 = new JPanel();
        JPanel jPanel3 = new JPanel();
        JLabel jl1 = new JLabel();
        JLabel jLabel1 = new JLabel();
        JLabel jLabel8 = new JLabel();
        JButton jsave = new JButton();
        JLabel jLabel9 = new JLabel();
        JPanel jPanel5 = new JPanel();
        JTextField jtext1 = new JTextField();
        JButton jopen_file = new JButton();
        JButton jplay = new JButton();
        JButton jstop = new JButton();
        JButton Recognition = new JButton();
        ButtonGroup bg1 = new ButtonGroup();
        JPanel jPanel6 = new JPanel();
        JScrollPane jScrollPane1 = new JScrollPane();
        JTextArea jTextArea1 = new JTextArea();
        JButton jbpre = new JButton();
        JComboBox combo1 = new JComboBox(musical);
        JLabel jLabel2 = new JLabel();
        JLabel jLabel3 = new JLabel();
        JLabel jLabel4 = new JLabel();
        JComboBox combo2 = new JComboBox(tempo);
        JLabel jLabel5 = new JLabel();

        public Frame1() {
                enableEvents(AWTEvent.WINDOW_EVENT_MASK);
                try {
                        jbInit();
                }
                catch (Exception e) {
                        e.printStackTrace();
                }
        }

        //Component initialization
        private void jbInit() throws Exception {
                contentPane = (JPanel)this.getContentPane();
                titledBorder1 = new TitledBorder("");
                jimage.setBounds(new Rectangle(147, 25, 104, 28));
                jimage.setText("Open Image");
                jimage.addActionListener(new Frame1_jimage_actionAdapter(this));
                contentPane.setLayout(null);
                this.setSize(new Dimension(1024, 768));
                this.setTitle("Music Player From Provide Note Paper: MOZART");
                contentPane.setDebugGraphicsOptions(0);
                jPanel1.setBorder(BorderFactory.createEtchedBorder());
                jPanel1.setBounds(new Rectangle(5, 5, 737, 698));
                jPanel1.setLayout(null);
                tp.setBorder(BorderFactory.createLoweredBevelBorder());
                tp.setBounds(new Rectangle(5, 4, 726, 689));
                jPanel2.setBorder(BorderFactory.createEtchedBorder());
                jPanel2.setBounds(new Rectangle(746, 159, 263, 96));
                jPanel2.setLayout(null);
                jPanel3.setBorder(BorderFactory.createEtchedBorder());
                jPanel3.setBounds(new Rectangle(746, 6, 263, 150));
                jPanel3.setLayout(null);
                jl1.setText("Process Function");
                jl1.setBounds(new Rectangle(105, 0, 95, 26));
                jLabel1.setText("Choose Image for Open");
                jLabel1.setBounds(new Rectangle(17, 20, 122, 30));
                jLabel8.setText("Musical instruments");
                jLabel8.setBounds(new Rectangle(85, 4, 102, 29));
                jsave.setBounds(new Rectangle(147, 115, 104, 28));
                jsave.setText("Save to Midi");
                jsave.addActionListener(new Frame1_jsave_actionAdapter(this));
                jLabel9.setText("Save to Midi file");
                jLabel9.setBounds(new Rectangle(17, 113, 82, 26));
                jPanel5.setBorder(BorderFactory.createEtchedBorder());
                jPanel5.setBounds(new Rectangle(747, 637, 263, 66));
                jPanel5.setLayout(null);
                jtext1.setDoubleBuffered(false);
                jtext1.setText("");
                jtext1.setBounds(new Rectangle(3, 5, 179, 27));
                jopen_file.setBounds(new Rectangle(187, 5, 68, 27));
                jopen_file.setText("Open");
                jopen_file.addActionListener(new Frame1_jopen_file_actionAdapter(this));
                jplay.setBounds(new Rectangle(18, 38, 69, 23));
                jplay.setText("Play");
                jplay.addActionListener(new Frame1_jplay_actionAdapter(this));
                jstop.setBounds(new Rectangle(106, 38, 69, 23));
                jstop.setText("Stop");
                jstop.addActionListener(new Frame1_jstop_actionAdapter(this));
                Recognition.setBounds(new Rectangle(147, 85, 104, 28));
                Recognition.setMaximumSize(new Dimension(91, 25));
                Recognition.setMinimumSize(new Dimension(91, 25));
                Recognition.setPreferredSize(new Dimension(91, 25));
                Recognition.setActionCommand("Recognition");
                Recognition.setText("Recognition");
                Recognition.addActionListener(new Frame1_Recognition_actionAdapter(this));
                jPanel6.setBorder(BorderFactory.createEtchedBorder());
                jPanel6.setDebugGraphicsOptions(0);
                jPanel6.setBounds(new Rectangle(746, 257, 265, 377));
                jPanel6.setLayout(null);
                jScrollPane1.setBounds(new Rectangle(4, 4, 256, 368));
                jTextArea1.setFont(new java.awt.Font("Serif", 0, 14));
                jbpre.setBounds(new Rectangle(147, 55, 104, 28));
                jbpre.setText("Preprocessing");
                jbpre.addActionListener(new Frame1_jbpre_actionAdapter(this));
                combo1.setBounds(new Rectangle(97, 30, 154, 27));
                combo1.setEnabled(true);
                jLabel2.setText("Choose Musical");
                jLabel2.setBounds(new Rectangle(10, 30, 92, 28));
                jLabel3.setText("Preprocessing Image");
                jLabel3.setBounds(new Rectangle(17, 54, 116, 25));
                jLabel4.setText("Recognition Image");
                jLabel4.setBounds(new Rectangle(17, 86, 101, 24));
                combo2.setBounds(new Rectangle(97, 60, 154, 27));
                combo2.setEnabled(true);
                combo2.setSelectedIndex(3);
                jLabel5.setText("Set Tempo");
                jLabel5.setBounds(new Rectangle(10, 61, 67, 25));
                contentPane.add(jPanel1, null);
                jPanel1.add(tp, null);
                jPanel2.add(jLabel8, null);
                jPanel2.add(combo1, null);
                jPanel2.add(jLabel2, null);
                jPanel2.add(combo2, null);
                jPanel2.add(jLabel5, null);
                contentPane.add(jPanel5, null);
                contentPane.add(jPanel6, null);
                jPanel6.add(jScrollPane1, null);
                jScrollPane1.getViewport().add(jTextArea1, null);
                contentPane.add(jPanel3, null);
                jPanel3.add(jl1, null);
                jPanel3.add(jimage, null);
                jPanel3.add(jLabel1, null);
                jPanel3.add(jbpre, null);
                jPanel3.add(Recognition, null);
                jPanel3.add(jsave, null);
                jPanel3.add(jLabel3, null);
                jPanel3.add(jLabel9, null);
                jPanel3.add(jLabel4, null);
                jPanel5.add(jtext1, null);
                jPanel5.add(jopen_file, null);
                jPanel5.add(jstop, null);
                jPanel5.add(jplay, null);
                contentPane.add(jPanel2, null);
                jTextArea1.setEditable(false);
                i = new ImageIcon("girl2.gif");
        }

        //Overridden so we can exit when window is closed
        protected void processWindowEvent(WindowEvent e) {
                super.processWindowEvent(e);
                if (e.getID() == WindowEvent.WINDOW_CLOSING) {
                        System.exit(0);
                }
        }

        void jimage_actionPerformed(ActionEvent e) {
                BufferedImage buf;
                FileDialog d = new FileDialog(new Frame(), "Insert Image",
                                              FileDialog.LOAD);
                d.setDirectory(",");
                d.setVisible(true);
                String str = d.getDirectory() + d.getFile();
                String filebmp = d.getFile();

                if ( filebmp != null ) {
                        int n_end = filebmp.length();
                        int n_start = n_end - 3;

                        filebmp = filebmp.substring(n_start, n_end);

                        boolean mac = filebmp.equalsIgnoreCase("bmp");
                        if (mac == true) {
                                bmp = new BMP(new java.io.File(str));
                                image = bmp.getImage();
                                if (image == null) {
                                //System.out.println("no file bmp");
                                } else {
                                //System.out.println("have file bmp");
                                }
                        } else {
                                image = Toolkit.getDefaultToolkit().getImage(str);
                        }
                        MediaTracker tt = new MediaTracker(this);
                        tt.addImage(image, 0);
                        try {
                                tt.waitForID(0);
                        } catch (InterruptedException e1) {}

                        w = image.getWidth(null);
                        h = image.getHeight(null);
                        String file_show = "File image:";
                        file_show = file_show.concat(" " + str + '\n');
                        file_show = file_show.concat("Image width " + w + '\n');
                        file_show = file_show.concat("Image height " + h + '\n');
                        if (w < 1500 || h < 1500) {
                                jTextArea1.setText(file_show);
                                buf = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
                                Graphics2D g2 = buf.createGraphics();
                                g2.drawImage(image, 0, 0, null);

                                Java2DImaging jm = new Java2DImaging();
                                bufImage = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
                                g2 = bufImage.createGraphics();
                                g2.drawImage(image, 0, 0, null);

                                if (w >= 1400 || h >= 1400) {
                                        buf = jm.scale(buf, (float) 0.45);
                                }
                                else if (w >= 1200 && h >= 1200) {
                                        buf = jm.scale(buf, (float) 0.50);
                                }
                                else if (w >= 900 && h >= 900) {
                                        buf = jm.scale(buf, (float) 0.65);
                                }
                                else if (w >= 800 && h >= 800) {
                                        buf = jm.scale(buf, (float) 0.70);
                                }
                                else if (w >= 750 && h >= 650) {
                                        buf = jm.scale(buf, (float) 0.80);
                                }
                                else if (w >= 750 || h >= 650) {
                                        buf = jm.scale(buf, (float) 0.80);
                                }
                                im = new ImageIcon(buf);
                                l1 = new JLabel(im);
                                tp.addTab("Image", l1, i);
                                tp.addBufferedImage(bufImage);
                        }
                        else {
                                JOptionPane.showMessageDialog(null,"File is big size ","Message Dialog",JOptionPane.WARNING_MESSAGE);
                        }
                }
        }

  void jsave_actionPerformed(ActionEvent e) {

          int length=0;
          int size=0;
          Vector v,v1;
          for ( int i=0; i<tp.getTabCount(); i++ ) {
                  v = (Vector)tp.tab_byte.elementAt(i);
                  size = size + v.size();
          }
          Add_Midi am = new Add_Midi(size);
          v1 = new Vector();
          Vector tempo = new Vector();

          if ( combo2.getSelectedIndex() == 0 ) {
                  tempo.addElement(new Integer(0x1E));
                  tempo.addElement(new Integer(0x84));
                  tempo.addElement(new Integer(0x80));
          }
          else if ( combo2.getSelectedIndex() == 1 ) {
                  tempo.addElement(new Integer(0x0F));
                  tempo.addElement(new Integer(0x42));
                  tempo.addElement(new Integer(0x40));
          }
          else if ( combo2.getSelectedIndex() == 2 ) {
                  tempo.addElement(new Integer(0x0A));
                  tempo.addElement(new Integer(0x2C));
                  tempo.addElement(new Integer(0x2A));
          }
          else if ( combo2.getSelectedIndex() == 3 ) {
                  tempo.addElement(new Integer(0x07));
                  tempo.addElement(new Integer(0xA1));
                  tempo.addElement(new Integer(0x20));
          }
          else if ( combo2.getSelectedIndex() == 4 ) {
                  tempo.addElement(new Integer(0x06));
                  tempo.addElement(new Integer(0x1A));
                  tempo.addElement(new Integer(0x86));
          }
          else if ( combo2.getSelectedIndex() == 5 ) {
                  tempo.addElement(new Integer(0x05));
                  tempo.addElement(new Integer(0x16));
                  tempo.addElement(new Integer(0x15));
          }
          else if ( combo2.getSelectedIndex() == 6 ) {
                  tempo.addElement(new Integer(0x04));
                  tempo.addElement(new Integer(0x5C));
                  tempo.addElement(new Integer(0x12));
          }
          else if ( combo2.getSelectedIndex() == 7 ) {
                  tempo.addElement(new Integer(0x03));
                  tempo.addElement(new Integer(0xD0));
                  tempo.addElement(new Integer(0x90));
          }

          for ( int i=0; i<tp.getTabCount(); i++ ) {
                  v = (Vector)tp.tab_byte.elementAt(i);
                  for ( int m=0; m<v.size(); m++ ) {
                          v1.addElement(v.elementAt(m));
                  }
          }

          if ( tp.getTabCount() == 1 ) {
                  am.midi_music(tp.getTabCount(), mi.note_signature, mi.note_gain, length, (Vector)tp.tab_byte.elementAt(0),tempo);
          }
          else {
                  am.midi_music(tp.getTabCount(), mi.note_signature, mi.note_gain, length, v1,tempo);
          }

          byte b[] = am.note_midi;
          FileDialog d = new FileDialog(new Frame(), "Save File",
                                        FileDialog.SAVE);
          d.setDirectory(",");
          d.setVisible(true);
          String str = d.getDirectory() + d.getFile();
          String filesong = d.getFile();
          FileReader fin=null;
          FileWriter fout=null;
          if ( filesong != null ) {
                  int n_end = filesong.length();
                  int n_start = n_end - 3;
                  String file_type = filesong.substring(n_start, n_end);
                  if (file_type.equals("mid")) {
                          try {
                                  ByteArrayInputStream bin = new ByteArrayInputStream(b);
                                  ByteArrayOutputStream bout = new ByteArrayOutputStream();
                                  int c;
                                  while ( (c = bin.read()) != -1)
                                          bout.write( (byte) c);
                                  bout.close();
                                  bin.close();

                                  FileOutputStream out = new FileOutputStream(str);
                                  out.write(b);
                                  out.close();

                          } catch (Exception ex) {
                                  System.out.println("File not Found");
                          }
                  } else {
                          JOptionPane.showMessageDialog(null, "Incorrect file type ", "Message Dialog", JOptionPane.WARNING_MESSAGE);
                  }
          }
  }

  void Recognition_actionPerformed(ActionEvent e) {
          BufferedImage buf;
          mi = new Manage_Image();
          int  w,h;
          int number;
          int music=0x00;
          number = tp.getSelectedIndex();
          buf = (BufferedImage)tp.tab_image.elementAt(number);
          w = buf.getWidth();
          h = buf.getHeight();
          BufferedImage bufImage = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
          Graphics2D g2 = bufImage.createGraphics();
          g2.drawImage(buf, 0, 0, null);

          if ( combo1.getSelectedIndex() == 0 ) {
                  music = 0x00;
          }
          else if ( combo1.getSelectedIndex() == 1 ) {
                  music = 0x02;
          }
          else if ( combo1.getSelectedIndex() == 2 ) {
                  music = 0x18;
          }
          else if ( combo1.getSelectedIndex() == 3 ) {
                  music = 0x22;
          }
          else if ( combo1.getSelectedIndex() == 4 ) {
                  music = 0x23;
          }
          else if ( combo1.getSelectedIndex() == 5 ) {
                  music = 0x29;
          }
          else if ( combo1.getSelectedIndex() == 6 ) {
                  music = 0x39;
          }
          else if ( combo1.getSelectedIndex() == 7 ) {
                  music = 0x4A;
          }
          else if ( combo1.getSelectedIndex() == 8 ) {
                  music = 0x0B;
          }
          mi.manage(bufImage,number,music,this.angle);
          jTextArea1.setText(mi.show);
          tp.addArrayMusicBytes(mi.note_midi);  // add any track

  }

        void jopen_file_actionPerformed(ActionEvent e) {
                FileDialog d = new FileDialog(new Frame(), "Open file Midi",FileDialog.LOAD);
                d.setDirectory(",");
                d.setVisible(true);
                String str = d.getDirectory() + d.getFile();
                String filesong = d.getFile();
                if ( d.getFile() != null ) {
                        jtext1.setText(str);
                        try {
                                file = new File(str);
                        } catch (Exception e1) {
                                System.err.println(e1);
                        }
                }
        }

  void jplay_actionPerformed(ActionEvent e) {
          try {
                  currentSound = MidiSystem.getSequence(file);
                  player = MidiSystem.getSequencer();
                  player.open();
                  player.setSequence(currentSound); ;
                  player.start();
          }catch (Exception e2) {
                  System.out.println(e2);
          }
  }

  void jstop_actionPerformed(ActionEvent e) {
          if ( player.isRunning() ) {
                  player.close();
          }
  }

        void jbpre_actionPerformed(ActionEvent e) {   ///Transform   && Preprocessing /////
                final DecimalFormat format = new DecimalFormat ();

                DecimalFormat twoDigits= new DecimalFormat("0.00");

                Java2DImaging jm = new Java2DImaging();
                BufferedImage buf=null;
                buf = (BufferedImage)tp.tab_image.elementAt(tp.getSelectedIndex());

                int w = buf.getWidth();
                int h = buf.getHeight();
                BufferedImage bufImage = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                Graphics2D g2 = bufImage.createGraphics();
                g2.drawImage(buf, 0, 0, null);

                Find_Angle fa = new Find_Angle();
                fa.angle(bufImage);
                this.angle = fa.theta;
                int b1;
                String st1 = "Preprocessing Complete" + '\n';
                st1 = st1.concat("Angle = " + twoDigits.format(this.angle));
                jTextArea1.setText(st1);

                if ( fa.theta > 0 ) {  //theta > 0
                        bufImage = jm.rotate(bufImage, (float) Math.toRadians(fa.theta));
                        w = bufImage.getWidth(null);
                        h = bufImage.getHeight(null);

                        for ( int x=0; x<w; x++ ) {
                                for ( int y=0; y<h; y++ ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 == 0xFF ) {
                                                break;
                                        }
                                        else  if ( b1 == 0x00 ) {
                                                bufImage.setRGB(x, y, 0xFFFFFF);
                                        }
                                }
                        }

                        for ( int x=w-1; x>0; x-- ) {
                                for ( int y=h-1; y>0; y-- ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 == 0xFF ) {
                                                break;
                                        }
                                        else  if ( b1 == 0x00 ) {
                                                bufImage.setRGB(x, y, 0xFFFFFF);
                                        }
                                }
                        }
                        for ( int y=0; y<h; y++ ) {
                                for ( int x=0; x<w; x++ ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 < 225) {
                                                bufImage.setRGB(x,y,0x00);
                                        }
                                        else {
                                                bufImage.setRGB(x,y,0xFFFFFF);
                                        }
                                }
                        }

                        w = bufImage.getWidth(null);
                        h = bufImage.getHeight(null);

                        buf = new BufferedImage(w,h,BufferedImage.TYPE_BYTE_GRAY);
                        g2 = buf.createGraphics();
                        g2.drawImage(bufImage, 0, 0, null);

                        tp.tab_image.removeElementAt(tp.getSelectedIndex());
                        tp.remove(tp.getSelectedIndex());

                        if (w >= 1400 || h >= 1400) {
                                buf = jm.scale(buf, (float) 0.45);
                        }
                        else if ( w >= 1200 && h >= 1200) {
                                buf = jm.scale(buf, (float) 0.50);
                        }
                        else if ( w >=  900 && h >= 900 ) {
                                buf = jm.scale(buf,(float)0.65);
                        }
                        else if ( w >= 800 && h >= 800 ) {
                                buf = jm.scale(buf,(float)0.70);
                        }
                        else if ( w >= 750 && h >= 650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }
                        else if ( w >=750 || h >=650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }

                        im = new ImageIcon(buf);
                        l1 = new JLabel(im);
                        tp.addTab("Image", l1, i);
                        tp.addBufferedImage(bufImage);
                }
                else if ( fa.theta < 0 ) {  //theta < 0
                        bufImage = jm.rotate(bufImage, (float) Math.toRadians(fa.theta));
                        w = bufImage.getWidth(null);
                        h = bufImage.getHeight(null);
                        for ( int x=0; x<w; x++ ) {
                                for ( int y=0; y<h; y++ ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 == 0xFF ) {
                                                break;
                                        }
                                        else  if ( b1 == 0x00 ) {
                                                bufImage.setRGB(x, y, 0xFFFFFF);
                                        }
                                }
                        }

                        for ( int x=w-1; x>0; x-- ) {
                                for ( int y=h-1; y>0; y-- ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 == 0xFF ) {
                                                break;
                                        }
                                        else  if ( b1 == 0x00 ) {
                                                bufImage.setRGB(x, y, 0xFFFFFF);
                                        }
                                }
                        }
                        for ( int y=0; y<h; y++ ) {
                                for ( int x=0; x<w; x++ ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 < 225) {
                                                bufImage.setRGB(x,y,0x00);
                                        }
                                        else {
                                                bufImage.setRGB(x,y,0xFFFFFF);
                                        }
                                }
                        }

                        w = bufImage.getWidth(null);
                        h = bufImage.getHeight(null);

                        buf = new BufferedImage(w,h,BufferedImage.TYPE_BYTE_GRAY);
                        g2 = buf.createGraphics();
                        g2.drawImage(bufImage, 0, 0, null);

                        tp.tab_image.removeElementAt(tp.getSelectedIndex());
                        tp.remove(tp.getSelectedIndex());

                        if (w >= 1400 || h >= 1400) {
                                buf = jm.scale(buf, (float) 0.45);
                        }
                        else if ( w >= 1200 && h >= 1200) {
                                buf = jm.scale(buf, (float) 0.50);
                        }
                        else if ( w >=  900 && h >= 900 ) {
                                buf = jm.scale(buf,(float)0.65);
                        }
                        else if ( w >= 800 && h >= 800 ) {
                                buf = jm.scale(buf,(float)0.70);
                        }
                        else if ( w >= 750 && h >= 650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }
                        else if ( w >=750 || h >=650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }

                        im = new ImageIcon(buf);
                        l1 = new JLabel(im);
                        tp.addTab("Image", l1, i);
                        tp.addBufferedImage(bufImage);
                }
                else {      // theta == 0
                        for ( int y=0; y<h; y++ ) {
                                for ( int x=0; x<w; x++ ) {
                                        b1 = bufImage.getRGB(x, y) & 0xFF;
                                        if ( b1 < 0xE2) {
                                                bufImage.setRGB(x,y,0x00);
                                        }
                                        else {
                                                bufImage.setRGB(x,y,0xFFFFFF);
                                        }
                                }
                        }

                        buf = new BufferedImage(w,h,BufferedImage.TYPE_BYTE_GRAY);
                        g2 = buf.createGraphics();
                        g2.drawImage(bufImage, 0, 0, null);

                        tp.tab_image.removeElementAt(tp.getSelectedIndex());
                        tp.remove(tp.getSelectedIndex());

                        if (w >= 1400 || h >= 1400) {
                                buf = jm.scale(buf, (float) 0.45);
                        }
                        else if ( w >= 1200 && h >= 1200) {
                                buf = jm.scale(buf, (float) 0.50);
                        }
                        else if ( w >=  900 && h >= 900 ) {
                                buf = jm.scale(buf,(float)0.65);
                        }
                        else if ( w >= 800 && h >= 800 ) {
                                buf = jm.scale(buf,(float)0.70);
                        }
                        else if ( w >= 750 && h >= 650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }
                        else if ( w >=750 || h >=650 ) {
                                buf = jm.scale(buf,(float)0.80);
                        }

                        im = new ImageIcon(buf);
                        l1 = new JLabel(im);
                        tp.addTab("Image", l1, i);
                        tp.addBufferedImage(bufImage);
                }
        }
}

class Frame1_jimage_actionAdapter
        implements java.awt.event.ActionListener {
        Frame1 adaptee;

        Frame1_jimage_actionAdapter(Frame1 adaptee) {
                this.adaptee = adaptee;
        }

        public void actionPerformed(ActionEvent e) {
                adaptee.jimage_actionPerformed(e);
        }
}

class Frame1_jsave_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jsave_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jsave_actionPerformed(e);
  }
}

class Frame1_Recognition_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_Recognition_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Recognition_actionPerformed(e);
  }
}

class Frame1_jopen_file_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jopen_file_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jopen_file_actionPerformed(e);
  }
}

class Frame1_jplay_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jplay_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jplay_actionPerformed(e);
  }
}

class Frame1_jstop_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jstop_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jstop_actionPerformed(e);
  }
}

class Frame1_jbpre_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jbpre_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jbpre_actionPerformed(e);
  }
}