package image_jtab;

public class Point_pos
{
        public int xl;
        public int xr;


        public Point_pos()
        {
                xl=0;
                xr=0;
        }

}