package image_jtab;

import java.awt.image.*;
import java.util.*;
import java.lang.*;

public class Position_y
{
        public Vector pos_y;
        public Position_y()
        {
                pos_y = new Vector();
        }

}