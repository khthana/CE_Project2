package image_jtab;

import java.lang.*;
import java.util.*;
import java.awt.image.*;

public class Detect_Sound {
        private int w, h;
        private Vector note_sound;
        private Vector pos_line;
        private Vector note_pos;
        private MRectangle rec;
        private int count_line;
        private int bleft;
        private int bright;
        private Point_pos pp1; // keep x
        private Point_pos pp2;
        private Point_pos pp3;
        private Point_pos pp4;
        private Point_pos pp5;
        private Vector count_tail;
        private Vector pos_sort;
        private int width_line;

        public Detect_Sound()
        {
        }

        public void split_note(BufferedImage im, Vector vnote, Vector vpos,int width_line)
        {
                int r = 0;
                this.width_line = width_line;
                width_line = (width_line/2) + width_line;
                int p[]; // position point black
                BufferedImage im1 = null;
                note_sound = new Vector();
                note_pos = new Vector();
                for (int i = 0; i < vnote.size(); i++) {
                        Integer tmp = (Integer) vnote.elementAt(i);
                        r = tmp.intValue();
                        if (r != 14) {
                                note_sound.addElement(vnote.elementAt(i));
                                note_pos.addElement(vpos.elementAt(i));
                        } else {
                                rec = (MRectangle) vpos.elementAt(i);
                                w = (rec.x2 - rec.x1) + 2;
                                h = (rec.y2 - rec.y1) + 2;
                                if (rec != null && w != 0) {
                                        p = new int[w * h];
                                        rec.x1 = ( rec.x1 < 1 ) ? 1 : rec.x1;
                                        rec.y1 = ( rec.y1 < 1 ) ? 1 : rec.y1;
                                        im.getRGB(rec.x1 - 1, rec.y1 - 1, w, h, p, 0, w);
                                        im1 = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
                                        im1.setRGB(0, 0, w, h, p, 0, w);
                                        find_lrpoint(im1); //fine black left-right

                                        if (this.bleft == 1 && this.bright == 0) {
                                                point_left(im1);
                                        }
                                        if (this.bleft == 0 && this.bright == 1) {
                                                point_right(im1);
                                        }
                                }
                        }
                }
                for (int i = 0; i < note_sound.size(); i++) {
                        Integer tmp = (Integer) note_sound.elementAt(i);
                        r = tmp.intValue();
                }
        }

        public void find_linever(BufferedImage im)
        { //find line vertical
                int w=0;
                int h=0;
                w = im.getWidth();
                h = im.getHeight();
                pos_line = new Vector();
                int x1 = 0;
                int b;
                int count = 0;
                int line = 0;
                for (int x = 0; x < w; x++) {
                        for (int y = 0; y < h/2; y++) {
                                b = im.getRGB(x, y) & 0xFF;
                                if (b == 0x00) {
                                        count++;
                                }
                        }
                        if (count >= (70 * h/2) / 100) {
                                pos_line.addElement(new Integer(x));
                                if (x1 == x) {
                                        line++;
                                } else {
                                        if (x - x1 != 1) {
                                                x1 = x;
                                                line++;
                                        } else {
                                                if (x1 == 0) {
                                                        line++;
                                                }
                                                x1 = x;
                                        }
                                }
                        }
                        count = 0;
                }
                count_line = line;
        }

        public void find_linever1(BufferedImage im)
        { //find line vertical
                int w=0;
                int h=0;
                w = im.getWidth();
                h = im.getHeight();
                pos_line = new Vector();
                int x1 = 0;
                int b;
                int count = 0;
                int line = 0;
                for (int x = 0; x < w; x++) {
                        for (int y = h/2; y < h; y++) {
                                b = im.getRGB(x, y) & 0xFF;
                                if (b == 0x00) {
                                        count++;
                                }
                        }
                        if (count >= (70 * h/2) / 100) {
                                pos_line.addElement(new Integer(x));
                                if (x1 == x) {
                                        line++;
                                } else {
                                        if (x - x1 != 1) {
                                                x1 = x;
                                                line++;
                                        } else {
                                                if (x1 == 0) {
                                                        line++;
                                                }
                                                x1 = x;
                                        }
                                }
                        }
                        count = 0;
                }
                count_line = line;
        }

        public void find_lrpoint(BufferedImage im)
        { //find first,last line black
                bleft = 0;
                bright = 0;
                int b, b1, b2, b3;
                int count = 0;
                int x1 = 0;
                int x2 = 0;
                int c = (40 * h) / 100;
                for (int i = 0; i < w; i++) {
                        int br = 0;
                        for (int j = 0; j < h; j++) {
                                b = im.getRGB(i, j) & 0xFF;
                                if (b == 0x00) {
                                        count++;
                                }
                        }
                        if (count >= c) {
                                x1 = i;
                                break;
                        }
                        count = 0;
                }
                count = 0;
                for (int i = w - 1; i > 0; i--) {
                        for (int j = 0; j < h; j++) {
                                b = im.getRGB(i, j) & 0xFF;
                                if (b == 0x00) {
                                        count++;
                                }
                        }
                        if (count >= c) {
                                x2 = i;
                                break;
                        }
                        count = 0;
                }
                if (x1 >= 4) {
                        for (int y = 0; y < h; y++) {
                                b = im.getRGB(x1 - 1, y) & 0xFF;
                                b1 = im.getRGB(x1 - 2, y) & 0xFF;
                                b2 = im.getRGB(x1 - 3, y) & 0xFF;
                                b3 = im.getRGB(x1 - 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        bleft = 1;
                                }
                        }
                }

                if (x2 <= w - 5) {
                        for (int y = 0; y < h; y++) {
                                b = im.getRGB(x2 + 1, y) & 0xFF;
                                b1 = im.getRGB(x2 + 2, y) & 0xFF;
                                b2 = im.getRGB(x2 + 3, y) & 0xFF;
                                b3 = im.getRGB(x2 + 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        bright = 1;
                                }
                        }
                }
        }

        public void point_left(BufferedImage im)
        { //split note long
                find_linever(im); //find amount line
                set_posline();
                find_tail(im);
                erase_point(im);
        }

        public void point_right(BufferedImage im)
        {
                find_linever1(im); //find amount line
                set_posline();
                find_tail1(im);
                erase_point1(im);
        }

        public void set_posline()          //set xl and xr
        {
                pp1 = new Point_pos();
                pp2 = new Point_pos();
                pp3 = new Point_pos();
                pp4 = new Point_pos();
                pp5 = new Point_pos();
                Vector tm1 = new Vector();
                Vector tm = new Vector();

                if (this.count_line == pos_line.size()) {
                        for (int i = 0; i < pos_line.size(); i++) { // line vertical thin 1
                                if (i == 0) {
                                        Integer tmp1 = (Integer) pos_line.elementAt(0);
                                        pp1.xl = tmp1.intValue();
                                        pp1.xr = pp1.xl;
                                } else if (i == 1) {
                                        Integer tmp1 = (Integer) pos_line.elementAt(1);
                                        pp2.xl = tmp1.intValue();
                                        pp2.xr = pp2.xl;
                                } else if (i == 2) {
                                        Integer tmp1 = (Integer) pos_line.elementAt(2);
                                        pp3.xl = tmp1.intValue();
                                        pp3.xr = pp3.xl;
                                } else if (i == 3) {
                                        Integer tmp1 = (Integer) pos_line.elementAt(3);
                                        pp4.xl = tmp1.intValue();
                                        pp4.xr = pp4.xl;
                                } else if (i == 4) {
                                        Integer tmp1 = (Integer) pos_line.elementAt(4);
                                        pp5.xl = tmp1.intValue();
                                        pp5.xr = pp5.xl;
                                }
                        }
                }
                else {    //in one line can thin more than one
                        int count = 0;
                        for (int i = 0; i < pos_line.size(); i++) {
                                int tmp1 = 0, tmp2 = 0;
                                Integer t1 = (Integer) pos_line.elementAt(i);
                                tmp1 = t1.intValue();

                                if ( tm.size() == 0 )  {
                                        tm.addElement(new Integer(tmp1));
                                }
                                else {
                                        Integer t2 = (Integer) tm.elementAt(tm.size()-1);
                                        tmp2 = t2.intValue();
                                        if (tmp1 - tmp2 == 1) {
                                                tm.addElement(new Integer(tmp1));
                                        } else {
                                                tm1.addElement(tm);
                                                tm = new Vector();
                                                tm.addElement(new Integer(tmp1));
                                        }
                                }
                        }
                        if ( tm.size() != 0 ) {
                                tm1.addElement(tm);
                        }

                        if (tm1 != null) {
                                for (int i = 0; i < tm1.size(); i++) {
                                        Vector vec = new Vector();
                                        if (i == 0) {
                                                vec = (Vector) tm1.elementAt(i);
                                                if (vec.size() != 0) {
                                                        if ( vec.size() != 1 ) {
                                                                Integer m = (Integer) vec.elementAt(0);
                                                                pp1.xl = m.intValue();
                                                                Integer m1 = (Integer) vec.elementAt(vec.size() - 1);
                                                                pp1.xr = m1.intValue();
                                                        }
                                                        else {
                                                                Integer tmp1 = (Integer) vec.elementAt(0);
                                                                pp1.xl = tmp1.intValue();
                                                                pp1.xr = pp1.xl;
                                                        }
                                                }
                                        }
                                        else if (i == 1) {
                                                vec = (Vector) tm1.elementAt(i);
                                                if (vec.size() != 0) {
                                                                if (vec.size() != 1) {
                                                                        Integer m = (Integer) vec.elementAt(0);
                                                                        pp2.xl = m.intValue();
                                                                        Integer m1 = (Integer) vec.elementAt(vec.size() - 1);
                                                                        pp2.xr = m1.intValue();
                                                                }
                                                                else {
                                                                        Integer tmp1 = (Integer) vec.elementAt(0);
                                                                        pp2.xl = tmp1.intValue();
                                                                        pp2.xr = pp2.xl;
                                                                        }
                                                                }
                                                        }
                                                else if (i == 2) {
                                                        vec = (Vector) tm1.elementAt(i);
                                                        if (vec.size() != 0) {
                                                                if (vec.size() != 1) {
                                                                        Integer m = (Integer) vec.elementAt(0);
                                                                        pp3.xl = m.intValue();
                                                                        Integer m1 = (Integer) vec.elementAt(vec.size() - 1);
                                                                        pp3.xr = m1.intValue();
                                                                }
                                                                else {
                                                                        Integer tmp1 = (Integer) vec.elementAt(0);
                                                                        pp3.xl = tmp1.intValue();
                                                                        pp3.xr = pp3.xl;
                                                                }
                                                        }
                                                }
                                                else if (i == 3) {
                                                        vec = (Vector) tm1.elementAt(i);
                                                        if (vec.size() != 0) {
                                                                if (vec.size() != 1) {
                                                                        Integer m = (Integer) vec.elementAt(0);
                                                                        pp4.xl = m.intValue();
                                                                        Integer m1 = (Integer) vec.elementAt(vec.size() - 1);
                                                                        pp4.xr = m1.intValue();
                                                                }
                                                                else {
                                                                        Integer tmp1 = (Integer) vec.elementAt(0);
                                                                        pp4.xl = tmp1.intValue();
                                                                        pp4.xr = pp4.xl;
                                                                }
                                                        }
                                                }
                                                else if (i == 4) {
                                                        vec = (Vector) tm1.elementAt(i);
                                                        if (vec.size() != 0) {
                                                                if (vec.size() != 1) {
                                                                        Integer m = (Integer) vec.elementAt(0);
                                                                        pp5.xl = m.intValue();
                                                                        Integer m1 = (Integer) vec.elementAt(vec.size() - 1);
                                                                        pp5.xr = m1.intValue();
                                                                }
                                                                else {
                                                                        Integer tmp1 = (Integer) vec.elementAt(0);
                                                                        pp5.xl = tmp1.intValue();
                                                                        pp5.xr = pp5.xl;
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                }

        public void find_tail(BufferedImage im)
        {
                count_tail = new Vector();
                for (int i = 0; i < count_line; i++) {
                        if (i == 0) {
                                int p1, p2;
                                p1 = pp1.xl;
                                p2 = pp1.xr;
                                int a = check_tail(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 1) {
                                int p1, p2;
                                p1 = pp2.xl;
                                p2 = pp2.xr;
                                int a = check_tail(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 2) {
                                int p1, p2;
                                p1 = pp3.xl;
                                p2 = pp3.xr;
                                int a = check_tail(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 3) {
                                int p1, p2;
                                p1 = pp4.xl;
                                p2 = pp4.xr;
                                int a = check_tail(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 4) {
                                int p1, p2;
                                p1 = pp5.xl;
                                p2 = pp5.xr;
                                int a = check_tail(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        }
                }
        }

        public int check_tail(BufferedImage im, int x1, int x2)
        {
                int b, b1, b2, b3;
                int cl = 0;
                int cr = 0;
                int y1 = 0, y2 = 0;
                int goal = (40 * h) / 100;
                if ( x1 >= 4 ) {
                        for (int y = 0; y <= goal; y++) {
                                b = im.getRGB(x1 - 1, y) & 0xFF;
                                b1 = im.getRGB(x1 - 2, y) & 0xFF;
                                b2 = im.getRGB(x1 - 3, y) & 0xFF;
                                b3 = im.getRGB(x1 - 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        if (y1 == y) {
                                                y1 = y;
                                                cl++;
                                        } else {
                                                int ans = y - y1;
                                                if (ans != 1) {
                                                        cl++;
                                                        y1 = y;
                                                } else {
                                                        if (y1 == 0) {
                                                                cl++;
                                                                y1 = y;
                                                        }
                                                        y1 = y;
                                                }
                                        }
                                }
                        }
                }
                if (x2 <= w - 5) {
                        for (int y = 0; y <= goal; y++) {
                                b = im.getRGB(x2 + 1, y) & 0xFF;
                                b1 = im.getRGB(x2 + 2, y) & 0xFF;
                                b2 = im.getRGB(x2 + 3, y) & 0xFF;
                                b3 = im.getRGB(x2 + 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        if (y2 == y) {
                                                y2 = y;
                                                cr++;
                                        } else {
                                                int ans = y - y2;
                                                if (ans != 1) {
                                                        cr++;
                                                        y2 = y;
                                                } else {
                                                        if (y2 == 0) {
                                                                cr++;
                                                                y2 = y;
                                                        }
                                                        y2 = y;
                                                }
                                        }
                                }
                        }
                } else {
                        cr = 0;
                }

                if (cl >= cr) {
                        cl = cl;
                } else {
                        cl = cr;
                }
                return cl;
        }

        public void find_tail1(BufferedImage im)
        {
                count_tail = new Vector();
                for (int i = 0; i < count_line; i++) {
                        if (i == 0) {
                                int p1, p2;
                                p1 = pp1.xl;
                                p2 = pp1.xr;
                                int a = check_tail1(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 1) {
                                int p1, p2;
                                p1 = pp2.xl;
                                p2 = pp2.xr;
                                int a = check_tail1(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 2) {
                                int p1, p2;
                                p1 = pp3.xl;
                                p2 = pp3.xr;
                                int a = check_tail1(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 3) {
                                int p1, p2;
                                p1 = pp4.xl;
                                p2 = pp4.xr;
                                int a = check_tail1(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        } else if (i == 4) {
                                int p1, p2;
                                p1 = pp5.xl;
                                p2 = pp5.xr;
                                int a = check_tail1(im, p1, p2);
                                count_tail.addElement(new Integer(a));
                        }
                }
        }

        public int check_tail1(BufferedImage im, int x1, int x2)
        {
                int b, b1, b2, b3;
                int cl = 0;
                int cr = 0;
                int y1 = 0, y2 = 0;
                int goal = (70 * h) / 100;
                if ( x1 >= 4 ) {
                        for (int y = goal; y < h; y++) {
                                b = im.getRGB(x1 - 1, y) & 0xFF;
                                b1 = im.getRGB(x1 - 2, y) & 0xFF;
                                b2 = im.getRGB(x1 - 3, y) & 0xFF;
                                b3 = im.getRGB(x1 - 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        if (y1 == y) {
                                                y1 = y;
                                                cl++;
                                        } else {
                                                int ans = y - y1;
                                                if (ans != 1) {
                                                        cl++;
                                                        y1 = y;
                                                } else {
                                                        if (y1 == 0) {
                                                                cl++;
                                                                y1 = y;
                                                        }
                                                        y1 = y;
                                                }
                                        }
                                }
                        }
                }
                if (x2 <= w - 5) {
                        for (int y = goal; y < h; y++) {
                                b = im.getRGB(x2 + 1, y) & 0xFF;
                                b1 = im.getRGB(x2 + 2, y) & 0xFF;
                                b2 = im.getRGB(x2 + 3, y) & 0xFF;
                                b3 = im.getRGB(x2 + 4, y) & 0xFF;
                                if (b == 0x00 && b1 == 0x00 && b2 == 0x00 && b3 == 0x00) {
                                        if (y2 == y) {
                                                y2 = y;
                                                cr++;
                                        } else {
                                                int ans = y - y2;
                                                if (ans != 1) {
                                                        cr++;
                                                        y2 = y;
                                                } else {
                                                        if (y2 == 0) {
                                                                cr++;
                                                                y2 = y;
                                                        }
                                                        y2 = y;
                                                }
                                        }
                                }
                        }
                } else {
                        cr = 0;
                }

                if (cl >= cr) {
                        cl = cl;
                } else {
                        cl = cr;
                }
                return cl;
        }

        public void erase_point(BufferedImage im)
        {
                int b;
                if (count_line == 2) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 3) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 4) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp3.xr + 1; i < pp4.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 5) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp3.xr + 1; i < pp4.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp4.xr + 1; i < pp5.xl; i++) {
                                for (int j = 0; j <= (40 * h) / 100; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                }

                add_note(im); //add note to note_sound
        }

        public void erase_point1(BufferedImage im)
        {
                int b;
                if (count_line == 2) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 3) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 4) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp3.xr + 1; i < pp4.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                } else if (count_line == 5) {
                        for (int i = pp1.xr + 1; i < pp2.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp2.xr + 1; i < pp3.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp3.xr + 1; i < pp4.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                        for (int i = pp4.xr + 1; i < pp5.xl; i++) {
                                for (int j = h/2; j < h; j++) {
                                        b = im.getRGB(i, j) & 0xFF;
                                        if (b == 0x00) {
                                                im.setRGB(i, j, 0xFFFFFF);
                                        }
                                }
                        }
                }
                add_note1(im); //add note to note_sound
        }

        public void add_note(BufferedImage im)
        {
                NoteSearcher ns = new NoteSearcher(im);   // find new position of note split
                Vector tmp = new Vector();
                Vector tmp1 = new Vector();
                tmp = ns.searchAll();

                for (int i = 0; i < tmp.size(); i++) {
                        MRectangle r = (MRectangle) tmp.elementAt(i);
                        if ( (r.y2 - r.y1) >  this.width_line  &&  (r.x2 - r.x1) >=4)  {
                                tmp1.addElement(r);
                        }
                }

                if (count_line == tmp1.size()) {
                        this.sort_position(tmp1);

                        for (int i = 0; i < this.pos_sort.size(); i++) {
                                MRectangle r = (MRectangle)pos_sort.elementAt(i);
                                r.x1 = (r.x1 + rec.x1) - 1;
                                r.x2 = (r.x2 + rec.x1) - 1;
                                r.y1 = (r.y1 + rec.y1) - 1;
                                r.y2 = (r.y2 + rec.y1) - 1;
                                Integer i1 = (Integer) count_tail.elementAt(i);
                                int tail = i1.intValue();
                                if (tail == 1) {
                                        note_sound.addElement(new Integer(9));
                                        note_pos.addElement(r);
                                } else if (tail == 2) {
                                        note_sound.addElement(new Integer(10));
                                        note_pos.addElement(r);
                                }
                        }
                }
        }

        public void add_note1(BufferedImage im)
        {
                NoteSearcher ns = new NoteSearcher(im);
                Vector tmp = new Vector();
                Vector tmp1 = new Vector();

                tmp = ns.searchAll();

                for (int i = 0; i < tmp.size(); i++) {
                        MRectangle r = (MRectangle) tmp.elementAt(i);
                        if ( (r.y2 - r.y1) >  this.width_line  &&  (r.x2 - r.x1) >=4)  {
                                tmp1.addElement(r);
                        }
                }

                if (count_line == tmp1.size()) {
                        this.sort_position(tmp1);

                        for (int i = 0; i < pos_sort.size(); i++) {
                                MRectangle r = (MRectangle) pos_sort.elementAt(i);
                                r.x1 = (r.x1 + rec.x1) - 1;
                                r.x2 = (r.x2 + rec.x1) - 1;
                                r.y1 = (r.y1 + rec.y1) - 1;
                                r.y2 = (r.y2 + rec.y1) - 1;
                                Integer i1 = (Integer) count_tail.elementAt(i);
                                int tail = i1.intValue();
                                if (tail == 1) {
                                        note_sound.addElement(new Integer(4));
                                        note_pos.addElement(r);
                                } else if (tail == 2) {
                                        note_sound.addElement(new Integer(5));
                                        note_pos.addElement(r);
                                }
                        }
                }
        }

        public void  sort_position(Vector tmp_pos) {
                this.pos_sort = new Vector();
                pos_sort = tmp_pos;
                MRectangle r1 = new MRectangle();
                MRectangle r2 = new MRectangle();

                for (int i = 0; i < pos_sort.size(); i++) {
                        r1 = (MRectangle) pos_sort.elementAt(i);
                        for (int j = i + 1; j < pos_sort.size(); j++) {
                                r2 = (MRectangle) pos_sort.elementAt(j);
                                if (r1.x1 > r2.x1) {
                                        MRectangle ptmp, ptmp1;
                                        ptmp = (MRectangle) pos_sort.elementAt(i);
                                        ptmp1 = (MRectangle) pos_sort.elementAt(j);

                                        pos_sort.removeElementAt(i);
                                        pos_sort.insertElementAt(ptmp1, i);

                                        pos_sort.removeElementAt(j);
                                        pos_sort.insertElementAt(ptmp, j);
                                        r1 = (MRectangle) pos_sort.elementAt(i);
                                } else if (r1.x1 == r2.x1 && r1.y1 > r2.y1) {
                                        Integer vtmp, vtmp1;
                                        MRectangle ptmp, ptmp1;
                                        ptmp = (MRectangle) pos_sort.elementAt(i);
                                        ptmp1 = (MRectangle) pos_sort.elementAt(j);

                                        pos_sort.removeElementAt(i);
                                        pos_sort.insertElementAt(ptmp1, i);

                                        pos_sort.removeElementAt(j);
                                        pos_sort.insertElementAt(ptmp, j);
                                        r1 = (MRectangle) pos_sort.elementAt(i);
                                }
                        }
                }
        }

        Vector Get_Note()
        {
                return note_sound;
        }

        Vector Get_Posnote()
        {
                return note_pos;
        }
}