package image_jtab;

import java.util.*;
import java.lang.*;
import java.awt.image.*;
import java.awt.*;

public class Manage_Image
{
        private Vector note_music;
        public int note_signature;
        public int note_gain;
        private Vector position_note;
        private Image image;
        public BufferedImage im;
        private int w;
        private int h;
        public Position_y py;
        private int width_line;
        private Vector vector;
        public Vector note_midi;
        public int count_midi;
        public String clef = "Gclef";
        public String show;
        private int count1;

        public Manage_Image()
        {
                count_midi=0;
                count1 = 1;
        }

        public void  manage(BufferedImage bufImage,int number,int music,double angle)  {
                py = new Position_y();
                int goal_line=0;
                Position_y py_tmp = new Position_y();  // position staff line in image
                int b1, b;
                int cl = 0; //count amount line
                int p1, p2;
                int bb, yc, c, cc;
                Integer ii;

                vector = new Vector();
                w =bufImage.getWidth(null);
                h = bufImage.getHeight(null);
                //Add_Midi am;
                im = new BufferedImage(w, h,BufferedImage.TYPE_BYTE_GRAY);
                Graphics2D g2 = im.createGraphics();
                g2.drawImage(bufImage, 0, 0, null);

                int count = 0;
                int index;
                Integer in;
                int size;
                w = im.getWidth();
                h = im.getHeight();
                int x1=0,x2=0;

                for ( int i=0; i<h; i++ ) {
                        for ( int j=0; j<w; j++ ) {
                                b = im.getRGB(j,i) & 0xFF;
                                if ( b == 0x00 ) {
                                        if ( x1 == 0 ) {
                                                x1 = j;
                                                break;
                                        }
                                        else if ( j < x1 ) {
                                                x1 = j;
                                                break;
                                        }
                                }
                        }
                }

                for ( int i=0; i<h; i++ ) {
                        for ( int j=w-1; j>0; j-- ) {
                                b = im.getRGB(j,i) & 0xFF;
                                if ( b == 0x00 ) {
                                        if ( x2 == 0 ) {
                                                x2 = j;
                                                break;
                                        }
                                        else if ( j > x2 ) {
                                                x2 = j;
                                                break;
                                        }
                                }
                        }
                }

                for (int y = 0; y < h; y++) { //fine line staff
                        for (int x = 0; x < w; x++) {
                                b = im.getRGB(x, y);
                                b = b & 0xFF;
                                if (b == 0x00) {
                                        count++;
                                }
                        }
                        int co = (x2-x1)*60 / 100;

                        if (count >= co) {
                                if ( py.pos_y.size() == 0 ) {
                                        py.pos_y.addElement(new Integer(y));
                                        System.out.println("y " + y);
                                }
                                else {
                                        size = py_tmp.pos_y.size() - 1;
                                        in = (Integer)py_tmp.pos_y.elementAt(size);
                                        index = in.intValue();
                                        index = y - index;
                                        if ( index != 1 ) {
                                                py.pos_y.addElement(new Integer(y));
                                        }
                                }
                                py_tmp.pos_y.addElement(new Integer(y));
                                for (int m = 0; m < w; m++) {
                                        im.setRGB(m, y, 0xFFFFFF);
                                        if ( angle != 0 ) {
                                                if ( (im.getRGB(m, y - 1) & 0xFF) == 0x00) {
                                                        if ( (im.getRGB(m, y - 2) & 0xFF) != 0x00) {
                                                                im.setRGB(m, y - 1, 0xFFFFFF);
                                                        }
                                                }
                                                if ( (im.getRGB(m, y + 1) & 0xFF) == 0x00) {
                                                        if ( (im.getRGB(m, y + 2) & 0xFF) != 0x00) {
                                                                im.setRGB(m, y + 1, 0xFFFFFF);
                                                        }
                                                }
                                        }
                                }
                        }
                        count=0;
                }
                if ( py.pos_y.size() > 2 ) {
                        Integer i1 = (Integer) py.pos_y.elementAt(0); //calculate width line staff
                        Integer i2 = (Integer) py.pos_y.elementAt(2);
                        p1 = i1.intValue();
                        p2 = i2.intValue();
                        width_line = (p2 - p1)+2;
                }

                for (int y = 0; y < py_tmp.pos_y.size(); y++) { //fill line staff
                        ii = (Integer) py_tmp.pos_y.elementAt(y);
                        yc = ii.intValue();
                        for (int x = 2; x < w - 1; x++) {
                                b = im.getRGB(x, yc - 1);
                                b = b & 0xFF;
                                bb = im.getRGB(x, yc + 1);
                                bb = bb & 0xFF;
                                c = im.getRGB(x - 1, yc);
                                c = c & 0xFF;
                                cc = im.getRGB(x + 1, yc);
                                cc = cc & 0xFF;
                                if (b == 0x00 && bb == 0xFF ||
                                    bb == 0x00) {
                                        im.setRGB(x, yc, 0x00);
                                }
                                if (b == 0xFF && bb == 0x00) {
                                        im.setRGB(x, yc, 0x00);
                                }
                                if (b == 0xFF && bb == 0xFF &&
                                    c == 0x00 &&
                                    cc == 0x00) {
                                        im.setRGB(x, yc, 0x00);
                                }
                        }
                }
                Delete_Noise dn = new Delete_Noise();

                if ( angle != 0 ) {
                        im = dn.Clear_Noise1(im);
                }

                im = dn.Clear_Noise2(im);
                im = dn.Clear_Noise3(im);

                NoteSearcher noteSearcher = new NoteSearcher(im); //fine position any note
                vector = noteSearcher.searchAll();    // vector keep position of any note

                Vector note = new Vector(); //mean note
                Vector pos_note = new Vector();//position note
                Vector note_tmp = new Vector(); //mean note
                Vector pos_note_tmp = new Vector();//position note
                Detect_Note detectNote = new Detect_Note();

                Vector note1;
                Vector posnote1;
                Vector pos_line = new Vector();   //position of  staff
                Vector pos_sound = new Vector();  // sound of any staff

                detectNote.NoteMean(im, vector, width_line,py.pos_y);   // find note and instead number of any note
                note = detectNote.Get_Note();
                pos_note = detectNote.Get_Posnote();

                for ( int i=0; i< note.size(); i++ ) {
                        Integer i1= (Integer)note.elementAt(i);
                        int i2 = i1.intValue();
                        if ( i2 == 24 ) {
                                clef = "Fclef";
                                break;
                        }
                        else if ( i2 == 25 ) {
                                clef = "Gclef";
                                break;
                        }
                }

                if  ( clef.equals("Fclef")) {
                        Generate_LineBass gb = new Generate_LineBass();
                        gb.staff_pos(py.pos_y);
                        pos_sound = gb.get_sound();
                        pos_line = gb.get_staff();
                }
                else {
                        Generate_Line gl = new Generate_Line();
                        gl.staff_pos(py.pos_y);
                        pos_sound = gl.get_sound();
                        pos_line = gl.get_staff();
                }

                Detect_Sound ds = new Detect_Sound();   // split note and instead number of any note
                ds.split_note( im,note,pos_note,width_line);

                note1 = new Vector();
                posnote1 = new Vector();

                note.removeAllElements();
                pos_note.removeAllElements();

                note = ds.Get_Note();
                pos_note = ds.Get_Posnote();

                Sort_Note sn = new Sort_Note();  //sort note
                sn.sort(note,pos_note,py.pos_y);

                note_tmp = sn.Get_Notesort();
                pos_note_tmp = sn.Get_Possort();
                int xm=0;
                int xn=0;

                for ( int i=0; i< note_tmp.size(); i++ ) {
                        MRectangle r1 = (MRectangle)pos_note_tmp.elementAt(i);
                        Integer i1 = (Integer)note_tmp.elementAt(i);
                        int i2 = i1.intValue();
                        if ( i2 == 24 ) {
                                xm = r1.x2;
                                xn = r1.x2 + 5;
                        }
                        else if ( i2 == 16 ) {
                                if ( r1.x1 > xm && r1.x1 <= xn ) {
                                        //System.out.println("remove 16 ");
                                }
                                else {
                                        note1.addElement(new Integer(i2));
                                        posnote1.addElement(r1);
                                }
                        }
                        else if ( i2 != 25 && i2 != 24)  {
                                note1.addElement(new Integer(i2));
                                posnote1.addElement(r1);
                        }
                }

                String str = "Detect Found";
                show = new String();

                for ( int i=0; i<posnote1.size(); i++ ) {
                        MRectangle r1 = (MRectangle) posnote1.elementAt(i);
                }

                if ( clef.equals("Fclef") ) {
                        Track_Fclef tf = new Track_Fclef();
                        tf.array_midi(note1, posnote1, pos_sound, pos_line, im, number, music);
                        this.note_signature = tf.note_signature;
                        this.note_gain = tf.note_gain;
                        this.note_midi = tf.note_midi;
                }
                else {
                        Track_Gclef tg = new Track_Gclef();
                        tg.array_midi(note1, posnote1, pos_sound, pos_line, im, number, music);
                        this.note_signature = tg.note_signature;
                        this.note_gain = tg.note_gain;
                        this.note_midi = tg.note_midi;
                }

                show = str + " " + clef + '\n';
                show = show.concat("Time Signature" + " " + this.note_signature + '\n');
                show = show.concat("Note Gain" + " " + note_gain + '\n');

            for ( int i=0; i<note1.size(); i++ ) {
                    Integer i1 = (Integer)note1.elementAt(i);
                    int i2 = i1.intValue();
                    if ( i2 == 1 ) {
                            show = show.concat(count1 + " " + str + " " + "�鵵�ǡ��" + '\n');
                            count1++;
                    }
                    else if ( i2 == 2 || i2 == 7) {
                            show = show.concat(count1+ " " + str + " " + "�鵵�Ǵ�" + '\n');
                            count1++;
                    }
                    else if ( i2 == 3 || i2 == 8) {
                            show = show.concat(count1+ " " + str + " " + "�鵵�Ǣ��" + '\n');
                            count1++;
                    }
                    else if ( i2 == 4 || i2 == 9) {
                            show = show.concat(count1+ " "  + str + " " + "�鵵��ࢺ� 1 ���" + '\n');
                            count1++;
                    }
                    else if ( i2 == 5 || i2 == 10) {
                            show = show.concat(count1+ " "  + str + " " + "�鵵��ࢺ� 2 ���" + '\n');
                            count1++;
                    }
                    else if ( i2 == 26 || i2 == 27) {
                            show = show.concat(count1+ " "  + str + " " + "�鵵��ࢺ� 3 ���" + '\n');
                            count1++;
                    }
                    else if ( i2 == 6 ) {
                            show = show.concat(count1+ " "  + str + " " + "����ͧ���� Flat" + '\n');
                            count1++;
                    }
                    else if ( i2 == 11 ) {
                            show = show.concat(count1+ " "  + str + " " + "�����ش��Ǵ�" + '\n');
                            count1++;
                    }
                    else if ( i2 == 12 ) {
                            show = show.concat(count1+ " "  + str + " " + "����ͧ���� Sharp" + '\n');
                            count1++;
                    }
                    else if ( i2 == 13 ) {
                            show = show.concat(count1+ " "  + str + " " + "����ͧ���� Natural" + '\n');
                            count1++;
                    }
                    else if ( i2 == 14 ) {
                            show = show.concat(count1+ " "  + str + " " + "Combine note" + '\n');
                            count1++;
                    }
                    else if ( i2 == 15 ) {
                            show = show.concat(count1+ " "  + str + " " + "�����ش��ǡ��" + '\n');
                            count1++;
                    }
                    else if ( i2 == 16 ) {
                            show = show.concat(count1+ " "  + str + " " + "�鵻�Шش" + '\n');
                            count1++;
                    }
                    else if ( i2 == 17 ) {
                            show = show.concat(count1+ " "  + str + " " + "�����ش���ࢺ� 1 ���" + '\n');
                            count1++;
                    }
                    else if ( i2 == 18 ) {
                            show = show.concat(count1+ " "  + str + " " + "�����ش���ࢺ� 2 ���" + '\n');
                            count1++;
                    }
                    else if ( i2 == 19 ) {
                            show = show.concat(count1+ " "  + str + " " + "�����ش��Ǣ��" + '\n');
                            count1++;
                    }
            }
        }
}
