package database;

import java.sql.*;
import java.io.*;

public class Members implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addMembers(String username,String password,String firstname,String surname,String nickname,String email)throws SQLException{
		sql = "Insert Into members(USERNAME,PASSWORD,FIRSTNAME,SURNAME,NICKNAME,EMAIL,ACTIVE,PERMIT) Values('"+username+"',MD5('"+password+"'),'"+firstname+"','"+surname+"','"+nickname+"','"+email+"','0','0')";
		statement.executeUpdate(sql);
	}
	
	public void editMembers(String id,String firstname,String surname,String nickname,String email)throws SQLException{
		sql = "Update members Set FIRSTNAME='"+firstname+"',SURNAME='"+surname+"',NICKNAME='"+nickname+"',EMAIL='"+email+"' Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public void changePassword(String id,String password)throws SQLException{
		sql = "Update members Set PASSWORD=MD5('"+password+"') Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public void activeMembers(String id)throws SQLException{
		sql = "update members set ACTIVE='1' where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public String getID(String username)throws SQLException,java.io.UnsupportedEncodingException{
		sql = "select ID from members where USERNAME='"+username+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return this.getField("ID");
	}
	
	//Check for no duplicate Username
	public boolean existMembers(String username)throws SQLException{
		sql = "SELECT COUNT(*) FROM members WHERE USERNAME='"+username+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return (rs.getInt("COUNT(*)")==1);
	}
	
	//Access Member
	public boolean accessMembers(String username,String password)throws SQLException{
		boolean ac=false;
		sql = "SELECT count(*) FROM members WHERE USERNAME='"+username+"' and PASSWORD=MD5('"+password+"')";
		rs = statement.executeQuery(sql);
		rs.next();
		if (rs.getInt("COUNT(*)")==1)
			ac = true;
		return ac;
	}
	
	public void listMembers()throws SQLException{
		sql = "SELECT * FROM members ORDER BY ID";
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextMembers()throws SQLException{
		return rs.next();
	}
	
	//Get Member
	public void getMembers(String id)throws SQLException{
		sql = "SELECT * FROM members WHERE ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public void deleteMembers(String id)throws SQLException{
		sql = "Delete FROM members WHERE ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 
}