import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Topic;
import database.LogFile;

public class Post01 extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String topic = request.getParameter("topic");
		String comment = request.getParameter("comment");
		String mid = request.getParameter("mid");
		String tid;
		String ip = request.getRemoteAddr();
		Topic tp = new Topic();
		LogFile lf = new LogFile();
		try{
			tp.makeConnect();
			tp.addTopic(topic,comment,mid);
			tid = tp.getLastID(mid);
			tp.closeConnect();
			lf.makeConnect();
			lf.addLogFile(mid,"Create Topic(TID="+tid+")",ip);
			lf.closeConnect();
			response.sendRedirect("../project/post02.jsp?tid="+tid);
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}catch(ClassNotFoundException e){
			System.out.println(e.getMessage());
		}
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}		