package http;
import java.io.*;
import java.net.*;
import java.util.*;
import database.Input;
import database.Webboard;
import database.Topic;
import database.Members;
import database.TW;

public class HttpMessage extends Thread{
	private URL action;
	private String referer;
	private String argString;
	private RequestPage rp;
	private boolean finished = false;
	private boolean successed;
	private Webboard wb = new Webboard();
	private Input ip = new Input();
	private Properties proper = new Properties();
	private String topic;
	private String name;
	private String email;
	private String comment;
	private String wid;
	private String rep = null;
	private HTMLManage hm;
	private String mid;
	private String urlreply;
	private String tid;
	private String cause;
	
	public HttpMessage(String action,String referer,Properties prop)throws java.net.MalformedURLException,java.io.IOException{
		super(action);
		this.action = new URL(action);
		this.argString = this.toEncodedString(prop);
		this.referer = new String(referer);
		this.rp = new RequestPage(this.referer);
	}
	
	public HttpMessage(String wid,String tid)throws java.net.MalformedURLException,java.io.IOException,java.sql.SQLException,java.lang.ClassNotFoundException{
		super(wid);
		this.wid = new String(wid);
		this.tid = new String(tid);
		Members mm = new Members();
		mm.makeConnect();
		Topic tp = new Topic();
		tp.makeConnect();
		tp.getTopic(this.tid);
		this.topic = tp.getField("TOPIC");
		this.comment = tp.getField("CONTENT");
		mm.getMembers(tp.getField("MID"));
		this.mid = mm.getField("ID");
		this.email = mm.getField("EMAIL");
		this.name = mm.getField("NICKNAME");
		mm.closeConnect();
		tp.closeConnect();
		wb.makeConnect();
		ip.makeConnect();
		wb.getWebboard(wid);
		this.action = new URL(wb.getField("ACTION"));
		this.referer = new String(wb.getField("POST"));
		this.rp = new RequestPage(this.referer);
		ip.listInput(wid);
		while(ip.nextInput()){
			if(ip.getField("IID").equals("1"))
				this.proper.put(ip.getField("NAME"),ip.getField("VALUE"));
			if(ip.getField("IID").equals("2"))
				this.proper.put(ip.getField("NAME"),this.topic);
			if(ip.getField("IID").equals("3"))
				this.proper.put(ip.getField("NAME"),this.name);
			if(ip.getField("IID").equals("4"))
				this.proper.put(ip.getField("NAME"),this.email);
			if(ip.getField("IID").equals("5"))
				this.proper.put(ip.getField("NAME"),this.comment);
		}
		this.argString = this.toEncodedString(this.proper);
		wb.closeConnect();
		ip.closeConnect();
		
	}
	
	public HttpMessage(String wid,String topic,String name,String email,String comment)throws java.net.MalformedURLException,java.io.IOException,java.sql.SQLException,java.lang.ClassNotFoundException{
		super(wid);
		this.wid = wid;
		this.topic = topic;
		this.name = name;
		this.email = email;
		this.comment = comment;
		wb.makeConnect();
		ip.makeConnect();
		wb.getWebboard(wid);
		//super(wb.getField("NAME"));
		this.action = new URL(wb.getField("ACTION"));
		this.referer = new String(wb.getField("POST"));
		this.rp = new RequestPage(this.referer);
		ip.listInput(wid);
		while(ip.nextInput()){
			if(ip.getField("IID").equals("1"))
				this.proper.put(ip.getField("NAME"),ip.getField("VALUE"));
			if(ip.getField("IID").equals("2"))
				this.proper.put(ip.getField("NAME"),this.topic);
			if(ip.getField("IID").equals("3"))
				this.proper.put(ip.getField("NAME"),this.name);
			if(ip.getField("IID").equals("4"))
				this.proper.put(ip.getField("NAME"),this.email);
			if(ip.getField("IID").equals("5"))
				this.proper.put(ip.getField("NAME"),this.comment);
		}
		this.argString = this.toEncodedString(this.proper);
		wb.closeConnect();
		ip.closeConnect();
	}
	
	
	private String toEncodedString(Properties args){
		StringBuffer buf = new StringBuffer();
		Enumeration names = args.propertyNames();
		while(names.hasMoreElements()){
			String name = (String)names.nextElement();
			String value = args.getProperty(name);
			buf.append(URLEncoder.encode(name)+"="+URLEncoder.encode(value));
			if (names.hasMoreElements())
				buf.append("&");
		}
		return buf.toString();
	}
	
	public void run(){
		try{
			if(!this.rp.errorPage()){
				URLConnection con = this.action.openConnection();
				//Prepare for both input and output
				con.setDoInput(true);
				con.setDoOutput(true);
		
				//Turn off caching
				con.setUseCaches(false);
				//Work around a Netscape bug
				con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
				//default HTTP Header
				con.setRequestProperty("Referer",this.referer);
				con.setRequestProperty("Accept-Language","th");
				con.setRequestProperty("Accept-Encoding","gzip, deflate");
				con.setRequestProperty("User-Agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)");
				DataOutputStream out = new DataOutputStream(con.getOutputStream());
				out.writeBytes(this.argString);
				out.flush();
				out.close();
			//	HttpURLConnection huc = (HttpURLConnection)(con.getURL()).openConnection();
				con.getInputStream();
				this.finished = true;
				
			//	System.out.println(this.referer);
			//	System.out.println("Success = "+action);
			//	System.out.println(this.argString);
				System.out.println(this.getName()+" is Sent");
				this.successed = true;
				TW tw = new TW();
				
				//Add To DB
				tw.makeConnect();
				tw.addTW(this.tid,this.wid);
				tw.closeConnect();
			}else{
			//	System.out.println("Not Success = "+action);
				this.successed = false;
				this.cause = "Can't Connect to Webboard";
				this.finished = true;
			}
		}catch(Exception e){
			System.out.println("Exception Born "+e.getMessage());
		}
		
		/*
		//get Reply
		if(this.successed){
			try{
				this.wb.makeConnect();
				this.wb.getWebboard(this.wid);
				this.hm = new HTMLManage(this.wb.getField("LIST"));
				this.rep = new String(this.hm.getHref(this.topic));
				URL boardlist = new URL(this.wb.getField("LIST"));
				if(this.rep!=null){
					URL reply = new URL(boardlist,this.rep);
					System.out.println(this.getName()+" Reply is "+reply.toString());
				//	System.out.println(this.rep.);
				}
				this.wb.closeConnect();
			}catch(Exception e){}
				
		}
		*/
		/*
		if(this.successed){
			try{
				HttpReply hr = new HttpReply(this.wid,this.topic);
				this.urlreply = hr.getURL();
				System.out.println(this.urlreply);
			}catch(Exception e){}
		}
		*/
	}
	
	public boolean isSuccessed(){
		return this.successed;
	}
	
	public boolean isFinished(){
		return this.finished;
	}
	
	public String getURLReply(){
		return this.urlreply;
	}
	
	public String getWID(){
		return this.wid;
	}
	
	public void setCause(String cause){
		this.cause = cause;
	}
	
	public String getCause(){
		return this.cause;
	}
}