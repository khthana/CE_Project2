package database;

import java.sql.*;
import java.io.*;

public class Webboard implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addWebboard(String name,String action,String post,String list)throws SQLException{
		sql = "Insert Into webboard(NAME,ACTION,POST,LIST) Values('"+name+"','"+action+"','"+post+"','"+list+"')";
		statement.executeUpdate(sql);
	}
	
	public void getWebboard(String id)throws SQLException{
		sql = "Select * From webboard Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	//Edit Webboard
	public void editWebboard(String id,String name,String post,String list,String action)throws SQLException{
		sql = "UPDATE webboard SET NAME='"+name+"',POST='"+post+"',LIST='"+list+"',ACTION='"+action+"' WHERE ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 

	//Get max WID
	public int getWID()throws SQLException{
			sql ="SELECT max(ID) FROM webboard ";
			rs = statement.executeQuery(sql);	
			rs.next();
			return rs.getInt("max(ID)");
	}

	//------------------------------------------------------
	//get webboard
	public void getWebboard()throws SQLException{
			sql ="SELECT ID,name FROM webboard";
			rs = statement.executeQuery(sql);
	}

	public boolean nextWebboard()throws SQLException{
		return rs.next();
	}
}