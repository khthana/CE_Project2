import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Topic;
import database.LogFile;
import database.Members;

public class DeleteMember extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String[] mid = request.getParameterValues("mid");
		Topic tp = new Topic();
		LogFile lf = new LogFile();
		Members mm = new Members();		
		try{
			mm.makeConnect();
			lf.makeConnect();
			tp.makeConnect();
			for(int i=0;i<mid.length;i++){
				mm.deleteMembers(mid[i]);
				lf.delMemberLog(mid[i]);
				tp.deleteMemberTopic(mid[i]);
			}
			mm.closeConnect();
			lf.closeConnect();
			tp.closeConnect();	
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}
		response.sendRedirect("../project/deletemember.jsp");
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}
		