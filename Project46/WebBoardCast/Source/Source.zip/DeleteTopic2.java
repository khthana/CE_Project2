import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Topic;
import database.TW;

public class DeleteTopic2 extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
	//	PrintWriter out = response.getWriter();
		String TID = request.getParameter("id");
		try{
			TW tw = new TW();
			tw.makeConnect();
			tw.deleteTW(TID);
			tw.closeConnect();
			Topic tp = new Topic();
			tp.makeConnect();
			tp.deleteTopic(TID);
			tp.closeConnect();
		//	out.println("okokokok");
			response.sendRedirect("../project/viewtopic.jsp");

		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}