package database;

import java.sql.*;
import java.io.*;

public class Topic implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addTopic(String topic,String content,String mid)throws SQLException{
		sql = "Insert Into topic(TOPIC,CONTENT,DMYT,MID) Values('"+topic+"','"+content+"',now(),'"+mid+"')";
		statement.executeUpdate(sql);
	}
	
	public void listTopic(String mid,String order)throws SQLException{
		sql = "Select * From topic Where MID='"+mid+"' Order By "+order;
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextTopic()throws SQLException{
		return rs.next();
	}
	
	public void getTopic(String id)throws SQLException{
		sql = "Select * From topic Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public void deleteTopic(String id)throws SQLException{
		sql = "Delete From topic Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}

	public int countTopic(String mid)throws SQLException{
		sql = "Select Count(*) From topic Where MID='"+mid+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return rs.getInt("COUNT(*)");
	}
	
	public String getLastID(String mid)throws SQLException,java.io.UnsupportedEncodingException{
		sql = "Select MAX(ID) From topic Where MID='"+mid+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return this.getField("MAX(ID)");
	}
	
	public int countJoint(String mid)throws SQLException{
		sql = "SELECT COUNT(*) FROM topic t1,tw t2 WHERE t1.MID='"+mid+"' AND t1.ID=t2.TID";
		rs = statement.executeQuery(sql);
		rs.next();
		return rs.getInt("COUNT(*)");
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 

//---------------------------------------------------------------------------------
	//get all topic
	public void getTopic()throws SQLException{
		sql ="SELECT * FROM topic";
		rs = statement.executeQuery(sql);
	}
	
	public void deleteMemberTopic(String mid)throws SQLException{
		sql="DELETE FROM topic WHERE MID='"+mid+"'";
		statement.executeUpdate(sql);
	}
}