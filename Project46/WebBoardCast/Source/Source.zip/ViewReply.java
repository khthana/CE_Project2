import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.TW;
import database.LogFile;

public class ViewReply extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String tid = request.getParameter("tid");
		String wid = request.getParameter("wid");
		String size = request.getParameter("size");
		String ip = request.getRemoteAddr();
		String mid = request.getParameter("mid");
		TW tw = new TW();
		LogFile lf = new LogFile();
		try{
			lf.makeConnect();
			lf.addLogFile(mid,"View Reply (WID="+wid+",TID="+tid+")",ip);
			lf.closeConnect();
			tw.makeConnect();
			tw.getTW(tid,wid);
			String urlreply = tw.getField("REPLYURL");
			if(Integer.parseInt(tw.getField("REPLYSIZE"))<Integer.parseInt(size)){
				tw.setSize(tid,wid,size);
			}
			tw.closeConnect();
			response.sendRedirect(urlreply);
		}catch(SQLException e){
		}catch(ClassNotFoundException e){
		}
		
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}