package database;

import java.sql.*;
import java.io.*;

public class LogFile implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addLogFile(String mid,String action,String ip)throws SQLException{
		sql = "INSERT INTO logfile(MID,ACTION,DMYT,IP) VALUES('"+mid+"','"+action+"',now(),'"+ip+"')";
		statement.executeUpdate(sql);
	}
	
	public void listLogFile(String order)throws SQLException{
		sql = "SELECT * FROM logfile ORDER BY "+order;
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextLogFile()throws SQLException{
		return rs.next();
	}
	
	public void delMemberLog(String mid)throws SQLException{
		sql = "Delete From logfile Where MID='"+mid+"'";
		statement.executeUpdate(sql);
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 
}