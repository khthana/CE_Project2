import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Members;
import database.LogFile;

public class Activation extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String id = request.getParameter("id");
		String ip = request.getRemoteAddr();
		Members mm = new Members();
		LogFile lf = new LogFile();
		try{
			lf.makeConnect();
			mm.makeConnect();
			mm.getMembers(id);
			if(mm.getField("ACTIVE").equals("0")){
				lf.addLogFile(id,"Activate Acccount,Success",ip);
				lf.closeConnect();
				mm.activeMembers(id);
				mm.closeConnect();
			}else{
				lf.addLogFile(id,"Activate Acccount,But Has Activate Already",ip);
				lf.closeConnect();
				mm.closeConnect();
				response.sendRedirect("../project/error.jsp?reason=This Account Has Activate Already");
			}
			
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}
		response.sendRedirect("../project/thanks.jsp");
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);				
	}
}