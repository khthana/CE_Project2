import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Category;

public class addCategory extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		PrintWriter out = response.getWriter();
		String Category = request.getParameter("Category1");
		try{
			Category cg = new Category();
			cg.makeConnect();
			cg.addCategory(Category);
			cg.closeConnect();
			response.sendRedirect("../project/addNewCate.jsp");

		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}