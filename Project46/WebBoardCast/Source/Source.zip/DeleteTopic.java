import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Topic;
import database.TW;
import database.LogFile;

public class DeleteTopic extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String[] tid = request.getParameterValues("tid");
		String mid = request.getParameter("mid");
		String ip = request.getRemoteAddr();
		Topic tp = new Topic();
		TW tw = new TW();
		LogFile lf = new LogFile();
		try{
			lf.makeConnect();
			tw.makeConnect();
			tp.makeConnect();
			for(int i=0;i<tid.length;i++){
				tp.getTopic(tid[i]);
				lf.addLogFile(mid,"Delete Topic "+tp.getField("TOPIC"),ip);
				tp.deleteTopic(tid[i]);
				tw.deleteTW(tid[i]);
			}
			lf.closeConnect();
			tp.closeConnect();
			tw.closeConnect();
			response.sendRedirect("../project/inbox.jsp");
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}