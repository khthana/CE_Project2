import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.WSC;

public class AddsubCate extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String WID2,SCID2;
		boolean check=true;
		String webboard = request.getParameter("WID");
		String subCategory = request.getParameter("SCID");

		try{
			WSC wsc = new WSC();
			wsc.makeConnect();
			check = wsc.checkWSC(webboard,subCategory);
		
			if(check){
				wsc.closeConnect();
				response.sendRedirect("../project/error.jsp?reason=SubCategory Have This Webboard Already");

			}else{
				wsc.addWSC(webboard,subCategory);
				wsc.closeConnect();
				response.sendRedirect("../project/adminhome.jsp");
		   }
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}