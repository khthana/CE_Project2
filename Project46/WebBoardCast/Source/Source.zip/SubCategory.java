package database;

import java.sql.*;
import java.io.*;

public class SubCategory implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addSubCategory(String name)throws SQLException{
		sql = "Insert Into subcategory(NAME) Values('"+name+"')";
		statement.executeUpdate(sql);
	}
	
	public void listSubCategory(String cid)throws SQLException{
		sql = "Select * From subcategory Where CID='"+cid+"'";
		rs = statement.executeQuery(sql);
	}
	
	public void listSubCategory()throws SQLException{
		sql = "Select * From subcategory";
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextSubCategory()throws SQLException{
		return rs.next();
	}
	
	public void getSubCategory(String id)throws SQLException{
		sql = "Select * From subcategory Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public void delelteSubCategory(String id)throws SQLException{
		sql = "Delete From subcategory Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public void editSubCategory(String id,String name)throws SQLException{
		sql = "Update subcategory Set NAME='"+name+"' Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 

	// add subCategory
	public void addSubCategory(String name,String CID1)throws SQLException{
		sql = "Insert Into subcategory(NAME,CID) Values('"+name+"','"+CID1+"')";
		statement.executeUpdate(sql);
	}
}