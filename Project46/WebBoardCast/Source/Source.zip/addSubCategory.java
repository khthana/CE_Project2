import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.SubCategory;

public class addSubCategory extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String Category = request.getParameter("CID");
		String subCategory = request.getParameter("subCategory");

		try{
			SubCategory scg = new SubCategory();
			scg.makeConnect();
			scg.addSubCategory(subCategory,Category);
			scg.closeConnect();
			response.sendRedirect("../project/adminhome.jsp");

		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}