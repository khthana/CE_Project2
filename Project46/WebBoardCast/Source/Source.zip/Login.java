import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Members;
import database.LogFile;

public class Login extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
	//	String go = request.getParameter("go");
		String id ;
		String ip = request.getRemoteAddr();
		Members mm = new Members();
		LogFile lf = new LogFile();
		try{
			mm.makeConnect();
			if(!mm.accessMembers(username,password)){
				mm.closeConnect();
				lf.makeConnect();
				lf.addLogFile("0","Try To Login Username = "+username+" ,But Fail Because Username or Password Incorrect",ip);
				lf.closeConnect();
				response.sendRedirect("../project/error.jsp?reason=Username or Password Incorrect");
			}
			id = mm.getID(username);
			mm.getMembers(id);
			if(mm.getField("ACTIVE").equals("0")){
				mm.closeConnect();
				lf.makeConnect();
				lf.addLogFile(id,"Try To Login Username = "+username+" ,But Fail Because Account not Activate",ip);
				lf.closeConnect();
				response.sendRedirect("../project/error.jsp?reason=UnActivate Account");
			}else{
				Cookie cookie = new Cookie("mid",id);
				cookie.setPath("/");
				cookie.setMaxAge(-1);
				response.addCookie(cookie);
				if(mm.getField("PERMIT").equals("0")){
					response.sendRedirect("../project/inbox.jsp");
					mm.closeConnect();
				}else{
					response.sendRedirect("../project/adminhome.jsp");
					mm.closeConnect();
				}
				lf.makeConnect();
				lf.addLogFile(id,"Try To Login Username = "+username+" ,Success",ip);
				lf.closeConnect();
				
			}
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}