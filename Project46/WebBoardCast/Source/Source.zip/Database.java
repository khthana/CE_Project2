package database;

import java.sql.*;
import java.text.*;

public class Database implements java.io.Serializable {
	private  String driver = "com.mysql.jdbc.Driver";
  	private  String url = "jdbc:mysql://localhost:3306/project";
  	private  String user = "root";
  	private  String password = "6688622";
  	private  Connection connection = null;
  	private  Statement statement = null;
  	
  	//Constructor
  	public Database() throws ClassNotFoundException,SQLException {
  		try{
  			Class.forName(driver);
  			connection = DriverManager.getConnection(url,user,password);
  		}
  		catch(Exception ex){
  			ex.printStackTrace();
  		}
  	}
  	
  	public Statement createStm() throws SQLException{
  		return statement = connection.createStatement();
  	}
  	
  	public String getField(ResultSet rs,String col)throws SQLException{
  		return rs.getString(col);
  	}
  	
  	//Close Database
  	public  void closeDb() throws SQLException{
		statement.close();
		connection.close();
	}
	
	public boolean nextRecord(ResultSet re) throws SQLException{
		return re.next();
	}
}