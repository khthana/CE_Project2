package database;

import java.sql.*;
import java.io.*;

public class Category implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addCategory(String name)throws SQLException{
		sql = "Insert Into category(NAME) Values('"+name+"')";
		statement.executeUpdate(sql);
	}
	
	public void deleteCategory(String id) throws SQLException{
		sql = "Delete From category Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public void editCategory(String id,String name) throws SQLException{
		sql = "Update category Set NAME='"+name+"' Where ID='"+id+"'";
		statement.executeUpdate(sql);
	}
	
	public void listCategory(String order) throws SQLException{
		sql = "Select * From category Order By "+order;
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextCategory() throws SQLException{
		return rs.next();
	}
	
	public void getCategory(String id)throws SQLException{
		sql = "Select * From category Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	}
	
}