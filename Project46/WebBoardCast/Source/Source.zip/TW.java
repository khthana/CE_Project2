package database;

import java.sql.*;
import java.io.*;

public class TW implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addTW(String tid,String wid,String replysize,String replyurl)throws SQLException{
		sql = "Insert Into tw(TID,WID,REPLYSIZE,REPLYURL) Values('"+tid+"','"+wid+"','"+replysize+"','"+replyurl+"')";
		statement.executeUpdate(sql);
	}
	
	public void addTW(String tid,String wid)throws SQLException{
		sql = "Insert Into tw(TID,WID) Values('"+tid+"','"+wid+"')";
		statement.executeUpdate(sql);
	}
	
	public void listTW(String tid)throws SQLException{
		sql = "Select * From tw Where TID='"+tid+"'";
		rs  = statement.executeQuery(sql);
	}
	
	public boolean nextTW()throws SQLException{
		return rs.next();
	}
	
	public void getTW(String tid,String wid)throws SQLException{
		sql = "Select * From tw Where TID='"+tid+"' and WID='"+wid+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public void deleteTW(String tid,String wid)throws SQLException{
		sql = "DELETE FROM tw WHERE TID='"+tid+"' and WID='"+wid+"'";
		statement.executeUpdate(sql);
	}
	
	public void setTW(String tid,String wid,String url,String size)throws SQLException{
		sql = "UPDATE tw SET REPLYSIZE='"+size+"',REPLYURL='"+url+"' WHERE TID='"+tid+"' and WID='"+wid+"'";
		statement.executeUpdate(sql);
	}
	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 
	
	public void setSize(String tid,String wid,String size)throws SQLException{
		sql = "UPDATE tw SET REPLYSIZE='"+size+"' WHERE TID='"+tid+"' and WID='"+wid+"'";
		statement.executeUpdate(sql);
	}
	
	public void deleteTW(String tid)throws SQLException{
		sql = "DELETE FROM tw WHERE TID='"+tid+"'";
		statement.executeUpdate(sql);
	}
}