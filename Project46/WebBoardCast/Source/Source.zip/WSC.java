package database;

import java.sql.*;
import java.io.*;

public class WSC implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addWSC(String wid,String scid)throws SQLException{
		sql = "Insert Into wsc(WID,SCID) Values('"+wid+"','"+scid+"')";
		statement.executeUpdate(sql);
	}
	
	public void listWSC(String scid)throws SQLException{
		sql = "Select * From wsc Where SCID='"+scid+"'";
		rs = statement.executeQuery(sql);
	}
		
	public void listWSC(String[] scid)throws SQLException{
		StringBuffer sb = new StringBuffer();
		for(int i = 0;i<scid.length;i++){
			sb.append("SCID='");
			sb.append(scid[i]);
			sb.append("' ");
			if(i!=(scid.length-1))
				sb.append("OR ");
		}
		sql = "Select Distinct WID From wsc Where "+sb.toString();
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextWSC()throws SQLException{
		return rs.next();
	}
	
	public int countWSC(String scid)throws SQLException{
		sql = "Select Count(*) From wsc Where SCID='"+scid+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return rs.getInt("COUNT(*)");
	}
	
	//Delete Webboard & SubClassWeb
	public void deleteWSC(String wid,String scid)throws SQLException{
		sql = "DELETE FROM wsc WHERE WID='"+wid+"' and SCID='"+scid+"'";
		statement.executeUpdate(sql);
	}

	
	//Get Field
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	} 
	//---------------------------------------------------------------------

	public boolean checkWSC(String WID1,String SCID1)throws SQLException{
		sql = "Select Count(*) From wsc Where WID='"+WID1+"' and SCID='"+SCID1+"'";
		rs = statement.executeQuery(sql);
		rs.next();
		return (rs.getInt("COUNT(*)")==1);
	}

}