package http;


public class ReplyThread extends Thread{
	
	private String[] wid;
	private String tid;
	
	
	public ReplyThread(String[] wid,String tid){
		this.wid = wid;
		this.tid = tid;
	}
	
	public void run(){
		try{
			for(int i=0;i<this.wid.length;i++)
				new HttpReply(this.wid[i],this.tid).setReply();
		}catch(Exception e){}
	}
}				