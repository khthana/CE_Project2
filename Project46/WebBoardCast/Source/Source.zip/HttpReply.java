package http;

import java.io.*;
import java.net.*;
import java.util.*;
import database.Topic;
import database.Webboard;
import database.TW;

public class HttpReply{
	
	private String wid;
	private String tid;
	private String topic;
	private String urllist;
	private String reply = null;
	private URL urlreply;
	
	public HttpReply(String wid,String tid){
		this.wid = new String(wid);
		this.tid = new String(tid);
	//	this.topic = new String(topic);
		Topic tp = new Topic();
		
		Webboard wb = new Webboard();
		try{
			wb.makeConnect();
			wb.getWebboard(this.wid);
			this.urllist = new String(wb.getField("LIST"));
			wb.closeConnect();
			tp.makeConnect();
			tp.getTopic(tid);
			this.topic = tp.getField("TOPIC");
			tp.closeConnect();
		}catch(java.sql.SQLException e){}
		catch(java.lang.ClassNotFoundException e){}
		catch(java.io.UnsupportedEncodingException e){}
	}
	
	public HttpReply(String topic,String urllist,int nothing){
		this.urllist = new String(urllist);
		this.topic = new String(topic);
	}
	
	public String getURL(){
		String url = null;
		try{
			HTMLManage hm = new HTMLManage(this.urllist);
			this.reply = hm.getHref(this.topic);
			this.urlreply = new URL(new URL(this.urllist),this.reply);
			url = this.urlreply.toString();
			//System.out.println(this.urlreply.toString());
		}catch(Exception e){
			System.out.println(e.getLocalizedMessage());
		}
		return url;
	}
	
	public int getSize()throws java.net.MalformedURLException,java.io.IOException{
		int size = 0;
		try{	
			RequestPage rp = new RequestPage(this.urlreply);
			size = rp.getSize();
		}catch(Exception e){
		}
		return size;
	}
	
	public void setReply()throws java.sql.SQLException,java.net.MalformedURLException,java.io.IOException,java.lang.ClassNotFoundException{
		TW tw = new TW();
		tw.makeConnect();
		tw.setTW(this.tid,this.wid,this.getURL(),String.valueOf(this.getSize()));
		tw.closeConnect();
	}
	
}