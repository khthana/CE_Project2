import http.HTMLManage;
import http.HttpReply;
import http.HttpMessage;
import java.util.Properties;

public class TestPost {
	public static void main(String args[]){
		Properties prop = new Properties();
		String action="http://www.en.kku.ac.th/enboard/NewQuestion.asp";
		String referer="http://www.en.kku.ac.th/enboard/add.htm";
		String urllist="http://www.en.kku.ac.th/enboard/wblist.asp";
		
		String topic="Hi hello";
		
		
		
		//Topic
		prop.put("topic",topic);
		
		//Comment
		prop.put("question","Hi Nice To Meet YOu ^^");
		
		prop.put("name","arbujung");

		//Email
	//	prop.put("QEmail","roberto@thai.com");
		
		//Other
		prop.put("ptype","0");
//		prop.put("Qexpire","0");
	//	prop.put("category","dtcomm");
//		prop.put("level2","P");
//		prop.put("action","post");
//		prop.put("step","�觡�з����ҡ���� Hardware");

		try{
			HttpMessage hm = new HttpMessage(action,referer,prop);
			hm.start();
		}catch(java.io.IOException e){}
	//	}catch(java.net.MalformedURLException e){}
		try{
			Thread.sleep(10000);
		}catch(Exception e){}
	//	try{
		HttpReply hm = new HttpReply(topic,urllist,3);
		System.out.println(hm.getURL());
	//	}catch(java.net.MalformedURLException e){}
	//	catch(java.io.IOException e){}
	}
}