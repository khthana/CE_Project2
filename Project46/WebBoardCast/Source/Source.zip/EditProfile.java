import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Members;
import database.LogFile;

public class EditProfile extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String nickname = request.getParameter("nickname");
		String email = request.getParameter("email");
		String mid = request.getParameter("mid");
		String ip = request.getRemoteAddr();
		Members mm = new Members();
		LogFile lf = new LogFile();
		try{
			lf.makeConnect();
			lf.addLogFile(mid,"Edit Profile",ip);
			lf.closeConnect();
			mm.makeConnect();
			mm.editMembers(mid,firstname,lastname,nickname,email);
			mm.closeConnect();
		}catch(SQLException e){
		}catch(ClassNotFoundException e){
		}
		response.sendRedirect("../project/home.jsp");
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
	}
}	