package http;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class HTMLhandle extends HTMLEditorKit.ParserCallback {

	static public HashHTML hh;
 
 	// Constructor
  	public HTMLhandle() {
		this.hh = new HashHTML();
  	}
	
	// handleStartTag
  	public void handleStartTag(HTML.Tag tag, MutableAttributeSet attributes, int position){
		this.hh.next();
		this.hh.addTag(tag);
		this.hh.addAttrs(attributes);
  	} 
  	
  	// handleSimpleTag
  	public void handleSimpleTag(HTML.Tag tag,MutableAttributeSet attributes, int position){
		this.hh.next();
		this.hh.addTag(tag);
		this.hh.addAttrs(attributes);
	}
	// handleEndTag
  	public void handleEndTag(HTML.Tag tag, int position) {


  	}

 	// handleText
  	public void handleText(char[] text, int position) {
  		this.hh.addData(new String(text).toString());
  	} 
}