package http;
import java.util.*;
import javax.swing.text.*;
import javax.swing.text.html.*;

public class HashHTML{
	
	private Hashtable tag;
	private Hashtable attrs;
	private Hashtable data;
	private int index;
	
	//Constructor
	public HashHTML(){
		this.tag = new Hashtable();
		this.attrs = new Hashtable();
		this.data = new Hashtable();
		this.index = 0;
	}
	
	public void addTag(HTML.Tag tag){
		this.tag.put(new Integer(this.index),tag);
	}
	
	public void addAttrs(MutableAttributeSet attrs){
		this.attrs.put(new Integer(this.index),new SimpleAttributeSet(attrs));
	}
	
	public void addData(String data){
		this.data.put(new Integer(this.index),data);
	}
	
	public HTML.Tag getTag(int index){
		return (HTML.Tag)this.tag.get(new Integer(index));
	}
	
	public SimpleAttributeSet getAttrs(int index){
		return (SimpleAttributeSet)this.attrs.get(new Integer(index));
	}
	
	public String getData(int index){
		return String.valueOf(this.data.get(new Integer(index)));
	}
	
	public void next(){
		this.index++;
	}
	
	public int getIndex(){
		return this.index;
	}
}