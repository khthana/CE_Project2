import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Members;
import database.LogFile;

public class ChangePassword extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String mid = request.getParameter("mid");
		String oldpwd = request.getParameter("oldpwd");
		String newpwd = request.getParameter("newpwd");
		String renewpwd = request.getParameter("renewpwd");
		String ip = request.getRemoteAddr();
		String username;
		Members mm = new Members();
		LogFile lf = new LogFile();
		try{
			mm.makeConnect();
			mm.getMembers(mid);
			username = mm.getField("USERNAME");
			if(!mm.accessMembers(username,oldpwd)){
				mm.closeConnect();
				lf.makeConnect();
				lf.addLogFile(mid,"Try To Change Password,But Fail Because Old Password Incorrect",ip);
				lf.closeConnect();
				response.sendRedirect("../project/error.jsp?reason=Old Password Incorrect");
			}else{
				if(!newpwd.equals(renewpwd)){
					lf.makeConnect();
					lf.addLogFile(mid,"Try To Change Password,But Fail Because Password and Repassword Not Match",ip);
					lf.closeConnect();
					mm.closeConnect();
					response.sendRedirect("../project/error.jsp?reason=Password and Repassword Not Match");
				}else{
					lf.makeConnect();
					lf.addLogFile(mid,"Try To Change Password,Success",ip);
					lf.closeConnect();
					mm.changePassword(mid,newpwd);
					mm.closeConnect();
					response.sendRedirect("../project/inbox.jsp");
				}
			}
		}catch(SQLException e){
		}catch(ClassNotFoundException e){
		}
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}