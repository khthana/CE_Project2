package http;
import java.io.*;
import java.net.*; 

public class RequestPage{
	
	//Class Declaration
	private URL url;
//	private URLConnection uc;
	private HttpURLConnection huc;
	private InputStream is;
//	private InputStream is2;
	private InputStreamReader isr;
	
	//Member Declaration
	private String protocol = "http";
	private String host;
	private String page;
	private int port = 80;
	private boolean errorpage;
	private String htmlpage;
	
	
	//Constructor full version
	public RequestPage(String protocol,String host,int port,String page)throws java.net.MalformedURLException,java.io.IOException{
		this.protocol = protocol;
		this.host = host;
		this.port = port;
		this.page = page;
		this.url = new URL(this.protocol,this.host,this.port,this.page);
	//	uc = url.openConnection();
		this.huc = (HttpURLConnection)this.url.openConnection();
	}
	
	//Constructor without port number and protocal
	public RequestPage(String host,String page)throws java.net.MalformedURLException,java.io.IOException{
		this.host = host;
		this.page = page;
		this.url = new URL(this.protocol,this.host,this.port,this.page);
	//	uc = url.openConnection();
		this.huc = (HttpURLConnection)this.url.openConnection();
	}
	
	//Constructor 
	public RequestPage(String url)throws java.net.MalformedURLException,java.io.IOException{
		this.url = new URL(url);
		this.huc = (HttpURLConnection)this.url.openConnection();
	}
	
	//Constructor 
	public RequestPage(URL url)throws java.net.MalformedURLException,java.io.IOException{
		this.url = new URL(url.toString());
		this.huc = (HttpURLConnection)this.url.openConnection();
	}
	
	//Get Request Html Page
	public void request()throws java.io.IOException{
		try{
			StringBuffer sb = new StringBuffer();
			byte buffer[] = new byte[1];
			this.is = huc.getInputStream();
			this.isr = new InputStreamReader(this.is);
			while(this.is.read(buffer)!=-1){
				sb.append(new String(buffer,0,buffer.length));
			}
		//	this.errorpage = false;
			this.htmlpage = sb.toString();
		}catch(FileNotFoundException e){
			StringBuffer sb2 = new StringBuffer();
			byte buffer2[] = new byte[1];
			this.is = huc.getInputStream();
			this.isr = new InputStreamReader(this.is);
			while(this.is.read(buffer2)!=-1){
				sb2.append(new String(buffer2,0,buffer2.length));
			}
		//	this.errorpage = true;
			this.htmlpage = sb2.toString();
		}
	}
	
	//Check Error Page True or False
	public boolean errorPage()throws java.io.IOException{
		
		if(this.responseCode()==200)
			this.errorpage = false;
		else
			this.errorpage = true;
			
		return this.errorpage;
		
	}
	
	//Response Code
	private int responseCode()throws java.io.IOException{
		try{
			return this.huc.getResponseCode();
		}catch(Exception e){
			return 0;
		}
	}
	
	//Get InpuStreamReader
	public InputStreamReader toInputStreamReader()throws java.io.IOException{
		return new InputStreamReader(this.url.openStream());
	}
	
	//Get String
	public String getString(){
		return this.htmlpage;
	}
	
	public InputStream toInputStream()throws java.io.IOException{
		return this.url.openStream();
	}
	
	public void getProp()throws java.io.IOException{
		System.out.println("getContent = "+this.huc.getContent());
		System.out.println("getContentEncoding = "+this.huc.getContentEncoding());
		System.out.println("getContentLength = "+this.huc.getContentLength());
		System.out.println("getContentType = "+this.huc.getContentType());
		System.out.println("getDate = "+this.huc.getDate());
		System.out.println("toString = "+this.huc.toString());
		for(int i=0;i<10;i++)
			System.out.println("getHeaderFieldKey["+i+"] = "+this.huc.getHeaderFieldKey(i));
		for(int i=0;i<10;i++)
			System.out.println("getHeaderField["+i+"] = "+this.huc.getHeaderField(i));
	}
	
	//Get Size of Page
	public int getSize(){
		int size=0;
		size = this.huc.getContentLength();
		try{
			if(size==-1){
				this.request();
				size = this.htmlpage.length();
			}
		}catch(Exception e){}
		return size;
	}
}