package http;

import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class HTMLManage{
	
	private String url;
	private int index;
//	private HashAttr attr;
	private ParserGetter kit;
	private HTMLEditorKit.Parser parser;
	private HashHTML hh;
	private RequestPage rp;
	private InputStreamReader r;
	private HTMLEditorKit.ParserCallback callback;
	
	public HTMLManage(String url)throws java.net.MalformedURLException,java.io.IOException{
		this.url = url;
		this.kit = new ParserGetter();
		this.parser = this.kit.getParser();
		this.rp = new RequestPage(this.url);
		this.r = new InputStreamReader(this.rp.toInputStream());
		this.callback = new HTMLhandle();
		this.parser.parse(this.r, this.callback, true);
		this.hh = HTMLhandle.hh;
		this.index = this.hh.getIndex();
	}
	
	//Get Data from Begin String
	public String getData(String begin){
		StringBuffer sb = new StringBuffer();
		sb.append("["+this.url+"]<br>");
		int k=0;
		for(int i=1;i<this.index+1;i++){
			if(this.hh.getData(i)!=null)
				if(this.hh.getData(i).equals(begin))
					k=i;
		}
		for(int i=k;i<this.index+1;i++){
			if(this.hh.getTag(i).equals(HTML.Tag.BR))
				sb.append("<br>");
			if(this.hh.getTag(i).equals(HTML.Tag.TD))
				sb.append("<br>");
			if(this.hh.getTag(i).equals(HTML.Tag.TR)){
				
			//	sb.append("----------------------------");
				sb.append("<br>");
			}
			if(this.hh.getData(i)!=null)
				sb.append(this.hh.getData(i));
		}
		return sb.toString();	
	}
	
	public Vector getAttrs(String tag){
		Vector temp = new Vector();
		for(int i=1;i<this.index+1;i++){
			if(this.hh.getTag(i).toString().equals(tag)){
				temp.add(this.hh.getAttrs(i));
				Enumeration e = this.hh.getAttrs(i).getAttributeNames();
				while(e.hasMoreElements()){
					Object name = e.nextElement();
					String value = (String)hh.getAttrs(i).getAttribute(name);
					String n1 = name.toString();
					String v1 = new String(value);
					if (n1.equals(null)||v1.equals(null))
						System.out.println("Null Exception");
				//	System.out.println(n1+" = "+v1);
				}
			//	System.out.println("----------------");
			}
		}
		return temp;
	}
	
	public String getHref(String s){
		String temp = null;
		for(int i=1;i<this.index+1;i++){
			if ((this.hh.getData(i).trim().indexOf(s)>=0)||this.hh.getData(i).trim().endsWith(s)||this.hh.getData(i).trim().startsWith(s)||this.hh.getData(i).trim().equals(s)){
				System.out.println(this.hh.getData(i));
				for(int j=i; j>0;j--){
					if(this.hh.getTag(j).equals(HTML.Tag.A)){
						temp = (String)this.hh.getAttrs(j).getAttribute(HTML.Attribute.HREF);
						break;
					}
				}
				break;
			}
		}
		return temp;
	}
			

	
	public HashHTML getHashHTML(){
		return this.hh;
	}
	
	public int getIndex(){
		return this.index;
	}
}