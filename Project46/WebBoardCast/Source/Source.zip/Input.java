package database;

import java.sql.*;
import java.io.*;

public class Input implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addInput(String wid,String iid,String name,String value)throws SQLException{
		sql = "Insert Into input(WID,IID,NAME,VALUE) Values('"+wid+"','"+iid+"','"+name+"','"+value+"')";
		statement.executeUpdate(sql);
	}
	
	public void listInput(String wid)throws SQLException{
		sql = "Select * From input Where WID='"+wid+"'";
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextInput()throws SQLException{
		return rs.next();
	}
	
	public void getInput(String id)throws SQLException{
		sql = "Select * From input Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	}

	//----------------------------------------------------------------------------
	//add input in input table
	public void addInput(String topic1,String name1,String email1,String message1,int WID1)throws SQLException{
			sql ="INSERT INTO input VALUES('','"+WID1+"','2','"+topic1+"','')";
			statement.executeUpdate(sql);
			sql ="INSERT INTO input VALUES('','"+WID1+"','3','"+name1+"','')";
			statement.executeUpdate(sql);
			if(email1.length() !=0 ){
			sql ="INSERT INTO input VALUES('','"+WID1+"','4','"+email1+"','')";
				statement.executeUpdate(sql);
			}
			sql ="INSERT INTO input VALUES('','"+WID1+"','5','"+message1+"','')";
			statement.executeUpdate(sql);
	}

	//add hidden in input table
	public void addHidden(String hidden1,String value1,int WID1)throws SQLException{
			sql ="INSERT INTO input VALUES('','"+WID1+"','1','"+hidden1+"','"+value1+"')";
			statement.executeUpdate(sql);
	}
}