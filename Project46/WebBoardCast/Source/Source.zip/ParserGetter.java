package http;
import javax.swing.text.html.*;

public class ParserGetter extends HTMLEditorKit {

 	public HTMLEditorKit.Parser getParser(){
   		return super.getParser();
 	}
}