import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Input;

public class Addboard2 extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{

		int WID,SCID;
		String WID1;
		String finish = request.getParameter("submit");
		String wid = request.getParameter("wid");
		String hid = request.getParameter("hid");
		String hidv = request.getParameter("hidv");
		try{
			Input ip = new Input();
			ip.makeConnect();
			WID = Integer.parseInt(wid);

			if(finish.equals("NEXT")){
				 ip.addHidden(hid,hidv,WID);
				 ip.closeConnect();
				 response.sendRedirect("../project/addboard04.jsp?wid="+wid);
			}else{
				ip.closeConnect();
				response.sendRedirect("../project/adminhome.jsp");
			}
				
		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}