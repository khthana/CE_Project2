package database;

import java.sql.*;
import java.io.*;

public class InputType implements java.io.Serializable{
	private Database db;
	private Statement statement = null;
	private String sql;
	private ResultSet rs;
	
	//Make Connection to DB
	public void makeConnect() throws SQLException,ClassNotFoundException{
		db = new Database();
		statement = db.createStm();
	}
	
	//Close Connection
	public void closeConnect() throws SQLException{
		db.closeDb();
	}
	
	public void addInputType(String name)throws SQLException{
		sql = "Insert Into inputtype(NAME) Values('"+name+"')";
		statement.executeUpdate(sql);
	}
	
	public void listInputType(String order)throws SQLException{
		sql = "Select * From inputtype Order By "+order;
		rs = statement.executeQuery(sql);
	}
	
	public boolean nextInputType()throws SQLException{
		return rs.next();
	}
	
	public void getInputType(String id)throws SQLException{
		sql = "Select * From inputtype Where ID='"+id+"'";
		rs = statement.executeQuery(sql);
		rs.next();
	}
	
	public String getField(String s)throws SQLException,java.io.UnsupportedEncodingException{
		return new String(db.getField(rs,s).getBytes("ISO8859_1"),"WINDOWS-874").toString();
	}
	
}