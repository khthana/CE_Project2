import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.util.*;

public class SendMail implements java.io.Serializable {
	
	static private String host = "mail.kmitl.ac.th";
	static private String from = "roberto@thai.com";
	
	public SendMail(){};
	
	public static void mailTo(String to,String subject,String body)throws MessagingException{
		Properties props = System.getProperties();
		props.put("mail.smtp.host",host);
		
		Session s = Session.getDefaultInstance(props,null);
		
		MimeMessage mimeMessage = new MimeMessage(s);
		mimeMessage.setFrom(new InternetAddress(from));
		mimeMessage.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
		mimeMessage.setSubject(subject);
		mimeMessage.setSentDate(new java.util.Date());
		mimeMessage.setContent(body,"text/html; char-set=windows-874");
		mimeMessage.setText(body);

		Transport.send(mimeMessage);
	}
}