import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Members;
import database.LogFile;

public class Register extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String nickname = request.getParameter("nickname");
		String email = request.getParameter("email");
		String body = "You Username = "+username+" Password = "+password+" ";
		String active = "http://"+request.getServerName()+":"+request.getServerPort()+"/servlet/Activation?id=";
		String id;
		String ip = request.getRemoteAddr();
		
		if(password.equals(repassword)){
			try{
				LogFile lf = new LogFile();
				Members mm = new Members();
				mm.makeConnect();
				if (mm.existMembers(username)){
					mm.closeConnect();
					response.sendRedirect("../project/error.jsp?reason=Username has Already");
				}
				mm.addMembers(username,password,firstname,lastname,nickname,email);
				mm.closeConnect();
				mm.makeConnect();
				id = mm.getID(username);
				lf.makeConnect();
				lf.addLogFile(id,"Register",ip);
				lf.closeConnect();
				SendMail.mailTo(email,"Please Activate Account",body+active+id);
				response.sendRedirect("../project/index.jsp");
			}catch(SQLException e){}
			catch(ClassNotFoundException e){}
			catch(javax.mail.MessagingException e){}
		}else{
			response.sendRedirect("../project/error.jsp?reason=Password and Repassword Not Match");
		}
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}