import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import database.Webboard;
import database.Input;
import database.WSC;

public class Addboard extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{

		int WID,SCID;
		String WID1;
		String finish = request.getParameter("submit");
		String newboard = request.getParameter("newboard");
		String listurl = request.getParameter("listurl");
		String actionurl = request.getParameter("actionurl");
		String posturl = request.getParameter("posturl");
		String subCategory = request.getParameter("subCategory");
		String topic = request.getParameter("topic");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String comment = request.getParameter("comment");
		String hid1 = request.getParameter("hid1");
		String hid1v = request.getParameter("hid1v");
		try{
			WSC wsc = new WSC();
			Webboard wb = new Webboard();
			Input ip = new Input();
			wb.makeConnect();
			wb.addWebboard(newboard,actionurl,posturl,listurl);
			WID = wb.getWID();
			SCID = Integer.parseInt(subCategory);
			WID1 = String.valueOf(WID);
			wsc.makeConnect();
			wsc.addWSC(WID1,subCategory);

			ip.makeConnect();
			ip.addInput(topic,name,email,comment,WID);
			if(finish.equals("NEXT")){
				ip.addHidden(hid1,hid1v,WID);
 				wsc.closeConnect();
				ip.closeConnect();
				wb.closeConnect();
				response.sendRedirect("../project/addboard04.jsp?wid="+WID);
			}else{
 				wsc.closeConnect();
				ip.closeConnect();
				wb.closeConnect();
				response.sendRedirect("../project/adminhome.jsp");
			}


		}catch(SQLException e){}
		catch(ClassNotFoundException e){}

	//	doPost(request,response);
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		doGet(request,response);
				
	}
}