package test1;

import java.awt.*;

public class Line {
  public String s1;
  public int x1,x2;
  public int y1,y2;
    public Line() {
      x1=0;y1=0;x2=0;y2=0;
    }

    public Line(int i,int j,int k,int l) {
      x1=i;x2=j;y1=k;y2=l;
    }

    public void setLine(int i,int j,int k,int l) {
      x1=i;x2=j;y1=k;y2=l;}

    public void setStr(String s){
      s1=s;
    }


      public void drawObject(Graphics g) {
        g.drawLine(x1,x2,y1,y2);
      }
      public void drawStr(Graphics g){
       g.drawString(s1,x1,x2);
      }


}