package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.MouseEvent;

public class DrawPanel extends JPanel   implements MouseListener,MouseMotionListener {

// private Vector v  = new Vector();
 LogicStore v = new LogicStore();
Frame2In getG1 = new Frame2In();
Frame3In getG2 = new Frame3In();
 f4In getG3 = new f4In();
 checkstate check = new checkstate();



  public int s,bs;
 private boolean logiccome=false;
  public static int logicstart=0;
  private  int drawstart=0;
  public static int duble=10;
  private static int x_mouse1,x_mouse3,x_mouseMove;
  private static int x_mouseMoveSq,x_mouse1Sq,x_mouse3Sq;
  private static String HexMouseMove,HexMouseMove1,HexMouseMove3;



  public DrawPanel() {


/*   /////////////// print value of signal
vecS5.getCapacity();
int b = vecS5.getSize();
for(int i=0;i<b;i++)
{
int iPalm = vecS5.getValue(i);
  System.out.println(iPalm);
}
String str = "11110101";
MNumber mh = new MBinary(str);
MNumber mtmp = new MHex(mh.toDouble());
str = mtmp.toString();
System.out.println("mh " + mh + " " + "mtmp " + mtmp + "str " + str);*/



   addMouseListener(this);
   addMouseMotionListener(this);

//////////////////////  initial Value signal //////////////
/*  int count=0;
  do{
    try{
           v.addElement(new Logic());
    }
    catch (Exception e) {}
 count++;
  }while(count<500);

*/

    try {
      jbInit();


    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }



  protected void jbInit() throws Exception {
    this.setLayout(null);

  }

public void setLogiccome( boolean i){
     this.logiccome = i;
  }

  public void setDrawStart(int i){
       this.drawstart=i;
       System.out.println("drawstart = "+i);
       repaint();
  }
  public int getDrawStart(){
      return this.drawstart;
  }
  public void setduble(int i){
           duble = i;
  }

  public void setlogicstart(int i){
           logicstart = i;
  }
  public int getduble(){
           return duble;
  }
public int getx_mouse1Sq(){
   return this.x_mouse1Sq;
  }
public int getx_mouse3Sq(){
   return this.x_mouse3Sq;
  }

/*public int getMaxjSbar(){
       int re = v.capacity();
       return re;
  }*/
  public void incMouse(){
        x_mouse1 = x_mouse1+duble;
        x_mouse3 = x_mouse3+duble;
        System.out.println("inc x mouse"+ x_mouse1);

      }
 public void decMouse(){
        x_mouse1 = x_mouse1-duble;
        x_mouse3 = x_mouse3-duble;
      System.out.println("dec x mouse"+ x_mouse1);
      }
public String strCursor(){
      String strMouseMove = "Cursor      Sample#:"+this.x_mouseMoveSq+" Value:"+this.HexMouseMove+" 00000004 us";

      return strMouseMove;

      }
public String strMouse1(){
            String strMouseX = "X Cursor   Sample#:"+this.x_mouse1Sq+" Value:"+this.HexMouseMove1+" 00000004 us";

            return strMouseX;

          }
public String strMouse3(){
                String strMouseY = "Y Cursor   Sample#:"+this.x_mouse3Sq+" Value:"+this.HexMouseMove3+" 00000004 us";

                return strMouseY;

          }
public String strMouseXY(){
             int sum = this.x_mouse1Sq - this.x_mouse3Sq;
             int absSum = Math.abs(sum);
            String strMouseXtoY = "X to Y    Start X:"+this.x_mouse1Sq+" Stop Y :"+this.x_mouse3Sq+" Samples:"+absSum+" Time: 2 us";

          return strMouseXtoY;
          }
public void incNewPositionmouse(){
          System.out.println("duble "+this.duble);
            this.x_mouse1 = this.x_mouse1 + this.duble;
          this.x_mouse3 = this.x_mouse3 + this.duble;
          }
public void decNewPositionmouse(){
                    this.x_mouse1 = this.x_mouse1 - (this.duble/2);
                    this.x_mouse3 = this.x_mouse3 - (this.duble/2);
           }





  public  void paintComponent(Graphics g){
    super.paintComponent(g);
    int H=10;
    int wide=1;
      int W=100;
      int W2=W+(wide*duble);
    Line L = new Line();





    ///// print table jPanel1 //////
     g.setColor(SystemColor.lightGray);
        for(int i=10;i<1500;i=i+10){g.drawLine(0,i,1500,i);}
        for(int i=10;i<1500;i=i+10){g.drawLine(i,0,i,1500);}

if(check.getLogicCome()==true){

    ///// print  cursor mouse //////

    int vMax = v.getMaxV();
            if(this.x_mouseMoveSq<=vMax-1)  {

        g.setColor(SystemColor.YELLOW);
        g.drawLine(x_mouseMove,0,x_mouseMove,600);
        g.drawString("Cursor",x_mouseMove+5,15);

  }
        g.setColor(SystemColor.RED);
         g.drawLine(x_mouse1,0,x_mouse1,600);
         g.drawString("X",x_mouse1+5,30);
         g.setColor(SystemColor.BLUE);
         g.drawLine(x_mouse3,0,x_mouse3,600);
         g.drawString("Y",x_mouse3+5,30);



  ///// print signal //////
//   g.setColor(SystemColor.BLACK);
//   g.setColor(new Color(20,137,212));
try{
//int max = v.capacity();
int max = v.getMaxV();
   for(int c = logicstart;c<max;c++){


     Logic s =(Logic)v.get(c);
                for(int b=0;b<16;b++){

                  g.setColor(SystemColor.BLACK);

             if(check.getcolorWave()){
                  if(b==0){
                         g.setColor(new Color(204,0,0));
                     }else if(b==1){
                         g.setColor(new Color(204,51,153));
                     }else if(b==2){
                          g.setColor(new Color(153,51,204));
                      }else if(b==3){
                          g.setColor(new Color(51,51,204));
                        }else if(b==4){
                         g.setColor(new Color(51,153,204));
                       }else if(b==5){
                           g.setColor(new Color(0,153,153));
                         }else if(b==6){
                           g.setColor(new Color(0,102,51));
                         }else if(b==7){
                           g.setColor(new Color(0,102,153));
                         }else if(b==8){
                           g.setColor(new Color(0,153,0));
                         }else if(b==9){
                           g.setColor(new Color(153,153,51));
                         }else if(b==10){
                           g.setColor(new Color(255,153,0));
                         }else if(b==11){
                           g.setColor(new Color(255,102,204));
                         }else if(b==12){
                           g.setColor(new Color(153,102,0));
                         }else if(b==13){
                           g.setColor(new Color(153,102,204));
                         }else if(b==14){
                           g.setColor(new Color(255,102,51));
                         }else if(b==15){
                           g.setColor(new Color(204,51,0));
                       }


             }
                  int hilo = s.getIndex(b);
                      if(hilo==1){
                                  if(c>0){
                                       Logic Vbs = (Logic)v.get(c-1);
                                       int bs = Vbs.getIndex(b);
                                       if(bs==0){
                                              L.setLine(W,H,W,H+10);
                                               L.drawObject(g);
                                       }

                                  }
                                  L.setLine(W,H,W2,H);
                                  L.drawObject(g);
                              }
                      if(hilo==0){
                             H = H+10;
                             if(c>0){
                                  Logic Vbs = (Logic)v.get(c-1);
                                  int bs = Vbs.getIndex(b);
                                  if(bs==1){
                                              L.setLine(W,H,W,H-10);
                                              L.drawObject(g);
                                  }
                             }
                        L.setLine(W,H,W2,H);
                        L.drawObject(g);
                        H=H-10;

                      }
               H=H+30;
             }


   H=10;
   W=W+(wide*duble);
     W2=W2+(wide*duble);
       }


}
     catch (Exception e){}

/////////////////////////////// GROUP ///////////////////////////////////////////

//// group 1 ////
if(getG1.getEnable()==true){

       if(getG1.getColor()==1){
           g.setColor(new Color(0,0,0));
       }else if(getG1.getColor()==2){
           g.setColor(new Color(255,0,255));
       }else if(getG1.getColor()==3){
          g.setColor(new Color(0,0,255));
       }else if(getG1.getColor()==4){
         g.setColor(new Color(200,0,0));
       }

int gro=100;
int groBorder=100;

  try{

// int max = v.capacity();
int max = v.getMaxV();

 for(int c = logicstart+1;c<max;c++){
      g.drawLine(groBorder,487,groBorder+duble,487);
      g.drawLine(groBorder,503,groBorder+duble,503);

   Logic s =(Logic)v.get(c);
   Logic sov =(Logic)v.get(c-1);
           for(int b=0;b<=15;b++){
                if(getG1.getStatus(b)){

                int hilo = s.getIndex(b);
                 int hiloov = sov.getIndex(b);

                 if(hilo!=hiloov){

                            if(duble==80||duble==40){   ////// write hex group

                              String biTohex="";
                              String biTohex1="";
                              String Grouphex="";
                             for(int grovalue=15;grovalue>=0;grovalue--){

                                 if(getG1.getStatus(grovalue)){
                                   int Gvalue = s.getIndex(grovalue);
                                    biTohex1 = Integer.toHexString(Gvalue);
                                    biTohex = biTohex.concat(biTohex1);
                                  }}
          MNumber mh = new MBinary(biTohex);
          MNumber mtmp = new MHex(mh.toDouble());
          Grouphex = mtmp.toString();
                             g.drawString(Grouphex+"H",(gro+duble)+10,500);


                            }
                        L.setLine(gro+duble,487,gro+duble,503);
                        L.drawObject(g);
                                         }


                }
//
 }
  gro = gro+duble;
  groBorder = groBorder+duble;
  }





  }catch (Exception e){}
} // end group 1

//// group 2 ////
if(getG2.getEnable()==true){

g.setColor(new Color(0,0,0));

  if(getG2.getColor()==1){
          g.setColor(new Color(0,0,0));
      }else if(getG2.getColor()==2){
          g.setColor(new Color(255,0,255));
      }else if(getG2.getColor()==3){
         g.setColor(new Color(0,0,255));
      }else if(getG2.getColor()==4){
        g.setColor(new Color(200,0,0));
      }


int gro=100;
int groBorder=100;

  try{

// int max = v.capacity();
int max = v.getMaxV();

 for(int c = logicstart+1;c<max;c++){
      g.drawLine(groBorder,517,groBorder+duble,517);
      g.drawLine(groBorder,533,groBorder+duble,533);

   Logic s =(Logic)v.get(c);
   Logic sov =(Logic)v.get(c-1);
           for(int b=0;b<=15;b++){
                if(getG2.getStatus(b)){

                int hilo = s.getIndex(b);
                 int hiloov = sov.getIndex(b);

                 if(hilo!=hiloov){

                            if(duble==80||duble==40){   ////// write hex group

                              String biTohex="";
                              String biTohex1="";
                              String Grouphex="";
                             for(int grovalue=15;grovalue>=0;grovalue--){

                                 if(getG2.getStatus(grovalue)){
                                   int Gvalue = s.getIndex(grovalue);
                                    biTohex1 = Integer.toHexString(Gvalue);
                                    biTohex = biTohex.concat(biTohex1);
                                  }}
          MNumber mh = new MBinary(biTohex);
          MNumber mtmp = new MHex(mh.toDouble());
          Grouphex = mtmp.toString();
                             g.drawString(Grouphex+"H",(gro+duble)+10,530);


                            }
                        L.setLine(gro+duble,517,gro+duble,533);
                        L.drawObject(g);
                                         }


                }
//
 }
  gro = gro+duble;
  groBorder = groBorder+duble;
  }





  }catch (Exception e){}
} // end group 2

//// group 3 ////
if(getG3.getEnable()==true){

int gro=100;
int groBorder=100;

  try{

// int max = v.capacity();
int max = v.getMaxV();

 for(int c = logicstart+1;c<max;c++){
      g.drawLine(groBorder,547,groBorder+duble,547);
      g.drawLine(groBorder,563,groBorder+duble,563);

   Logic s =(Logic)v.get(c);
   Logic sov =(Logic)v.get(c-1);
           for(int b=0;b<=15;b++){
                if(getG3.getStatus(b)){

                int hilo = s.getIndex(b);
                 int hiloov = sov.getIndex(b);

                 if(hilo!=hiloov){

                            if(duble==80||duble==40){   ////// write hex group

                              String biTohex="";
                              String biTohex1="";
                              String Grouphex="";
                             for(int grovalue=15;grovalue>=0;grovalue--){

                                 if(getG3.getStatus(grovalue)){
                                   int Gvalue = s.getIndex(grovalue);
                                    biTohex1 = Integer.toHexString(Gvalue);
                                    biTohex = biTohex.concat(biTohex1);
                                  }}
          MNumber mh = new MBinary(biTohex);
          MNumber mtmp = new MHex(mh.toDouble());
          Grouphex = mtmp.toString();
                             g.drawString(Grouphex+"H",(gro+duble)+10,560);


                            }
                        L.setLine(gro+duble,547,gro+duble,563);
                        L.drawObject(g);
                                         }


                }
//
 }
  gro = gro+duble;
  groBorder = groBorder+duble;
  }





  }catch (Exception e){}
} // end group 3



}}  /// end Graphic

/////////////////////////// MOUSE EVENT ///////////////////////////////////////////
  public void mouseClicked(MouseEvent e) {

    if(check.getLogicCome()==true){

    int linier = e.getX();
    int positionSq=e.getX();
    int m = e.getModifiers();
       if(( m & InputEvent.BUTTON1_MASK)!=0){    // if mouse1 hit
                   // check siganl duble  Mouse1
                   int vMax = v.getMaxV();
if(this.x_mouseMoveSq<=vMax-1)  {

                     if(duble==10){                           // if   duble ==10
                   if(e.getX()>=100){
                   linier=linier%10;
                   if(linier<=5){linier=e.getX()-linier;}
                   else {
                   linier=10-linier;
                   linier=e.getX()+linier;}
              positionSq =  linier;
              positionSq = (positionSq-100)/10;
                   } }

                 if(duble==20){                                 // if   duble ==20
                 if(e.getX()>=100){
                 linier=linier%20;
                  if(linier<=10){linier=e.getX()-linier;}
                  else {
                   linier=20-linier;
                   linier=e.getX()+linier;}
                 positionSq =  linier;
                positionSq = (positionSq-100)/10;
                if(positionSq>0){positionSq = positionSq/2;}

                    }}

                     if(duble==40){                            // if   duble ==40
                   int a = (e.getX()-100)/40;
                   int b = (e.getX()-100)%40;
                   if(b>20){a++;}
                   linier = a*40+100;

                   positionSq =  linier;
                  positionSq = (positionSq-100)/10;
                   if(positionSq>0){positionSq = positionSq/4;}

                                              }
                    if(duble==80){                         // if   duble ==80
                    int a = (e.getX()-100)/80;
                    int b = (e.getX()-100)%80;
                    if(b>40){a++;}
                    linier = a*80+100;

                    positionSq =  linier;
               positionSq = (positionSq-100)/10;
               if(positionSq>0){positionSq = positionSq/8;}

                    }

          this.x_mouse1Sq = this.logicstart + positionSq;
          x_mouse1 = linier;
System.out.println(this.x_mouse1);



          String biTohex="";
          String biTohex1="";
          Logic s =(Logic)v.get(this.x_mouse1Sq);
                       for(int b=15;b>=0;b--){
                                    int hilo = s.getIndex(b);
                                    biTohex1 = Integer.toHexString(hilo);
                                    biTohex = biTohex.concat(biTohex1);
                                  }
          MNumber mh = new MBinary(biTohex);
          MNumber mtmp = new MHex(mh.toDouble());
          this.HexMouseMove1 = mtmp.toString();

}

}
      if(( m & InputEvent.BUTTON3_MASK)!=0){  // if mouse3 hit
        // check siganl duble   Mouse3
        int vMax = v.getMaxV();
if(this.x_mouseMoveSq<=vMax-1)  {

                 if(duble==10){                          // if   duble ==10
                 if(e.getX()>=100){
                 linier=linier%10;
                 if(linier<=5){linier=e.getX()-linier;}
                 else {
                 linier=10-linier;
                 linier=e.getX()+linier;}
              positionSq =  linier;
              positionSq = (positionSq-100)/10;
                 }}

                     if(duble==20){                   // if   duble ==20
                     if(e.getX()>=100){
                     linier=linier%20;
                     if(linier<=10){linier=e.getX()-linier;}
                     else {
                     linier=20-linier;
                     linier=e.getX()+linier;}
                   positionSq =  linier;
                positionSq = (positionSq-100)/10;
                if(positionSq>0){positionSq = positionSq/2;}

                     }}

                    if(duble==40){                     // if   duble ==40
                   int a = (e.getX()-100)/40;
                   int b = (e.getX()-100)%40;
                   if(b>20){a++;}
                   linier = a*40+100;

                   positionSq =  linier;
                  positionSq = (positionSq-100)/10;
                   if(positionSq>0){positionSq = positionSq/4;}

                           }
                  if(duble==80){                        // if   duble ==80
                 int a = (e.getX()-100)/80;
                 int b = (e.getX()-100)%80;
                  if(b>40){a++;}
                 linier = a*80+100;

                 positionSq =  linier;
               positionSq = (positionSq-100)/10;
               if(positionSq>0){positionSq = positionSq/8;}


                     }
this.x_mouse3Sq = this.logicstart + positionSq;
x_mouse3 = linier;




String biTohex="";
String biTohex1="";
Logic s =(Logic)v.get(this.x_mouse3Sq);
             for(int b=15;b>=0;b--){
                          int hilo = s.getIndex(b);
                          biTohex1 = Integer.toHexString(hilo);
                          biTohex = biTohex.concat(biTohex1);
                        }
MNumber mh = new MBinary(biTohex);
MNumber mtmp = new MHex(mh.toDouble());
this.HexMouseMove3 = mtmp.toString();

      }
        System.out.println("mouseClick 3 : "+e.getX());}
repaint();
  }
}

  public void mousePressed(MouseEvent mouseEvent) {
  }

  public void mouseReleased(MouseEvent mouseEvent) {
  }

  public void mouseEntered(MouseEvent mouseEvent) {
  }

  public void mouseExited(MouseEvent mouseEvent) {
  }

  public void mouseDragged(MouseEvent mouseEvent) {
    repaint();
  }

  public void mouseMoved(MouseEvent e) {


  if(check.getLogicCome()==true){

  int linier = e.getX();
  int positionSq=e.getX();
//  System.out.print(positionSq);

  if(duble==10){                          // if   duble ==10
                 if(e.getX()>=100){
                 linier=linier%10;
                 if(linier<=5){linier=e.getX()-linier;}
                 else {
                 linier=10-linier;
                 linier=e.getX()+linier;}
              positionSq =  linier;
              positionSq = (positionSq-100)/10;
             }}

if(duble==20){                   // if   duble ==20
                     if(e.getX()>=100){
                     linier=linier%20;
                     if(linier<=10){linier=e.getX()-linier;}
                     else {
                     linier=20-linier;
                     linier=e.getX()+linier;}
                     positionSq =  linier;
                   positionSq = (positionSq-100)/10;
                   if(positionSq>0){positionSq = positionSq/2;}
                     }}

if(duble==40){                     // if   duble ==40
                   int a = (e.getX()-100)/40;
                   int b = (e.getX()-100)%40;
                   if(b>20){a++;}
                   linier = a*40+100;

                   positionSq =  linier;
                   positionSq = (positionSq-100)/10;
                    if(positionSq>0){positionSq = positionSq/4;}

                           }
if(duble==80){                        // if   duble ==80
                 int a = (e.getX()-100)/80;
                 int b = (e.getX()-100)%80;
                  if(b>40){a++;}
                 linier = a*80+100;

                 positionSq =  linier;
                positionSq = (positionSq-100)/10;
                if(positionSq>0){positionSq = positionSq/8;}

                     }
x_mouseMove = linier;
this.x_mouseMoveSq = this.logicstart+ positionSq;
////////////////////////////////

int vMax = v.getMaxV();
 if(this.x_mouseMoveSq<=vMax-1)  {

String biTohex="";
String biTohex1="";
Logic s =(Logic)v.get(this.x_mouseMoveSq);
             for(int b=15;b>=0;b--){
                          int hilo = s.getIndex(b);
                          biTohex1 = Integer.toHexString(hilo);
                          biTohex = biTohex.concat(biTohex1);
                        }
MNumber mh = new MBinary(biTohex);
MNumber mtmp = new MHex(mh.toDouble());
this.HexMouseMove = mtmp.toString();

                                 }
////////////////////////////////

  repaint();
  }
}

  /////////////////////////// -------------------------- ///////////////////////////////////////////
}