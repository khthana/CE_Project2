package test1;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Frame2  extends JFrame {

  private ButtonGroup radioGroup;

  private  boolean enable;
  Frame2In getset = new Frame2In();
  JPanel jPanel1 = new JPanel();
  JButton jButton1 = new JButton();
  JCheckBox jCheckBox1 = new JCheckBox();
  JCheckBox jCheckBox2 = new JCheckBox();
  JCheckBox jCheckBox4 = new JCheckBox();
  JCheckBox jCheckBox3 = new JCheckBox();
  JCheckBox jCheckBox6 = new JCheckBox();
  JCheckBox jCheckBox7 = new JCheckBox();
  JCheckBox jCheckBox5 = new JCheckBox();
  JCheckBox jCheckBox8 = new JCheckBox();
  JCheckBox jCheckBox10 = new JCheckBox();
  JCheckBox jCheckBox11 = new JCheckBox();
  JCheckBox jCheckBox16 = new JCheckBox();
  JCheckBox jCheckBox15 = new JCheckBox();
  JCheckBox jCheckBox9 = new JCheckBox();
  JCheckBox jCheckBox13 = new JCheckBox();
  JCheckBox jCheckBox14 = new JCheckBox();
  JCheckBox jCheckBox12 = new JCheckBox();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JButton jButton2 = new JButton();
  JCheckBox enableG1 = new JCheckBox();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel3 = new JLabel();
  JRadioButton jRadioButton2 = new JRadioButton();
  JRadioButton jRadioButton3 = new JRadioButton();
  JRadioButton jRadioButton4 = new JRadioButton();
  JRadioButton jRadioButton5 = new JRadioButton();


/*
  public Frame2(Frame1 f){

  JDialog j;
   JCheckBox box1;
  j = new JDialog(f,"Group",true);
 j.setDefaultCloseOperation(j.DISPOSE_ON_CLOSE);
 j.getContentPane().add(

 j.setSize(300,600);
 j.setVisible(true);


  }
*/
  public Frame2() {
    initframe();
    setTitle("Bus Properties");
   setSize(300,700);
    show();


    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }


public void initframe(){
  jCheckBox1.setSelected(getset.getStatus(0));
  jCheckBox2.setSelected(getset.getStatus(1));
  jCheckBox3.setSelected(getset.getStatus(2));
  jCheckBox4.setSelected(getset.getStatus(3));
  jCheckBox5.setSelected(getset.getStatus(4));
  jCheckBox6.setSelected(getset.getStatus(5));
  jCheckBox7.setSelected(getset.getStatus(6));
  jCheckBox8.setSelected(getset.getStatus(7));
  jCheckBox9.setSelected(getset.getStatus(8));
  jCheckBox10.setSelected(getset.getStatus(9));
  jCheckBox11.setSelected(getset.getStatus(10));
  jCheckBox12.setSelected(getset.getStatus(11));
  jCheckBox13.setSelected(getset.getStatus(12));
  jCheckBox14.setSelected(getset.getStatus(13));
  jCheckBox15.setSelected(getset.getStatus(14));
  jCheckBox16.setSelected(getset.getStatus(15));
  enableG1.setSelected(getset.getEnable());
  jTextField1.setText(getset.getLabelG1());

  if(getset.getColor()==1){
         jRadioButton5.setSelected(true);
     }else if(getset.getColor()==2){
       jRadioButton2.setSelected(true);
     }else if(getset.getColor()==3){
       jRadioButton3.setSelected(true);
     }else if(getset.getColor()==4){
        jRadioButton4.setSelected(true);
     }


  }


  public void setSigname(int i,String sq){

   switch(i){
       case 0:
             jCheckBox1.setText(sq);
             break;
       case 1:
             jCheckBox2.setText(sq);
             break;
       case 2:
             jCheckBox3.setText(sq);
             break;
       case 3:
             jCheckBox4.setText(sq);
             break;
       case 4:
             jCheckBox5.setText(sq);
             break;
       case 5:
             jCheckBox6.setText(sq);
             break;
       case 6:
             jCheckBox7.setText(sq);
             break;
       case 7:
             jCheckBox8.setText(sq);
             break;
       case 8:
             jCheckBox9.setText(sq);
             break;
       case 9:
             jCheckBox10.setText(sq);
             break;
       case 10:
             jCheckBox11.setText(sq);
             break;
       case 11:
             jCheckBox12.setText(sq);
             break;
       case 12:
             jCheckBox13.setText(sq);
             break;
       case 13:
             jCheckBox14.setText(sq);
             break;
       case 14:
             jCheckBox15.setText(sq);
             break;
       case 15:
             jCheckBox16.setText(sq);
             break;
   }

  }

  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(1, 0, 379, 571));
    jPanel1.setLayout(null);
    jButton1.setBounds(new Rectangle(38, 602, 73, 25));
    jButton1.setToolTipText("");
    jButton1.setText("OK");
    jButton1.addActionListener(new Frame2_jButton1_actionAdapter(this));
    jCheckBox1.setText("jCheckBox1");
    jCheckBox1.setBounds(new Rectangle(99, 94, 141, 23));
    jCheckBox1.addActionListener(new Frame2_jCheckBox1_actionAdapter(this));
    jCheckBox2.setText("jCheckBox2");
    jCheckBox2.setBounds(new Rectangle(100, 113, 150, 23));
    jCheckBox2.addActionListener(new Frame2_jCheckBox2_actionAdapter(this));
    jCheckBox4.setBounds(new Rectangle(100, 159, 150, 23));
    jCheckBox4.addActionListener(new Frame2_jCheckBox4_actionAdapter(this));
    jCheckBox4.setText("jCheckBox2");
    jCheckBox3.setBounds(new Rectangle(100, 135, 147, 23));
    jCheckBox3.addActionListener(new Frame2_jCheckBox3_actionAdapter(this));
    jCheckBox3.setText("jCheckBox1");
    jCheckBox6.setBounds(new Rectangle(100, 207, 153, 23));
    jCheckBox6.addActionListener(new Frame2_jCheckBox6_actionAdapter(this));
    jCheckBox6.setText("jCheckBox2");
    jCheckBox7.setText("jCheckBox1");
    jCheckBox7.setBounds(new Rectangle(100, 229, 164, 23));
    jCheckBox7.addActionListener(new Frame2_jCheckBox7_actionAdapter(this));
    jCheckBox5.setBounds(new Rectangle(100, 183, 156, 23));
    jCheckBox5.addActionListener(new Frame2_jCheckBox5_actionAdapter(this));
    jCheckBox5.setText("jCheckBox1");
    jCheckBox8.setText("jCheckBox2");
    jCheckBox8.setBounds(new Rectangle(100, 253, 166, 23));
    jCheckBox8.addActionListener(new Frame2_jCheckBox8_actionAdapter(this));
    jCheckBox10.setBounds(new Rectangle(100, 300, 161, 23));
    jCheckBox10.addActionListener(new Frame2_jCheckBox10_actionAdapter(this));
    jCheckBox10.setText("jCheckBox2");
    jCheckBox11.setText("jCheckBox1");
    jCheckBox11.setBounds(new Rectangle(100, 322, 163, 23));
    jCheckBox11.addActionListener(new Frame2_jCheckBox11_actionAdapter(this));
    jCheckBox16.setBounds(new Rectangle(100, 440, 165, 23));
    jCheckBox16.addActionListener(new Frame2_jCheckBox16_actionAdapter(this));
    jCheckBox16.setText("jCheckBox2");
    jCheckBox15.setBounds(new Rectangle(100, 416, 171, 23));
    jCheckBox15.addActionListener(new Frame2_jCheckBox15_actionAdapter(this));
    jCheckBox15.setText("jCheckBox1");
    jCheckBox9.setBounds(new Rectangle(100, 276, 161, 23));
    jCheckBox9.addActionListener(new Frame2_jCheckBox9_actionAdapter(this));
    jCheckBox9.setText("jCheckBox1");
    jCheckBox13.setText("jCheckBox1");
    jCheckBox13.setBounds(new Rectangle(100, 370, 170, 23));
    jCheckBox13.addActionListener(new Frame2_jCheckBox13_actionAdapter(this));
    jCheckBox14.setText("jCheckBox2");
    jCheckBox14.setBounds(new Rectangle(100, 394, 166, 23));
    jCheckBox14.addActionListener(new Frame2_jCheckBox14_actionAdapter(this));
    jCheckBox12.setText("jCheckBox2");
    jCheckBox12.setBounds(new Rectangle(100, 346, 165, 23));
    jCheckBox12.addActionListener(new Frame2_jCheckBox12_actionAdapter(this));
    jLabel1.setText("Select Signals");
    jLabel1.setBounds(new Rectangle(37, 74, 89, 15));
    jLabel2.setText("Bus Label");
    jLabel2.setBounds(new Rectangle(38, 19, 85, 15));
    jTextField1.setBounds(new Rectangle(61, 43, 164, 21));
    jTextField1.addActionListener(new Frame2_jTextField1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(138, 601, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new Frame2_jButton2_actionAdapter(this));
    enableG1.setText("Enable");
    enableG1.setBounds(new Rectangle(34, 570, 89, 23));
    enableG1.addActionListener(new Frame2_enableG1_actionAdapter(this));
    jPanel2.setBounds(new Rectangle(223, 91, 52, 58));
    jLabel3.setText("Color Bus");
    jLabel3.setBounds(new Rectangle(31, 469, 99, 15));
    jRadioButton2.setForeground(new Color(255,0,255));
    jRadioButton2.setText("Magenta");
    jRadioButton2.setBounds(new Rectangle(98, 507, 91, 23));
    jRadioButton2.addActionListener(new Frame2_jRadioButton2_actionAdapter(this));
    jRadioButton3.setForeground(new Color(0,0,255));
    jRadioButton3.setText("Blue");
    jRadioButton3.setBounds(new Rectangle(98, 526, 91, 23));
    jRadioButton3.addActionListener(new Frame2_jRadioButton3_actionAdapter(this));
    jRadioButton4.setForeground(new Color(200,0,0));
    jRadioButton4.setText("Red");
    jRadioButton4.setBounds(new Rectangle(98, 544, 91, 23));
    jRadioButton4.addActionListener(new Frame2_jRadioButton4_actionAdapter(this));
    this.setForeground(Color.black);
    jRadioButton5.setText("Balck");
    jRadioButton5.setBounds(new Rectangle(98, 492, 89, 19));
    jRadioButton5.addActionListener(new Frame2_jRadioButton5_actionAdapter(this));
    jPanel1.add(jCheckBox15, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jCheckBox2, null);
    jPanel1.add(jCheckBox3, null);
    jPanel1.add(jCheckBox4, null);
    jPanel1.add(jCheckBox5, null);
    jPanel1.add(jCheckBox6, null);
    jPanel1.add(jCheckBox7, null);
    jPanel1.add(jCheckBox8, null);
    jPanel1.add(jCheckBox9, null);
    jPanel1.add(jCheckBox10, null);
    jPanel1.add(jCheckBox11, null);
    jPanel1.add(jCheckBox12, null);
    jPanel1.add(jCheckBox13, null);
    jPanel1.add(jCheckBox14, null);
    jPanel1.add(jCheckBox16, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jCheckBox1, null);
    jPanel1.add(jPanel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jRadioButton4, null);
    jPanel1.add(jRadioButton3, null);
    jPanel1.add(jRadioButton2, null);
    jPanel1.add(jRadioButton5, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(enableG1, null);
    this.getContentPane().add(jPanel1, null);

    radioGroup = new ButtonGroup();
    radioGroup.add(jRadioButton2);
    radioGroup.add(jRadioButton3);
    radioGroup.add(jRadioButton4);
    radioGroup.add(jRadioButton5);


  }

  void jButton1_actionPerformed(ActionEvent e) {

           //      getset.setEnable(this.enable);
                 getset.setLabelG1(jTextField1.getText());
                 this.show(false);


  }

  void jCheckBox1_actionPerformed(ActionEvent e) {
    boolean s;
    s=getset.getStatus(0);
    if(s==true){s=false;}else{s=true;}
    getset.setSq(0,s);
  }

  void jCheckBox2_actionPerformed(ActionEvent e) {
    boolean s;
       s=getset.getStatus(1);
       if(s==true){s=false;}else{s=true;}
       getset.setSq(1,s);

  }

  void jCheckBox3_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(2);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(2,s);

  }

  void jCheckBox4_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(3);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(3,s);

  }

  void jCheckBox5_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(4);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(4,s);

  }

  void jCheckBox6_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(5);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(5,s);

  }

  void jCheckBox7_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(6);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(6,s);

  }

  void jCheckBox8_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(7);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(7,s);

  }

  void jCheckBox9_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(8);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(8,s);

  }

  void jCheckBox10_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(9);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(9,s);

  }

  void jCheckBox11_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(10);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(10,s);

  }

  void jCheckBox12_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(11);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(11,s);

  }

  void jCheckBox13_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(12);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(12,s);

  }

  void jCheckBox14_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(13);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(13,s);

  }

  void jCheckBox15_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(14);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(14,s);

  }

  void jCheckBox16_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(15);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(15,s);

  }

  void enableG1_actionPerformed(ActionEvent e) {

        this.enable = getset.getEnable();
    if(this.enable==true){this.enable=false;}else{this.enable=true;}
            getset.setEnable(this.enable);
         //   System.out.println(this.enable);
  }

  void jButton2_actionPerformed(ActionEvent e) {
this.show(false);
  }

  void jTextField1_actionPerformed(ActionEvent e) {

  }

  void jRadioButton1_actionPerformed(ActionEvent e) {

           getset.setColor(1);

  }

  void jRadioButton2_actionPerformed(ActionEvent e) {
       getset.setColor(2);
  }

  void jRadioButton3_actionPerformed(ActionEvent e) {
      getset.setColor(3);
  }

  void jRadioButton4_actionPerformed(ActionEvent e) {
     getset.setColor(4);
  }

  void jRadioButton5_actionPerformed(ActionEvent e) {
          getset.setColor(1);
  }


}

class Frame2_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jButton1_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Frame2_jCheckBox1_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox1_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox1_actionPerformed(e);
  }
}

class Frame2_jCheckBox2_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox2_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox2_actionPerformed(e);
  }
}

class Frame2_jCheckBox3_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox3_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox3_actionPerformed(e);
  }
}

class Frame2_jCheckBox4_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox4_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox4_actionPerformed(e);
  }
}

class Frame2_jCheckBox5_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox5_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox5_actionPerformed(e);
  }
}

class Frame2_jCheckBox6_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox6_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox6_actionPerformed(e);
  }
}

class Frame2_jCheckBox7_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox7_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox7_actionPerformed(e);
  }
}

class Frame2_jCheckBox8_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox8_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox8_actionPerformed(e);
  }
}

class Frame2_jCheckBox9_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox9_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox9_actionPerformed(e);
  }
}

class Frame2_jCheckBox10_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox10_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox10_actionPerformed(e);
  }
}

class Frame2_jCheckBox11_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox11_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox11_actionPerformed(e);
  }
}

class Frame2_jCheckBox12_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox12_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox12_actionPerformed(e);
  }
}

class Frame2_jCheckBox13_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox13_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox13_actionPerformed(e);
  }
}

class Frame2_jCheckBox14_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox14_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox14_actionPerformed(e);
  }
}

class Frame2_jCheckBox15_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox15_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox15_actionPerformed(e);
  }
}

class Frame2_jCheckBox16_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jCheckBox16_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox16_actionPerformed(e);
  }
}

class Frame2_enableG1_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_enableG1_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.enableG1_actionPerformed(e);
  }
}

class Frame2_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jButton2_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class Frame2_jTextField1_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jTextField1_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField1_actionPerformed(e);
  }
}

class Frame2_jRadioButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jRadioButton2_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton2_actionPerformed(e);
  }
}

class Frame2_jRadioButton3_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jRadioButton3_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton3_actionPerformed(e);
  }
}

class Frame2_jRadioButton4_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jRadioButton4_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton4_actionPerformed(e);
  }
}

class Frame2_jRadioButton5_actionAdapter implements java.awt.event.ActionListener {
  Frame2 adaptee;

  Frame2_jRadioButton5_actionAdapter(Frame2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton5_actionPerformed(e);
  }
}