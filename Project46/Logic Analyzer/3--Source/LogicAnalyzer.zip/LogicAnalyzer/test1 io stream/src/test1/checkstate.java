package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class checkstate {

  private static boolean logiccome=false;
 private static boolean colorWave=false;

  public checkstate() {
  }

  public void setLogicCome(boolean i){
     this.logiccome = i;
  }
  public boolean getLogicCome(){
    return this.logiccome;
  }

  public void setcolorWave(boolean i){
      this.colorWave = i;
  }
  public boolean getcolorWave(){
      return this.colorWave;
  }

}