package test1;

import java.io.*;
import java.util.*;
import javax.comm.*;
import javax.comm.SerialPortEvent;


public class read  implements Runnable, SerialPortEventListener{

  checkstate check = new checkstate();
  LogicStore logic = new LogicStore();
  int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p;
  static CommPortIdentifier portId;
  static Enumeration portList;
  static String messageString = "Request.";
  int bitHL = 1;
//  DrawPanel draw;
//  Frame1 F1;


  InputStream inputStream;
  OutputStream outputStream;
  SerialPort serialPort;
  Thread readThread;



  public read() {


  }

public void startRead(){
    portList = CommPortIdentifier.getPortIdentifiers();

while (portList.hasMoreElements()) {
portId = (CommPortIdentifier) portList.nextElement();
if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
    if (portId.getName().equals("COM1")) {

   readPort();

    }}}
}

public void readPort(){

    try {
          serialPort = (SerialPort) portId.open("SimpleReadApp", 2000);
      } catch (PortInUseException e) {}
      try {
          inputStream = serialPort.getInputStream();
          outputStream = serialPort.getOutputStream();
      } catch (IOException e) {}
      try {
          serialPort.addEventListener(this);
       //   sent();
      } catch (TooManyListenersException e) {}
      serialPort.notifyOnDataAvailable(true);
      try {
          serialPort.setSerialPortParams(9600,
              SerialPort.DATABITS_8,
              SerialPort.STOPBITS_1,
              SerialPort.PARITY_NONE);
      } catch (UnsupportedCommOperationException e) {}
      readThread = new Thread(this);
    readThread.start();


  }

  public void sent(String i){

    try {
      System.out.println(i);
                outputStream.write(i.getBytes());
              } catch (IOException e) {}


  }

  public void run() {
    try {
           Thread.sleep(20000);
       } catch (InterruptedException e) {}

  }

  public void serialEvent(SerialPortEvent event) {

    switch(event.getEventType()) {
        case SerialPortEvent.BI:
        case SerialPortEvent.OE:
        case SerialPortEvent.FE:
        case SerialPortEvent.PE:
        case SerialPortEvent.CD:
        case SerialPortEvent.CTS:
        case SerialPortEvent.DSR:
        case SerialPortEvent.RI:
        case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
            break;
        case SerialPortEvent.DATA_AVAILABLE:
            byte[] readBuffer = new byte[8];

            try {
                while (inputStream.available() > 0) {
                    int numBytes = inputStream.read(readBuffer);
                }
                //System.out.print(new String(readBuffer));
                String strRead = new String(readBuffer);

                if(bitHL==1){

                  String aa = strRead.substring(0,1);
                  this.a = Integer.parseInt(aa);
                  String bb = strRead.substring(1,2);
                  this.b = Integer.parseInt(bb);
                  String cc = strRead.substring(2,3);
                  this.c = Integer.parseInt(cc);
                  String dd = strRead.substring(3,4);
                  this.d = Integer.parseInt(dd);
                  String ee = strRead.substring(4,5);
                  this.e = Integer.parseInt(ee);
                  String ff = strRead.substring(5,6);
                  this.f = Integer.parseInt(ff);
                  String gg = strRead.substring(6,7);
                  this.g = Integer.parseInt(gg);
                  String hh = strRead.substring(7,8);
                  this.h = Integer.parseInt(hh);

                  System.out.print("int "+this.a+" "+this.b+" "+this.c+" "+this.d+" "+this.e+" "+this.f+" "+this.g+" "+this.h+" ");

                   bitHL=2;
                }else{

                  String aa = strRead.substring(0,1);
                  this.i = Integer.parseInt(aa);
                  String bb = strRead.substring(1,2);
                  this.j = Integer.parseInt(bb);
                  String cc = strRead.substring(2,3);
                  this.k = Integer.parseInt(cc);
                  String dd = strRead.substring(3,4);
                  this.l = Integer.parseInt(dd);
                  String ee = strRead.substring(4,5);
                  this.m = Integer.parseInt(ee);
                  String ff = strRead.substring(5,6);
                  this.n= Integer.parseInt(ff);
                  String gg = strRead.substring(6,7);
                  this.o = Integer.parseInt(gg);
                  String hh = strRead.substring(7,8);
                  this.p = Integer.parseInt(hh);

                 System.out.print("int "+this.i+" "+this.j+" "+this.k+" "+this.l+" "+this.m+" "+this.n+" "+this.o+" "+this.p+" ");

                 logic.add(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);
                 check.setLogicCome(true);
      //           F1.setjSbar(logic.getMaxV());
     //            draw.repaint();

                   bitHL=1;
                }


            } catch (IOException e) {}
            break;
        }


  }
}