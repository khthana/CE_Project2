package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class search extends JFrame{

  private ButtonGroup radioGroup0,radioGroup1,radioGroup2,radioGroup3,radioGroup4,radioGroup5,radioGroup6,radioGroup7,radioGroup8,radioGroup9,radioGroup10,radioGroup11,radioGroup12,radioGroup13,radioGroup14,radioGroup15;
  private int sigb0,sigb1,sigb2,sigb3,sigb4,sigb5,sigb6,sigb7,sigb8,sigb9,sigb10,sigb11,sigb12,sigb13,sigb14,sigb15=2;
  private int startSearch=0;
  Frame1 reSearch;
  LogicStore v = new LogicStore();
  DrawPanel slideSearch = new DrawPanel();

  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel sig0 = new JLabel();
  JRadioButton jRadio0_1 = new JRadioButton();
  JRadioButton jRadio0_0 = new JRadioButton();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JRadioButton jRadio1_1 = new JRadioButton();
  JLabel sig1 = new JLabel();
  JPanel jPanel3 = new JPanel();
  JRadioButton jRadio1_0 = new JRadioButton();
  JRadioButton jRadio2_0 = new JRadioButton();
  JLabel sig2 = new JLabel();
  JRadioButton jRadio2_1 = new JRadioButton();
  JPanel jPanel4 = new JPanel();
  JRadioButton jRadio3_0 = new JRadioButton();
  JPanel jPanel5 = new JPanel();
  JRadioButton jRadio3_1 = new JRadioButton();
  JLabel sig3 = new JLabel();
  JRadioButton jRadio4_0 = new JRadioButton();
  JLabel sig4 = new JLabel();
  JRadioButton jRadio4_1 = new JRadioButton();
  JPanel jPanel6 = new JPanel();
  JRadioButton jRadio5_1 = new JRadioButton();
  JPanel jPanel7 = new JPanel();
  JRadioButton jRadio5_0 = new JRadioButton();
  JLabel sig5 = new JLabel();
  JRadioButton jRadio6_1 = new JRadioButton();
  JLabel sig6 = new JLabel();
  JPanel jPanel8 = new JPanel();
  JRadioButton jRadio6_0 = new JRadioButton();
  JRadioButton jRadio7_1 = new JRadioButton();
  JPanel jPanel9 = new JPanel();
  JLabel sig7 = new JLabel();
  JRadioButton jRadio7_0 = new JRadioButton();
  JRadioButton jRadio8_0 = new JRadioButton();
  JLabel sig8 = new JLabel();
  JRadioButton jRadio8_1 = new JRadioButton();
  JPanel jPanel10 = new JPanel();
  JRadioButton jRadio9_1 = new JRadioButton();
  JPanel jPanel11 = new JPanel();
  JRadioButton jRadio9_0 = new JRadioButton();
  JLabel sig9 = new JLabel();
  JLabel sig10 = new JLabel();
  JPanel jPanel12 = new JPanel();
  JRadioButton jRadio10_1 = new JRadioButton();
  JRadioButton jRadio10_0 = new JRadioButton();
  JPanel jPanel13 = new JPanel();
  JRadioButton jRadio11_1 = new JRadioButton();
  JRadioButton jRadio11_0 = new JRadioButton();
  JLabel sig11 = new JLabel();
  JPanel jPanel14 = new JPanel();
  JRadioButton jRadio12_1 = new JRadioButton();
  JLabel sig12 = new JLabel();
  JRadioButton jRadio12_0 = new JRadioButton();
  JRadioButton jRadio13_1 = new JRadioButton();
  JRadioButton jRadio13_0 = new JRadioButton();
  JPanel jPanel15 = new JPanel();
  JLabel sig13 = new JLabel();
  JRadioButton jRadio14_0 = new JRadioButton();
  JRadioButton jRadio14_1 = new JRadioButton();
  JLabel sig14 = new JLabel();
  JPanel jPanel16 = new JPanel();
  JPanel jPanel17 = new JPanel();
  JRadioButton jRadio15_0 = new JRadioButton();
  JLabel sig15 = new JLabel();
  JRadioButton jRadio15_1 = new JRadioButton();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JRadioButton jRadio0_2 = new JRadioButton();
  JLabel jLabel2 = new JLabel();
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadio3_2 = new JRadioButton();
  JRadioButton jRadio4_2 = new JRadioButton();
  JRadioButton jRadio5_2 = new JRadioButton();
  JRadioButton jRadio6_2 = new JRadioButton();
  JRadioButton jRadio1_2 = new JRadioButton();
  JRadioButton jRadio7_2 = new JRadioButton();
  JRadioButton jRadio2_2 = new JRadioButton();
  JRadioButton jRadio8_2 = new JRadioButton();
  JRadioButton jRadio9_2 = new JRadioButton();
  JRadioButton jRadio10_2 = new JRadioButton();
  JRadioButton jRadio11_2 = new JRadioButton();
  JRadioButton jRadio12_2 = new JRadioButton();
  JRadioButton jRadio13_2 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  JRadioButton jRadio15_2 = new JRadioButton();
  JRadioButton jRadio14_2 = new JRadioButton();

  public search(Frame1 f) {
    this.sigb0=2;this.sigb1=2;this.sigb2=2;this.sigb3=2; this.sigb4=2;this.sigb5=2; this.sigb6=2; this.sigb7=2;this.sigb8=2;this.sigb9=2;this.sigb10=2;this.sigb11=2;this.sigb12=2;this.sigb13=2; this.sigb14=2; this.sigb15=2;
    setTitle("Search for Pattern");
    setSize(300,600);
    reSearch = f;
    show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }

  public void setSigname(int i,String sq){

     switch(i){
         case 0:
               sig0.setText(sq);
               break;
         case 1:
               sig1.setText(sq);
               break;
         case 2:
               sig2.setText(sq);
               break;
         case 3:
               sig3.setText(sq);
               break;
         case 4:
               sig4.setText(sq);
               break;
         case 5:
               sig5.setText(sq);
               break;
         case 6:
               sig6.setText(sq);
               break;
         case 7:
               sig7.setText(sq);
               break;
         case 8:
               sig8.setText(sq);
               break;
         case 9:
               sig9.setText(sq);
               break;
         case 10:
               sig10.setText(sq);
               break;
         case 11:
               sig11.setText(sq);
               break;
         case 12:
               sig12.setText(sq);
               break;
         case 13:
               sig13.setText(sq);
               break;
         case 14:
               sig14.setText(sq);
               break;
         case 15:
               sig15.setText(sq);
               break;
     }

    }


  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(107, 100, 10, 10));
    jPanel1.setLayout(null);
    jLabel1.setText("Choose pattern to search");
    jLabel1.setBounds(new Rectangle(28, 24, 149, 15));
    sig0.setText("Sig0");
    sig0.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio0_1.setText("");
    jRadio0_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio0_1.addActionListener(new search_jRadio0_1_actionAdapter(this));
    jRadio0_0.setText("");
    jRadio0_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio0_0.addActionListener(new search_jRadio0_0_actionAdapter(this));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(35, 62, 231, 25));
    jPanel2.setLayout(null);
    jLabel3.setText("0");
    jLabel3.setBounds(new Rectangle(198, 45, 10, 15));
    jLabel4.setText("1");
    jLabel4.setBounds(new Rectangle(219, 44, 12, 15));
    jRadio1_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio1_1.addActionListener(new search_jRadio1_1_actionAdapter(this));
    jRadio1_1.setText("");
    sig1.setBounds(new Rectangle(8, 5, 103, 15));
    sig1.setText("Sig1");
    jPanel3.setLayout(null);
    jPanel3.setBounds(new Rectangle(35, 88, 231, 25));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jRadio1_0.setText("");
    jRadio1_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio1_0.addActionListener(new search_jRadio1_0_actionAdapter(this));
    jRadio2_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio2_0.addActionListener(new search_jRadio2_0_actionAdapter(this));
    jRadio2_0.setText("");
    sig2.setText("Sig2");
    sig2.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio2_1.setText("");
    jRadio2_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio2_1.addActionListener(new search_jRadio2_1_actionAdapter(this));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setBounds(new Rectangle(35, 114, 231, 25));
    jPanel4.setLayout(null);
    jRadio3_0.setText("");
    jRadio3_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio3_0.addActionListener(new search_jRadio3_0_actionAdapter(this));
    jPanel5.setLayout(null);
    jPanel5.setBounds(new Rectangle(35, 140, 231, 25));
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    jRadio3_1.setText("");
    jRadio3_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio3_1.addActionListener(new search_jRadio3_1_actionAdapter(this));
    sig3.setText("Sig3");
    sig3.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio4_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio4_0.addActionListener(new search_jRadio4_0_actionAdapter(this));
    jRadio4_0.setText("");
    sig4.setBounds(new Rectangle(8, 5, 103, 15));
    sig4.setText("Sig4");
    jRadio4_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio4_1.addActionListener(new search_jRadio4_1_actionAdapter(this));
    jRadio4_1.setText("");
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    jPanel6.setBounds(new Rectangle(35, 166, 230, 25));
    jPanel6.setLayout(null);
    jRadio5_1.setText("");
    jRadio5_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio5_1.addActionListener(new search_jRadio5_1_actionAdapter(this));
    jPanel7.setLayout(null);
    jPanel7.setBounds(new Rectangle(35, 192, 230, 25));
    jPanel7.setBorder(BorderFactory.createEtchedBorder());
    jRadio5_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio5_0.addActionListener(new search_jRadio5_0_actionAdapter(this));
    jRadio5_0.setText("");
    sig5.setBounds(new Rectangle(8, 5, 103, 15));
    sig5.setText("Sig5");
    jRadio6_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio6_1.addActionListener(new search_jRadio6_1_actionAdapter(this));
    jRadio6_1.setText("");
    sig6.setText("Sig6");
    sig6.setBounds(new Rectangle(8, 5, 103, 15));
    jPanel8.setBorder(BorderFactory.createEtchedBorder());
    jPanel8.setBounds(new Rectangle(35, 218, 230, 25));
    jPanel8.setLayout(null);
    jRadio6_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio6_0.addActionListener(new search_jRadio6_0_actionAdapter(this));
    jRadio6_0.setText("");
    jRadio7_1.setText("");
    jRadio7_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio7_1.addActionListener(new search_jRadio7_1_actionAdapter(this));
    jPanel9.setLayout(null);
    jPanel9.setBounds(new Rectangle(35, 244, 230, 25));
    jPanel9.setBorder(BorderFactory.createEtchedBorder());
    sig7.setText("Sig7");
    sig7.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio7_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio7_0.addActionListener(new search_jRadio7_0_actionAdapter(this));
    jRadio7_0.setText("");
    jRadio8_0.setText("");
    jRadio8_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio8_0.addActionListener(new search_jRadio8_0_actionAdapter(this));
    sig8.setBounds(new Rectangle(8, 5, 103, 15));
    sig8.setText("Sig8");
    jRadio8_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio8_1.addActionListener(new search_jRadio8_1_actionAdapter(this));
    jRadio8_1.setText("");
    jPanel10.setBorder(BorderFactory.createEtchedBorder());
    jPanel10.setBounds(new Rectangle(35, 270, 230, 25));
    jPanel10.setLayout(null);
    jRadio9_1.setText("");
    jRadio9_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio9_1.addActionListener(new search_jRadio9_1_actionAdapter(this));
    jPanel11.setLayout(null);
    jPanel11.setBounds(new Rectangle(35, 296, 230, 25));
    jPanel11.setBorder(BorderFactory.createEtchedBorder());
    jRadio9_0.setText("");
    jRadio9_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio9_0.addActionListener(new search_jRadio9_0_actionAdapter(this));
    sig9.setBounds(new Rectangle(8, 5, 103, 15));
    sig9.setText("Sig9");
    sig10.setText("Sig10");
    sig10.setBounds(new Rectangle(8, 5, 103, 15));
    jPanel12.setBorder(BorderFactory.createEtchedBorder());
    jPanel12.setBounds(new Rectangle(35, 322, 230, 25));
    jPanel12.setLayout(null);
    jRadio10_1.setText("");
    jRadio10_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio10_1.addActionListener(new search_jRadio10_1_actionAdapter(this));
    jRadio10_0.setText("");
    jRadio10_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio10_0.addActionListener(new search_jRadio10_0_actionAdapter(this));
    jPanel13.setLayout(null);
    jPanel13.setBounds(new Rectangle(35, 348, 230, 25));
    jPanel13.setBorder(BorderFactory.createEtchedBorder());
    jRadio11_1.setText("");
    jRadio11_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio11_1.addActionListener(new search_jRadio11_1_actionAdapter(this));
    jRadio11_0.setText("");
    jRadio11_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio11_0.addActionListener(new search_jRadio11_0_actionAdapter(this));
    sig11.setText("Sig11");
    sig11.setBounds(new Rectangle(8, 5, 103, 15));
    jPanel14.setBorder(BorderFactory.createEtchedBorder());
    jPanel14.setBounds(new Rectangle(35, 374, 230, 25));
    jPanel14.setLayout(null);
    jRadio12_1.setText("");
    jRadio12_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio12_1.addActionListener(new search_jRadio12_1_actionAdapter(this));
    sig12.setText("Sig12");
    sig12.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio12_0.setText("");
    jRadio12_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio12_0.addActionListener(new search_jRadio12_0_actionAdapter(this));
    jRadio13_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio13_1.addActionListener(new search_jRadio13_1_actionAdapter(this));
    jRadio13_1.setText("");
    jRadio13_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio13_0.addActionListener(new search_jRadio13_0_actionAdapter(this));
    jRadio13_0.setText("");
    jPanel15.setLayout(null);
    jPanel15.setBounds(new Rectangle(35, 400, 230, 25));
    jPanel15.setBorder(BorderFactory.createEtchedBorder());
    sig13.setText("Sig13");
    sig13.setBounds(new Rectangle(8, 5, 103, 15));
    jRadio14_0.setText("");
    jRadio14_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio14_0.addActionListener(new search_jRadio14_0_actionAdapter(this));
    jRadio14_1.setText("");
    jRadio14_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio14_1.addActionListener(new search_jRadio14_1_actionAdapter(this));
    sig14.setBounds(new Rectangle(8, 5, 103, 15));
    sig14.setText("Sig14");
    jPanel16.setBorder(BorderFactory.createEtchedBorder());
    jPanel16.setBounds(new Rectangle(35, 426, 229, 25));
    jPanel16.setLayout(null);
    jPanel17.setLayout(null);
    jPanel17.setBounds(new Rectangle(35, 452, 229, 25));
    jPanel17.setBorder(BorderFactory.createEtchedBorder());
    jRadio15_0.setText("");
    jRadio15_0.setBounds(new Rectangle(157, 2, 21, 21));
    jRadio15_0.addActionListener(new search_jRadio15_0_actionAdapter(this));
    sig15.setBounds(new Rectangle(8, 5, 103, 15));
    sig15.setText("Sig15");
    jRadio15_1.setText("");
    jRadio15_1.setBounds(new Rectangle(177, 2, 21, 21));
    jRadio15_1.addActionListener(new search_jRadio15_1_actionAdapter(this));
    jButton1.setBounds(new Rectangle(103, 502, 92, 25));
    jButton1.setText("Search");
    jButton1.addActionListener(new search_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(199, 502, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new search_jButton2_actionAdapter(this));
    jRadio0_2.setSelected(true);
    jRadio0_2.setText("");
    jRadio0_2.setBounds(new Rectangle(207, 2, 21, 19));
    jRadio0_2.addActionListener(new search_jRadio0_2_actionAdapter(this));
    jLabel2.setText("don\'t care");
    jLabel2.setBounds(new Rectangle(233, 44, 82, 15));
    jRadio1_2.setText("jRadioButton1");
    jRadio1_2.setBounds(new Rectangle(267, 139, 91, 23));
    jRadio3_2.setSelected(true);
    jRadio3_2.setText("");
    jRadio3_2.setBounds(new Rectangle(207, 4, 18, 16));
    jRadio3_2.addActionListener(new search_jRadio3_2_actionAdapter(this));
    jRadio4_2.setSelected(true);
    jRadio4_2.setText("");
    jRadio4_2.setBounds(new Rectangle(207, 3, 19, 17));
    jRadio4_2.addActionListener(new search_jRadio4_2_actionAdapter(this));
    jRadio5_2.setSelected(true);
    jRadio5_2.setText("");
    jRadio5_2.setBounds(new Rectangle(207, 2, 21, 19));
    jRadio5_2.addActionListener(new search_jRadio5_2_actionAdapter(this));
    jRadio6_2.setSelected(true);
    jRadio6_2.setText("");
    jRadio6_2.setBounds(new Rectangle(207, 4, 19, 17));
    jRadio6_2.addActionListener(new search_jRadio6_2_actionAdapter(this));
    jRadio1_2.setSelected(true);
    jRadio1_2.setText("");
    jRadio1_2.setBounds(new Rectangle(206, 4, 20, 18));
    jRadio1_2.addActionListener(new search_jRadio1_2_actionAdapter(this));
    jRadio7_2.setSelected(true);
    jRadio7_2.setText("");
    jRadio7_2.setBounds(new Rectangle(207, 2, 18, 20));
    jRadio7_2.addActionListener(new search_jRadio7_2_actionAdapter(this));
    jRadio2_2.setSelected(true);
    jRadio2_2.setText("");
    jRadio2_2.setBounds(new Rectangle(207, 3, 19, 16));
    jRadio2_2.addActionListener(new search_jRadio2_2_actionAdapter(this));
    jRadio8_2.setSelected(true);
    jRadio8_2.setText("");
    jRadio8_2.setBounds(new Rectangle(207, 3, 21, 18));
    jRadio8_2.addActionListener(new search_jRadio8_2_actionAdapter(this));
    jRadio9_2.setSelected(true);
    jRadio9_2.setText("");
    jRadio9_2.setBounds(new Rectangle(207, 3, 18, 18));
    jRadio9_2.addActionListener(new search_jRadio9_2_actionAdapter(this));
    jRadio10_2.setSelected(true);
    jRadio10_2.setText("");
    jRadio10_2.setBounds(new Rectangle(207, 2, 20, 21));
    jRadio10_2.addActionListener(new search_jRadio10_2_actionAdapter(this));
    jRadio11_2.setFont(new java.awt.Font("Dialog", 0, 11));
    jRadio11_2.setSelected(true);
    jRadio11_2.setText("");
    jRadio11_2.setBounds(new Rectangle(207, 2, 19, 18));
    jRadio11_2.addActionListener(new search_jRadio11_2_actionAdapter(this));
    jRadio12_2.setSelected(true);
    jRadio12_2.setText("");
    jRadio12_2.setBounds(new Rectangle(207, 3, 20, 18));
    jRadio12_2.addActionListener(new search_jRadio12_2_actionAdapter(this));
    jRadio13_2.setSelected(true);
    jRadio13_2.setText("");
    jRadio13_2.setBounds(new Rectangle(207, 2, 20, 19));
    jRadio13_2.addActionListener(new search_jRadio13_2_actionAdapter(this));
    jRadio14_2.setText("jRadioButton2");
    jRadio14_2.setBounds(new Rectangle(223, 18, 91, 23));
    jRadio15_2.setSelected(true);
    jRadio15_2.setText("");
    jRadio15_2.setBounds(new Rectangle(207, 3, 20, 19));
    jRadio15_2.addActionListener(new search_jRadio15_2_actionAdapter(this));
    jRadio14_2.setSelected(true);
    jRadio14_2.setText("");
    jRadio14_2.setBounds(new Rectangle(207, 4, 18, 16));
    jRadio14_2.addActionListener(new search_jRadio14_2_actionAdapter(this));
    jPanel3.add(sig1, null);
    jPanel3.add(jRadio1_1, null);
    jPanel3.add(jRadio1_0, null);
    jPanel3.add(jRadio1_2, null);
    this.getContentPane().add(jPanel4, null);
    jPanel3.add(jRadio1_2, null);
    jPanel2.add(sig0, null);
    jPanel2.add(jRadio0_1, null);
    jPanel2.add(jRadio0_0, null);
    jPanel2.add(jRadio0_2, null);
    this.getContentPane().add(jPanel6, null);
    this.getContentPane().add(jLabel1, null);
    jPanel5.add(sig3, null);
    jPanel5.add(jRadio3_1, null);
    jPanel5.add(jRadio3_0, null);
    jPanel5.add(jRadio3_2, null);
    this.getContentPane().add(jPanel17, null);
    jPanel16.add(sig14, null);
    jPanel16.add(jRadio14_1, null);
    jPanel16.add(jRadio14_0, null);
    jPanel16.add(jRadio14_2, null);
    this.getContentPane().add(jPanel5, null);
    jPanel4.add(jRadio2_1, null);
    jPanel4.add(jRadio2_0, null);
    jPanel4.add(sig2, null);
    jPanel4.add(jRadio2_2, null);
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jPanel10, null);
    jPanel6.add(sig4, null);
    jPanel6.add(jRadio4_1, null);
    jPanel6.add(jRadio4_0, null);
    jPanel6.add(jRadio4_2, null);
    this.getContentPane().add(jPanel7, null);
    jPanel7.add(sig5, null);
    jPanel7.add(jRadio5_1, null);
    jPanel7.add(jRadio5_0, null);
    jPanel7.add(jRadio5_2, null);
    this.getContentPane().add(jPanel8, null);
    jPanel8.add(sig6, null);
    jPanel8.add(jRadio6_1, null);
    jPanel8.add(jRadio6_0, null);
    jPanel8.add(jRadio6_2, null);
    this.getContentPane().add(jPanel9, null);
    jPanel9.add(sig7, null);
    jPanel9.add(jRadio7_1, null);
    jPanel9.add(jRadio7_0, null);
    jPanel9.add(jRadio7_2, null);
    this.getContentPane().add(jLabel4, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jPanel3, null);
    jPanel10.add(sig8, null);
    jPanel10.add(jRadio8_1, null);
    jPanel10.add(jRadio8_0, null);
    jPanel10.add(jRadio8_2, null);
    this.getContentPane().add(jPanel11, null);
    jPanel11.add(sig9, null);
    jPanel11.add(jRadio9_1, null);
    jPanel11.add(jRadio9_0, null);
    jPanel11.add(jRadio9_2, null);
    this.getContentPane().add(jPanel12, null);
    jPanel12.add(sig10, null);
    jPanel12.add(jRadio10_1, null);
    jPanel12.add(jRadio10_0, null);
    jPanel12.add(jRadio10_2, null);
    this.getContentPane().add(jPanel13, null);
    jPanel13.add(sig11, null);
    jPanel13.add(jRadio11_1, null);
    jPanel13.add(jRadio11_0, null);
    jPanel13.add(jRadio11_2, null);
    this.getContentPane().add(jPanel14, null);
    jPanel14.add(sig12, null);
    jPanel14.add(jRadio12_1, null);
    jPanel14.add(jRadio12_0, null);
    jPanel14.add(jRadio12_2, null);
    this.getContentPane().add(jPanel15, null);
    jPanel15.add(sig13, null);
    jPanel15.add(jRadio13_1, null);
    jPanel15.add(jRadio13_0, null);
    jPanel15.add(jRadio13_2, null);
    this.getContentPane().add(jPanel16, null);
    jPanel17.add(sig15, null);
    jPanel17.add(jRadio15_1, null);
    jPanel17.add(jRadio15_0, null);
    jPanel17.add(jRadio15_2, null);
    this.getContentPane().add(jPanel2, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);


    radioGroup0 = new ButtonGroup();
    radioGroup0.add(jRadio0_0);
    radioGroup0.add(jRadio0_1);
    radioGroup0.add(jRadio0_2);
    radioGroup1 = new ButtonGroup();
    radioGroup1.add(jRadio1_0);
    radioGroup1.add(jRadio1_1);
    radioGroup1.add(jRadio1_2);
    radioGroup2 = new ButtonGroup();
    radioGroup2.add(jRadio2_0);
    radioGroup2.add(jRadio2_1);
    radioGroup2.add(jRadio2_2);
    radioGroup3 = new ButtonGroup();
    radioGroup3.add(jRadio3_0);
    radioGroup3.add(jRadio3_1);
    radioGroup3.add(jRadio3_2);
    radioGroup4 = new ButtonGroup();
    radioGroup4.add(jRadio4_0);
    radioGroup4.add(jRadio4_1);
    radioGroup4.add(jRadio4_2);
    radioGroup5 = new ButtonGroup();
    radioGroup5.add(jRadio5_0);
    radioGroup5.add(jRadio5_1);
    radioGroup5.add(jRadio5_2);
    radioGroup6 = new ButtonGroup();
    radioGroup6.add(jRadio6_0);
    radioGroup6.add(jRadio6_1);
    radioGroup6.add(jRadio6_2);
    radioGroup7 = new ButtonGroup();
    radioGroup7.add(jRadio7_0);
    radioGroup7.add(jRadio7_1);
    radioGroup7.add(jRadio7_2);
    radioGroup8 = new ButtonGroup();
    radioGroup8.add(jRadio8_0);
    radioGroup8.add(jRadio8_1);
    radioGroup8.add(jRadio8_2);
    radioGroup9 = new ButtonGroup();
    radioGroup9.add(jRadio9_0);
    radioGroup9.add(jRadio9_1);
    radioGroup9.add(jRadio9_2);
    radioGroup10 = new ButtonGroup();
    radioGroup10.add(jRadio10_0);
    radioGroup10.add(jRadio10_1);
    radioGroup10.add(jRadio10_2);
    radioGroup11 = new ButtonGroup();
    radioGroup11.add(jRadio11_0);
    radioGroup11.add(jRadio11_1);
    radioGroup11.add(jRadio11_2);
    radioGroup12 = new ButtonGroup();
    radioGroup12.add(jRadio12_0);
    radioGroup12.add(jRadio12_1);
    radioGroup12.add(jRadio12_2);
    radioGroup13 = new ButtonGroup();
    radioGroup13.add(jRadio13_0);
    radioGroup13.add(jRadio13_1);
    radioGroup13.add(jRadio13_2);
    radioGroup14 = new ButtonGroup();
    radioGroup14.add(jRadio14_0);
    radioGroup14.add(jRadio14_1);
    radioGroup14.add(jRadio14_2);
    radioGroup15 = new ButtonGroup();
    radioGroup15.add(jRadio15_0);
    radioGroup15.add(jRadio15_1);
    radioGroup15.add(jRadio15_2);

  }

 public void checkSearch(){

   try{
     int max = v.getMaxV();

     for(int c = this.startSearch;c<max;c++){
System.out.println("conti "+c);
          Logic s =(Logic)v.get(c);

                                   if(s.getIndex(0)==this.sigb0||this.sigb0==2){
                                      if(s.getIndex(1)==this.sigb1||this.sigb1==2){
                                         if(s.getIndex(2)==this.sigb2||this.sigb2==2){
                                           if(s.getIndex(3)==this.sigb3||this.sigb3==2){
                                             if(s.getIndex(4)==this.sigb4||this.sigb4==2){
                                               if(s.getIndex(5)==this.sigb5||this.sigb5==2){
                                                 if(s.getIndex(6)==this.sigb6||this.sigb6==2){
                                                   if(s.getIndex(7)==this.sigb7||this.sigb7==2){
                                                     if(s.getIndex(8)==this.sigb8||this.sigb8==2){
                                                       if(s.getIndex(9)==this.sigb9||this.sigb9==2){
                                                         if(s.getIndex(10)==this.sigb10||this.sigb10==2){
                                                           if(s.getIndex(11)==this.sigb11||this.sigb11==2){
                                                             if(s.getIndex(12)==this.sigb12||this.sigb12==2){
                                                               if(s.getIndex(13)==this.sigb13||this.sigb13==2){
                                                                 if(s.getIndex(14)==this.sigb14||this.sigb14==2){
                                                                   if(s.getIndex(15)==this.sigb15||this.sigb15==2){

                                                                     //this.startSearch = c;
                                                                     //System.out.println("search ^_^ "+startSearch);
                                                                     this.startSearch = c+1;
                                                                        reSearch.setjSbar(this.startSearch-1);
                                                                        System.out.println("search ^_^ "+startSearch);
                                                                        System.out.println("Max ^_^ "+max);
                                                            //   slideSearch.setDrawStart(this.startSearch);
                                                                         break;

                                                                   }
                                                                 }
                                                               }
                                                             }
                                                           }
                                                         }
                                                       }
                                                     }
                                                   }
                                                 }
                                               }
                                             }
                                           }
                                         }
                                       }
                                     }

                                     if(c==max-1){
                                           JOptionPane.showMessageDialog(null,"Finished searching the data","Search message",JOptionPane.INFORMATION_MESSAGE);
                                                            }

                                                  }


     }
          catch (Exception e){
          e.printStackTrace();
          }

 }

  void jButton2_actionPerformed(ActionEvent e) {
       this.show(false);
  }

  void jRadio0_0_actionPerformed(ActionEvent e) {
        this.sigb0=0;
        this.startSearch=0;
  }

  void jRadio0_1_actionPerformed(ActionEvent e) {
     this.sigb0=1;
     this.startSearch=0;
  }

  void jRadio1_0_actionPerformed(ActionEvent e) {
this.sigb1=0;
    this.startSearch=0;
  }

  void jRadio1_1_actionPerformed(ActionEvent e) {
this.sigb1=1;
    this.startSearch=0;
  }

  void jRadio2_0_actionPerformed(ActionEvent e) {
this.sigb2=0;
    this.startSearch=0;
  }

  void jRadio2_1_actionPerformed(ActionEvent e) {
this.sigb2=1;
    this.startSearch=0;
  }

  void jRadio3_0_actionPerformed(ActionEvent e) {
this.sigb3=0;
    this.startSearch=0;
  }

  void jRadio3_1_actionPerformed(ActionEvent e) {
this.sigb3=1;
    this.startSearch=0;
  }

  void jRadio4_0_actionPerformed(ActionEvent e) {
this.sigb4=0;
    this.startSearch=0;
  }

  void jRadio4_1_actionPerformed(ActionEvent e) {
this.sigb4=1;
    this.startSearch=0;
  }

  void jRadio5_0_actionPerformed(ActionEvent e) {
this.sigb5=0;
    this.startSearch=0;
  }

  void jRadio5_1_actionPerformed(ActionEvent e) {
this.sigb5=1;
    this.startSearch=0;
  }

  void jRadio6_0_actionPerformed(ActionEvent e) {
this.sigb6=0;
    this.startSearch=0;
  }

  void jRadio6_1_actionPerformed(ActionEvent e) {
this.sigb6=1;
    this.startSearch=0;
  }

  void jRadio7_0_actionPerformed(ActionEvent e) {
this.sigb7=0;
    this.startSearch=0;
  }

  void jRadio7_1_actionPerformed(ActionEvent e) {
this.sigb7=1;
    this.startSearch=0;
  }

  void jRadio8_0_actionPerformed(ActionEvent e) {
this.sigb8=0;
    this.startSearch=0;
  }

  void jRadio8_1_actionPerformed(ActionEvent e) {
this.sigb8=1;
    this.startSearch=0;
  }

  void jRadio9_0_actionPerformed(ActionEvent e) {
this.sigb9=0;
    this.startSearch=0;
  }

  void jRadio9_1_actionPerformed(ActionEvent e) {
this.sigb9=1;
    this.startSearch=0;
  }

  void jRadio10_0_actionPerformed(ActionEvent e) {
this.sigb10=0;
    this.startSearch=0;
  }

  void jRadio10_1_actionPerformed(ActionEvent e) {
this.sigb10=1;
    this.startSearch=0;
  }

  void jRadio11_0_actionPerformed(ActionEvent e) {
this.sigb11=0;
    this.startSearch=0;
  }

  void jRadio11_1_actionPerformed(ActionEvent e) {
this.sigb11=1;
    this.startSearch=0;
  }

  void jRadio12_0_actionPerformed(ActionEvent e) {
this.sigb12=0;
    this.startSearch=0;
  }

  void jRadio12_1_actionPerformed(ActionEvent e) {
this.sigb12=1;
    this.startSearch=0;
  }

  void jRadio13_0_actionPerformed(ActionEvent e) {
this.sigb13=0;
    this.startSearch=0;
  }

  void jRadio13_1_actionPerformed(ActionEvent e) {
this.sigb13=1;
    this.startSearch=0;
  }

  void jRadio14_0_actionPerformed(ActionEvent e) {
this.sigb14=0;
    this.startSearch=0;
  }

  void jRadio14_1_actionPerformed(ActionEvent e) {
this.sigb14=1;
    this.startSearch=0;
  }

  void jRadio15_0_actionPerformed(ActionEvent e) {
this.sigb15=0;
    this.startSearch=0;
  }

  void jRadio15_1_actionPerformed(ActionEvent e) {
this.sigb15=1;
    this.startSearch=0;
  }

  void jButton1_actionPerformed(ActionEvent e) {

             this.checkSearch();

  }

  void jRadio0_2_actionPerformed(ActionEvent e) {
this.sigb0=2;
    this.startSearch=0;
  }

  void jRadio1_2_actionPerformed(ActionEvent e) {
this.sigb1=2;
    this.startSearch=0;
  }

  void jRadio2_2_actionPerformed(ActionEvent e) {
this.sigb2=2;
    this.startSearch=0;
  }

  void jRadio3_2_actionPerformed(ActionEvent e) {
this.sigb3=2;
    this.startSearch=0;
  }

  void jRadio4_2_actionPerformed(ActionEvent e) {
this.sigb4=2;
    this.startSearch=0;
  }

  void jRadio5_2_actionPerformed(ActionEvent e) {
this.sigb5=2;
    this.startSearch=0;
  }

  void jRadio6_2_actionPerformed(ActionEvent e) {
this.sigb6=2;
    this.startSearch=0;
  }

  void jRadio7_2_actionPerformed(ActionEvent e) {
this.sigb7=2;
    this.startSearch=0;
  }

  void jRadio8_2_actionPerformed(ActionEvent e) {
this.sigb8=2;
    this.startSearch=0;
  }

  void jRadio9_2_actionPerformed(ActionEvent e) {
this.sigb9=2;
    this.startSearch=0;
  }

  void jRadio10_2_actionPerformed(ActionEvent e) {
this.sigb10=2;
    this.startSearch=0;
  }

  void jRadio11_2_actionPerformed(ActionEvent e) {
this.sigb11=2;
    this.startSearch=0;
  }

  void jRadio12_2_actionPerformed(ActionEvent e) {
this.sigb12=2;
    this.startSearch=0;
  }

  void jRadio13_2_actionPerformed(ActionEvent e) {
this.sigb13=2;
    this.startSearch=0;
  }

  void jRadio14_2_actionPerformed(ActionEvent e) {
this.sigb14=2;
    this.startSearch=0;
  }

  void jRadio15_2_actionPerformed(ActionEvent e) {
this.sigb15=2;
    this.startSearch=0;
  }

}

class search_jButton2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jButton2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class search_jRadio0_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio0_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio0_0_actionPerformed(e);
  }
}

class search_jRadio0_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio0_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio0_1_actionPerformed(e);
  }
}

class search_jRadio1_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio1_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio1_0_actionPerformed(e);
  }
}

class search_jRadio1_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio1_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio1_1_actionPerformed(e);
  }
}

class search_jRadio2_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio2_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio2_0_actionPerformed(e);
  }
}

class search_jRadio2_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio2_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio2_1_actionPerformed(e);
  }
}

class search_jRadio3_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio3_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio3_0_actionPerformed(e);
  }
}

class search_jRadio3_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio3_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio3_1_actionPerformed(e);
  }
}

class search_jRadio4_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio4_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio4_0_actionPerformed(e);
  }
}

class search_jRadio4_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio4_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio4_1_actionPerformed(e);
  }
}

class search_jRadio5_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio5_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio5_0_actionPerformed(e);
  }
}

class search_jRadio5_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio5_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio5_1_actionPerformed(e);
  }
}

class search_jRadio6_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio6_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio6_0_actionPerformed(e);
  }
}

class search_jRadio6_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio6_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio6_1_actionPerformed(e);
  }
}

class search_jRadio7_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio7_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio7_0_actionPerformed(e);
  }
}

class search_jRadio7_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio7_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio7_1_actionPerformed(e);
  }
}

class search_jRadio8_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio8_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio8_0_actionPerformed(e);
  }
}

class search_jRadio8_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio8_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio8_1_actionPerformed(e);
  }
}

class search_jRadio9_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio9_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio9_0_actionPerformed(e);
  }
}

class search_jRadio9_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio9_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio9_1_actionPerformed(e);
  }
}

class search_jRadio10_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio10_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio10_0_actionPerformed(e);
  }
}

class search_jRadio10_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio10_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio10_1_actionPerformed(e);
  }
}

class search_jRadio11_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio11_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio11_0_actionPerformed(e);
  }
}

class search_jRadio11_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio11_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio11_1_actionPerformed(e);
  }
}

class search_jRadio12_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio12_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio12_0_actionPerformed(e);
  }
}

class search_jRadio12_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio12_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio12_1_actionPerformed(e);
  }
}

class search_jRadio13_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio13_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio13_0_actionPerformed(e);
  }
}

class search_jRadio13_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio13_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio13_1_actionPerformed(e);
  }
}

class search_jRadio14_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio14_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio14_0_actionPerformed(e);
  }
}

class search_jRadio14_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio14_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio14_1_actionPerformed(e);
  }
}

class search_jRadio15_0_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio15_0_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio15_0_actionPerformed(e);
  }
}

class search_jRadio15_1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio15_1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio15_1_actionPerformed(e);
  }
}

class search_jButton1_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jButton1_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class search_jRadio0_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio0_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio0_2_actionPerformed(e);
  }
}

class search_jRadio1_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio1_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio1_2_actionPerformed(e);
  }
}

class search_jRadio2_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio2_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio2_2_actionPerformed(e);
  }
}

class search_jRadio3_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio3_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio3_2_actionPerformed(e);
  }
}

class search_jRadio4_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio4_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio4_2_actionPerformed(e);
  }
}

class search_jRadio5_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio5_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio5_2_actionPerformed(e);
  }
}

class search_jRadio6_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio6_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio6_2_actionPerformed(e);
  }
}

class search_jRadio7_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio7_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio7_2_actionPerformed(e);
  }
}

class search_jRadio8_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio8_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio8_2_actionPerformed(e);
  }
}

class search_jRadio9_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio9_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio9_2_actionPerformed(e);
  }
}

class search_jRadio10_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio10_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio10_2_actionPerformed(e);
  }
}

class search_jRadio11_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio11_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio11_2_actionPerformed(e);
  }
}

class search_jRadio12_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio12_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio12_2_actionPerformed(e);
  }
}

class search_jRadio13_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio13_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio13_2_actionPerformed(e);
  }
}

class search_jRadio14_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio14_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio14_2_actionPerformed(e);
  }
}

class search_jRadio15_2_actionAdapter implements java.awt.event.ActionListener {
  search adaptee;

  search_jRadio15_2_actionAdapter(search adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadio15_2_actionPerformed(e);
  }
}