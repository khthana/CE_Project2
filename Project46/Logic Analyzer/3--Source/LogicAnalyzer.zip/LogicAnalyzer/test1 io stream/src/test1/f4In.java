package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class f4In {

  private static boolean sq0,sq1,sq2,sq3,sq4,sq5,sq6,sq7,sq8,sq9,sq10,sq11,sq12,sq13,sq14,sq15;
 private static boolean G3enable=false;
 private static String labelG3="Bus 3";


  public f4In() {

  }

  public void setLabelG1(String str){
        this.labelG3 = str;
        System.out.println(this.labelG3);
   }

   public String getLabelG2(){
      return  labelG3;
  }

  public void setEnable(boolean s){
      G3enable = s;
      System.out.println("Enable "+s);
  }

  public boolean getEnable(){
    boolean g2 = G3enable;
    return  g2;
  }

  public void setSq(int i,boolean s){
      switch(i){
                case 0:
                      sq0 = s;
                      break;
                case 1:
                     sq1 = s;
                      break;
                case 2:
                      sq2 = s;
                      break;
                case 3:
                      sq3 = s;
                      break;
                case 4:
                     sq4 = s;
                      break;
                case 5:
                     sq5 = s;
                      break;
                case 6:
                      sq6 = s;
                      break;
                case 7:
                      sq7 = s;
                      break;
                case 8:
                     sq8 = s;
                      break;
                case 9:
                     sq9 = s;
                      break;
                case 10:
                     sq10 = s;
                      break;
                case 11:
                     sq11 = s;
                      break;
                case 12:
                      sq12 = s;
                      break;
                case 13:
                      sq13 = s;
                      break;
                case 14:
                      sq14 = s;
                      break;
                case 15:
                      sq15 = s;
                      break;
            }

    }
    public boolean getStatus(int i){
            boolean state=false;

            switch(i){
                case 0:
                      state = sq0;
                      break;
                case 1:
                     state = sq1;
                      break;
                case 2:
                      state = sq2;
                      break;
                case 3:
                      state = sq3;
                      break;
                case 4:
                     state = sq4;
                      break;
                case 5:
                     state = sq5;
                      break;
                case 6:
                      state = sq6;
                      break;
                case 7:
                      state = sq7;
                      break;
                case 8:
                     state = sq8;
                      break;
                case 9:
                     state = sq9;
                      break;
                case 10:
                     state = sq10;
                      break;
                case 11:
                     state = sq11;
                      break;
                case 12:
                      state = sq12;
                      break;
                case 13:
                      state = sq13;
                      break;
                case 14:
                      state = sq14;
                      break;
                case 15:
                      state = sq15;
                      break;
            }


            return state;
        }

}