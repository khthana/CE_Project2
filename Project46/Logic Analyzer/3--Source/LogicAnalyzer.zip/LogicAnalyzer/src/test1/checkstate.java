package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class checkstate {

  private static boolean logiccome=false;
 private static boolean colorWave=false;
 private static boolean viewList=false;
 private static int bgcolor=4;
 private static int Gcolor=2;
 private static int Ccolor=1;
 private static int Xcolor=2;
 private static int Ycolor=3;
 private static  String LogicName[] = {"Signal 0","Signal 1","Signal 2","Signal 3","Signal 4","Signal 5","Signal 6","Signal 7","Signal 8","Signal 9","Signal 10","Signal 11","Signal 12","Signal 13","Signal 14","Signal 15",};
 private static int LogicSource[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
 private static int LogicColor[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
 private static int trigchk[]={2,2,2,2,2,2,2,2,2,2,2,2,2,2,2};


  public checkstate() {
  }



public int getTrigChk(int position){
    int re=0;
      switch(position){
         case 0:
                re = this.trigchk[0];
               break;
         case 1:
               re = this.trigchk[1];
               break;
         case 2:
               re = this.trigchk[2];
               break;
         case 3:
              re = this.trigchk[3];
               break;
         case 4:
               re = this.trigchk[4];
               break;
         case 5:
               re = this.trigchk[5];
               break;
         case 6:
               re = this.trigchk[6];
               break;
         case 7:
              re = this.trigchk[7];
               break;
         case 8:
               re = this.trigchk[8];
               break;
         case 9:
               re = this.trigchk[9];
               break;
         case 10:
               re = this.trigchk[10];
               break;
         case 11:
               re = this.trigchk[11];
               break;
         case 12:
               re = this.trigchk[12];
               break;
         case 13:
               re = this.trigchk[13];
               break;
         case 14:
               re = this.trigchk[14];
               break;
         case 15:
               re = this.trigchk[15];
               break;
     }
  return  re;

  }
public void setTrigChk(int position,int i){
    switch(position){
                 case 0:
                       this.trigchk[0] = i;
                       break;
                 case 1:
                      this.trigchk[1] = i;
                       break;
                 case 2:
                       this.trigchk[2] = i;
                       break;
                 case 3:
                       this.trigchk[3] = i;
                       break;
                 case 4:
                      this.trigchk[4] = i;
                       break;
      case 5:
             this.trigchk[5] = i;
            break;
      case 6:
             this.trigchk[6] = i;
            break;
      case 7:
             this.trigchk[7] = i;
            break;
      case 8:
             this.trigchk[8] = i;
            break;
      case 9:
             this.trigchk[9] = i;
            break;
      case 10:
             this.trigchk[10] = i;
            break;
      case 11:
             this.trigchk[11] = i;
            break;
      case 12:
             this.trigchk[12] = i;
            break;
      case 13:
             this.trigchk[13] = i;
            break;
      case 14:
             this.trigchk[14] = i;
            break;
      case 15:
            this.trigchk[15] = i;
            break;
     }
for(int ii=0;ii<=16;ii++){
     System.out.println(this.trigchk[ii]);
     }
  }
  public void setLogicName(int a,String i){

    switch(a){
                case 0:
                      this.LogicName[0] = i;
                      break;
                case 1:
                     this.LogicName[1] = i;
                      break;
                case 2:
                      this.LogicName[2] = i;
                      break;
                case 3:
                      this.LogicName[3] = i;
                      break;
                case 4:
                     this.LogicName[4] = i;
                      break;
     case 5:
            this.LogicName[5] = i;
           break;
     case 6:
            this.LogicName[6] = i;
           break;
     case 7:
            this.LogicName[7] = i;
           break;
     case 8:
            this.LogicName[8] = i;
           break;
     case 9:
            this.LogicName[9] = i;
           break;
     case 10:
            this.LogicName[10] = i;
           break;
     case 11:
            this.LogicName[11] = i;
           break;
     case 12:
            this.LogicName[12] = i;
           break;
     case 13:
            this.LogicName[13] = i;
           break;
     case 14:
            this.LogicName[14] = i;
           break;
     case 15:
           this.LogicName[15] = i;
           break;
    }


  }
  public String getLogicName(int i){

    String re="";
    switch(i){
       case 0:
              re = this.LogicName[0];
             break;
       case 1:
             re = this.LogicName[1];
             break;
       case 2:
             re = this.LogicName[2];
             break;
       case 3:
            re = this.LogicName[3];
             break;
       case 4:
             re = this.LogicName[4];
             break;
       case 5:
             re = this.LogicName[5];
             break;
       case 6:
             re = this.LogicName[6];
             break;
       case 7:
            re = this.LogicName[7];
             break;
       case 8:
             re = this.LogicName[8];
             break;
       case 9:
             re = this.LogicName[9];
             break;
       case 10:
             re = this.LogicName[10];
             break;
       case 11:
             re = this.LogicName[11];
             break;
       case 12:
             re = this.LogicName[12];
             break;
       case 13:
             re = this.LogicName[13];
             break;
       case 14:
             re = this.LogicName[14];
             break;
       case 15:
             re = this.LogicName[15];
             break;
   }
return  re;

  }

  public void setLogicSource(int sellectLogic,int j){

    switch(sellectLogic){
                case 0:
                     this.LogicSource[0] = j;
                      break;
                case 1:
                    this.LogicSource[1] = j;
                      break;
                case 2:
                      this.LogicSource[2] = j;
                      break;
                case 3:
                      this.LogicSource[3] = j;
                      break;
                case 4:
                     this.LogicSource[4] = j;
                      break;
                case 5:
                     this.LogicSource[5] = j;
                     break;
                case 6:
                    this.LogicSource[6] = j;
                    break;
                case 7:
                    this.LogicSource[7] = j;
                    break;
               case 8:
                    this.LogicSource[8] = j;
                    break;
              case 9:
                   this.LogicSource[9] = j;
                   break;
             case 10:
                  this.LogicSource[10] = j;
                  break;
            case 11:
                  this.LogicSource[11] = j;
                  break;
            case 12:
                 this.LogicSource[12] = j;
                 break;
            case 13:
                 this.LogicSource[13] = j;
                 break;
            case 14:
                 this.LogicSource[14] = j;
                 break;
            case 15:
                this.LogicSource[15] = j;
                break;

    }


  }
  public int getLogicSource(int selectLogic){

     int re=0;
     switch(selectLogic){
        case 0:
               re = this.LogicSource[0];
              break;
        case 1:
              re = this.LogicSource[1];
              break;
        case 2:
              re = this.LogicSource[2];
              break;
        case 3:
             re = this.LogicSource[3];
              break;
        case 4:
              re = this.LogicSource[4];
              break;
        case 5:
              re = this.LogicSource[5];
              break;
        case 6:
              re = this.LogicSource[6];
              break;
        case 7:
             re = this.LogicSource[7];
              break;
        case 8:
              re = this.LogicSource[8];
              break;
        case 9:
              re = this.LogicSource[9];
              break;
        case 10:
              re = this.LogicSource[10];
              break;
        case 11:
              re = this.LogicSource[11];
              break;
        case 12:
              re = this.LogicSource[12];
              break;
        case 13:
              re = this.LogicSource[13];
              break;
        case 14:
              re = this.LogicSource[14];
              break;
        case 15:
              re = this.LogicSource[15];
              break;
    }
 return  re;

   }

   public void setLogicColor(int sellectLogic,int j){

       switch(sellectLogic){
                   case 0:
                        this.LogicColor[0] = j;
                         break;
                   case 1:
                       this.LogicColor[1] = j;
                         break;
                   case 2:
                         this.LogicColor[2] = j;
                         break;
                   case 3:
                         this.LogicColor[3] = j;
                         break;
                   case 4:
                        this.LogicColor[4] = j;
                         break;
                   case 5:
                        this.LogicColor[5] = j;
                        break;
                   case 6:
                       this.LogicColor[6] = j;
                       break;
                   case 7:
                       this.LogicColor[7] = j;
                       break;
                  case 8:
                       this.LogicColor[8] = j;
                       break;
                 case 9:
                      this.LogicColor[9] = j;
                      break;
                case 10:
                     this.LogicColor[10] = j;
                     break;
               case 11:
                     this.LogicColor[11] = j;
                     break;
               case 12:
                    this.LogicColor[12] = j;
                    break;
               case 13:
                    this.LogicColor[13] = j;
                    break;
               case 14:
                    this.LogicColor[14] = j;
                    break;
               case 15:
                   this.LogicColor[15] = j;
                   break;
       }


     }
     public int getLogicColor(int selectLogic){

        int re=0;
        switch(selectLogic){
           case 0:
                  re = this.LogicColor[0];
                 break;
           case 1:
                 re = this.LogicColor[1];
                 break;
           case 2:
                 re = this.LogicColor[2];
                 break;
           case 3:
                re = this.LogicColor[3];
                 break;
           case 4:
                 re = this.LogicColor[4];
                 break;
           case 5:
                 re = this.LogicColor[5];
                 break;
           case 6:
                 re = this.LogicColor[6];
                 break;
           case 7:
                re = this.LogicColor[7];
                 break;
           case 8:
                 re = this.LogicColor[8];
                 break;
           case 9:
                 re = this.LogicColor[9];
                 break;
           case 10:
                 re = this.LogicColor[10];
                 break;
           case 11:
                 re = this.LogicColor[11];
                 break;
           case 12:
                 re = this.LogicColor[12];
                 break;
           case 13:
                 re = this.LogicColor[13];
                 break;
           case 14:
                 re = this.LogicColor[14];
                 break;
           case 15:
                 re = this.LogicColor[15];
                 break;
       }
    return  re;

      }


  public void setLogicCome(boolean i){
     this.logiccome = i;
  }
  public boolean getLogicCome(){
    return this.logiccome;
  }

 public void setColor(int bg,int G,int C,int X,int Y){
          this.bgcolor = bg;
          this.Gcolor = G;
          this.Ccolor = C;
          this.Xcolor = X;
          this.Ycolor = Y;


 }

 public int getColor(int i){
   int col=0;
   switch(i){
                case 0:
                      col = this.bgcolor;
                      break;
                case 1:
                     col = this.Gcolor;
                      break;
                case 2:
                      col = this.Ccolor;
                      break;
                case 3:
                      col = this.Xcolor;
                      break;
                case 4:
                     col = this.Ycolor;
                      break;
            }
return col;
 }

  public void setcolorWave(boolean i){
      this.colorWave = i;
  }
  public boolean getcolorWave(){
      return this.colorWave;
  }

  public void setviewList(boolean i){
    this.viewList=i;
  }
  public boolean getviewList(){
    return this.viewList;
  }

}