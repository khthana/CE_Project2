package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Trig  extends JFrame{
   private ButtonGroup radioGroup0,radioGroup1,radioGroup2,radioGroup3,radioGroup4,radioGroup5,radioGroup6,radioGroup7,radioGroup8,radioGroup9,radioGroup10,radioGroup11,radioGroup12,radioGroup13,radioGroup14,radioGroup15;
   private int sigb0,sigb1,sigb2,sigb3,sigb4,sigb5,sigb6,sigb7,sigb8,sigb9,sigb10,sigb11,sigb12,sigb13,sigb14,sigb15=2;
   checkstate chk = new checkstate();
   JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JLabel label0 = new JLabel();
  JRadioButton Radio0_0 = new JRadioButton();
  JRadioButton Radio0_1 = new JRadioButton();
  JRadioButton Radio0_2 = new JRadioButton();
  JPanel jPanel3 = new JPanel();
  JLabel label1 = new JLabel();
  JRadioButton Radio1_0 = new JRadioButton();
  JRadioButton Radio1_1 = new JRadioButton();
  JRadioButton Radio1_2 = new JRadioButton();
  JPanel jPanel4 = new JPanel();
  JLabel label2 = new JLabel();
  JRadioButton Radio2_0 = new JRadioButton();
  JRadioButton Radio2_1 = new JRadioButton();
  JRadioButton Radio2_2 = new JRadioButton();
  JPanel jPanel5 = new JPanel();
  JLabel Label3 = new JLabel();
  JRadioButton Radio3_0 = new JRadioButton();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JRadioButton Radio3_1 = new JRadioButton();
  JRadioButton Radio3_2 = new JRadioButton();
  JPanel jPanel6 = new JPanel();
  JLabel Label4 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JRadioButton Radio4_0 = new JRadioButton();
  JRadioButton Radio4_1 = new JRadioButton();
  JRadioButton Radio4_2 = new JRadioButton();
  JPanel jPanel7 = new JPanel();
  JLabel Label5 = new JLabel();
  JRadioButton Radio5_0 = new JRadioButton();
  JRadioButton Radio5_1 = new JRadioButton();
  JRadioButton Radio5_2 = new JRadioButton();
  JPanel jPanel8 = new JPanel();
  JLabel Label6 = new JLabel();
  JRadioButton Radio6_0 = new JRadioButton();
  JRadioButton Radio6_1 = new JRadioButton();
  JPanel jPanel9 = new JPanel();
  JLabel Label7 = new JLabel();
  JRadioButton Radio6_2 = new JRadioButton();
  JRadioButton Radio7_0 = new JRadioButton();
  JRadioButton Radio7_1 = new JRadioButton();
  JRadioButton Radio7_2 = new JRadioButton();
  JPanel jPanel10 = new JPanel();
  JLabel Label8 = new JLabel();
  JRadioButton Radio8_0 = new JRadioButton();
  JRadioButton Radio8_1 = new JRadioButton();
  JRadioButton Radio8_2 = new JRadioButton();
  JRadioButton Radio9_0 = new JRadioButton();
  JPanel jPanel11 = new JPanel();
  JRadioButton Radio11_2 = new JRadioButton();
  JRadioButton Radio10_1 = new JRadioButton();
  JPanel jPanel12 = new JPanel();
  JRadioButton Radio11_0 = new JRadioButton();
  JRadioButton Radio13_2 = new JRadioButton();
  JRadioButton Radio10_2 = new JRadioButton();
  JPanel jPanel14 = new JPanel();
  JRadioButton Radio12_1 = new JRadioButton();
  JPanel jPanel15 = new JPanel();
  JRadioButton Radio15_0 = new JRadioButton();
  JRadioButton Radio12_2 = new JRadioButton();
  JRadioButton Radio14_1 = new JRadioButton();
  JLabel Label13 = new JLabel();
  JLabel Label14 = new JLabel();
  JLabel Label11 = new JLabel();
  JRadioButton Radio11_1 = new JRadioButton();
  JRadioButton Radio13_0 = new JRadioButton();
  JRadioButton Radio14_0 = new JRadioButton();
  JRadioButton Radio10_0 = new JRadioButton();
  JLabel Label12 = new JLabel();
  JRadioButton Radio9_1 = new JRadioButton();
  JRadioButton Radio15_2 = new JRadioButton();
  JPanel jPanel17 = new JPanel();
  JRadioButton Radio14_2 = new JRadioButton();
  JRadioButton Radio15_1 = new JRadioButton();
  JRadioButton Radio9_2 = new JRadioButton();
  JLabel Label9 = new JLabel();
  JPanel jPanel18 = new JPanel();
  JRadioButton Radio12_0 = new JRadioButton();
  JLabel Label15 = new JLabel();
  JPanel jPanel19 = new JPanel();
  JLabel Label10 = new JLabel();
  JRadioButton Radio13_1 = new JRadioButton();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  public Trig() {
    setTitle("Trigger");
   setSize(400,700);
    show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(3, 3, 423, 636));
    jPanel1.setLayout(null);
    jLabel1.setText("Choose pattern to Trigger");
    jLabel1.setBounds(new Rectangle(6, 33, 195, 15));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setDebugGraphicsOptions(0);
    jPanel2.setBounds(new Rectangle(42, 61, 275, 26));
    jPanel2.setLayout(null);
    label0.setText("Sig 0");
    label0.setBounds(new Rectangle(5, 4, 112, 15));
    Radio0_0.setText("");
    Radio0_0.setBounds(new Rectangle(185, 1, 21, 23));
    Radio0_0.addActionListener(new Trig_Radio0_0_actionAdapter(this));
    Radio0_1.setText("");
    Radio0_1.setBounds(new Rectangle(217, 1, 21, 23));
    Radio0_1.addActionListener(new Trig_Radio0_1_actionAdapter(this));
    Radio0_2.setSelected(true);
    Radio0_2.setText("");
    Radio0_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio0_2.addActionListener(new Trig_Radio0_2_actionAdapter(this));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setBounds(new Rectangle(42, 88, 275, 26));
    jPanel3.setLayout(null);
    label1.setText("Sig 1");
    label1.setBounds(new Rectangle(4, 4, 83, 15));
    Radio1_0.setSelectedIcon(null);
    Radio1_0.setText("");
    Radio1_0.setBounds(new Rectangle(185, 1, 20, 23));
    Radio1_0.addActionListener(new Trig_Radio1_0_actionAdapter(this));
    Radio1_1.setText("");
    Radio1_1.setBounds(new Rectangle(217, 1, 20, 23));
    Radio1_1.addActionListener(new Trig_Radio1_1_actionAdapter(this));
    Radio1_2.setSelected(true);
    Radio1_2.setText("");
    Radio1_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio1_2.addActionListener(new Trig_Radio1_2_actionAdapter(this));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setBounds(new Rectangle(42, 115, 275, 26));
    jPanel4.setLayout(null);
    label2.setText("Sig 2");
    label2.setBounds(new Rectangle(4, 4, 90, 15));
    Radio2_0.setText("");
    Radio2_0.setBounds(new Rectangle(185, 1, 21, 23));
    Radio2_0.addActionListener(new Trig_Radio2_0_actionAdapter(this));
    Radio2_1.setText("");
    Radio2_1.setBounds(new Rectangle(217, 1, 20, 23));
    Radio2_1.addActionListener(new Trig_Radio2_1_actionAdapter(this));
    Radio2_2.setSelected(true);
    Radio2_2.setText("");
    Radio2_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio2_2.addActionListener(new Trig_Radio2_2_actionAdapter(this));
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setBounds(new Rectangle(42, 142, 275, 26));
    jPanel5.setLayout(null);
    Label3.setText("Sig 3");
    Label3.setBounds(new Rectangle(4, 4, 112, 15));
    Radio3_0.setText("");
    Radio3_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio3_0.addActionListener(new Trig_Radio3_0_actionAdapter(this));
    jLabel2.setText("0");
    jLabel2.setBounds(new Rectangle(234, 44, 13, 15));
    jLabel3.setText("1");
    jLabel3.setBounds(new Rectangle(266, 44, 11, 15));
    Radio3_1.setText("");
    Radio3_1.setBounds(new Rectangle(217, 1, 23, 23));
    Radio3_1.addActionListener(new Trig_Radio3_1_actionAdapter(this));
    Radio3_2.setSelected(true);
    Radio3_2.setText("");
    Radio3_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio3_2.addActionListener(new Trig_Radio3_2_actionAdapter(this));
    jPanel6.setBorder(BorderFactory.createEtchedBorder());
    jPanel6.setBounds(new Rectangle(42, 169, 275, 26));
    jPanel6.setLayout(null);
    Label4.setText("Sig 4");
    Label4.setBounds(new Rectangle(4, 4, 110, 15));
    jLabel4.setText("don\'t care");
    jLabel4.setBounds(new Rectangle(276, 44, 57, 15));
    Radio4_0.setText("");
    Radio4_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio4_0.addActionListener(new Trig_Radio4_0_actionAdapter(this));
    Radio4_1.setText("");
    Radio4_1.setBounds(new Rectangle(217, 1, 22, 23));
    Radio4_1.addActionListener(new Trig_Radio4_1_actionAdapter(this));
    Radio4_2.setSelected(true);
    Radio4_2.setText("");
    Radio4_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio4_2.addActionListener(new Trig_Radio4_2_actionAdapter(this));
    jPanel7.setBorder(BorderFactory.createEtchedBorder());
    jPanel7.setBounds(new Rectangle(42, 196, 275, 26));
    jPanel7.setLayout(null);
    Label5.setText("Sig 5");
    Label5.setBounds(new Rectangle(4, 4, 104, 15));
    Radio5_0.setText("");
    Radio5_0.setBounds(new Rectangle(186, 1, 21, 23));
    Radio5_0.addActionListener(new Trig_Radio5_0_actionAdapter(this));
    Radio5_1.setText("");
    Radio5_1.setBounds(new Rectangle(216, 1, 21, 23));
    Radio5_1.addActionListener(new Trig_Radio5_1_actionAdapter(this));
    Radio5_2.setSelected(true);
    Radio5_2.setText("");
    Radio5_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio5_2.addActionListener(new Trig_Radio5_2_actionAdapter(this));
    jPanel8.setBorder(BorderFactory.createEtchedBorder());
    jPanel8.setBounds(new Rectangle(42, 223, 275, 26));
    jPanel8.setLayout(null);
    Label6.setText("Sig 6");
    Label6.setBounds(new Rectangle(4, 5, 94, 15));
  //  Radio6_1_0.setText("");
 //   Radio6_1_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio6_1.setText("");
    Radio6_1.setBounds(new Rectangle(216, 1, 20, 23));
    Radio6_1.addActionListener(new Trig_Radio6_1_actionAdapter(this));
    jPanel9.setBorder(BorderFactory.createEtchedBorder());
    jPanel9.setBounds(new Rectangle(42, 250, 275, 26));
    jPanel9.setLayout(null);
    Label7.setText("Sig 7");
    Label7.setBounds(new Rectangle(5, 4, 81, 15));
  //  Radio6_1_2.setText("");
 //   Radio6_1_2.setBounds(new Rectangle(247, 1, 21, 23));
    Radio7_0.setText("");
    Radio7_0.setBounds(new Rectangle(186, 1, 21, 23));
    Radio7_0.addActionListener(new Trig_Radio7_0_actionAdapter(this));
    Radio7_1.setText("");
    Radio7_1.setBounds(new Rectangle(216, 1, 18, 23));
    Radio7_1.addActionListener(new Trig_Radio7_1_actionAdapter(this));
    Radio7_2.setSelected(true);
    Radio7_2.setText("");
    Radio7_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio7_2.addActionListener(new Trig_Radio7_2_actionAdapter(this));
    jPanel10.setBorder(BorderFactory.createEtchedBorder());
    jPanel10.setBounds(new Rectangle(42, 277, 275, 26));
    jPanel10.setLayout(null);
    Label8.setText("Sig 8");
    Label8.setBounds(new Rectangle(5, 4, 114, 15));
    Radio8_0.setText("");
    Radio8_0.setBounds(new Rectangle(187, 1, 20, 23));
    Radio8_0.addActionListener(new Trig_Radio8_0_actionAdapter(this));
    Radio8_1.setText("");
    Radio8_1.setBounds(new Rectangle(216, 1, 22, 23));
    Radio8_1.addActionListener(new Trig_Radio8_1_actionAdapter(this));
    Radio8_2.setSelected(true);
    Radio8_2.setText("");
    Radio8_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio8_2.addActionListener(new Trig_Radio8_2_actionAdapter(this));
    Radio9_0.setBounds(new Rectangle(185, 1, 21, 23));
    Radio9_0.addActionListener(new Trig_Radio9_0_actionAdapter(this));
    Radio9_0.setText("");
    jPanel11.setLayout(null);
    jPanel11.setBounds(new Rectangle(42, 358, 275, 26));
    jPanel11.setBorder(BorderFactory.createEtchedBorder());
    Radio11_2.setSelected(true);
    Radio11_2.setText("");
    Radio11_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio11_2.addActionListener(new Trig_Radio11_2_actionAdapter(this));
    Radio10_1.setText("");
    Radio10_1.setBounds(new Rectangle(217, 1, 20, 23));
    Radio10_1.addActionListener(new Trig_Radio10_1_actionAdapter(this));
    jPanel12.setBorder(BorderFactory.createEtchedBorder());
    jPanel12.setBounds(new Rectangle(42, 331, 275, 26));
    jPanel12.setLayout(null);
    Radio11_0.setText("");
    Radio11_0.setBounds(new Rectangle(185, 1, 21, 23));
    Radio11_0.addActionListener(new Trig_Radio11_0_actionAdapter(this));
    Radio13_2.setSelected(true);
    Radio13_2.setText("");
    Radio13_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio13_2.addActionListener(new Trig_Radio13_2_actionAdapter(this));
    Radio10_2.setSelected(true);
    Radio10_2.setText("");
    Radio10_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio10_2.addActionListener(new Trig_Radio10_2_actionAdapter(this));
    jPanel14.setBorder(BorderFactory.createEtchedBorder());
    jPanel14.setDebugGraphicsOptions(0);
    jPanel14.setBounds(new Rectangle(42, 304, 275, 26));
    jPanel14.setLayout(null);
    Radio12_1.setText("");
    Radio12_1.setBounds(new Rectangle(217, 1, 23, 23));
    Radio12_1.addActionListener(new Trig_Radio12_1_actionAdapter(this));
    jPanel15.setBorder(BorderFactory.createEtchedBorder());
    jPanel15.setBounds(new Rectangle(42, 385, 275, 26));
    jPanel15.setLayout(null);
    Radio15_0.setText("");
    Radio15_0.setBounds(new Rectangle(186, 1, 21, 23));
    Radio15_0.setText("");
    Radio15_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio15_0.addActionListener(new Trig_Radio15_0_actionAdapter(this));
    Radio12_2.setSelected(true);
    Radio12_2.setText("");
    Radio12_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio12_2.addActionListener(new Trig_Radio12_2_actionAdapter(this));
    Radio14_1.setText("");
    Radio14_1.setBounds(new Rectangle(216, 1, 21, 23));
    Radio14_1.addActionListener(new Trig_Radio14_1_actionAdapter(this));
    Label13.setText("Sig 13");
    Label13.setBounds(new Rectangle(4, 4, 110, 15));
    Label14.setText("Sig 14");
    Label14.setBounds(new Rectangle(4, 4, 104, 15));
    Label11.setText("Sig 11");
    Label11.setBounds(new Rectangle(4, 4, 90, 15));
    Radio11_1.setText("");
    Radio11_1.setBounds(new Rectangle(217, 1, 20, 23));
    Radio11_1.addActionListener(new Trig_Radio11_1_actionAdapter(this));
    Radio13_0.setText("");
    Radio13_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio13_0.addActionListener(new Trig_Radio13_0_actionAdapter(this));
    Radio14_0.setText("");
    Radio14_0.setBounds(new Rectangle(186, 1, 21, 23));
    Radio14_0.addActionListener(new Trig_Radio14_0_actionAdapter(this));
    Radio10_0.setSelectedIcon(null);
    Radio10_0.setText("");
    Radio10_0.setBounds(new Rectangle(185, 1, 20, 23));
    Radio10_0.addActionListener(new Trig_Radio10_0_actionAdapter(this));
    Label12.setText("Sig 12");
    Label12.setBounds(new Rectangle(4, 4, 112, 15));
    Radio9_1.setText("");
    Radio9_1.setBounds(new Rectangle(217, 1, 21, 23));
    Radio9_1.addActionListener(new Trig_Radio9_1_actionAdapter(this));
    Radio15_2.setText("");
    Radio15_2.setBounds(new Rectangle(247, 1, 21, 23));
    Radio15_2.setSelected(true);
    Radio15_2.setText("");
    Radio15_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio15_2.addActionListener(new Trig_Radio15_2_actionAdapter(this));
    jPanel17.setBorder(BorderFactory.createEtchedBorder());
    jPanel17.setBounds(new Rectangle(42, 439, 275, 26));
    jPanel17.setLayout(null);
    Radio14_2.setSelected(true);
    Radio14_2.setText("");
    Radio14_2.setBounds(new Rectangle(247, 1, 19, 23));
    Radio14_2.addActionListener(new Trig_Radio14_2_actionAdapter(this));
    Radio15_1.setText("");
    Radio15_1.setBounds(new Rectangle(216, 1, 18, 23));
    Radio15_1.addActionListener(new Trig_Radio15_1_actionAdapter(this));
    Radio9_2.setSelected(true);
    Radio9_2.setText("");
    Radio9_2.setBounds(new Rectangle(247, 1, 20, 23));
    Radio9_2.addActionListener(new Trig_Radio9_2_actionAdapter(this));
    Label9.setText("Sig 9");
    Label9.setBounds(new Rectangle(5, 4, 112, 15));
    jPanel18.setBorder(BorderFactory.createEtchedBorder());
    jPanel18.setBounds(new Rectangle(42, 412, 275, 26));
    jPanel18.setLayout(null);
    Radio12_0.setText("");
    Radio12_0.setBounds(new Rectangle(186, 1, 19, 23));
    Radio12_0.addActionListener(new Trig_Radio12_0_actionAdapter(this));
    Label15.setText("Sig 15");
    Label15.setBounds(new Rectangle(5, 4, 81, 15));
    jPanel19.setBorder(BorderFactory.createEtchedBorder());
    jPanel19.setBounds(new Rectangle(41, 466, 275, 26));
    jPanel19.setLayout(null);
    Label10.setText("Sig 10");
    Label10.setBounds(new Rectangle(4, 4, 83, 15));
    Radio13_1.setText("");
    Radio13_1.setBounds(new Rectangle(217, 1, 22, 23));
    Radio13_1.addActionListener(new Trig_Radio13_1_actionAdapter(this));
//    Rado6_1.setBounds(new Rectangle(243, 3, 21, 21));
    jButton1.setBounds(new Rectangle(219, 556, 73, 25));
    jButton1.setText("OK");
    jButton1.addActionListener(new Trig_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(295, 556, 73, 25));
    jButton2.setText("Cancel");
    Radio6_0.setBounds(new Rectangle(186, 3, 23, 18));
    Radio6_0.addActionListener(new Trig_Radio6_0_actionAdapter(this));
    Radio6_2.setSelected(true);
    Radio6_2.setBounds(new Rectangle(247, 3, 19, 20));
    Radio6_2.addActionListener(new Trig_Radio6_2_actionAdapter(this));
    this.getContentPane().add(jPanel1, null);
    jPanel2.add(label0, null);
    jPanel2.add(Radio0_1, null);
    jPanel2.add(Radio0_2, null);
    jPanel2.add(Radio0_0, null);
    jPanel1.add(jPanel3, null);
    jPanel3.add(label1, null);
    jPanel3.add(Radio1_0, null);
    jPanel3.add(Radio1_1, null);
    jPanel3.add(Radio1_2, null);
    jPanel1.add(jPanel4, null);
    jPanel4.add(label2, null);
    jPanel4.add(Radio2_1, null);
    jPanel4.add(Radio2_0, null);
    jPanel4.add(Radio2_2, null);
    jPanel1.add(jPanel5, null);
    jPanel5.add(Label3, null);
    jPanel5.add(Radio3_0, null);
    jPanel5.add(Radio3_1, null);
    jPanel5.add(Radio3_2, null);
    jPanel1.add(jPanel2, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jPanel6, null);
    jPanel6.add(Label4, null);
    jPanel6.add(Radio4_0, null);
    jPanel6.add(Radio4_1, null);
    jPanel6.add(Radio4_2, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(jPanel7, null);
    jPanel7.add(Label5, null);
    jPanel7.add(Radio5_0, null);
    jPanel7.add(Radio5_1, null);
    jPanel7.add(Radio5_2, null);
    jPanel1.add(jPanel8, null);
    jPanel8.add(Radio6_1, null);
    jPanel1.add(jPanel9, null);
    jPanel9.add(Radio7_0, null);
    jPanel9.add(Radio7_1, null);
    jPanel9.add(Radio7_2, null);
    jPanel1.add(jPanel10, null);
    jPanel10.add(Label8, null);
    jPanel10.add(Radio8_0, null);
    jPanel10.add(Radio8_1, null);
    jPanel10.add(Radio8_2, null);
    jPanel11.add(Label11, null);
    jPanel11.add(Radio11_1, null);
    jPanel11.add(Radio11_0, null);
    jPanel11.add(Radio11_2, null);
    jPanel1.add(jPanel15, null);
    jPanel12.add(Label10, null);
    jPanel12.add(Radio10_0, null);
    jPanel12.add(Radio10_1, null);
    jPanel12.add(Radio10_2, null);
    jPanel1.add(jPanel11, null);
    jPanel1.add(jPanel19, null);
    jPanel1.add(jPanel14, null);
    jPanel14.add(Label9, null);
    jPanel14.add(Radio9_1, null);
    jPanel14.add(Radio9_2, null);
    jPanel14.add(Radio9_0, null);
    jPanel1.add(jPanel12, null);
    jPanel15.add(Label12, null);
    jPanel15.add(Radio12_0, null);
    jPanel15.add(Radio12_1, null);
    jPanel15.add(Radio12_2, null);
    jPanel1.add(jPanel18, null);
    jPanel17.add(Label14, null);
    jPanel17.add(Radio14_0, null);
    jPanel17.add(Radio14_1, null);
    jPanel17.add(Radio14_2, null);
    jPanel18.add(Label13, null);
    jPanel18.add(Radio13_0, null);
    jPanel18.add(Radio13_1, null);
    jPanel18.add(Radio13_2, null);
    jPanel1.add(jPanel17, null);
    jPanel19.add(Radio15_0, null);
    jPanel19.add(Radio15_1, null);
    jPanel19.add(Radio15_2, null);
    jPanel19.add(Label15, null);
    jPanel9.add(Label7, null);
    jPanel8.add(Label6, null);
    jPanel8.add(Radio6_0, null);
    jPanel8.add(Radio6_2, null);
    jPanel1.add(jButton2, null);
    jPanel1.add(jButton1, null);
    radioGroup0.add(Radio0_0);
    radioGroup0.add(Radio0_1);
    radioGroup0.add(Radio0_2);
    radioGroup1.add(Radio1_0);
    radioGroup1.add(Radio1_1);
    radioGroup1.add(Radio1_2);
    radioGroup2.add(Radio2_0);
    radioGroup2.add(Radio2_1);
    radioGroup2.add(Radio2_2);
    radioGroup3.add(Radio3_0);
    radioGroup3.add(Radio3_1);
    radioGroup3.add(Radio3_2);
    radioGroup4.add(Radio4_0);
    radioGroup4.add(Radio4_1);
    radioGroup4.add(Radio4_2);
    radioGroup5.add(Radio5_0);
    radioGroup5.add(Radio5_1);
    radioGroup5.add(Radio5_2);
    radioGroup6.add(Radio6_0);
    radioGroup6.add(Radio6_1);
    radioGroup6.add(Radio6_2);
    radioGroup7.add(Radio7_0);
    radioGroup7.add(Radio7_1);
    radioGroup7.add(Radio7_2);
    radioGroup8.add(Radio8_0);
    radioGroup8.add(Radio8_1);
    radioGroup8.add(Radio8_2);
    radioGroup9.add(Radio9_0);
    radioGroup9.add(Radio9_1);
    radioGroup9.add(Radio9_2);
    radioGroup10.add(Radio10_0);
    radioGroup10.add(Radio10_1);
    radioGroup10.add(Radio10_2);
    radioGroup11.add(Radio11_0);
    radioGroup11.add(Radio11_1);
    radioGroup11.add(Radio11_2);
    radioGroup12.add(Radio12_0);
    radioGroup12.add(Radio12_1);
    radioGroup12.add(Radio12_2);
    radioGroup13.add(Radio13_0);
    radioGroup13.add(Radio13_1);
    radioGroup13.add(Radio13_2);
    radioGroup14.add(Radio14_0);
    radioGroup14.add(Radio14_1);
    radioGroup14.add(Radio14_2);
    radioGroup15.add(Radio15_0);
    radioGroup15.add(Radio15_1);
    radioGroup15.add(Radio15_2);

  }

  void Radio0_0_actionPerformed(ActionEvent e) {
this.sigb0=0;
  }

  void Radio0_1_actionPerformed(ActionEvent e) {
this.sigb0=1;
  }

  void Radio0_2_actionPerformed(ActionEvent e) {
this.sigb0=2;
  }

  void Radio1_0_actionPerformed(ActionEvent e) {
this.sigb1=0;
  }

  void Radio1_1_actionPerformed(ActionEvent e) {
this.sigb1=1;
  }

  void Radio1_2_actionPerformed(ActionEvent e) {
this.sigb1=2;
  }

  void Radio2_0_actionPerformed(ActionEvent e) {
this.sigb2=0;
  }

  void Radio2_1_actionPerformed(ActionEvent e) {
this.sigb2=1;
  }

  void Radio2_2_actionPerformed(ActionEvent e) {
this.sigb2=2;
  }

  void Radio3_0_actionPerformed(ActionEvent e) {
this.sigb3=0;
  }

  void Radio3_1_actionPerformed(ActionEvent e) {
this.sigb3=1;
  }

  void Radio3_2_actionPerformed(ActionEvent e) {
this.sigb3=2;
  }

  void Radio4_0_actionPerformed(ActionEvent e) {
this.sigb4=0;
  }

  void Radio4_1_actionPerformed(ActionEvent e) {
this.sigb4=1;
  }

  void Radio4_2_actionPerformed(ActionEvent e) {
this.sigb4=2;
  }

  void Radio5_0_actionPerformed(ActionEvent e) {
this.sigb5=0;
  }

  void Radio5_1_actionPerformed(ActionEvent e) {
this.sigb5=1;
  }

  void Radio5_2_actionPerformed(ActionEvent e) {
this.sigb5=2;
  }

  void Radio6_0_actionPerformed(ActionEvent e) {
this.sigb6=0;
  }

  void Radio6_1_actionPerformed(ActionEvent e) {
this.sigb6=1;
  }

  void Radio6_2_actionPerformed(ActionEvent e) {
this.sigb6=2;
  }

  void Radio7_0_actionPerformed(ActionEvent e) {
this.sigb7=0;
  }

  void Radio7_1_actionPerformed(ActionEvent e) {
this.sigb7=1;
  }

  void Radio7_2_actionPerformed(ActionEvent e) {
this.sigb7=2;
  }

  void Radio8_0_actionPerformed(ActionEvent e) {
this.sigb8=0;
  }

  void Radio8_1_actionPerformed(ActionEvent e) {
this.sigb8=1;
  }

  void Radio8_2_actionPerformed(ActionEvent e) {
this.sigb8=2;
  }

  void Radio9_0_actionPerformed(ActionEvent e) {
this.sigb9=0;
  }

  void Radio9_1_actionPerformed(ActionEvent e) {
this.sigb9=1;
  }

  void Radio9_2_actionPerformed(ActionEvent e) {
this.sigb9=2;
  }

  void Radio10_0_actionPerformed(ActionEvent e) {
this.sigb10=0;
  }

  void Radio10_1_actionPerformed(ActionEvent e) {
this.sigb10=1;
  }

  void Radio10_2_actionPerformed(ActionEvent e) {
this.sigb10=2;
  }

  void Radio11_0_actionPerformed(ActionEvent e) {
this.sigb11=0;
  }

  void Radio11_1_actionPerformed(ActionEvent e) {
this.sigb11=1;
  }

  void Radio11_2_actionPerformed(ActionEvent e) {
this.sigb11=2;
  }

  void Radio12_0_actionPerformed(ActionEvent e) {
this.sigb12=0;
  }

  void Radio12_1_actionPerformed(ActionEvent e) {
this.sigb12=1;
  }

  void Radio12_2_actionPerformed(ActionEvent e) {
this.sigb12=2;
  }

  void Radio13_0_actionPerformed(ActionEvent e) {
this.sigb13=0;
  }

  void Radio13_1_actionPerformed(ActionEvent e) {
this.sigb13=1;
  }

  void Radio13_2_actionPerformed(ActionEvent e) {
this.sigb13=2;
  }

  void Radio14_0_actionPerformed(ActionEvent e) {
this.sigb14=0;
  }

  void Radio14_1_actionPerformed(ActionEvent e) {
this.sigb14=1;
  }

  void Radio14_2_actionPerformed(ActionEvent e) {
this.sigb14=2;
  }

  void Radio15_0_actionPerformed(ActionEvent e) {
this.sigb15=0;
  }

  void Radio15_1_actionPerformed(ActionEvent e) {
this.sigb15=1;
  }

  void Radio15_2_actionPerformed(ActionEvent e) {
this.sigb15=2;
  }

  void jButton1_actionPerformed(ActionEvent e) {
System.out.println(this.sigb0+" "+this.sigb1+" "+this.sigb2+" "+this.sigb3+" "+this.sigb4+" "+ this.sigb5+" "+this.sigb6+" "+this.sigb7+" "+this.sigb8+" "+this.sigb9+" "+this.sigb10+" "+this.sigb11+" "+this.sigb12+" "+this.sigb13+" "+this.sigb14+" "+this.sigb15);
 chk.setTrigChk(0,this.sigb0);
 chk.setTrigChk(1,this.sigb1);
 chk.setTrigChk(2,this.sigb2);
 chk.setTrigChk(3,this.sigb3);
 chk.setTrigChk(4,this.sigb4);
 chk.setTrigChk(5,this.sigb5);
 chk.setTrigChk(6,this.sigb6);
 chk.setTrigChk(7,this.sigb7);
 chk.setTrigChk(8,this.sigb8);
 chk.setTrigChk(9,this.sigb9);
 chk.setTrigChk(10,this.sigb10);
 chk.setTrigChk(11,this.sigb11);
 chk.setTrigChk(12,this.sigb12);
 chk.setTrigChk(13,this.sigb13);
 chk.setTrigChk(14,this.sigb14);
 chk.setTrigChk(15,this.sigb15);
this.show(false);
  }
}

class Trig_Radio0_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio0_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio0_0_actionPerformed(e);
  }
}

class Trig_Radio0_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio0_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio0_1_actionPerformed(e);
  }
}

class Trig_Radio0_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio0_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio0_2_actionPerformed(e);
  }
}

class Trig_Radio1_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio1_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio1_0_actionPerformed(e);
  }
}

class Trig_Radio1_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio1_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio1_1_actionPerformed(e);
  }
}

class Trig_Radio1_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio1_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio1_2_actionPerformed(e);
  }
}

class Trig_Radio2_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio2_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio2_0_actionPerformed(e);
  }
}

class Trig_Radio2_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio2_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio2_1_actionPerformed(e);
  }
}

class Trig_Radio2_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio2_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio2_2_actionPerformed(e);
  }
}

class Trig_Radio3_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio3_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio3_0_actionPerformed(e);
  }
}

class Trig_Radio3_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio3_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio3_1_actionPerformed(e);
  }
}

class Trig_Radio3_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio3_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio3_2_actionPerformed(e);
  }
}

class Trig_Radio4_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio4_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio4_0_actionPerformed(e);
  }
}

class Trig_Radio4_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio4_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio4_1_actionPerformed(e);
  }
}

class Trig_Radio4_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio4_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio4_2_actionPerformed(e);
  }
}

class Trig_Radio5_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio5_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio5_0_actionPerformed(e);
  }
}

class Trig_Radio5_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio5_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio5_1_actionPerformed(e);
  }
}

class Trig_Radio5_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio5_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio5_2_actionPerformed(e);
  }
}

class Trig_Radio6_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio6_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio6_0_actionPerformed(e);
  }
}

class Trig_Radio6_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio6_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio6_1_actionPerformed(e);
  }
}

class Trig_Radio6_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio6_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio6_2_actionPerformed(e);
  }
}

class Trig_Radio7_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio7_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio7_0_actionPerformed(e);
  }
}

class Trig_Radio7_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio7_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio7_1_actionPerformed(e);
  }
}

class Trig_Radio7_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio7_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio7_2_actionPerformed(e);
  }
}

class Trig_Radio8_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio8_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio8_0_actionPerformed(e);
  }
}

class Trig_Radio8_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio8_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio8_1_actionPerformed(e);
  }
}

class Trig_Radio8_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio8_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio8_2_actionPerformed(e);
  }
}

class Trig_Radio9_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio9_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio9_0_actionPerformed(e);
  }
}

class Trig_Radio9_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio9_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio9_1_actionPerformed(e);
  }
}

class Trig_Radio9_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio9_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio9_2_actionPerformed(e);
  }
}

class Trig_Radio10_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio10_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio10_0_actionPerformed(e);
  }
}

class Trig_Radio10_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio10_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio10_1_actionPerformed(e);
  }
}

class Trig_Radio10_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio10_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio10_2_actionPerformed(e);
  }
}

class Trig_Radio11_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio11_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio11_0_actionPerformed(e);
  }
}

class Trig_Radio11_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio11_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio11_1_actionPerformed(e);
  }
}

class Trig_Radio11_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio11_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio11_2_actionPerformed(e);
  }
}

class Trig_Radio12_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio12_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio12_0_actionPerformed(e);
  }
}

class Trig_Radio12_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio12_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio12_1_actionPerformed(e);
  }
}

class Trig_Radio12_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio12_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio12_2_actionPerformed(e);
  }
}

class Trig_Radio13_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio13_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio13_0_actionPerformed(e);
  }
}

class Trig_Radio13_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio13_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio13_1_actionPerformed(e);
  }
}

class Trig_Radio13_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio13_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio13_2_actionPerformed(e);
  }
}

class Trig_Radio14_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio14_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio14_0_actionPerformed(e);
  }
}

class Trig_Radio14_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio14_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio14_1_actionPerformed(e);
  }
}

class Trig_Radio14_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio14_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio14_2_actionPerformed(e);
  }
}

class Trig_Radio15_0_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio15_0_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio15_0_actionPerformed(e);
  }
}

class Trig_Radio15_1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio15_1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio15_1_actionPerformed(e);
  }
}

class Trig_Radio15_2_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_Radio15_2_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Radio15_2_actionPerformed(e);
  }
}

class Trig_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Trig adaptee;

  Trig_jButton1_actionAdapter(Trig adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}