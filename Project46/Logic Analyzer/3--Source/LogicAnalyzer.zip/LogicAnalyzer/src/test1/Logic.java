package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Logic {

  private int []sq= new int[16];

  public Logic() {

    for(int i=0;i<16;i++){
     int ranValue = (int)(Math.random()*2);
     sq[i] = ranValue;
    }

  }

  public Logic(int a,int b,int c,int d,int e,int f,int g,int h,int i,int j,int k,int l,int m,int n,int o,int p){
  sq[0] = a;
  sq[1] = b;
  sq[2] = c;
  sq[3] = d;
  sq[4] = e;
  sq[5] = f;
  sq[6] = g;
  sq[7] = h;
  sq[8] = i;
  sq[9] = j;
  sq[10] = k;
  sq[11] = l;
  sq[12] = m;
  sq[13] = n;
  sq[14] = o;
  sq[15] = p;

  }

  public int getIndex(int position){
  int a=0;
             a = sq[position];

    return a;
  }



}