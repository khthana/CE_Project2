package test1;

import java.util.BitSet;
import java.lang.*;
import java.awt.*;

public class MBinary extends MNumber {
  protected BitSet bNumber;

  MBinary(String strInput) {
    this.name = "BIN";
    fromString(strInput);
  }

  MBinary(double dInput) {
    this.name = "BIN";
    fromDouble(dInput);
  }

  public double toDouble() {
    return this.dNumber;
  }

  public void fromDouble(double dInput) {
    //set dNumber
    this.dNumber = dInput;
    //set bNumber
    this.setBitSet(dInput);
  }

  public String toString() {
    String str = "";
    for(int i=0; i<this.nDigits; i++) {
      if(this.bNumber.get(i) == true)
            str += "1";
      else  str += "0";
    }
    return str;
  }

  public void fromString(String strInput) {
    //set bNumber
    bNumber = new BitSet(strInput.length());
    nDigits = strInput.length();
    for(int i=0; i<strInput.length(); i++) {
      if(strInput.charAt(i) == '1')
           bNumber.set(i);
      else bNumber.clear(i);
    }
    //set dNumber
    double ans = 0;
    int j=strInput.length() -1;
    for(int i=0; i<strInput.length(); i++) {
      if(strInput.charAt(j) == '1')
           ans = ans + Math.pow(2,i);
      j--;
    }
    dNumber = ans;
  }

  protected void setBitSet(double dInput) {
    //dInput in decimal to binary in the BitSet bNumber.
    String str = "";
    int input = (int)dInput;
    do {
      if(input % 2 == 1)
           str += "1";
      else str += "0";
      input /= 2;
    }while(input > 0);

    bNumber = new BitSet(str.length());
    nDigits = str.length();

    int j=str.length() -1;
    for(int i=0; i < str.length(); i++) {
      if(str.charAt(i) == '1')
           bNumber.set(j);
      else bNumber.clear(j);
      j--;
    }
  }

  protected BitSet toBitset() {
     return bNumber;
  }

  public double or(double in) {
    MBinary x = new MBinary(in);
    int len = (x.nDigits < this.nDigits) ? this.nDigits : x.nDigits;
    String str = new String("");
    for(int i=0; i<len; i++) {
      if(this.bNumber.get(i) == false && x.bNumber.get(i) == false)
           str += "0";
      else if(this.bNumber.get(i) == false && x.bNumber.get(i) == true)
           str += "1";
      else if(this.bNumber.get(i) == true && x.bNumber.get(i) == false)
           str += "1";
      else str += "1";
    }
    x = new MBinary(str);
    return x.toDouble();
  }

  public double and(double in) {
    MBinary x = new MBinary(in);
    int len = (x.nDigits < this.nDigits) ? this.nDigits : x.nDigits;
    String str = new String("");
    for(int i=0; i<len; i++) {
      if(this.bNumber.get(i) == false && x.bNumber.get(i) == false)
           str += "0";
      else if(this.bNumber.get(i) == false && x.bNumber.get(i) == true)
           str += "0";
      else if(this.bNumber.get(i) == true && x.bNumber.get(i) == false)
           str += "0";
      else str += "1";
    }
    x = new MBinary(str);
    return x.toDouble();
  }

  public double xor(double in) {
    MBinary x = new MBinary(in);
    int len = (x.nDigits < this.nDigits) ? this.nDigits : x.nDigits;
    String str = new String("");
    for(int i=0; i<len; i++) {
      if(this.bNumber.get(i) == false && x.bNumber.get(i) == false)
           str += "0";
      else if(this.bNumber.get(i) == false && x.bNumber.get(i) == true)
           str += "1";
      else if(this.bNumber.get(i) == true && x.bNumber.get(i) == false)
           str += "1";
      else str += "0";
    }
    x = new MBinary(str);
    return x.toDouble();
  }

  public double not() {
    String str = new String("");
    for(int j=0; j<(this.nBytes - this.nDigits); j++)
      str += "1";
    for(int i=0; i<this.nDigits; i++) {
      if(this.bNumber.get(i) == false)
           str += "1";
      else str += "0";
    }
    MBinary x = new MBinary(str);
    return x.toDouble();
  }
}