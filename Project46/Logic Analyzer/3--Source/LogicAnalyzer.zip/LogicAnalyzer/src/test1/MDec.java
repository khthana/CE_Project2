package test1;

import java.lang.*;
import java.awt.*;

public class MDec extends MNumber {

  protected String decNumber;

  MDec(String strInput) {
    this.name = "DEC";
    fromString(strInput);
  }

  MDec(double dInput) {
    this.name = "DEC";
    fromDouble(dInput);
  }

  public double toDouble() {
    return this.dNumber;
  }

  public void fromDouble(double dInput) {
    //set dNumber
    dNumber = dInput;
    //set octNumber
    decNumber = String.valueOf(dInput);
    this.nDigits = decNumber.length();
  }

  public String toString() {
    return decNumber;
  }

  public void fromString(String strInput) {
    //set decNumber
    decNumber = strInput;
    //set dNumber
    dNumber = (Double.valueOf(strInput)).doubleValue();
    //set nDigits
    this.nDigits = strInput.length();
  }

}