package test1;

import java.lang.*;
import java.awt.*;
import java.util.*;

import javax.swing.*;


public class mainprogram  extends JFrame  {

  public static void main(String args[]) {
    LogicStore newlogic = new LogicStore();
 //  newlogic.initeV();
   Frame1 Frame =  new Frame1();


  }

}