package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.awt.event.MouseEvent;
import java.io.*;
import java.lang.Object;
import java.awt.print.*;
import java.awt.Graphics;
import java.awt.print.PageFormat;
import java.awt.event.ActionEvent;
import java.text.DecimalFormat;



class Frame1 extends JFrame  implements Printable,ActionListener {


Container c;
  private String test="";
private byte [] data;
private TextArea textArea1 = new TextArea();
private TextArea textArea2 = new TextArea();
private ObjectOutputStream output;
private FileWriter writer;
private String array[];
private int arraynum[];
Book bk;
PageFormat pf;

read reader = new read();


setLogic setlogic = new setLogic();
write wrt = new write();
checkstate check = new checkstate();
  DrawPanel jPanel1 = new DrawPanel();
 public  static int chkcount;

  JButton jButton1 = new JButton();
  JMenuBar jMenuBar1 = new JMenuBar();


int ovdouble;
boolean ovG1enable;
boolean ovG2enable;
boolean ovG3enable;
int b ;
LogicStore logic = new LogicStore();
Frame2In G1 = new Frame2In();
Frame3In G2 = new Frame3In();
f4In G3 = new f4In();
private String value_combobox1[ ] = {"24MHz","12MHz","6MHz","2MHz","1MHz","500kHz","200kHz","100kHz","50kHz","20kHz","10kHz","5kHz","2kHz","1kHz"};
private String samRateSelect[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N",};
  int drawstart2;
  JButton jButton2 = new JButton();
  TitledBorder titledBorder1;
  JScrollBar jSbar1 = new JScrollBar();
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  JComboBox jComboBox1 = new JComboBox(value_combobox1);
  JLabel jLabel17 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  TitledBorder titledBorder4;
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  JMenuItem jMenuItem3 = new JMenuItem();
  JMenu jMenu2 = new JMenu();
  JMenuItem jMenuItem4 = new JMenuItem();
  private int ovSbar;
  JMenu jMenu3 = new JMenu();
  JMenu jMenu4 = new JMenu();
  JMenuItem jMenuItem5 = new JMenuItem();
  JMenuItem jMenuItem6 = new JMenuItem();
  JMenuItem jMenuItem8 = new JMenuItem();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  JButton jButton11 = new JButton();
  JButton jButton12 = new JButton();
  JButton jButton13 = new JButton();
  JButton jButton14 = new JButton();
  JButton jButton15 = new JButton();
  JButton jButton16 = new JButton();
  JButton jButton17 = new JButton();
  JButton jButton18 = new JButton();
  JButton jButton19 = new JButton();
  JButton jButton20 = new JButton();
  JButton jButton21 = new JButton();
  JButton jButton22 = new JButton();
  JButton jButton23 = new JButton();
  JMenuItem jMenuItem9 = new JMenuItem();
  JPanel jPanel2 = new JPanel();
  JButton jButton25 = new JButton();
  JButton jButton26 = new JButton();
  JCheckBoxMenuItem jCheckBoxMenuItem1 = new JCheckBoxMenuItem();
  JCheckBoxMenuItem jCheckBoxMenuItem2 = new JCheckBoxMenuItem();
  JMenuItem jMenuItem7 = new JMenuItem();
  JMenuItem jMenuItem10 = new JMenuItem();
  JMenuItem jMenuItem11 = new JMenuItem();

  public Frame1() {



    setTitle("Logic Analyzer");
    setSize(750,800);
    show();
 reader.startRead();

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

public void setjSbar(int i){

          jSbar1.setValue(i);
  }
public void setMaxjSbar(int i){
   jSbar1.setMaximum(i);

  }

  private void jbInit() throws Exception {
    jTextField1.setBackground(Color.white);
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    this.getContentPane().setLayout(null);
    this.setSize(new Dimension(1029, 737));
    this.setVisible(true);




    jPanel1.setLayout(null);
    jButton1.setBounds(new Rectangle(8, 6, 91, 41));
    jButton1.setText("Zoom In");
    jButton1.addActionListener(new Frame1_jButton1_actionAdapter(this));


    jButton2.setBounds(new Rectangle(8, 48, 91, 40));
    jButton2.setText("Zoom Out");
    jButton2.addActionListener(new Frame1_jButton2_actionAdapter(this));



    jPanel1.setBackground(SystemColor.control);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(9, 92, 1003, 586));
    jPanel1.addMouseMotionListener(new Frame1_jPanel1_mouseMotionAdapter(this));
    jPanel1.addMouseListener(new Frame1_jPanel1_mouseAdapter(this));

    jSbar1.setMaximum(logic.getMaxV());
    jSbar1.setOrientation(JScrollBar.HORIZONTAL);
    jSbar1.setUnitIncrement(1);
    jSbar1.setBorder(null);
    jSbar1.setOpaque(true);
    jSbar1.setPreferredSize(new Dimension(48, 17));
    jSbar1.setRequestFocusEnabled(true);
    jSbar1.setToolTipText("");
    jSbar1.setBounds(new Rectangle(0, 571, 1002, 14));
    jSbar1.addAdjustmentListener(new Frame1_jSbar1_adjustmentAdapter(this));

    jComboBox1.setDoubleBuffered(false);
    jComboBox1.setBounds(new Rectangle(12, 45, 92, 21));
    jComboBox1.addActionListener(new Frame1_jComboBox1_actionAdapter(this));



    jLabel17.setText("Sample Rate");
    jLabel17.setBounds(new Rectangle(23, 17, 83, 15));
    jTextField1.setBorder(BorderFactory.createEtchedBorder());
    jTextField1.setEditable(false);
    jTextField1.setText("Cursor      Sample#:0000 Value:7D44H 00000000 us");
    jTextField1.setBounds(new Rectangle(106, 1, 366, 21));
    jTextField2.setBounds(new Rectangle(106, 24, 366, 21));
    jTextField2.setBackground(Color.white);
    jTextField2.setBorder(BorderFactory.createEtchedBorder());
    jTextField2.setEditable(false);
    jTextField2.setText("X Cursor   Sample#:0000 Value:C925H 00000000 us");
    jTextField3.setBackground(Color.white);
    jTextField3.setBorder(BorderFactory.createEtchedBorder());
    jTextField3.setEditable(false);
    jTextField3.setText("Y Cursor   Sample#:0000 Value:5DD6H 00000000 us");
    jTextField3.setBounds(new Rectangle(105, 47, 366, 21));
    jTextField4.setBounds(new Rectangle(105, 70, 366, 21));
    jTextField4.setBackground(Color.white);
    jTextField4.setBorder(BorderFactory.createEtchedBorder());
    jTextField4.setEditable(false);
    jTextField4.setText("X to Y        Start:0000 Stop:0000 Samples:0000 Time: 0 us");
    jMenu1.setText("File");
    jMenuItem1.setText("Load Data");
    jMenuItem1.addActionListener(new Frame1_jMenuItem1_actionAdapter(this));
    jMenuItem2.setText("Save Data As..");
    jMenuItem2.addActionListener(new Frame1_jMenuItem2_actionAdapter(this));
    jMenuItem3.setText("Print...");
    jMenuItem3.addActionListener(new Frame1_jMenuItem3_actionAdapter(this));
    jMenu2.setText("Edit");
    jMenuItem4.setText("Search for Pattern");
    jMenuItem4.addActionListener(new Frame1_jMenuItem4_actionAdapter(this));
    jMenu3.setText("View");
    jMenu4.setText("Group");
    jMenuItem5.setText("Bus 1");
    jMenuItem5.addActionListener(new Frame1_jMenuItem5_actionAdapter(this));
    jMenuItem6.setText("Bus 2");
    jMenuItem6.addActionListener(new Frame1_jMenuItem6_actionAdapter(this));
    jMenuItem8.setText("Bus 3");
    jMenuItem8.addActionListener(new Frame1_jMenuItem8_actionAdapter(this));
    jButton3.setBounds(new Rectangle(1, 1, 101, 30));
    jButton3.setText("Signal 0");
    jButton3.setToolTipText("Set Signal 0");
    jButton3.addActionListener(new Frame1_jButton3_actionAdapter(this));
    jButton4.setBounds(new Rectangle(1, 28, 101, 32));
    jButton4.setText("Signal 1");
    jButton4.addActionListener(new Frame1_jButton4_actionAdapter(this));
    jButton5.setBounds(new Rectangle(1, 58, 101, 33));
    jButton5.setText("Signal 2");
    jButton5.addActionListener(new Frame1_jButton5_actionAdapter(this));
    jButton8.setText("Signal 5");
    jButton8.addActionListener(new Frame1_jButton8_actionAdapter(this));
    jButton8.setBounds(new Rectangle(1, 147, 101, 33));
    jButton7.setText("Signal 4");
    jButton7.addActionListener(new Frame1_jButton7_actionAdapter(this));
    jButton7.setBounds(new Rectangle(1, 117, 101, 32));
    jButton6.setText("Signal 3");
    jButton6.addActionListener(new Frame1_jButton6_actionAdapter(this));
    jButton6.setBounds(new Rectangle(1, 89, 101, 30));
    jButton9.setBounds(new Rectangle(1, 178, 101, 33));
    jButton9.setText("Signal 6");
    jButton9.addActionListener(new Frame1_jButton9_actionAdapter(this));
    jButton10.setText("Signal 7");
    jButton10.addActionListener(new Frame1_jButton10_actionAdapter(this));
    jButton10.setBounds(new Rectangle(1, 209, 101, 33));
    jButton11.setBounds(new Rectangle(1, 240, 101, 31));
    jButton11.setText("Signal 8");
    jButton11.addActionListener(new Frame1_jButton11_actionAdapter(this));
    jButton12.setText("Signal 9");
    jButton12.addActionListener(new Frame1_jButton12_actionAdapter(this));
    jButton12.setBounds(new Rectangle(1, 269, 101, 31));
    jButton13.setText("Signal 10");
    jButton13.addActionListener(new Frame1_jButton13_actionAdapter(this));
    jButton13.setBounds(new Rectangle(1, 298, 101, 31));
    jButton14.setText("Signal 11");
    jButton14.addActionListener(new Frame1_jButton14_actionAdapter(this));
    jButton14.setBounds(new Rectangle(1, 327, 101, 31));
    jButton15.setText("Signal 12");
    jButton15.addActionListener(new Frame1_jButton15_actionAdapter(this));
    jButton15.setBounds(new Rectangle(1, 356, 101, 33));
    jButton16.setBounds(new Rectangle(1, 387, 101, 33));
    jButton16.setText("Signal 13");
    jButton16.addActionListener(new Frame1_jButton16_actionAdapter(this));
    jButton17.setBounds(new Rectangle(1, 418, 101, 33));
    jButton17.setText("Signal 14");
    jButton17.addActionListener(new Frame1_jButton17_actionAdapter(this));
    jButton18.setBounds(new Rectangle(1, 449, 101, 31));
    jButton18.setText("Signal 15");
    jButton18.addActionListener(new Frame1_jButton18_actionAdapter(this));
    jButton19.setBounds(new Rectangle(1, 478, 101, 32));
    jButton19.setText("Bus 1");
    jButton19.addActionListener(new Frame1_jButton19_actionAdapter(this));
    jButton20.setBounds(new Rectangle(1, 508, 101, 32));
    jButton20.setText("jButton20");
    jButton20.addActionListener(new Frame1_jButton20_actionAdapter(this));
    jButton21.setBounds(new Rectangle(1, 538, 101, 34));
    jButton21.setText("jButton21");
    jButton21.addActionListener(new Frame1_jButton21_actionAdapter(this));
    jButton22.setBounds(new Rectangle(477, 32, 95, 17));
    jButton22.setText("Go to X");
    jButton22.addActionListener(new Frame1_jButton22_actionAdapter(this));
    jButton23.setBounds(new Rectangle(477, 53, 95, 18));
    jButton23.setText("Go to Y");
    jButton23.addActionListener(new Frame1_jButton23_actionAdapter(this));
    jMenuItem9.setText("New");
    jMenuItem9.addActionListener(new Frame1_jMenuItem9_actionAdapter(this));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(646, 4, 281, 82));
    jPanel2.setLayout(null);
    jButton25.setBounds(new Rectangle(135, 14, 124, 25));
    jButton25.setText("Start capture");
    jButton25.addActionListener(new Frame1_jButton25_actionAdapter(this));
    jButton26.setBounds(new Rectangle(135, 45, 124, 25));
    jButton26.setText("Stop capture");
    jButton26.addActionListener(new Frame1_jButton26_actionAdapter(this));
    jCheckBoxMenuItem1.setText("Color Waveform");
    jCheckBoxMenuItem1.addActionListener(new Frame1_jCheckBoxMenuItem1_actionAdapter(this));
    jCheckBoxMenuItem2.setText("List");
    jCheckBoxMenuItem2.addActionListener(new Frame1_jCheckBoxMenuItem2_actionAdapter(this));
    jMenuItem7.setText("Environment Settings");
    jMenuItem7.addActionListener(new Frame1_jMenuItem7_actionAdapter(this));
    jMenuItem10.setText("Exit");
    jMenuItem10.addActionListener(new Frame1_jMenuItem10_actionAdapter(this));
    jMenuItem11.setText("Print Setup");
    jMenuItem11.addActionListener(new Frame1_jMenuItem11_actionAdapter(this));
    jPanel1.add(jButton3, null);
    jPanel1.add(jButton17, null);
    jPanel1.add(jButton4, null);
    jPanel1.add(jButton5, null);
    jPanel1.add(jButton6, null);
    jPanel1.add(jButton7, null);
    jPanel1.add(jButton8, null);
    jPanel1.add(jButton9, null);
    jPanel1.add(jButton10, null);
    jPanel1.add(jButton11, null);
    jPanel1.add(jButton12, null);
    jPanel1.add(jButton13, null);
    jPanel1.add(jButton14, null);
    jPanel1.add(jButton15, null);
    jPanel1.add(jButton16, null);
    jPanel1.add(jButton18, null);
    jPanel1.add(jButton19, null);
    jPanel1.add(jButton20, null);
    jPanel1.add(jButton21, null);
    jPanel1.add(jSbar1, null);
    this.getContentPane().add(jTextField1, null);
    this.getContentPane().add(jTextField2, null);
    this.getContentPane().add(jTextField3, null);
    this.getContentPane().add(jTextField4, null);
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jButton22, null);
    this.getContentPane().add(jButton23, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(jComboBox1, null);
    jPanel2.add(jButton25, null);
    jPanel2.add(jButton26, null);
    jPanel2.add(jLabel17, null);
    jMenuBar1.add(jMenu1);
    jMenuBar1.add(jMenu2);
    jMenuBar1.add(jMenu3);
     this.setJMenuBar(jMenuBar1);
    jMenu1.add(jMenuItem9);
    jMenu1.add(jMenuItem1);
    jMenu1.add(jMenuItem2);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem11);
    jMenu1.add(jMenuItem3);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem10);
    jMenu2.add(jMenuItem4);
    jMenu2.add(jMenu4);
    jMenu2.add(jMenuItem7);
    jMenu4.add(jMenuItem5);
    jMenu4.add(jMenuItem6);
    jMenu4.add(jMenuItem8);
    jMenu3.add(jCheckBoxMenuItem1);
    jMenu3.add(jCheckBoxMenuItem2);


  }



  void jButton1_actionPerformed(ActionEvent e) {

//jPanel1.incNewPositionmouse();




   DrawPanel a = new DrawPanel();
     b = a.getduble();
     if(b<80){
     b = b*2;}
     a.setduble(b);
     System.out.println("Zoom in "+a.getduble());

     repaint();

  }


  void jButton2_actionPerformed(ActionEvent e) {

//jPanel1.decNewPositionmouse();

    DrawPanel a = new DrawPanel();
        b = a.getduble();
        if(b>10){
        b = b/2;}
        a.setduble(b);
        System.out.println("Zoom out"+a.getduble());

        repaint();

  }

  void jSbar1_adjustmentValueChanged(AdjustmentEvent e) {

System.out.println("jSbar change"+jSbar1.getValue()+" "+e.getValue());
  //  drawstart2 = jSbar1.getValue();

jPanel1.setDrawStart(jSbar1.getValue());
//    System.out.println("iPalm" +drawstart2);
                 jPanel1.setlogicstart(jPanel1.getDrawStart());

                 if(ovSbar>jPanel1.getDrawStart()){
                    int a = ovSbar-jPanel1.getDrawStart();
                        for(int i=0;i<a;i++){
                            jPanel1.incMouse();}
                      }
                    if(ovSbar<jPanel1.getDrawStart()){
                      int a = jPanel1.getDrawStart()-ovSbar;
                      for(int i=0;i<a;i++){
                           jPanel1.decMouse();}
                      }
                 ovSbar = jSbar1.getValue();
                 repaint();

  }


  void jPanel1_mouseClicked(MouseEvent e) {
int m = e.getModifiers();



    if(( m & InputEvent.BUTTON1_MASK)!=0){

      String cursorX = jPanel1.strMouse1();
      int position = jPanel1.getx_mouse1Sq();

      String po = this.chkTimecursor(position);

      jTextField2.setText(cursorX+po);

       }
        if(( m & InputEvent.BUTTON3_MASK)!=0){

          String cursorY = jPanel1.strMouse3();
          int position = jPanel1.getx_mouse3Sq();

      String po = this.chkTimecursor(position);


           jTextField3.setText(cursorY+po);
        }

String cursorXY = jPanel1.strMouseXY();

        int position = jPanel1.getx_mouse1Sq()-jPanel1.getx_mouse3Sq();
         int absPosition = Math.abs(position);

     String po = this.chkTimecursor(absPosition);


          jTextField4.setText(cursorXY+po);

  }

  void jComboBox1_actionPerformed(ActionEvent e) {

  }



  void jButton3_actionPerformed(ActionEvent e) {

  setlogic.show(0);
    /*  String namSig3;
       namSig3 = JOptionPane.showInputDialog("Enter new signal name.");
       jButton3.setText(namSig3);
      */

  }

  void jButton4_actionPerformed(ActionEvent e) {

   setlogic.show(1);

 }

 void jButton5_actionPerformed(ActionEvent e) {

 setlogic.show(2);
   /*String namSig5;
              namSig5 = JOptionPane.showInputDialog("Enter new signal name.");
              jButton5.setText(namSig5);
*/
  }

  void jButton6_actionPerformed(ActionEvent e) {
    setlogic.show(3);

  }

  void jButton7_actionPerformed(ActionEvent e) {
    setlogic.show(4);

  }

  void jButton8_actionPerformed(ActionEvent e) {
    setlogic.show(5);

  }

  void jButton9_actionPerformed(ActionEvent e) {
    setlogic.show(6);

  }

  void jButton10_actionPerformed(ActionEvent e) {
    setlogic.show(7);

  }

  void jButton11_actionPerformed(ActionEvent e) {
    setlogic.show(8);

  }

  void jButton12_actionPerformed(ActionEvent e) {
    setlogic.show(9);

  }

  void jButton13_actionPerformed(ActionEvent e) {
    setlogic.show(10);

  }

  void jButton14_actionPerformed(ActionEvent e) {
    setlogic.show(11);

  }

  void jButton15_actionPerformed(ActionEvent e) {
    setlogic.show(12);

  }

  void jButton16_actionPerformed(ActionEvent e) {
    setlogic.show(13);

  }

  void jButton17_actionPerformed(ActionEvent e) {
    setlogic.show(14);

  }

  void jButton18_actionPerformed(ActionEvent e) {
    setlogic.show(15);

  }

  void jPanel1_mouseMoved(MouseEvent e) {

       String cursor = jPanel1.strCursor();


       int position = jPanel1.getx_mousemove();
if(position<logic.getMaxV()){
     String po = this.chkTimecursor(position);
       jTextField1.setText(cursor+po);
}
       jButton19.setText(G1.getLabelG1());
       jButton20.setText(G2.getLabelG2());
        jButton21.setText(G3.getLabelG2());
         jSbar1.setMaximum(logic.getMaxV());

         jButton3.setText(check.getLogicName(0));
         jButton4.setText(check.getLogicName(1));
         jButton5.setText(check.getLogicName(2));
         jButton6.setText(check.getLogicName(3));
         jButton7.setText(check.getLogicName(4));
         jButton8.setText(check.getLogicName(5));
         jButton9.setText(check.getLogicName(6));
         jButton10.setText(check.getLogicName(7));
         jButton11.setText(check.getLogicName(8));
         jButton12.setText(check.getLogicName(9));
         jButton13.setText(check.getLogicName(10));
         jButton14.setText(check.getLogicName(11));
         jButton15.setText(check.getLogicName(12));
         jButton16.setText(check.getLogicName(13));
         jButton17.setText(check.getLogicName(14));
         jButton18.setText(check.getLogicName(15));

int color;
         color = check.getColor(0);   //get bg color
              if(color==1){
              jPanel1.setBackground(SystemColor.black);
             }else if(color==2){
                jPanel1.setBackground(SystemColor.GRAY);
             }else if(color==3){
                 jPanel1.setBackground(SystemColor.lightGray);
             }else if(color==4){
                    jPanel1.setBackground(SystemColor.control);
               }else {
                jPanel1.setBackground(SystemColor.white);
             }


//// set color group1
        if(G1.getColor()==1){
          jButton19.setForeground(new Color(0,0,0));
      }else if(G1.getColor()==2){
        jButton19.setForeground(new Color(255,0,255));
      }else if(G1.getColor()==3){
        jButton19.setForeground(new Color(0,0,255));
      }else if(G1.getColor()==4){
         jButton19.setForeground(new Color(200,0,0));
      }

//// set color group2
        if(G2.getColor()==1){
          jButton20.setForeground(new Color(0,0,0));
      }else if(G2.getColor()==2){
        jButton20.setForeground(new Color(255,0,255));
      }else if(G2.getColor()==3){
        jButton20.setForeground(new Color(0,0,255));
      }else if(G2.getColor()==4){
         jButton20.setForeground(new Color(200,0,0));
      }

///// set color button logic
   if(check.getcolorWave()){
     int intcolor=check.getLogicColor(0);
                      if(intcolor==0){
                         jButton3.setForeground(SystemColor.BLACK);
                      }else if(intcolor==1){
                         jButton3.setForeground(SystemColor.green);
                      }else if(intcolor==2){
                         jButton3.setForeground(SystemColor.blue);
                      }else if(intcolor==3){
                         jButton3.setForeground(SystemColor.yellow);
                       }
            intcolor=check.getLogicColor(1);
                       if(intcolor==0){
                          jButton4.setForeground(SystemColor.BLACK);
                       }else if(intcolor==1){
                          jButton4.setForeground(SystemColor.green);
                       }else if(intcolor==2){
                          jButton4.setForeground(SystemColor.blue);
                       }else if(intcolor==3){
                          jButton4.setForeground(SystemColor.yellow);
                        }
            intcolor=check.getLogicColor(2);
                       if(intcolor==0){
                          jButton5.setForeground(SystemColor.BLACK);
                       }else if(intcolor==1){
                          jButton5.setForeground(SystemColor.green);
                       }else if(intcolor==2){
                          jButton5.setForeground(SystemColor.blue);
                       }else if(intcolor==3){
                          jButton5.setForeground(SystemColor.yellow);
                        }
          intcolor=check.getLogicColor(3);
                       if(intcolor==0){
                          jButton6.setForeground(SystemColor.BLACK);
                       }else if(intcolor==1){
                          jButton6.setForeground(SystemColor.green);
                       }else if(intcolor==2){
                          jButton6.setForeground(SystemColor.blue);
                       }else if(intcolor==3){
                          jButton6.setForeground(SystemColor.yellow);
                        }
          intcolor=check.getLogicColor(4);
                       if(intcolor==0){
                          jButton7.setForeground(SystemColor.BLACK);
                       }else if(intcolor==1){
                          jButton7.setForeground(SystemColor.green);
                       }else if(intcolor==2){
                          jButton7.setForeground(SystemColor.blue);
                       }else if(intcolor==3){
                          jButton7.setForeground(SystemColor.yellow);
                        }
          intcolor=check.getLogicColor(5);
                        if(intcolor==0){
                           jButton8.setForeground(SystemColor.BLACK);
                        }else if(intcolor==1){
                           jButton8.setForeground(SystemColor.green);
                        }else if(intcolor==2){
                           jButton8.setForeground(SystemColor.blue);
                        }else if(intcolor==3){
                           jButton8.setForeground(SystemColor.yellow);
                         }
          intcolor=check.getLogicColor(6);
                        if(intcolor==0){
                           jButton9.setForeground(SystemColor.BLACK);
                        }else if(intcolor==1){
                           jButton9.setForeground(SystemColor.green);
                        }else if(intcolor==2){
                           jButton9.setForeground(SystemColor.blue);
                        }else if(intcolor==3){
                           jButton9.setForeground(SystemColor.yellow);
                         }
          intcolor=check.getLogicColor(7);
                        if(intcolor==0){
                           jButton10.setForeground(SystemColor.BLACK);
                        }else if(intcolor==1){
                           jButton10.setForeground(SystemColor.green);
                        }else if(intcolor==2){
                           jButton10.setForeground(SystemColor.blue);
                        }else if(intcolor==3){
                           jButton10.setForeground(SystemColor.yellow);
                         }
          intcolor=check.getLogicColor(8);
                         if(intcolor==0){
                            jButton11.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton11.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton11.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton11.setForeground(SystemColor.yellow);
                          }
        intcolor=check.getLogicColor(9);
                         if(intcolor==0){
                            jButton12.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton12.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton12.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton12.setForeground(SystemColor.yellow);
                          }
          intcolor=check.getLogicColor(10);
                         if(intcolor==0){
                            jButton13.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton13.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton13.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton13.setForeground(SystemColor.yellow);
                          }
            intcolor=check.getLogicColor(11);
                         if(intcolor==0){
                            jButton14.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton14.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton14.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton14.setForeground(SystemColor.yellow);
                          }
            intcolor=check.getLogicColor(12);
                         if(intcolor==0){
                            jButton15.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton15.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton15.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton15.setForeground(SystemColor.yellow);
                          }
            intcolor=check.getLogicColor(13);
                         if(intcolor==0){
                            jButton16.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton16.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton16.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton16.setForeground(SystemColor.yellow);
                          }
            intcolor=check.getLogicColor(14);
                         if(intcolor==0){
                            jButton17.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton17.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton17.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton17.setForeground(SystemColor.yellow);
                          }
              intcolor=check.getLogicColor(15);
                         if(intcolor==0){
                            jButton18.setForeground(SystemColor.BLACK);
                         }else if(intcolor==1){
                            jButton18.setForeground(SystemColor.green);
                         }else if(intcolor==2){
                            jButton18.setForeground(SystemColor.blue);
                         }else if(intcolor==3){
                            jButton18.setForeground(SystemColor.yellow);
                         }

   }

  }

  void jButton19_actionPerformed(ActionEvent e) {

  //  Frame2In newG = new Frame2In();
    Frame2 f2 = new Frame2();
    f2.setSigname(0,jButton3.getText());
    f2.setSigname(1,jButton4.getText());
    f2.setSigname(2,jButton5.getText());
    f2.setSigname(3,jButton6.getText());
    f2.setSigname(4,jButton7.getText());
    f2.setSigname(5,jButton8.getText());
    f2.setSigname(6,jButton9.getText());
    f2.setSigname(7,jButton10.getText());
    f2.setSigname(8,jButton11.getText());
    f2.setSigname(9,jButton12.getText());
    f2.setSigname(10,jButton13.getText());
    f2.setSigname(11,jButton14.getText());
    f2.setSigname(12,jButton15.getText());
    f2.setSigname(13,jButton16.getText());
    f2.setSigname(14,jButton17.getText());
    f2.setSigname(15,jButton18.getText());

 }

  void jButton110_actionPerformed(ActionEvent e) {

 //   Frame3In newG = new Frame3In();
    Frame3 f3 = new Frame3();
    //System.out.println("iPalm");
    f3.setSigname(0,jButton3.getText());
    f3.setSigname(1,jButton4.getText());
    f3.setSigname(2,jButton5.getText());
    f3.setSigname(3,jButton8.getText());
    f3.setSigname(4,jButton7.getText());
    f3.setSigname(5,jButton6.getText());
    f3.setSigname(6,jButton9.getText());
    f3.setSigname(7,jButton10.getText());
    f3.setSigname(8,jButton11.getText());
    f3.setSigname(9,jButton12.getText());
    f3.setSigname(10,jButton13.getText());
    f3.setSigname(11,jButton14.getText());
    f3.setSigname(12,jButton15.getText());
    f3.setSigname(13,jButton16.getText());
    f3.setSigname(14,jButton17.getText());
    f3.setSigname(15,jButton18.getText());

  }

  void jButton20_actionPerformed(ActionEvent e) {
    Frame3 f3 = new Frame3();

       f3.setSigname(0,jButton3.getText());
       f3.setSigname(1,jButton4.getText());
       f3.setSigname(2,jButton5.getText());
       f3.setSigname(3,jButton6.getText());
       f3.setSigname(4,jButton7.getText());
       f3.setSigname(5,jButton8.getText());
       f3.setSigname(6,jButton9.getText());
       f3.setSigname(7,jButton10.getText());
       f3.setSigname(8,jButton11.getText());
       f3.setSigname(9,jButton12.getText());
       f3.setSigname(10,jButton13.getText());
       f3.setSigname(11,jButton14.getText());
       f3.setSigname(12,jButton15.getText());
       f3.setSigname(13,jButton16.getText());
       f3.setSigname(14,jButton17.getText());
       f3.setSigname(15,jButton18.getText());

  }

  void jButton21_actionPerformed(ActionEvent e) {
    Frame4 f4 = new Frame4();

           f4.setSigname(0,jButton3.getText());
           f4.setSigname(1,jButton4.getText());
           f4.setSigname(2,jButton5.getText());
           f4.setSigname(3,jButton6.getText());
           f4.setSigname(4,jButton7.getText());
           f4.setSigname(5,jButton8.getText());
           f4.setSigname(6,jButton9.getText());
           f4.setSigname(7,jButton10.getText());
           f4.setSigname(8,jButton11.getText());
           f4.setSigname(9,jButton12.getText());
           f4.setSigname(10,jButton13.getText());
           f4.setSigname(11,jButton14.getText());
           f4.setSigname(12,jButton15.getText());
           f4.setSigname(13,jButton16.getText());
           f4.setSigname(14,jButton17.getText());
           f4.setSigname(15,jButton18.getText());

  }

  void jButton22_actionPerformed(ActionEvent e) {
    jSbar1.setValue(jPanel1.getx_mouse1Sq()-1);

  }

  void jButton23_actionPerformed(ActionEvent e) {
      jSbar1.setValue(jPanel1.getx_mouse3Sq()-1);
  }

  void jMenuItem4_actionPerformed(ActionEvent e) {

    search a = new search(this);
a.setSigname(0,jButton3.getText());
a.setSigname(1,jButton4.getText());
a.setSigname(2,jButton5.getText());
a.setSigname(3,jButton6.getText());
a.setSigname(4,jButton7.getText());
a.setSigname(5,jButton8.getText());
a.setSigname(6,jButton9.getText());
a.setSigname(7,jButton10.getText());
a.setSigname(8,jButton11.getText());
a.setSigname(9,jButton12.getText());
a.setSigname(10,jButton13.getText());
a.setSigname(11,jButton14.getText());
a.setSigname(12,jButton15.getText());
a.setSigname(13,jButton16.getText());
a.setSigname(14,jButton17.getText());
a.setSigname(15,jButton18.getText());


  }

  void jMenuItem3_actionPerformed(ActionEvent e) {
                     showprint();
  }

  void jMenuItem5_actionPerformed(ActionEvent e) {
    Frame2 f2 = new Frame2();
        f2.setSigname(0,jButton3.getText());
        f2.setSigname(1,jButton4.getText());
        f2.setSigname(2,jButton5.getText());
        f2.setSigname(3,jButton6.getText());
        f2.setSigname(4,jButton7.getText());
        f2.setSigname(5,jButton8.getText());
        f2.setSigname(6,jButton9.getText());
        f2.setSigname(7,jButton10.getText());
        f2.setSigname(8,jButton11.getText());
        f2.setSigname(9,jButton12.getText());
        f2.setSigname(10,jButton13.getText());
        f2.setSigname(11,jButton14.getText());
        f2.setSigname(12,jButton15.getText());
        f2.setSigname(13,jButton16.getText());
        f2.setSigname(14,jButton17.getText());
        f2.setSigname(15,jButton18.getText());

  }

  void jMenuItem6_actionPerformed(ActionEvent e) {
    Frame3 f3 = new Frame3();

          f3.setSigname(0,jButton3.getText());
          f3.setSigname(1,jButton4.getText());
          f3.setSigname(2,jButton5.getText());
          f3.setSigname(3,jButton6.getText());
          f3.setSigname(4,jButton7.getText());
          f3.setSigname(5,jButton8.getText());
          f3.setSigname(6,jButton9.getText());
          f3.setSigname(7,jButton10.getText());
          f3.setSigname(8,jButton11.getText());
          f3.setSigname(9,jButton12.getText());
          f3.setSigname(10,jButton13.getText());
          f3.setSigname(11,jButton14.getText());
          f3.setSigname(12,jButton15.getText());
          f3.setSigname(13,jButton16.getText());
          f3.setSigname(14,jButton17.getText());
          f3.setSigname(15,jButton18.getText());

  }

  void jMenuItem8_actionPerformed(ActionEvent e) {
    Frame4 f4 = new Frame4();

               f4.setSigname(0,jButton3.getText());
               f4.setSigname(1,jButton4.getText());
               f4.setSigname(2,jButton5.getText());
               f4.setSigname(3,jButton6.getText());
               f4.setSigname(4,jButton7.getText());
               f4.setSigname(5,jButton8.getText());
               f4.setSigname(6,jButton9.getText());
               f4.setSigname(7,jButton10.getText());
               f4.setSigname(8,jButton11.getText());
               f4.setSigname(9,jButton12.getText());
               f4.setSigname(10,jButton13.getText());
               f4.setSigname(11,jButton14.getText());
               f4.setSigname(12,jButton15.getText());
               f4.setSigname(13,jButton16.getText());
               f4.setSigname(14,jButton17.getText());
               f4.setSigname(15,jButton18.getText());

  }

  private void saveFile(){



    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

    int result = fileChooser.showSaveDialog(this);

    if(result == JFileChooser.CANCEL_OPTION)
      return;

    File fileName = fileChooser.getSelectedFile();

    if( fileName == null || fileName.getName().equals(""))
      JOptionPane.showMessageDialog(this,"Invalid File Name" ,"Invalid File Name",JOptionPane.ERROR_MESSAGE);

    else{
      try {

        BufferedWriter bw =new BufferedWriter(new FileWriter(fileName));

String strSave1;
String strSave="";

        try{

        int max = logic.getMaxV();
           for(int c =  0;c<max;c++){
                 Logic s =(Logic)logic.get(c);
                        for(int b=0;b<16;b++){
                              int logicValue = s.getIndex(b);

                                    strSave1 = Integer.toString(logicValue);
                                    strSave = strSave.concat(strSave1);
                                                         }
                     bw.write(strSave);
                     strSave="";
                         if(c!=max-1){
                                bw.newLine();
                                      }
               }


        }catch (Exception e){}


        bw.close();

   }
   catch(FileNotFoundException e) {
       }
      catch (IOException ioException) {
        JOptionPane.showMessageDialog(this,
        "Error Opening File", "Error",
        JOptionPane.ERROR_MESSAGE);
      }
    }
  }


  private void openfile(){
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);


    int result = fileChooser.showOpenDialog(this);

    if(result == JFileChooser.CANCEL_OPTION)
      return;

    File fileName = fileChooser.getSelectedFile();

    if( fileName == null || fileName.getName().equals(""))
      JOptionPane.showMessageDialog(this,"Invalid File Name" ,"Invalid File Name",JOptionPane.ERROR_MESSAGE);

    else{

      newlogic();

      try {
       FileInputStream inputFile = new FileInputStream(fileName);
        int length = inputFile.available();
        data = new byte [length];
        inputFile.read(data,0,length);

        test = new  String(data,0,length);

 //     System.out.println("length "+length);

for(int i=0;i<=length;i=i+18){

        String aa = test.substring(i,i+1);
       int a = Integer.parseInt(aa);
      String bb = test.substring(i+1,i+2);
       int b = Integer.parseInt(bb);
       String cc = test.substring(i+2,i+3);
       int c = Integer.parseInt(cc);
       String dd = test.substring(i+3,i+4);
       int d = Integer.parseInt(dd);
       String ee = test.substring(i+4,i+5);
       int e = Integer.parseInt(ee);
       String ff = test.substring(i+5,i+6);
       int f = Integer.parseInt(ff);
       String gg = test.substring(i+6,i+7);
       int g = Integer.parseInt(gg);
       String hh = test.substring(i+7,i+8);
       int h = Integer.parseInt(hh);
       String iii = test.substring(i+8,i+9);
       int ii = Integer.parseInt(iii);
       String jj = test.substring(i+9,i+10);
       int j = Integer.parseInt(jj);
       String kk = test.substring(i+10,i+11);
       int k = Integer.parseInt(kk);
       String ll = test.substring(i+11,i+12);
       int l = Integer.parseInt(ll);
       String mm = test.substring(i+12,i+13);
       int m = Integer.parseInt(mm);
       String nn = test.substring(i+13,i+14);
       int n = Integer.parseInt(nn);
       String oo = test.substring(i+14,i+15);
       int o = Integer.parseInt(oo);
       String pp = test.substring(i+15,i+16);
       int p = Integer.parseInt(pp);


   logic.add(a,b,c,d,e,f,g,h,ii,j,k,l,m,n,o,p);
}
check.setLogicCome(true);
// System.out.print("getMaxV "+logic.getMaxV());
 //this.setjSbar(logic.getMaxV());
 jSbar1.setMaximum(logic.getMaxV());
        inputFile.close();
   }
   catch(FileNotFoundException e) {
       }
      catch (IOException ioException) {
        JOptionPane.showMessageDialog(this,
        "Error Opening File", "Error",
        JOptionPane.ERROR_MESSAGE);
      }
    }
  }


  void jMenuItem1_actionPerformed(ActionEvent e) {
     openfile();
  }

 private void newlogic(){
   logic.clearvec();
    jSbar1.setMaximum(0);
   check.setLogicCome(false);
 }
  void jMenuItem9_actionPerformed(ActionEvent e) {

      newlogic();

  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    saveFile();
  }

  void jCheckBoxMenuItem1_actionPerformed(ActionEvent e) {

     boolean i = check.getcolorWave();
        if(i){
            check.setcolorWave(false);

             jButton3.setForeground(new Color(0,0,0));
             jButton4.setForeground(new Color(0,0,0));
             jButton5.setForeground(new Color(0,0,0));
             jButton6.setForeground(new Color(0,0,0));
             jButton7.setForeground(new Color(0,0,0));
             jButton8.setForeground(new Color(0,0,0));
             jButton9.setForeground(new Color(0,0,0));
             jButton10.setForeground(new Color(0,0,0));
             jButton11.setForeground(new Color(0,0,0));
             jButton12.setForeground(new Color(0,0,0));
             jButton13.setForeground(new Color(0,0,0));
             jButton14.setForeground(new Color(0,0,0));
             jButton15.setForeground(new Color(0,0,0));
             jButton16.setForeground(new Color(0,0,0));
             jButton17.setForeground(new Color(0,0,0));
             jButton18.setForeground(new Color(0,0,0));
        }else if(!i){
            check.setcolorWave(true);



        }

  }

  void jButton25_actionPerformed(ActionEvent e) {

/*      logic.add(0,1,0,1,1,1,1,1,0,0,0,0,1,1,0,0);
      logic.add(1,0,1,0,0,0,0,0,1,1,1,1,0,0,1,1);
      check.setLogicCome(true);
       jSbar1.setMaximum(logic.getMaxV());

      jPanel1.repaint();
*/
int samRate = jComboBox1.getSelectedIndex();
//System.out.println(samRateSelect[samRate]);



//System.out.println(jPanel1.getx_mouse1Sq());
  reader.sent(samRateSelect[samRate]);






  }

  void jButton26_actionPerformed(ActionEvent e) {

         reader.sent("O");

  }

  void jCheckBoxMenuItem2_actionPerformed(ActionEvent e) {

    boolean i = check.getviewList();
       if(i){
           check.setviewList(false);

           jPanel1.setduble(ovdouble);
           G1.setEnable(ovG1enable);
           G2.setEnable(ovG2enable);
           G3.setEnable(ovG3enable);
           jButton1.setEnabled(true);
           jButton2.setEnabled(true);
           jButton19.setEnabled(true);
           jButton20.setEnabled(true);
           jButton21.setEnabled(true);
            jMenu4.setEnabled(true);


       }else if(!i){
           check.setviewList(true);

                          ovdouble = jPanel1.getduble();
                          jPanel1.setduble(10);
                          ovG1enable = G1.getEnable();
                          ovG2enable = G2.getEnable();
                          ovG3enable = G3.getEnable();
                          G1.setEnable(false);
                          G2.setEnable(false);
                          G3.setEnable(false);
                          jButton1.setEnabled(false);
                          jButton2.setEnabled(false);
                          jButton19.setEnabled(false);
                          jButton20.setEnabled(false);
                          jButton21.setEnabled(false);
                          jMenu4.setEnabled(false);

       }

  }

  void jMenuItem7_actionPerformed(ActionEvent e) {
       EnvSet Env = new EnvSet();
  }


public void showprint(){

    PrinterJob pj = PrinterJob.getPrinterJob();
         pj.setPrintable(this);
         if(pj.printDialog()){
           try{
               pj.print();
           }catch(Exception e){
             System.out.println(e);
           }
             }

  }

  public void showPrintPreview(){

      PrinterJob pj = PrinterJob.getPrinterJob();
      bk = new Book();
      pf = pj.pageDialog(pj.defaultPage());
      bk.append(this,pf,1);
      pj.setPageable(bk);
      if(pj.printDialog()){
           try{
               pj.print();
           }catch(Exception e){
             System.out.println(e);
           }
             }

  }

  public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException{

     if(pageIndex>0){
       return NO_SUCH_PAGE;
     }else{

       Graphics2D g2 = (Graphics2D)g;

       g2.translate(pf.getImageableX(),pf.getImageableY());
       int h = jPanel1.getHeight();
       int w = jPanel1.getWidth();
     g2.scale(0.4,0.4);
     g2.drawString("Logic Analyzer KMITL CE",850f,20f);

      // jPanel1.print(g2);
     this.print(g2);
        return PAGE_EXISTS;
     }

  }

  public String chkTimecursor(int position1){
      String sum="";


      DecimalFormat teedigit = new DecimalFormat("0");
double ipalm1 = 1;
double ipalm2 = 24;
double sumtime=0;



      int samRate1 = jComboBox1.getSelectedIndex();
          if(samRate1==0){     //////// 24MHz
          sumtime = ((ipalm1/ipalm2)*(position1))*1000;
               sum = teedigit.format(sumtime)+"ns";
          }else if(samRate1==1) {
            ipalm2 = 12;      /////// 12MHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"ns";
          }else if(samRate1==2) {
            ipalm2 = 6;      /////// 6MHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"ns";
          }else if(samRate1==3) {
            ipalm2 = 2;      /////// 2MHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"ns";
          }else if(samRate1==4) {
            ipalm2 = 1;      /////// 1MHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==5) {
            ipalm2 = 500;      /////// 500kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==6) {
            ipalm2 = 200;      /////// 200kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==7) {
            ipalm2 = 100;      /////// 100kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==8) {
            ipalm2 = 50;      /////// 50kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==9) {
            ipalm2 = 20;      /////// 20kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==10) {
            ipalm2 = 10;      /////// 10kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==11) {
            ipalm2 = 5;      /////// 5kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else if(samRate1==12) {
            ipalm2 = 2;      /////// 2kHz
            sumtime = ((ipalm1/ipalm2)*(position1))*1000;
            sum = teedigit.format(sumtime)+"us";
          }else{
            ipalm2 = 1;      /////// 1kHz
              sumtime = ((ipalm1/ipalm2)*(position1))*1;
              sum = teedigit.format(sumtime)+"ms";

          }










      return sum;
  }

  public void actionPerformed(ActionEvent actionEvent) {
  }

  void jMenuItem10_actionPerformed(ActionEvent e) {
System.exit(0);
  }

  void jMenuItem11_actionPerformed(ActionEvent e) {
      showPrintPreview();
  }

  void jButton24_actionPerformed(ActionEvent e) {
Trig trigg = new Trig();
  }
}

class Frame1_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton1_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Frame1_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton2_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class Frame1_jSbar1_adjustmentAdapter implements java.awt.event.AdjustmentListener {
  Frame1 adaptee;

  Frame1_jSbar1_adjustmentAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void adjustmentValueChanged(AdjustmentEvent e) {
    adaptee.jSbar1_adjustmentValueChanged(e);
  }
}

class Frame1_jPanel1_mouseAdapter extends java.awt.event.MouseAdapter {
  Frame1 adaptee;

  Frame1_jPanel1_mouseAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseClicked(MouseEvent e) {
    adaptee.jPanel1_mouseClicked(e);
  }
}

class Frame1_jComboBox1_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jComboBox1_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jComboBox1_actionPerformed(e);
  }
}

class Frame1_jButton5_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton5_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton5_actionPerformed(e);
  }
}

class Frame1_jButton3_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton3_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class Frame1_jButton4_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton4_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class Frame1_jButton6_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton6_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton6_actionPerformed(e);
  }
}

class Frame1_jButton7_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton7_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton7_actionPerformed(e);
  }
}

class Frame1_jButton8_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton8_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton8_actionPerformed(e);
  }
}

class Frame1_jButton9_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton9_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton9_actionPerformed(e);
  }
}

class Frame1_jButton10_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton10_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton10_actionPerformed(e);
  }
}

class Frame1_jButton11_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton11_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton11_actionPerformed(e);
  }
}

class Frame1_jButton12_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton12_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton12_actionPerformed(e);
  }
}

class Frame1_jButton13_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton13_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton13_actionPerformed(e);
  }
}

class Frame1_jButton14_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton14_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton14_actionPerformed(e);
  }
}

class Frame1_jButton15_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton15_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton15_actionPerformed(e);
  }
}

class Frame1_jButton16_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton16_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton16_actionPerformed(e);
  }
}

class Frame1_jButton17_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton17_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton17_actionPerformed(e);
  }
}

class Frame1_jButton18_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton18_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton18_actionPerformed(e);
  }
}

class Frame1_jPanel1_mouseMotionAdapter extends java.awt.event.MouseMotionAdapter {
  Frame1 adaptee;

  Frame1_jPanel1_mouseMotionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseMoved(MouseEvent e) {
    adaptee.jPanel1_mouseMoved(e);
  }
}

class Frame1_jButton19_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton19_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton19_actionPerformed(e);
  }
}

class Frame1_jButton20_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton20_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton20_actionPerformed(e);
  }
}

class Frame1_jButton21_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton21_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton21_actionPerformed(e);
  }
}

class Frame1_jButton22_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton22_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton22_actionPerformed(e);
  }
}

class Frame1_jButton23_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton23_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton23_actionPerformed(e);
  }
}

class Frame1_jMenuItem4_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem4_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem4_actionPerformed(e);
  }
}

class Frame1_jMenuItem3_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem3_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem3_actionPerformed(e);
  }
}

class Frame1_jMenuItem5_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem5_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem5_actionPerformed(e);
  }
}

class Frame1_jMenuItem6_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem6_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem6_actionPerformed(e);
  }
}

class Frame1_jMenuItem8_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem8_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem8_actionPerformed(e);
  }
}

class Frame1_jMenuItem1_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem1_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem1_actionPerformed(e);
  }
}

class Frame1_jMenuItem9_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem9_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem9_actionPerformed(e);
  }
}

class Frame1_jMenuItem2_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem2_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem2_actionPerformed(e);
  }
}

class Frame1_jCheckBoxMenuItem1_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jCheckBoxMenuItem1_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBoxMenuItem1_actionPerformed(e);
  }
}

class Frame1_jButton25_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton25_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton25_actionPerformed(e);
  }
}

class Frame1_jButton26_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jButton26_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton26_actionPerformed(e);
  }
}

class Frame1_jCheckBoxMenuItem2_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jCheckBoxMenuItem2_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBoxMenuItem2_actionPerformed(e);
  }
}

class Frame1_jMenuItem7_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem7_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem7_actionPerformed(e);
  }
}

class Frame1_jMenuItem10_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem10_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem10_actionPerformed(e);
  }
}

class Frame1_jMenuItem11_actionAdapter implements java.awt.event.ActionListener {
  Frame1 adaptee;

  Frame1_jMenuItem11_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem11_actionPerformed(e);
  }
}