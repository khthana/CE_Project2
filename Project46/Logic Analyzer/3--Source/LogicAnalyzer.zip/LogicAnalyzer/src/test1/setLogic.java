package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class setLogic extends JFrame{

 checkstate chk = new checkstate();
  private int LogicNum;
  private Container c;
  private String listColor[] = {"Black","Green","Blue","Yellow"};
  private String listSource[] = {"a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","a10","a11","a12","a13","a14","a15"};
  private String Logicnam="";
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel2 = new JLabel();
  JComboBox jComboBox1 = new JComboBox(listColor);
  JLabel jLabel3 = new JLabel();
  JComboBox jComboBox2 = new JComboBox(listSource);
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JLabel iPalm = new JLabel();

  public setLogic(){

  }
  public void show(int i) {
     this.LogicNum = i;
    setTitle("Settings Logic");
    setSize(270,300);
    init();
    show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }


  }
  private void jbInit() throws Exception {

    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(22, 4, 233, 289));
    jPanel1.setLayout(null);
    jLabel1.setText("Signal name");
    jLabel1.setBounds(new Rectangle(5, 13, 97, 15));
    jTextField1.setToolTipText("");
    jTextField1.setBounds(new Rectangle(34, 31, 175, 21));
    jLabel2.setText("Signal Color");
    jLabel2.setBounds(new Rectangle(3, 62, 89, 15));
    jComboBox1.setBounds(new Rectangle(34, 80, 116, 21));
    jComboBox1.addItemListener(new setLogic_jComboBox1_itemAdapter(this));
    jComboBox1.setMaximumRowCount(4);

    jLabel3.setText("Source");
    jLabel3.setBounds(new Rectangle(4, 108, 74, 15));
    jComboBox2.setBounds(new Rectangle(34, 127, 115, 21));
    jComboBox2.addItemListener(new setLogic_jComboBox2_itemAdapter(this));
    jButton1.setBounds(new Rectangle(59, 224, 73, 25));
    jButton1.setText("OK");
    jButton1.addActionListener(new setLogic_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(137, 224, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new setLogic_jButton2_actionAdapter(this));
    iPalm.setText("test"+this.LogicNum);
    iPalm.setBounds(new Rectangle(87, 176, 53, 15));
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jComboBox1, null);
    jPanel1.add(jComboBox2, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jButton2, null);
    jPanel1.add(iPalm, null);

    this.repaint();
  }

 private void init(){

   jTextField1.setText(chk.getLogicName(this.LogicNum));
   jComboBox1.setSelectedIndex(chk.getLogicColor(this.LogicNum));
   jComboBox2.setSelectedIndex(chk.getLogicSource(this.LogicNum));



 }

  void jComboBox1_itemStateChanged(ItemEvent e) {
       int a = jComboBox1.getSelectedIndex();
//System.out.println("a = "+a);
  }

  void jComboBox2_itemStateChanged(ItemEvent e) {
    int a = jComboBox2.getSelectedIndex();
//System.out.println("a = "+a);
  }

  void jButton1_actionPerformed(ActionEvent e) {

        chk.setLogicName(this.LogicNum,jTextField1.getText());
        chk.setLogicColor(this.LogicNum,jComboBox1.getSelectedIndex());
        chk.setLogicSource(this.LogicNum,jComboBox2.getSelectedIndex());
         this.show(false);

  }

  void jButton2_actionPerformed(ActionEvent e) {
this.show(false);
  }

}

class setLogic_jComboBox1_itemAdapter implements java.awt.event.ItemListener {
  setLogic adaptee;

  setLogic_jComboBox1_itemAdapter(setLogic adaptee) {
    this.adaptee = adaptee;
  }
  public void itemStateChanged(ItemEvent e) {
    adaptee.jComboBox1_itemStateChanged(e);
  }
}

class setLogic_jComboBox2_itemAdapter implements java.awt.event.ItemListener {
  setLogic adaptee;

  setLogic_jComboBox2_itemAdapter(setLogic adaptee) {
    this.adaptee = adaptee;
  }
  public void itemStateChanged(ItemEvent e) {
    adaptee.jComboBox2_itemStateChanged(e);
  }
}

class setLogic_jButton1_actionAdapter implements java.awt.event.ActionListener {
  setLogic adaptee;

  setLogic_jButton1_actionAdapter(setLogic adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class setLogic_jButton2_actionAdapter implements java.awt.event.ActionListener {
  setLogic adaptee;

  setLogic_jButton2_actionAdapter(setLogic adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}