package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Frame4  extends JFrame{

  private  boolean enable;
  f4In getset = new f4In();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField signalLabel = new JTextField();
  JLabel jLabel2 = new JLabel();
  JCheckBox jCheckBox1 = new JCheckBox();
  JCheckBox jCheckBox2 = new JCheckBox();
  JCheckBox jCheckBox3 = new JCheckBox();
  JCheckBox jCheckBox4 = new JCheckBox();
  JCheckBox jCheckBox5 = new JCheckBox();
  JCheckBox jCheckBox6 = new JCheckBox();
  JCheckBox jCheckBox7 = new JCheckBox();
  JCheckBox jCheckBox8 = new JCheckBox();
  JCheckBox jCheckBox9 = new JCheckBox();
  JCheckBox jCheckBox10 = new JCheckBox();
  JCheckBox jCheckBox11 = new JCheckBox();
  JCheckBox jCheckBox12 = new JCheckBox();
  JCheckBox jCheckBox13 = new JCheckBox();
  JCheckBox jCheckBox14 = new JCheckBox();
  JCheckBox jCheckBox15 = new JCheckBox();
  JCheckBox jCheckBox16 = new JCheckBox();
  JCheckBox enableG3 = new JCheckBox();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();

  public Frame4() {
    initframe();
   setTitle("Bus Properties");
  setSize(300,600);
   show();


    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void initframe(){
 jCheckBox1.setSelected(getset.getStatus(0));
 jCheckBox2.setSelected(getset.getStatus(1));
 jCheckBox3.setSelected(getset.getStatus(2));
 jCheckBox4.setSelected(getset.getStatus(3));
 jCheckBox5.setSelected(getset.getStatus(4));
 jCheckBox6.setSelected(getset.getStatus(5));
 jCheckBox7.setSelected(getset.getStatus(6));
 jCheckBox8.setSelected(getset.getStatus(7));
 jCheckBox9.setSelected(getset.getStatus(8));
 jCheckBox10.setSelected(getset.getStatus(9));
 jCheckBox11.setSelected(getset.getStatus(10));
 jCheckBox12.setSelected(getset.getStatus(11));
 jCheckBox13.setSelected(getset.getStatus(12));
 jCheckBox14.setSelected(getset.getStatus(13));
 jCheckBox15.setSelected(getset.getStatus(14));
 jCheckBox16.setSelected(getset.getStatus(15));
 enableG3.setSelected(getset.getEnable());
// signalLabel.setText(getset.getLabelG2());
//  signalLabel.setText("mkdsl");
 }

 public void setSigname(int i,String sq){

   switch(i){
       case 0:
             jCheckBox1.setText(sq);
             break;
       case 1:
             jCheckBox2.setText(sq);
             break;
       case 2:
             jCheckBox3.setText(sq);
             break;
       case 3:
             jCheckBox4.setText(sq);
             break;
       case 4:
             jCheckBox5.setText(sq);
             break;
       case 5:
             jCheckBox6.setText(sq);
             break;
       case 6:
             jCheckBox7.setText(sq);
             break;
       case 7:
             jCheckBox8.setText(sq);
             break;
       case 8:
             jCheckBox9.setText(sq);
             break;
       case 9:
             jCheckBox10.setText(sq);
             break;
       case 10:
             jCheckBox11.setText(sq);
             break;
       case 11:
             jCheckBox12.setText(sq);
             break;
       case 12:
             jCheckBox13.setText(sq);
             break;
       case 13:
             jCheckBox14.setText(sq);
             break;
       case 14:
             jCheckBox15.setText(sq);
             break;
       case 15:
             jCheckBox16.setText(sq);
             break;
   }

  }


  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(188, 139, 10, 10));
    jPanel1.setLayout(null);
    jLabel1.setText("Bus Label");
    jLabel1.setBounds(new Rectangle(34, 32, 141, 15));
    signalLabel.setText(getset.getLabelG2());
    signalLabel.setBounds(new Rectangle(58, 52, 205, 21));
    jLabel2.setText("Select Signal");
    jLabel2.setBounds(new Rectangle(33, 97, 122, 15));
    jCheckBox1.setText("jCheckBox1");
    jCheckBox1.setBounds(new Rectangle(56, 115, 181, 23));
    jCheckBox1.addActionListener(new Frame4_jCheckBox1_actionAdapter(this));
    jCheckBox2.setText("jCheckBox2");
    jCheckBox2.setBounds(new Rectangle(56, 136, 167, 23));
    jCheckBox2.addActionListener(new Frame4_jCheckBox2_actionAdapter(this));
    jCheckBox3.setText("jCheckBox3");
    jCheckBox3.setBounds(new Rectangle(56, 156, 177, 23));
    jCheckBox3.addActionListener(new Frame4_jCheckBox3_actionAdapter(this));
    jCheckBox4.setText("jCheckBox4");
    jCheckBox4.setBounds(new Rectangle(56, 177, 174, 23));
    jCheckBox4.addActionListener(new Frame4_jCheckBox4_actionAdapter(this));
    jCheckBox5.setText("jCheckBox5");
    jCheckBox5.setBounds(new Rectangle(56, 197, 172, 23));
    jCheckBox5.addActionListener(new Frame4_jCheckBox5_actionAdapter(this));
    jCheckBox6.setText("jCheckBox6");
    jCheckBox6.setBounds(new Rectangle(56, 217, 175, 23));
    jCheckBox6.addActionListener(new Frame4_jCheckBox6_actionAdapter(this));
    jCheckBox7.setText("jCheckBox7");
    jCheckBox7.setBounds(new Rectangle(56, 238, 169, 23));
    jCheckBox7.addActionListener(new Frame4_jCheckBox7_actionAdapter(this));
    jCheckBox8.setText("jCheckBox8");
    jCheckBox8.setBounds(new Rectangle(56, 259, 176, 23));
    jCheckBox8.addActionListener(new Frame4_jCheckBox8_actionAdapter(this));
    jCheckBox9.setText("jCheckBox9");
    jCheckBox9.setBounds(new Rectangle(56, 280, 144, 23));
    jCheckBox9.addActionListener(new Frame4_jCheckBox9_actionAdapter(this));
    jCheckBox10.setText("jCheckBox10");
    jCheckBox10.setBounds(new Rectangle(56, 301, 178, 23));
    jCheckBox10.addActionListener(new Frame4_jCheckBox10_actionAdapter(this));
    jCheckBox11.setText("jCheckBox11");
    jCheckBox11.setBounds(new Rectangle(56, 322, 186, 23));
    jCheckBox11.addActionListener(new Frame4_jCheckBox11_actionAdapter(this));
    jCheckBox12.setText("jCheckBox12");
    jCheckBox12.setBounds(new Rectangle(56, 343, 194, 23));
    jCheckBox12.addActionListener(new Frame4_jCheckBox12_actionAdapter(this));
    jCheckBox13.setText("jCheckBox13");
    jCheckBox13.setBounds(new Rectangle(56, 364, 172, 23));
    jCheckBox13.addActionListener(new Frame4_jCheckBox13_actionAdapter(this));
    jCheckBox14.setText("jCheckBox14");
    jCheckBox14.setBounds(new Rectangle(56, 385, 178, 23));
    jCheckBox14.addActionListener(new Frame4_jCheckBox14_actionAdapter(this));
    jCheckBox15.setText("jCheckBox15");
    jCheckBox15.setBounds(new Rectangle(57, 406, 157, 23));
    jCheckBox15.addActionListener(new Frame4_jCheckBox15_actionAdapter(this));
    jCheckBox16.setText("jCheckBox16");
    jCheckBox16.setBounds(new Rectangle(58, 427, 158, 23));
    jCheckBox16.addActionListener(new Frame4_jCheckBox16_actionAdapter(this));
    enableG3.setText("Enable");
    enableG3.setBounds(new Rectangle(37, 467, 89, 23));
    enableG3.addActionListener(new Frame4_enableG3_actionAdapter(this));
    jButton1.setBounds(new Rectangle(80, 504, 73, 25));
    jButton1.setText("OK");
    jButton1.addActionListener(new Frame4_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(164, 504, 73, 25));
    jButton2.setText("cancel");
    jButton2.addActionListener(new Frame4_jButton2_actionAdapter(this));
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(signalLabel, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jCheckBox1, null);
    this.getContentPane().add(jCheckBox2, null);
    this.getContentPane().add(jCheckBox3, null);
    this.getContentPane().add(jCheckBox4, null);
    this.getContentPane().add(jCheckBox5, null);
    this.getContentPane().add(jCheckBox7, null);
    this.getContentPane().add(jCheckBox6, null);
    this.getContentPane().add(jCheckBox8, null);
    this.getContentPane().add(jCheckBox9, null);
    this.getContentPane().add(jCheckBox10, null);
    this.getContentPane().add(jCheckBox11, null);
    this.getContentPane().add(jCheckBox12, null);
    this.getContentPane().add(jCheckBox13, null);
    this.getContentPane().add(jCheckBox14, null);
    this.getContentPane().add(jCheckBox15, null);
    this.getContentPane().add(jCheckBox16, null);
    this.getContentPane().add(enableG3, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
  }

  void enableG3_actionPerformed(ActionEvent e) {

    this.enable = getset.getEnable();
if(this.enable==true){this.enable=false;}else{this.enable=true;}
        getset.setEnable(this.enable);

  }

  void jButton1_actionPerformed(ActionEvent e) {
    getset.setLabelG1(signalLabel.getText());
                 this.show(false);
  }

  void jButton2_actionPerformed(ActionEvent e) {
  this.show(false);
  }

  void jCheckBox1_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(0);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(0,s);

  }

  void jCheckBox2_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(1);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(1,s);

  }

  void jCheckBox3_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(2);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(2,s);

  }

  void jCheckBox4_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(3);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(3,s);

  }

  void jCheckBox5_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(4);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(4,s);

  }

  void jCheckBox6_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(5);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(5,s);

  }

  void jCheckBox7_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(6);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(6,s);

  }

  void jCheckBox8_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(7);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(7,s);

  }

  void jCheckBox9_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(8);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(8,s);

  }

  void jCheckBox10_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(9);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(9,s);

  }

  void jCheckBox11_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(10);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(10,s);

  }

  void jCheckBox12_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(11);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(11,s);

  }

  void jCheckBox13_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(12);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(12,s);

  }

  void jCheckBox14_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(13);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(13,s);

  }

  void jCheckBox15_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(14);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(14,s);

  }

  void jCheckBox16_actionPerformed(ActionEvent e) {
    boolean s;
           s=getset.getStatus(15);
           if(s==true){s=false;}else{s=true;}
           getset.setSq(15,s);

  }

}

class Frame4_enableG3_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_enableG3_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.enableG3_actionPerformed(e);
  }
}

class Frame4_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jButton1_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Frame4_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jButton2_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class Frame4_jCheckBox1_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox1_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox1_actionPerformed(e);
  }
}

class Frame4_jCheckBox2_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox2_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox2_actionPerformed(e);
  }
}

class Frame4_jCheckBox3_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox3_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox3_actionPerformed(e);
  }
}

class Frame4_jCheckBox4_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox4_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox4_actionPerformed(e);
  }
}

class Frame4_jCheckBox5_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox5_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox5_actionPerformed(e);
  }
}

class Frame4_jCheckBox6_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox6_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox6_actionPerformed(e);
  }
}

class Frame4_jCheckBox7_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox7_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox7_actionPerformed(e);
  }
}

class Frame4_jCheckBox8_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox8_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox8_actionPerformed(e);
  }
}

class Frame4_jCheckBox9_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox9_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox9_actionPerformed(e);
  }
}

class Frame4_jCheckBox10_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox10_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox10_actionPerformed(e);
  }
}

class Frame4_jCheckBox11_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox11_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox11_actionPerformed(e);
  }
}

class Frame4_jCheckBox12_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox12_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox12_actionPerformed(e);
  }
}

class Frame4_jCheckBox13_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox13_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox13_actionPerformed(e);
  }
}

class Frame4_jCheckBox14_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox14_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox14_actionPerformed(e);
  }
}

class Frame4_jCheckBox15_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox15_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox15_actionPerformed(e);
  }
}

class Frame4_jCheckBox16_actionAdapter implements java.awt.event.ActionListener {
  Frame4 adaptee;

  Frame4_jCheckBox16_actionAdapter(Frame4 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox16_actionPerformed(e);
  }
}