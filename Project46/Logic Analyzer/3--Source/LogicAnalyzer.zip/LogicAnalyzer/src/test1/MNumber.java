package test1;

import java.util.BitSet;
import java.lang.String;

public abstract class MNumber {
  protected static final String [] strPattern = {"0", "1", "2", "3", "4", "5", "6", "7",
                                                 "8", "9", "A", "B", "C", "D", "E", "F"};
  protected double dNumber;
  protected int nDigits;
  protected String name;
  public static int nBytes; //
  abstract public double toDouble();
  abstract public void fromDouble(double dInput);
  abstract public String toString();
  abstract public void fromString(String strInput);

  public int length() {
    return nDigits;
  }
  protected int getPattern(String str) {
    for(int i=0; i<16; i++) {
      if(strPattern[i].compareTo(str) == 0)
        return i;
    }
    return 0;
  }
}

