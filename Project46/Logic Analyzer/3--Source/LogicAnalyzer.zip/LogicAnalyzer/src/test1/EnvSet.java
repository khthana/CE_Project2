package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class EnvSet  extends JFrame{

  checkstate chk = new checkstate();
  int bgColor,cColor,gColor,xColor,yColor=1;

  private ButtonGroup BGgroup,Ggroup,Cgroup,Xgroup,Ygroup;
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  JRadioButton jRadioButton3 = new JRadioButton();
  JRadioButton jRadioButton4 = new JRadioButton();
  JRadioButton jRadioButton5 = new JRadioButton();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel2 = new JLabel();
  JRadioButton jRadioButton6 = new JRadioButton();
  JRadioButton jRadioButton7 = new JRadioButton();
  JRadioButton jRadioButton8 = new JRadioButton();
  JRadioButton jRadioButton9 = new JRadioButton();
  JRadioButton jRadioButton10 = new JRadioButton();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel3 = new JLabel();
  JRadioButton jRadioButton11 = new JRadioButton();
  JRadioButton jRadioButton12 = new JRadioButton();
  JRadioButton jRadioButton13 = new JRadioButton();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JRadioButton jRadioButton14 = new JRadioButton();
  JRadioButton jRadioButton15 = new JRadioButton();
  JRadioButton jRadioButton16 = new JRadioButton();
  JPanel jPanel5 = new JPanel();
  JLabel jLabel6 = new JLabel();
  JRadioButton jRadioButton17 = new JRadioButton();
  JRadioButton jRadioButton18 = new JRadioButton();
  JRadioButton jRadioButton19 = new JRadioButton();
  public EnvSet() {

    setTitle("Environment Settings");
   setSize(700,400);
   init();
   show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }


  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(41, 31, 308, 139));
    jPanel1.setLayout(null);
    jLabel1.setText("Background Color");
    jLabel1.setBounds(new Rectangle(5, 6, 169, 15));
    jRadioButton1.setText("Black");
    jRadioButton1.setBounds(new Rectangle(43, 30, 149, 23));
    jRadioButton1.addActionListener(new EnvSet_jRadioButton1_actionAdapter(this));
    jRadioButton2.setText("Gray");
    jRadioButton2.setBounds(new Rectangle(43, 48, 151, 23));
    jRadioButton2.addActionListener(new EnvSet_jRadioButton2_actionAdapter(this));
    jRadioButton3.setText("LightGray");
    jRadioButton3.setBounds(new Rectangle(43, 66, 163, 23));
    jRadioButton3.addActionListener(new EnvSet_jRadioButton3_actionAdapter(this));
    jRadioButton4.setText("WhiteGray");
    jRadioButton4.setBounds(new Rectangle(43, 84, 164, 23));
    jRadioButton4.addActionListener(new EnvSet_jRadioButton4_actionAdapter(this));
    jRadioButton5.setText("White");
    jRadioButton5.setBounds(new Rectangle(43, 102, 162, 23));
    jRadioButton5.addActionListener(new EnvSet_jRadioButton5_actionAdapter(this));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(41, 172, 307, 147));
    jPanel2.setLayout(null);
    jLabel2.setText("Grid Color");
    jLabel2.setBounds(new Rectangle(6, 4, 123, 15));
    jRadioButton6.setText("White");
    jRadioButton6.setBounds(new Rectangle(43, 24, 180, 23));
    jRadioButton6.addActionListener(new EnvSet_jRadioButton6_actionAdapter(this));
    jRadioButton7.setText("LightGray");
    jRadioButton7.setBounds(new Rectangle(43, 42, 173, 23));
    jRadioButton7.addActionListener(new EnvSet_jRadioButton7_actionAdapter(this));
    jRadioButton8.setText("Green");
    jRadioButton8.setBounds(new Rectangle(43, 60, 173, 23));
    jRadioButton8.addActionListener(new EnvSet_jRadioButton8_actionAdapter(this));
    jRadioButton9.setText("jRadioButton9");
    jRadioButton9.setBounds(new Rectangle(43, 78, 182, 23));
    jRadioButton9.addActionListener(new EnvSet_jRadioButton9_actionAdapter(this));
    jRadioButton10.setText("Black");
    jRadioButton10.setBounds(new Rectangle(43, 96, 180, 23));
    jRadioButton10.addActionListener(new EnvSet_jRadioButton10_actionAdapter(this));
    jButton1.setBounds(new Rectangle(506, 329, 73, 25));
    jButton1.setText("OK");
    jButton1.addActionListener(new EnvSet_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(583, 328, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new EnvSet_jButton2_actionAdapter(this));
    this.setForeground(Color.white);
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setBounds(new Rectangle(351, 31, 307, 89));
    jPanel3.setLayout(null);
    jLabel3.setText("Cursor Color");
    jLabel3.setBounds(new Rectangle(6, 3, 96, 15));
    jRadioButton11.setText("Yellow");
    jRadioButton11.setBounds(new Rectangle(45, 22, 97, 23));
    jRadioButton11.addActionListener(new EnvSet_jRadioButton11_actionAdapter(this));
    jRadioButton12.setText("Red");
    jRadioButton12.setBounds(new Rectangle(45, 40, 97, 23));
    jRadioButton12.addActionListener(new EnvSet_jRadioButton12_actionAdapter(this));
    jRadioButton13.setText("Blue");
    jRadioButton13.setBounds(new Rectangle(45, 58, 97, 23));
    jRadioButton13.addActionListener(new EnvSet_jRadioButton13_actionAdapter(this));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setBounds(new Rectangle(351, 121, 306, 95));
    jPanel4.setLayout(null);
    jLabel4.setText("Cursor X Color");
    jLabel4.setBounds(new Rectangle(4, 5, 96, 15));
    jLabel5.setText("Environment Settings");
    jLabel5.setBounds(new Rectangle(7, 11, 185, 15));
    jRadioButton14.setText("Yellow");
    jRadioButton14.setBounds(new Rectangle(46, 25, 97, 23));
    jRadioButton14.addActionListener(new EnvSet_jRadioButton14_actionAdapter(this));
    jRadioButton15.setText("Red");
    jRadioButton15.setBounds(new Rectangle(46, 43, 97, 23));
    jRadioButton15.addActionListener(new EnvSet_jRadioButton15_actionAdapter(this));
    jRadioButton16.setText("Blue");
    jRadioButton16.setBounds(new Rectangle(46, 60, 97, 23));
    jRadioButton16.addActionListener(new EnvSet_jRadioButton16_actionAdapter(this));
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    jPanel5.setBounds(new Rectangle(351, 217, 306, 102));
    jPanel5.setLayout(null);
    jLabel6.setText("Cursor Y Color");
    jLabel6.setBounds(new Rectangle(5, 5, 84, 15));
    jRadioButton17.setText("Yellow");
    jRadioButton17.setBounds(new Rectangle(48, 25, 97, 23));
    jRadioButton17.addActionListener(new EnvSet_jRadioButton17_actionAdapter(this));
    jRadioButton18.setText("Red");
    jRadioButton18.setBounds(new Rectangle(48, 43, 97, 23));
    jRadioButton18.addActionListener(new EnvSet_jRadioButton18_actionAdapter(this));
    jRadioButton19.setText("Blue");
    jRadioButton19.setBounds(new Rectangle(48, 61, 97, 23));
    jRadioButton19.addActionListener(new EnvSet_jRadioButton19_actionAdapter(this));
    jPanel1.add(jLabel1, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jRadioButton2, null);
    jPanel1.add(jRadioButton3, null);
    jPanel1.add(jRadioButton4, null);
    jPanel1.add(jRadioButton5, null);
    this.getContentPane().add(jPanel3, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(jRadioButton8, null);
    jPanel2.add(jRadioButton9, null);
    jPanel2.add(jRadioButton10, null);
    jPanel2.add(jRadioButton6, null);
    jPanel2.add(jRadioButton7, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jPanel1, null);
    jPanel3.add(jLabel3, null);
    jPanel3.add(jRadioButton11, null);
    jPanel3.add(jRadioButton12, null);
    jPanel3.add(jRadioButton13, null);
    this.getContentPane().add(jPanel4, null);
    jPanel4.add(jLabel4, null);
    jPanel4.add(jRadioButton16, null);
    jPanel4.add(jRadioButton14, null);
    jPanel4.add(jRadioButton15, null);
    this.getContentPane().add(jLabel5, null);
    this.getContentPane().add(jPanel5, null);
    jPanel5.add(jLabel6, null);
    jPanel5.add(jRadioButton19, null);
    jPanel5.add(jRadioButton17, null);
    jPanel5.add(jRadioButton18, null);
    this.getContentPane().add(jPanel2, null);

    BGgroup = new ButtonGroup();
    BGgroup.add(jRadioButton1);
    BGgroup.add(jRadioButton2);
    BGgroup.add(jRadioButton3);
    BGgroup.add(jRadioButton4);
    BGgroup.add(jRadioButton5);

    Ggroup = new ButtonGroup();
    Ggroup.add(jRadioButton6);
    Ggroup.add(jRadioButton7);
    Ggroup.add(jRadioButton8);
    Ggroup.add(jRadioButton9);
    Ggroup.add(jRadioButton10);

    Cgroup = new ButtonGroup();
    Cgroup.add(jRadioButton11);
    Cgroup.add(jRadioButton12);
    Cgroup.add(jRadioButton13);

    Xgroup = new ButtonGroup();
    Xgroup.add(jRadioButton14);
    Xgroup.add(jRadioButton15);
    Xgroup.add(jRadioButton16);

    Ygroup = new ButtonGroup();
    Ygroup.add(jRadioButton17);
    Ygroup.add(jRadioButton18);
    Ygroup.add(jRadioButton19);



  }

  public void init(){
   int color;

   color = chk.getColor(0);   //get bg color
        if(color==1){
         jRadioButton1.setSelected(true);
         this.bgColor = 1;
       }else if(color==2){
         jRadioButton2.setSelected(true);
         this.bgColor = 2;
       }else if(color==3){
         jRadioButton3.setSelected(true);
         this.bgColor = 3;
       }else if(color==4){
             jRadioButton4.setSelected(true);
             this.bgColor = 4;
         }else {
         jRadioButton5.setSelected(true);
         this.bgColor = 5;
       }


   color = chk.getColor(1);   //get grid color
     if(color==1){
      jRadioButton6.setSelected(true);
      this.gColor = 1;
    }else if(color==2){
      jRadioButton7.setSelected(true);
      this.gColor = 2;
    }else if(color==3){
      jRadioButton8.setSelected(true);
      this.gColor = 3;
    }else if(color==4){
          jRadioButton9.setSelected(true);
          this.gColor = 4;
      }else {
      jRadioButton10.setSelected(true);
      this.gColor = 5;
    }


   color = chk.getColor(2);   //get cursor color
     if(color==1){
      jRadioButton11.setSelected(true);
      this.cColor = 1;
    }else if(color==2){
      jRadioButton12.setSelected(true);
      this.cColor = 2;
    }else {
      jRadioButton13.setSelected(true);
      this.cColor = 3;
    }

    color = chk.getColor(3);   //get cursor X color
     if(color==1){
      jRadioButton14.setSelected(true);
      this.xColor = 1;
    }else if(color==2){
      jRadioButton15.setSelected(true);
      this.xColor = 2;
    }else {
      jRadioButton16.setSelected(true);
      this.xColor = 3;
    }

    color = chk.getColor(4);   //get cursor Y color
     if(color==1){
      jRadioButton17.setSelected(true);
      this.yColor = 1;
    }else if(color==2){
      jRadioButton18.setSelected(true);
      this.yColor = 2;
    }else {
      jRadioButton19.setSelected(true);
      this.yColor = 3;
    }

  }

  void jRadioButton1_actionPerformed(ActionEvent e) {
  this.bgColor = 1;
  }

  void jRadioButton2_actionPerformed(ActionEvent e) {
  this.bgColor = 2;
  }

  void jRadioButton3_actionPerformed(ActionEvent e) {
  this.bgColor = 3;
  }

  void jRadioButton4_actionPerformed(ActionEvent e) {
  this.bgColor = 4;
  }

  void jRadioButton5_actionPerformed(ActionEvent e) {
  this.bgColor = 5;
  }

  void jRadioButton6_actionPerformed(ActionEvent e) {
this.gColor = 1;
  }

  void jRadioButton7_actionPerformed(ActionEvent e) {
this.gColor = 2;
  }

  void jRadioButton8_actionPerformed(ActionEvent e) {
this.gColor = 3;
  }

  void jRadioButton9_actionPerformed(ActionEvent e) {
this.gColor = 4;
  }

  void jRadioButton10_actionPerformed(ActionEvent e) {
this.gColor = 5;
  }

  void jRadioButton11_actionPerformed(ActionEvent e) {
this.cColor = 1;
  }

  void jRadioButton12_actionPerformed(ActionEvent e) {
this.cColor = 2;
  }

  void jRadioButton13_actionPerformed(ActionEvent e) {
this.cColor = 3;
  }

  void jRadioButton14_actionPerformed(ActionEvent e) {
this.xColor = 1;
  }

  void jRadioButton15_actionPerformed(ActionEvent e) {
this.xColor = 2;
  }

  void jRadioButton16_actionPerformed(ActionEvent e) {
this.xColor = 3;
  }

  void jRadioButton17_actionPerformed(ActionEvent e) {
this.yColor = 1;
  }

  void jRadioButton18_actionPerformed(ActionEvent e) {
this.yColor = 2;
  }

  void jRadioButton19_actionPerformed(ActionEvent e) {
this.yColor = 3;
  }

  void jButton1_actionPerformed(ActionEvent e) {
   chk.setColor(this.bgColor,this.gColor,this.cColor,this.xColor,this.yColor);
    this.show(false);
  }

  void jButton2_actionPerformed(ActionEvent e) {
 this.show(false);
  }

}

class EnvSet_jRadioButton1_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton1_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton1_actionPerformed(e);
  }
}

class EnvSet_jRadioButton2_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton2_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton2_actionPerformed(e);
  }
}

class EnvSet_jRadioButton3_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton3_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton3_actionPerformed(e);
  }
}

class EnvSet_jRadioButton4_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton4_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton4_actionPerformed(e);
  }
}

class EnvSet_jRadioButton5_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton5_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton5_actionPerformed(e);
  }
}

class EnvSet_jRadioButton6_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton6_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton6_actionPerformed(e);
  }
}

class EnvSet_jRadioButton7_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton7_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton7_actionPerformed(e);
  }
}

class EnvSet_jRadioButton8_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton8_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton8_actionPerformed(e);
  }
}

class EnvSet_jRadioButton9_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton9_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton9_actionPerformed(e);
  }
}

class EnvSet_jRadioButton10_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton10_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton10_actionPerformed(e);
  }
}

class EnvSet_jRadioButton11_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton11_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton11_actionPerformed(e);
  }
}

class EnvSet_jRadioButton12_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton12_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton12_actionPerformed(e);
  }
}

class EnvSet_jRadioButton13_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton13_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton13_actionPerformed(e);
  }
}

class EnvSet_jRadioButton14_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton14_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton14_actionPerformed(e);
  }
}

class EnvSet_jRadioButton15_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton15_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton15_actionPerformed(e);
  }
}

class EnvSet_jRadioButton16_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton16_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton16_actionPerformed(e);
  }
}

class EnvSet_jRadioButton17_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton17_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton17_actionPerformed(e);
  }
}

class EnvSet_jRadioButton18_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton18_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton18_actionPerformed(e);
  }
}

class EnvSet_jRadioButton19_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jRadioButton19_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton19_actionPerformed(e);
  }
}

class EnvSet_jButton1_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jButton1_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class EnvSet_jButton2_actionAdapter implements java.awt.event.ActionListener {
  EnvSet adaptee;

  EnvSet_jButton2_actionAdapter(EnvSet adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}