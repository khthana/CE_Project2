package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class vectorSig {

  private Vector Sig = new Vector();

  public vectorSig() {

  }

  public void setSig(int value){

    Sig.addElement(new Integer(value));

  }

  public void getCapacity(){

    System.out.println("Vector "+Sig.capacity());

  }


public int getValue(int position){
    int atElement;
           Integer in = (Integer)Sig.elementAt(position);
                          atElement = in.intValue();
 return atElement;
 }


public int getSize(){
    int vecSize;
    vecSize = Sig.size();
    return vecSize;
 }


}