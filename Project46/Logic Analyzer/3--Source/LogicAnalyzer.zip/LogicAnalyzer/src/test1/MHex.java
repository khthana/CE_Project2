package test1;

public class MHex extends MNumber {
  protected String hexNumber;      //Hexnumber

  MHex(String strInput) {
    this.name = "HEX";
    fromString(strInput);
  }

  MHex(double dInput) {
    this.name = "HEX";
    fromDouble(dInput);
  }

  public double toDouble() {
    return this.dNumber;
  }

  public void fromDouble(double dInput) {
    //set dNumber
    dNumber = dInput;
    //set octNumber
    int input = (int)dInput;
    String str = "";
    do {
      int index = input % 16;
      str = strPattern[index] + str;
      input /= 16;
    }while(input > 0);
    hexNumber = str;
    this.nDigits = hexNumber.length();
  }

  public String toString() {
    return hexNumber;
  }

  public void fromString(String strInput) {
    //set hexNumber
    hexNumber = strInput;
    //set dNumber
    double ans = 0;
    int j=strInput.length() -1;
    for(int i=0; i<strInput.length(); i++) {
      int n = this.getPattern(String.valueOf(strInput.charAt(j)));
      ans = ans + (n*Math.pow(16,i));
      j--;
    }
    dNumber = ans;
    //set nDigits
    this.nDigits = strInput.length();
  }


}