package test1;

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class LogicStore {

  checkstate check = new checkstate();
  private static Vector v  = new Vector();


  public LogicStore() {


  }



public void initeV(){
 check.setLogicCome(true);

 int count=0;

    do{
      try{
             v.addElement(new Logic());
      }
      catch (Exception e) {}
   count++;
    }while(count<2000);
}

public void add(int a,int b,int c,int d,int e,int f,int g,int h,int i,int j,int k,int l,int m,int n,int o,int p){

       v.addElement(new Logic(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p));

  }

 public void clearvec(){
     v.clear();
 }

  public int getMaxV(){
         int re = v.size();
         return re;
  }
  public Logic get(int i){
  Logic s;
    return  s = (Logic)v.get(i);
  }

}