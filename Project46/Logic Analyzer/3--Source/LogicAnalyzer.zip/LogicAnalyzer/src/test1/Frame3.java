package test1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Frame3  extends JFrame {

   private ButtonGroup radioGroup;

  private  boolean enable;
  Frame3In getset = new Frame3In();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JTextField signalLabel = new JTextField();
  JLabel jLabel2 = new JLabel();
  JCheckBox jCheckBox1 = new JCheckBox();
  JCheckBox jCheckBox2 = new JCheckBox();
  JCheckBox jCheckBox3 = new JCheckBox();
  JCheckBox jCheckBox4 = new JCheckBox();
  JCheckBox jCheckBox5 = new JCheckBox();
  JCheckBox jCheckBox6 = new JCheckBox();
  JCheckBox jCheckBox7 = new JCheckBox();
  JCheckBox jCheckBox8 = new JCheckBox();
  JCheckBox jCheckBox9 = new JCheckBox();
  JCheckBox jCheckBox10 = new JCheckBox();
  JCheckBox jCheckBox11 = new JCheckBox();
  JCheckBox jCheckBox12 = new JCheckBox();
  JCheckBox jCheckBox13 = new JCheckBox();
  JCheckBox jCheckBox14 = new JCheckBox();
  JCheckBox jCheckBox15 = new JCheckBox();
  JCheckBox jCheckBox16 = new JCheckBox();
  JCheckBox enableG2 = new JCheckBox();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JLabel jLabel3 = new JLabel();
  JRadioButton jRadioButton1 = new JRadioButton();
  JRadioButton jRadioButton2 = new JRadioButton();
  JRadioButton jRadioButton3 = new JRadioButton();
  JRadioButton jRadioButton4 = new JRadioButton();

  public Frame3() {
    initframe();
    setTitle("Bus Properties");
   setSize(300,700);
    show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }


  }

  public void initframe(){
  jCheckBox1.setSelected(getset.getStatus(0));
  jCheckBox2.setSelected(getset.getStatus(1));
  jCheckBox3.setSelected(getset.getStatus(2));
  jCheckBox4.setSelected(getset.getStatus(3));
  jCheckBox5.setSelected(getset.getStatus(4));
  jCheckBox6.setSelected(getset.getStatus(5));
  jCheckBox7.setSelected(getset.getStatus(6));
  jCheckBox8.setSelected(getset.getStatus(7));
  jCheckBox9.setSelected(getset.getStatus(8));
  jCheckBox10.setSelected(getset.getStatus(9));
  jCheckBox11.setSelected(getset.getStatus(10));
  jCheckBox12.setSelected(getset.getStatus(11));
  jCheckBox13.setSelected(getset.getStatus(12));
  jCheckBox14.setSelected(getset.getStatus(13));
  jCheckBox15.setSelected(getset.getStatus(14));
  jCheckBox16.setSelected(getset.getStatus(15));
  enableG2.setSelected(getset.getEnable());
 // signalLabel.setText(getset.getLabelG2());
//  signalLabel.setText("mkdsl");
  }

  public void setSigname(int i,String sq){

  switch(i){
      case 0:
            jCheckBox1.setText(sq);
            break;
      case 1:
            jCheckBox2.setText(sq);
            break;
      case 2:
            jCheckBox3.setText(sq);
            break;
      case 3:
            jCheckBox4.setText(sq);
            break;
      case 4:
            jCheckBox5.setText(sq);
            break;
      case 5:
            jCheckBox6.setText(sq);
            break;
      case 6:
            jCheckBox7.setText(sq);
            break;
      case 7:
            jCheckBox8.setText(sq);
            break;
      case 8:
            jCheckBox9.setText(sq);
            break;
      case 9:
            jCheckBox10.setText(sq);
            break;
      case 10:
            jCheckBox11.setText(sq);
            break;
      case 11:
            jCheckBox12.setText(sq);
            break;
      case 12:
            jCheckBox13.setText(sq);
            break;
      case 13:
            jCheckBox14.setText(sq);
            break;
      case 14:
            jCheckBox15.setText(sq);
            break;
      case 15:
            jCheckBox16.setText(sq);
            break;
  }

 }



  private void jbInit() throws Exception {
    jPanel1.setLayout(null);
    this.getContentPane().setLayout(null);
    jPanel1.setBounds(new Rectangle(0, 0, 1, 1));
    jLabel1.setText("Bus Label");
    jLabel1.setBounds(new Rectangle(34, 22, 139, 15));
    signalLabel.setText(getset.getLabelG2());
    signalLabel.setBounds(new Rectangle(54, 43, 172, 21));
    jLabel2.setText("Select Signals");
    jLabel2.setBounds(new Rectangle(34, 76, 88, 15));
    jCheckBox1.setText("jCheckBox1");
    jCheckBox1.setBounds(new Rectangle(57, 99, 183, 23));
    jCheckBox1.addActionListener(new Frame3_jCheckBox1_actionAdapter(this));
    jCheckBox2.setText("jCheckBox2");
    jCheckBox2.setBounds(new Rectangle(57, 119, 175, 23));
    jCheckBox2.addActionListener(new Frame3_jCheckBox2_actionAdapter(this));
    jCheckBox3.setBounds(new Rectangle(57, 138, 175, 23));
    jCheckBox3.addActionListener(new Frame3_jCheckBox3_actionAdapter(this));
    jCheckBox3.setText("jCheckBox2");
    jCheckBox4.setBounds(new Rectangle(57, 158, 183, 23));
    jCheckBox4.addActionListener(new Frame3_jCheckBox4_actionAdapter(this));
    jCheckBox4.setText("jCheckBox1");
    jCheckBox5.setText("jCheckBox1");
    jCheckBox5.setBounds(new Rectangle(57, 179, 183, 23));
    jCheckBox5.addActionListener(new Frame3_jCheckBox5_actionAdapter(this));
    jCheckBox6.setText("jCheckBox2");
    jCheckBox6.setBounds(new Rectangle(57, 200, 175, 23));
    jCheckBox6.addActionListener(new Frame3_jCheckBox6_actionAdapter(this));
    jCheckBox7.setBounds(new Rectangle(57, 221, 175, 23));
    jCheckBox7.addActionListener(new Frame3_jCheckBox7_actionAdapter(this));
    jCheckBox7.setText("jCheckBox2");
    jCheckBox8.setBounds(new Rectangle(57, 242, 183, 23));
    jCheckBox8.addActionListener(new Frame3_jCheckBox8_actionAdapter(this));
    jCheckBox8.setText("jCheckBox1");
    jCheckBox9.setText("jCheckBox9");
    jCheckBox9.setBounds(new Rectangle(57, 263, 174, 23));
    jCheckBox9.addActionListener(new Frame3_jCheckBox9_actionAdapter(this));
    jCheckBox10.setText("jCheckBox10");
    jCheckBox10.setBounds(new Rectangle(57, 284, 178, 23));
    jCheckBox10.addActionListener(new Frame3_jCheckBox10_actionAdapter(this));
    jCheckBox11.setText("jCheckBox11");
    jCheckBox11.setBounds(new Rectangle(57, 305, 171, 23));
    jCheckBox11.addActionListener(new Frame3_jCheckBox11_actionAdapter(this));
    jCheckBox12.setText("jCheckBox12");
    jCheckBox12.setBounds(new Rectangle(57, 326, 177, 23));
    jCheckBox12.addActionListener(new Frame3_jCheckBox12_actionAdapter(this));
    jCheckBox13.setText("jCheckBox13");
    jCheckBox13.setBounds(new Rectangle(57, 347, 184, 23));
    jCheckBox13.addActionListener(new Frame3_jCheckBox13_actionAdapter(this));
    jCheckBox14.setText("jCheckBox14");
    jCheckBox14.setBounds(new Rectangle(57, 368, 89, 23));
    jCheckBox14.addActionListener(new Frame3_jCheckBox14_actionAdapter(this));
    jCheckBox15.setText("jCheckBox15");
    jCheckBox15.setBounds(new Rectangle(57, 389, 178, 23));
    jCheckBox15.addActionListener(new Frame3_jCheckBox15_actionAdapter(this));
    jCheckBox16.setText("jCheckBox16");
    jCheckBox16.setBounds(new Rectangle(57, 410, 173, 23));
    jCheckBox16.addActionListener(new Frame3_jCheckBox16_actionAdapter(this));
    enableG2.setText("Enable");
    enableG2.setBounds(new Rectangle(32, 553, 89, 23));
    enableG2.addActionListener(new Frame3_enableG2_actionAdapter(this));
    jButton1.setBounds(new Rectangle(45, 587, 73, 25));
    jButton1.setText("OK");
    jButton1.addActionListener(new Frame3_jButton1_actionAdapter(this));
    jButton2.setBounds(new Rectangle(143, 587, 73, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new Frame3_jButton2_actionAdapter(this));
    jLabel3.setText("Color Bus");
    jLabel3.setBounds(new Rectangle(32, 450, 62, 15));
    jRadioButton1.setText("Black");
    jRadioButton1.setBounds(new Rectangle(59, 466, 91, 23));
    jRadioButton1.addActionListener(new Frame3_jRadioButton1_actionAdapter(this));
    jRadioButton2.setForeground(new Color(255,0,255));
    jRadioButton2.setText("Magenta");
    jRadioButton2.setBounds(new Rectangle(59, 487, 91, 23));
    jRadioButton2.addActionListener(new Frame3_jRadioButton2_actionAdapter(this));
    jRadioButton3.setText("Blue");
    jRadioButton3.setForeground(new Color(0,0,255));
    jRadioButton3.setBounds(new Rectangle(59, 509, 91, 23));
    jRadioButton3.addActionListener(new Frame3_jRadioButton3_actionAdapter(this));
    jRadioButton4.setText("Red");
    jRadioButton4.setForeground(new Color(200,0,0));
    jRadioButton4.setBounds(new Rectangle(59, 528, 91, 23));
    jRadioButton4.addActionListener(new Frame3_jRadioButton4_actionAdapter(this));
    this.getContentPane().add(jPanel1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(signalLabel, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jCheckBox1, null);
    this.getContentPane().add(jCheckBox2, null);
    this.getContentPane().add(jCheckBox3, null);
    this.getContentPane().add(jCheckBox4, null);
    this.getContentPane().add(jCheckBox5, null);
    this.getContentPane().add(jCheckBox6, null);
    this.getContentPane().add(jCheckBox7, null);
    this.getContentPane().add(jCheckBox8, null);
    this.getContentPane().add(jCheckBox9, null);
    this.getContentPane().add(jCheckBox10, null);
    this.getContentPane().add(jCheckBox11, null);
    this.getContentPane().add(jCheckBox12, null);
    this.getContentPane().add(jCheckBox13, null);
    this.getContentPane().add(jCheckBox14, null);
    this.getContentPane().add(jCheckBox15, null);
    this.getContentPane().add(jCheckBox16, null);
    this.getContentPane().add(jRadioButton1, null);
    this.getContentPane().add(jRadioButton2, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(enableG2, null);
    this.getContentPane().add(jRadioButton3, null);
    this.getContentPane().add(jRadioButton4, null);

    radioGroup = new ButtonGroup();
    radioGroup.add(jRadioButton2);
    radioGroup.add(jRadioButton3);
    radioGroup.add(jRadioButton4);
    radioGroup.add(jRadioButton1);


  }

  void enableG2_actionPerformed(ActionEvent e) {

    this.enable = getset.getEnable();
if(this.enable==true){this.enable=false;}else{this.enable=true;}
        getset.setEnable(this.enable);

  }

  void jButton1_actionPerformed(ActionEvent e) {
                getset.setLabelG1(signalLabel.getText());
                 this.show(false);
  }

  void jCheckBox1_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(0);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(0,s);

  }

  void jCheckBox2_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(1);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(1,s);

  }

  void jCheckBox3_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(2);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(2,s);

  }

  void jCheckBox4_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(3);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(3,s);

  }

  void jCheckBox5_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(4);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(4,s);

  }

  void jCheckBox6_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(5);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(5,s);

  }

  void jCheckBox7_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(6);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(6,s);

  }

  void jCheckBox8_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(7);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(7,s);

  }

  void jCheckBox9_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(8);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(8,s);

  }

  void jCheckBox10_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(9);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(9,s);

  }

  void jCheckBox11_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(10);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(10,s);

  }

  void jCheckBox12_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(11);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(11,s);

  }

  void jCheckBox13_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(12);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(12,s);

  }

  void jCheckBox14_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(13);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(13,s);

  }

  void jCheckBox15_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(14);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(14,s);

  }

  void jCheckBox16_actionPerformed(ActionEvent e) {
    boolean s;
        s=getset.getStatus(15);
        if(s==true){s=false;}else{s=true;}
        getset.setSq(15,s);

  }

  void jButton2_actionPerformed(ActionEvent e) {
this.show(false);
  }

  void jRadioButton1_actionPerformed(ActionEvent e) {
    getset.setColor(1);
  }

  void jRadioButton2_actionPerformed(ActionEvent e) {
   getset.setColor(2);
  }

  void jRadioButton3_actionPerformed(ActionEvent e) {
 getset.setColor(3);
  }

  void jRadioButton4_actionPerformed(ActionEvent e) {
  getset.setColor(4);
  }

}

class Frame3_enableG2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_enableG2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.enableG2_actionPerformed(e);
  }
}

class Frame3_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Frame3_jCheckBox1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox1_actionPerformed(e);
  }
}

class Frame3_jCheckBox2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox2_actionPerformed(e);
  }
}

class Frame3_jCheckBox3_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox3_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox3_actionPerformed(e);
  }
}

class Frame3_jCheckBox4_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox4_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox4_actionPerformed(e);
  }
}

class Frame3_jCheckBox5_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox5_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox5_actionPerformed(e);
  }
}

class Frame3_jCheckBox6_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox6_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox6_actionPerformed(e);
  }
}

class Frame3_jCheckBox7_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox7_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox7_actionPerformed(e);
  }
}

class Frame3_jCheckBox8_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox8_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox8_actionPerformed(e);
  }
}

class Frame3_jCheckBox9_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox9_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox9_actionPerformed(e);
  }
}

class Frame3_jCheckBox10_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox10_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox10_actionPerformed(e);
  }
}

class Frame3_jCheckBox11_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox11_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox11_actionPerformed(e);
  }
}

class Frame3_jCheckBox12_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox12_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox12_actionPerformed(e);
  }
}

class Frame3_jCheckBox13_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox13_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox13_actionPerformed(e);
  }
}

class Frame3_jCheckBox14_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox14_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox14_actionPerformed(e);
  }
}

class Frame3_jCheckBox15_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox15_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox15_actionPerformed(e);
  }
}

class Frame3_jCheckBox16_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jCheckBox16_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jCheckBox16_actionPerformed(e);
  }
}

class Frame3_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jButton2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class Frame3_jRadioButton1_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jRadioButton1_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton1_actionPerformed(e);
  }
}

class Frame3_jRadioButton2_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jRadioButton2_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton2_actionPerformed(e);
  }
}

class Frame3_jRadioButton3_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jRadioButton3_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton3_actionPerformed(e);
  }
}

class Frame3_jRadioButton4_actionAdapter implements java.awt.event.ActionListener {
  Frame3 adaptee;

  Frame3_jRadioButton4_actionAdapter(Frame3 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRadioButton4_actionPerformed(e);
  }
}