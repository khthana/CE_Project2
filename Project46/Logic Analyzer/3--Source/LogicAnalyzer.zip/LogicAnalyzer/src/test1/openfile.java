package test1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.lang.Object;
import java.util.StringTokenizer;



public class openfile {

private String test="";
private byte [] data;
private TextArea textArea1 = new TextArea();
private TextArea textArea2 = new TextArea();
private ObjectOutputStream output;
private FileWriter writer;
private String array[];
private int arraynum[];


  public openfile() {

  }




}