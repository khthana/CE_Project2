<%@ Page language="c#" Codebehind="index.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.WebForm1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<TITLE>INDEX</TITLE>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<frameset rows="8%,92%">
		<frame src="Header.htm" scrolling="no" noresize name="H">
		<frame src="Login.aspx" scrolling="auto" noresize name="L">
	</frameset><noframes></noframes>
</HTML>
