<%@ Application Codebehind="Global.asax.cs" Inherits="XMLAC.Global" %>
