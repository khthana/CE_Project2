<%@ Page language="c#" Codebehind="member.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.member" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>member</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="member" method="post" runat="server">
			<FONT face="Tahoma">
				<table width="100%" border="0">
					<tr>
						<td>
							<table width="100%" border="0">
								<tr>
									<td align="middle">
										<div align="center"><IMG src="headermember.gif"></div>
									</td>
								</tr>
								<tr>
									<td>
										<table width="100%" border="0">
											<tr>
												<td style="WIDTH: 216px" vAlign="top" width="216">
													<table width="100%" border="0">
														<tr>
															<td>
																<table cellSpacing="0" cellPadding="0" width="100%" border="1">
																	<tr>
																		<td>
																			<table width="100%" border="0">
																				<tr vAlign="bottom">
																					<td colSpan="2"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">
																								<div align="center">:: MENU FOR ::</div>
																							</font></strong>
																					</td>
																				</tr>
																				<tr>
																					<td colSpan="2">
																						<hr>
																					</td>
																				</tr>
																				<tr>
																					<td width="37%">
																						<div align="center"><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">MEMBER::</font></div>
																					</td>
																					<td width="63%"><asp:textbox id="Txtname" runat="server" ReadOnly="True" ForeColor="Black"></asp:textbox></td>
																				</tr>
																				<tr>
																					<td colSpan="2">
																						<hr>
																					</td>
																				</tr>
																				<tr>
																					<td align="middle" colSpan="2"><asp:button id="butShowXml" runat="server" Text="View XML Document"></asp:button></td>
																				</tr>
																				<tr>
																					<td align="middle" colSpan="2"><asp:button id="butupdatate" runat="server" Text="Change Information" Width="179px"></asp:button></td>
																				</tr>
																				<tr>
																					<td colSpan="2">
																						<hr>
																					</td>
																				</tr>
																				<tr>
																					<td colSpan="2">
																						<div align="center"><asp:button id="Button1" runat="server" Text="Logout"></asp:button></div>
																					</td>
																				</tr>
																			</table>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
														<tr>
															<td align="middle" colSpan="2">
																<div align="center"><IMG src="leftpicture.gif"></div>
															</td>
														</tr>
													</table>
												</td>
												<td align="middle" width="81%"><asp:xml id="Xml1" runat="server" DocumentSource="member.xml" TransformSource="showpublic.xsl"></asp:xml></td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td align="middle">
										<div align="center"><IMG height="48" src="footerpicture.gif" width="965"></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</FONT>
		</form>
	</body>
</HTML>
