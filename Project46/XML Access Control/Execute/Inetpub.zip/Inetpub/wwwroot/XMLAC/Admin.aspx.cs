using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.XPath;
namespace XMLAC
{
	/// <summary>
	/// Summary description for Admin.
	/// </summary>
	
	public class Admin : System.Web.UI.Page
	{
		 public static bool updatedata=false;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand2;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand2;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand2;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand2;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand3;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand3;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand3;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand3;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter2;
		protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter3;
		protected System.Web.UI.WebControls.Button butUpdate;
		protected System.Web.UI.WebControls.TextBox txtUpdate;
		protected System.Web.UI.WebControls.TextBox txtOld;
		protected System.Web.UI.WebControls.DropDownList DropDownElement;
		protected System.Web.UI.WebControls.TextBox TxtName;
		protected System.Web.UI.WebControls.Button butShowXml;
		protected XMLAC.DataSet1 root;
		protected System.Web.UI.WebControls.Button User;
		protected System.Web.UI.WebControls.Button Rule;
		protected System.Web.UI.WebControls.Button Data;
		protected System.Web.UI.WebControls.Button XML;
		protected System.Web.UI.WebControls.DataGrid dgShow;
		protected System.Web.UI.WebControls.Button Button1;
		
		protected System.Web.UI.WebControls.Xml Xml1;
		
		
	
		public  void  BindData()
		{
			
			this.sqlDataAdapter3.Fill(this.root,"notebook");
			if (updatedata==true)
			{
				DataSet ds2 = new DataSet();
				this.sqlDataAdapter3.Fill(ds2,"notebook");
			
				ds2.WriteXml("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
				root.WriteXml("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			}
			DataSet ds = new DataSet();
			ds.ReadXml("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			dgShow.DataSource=ds.Tables[0];
			dgShow.DataBind();
			
		}

		public  void Update()
		{
				DataSet ds = new DataSet();
			this.sqlDataAdapter3.Update(root,"notebook");
		}
		
		private void Page_Load(object sender, System.EventArgs e)	
		{
		//	root.WriteXml("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			if((bool)Session["admin"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
		
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.Load("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
		
			bool write=false;
			this.sqlDataAdapter2.Fill(this.root,"rule");
			this.sqlDataAdapter1.Fill(this.root,"user");

	
			foreach(DataRow userRow in this.root.Tables["user"].Rows)
			{
				string s=userRow["user"].ToString();
		
			{
				this.sqlDataAdapter2.Fill(this.root,"rule");
				foreach(DataRow therow in this.root.Tables["rule"].Rows)
				{
					object tempS,tempO,tempP,tempA,tempPe;
					string str;
				
					tempS=therow["subject"];
					tempO=therow["object"];
					str=tempS.ToString();
					login.cut(ref str);
					if(str==login.user)
					{
						string action,path;
						tempA=therow["action"];
						action=tempA.ToString();
						login.cut(ref action);
						tempP=therow["object"];
						path=tempP.ToString();
						login.cut(ref path);
						if(action=="read")
						{
							string per;
							tempPe=therow["permission"];
							per=tempPe.ToString();
							if(per=="deny")
							{
								NameTable NameTable = new NameTable();
								XmlNamespaceManager nsmgr = new XmlNamespaceManager(NameTable);
								nsmgr.AddNamespace("mstns","http://www.tempuri.org/DataSet1.xsd");

								XmlNode root = xmlDoc.DocumentElement; //root
					
								XmlNode xmlNode = root.SelectSingleNode(path,nsmgr); //root
								login.getnode(ref path);
						
								XmlNodeList xmlNL=xmlDoc.GetElementsByTagName(path);
								int count = xmlNL.Count;

								XmlElement xmlE = xmlDoc.DocumentElement;
								for(int i=0;i<count;i++)
								{
									xmlNode = xmlNL.Item(i);
									xmlNode.RemoveAll();
								}
							}
							else
							{
								if (write==true)  break; 
								xmlDoc.Save("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
								write=true;
						
							}
						}
					}
				}
			}
				this.BindData();
				this.TxtName.Text = login.user;
			}
		}
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			this.root = new XMLAC.DataSet1();
			((System.ComponentModel.ISupportInitialize)(this.root)).BeginInit();
			this.DropDownElement.SelectedIndexChanged += new System.EventHandler(this.DropDownElement_SelectedIndexChanged);
			this.txtOld.TextChanged += new System.EventHandler(this.txtOld_TextChanged);
			this.txtUpdate.TextChanged += new System.EventHandler(this.txtUpdate_TextChanged);
			this.butUpdate.Click += new System.EventHandler(this.butUpdate_Click);
			this.TxtName.TextChanged += new System.EventHandler(this.TxtName_TextChanged);
			this.butShowXml.Click += new System.EventHandler(this.butShowXml_Click);
			this.User.Click += new System.EventHandler(this.User_Click);
			this.Rule.Click += new System.EventHandler(this.Rule_Click);
			this.Data.Click += new System.EventHandler(this.Data_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT ID, [USER], PASSWORD, [GROUP] FROM [user]";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "password=ching39;data source=CG;initial catalog=data;persist security info=False;" +
				"user id=sa;workstation id=CG;packet size=4096";
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = "INSERT INTO [user] (ID, [USER], PASSWORD, [GROUP]) VALUES (@ID, @Param1, @PASSWOR" +
				"D, @Param2); SELECT ID, [USER], PASSWORD, [GROUP] FROM [user] WHERE (ID = @ID)";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param1", System.Data.SqlDbType.VarChar, 20, "USER"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PASSWORD", System.Data.SqlDbType.VarChar, 10, "PASSWORD"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param2", System.Data.SqlDbType.VarChar, 20, "GROUP"));
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE [user] SET ID = @ID, [USER] = @Param3, PASSWORD = @PASSWORD, [GROUP] = @Param4 WHERE (ID = @Original_ID) AND ([GROUP] = @Original_GROUP OR @Original_GROUP IS NULL AND [GROUP] IS NULL) AND (PASSWORD = @Original_PASSWORD OR @Original_PASSWORD IS NULL AND PASSWORD IS NULL) AND ([USER] = @Original_USER OR @Original_USER IS NULL AND [USER] IS NULL); SELECT ID, [USER], PASSWORD, [GROUP] FROM [user] WHERE (ID = @ID)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param3", System.Data.SqlDbType.VarChar, 20, "USER"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PASSWORD", System.Data.SqlDbType.VarChar, 10, "PASSWORD"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param4", System.Data.SqlDbType.VarChar, 20, "GROUP"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GROUP", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GROUP", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PASSWORD", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PASSWORD", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_USER", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "USER", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = @"DELETE FROM [user] WHERE (ID = @Original_ID) AND ([GROUP] = @Original_GROUP OR @Original_GROUP IS NULL AND [GROUP] IS NULL) AND (PASSWORD = @Original_PASSWORD OR @Original_PASSWORD IS NULL AND PASSWORD IS NULL) AND ([USER] = @Original_USER OR @Original_USER IS NULL AND [USER] IS NULL)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GROUP", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GROUP", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PASSWORD", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PASSWORD", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_USER", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "USER", System.Data.DataRowVersion.Original, null));
			// 
			// sqlSelectCommand2
			// 
			this.sqlSelectCommand2.CommandText = "SELECT ID, SUBJECT, OBJECT, ACTION, PERMISSION FROM [rule] ORDER BY PERMISSION";
			this.sqlSelectCommand2.Connection = this.sqlConnection1;
			// 
			// sqlInsertCommand2
			// 
			this.sqlInsertCommand2.CommandText = "INSERT INTO [rule] (ID, SUBJECT, OBJECT, ACTION, PERMISSION) VALUES (@ID, @SUBJEC" +
				"T, @OBJECT, @ACTION, @PERMISSION); SELECT ID, SUBJECT, OBJECT, ACTION, PERMISSIO" +
				"N FROM [rule] WHERE (ID = @ID)";
			this.sqlInsertCommand2.Connection = this.sqlConnection1;
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SUBJECT", System.Data.SqlDbType.VarChar, 20, "SUBJECT"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OBJECT", System.Data.SqlDbType.VarChar, 50, "OBJECT"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ACTION", System.Data.SqlDbType.VarChar, 5, "ACTION"));
			this.sqlInsertCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PERMISSION", System.Data.SqlDbType.VarChar, 5, "PERMISSION"));
			// 
			// sqlUpdateCommand2
			// 
			this.sqlUpdateCommand2.CommandText = @"UPDATE [rule] SET ID = @ID, SUBJECT = @SUBJECT, OBJECT = @OBJECT, ACTION = @ACTION, PERMISSION = @PERMISSION WHERE (ID = @Original_ID) AND (ACTION = @Original_ACTION OR @Original_ACTION IS NULL AND ACTION IS NULL) AND (OBJECT = @Original_OBJECT OR @Original_OBJECT IS NULL AND OBJECT IS NULL) AND (PERMISSION = @Original_PERMISSION OR @Original_PERMISSION IS NULL AND PERMISSION IS NULL) AND (SUBJECT = @Original_SUBJECT OR @Original_SUBJECT IS NULL AND SUBJECT IS NULL); SELECT ID, SUBJECT, OBJECT, ACTION, PERMISSION FROM [rule] WHERE (ID = @ID)";
			this.sqlUpdateCommand2.Connection = this.sqlConnection1;
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@SUBJECT", System.Data.SqlDbType.VarChar, 20, "SUBJECT"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OBJECT", System.Data.SqlDbType.VarChar, 50, "OBJECT"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ACTION", System.Data.SqlDbType.VarChar, 5, "ACTION"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PERMISSION", System.Data.SqlDbType.VarChar, 5, "PERMISSION"));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ACTION", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ACTION", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OBJECT", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OBJECT", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PERMISSION", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PERMISSION", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SUBJECT", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SUBJECT", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand2
			// 
			this.sqlDeleteCommand2.CommandText = @"DELETE FROM [rule] WHERE (ID = @Original_ID) AND (ACTION = @Original_ACTION OR @Original_ACTION IS NULL AND ACTION IS NULL) AND (OBJECT = @Original_OBJECT OR @Original_OBJECT IS NULL AND OBJECT IS NULL) AND (PERMISSION = @Original_PERMISSION OR @Original_PERMISSION IS NULL AND PERMISSION IS NULL) AND (SUBJECT = @Original_SUBJECT OR @Original_SUBJECT IS NULL AND SUBJECT IS NULL)";
			this.sqlDeleteCommand2.Connection = this.sqlConnection1;
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ACTION", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ACTION", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OBJECT", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OBJECT", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PERMISSION", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PERMISSION", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand2.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_SUBJECT", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "SUBJECT", System.Data.DataRowVersion.Original, null));
			// 
			// sqlSelectCommand3
			// 
			this.sqlSelectCommand3.CommandText = "SELECT Model, Name, Spec, PriceTh, PriceMemberTh, PriceSi, PriceMemberSi, PriceIn" +
				", PriceMemberIn, Image FROM notebook";
			this.sqlSelectCommand3.Connection = this.sqlConnection1;
			// 
			// sqlInsertCommand3
			// 
			this.sqlInsertCommand3.CommandText = @"INSERT INTO notebook(Model, Name, Spec, PriceTh, PriceMemberTh, PriceSi, PriceMemberSi, PriceIn, PriceMemberIn, Image) VALUES (@Model, @Name, @Spec, @PriceTh, @PriceMemberTh, @PriceSi, @PriceMemberSi, @PriceIn, @PriceMemberIn, @Image); SELECT Model, Name, Spec, PriceTh, PriceMemberTh, PriceSi, PriceMemberSi, PriceIn, PriceMemberIn, Image FROM notebook WHERE (Model = @Model)";
			this.sqlInsertCommand3.Connection = this.sqlConnection1;
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Model", System.Data.SqlDbType.VarChar, 50, "Model"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.VarChar, 20, "Name"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Spec", System.Data.SqlDbType.VarChar, 500, "Spec"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceTh", System.Data.SqlDbType.VarChar, 10, "PriceTh"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberTh", System.Data.SqlDbType.VarChar, 10, "PriceMemberTh"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceSi", System.Data.SqlDbType.VarChar, 10, "PriceSi"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberSi", System.Data.SqlDbType.VarChar, 10, "PriceMemberSi"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceIn", System.Data.SqlDbType.VarChar, 10, "PriceIn"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberIn", System.Data.SqlDbType.VarChar, 10, "PriceMemberIn"));
			this.sqlInsertCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Image", System.Data.SqlDbType.VarChar, 10, "Image"));
			// 
			// sqlUpdateCommand3
			// 
			this.sqlUpdateCommand3.CommandText = @"UPDATE notebook SET Model = @Model, Name = @Name, Spec = @Spec, PriceTh = @PriceTh, PriceMemberTh = @PriceMemberTh, PriceSi = @PriceSi, PriceMemberSi = @PriceMemberSi, PriceIn = @PriceIn, PriceMemberIn = @PriceMemberIn, Image = @Image WHERE (Model = @Original_Model) AND (Image = @Original_Image OR @Original_Image IS NULL AND Image IS NULL) AND (Name = @Original_Name OR @Original_Name IS NULL AND Name IS NULL) AND (PriceIn = @Original_PriceIn OR @Original_PriceIn IS NULL AND PriceIn IS NULL) AND (PriceMemberIn = @Original_PriceMemberIn OR @Original_PriceMemberIn IS NULL AND PriceMemberIn IS NULL) AND (PriceMemberSi = @Original_PriceMemberSi OR @Original_PriceMemberSi IS NULL AND PriceMemberSi IS NULL) AND (PriceMemberTh = @Original_PriceMemberTh OR @Original_PriceMemberTh IS NULL AND PriceMemberTh IS NULL) AND (PriceSi = @Original_PriceSi OR @Original_PriceSi IS NULL AND PriceSi IS NULL) AND (PriceTh = @Original_PriceTh OR @Original_PriceTh IS NULL AND PriceTh IS NULL) AND (Spec = @Original_Spec OR @Original_Spec IS NULL AND Spec IS NULL); SELECT Model, Name, Spec, PriceTh, PriceMemberTh, PriceSi, PriceMemberSi, PriceIn, PriceMemberIn, Image FROM notebook WHERE (Model = @Model)";
			this.sqlUpdateCommand3.Connection = this.sqlConnection1;
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Model", System.Data.SqlDbType.VarChar, 50, "Model"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.VarChar, 20, "Name"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Spec", System.Data.SqlDbType.VarChar, 500, "Spec"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceTh", System.Data.SqlDbType.VarChar, 10, "PriceTh"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberTh", System.Data.SqlDbType.VarChar, 10, "PriceMemberTh"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceSi", System.Data.SqlDbType.VarChar, 10, "PriceSi"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberSi", System.Data.SqlDbType.VarChar, 10, "PriceMemberSi"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceIn", System.Data.SqlDbType.VarChar, 10, "PriceIn"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PriceMemberIn", System.Data.SqlDbType.VarChar, 10, "PriceMemberIn"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Image", System.Data.SqlDbType.VarChar, 10, "Image"));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Model", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Model", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Image", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Image", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Name", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceIn", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceIn", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberIn", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberIn", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberSi", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberSi", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberTh", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberTh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceSi", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceSi", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceTh", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceTh", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Spec", System.Data.SqlDbType.VarChar, 500, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Spec", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand3
			// 
			this.sqlDeleteCommand3.CommandText = @"DELETE FROM notebook WHERE (Model = @Original_Model) AND (Image = @Original_Image OR @Original_Image IS NULL AND Image IS NULL) AND (Name = @Original_Name OR @Original_Name IS NULL AND Name IS NULL) AND (PriceIn = @Original_PriceIn OR @Original_PriceIn IS NULL AND PriceIn IS NULL) AND (PriceMemberIn = @Original_PriceMemberIn OR @Original_PriceMemberIn IS NULL AND PriceMemberIn IS NULL) AND (PriceMemberSi = @Original_PriceMemberSi OR @Original_PriceMemberSi IS NULL AND PriceMemberSi IS NULL) AND (PriceMemberTh = @Original_PriceMemberTh OR @Original_PriceMemberTh IS NULL AND PriceMemberTh IS NULL) AND (PriceSi = @Original_PriceSi OR @Original_PriceSi IS NULL AND PriceSi IS NULL) AND (PriceTh = @Original_PriceTh OR @Original_PriceTh IS NULL AND PriceTh IS NULL) AND (Spec = @Original_Spec OR @Original_Spec IS NULL AND Spec IS NULL)";
			this.sqlDeleteCommand3.Connection = this.sqlConnection1;
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Model", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Model", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Image", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Image", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Name", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceIn", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceIn", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberIn", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberIn", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberSi", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberSi", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceMemberTh", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceMemberTh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceSi", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceSi", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PriceTh", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PriceTh", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand3.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Spec", System.Data.SqlDbType.VarChar, 500, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Spec", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDataAdapter1
			// 
			this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
			this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
			this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
			this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "user", new System.Data.Common.DataColumnMapping[] {
																																																			  new System.Data.Common.DataColumnMapping("ID", "ID"),
																																																			  new System.Data.Common.DataColumnMapping("USER", "USER"),
																																																			  new System.Data.Common.DataColumnMapping("PASSWORD", "PASSWORD"),
																																																			  new System.Data.Common.DataColumnMapping("GROUP", "GROUP")})});
			this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDataAdapter2
			// 
			this.sqlDataAdapter2.DeleteCommand = this.sqlDeleteCommand2;
			this.sqlDataAdapter2.InsertCommand = this.sqlInsertCommand2;
			this.sqlDataAdapter2.SelectCommand = this.sqlSelectCommand2;
			this.sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "rule", new System.Data.Common.DataColumnMapping[] {
																																																			  new System.Data.Common.DataColumnMapping("ID", "ID"),
																																																			  new System.Data.Common.DataColumnMapping("SUBJECT", "SUBJECT"),
																																																			  new System.Data.Common.DataColumnMapping("OBJECT", "OBJECT"),
																																																			  new System.Data.Common.DataColumnMapping("ACTION", "ACTION"),
																																																			  new System.Data.Common.DataColumnMapping("PERMISSION", "PERMISSION")})});
			this.sqlDataAdapter2.UpdateCommand = this.sqlUpdateCommand2;
			// 
			// sqlDataAdapter3
			// 
			this.sqlDataAdapter3.DeleteCommand = this.sqlDeleteCommand3;
			this.sqlDataAdapter3.InsertCommand = this.sqlInsertCommand3;
			this.sqlDataAdapter3.SelectCommand = this.sqlSelectCommand3;
			this.sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "notebook", new System.Data.Common.DataColumnMapping[] {
																																																				  new System.Data.Common.DataColumnMapping("Model", "Model"),
																																																				  new System.Data.Common.DataColumnMapping("Name", "Name"),
																																																				  new System.Data.Common.DataColumnMapping("Spec", "Spec"),
																																																				  new System.Data.Common.DataColumnMapping("PriceTh", "PriceTh"),
																																																				  new System.Data.Common.DataColumnMapping("PriceMemberTh", "PriceMemberTh"),
																																																				  new System.Data.Common.DataColumnMapping("PriceSi", "PriceSi"),
																																																				  new System.Data.Common.DataColumnMapping("PriceMemberSi", "PriceMemberSi"),
																																																				  new System.Data.Common.DataColumnMapping("PriceIn", "PriceIn"),
																																																				  new System.Data.Common.DataColumnMapping("PriceMemberIn", "PriceMemberIn"),
																																																				  new System.Data.Common.DataColumnMapping("Image", "Image")})});
			this.sqlDataAdapter3.UpdateCommand = this.sqlUpdateCommand3;
			// 
			// root
			// 
			this.root.DataSetName = "root";
			this.root.Locale = new System.Globalization.CultureInfo("en-US");
			this.root.Namespace = "http://www.tempuri.org/DataSet1.xsd";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.root)).EndInit();

		}
		#endregion

		

	

		private void User_Click(object sender, System.EventArgs e)
		{
			this.Response.Redirect("User.aspx");
		}

		private void Rule_Click(object sender, System.EventArgs e)
		{
			this.Response.Redirect("Rule.aspx");
		}

		private void Data_Click(object sender, System.EventArgs e)
		{
			updatedata=true;
			this.Response.Redirect("Data.aspx");
		}

		private void XML_Click(object sender, System.EventArgs e)
		{
			this.Response.Redirect("notebook.xml");
		}

		private void DropDownElement_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void txtOld_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void txtUpdate_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void butUpdate_Click(object sender, System.EventArgs e)
		{
			XmlDocument xmlDoc = new XmlDocument();
			XmlDocument xmlDocTemp = new XmlDocument(); 
			xmlDoc.Load("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			xmlDocTemp.Load("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			XmlNode root1 = xmlDoc.DocumentElement;
			XmlNode rootTemp = xmlDocTemp.DocumentElement; 

			NameTable NameTable = new NameTable();
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(NameTable);
			nsmgr.AddNamespace("mstns","http://www.tempuri.org/DataSet1.xsd");
			
				
									
			string oldvalue = this.txtOld.Text;
			
			string newvalue = this.txtUpdate.Text;
			string path="//mstns:"  +  DropDownElement.SelectedItem.Text + "[.='"    +oldvalue+   "']";
			string pathRule="//mstns:"+DropDownElement.SelectedItem.Text ;
					    
				
			foreach(DataRow therow in this.root.Tables["rule"].Rows)
			{
				object obj = therow["OBJECT"];
				object per= therow["PERMISSION"];
				object sub = therow["SUBJECT"];
				
				string pathIR=obj.ToString();
				login.cut(ref pathIR);
				string perIR=per.ToString();
				login.cut(ref perIR);
				string subIR =sub.ToString();
				login.cut(ref subIR);
				
				if(login.user==subIR)
				{
			
					{
				
						{

							XmlNode xmlNode =root1.SelectSingleNode(path,nsmgr);
							if (xmlNode==null)
							{
								this.Response.Redirect("PathNotFound.htm");
							}
							else
							{
								xmlNode.InnerText=newvalue;
								this.sqlDataAdapter3.Fill(this.root,"notebook");
								foreach (DataRow  row in root.Tables["notebook"].Rows)
								{
									object temp = row[ DropDownElement.SelectedItem.Text];
									if (temp.ToString()== oldvalue)
									{
										row[ DropDownElement.SelectedItem.Text]=newvalue;
										break;
									}
											
								}
							}

						XmlNode xmlNodeTemp=rootTemp.SelectSingleNode(path,nsmgr);
							if(xmlNodeTemp==null)
							{
								this.Response.Redirect("error.aspx");
							}
							else
								xmlNodeTemp.InnerText=newvalue;
							break;
						}
					
					} // end if
				}
			} // foreach

			
			xmlDoc.Save("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
	
							
			
			this.Update();
			this.BindData();
		}

		private void butShowXml_Click(object sender, System.EventArgs e)
		{
		this.Response.Redirect("notebook.xml");
		}

		private void TxtName_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Session.Abandon();
			XmlDocument xmlNull = new XmlDocument();
			xmlNull.Load("c:\\Inetpub\\wwwroot\\XMLAC\\Null.xml");
			xmlNull.Save("C:\\Inetpub\\wwwroot\\XMLAC\\notebook.xml");
			this.Response.Redirect("Login.aspx");
		}

		


	
		
	}
}
