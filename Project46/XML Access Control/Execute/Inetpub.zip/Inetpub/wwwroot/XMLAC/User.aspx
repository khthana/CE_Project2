<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Page Language="C#" Debug="true" %>
<HTML>
	<HEAD>
		<title>User Add Delete</title>
	</HEAD>
	<body bgcolor="#ffffff">
		<script language="C#" runat="server">

		void Page_Load(Object Sender, EventArgs E)
		{
			if((bool)Session["Count"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
			if((bool)Session["Count"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
				if(!Page.IsPostBack)
				{
						BindData();
				}
		}//end Page_Load

/*		void MyDataGrid_Paging(Object Sender, DataGridPageChangedEventArgs E)
		{
				mydatagrid.CurrentPageIndex = E.NewPageIndex;
				BindGrid();
		}//end MyDataGrid_Paging
*/

		void BindData()
		{ 
				SqlConnection myconn = new SqlConnection("server=(local); 	database=Data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From [user]",myconn);
				DataSet ds123 = new DataSet();
				myda.Fill(ds123,"user123");
				mydatagrid.DataSource = ds123.Tables["user123"];
				
					System.Data.DataRow BlankRow = ds123.Tables[ "user123" ].NewRow( );
					BlankRow[ "ID" ] = "0";
					BlankRow[ "USER" ] = "";
					BlankRow[ "PASSWORD" ] = "";
					BlankRow[ "GROUP" ] = "";
					ds123.Tables[ "user123" ].Rows.InsertAt( BlankRow, 0 );
					mydatagrid.DataSource = ds123.Tables[ "user123" ];
				
				mydatagrid.DataBind();
		}//end BindGrid

	void DataGrid_Edit(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = E.Item.ItemIndex;
			BindData();
	}//end DataGrid_Edit

	void DataGrid_Update(Object Source, DataGridCommandEventArgs E)
	{
			if ( E.Item.ItemIndex == 0 ) 
			{
					TextBox newID, newUSER, newPASSWORD, newGROUP;
					 newID = (TextBox)E.Item.Cells[1].Controls[0];
					newUSER = (TextBox)E.Item.Cells[2].Controls[0];
					newPASSWORD = (TextBox)E.Item.Cells[3].Controls[0];
					newGROUP = (TextBox)E.Item.Cells[4].Controls[0];
					SqlConnection myconn = new SqlConnection("server=(local); database=Data; uid=sa;  password=ching39");
					String strconn;
					strconn = "INSERT INTO [user] (ID,[USER],PASSWORD,[GROUP]) values('"+newID.Text+"','"+newUSER.Text+"','"+newPASSWORD.Text+"','"+newGROUP.Text+"')";
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
			else
			{
					int id;
					TextBox newID,user, password, group;
					id = (int)mydatagrid.DataKeys[E.Item.ItemIndex];
					newID = (TextBox)E.Item.Cells[1].Controls[0];
					user = (TextBox)E.Item.Cells[2].Controls[0];
					password = (TextBox)E.Item.Cells[3].Controls[0];
					group = (TextBox)E.Item.Cells[4].Controls[0];
					String strconn;
					SqlConnection myconn = new SqlConnection("server=(local); database=Data; uid=sa;  password=ching39");
					strconn = "Update [user]  Set   ID='"+newID.Text+"',[USER]='" + user.Text + "', PASSWORD= '" + password.Text +"', [GROUP] = '" + group.Text+"' Where ID = " +id ;
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
	}//end DataGrid_Update

	void DataGrid_Cancel(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = -1;
			BindData();
	}//end DataGrid_Cancel
	
		
	protected void dg_ItemCreated( System.Object sender, DataGridItemEventArgs e ) 
	{
			if ( e.Item.ItemIndex == 0 ) 
			{
					System.Web.UI.WebControls.LinkButton lb = ( System.Web.UI.WebControls.LinkButton )e.Item.Cells[ 0 ].Controls[ 0 ];
					if ( lb.Text == "Edit" ) 
					{
							lb.Text = "Insert New USER";
					}
					 else if ( lb.Text == "Update" ) 
					{
							lb.Text = "Insert";
					}
			}
	}//end dg_ItemCreated

	  void DataGrid1_Delete(Object sender, DataGridCommandEventArgs e) 
      {
		int rowtodel = e.Item.ItemIndex;
				SqlConnection myconn = new SqlConnection("server=(local); 	database=Data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From [user]",myconn);
				DataSet ds123 = new DataSet();		
				myda.Fill(ds123,"user123");
		
		    int temp =rowtodel-1;
				
				DataRow findRow = ds123.Tables["user123"].Rows[temp];
			//	findRow.Delete();
			//	myda.Update(ds123, "user123");
		
			int id;
			id = (int)mydatagrid.DataKeys[e.Item.ItemIndex];
			
					String strconn;
					strconn = "Delete From[user] where ID="+id ;
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
			
		    	BindData();
		
      }
		</script>
		<form id="Form1" runat="server">
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
			<asp:datagrid id="mydatagrid" runat="server" cellpadding="3" BorderWidth="2" OnDeleteCommand="DataGrid1_Delete" OnItemCreated="dg_ItemCreated" onUpdateCommand="DataGrid_Update" onCancelCommand="DataGrid_Cancel" onEditCommand="DataGrid_Edit" DataKeyField="ID" AutoGenerateColumns="false">
				<HeaderStyle BackColor="#993333" Font-Name="Verdana" Font-Bold="true" Font-Size="10" ForeColor="#FFFFFF" />
				<ItemStyle Font-Name="Ms San Serif" Font-Size="10" />
				<AlternatingItemStyle BackColor="#EEEEEE" />
				<columns>
					<asp:EditCommandColumn ButtonType="LinkButton" EditText="Edit" UpdateText="Update" CancelText="Cancel" HeaderText="Edit" />
					<asp:BoundColumn HeaderText="ID" DataField="ID" />
					<asp:BoundColumn HeaderText="USER" DataField="USER" />
					<asp:BoundColumn HeaderText="PASSWORD" DataField="PASSWORD" />
					<asp:BoundColumn HeaderText="GROUP" DataField="GROUP" />
					<asp:ButtonColumn HeaderText="Delete Item" ButtonType="LinkButton" Text="Delete" CommandName="Delete"></asp:ButtonColumn>
				</columns>
			</asp:datagrid>
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
		</form>
	</body>
</HTML>
