using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace XMLAC
{
	/// <summary>
	/// Summary description for updateProfile.
	/// </summary>
	public class updateProfile : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox username;
		protected System.Web.UI.WebControls.TextBox newpassword;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.TextBox oldpassword;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.TextBox Status;
		protected System.Web.UI.WebControls.Button butManu;
		protected System.Web.UI.WebControls.TextBox confirm;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
		this.username.Text = login.user;
		}

	


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "password=ching39;data source=CG;initial catalog=data;persist security info=False;" +
				"user id=sa;workstation id=CG;packet size=4096";
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT ID, [USER], PASSWORD, [GROUP] FROM [user] where [USER]=\'\'";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = "INSERT INTO [user] (ID, [USER], PASSWORD, [GROUP]) VALUES (@ID, @Param1, @PASSWOR" +
				"D, @Param2); SELECT ID, [USER], PASSWORD, [GROUP] FROM [user] WHERE (ID = @ID)";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param1", System.Data.SqlDbType.VarChar, 20, "USER"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PASSWORD", System.Data.SqlDbType.VarChar, 10, "PASSWORD"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param2", System.Data.SqlDbType.VarChar, 20, "GROUP"));
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE [user] SET ID = @ID, [USER] = @Param3, PASSWORD = @PASSWORD, [GROUP] = @Param4 WHERE (ID = @Original_ID) AND ([GROUP] = @Original_GROUP OR @Original_GROUP IS NULL AND [GROUP] IS NULL) AND (PASSWORD = @Original_PASSWORD OR @Original_PASSWORD IS NULL AND PASSWORD IS NULL) AND ([USER] = @Original_USER); SELECT ID, [USER], PASSWORD, [GROUP] FROM [user] WHERE (ID = @ID)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param3", System.Data.SqlDbType.VarChar, 20, "USER"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PASSWORD", System.Data.SqlDbType.VarChar, 10, "PASSWORD"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param4", System.Data.SqlDbType.VarChar, 20, "GROUP"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GROUP", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GROUP", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PASSWORD", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PASSWORD", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_USER", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "USER", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = "DELETE FROM [user] WHERE (ID = @Original_ID) AND ([GROUP] = @Original_GROUP OR @O" +
				"riginal_GROUP IS NULL AND [GROUP] IS NULL) AND (PASSWORD = @Original_PASSWORD OR" +
				" @Original_PASSWORD IS NULL AND PASSWORD IS NULL) AND ([USER] = @Original_USER)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_GROUP", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "GROUP", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PASSWORD", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PASSWORD", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_USER", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "USER", System.Data.DataRowVersion.Original, null));
			// 
			// sqlDataAdapter1
			// 
			this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
			this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
			this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
			this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "user", new System.Data.Common.DataColumnMapping[] {
																																																			  new System.Data.Common.DataColumnMapping("ID", "ID"),
																																																			  new System.Data.Common.DataColumnMapping("USER", "USER"),
																																																			  new System.Data.Common.DataColumnMapping("PASSWORD", "PASSWORD"),
																																																			  new System.Data.Common.DataColumnMapping("GROUP", "GROUP")})});
			this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.butManu.Click += new System.EventHandler(this.butManu_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			
	
			string username = this.username.Text ;
			string oldPW = this.oldpassword.Text;
			string newPW = this.newpassword.Text;
			string ConPW = this.confirm.Text;
			string OKPW=null;
		
			
			try
			{
				if((newPW == ConPW)&&(username==login.user)&&(oldPW==login.password))
				{
					OKPW=newPW;

					String strconn;
					SqlConnection myconn2 = new SqlConnection("server=(local); database=Data; uid=sa;  password=ching39");
					myconn2.Open();
					strconn = "Update [user] Set  PASSWORD= '"+OKPW+"' WHERE [USER]='"+username+"'";
					SqlCommand mycommand = new SqlCommand(strconn, myconn2);
				
					mycommand.ExecuteNonQuery();
					myconn2.Close();
					this.Status.Text="UPDATE COMPLETE";

				}
				else  this.Status.Text="UPDATE FAIL";
			}
			catch
			{this.Status.Text="UPDATE FAIL";}
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			this.username.Text="";
			this.oldpassword.Text="";
			this.newpassword.Text="";
			this.confirm.Text="";
			this.Status.Text="";
		}

		private void butManu_Click(object sender, System.EventArgs e)
		{
			if((bool)Session["manager"]==true)
			{
			this.Response.Redirect("manager.aspx");
			}
			else this.Response.Redirect("member.aspx");
		}
	}
}
