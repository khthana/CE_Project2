<%@ Page language="c#" Codebehind="Login.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.login" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Login</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffffff" MS_POSITIONING="GridLayout">
		<form id="login" method="post" runat="server">
			<table width="100%" border="0">
				<tr>
					<td>
						<table width="100%" border="0">
							<tr>
								<td align="middle">
									<div align="center"><IMG src="headerpicture.gif"></div>
								</td>
							</tr>
							<tr>
								<td>
									<table width="100%" border="0">
										<tr>
											<td style="WIDTH: 216px" vAlign="top" width="216">
												<table width="100%" border="0">
													<tr>
														<td>
															<table width="100%" border="1" cellpadding="0" cellspacing="0">
																<tr>
																	<td>
																		<table width="100%" border="0">
																			<TR>
																				<td colSpan="2">
																					<div align="center">
																						<strong><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">:: LOGIN 
																								::</font></strong>
																						<hr>
																					</div>
																				</td>
																			</TR>
																			<tr>
																				<td align="right" width="33%"><strong><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif">
																							<asp:label id="labUser" runat="server" Width="77px">USER :: </asp:label>
																						</font></strong>
																				</td>
																				<td width="67%"><strong><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif">
																							<asp:textbox id="txtName" runat="server"></asp:textbox>
																						</font></strong>
																				</td>
																			</tr>
																			<tr align="middle" colspan="2">
																			</tr>
																			<tr>
																				<td align="right"><strong><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif">
																							<asp:label id="labPW" runat="server"> PASSWORD ::</asp:label>
																						</font></strong>
																				</td>
																				<td><strong><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif">
																							<asp:textbox id="txtPW" runat="server" Width="154px" TextMode="Password"></asp:textbox>
																						</font></strong>
																				</td>
																			<tr>
																				<td align="middle" colSpan="2"><asp:button id="butSingIn" runat="server" Width="79px" BorderColor="Gainsboro" Text="Login"></asp:button>
																					&nbsp;&nbsp;
																					<asp:button id="butClr" runat="server" Width="80px" BorderColor="White" Text="Clear"></asp:button>
																				</td>
																			</tr>
																		</table>
																	</td>
																</tr>
															</table>
														</td>
													</tr>
													<tr>
														<td colspan="2"><div align="center"><IMG src="leftpicture.gif"></div>
														</td>
													</tr>
												</table>
											</td>
											<td align="middle" width="81%"><asp:xml id="Xml1" runat="server" TransformSource="showpublic.xsl" DocumentSource="public.xml"></asp:xml></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td align="middle"><div align="center"><IMG src="footerpicture.gif"></div>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</form>
	</body>
</HTML>
