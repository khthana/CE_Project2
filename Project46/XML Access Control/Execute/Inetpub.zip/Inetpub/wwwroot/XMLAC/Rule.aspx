<%@ Page Language="C#" Debug="true" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Data" %>
<HTML>
	<HEAD>
		<title>Rule</title>
	</HEAD>
	<body bgColor="#ffffff">
		<script language="C#" runat="server">
		
		//code ��ǹ��� ��͹���������� load page ��ҹ��
		void Page_Load(Object Sender, EventArgs E)
		{
			if((bool)Session["Count"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
			if((bool)Session["Count"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
				if(!Page.IsPostBack)
				{
						BindData();
				}
		}//end Page_Load


		void BindData()
		{ 
				SqlConnection myconn = new SqlConnection("server=(local); 	database=data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From [rule]ORDER BY SUBJECT,ACTION,PERMISSION",myconn);
				DataSet ds123 = new DataSet();
				myda.Fill(ds123,"rule123");
				mydatagrid.DataSource = ds123.Tables["rule123"];
					System.Data.DataRow BlankRow = ds123.Tables[ "rule123" ].NewRow( );
					BlankRow[ "ID" ] = "0";
					BlankRow[ "SUBJECT" ] = "";
					BlankRow[ "OBJECT" ] = "";
					BlankRow[ "PERMISSION" ] = "";
					ds123.Tables[ "rule123" ].Rows.InsertAt( BlankRow, 0 );
					mydatagrid.DataSource = ds123.Tables[ "rule123" ];
				mydatagrid.DataBind();
		}//end BindGrid

	//�ա���Ѻ event ����� �ҡ��鹨�����¹ʶҹ��� edit mode ���ͷӡ�����
	void DataGrid_Edit(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = E.Item.ItemIndex;
			BindData();
	}//end DataGrid_Edit

	// method ����ͧ���͡�����Ҷ�� click insert ��� insert mode ���� click update ��������� update 
	void DataGrid_Update(Object Source, DataGridCommandEventArgs E)
	{
			if ( E.Item.ItemIndex == 0 ) 
			{
					TextBox newID, newSUBJECT, newOBJECT, newACTION, newPERMISSION;
					 newID = (TextBox)E.Item.Cells[1].Controls[0];
					newSUBJECT = (TextBox)E.Item.Cells[2].Controls[0];
					newOBJECT = (TextBox)E.Item.Cells[3].Controls[0];
					newACTION = (TextBox)E.Item.Cells[4].Controls[0];
					newPERMISSION = (TextBox)E.Item.Cells[5].Controls[0];
					SqlConnection myconn = new SqlConnection("server=(local); database=data; uid=sa;  password=ching39");
					String strconn;
					//strconn = "Update [rule] Set  SUBJECT= '" + newSUBJECT.Text + "', OBJECT= '" + newOBJECT.Text +"', ACTION = '" + newACTION.Text + "', PERMISSION = '" + newPERMISSION.Text  ;
					strconn = "INSERT INTO [rule](ID,SUBJECT,OBJECT,ACTION,PERMISSION) values('"+newID.Text+"','"+newSUBJECT.Text+"','"+newOBJECT.Text+"','"+newACTION.Text+"','"+newPERMISSION.Text+"')";
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
			else
			{
					int id;
					TextBox newId,subject, object_rule, action, permission;
					id = (int)mydatagrid.DataKeys[E.Item.ItemIndex];
					newId =(TextBox)E.Item.Cells[1].Controls[0];
					subject = (TextBox)E.Item.Cells[2].Controls[0];
					object_rule = (TextBox)E.Item.Cells[3].Controls[0];
					action = (TextBox)E.Item.Cells[4].Controls[0];
					permission = (TextBox)E.Item.Cells[5].Controls[0];
					String strconn;
					SqlConnection myconn = new SqlConnection("server=(local); database=Data; uid=sa;  password=ching39");
					strconn = "Update [rule] Set  ID='"+newId.Text+"',SUBJECT= '" + subject.Text + "', OBJECT= '" + object_rule.Text +"', ACTION = '" + action.Text + "', PERMISSION = '" + permission.Text +"' Where ID = " +id ;
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
	}//end DataGrid_Update

	// ¡��ԡ��� Edit ���ǡ�Ѻ������ mode ����
	void DataGrid_Cancel(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = -1;
			BindData();
	}//end DataGrid_Cancel
	
	//�ѹ����� method ������ҧ�����������㹡�� row ����Ѻ insert ������
	protected void dg_ItemCreated( System.Object sender, DataGridItemEventArgs e ) 
	{
			if ( e.Item.ItemIndex == 0 ) 
			{
					System.Web.UI.WebControls.LinkButton lb = ( System.Web.UI.WebControls.LinkButton )e.Item.Cells[ 0 ].Controls[ 0 ];
					if ( lb.Text == "Edit" ) 
					{
							lb.Text = "Insert New RULE";
					}
					 else if ( lb.Text == "Update" ) 
					{
							lb.Text = "Insert";
					}
			}
	}//end dg_ItemCreated
	
	  void DataGrid1_Delete(Object sender, DataGridCommandEventArgs e) 
      {
		int rowtodel = e.Item.ItemIndex;
				SqlConnection myconn = new SqlConnection("server=(local); 	database=Data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From [rule]",myconn);
				DataSet ds123 = new DataSet();		
				myda.Fill(ds123,"rule123");
		
		    int temp =rowtodel-1;
				
				DataRow findRow = ds123.Tables["rule123"].Rows[temp];
			//	findRow.Delete();
			//	myda.Update(ds123, "rule123");
		
			int id;
			id = (int)mydatagrid.DataKeys[e.Item.ItemIndex];
			
					String strconn;
					strconn = "Delete From[rule] where ID="+id ;
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
			
		    	BindData();
		
      }

		</script>
		<form id="Form1" runat="server">
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
			<asp:datagrid id="mydatagrid" runat="server" cellpadding="3" BorderWidth="2" OnDeleteCommand="DataGrid1_Delete" OnItemCreated="dg_ItemCreated" onUpdateCommand="DataGrid_Update" onCancelCommand="DataGrid_Cancel" onEditCommand="DataGrid_Edit" DataKeyField="ID" AutoGenerateColumns="false">
				<HeaderStyle BackColor="#993333" Font-Name="Verdana" Font-Bold="true" Font-Size="10" ForeColor="#FFFFFF" />
				<ItemStyle Font-Name="Ms San Serif" Font-Size="10" />
				<AlternatingItemStyle BackColor="#EEEEEE" />
				<columns>
					<asp:EditCommandColumn ButtonType="LinkButton" EditText="Edit" UpdateText="Update" CancelText="Cancel" HeaderText="Edit" />
					<asp:BoundColumn HeaderText="ID" DataField="ID" />
					<asp:BoundColumn HeaderText="Subject" DataField="SUBJECT" />
					<asp:BoundColumn HeaderText="Object" DataField="OBJECT" />
					<asp:BoundColumn HeaderText="Action" DataField="ACTION" />
					<asp:BoundColumn HeaderText="Permission" DataField="PERMISSION" />
					<asp:ButtonColumn HeaderText="Delete Item" ButtonType="LinkButton" Text="Delete" CommandName="Delete"></asp:ButtonColumn>
				</columns>
			</asp:datagrid>
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
		</form>
	</body>
</HTML>
