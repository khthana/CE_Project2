<%@ Page language="c#" Codebehind="Manager.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.Manager" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Manager</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Manager" method="post" runat="server">
			<FONT face="Tahoma">
				<table border='"0" =100%'>
					<tr>
						<td>
							<div align="center"><IMG src="headermanager.gif"></div>
						</td>
					</tr>
					<tr>
						<td>
							<table width="100%" border="0">
								<tr>
									<td align="middle">
										<table cellSpacing="0" cellPadding="0" width="100%" border="1">
											<tr>
												<td>
													<div align="center"><strong><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">Edit 
																with XPATH &gt;&gt;</font></strong></div>
												</td>
												<td>
													<table width="100%" border="0">
														<tr>
															<td vAlign="center" align="middle">
																<div align="right"><strong><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">XPATH 
																			=</font></strong></div>
															</td>
															<td vAlign="center" align="middle">
																<div align="left"><asp:dropdownlist id="DropDownElement" runat="server">
																		<asp:ListItem Value="PriceTh">PriceTh</asp:ListItem>
																		<asp:ListItem Value="PriceMemberTh">PriceMemberTh</asp:ListItem>
																		<asp:ListItem Value="PriceSi">PriceSi</asp:ListItem>
																		<asp:ListItem Value="PriceMemberSi">PriceMemberSi</asp:ListItem>
																		<asp:ListItem Value="PriceIn">PriceIn</asp:ListItem>
																		<asp:ListItem Value="PriceMemberIn">PriceMemberIn</asp:ListItem>
																	</asp:dropdownlist></div>
															</td>
														</tr>
													</table>
												</td>
												<td>
													<table width="100%" border="0">
														<tr>
															<td vAlign="center" align="middle">
																<div align="right"><strong><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">OLD 
																			VALUE =</font></strong></div>
															</td>
															<td vAlign="center" align="middle">
																<div align="left"><asp:textbox id="txtOld" runat="server" Width="88px"></asp:textbox></div>
															</td>
														</tr>
													</table>
												</td>
												<td>
													<table width="100%" border="0">
														<tr>
															<td vAlign="center" align="middle">
																<div align="right"><strong><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">NEW 
																			VALUE =</font></strong></div>
															</td>
															<td vAlign="center" align="middle">
																<div align="left"><asp:textbox id="txtUpdate" runat="server" Width="85px"></asp:textbox></div>
															</td>
														</tr>
													</table>
												</td>
												<td vAlign="center" align="middle"><asp:button id="butUpdate" runat="server" Text="Update Value"></asp:button></td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td>
										<table width="100%" border="0">
											<tr>
												<td style="WIDTH: 216px" vAlign="top" width="216">
													<table cellSpacing="0" cellPadding="0" width="100%" border="1">
														<tr>
															<td>
																<table width="100%" border="0">
																	<tr>
																		<td colSpan="2"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">
																					<div align="center">:: MENU FOR ::</div>
																				</font></strong>
																		</td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td width="37%">
																			<div align="right"><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif" size="1">MANAGER::</font></div>
																		</td>
																		<td width="63%"><asp:textbox id="TxtName" runat="server"></asp:textbox></td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="butShowXml" runat="server" Text="View XML Document"></asp:button></td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="butupdatate" runat="server" Width="179px" Text="Change Information"></asp:button></td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<div align="center"><asp:button id="Button1" runat="server" Text="Logout"></asp:button></div>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
												<td align="middle" width="81%"><asp:xml id="Xml1" runat="server" DocumentSource="manager.xml" TransformSource="showpublic.xsl"></asp:xml></td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td align="middle">
										<div align="center"><IMG src="footerpicture.gif"></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</FONT>
		</form>
	</body>
</HTML>
