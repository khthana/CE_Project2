<?xml version = "1.0"?>

<!-- Fig. 12.1 : public.xsl              -->
<!-- Simple XSLT document for intro.xml -->

<xsl:stylesheet version = "1.0" xmlns:xsl = "http://www.w3.org/1999/XSL/Transform">

<xsl:template match = "/">
      <html>
         <xsl:apply-templates/>
      </html>
</xsl:template>



  <xsl:template match = "notebook">

      <body bgcolor = "white">

<table width="75%" border="1">
  <tr>
    <td>Picture</td>
    <td>Model</td>
    <td>Name</td>
    <td>Spec</td>
    <td>PriceTh</td>
    <td>PriceSi</td>
    <td>PriceIn</td>
    <td>PriceMemberTh</td>
    <td>PriceMemberSi</td>
    <td>PriceMemberIn</td>
  </tr>
  <tr>
    <td align="center"><image src="{image}" /></td>
    <td><xsl:value-of select = "Model"/></td>
    <td><xsl:value-of select = "Name"/></td>
    <td><xsl:value-of select = "Spec"/></td>
    <td><xsl:value-of select = "PriceTh"/></td>
    <td><xsl:value-of select = "PriceSi"/></td>
    <td><xsl:value-of select = "PriceIn"/></td>
    <td><xsl:value-of select = "PriceMemberTh"/></td>
    <td><xsl:value-of select = "PriceMemberSi"/></td>
    <td><xsl:value-of select = "PriceMemberIn"/></td>
  </tr>
</table>
      </body>

   </xsl:template>


</xsl:stylesheet>
