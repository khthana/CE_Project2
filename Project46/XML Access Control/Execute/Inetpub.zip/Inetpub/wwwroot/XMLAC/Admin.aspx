<%@ Page language="c#" Codebehind="Admin.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.Admin" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Admin</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Admin" method="post" runat="server">
			<FONT face="Tahoma">
				<table width="100%" border="0">
					<tr>
						<td>
							<div align="center"><IMG src="headeradmin.gif"></div>
						</td>
					</tr>
					<tr>
						<td>
							<table width="100%" border="0">
								<tr>
									<td>
										<table cellSpacing="0" cellPadding="0" width="100%" border="1">
											<tr>
												<td vAlign="center">
													<div align="center"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">Edit 
																with XPATH &gt;&gt;</font></strong></div>
												</td>
												<td vAlign="center" align="middle">
													<table width="100%" border="0">
														<tr>
															<td>
																<div align="right"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">XPATH&nbsp;=
																		</font></strong>
																</div>
															</td>
															<td><asp:dropdownlist id="DropDownElement" runat="server">
																	<asp:ListItem Value="Model">Model</asp:ListItem>
																	<asp:ListItem Value="Name">Name</asp:ListItem>
																	<asp:ListItem Value="PriceTh">PriceTh</asp:ListItem>
																	<asp:ListItem Value="PriceMemberTh">PriceMemberTh</asp:ListItem>
																	<asp:ListItem Value="PriceSi">PriceSi</asp:ListItem>
																	<asp:ListItem Value="PriceMemberSi">PriceMemberSi</asp:ListItem>
																	<asp:ListItem Value="PriceIn">PriceIn</asp:ListItem>
																	<asp:ListItem Value="PriceMemberIn">PriceMemberIn</asp:ListItem>
																	<asp:ListItem Value="Spec">Spec</asp:ListItem>
																	<asp:ListItem Value="Image">Image</asp:ListItem>
																</asp:dropdownlist></td>
														</tr>
													</table>
												</td>
												<td vAlign="center" align="middle">
													<table width="100%" border="0">
														<tr>
															<td vAlign="center" align="right"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">OLD 
																		VALUE =</font></strong></td>
															<td><asp:textbox id="txtOld" runat="server" Width="88px"></asp:textbox></td>
														</tr>
													</table>
												</td>
												<td vAlign="center" align="middle">
													<table width="100%" border="0">
														<tr>
															<td vAlign="center" align="right"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">NEW 
																		VALUE =</font></strong></td>
															<td><asp:textbox id="txtUpdate" runat="server" Width="88px"></asp:textbox></td>
														</tr>
													</table>
												</td>
												<td>
													<div align="center"><asp:button id="butUpdate" runat="server" Text="Update Value"></asp:button></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td>
										<table width="100%" border="0">
											<tr>
												<td style="WIDTH: 216px" vAlign="top" width="216">
													<table cellSpacing="0" cellPadding="0" width="100%" border="1">
														<tr>
															<td>
																<table width="100%" border="0">
																	<tr>
																		<td colSpan="2"><strong><font face="MS Sans Serif, Tahoma, sans-serif" size="1">
																					<div align="center">:: MENU FOR ::</div>
																				</font></strong>
																		</td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td width="37%">
																			<div align="right"><font face="MS Sans Serif, Tahoma, sans-serif" size="1">ADMIN ::</font></div>
																		</td>
																		<td width="63%"><asp:textbox id="TxtName" runat="server" Width="125px"></asp:textbox></td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="butShowXml" runat="server" Text="View XML Document"></asp:button></td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="User" runat="server" Text="Edit User"></asp:button></td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="Rule" runat="server" Text="Edit Rule"></asp:button></td>
																	</tr>
																	<tr>
																		<td align="middle" colSpan="2"><asp:button id="Data" runat="server" Text="Edit Data"></asp:button></td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<hr>
																		</td>
																	</tr>
																	<tr>
																		<td colSpan="2">
																			<div align="center"><asp:button id="Button1" runat="server" Text="Logout"></asp:button></div>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
												<td align="middle" width="81%"><asp:datagrid id="dgShow" runat="server" BorderColor="#3366CC" BorderStyle="None" BorderWidth="1px" BackColor="White" CellPadding="4" Font-Size="8" Font-Name="MS Sans Serif">
														<SelectedItemStyle Font-Names="MS Sans Serif,8pt" Font-Bold="True" ForeColor="#CCFF99" BackColor="#009999"></SelectedItemStyle>
														<ItemStyle Font-Names="MS Sans Serif,8pt" ForeColor="Black" BackColor="White"></ItemStyle>
														<HeaderStyle Font-Bold="True" ForeColor="#CCCCFF" BackColor="#003399"></HeaderStyle>
														<FooterStyle ForeColor="#003399" BackColor="#99CCCC"></FooterStyle>
														<PagerStyle Font-Size="Small" HorizontalAlign="Left" ForeColor="#003399" BackColor="#99CCCC" Mode="NumericPages"></PagerStyle>
													</asp:datagrid></ASP:XML></td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td align="middle">
										<div align="center"><IMG src="footerpicture.gif"></div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</FONT>
		</form>
	</body>
</HTML>
