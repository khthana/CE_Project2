<%@ Page language="c#" Codebehind="updateProfile.aspx.cs" AutoEventWireup="false" Inherits="XMLAC.updateProfile" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>updateProfile</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="updateProfile" method="post" runat="server">
			<FONT face="Tahoma">
				<table width="100%" border="0">
					<tr>
						<td><IMG src="headerchangeinformation.gif">
							<DIV></DIV>
						</td>
					</tr>
					<tr>
						<td>
							<table width="40%" align="center" border="0">
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td style="WIDTH: 145px"><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>User 
																::</strong></font></div>
												</td>
												<td><div align="left"><asp:TextBox id="username" runat="server" Width="177px"></asp:TextBox></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td style="WIDTH: 146px"><div align="right"><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>Old 
																	Password ::</strong></font></div>
													</div>
												</td>
												<td>
													<div align="left"><asp:TextBox id="oldpassword" runat="server" TextMode="Password" Width="175px"></asp:TextBox></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td style="WIDTH: 145px"><div align="right"><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>New 
																	Password ::</strong></font></div>
													</div>
												</td>
												<td><div align="left"><asp:TextBox id="newpassword" runat="server" TextMode="Password" Width="175px"></asp:TextBox></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td style="WIDTH: 144px"><div align="right"><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>Confirm 
																	::</strong></font></div>
													</div>
												</td>
												<td><div align="left"><asp:TextBox id="confirm" runat="server" TextMode="Password" Width="175px"></asp:TextBox></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td>&nbsp;</td>
								</tr>
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td><div align="right"><asp:Button id="Button1" runat="server" Text="Update" Width="111px"></asp:Button>
														::
													</div>
												</td>
												<td><div align="left"><asp:Button id="Button2" runat="server" Text="Cancel" Width="107px"></asp:Button></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td><table width="100%" border="0" align="center">
											<tr>
												<td style="WIDTH: 144px"><div align="right"><font color="#ff0000" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>Status 
																::</strong></font></div>
												</td>
												<td><div align="left"><asp:TextBox id="Status" runat="server" ReadOnly="True" Width="172px" BorderStyle="None" Font-Bold="True" Font-Size="Small" ForeColor="Black"></asp:TextBox></div>
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td>&nbsp;</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</FONT>
			<div align="right"><asp:Button id="butManu" runat="server" Text=":: Back to Previous Page ::" BorderStyle="Solid" BackColor="White" BorderColor="Black"></asp:Button></div>
		</form>
	</body>
</HTML>
