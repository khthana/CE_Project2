<?xml version = "1.0"?>

<!-- Fig. 12.1 : public.xsl              -->
<!-- Simple XSLT document for intro.xml -->

<xsl:stylesheet version = "1.0" xmlns:xsl = "http://www.w3.org/1999/XSL/Transform" xmlns:root="http://www.tempuri.org/DataSet1.xsd">

<xsl:template match = "/">
      <html>
         <xsl:apply-templates/>
      </html>
</xsl:template>



<xsl:template match = "//root:notebook">

      <body bgcolor = "white">







<table width="100%" border="1" cellpadding="0" cellspacing="0">
  <tr>
    <td width="20%" align="center"><image src="{root:Image}" /></td>
    <td width="80%"><table width="100%" border="1" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="36%"><div align="right"><font color="#666666" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>Model 
              :: </strong></font></div></td>
          <td width="64%"><font color="#666666" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "//root:Model"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font color="#6600FF" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong>Name 
              :: </strong></font></div></td>
          <td><font color="#6600FF" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:Name"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#006666">Specification</font> 
              :: </strong></font></div></td>
          <td><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:Spec"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#000099">Price 
              for Thai </font>::<br/>
              </strong>(Thai Baht :THB)<strong> ::</strong></font></div></td>
          <td><font color="#000099" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceTh"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#FF0000">Price 
              for Thai Member</font> ::<br/>
              </strong>(Thai Baht :THB)<strong> ::</strong></font></div></td>
          <td><font color="#FF0000" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceMemberTh"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#000099">Price 
              for Singapore</font> ::<br/>
              </strong>(Singapore Dollar:SGD)<strong> ::</strong></font></div></td>
          <td><font color="#000099" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceSi"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#FF0000">Price 
              for Singapore Member</font> ::<br/>
              </strong>(Singapore Dollar:SGD)<strong> ::</strong></font></div></td>
          <td><font color="#FF0000" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceMemberSi"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#000099">Price 
              for India</font> ::<br/>
              </strong>(Indian Rupee :INR)<strong>::</strong></font></div></td>
          <td><font color="#000099" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceIn"/></font></td>
        </tr>
        <tr> 
          <td><div align="right"><font size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><strong><font color="#FF0000">Price 
              for India Member</font> ::<br/>
              </strong>(Indian Rupee :INR)<strong>::</strong></font></div></td>
          <td><font color="#FF0000" size="1" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><xsl:value-of select = "root:PriceMemberIn"/></font></td>
        </tr>
      </table></td>
  </tr>
</table>




















      </body>

   </xsl:template>


</xsl:stylesheet>
