<%@ Page Language="C#" Debug="true" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Data" %>
<HTML>
	<HEAD>
		<title>Data</title>
	</HEAD>
	<body bgColor="#ffffff">
		<script language="C#" runat="server">
		
		//code ��ǹ��� ��͹���������� load page ��ҹ��
		void Page_Load(Object Sender, EventArgs E)
		{
			if((bool)Session["Count"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
			if((bool)Session["Admin"]==false)
			{
				Response.Redirect("NotSession.htm");
			}
			
				if(!Page.IsPostBack)
				{
						BindData();
				}
		}//end Page_Load


		void BindData()
		{ 
				SqlConnection myconn = new SqlConnection("server=(local); 	database=data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From notebook",myconn);
				DataSet ds123 = new DataSet();
				myda.Fill(ds123,"notebook123");
				mydatagrid.DataSource = ds123.Tables["notebook123"];
					System.Data.DataRow BlankRow = ds123.Tables[ "notebook123" ].NewRow( );
					BlankRow[ "Model" ] = "";
					BlankRow[ "Name" ] = "";
					BlankRow[ "Spec" ] = "";
					BlankRow[ "PriceTh" ] = "";
					BlankRow[ "PriceMemberTh" ] = "";
					BlankRow[ "PriceSi" ] = "";
					BlankRow[ "PriceMemberSi" ] = "";
					BlankRow[ "PriceIn" ] = "";
					BlankRow[ "PriceMemberIn" ] = "";
					BlankRow[ "Image" ] = "";
					ds123.Tables[ "notebook123" ].Rows.InsertAt( BlankRow, 0 );
					mydatagrid.DataSource = ds123.Tables[ "notebook123" ];
				mydatagrid.DataBind();
		}//end BindGrid

	//�ա���Ѻ event ����� �ҡ��鹨�����¹ʶҹ��� edit mode ���ͷӡ�����
	void DataGrid_Edit(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = E.Item.ItemIndex;
			BindData();
	}//end DataGrid_Edit

	// method ����ͧ���͡�����Ҷ�� click insert ��� insert mode ���� click update ��������� update 
	void DataGrid_Update(Object Source, DataGridCommandEventArgs E)
	{
			if ( E.Item.ItemIndex == 0 ) 
			{
					TextBox newMODEL, newNAME, newSPEC, newPRICETH, newPRICEMEMBERTH, newPRICESI, newPRICEMEMBERSI, newPRICEIN, newPRICEMEMBERIN,newImage;
					newMODEL = (TextBox)E.Item.Cells[1].Controls[0];
					newNAME = (TextBox)E.Item.Cells[2].Controls[0];
					newSPEC = (TextBox)E.Item.Cells[3].Controls[0];
					newPRICETH = (TextBox)E.Item.Cells[4].Controls[0];
					newPRICEMEMBERTH = (TextBox)E.Item.Cells[5].Controls[0];
					newPRICESI = (TextBox)E.Item.Cells[6].Controls[0];
					newPRICEMEMBERSI = (TextBox)E.Item.Cells[7].Controls[0];
					newPRICEIN = (TextBox)E.Item.Cells[8].Controls[0];
					newPRICEMEMBERIN = (TextBox)E.Item.Cells[9].Controls[0];
					newImage=(TextBox)E.Item.Cells[10].Controls[0];

					
					SqlConnection myconn = new SqlConnection("server=(local); database=data; uid=sa;  password=ching39");
					String strconn;
					//strconn = "Update [notebook] Set  Model= '" + newMODEL.Text + "', Name= '" + newNAME.Text +"', Spec = '" + newSPEC.Text + "', PriceTh = '" + newPRICETH.Text +"', PriceMemberTh = '" + newPRICEMEMBERTH.Text + "', PriceSi = '" + newPRICESI.Text + "', PriceMemberSi = '" + newPRICEMEMBERSI.Text + "', PriceIn = '" + newPRICEIN.Text + "', PriceMemberIn = '"+newPRICEMEMBERIN.Text;
					strconn = "INSERT INTO notebook (Model,Name,Spec,PriceTh,PriceMemberTh,PriceSi,PriceMemberSi,PriceIn,PriceMemberIn,Image) values('"+newMODEL.Text+"','"+newNAME.Text+"','"+newSPEC.Text+"','"+newPRICETH.Text+"','"+newPRICEMEMBERTH.Text+"','"+newPRICESI.Text+"','"+newPRICEMEMBERSI.Text+"','"+newPRICEIN.Text+"','"+newPRICEMEMBERIN.Text+"','"+newImage.Text+"')";
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
			else
			{
					string id;
					TextBox newMODEL, newNAME, newSPEC, newPRICETH, newPRICEMEMBERTH, newPRICESI, newPRICEMEMBERSI, newPRICEIN, newPRICEMEMBERIN,newImage;
					id = (string)mydatagrid.DataKeys[E.Item.ItemIndex];
					newMODEL = (TextBox)E.Item.Cells[1].Controls[0];
					newNAME = (TextBox)E.Item.Cells[2].Controls[0];
					newSPEC = (TextBox)E.Item.Cells[3].Controls[0];
					newPRICETH = (TextBox)E.Item.Cells[4].Controls[0];
					newPRICEMEMBERTH = (TextBox)E.Item.Cells[5].Controls[0];
					newPRICESI = (TextBox)E.Item.Cells[6].Controls[0];
					newPRICEMEMBERSI = (TextBox)E.Item.Cells[7].Controls[0];
					newPRICEIN = (TextBox)E.Item.Cells[8].Controls[0];
					newPRICEMEMBERIN = (TextBox)E.Item.Cells[9].Controls[0];
						newImage=(TextBox)E.Item.Cells[10].Controls[0];
					
					String strconn;
					SqlConnection myconn = new SqlConnection("server=(local); database=Data; uid=sa;  password=ching39");
					strconn = "Update [notebook] Set  Model= '" + newMODEL.Text +"', Name= '" + newNAME.Text +"', Spec = '" + newSPEC.Text + "', PriceTh = '" + newPRICETH.Text +"', PriceMemberTh = '" + newPRICEMEMBERTH.Text +"', PriceSi = '" + newPRICESI.Text +"', PriceMemberSi = '" + newPRICEMEMBERSI.Text +"', PriceIn = '" + newPRICEIN.Text +"', PriceMemberIn = '" + newPRICEMEMBERIN.Text +"', Image = '" + newImage.Text +"' Where Model =  '"+id+"'";
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
					mydatagrid.EditItemIndex = -1;
					BindData();
			}
	}//end DataGrid_Update

	// ¡��ԡ��� Edit ���ǡ�Ѻ������ mode ����
	void DataGrid_Cancel(Object Source, DataGridCommandEventArgs E)
	{
			mydatagrid.EditItemIndex = -1;
			BindData();
	}//end DataGrid_Cancel
	
	//�ѹ����� method ������ҧ�����������㹡�� row ����Ѻ insert ������
	protected void dg_ItemCreated( System.Object sender, DataGridItemEventArgs e ) 
	{
			if ( e.Item.ItemIndex == 0 ) 
			{
					System.Web.UI.WebControls.LinkButton lb = ( System.Web.UI.WebControls.LinkButton )e.Item.Cells[ 0 ].Controls[ 0 ];
					if ( lb.Text == "Edit" ) 
					{
							lb.Text = "Insert New RULE";
					}
					 else if ( lb.Text == "Update" ) 
					{
							lb.Text = "Insert";
					}
			}
	}//end dg_ItemCreated
	
	  void DataGrid1_Delete(Object sender, DataGridCommandEventArgs e) 
      {
		int rowtodel = e.Item.ItemIndex;
				SqlConnection myconn = new SqlConnection("server=(local); 	database=data;  uid=sa; password=ching39");	
				SqlDataAdapter myda = new SqlDataAdapter("Select * From [notebook]",myconn);
				DataSet ds123 = new DataSet();		
				myda.Fill(ds123,"notebook123");
		
		    int temp =rowtodel-1;
				
				DataRow findRow = ds123.Tables["notebook123"].Rows[temp];
			//	findRow.Delete();
			//	myda.Update(ds123, "notebook123");
		
			 string id;
			 id = (string)mydatagrid.DataKeys[e.Item.ItemIndex];
			
			
			
					String strconn;
					strconn = "Delete From[notebook]  Where Model =  '"+id+"'";
					SqlCommand mycommand = new SqlCommand(strconn, myconn);
					myconn.Open();
					mycommand.ExecuteNonQuery();
					myconn.Close();
			
		    	BindData();
		
      }
 

		</script>
		<form id="Form1" runat="server">
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
			<asp:datagrid id="mydatagrid" runat="server" cellpadding="3" BorderWidth="2" OnDeleteCommand="DataGrid1_Delete" OnItemCreated="dg_ItemCreated" onUpdateCommand="DataGrid_Update" onCancelCommand="DataGrid_Cancel" onEditCommand="DataGrid_Edit" DataKeyField="Model" AutoGenerateColumns="false">
				<HeaderStyle BackColor="#993333" Font-Name="Verdana" Font-Bold="true" Font-Size="10" ForeColor="#FFFFFF" />
				<ItemStyle Font-Name="Ms San Serif" Font-Size="10" />
				<AlternatingItemStyle BackColor="#EEEEEE" />
				<columns>
					<asp:EditCommandColumn ButtonType="LinkButton" EditText="Edit" UpdateText="Update" CancelText="Cancel" HeaderText="Edit" />
					<asp:BoundColumn HeaderText="Model" DataField="Model" />
					<asp:BoundColumn HeaderText="Name" DataField="Name" />
					<asp:BoundColumn HeaderText="Spec" DataField="Spec" />
					<asp:BoundColumn HeaderText="PriceTh" DataField="PriceTh" />
					<asp:BoundColumn HeaderText="PriceMemberTh" DataField="PriceMemberTh" />
					<asp:BoundColumn HeaderText="PriceSi" DataField="PriceSi" />
					<asp:BoundColumn HeaderText="PriceMemberSi" DataField="PriceMemberSi" />
					<asp:BoundColumn HeaderText="PriceIn" DataField="PriceIn" />
					<asp:BoundColumn HeaderText="PriceMemberIn" DataField="PriceMemberIn" />
					<asp:BoundColumn HeaderText="Image" DataField="Image" />
					
					<asp:ButtonColumn HeaderText="Delete Item" ButtonType="LinkButton" Text="Delete" CommandName="Delete"></asp:ButtonColumn>
				</columns>
			</asp:datagrid>
			<div align="right"><A href="Admin.aspx">:: Back to Previous Page ::</A></div>
		</form>
	</body>
</HTML>
