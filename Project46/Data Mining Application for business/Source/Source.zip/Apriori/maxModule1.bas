Attribute VB_Name = "Module1"
Option Explicit
Public a(100)  As Integer
Public b(100, 100) As Integer
Public c1(50, 50, 50) As Integer
Public c2(50, 50, 50, 50) As Integer
'Public d1(100, 100, 100, 100) As String
Public t2(100, 2) As String
Public t3(100, 3) As String
Public t4(100, 4) As String
Public dat As Database
Public rec As Recordset
Public rec1 As Recordset
Public num As Integer
Public lev As Single
Public tot As Integer
Public fre(100) As Integer
Public goods(100) As String
Public code(100) As Integer
Public tab1, tab2 As String
Public rec2 As Recordset


