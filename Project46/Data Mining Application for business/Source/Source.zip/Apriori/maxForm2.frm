VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Form2"
   ClientHeight    =   8310
   ClientLeft      =   165
   ClientTop       =   855
   ClientWidth     =   11880
   LinkTopic       =   "Form2"
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame2 
      Caption         =   "Frame2"
      Height          =   5535
      Left            =   600
      TabIndex        =   6
      Top             =   720
      Width           =   12375
      Begin VB.CommandButton Command1 
         Caption         =   "SUBMIT TO PROCESS"
         Height          =   375
         Left            =   5400
         TabIndex        =   10
         Top             =   4440
         Width           =   2415
      End
      Begin VB.CommandButton Command2 
         Caption         =   "==>"
         BeginProperty Font 
            Name            =   "MS Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   4560
         TabIndex        =   9
         Top             =   2280
         Width           =   975
      End
      Begin VB.ListBox List3 
         Height          =   2010
         ItemData        =   "maxForm2.frx":0000
         Left            =   5520
         List            =   "maxForm2.frx":0002
         TabIndex        =   8
         Top             =   1440
         Width           =   4335
      End
      Begin VB.ListBox List2 
         Height          =   2790
         Left            =   120
         TabIndex        =   7
         Top             =   1320
         Width           =   4335
      End
      Begin VB.Label Label2 
         Caption         =   "�������"
         Height          =   375
         Left            =   2760
         TabIndex        =   12
         Top             =   840
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "�����Թ���"
         Height          =   255
         Left            =   0
         TabIndex        =   11
         Top             =   0
         Width           =   1695
      End
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access"
      DatabaseName    =   ""
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   375
      Left            =   0
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   ""
      Top             =   6600
      Width           =   2415
   End
   Begin VB.Frame Frame1 
      Caption         =   "Frame1"
      Height          =   4095
      Left            =   1080
      TabIndex        =   0
      Top             =   600
      Width           =   3855
      Begin VB.ListBox List1 
         Height          =   255
         Left            =   120
         TabIndex        =   5
         Top             =   2040
         Width           =   2775
      End
      Begin VB.TextBox Text1 
         Height          =   495
         Left            =   120
         TabIndex        =   4
         Text            =   "Text1"
         Top             =   2880
         Width           =   2775
      End
      Begin VB.FileListBox File1 
         Height          =   480
         Left            =   120
         TabIndex        =   3
         Top             =   1560
         Width           =   2775
      End
      Begin VB.DirListBox Dir1 
         Height          =   990
         Left            =   120
         TabIndex        =   2
         Top             =   480
         Width           =   2775
      End
      Begin VB.DriveListBox Drive1 
         Height          =   315
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   2775
      End
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuOpen 
         Caption         =   "Open"
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
         Shortcut        =   ^X
      End
   End
   Begin VB.Menu mnuProcess 
      Caption         =   "Process"
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim codel(100) As Integer
Dim goodslo(100)   As String

Private Sub Command1_Click()
Dim i, r, j  As Integer
Cls
   r = List3.ListCount
   For i = 1 To r
          goods(i) = Str(codel(i))
          Print goods(i)
   Next i
   num = r
    Form2.Hide
    Form1.Show

End Sub

Private Sub Command2_Click()
Dim mess1   As String * 50
Dim i   As Integer
Dim j, k  As Integer
Dim goodst(100) As String
Dim lev1 As Single
Static pt, num1    As Integer
  
  If (pt = 0) Then
                    num1 = num
                    pt = 1
   Else
      List3.Clear
   End If
j = 0
For i = 1 To num1
     If ((fre(i) / tot) >= lev) Then
            j = j + 1
              goodst(j) = goodslo(i)
              List3.AddItem goodst(j)
              goods(j) = goodst(j)
              codel(j) = code(i)
      End If
Next i
If (pt = 0) Then num = j
For i = 1 To num
     goods(i) = goodslo(i)
Next i
Command1.Enabled = True
End Sub



Private Sub Dir1_Change()
File1.Pattern = "*." + List1.Text
File1.FileName = Dir1.Path
End Sub

Private Sub Drive1_Change()
Dir1.Path = Drive1.Drive
End Sub

Private Sub File1_Click()
Dim fname As String
fname = Dir1.Path + "\" + File1.FileName
Text1.Text = fname
End Sub

Private Sub File1_DblClick()
Text1.Text = File1.FileName
End Sub


Private Sub Form_Load()
Form1.WindowState = 2
Frame2.Visible = False
List1.AddItem "mdb"
List1.AddItem "*.*"
Data1.Visible = False
Command1.Enabled = False
End Sub

Private Sub mnuExit_Click()
''Form3.Show
''Form2.Hide
End
End Sub

Private Sub mnuOpen_Click()
Dim fname As String
fname = Text1.Text
Set dat = OpenDatabase(fname)
Frame1.Visible = False
Frame2.Visible = False
End Sub

Private Sub mnuProcess_Click()
    Dim tab2 As String
    Dim tab1 As String
    Dim myname As String * 50
    Dim tcode, mycode As String
    Dim i, numlo, bl As Integer
    Dim lev1 As Single
    tab1 = InputBox("OrderDetails")
    tab2 = InputBox("Products")
    'tab2 = "Products"
    'tab1 = "OrderDetails"
    'tab2 = "tab2"
    'tab1 = "tab1"
    Frame2.Visible = True
    lev = Val(InputBox("Input % Minimum Support"))
    lev = lev / 100
    Set rec1 = dat.OpenRecordset("select * from " & tab2 & "'")
    Set rec2 = dat.OpenRecordset("select * from " & tab1 & "'")
     rec2.MoveFirst
     While Not rec2.EOF
         i = rec2("ProductID")
         fre(i) = fre(i) + 1
         rec2.MoveNext
     Wend
     rec2.MoveFirst
     tcode = rec2("OrderID")
     rec2.MoveNext
     While (Not rec2.EOF)
          mycode = rec2("OrderID")
          If (tcode <> mycode) Then
              tot = tot + 1
          End If
           tcode = mycode
           rec2.MoveNext
     Wend
     tot = tot + 1
     numlo = 0
     rec1.MoveFirst
     While Not rec1.EOF
          numlo = numlo + 1
          code(numlo) = rec1("ProductID")
          goodslo(numlo) = rec1("ProductName")
          bl = Len(myname)
          myname = rec1("ProductName") & String(50 - bl, " ")
          List2.AddItem myname & "FRE =" & Str(fre(numlo))
          rec1.MoveNext
     Wend
     num = numlo
     i = 0
     List2.Selected(0) = True
     Frame1.Visible = False

End Sub
