VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   10275
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   14475
   LinkTopic       =   "Form1"
   ScaleHeight     =   10275
   ScaleWidth      =   14475
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command5 
      Caption         =   "GO TO MENU"
      Height          =   855
      Left            =   5760
      Picture         =   "maxForm1.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   6720
      Width           =   1335
   End
   Begin VB.CommandButton Command4 
      Caption         =   " 4 ITEM"
      Height          =   855
      Left            =   4320
      Picture         =   "maxForm1.frx":0442
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   6720
      Width           =   1335
   End
   Begin VB.CommandButton Command3 
      Caption         =   "3   ITEM"
      Height          =   855
      Left            =   2880
      Picture         =   "maxForm1.frx":0EFC
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   6720
      Width           =   1335
   End
   Begin VB.CommandButton Command2 
      Caption         =   "2  ITEM"
      Height          =   855
      Left            =   1440
      Picture         =   "maxForm1.frx":369E
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   6720
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "1    ITEM"
      Height          =   855
      Left            =   0
      MaskColor       =   &H00FFFFFF&
      Picture         =   "maxForm1.frx":39A8
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   6720
      Width           =   1335
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Sub Head2()
Print String(200, "=")
   Print , , "ITEM_1 ", " ITEM_2 ", " CONFIDENCE  of P(A / B) "
   Print String(200, "=")

End Sub
Sub Head3()
Print String(200, "=")
   Print , , "ITEM_1 ", " ITEM_2 ", "ITEM_3", " CONFIDENCE  of P(AB /C) "
   Print String(200, "=")

End Sub
Sub Head4()
Print String(200, "=")
   Print , "ITEM_1 ", " ITEM_2 ", "ITEM_3", "ITEM_4", " CONFIDENCE  of P(ABC /d) "
   Print String(200, "=")

End Sub

Function ret(ByVal s As String)
Dim j As Integer
     j = 1
     While (s <> goods(j) And j < num)
        j = j + 1
     Wend
      If (s = goods(j)) Then
          ret = j
      End If
End Function
Function check(ByVal s As String)
  Dim i As Integer
      i = 1
     While (s <> goods(i) And i < num)
        i = i + 1
     Wend
      If (s = goods(i)) Then
         check = "Y"
      Else
          check = "N"
      End If
End Function



Private Sub Command1_Click()
Dim i, j, k, tot1  As Integer
Dim s As String
rec2.MoveFirst
While (Not rec2.EOF)
      s = Str(rec2("ProductId"))
      If (check(s) = "Y") Then
              k = ret(s)
              a(k) = a(k) + 1
              tot1 = tot1 + 1
      End If
      rec2.MoveNext
Wend
   Print String(200, "=")
   Print , " ITEM    ID ", " FREQUENCY ", "P(A)"
   Print String(200, "=")
   For i = 1 To num
      Print , goods(i), a(i), Round((a(i) / tot1), 2)
   Next i
Print String(200, "=")

End Sub



Private Sub Command2_Click()
Dim tcode, mycode As String
Dim v(50) As String
Dim i, j, k, n, c, p, co  As Integer
Dim t1(100) As String
Dim test As Integer
Dim tot2 As Integer
Dim sup As Single
Cls
lev = lev / 2
Print
n = 0
   For i = 1 To num
          n = n + 1
          t1(n) = goods(i)
   Next i
   rec2.MoveFirst
   mycode = Str(rec2("OrderId"))
   If (check(Str(rec2("ProductId"))) = "Y") Then
       ' Print rec2("ProductId")
        p = 1
        v(1) = Str(rec2("ProductId"))
        rec2.MoveNext
    End If
Do While (Not rec2.EOF)
       tcode = Str(rec2("OrderId"))
      If (mycode <> tcode) Then
          For i = 1 To n - 1
              k = 1
              While (k < p And t1(i) <> v(k))
                       k = k + 1
              Wend
              If (t1(i) = v(k)) Then
                   For j = i + 1 To n
                       k = 1
                      While (k < p And t1(j) <> v(k))
                          k = k + 1
                      Wend
                       If (t1(j) = v(k)) Then
                          b(i, j) = b(i, j) + 1
                          tot2 = tot2 + 1
                       End If
                    Next j
                End If
          Next i
           p = 0
      End If
          If (check(Str(rec2("ProductId"))) = "Y") Then
                p = p + 1
                v(p) = Str(rec2("ProductId"))
           End If
                mycode = tcode
        rec2.MoveNext
Loop
      For i = 1 To n - 1
              k = 1
              While (k < p And t1(i) <> v(k))
                       k = k + 1
              Wend
              If (t1(i) = v(k)) Then
                   For j = i + 1 To n
                       k = 1
                      While (k < p And t1(j) <> v(k))
                          k = k + 1
                      Wend
                       If (t1(j) = v(k)) Then
                          b(i, j) = b(i, j) + 1
                          tot2 = tot2 + 1
                       End If
                    Next j
                End If
       Next i
   k = 0
   co = 0
   Head2
   sup = lev / tot2
   For i = 1 To num
       For j = i + 1 To num
              If (b(i, j) / tot2 > lev) Then
              k = k + 1
              t2(k, 1) = goods(i)
              t2(k, 2) = goods(j)
              co = co + 1
          'Print " Frequency   of  b(i,j)     =    ", t2(k, 1), t2(k, 2), b(i, j)
           If (co Mod 40 = 0) Then
                  Print String(200, "=")
                  MsgBox ("Continue")
                  Cls
                  Head2
                  co = 0
            End If
            Print , , t2(k, 1), t2(k, 2), Round((b(i, j) / a(i)), 2)
          End If
          
       Next j
    Next i
       Print String(200, "=")
       num = k
       For i = 1 To k
        'Print "               ", t2(i, 1), t2(i, 2)
       Next i
       
End Sub

Private Sub Command3_Click()
Dim tcode, mycode As String
Dim v(40) As String
Dim i, j, k, n, c, p, m1, m2 As Integer
Dim d1, d2, d3 As Integer
Dim lo1, lo2, k1  As Integer
Dim tot3, co  As Integer
Dim test As Integer
n = num
lev = lev / 2
rec2.MoveFirst
tcode = rec2("OrderID")
p = 0
Cls
   rec2.MoveFirst
Do While (Not rec2.EOF)
    mycode = Str(rec2("OrderId"))
    If (tcode = mycode) Then
       If (check(Str(rec2("ProductId"))) = "Y") Then
              p = p + 1
              v(p) = Str(rec2("ProductId"))
        End If
     End If
     If (mycode <> tcode) Then
        If (p > 2) Then
            'Print "v", , v(1), v(2), v(3)
            For i = 1 To n
                   k = 1
                   While (k < p And t2(i, 1) <> v(k))
                       k = k + 1
                   Wend
                  If (t2(i, 1) = v(k)) Then
                       d1 = ret(t2(i, 1))
                       lo1 = k
                       k = 1
                      While (k < p And t2(i, 2) <> v(k))
                          k = k + 1
                      Wend
                       If (t2(i, 2) = v(k)) Then
                           d2 = ret(t2(i, 2))
                           lo2 = k
                           For m1 = 1 To p
                              If Not (m1 = lo1 Or m1 = lo2) Then
                                   d3 = ret(v(m1))
                                   'Print "d", d1, d2, d3
                                  c1(d1, d2, d3) = c1(d1, d2, d3) + 1
                                  tot3 = tot3 + 1
                              End If
                           Next m1
                     
                       End If
                End If
             Next i
        End If
          If (check(Str(rec2("ProductId"))) = "Y") Then
            p = 1
            v(p) = Str(rec2("ProductId"))
          Else
            p = 0
          End If
    End If
       tcode = mycode
       rec2.MoveNext
Loop
      If (p > 2) Then
        For i = 1 To n
              k = 1
              While (k < p And t2(i, 1) <> v(k))
                       k = k + 1
              Wend
              If (t2(i, 1) = v(k)) Then
                       d1 = ret(t2(i, 1))
                       lo1 = k
                       k = 1
                      While (k < p And t2(i, 2) <> v(k))
                          k = k + 1
                      Wend
                       If (t2(i, 2) = v(k)) Then
                           d2 = ret(t2(i, 2))
                           lo2 = k
                           For m1 = 1 To p
                              If Not (m1 = lo1 Or m1 = lo2) Then
                                  d3 = ret(v(m1))
                                  c1(d1, d2, d3) = c1(d1, d2, d3) + 1
                                   tot3 = tot3 + 1
                              End If
                           Next m1
                       End If
                End If
          Next i
       End If
        For i = 1 To 3
           For j = i + 1 To 4
             For k = j + 1 To 5
                'Print " Three Item  ", c1(i, j, k)
             Next k
            Next j
        Next i
       ' Print "tot3", tot3
   k = 0
   co = 0
   Cls
   Head3
   For i = 1 To 3
       For j = i + 1 To 4
          For k1 = j + 1 To 5
                       If (tot3 > 0) Then
                                If ((c1(i, j, k1) / tot3) > lev) Then
                                      ' Print c1(i, j, k1), b(i, j)
                                        k = k + 1
                                        t3(k, 1) = goods(i)
                                        t3(k, 2) = goods(j)
                                        t3(k, 3) = goods(k1)
                                        Print , , t3(k, 1), t3(k, 2), t3(k, 3), "=", Round((c1(i, j, k1) / b(i, j)), 2)
                                        co = co + 1
                                        If (co Mod 40 = 0) Then
                                            MsgBox ("Continue")
                                            Cls
                                            co = 0
                                             Print String(200, "=")
                                        End If
                                 End If
                        End If
        Next k1
       Next j
   Next i
   Print String(200, "=")
   num = k

End Sub

Private Sub Command4_Click()
Dim tcode, mycode As String
Dim v(50) As String
Dim i, j, k, n, c, p, m1, m2 As Integer
Dim d1, d2, d3, d4, tot4 As Integer
Dim lo1, lo2, lo3, k2, k1, l As Integer
Dim test, co As Integer
n = num
rec2.MoveFirst
tcode = rec2("OrderID")
Cls
p = 0
lev = lev / 2
   rec2.MoveFirst
Do While (Not rec2.EOF)
    mycode = rec2("OrderId")
   ' Print "mycode", mycode, tcode
    If (tcode = mycode) Then
       If (check(Str(rec2("ProductId"))) = "Y") Then
          p = p + 1
          v(p) = Str(rec2("ProductId"))
        End If
     End If
      If (mycode <> tcode) Then
        If (p > 3) Then
            'Print "v", , v(1), v(2), v(3)
            For i = 1 To n
                   k = 1
                   While (k < p And t3(i, 1) <> v(k))
                       k = k + 1
                   Wend
                  If (t3(i, 1) = v(k)) Then
                       d1 = ret(t3(i, 1))
                       lo1 = k
                       k = 1
                        While (k < p And t3(i, 2) <> v(k))
                          k = k + 1
                        Wend
                        If (t3(i, 2) = v(k)) Then
                           d2 = ret(t3(i, 2))
                           lo2 = k
                            k = 1
                            While (k < p And t3(i, 3) <> v(k))
                                  k = k + 1
                            Wend
                            If (t3(i, 3) = v(k)) Then
                              d3 = ret(t3(i, 3))
                              lo3 = k
                              For m1 = 1 To p
                              If Not (m1 = lo1 Or m1 = lo2 Or m1 = lo3) Then
                                   d4 = ret(v(m1))
                                   'Print "d", d1, d2, d3
                                  c2(d1, d2, d3, d4) = c2(d1, d2, d3, d4) + 1
                                    tot4 = tot4 + 1
                              End If
                           Next m1
                         End If
                       End If
                End If
             Next i
          End If
        If (check(Str(rec2("ProductId"))) = "Y") Then
          p = 1
          'v(p) = Str(rec2("ProductId"))
         Else
            p = 0
         End If
         
       End If
       tcode = mycode
       rec2.MoveNext
Loop
      If (p > 3) Then
        For i = 1 To n
                   k = 1
                   While (k < p And t3(i, 1) <> v(k))
                       k = k + 1
                   Wend
                  If (t3(i, 1) = v(k)) Then
                       d1 = ret(t3(i, 1))
                       lo1 = k
                       k = 1
                        While (k < p And t3(i, 2) <> v(k))
                          k = k + 1
                        Wend
                        If (t3(i, 2) = v(k)) Then
                           d2 = ret(t3(i, 2))
                           lo2 = k
                            k = 1
                            While (k < p And t3(i, 3) <> v(k))
                                  k = k + 1
                            Wend
                            If (t3(i, 3) = v(k)) Then
                              d3 = ret(t3(i, 3))
                              lo3 = k
                              For m1 = 1 To p
                              If Not (m1 = lo1 Or m1 = lo2 Or m1 = lo3) Then
                                   d4 = ret(v(m1))
                                   'Print "d", d1, d2, d3
                                  c2(d1, d2, d3, d4) = c2(d1, d2, d3, d4) + 1
                                  tot4 = tot4 + 1
                              End If
                           Next m1
                         End If
                       End If
                End If
             Next i
  End If
        For i = 1 To 2
           For j = i + 1 To 3
             For k = j + 1 To 4
                For l = k + 1 To 5
                  ' Print " Four Item  ", c2(i, j, k, l)
                Next l
             Next k
            Next j
        Next i
   Cls
   Head4
   For i = 1 To 2
       For j = i + 1 To 3
          For k1 = j + 1 To 4
            For l = k1 + 1 To 5
              If (c2(i, j, k1, l) > lev) Then
                 k = k + 1
                 t4(k, 1) = goods(i)
                 t4(k, 2) = goods(j)
                 t4(k, 3) = goods(k1)
                 t4(k, 4) = goods(l)
              'Print "       ", t4(k, 1), t4(k, 2), t4(k, 3), t4(k, 4)
              End If
              If (c2(i, j, k1, l) > 0 And c1(i, j, k1) > 0) Then
                 'Print " Confidence  of P(ABC/D)      =    ", c2(i, j, k1, l), c1(i, j, k1)
                 Print , t4(k, 1), t4(k, 2), t4(k, 3), t4(k, 4), Round((c2(i, j, k1, l) / c1(i, j, k1)), 2)
                co = co + 1
                 If (co Mod 50 = 0) Then
                    MsgBox ("Continue")
                    Cls
                    co = 0
                    Print String(200, "=")
                 End If
            End If
            Next l
       Next k1
      Next j
    Next i
    Print String(200, "=")
    num = k
    

End Sub

Private Sub Command5_Click()
'''Form1.Hide
'''Form3.Show
End
End Sub

Private Sub Form_Activate()
Form1.Caption = "DATA MINING"
Form1.WindowState = 2
Command1.Caption = "One Items"
Command2.Caption = "Two Items"
Command3.Caption = "Three Items"
Command4.Caption = "Four Items"
Command5.Caption = "EXIT"


End Sub

