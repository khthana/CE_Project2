VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4800
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   7200
   LinkTopic       =   "Form1"
   ScaleHeight     =   4800
   ScaleWidth      =   7200
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      Height          =   3735
      Left            =   1200
      TabIndex        =   0
      Top             =   480
      Width           =   4575
      Begin VB.CommandButton Command1 
         Caption         =   "MBA"
         Height          =   615
         Index           =   0
         Left            =   1680
         TabIndex        =   4
         Top             =   360
         Width           =   1215
      End
      Begin VB.CommandButton Command1 
         Caption         =   "DecisionTree"
         Height          =   615
         Index           =   1
         Left            =   1680
         TabIndex        =   3
         Top             =   1200
         Width           =   1215
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Regression"
         Height          =   615
         Index           =   2
         Left            =   1680
         TabIndex        =   2
         Top             =   2040
         Width           =   1215
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Exit"
         Height          =   615
         Index           =   3
         Left            =   1680
         TabIndex        =   1
         Top             =   2880
         Width           =   1215
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click(Index As Integer)
Dim iTask As Long
Dim i As Integer
 i = Index
 Select Case i
 Case 0: iTask = Shell(App.Path & "\maxProject1.exe", vbNormalFocus)
 Case 1: iTask = Shell(App.Path & "\ParetoAnalysts.exe", vbNormalFocus)
 Case 2: iTask = Shell(App.Path & "\Regression.exe", vbNormalFocus)
 Case 3: End
 End Select
    
End Sub
