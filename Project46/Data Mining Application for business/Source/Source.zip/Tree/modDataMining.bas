Attribute VB_Name = "modDataMining"
Public DataAccessObject As cDataAccessObject
Public DatabaseSchema As cADOSchemas
Public DataMiningServer As cDataMiningServer
Public ErrorManager As New cErrors
Public DecisionTrees As New cDecisionTrees
Public cNodes As New colNodes


'The maximum number of nodes allowed in a Nodes collection
Public Const NODE_LIMIT As Long = 100


'Conditional compilation statement used to remove
'debugging statements from the application. when distributed
#Const DebugMode = True


Public Enum UseView
    XMLView = 1
    SQLView = 2
End Enum



