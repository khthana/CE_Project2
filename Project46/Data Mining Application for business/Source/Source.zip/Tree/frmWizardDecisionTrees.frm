VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmWizardDecisionTrees 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Decision Trees Wizard "
   ClientHeight    =   7410
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9660
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MinButton       =   0   'False
   ScaleHeight     =   7410
   ScaleMode       =   0  'User
   ScaleWidth      =   9660
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   7320
      Index           =   0
      Left            =   60
      TabIndex        =   0
      Top             =   50
      Width           =   9520
      Begin VB.Frame fraDecisionTrees 
         Caption         =   "&Decision Trees Data Mining"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   5745
         Left            =   120
         TabIndex        =   7
         Top             =   140
         Width           =   9285
         Begin MSComctlLib.TreeView tvwTrees 
            Height          =   5415
            Left            =   75
            TabIndex        =   8
            Top             =   240
            Width           =   9120
            _ExtentX        =   16087
            _ExtentY        =   9551
            _Version        =   393217
            LabelEdit       =   1
            LineStyle       =   1
            Sorted          =   -1  'True
            Style           =   5
            ImageList       =   "imgLst"
            BorderStyle     =   1
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            OLEDropMode     =   1
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   615
         Index           =   2
         Left            =   120
         TabIndex        =   5
         Top             =   5880
         Width           =   9285
         Begin MSComctlLib.ImageList imgLst 
            Left            =   3720
            Top             =   0
            _ExtentX        =   1005
            _ExtentY        =   1005
            BackColor       =   -2147483643
            ImageWidth      =   32
            ImageHeight     =   32
            MaskColor       =   12632256
            _Version        =   393216
            BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
               NumListImages   =   4
               BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
                  Picture         =   "frmWizardDecisionTrees.frx":0000
                  Key             =   "Square"
               EndProperty
               BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
                  Picture         =   "frmWizardDecisionTrees.frx":12D2
                  Key             =   "BlackCircle"
               EndProperty
               BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
                  Picture         =   "frmWizardDecisionTrees.frx":229C
                  Key             =   "Arrow"
               EndProperty
               BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
                  Picture         =   "frmWizardDecisionTrees.frx":29EE
                  Key             =   "Rectangle"
               EndProperty
            EndProperty
         End
         Begin VB.Label lblWelcome 
            Caption         =   "The Decision Trees Algorithm Results."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   120
            TabIndex        =   6
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   120
         TabIndex        =   1
         Top             =   6480
         Width           =   9285
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   4920
            TabIndex        =   4
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdRun 
            Caption         =   "&Run >"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3480
            TabIndex        =   3
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdBack 
            Caption         =   "< &Back"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   2160
            TabIndex        =   2
            Top             =   240
            Width           =   855
         End
      End
   End
End
Attribute VB_Name = "frmWizardDecisionTrees"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Private Copy of the cNode class
Private cNode As New cNode

Private Sub cmdBack_Click()

    frmWizardDefineAttributes.Show
    
    Me.Hide
    
End Sub

Private Sub cmdCancel_Click()

    ''Unload Me
    
    ''frmWizardWelcome.Show
    End
End Sub

Private Sub cmdRun_Click()
On Error GoTo ErrorHandler
    
    
    Set cNodes = Nothing
    
    
    Set cNodes = New colNodes
    
    
    DecisionTrees.CreateDecisionTree
    
    
    Call DrawTreeNodes(cNodes)
    
  
    
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "cmdRun_Click.frmWizardDecisionTrees"
    
    Resume Exit_ErrorHandler


End Sub

Private Function CreateNode(ByVal NodeText As String, ByVal NodeTag As String, _
                            ByVal NodeKey As String, _
                            Optional ByVal ParentKey As String, _
                            Optional ByVal NodeImage As String, _
                            Optional ByVal NodeRelations As TreeRelationshipConstants) As Node
    
    'Adds a node to the node tree
    
    
    Dim Nodx As Node
    

    If ParentKey = "" Then
        
        Set Nodx = tvwTrees.Nodes.Add(, , NodeKey)
        
    Else
    
        Set Nodx = tvwTrees.Nodes.Add(ParentKey, NodeRelations, NodeKey)
        
    End If


    
    Nodx.Text = UCase(NodeText)
    Nodx.Tag = NodeTag
    Nodx.Bold = True
    Nodx.Key = NodeKey
    Nodx.Image = NodeImage
    Nodx.EnsureVisible
    
    
    Set CreateNode = Nodx
    
    
End Function

Private Function DrawTreeNodes(ByVal TreeNodeCollection As colNodes) As TreeView
On Error GoTo ErrorHandler

    'Draws a Data Mining Tree Node Using A Tree View Control
    
    
    Dim Nodx As cNode
    Dim strChildKey As String
    Dim strParentKey As String
    
    
    If tvwTrees.Nodes.Count <> 0 Then
        tvwTrees.Nodes.Clear
    End If
    
    
    For Each Nodx In TreeNodeCollection
    
        
        'The Child Key for each Node
        strChildKey = "NODE" & CStr(Nodx.NodeIndex)
        
        'The Parent Key for each Node
        strParentKey = "NODE" & CStr(Nodx.NodeParent.NodeIndex)
        
        
        Select Case Nodx.NodeType
        
        
        Case NODE_TYPE.adRootNode
        
            Call CreateNode(Nodx.NodeName, Nodx.NodeName, strChildKey, , "Arrow")
        
        
        Case NODE_TYPE.adLeafNode
            
            Call CreateNode(Nodx.NodeName, Nodx.NodeName, strChildKey, strParentKey, "Rectangle", tvwChild)
            
            
        Case NODE_TYPE.adValueNode
            
            Call CreateNode(Nodx.NodeName, Nodx.NodeName, strChildKey, strParentKey, "BlackCircle", tvwChild)
            
            
            
        Case Else
            
            Call CreateNode(Nodx.NodeName, Nodx.NodeName, strChildKey, strParentKey, "Square", tvwChild)

        
        End Select
        
    
    Next
    
    
    'Return The TreeView Control
    Set DrawTreeNodes = tvwTrees
    
    
Exit_ErrorHandler:
    Exit Function
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "DrawTreeNodes.frmWizardDecisionTrees"
   
End Function
