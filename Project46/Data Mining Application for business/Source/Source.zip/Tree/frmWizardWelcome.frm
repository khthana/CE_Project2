VERSION 5.00
Begin VB.Form frmWizardWelcome 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Wizard "
   ClientHeight    =   5190
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6870
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5190
   ScaleWidth      =   6870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   4935
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6615
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   360
         TabIndex        =   6
         Top             =   4080
         Width           =   5895
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3240
            TabIndex        =   10
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdHelp 
            Caption         =   "&Help"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   4560
            TabIndex        =   9
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdNext 
            Caption         =   "&Next >"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   1800
            TabIndex        =   8
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdBack 
            Caption         =   "< &Back"
            Enabled         =   0   'False
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   480
            TabIndex        =   7
            Top             =   240
            Width           =   855
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   975
         Index           =   2
         Left            =   120
         TabIndex        =   4
         Top             =   3000
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   "You will also specify the Data Mining Algorithm that you will use, and the output format of the final result."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Index           =   2
            Left            =   120
            TabIndex        =   5
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   1815
         Index           =   1
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   $"frmWizardWelcome.frx":0000
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Index           =   1
            Left            =   120
            TabIndex        =   3
            Top             =   720
            Width           =   6135
            WordWrap        =   -1  'True
         End
         Begin VB.Label lblWelcome 
            Caption         =   " Welcome to the Data Mining Wizard."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   0
            Left            =   120
            TabIndex        =   2
            Top             =   240
            Width           =   3375
         End
      End
   End
End
Attribute VB_Name = "frmWizardWelcome"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
    
    Dim frm As Form
    
    
    'Unload All Forms
    For Each frm In Forms
    
        Unload frm
        
        Set frm = Nothing
        
    Next frm
    
    
End Sub

Private Sub cmdNext_Click()

    frmWizardDataMiningAlgorithms.Show
    
    Me.Hide
    
End Sub

