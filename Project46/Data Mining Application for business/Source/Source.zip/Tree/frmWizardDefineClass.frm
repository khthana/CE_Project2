VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmWizardDefineClass 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Wizard "
   ClientHeight    =   5190
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6870
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5190
   ScaleWidth      =   6870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   4935
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6615
      Begin VB.Frame fraSelectedTable 
         Caption         =   "&Your Selected Class"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   3360
         TabIndex        =   8
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwClassPredict 
            Height          =   2895
            Left            =   75
            TabIndex        =   10
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            LineStyle       =   1
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
         End
      End
      Begin VB.Frame fraAvailableTables 
         Caption         =   "&Select One Column As Your Class"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwAttributes 
            Height          =   2895
            Left            =   75
            TabIndex        =   9
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            OLEDropMode     =   1
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   615
         Index           =   2
         Left            =   120
         TabIndex        =   5
         Top             =   3480
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   "Select The Column You Will Use For Classifying Other Columns."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   120
            TabIndex        =   6
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   360
         TabIndex        =   1
         Top             =   4080
         Width           =   5895
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3240
            TabIndex        =   4
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdNext 
            Caption         =   "&Next >"
            Enabled         =   0   'False
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   1800
            TabIndex        =   3
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdBack 
            Caption         =   "< &Back"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   480
            TabIndex        =   2
            Top             =   240
            Width           =   855
         End
      End
   End
End
Attribute VB_Name = "frmWizardDefineClass"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private rstSchema As ADODB.Recordset

Private Sub cmdBack_Click()
    
    Dim strChoice
    
    strChoice = DataMiningServer.DataSourceChoice
    
    If (strChoice = "optSingleTable") Then
    
        frmWizardSingleTable.Show
        
    ElseIf (strChoice = "optSQL") Then
    
        frmWizardDataSourceChoices.Show
        
    End If

    Unload Me
    
    frmWizardSingleTable.Show
    
End Sub

Private Sub cmdCancel_Click()

    ''Unload Me
    
    ''frmWizardWelcome.Show
    End
End Sub

Private Sub cmdNext_Click()

    frmWizardDefineAttributes.Show
    
    Me.Hide
    
End Sub

Private Sub Form_Load()
    
    
    Dim strTable As String
    Dim strNode As String
    Dim NodeObject As Node
    Dim fld As ADODB.Field
    
    
    'refresh the form
    Me.Refresh
    

    'Get the schema for the fields in the database
    Set rstSchema = DatabaseSchema.FieldSchema
        
        
    rstSchema.MoveFirst
    
    
    'The tree view control used for classification will use check boxes
    tvwAttributes.Checkboxes = True
  
    'Get the selected table's name
    strTable = DataMiningServer.TableSelected

    If strTable <> "" Then
    
        ' The root node
        Set NodeObject = tvwAttributes.Nodes.Add(, , "root", strTable)
        
        NodeObject.Expanded = True
        NodeObject.Sorted = True
        NodeObject.Bold = True
        NodeObject.Checked = True
        NodeObject.Tag = "Selected Table"

    
        Do While rstSchema.EOF = False
            
            strNode = "[" & rstSchema!TABLE_NAME & "]"
            
            If (strTable = strNode) Then
                
                ' This next node is a child of the root node (root).
                Set NodeObject = tvwAttributes.Nodes.Add("root", tvwChild, , rstSchema!COLUMN_NAME)
                
                NodeObject.Tag = rstSchema!COLUMN_NAME
                
               'Expand the parent node
                NodeObject.Parent.Expanded = True
            
            End If
    
            rstSchema.MoveNext
        
        Loop
        
    End If
    

End Sub

Private Sub tvwAttributes_NodeCheck(ByVal Node As MSComctlLib.Node)

'This procedures runs when a Node is checked or unchecked in the Tree View

On Error GoTo ErrorHandler


    Dim strNode As String
    Dim strTable As String
    Dim lngIndex As Long
    Dim fld As ADODB.Field
    Dim rstSchema As ADODB.Recordset
    Dim nodClass As Node
    Dim blnCheck As Boolean
    
    
    'If the Root Node is selected, then exit
    If Node = Node.Root Then Exit Sub
        
    'If the parent node is not the root node, then exit
    If Not Node.Parent = Node.Root Then Exit Sub
    
    'If no field is selected then exit
    If Node.Text = "" Then Exit Sub
    
    lngIndex = Node.Index
    
    'The name of the node selected
    strNode = Node.Text
    
    'The check state of the node
    blnCheck = Node.Checked
    
   
    'Add only the selected table to the right tree view control
    'Add each table to the Tree View tvwPredict
    tvwClassPredict.Nodes.Clear
    
    
    'Uncheck all previously checked nodes
    For Each Node In tvwAttributes.Nodes
        If (Node.Text <> strNode) And (Node.Checked = True) And (Node <> Node.Root) Then
            Node.Checked = False
        End If
    Next
    
    
    If blnCheck = True Then
    
    
        ' The root node
        Set nodClass = tvwClassPredict.Nodes.Add(, , "root", "")
        nodClass.Tag = "Selected Class"
        nodClass.Text = "Class"

        ' This next node is a child of the root node (root).
        Set nodClass = tvwClassPredict.Nodes.Add("root", tvwChild, strNode, strNode)
    
        nodClass.Tag = strNode
    
        'Check the node
        nodClass.Checked = blnCheck
    
        'Expand the parent node
        nodClass.Parent.Expanded = True
        nodClass.Parent.Checked = True
        
        
    End If
    
    
    'Store the selected class
    DataMiningServer.ClassSelected = strNode
    
    
    'Enable Or Disable the 'Next' Command Button
    Call TreeView_Validate
    
    
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "tvwAttributes_NodeCheck.frmWizardDefineClass"
    
    Resume Exit_ErrorHandler
   

End Sub

Private Function TreeView_Validate() As Boolean
    'Enables the 'Next' button if
    'a table has been selected
    
    
    Dim Node As Node
    
    
    TreeView_Validate = False
    cmdNext.Enabled = False
    
        
    For Each Node In tvwClassPredict.Nodes
        
        If Node <> Node.Root Then
        
            cmdNext.Enabled = True
            
        End If
        
    Next
    
    
    TreeView_Validate = True
    
        
End Function
