VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmWizardNumericAttributes 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Wizard "
   ClientHeight    =   5190
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6870
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5190
   ScaleWidth      =   6870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   4935
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6615
      Begin VB.Frame fraSelectedTable 
         Caption         =   "&Your Selected Columns"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   3360
         TabIndex        =   8
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwClassPredict 
            Height          =   2895
            Left            =   75
            TabIndex        =   10
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            LineStyle       =   1
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
         End
      End
      Begin VB.Frame fraAvailableTables 
         Caption         =   "&Select The Numeric Columns"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwAttributes 
            Height          =   2895
            Left            =   75
            TabIndex        =   9
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            OLEDropMode     =   1
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   615
         Index           =   2
         Left            =   120
         TabIndex        =   5
         Top             =   3480
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   "Select The Columns That Have Numeric Values (Numeric Attributes)."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   120
            TabIndex        =   6
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   360
         TabIndex        =   1
         Top             =   4080
         Width           =   5895
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3240
            TabIndex        =   4
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdNext 
            Caption         =   "&Next >"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   1800
            TabIndex        =   3
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdBack 
            Caption         =   "< &Back"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   480
            TabIndex        =   2
            Top             =   240
            Width           =   855
         End
      End
   End
End
Attribute VB_Name = "frmWizardNumericAttributes"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private rstSchema As ADODB.Recordset

Private Sub cmdBack_Click()

    frmWizardDefineAttributes.Show
    
    Unload Me
    
End Sub

Private Sub cmdCancel_Click()

    ''Unload Me
    
    ''frmWizardWelcome.Show
    End
    
End Sub

Private Sub cmdNext_Click()
On Error GoTo ErrorHandler


    Dim strSQL As String
    Dim strTable As String
    Dim varData As Variant
    Dim CountFields As Long
    Dim lngNumeric As Long
    Dim lngNonNumeric As Long
    
    
    'The SQL String Used In Processing
    varData = DataMiningServer.AttributesSelected
    
    strSQL = "SELECT "
    
    For CountFields = LBound(varData) To UBound(varData)
        strSQL = strSQL & varData(CountFields) & ", "
    Next
    
    strSQL = Trim(strSQL)
        
    If Right(strSQL, 1) = "," Then
        strSQL = Mid(strSQL, 1, (Len(strSQL) - 1))
    End If
    
    strTable = Trim(DataMiningServer.TableSelected)
    
    'Replace any bracketing of the table name
    If Right(strTable, 1) = "]" Then
        strTable = Mid(strTable, 1, (Len(strTable) - 1))
    End If
    
    If Left(strTable, 1) = "[" Then
        strTable = Mid(strTable, 2, (Len(strTable) - 1))
    End If
            
    strSQL = strSQL & " FROM " & strTable
    
    
    DataMiningServer.SQLStatementUsed = strSQL
        
        
    DataMiningServer.UseView = SQLView
    
    
    'Create a List Of Numeric And
    'Non Numeric Selections
    lngNumeric = DataMiningServer.CountOfNumericAttributes
    lngNonNumeric = DataMiningServer.CountOfNonNumericAttributes
    If (lngNumeric = 0) And (lngNonNumeric = 0) Then
        Call TreeView_Selection
    End If
       
        
    frmWizardResults.Show
    Me.Hide
    
    
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "cmdNext_Click.frmWizardNumericAttributes"
    
    Resume Exit_ErrorHandler
       
    
End Sub

Private Sub Form_Load()
On Error GoTo ErrorHandler

    
    Dim strTable As String
    Dim varAttributes() As Variant
    Dim strNode As String
    Dim Nodx As Node
    Dim lngCount As Long
    
    
    
    'The tree view control used for classification will use check boxes
    tvwAttributes.Checkboxes = True
  
    'Get the selected table's name
    strTable = DataMiningServer.TableSelected
    
    'Get the selected attributes
    varAttributes = DataMiningServer.AttributesSelected
    

    If strTable <> "" Then
    
        ' The root node
        Set Nodx = tvwAttributes.Nodes.Add(, , "root")
        
        Nodx.Text = strTable
        Nodx.Tag = "Selected Table"
        Nodx.Expanded = True
        Nodx.Sorted = True
        Nodx.Bold = True
        Nodx.Checked = True
        
        
        'Root Node For Non Numeric Attributes
        Set Nodx = tvwClassPredict.Nodes.Add(, , "NonNumeric")
        
        Nodx.Text = "Non Numeric Attributes"
        Nodx.Tag = "Non Numeric Attributes"
        Nodx.Expanded = True
        Nodx.Sorted = True
        Nodx.Bold = True
        Nodx.Checked = False
          
    
        'Root Node For Numeric Attributes
        Set Nodx = tvwClassPredict.Nodes.Add("NonNumeric", tvwNext, "Numeric")
        
        Nodx.Text = "Numeric Attributes"
        Nodx.Tag = "Numeric Attributes"
        Nodx.Expanded = True
        Nodx.Sorted = True
        Nodx.Bold = True
        Nodx.Checked = False
        
            
        'Only the previously selected attributes will be available
        For lngCount = LBound(varAttributes) To UBound(varAttributes)
            
            strNode = varAttributes(lngCount)
            
               
            ' This next node is a child of the root node (root).
            Set Nodx = tvwAttributes.Nodes.Add("root", tvwChild, , strNode)
                
            'Tag the Node
            Nodx.Tag = strNode
                
            'Expand the parent node
            'nodX.Parent.Expanded = True
            
            
            'Add The Node To The Non Numeric Node
            Set Nodx = tvwClassPredict.Nodes.Add("NonNumeric", tvwChild)
            
            'The text to display for the Node
            Nodx.Text = strNode
        
            'Tag the Node
            Nodx.Tag = strNode
                                    
        Next
        
    End If
    
    
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "Form_Load.frmWizardNumericAttributes"
    
    Resume Exit_ErrorHandler
    
    
End Sub

Private Sub tvwAttributes_NodeCheck(ByVal Node As MSComctlLib.Node)
On Error GoTo ErrorHandler
    'This procedures runs when a Node is checked
    'or unchecked in the Tree View


    Dim strNode As String
    Dim strTable As String
    Dim lngIndex As Long
    Dim fld As ADODB.Field
    Dim rstSchema As ADODB.Recordset
    Dim Nodx As Node
    Dim blnCheck As Boolean
        
    
    'If the Root Node is selected, then exit
    If Node = Node.Root Then Exit Sub
        
    'If the parent node is not the root node, then exit
    If Not Node.Parent = Node.Root Then Exit Sub
    
    'If no field is selected then exit
    If Node.Text = "" Then Exit Sub
    
    lngIndex = Node.Index
    
    'The name of the node selected
    strNode = Node.Text
    
    'The check state of the node
    blnCheck = Node.Checked
    
    
    If blnCheck = True Then
        
        For Each Node In tvwClassPredict.Nodes
            
            If (Node.Text = strNode) _
                And (Node <> "Numeric Attributes") _
                And (Node <> "Non Numeric Attributes") Then
            
                lngIndex = Node.Index
                
                'Remove The Node From The Non Numeric Node
                tvwClassPredict.Nodes.Remove lngIndex
                
                
                'Add The Node To The Numeric Node
                Set Nodx = tvwClassPredict.Nodes.Add("Numeric", tvwChild)
        
                'The text to display for the Node
                Nodx.Text = strNode
        
                'Tag the Node
                Nodx.Tag = strNode
                                
                Exit For
                
            End If
            
        Next

        
       
        
    Else
        
        
        'The node deselected must be removed from the
        'Numeric Root And Added To The Non Numeric Root
        
        For Each Node In tvwClassPredict.Nodes
            
            If (Node.Text = strNode) _
                And (Node <> "Numeric Attributes") _
                And (Node <> "Non Numeric Attributes") Then
            
                lngIndex = Node.Index
                
                'Remove The Node From The Numeric Node
                tvwClassPredict.Nodes.Remove lngIndex
                
                
                'Add The Node To The Non Numeric Node
                Set Nodx = tvwClassPredict.Nodes.Add("NonNumeric", tvwChild)
        
                'The text to display for the Node
                Nodx.Text = strNode
        
                'Tag the Node
                Nodx.Tag = strNode
                
                
                Exit For
                
            End If
            
        Next
                
        
    End If
        
    
    'Create a List Of Numeric And
    'Non Numeric Selections
    Call TreeView_Selection
    
        
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "tvwAttributes_NodeCheck.frmWizardNumericAttributes"
    
    Resume Exit_ErrorHandler
 
 
End Sub

Private Function TreeView_Selection()
On Error GoTo ErrorHandler
    'Create a list of the numeric and
    'non numeric attributes selected
    
    
    Dim strNumeric() As String
    Dim strNonNumeric() As String
    Dim CountNumeric As Long
    Dim CountNonNumeric As Long
    
    
     For Each Node In tvwClassPredict.Nodes
            
        If (Node <> "Numeric Attributes") _
                    And (Node <> "Non Numeric Attributes") Then
        
            If (Node.Parent = "Numeric Attributes") Then
                
                'List Of Numeric Attributes
                ReDim Preserve strNumeric(CountNumeric)
        
                strNumeric(CountNumeric) = Node.Text
        
                CountNumeric = CountNumeric + 1
                
            Else
            
                'List Of Non Numeric Attributes
                ReDim Preserve strNonNumeric(CountNonNumeric)
                
                strNonNumeric(CountNonNumeric) = Node.Text
                
                CountNonNumeric = CountNonNumeric + 1
                                
            End If
            
        End If
        
    Next
    
    
    'Store the list of the numeric attributes selected
    DataMiningServer.NumericAttributes = strNumeric()
    DataMiningServer.CountOfNumericAttributes = CountNumeric
        
        
    'Store the list of the non numeric attributes selected
    DataMiningServer.NonNumericAttributes = strNonNumeric()
    DataMiningServer.CountOfNonNumericAttributes = CountNonNumeric
    
    
Exit_ErrorHandler:
    Exit Function
    
ErrorHandler:
    ErrorManager.ErrorHandler Err, _
        "TreeView_Selection.frmWizardNumericAttributes"
    
    Resume Exit_ErrorHandler
    
    
End Function
