VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmWizardSingleTable 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Wizard "
   ClientHeight    =   5190
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6870
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5190
   ScaleWidth      =   6870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   4935
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6615
      Begin VB.Frame fraSelectedTable 
         Caption         =   "&Your Selected Table"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   3360
         TabIndex        =   8
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwClassPredict 
            Height          =   2895
            Left            =   75
            TabIndex        =   10
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            LineStyle       =   1
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
         End
      End
      Begin VB.Frame fraAvailableTables 
         Caption         =   "&Select One Table"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   3255
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   3150
         Begin MSComctlLib.TreeView tvwAttributes 
            Height          =   2895
            Left            =   75
            TabIndex        =   9
            Top             =   240
            Width           =   3000
            _ExtentX        =   5292
            _ExtentY        =   5106
            _Version        =   393217
            Sorted          =   -1  'True
            Style           =   6
            Appearance      =   1
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Verdana"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            OLEDropMode     =   1
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   615
         Index           =   2
         Left            =   120
         TabIndex        =   5
         Top             =   3480
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   "Select the single table that contains all your data. "
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   2
            Left            =   120
            TabIndex        =   6
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   360
         TabIndex        =   1
         Top             =   4080
         Width           =   5895
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3240
            TabIndex        =   4
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdNext 
            Caption         =   "&Next >"
            Enabled         =   0   'False
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   1800
            TabIndex        =   3
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdBack 
            Caption         =   "< &Back"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   480
            TabIndex        =   2
            Top             =   240
            Width           =   855
         End
      End
   End
End
Attribute VB_Name = "frmWizardSingleTable"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private mNode As Node
Private CLASSIFY_ROOT_NAME As String
Private PREDICT_ROOT_NAME As String

Private Sub cmdBack_Click()

    frmWizardDataSource.Show
    Me.Hide
    
End Sub

Private Sub cmdCancel_Click()

    ''Unload Me
    ''frmWizardWelcome.Show
    End
End Sub

Private Sub cmdNext_Click()

    frmWizardDefineClass.Show
    Me.Hide
    
End Sub

Private Sub CreateRootNode()
On Error GoTo ErrorHandler
    
    
    'The tree view control used for classification
    'will use check boxes
    tvwAttributes.Checkboxes = True
    
    Set mNode = tvwAttributes.Nodes.Add()    'Create the firstSchema node
    
    'The properties of the Root Node Object.
    CLASSIFY_ROOT_NAME = "Default Schema..."
    mNode.Text = CLASSIFY_ROOT_NAME
    mNode.Expanded = True
    mNode.Sorted = True
    mNode.Bold = True
    mNode.Checked = True
    mNode.Tag = mNode.Root
        
    
    'For the tree view control tvwClassPredict used for ,
    'prediction the root node will be the different
    tvwClassPredict.Checkboxes = False
    
    Set mNode = tvwClassPredict.Nodes.Add       'Create the firstSchema node
    PREDICT_ROOT_NAME = "Selected Table..."
    mNode.Text = PREDICT_ROOT_NAME
    mNode.Expanded = False
    mNode.Sorted = True
    mNode.Bold = True
    mNode.Checked = False
    mNode.ForeColor = vbBlue
    mNode.Tag = mNode.Root
        
        
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:

    ErrorManager.ErrorHandler Err, "CreateRootNode.frmWizardSingleTable"
    
    Resume Exit_ErrorHandler
    
    
End Sub

Private Sub ListTables()
On Error GoTo ErrorHandler

    'Lists and adds the tables in the
    'database to the tree view controls

    
    Dim rstSchema As ADODB.Recordset


    'Retrieve the schema tables through a call to the OpenSchema method
    If (DatabaseSchema Is Nothing) Then
        Set DatabaseSchema = New cADOSchemas
    End If
    
    
    Set rstSchema = DatabaseSchema.OpenSchema_Tables(DataAccessObject.ConnectionObject)


    rstSchema.MoveFirst


    Do While (rstSchema.EOF = False)
    
        'Add each table to the Tree View tvwAttributes
        
        Set mNode = tvwAttributes.Nodes.Add(1, tvwChild)
        mNode.Text = "[" & rstSchema!TABLE_NAME & "]"
        mNode.Tag = "[" & rstSchema!TABLE_NAME & "]"
        
        rstSchema.MoveNext
    
    Loop


Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:

    ErrorManager.ErrorHandler Err, "ListTables.frmWizardSingleTable"
    
    Resume Exit_ErrorHandler
 

End Sub

Private Sub Form_Load()
    
    tvwAttributes.Nodes.Clear
    tvwClassPredict.Nodes.Clear
    
    Call CreateRootNode
    Call ListTables
    
End Sub

Private Sub tvwAttributes_NodeCheck(ByVal Node As MSComctlLib.Node)
On Error GoTo ErrorHandler
    'This procedures runs when a Node is
    'checked or unchecked in the Tree View


    Dim strNode As String
    Dim strTable As String
    Dim lngIndex As Long
    Dim fld As ADODB.Field
    Dim rstSchema As ADODB.Recordset
    Dim nodClass As Node
    Dim blnCheck As Boolean
    
    
    'If the Root Node is selected, then exit
    If Node = CLASSIFY_ROOT_NAME Then Exit Sub
    
    'If the parent node is not the root node, then exit
    If Not Node.Parent = CLASSIFY_ROOT_NAME Then Exit Sub
    
    'If the node has children, then exit
    'If (Node.Children > 0) Then Exit Sub
    
    'If no field is selected then exit
    If Node.Text = "" Then Exit Sub
    
    lngIndex = Node.Index
    
    'The name of the node selected
    strNode = Node.Text
    
    'The check state of the node
    blnCheck = Node.Checked
    
    
    'Uncheck all previously checked nodes
    For Each Node In tvwAttributes.Nodes
        If (Node.Text <> strNode) And (Node.Checked = True) And (Node <> Node.Root) Then
            Node.Checked = False
        End If
    Next

    
    
    If (DatabaseSchema Is Nothing) Then
        Set DatabaseSchema = New cADOSchemas
    End If
    
    
    Set rstSchema = DatabaseSchema.OpenSchema_Fields(DataAccessObject.ConnectionObject)
    
    
    rstSchema.MoveFirst
    
    
    Do While rstSchema.EOF = False


        strTable = "[" & rstSchema!TABLE_NAME & "]"
        
        If (strTable = strNode) Then
        
            Set Node = tvwAttributes.Nodes.Add(lngIndex, tvwChild)
      
            ' The text property of the node
            Node.Text = rstSchema!COLUMN_NAME
      
            'The tag property of the node
            Node.Tag = rstSchema!COLUMN_NAME
      
            'Expand the parent node
            Node.Parent.Expanded = True
            
        End If
    
        rstSchema.MoveNext
        

    Loop
    
    
    'Add only the selected table to the right tree view control
    'Add each table to the Tree View tvwPredict
    tvwClassPredict.Nodes.Clear
    
    
    If blnCheck = True Then
    
    
        ' The root node
        Set nodClass = tvwClassPredict.Nodes.Add(, , "root", "")
        nodClass.Tag = "Selected Table"
        nodClass.Text = "Table"

        ' This next node is a child of the root node (root).
        Set nodClass = tvwClassPredict.Nodes.Add("root", tvwChild, strNode, strNode)
    
        nodClass.Tag = strNode
    
        'Check the node
        nodClass.Checked = blnCheck
    
        'Expand the parent node
        nodClass.Parent.Expanded = True
        nodClass.Parent.Checked = True
        
        
    End If
    
    
    'Make The Selected Table Available To Other Forms
    If blnCheck = True Then
        DataMiningServer.TableSelected = strNode
    Else
        DataMiningServer.TableSelected = ""
    End If
    
    
    'Enable Or Disable the 'Next' Command Button
    Call TreeView_Validate
                     
    
Exit_ErrorHandler:
    Exit Sub
    
ErrorHandler:

    ErrorManager.ErrorHandler Err, "tvwAttributes_NodeCheck.frmWizardSingleTable"
    
    Resume Exit_ErrorHandler
    

End Sub

Private Function TreeView_Validate() As Boolean
    'Enables the 'Next' button if
    'a table has been selected
    
    
    Dim Node As Node
    
    
    TreeView_Validate = False
    cmdNext.Enabled = False
    
        
    For Each Node In tvwClassPredict.Nodes
        
        If Node <> Node.Root Then
        
            cmdNext.Enabled = True
            
        End If
        
    Next
    
    
    TreeView_Validate = True
    
        
End Function
