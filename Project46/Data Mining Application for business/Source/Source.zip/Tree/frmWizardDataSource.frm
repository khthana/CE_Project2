VERSION 5.00
Begin VB.Form frmWizardDataSource 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Data Mining Wizard "
   ClientHeight    =   5190
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6870
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5190
   ScaleWidth      =   6870
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame fraWelcome 
      Height          =   4935
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6615
      Begin VB.Frame FraNavigation 
         Height          =   735
         Left            =   360
         TabIndex        =   6
         Top             =   4080
         Width           =   5895
         Begin VB.CommandButton cmdCancel 
            Caption         =   "&Cancel"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   3240
            TabIndex        =   8
            Top             =   240
            Width           =   855
         End
         Begin VB.CommandButton cmdNext 
            Caption         =   "&Next >"
            Enabled         =   0   'False
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   1800
            TabIndex        =   7
            Top             =   240
            Width           =   855
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   975
         Index           =   2
         Left            =   120
         TabIndex        =   4
         Top             =   3000
         Width           =   6375
         Begin VB.Label lblWelcome 
            Caption         =   "Click on the button 'Connect to your database' to create a connection to the database containing the data to be analyzed."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Index           =   2
            Left            =   120
            TabIndex        =   5
            Top             =   240
            Width           =   6135
            WordWrap        =   -1  'True
         End
      End
      Begin VB.Frame fraWelcome 
         Height          =   2415
         Index           =   1
         Left            =   120
         TabIndex        =   1
         Top             =   240
         Width           =   6375
         Begin VB.CommandButton cmdNewDataSource 
            Caption         =   "Connect to your database ..."
            BeginProperty Font 
               Name            =   "Verdana"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   960
            TabIndex        =   9
            ToolTipText     =   "Select The Database"
            Top             =   1440
            Width           =   3950
         End
         Begin VB.Label lblWelcome 
            Caption         =   " "
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   1
            Left            =   120
            TabIndex        =   3
            Top             =   720
            Width           =   6135
            WordWrap        =   -1  'True
         End
         Begin VB.Label lblWelcome 
            Caption         =   " Create Your Data Source . . ."
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   0
            Left            =   120
            TabIndex        =   2
            Top             =   240
            Width           =   3375
         End
      End
   End
End
Attribute VB_Name = "frmWizardDataSource"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Microsoft Service Component OLEDB Service Component 1.0 Type Library
'C:\Program Files\Common Files\System\OLE DB\oledb32.dll

Private msDataLink As DataLinks

Private ConnectionString As String

Private Sub cmdCancel_Click()

    ''Unload Me
    
    ''frmWizardWelcome.Show
    End
End Sub

Private Sub cmdNewDataSource_Click()
    'Creates a new Data Source
    
    If (OpenConnection = True) Then
    
        cmdNext.Enabled = True
        
    End If
    
End Sub

Private Sub cmdNext_Click()
    
    frmWizardSingleTable.Show
    
    Me.Hide
    
End Sub


Private Function OpenConnection() As Boolean
On Error GoTo ErrorHandler

'   This sub uses MS Datalinks to build a connection string that is used to
'   poulate the treeview
'
'   Choose the provider Jet OLE 3 is Access '97
'   OLE 4.0 is Access 2000
'   Then select the database that you want to open and click ok.
'   The library can be located at the location below.
'   Microsoft Service Component OLEDB Service Component 1.0 Type Library
'   C:\Program Files\Common Files\System\OLE DB\oledb32.dll
            
    
    Dim varConnect As Variant

    
    OpenConnection = False
    
    
    If (msDataLink Is Nothing) Then
        Set msDataLink = New DataLinks
    End If
            
    
    varConnect = msDataLink.PromptNew
    
    If IsEmpty(varConnect) Or (varConnect = "") Then
        Exit Function
    Else
        ConnectionString = varConnect
    End If
    
    
    'Create the Data Access Object
    If DataAccessObject Is Nothing Then
        Set DataAccessObject = New cDataAccessObject
    End If
    
    
    'Close the previous connection
    If Not DataAccessObject.ConnectionObject Is Nothing Then
        Set DataAccessObject.ConnectionObject = Nothing
    End If

        
    Set DataAccessObject.ConnectionObject = New ADODB.Connection
            
   
    DataAccessObject.ConnectionObject.Open ConnectionString
    
    
    'Store the Connection String Used
    DataMiningServer.ConnectionStringUsed = ConnectionString
    
    
    OpenConnection = True
    
    
Exit_ErrorHandler:
    Exit Function
    
ErrorHandler:
        
    ErrorManager.ErrorHandler Err, "OpenConnection.frmWizardDataSource"
                            
    Resume Exit_ErrorHandler
    
    
End Function

Private Sub Form_Load()
''''''''''''''''
    If DataMiningServer Is Nothing Then
    
        Set DataMiningServer = New cDataMiningServer
        
    End If
    
''''''''''''''''


    If DataMiningServer.ConnectionStringUsed <> "" Then
        
        If DataAccessObject Is Nothing Then
        
            Set DataAccessObject = New cDataAccessObject
            
        End If
        
        
        'Close the previous connection
        If Not DataAccessObject.ConnectionObject Is Nothing Then
        
            DataAccessObject.ConnectionObject.Close
            
            Set DataAccessObject.ConnectionObject = Nothing
            
        End If
                        
                
        'Use the previously stored connection string to open a new connection
        Set DataAccessObject.ConnectionObject = New ADODB.Connection
        
        DataAccessObject.ConnectionObject.Open DataMiningServer.ConnectionStringUsed
        
        cmdNext.Enabled = True
    
    End If
    
End Sub
