VERSION 5.00
Begin VB.Form Form5 
   Caption         =   "Form2"
   ClientHeight    =   8190
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   11880
   LinkTopic       =   "Form2"
   ScaleHeight     =   8190
   ScaleWidth      =   11880
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      Caption         =   "Frame1"
      Height          =   4095
      Left            =   2520
      TabIndex        =   8
      Top             =   3600
      Width           =   5055
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   1
         Left            =   960
         TabIndex        =   28
         Text            =   "Text1"
         Top             =   840
         Width           =   855
      End
      Begin VB.OptionButton Option2 
         Caption         =   "CLEAR"
         Height          =   375
         Left            =   2400
         TabIndex        =   27
         Top             =   1680
         Width           =   1575
      End
      Begin VB.OptionButton Option1 
         Caption         =   "DISPLAY RESULT"
         Height          =   375
         Left            =   2400
         TabIndex        =   26
         Top             =   1200
         Width           =   2055
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   8
         Left            =   3360
         TabIndex        =   24
         Text            =   "Text1"
         Top             =   480
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   7
         Left            =   960
         TabIndex        =   23
         Text            =   "Text1"
         Top             =   3000
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   6
         Left            =   960
         TabIndex        =   22
         Text            =   "Text1"
         Top             =   2640
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   5
         Left            =   960
         TabIndex        =   21
         Text            =   "Text1"
         Top             =   2280
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   4
         Left            =   960
         TabIndex        =   20
         Text            =   "Text1"
         Top             =   1920
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   3
         Left            =   960
         TabIndex        =   19
         Text            =   "Text1"
         Top             =   1560
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   2
         Left            =   960
         TabIndex        =   18
         Text            =   "Text1"
         Top             =   1200
         Width           =   855
      End
      Begin VB.TextBox Text1 
         Height          =   315
         Index           =   0
         Left            =   960
         TabIndex        =   17
         Text            =   "Text1"
         Top             =   480
         Width           =   855
      End
      Begin VB.Label Label9 
         Caption         =   "FORECAST MPG"
         Height          =   375
         Left            =   2040
         TabIndex        =   25
         Top             =   480
         Width           =   1455
      End
      Begin VB.Label Label8 
         Caption         =   "FILTER"
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   3000
         Width           =   735
      End
      Begin VB.Label Label7 
         Caption         =   "CYLINDER"
         Height          =   375
         Left            =   120
         TabIndex        =   15
         Top             =   2640
         Width           =   855
      End
      Begin VB.Label Label6 
         Caption         =   "ORIGIN"
         Height          =   375
         Left            =   120
         TabIndex        =   14
         Top             =   2280
         Width           =   735
      End
      Begin VB.Label Label5 
         Caption         =   "YEAR"
         Height          =   375
         Left            =   120
         TabIndex        =   13
         Top             =   1920
         Width           =   735
      End
      Begin VB.Label Label4 
         Caption         =   "ACCEL"
         Height          =   375
         Left            =   120
         TabIndex        =   12
         Top             =   1560
         Width           =   735
      End
      Begin VB.Label Label3 
         Caption         =   "WEIGHT"
         Height          =   375
         Left            =   120
         TabIndex        =   11
         Top             =   1200
         Width           =   975
      End
      Begin VB.Label Label2 
         Caption         =   "HORSE"
         Height          =   255
         Left            =   120
         TabIndex        =   10
         Top             =   840
         Width           =   735
      End
      Begin VB.Label Label1 
         Caption         =   "ENGINE"
         Height          =   375
         Left            =   120
         TabIndex        =   9
         Top             =   480
         Width           =   975
      End
   End
   Begin VB.CommandButton Command5 
      Caption         =   "FORECAST"
      Height          =   615
      Left            =   0
      TabIndex        =   7
      ToolTipText     =   "������Ѻ��þ�ҡó��ҷ���ͧ���"
      Top             =   4440
      Width           =   1575
   End
   Begin VB.CommandButton Command4 
      Caption         =   "GO TO FORM1"
      Height          =   615
      Left            =   0
      TabIndex        =   6
      Top             =   5040
      Width           =   1575
   End
   Begin VB.ListBox List3 
      Height          =   255
      Left            =   9360
      TabIndex        =   5
      Top             =   1200
      Width           =   2295
   End
   Begin VB.CommandButton Command3 
      Caption         =   " REGRESSION"
      Height          =   615
      Left            =   0
      TabIndex        =   4
      Top             =   3840
      Width           =   1575
   End
   Begin VB.CommandButton Command2 
      Caption         =   "DEPENDENT VARIABLE ==>"
      Height          =   615
      Left            =   6720
      TabIndex        =   3
      Top             =   1200
      Width           =   2535
   End
   Begin VB.CommandButton Command1 
      Caption         =   "INDEPENDENT VARIABLE"
      Height          =   615
      Left            =   6720
      TabIndex        =   2
      Top             =   2400
      Width           =   2535
   End
   Begin VB.ListBox List2 
      Height          =   1035
      Left            =   9360
      TabIndex        =   1
      Top             =   2040
      Width           =   2295
   End
   Begin VB.ListBox List1 
      Height          =   1425
      Left            =   4080
      TabIndex        =   0
      Top             =   1200
      Width           =   2655
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public t  As Integer
Sub cl()
For i = 0 To 8
   Text1(i).Text = ""
Next i
End Sub


Private Sub Command1_Click()
Dim i, c  As Integer
  c = List1.ListCount
 i = List1.ListIndex
 If (c > 0 And i <> -1) Then
       List2.AddItem List1.List(i)
       List1.RemoveItem i
       If (c > 1) Then List1.Selected(i) = True
       t = 0
  End If
  
 If (List2.ListCount > 0 And t = 1) Then
       c = List2.ListCount
       i = List2.ListIndex
       List1.AddItem List2.List(i)
       List2.RemoveItem i
       t = 1
       If (c > 1) Then List2.Selected(i) = True
 End If
End Sub
Private Sub Command2_Click()
Dim i   As Integer
i = List1.ListIndex
 If (List3.ListCount = 0) Then
       List3.AddItem List1.List(i)
       List1.RemoveItem i
       List1.Selected(0) = True
       t = 0
  End If
  If (List1.ListCount > 0 And t = 1) Then
      i = List3.ListIndex
      List1.AddItem List3.Text
      List3.RemoveItem i
      t = 1
End If
End Sub

Private Sub Command3_Click()
Dim tname As String
Dim n, nsize As Integer
Dim i, j, k, st  As Integer
Dim temp As Single
Dim t(20) As Double
Dim std, yf, yc As Double
nsize = 8
' rem tname = inputBox("regemax")
tname = "regmax"
Set trec = tdat.OpenRecordset("select * From " & tname)
n = 0
trec.MoveFirst
st = 1
While (Not trec.EOF)
        For i = 0 To nsize
            t(i) = trec(des(i))
            'Print t(i)
       Next i
       n = n + 1
      For i = 0 To nsize
         If (i = 0) Then y(i + 1) = y(i + 1) + t(0)
         If (i > 0) Then y(i + 1) = y(i + 1) + t(i) * t(0)
      Next i
      For i = 1 To nsize + 1
        For j = i To nsize + 1
                  If (i = 1 And i < j) Then x(i, j) = x(i, j) + t(j - 1)
                  If (i > 1 And i < j) Then x(i, j) = x(i, j) + t(i - 1) * t(j - 1)
                  If (i = j And i > 1) Then
                           x(i, j) = x(i, j) + t(i - 1) * t(i - 1)
                  End If
          Next j
     Next i
       trec.MoveNext
Wend
    x(1, 1) = n
   For i = 2 To nsize + 1
       For j = 1 To i - 1
           x(i, j) = x(j, i)
       Next j
   Next i
   For i = 1 To nsize + 1
       For j = 1 To 2 * (nsize + 1)
              d(i, j) = 0
        Next j
    Next i
For i = 1 To nsize + 1
   For j = 1 To nsize + 1
      d(i, j) = x(i, j)
   Next j
Next i
j = nsize + 2
For i = 1 To nsize + 1
     d(i, j) = 1
     j = j + 1
Next i
'Cls
  For i = 1 To nsize + 1
     'Print y(i)
     For j = 1 To 2 * (nsize + 1)
        'Print Round(d(i, j), 2); "  ";
     Next j
    'Print
  Next i
For j = 1 To nsize + 1
    temp = d(j, j)
    For k = 1 To 2 * (nsize + 1)
         d(j, k) = d(j, k) / temp
     Next k
          For i = 1 To nsize + 1
              If (j <> i) Then
                  temp = d(i, j)
                   For k = 1 To 2 * (nsize + 1)
                       d(i, k) = d(i, k) - (d(j, k) * temp)
                    Next k
              End If
           Next i
Next j
For i = 1 To nsize + 1
   For j = 1 To nsize + 1
       xi(i, j) = d(i, j + nsize + 1)
    Next j
Next i
   For i = 1 To nsize + 1
      For j = 1 To nsize + 1
         For k = 1 To nsize + 1
            y1(i, j) = y1(i, j) + x(i, k) * xi(k, j)
          Next k
      Next j
    Next i
Print String(50, "=")
Print "    COEFFICIENT  OF  REGRESSION MODEL"
Print String(50, "=")
 For i = 1 To nsize + 1
      For j = 1 To nsize + 1
            ta(i) = ta(i) + xi(i, j) * y(j)
      Next j
    Print "      a (  "; i; ")     =      "; Round(ta(i), 3)
    Next i
For i = 1 To nsize + 1
     For j = 1 To nsize + 1
          'Print , Round(y1(i, j), 1); "  ";
     Next j
Next i
trec.MoveFirst
n = 0
std = 0
While (Not trec.EOF)
         For i = 0 To nsize
            t(i) = trec(des(i))
             If (i = 0) Then yf = a(1)
             If (i > 0) Then yf = yf + ta(i + 1) * t(i)
       Next i
       ya = t(0)
        n = n + 1
        std = std + (ya - yf) ^ 2
       trec.MoveNext
Wend
    std = std / n
    Print String(50, "=")
    Print " STANDARD ERROR =  ", Round(std, 2)
     Print String(50, "=")
End Sub

Private Sub Command4_Click()
''Form3.Show
''Form5.Hide
End
End Sub

Private Sub Command5_Click()
Frame1.Visible = True
Text1(0).SetFocus
Text1(0).Text = 225
Text1(1).Text = 95
Text1(2).Text = 3264
Text1(3).Text = 16
Text1(4).Text = 75
Text1(5).Text = 1
Text1(6).Text = 6
Text1(7).Text = 1
End Sub

Private Sub Form_Activate()
Dim tname As String
Dim i As Integer
tname = "TV"
Form5.WindowState = 2
'Set rec1 = dat.OpenRecordset("  select  *  from  " & "'" & tname & "'")
Set trec1 = tdat.OpenRecordset("  select  *  from   TV ")
trec1.MoveFirst
i = 0
While Not trec1.EOF
     des(i) = trec1("VAR")
     List1.AddItem des(i)
     trec1.MoveNext
        i = i + 1
Wend
List1.Selected(0) = True
cl
Frame1.Visible = False

End Sub

Private Sub List1_Click()
 Dim i As Integer
     i = List1.ListIndex
     Command2.Caption = "INDEPENDENT VAR"
End Sub

Private Sub List2_Click()
Dim i As Integer
      List2.Selected(0) = True
      i = List2.ListIndex
      t = 1
      List2.Selected(i) = True
      Command1.Caption = "<=="
End Sub

Private Sub List3_Click()
Command2.Caption = "< == "
t = 1
End Sub



Private Sub Option1_Click()
Dim f(9) As Single
Dim i As Integer
Dim pre As Single
pre = ta(1)
For i = 0 To 7
f(i + 1) = Val(Text1(i).Text)
Next i
For i = 1 To 7
   pre = pre + ta(i + 1) * f(i)
Next i
Text1(8).Text = Str(Round(pre, 0))

End Sub

Private Sub Option2_Click()
cl
Text1(0).SetFocus
End Sub

Private Sub Text1_KeyPress(Index As Integer, KeyAscii As Integer)
Dim i, j As Integer
  i = Index
  j = KeyAscii
  If (j = 13 And i < 9) Then Text1(i + 1).SetFocus
End Sub
