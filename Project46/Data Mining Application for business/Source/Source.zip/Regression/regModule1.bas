Attribute VB_Name = "Module2"
Option Explicit
Public x(50, 50) As Double
Public xi(50, 50) As Double
Public y(1000) As Double
Public y1(50, 50) As Double
Public ta(50)   As Single
Public tdat As Database
Public trec1    As Recordset
Public trec    As Recordset
Public des(50) As String
Public d(50, 100) As Double

Public a(100)  As Integer


