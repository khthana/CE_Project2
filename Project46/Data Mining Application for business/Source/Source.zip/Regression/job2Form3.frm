VERSION 5.00
Begin VB.Form Form3 
   Caption         =   "PROJECT DATA MINING"
   ClientHeight    =   4905
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   8325
   LinkTopic       =   "Form3"
   Picture         =   "job2Form3.frx":0000
   ScaleHeight     =   4905
   ScaleWidth      =   8325
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "EXIT"
      Height          =   495
      Index           =   3
      Left            =   5040
      TabIndex        =   3
      Top             =   2880
      Width           =   2295
   End
   Begin VB.CommandButton Command1 
      Caption         =   "DECISION TREE"
      Height          =   495
      Index           =   2
      Left            =   5040
      TabIndex        =   2
      Top             =   2280
      Width           =   2295
   End
   Begin VB.CommandButton Command1 
      Caption         =   "REGRESSION"
      Height          =   495
      Index           =   1
      Left            =   5040
      TabIndex        =   1
      Top             =   1680
      Width           =   2295
   End
   Begin VB.CommandButton Command1 
      Caption         =   "APRIOI"
      Height          =   495
      Index           =   0
      Left            =   5040
      TabIndex        =   0
      Top             =   1080
      Width           =   2295
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click(Index As Integer)
Dim i As Integer
 i = Index
 Select Case i
 Case 0: Form2.Show
 Case 1: Form4.Show
 Case 2: Form6.Show
 Case 3: End
 End Select
 Form3.Hide

End Sub
