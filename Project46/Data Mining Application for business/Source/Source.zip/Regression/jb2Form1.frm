VERSION 5.00
Begin VB.Form Form4 
   Caption         =   "Form1"
   ClientHeight    =   8310
   ClientLeft      =   165
   ClientTop       =   855
   ClientWidth     =   7845
   LinkTopic       =   "Form1"
   ScaleHeight     =   8310
   ScaleWidth      =   7845
   StartUpPosition =   3  'Windows Default
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access"
      DatabaseName    =   ""
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   495
      Left            =   720
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   ""
      Top             =   5160
      Width           =   2175
   End
   Begin VB.Frame Frame1 
      Caption         =   "Frame1"
      Height          =   3975
      Left            =   960
      TabIndex        =   0
      Top             =   480
      Width           =   6135
      Begin VB.TextBox Text2 
         Height          =   495
         Left            =   3480
         TabIndex        =   5
         Text            =   "Text2"
         Top             =   600
         Width           =   2175
      End
      Begin VB.TextBox Text1 
         Height          =   405
         Left            =   0
         TabIndex        =   4
         Top             =   2880
         Width           =   2175
      End
      Begin VB.FileListBox File1 
         Height          =   870
         Left            =   0
         TabIndex        =   3
         Top             =   1800
         Width           =   2175
      End
      Begin VB.DirListBox Dir1 
         Height          =   1440
         Left            =   0
         TabIndex        =   2
         Top             =   720
         Width           =   2175
      End
      Begin VB.DriveListBox Drive1 
         Height          =   315
         Left            =   0
         TabIndex        =   1
         Top             =   360
         Width           =   2175
      End
   End
   Begin VB.Menu mnufile 
      Caption         =   "File"
      Begin VB.Menu mnuOpen 
         Caption         =   "&Open"
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuPrint 
         Caption         =   "&Print"
      End
      Begin VB.Menu mnuClose 
         Caption         =   "&Close"
         Shortcut        =   ^C
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
         Shortcut        =   ^X
      End
   End
   Begin VB.Menu mnuform 
      Caption         =   "FORM2"
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
End Sub

Private Sub Dir1_Change()
File1.FileName = Dir1.Path
File1.Pattern = "*." & Text1.Text
End Sub

Private Sub Drive1_Change()
Dir1.Path = Drive1.Drive
End Sub

Private Sub File1_Click()

Text2.Text = Dir1.Path & "\" & File1.FileName

End Sub

Private Sub Form_Load()
mnuPrint.Visible = False
Text1.Text = "mdb"
Data1.Visible = False
End Sub

Private Sub mnuExit_Click()
End
End Sub

Private Sub mnuform_Click()
Form4.Hide
Form5.Show
End Sub

Private Sub mnuOpen_Click()
Dim fname As String
fname = Text2.Text
Set tdat = OpenDatabase(fname)
fname = InputBox("Input Table name regmax")
Set trec = tdat.OpenRecordset("select  *  from " & fname & "'")
Frame1.Visible = False
       
End Sub

