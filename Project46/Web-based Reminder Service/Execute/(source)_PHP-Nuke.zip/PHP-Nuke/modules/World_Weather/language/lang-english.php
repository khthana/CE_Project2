<?

/****************************************************************************************/
/* World_Weather version 3.1 for PHP-Nuke 5.5 - 5.6 					*/
/* ================================================					*/
/* Created By Harry Mangindaan and Sudirman Angriawan - NukeStars.com team -		*/
/*											*/
/* http://www.nukeStars.com   ( email : sens@indosat.net.id )				*/
/*											*/
/****************************************************************************************/

define("_PILIHLOKASI","Select Location");
define("_MASUKKANKOTADANKODE","Fill in city name and  city code");
define("_NAMAKOTA","City");
define("_KODEKOTA","City Code");
define("_TAMBAHKOTA","Add");
define("_KOTAYANGAKTIF","List of the active city ");
define("_KOTA","City");
define("_CHOOSECITY","Choose any city");



define("_1GIF","Rain/Wind");
define("_3GIF","Rain/T-Storms");
define("_4GIF","T-Storms");
define("_5GIF","Cloudy");
define("_6GIF","");
define("_7GIF","Snow/Icy");
define("_8GIF","");
define("_9GIF","");
define("_10GIF","");
define("_11GIF","Light Rain");
define("_12GIF","Rain");
define("_13GIF","Scattered Flurreis");
define("_14GIF","Light Snow");
define("_15GIF","");
define("_16GIF","");
define("_17GIF","");
define("_18GIF","");
define("_19GIF","Dusty");
define("_20GIF","Foggy");
define("_21GIF","Haze");
define("_22GIF","Smoke");
define("_23GIF","Wind");
define("_24GIF","Cloudy/Wind");
define("_25GIF","Extremely Cold");
define("_26GIF","Cloudy");
define("_27GIF","Mostly Cloudy");
define("_28GIF","Mostly Cloudy");
define("_29GIF","Partly Cloudy");
define("_30GIF","Partly Cloudy");
define("_31GIF","Partly Cloudy");
define("_32GIF","Sunny");
define("_33GIF","");
define("_34GIF","Mostly Sunny");
define("_35GIF","");
define("_36GIF","Extremely Hot");
define("_37GIF","Isolated T-Storms");
define("_38GIF","Sct T-Storms");
define("_39GIF","Showers");
define("_40GIF","Showers");
define("_41GIF","Snow");
define("_42GIF","Light Wind");
define("_43GIF","Snow/Wind");
define("_44GIF","Partly Coudy");
define("_GIF","Check again later !");



/****************************************************************************************/
/* PHP-NUKE Add-On 5.0 : Weather Addon
/* Brought to you by PHPNuke Add-On Team
/* Copyright (c) 2001 by Richard Tirtadji AKA King Richard (rtirtadji@hotmail.com)
/* http://www.nukeaddon.com
/* Bahasa Indonesia Language by Richard Tirtadji
/*
/****************************************************************************************/


define("_WWEATHER", "World Weather");
define("_ALLTEMP", "Show Temperature in");
define("_FAHREN", "Fahrenheit");
define("_OR", "or");
define("_CELCIUS", "Celcius");
define("_REG", "Region");
define("_CURCOND", "Current Condition");
define("_TEMP", "Temp");
define("_WIND", "Wind");
define("_BARO", "Barometer");
define("_HUMID", "Humidity");
define("_UV", "UV index");
define("_REFE", "Real Feel");
define("_VIS", "Visibility");
define("_FOREC", "5 days forecast");
define("_WHIGH", "Highest ");
define("_WLOW", "Lowest ");
define("_WSUN", " Sunday");
define("_WMON", " Monday");
define("_WTUE", " Tuesday");
define("_WWED", " Wednesday");
define("_WTHU", " Thursday");
define("_WFRI", " Friday");
define("_WSAT", " Saturday");
define("_WTEMP", "Temperature");
define("_WMORE", "5 days Forecast");



?>