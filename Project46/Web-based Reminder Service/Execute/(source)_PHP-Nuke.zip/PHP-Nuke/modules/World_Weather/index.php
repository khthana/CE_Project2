<?php

###################################################################################
#
# World_Weather version 3.1 for PHP-Nuke 5.5 - 5.6 
#
# Created By Harry Mangindaan and Sudirman Angriawan - NukeStars.com team -
#
# http://www.nukeStars.com   ( email : sens@indosat.net.id )
#
# Based on :
# PHP-NUKE Add-On 5.0 : Weather AddOn
# Copyright (c) 2001 by Richard Tirtadji AKA King Richard (rtirtadji@hotmail.com)
# Modifications by Mattias Sandstrom (/msa) <mattis@ffoff.org>
# http://www.nukeaddon.com
# Original code based on METEO live v1.0
# By Martin Bolduc at martin.bolduc@littera.com
# License : Free, do what you want, but please, let my name in reference.
# 
#####################################################################################


if (!eregi("modules.php", $PHP_SELF)) {
    die ("You can't access this file directly...");
}


require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
include("modules/$module_name/d_config.php");


if (isset($newlang)) {
	include("modules/$module_name/language/lang-$newlang.php");
	$language = $newlang;
} elseif (isset($lang)) {
    include("modules/$module_name/language/lang-$lang.php");
    $language = $lang;
} else {
    include("modules/$module_name/language/lang-$language.php");
}



if ($tp == "") {
	$tp = $temp;}   

function WeatherIndex($tp,$kota) {
global $module_name, $accid,$prefix;
include("header.php");

if ($kota == "") {
	$sql = "select kota,kode from $prefix"."_weather where sbgdefault=1";
	$row = mysql_fetch_array(mysql_query($sql));
	$kota = $row[kode];
	$accid = $kota;
} else {
	$accid = $kota;
}


#echo $accid;

OpenTable();
$fa = fsockopen("www.msnbc.com", 80, &$num_error, &$str_error, 30);
if(!$fa)
   { print "Weather is is not available: $str_error ($num_error)\n"; }
else
{
  //fputs($fa,"GET /m/chnk/d/weather_d_src.asp?acid=$accid HTTP/1.0\n\n");
	fputs($fa,"GET http://www.msnbc.com/m/chnk/d/weather_d_src.asp?acid=$accid HTTP/1.0\n\n");
  $answer=fgets($fa,128);

  $v_City    = "";
  $v_SubDiv  = "";
  $v_Country = "";
  $v_Region  = "";
  $v_Temp    = "";
  $v_CIcon   = "";
  $v_WindS   = "";
  $v_WindD   = "";
  $v_Baro    = "";
  $v_Humid   = "";
  $v_Real    = "";
  $v_UV      = "";
  $v_Vis     = "";
  $v_LastUp  = "";
  $v_Fore    = "";
  $v_Acid    = "";
  $v_ConText = "";

  
$v_Text[] = ""._GIF."";
$v_Text[1] = ""._1GIF."";
$v_Text[3] = ""._3GIF."";
$v_Text[4] = ""._4GIF."";
$v_Text[5] = ""._5GIF."";
$v_Text[6] = ""._6GIF."";
$v_Text[7] = ""._7GIF."";
$v_Text[8] = ""._8GIF."";
$v_Text[9] = ""._9GIF."";
$v_Text[10] = ""._10GIF."";
$v_Text[11] = ""._11GIF."";
$v_Text[12] = ""._12GIF."";
$v_Text[13] = ""._13GIF."";
$v_Text[14] = ""._14GIF."";
$v_Text[15] = ""._15GIF."";
$v_Text[16] = ""._16GIF."";
$v_Text[17] = ""._17GIF."";
$v_Text[18] = ""._18GIF."";
$v_Text[19] = ""._19GIF."";
$v_Text[20] = ""._20GIF."";
$v_Text[21] = ""._21GIF."";
$v_Text[22] = ""._22GIF."";
$v_Text[23] = ""._23GIF."";
$v_Text[24] = ""._24GIF."";
$v_Text[25] = ""._25GIF."";
$v_Text[26] = ""._26GIF."";
$v_Text[27] = ""._27GIF."";
$v_Text[28] = ""._28GIF."";
$v_Text[29] = ""._29GIF."";
$v_Text[30] = ""._30GIF."";
$v_Text[31] = ""._31GIF."";
$v_Text[32] = ""._32GIF."";
$v_Text[33] = ""._33GIF."";
$v_Text[34] = ""._34GIF."";
$v_Text[35] = ""._35GIF."";
$v_Text[36] = ""._36GIF."";
$v_Text[37] = ""._37GIF."";
$v_Text[38] = ""._38GIF."";
$v_Text[39] = ""._39GIF."";
$v_Text[40] = ""._40GIF."";
$v_Text[41] = ""._41GIF."";
$v_Text[42] = ""._42GIF."";
$v_Text[43] = ""._43GIF."";
$v_Text[44] = ""._44GIF."";

  


  while (!feof($fa))
     {
     $grabline = fgets($fa, 4096);
     $grabline= trim($grabline) . "\n";
     if (substr($grabline,7,4) == "City")    { $v_City    = substr($grabline,15,20); }
     if (substr($grabline,7,6) == "SubDiv")  { $v_SubDiv  = substr($grabline,17,20); }
     if (substr($grabline,7,7) == "Country") { $v_Country = substr($grabline,18,20); }
     if (substr($grabline,7,6) == "Region")  { $v_Region  = substr($grabline,17,20); }
     if (substr($grabline,7,5) == "Temp ")    { $v_Temp    = substr($grabline,15,20); }
     if (substr($grabline,7,5) == "CIcon")   { $v_CIcon   = substr($grabline,16,20); }
     if (substr($grabline,7,5) == "WindS")   { $v_WindS   = substr($grabline,16,20); }
     if (substr($grabline,7,5) == "WindD")   { $v_WindD   = substr($grabline,16,20); }
     if (substr($grabline,7,4) == "Baro")    { $v_Baro    = substr($grabline,15,20); }
     if (substr($grabline,7,5) == "Humid")   { $v_Humid   = substr($grabline,16,20); }
     if (substr($grabline,7,4) == "Real")    { $v_Real    = substr($grabline,15,20); }
     if (substr($grabline,7,2) == "UV")      { $v_UV      = substr($grabline,13,20); }
     if (substr($grabline,7,3) == "Vis")     { $v_Vis     = substr($grabline,14,20); }
     if (substr($grabline,7,5) == "LastUp")  { $v_LastUp  = substr($grabline,16,20); }
     if (substr($grabline,7,7) == "ConText") { $v_ConText = substr($grabline,16,20); } 


     if (substr($grabline,7,4) == "Fore")    { $v_Fore    = substr($grabline,15,200); }
     if (substr($grabline,7,4) == "Acid")    { $v_Acid    = substr($grabline,15,20); }
//     print $grabline . "\n";
     }

  $v_City    = substr($v_City,0,strlen($v_City)-3);
  $v_SubDiv  = substr($v_SubDiv,0,strlen($v_SubDiv)-3);
  $v_Country = substr($v_Country,0,strlen($v_Country)-3);
  $v_Region  = substr($v_Region,0,strlen($v_Region)-3);
  $v_Temp    = substr($v_Temp,0,strlen($v_Temp)-3);
  $v_CIcon   = substr($v_CIcon,0,strlen($v_CIcon)-3);
  $v_WindS   = substr($v_WindS,0,strlen($v_WindS)-3);
  $v_WindD   = substr($v_WindD,0,strlen($v_WindD)-3);
  $v_Baro    = substr($v_Baro,0,strlen($v_Baro)-3);
  $v_Humid   = substr($v_Humid,0,strlen($v_Humid)-3);
  $v_Real    = substr($v_Real,0,strlen($v_Real)-3);
  $v_UV      = substr($v_UV,0,strlen($v_UV)-3);
  $v_Vis     = substr($v_Vis,0,strlen($v_Vis)-3);
  $v_LastUp  = substr($v_LastUp,0,strlen($v_LastUp)-3);
  $v_Fore    = substr($v_Fore,0,strlen($v_Fore)-3);
  $v_Acid    = substr($v_Acid,0,strlen($v_Acid)-3);


$v_Fore = explode("|", $v_Fore);

echo "<div align=\"right\"><small>"._ALLTEMP.": ";
echo "<a href=\"modules.php?name=".$module_name."&amp;file=index&amp;kota=$accid&amp;tp=F\"><b>"._FAHREN."</b></a><br>";
echo "<a href=\"modules.php?name=".$module_name."&amp;file=index&amp;kota=$accid&amp;tp=C\"><b>"._CELCIUS."</b></a>";
echo "</div>";

echo "<font class=\"wwtext0\"><b>"._REG.": $v_Region</b><br>";
echo "<b>$v_City, $v_Country</b></font><hr>";
echo "<table cellpadding=\"4\" cellspacing=\"0\" border=\"0\">";
echo "<tr><td valign=\"top\">";
echo "<img src=\"images/weather/current_cond.gif\" align=\"top\">";

if ($tp == "C") {

echo "<font class=\"wwtext2\"><b>".CelNumber($v_Temp)."</b></font>";

} else {

echo "<font class=\"wwtext2\"><b>$v_Temp&deg;F</b></font>";

}

echo " <img src=\"images/weather/".$v_CIcon . ".gif\" align=\"center\"><br>";
echo "<font class=\"wwtext5\"<br>".$v_Text[$v_CIcon]."<br><br><br></td><td>";



$v_Baro_nice = PreNumber($v_Baro, $tp);
$v_WindS_nice = VelNumber($v_WindS, $tp);
$v_Real_nice = CelNumber2($v_Real, $tp);
$v_Vis_nice = LenNumber($v_Vis, $tp);

echo "<font class=\"wwtext1\">"._WIND.":</font> $v_WindD $v_WindS_nice <font class=\"wwtext1\">"._VIS.":</font> $v_Vis_nice <font class=\"wwtext1\"> "._HUMID.": </font> $v_Humid%<hr>";
echo "<font class=\"wwtext1\">"._UV.":</font> $v_UV  <font class=\"wwtext1\">"._REFE.": </font>$v_Real_nice <font class=\"wwtext1\"> "._BARO.": </font>$v_Baro_nice";
echo "</td></tr></table>";
echo "<table cellpadding=\"4\" cellspacing=\"0\" border=\"0\">";
echo "<tr><td valign=\"top\" align=\"center\">";
echo "<img src=\"images/weather/forecast.gif\">";
echo "</td><td>&nbsp;</td><td>";


echo Fore($v_Fore[0]);
echo "<font class=\"wwtext1\"><br><img src=\"images/weather/".$v_Fore[10].".gif\"><br>".$v_Text[$v_Fore[10]]."</td><td>";
echo Fore($v_Fore[1]);
echo "<font class=\"wwtext1\"><br><img src=\"images/weather/".$v_Fore[11].".gif\"><br>".$v_Text[$v_Fore[11]]."</td><td>";
echo Fore($v_Fore[2]);
echo "<font class=\"wwtext1\"><br><img src=\"images/weather/".$v_Fore[12].".gif\"><br>".$v_Text[$v_Fore[12]]."</td><td>";
echo Fore($v_Fore[3]);
echo "<font class=\"wwtext1\"><br><img src=\"images/weather/".$v_Fore[13].".gif\"><br>".$v_Text[$v_Fore[13]]."</td><td>";
echo Fore($v_Fore[4]);
echo "<font class=\"wwtext1\"><br><img src=\"images/weather/".$v_Fore[14].".gif\"><br>".$v_Text[$v_Fore[14]]."";


echo "</font></td></tr><tr><td>&nbsp;</td><td colspan=\"6\"><hr></td></tr>";
echo "<tr><td>&nbsp;</td><td><font class=\"wwtext5\">"._WHIGH.": </font></td><td>";

if ($tp == "C") {

echo "<font class=\"wwtext5\">".CelNumber($v_Fore[20])."</td><td>";
echo "<font class=\"wwtext5\">".CelNumber($v_Fore[21])."</td><td>";
echo "<font class=\"wwtext5\">".CelNumber($v_Fore[22])."</td><td>";
echo "<font class=\"wwtext5\">".CelNumber($v_Fore[23])."</td><td>";
echo "<font class=\"wwtext5\">".CelNumber($v_Fore[24])."</td><td>";
echo "</font></td></tr>";

echo "<tr><td>&nbsp;</td><td colspan=\"6\"><hr></td></tr>";
echo "<tr><td>&nbsp;</td><td><font class=\"wwtext6\">"._WLOW.":</td><td>";


echo "<font class=\"wwtext6\">".CelNumber($v_Fore[40])."</td><td>";
echo "<font class=\"wwtext6\">".CelNumber($v_Fore[41])."</td><td>";
echo "<font class=\"wwtext6\">".CelNumber($v_Fore[42])."</td><td>";
echo "<font class=\"wwtext6\">".CelNumber($v_Fore[43])."</td><td>";
echo "<font class=\"wwtext6\">".CelNumber($v_Fore[44])."</td><td>";
echo "</font></td></tr>";

} else {

echo "<font class=\"wwtext5\">$v_Fore[20]&deg</td><td>";
echo "<font class=\"wwtext5\">$v_Fore[21]&deg</td><td>";
echo "<font class=\"wwtext5\">$v_Fore[22]&deg</td><td>";
echo "<font class=\"wwtext5\">$v_Fore[23]&deg</td><td>";
echo "<font class=\"wwtext5\">$v_Fore[24]&deg</td><td>";
echo "</font></td></tr>";

echo "<tr><td>&nbsp;</td><td colspan=\"6\"><hr></td></tr>";
echo "<tr><td>&nbsp;</td><td><font class=\"wwtext6\">"._WLOW.":</td><td>";

echo "<font class=\"wwtext6\">$v_Fore[40]&deg</td><td>";
echo "<font class=\"wwtext6\">$v_Fore[41]&deg</td><td>";
echo "<font class=\"wwtext6\">$v_Fore[42]&deg</td><td>";
echo "<font class=\"wwtext6\">$v_Fore[43]&deg</td><td>";
echo "<font class=\"wwtext6\">$v_Fore[44]&deg</td><td>";
echo "</font>";

}


echo "</td></tr></table><hr>";


fclose($fa);
}
echo "<div align=\"right\"><small>Weather Data is provided by MSNBC Weather<br>World Weather Created by : <A href=\"http://www.nukestars.com\">NukeStars.com</a><br></small>";
echo "</div>";


$sql = "select kode,kota from nuke_weather order by kota";
$result = mysql_query($sql);
echo "<form action=\"modules.php?name=$module_name&file=index\" method=\"post\">";

echo _PILIHLOKASI." : <select name=\"kota\" onChange=\"submit()\">";
echo "<option selected>"._CHOOSECITY."</option>";
while ($row = mysql_fetch_array($result)) {
	echo "<option value=\"$row[kode]\">$row[kota]</option>";
}
echo "</select></form>";

CloseTable();
include ("footer.php");
}


function CelNumber($number) {
	$number = $number-32;
	$number = $number * 5;
	$number = $number / 9;
	$number = round ($number);
	return $number."&deg;C";
}
    
function CelNumber2($number,$tp) {
        if ($tp == "C") {                $number = $number-32;
	        $number = $number * 5;
	        $number = $number / 9;
	        $number = round ($number);
	        return "$number&deg;C";
        }       else {                return "$number&deg;F";       } }



function PreNumber($number,$tp) {
	if ($tp == "C") {
		$number = $number *33.86;
		$number = round ($number);
		return "$number mbar";
	}
	else {
		return "$number inHg";
	}
}

function LenNumber($number,$tp) {
	if ($tp == "C") {
		$number = $number * 1.852;
		$number = round ($number);
        if ($number == 0)
        {
                return "N/A";
        }
        else {
		return "$number km";
	}
        }else {
	 if ($number == 0)
           {
	return "N/A";
           }


	else {
		return "$number mi";
	}
}
   } 

function VelNumber($number,$tp) {
	if ($tp == "C") {
		$number = $number * 0.44704;
		$number = round ($number);
		return "$number m/s";
	}
	else {
		return "$number mph";
	}
}

function Fore($numbers) {
	if ($numbers == "1") {
		$date=""._WSUN."";
		echo "$date";
	}
	elseif ($numbers == "2") {
		$date=""._WMON."";
		echo "$date";
	}
	elseif ($numbers == "3") {
		$date=""._WTUE."";
		echo "$date";
	}
	elseif ($numbers == "4") {
		$date=""._WWED."";
		echo "$date";
	}
	elseif ($numbers == "5") {
		$date=""._WTHU."";
		echo "$date";
	}
	elseif ($numbers == "6") {
		$date=""._WFRI."";
		echo "$date";
	} else {
		$date=""._WSAT."";
		echo "$date";
	}
}				

# End AddOn Modules

switch($func) {

    default:
    WeatherIndex($tp,$kota);
    break;
}

?>

