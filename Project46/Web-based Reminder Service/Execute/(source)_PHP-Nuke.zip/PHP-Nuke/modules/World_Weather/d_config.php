<?php

/****************************************************************************************/
/* World_Weather version 3.1 for PHP-Nuke 5.5 - 5.6 					*/
/* ================================================					*/
/* Created By Harry Mangindaan and Sudirman Angriawan - NukeStars.com team -		*/
/*											*/
/* http://www.nukeStars.com   ( email : sens@indosat.net.id )				*/
/*											*/
/****************************************************************************************/



/****************************************************************************************/
/* World Weather Preferences 								*/
/*											*/
/* $temp:      	    	Default value; C for Celcius and F for Farrenthiet		*/
/* $cache:      	Cache time for block between 1 - 3600 ( in second ) 		*/
/* $index:     	    	0 ; your page-look without right bloks, 1 with right blocks	*/
/* $pagetitle:     	page title							*/
/*											*/
/****************************************************************************************/


$temp = C;
$cache = 900;
$index = 0;
$pagetitle = "- "._WWEATHER."";

?>