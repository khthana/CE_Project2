<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_SEND","Send");
define("_URL","URL");
define("_PRINTER","Utskriftsvennlig side");
define("_FRIEND","Send denne artikkelen til en venn");
define("_YOURNAME","Ditt navn");
define("_OK","Ok!");
define("_RELATED","Relaterte linker");
define("_MOREABOUT","Mer om");
define("_NEWSBY","Artikler av");
define("_MOSTREAD","Mest leste artikkel om");
define("_READMORE","Les mer...");
define("_BYTESMORE","bytes mer");
define("_COMMENTSQ","kommentarer?");
define("_COMMENT","kommentar");
define("_CONFIGURE","Konfigurer");
define("_LOGINCREATE","Logg inn/opprett konto");
define("_THRESHOLD","Terskel");
define("_NOCOMMENTS","Ingen kommentarer");
define("_NESTED","Nestet");
define("_FLAT","Flat");
define("_THREAD","Tr�det");
define("_OLDEST","Eldst f�rst");
define("_NEWEST","Nyest f�rst");
define("_HIGHEST","H�yst poeng f�rst");
define("_COMMENTSWARNING","Kommentarer eies av respektive poster. Vi tar <b>ikke</b> ansvar for innholdet av disse!");
define("_SCORE","Poeng:");
define("_USERINFO","Brukerinformasjon");
define("_READREST","Les resten av denne kommentaren...");
define("_REPLY","Svar p� dette");
define("_REPLYMAIN","Post kommentar");
define("_NOSUBJECT","Ingen emner");
define("_NOANONCOMMENTS","Ingen kommentarer er tillatt for anonyme bes�kendel. Vennligst <a href=\"modules.php?name=Your_Account&amp;op=new_user\">registrer deg</a>");
define("_PARENT","Foreldre");
define("_ROOT","Rot");
define("_UCOMMENT","Kommentar");
define("_ALLOWEDHTML","Tillat HTML:");
define("_POSTANON","Post anonymt");
define("_EXTRANS","Extrans (htmlkode til tekst)");
define("_HTMLFORMATED","HTML formatert");
define("_PLAINTEXT","Helt vanlig tekst");
define("_ONN","p�...");
define("_SUBJECT","Emne");
define("_COMMENTREPLY","Poste kommentar");
define("_COMREPLYPRE","Forh�ndsvis kommentar");
define("_NOTRIGHT","Noe gikk galt n�r vi sendte en variabel til denne funksjonen. Denne beskjeden er bare for ikke � rote det til lengre ned.");
define("_SENDAMSG","Send en beskjed");
define("_YOUSENDSTORY","Du kommer til � sende artikkelen");
define("_TOAFRIEND","til en venn:");
define("_FYOURNAME","Ditt navn:");
define("_FYOUREMAIL","Din e-postadresse:");
define("_FFRIENDNAME","Din venns navn:");
define("_FFRIENDEMAIL","Din venns e-postadresse:");
define("_INTERESTING","Interessant artikkel p�");
define("_HELLO","Hei");
define("_YOURFRIEND","Din venn");
define("_CONSIDERED","syntes at f�lgende artikkel var interessant, og ville sende den til deg!");
define("_FDATE","Dato:");
define("_FTOPIC","Emne:");
define("_YOUCANREAD","Du kan lese flere interessante artikler p�");
define("_FSTORY","Artikkelen");
define("_HASSENT","Har blitt sendt til");
define("_THANKS","Takk!");
define("_RECOMMEND","Anbefal denne websiden til en venn");
define("_PDATE","Dato:");
define("_PTOPIC","Emne:");
define("_COMESFROM","Denne artikkelen kommer fra");
define("_THEURL","Adressen til denne artikkelen er:");
define("_PREVIEW","Forh�ndsvisning");
define("_NEWUSER","Ny medlem");
define("_OPTIONS","Alternativ");
define("_REFRESH","Oppdatere");
define("_ADD","Legg til");
define("_NOCOMMENTSACT","Beklager, kommentarer kan ikke brukes i denne artiklen.");
define("_ARTICLEPOLL","Artikkelens avstemming");
define("_RATEARTICLE","Artikkelens poengsum");
define("_RATETHISARTICLE","Bruk gjerne litt tid p� � stemme p� denne artikkelen:");
define("_CASTMYVOTE","Stem!");
define("_AVERAGESCORE","Gjennomstnitt");
define("_BAD","D�rlig");
define("_REGULAR","Gjennomsnittlig");
define("_GOOD","God");
define("_VERYGOOD","Veldig god");
define("_EXCELLENT","Str�lende");
define("_ARTICLERATING","Artikkelavstemming");
define("_THANKSVOTEARTICLE","Takk for at du stemte p� denne artikkelen!");
define("_ALREADYVOTEDARTICLE","Beklager, du har allerede stemt p� denne artikkelen!");
define("_BACKTOARTICLEPAGE","Tilbake til artikler");
define("_DIDNTRATE","Du valgte ingen poengsum for artikkelen!");
define("_NOINFO4TOPIC","Beklager, det finnes ingen informasjon for det valgte emnet.");
define("_GOTONEWSINDEX","G� til nyhetsoversikt");
define("_SELECTNEWTOPIC","Velg et nytt emne");
define("_GOTOHOME","G� til hjemmesiden");
define("_SEARCHONTOPIC","S�k i dette emnet");
define("_SEARCHDIS","S�k i diskusjoner");

?>