<?php
define("_A001","Add new \"Extra\" item (Admin Only)");
define("_A002","insert new item, field \"Topic\" and \"Description\"");
define("_A003","Topic");
define("_A004","Description");
define("_A005","Save");
define("_A006","Reset");
?>
