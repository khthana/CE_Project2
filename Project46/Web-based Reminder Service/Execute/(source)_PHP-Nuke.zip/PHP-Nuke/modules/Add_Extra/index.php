<?php
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
$index = 1; // 0 = close right bar , 1 =  open right bar

require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

include("header.php");
OpenTable();
if ($submit==null){ //if not press "Submit" then create menu 
	echo "<center><b>"._A001."</b></center><br/><center>"._A002."</center><br/><br/>";
	echo "<form action=\"modules.php?name=Add_Extra\" method=\"post\">";
	echo "<table border=\"0\" width=\"80%\" align=\"center\"><tr><td>";
	echo "<b>"._A003.":</b><br/>";
	echo "<input type=\"text\" name=\"shot_text\" maxlength=\"20\" ><br/><br/>";
	echo "<b>"._A004.":</b><br/>";
	echo "<textarea name=\"long_text\" rows=\"9\" cols=\"50\" ></textarea><br/><br/>";
	echo "<INPUT type=\"submit\" value=\""._A005."\" name=\"submit\">&nbsp;&nbsp;<INPUT type=\"reset\" value=\""._A006."\" name=\"reset\">";
	echo  "</td></tr></table>";
	echo "</form>";
}else{//this section will activate when press "Submit"
	//----------------------------- if not have error, insert data to DB
	$my_host = "localhost";
	$my_user = "root";
	$my_link = mysql_connect($my_host, $my_user);	//-----Connect to MySQL
	if (!$my_link){															//show Error when fail to connect
		echo "<center><b>Internal Error [ Database connection error!! ]</b></center><br/><br/>";
		echo _err_connect;
		echo "<center>"._GOBACK."</center>";
	}else{
		$sql = "USE Reminder";
		$result = mysql_query($sql);									//----- Select Database
		if(!$result){															//show Error when fail to select
			echo _err_select;
			echo "<center>"._GOBACK."</center>";
		}else{
			$sql ="INSERT INTO reminder_extra (shot_text,long_text) VALUES ('$shot_text','$long_text');";
			$result = mysql_query($sql);								//insert data item
			if (!$result){
				echo _err_insert;
				echo "<center>"._GOBACK."</center>";
			}else{
				echo "�ѹ�֡��Ǣ���������º��������";
				echo "<center>[ <a href=modules.php?name=Add_Extra>��͹��Ѻ</a> ]</center>";
			}
		}
		mysql_close($my_link);
	}
//---------------------------------------
}
CloseTable();
include("footer.php");
?>
