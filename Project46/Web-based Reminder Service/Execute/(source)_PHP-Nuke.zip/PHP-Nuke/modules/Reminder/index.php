<?php
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
$index = 1; // 0 = close right bar , 1 =  open right bar

require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

include("header.php");

//-------------- get day/month/year from computer
$today = (isset($today))? $today : date("j", time());
$month = (isset($month)) ? $month : date("n",time());
$montharray = array(_month1,_month2,_month3,_month4,_month5,_month6,_month7,_month8,_month9,_month10,_month11,_month12);
$year = (isset($year)) ? $year : date("Y",time()); 

//-------------- get  username & email from cookie and DB
global $user, $cookie, $user_prefix, $db;
$autousername=$cookie[1];
$sql = "SELECT * FROM ".$user_prefix."_users WHERE username='$autousername'";
$result = $db->sql_query($sql);
$num = $db->sql_numrows($result);
$userinfo = $db->sql_fetchrow($result);
//  $autousername & $userinfo[user_email] use for reference when need to know username & email of current user
//-----------------

OpenTable();
//****************************************************************************************************
if ($submit==null){ //if not press "Submit" then create menu 
	$by_email="";$by_sms="";$by_icq="";$by_pager="";
	echo "<center><b>"._H001."</b></center><br/><center>"._H002."</center><br/><br/>";
	echo "<form action=\"modules.php?name=Reminder\" method=\"post\">";
	echo "<table border=\"0\" width=\"80%\" align=\"center\"><tr><td>";

	//============ show name =================
	echo "<b>"._H003.":</b>";
	echo " [ ".$autousername." ]<br/>";

	//============ hidden data, send with page==========
	echo "<input type=\"hidden\" name=\"username\" maxlength=\"60\" value=\"".$autousername."\" ><br/>";
	echo "<input type=\"hidden\" name=\"email\" maxlength=\"50\" size=\"40\" value=\"".$userinfo[user_email]."\" >";
	echo "<input type=\"hidden\" name=\"icq\" maxlength=\"50\" size=\"40\" value=\"".$userinfo[user_icq]."\" >";
	echo "<input type=\"hidden\" name=\"phone\" maxlength=\"50\" size=\"40\" value=\"".$userinfo[user_aim]."\" >";
	echo "<input type=\"hidden\" name=\"pager\" maxlength=\"50\" size=\"40\" value=\"".$userinfo[user_yim]."\" >";

	//============= input nute =====================
	echo "<b>"._H005.":</b><br/>";
	echo "<textarea name=\"note\" rows=\"9\" cols=\"50\"  ></textarea><br/><br/>";

	//============ show date detail ================
	echo "("._H006." " .$today ."/".$month."/".$year.")<br/><br/>";

	//============ create combo list "day"===============
	echo "<b>"._H007.":</b> <select name=\"day\">";
	for ($i = 1;$i<32;$i=$i+1)
		{
		echo "<option value=\"".$i."\"";
		if ($i==$today)
			echo " selected=\"selected\" ";
		echo ">".$i."</option>";
	}
	echo "</select>";
	//============create combo list "month" ===========
	echo "&nbsp;&nbsp;<b>"._H008.":</b><select name=\"month\">";
	for ($i = 1;$i<13;$i=$i+1)
		{
		echo "<option value=\"".$i."\"";
		if ($i==$month)
			echo " selected=\"selected\" ";
		echo ">".$montharray[$i-1]."</option>";
		}
	echo "</select>";

	//==============create combo list "year" ==============
	echo "&nbsp;&nbsp;<b>"._H009.":</b><select name=\"year\">";
	for ($i=$year;$i<($year+10);$i++)
		{
		echo "<option value=\"".$i."\"";
		if($i==$year)
			echo "selected=\"selected\" ";
		echo ">".$i."</option>";
		}
	echo "</select>";
	echo "<br/><br/>";
	echo "<b>"._H010.":</b> <select name=\"time\"><option value=\"00:00\">00:00</option><option value=\"01:00\">01:00</option><option value=\"02:00\">02:00</option><option value=\"03:00\">03:00</option><option value=\"04:00\">04:00</option><option value=\"05:00\">05:00</option><option value=\"06:00\">06:00</option><option value=\"07:00\">07:00</option><option value=\"08:00\">08:00</option><option value=\"09:00\">09:00</option><option value=\"10:00\">10:00</option><option value=\"11:00\">11:00</option><option value=\"12:00\">12:00</option><option value=\"13:00\">13:00</option><option value=\"14:00\">14:00</option><option value=\"15:00\">15:00</option><option value=\"16:00\">16:00</option><option value=\"17:00\">17:00</option><option value=\"18:00\">18:00</option><option value=\"19:00\">19:00</option><option value=\"20:00\">20:00</option><option value=\"21:00\">21:00</option><option value=\"22:00\">22:00</option><option value=\"23:00\">23:00</option></select>";
	//===============create combo list "Extra"===============
	echo "&nbsp;&nbsp;<b>"._H011.": </b>";
	$my_host = "localhost";
	$my_user = "root";
	$my_link = mysql_connect($my_host, $my_user);	//----- �ӡ�����͵����ѧ MySQL
	if (!$my_link){															//�ʴ� Error �ҡ���������������
		echo "<center><b>Internal Error [ Database connection error!! ]</b></center><br/><br/>";
		echo _error_connect;
		echo "<center>"._GOBACK."</center>";
	}else{
		$sql2 = "USE Reminder";
		$result2 = mysql_query($sql2);									//----- �ӡ�����͡ DB ������
		if(!$result2){															//�ʴ� Error �ҡ ��辺 DB ����ͧ���
			echo _error_select;
			echo "<center>"._GOBACK."</center>";
		}else{
			$sql2 = "SELECT * FROM reminder_extra ORDER BY shot_text ;";
			$result2 = mysql_query($sql2);
			echo "<select name=\"extra\">";
			while ($dbarr = mysql_fetch_array($result2)){	//���ҧ option ��������ŷ��������㹰ҹ������
				echo "<option value=\"".$dbarr["id"]."\">".$dbarr["shot_text"]."</option>";
			}
			echo "</select>";
		}
	}
	mysql_close($my_link);
	echo "<br/><br/>";

	//========== create checkbox
	echo "<br/>";
	echo "<b>"._msg_ToYouBy.":</b>&nbsp;&nbsp;(<a href=\"pop_up.html\" target=\"_blank\">"._msg_detail."</a>)";
//	echo "<br/><br/>";
	echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
	echo "<tr><td><input type=\"checkbox\" name=\"by_email\" ";
						if($userinfo[user_email]==""){
							echo "disabled";
						}else{
							echo "checked=\"on\"";
						}						
	echo "		><b>"._H004."</b> [ ".$userinfo[user_email]." ]</td>";

	echo"        <td width=\"30px\">&nbsp;</td>";
	echo "       <td><input type=\"checkbox\" name=\"by_sms\" ";
						if($userinfo[user_aim]=="")echo "disabled";
	echo			"><b>"._msg_bySMS."</b> [ ".$userinfo[user_aim]." ]</td></tr>";

	echo "<tr><td><input type=\"checkbox\" name=\"by_icq\" ";
						if($userinfo[user_icq]=="")echo "disabled";
	echo			"><b>"._msg_byICQ."</b> [ ".$userinfo[user_icq]." ]</td>";
	echo			"<td width=\"30px\">&nbsp;</td>";
	echo			"<td><input type=\"checkbox\" name=\"by_pager\" ";
						if($userinfo[user_yim]=="")echo "disabled";
	echo			"><b>"._msg_byPager."</b> [ ".$userinfo[user_yim]." ]</td></tr>";
	echo "</table>";
	
	//=============button===========
	echo "<br/>";
	echo "<INPUT type=\"submit\" value=\""._H012."\" name=\"submit\">&nbsp;&nbsp;<INPUT type=\"reset\" value=\""._H013."\" name=\"reset\">";
	echo  "</td></tr></table>";
	echo "</form>";

//****************************************************************************************************
}else{
	
	if($by_email!="on"&&$by_sms!="on"&&$by_icq!="on"&&$by_pager!="on"){		// pair A
		echo "<center><b>Send Error : "._err_method."</b></center><br/><br/>";
		echo "<center>"._GOBACK."</center>";
	}else{ //pair A (half)  //this section will activate when press "Submit"
		if($by_email!="on")$email="";
		if($by_sms!="on")$phone="";
		if($by_pager!="on")$pager="";
		if($by_icq!="on")$icq="";

$this_month = date("n",time());
$this_year  = date("Y",time()); 

	//---- check date validity
	if (!checkdate($month, $day, $year)){
		echo "<center><b>Date Error : [".$day."/".$month."/".$year."] "._err_date."</b></center><br/><br/>";
		echo "<center>"._GOBACK."</center>";
	}else{
			if($year<$this_year){
				echo "<center><b>Date Error : "._err_yearback."</b></center><br/><br/>";
				echo "<center>"._GOBACK."</center>";		
			}else{
					if(($month<$this_month)and($year==$this_year)){
						echo "<center><b>Date Error : "._err_monthback."</b></center><br/><br/>";
						echo "<center>"._GOBACK."</center>";
					}else{
						if(($day<$today)and($month==$this_month)and($year==$this_year)){
							echo "<center><b>Date Error : "._err_dayback."</b></center><br/><br/>";
							echo "<center>"._GOBACK."</center>";
						}else{
							if(strlen($note)==0){ //������� note �������
								echo "<center><b>Note Error : "._err_blank."</b></center><br/><br/>";
								echo "<center>"._GOBACK."</center>";
							}else{
								if(($by_sms=="on")and!((strlen(trim($phone))==9)and(ereg('^06|^01|^09|^07',$phone)))){
									echo "<center><b>Phone Number Error : "._err_phone."</b></center><br/><br/>";
									echo "<center>"._GOBACK."</center>";
								}else{
									//*******************
									//----------------------------- if not have error, insert data to DB
									$my_host = "localhost";
									$my_user = "root";
									$my_link = mysql_connect($my_host, $my_user);	//-----Connect to MySQL
									if (!$my_link){															//show Error when fail to connect
										echo "<center><b>Internal Error [ Database connection error!! ]</b></center><br/><br/>";
										echo _err_connect;
										echo "<center>"._GOBACK."</center>";
									}else{
										$sql = "USE Reminder";
										$result = mysql_query($sql);									//----- Select Database
										if(!$result){															//show Error when fail to select
											echo _err_select;
											echo "<center>"._GOBACK."</center>";
										}else{
											//---------
											$sql ="INSERT INTO reminder_note (username,email,note,day,month,year,time,extra,phone,icq,pager) VALUES ('$username','$email','$note',$day,$month,$year,'$time',$extra,'$phone','$icq','$pager');";
											$result = mysql_query($sql);								//insert data item
											if (!$result){
												echo $sql;
												echo "<br/>";
												echo _err_insert;
												echo "<center>"._GOBACK."</center>";
											}else{
												echo _ok_now;
												$show_complete = "";
												if($email!="")$show_complete.=$email;
												if($phone!="")$show_complete.=", SMS ���� ".$phone;
												if($icq!="")$show_complete.=", ICQ ����".$icq;
												if($pager!="")$show_complete.=", Pager ����".$pager;
												echo "<center>"._complete1." [".$show_complete."]<br/> "._complete2." [".$time."] "._complete3." [".$day."/".$month."/".$year."]</center><br/><br/>\n<center>[ <a href=modules.php?name=Reminder>"._gogoback."</a> ]</center>";
											}
												//---------
										}
										mysql_close($my_link);
									}
										//*****************
								}
							}
						}
					}
			}

//---------------------------------------
	}

	/*echo $my_host."<br/>".$my_user."<br/>".$my_link."<br/>".$sql."<br/>".$result."<br/>";
	echo $username;
	echo $email;
	echo $note;
	echo $day;
	echo $month;
	echo $year;
	echo $time;
	echo $extra;*/
	}//pair A

}
CloseTable();
include("footer.php");

//=========== requirement
/*
form will send this data
username : character,<=60 
email : character, <= 50
note : text
day : integer (1-31) 
month : integer (1-12)
year : integer (20xx) plus current year+10
time : character 
	0:00
	3:00
	6:00
	9:00
	12:00
	15:00
	18:00
	21:00
extra : integer  1-x 
	1 = ��
	2 =

***** you must create table for support this data by use
1st column ==> id (auto number)
2nd column ==> username
3rd column ==> email
4th column ==> note
5th column ==> day
6th column ==> month
7th column ==> year
8th column ==> time
9th column ==> extra
10th column ==>phone no. (use in sms)
11th column ==> icq no.
12nd column ==> pager no.
	*/
?>
