<?
function checkx($tmp){
	echo "11";
	list($usr,$thathost) = split("@",$tmp);
	echo "22";
	$fp = fsockopen ($thathost, 25);
	echo "33";
	set_socket_blocking ($fp, true);
	echo ""44;
	fputs ($fp, "Helo Local\n");
	echo "55";
	fgets ($fp, 2000);
	echo "66";
	fgets ($fp, 2000);
	echo "77";
	fputs ($fp, "Mail From:<$usr@$thathost> \n");
	echo "88";
	fgets ($fp, 2000);
	echo "99";
	fputs ($fp, "RCPT to:aetos<$usr@$thathost> \n");
	echo "aa";
	$result= fgets ($fp, 2000);
	echo "bb";
	$st= substr($result,0,3);
	echo "cc";
	if ($st==250){
		echo "dd";
		echo"xxEmail address is valid";
	}else{
		echo "ee";
		echo"xxThe address is not valid";
	}
}
?>