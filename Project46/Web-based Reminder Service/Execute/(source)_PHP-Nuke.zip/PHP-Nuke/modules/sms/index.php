<?php

/************************************************************************/
/* SMS: PHP-Nuke module modified to work with an ICQ email2sms gateway. */
/* radically based on:
/* Send_Mail: PHP-NUKE module created by Jan Skurovec (svab@cooltura.cz)*/
/* Nuke_Mailer: module	by yahooooh@yahooooh.com                        */
/* ===========================                                          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (!eregi("modules.php", $PHP_SELF)) {
	die ("You can't access this file directly...");
}
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

$index = 1;
$registered_only = "1";

function adresar() {
    global $dbi, $module_name, $cookie;
        $result = sql_query("SELECT * FROM nuke_send_sms_phonebook WHERE smuid='$cookie[1]' ", $dbi);
while(list($adress_id, $suid, $smemail, $smname) = sql_fetch_row($result, $dbi)) {
$usersnames .= "<option value=\"$smemail\">$smname</option>"; }
return $usersnames;
}

function main() {
        global  $module_name;
        global $registered_only;
        include("header.php");
if($registered_only == "1"):
    global $uname, $user_prefix, $dbi, $cookie;
	if($cookie[1]==""):
		header("location: modules.php?name=$module_name&file=index&func=smula");
	endif;
    $result = sql_query("select email from ".$user_prefix."_users where uname='$cookie[1]'", $dbi);
    $userinfo = sql_fetch_array($result, $dbi);
	$odkoho = $userinfo[email];
endif;
    OpenTable();
                                                echo("	<center><br><h2>"._welcome."</h2><p><a href=\"modules.php?name=$module_name&file=index&func=terms\">"._smsterms."</a><br><br>");
                                                echo("	<form action=\"modules.php?name=$module_name&amp;file=send\" method=\"POST\" enctype=\"MULTIPART/FORM-DATA\">");
                                                echo("	<table border=0 width=\"75%\" cellpadding=\"1\" cellspacing=\"0\">");
                                                echo("	<tr><td align=\"right\"></td><td><input name=\"jak\" type=\"radio\" value=\"normal\" checked>"._adresatovi.""); if($registered_only == "1"): echo ("<input name=\"jak\" type=\"radio\" value=\"adresar\">"._zadresare."</td></tr>"); endif;
if($registered_only == "1"):       echo("	<tr><td align=\"right\">"._adressbook.":</td><td><select name=\"seznam\"><option value=\"none\" selected>"._selectadress."</option>".adresar()."</select></td></tr>"); endif;
                                                 echo("	<tr><td align=\"right\">"._komu.":</td><td><input name=\"komu\" size=\"15\"> "._komuexam1."</td></tr>");
	                                echo("	<tr><td align=\"right\">"._subjekt.":</td><td><input name=\"subjekt\" size=\"15\"></td></tr>");
	                                echo("	<tr><td align=\"right\" valign=\"top\">"._zprava.":</td>");
	                                echo("	<td><textarea cols=\"42\" name=\"zprava\" rows=\"6\" ></textarea></td></tr>");
if($registered_only == "1"):
	echo("<tr><td align=\"right\">"._vasmail.":</td><td>$odkoho <input type=\"hidden\" name=\"odkoho\" value=\"$odkoho\" size=\"45\">");
                echo("</td></tr>");
else:
	echo("	<tr><td align=\"right\">"._vasmail.":</td><td><input name=\"odkoho\" value=\"$odkoho\" size=\"45\"></td></tr>");
endif;
	echo("	</table>");
	echo("	<br><input type=\"submit\" value=\""._odeslat."\"><input type=\"reset\" value=\""._CLEAR."\">");
	echo("	</form>");
    CloseTable();
if($registered_only == "1"):
         echo("<br>");
         OpenTable();
         echo("<h3>"._pridatdoadresare."</h3>");
         echo("<form action=\"modules.php?name=$module_name&amp;file=index&amp;func=pridat\" method=\"POST\" enctype=\"MULTIPART/FORM-DATA\">");
         echo("<table border=0 width=\"75%\" cellpadding=\"1\" cellspacing=\"0\">");
         echo("<tr><td align=\"right\">"._emailovaadresa.":</td><td><input name=\"smemail\" size=\"15\"> "._komuexam1."</td></tr>");
         echo("<tr><td align=\"right\">"._jmeno.":</td>            <td><input name=\"smname\" size=\"15\"> "._komuexam2."</td></tr>");
         echo("</table>");
         echo("<br><input type=\"submit\" value=\""._odeslat."\"><input type=\"reset\" value=\""._CLEAR."\">");
         echo("<input type=\"hidden\" name=\"smuid\" value=\"$cookie[1]\" ></td></tr>");
         echo("</form>");
         CloseTable();
endif;

if($registered_only == "1"):
         echo("<br>");
         OpenTable();
         echo("<h3>"._editovat."</h3>");
         echo("<form action=\"modules.php?name=$module_name&amp;file=edit\" method=\"POST\" enctype=\"MULTIPART/FORM-DATA\">");
         echo("<table border=0  cellpadding=\"1\" cellspacing=\"0\">");
         echo("<tr><td>"._selectfriend."</td><td><select name=\"editovat\"><option value=\"none\" selected>"._selectadress."</option>".adresar()."</select></td></tr>");
         echo("</table>");
         echo("<br><input type=\"submit\" name=\"buttonek\" value=\""._DELETED."\"><input type=\"submit\" name=\"buttonek\" value=\"Edit\">");
         echo("<input type=\"hidden\" name=\"smuid\" value=\"$cookie[1]\" ></td></tr>");
         echo("</form>");
         CloseTable();
endif;

include("footer.php");

}

function error() {
            global  $module_name;
    include("header.php");
    OpenTable();
	echo ""._error."";
	echo "<br><br><a href=\"modules.php?name=$module_name\">"._znovu."</a>";
    CloseTable();
    include("footer.php");

}

function sent() {
            global  $module_name;
    include("header.php");
    OpenTable();
	echo ""._smssent."";
	echo "<br><br><a href=\"modules.php?name=$module_name\">"._dalsi."</a>";
    CloseTable();
	echo("<br>");
	include("sms_count.php");
	OpenTable();
	echo "<p align=\"center\">"._smsthnks."</p>";
	echo "<br>";
	echo "<p align=\"center\"><a href=\"http://web.icq.com/sms\" target=\"_blank\"><IMG SRC=\"http://web.icq.com/lib/image/0,,5005,00.gif\" alt=\""._smsgateway."\" border=\"1\" hspace=\"0\"></a>";
    echo "<br>";
	echo "<p align=\"center\"><a href=\"modules.php?name=$module_name&file=index&func=terms\">"._smsterms."</a>";
	echo "<br>";
	echo "<br><em>- $count -</em></p>";
	CloseTable();
    include("footer.php");

}

function adresa() {
            global  $module_name;
    include("header.php");
    OpenTable();
	echo ""._adresa."";
	echo "<br><br><a href=\"modules.php?name=$module_name\">"._znovu."</a>";
    CloseTable();
    include("footer.php");
}

function smula() {
    include("header.php");
    OpenTable();
	echo ""._smula."";
	echo "<br><br><a href=\"modules.php?name=Your_Account&op=new_user\">"._zaregistrovat."</a>";
	echo " <a href=\"modules.php?name=Your_Account\">"._zalogovat."</a>";
    CloseTable();
    include("footer.php");
}

function pridat($smuid, $smemail, $smname) {
    global $dbi, $module_name, $cookie;

        $result = sql_query("INSERT INTO nuke_send_sms_phonebook VALUES ('', '$smuid', '$smemail', '$smname')", $dbi);
    if(!$result):
    include("header.php");
    OpenTable();
    echo ""._erroradd."";
    echo "<br><a href=\"modules.php?name=$module_name\">"._ted."</a>";
    CloseTable();
    include("footer.php");
else:
        header("location: modules.php?name=$module_name&file=index&func=pridano");
endif;
}


function pridano() {
    global  $module_name;
    include("header.php");
    OpenTable();
	echo ""._addeddb."";
                 echo "<br><br><a href=\"modules.php?name=$module_name\">"._nextsms."</a>";
    CloseTable();
    include("footer.php");
}

function terms() {
            global  $module_name;
    include("header.php");
    OpenTable();
	echo "<center><h2>"._welcome."</h2>";
	echo "<br>"._smsterms."</center";
    CloseTable();
	echo("<br>");
	include("sms_count.php");
	OpenTable();
	echo "<p align=\"left\">"._smsterms1."</p>";
	echo "<br>";
    echo "<p align=\"left\">"._smsterms2."</p>";
	echo "<br>";
	echo "<p align=\"left\">"._smsterms3."</p>";
	echo "<br>";
	echo "<p align=\"left\">"._smsterms4."</p>";
	echo "<br>";
	echo "<p align=\"left\">"._smsterms5."</p>";
	echo "<br>";
	echo "<p align=\"left\">"._smsterms6."</p>";
	echo "<br>";
	echo "<p align=\"left\">"._smsterms7."</p>";
	echo "<br>";
	echo "<br><br><a href=\"modules.php?name=$module_name\">"._nextsms."</a>";
	CloseTable();
    include("footer.php");
}

function createdb() {
  global $dbi;
 $result = sql_query("CREATE TABLE nuke_send_sms_phonebook (adress_id int(10) NOT NULL auto_increment, smuid varchar(25) NOT NULL default '', smemail varchar(255) NOT NULL default '', smname varchar(255) NOT NULL default '', PRIMARY KEY  (adress_id)) TYPE=MyISAM", $dbi);
 if(!$result):
 echo "error while creating table";
 else:
 echo "table created, now please comment lines 208-216 in modules/SMS/index.php";
 endif;
}

function error_delete() {
global  $module_name;
    include("header.php");
    OpenTable();
        echo ""._error_delete."";
        echo "<br><a href=\"modules.php?name=$module_name\">"._ted."</a>";
    CloseTable();
    include("footer.php");
}

function error_update() {
global  $module_name;
    include("header.php");
    OpenTable();
                echo ""._error_update."";
                echo "<br><a href=\"modules.php?name=$module_name\">"._ted."</a>";
    CloseTable();
    include("footer.php");
}


switch($func)
{
    default:
    main();
    break;

    case "error":
    error();
    break;

    case "pridat":
         pridat($smuid, $smemail, $smname);
        break;

    case "sent":
    sent();
    break;

    case "pridano":
    pridano();
    break;

    case "install":
    createdb();
    break;

    case "adresa":
    adresa();
    break;

    case "smula":
    smula();
    break;

    case "error_update":
    update();
    break;

    case "error_delete":
    error_delete();
    break;

    case "terms":
    terms();
    break;


}


?>