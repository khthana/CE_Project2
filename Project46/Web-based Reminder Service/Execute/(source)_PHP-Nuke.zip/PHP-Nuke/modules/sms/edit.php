<?php
/************************************************************************/
/* Send_Mail: PHP-NUKE module created by Jan Skurovec (svab@cooltura.cz)*/
/* based on Nuke_Mailer module	by yahooooh@yahooooh.com                */
/* ===========================                                          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (!eregi("modules.php", $PHP_SELF)) {
	die ("You can't access this file directly...");
}
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);


if($buttonek == "Edit"):
        if($editovat == "none"):
         header("location: modules.php?name=$module_name");
         else:
        $result = sql_query("SELECT * FROM nuke_send_sms_phonebook WHERE smemail='$editovat' AND smuid='$smuid' ", $dbi);
        $udaje = sql_fetch_array($result, $dbi);

        include("header.php");
        echo("<br>");
         OpenTable();
         echo("<h3>"._editovat."</h3>");
         echo("<form action=\"modules.php?name=$module_name&amp;file=edit\" method=\"POST\" enctype=\"MULTIPART/FORM-DATA\">");
         echo("<table border=0  cellpadding=\"1\" cellspacing=\"0\">");
         echo("<tr><td>"._friendname.":</td><td><input name=\"smname\" size=\"45\" value=\"$udaje[smname]\"> "._komuexam2."</td></tr>");
         echo("<tr><td>"._friendmail.":</td><td><input name=\"smemail\" size=\"45\" value=\"$udaje[smemail]\"> "._komuexam1."</td></tr>");
          echo("</table>");
         echo("<br><input type=\"submit\" name=\"buttonek\" value=\"Ok\">");
         echo("<input type=\"hidden\" name=\"adress_id\" value=\"$udaje[adress_id]\" ></td></tr>");
         echo("</form>");
         CloseTable();
         include("footer.php");
                  endif;

elseif($buttonek == "Ok"):
        $result = sql_query("UPDATE nuke_send_sms_phonebook SET smname='$smname', smemail='$smemail' WHERE adress_id='$adress_id'", $dbi);
        if(!$result):
        header("location: modules.php?name=$module_name&file=index&func=error_update");
        exit;
        endif;
        header("location: modules.php?name=$module_name");
else:
        if($editovat != "none"):
        $result = sql_query("DELETE FROM nuke_send_sms_phonebook WHERE smemail='$editovat' AND smuid='$smuid' ", $dbi);
        if(!$result):
        header("location: modules.php?name=$module_name&file=index&func=error_delete");
        exit;
        endif;
        header("location: modules.php?name=$module_name");
        else:
        header("location: modules.php?name=$module_name");
        endif;
endif;

?>