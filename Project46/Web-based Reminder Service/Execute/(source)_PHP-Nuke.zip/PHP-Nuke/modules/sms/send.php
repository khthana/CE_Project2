<?php
/************************************************************************/
/* Send_Mail: PHP-NUKE module created by Jan Skurovec (svab@cooltura.cz)*/
/* based on Nuke_Mailer module	by yahooooh@yahooooh.com                */
/* ===========================                                          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (!eregi("modules.php", $PHP_SELF)) {
	die ("You can't access this file directly...");
}
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

$multisend = 0;

switch($jak)
{
case "normal":
if($multisend == 0):
	if(!ereg("^[0-9]",$komu))                                           // number validation
	{
	header("location: modules.php?name=$module_name&file=index&func=adresa");
	exit;
	}
endif;
break;

case "admin":
$komu = $adminmail;
break;                    

case "adresar":
$komu = $seznam;
break;
}

$komu =		strip_tags(trim($komu));
$subjekt =	strip_tags(trim($subjekt));
$zprava =	strip_tags(trim($zprava));
$odkoho =	strip_tags(trim($odkoho));
$headers = "From:$odkoho";
// --- Start editing here ---  //

$prefix = "359";                           // Your prefix. (359 mean Bulgaria)
                                          // Note that some mobile providers required "+" from the begining of number
$gateway = "@sms.mtel.net";              // Your mobile provider e-mail gateway E.g.: @sms.mtel.net this is 
                                        // for Bulgaria only and working pretty fine for me.

// --  READ CAREFULLY --      //
/*
-----------------------------------------
FREE EMAIL2SMS GATEWAYS:
-----------------------------------------
Malaysya - Celcom
019xxxxxxx@sms.celcom.com.my             // In this way $prefix = "019";
Germany
0177xxxxxxx@mobilis.de       // E-Plus   // In this way $prefix = "0177";
0177xxxxxxx.sms@eplus.de  // E-Plus
xxxxxxx@d2-message.de      // D2         // But HERE: There is no $prefix, SEE line 127
+49xxxxxxx@t-d1-sms.de   // D1
Poland
+4860xxxxxxx@text.plusgsm.pl  // Plus-GSM
501XXXXXX@sms.centertel.pl       // Idea Centertel
Norway
xxxxxxx@sms.netcom.no            // Netcom GSM
xxxxxxxx@mobilpost.com          // Telenor Mobil
Sweden
4670xxxxxxx@europolitan.se     // Europolitan
467xxxxxxxx@sms.comviq.se   //  Comviq GSM
Denmark
xxxxxxxx@smartsms.dk            // Sonofon
xxxxxxxx@note.sonofon.dk          // Sonofon
xxxxxxxx@sms.tdk.dk                   // Tele Danmark Mobil
UK
0973xxxxxx@omail.net                  // Orange
Austria
xxxxxxxxxx@max.mail.at              // Max.Mobil
xxxxxxxxxx@text.mobilkom.at     // Mobilkom
Tanzania
xxxxxx@sms.co.tz                         // Mobitel
Portugal
91xxxxxxx@sms.telecel.pt            // Telecel
93xxxxxxx@sms.optimus.pt         // Optimus
96xxxxxxx@mail.tmn.pt                // TMN
Lithuania
xxxxxxx@gsm.lt // Omnitel
Latvia
9xxxxxx@smsmail.lmt.lv   // LMT
Slovenia
xxxxxx@simobil.net   // SiMobil
xxxxxx@linux.mobitel.si    // Mobitel
Chez Republic
+ccaaxxxxxxx@sms.eurotel.cz       // Eurotel
+4206037xxxxx@sms.paegas.cz    // Radiomobil
Lebanon
9613xxxxxx@ens.jinny.com.lb       //  Cellis and LibanCell
USA & Canada
xxxxxxxxxx@message.bam.com    // Bell
xxxxxxxxxx@dogphone.com         // FIDO
xxxxxxxxxx@page.nextel.com   // Nextel
xxxxxxxxxx@messaging.sprintpcs.com  // Sprint PCS
Russia
7xxxxxxxxxx@sms.mts.ru     // MTS
Belgium
095xxxxxx@mobistar.be   // Mobistar
France
06xxxxxxx@sfrmail.axialys.fr    //Bouygues Telecom Itineris SFR
Spain
6xxxxxxxx@correo.movistar.net             // Movistar
6xxxxxxxx@activajoven.tsm.es // Movistar
Hungary
3620xxxxxxx@sms.pgsm.hu  // Pannon
Italy
33xxxxxxxx@posta.tim.it  // Telecom Italia Mobile
34xxxxxxxx@vizzavi.it      // Omnitel Pronto Italia
Bulgaria
359xxxxxxxx@sms.mtel.net        // M-tel
ICQ Global Network
+country_code_phone_number@icqsms.com         // Over the World
*/
$phone = "$prefix$komu$gateway";                // With $prefix (e.g.: 095xxxxxx@mobistar.be)
//$phone = "$komu$gateway";                       // Without $prefix (e.g.: xxxxxxxxxx@message.bam.com)
//
// --- Stop editing here ---  //
@$send=mail($phone,$subjekt,$zprava,$headers);

if(!$send){
	header("location: modules.php?name=$module_name&file=index&func=error");
    }else{
	header("location: modules.php?name=$module_name&file=index&func=sent");
    }

exit();


?>