<?php
/************************************************************************/
/* SMS module is radicaly based on:
/* Send_Mail: PHP-NUKE module created by Jan Skurovec (svab@cooltura.cz)*/
/* based on Nuke_Mailer module	by yahooooh@yahooooh.com                */
/* ===========================                                          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

define("_adresa","The number is incorrect!");
define("_smssent","The message was send successful!");
define("_error","There is a problem at the moment. Please try again later!");
define("_welcome","SMS center");
define("_komu","To (number)");
define("_subjekt","Subject");
define("_zprava","Message");
define("_vasmail","From");
define("_odeslat","Send");
define("_CLEAR","Clear");
define("_dalsi","New message");
define("_znovu","Back");
define("_smula","You're not logged on.");
define("_zaregistrovat","Registration");
define("_zalogovat","Log on");

//added in 1.5
define("_adresatovi","number");
define("_zadresare","phonebook");
define("_adminovi","Admin");
define("_pridatdoadresare","Add to phonebook");
define("_emailovaadresa","Phone number");
define("_jmeno","Name");
define("_editovat","Edit/Delete");
define("_selectfriend","Select name");
define("_selectadress","--Select--");
define("_DELETED","Delete");
define("_erroradd","There is a problem at the moment. Please try again later.");
define("_ted","Try now ...");
define("_addeddb","Added successful.");
define("_nextsms","SMS center");
define("_friendname","Name");
define("_friendmail","Phone number");
define("_adressbook","Phonebook");
define("_error_update","There is a problem with update at the moment. Please try again later..");
define("_error_delete","There is a problem with delete at the moment. Please try again later..");
define("_editovat","Edit");
//added by plovdiv-news.com
define("_komuexam1","<em>(E.g.: 17274445566)</em>");
define("_komuexam2","<em>(E.g.: Johnny)</em>");
define("_smsgateway","ICQ mail2sms");
define("_smsthnks","Sponsored by");
define("_smsterms","Terms and conditions for using SMS services by registered users");
define("_smsterms1","1. The present Terms and Conditions shall be considered accepted and agreed to by THE USER on his/her confirmation thereof and on filling-in the registration form. THE USER shall be obligated to use the SMS services in conjunction with the present Terms and Conditions.");
define("_smsterms2","2. The SMS center reserves its right to disconnect immediately and without notice the access to materials or data and to stop the use of the network by one or more users if the Provider decides, on its discretion, that these Terms and conditions have been breached.");
define("_smsterms3","3. The SMS center shall not be liable for any illegal use of the systems or the network nor for illegal contents distributed by its Users or by third parties, as far as it undertakes to provide only technical possibility for access to the resources of the Internet space.");
define("_smsterms4","4. It is inadmissible to send large messages (\"junk mail\" or \"spam\") as well as messages containing commercial advertisements, political speeches, announcements, etc., via the electronic mail (e-mail) to any third parties who have expressly stated that they do not want to receive such messages..");
define("_smsterms5","5. It is inadmissible to send messages from the e-mail address of another person except with the express consent of the owner, as well as to falsify any information about the sender.");
define("_smsterms6","6. It is inadmissible to forward or distribute the so-called chain messages.");
define("_smsterms7","7. The users who violate the security of the existing systems and networks shall be liable pursuant to the laws.");
?>