<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_PRINTER","Trang in");
define("_FRIEND","G&#7903;i truy&#7879;n n�y cho ng&#432;&#7901;i quen");
define("_YOURNAME","T�n");
define("_OK","Ok!");
define("_ALLOWEDHTML","Cho ph�p d�ng HTML:");
define("_EXTRANS","Extrans (html tags to text)");
define("_HTMLFORMATED","HTML Formated");
define("_PLAINTEXT","Plain Old Text");
define("_ARTICLES","Articles");
define("_SUBMITNEWS","G&#7903;i tin t&#7913;c");
define("_SUBMITADVICE","Please write your article/story filling the following form and double check your submission.<br>You're advised that not all submissions will be posted.<br>Your submission will be checked for proper grammar and maybe edited by our staff.");
define("_SUBTITLE","Ch&#7911; &#273;&#7873;");
define("_BEDESCRIPTIVE","Be Descriptive, Clear and Simple");
define("_BADTITLES","bad titles='Check This Out!' or 'An Article'");
define("_HTMLISFINE","HTML is fine, but double check those URLs and HTML tags!");
define("_AREYOUSURE","Are you sure you included a URL? Did you test them for typos?");
define("_SUBPREVIEW","You must preview once before you can submit");
define("_SELECTTOPIC","Select Topic");
define("_NEWSUBPREVIEW","News Submission Preview");
define("_STORYLOOK","Your Story will look something like this:");
define("_CHECKSTORY","Please check text, links, etc. before send your story!");
define("_THANKSSUB","Thanks for your submission!");
define("_SUBSENT","Your Article has been received...");
define("_SUBTEXT","We will check your submission in the next few hours, if it is interesting and relevant we will publish it soon.");
define("_WEHAVESUB","At this moment we have");
define("_WAITING","submissions waiting to be published.");
define("_PREVIEW","Preview");
define("_NEWUSER","New User");
define("_USCORE","Score");
define("_DATE","Date");
define("_STORYTEXT","Story Text");
define("_EXTENDEDTEXT","Extended Text");
define("_LANGUAGE","Language");

define("_SELECTMONTH2VIEW","Please select the month you want to view:");
define("_SHOWALLSTORIES","Show ALL Stories");
define("_STORIESARCHIVE","Stories Archive");
define("_ACTIONS","Actions");
define("_ARCHIVESINDEX","Stories Archive Index");
define("_ALLSTORIESARCH","All Stories");
define("_NEXTPAGE","Trang t&#7899;i");
define("_PREVIOUSPAGE","Trang sau");

?>