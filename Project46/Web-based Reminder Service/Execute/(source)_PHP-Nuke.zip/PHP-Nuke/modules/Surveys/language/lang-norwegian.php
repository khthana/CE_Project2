<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_YOURNAME","Ditt navn");
define("_OK","Ok!");
define("_COMMENT","kommentar");
define("_CONFIGURE","Konfigurer");
define("_LOGINCREATE","Logg inn/opprett konto");
define("_THRESHOLD","Terskel");
define("_NOCOMMENTS","Ingen kommentarer");
define("_NESTED","Nestet");
define("_FLAT","Flat");
define("_THREAD","Tr�det");
define("_OLDEST","Eldst f�rst");
define("_NEWEST","Nyeste f�rst");
define("_HIGHEST","H�yest poengsum f�rst");
define("_COMMENTSWARNING","Kommentarene eies av respektive postere. Vi har ikke noe ansvar for innholdet av disse.");
define("_SCORE","Poeng:");
define("_USERINFO","Brukerinformasjon");
define("_READREST","Les resten av denne kommentaren...");
define("_REPLY","Svar p� dette");
define("_REPLYMAIN","Post kommentar");
define("_NOSUBJECT","Inget emne");
define("_NOANONCOMMENTS","Ingen kommentarer er tillatt for anonyme brukere. Vennligst <a href=\"modules.php?name=Your_Account&amp;op=new_user\">registrer deg</a>");
define("_PARENT","Forelder");
define("_ROOT","Rot");
define("_UCOMMENT","Kommentar");
define("_ALLOWEDHTML","Tillatt HTML:");
define("_POSTANON","Post anonymt");
define("_EXTRANS","Extrans (HTML kode til tekst)");
define("_HTMLFORMATED","HTML formatert");
define("_PLAINTEXT","Vanlig tekst");
define("_ONN","p�...");
define("_SUBJECT","Emne");
define("_SURVEYCOM","Post kommentar til avstemming");
define("_SURVEYCOMPRE","Forh�ndsvis kommentar til avstemming");
define("_NOTRIGHT","Noe gikk galt med en variabel i denne funksjonen. Denne beskjeden er her for � ikke rote det til mer lengre ned.");
define("_DIRECTCOM","Direkte kommentar til avstemming...");
define("_SENDAMSG","Send en beskjed");
define("_PASTSURVEYS","Tidligere avstemminger");
define("_LVOTES","stemmer");
define("_TOTALVOTES","Totalt antall stemmer:");
define("_VOTING","Omstemmingsb�s");
define("_OTHERPOLLS","Andre avstemminger");
define("_CURRENTSURVEY","N�v�rende avstemming");
define("_CURRENTPOLLRESULTS","Stilling");
define("_PREVIEW","Forh�ndsvisning");
define("_REFRESH","Oppdater");
define("_SURVEYS","Avstemminger");
define("_ATTACHEDTOARTICLE","- Vedlagt artikkel:");
define("_SURVEYSATTACHED","Avstemminger til artikler");
define("_LAST5POLLS", "Siste 5 avstemminger p�");
define("_MOREPOLLS", "...flere avstemminger");

?>