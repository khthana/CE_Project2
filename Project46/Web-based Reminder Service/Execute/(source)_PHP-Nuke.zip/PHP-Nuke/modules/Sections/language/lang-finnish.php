<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_PRINTER","Kevyempi versio tulostusta varten");
define("_PREVIOUS","Edellinen sivu");
define("_NEXT","Uusi sivu");
define("_COMESFROM","Artikkelin l�de");
define("_THEURL","Artikkelin URL:");
define("_SECWELCOME","Tervetuloa opetus -sivuillemme");
define("_YOUCANFIND","Olemme pyrkineet tuomaan kristinuskon perusopetukseen liittyvi� opetuksia ja artikkeleita.<br>Pyrimme my�s tarjoamaan teille materiaalia nuorteniltoihin, seuroihin, saarnoihin ja raamattupiireihin.<br>Opetukset on yritetty saada mahdollisimman luettavaan muotoon, vaikkakin voivat olla tukisanalistoja...");
define("_THISISSEC","Aihepiiri");
define("_FOLLOWINGART","Seuraavat opetukset olemme julkaisseet.");
define("_SECRETURN","aihepiirin etusivulle");
define("_TOTALWORDS","sanaa tekstiss�");
define("_BACKTO","takaisin");
define("_SECINDEX","Opetusten etusivulle");
define("_PAGE","sivu");

?>