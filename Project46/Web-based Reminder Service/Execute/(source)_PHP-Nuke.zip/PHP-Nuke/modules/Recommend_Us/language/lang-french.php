<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_SEND","Envoyer");
define("_FYOURNAME","Votre nom:");
define("_FYOUREMAIL","Votre E-mail:");
define("_FFRIENDNAME","Nom de votre ami(e):");
define("_FFRIENDEMAIL","E-mail de votre ami(e):");
define("_HELLO","Bonjour");
define("_YOURFRIEND","Votre ami(e)");
define("_RECOMMEND","Recommander ce site &agrave; un(e) ami(e)");
define("_INTSITE","Site int�ressant:");
define("_OURSITE","estime notre site");
define("_INTSENT","int�ressant et a souhait� vous en parler.");
define("_FSITENAME","Nom du Site:");
define("_FSITEURL","URL du Site:");
define("_FREFERENCE","La r&eacute;f&eacute;rence &agrave; notre site a &eacute;t&eacute; envoy&eacute;e &agrave;");
define("_THANKSREC","Merci de nous avoir recommand&eacute;!");


?>