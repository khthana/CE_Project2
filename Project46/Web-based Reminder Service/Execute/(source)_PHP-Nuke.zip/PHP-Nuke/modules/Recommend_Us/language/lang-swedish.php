<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/

define("_SEND","Skicka");
define("_FYOURNAME","Ditt Namn:");
define("_FYOUREMAIL","Din E-postadress:");
define("_FFRIENDNAME","Din Kompis Namn:");
define("_FFRIENDEMAIL","Din Kompis E-postadress:");
define("_HELLO","Hej");
define("_YOURFRIEND","Din kompis");
define("_RECOMMEND","Rekommendera denna webbplats till en kompis");
define("_INTSITE","Intressant Webbplats:");
define("_OURSITE","tyckte att v�r webbplats");
define("_INTSENT","var intressant och ville skicka en l�nk till dig.");
define("_FSITENAME","Webbplatsens Namn:");
define("_FSITEURL","Webbplatsens URL:");
define("_FREFERENCE","L�nken till v�r webbplats har skickats till");
define("_THANKSREC","Tack f�r att du rekommenderade oss!");

?>