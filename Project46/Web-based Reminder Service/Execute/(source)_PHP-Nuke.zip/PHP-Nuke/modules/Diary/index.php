<?php
if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
$index = 1; // 0 =  �Դ���� ��ҹ���, 1 =  �Դ�����ҹ���

require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
include("header.php");

//-----------------------connect database ---------------------------------
$host_name = "localhost";
$user_name = "root";
$link_name = mysql_connect($host_name, $user_name);	//----- �ӡ�����͵����ѧ MySQL

if (!$link_name){															//�ʴ� Error �ҡ���������������
	echo "error conected";
	
}else{
	$result = mysql_query("use Reminder");									//----- �ӡ�����͡ DB ������		
	if(!$result){															//�ʴ� Error �ҡ ��辺 DB ����ͧ���
		echo "error connect reminder";
	}
}
//------------------------------------------------
if($op=="change_calendar"){
	$year=$year-543;
}
include("calendar_box.php");
include("Date_combo.php");
include("show_more_detail.php");


OpenTable();	//���ҧ���ҧ (��ͺ) �����, ���繵�ͧ��Ǻ���Ѻ����� CloseTable() �����к� �ͺࢵ�ͧ��ͺ����ͧ������ҧ

//---------------
global $user, $cookie, $user_prefix, $db;
$autousername=$cookie[1];

//echo "<br/>".$combo_year."<br/>";




//---------------------------- �ʴ���������´�ͧ ������ �ҡ�ա�á� �ѹ��
if($op=="show_detail"){
//######################################################################################3
	show_more_detail($diary_day,$diary_month,$diary_year);
//	echo "<TABLE width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><TR><td style=\"background-image: url('modules/Diary/images/header_bg.gif');text-align:right;  color:#1A4A7B; \" >"._GOBACK."</TD></TR></TABLE>";
	echo "<TABLE width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><TR><td style=\"background-color:#222222;text-align:right;  color:#1A4A7B; \" >"._GOBACK."</TD></TR></TABLE>";

	if($sub_op=="show_edit"){

	
	}

	echo $MyBox;
//######################################################################################3
}else{
//######################################################################################3
//echo $combo_month;
//�Ҥ���ѹ�Ѩ�غѹ
$diary_day=date("j");
$diary_month= date("n");
$diary_year= date("Y"); 

//---------------�к����Ң����� �ͧ�ѹ�Ѩ�غѹ ���ͻ�ͧ�ѹ����á�����������ͧ�����ѹ���ǡѹ-------------

	if($delete!=""){//�׹�ѹ���ź
		$sql="DELETE FROM diary WHERE diary_year=$diary_year and diary_day=$diary_day and diary_month=$diary_month and diary_name='$autousername';";
		$result = mysql_query($sql);
		if (!$result)
			echo "CANT DELETE by SQL command ".$sql;
		else
			$MyBox.=" <b>ź���º����</b>";
		}

	$sql = "SELECT * FROM diary WHERE  diary_day=$diary_day and diary_year=$diary_year and diary_month=$diary_month and diary_name='$autousername';";
	$result2 = mysql_query($sql);
	if($result2 ){
	$dbarr2 = mysql_fetch_array($result2);
	}
	$havesomedata=mysql_num_rows( $result2);
	if($havesomedata){   //����բ���������������� ����ҷӧҹ���ǹ���仹��
		$textdata=$dbarr2["diary_note"];
		$headstory=$dbarr2["diary_title"];                 
	}

	

	if($save!="" && $mybox!=""){//�ӡ�úѹ�֡ �� ���������txt area ����繪�ͧ��ҧ  �����ѹ�֡
		$mybox=str_replace("\"","&quot;",$mybox);
		$mybox=str_replace("<","&lt;",$mybox);
		$mybox=str_replace(">","&gt;",$mybox);
		$storynew=str_replace("\"","&quot;",$storynew);
		$storynew=str_replace("<","&lt;",$storynew);
		$storynew=str_replace(">","&gt;",$storynew);
		if($textdata==""and$headstory=="")
			$sql="INSERT INTO diary (diary_name,diary_day,diary_month,diary_year,diary_title,diary_note) VALUES ('$autousername',$diary_day,$diary_month,$diary_year,'$storynew','$mybox');";
		else{
			//$sql="UPDATE diary SET diary_note='$mybox',diary_title='$storynew' WHERE  diary_day=$diary_day and diary_year=$diary_year and diary_month=$diary_month and diary_name='$autousername';";
			$sql="UPDATE diary SET diary_note=\"$mybox\",diary_title=\"$storynew\" WHERE  diary_day=$diary_day and diary_year=$diary_year and diary_month=$diary_month and diary_name='$autousername';";
		}
		$textdata=$mybox;$headstory=$storynew;
		$result = mysql_query($sql);
		if (!$result)
			echo "CANT INSERT by SQL command ".$sql;
		else
			$MyBox.=" <b>�ѹ�֡���º��������</b>";
	} 

	$sql = "SELECT * FROM diary WHERE  diary_year=$year and diary_month=$month and diary_name='$autousername' ORDER BY diary_day DESC;";
	$result3 = mysql_query($sql);
	$totalrecord=mysql_num_rows( $result3);
	if (!$result3)
		echo "CANT INSERT by SQL command ".$sql;
	else{
		$showdate.="<center><b>������ ��͹  ";
		$showdate.=$textmonth;
		$showdate.=$thyear;
		$showdate.="</b></center><br/>";
		$showdate.="<center><i>�ա����¹ ������ $totalrecord �ѹ </i></center><br/>" ;
		$showdate.="<table border=\"0\" cellspacing=\"0\"  cellpadding=\"2\" >";
        while( $dbarr = mysql_fetch_array($result3)){
			//$showdate.=$dbarr["diary_day"]."/";
			$showdate.="<tr><td valign=\"top\">~</td><td>";
			$showdate.="<a href=\"modules.php?name=Diary&op=show_detail&diary_day=".$dbarr["diary_day"]."&diary_month=".$dbarr["diary_month"]."&diary_year=".$dbarr["diary_year"]."\" >";
			$showdate.="�ѹ��� ".$dbarr["diary_day"]."&nbsp;-&nbsp;";
			$showdate.=$dbarr["diary_title"];
	        $showdate.="</a></td></tr>";
		}	
		$showdate.="</table>";
	}
//----------------

//------------- ���ҧ Form
	include("script.php");
	$MyBox.="<table border=\"0\"><tr><td>\n";
	$MyBox.="<form action=\"modules.php?name=Diary\" name=\"diary_form\" method=\"post\">\n";
	$MyBox.="��Ǣ������ͧ�ѹ��� :  (optional)<br/>";
    $MyBox.="<input type=\"text\"  name=storynew  value=\"$headstory\" size=\"50\"> <br/><br/>";

    $MyBox.="���ͤ��� : (required) <br/>";
	$MyBox.="<textarea rows=\"9\" cols=\"50\" name=\"mybox\">";
	$MyBox.=$textdata;
	$MyBox.="</textarea><br/>";
	$MyBox.= "<table border=\"0\" cellpadding=\"3\" cellspacing=\"3\" align=\"center\">";
	
	$MyBox.="<tr><td ><a href=\"#\" onClick=\"addEmoticon('*-)'); return false;\"><img src=\"modules/Diary/images/f001.gif\" border=\"0\" alt=\"*-)\"></a></td>";
	$MyBox.="      <td ><a href=\"#\" onClick=\"addEmoticon(':S'); return false;\"><img src=\"modules/Diary/images/f002.gif\" border=\"0\"alt=\":S\"></a></td>";
	$MyBox.="	   <td ><a href=\"#\" onClick=\"addEmoticon(':l'); return false;\"><img src=\"modules/Diary/images/f003.gif\" border=\"0\"alt=\":l\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':@'); return false;\"><img src=\"modules/Diary/images/f004.gif\" border=\"0\"alt=\":@\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(' :D'); return false;\"><img src=\"modules/Diary/images/f005.gif\" border=\"0\"alt=\" :D\"></a></td></tr>";
	$MyBox.="<tr><td ><a href=\"#\" onClick=\"addEmoticon(' :P'); return false;\"><img src=\"modules/Diary/images/f006.gif\" border=\"0\"alt=\" :P\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':)'); return false;\"><img src=\"modules/Diary/images/f007.gif\" border=\"0\"alt=\":)\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':('); return false;\"><img src=\"modules/Diary/images/f008.gif\" border=\"0\"alt=\":(\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':$'); return false;\"><img src=\"modules/Diary/images/f009.gif\" border=\"0\"alt=\":$\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':-('); return false;\"><img src=\"modules/Diary/images/f010.gif\" border=\"0\"alt=\":-(\"></a></td></tr>";
	$MyBox.="<tr><td ><a href=\"#\" onClick=\"addEmoticon('8-)'); return false;\"><img src=\"modules/Diary/images/f011.gif\" border=\"0\"alt=\"8-)\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':E'); return false;\"><img src=\"modules/Diary/images/f012.gif\" border=\"0\"alt=\":E\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':{'); return false;\"><img src=\"modules/Diary/images/f013.gif\" border=\"0\"alt=\":{\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':-?'); return false;\"><img src=\"modules/Diary/images/f014.gif\" border=\"0\"alt=\":-?\"></a></td>";
	$MyBox.="		<td ><a href=\"#\" onClick=\"addEmoticon(':-x'); return false;\"><img src=\"modules/Diary/images/f015.gif\" border=\"0\"alt=\":-x\"></a></td></tr>";
	$MyBox.="</table>";
	//$MyBox.="<input type=\"hidden\" name=\"op\" value=\"modify\"><br/>\n";
	$MyBox.="<center><input type=\"submit\"  name=\"save\"value=\" �ѹ�֡\">\n";
	$MyBox.="<input type=\"reset\" name=\"reset\"value=\" ¡��ԡ\" >\n";
	$MyBox.="<input type=\"submit\" value=\"  ź  \" name=\"delete\" ></center>\n";	
	
	$MyBox.="</form>\n";
	$MyBox.="</td></tr></table>";
	
	//----------------------------
	
	
	echo "<b>��ش�ѹ�֡��ǹ��� :   </b><b>$autousername</b><br/><br/>";
	echo"<center>";
	echo $DateSelect;
	echo"</center>";
	//echo "<table bgcolor=\"#ECF0F6\"border=\"2\" cellspacing=\"5\" cellpadding=\"10\" width=\"100%\"><tr><td rowspan=\"2\" align=\"left\" valign=\"top\">";
	echo "<table border=\"1\" cellspacing=\"4\" cellpadding=\"10\" width=\"100%\"><tr><td rowspan=\"2\" align=\"left\" valign=\"top\">";
 	//echo "123456789123456789123456789123456789";
	echo $showdate;
	//echo $dbarr["diary_day"];
	echo "</td><td  align=\"left\">";
	echo $Calendar;
	echo "</td></tr>";
	echo"<tr><td>";
	echo $MyBox;
	
	echo"</td></tr></table>";

//*************************************************************************************
mysql_close($link_name);
//######################################################################################3
}
CloseTable();
include("footer.php");
?>