<?
global $user, $cookie, $user_prefix, $db;
$autousername=$cookie[1];
 $fontfamily = isset($fontfamily) ? $fontfamily : "MS Sans Serif, Geneva, sans-serif"; 
  $defaultfontcolor = isset($defaultfontcolor) ? $defaultfontcolor : "#000000"; 
  $color1 = isset($color1)?$color1 : "#667788";
  $color2 = isset($color2)?$color2 : "#CCDDEE";
  $color3 = isset($color3)?$color3 : "#AABBCC";
  $color4 = isset($color4)?$color4 : "#FFFFFF";
  $color5 = isset($color5)?$color5 : "#ffffff";

  $todayfontcolor = isset($todayfontcolor) ? $todayfontcolor : "#FFFFFF"; 
  $todaybgcolor = isset($todaybgcolor) ? $todaybgcolor : "#336699"; 
  $monthcolor = isset($monthcolor) ? $monthcolor : "#333399"; 
  $relfontsize = isset($relfontsize) ? $relfontsize : "1"; 
  $cssfontsize = isset($cssfontsize) ? $cssfontsize : "7pt"; 

  $month = (isset($month)) ? $month : date("n",time());
  $monthnames = array("���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��Ȩԡ�¹","�ѹ�Ҥ�"); 
  $textmonth = $monthnames[$month - 1]; 

  $year = (isset($year)) ? $year : date("Y",time()); 
  $today = (isset($today))? $today : date("j", time());  
  $today = ($month == date("n",time()) && $year == date("Y",time())) ? $today : 32;  
  $days = date("t",mktime(1,1,1,$month,1,$year)); 
  $dayone = date("w",mktime(1,1,1,$month,1,$year)); 
  $daylast = date("w",mktime(1,1,1,$month,$days,$year)); 
  $dayarray = array("��.","�.","�.","�.","��.","�.","�."); 

//show YEAR header
$thyear=$year+543;
$Calendar .= "<table border=\"0\" cellpadding=\"3\" cellspacing=\"3\" width=\"100%\"><tr>\n";
$Calendar .= "<td bgcolor=\"$color4\" colspan=\"7\" valign=\"middle\" align=\"center\"><font color=\"$monthcolor\"><b>$textmonth $thyear</b></font></td></tr><tr>\n";

//show DayOfWeek Header
for($i=0; $i <= 6; $i++): 
	$width = ($i == 0 || $i == 6) ? "15%" : "14%"; 
    $Calendar .= "  <td valign=\"middle\" width=$width\" style=\"text-align:center; background:{$color1}; font:bold {$cssfontsize} {$fontfamily}; color:{$defaultfontcolor};\">$dayarray[$i]</td>\n";     
endfor; 
$Calendar .= "</tr>\n"; 

$span1 = $dayone; 
$span2 = 6 - $daylast; 

//show Day in month
//���ҧ���ҧ��ԷԹ
for($i = 1; $i <= $days; $i++): 
	//$sql = "SELECT * FROM diary WHERE  diary_year=$year and diary_day=$i and diary_month=$month and diary_name='$autousername';";
	$sql = "SELECT * FROM diary WHERE  diary_year=$year and diary_day=$i and diary_month=$month and diary_name='$autousername';";
	$result = mysql_query($sql);
	if($result ){
	$dbarr = mysql_fetch_array($result);
	}
	if ($dbarr["diary_note"]==""){
		$font_style="";
	}else{
		$font_style="font-weight:bold;color:#FF6900;";
	}

	$dayofweek = date("w",mktime(1,1,1,$month,$i,$year));
	$width = ($dayofweek == 0 || $dayofweek == 6) ? "15%" : "14%"; 

	switch ($i): 
		case $today: 
			$fontcolor = $todayfontcolor; 
	        $bgcellcolor = $todaybgcolor; 
		break; 
		default: 
			$fontcolor = $defaultfontcolor; 
			$bgcellcolor = $color2; 
		break; 
	endswitch; 
	if($i == 1 || $dayofweek == 0):
		$Calendar .= " <tr bgcolor=\"$color3\">\n"; 
		if($span1 > 0 && $i == 1) 
			$Calendar .= "  <td align=\"left\" bgcolor=\"$color3\" colspan=\"$span1\"><font face=\"null\" size=\"1\">&nbsp;</font></td>\n"; 
	endif; 
		
	if($font_style==""){
		$Calendar.="  <td valign=\"middle\" width=$width\" style=\"text-align:center; background:{$bgcellcolor}; font-family:{$fontfamily}; color:{$fontcolor}; font-size:{$cssfontsize}\">$i</td>\n"; 
	}else{
		$Calendar .= "  <td valign=\"middle\" width=$width\" style=\"text-align:center; background:{$bgcellcolor}; font-family:{$fontfamily}; color:{$fontcolor}; font-size:{$cssfontsize}\"><a href=\"modules.php?name=Diary&op=show_detail&diary_day=$i&diary_month=$month&diary_year=$year\" STYLE=\"color:{$fontcolor}; {$font_style}\">$i</a></td>\n"; 
	}
	
	if($i == $days && $span2 > 0) 
		$Calendar .= "  <td align=\"left\" bgcolor=\"$color3\" colspan=\"$span2\"><font face=\"null\" size=\"1\">&nbsp;</font></td>\n"; 
	if($dayofweek == 6 || $i == $days) 
		$Calendar .= " </tr>\n"; 
endfor; 			
  $Calendar .= "</table><BR>\n"; 

//echo $thyear;
//echo $year;
?>