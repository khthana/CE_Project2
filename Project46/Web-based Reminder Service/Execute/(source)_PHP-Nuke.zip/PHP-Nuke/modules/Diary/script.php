<?
echo "<script langauge=\"javascript\" type=\"text/javascript\">";
echo "function addEmoticon(text) {";
echo "	text = ' ' + text + ' ';";
echo "	if (document.diary_form.mybox.createTextRange && document.diary_form.mybox.caretPos) {";
echo "		var caretPos = document.diary_form.mybox.caretPos;";
echo "		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text;";
echo "		document.diary_form.mybox.focus();";
echo "	} else {";
echo "	document.diary_form.mybox.value  += text;";
echo "	document.diary_form.mybox.focus();";
echo "	}";
echo "}";
echo "</script>";
?>