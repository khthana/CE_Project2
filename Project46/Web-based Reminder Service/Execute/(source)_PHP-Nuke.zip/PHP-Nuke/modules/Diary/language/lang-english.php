<?php

/**************************************************************************/
/* PHP-NUKE: Advanced Content Management System                           */
/* ============================================                           */
/*                                                                        */
/* This is the language module with all the system messages               */
/*                                                                        */
/* If you made a translation, please go to the site and send to me        */
/* the translated file. Please keep the original text order by modules,   */
/* and just one message per line, also double check your translation!     */
/*                                                                        */
/* You need to change the second quoted phrase, not the capital one!      */
/*                                                                        */
/* If you need to use double quotes (") remember to add a backslash (\),  */
/* so your entry will look like: This is \"double quoted\" text.          */
/* And, if you use HTML code, please double check it.                     */
/**************************************************************************/
define("_month1","January");
define("_month2","February");
define("_month3","March");
define("_month4","April");
define("_month5","May");
define("_month6","June");
define("_month7","July");
define("_month8","August");
define("_month9","September");
define("_month10","October");
define("_month11","November");
define("_month12","December");
define("_H001","Reminder Service");
define("_H002","fill all blank, Service System will send your note to your email in your selected time");
define("_H003","Name");
define("_H004","Email");
define("_H005","Note");
define("_H006","Today");
define("_H007","Day");
define("_H008","Month");
define("_H009","Year");
define("_H010","Time");
define("_H011","Extra");
define("_H012","Submit");
define("_H013","Reset");
define("_err_date"," date invalid");
define("_err_connect","<center>Can't connect to MySQL server </center><center>Please verify Host, User, Password is valid</center><br/><br/>");
define("_err_select","<center><b>Internal Error</b> Can't found Reminder, please check again</center><br/><br/>");
define("_err_insert","<center><b>Internal Error</b> Can't insert data item to table</center><br/><br/>");
define("_ok_now","<center><b>Successful : Reminder note saved</b></center><br/><br/>");
define("_msg_ToYouBy","Send to you by");
define("_msg_bySMS","SMS");
define("_msg_byICQ","ICQ");
define("_msg_byPager","Pager");
define("_msg_detail","more detail");
define("_err_yearback","select Year backward, can't reminder in that year");
define("_err_monthback","select Month backward, can't reminder in that month");
define("_err_dayback","select Day backward, can't reminder in that day");
define("_err_method","pleas select at least one method to send");
define("_complete1","Message will send to");
define("_complete2","at time");
define("_complete3","of date");
define("_gogoback","Go back");
define("_err_blank","Please insert your note");
define("_err_phone","Please check your mobile phone number");




/*****************************************************/
/* Function to translate Datestrings                 */
/*****************************************************/
/*
function translate($phrase) {
    switch($phrase) {
	case "xdatestring":	$tmp = "%A, %B %d @ %T %Z"; break;
	case "linksdatestring":	$tmp = "%d-%b-%Y"; break;
	case "xdatestring2":	$tmp = "%A, %B %d"; break;
	default:		$tmp = "$phrase"; break;
    }
    return $tmp;
}
*/
?>
