<?
//USE:			after include this module, then  	"echo $DateSelect"

//--------------------------�ӵ�����͡ �ѹ �����͹ ��--------------------
//�Ҥ���ѹ�Ѩ�غѹ
	$combo_today = (isset($combo_today))? $combo_today : date("j", time());
	$combo_month = (isset($combo_month)) ? $combo_month : date("n",time());
	$combo_year = (isset($combo_year)) ? $combo_year : date("Y",time()); 
	$combo_year=$combo_year+543;  
	
//============create combo list "month" ===========
	$DateSelect .= "<form action=\"modules.php?name=Diary\" method=\"post\">";
	$DateSelect .= "<select name=\"month\">";
	for ($i = 1;$i<13;$i=$i+1)
		{
		$DateSelect .= "<option value=\"".$i."\"";
		if ($i==$combo_month)
			$DateSelect .= " selected=\"selected\" ";
		$DateSelect .= ">". $monthnames[$i-1]."</option>";
		}
	$DateSelect .= "</select>";

	//==============create combo list "year" ==============
	$DateSelect .= "<select name=\"year\">";
	for ($i=($combo_year-15);$i<=($combo_year);$i++)
		{
		$DateSelect .= "<option value=\"".$i."\"";
		if($i==$combo_year)
			$DateSelect .= "selected=\"selected\" ";
		$DateSelect .= ">".$i."</option>";
		}
	$DateSelect .= "</select>";
	$DateSelect .= "<INPUT type=\"submit\" value=\"���͡仴�!\" name=\"submit\" >";
	$DateSelect .="<input type=\"hidden\" name=\"op\" value=\"change_calendar\">";
	$DateSelect .= "</form>";

?>