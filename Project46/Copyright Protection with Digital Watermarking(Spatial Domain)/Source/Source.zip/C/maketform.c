/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "maketform.h"
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static double _ieee_plusinf_;
static mxArray * _mxarray1_;

static mxChar _array3_[6] = { 'a', 'f', 'f', 'i', 'n', 'e' };
static mxArray * _mxarray2_;

static mxChar _array5_[10] = { 'p', 'r', 'o', 'j', 'e',
                               'c', 't', 'i', 'v', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[9] = { 'c', 'o', 'm', 'p', 'o', 's', 'i', 't', 'e' };
static mxArray * _mxarray6_;

static mxChar _array9_[6] = { 'c', 'u', 's', 't', 'o', 'm' };
static mxArray * _mxarray8_;

static mxChar _array11_[3] = { 'b', 'o', 'x' };
static mxArray * _mxarray10_;

static mxChar _array13_[23] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ',
                                'T', 'R', 'A', 'N', 'S', 'F', 'O', 'R',
                                'M', 'T', 'Y', 'P', 'E', ':', ' ' };
static mxArray * _mxarray12_;

static mxChar _array15_[1] = { '.' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;

static double _array18_[3] = { 0.0, 0.0, 1.0 };
static mxArray * _mxarray17_;
static mxArray * _mxarray19_;
static mxArray * _mxarray20_;

static mxChar _array22_[7] = { 'i', 'n', 'v', 'e', 'r', 's', 'e' };
static mxArray * _mxarray21_;

static mxChar _array24_[7] = { 'f', 'o', 'r', 'w', 'a', 'r', 'd' };
static mxArray * _mxarray23_;

static mxChar _array26_[48] = { 'D', 'I', 'R', 'E', 'C', 'T', 'I', 'O', 'N',
                                ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'e', 'i', 't', 'h', 'e', 'r', ' ', 0x0027,
                                'f', 'o', 'r', 'w', 'a', 'r', 'd', 0x0027,
                                ' ', 'o', 'r', ' ', 0x0027, 'i', 'n', 'v',
                                'e', 'r', 's', 'e', 0x0027, '.' };
static mxArray * _mxarray25_;

static mxChar _array28_[47] = { 'A', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'a', ' ', 'r', 'e', 'a', 'l',
                                '-', 'v', 'a', 'l', 'u', 'e', 'd', ' ',
                                'm', 'a', 't', 'r', 'i', 'x', ' ', 'o',
                                'f', ' ', 'c', 'l', 'a', 's', 's', ' ',
                                'd', 'o', 'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray27_;

static mxChar _array30_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray29_;

static mxChar _array32_[33] = { 'A', 'l', 'l', ' ', 'e', 'l', 'e', 'm', 'e',
                                'n', 't', 's', ' ', 'o', 'f', ' ', 'A', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'f',
                                'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray31_;

static mxChar _array34_[37] = { 'A', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 's', 'q', 'u', 'a', 'r', 'e',
                                ' ', 'a', 'n', 'd', ' ', 'a', 't', ' ',
                                'l', 'e', 'a', 's', 't', ' ', '2', '-',
                                'b', 'y', '-', '2', '.' };
static mxArray * _mxarray33_;

static mxChar _array36_[79] = { 'T', 'h', 'e', ' ', 'f', 'i', 'n', 'a', 'l',
                                ' ', 'c', 'o', 'l', 'u', 'm', 'n', ' ', 'o',
                                'f', ' ', 'A', ' ', 'm', 'u', 's', 't', ' ',
                                'c', 'o', 'n', 's', 'i', 's', 't', ' ', 'o',
                                'f', ' ', 'z', 'e', 'r', 'o', 'e', 's', ',',
                                ' ', 'e', 'x', 'c', 'e', 'p', 't', ' ', 'f',
                                'o', 'r', ' ', 'a', ' ', 'o', 'n', 'e', ' ',
                                'i', 'n', ' ', 't', 'h', 'e', ' ', 'l', 'a',
                                's', 't', ' ', 'r', 'o', 'w', '.' };
static mxArray * _mxarray35_;
static mxArray * _mxarray37_;

static mxChar _array39_[44] = { 'T', 'h', 'e', ' ', 'l', 'a', 's', 't', ' ',
                                'e', 'l', 'e', 'm', 'e', 'n', 't', ' ', 'o',
                                'f', ' ', 'A', ' ', 'i', 's', ' ', 'v', 'e',
                                'r', 'y', ' ', 'c', 'l', 'o', 's', 'e', ' ',
                                't', 'o', ' ', 'z', 'e', 'r', 'o', '.' };
static mxArray * _mxarray38_;

static mxChar _array41_[29] = { 'T', 'h', 'e', ' ', 'c', 'o', 'n', 'd',
                                'i', 't', 'i', 'o', 'n', ' ', 'n', 'u',
                                'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'A', ' ', 'i', 's', ' ' };
static mxArray * _mxarray40_;
static mxArray * _mxarray42_;

static mxChar _array44_[18] = { 'U', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', '%', 'd', '-', 'b', 'y', '-', '2', '.' };
static mxArray * _mxarray43_;

static mxChar _array46_[18] = { 'X', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', '%', 'd', '-', 'b', 'y', '-', '2', '.' };
static mxArray * _mxarray45_;

static mxChar _array48_[48] = { 'U', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'r', 'e', 'a', 'l', '-', 'v',
                                'a', 'l', 'u', 'e', 'd', ' ', '(', 'c',
                                'l', 'a', 's', 's', ' ', 'd', 'o', 'u',
                                'b', 'l', 'e', ')', ' ', 'a', 'n', 'd',
                                ' ', 'f', 'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray47_;

static mxChar _array50_[48] = { 'X', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'r', 'e', 'a', 'l', '-', 'v',
                                'a', 'l', 'u', 'e', 'd', ' ', '(', 'c',
                                'l', 'a', 's', 's', ' ', 'd', 'o', 'u',
                                'b', 'l', 'e', ')', ' ', 'a', 'n', 'd',
                                ' ', 'f', 'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray49_;

static mxChar _array52_[53] = { 'P', 'o', 'i', 'n', 't', 's', ' ', 'i', 'n',
                                ' ', 'U', ' ', 'a', 'r', 'e', ' ', 'n', 'e',
                                'a', 'r', 'l', 'y', ' ', 'c', 'o', 'l', 'l',
                                'i', 'n', 'e', 'a', 'r', ' ', 'a', 'n', 'd',
                                '/', 'o', 'r', ' ', 'c', 'o', 'i', 'n', 'c',
                                'i', 'd', 'e', 'n', 't', 'a', 'l', '.' };
static mxArray * _mxarray51_;

static mxChar _array54_[53] = { 'P', 'o', 'i', 'n', 't', 's', ' ', 'i', 'n',
                                ' ', 'X', ' ', 'a', 'r', 'e', ' ', 'n', 'e',
                                'a', 'r', 'l', 'y', ' ', 'c', 'o', 'l', 'l',
                                'i', 'n', 'e', 'a', 'r', ' ', 'a', 'n', 'd',
                                '/', 'o', 'r', ' ', 'c', 'o', 'i', 'n', 'c',
                                'i', 'd', 'e', 'n', 't', 'a', 'l', '.' };
static mxArray * _mxarray53_;

static mxChar _array56_[44] = { 'C', 'o', 'l', 'l', 'i', 'n', 'e', 'a', 'r',
                                ' ', 'p', 'o', 'i', 'n', 't', 's', ' ', 'i',
                                'n', ' ', 'U', ' ', 'o', 'r', ' ', 'X', ';',
                                ' ', 'c', 'a', 'n', 'n', 'o', 't', ' ', 'c',
                                'o', 'n', 't', 'i', 'n', 'u', 'e', '.' };
static mxArray * _mxarray55_;

static mxChar _array58_[38] = { 'A', 't', ' ', 'l', 'e', 'a', 's', 't',
                                ' ', 'o', 'n', 'e', ' ', 'T', 'F', 'O',
                                'R', 'M', ' ', 's', 't', 'r', 'u', 'c',
                                't', ' ', 'i', 's', ' ', 'r', 'e', 'q',
                                'u', 'i', 'r', 'e', 'd', '.' };
static mxArray * _mxarray57_;

static mxChar _array60_[26] = { 'T', '1', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'a', ' ', 'T', 'F', 'O', 'R', 'M',
                                ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray59_;

static mxChar _array62_[51] = { '[', 'T', '1', ',', ' ', 'T', '2', ',', ' ',
                                '.', '.', '.', ' ', 'T', 'N', ']', ' ', 'm',
                                'u', 's', 't', ' ', 'b', 'e', ' ', 'a', 'n',
                                ' ', 'a', 'r', 'r', 'a', 'y', ' ', 'o', 'f',
                                ' ', 'T', 'F', 'O', 'R', 'M', ' ', 's', 't',
                                'r', 'u', 'c', 't', 's', '.' };
static mxArray * _mxarray61_;
static mxArray * _mxarray63_;

static mxChar _array65_[43] = { 'T', '1', ',', ' ', 'T', '2', ',', ' ', '.',
                                '.', '.', ' ', 'T', 'N', ' ', 'm', 'u', 's',
                                't', ' ', 'e', 'a', 'c', 'h', ' ', 'b', 'e',
                                ' ', 'a', ' ', 'T', 'F', 'O', 'R', 'M', ' ',
                                's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray64_;

static mxChar _array67_[49] = { 'I', 'n', 'p', 'u', 't', ' ', 'T', 'F', 'O',
                                'R', 'M', ' ', 'o', 'b', 'j', 'e', 'c', 't',
                                's', ' ', 'h', 'a', 'v', 'e', ' ', 'i', 'n',
                                'c', 'o', 'n', 's', 'i', 's', 't', 'e', 'n',
                                't', ' ', 'd', 'i', 'm', 'e', 'n', 's', 'i',
                                'o', 'n', 's', '.' };
static mxArray * _mxarray66_;

static mxChar _array69_[7] = { 'i', 's', 'e', 'm', 'p', 't', 'y' };
static mxArray * _mxarray68_;

static mxChar _array71_[61] = { 'U', 'n', 'a', 'b', 'l', 'e', ' ', 't', 'o',
                                ' ', 'c', 'o', 'm', 'p', 'o', 's', 'e', ' ',
                                'e', 'i', 't', 'h', 'e', 'r', ' ', 'a', ' ',
                                'f', 'o', 'r', 'w', 'a', 'r', 'd', ' ', 'o',
                                'r', ' ', 'i', 'n', 'v', 'e', 'r', 's', 'e',
                                ' ', 't', 'r', 'a', 'n', 's', 'f', 'o', 'r',
                                'm', 'a', 't', 'i', 'o', 'n', '.' };
static mxArray * _mxarray70_;
static mxArray * _mxarray72_;
static mxArray * _mxarray73_;

static mxChar _array75_[49] = { 'N', 'D', 'I', 'M', 'S', '_', 'I', 'N', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                                ' ', 'f', 'i', 'n', 'i', 't', 'e', ',', ' ',
                                'i', 'n', 't', 'e', 'g', 'e', 'r', '-', 'v',
                                'a', 'l', 'u', 'e', 'd', ' ', 'd', 'o', 'u',
                                'b', 'l', 'e', '.' };
static mxArray * _mxarray74_;

static mxChar _array77_[50] = { 'N', 'D', 'I', 'M', 'S', '_', 'O', 'U', 'T',
                                ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'a', ' ', 'f', 'i', 'n', 'i', 't', 'e', ',',
                                ' ', 'i', 'n', 't', 'e', 'g', 'e', 'r', '-',
                                'v', 'a', 'l', 'u', 'e', 'd', ' ', 'd', 'o',
                                'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray76_;

static mxChar _array79_[26] = { 'N', 'D', 'I', 'M', 'S', '_', 'I', 'N', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'p',
                                'o', 's', 'i', 't', 'i', 'v', 'e', '.' };
static mxArray * _mxarray78_;

static mxChar _array81_[27] = { 'N', 'D', 'I', 'M', 'S', '_', 'O', 'U', 'T',
                                ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'p', 'o', 's', 'i', 't', 'i', 'v', 'e', '.' };
static mxArray * _mxarray80_;

static mxChar _array83_[15] = { 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                '_', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray82_;

static mxChar _array85_[38] = { 'F', 'O', 'R', 'W', 'A', 'R', 'D', '_',
                                'F', 'C', 'N', ' ', 'm', 'u', 's', 't',
                                ' ', 'b', 'e', ' ', 'a', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', 'h',
                                'a', 'n', 'd', 'l', 'e', '.' };
static mxArray * _mxarray84_;

static mxChar _array87_[38] = { 'I', 'N', 'V', 'E', 'R', 'S', 'E', '_',
                                'F', 'C', 'N', ' ', 'm', 'u', 's', 't',
                                ' ', 'b', 'e', ' ', 'a', ' ', 'f', 'u',
                                'n', 'c', 't', 'i', 'o', 'n', ' ', 'h',
                                'a', 'n', 'd', 'l', 'e', '.' };
static mxArray * _mxarray86_;

static mxChar _array89_[49] = { 'F', 'O', 'R', 'W', 'A', 'R', 'D', '_', 'F',
                                'C', 'N', ' ', 'a', 'n', 'd', ' ', 'I', 'N',
                                'V', 'E', 'R', 'S', 'E', '_', 'F', 'C', 'N',
                                ' ', 'c', 'a', 'n', 'n', 'o', 't', ' ', 'b',
                                'o', 't', 'h', ' ', 'b', 'e', ' ', 'e', 'm',
                                'p', 't', 'y', '.' };
static mxArray * _mxarray88_;

static mxChar _array91_[55] = { 'T', 'S', 'I', 'Z', 'E', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'i', 'n',
                                't', 'e', 'g', 'e', 'r', '-', 'v', 'a',
                                'l', 'u', 'e', 'd', ' ', '(', 'c', 'l',
                                'a', 's', 's', ' ', 'd', 'o', 'u', 'b',
                                'l', 'e', ')', ' ', 'a', 'n', 'd', ' ',
                                'f', 'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray90_;

static mxChar _array93_[55] = { 'A', 'l', 'l', ' ', 'v', 'a', 'l', 'u',
                                'e', 's', ' ', 'i', 'n', ' ', 'T', 'S',
                                'I', 'Z', 'E', ' ', 'm', 'u', 's', 't',
                                ' ', 'b', 'e', ' ', 'g', 'r', 'e', 'a',
                                't', 'e', 'r', ' ', 't', 'h', 'a', 'n',
                                ' ', 'o', 'r', ' ', 'e', 'q', 'u', 'a',
                                'l', ' ', 't', 'o', ' ', '1', '.' };
static mxArray * _mxarray92_;

static mxChar _array95_[49] = { 'L', 'O', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'r', 'e', 'a', 'l', '-', 'v', 'a',
                                'l', 'u', 'e', 'd', ' ', '(', 'c', 'l', 'a',
                                's', 's', ' ', 'd', 'o', 'u', 'b', 'l', 'e',
                                ')', ' ', 'a', 'n', 'd', ' ', 'f', 'i', 'n',
                                'i', 't', 'e', '.' };
static mxArray * _mxarray94_;

static mxChar _array97_[49] = { 'H', 'I', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'r', 'e', 'a', 'l', '-', 'v', 'a',
                                'l', 'u', 'e', 'd', ' ', '(', 'c', 'l', 'a',
                                's', 's', ' ', 'd', 'o', 'u', 'b', 'l', 'e',
                                ')', ' ', 'a', 'n', 'd', ' ', 'f', 'i', 'n',
                                'i', 't', 'e', '.' };
static mxArray * _mxarray96_;

static mxChar _array99_[42] = { 'T', 'S', 'I', 'Z', 'E', ',', ' ', 'L', 'O',
                                ',', ' ', 'a', 'n', 'd', ' ', 'H', 'I', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 't',
                                'h', 'e', ' ', 's', 'a', 'm', 'e', ' ', 'l',
                                'e', 'n', 'g', 't', 'h', '.' };
static mxArray * _mxarray98_;

static mxChar _array101_[74] = { 'T', 'h', 'e', ' ', 'c', 'o', 'r', 'r', 'e',
                                 's', 'p', 'o', 'n', 'd', 'i', 'n', 'g', ' ',
                                 'e', 'n', 't', 'r', 'i', 'e', 's', ' ', 'i',
                                 'n', ' ', 'L', 'O', ' ', 'a', 'n', 'd', ' ',
                                 'H', 'I', ' ', 'm', 'a', 'y', ' ', 'n', 'o',
                                 't', ' ', 'b', 'e', ' ', 'e', 'q', 'u', 'a',
                                 'l', ' ', 'u', 'n', 'l', 'e', 's', 's', ' ',
                                 'T', 'S', 'I', 'Z', 'E', ' ', 'i', 's', ' ',
                                 '1', '.' };
static mxArray * _mxarray100_;

static mxChar _array103_[33] = { 'I', 'N', 'B', 'O', 'U', 'N', 'D', 'S', ' ',
                                 'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'r',
                                 'e', 'a', 'l', ' ', 'a', 'n', 'd', ' ', 'f',
                                 'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray102_;

static mxChar _array105_[34] = { 'O', 'U', 'T', 'B', 'O', 'U', 'N', 'D', 'S',
                                 ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                 'r', 'e', 'a', 'l', ' ', 'a', 'n', 'd', ' ',
                                 'f', 'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray104_;

static mxChar _array107_[55] = { 'I', 'N', 'B', 'O', 'U', 'N', 'D', 'S',
                                 ' ', 'a', 'n', 'd', ' ', 'O', 'U', 'T',
                                 'B', 'O', 'U', 'N', 'D', 'S', ' ', 'm',
                                 'u', 's', 't', ' ', 'b', 'e', ' ', '2',
                                 '-', 'b', 'y', '-', 'N', ' ', '(', 'f',
                                 'o', 'r', ' ', 't', 'h', 'e', ' ', 's',
                                 'a', 'm', 'e', ' ', 'N', ')', '.' };
static mxArray * _mxarray106_;

static mxChar _array109_[90] = { 'O', 'U', 'T', 'B', 'O', 'U', 'N', 'D', 'S',
                                 '(', '1', ',', 'k', ')', ' ', 'm', 'a', 'y',
                                 ' ', 'e', 'q', 'u', 'a', 'l', ' ', 'O', 'U',
                                 'T', 'B', 'O', 'U', 'N', 'D', 'S', '(', '2',
                                 ',', 'k', ')', ' ', 'i', 'f', ' ', 'a', 'n',
                                 'd', ' ', 'o', 'n', 'l', 'y', ' ', 'i', 'f',
                                 ' ', 'I', 'N', 'B', 'O', 'U', 'N', 'D', 'S',
                                 '(', '1', ',', 'k', ')', ' ', 'e', 'q', 'u',
                                 'a', 'l', 's', ' ', 'I', 'N', 'B', 'O', 'U',
                                 'N', 'D', 'S', '(', '2', ',', 'k', ')', '.' };
static mxArray * _mxarray108_;

static mxChar _array111_[31] = { 'T', 'R', 'A', 'N', 'S', 'F', 'O', 'R',
                                 'M', 'T', 'Y', 'P', 'E', ' ', 'm', 'u',
                                 's', 't', ' ', 'b', 'e', ' ', 'a', ' ',
                                 's', 't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray110_;

static mxArray * _array113_[5] = { NULL /*_mxarray2_*/, NULL /*_mxarray4_*/,
                                   NULL /*_mxarray6_*/, NULL /*_mxarray8_*/,
                                   NULL /*_mxarray10_*/ };
static mxArray * _mxarray112_;

static mxChar _array115_[28] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                 'i', 'z', 'e', 'd', ' ', 'T', 'R', 'A',
                                 'N', 'S', 'F', 'O', 'R', 'M', 'T', 'Y',
                                 'P', 'E', ' ', 0x0027 };
static mxArray * _mxarray114_;

static mxChar _array117_[2] = { 0x0027, '.' };
static mxArray * _mxarray116_;

static mxChar _array119_[25] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                 ' ', 'T', 'R', 'A', 'N', 'S', 'F', 'O', 'R',
                                 'M', 'T', 'Y', 'P', 'E', ' ', 0x0027 };
static mxArray * _mxarray118_;
static mxArray * _mxarray120_;
static mxArray * _mxarray121_;

void InitializeModule_maketform(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _ieee_plusinf_ = mclGetInf();
    _mxarray1_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _mxarray4_ = mclInitializeString(10, _array5_);
    _mxarray6_ = mclInitializeString(9, _array7_);
    _mxarray8_ = mclInitializeString(6, _array9_);
    _mxarray10_ = mclInitializeString(3, _array11_);
    _mxarray12_ = mclInitializeString(23, _array13_);
    _mxarray14_ = mclInitializeString(1, _array15_);
    _mxarray16_ = mclInitializeDouble(2.0);
    _mxarray17_ = mclInitializeDoubleVector(3, 1, _array18_);
    _mxarray19_ = mclInitializeDouble(3.0);
    _mxarray20_ = mclInitializeDouble(0.0);
    _mxarray21_ = mclInitializeString(7, _array22_);
    _mxarray23_ = mclInitializeString(7, _array24_);
    _mxarray25_ = mclInitializeString(48, _array26_);
    _mxarray27_ = mclInitializeString(47, _array28_);
    _mxarray29_ = mclInitializeString(6, _array30_);
    _mxarray31_ = mclInitializeString(33, _array32_);
    _mxarray33_ = mclInitializeString(37, _array34_);
    _mxarray35_ = mclInitializeString(79, _array36_);
    _mxarray37_ = mclInitializeDouble(2.220446049250313e-14);
    _mxarray38_ = mclInitializeString(44, _array39_);
    _mxarray40_ = mclInitializeString(29, _array41_);
    _mxarray42_ = mclInitializeDouble(4.0);
    _mxarray43_ = mclInitializeString(18, _array44_);
    _mxarray45_ = mclInitializeString(18, _array46_);
    _mxarray47_ = mclInitializeString(48, _array48_);
    _mxarray49_ = mclInitializeString(48, _array50_);
    _mxarray51_ = mclInitializeString(53, _array52_);
    _mxarray53_ = mclInitializeString(53, _array54_);
    _mxarray55_ = mclInitializeString(44, _array56_);
    _mxarray57_ = mclInitializeString(38, _array58_);
    _mxarray59_ = mclInitializeString(26, _array60_);
    _mxarray61_ = mclInitializeString(51, _array62_);
    _mxarray63_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray64_ = mclInitializeString(43, _array65_);
    _mxarray66_ = mclInitializeString(49, _array67_);
    _mxarray68_ = mclInitializeString(7, _array69_);
    _mxarray70_ = mclInitializeString(61, _array71_);
    _mxarray72_ = mclInitializeDouble(-1.0);
    _mxarray73_ = mclInitializeDouble(5.0);
    _mxarray74_ = mclInitializeString(49, _array75_);
    _mxarray76_ = mclInitializeString(50, _array77_);
    _mxarray78_ = mclInitializeString(26, _array79_);
    _mxarray80_ = mclInitializeString(27, _array81_);
    _mxarray82_ = mclInitializeString(15, _array83_);
    _mxarray84_ = mclInitializeString(38, _array85_);
    _mxarray86_ = mclInitializeString(38, _array87_);
    _mxarray88_ = mclInitializeString(49, _array89_);
    _mxarray90_ = mclInitializeString(55, _array91_);
    _mxarray92_ = mclInitializeString(55, _array93_);
    _mxarray94_ = mclInitializeString(49, _array95_);
    _mxarray96_ = mclInitializeString(49, _array97_);
    _mxarray98_ = mclInitializeString(42, _array99_);
    _mxarray100_ = mclInitializeString(74, _array101_);
    _mxarray102_ = mclInitializeString(33, _array103_);
    _mxarray104_ = mclInitializeString(34, _array105_);
    _mxarray106_ = mclInitializeString(55, _array107_);
    _mxarray108_ = mclInitializeString(90, _array109_);
    _mxarray110_ = mclInitializeString(31, _array111_);
    _array113_[0] = _mxarray2_;
    _array113_[1] = _mxarray4_;
    _array113_[2] = _mxarray6_;
    _array113_[3] = _mxarray8_;
    _array113_[4] = _mxarray10_;
    _mxarray112_ = mclInitializeCellVector(1, 5, _array113_);
    _mxarray114_ = mclInitializeString(28, _array115_);
    _mxarray116_ = mclInitializeString(2, _array117_);
    _mxarray118_ = mclInitializeString(25, _array119_);
    _mxarray120_ = mclInitializeLogical(false);
    _mxarray121_ = mclInitializeDouble(1e+09);
}

void TerminateModule_maketform(void) {
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray120_);
    mxDestroyArray(_mxarray118_);
    mxDestroyArray(_mxarray116_);
    mxDestroyArray(_mxarray114_);
    mxDestroyArray(_mxarray112_);
    mxDestroyArray(_mxarray110_);
    mxDestroyArray(_mxarray108_);
    mxDestroyArray(_mxarray106_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray98_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfMaketform_assigntform(mxArray * ndims_in,
                                          mxArray * ndims_out,
                                          mxArray * forward_fcn,
                                          mxArray * inverse_fcn,
                                          mxArray * tdata);
static void mlxMaketform_assigntform(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfMaketform_affine(mxArray * synthetic_varargin_argument,
                                     ...);
static void mlxMaketform_affine(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static mxArray * mlfMaketform_inv_affine(mxArray * X, mxArray * t);
static void mlxMaketform_inv_affine(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfMaketform_fwd_affine(mxArray * U, mxArray * t);
static void mlxMaketform_fwd_affine(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfMaketform_trans_affine(mxArray * X,
                                           mxArray * t,
                                           mxArray * direction);
static void mlxMaketform_trans_affine(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static mxArray * mlfMaketform_projective(mxArray * synthetic_varargin_argument,
                                         ...);
static void mlxMaketform_projective(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfMaketform_inv_projective(mxArray * X, mxArray * t);
static void mlxMaketform_inv_projective(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfMaketform_fwd_projective(mxArray * U, mxArray * t);
static void mlxMaketform_fwd_projective(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfMaketform_trans_projective(mxArray * X,
                                               mxArray * t,
                                               mxArray * direction);
static void mlxMaketform_trans_projective(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMaketform_validate_matrix(mxArray * A_in,
                                              mxArray * transform_type);
static void mlxMaketform_validate_matrix(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfMaketform_construct_matrix(mxArray * U,
                                               mxArray * X,
                                               mxArray * transform_type);
static void mlxMaketform_construct_matrix(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMaketform_UnitToTriangle(mxArray * X);
static void mlxMaketform_UnitToTriangle(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfMaketform_UnitToQuadrilateral(mxArray * X);
static void mlxMaketform_UnitToQuadrilateral(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static mxArray * mlfMaketform_composite(mxArray * synthetic_varargin_argument,
                                        ...);
static void mlxMaketform_composite(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * mlfMaketform_fwd_composite(mxArray * U, mxArray * t);
static void mlxMaketform_fwd_composite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfMaketform_inv_composite(mxArray * X, mxArray * t);
static void mlxMaketform_inv_composite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfMaketform_custom(mxArray * synthetic_varargin_argument,
                                     ...);
static void mlxMaketform_custom(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static mxArray * mlfMaketform_box(mxArray * synthetic_varargin_argument, ...);
static void mlxMaketform_box(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]);
static mxArray * mlfMaketform_box2(mxArray * inBounds, mxArray * outBounds);
static void mlxMaketform_box2(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]);
static mxArray * mlfMaketform_getTransformType(mxArray * type);
static void mlxMaketform_getTransformType(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMaketform_isfinitedouble(mxArray * x);
static void mlxMaketform_isfinitedouble(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfMaketform_isdoubleinteger(mxArray * x);
static void mlxMaketform_isdoubleinteger(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfMaketform_condlimit(void);
static void mlxMaketform_condlimit(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * Mmaketform(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_assigntform(int nargout_,
                                        mxArray * ndims_in,
                                        mxArray * ndims_out,
                                        mxArray * forward_fcn,
                                        mxArray * inverse_fcn,
                                        mxArray * tdata);
static mxArray * Mmaketform_affine(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_inv_affine(int nargout_, mxArray * X, mxArray * t);
static mxArray * Mmaketform_fwd_affine(int nargout_, mxArray * U, mxArray * t);
static mxArray * Mmaketform_trans_affine(int nargout_,
                                         mxArray * X,
                                         mxArray * t,
                                         mxArray * direction);
static mxArray * Mmaketform_projective(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_inv_projective(int nargout_,
                                           mxArray * X,
                                           mxArray * t);
static mxArray * Mmaketform_fwd_projective(int nargout_,
                                           mxArray * U,
                                           mxArray * t);
static mxArray * Mmaketform_trans_projective(int nargout_,
                                             mxArray * X,
                                             mxArray * t,
                                             mxArray * direction);
static mxArray * Mmaketform_validate_matrix(int nargout_,
                                            mxArray * A_in,
                                            mxArray * transform_type);
static mxArray * Mmaketform_construct_matrix(int nargout_,
                                             mxArray * U,
                                             mxArray * X,
                                             mxArray * transform_type);
static mxArray * Mmaketform_UnitToTriangle(int nargout_, mxArray * X);
static mxArray * Mmaketform_UnitToQuadrilateral(int nargout_, mxArray * X);
static mxArray * Mmaketform_composite(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_fwd_composite(int nargout_,
                                          mxArray * U,
                                          mxArray * t);
static mxArray * Mmaketform_inv_composite(int nargout_,
                                          mxArray * X,
                                          mxArray * t);
static mxArray * Mmaketform_custom(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_box(int nargout_, mxArray * varargin);
static mxArray * Mmaketform_box2(int nargout_,
                                 mxArray * inBounds,
                                 mxArray * outBounds);
static mxArray * Mmaketform_getTransformType(int nargout_, mxArray * type);
static mxArray * Mmaketform_isfinitedouble(int nargout_, mxArray * x);
static mxArray * Mmaketform_isdoubleinteger(int nargout_, mxArray * x);
static mxArray * Mmaketform_condlimit(int nargout_);

static mexFunctionTableEntry local_function_table_[23]
  = { { "assigntform", mlxMaketform_assigntform, 5, 1, NULL },
      { "affine", mlxMaketform_affine, -1, 1, NULL },
      { "inv_affine", mlxMaketform_inv_affine, 2, 1, NULL },
      { "fwd_affine", mlxMaketform_fwd_affine, 2, 1, NULL },
      { "trans_affine", mlxMaketform_trans_affine, 3, 1, NULL },
      { "projective", mlxMaketform_projective, -1, 1, NULL },
      { "inv_projective", mlxMaketform_inv_projective, 2, 1, NULL },
      { "fwd_projective", mlxMaketform_fwd_projective, 2, 1, NULL },
      { "trans_projective", mlxMaketform_trans_projective, 3, 1, NULL },
      { "validate_matrix", mlxMaketform_validate_matrix, 2, 1, NULL },
      { "construct_matrix", mlxMaketform_construct_matrix, 3, 1, NULL },
      { "UnitToTriangle", mlxMaketform_UnitToTriangle, 1, 1, NULL },
      { "UnitToQuadrilateral", mlxMaketform_UnitToQuadrilateral, 1, 1, NULL },
      { "composite", mlxMaketform_composite, -1, 1, NULL },
      { "fwd_composite", mlxMaketform_fwd_composite, 2, 1, NULL },
      { "inv_composite", mlxMaketform_inv_composite, 2, 1, NULL },
      { "custom", mlxMaketform_custom, -1, 1, NULL },
      { "box", mlxMaketform_box, -1, 1, NULL },
      { "box2", mlxMaketform_box2, 2, 1, NULL },
      { "getTransformType", mlxMaketform_getTransformType, 1, 1, NULL },
      { "isfinitedouble", mlxMaketform_isfinitedouble, 1, 1, NULL },
      { "isdoubleinteger", mlxMaketform_isdoubleinteger, 1, 1, NULL },
      { "condlimit", mlxMaketform_condlimit, 0, 1, NULL } };

_mexLocalFunctionTable _local_function_table_maketform
  = { 23, local_function_table_ };

/*
 * The function "mlfMaketform" contains the normal interface for the
 * "maketform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 1-126). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfMaketform(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform" contains the feval interface for the "maketform"
 * M-function from file "k:\matlab6p5\toolbox\images\images\maketform.m" (lines
 * 1-126). The feval function calls the implementation version of maketform
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxMaketform(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform Line: 1 Column:"
            " 1 The function \"maketform\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_assigntform" contains the normal interface for
 * the "maketform/assigntform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 126-139). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_assigntform(mxArray * ndims_in,
                                          mxArray * ndims_out,
                                          mxArray * forward_fcn,
                                          mxArray * inverse_fcn,
                                          mxArray * tdata) {
    int nargout = 1;
    mxArray * t = NULL;
    mlfEnterNewContext(
      0, 5, ndims_in, ndims_out, forward_fcn, inverse_fcn, tdata);
    t
      = Mmaketform_assigntform(
          nargout, ndims_in, ndims_out, forward_fcn, inverse_fcn, tdata);
    mlfRestorePreviousContext(
      0, 5, ndims_in, ndims_out, forward_fcn, inverse_fcn, tdata);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_assigntform" contains the feval interface for the
 * "maketform/assigntform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 126-139). The feval
 * function calls the implementation version of maketform/assigntform through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_assigntform(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[5];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/assigntform Line: 126 Co"
            "lumn: 1 The function \"maketform/assigntform\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/assigntform Line: 126 C"
            "olumn: 1 The function \"maketform/assigntform\" was cal"
            "led with more than the declared number of inputs (5)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 5 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 5; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mplhs[0]
      = Mmaketform_assigntform(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mlfRestorePreviousContext(
      0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_affine" contains the normal interface for the
 * "maketform/affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 139-172). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_affine(mxArray * synthetic_varargin_argument,
                                     ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform_affine(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_affine" contains the feval interface for the
 * "maketform/affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 139-172). The feval
 * function calls the implementation version of maketform/affine through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxMaketform_affine(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/affine Line: 139 Col"
            "umn: 1 The function \"maketform/affine\" was called "
            "with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform_affine(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_inv_affine" contains the normal interface for the
 * "maketform/inv_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 172-183). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_inv_affine(mxArray * X, mxArray * t) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 2, X, t);
    U = Mmaketform_inv_affine(nargout, X, t);
    mlfRestorePreviousContext(0, 2, X, t);
    return mlfReturnValue(U);
}

/*
 * The function "mlxMaketform_inv_affine" contains the feval interface for the
 * "maketform/inv_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 172-183). The feval
 * function calls the implementation version of maketform/inv_affine through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_inv_affine(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_affine Line: 172 Co"
            "lumn: 1 The function \"maketform/inv_affine\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_affine Line: 172 Co"
            "lumn: 1 The function \"maketform/inv_affine\" was calle"
            "d with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_inv_affine(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_fwd_affine" contains the normal interface for the
 * "maketform/fwd_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 183-194). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_fwd_affine(mxArray * U, mxArray * t) {
    int nargout = 1;
    mxArray * X = NULL;
    mlfEnterNewContext(0, 2, U, t);
    X = Mmaketform_fwd_affine(nargout, U, t);
    mlfRestorePreviousContext(0, 2, U, t);
    return mlfReturnValue(X);
}

/*
 * The function "mlxMaketform_fwd_affine" contains the feval interface for the
 * "maketform/fwd_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 183-194). The feval
 * function calls the implementation version of maketform/fwd_affine through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_fwd_affine(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_affine Line: 183 Co"
            "lumn: 1 The function \"maketform/fwd_affine\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_affine Line: 183 Co"
            "lumn: 1 The function \"maketform/fwd_affine\" was calle"
            "d with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_fwd_affine(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_trans_affine" contains the normal interface for
 * the "maketform/trans_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 194-216). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_trans_affine(mxArray * X,
                                           mxArray * t,
                                           mxArray * direction) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 3, X, t, direction);
    U = Mmaketform_trans_affine(nargout, X, t, direction);
    mlfRestorePreviousContext(0, 3, X, t, direction);
    return mlfReturnValue(U);
}

/*
 * The function "mlxMaketform_trans_affine" contains the feval interface for
 * the "maketform/trans_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 194-216). The feval
 * function calls the implementation version of maketform/trans_affine through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_trans_affine(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/trans_affine Line: 194 C"
            "olumn: 1 The function \"maketform/trans_affine\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/trans_affine Line: 194 C"
            "olumn: 1 The function \"maketform/trans_affine\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mmaketform_trans_affine(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_projective" contains the normal interface for the
 * "maketform/projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 216-244). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_projective(mxArray * synthetic_varargin_argument,
                                         ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform_projective(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_projective" contains the feval interface for the
 * "maketform/projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 216-244). The feval
 * function calls the implementation version of maketform/projective through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_projective(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/projective Line: 216 Co"
            "lumn: 1 The function \"maketform/projective\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform_projective(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_inv_projective" contains the normal interface for
 * the "maketform/inv_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 244-255). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_inv_projective(mxArray * X, mxArray * t) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 2, X, t);
    U = Mmaketform_inv_projective(nargout, X, t);
    mlfRestorePreviousContext(0, 2, X, t);
    return mlfReturnValue(U);
}

/*
 * The function "mlxMaketform_inv_projective" contains the feval interface for
 * the "maketform/inv_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 244-255). The feval
 * function calls the implementation version of maketform/inv_projective
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_inv_projective(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_projective Line: 244 C"
            "olumn: 1 The function \"maketform/inv_projective\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_projective Line: 244 "
            "Column: 1 The function \"maketform/inv_projective\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_inv_projective(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_fwd_projective" contains the normal interface for
 * the "maketform/fwd_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 255-266). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_fwd_projective(mxArray * U, mxArray * t) {
    int nargout = 1;
    mxArray * X = NULL;
    mlfEnterNewContext(0, 2, U, t);
    X = Mmaketform_fwd_projective(nargout, U, t);
    mlfRestorePreviousContext(0, 2, U, t);
    return mlfReturnValue(X);
}

/*
 * The function "mlxMaketform_fwd_projective" contains the feval interface for
 * the "maketform/fwd_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 255-266). The feval
 * function calls the implementation version of maketform/fwd_projective
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_fwd_projective(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_projective Line: 255 C"
            "olumn: 1 The function \"maketform/fwd_projective\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_projective Line: 255 "
            "Column: 1 The function \"maketform/fwd_projective\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_fwd_projective(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_trans_projective" contains the normal interface
 * for the "maketform/trans_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 266-290). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_trans_projective(mxArray * X,
                                               mxArray * t,
                                               mxArray * direction) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 3, X, t, direction);
    U = Mmaketform_trans_projective(nargout, X, t, direction);
    mlfRestorePreviousContext(0, 3, X, t, direction);
    return mlfReturnValue(U);
}

/*
 * The function "mlxMaketform_trans_projective" contains the feval interface
 * for the "maketform/trans_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 266-290). The feval
 * function calls the implementation version of maketform/trans_projective
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_trans_projective(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/trans_projective Line: 266 "
            "Column: 1 The function \"maketform/trans_projective\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/trans_projective Line: 266 "
            "Column: 1 The function \"maketform/trans_projective\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mmaketform_trans_projective(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_validate_matrix" contains the normal interface
 * for the "maketform/validate_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 290-331). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_validate_matrix(mxArray * A_in,
                                              mxArray * transform_type) {
    int nargout = 1;
    mxArray * A = NULL;
    mlfEnterNewContext(0, 2, A_in, transform_type);
    A = Mmaketform_validate_matrix(nargout, A_in, transform_type);
    mlfRestorePreviousContext(0, 2, A_in, transform_type);
    return mlfReturnValue(A);
}

/*
 * The function "mlxMaketform_validate_matrix" contains the feval interface for
 * the "maketform/validate_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 290-331). The feval
 * function calls the implementation version of maketform/validate_matrix
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_validate_matrix(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/validate_matrix Line: 290 "
            "Column: 1 The function \"maketform/validate_matrix\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/validate_matrix Line: 290 "
            "Column: 1 The function \"maketform/validate_matrix\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_validate_matrix(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_construct_matrix" contains the normal interface
 * for the "maketform/construct_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 331-387). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_construct_matrix(mxArray * U,
                                               mxArray * X,
                                               mxArray * transform_type) {
    int nargout = 1;
    mxArray * A = NULL;
    mlfEnterNewContext(0, 3, U, X, transform_type);
    A = Mmaketform_construct_matrix(nargout, U, X, transform_type);
    mlfRestorePreviousContext(0, 3, U, X, transform_type);
    return mlfReturnValue(A);
}

/*
 * The function "mlxMaketform_construct_matrix" contains the feval interface
 * for the "maketform/construct_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 331-387). The feval
 * function calls the implementation version of maketform/construct_matrix
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_construct_matrix(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/construct_matrix Line: 331 "
            "Column: 1 The function \"maketform/construct_matrix\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/construct_matrix Line: 331 "
            "Column: 1 The function \"maketform/construct_matrix\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mmaketform_construct_matrix(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_UnitToTriangle" contains the normal interface for
 * the "maketform/UnitToTriangle" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 387-401). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_UnitToTriangle(mxArray * X) {
    int nargout = 1;
    mxArray * A = NULL;
    mlfEnterNewContext(0, 1, X);
    A = Mmaketform_UnitToTriangle(nargout, X);
    mlfRestorePreviousContext(0, 1, X);
    return mlfReturnValue(A);
}

/*
 * The function "mlxMaketform_UnitToTriangle" contains the feval interface for
 * the "maketform/UnitToTriangle" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 387-401). The feval
 * function calls the implementation version of maketform/UnitToTriangle
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_UnitToTriangle(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/UnitToTriangle Line: 387 C"
            "olumn: 1 The function \"maketform/UnitToTriangle\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/UnitToTriangle Line: 387 "
            "Column: 1 The function \"maketform/UnitToTriangle\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmaketform_UnitToTriangle(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_UnitToQuadrilateral" contains the normal
 * interface for the "maketform/UnitToQuadrilateral" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 401-448). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_UnitToQuadrilateral(mxArray * X) {
    int nargout = 1;
    mxArray * A = NULL;
    mlfEnterNewContext(0, 1, X);
    A = Mmaketform_UnitToQuadrilateral(nargout, X);
    mlfRestorePreviousContext(0, 1, X);
    return mlfReturnValue(A);
}

/*
 * The function "mlxMaketform_UnitToQuadrilateral" contains the feval interface
 * for the "maketform/UnitToQuadrilateral" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 401-448). The feval
 * function calls the implementation version of maketform/UnitToQuadrilateral
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_UnitToQuadrilateral(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/UnitToQuadrilateral Line: 401"
            " Column: 1 The function \"maketform/UnitToQuadrilateral\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/UnitToQuadrilateral Line: 401"
            " Column: 1 The function \"maketform/UnitToQuadrilateral\" was"
            " called with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmaketform_UnitToQuadrilateral(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_composite" contains the normal interface for the
 * "maketform/composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 448-510). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_composite(mxArray * synthetic_varargin_argument,
                                        ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform_composite(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_composite" contains the feval interface for the
 * "maketform/composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 448-510). The feval
 * function calls the implementation version of maketform/composite through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_composite(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/composite Line: 448 Co"
            "lumn: 1 The function \"maketform/composite\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform_composite(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_fwd_composite" contains the normal interface for
 * the "maketform/fwd_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 510-525). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_fwd_composite(mxArray * U, mxArray * t) {
    int nargout = 1;
    mxArray * X = NULL;
    mlfEnterNewContext(0, 2, U, t);
    X = Mmaketform_fwd_composite(nargout, U, t);
    mlfRestorePreviousContext(0, 2, U, t);
    return mlfReturnValue(X);
}

/*
 * The function "mlxMaketform_fwd_composite" contains the feval interface for
 * the "maketform/fwd_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 510-525). The feval
 * function calls the implementation version of maketform/fwd_composite through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_fwd_composite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_composite Line: 510 C"
            "olumn: 1 The function \"maketform/fwd_composite\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/fwd_composite Line: 510 C"
            "olumn: 1 The function \"maketform/fwd_composite\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_fwd_composite(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_inv_composite" contains the normal interface for
 * the "maketform/inv_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 525-540). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_inv_composite(mxArray * X, mxArray * t) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 2, X, t);
    U = Mmaketform_inv_composite(nargout, X, t);
    mlfRestorePreviousContext(0, 2, X, t);
    return mlfReturnValue(U);
}

/*
 * The function "mlxMaketform_inv_composite" contains the feval interface for
 * the "maketform/inv_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 525-540). The feval
 * function calls the implementation version of maketform/inv_composite through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_inv_composite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_composite Line: 525 C"
            "olumn: 1 The function \"maketform/inv_composite\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/inv_composite Line: 525 C"
            "olumn: 1 The function \"maketform/inv_composite\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_inv_composite(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_custom" contains the normal interface for the
 * "maketform/custom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 540-590). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_custom(mxArray * synthetic_varargin_argument,
                                     ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform_custom(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_custom" contains the feval interface for the
 * "maketform/custom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 540-590). The feval
 * function calls the implementation version of maketform/custom through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxMaketform_custom(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/custom Line: 540 Col"
            "umn: 1 The function \"maketform/custom\" was called "
            "with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform_custom(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_box" contains the normal interface for the
 * "maketform/box" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 590-646). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_box(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * t = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    t = Mmaketform_box(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_box" contains the feval interface for the
 * "maketform/box" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 590-646). The feval
 * function calls the implementation version of maketform/box through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxMaketform_box(int nlhs,
                             mxArray * plhs[],
                             int nrhs,
                             mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/box Line: 590 Colu"
            "mn: 1 The function \"maketform/box\" was called wi"
            "th more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmaketform_box(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMaketform_box2" contains the normal interface for the
 * "maketform/box2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 646-691). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_box2(mxArray * inBounds, mxArray * outBounds) {
    int nargout = 1;
    mxArray * t = NULL;
    mlfEnterNewContext(0, 2, inBounds, outBounds);
    t = Mmaketform_box2(nargout, inBounds, outBounds);
    mlfRestorePreviousContext(0, 2, inBounds, outBounds);
    return mlfReturnValue(t);
}

/*
 * The function "mlxMaketform_box2" contains the feval interface for the
 * "maketform/box2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 646-691). The feval
 * function calls the implementation version of maketform/box2 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxMaketform_box2(int nlhs,
                              mxArray * plhs[],
                              int nrhs,
                              mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/box2 Line: 646 Colu"
            "mn: 1 The function \"maketform/box2\" was called wi"
            "th more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/box2 Line: 646 Colu"
            "mn: 1 The function \"maketform/box2\" was called wi"
            "th more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmaketform_box2(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_getTransformType" contains the normal interface
 * for the "maketform/getTransformType" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 691-715). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_getTransformType(mxArray * type) {
    int nargout = 1;
    mxArray * transform_type = NULL;
    mlfEnterNewContext(0, 1, type);
    transform_type = Mmaketform_getTransformType(nargout, type);
    mlfRestorePreviousContext(0, 1, type);
    return mlfReturnValue(transform_type);
}

/*
 * The function "mlxMaketform_getTransformType" contains the feval interface
 * for the "maketform/getTransformType" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 691-715). The feval
 * function calls the implementation version of maketform/getTransformType
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_getTransformType(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/getTransformType Line: 691 "
            "Column: 1 The function \"maketform/getTransformType\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/getTransformType Line: 691 "
            "Column: 1 The function \"maketform/getTransformType\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmaketform_getTransformType(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_isfinitedouble" contains the normal interface for
 * the "maketform/isfinitedouble" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 715-726). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_isfinitedouble(mxArray * x) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, x);
    q = Mmaketform_isfinitedouble(nargout, x);
    mlfRestorePreviousContext(0, 1, x);
    return mlfReturnValue(q);
}

/*
 * The function "mlxMaketform_isfinitedouble" contains the feval interface for
 * the "maketform/isfinitedouble" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 715-726). The feval
 * function calls the implementation version of maketform/isfinitedouble
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_isfinitedouble(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/isfinitedouble Line: 715 C"
            "olumn: 1 The function \"maketform/isfinitedouble\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/isfinitedouble Line: 715 "
            "Column: 1 The function \"maketform/isfinitedouble\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmaketform_isfinitedouble(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_isdoubleinteger" contains the normal interface
 * for the "maketform/isdoubleinteger" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 726-739). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_isdoubleinteger(mxArray * x) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, x);
    q = Mmaketform_isdoubleinteger(nargout, x);
    mlfRestorePreviousContext(0, 1, x);
    return mlfReturnValue(q);
}

/*
 * The function "mlxMaketform_isdoubleinteger" contains the feval interface for
 * the "maketform/isdoubleinteger" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 726-739). The feval
 * function calls the implementation version of maketform/isdoubleinteger
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMaketform_isdoubleinteger(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/isdoubleinteger Line: 726 "
            "Column: 1 The function \"maketform/isdoubleinteger\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/isdoubleinteger Line: 726 "
            "Column: 1 The function \"maketform/isdoubleinteger\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmaketform_isdoubleinteger(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMaketform_condlimit" contains the normal interface for the
 * "maketform/condlimit" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 739-742). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMaketform_condlimit(void) {
    int nargout = 1;
    mxArray * limit = NULL;
    mlfEnterNewContext(0, 0);
    limit = Mmaketform_condlimit(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(limit);
}

/*
 * The function "mlxMaketform_condlimit" contains the feval interface for the
 * "maketform/condlimit" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 739-742). The feval
 * function calls the implementation version of maketform/condlimit through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxMaketform_condlimit(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/condlimit Line: 739 Co"
            "lumn: 1 The function \"maketform/condlimit\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: maketform/condlimit Line: 739 Co"
            "lumn: 1 The function \"maketform/condlimit\" was calle"
            "d with more than the declared number of inputs (0)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mmaketform_condlimit(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mmaketform" is the implementation version of the "maketform"
 * M-function from file "k:\matlab6p5\toolbox\images\images\maketform.m" (lines
 * 1-126). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = maketform( varargin )
 */
static mxArray * Mmaketform(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * fcn = NULL;
    mxArray * transform_type = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * % MAKETFORM Create geometric transformation structure.  T =
     * %   MAKETFORM(TRANSFORMTYPE,...) creates a multidimensional geometric
     * %   transformation structure (a 'TFORM struct') that can be used with
     * %   TFORMFWD, TFORMINV, FLIPTFORM, IMTRANSFORM, or TFORMARRAY.
     * %   TRANSFORMTYPE can be 'affine', 'projective', 'custom', 'box', or
     * %   'composite'.
     * %
     * %   T = MAKETFORM('affine',A) builds a TFORM struct for an N-dimensional
     * %   affine transformation.  A is a nonsingular real (N+1)-by-(N+1) or
     * %   (N+1)-by-N matrix.  If A is (N+1)-by-(N+1), then the last column
     * %   of A must be [zeros(N,1); 1].  Otherwise, A is augmented automatically
     * %   such that its last column is [zeros(N,1); 1].  A defines a forward
     * %   transformation such that TFORMFWD(U,T), where U is a 1-by-N vector,
     * %   returns a 1-by-N vector X such that X = U * A(1:N,1:N) + A(N+1,1:N).
     * %   T has both forward and inverse transformations.
     * %
     * %   T = MAKETFORM('projective',A) builds a TFORM struct for an N-dimensional
     * %   projective transformation.  A is a nonsingular real (N+1)-by-(N+1)
     * %   matrix.  A(N+1,N+1) cannot be 0.  A defines a forward transformation
     * %   such that TFORMFWD(U,T), where U is a 1-by-N vector, returns a 1-by-N
     * %   vector X such that X = W(1:N)/W(N+1), where W = [U 1] * A.  T has
     * %   both forward and inverse transformations.
     * %   
     * %   T = MAKETFORM('affine',U,X) builds a TFORM struct for a
     * %   two-dimensional affine transformation that maps each row of U
     * %   to the corresponding row of X.  U and X are each 3-by-2 and
     * %   define the corners of input and output triangles.  The corners
     * %   may not be collinear.
     * %
     * %   T = MAKETFORM('projective',U,X) builds a TFORM struct for a
     * %   two-dimensional projective transformation that maps each row of U
     * %   to the corresponding row of X.  U and X are each 4-by-2 and
     * %   define the corners of input and output quadrilaterals.  No three
     * %   corners may be collinear.
     * %
     * %   T = MAKETFORM('custom',NDIMS_IN,NDIMS_OUT,FORWARD_FCN,INVERSE_FCN,
     * %   TDATA) builds a custom TFORM struct based on user-provided function
     * %   handles and parameters.  NDIMS_IN and NDIMS_OUT are the numbers of
     * %   input and output dimensions.  FORWARD_FCN and INVERSE_FCN are
     * %   function handles to forward and inverse functions.  Those functions
     * %   must support the syntaxes X = FORWARD_FCN(U,T) and U =
     * %   INVERSE_FCN(X,T), where U is a P-by-NDIMS_IN matrix whose rows are
     * %   points in the transformation's input space, and X is a
     * %   P-by-NDIMS_OUT matrix whose rows are points in the transformation's
     * %   output space.  TDATA can be any MATLAB array and is typically used to
     * %   store parameters of the custom transformation.  It is accessible to
     * %   FORWARD_FCN and INVERSE_FNC via the "tdata" field of T.  Either
     * %   FORWARD_FCN or INVERSE_FCN can be empty, although at least
     * %   INVERSE_FCN must be defined to use T with TFORMARRAY or IMTRANSFORM.
     * %
     * %   T = MAKETFORM('composite',T1,T2,...,TL) or T = MAKETFORM('composite',
     * %   [T1 T2 ... TL]) builds a TFORM whose forward and inverse functions
     * %   are the functional compositions of the forward and inverse functions
     * %   of the T1, T2, ..., TL.  For example, if L = 3 then TFORMFWD(U,T) is
     * %   the same as TFORMFWD(TFORMFWD(TFORMFWD(U,T3),T2),T1).  The components
     * %   T1 through TL must be compatible in terms of the numbers of input and
     * %   output dimensions.  T has a defined forward transform function only
     * %   if all of the component transforms have defined forward transform
     * %   functions.  T has a defined inverse transform function only if all of
     * %   the component functions have defined inverse transform functions.
     * %
     * %   T = MAKETFORM('box',TSIZE,LOW,HIGH) or T = MAKETFORM('box',INBOUNDS,
     * %   OUTBOUNDS) builds an N-dimensional affine TFORM struct, T.  TSIZE is
     * %   an N-element vector of positive integers, and LOW and HIGH are also
     * %   N-element vectors.  The transformation maps an input "box" defined
     * %   by the opposite corners ONES(1,N) and TSIZE or, alternatively, by
     * %   corners INBOUNDS(1,:) and INBOUND(2,:) to an output box defined by
     * %   the opposite corners LOW and HIGH or OUTBOUNDS(1,:) and OUTBOUNDS(2,:).
     * %   LOW(K) and HIGH(K) must be different unless TSIZE(K) is 1, in which
     * %   case the affine scale factor along the K-th dimension is assumed to be
     * %   1.0.  Similarly, INBOUNDS(1,K) and INBOUNDS(2,K) must be different
     * %   unless OUTBOUNDS(1,K) and OUTBOUNDS(1,K) are the same, and vice versa.
     * %   The 'box' TFORM is typically used to register the row and column
     * %   subscripts of an image or array to some "world" coordinate system.
     * %
     * %   Example
     * %   -------
     * %   Make and apply an affine transformation.
     * %
     * %       T = maketform('affine',[.5 0 0; .5 2 0; 0 0 1]);
     * %       tformfwd([10 20],T)
     * %       I = imread('cameraman.tif');
     * %       I2 = imtransform(I,T);
     * %       imshow(I2)
     * %
     * %   See also FLIPTFORM, IMTRANSFORM, TFORMARRAY, TFORMFWD, TFORMINV.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.10 $ $Date: 2002/03/15 15:28:37 $
     * 
     * % Testing notes
     * % Syntaxes
     * %---------
     * % T = MAKETFORM( 'affine', A )
     * %
     * % A:        Numeric, non-singular, real square matrix (no Infs or Nans).
     * %           Last column must be be zero except for a one in the lower right corner.
     * 
     * message = nargchk(1,Inf,nargin);
     */
    mlfAssign(&message, mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * transform_type = getTransformType(varargin{1});
     */
    mlfAssign(
      &transform_type,
      mclFeval(
        mclValueVarargout(),
        mlxMaketform_getTransformType,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
        NULL));
    /*
     * 
     * switch transform_type
     */
    {
        mxArray * v_ = mclInitialize(mclVv(transform_type, "transform_type"));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 'affine'
             * fcn = @affine;
             */
            mlfAssign(
              &fcn,
              mclCreateSimpleFunctionHandle(mlxMaketform_affine, "affine"));
        /*
         * case 'projective'
         */
        } else if (mclSwitchCompare(v_, _mxarray4_)) {
            /*
             * fcn = @projective;
             */
            mlfAssign(
              &fcn,
              mclCreateSimpleFunctionHandle(
                mlxMaketform_projective, "projective"));
        /*
         * case 'composite'
         */
        } else if (mclSwitchCompare(v_, _mxarray6_)) {
            /*
             * fcn = @composite;
             */
            mlfAssign(
              &fcn,
              mclCreateSimpleFunctionHandle(
                mlxMaketform_composite, "composite"));
        /*
         * case 'custom'
         */
        } else if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * fcn = @custom;
             */
            mlfAssign(
              &fcn,
              mclCreateSimpleFunctionHandle(mlxMaketform_custom, "custom"));
        /*
         * case 'box'
         */
        } else if (mclSwitchCompare(v_, _mxarray10_)) {
            /*
             * fcn = @box;
             */
            mlfAssign(
              &fcn, mclCreateSimpleFunctionHandle(mlxMaketform_box, "box"));
        /*
         * otherwise
         */
        } else {
            /*
             * error(['Unknown TRANSFORMTYPE: ' varargin{1} '.']);
             */
            mlfError(
              mlfHorzcat(
                _mxarray12_,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                _mxarray14_,
                NULL),
              NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * t = feval(fcn,varargin{2:end});
     */
    mlfAssign(
      &t,
      mlfFeval(
        mclValueVarargout(),
        mclVv(fcn, "fcn"),
        mlfIndexRef(
          mclVa(varargin, "varargin"),
          "{?}",
          mlfColon(
            _mxarray16_,
            mlfEnd(mclVa(varargin, "varargin"), _mxarray0_, _mxarray0_),
            NULL)),
        NULL));
    mclValidateOutput(t, 1, nargout_, "t", "maketform");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(transform_type);
    mxDestroyArray(fcn);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_assigntform" is the implementation version of the
 * "maketform/assigntform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 126-139). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = assigntform(ndims_in, ndims_out, forward_fcn, inverse_fcn, tdata)
 */
static mxArray * Mmaketform_assigntform(int nargout_,
                                        mxArray * ndims_in,
                                        mxArray * ndims_out,
                                        mxArray * forward_fcn,
                                        mxArray * inverse_fcn,
                                        mxArray * tdata) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * t = NULL;
    mclCopyArray(&ndims_in);
    mclCopyArray(&ndims_out);
    mclCopyArray(&forward_fcn);
    mclCopyArray(&inverse_fcn);
    mclCopyArray(&tdata);
    /*
     * 
     * % Use this function to ensure consistency in the way we assign
     * % the fields of each TFORM struct.
     * 
     * t.ndims_in    = ndims_in;
     */
    mlfIndexAssign(&t, ".ndims_in", mclVa(ndims_in, "ndims_in"));
    /*
     * t.ndims_out   = ndims_out;
     */
    mlfIndexAssign(&t, ".ndims_out", mclVa(ndims_out, "ndims_out"));
    /*
     * t.forward_fcn = forward_fcn;
     */
    mlfIndexAssign(&t, ".forward_fcn", mclVa(forward_fcn, "forward_fcn"));
    /*
     * t.inverse_fcn = inverse_fcn;
     */
    mlfIndexAssign(&t, ".inverse_fcn", mclVa(inverse_fcn, "inverse_fcn"));
    /*
     * t.tdata       = tdata;
     */
    mlfIndexAssign(&t, ".tdata", mclVa(tdata, "tdata"));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/assigntform");
    mxDestroyArray(tdata);
    mxDestroyArray(inverse_fcn);
    mxDestroyArray(forward_fcn);
    mxDestroyArray(ndims_out);
    mxDestroyArray(ndims_in);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_affine" is the implementation version of the
 * "maketform/affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 139-172). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = affine( varargin )
 */
static mxArray * Mmaketform_affine(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * tdata = NULL;
    mxArray * N = NULL;
    mxArray * A = NULL;
    mxArray * X = NULL;
    mxArray * U = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % Build an affine TFORM struct.
     * 
     * message = nargchk(1,2,nargin);
     */
    mlfAssign(
      &message, mlfNargchk(_mxarray0_, _mxarray16_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if nargin == 2
     */
    if (nargin_ == 2) {
        /*
         * % Construct a 3-by-3 2-D affine transformation matrix A
         * % that maps the three points in X to the three points in U.
         * U = varargin{1};
         */
        mlfAssign(
          &U, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * X = varargin{2};
         */
        mlfAssign(
          &X, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * A = construct_matrix( U, X, 'affine' ); 
         */
        mlfAssign(
          &A,
          mlfMaketform_construct_matrix(
            mclVv(U, "U"), mclVv(X, "X"), _mxarray2_));
        /*
         * A(:,3) = [0 0 1]';  % Clean up noise before validating A.
         */
        mclArrayAssign2(&A, _mxarray17_, mlfCreateColonIndex(), _mxarray19_);
    /*
     * else
     */
    } else {
        /*
         * A = varargin{1};
         */
        mlfAssign(
          &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
    /*
     * end
     */
    }
    /*
     * A = validate_matrix( A, 'affine' );
     */
    mlfAssign(&A, mlfMaketform_validate_matrix(mclVv(A, "A"), _mxarray2_));
    /*
     * 
     * N = size(A,2) - 1;
     */
    mlfAssign(
      &N,
      mclMinus(
        mlfSize(mclValueVarargout(), mclVv(A, "A"), _mxarray16_), _mxarray0_));
    /*
     * tdata.T    = A;
     */
    mlfIndexAssign(&tdata, ".T", mclVv(A, "A"));
    /*
     * tdata.Tinv = inv(A);
     */
    mlfIndexAssign(&tdata, ".Tinv", mlfInv(mclVv(A, "A")));
    /*
     * 
     * % In case of numerical noise, coerce the inverse into the proper form.
     * tdata.Tinv(1:end-1,end) = 0;
     */
    mlfIndexAssign(
      &tdata,
      ".Tinv(?,?)",
      mlfColon(
        _mxarray0_,
        mclMinus(
          mclFeval(
            mclValueVarargout(),
            mlxEnd,
            mlfIndexRef(mclVv(tdata, "tdata"), ".Tinv"),
            _mxarray0_,
            _mxarray16_,
            NULL),
          _mxarray0_),
        NULL),
      mclFeval(
        mclValueVarargout(),
        mlxEnd,
        mlfIndexRef(mclVv(tdata, "tdata"), ".Tinv"),
        _mxarray16_,
        _mxarray16_,
        NULL),
      _mxarray20_);
    /*
     * tdata.Tinv(end,end) = 1;
     */
    mlfIndexAssign(
      &tdata,
      ".Tinv(?,?)",
      mclFeval(
        mclValueVarargout(),
        mlxEnd,
        mlfIndexRef(mclVv(tdata, "tdata"), ".Tinv"),
        _mxarray0_,
        _mxarray16_,
        NULL),
      mclFeval(
        mclValueVarargout(),
        mlxEnd,
        mlfIndexRef(mclVv(tdata, "tdata"), ".Tinv"),
        _mxarray16_,
        _mxarray16_,
        NULL),
      _mxarray0_);
    /*
     * 
     * t = assigntform(N, N, @fwd_affine, @inv_affine, tdata);
     */
    mlfAssign(
      &t,
      mlfMaketform_assigntform(
        mclVv(N, "N"),
        mclVv(N, "N"),
        mclCreateSimpleFunctionHandle(mlxMaketform_fwd_affine, "fwd_affine"),
        mclCreateSimpleFunctionHandle(mlxMaketform_inv_affine, "inv_affine"),
        mclVv(tdata, "tdata")));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/affine");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(U);
    mxDestroyArray(X);
    mxDestroyArray(A);
    mxDestroyArray(N);
    mxDestroyArray(tdata);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_inv_affine" is the implementation version of the
 * "maketform/inv_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 172-183). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = inv_affine( X, t )
 */
static mxArray * Mmaketform_inv_affine(int nargout_, mxArray * X, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * U = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    /*
     * 
     * % INVERSE affine transformation 
     * %
     * % T is an affine transformation structure. X is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * 
     * U = trans_affine(X, t, 'inverse');
     */
    mlfAssign(
      &U, mlfMaketform_trans_affine(mclVa(X, "X"), mclVa(t, "t"), _mxarray21_));
    mclValidateOutput(U, 1, nargout_, "U", "maketform/inv_affine");
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_fwd_affine" is the implementation version of the
 * "maketform/fwd_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 183-194). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = fwd_affine( U, t)
 */
static mxArray * Mmaketform_fwd_affine(int nargout_, mxArray * U, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * X = NULL;
    mclCopyArray(&U);
    mclCopyArray(&t);
    /*
     * 
     * % FORWARD affine transformation 
     * %
     * % T is an affine transformation structure. U is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * 
     * X = trans_affine(U, t, 'forward');
     */
    mlfAssign(
      &X, mlfMaketform_trans_affine(mclVa(U, "U"), mclVa(t, "t"), _mxarray23_));
    mclValidateOutput(X, 1, nargout_, "X", "maketform/fwd_affine");
    mxDestroyArray(t);
    mxDestroyArray(U);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_trans_affine" is the implementation version of the
 * "maketform/trans_affine" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 194-216). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = trans_affine( X, t, direction )
 */
static mxArray * Mmaketform_trans_affine(int nargout_,
                                         mxArray * X,
                                         mxArray * t,
                                         mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * U = NULL;
    mxArray * U1 = NULL;
    mxArray * X1 = NULL;
    mxArray * ans = NULL;
    mxArray * M = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    mclCopyArray(&direction);
    /*
     * 
     * % Forward/inverse affine transformation method
     * %
     * % T is an affine transformation structure. X is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * % DIRECTION is either 'forward' or 'inverse'.
     * 
     * if strcmp(direction,'forward')
     */
    if (mlfTobool(mlfStrcmp(mclVa(direction, "direction"), _mxarray23_))) {
        /*
         * M = t.tdata.T;
         */
        mlfAssign(&M, mlfIndexRef(mclVa(t, "t"), ".tdata.T"));
    /*
     * elseif strcmp(direction,'inverse')
     */
    } else if (mlfTobool(
                 mlfStrcmp(mclVa(direction, "direction"), _mxarray21_))) {
        /*
         * M = t.tdata.Tinv;
         */
        mlfAssign(&M, mlfIndexRef(mclVa(t, "t"), ".tdata.Tinv"));
    /*
     * else
     */
    } else {
        /*
         * error('DIRECTION must be either ''forward'' or ''inverse''.');
         */
        mlfError(_mxarray25_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * X1 = [X ones(size(X,1),1)];   % Convert X to homogeneous coordinates
     */
    mlfAssign(
      &X1,
      mlfHorzcat(
        mclVa(X, "X"),
        mlfOnes(
          mlfSize(mclValueVarargout(), mclVa(X, "X"), _mxarray0_),
          _mxarray0_,
          NULL),
        NULL));
    /*
     * U1 = X1 * M;                  % Transform in homogeneous coordinates
     */
    mlfAssign(&U1, mclMtimes(mclVv(X1, "X1"), mclVv(M, "M")));
    /*
     * U  = U1(:,1:end-1);           % Convert homogeneous coordinates to U
     */
    mlfAssign(
      &U,
      mclArrayRef2(
        mclVv(U1, "U1"),
        mlfCreateColonIndex(),
        mlfColon(
          _mxarray0_,
          mclMinus(
            mlfEnd(mclVv(U1, "U1"), _mxarray16_, _mxarray16_), _mxarray0_),
          NULL)));
    mclValidateOutput(U, 1, nargout_, "U", "maketform/trans_affine");
    mxDestroyArray(M);
    mxDestroyArray(ans);
    mxDestroyArray(X1);
    mxDestroyArray(U1);
    mxDestroyArray(direction);
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_projective" is the implementation version of the
 * "maketform/projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 216-244). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = projective( varargin )
 */
static mxArray * Mmaketform_projective(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * tdata = NULL;
    mxArray * N = NULL;
    mxArray * A = NULL;
    mxArray * X = NULL;
    mxArray * U = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % Build a projective TFORM struct.
     * 
     * message = nargchk(1,2,nargin);
     */
    mlfAssign(
      &message, mlfNargchk(_mxarray0_, _mxarray16_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if nargin == 2
     */
    if (nargin_ == 2) {
        /*
         * % Construct a 3-by-3 2-D projective transformation matrix A
         * % that maps the four points in U to the four points in X.
         * U = varargin{1};
         */
        mlfAssign(
          &U, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * X = varargin{2};
         */
        mlfAssign(
          &X, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * A = construct_matrix( U, X, 'projective' ); 
         */
        mlfAssign(
          &A,
          mlfMaketform_construct_matrix(
            mclVv(U, "U"), mclVv(X, "X"), _mxarray4_));
    /*
     * else
     */
    } else {
        /*
         * A = varargin{1};
         */
        mlfAssign(
          &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
    /*
     * end
     */
    }
    /*
     * A = validate_matrix( A, 'projective' );
     */
    mlfAssign(&A, mlfMaketform_validate_matrix(mclVv(A, "A"), _mxarray4_));
    /*
     * 
     * N = size(A,2) - 1;
     */
    mlfAssign(
      &N,
      mclMinus(
        mlfSize(mclValueVarargout(), mclVv(A, "A"), _mxarray16_), _mxarray0_));
    /*
     * tdata.T    = A;
     */
    mlfIndexAssign(&tdata, ".T", mclVv(A, "A"));
    /*
     * tdata.Tinv = inv(A);
     */
    mlfIndexAssign(&tdata, ".Tinv", mlfInv(mclVv(A, "A")));
    /*
     * 
     * t = assigntform(N, N, @fwd_projective, @inv_projective, tdata);
     */
    mlfAssign(
      &t,
      mlfMaketform_assigntform(
        mclVv(N, "N"),
        mclVv(N, "N"),
        mclCreateSimpleFunctionHandle(
          mlxMaketform_fwd_projective, "fwd_projective"),
        mclCreateSimpleFunctionHandle(
          mlxMaketform_inv_projective, "inv_projective"),
        mclVv(tdata, "tdata")));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/projective");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(U);
    mxDestroyArray(X);
    mxDestroyArray(A);
    mxDestroyArray(N);
    mxDestroyArray(tdata);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_inv_projective" is the implementation version of
 * the "maketform/inv_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 244-255). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = inv_projective( X, t )
 */
static mxArray * Mmaketform_inv_projective(int nargout_,
                                           mxArray * X,
                                           mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * U = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    /*
     * 
     * % INVERSE projective transformation 
     * %
     * % T is an projective transformation structure. X is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * 
     * U = trans_projective(X, t, 'inverse');
     */
    mlfAssign(
      &U,
      mlfMaketform_trans_projective(mclVa(X, "X"), mclVa(t, "t"), _mxarray21_));
    mclValidateOutput(U, 1, nargout_, "U", "maketform/inv_projective");
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_fwd_projective" is the implementation version of
 * the "maketform/fwd_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 255-266). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = fwd_projective( U, t)
 */
static mxArray * Mmaketform_fwd_projective(int nargout_,
                                           mxArray * U,
                                           mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * X = NULL;
    mclCopyArray(&U);
    mclCopyArray(&t);
    /*
     * 
     * % FORWARD projective transformation 
     * %
     * % T is an projective transformation structure. U is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * 
     * X = trans_projective(U, t, 'forward');
     */
    mlfAssign(
      &X,
      mlfMaketform_trans_projective(mclVa(U, "U"), mclVa(t, "t"), _mxarray23_));
    mclValidateOutput(X, 1, nargout_, "X", "maketform/fwd_projective");
    mxDestroyArray(t);
    mxDestroyArray(U);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_trans_projective" is the implementation version of
 * the "maketform/trans_projective" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 266-290). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = trans_projective( X, t, direction )
 */
static mxArray * Mmaketform_trans_projective(int nargout_,
                                             mxArray * X,
                                             mxArray * t,
                                             mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * U = NULL;
    mxArray * UN = NULL;
    mxArray * U1 = NULL;
    mxArray * X1 = NULL;
    mxArray * N = NULL;
    mxArray * ans = NULL;
    mxArray * M = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    mclCopyArray(&direction);
    /*
     * 
     * % Forward/inverse projective transformation method
     * %
     * % T is an projective transformation structure. X is the row vector to
     * % be transformed, or a matrix with a vector in each row.
     * % DIRECTION is either 'forward' or 'inverse'.
     * 
     * if strcmp(direction,'forward')
     */
    if (mlfTobool(mlfStrcmp(mclVa(direction, "direction"), _mxarray23_))) {
        /*
         * M = t.tdata.T;
         */
        mlfAssign(&M, mlfIndexRef(mclVa(t, "t"), ".tdata.T"));
    /*
     * elseif strcmp(direction,'inverse')
     */
    } else if (mlfTobool(
                 mlfStrcmp(mclVa(direction, "direction"), _mxarray21_))) {
        /*
         * M = t.tdata.Tinv;
         */
        mlfAssign(&M, mlfIndexRef(mclVa(t, "t"), ".tdata.Tinv"));
    /*
     * else
     */
    } else {
        /*
         * error('DIRECTION must be either ''forward'' or ''inverse''.');
         */
        mlfError(_mxarray25_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * N  = t.ndims_in;
     */
    mlfAssign(&N, mlfIndexRef(mclVa(t, "t"), ".ndims_in"));
    /*
     * X1 = [X ones(size(X,1),1)];   % Convert X to homogeneous coordinates
     */
    mlfAssign(
      &X1,
      mlfHorzcat(
        mclVa(X, "X"),
        mlfOnes(
          mlfSize(mclValueVarargout(), mclVa(X, "X"), _mxarray0_),
          _mxarray0_,
          NULL),
        NULL));
    /*
     * U1 = X1 * M;                  % Transform in homogeneous coordinates
     */
    mlfAssign(&U1, mclMtimes(mclVv(X1, "X1"), mclVv(M, "M")));
    /*
     * UN = repmat(U1(:,end),[1 N]); % Replicate the last column of U
     */
    mlfAssign(
      &UN,
      mlfRepmat(
        mclArrayRef2(
          mclVv(U1, "U1"),
          mlfCreateColonIndex(),
          mlfEnd(mclVv(U1, "U1"), _mxarray16_, _mxarray16_)),
        mlfHorzcat(_mxarray0_, mclVv(N, "N"), NULL),
        NULL));
    /*
     * U  = U1(:,1:end-1) ./ UN;     % Convert homogeneous coordinates to U
     */
    mlfAssign(
      &U,
      mclRdivide(
        mclArrayRef2(
          mclVv(U1, "U1"),
          mlfCreateColonIndex(),
          mlfColon(
            _mxarray0_,
            mclMinus(
              mlfEnd(mclVv(U1, "U1"), _mxarray16_, _mxarray16_), _mxarray0_),
            NULL)),
        mclVv(UN, "UN")));
    mclValidateOutput(U, 1, nargout_, "U", "maketform/trans_projective");
    mxDestroyArray(M);
    mxDestroyArray(ans);
    mxDestroyArray(N);
    mxDestroyArray(X1);
    mxDestroyArray(U1);
    mxDestroyArray(UN);
    mxDestroyArray(direction);
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
    /*
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_validate_matrix" is the implementation version of
 * the "maketform/validate_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 290-331). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function A = validate_matrix( A, transform_type )
 */
static mxArray * Mmaketform_validate_matrix(int nargout_,
                                            mxArray * A_in,
                                            mxArray * transform_type) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * A = NULL;
    mxArray * N = NULL;
    mxArray * ans = NULL;
    mclCopyInputArg(&A, A_in);
    mclCopyArray(&transform_type);
    /*
     * 
     * % Make sure A is double and real-valued.
     * if ~isa(A,'double') | ~isreal(A)
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfIsa(mclVa(A, "A"), _mxarray29_)));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mclNot(mlfIsreal(mclVa(A, "A")))))) {
            mxDestroyArray(a_);
            /*
             * error('A must be a real-valued matrix of class double.');
             */
            mlfError(_mxarray27_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Make sure A is finite.
     * if ~all(isfinite(A))
     */
    if (mclNotBool(mlfAll(mlfIsfinite(mclVa(A, "A")), NULL))) {
        /*
         * error('All elements of A must be finite.');
         */
        mlfError(_mxarray31_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % Make sure A is (N + 1)-by-(N + 1).  Append a column if needed for 'affine'.
     * N = size(A,1) - 1;
     */
    mlfAssign(
      &N,
      mclMinus(
        mlfSize(mclValueVarargout(), mclVa(A, "A"), _mxarray0_), _mxarray0_));
    /*
     * if strcmp(transform_type,'affine') & size(A,2) == N
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfStrcmp(mclVa(transform_type, "transform_type"), _mxarray2_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclEq(
                     mlfSize(mclValueVarargout(), mclVa(A, "A"), _mxarray16_),
                     mclVv(N, "N"))))) {
            mxDestroyArray(a_);
            /*
             * A(:,N+1) = [zeros(N,1); 1];
             */
            mclArrayAssign2(
              &A,
              mlfVertcat(
                mlfZeros(mclVv(N, "N"), _mxarray0_, NULL), _mxarray0_, NULL),
              mlfCreateColonIndex(),
              mclPlus(mclVv(N, "N"), _mxarray0_));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * if N < 1 | size(A,2) ~= N + 1
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVv(N, "N"), _mxarray0_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNe(
                     mlfSize(mclValueVarargout(), mclVa(A, "A"), _mxarray16_),
                     mclPlus(mclVv(N, "N"), _mxarray0_))))) {
            mxDestroyArray(a_);
            /*
             * error('A must be square and at least 2-by-2.');
             */
            mlfError(_mxarray33_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * switch transform_type
     */
    {
        mxArray * v_ = mclInitialize(mclVa(transform_type, "transform_type"));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 'affine'
             * % Validate the final column of A.
             * if any(A(:,N+1) ~= [zeros(N,1); 1])
             */
            if (mlfTobool(
                  mlfAny(
                    mclNe(
                      mclArrayRef2(
                        mclVa(A, "A"),
                        mlfCreateColonIndex(),
                        mclPlus(mclVv(N, "N"), _mxarray0_)),
                      mlfVertcat(
                        mlfZeros(mclVv(N, "N"), _mxarray0_, NULL),
                        _mxarray0_,
                        NULL)),
                    NULL))) {
                /*
                 * error('The final column of A must consist of zeroes, except for a one in the last row.');
                 */
                mlfError(_mxarray35_, NULL);
            /*
             * end
             */
            }
        /*
         * 
         * case 'projective'
         */
        } else if (mclSwitchCompare(v_, _mxarray4_)) {
            /*
             * % Validate lower right corner of A
             * if abs(A(N+1,N+1)) <= 100 * eps * norm(A)
             */
            if (mclLeBool(
                  mlfAbs(
                    mclArrayRef2(
                      mclVa(A, "A"),
                      mclPlus(mclVv(N, "N"), _mxarray0_),
                      mclPlus(mclVv(N, "N"), _mxarray0_))),
                  mclMtimes(_mxarray37_, mlfNorm(mclVa(A, "A"), NULL)))) {
                /*
                 * warning('The last element of A is very close to zero.');
                 */
                mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray38_, NULL));
            /*
             * end
             */
            }
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * if cond(A) > condlimit
     */
    if (mclGtBool(mlfCond(mclVa(A, "A"), NULL), mlfMaketform_condlimit())) {
        /*
         * warning(['The condition number of A is ' num2str(cond(A)) '.']);
         */
        mclAssignAns(
          &ans,
          mlfNWarning(
            0,
            NULL,
            mlfHorzcat(
              _mxarray40_,
              mlfNum2str(mlfCond(mclVa(A, "A"), NULL), NULL),
              _mxarray14_,
              NULL),
            NULL));
    /*
     * end
     */
    }
    mclValidateOutput(A, 1, nargout_, "A", "maketform/validate_matrix");
    mxDestroyArray(ans);
    mxDestroyArray(N);
    mxDestroyArray(transform_type);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
    /*
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_construct_matrix" is the implementation version of
 * the "maketform/construct_matrix" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 331-387). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function A = construct_matrix( U, X, transform_type )
 */
static mxArray * Mmaketform_construct_matrix(int nargout_,
                                             mxArray * U,
                                             mxArray * X,
                                             mxArray * transform_type) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * A = NULL;
    mxArray * Ax = NULL;
    mxArray * Au = NULL;
    mxArray * ans = NULL;
    mxArray * unitFcn = NULL;
    mxArray * nPoints = NULL;
    mclCopyArray(&U);
    mclCopyArray(&X);
    mclCopyArray(&transform_type);
    /*
     * 
     * % Construct a 3-by-3 2-D transformation matrix A
     * % that maps the points in U to the points in X.
     * 
     * switch transform_type
     */
    {
        mxArray * v_ = mclInitialize(mclVa(transform_type, "transform_type"));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 'affine'
             * nPoints = 3;
             */
            mlfAssign(&nPoints, _mxarray19_);
            /*
             * unitFcn = @UnitToTriangle;
             */
            mlfAssign(
              &unitFcn,
              mclCreateSimpleFunctionHandle(
                mlxMaketform_UnitToTriangle, "UnitToTriangle"));
        /*
         * case 'projective'
         */
        } else if (mclSwitchCompare(v_, _mxarray4_)) {
            /*
             * nPoints = 4;
             */
            mlfAssign(&nPoints, _mxarray42_);
            /*
             * unitFcn = @UnitToQuadrilateral;
             */
            mlfAssign(
              &unitFcn,
              mclCreateSimpleFunctionHandle(
                mlxMaketform_UnitToQuadrilateral, "UnitToQuadrilateral"));
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * if any(size(U) ~= [nPoints 2])
     */
    if (mlfTobool(
          mlfAny(
            mclNe(
              mlfSize(mclValueVarargout(), mclVa(U, "U"), NULL),
              mlfHorzcat(mclVv(nPoints, "nPoints"), _mxarray16_, NULL)),
            NULL))) {
        /*
         * error(sprintf('U must be %d-by-2.',nPoints));
         */
        mlfError(
          mlfSprintf(NULL, _mxarray43_, mclVv(nPoints, "nPoints"), NULL), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if any(size(X) ~= [nPoints 2])
     */
    if (mlfTobool(
          mlfAny(
            mclNe(
              mlfSize(mclValueVarargout(), mclVa(X, "X"), NULL),
              mlfHorzcat(mclVv(nPoints, "nPoints"), _mxarray16_, NULL)),
            NULL))) {
        /*
         * error(sprintf('X must be %d-by-2.',nPoints));
         */
        mlfError(
          mlfSprintf(NULL, _mxarray45_, mclVv(nPoints, "nPoints"), NULL), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~isa(U,'double') | ~isreal(U) | ~all(isfinite(U))
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfIsa(mclVa(U, "U"), _mxarray29_)));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVa(U, "U")))));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclNot(mlfAll(mlfIsfinite(mclVa(U, "U")), NULL))))) {
            mxDestroyArray(a_);
            /*
             * error('U must be real-valued (class double) and finite.');
             */
            mlfError(_mxarray47_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~isa(X,'double') | ~isreal(X) | ~all(isfinite(X))
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfIsa(mclVa(X, "X"), _mxarray29_)));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVa(X, "X")))));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclNot(mlfAll(mlfIsfinite(mclVa(X, "X")), NULL))))) {
            mxDestroyArray(a_);
            /*
             * error('X must be real-valued (class double) and finite.');
             */
            mlfError(_mxarray49_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * Au = feval(unitFcn,U);
     */
    mlfAssign(
      &Au,
      mlfFeval(
        mclValueVarargout(), mclVv(unitFcn, "unitFcn"), mclVa(U, "U"), NULL));
    /*
     * if cond(Au) > condlimit
     */
    if (mclGtBool(mlfCond(mclVv(Au, "Au"), NULL), mlfMaketform_condlimit())) {
        /*
         * warning('Points in U are nearly collinear and/or coincidental.');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray51_, NULL));
    /*
     * end
     */
    }
    /*
     * 
     * Ax = feval(unitFcn,X);
     */
    mlfAssign(
      &Ax,
      mlfFeval(
        mclValueVarargout(), mclVv(unitFcn, "unitFcn"), mclVa(X, "X"), NULL));
    /*
     * if cond(Ax) > condlimit
     */
    if (mclGtBool(mlfCond(mclVv(Ax, "Ax"), NULL), mlfMaketform_condlimit())) {
        /*
         * warning('Points in X are nearly collinear and/or coincidental.');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray53_, NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % (unit shape) * Au = U
     * % (unit shape) * Ax = X
     * %
     * % U * inv(Au) * Ax = (unit shape) * Ax = X and U * A = X,
     * % so inv(Au) * Ax = A, or Au * A = Ax, or A = Au \ Ax.
     * 
     * A = Au \ Ax;
     */
    mlfAssign(&A, mlfMldivide(mclVv(Au, "Au"), mclVv(Ax, "Ax")));
    /*
     * 
     * if any(~isfinite(A(:)))
     */
    if (mlfTobool(
          mlfAny(
            mclNot(
              mlfIsfinite(mclArrayRef1(mclVv(A, "A"), mlfCreateColonIndex()))),
            NULL))) {
        /*
         * error('Collinear points in U or X; cannot continue.');
         */
        mlfError(_mxarray55_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * A = A / A(end,end);
     */
    mlfAssign(
      &A,
      mclMrdivide(
        mclVv(A, "A"),
        mclArrayRef2(
          mclVv(A, "A"),
          mlfEnd(mclVv(A, "A"), _mxarray0_, _mxarray16_),
          mlfEnd(mclVv(A, "A"), _mxarray16_, _mxarray16_))));
    mclValidateOutput(A, 1, nargout_, "A", "maketform/construct_matrix");
    mxDestroyArray(nPoints);
    mxDestroyArray(unitFcn);
    mxDestroyArray(ans);
    mxDestroyArray(Au);
    mxDestroyArray(Ax);
    mxDestroyArray(transform_type);
    mxDestroyArray(X);
    mxDestroyArray(U);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
    /*
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_UnitToTriangle" is the implementation version of
 * the "maketform/UnitToTriangle" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 387-401). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function A = UnitToTriangle( X )
 */
static mxArray * Mmaketform_UnitToTriangle(int nargout_, mxArray * X) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * A = NULL;
    mclCopyArray(&X);
    /*
     * 
     * % Computes the 3-by-3 two-dimensional affine transformation
     * % matrix A that maps the unit triangle ([0 0], [1 0], [0 1])
     * % to a triangle with corners (X(1,:), X(2,:), X(3,:)).
     * % X must be 3-by-2, real-valued, and contain three distinct
     * % and non-collinear points. A is a 3-by-3, real-valued matrix.
     * 
     * A = [ X(2,1) - X(1,1)   X(2,2) - X(1,2)    0; ...
     */
    mlfAssign(
      &A,
      mlfVertcat(
        mlfHorzcat(
          mclMinus(
            mclIntArrayRef2(mclVa(X, "X"), 2, 1),
            mclIntArrayRef2(mclVa(X, "X"), 1, 1)),
          mclMinus(
            mclIntArrayRef2(mclVa(X, "X"), 2, 2),
            mclIntArrayRef2(mclVa(X, "X"), 1, 2)),
          _mxarray20_,
          NULL),
        mlfHorzcat(
          mclMinus(
            mclIntArrayRef2(mclVa(X, "X"), 3, 1),
            mclIntArrayRef2(mclVa(X, "X"), 1, 1)),
          mclMinus(
            mclIntArrayRef2(mclVa(X, "X"), 3, 2),
            mclIntArrayRef2(mclVa(X, "X"), 1, 2)),
          _mxarray20_,
          NULL),
        mlfHorzcat(
          mclIntArrayRef2(mclVa(X, "X"), 1, 1),
          mclIntArrayRef2(mclVa(X, "X"), 1, 2),
          _mxarray0_,
          NULL),
        NULL));
    mclValidateOutput(A, 1, nargout_, "A", "maketform/UnitToTriangle");
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
    /*
     * X(3,1) - X(1,1)   X(3,2) - X(1,2)    0; ...
     * X(1,1)            X(1,2)        1  ];
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_UnitToQuadrilateral" is the implementation version
 * of the "maketform/UnitToQuadrilateral" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 401-448). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function A = UnitToQuadrilateral( X )
 */
static mxArray * Mmaketform_UnitToQuadrilateral(int nargout_, mxArray * X) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * A = NULL;
    mxArray * a23 = NULL;
    mxArray * a13 = NULL;
    mxArray * dy3 = NULL;
    mxArray * dy2 = NULL;
    mxArray * dy1 = NULL;
    mxArray * dx3 = NULL;
    mxArray * dx2 = NULL;
    mxArray * dx1 = NULL;
    mxArray * y = NULL;
    mxArray * x = NULL;
    mclCopyArray(&X);
    /*
     * 
     * % Computes the 3-by-3 two-dimensional projective transformation
     * % matrix A that maps the unit square ([0 0], [1 0], [1 1], [0 1])
     * % to a quadrilateral corners (X(1,:), X(2,:), X(3,:), X(4,:)).
     * % X must be 4-by-2, real-valued, and contain four distinct
     * % and non-collinear points.  A is a 3-by-3, real-valued matrix.
     * % If the four points happen to form a parallelogram, then
     * % A(1,3) = A(2,3) = 0 and the mapping is affine.
     * %
     * % The formulas below are derived in
     * %   Wolberg, George. "Digital Image Warping," IEEE Computer
     * %   Society Press, Los Alamitos, CA, 1990, pp. 54-56,
     * % and are based on the derivation in
     * %   Heckbert, Paul S., "Fundamentals of Texture Mapping and
     * %   Image Warping," Master's Thesis, Department of Electrical
     * %   Engineering and Computer Science, University of California,
     * %   Berkeley, June 17, 1989, pp. 19-21.
     * 
     * x = X(:,1);
     */
    mlfAssign(
      &x, mclArrayRef2(mclVa(X, "X"), mlfCreateColonIndex(), _mxarray0_));
    /*
     * y = X(:,2);
     */
    mlfAssign(
      &y, mclArrayRef2(mclVa(X, "X"), mlfCreateColonIndex(), _mxarray16_));
    /*
     * 
     * dx1 = x(2) - x(3);
     */
    mlfAssign(
      &dx1,
      mclMinus(
        mclIntArrayRef1(mclVv(x, "x"), 2), mclIntArrayRef1(mclVv(x, "x"), 3)));
    /*
     * dx2 = x(4) - x(3);
     */
    mlfAssign(
      &dx2,
      mclMinus(
        mclIntArrayRef1(mclVv(x, "x"), 4), mclIntArrayRef1(mclVv(x, "x"), 3)));
    /*
     * dx3 = x(1) - x(2) + x(3) - x(4);
     */
    mlfAssign(
      &dx3,
      mclMinus(
        mclPlus(
          mclMinus(
            mclIntArrayRef1(mclVv(x, "x"), 1),
            mclIntArrayRef1(mclVv(x, "x"), 2)),
          mclIntArrayRef1(mclVv(x, "x"), 3)),
        mclIntArrayRef1(mclVv(x, "x"), 4)));
    /*
     * 
     * dy1 = y(2) - y(3);
     */
    mlfAssign(
      &dy1,
      mclMinus(
        mclIntArrayRef1(mclVv(y, "y"), 2), mclIntArrayRef1(mclVv(y, "y"), 3)));
    /*
     * dy2 = y(4) - y(3);
     */
    mlfAssign(
      &dy2,
      mclMinus(
        mclIntArrayRef1(mclVv(y, "y"), 4), mclIntArrayRef1(mclVv(y, "y"), 3)));
    /*
     * dy3 = y(1) - y(2) + y(3) - y(4);
     */
    mlfAssign(
      &dy3,
      mclMinus(
        mclPlus(
          mclMinus(
            mclIntArrayRef1(mclVv(y, "y"), 1),
            mclIntArrayRef1(mclVv(y, "y"), 2)),
          mclIntArrayRef1(mclVv(y, "y"), 3)),
        mclIntArrayRef1(mclVv(y, "y"), 4)));
    /*
     * 
     * if dx3 == 0 & dy3 == 0
     */
    {
        mxArray * a_ = mclInitialize(mclEq(mclVv(dx3, "dx3"), _mxarray20_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclEq(mclVv(dy3, "dy3"), _mxarray20_)))) {
            mxDestroyArray(a_);
            /*
             * % Parallelogram: Affine map
             * A = [ x(2) - x(1)    y(2) - y(1)   0 ; ...
             */
            mlfAssign(
              &A,
              mlfVertcat(
                mlfHorzcat(
                  mclMinus(
                    mclIntArrayRef1(mclVv(x, "x"), 2),
                    mclIntArrayRef1(mclVv(x, "x"), 1)),
                  mclMinus(
                    mclIntArrayRef1(mclVv(y, "y"), 2),
                    mclIntArrayRef1(mclVv(y, "y"), 1)),
                  _mxarray20_,
                  NULL),
                mlfHorzcat(
                  mclMinus(
                    mclIntArrayRef1(mclVv(x, "x"), 3),
                    mclIntArrayRef1(mclVv(x, "x"), 2)),
                  mclMinus(
                    mclIntArrayRef1(mclVv(y, "y"), 3),
                    mclIntArrayRef1(mclVv(y, "y"), 2)),
                  _mxarray20_,
                  NULL),
                mlfHorzcat(
                  mclIntArrayRef1(mclVv(x, "x"), 1),
                  mclIntArrayRef1(mclVv(y, "y"), 1),
                  _mxarray0_,
                  NULL),
                NULL));
        /*
         * x(3) - x(2)    y(3) - y(2)   0 ; ...
         * x(1)           y(1)          1 ];
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * % General quadrilateral: Projective map
             * a13 = (dx3 * dy2 - dx2 * dy3) / (dx1 * dy2 - dx2 * dy1);
             */
            mlfAssign(
              &a13,
              mclMrdivide(
                mclMinus(
                  mclMtimes(mclVv(dx3, "dx3"), mclVv(dy2, "dy2")),
                  mclMtimes(mclVv(dx2, "dx2"), mclVv(dy3, "dy3"))),
                mclMinus(
                  mclMtimes(mclVv(dx1, "dx1"), mclVv(dy2, "dy2")),
                  mclMtimes(mclVv(dx2, "dx2"), mclVv(dy1, "dy1")))));
            /*
             * a23 = (dx1 * dy3 - dx3 * dy1) / (dx1 * dy2 - dx2 * dy1);
             */
            mlfAssign(
              &a23,
              mclMrdivide(
                mclMinus(
                  mclMtimes(mclVv(dx1, "dx1"), mclVv(dy3, "dy3")),
                  mclMtimes(mclVv(dx3, "dx3"), mclVv(dy1, "dy1"))),
                mclMinus(
                  mclMtimes(mclVv(dx1, "dx1"), mclVv(dy2, "dy2")),
                  mclMtimes(mclVv(dx2, "dx2"), mclVv(dy1, "dy1")))));
            /*
             * 
             * A = [x(2) - x(1) + a13 * x(2)   y(2) - y(1) + a13 * y(2)   a13 ;...
             */
            mlfAssign(
              &A,
              mlfVertcat(
                mlfHorzcat(
                  mclPlus(
                    mclMinus(
                      mclIntArrayRef1(mclVv(x, "x"), 2),
                      mclIntArrayRef1(mclVv(x, "x"), 1)),
                    mclMtimes(
                      mclVv(a13, "a13"), mclIntArrayRef1(mclVv(x, "x"), 2))),
                  mclPlus(
                    mclMinus(
                      mclIntArrayRef1(mclVv(y, "y"), 2),
                      mclIntArrayRef1(mclVv(y, "y"), 1)),
                    mclMtimes(
                      mclVv(a13, "a13"), mclIntArrayRef1(mclVv(y, "y"), 2))),
                  mclVv(a13, "a13"),
                  NULL),
                mlfHorzcat(
                  mclPlus(
                    mclMinus(
                      mclIntArrayRef1(mclVv(x, "x"), 4),
                      mclIntArrayRef1(mclVv(x, "x"), 1)),
                    mclMtimes(
                      mclVv(a23, "a23"), mclIntArrayRef1(mclVv(x, "x"), 4))),
                  mclPlus(
                    mclMinus(
                      mclIntArrayRef1(mclVv(y, "y"), 4),
                      mclIntArrayRef1(mclVv(y, "y"), 1)),
                    mclMtimes(
                      mclVv(a23, "a23"), mclIntArrayRef1(mclVv(y, "y"), 4))),
                  mclVv(a23, "a23"),
                  NULL),
                mlfHorzcat(
                  mclIntArrayRef1(mclVv(x, "x"), 1),
                  mclIntArrayRef1(mclVv(y, "y"), 1),
                  _mxarray0_,
                  NULL),
                NULL));
        }
    /*
     * x(4) - x(1) + a23 * x(4)   y(4) - y(1) + a23 * y(4)   a23 ;...
     * x(1)                       y(1)                       1   ];
     * end
     */
    }
    mclValidateOutput(A, 1, nargout_, "A", "maketform/UnitToQuadrilateral");
    mxDestroyArray(x);
    mxDestroyArray(y);
    mxDestroyArray(dx1);
    mxDestroyArray(dx2);
    mxDestroyArray(dx3);
    mxDestroyArray(dy1);
    mxDestroyArray(dy2);
    mxDestroyArray(dy3);
    mxDestroyArray(a13);
    mxDestroyArray(a23);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
    /*
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_composite" is the implementation version of the
 * "maketform/composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 448-510). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = composite( varargin )
 */
static mxArray * Mmaketform_composite(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * inverse_fcn = NULL;
    mxArray * forward_fcn = NULL;
    mxArray * ndims_out = NULL;
    mxArray * ndims_in = NULL;
    mxArray * N = NULL;
    mxArray * k = NULL;
    mxArray * tdata = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % Construct COMPOSITE transformation structure.
     * 
     * % Create TDATA as a TFORM structure array.
     * if nargin == 0
     */
    if (nargin_ == 0) {
        /*
         * error('At least one TFORM struct is required.');
         */
        mlfError(_mxarray57_, NULL);
    /*
     * elseif nargin == 1
     */
    } else if (nargin_ == 1) {
        /*
         * if length(varargin{1}) == 1
         */
        if (mclEqBool(
              mclFeval(
                mclValueVarargout(),
                mlxLength,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL),
              _mxarray0_)) {
            /*
             * % One TFORM input, just copy to t
             * t = varargin{1};
             */
            mlfAssign(
              &t, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * if ~istform(t)
             */
            if (mclNotBool(mlfImages_private_istform(mclVv(t, "t")))) {
                /*
                 * error('T1 must be a TFORM struct.');
                 */
                mlfError(_mxarray59_, NULL);
            /*
             * end
             */
            }
            /*
             * return;
             */
            goto return_;
        /*
         * else
         */
        } else {
            /*
             * % An array of TFORMs
             * tdata = varargin{1};
             */
            mlfAssign(
              &tdata,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * if ~istform(tdata)
             */
            if (mclNotBool(mlfImages_private_istform(mclVv(tdata, "tdata")))) {
                /*
                 * error('[T1, T2, ... TN] must be an array of TFORM structs.');
                 */
                mlfError(_mxarray61_, NULL);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * else
     */
    } else {
        /*
         * % A list of TFORMs
         * for k = 1:nargin
         */
        int v_ = mclForIntStart(1);
        int e_ = nargin_;
        if (v_ > e_) {
            mlfAssign(&k, _mxarray63_);
        } else {
            /*
             * if ~istform(varargin{k}) | length(varargin{k}) ~= 1
             * error('T1, T2, ... TN must each be a TFORM struct.');
             * end
             * end
             */
            for (; ; ) {
                mxArray * a_
                  = mclInitialize(
                      mclNot(
                        mclFeval(
                          mclValueVarargout(),
                          mlxImages_private_istform,
                          mlfIndexRef(
                            mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                          NULL)));
                if (mlfTobool(a_)
                    || mlfTobool(
                         mclOr(
                           a_,
                           mclNe(
                             mclFeval(
                               mclValueVarargout(),
                               mlxLength,
                               mlfIndexRef(
                                 mclVa(varargin, "varargin"),
                                 "{?}",
                                 mlfScalar(v_)),
                               NULL),
                             _mxarray0_)))) {
                    mxDestroyArray(a_);
                    mlfError(_mxarray64_, NULL);
                } else {
                    mxDestroyArray(a_);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
        /*
         * tdata = [varargin{:}];
         */
        mlfAssign(
          &tdata,
          mlfHorzcat(
            mlfIndexRef(
              mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Check for consistency of dimensions
     * N = length(tdata);
     */
    mlfAssign(&N, mlfScalar(mclLengthInt(mclVv(tdata, "tdata"))));
    /*
     * ndims_in =  [tdata.ndims_in];
     */
    mlfAssign(
      &ndims_in,
      mlfHorzcat(mlfIndexRef(mclVv(tdata, "tdata"), ".ndims_in"), NULL));
    /*
     * ndims_out = [tdata.ndims_out];
     */
    mlfAssign(
      &ndims_out,
      mlfHorzcat(mlfIndexRef(mclVv(tdata, "tdata"), ".ndims_out"), NULL));
    /*
     * if any(ndims_in(1:N-1) ~= ndims_out(2:N))
     */
    if (mlfTobool(
          mlfAny(
            mclNe(
              mclArrayRef1(
                mclVv(ndims_in, "ndims_in"),
                mlfColon(
                  _mxarray0_, mclMinus(mclVv(N, "N"), _mxarray0_), NULL)),
              mclArrayRef1(
                mclVv(ndims_out, "ndims_out"),
                mlfColon(_mxarray16_, mclVv(N, "N"), NULL))),
            NULL))) {
        /*
         * error( 'Input TFORM objects have inconsistent dimensions.');
         */
        mlfError(_mxarray66_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % Check existence of forward and inverse function handles 
     * if any(cellfun('isempty',{tdata.forward_fcn}))
     */
    if (mlfTobool(
          mlfAny(
            mlfNCellfun(
              0,
              mclValueVarargout(),
              _mxarray68_,
              mlfCellhcat(
                mlfIndexRef(mclVv(tdata, "tdata"), ".forward_fcn"), NULL),
              NULL),
            NULL))) {
        /*
         * forward_fcn = [];
         */
        mlfAssign(&forward_fcn, _mxarray63_);
    /*
     * else
     */
    } else {
        /*
         * forward_fcn = @fwd_composite;
         */
        mlfAssign(
          &forward_fcn,
          mclCreateSimpleFunctionHandle(
            mlxMaketform_fwd_composite, "fwd_composite"));
    /*
     * end
     */
    }
    /*
     * 
     * if any(cellfun('isempty',{tdata.inverse_fcn}))
     */
    if (mlfTobool(
          mlfAny(
            mlfNCellfun(
              0,
              mclValueVarargout(),
              _mxarray68_,
              mlfCellhcat(
                mlfIndexRef(mclVv(tdata, "tdata"), ".inverse_fcn"), NULL),
              NULL),
            NULL))) {
        /*
         * inverse_fcn = [];
         */
        mlfAssign(&inverse_fcn, _mxarray63_);
    /*
     * else
     */
    } else {
        /*
         * inverse_fcn = @inv_composite;
         */
        mlfAssign(
          &inverse_fcn,
          mclCreateSimpleFunctionHandle(
            mlxMaketform_inv_composite, "inv_composite"));
    /*
     * end
     */
    }
    /*
     * 
     * if (isempty(forward_fcn) & isempty(inverse_fcn)) 
     */
    {
        mxArray * a_
          = mclInitialize(mlfIsempty(mclVv(forward_fcn, "forward_fcn")));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(a_, mlfIsempty(mclVv(inverse_fcn, "inverse_fcn"))))) {
            mxDestroyArray(a_);
            /*
             * error( 'Unable to compose either a forward or inverse transformation.');
             */
            mlfError(_mxarray70_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * t = assigntform(tdata(N).ndims_in, tdata(1).ndims_out, ...
     */
    mlfAssign(
      &t,
      mclFeval(
        mclValueVarargout(),
        mlxMaketform_assigntform,
        mlfIndexRef(mclVv(tdata, "tdata"), "(?).ndims_in", mclVv(N, "N")),
        mlfIndexRef(mclVv(tdata, "tdata"), "(?).ndims_out", _mxarray0_),
        mclVv(forward_fcn, "forward_fcn"),
        mclVv(inverse_fcn, "inverse_fcn"),
        mclVv(tdata, "tdata"),
        NULL));
    /*
     * forward_fcn, inverse_fcn, tdata);
     * 
     * %---------------------------------------------------------------
     * 
     */
    return_:
    mclValidateOutput(t, 1, nargout_, "t", "maketform/composite");
    mxDestroyArray(ans);
    mxDestroyArray(tdata);
    mxDestroyArray(k);
    mxDestroyArray(N);
    mxDestroyArray(ndims_in);
    mxDestroyArray(ndims_out);
    mxDestroyArray(forward_fcn);
    mxDestroyArray(inverse_fcn);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
}

/*
 * The function "Mmaketform_fwd_composite" is the implementation version of the
 * "maketform/fwd_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 510-525). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = fwd_composite( U, t )
 */
static mxArray * Mmaketform_fwd_composite(int nargout_,
                                          mxArray * U,
                                          mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * X = NULL;
    mxArray * i = NULL;
    mxArray * N = NULL;
    mclCopyArray(&U);
    mclCopyArray(&t);
    /*
     * 
     * % FORWARD composite transformation 
     * %
     * % U is the row vector to be transformed, or
     * % a matrix with a vector in each row.
     * 
     * N = length(t.tdata);
     */
    mlfAssign(
      &N,
      mclFeval(
        mclValueVarargout(),
        mlxLength,
        mlfIndexRef(mclVa(t, "t"), ".tdata"),
        NULL));
    /*
     * X = U;
     */
    mlfAssign(&X, mclVa(U, "U"));
    /*
     * for i = N:-1:1
     */
    {
        mclForLoopIterator viter__;
        for (mclForStart(&viter__, mclVv(N, "N"), _mxarray72_, _mxarray0_);
             mclForNext(&viter__, &i);
             ) {
            /*
             * X = feval(t.tdata(i).forward_fcn, X, t.tdata(i));
             */
            mlfAssign(
              &X,
              mlfFeval(
                mclValueVarargout(),
                mlfIndexRef(
                  mclVa(t, "t"), ".tdata(?).forward_fcn", mclVv(i, "i")),
                mclVv(X, "X"),
                mlfIndexRef(mclVa(t, "t"), ".tdata(?)", mclVv(i, "i")),
                NULL));
        /*
         * end
         */
        }
        mclDestroyForLoopIterator(viter__);
    }
    mclValidateOutput(X, 1, nargout_, "X", "maketform/fwd_composite");
    mxDestroyArray(N);
    mxDestroyArray(i);
    mxDestroyArray(t);
    mxDestroyArray(U);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %---------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_inv_composite" is the implementation version of the
 * "maketform/inv_composite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 525-540). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = inv_composite( X, t )
 */
static mxArray * Mmaketform_inv_composite(int nargout_,
                                          mxArray * X,
                                          mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * U = NULL;
    mxArray * i = NULL;
    mxArray * N = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    /*
     * 
     * % INVERSE composite transformation 
     * %
     * % X is the row vector to be transformed, or
     * % a matrix with a vector in each row.
     * 
     * N = length(t.tdata);
     */
    mlfAssign(
      &N,
      mclFeval(
        mclValueVarargout(),
        mlxLength,
        mlfIndexRef(mclVa(t, "t"), ".tdata"),
        NULL));
    /*
     * U = X;
     */
    mlfAssign(&U, mclVa(X, "X"));
    /*
     * for i = 1:N
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(N, "N"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray63_);
        } else {
            /*
             * U = feval(t.tdata(i).inverse_fcn, U, t.tdata(i));
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &U,
                  mlfFeval(
                    mclValueVarargout(),
                    mlfIndexRef(
                      mclVa(t, "t"), ".tdata(?).inverse_fcn", mlfScalar(v_)),
                    mclVv(U, "U"),
                    mlfIndexRef(mclVa(t, "t"), ".tdata(?)", mlfScalar(v_)),
                    NULL));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    mclValidateOutput(U, 1, nargout_, "U", "maketform/inv_composite");
    mxDestroyArray(N);
    mxDestroyArray(i);
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_custom" is the implementation version of the
 * "maketform/custom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 540-590). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = custom( varargin )
 */
static mxArray * Mmaketform_custom(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * tdata = NULL;
    mxArray * inverse_fcn = NULL;
    mxArray * forward_fcn = NULL;
    mxArray * ndims_out = NULL;
    mxArray * ndims_in = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * message = nargchk(5,5,nargin);
     */
    mlfAssign(
      &message, mlfNargchk(_mxarray73_, _mxarray73_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * ndims_in    = varargin{1};
     */
    mlfAssign(
      &ndims_in, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
    /*
     * ndims_out   = varargin{2};
     */
    mlfAssign(
      &ndims_out, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
    /*
     * forward_fcn = varargin{3};
     */
    mlfAssign(
      &forward_fcn,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_));
    /*
     * inverse_fcn = varargin{4};
     */
    mlfAssign(
      &inverse_fcn,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray42_));
    /*
     * tdata       = varargin{5};
     */
    mlfAssign(
      &tdata, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray73_));
    /*
     * 
     * % Validate sizes and types
     * if length(ndims_in) ~= 1 | ~isdoubleinteger(ndims_in)
     */
    {
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(mclLengthInt(mclVv(ndims_in, "ndims_in")) != 1));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mlfMaketform_isdoubleinteger(
                       mclVv(ndims_in, "ndims_in")))))) {
            mxDestroyArray(a_);
            /*
             * error('NDIMS_IN must be a finite, integer-valued double.');
             */
            mlfError(_mxarray74_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if length(ndims_out) ~= 1 | ~isdoubleinteger(ndims_out)
     */
    {
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(
                mclLengthInt(mclVv(ndims_out, "ndims_out")) != 1));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mlfMaketform_isdoubleinteger(
                       mclVv(ndims_out, "ndims_out")))))) {
            mxDestroyArray(a_);
            /*
             * error('NDIMS_OUT must be a finite, integer-valued double.');
             */
            mlfError(_mxarray76_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ndims_in < 1
     */
    if (mclLtBool(mclVv(ndims_in, "ndims_in"), _mxarray0_)) {
        /*
         * error('NDIMS_IN must be positive.');
         */
        mlfError(_mxarray78_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ndims_out < 1
     */
    if (mclLtBool(mclVv(ndims_out, "ndims_out"), _mxarray0_)) {
        /*
         * error('NDIMS_OUT must be positive.');
         */
        mlfError(_mxarray80_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~isempty(forward_fcn)
     */
    if (mclNotBool(mlfIsempty(mclVv(forward_fcn, "forward_fcn")))) {
        /*
         * if length(forward_fcn) ~= 1 | ~isa(forward_fcn,'function_handle')
         */
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(
                mclLengthInt(mclVv(forward_fcn, "forward_fcn")) != 1));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mlfIsa(
                       mclVv(forward_fcn, "forward_fcn"), _mxarray82_))))) {
            mxDestroyArray(a_);
            /*
             * error('FORWARD_FCN must be a function handle.');
             */
            mlfError(_mxarray84_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     * end
     */
    }
    /*
     * 
     * if ~isempty(inverse_fcn)
     */
    if (mclNotBool(mlfIsempty(mclVv(inverse_fcn, "inverse_fcn")))) {
        /*
         * if length(inverse_fcn) ~= 1 | ~isa(inverse_fcn,'function_handle')
         */
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(
                mclLengthInt(mclVv(inverse_fcn, "inverse_fcn")) != 1));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mlfIsa(
                       mclVv(inverse_fcn, "inverse_fcn"), _mxarray82_))))) {
            mxDestroyArray(a_);
            /*
             * error('INVERSE_FCN must be a function handle.');
             */
            mlfError(_mxarray86_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     * end
     */
    }
    /*
     * 
     * if isempty(forward_fcn) & isempty(inverse_fcn)
     */
    {
        mxArray * a_
          = mclInitialize(mlfIsempty(mclVv(forward_fcn, "forward_fcn")));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(a_, mlfIsempty(mclVv(inverse_fcn, "inverse_fcn"))))) {
            mxDestroyArray(a_);
            /*
             * error('FORWARD_FCN and INVERSE_FCN cannot both be empty.');
             */
            mlfError(_mxarray88_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * t = assigntform(ndims_in, ndims_out, forward_fcn, inverse_fcn, tdata);
     */
    mlfAssign(
      &t,
      mlfMaketform_assigntform(
        mclVv(ndims_in, "ndims_in"),
        mclVv(ndims_out, "ndims_out"),
        mclVv(forward_fcn, "forward_fcn"),
        mclVv(inverse_fcn, "inverse_fcn"),
        mclVv(tdata, "tdata")));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/custom");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(ndims_in);
    mxDestroyArray(ndims_out);
    mxDestroyArray(forward_fcn);
    mxDestroyArray(inverse_fcn);
    mxDestroyArray(tdata);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_box" is the implementation version of the
 * "maketform/box" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 590-646). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = box( varargin )
 */
static mxArray * Mmaketform_box(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * t = NULL;
    mxArray * outbounds = NULL;
    mxArray * inbounds = NULL;
    mxArray * N = NULL;
    mxArray * hi = NULL;
    mxArray * lo = NULL;
    mxArray * tsize = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * message = nargchk(2,3,nargin);
     */
    mlfAssign(
      &message, mlfNargchk(_mxarray16_, _mxarray19_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if nargin == 3
     */
    if (nargin_ == 3) {
        /*
         * % Construct an affine TFORM struct that maps a box bounded by 1 and TSIZE(k)
         * % in dimension k to a box bounded by LO(k) and HI(k) in dimension k.
         * % Construct INBOUNDS and OUTBOUNDS arrays, then call BOX2.
         * 
         * tsize = varargin{1};
         */
        mlfAssign(
          &tsize, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * lo    = varargin{2};
         */
        mlfAssign(
          &lo, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * hi    = varargin{3};
         */
        mlfAssign(
          &hi, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_));
        /*
         * 
         * tsize = tsize(:);
         */
        mlfAssign(
          &tsize, mclArrayRef1(mclVv(tsize, "tsize"), mlfCreateColonIndex()));
        /*
         * lo = lo(:);
         */
        mlfAssign(&lo, mclArrayRef1(mclVv(lo, "lo"), mlfCreateColonIndex()));
        /*
         * hi = hi(:);
         */
        mlfAssign(&hi, mclArrayRef1(mclVv(hi, "hi"), mlfCreateColonIndex()));
        /*
         * 
         * if ~isdoubleinteger(tsize)
         */
        if (mclNotBool(mlfMaketform_isdoubleinteger(mclVv(tsize, "tsize")))) {
            /*
             * error('TSIZE must be integer-valued (class double) and finite.');
             */
            mlfError(_mxarray90_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * if any(tsize < 1 )
         */
        if (mlfTobool(mlfAny(mclLt(mclVv(tsize, "tsize"), _mxarray0_), NULL))) {
            /*
             * error('All values in TSIZE must be greater than or equal to 1.');
             */
            mlfError(_mxarray92_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * if ~isa(lo,'double') | ~isreal(lo) | ~all(isfinite(lo))
         */
        {
            mxArray * a_
              = mclInitialize(mclNot(mlfIsa(mclVv(lo, "lo"), _mxarray29_)));
            if (mlfTobool(a_)) {
                mlfAssign(&a_, mlfScalar(1));
            } else {
                mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVv(lo, "lo")))));
            }
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclNot(mlfAll(mlfIsfinite(mclVv(lo, "lo")), NULL))))) {
                mxDestroyArray(a_);
                /*
                 * error('LO must be real-valued (class double) and finite.');
                 */
                mlfError(_mxarray94_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * 
         * if ~isa(hi,'double') | ~isreal(hi) | ~all(isfinite(hi))
         */
        {
            mxArray * a_
              = mclInitialize(mclNot(mlfIsa(mclVv(hi, "hi"), _mxarray29_)));
            if (mlfTobool(a_)) {
                mlfAssign(&a_, mlfScalar(1));
            } else {
                mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVv(hi, "hi")))));
            }
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclNot(mlfAll(mlfIsfinite(mclVv(hi, "hi")), NULL))))) {
                mxDestroyArray(a_);
                /*
                 * error('HI must be real-valued (class double) and finite.');
                 */
                mlfError(_mxarray96_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * 
         * N = length(tsize);
         */
        mlfAssign(&N, mlfScalar(mclLengthInt(mclVv(tsize, "tsize"))));
        /*
         * if length(lo) ~= N | length(hi) ~= N
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclNe(
                    mlfScalar(mclLengthInt(mclVv(lo, "lo"))), mclVv(N, "N")));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclNe(
                         mlfScalar(mclLengthInt(mclVv(hi, "hi"))),
                         mclVv(N, "N"))))) {
                mxDestroyArray(a_);
                /*
                 * error('TSIZE, LO, and HI must be the same length.');
                 */
                mlfError(_mxarray98_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * 
         * if any(lo == hi & ~(tsize == 1))
         */
        if (mlfTobool(
              mlfAny(
                mclAnd(
                  mclEq(mclVv(lo, "lo"), mclVv(hi, "hi")),
                  mclNot(mclEq(mclVv(tsize, "tsize"), _mxarray0_))),
                NULL))) {
            /*
             * error('The corresponding entries in LO and HI may not be equal unless TSIZE is 1.');
             */
            mlfError(_mxarray100_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * inbounds  = [ones(1,N); tsize'];
         */
        mlfAssign(
          &inbounds,
          mlfVertcat(
            mlfOnes(_mxarray0_, mclVv(N, "N"), NULL),
            mlfCtranspose(mclVv(tsize, "tsize")),
            NULL));
        /*
         * outbounds = [lo'; hi'];
         */
        mlfAssign(
          &outbounds,
          mlfVertcat(
            mlfCtranspose(mclVv(lo, "lo")),
            mlfCtranspose(mclVv(hi, "hi")),
            NULL));
    /*
     * else
     */
    } else {
        /*
         * inbounds  = varargin{1};
         */
        mlfAssign(
          &inbounds,
          mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * outbounds = varargin{2};
         */
        mlfAssign(
          &outbounds,
          mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
    /*
     * end
     */
    }
    /*
     * 
     * t = box2(inbounds,outbounds);
     */
    mlfAssign(
      &t,
      mlfMaketform_box2(
        mclVv(inbounds, "inbounds"), mclVv(outbounds, "outbounds")));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/box");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(tsize);
    mxDestroyArray(lo);
    mxDestroyArray(hi);
    mxDestroyArray(N);
    mxDestroyArray(inbounds);
    mxDestroyArray(outbounds);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_box2" is the implementation version of the
 * "maketform/box2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 646-691). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function t = box2( inBounds, outBounds )
 */
static mxArray * Mmaketform_box2(int nargout_,
                                 mxArray * inBounds,
                                 mxArray * outBounds) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * t = NULL;
    mxArray * A = NULL;
    mxArray * shift = NULL;
    mxArray * scale = NULL;
    mxArray * den = NULL;
    mxArray * num = NULL;
    mxArray * qDegenerate = NULL;
    mxArray * N = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&inBounds);
    mclCopyArray(&outBounds);
    /*
     * 
     * % Construct an affine TFORM struct that maps a box bounded by INBOUNDS(1,k)
     * % and INBOUNDS(2,k) in dimensions k to a box bounded by OUTBOUNDS(1,k) and
     * % OUTBOUNDS(2,k).
     * %
     * % inBounds:   2-by-N
     * % outBounds:  2-by-N
     * 
     * if ~isfinitedouble(inBounds)
     */
    if (mclNotBool(mlfMaketform_isfinitedouble(mclVa(inBounds, "inBounds")))) {
        /*
         * error('INBOUNDS must be real and finite.');
         */
        mlfError(_mxarray102_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~isfinitedouble(outBounds)
     */
    if (mclNotBool(
          mlfMaketform_isfinitedouble(mclVa(outBounds, "outBounds")))) {
        /*
         * error('OUTBOUNDS must be real and finite.');
         */
        mlfError(_mxarray104_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * N = size(inBounds,2);
     */
    mlfAssign(
      &N,
      mlfSize(mclValueVarargout(), mclVa(inBounds, "inBounds"), _mxarray16_));
    /*
     * if ndims(inBounds) ~= 2  ...
     * | ndims(outBounds)  ~= 2 ...
     */
    {
        mxArray * a_
          = mclInitialize(
              mclNe(mlfNdims(mclVa(inBounds, "inBounds")), _mxarray16_));
        if (mlfTobool(a_)) {
            /*
             * | size(inBounds,1)  ~= 2 ...
             */
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclNe(mlfNdims(mclVa(outBounds, "outBounds")), _mxarray16_)));
        }
        if (mlfTobool(a_)) {
            /*
             * | size(outBounds,1) ~= 2 ...
             */
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclNe(
                  mlfSize(
                    mclValueVarargout(),
                    mclVa(inBounds, "inBounds"),
                    _mxarray0_),
                  _mxarray16_)));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclNe(
                  mlfSize(
                    mclValueVarargout(),
                    mclVa(outBounds, "outBounds"),
                    _mxarray0_),
                  _mxarray16_)));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNe(
                     mlfSize(
                       mclValueVarargout(),
                       mclVa(outBounds, "outBounds"),
                       _mxarray16_),
                     mclVv(N, "N"))))) {
            mxDestroyArray(a_);
            /*
             * | size(outBounds,2) ~= N ...
             * error('INBOUNDS and OUTBOUNDS must be 2-by-N (for the same N).');
             */
            mlfError(_mxarray106_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * qDegenerate  = (inBounds(1,:) == inBounds(2,:));
     */
    mlfAssign(
      &qDegenerate,
      mclEq(
        mclArrayRef2(
          mclVa(inBounds, "inBounds"), _mxarray0_, mlfCreateColonIndex()),
        mclArrayRef2(
          mclVa(inBounds, "inBounds"), _mxarray16_, mlfCreateColonIndex())));
    /*
     * if any((outBounds(1,:) == outBounds(2,:)) ~= qDegenerate)
     */
    if (mlfTobool(
          mlfAny(
            mclNe(
              mclEq(
                mclArrayRef2(
                  mclVa(outBounds, "outBounds"),
                  _mxarray0_,
                  mlfCreateColonIndex()),
                mclArrayRef2(
                  mclVa(outBounds, "outBounds"),
                  _mxarray16_,
                  mlfCreateColonIndex())),
              mclVv(qDegenerate, "qDegenerate")),
            NULL))) {
        /*
         * error('OUTBOUNDS(1,k) may equal OUTBOUNDS(2,k) if and only if INBOUNDS(1,k) equals INBOUNDS(2,k).');
         */
        mlfError(_mxarray108_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * num = outBounds(2,:) - outBounds(1,:);
     */
    mlfAssign(
      &num,
      mclMinus(
        mclArrayRef2(
          mclVa(outBounds, "outBounds"), _mxarray16_, mlfCreateColonIndex()),
        mclArrayRef2(
          mclVa(outBounds, "outBounds"), _mxarray0_, mlfCreateColonIndex())));
    /*
     * den =  inBounds(2,:)  - inBounds(1,:);
     */
    mlfAssign(
      &den,
      mclMinus(
        mclArrayRef2(
          mclVa(inBounds, "inBounds"), _mxarray16_, mlfCreateColonIndex()),
        mclArrayRef2(
          mclVa(inBounds, "inBounds"), _mxarray0_, mlfCreateColonIndex())));
    /*
     * 
     * % Arbitrarily set the scale to unity for degenerate dimensions.
     * num(qDegenerate) = 1;
     */
    mclArrayAssign1(&num, _mxarray0_, mclVv(qDegenerate, "qDegenerate"));
    /*
     * den(qDegenerate) = 1;
     */
    mclArrayAssign1(&den, _mxarray0_, mclVv(qDegenerate, "qDegenerate"));
    /*
     * 
     * scale = num ./ den;
     */
    mlfAssign(&scale, mclRdivide(mclVv(num, "num"), mclVv(den, "den")));
    /*
     * shift = outBounds(1,:) - scale .* inBounds(1,:);
     */
    mlfAssign(
      &shift,
      mclMinus(
        mclArrayRef2(
          mclVa(outBounds, "outBounds"), _mxarray0_, mlfCreateColonIndex()),
        mclTimes(
          mclVv(scale, "scale"),
          mclArrayRef2(
            mclVa(inBounds, "inBounds"), _mxarray0_, mlfCreateColonIndex()))));
    /*
     * A = [[diag(scale) zeros(N,1)]; [shift 1]];
     */
    mlfAssign(
      &A,
      mlfVertcat(
        mlfHorzcat(
          mlfDiag(mclVv(scale, "scale"), NULL),
          mlfZeros(mclVv(N, "N"), _mxarray0_, NULL),
          NULL),
        mlfHorzcat(mclVv(shift, "shift"), _mxarray0_, NULL),
        NULL));
    /*
     * t = maketform('affine',A);
     */
    mlfAssign(&t, mlfMaketform(_mxarray2_, mclVv(A, "A"), NULL));
    mclValidateOutput(t, 1, nargout_, "t", "maketform/box2");
    mxDestroyArray(ans);
    mxDestroyArray(N);
    mxDestroyArray(qDegenerate);
    mxDestroyArray(num);
    mxDestroyArray(den);
    mxDestroyArray(scale);
    mxDestroyArray(shift);
    mxDestroyArray(A);
    mxDestroyArray(outBounds);
    mxDestroyArray(inBounds);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return t;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_getTransformType" is the implementation version of
 * the "maketform/getTransformType" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 691-715). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function transform_type = getTransformType(type)
 */
static mxArray * Mmaketform_getTransformType(int nargout_, mxArray * type) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * transform_type = NULL;
    mxArray * imatch = NULL;
    mxArray * transform_names = NULL;
    mxArray * ans = NULL;
    mxArray * low_type = NULL;
    mclCopyArray(&type);
    /*
     * 
     * if ischar(type)
     */
    if (mlfTobool(mlfIschar(mclVa(type, "type")))) {
        /*
         * low_type = lower(type);
         */
        mlfAssign(&low_type, mlfLower(mclVa(type, "type")));
    /*
     * else
     */
    } else {
        /*
         * error('TRANSFORMTYPE must be a string.');
         */
        mlfError(_mxarray110_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * transform_names = {'affine','projective','composite','custom','box'};
     */
    mlfAssign(&transform_names, _mxarray112_);
    /*
     * 
     * % try to recognize the TransformType
     * imatch = strmatch(low_type,transform_names);
     */
    mlfAssign(
      &imatch,
      mlfStrmatch(
        mclVv(low_type, "low_type"),
        mclVv(transform_names, "transform_names"),
        NULL));
    /*
     * 
     * switch length(imatch)
     */
    {
        mxArray * v_
          = mclInitialize(mlfScalar(mclLengthInt(mclVv(imatch, "imatch"))));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1    % one match
             * transform_type = transform_names{imatch};
             */
            mlfAssign(
              &transform_type,
              mlfIndexRef(
                mclVv(transform_names, "transform_names"),
                "{?}",
                mclVv(imatch, "imatch")));
        /*
         * case 0    % no matches
         */
        } else if (mclSwitchCompare(v_, _mxarray20_)) {
            /*
             * error(['Unrecognized TRANSFORMTYPE ''' type '''.']);
             */
            mlfError(
              mlfHorzcat(_mxarray114_, mclVa(type, "type"), _mxarray116_, NULL),
              NULL);
        /*
         * otherwise % more than one match
         */
        } else {
            /*
             * error(['Ambiguous TRANSFORMTYPE ''' type '''.']);
             */
            mlfError(
              mlfHorzcat(_mxarray118_, mclVa(type, "type"), _mxarray116_, NULL),
              NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(
      transform_type,
      1,
      nargout_,
      "transform_type",
      "maketform/getTransformType");
    mxDestroyArray(low_type);
    mxDestroyArray(ans);
    mxDestroyArray(transform_names);
    mxDestroyArray(imatch);
    mxDestroyArray(type);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return transform_type;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_isfinitedouble" is the implementation version of
 * the "maketform/isfinitedouble" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 715-726). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = isfinitedouble( x )
 */
static mxArray * Mmaketform_isfinitedouble(int nargout_, mxArray * x) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * q = NULL;
    mclCopyArray(&x);
    /*
     * 
     * % Return true iff x is a finite, real-valued double array.
     * 
     * q = isa(x,'double');
     */
    mlfAssign(&q, mlfIsa(mclVa(x, "x"), _mxarray29_));
    /*
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = isreal(x) & all(isfinite(x));
         */
        mlfAssign(
          &q,
          mclAnd(
            mlfIsreal(mclVa(x, "x")),
            mlfAll(mlfIsfinite(mclVa(x, "x")), NULL)));
    /*
     * end
     */
    }
    mclValidateOutput(q, 1, nargout_, "q", "maketform/isfinitedouble");
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_isdoubleinteger" is the implementation version of
 * the "maketform/isdoubleinteger" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 726-739). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = isdoubleinteger( x )
 */
static mxArray * Mmaketform_isdoubleinteger(int nargout_, mxArray * x) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * q = NULL;
    mclCopyArray(&x);
    /*
     * 
     * % Return true iff x is a double array containing 
     * % (real-valued and finite) integers.
     * 
     * if isa(x,'double')
     */
    if (mlfTobool(mlfIsa(mclVa(x, "x"), _mxarray29_))) {
        /*
         * q = ~(~isreal(x) | ~all(x == floor(x)) | ~all(isfinite(x)));
         */
        mlfAssign(
          &q,
          mclNot(
            mclOr(
              mclOr(
                mclNot(mlfIsreal(mclVa(x, "x"))),
                mclNot(
                  mlfAll(mclEq(mclVa(x, "x"), mlfFloor(mclVa(x, "x"))), NULL))),
              mclNot(mlfAll(mlfIsfinite(mclVa(x, "x")), NULL)))));
    /*
     * else
     */
    } else {
        /*
         * q = ~1;
         */
        mlfAssign(&q, _mxarray120_);
    /*
     * end
     */
    }
    mclValidateOutput(q, 1, nargout_, "q", "maketform/isdoubleinteger");
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmaketform_condlimit" is the implementation version of the
 * "maketform/condlimit" M-function from file
 * "k:\matlab6p5\toolbox\images\images\maketform.m" (lines 739-742). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function limit = condlimit
 */
static mxArray * Mmaketform_condlimit(int nargout_) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_maketform);
    mxArray * limit = NULL;
    /*
     * 
     * limit = 1e9;
     */
    mlfAssign(&limit, _mxarray121_);
    mclValidateOutput(limit, 1, nargout_, "limit", "maketform/condlimit");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return limit;
}
