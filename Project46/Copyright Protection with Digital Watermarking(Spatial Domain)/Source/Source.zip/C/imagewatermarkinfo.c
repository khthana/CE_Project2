/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imagewatermarkinfo.h"
#include "gui_mainfcn.h"
#include "guidata.h"
#include "im2double.h"
#include "imread.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[8] = { 'g', 'u', 'i', '_', 'N', 'a', 'm', 'e' };
static mxArray * _mxarray1_;

static mxChar _array4_[13] = { 'g', 'u', 'i', '_', 'S', 'i', 'n',
                               'g', 'l', 'e', 't', 'o', 'n' };
static mxArray * _mxarray3_;

static mxChar _array6_[14] = { 'g', 'u', 'i', '_', 'O', 'p', 'e',
                               'n', 'i', 'n', 'g', 'F', 'c', 'n' };
static mxArray * _mxarray5_;

static mxChar _array8_[13] = { 'g', 'u', 'i', '_', 'O', 'u', 't',
                               'p', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray7_;

static mxChar _array10_[13] = { 'g', 'u', 'i', '_', 'L', 'a', 'y',
                                'o', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[12] = { 'g', 'u', 'i', '_', 'C', 'a',
                                'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray12_;

static mxChar _array15_[15] = { 'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray14_;

static mxChar _array17_[5] = { 'w', 'h', 'i', 't', 'e' };
static mxArray * _mxarray16_;
static mxArray * _mxarray18_;

static mxChar _array20_[31] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', 'U',
                                'i', 'c', 'o', 'n', 't', 'r', 'o', 'l',
                                'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray19_;

static mxChar _array22_[8] = { 'l', 'e', 'n', 'a', '.', 'b', 'm', 'p' };
static mxArray * _mxarray21_;

static mxChar _array24_[13] = { 'l', 'e', 'n', 'a', 'w', 'a', 't',
                                'e', 'r', '.', 'b', 'm', 'p' };
static mxArray * _mxarray23_;
static mxArray * _mxarray25_;
static mxArray * _mxarray26_;
static mxArray * _mxarray27_;
static mxArray * _mxarray28_;

static mxChar _array30_[3] = { 't', 'a', 'g' };
static mxArray * _mxarray29_;

static mxChar _array32_[7] = { 'e', 'd', 'i', 't', 'M', 'S', 'E' };
static mxArray * _mxarray31_;

static mxChar _array34_[6] = { 'S', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray33_;

static mxChar _array36_[8] = { 'e', 'd', 'i', 't', 'P', 'S', 'N', 'R' };
static mxArray * _mxarray35_;

void InitializeModule_imagewatermarkinfo(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeString(8, _array2_);
    _mxarray3_ = mclInitializeString(13, _array4_);
    _mxarray5_ = mclInitializeString(14, _array6_);
    _mxarray7_ = mclInitializeString(13, _array8_);
    _mxarray9_ = mclInitializeString(13, _array10_);
    _mxarray11_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray12_ = mclInitializeString(12, _array13_);
    _mxarray14_ = mclInitializeString(15, _array15_);
    _mxarray16_ = mclInitializeString(5, _array17_);
    _mxarray18_ = mclInitializeDouble(0.0);
    _mxarray19_ = mclInitializeString(31, _array20_);
    _mxarray21_ = mclInitializeString(8, _array22_);
    _mxarray23_ = mclInitializeString(13, _array24_);
    _mxarray25_ = mclInitializeDouble(3.0);
    _mxarray26_ = mclInitializeDouble(2.0);
    _mxarray27_ = mclInitializeDouble(10.0);
    _mxarray28_ = mclInitializeDouble(65025.0);
    _mxarray29_ = mclInitializeString(3, _array30_);
    _mxarray31_ = mclInitializeString(7, _array32_);
    _mxarray33_ = mclInitializeString(6, _array34_);
    _mxarray35_ = mclInitializeString(8, _array36_);
}

void TerminateModule_imagewatermarkinfo(void) {
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static void mlfImagewatermarkinfo_imagewatermarkinfo_OpeningFcn(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles,
                                                                ...);
static void mlxImagewatermarkinfo_imagewatermarkinfo_OpeningFcn(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]);
static mxArray * mlfImagewatermarkinfo_imagewatermarkinfo_OutputFcn(mlfVarargoutList * varargout,
                                                                    mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles);
static void mlxImagewatermarkinfo_imagewatermarkinfo_OutputFcn(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]);
static void mlfImagewatermarkinfo_editPSNR_CreateFcn(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles);
static void mlxImagewatermarkinfo_editPSNR_CreateFcn(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]);
static void mlfImagewatermarkinfo_editPSNR_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxImagewatermarkinfo_editPSNR_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfImagewatermarkinfo_editMSE_CreateFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxImagewatermarkinfo_editMSE_CreateFcn(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfImagewatermarkinfo_editMSE_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void mlxImagewatermarkinfo_editMSE_Callback(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]);
static void mlfImagewatermarkinfo_pushbuttonPSEN_Ok_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void mlxImagewatermarkinfo_pushbuttonPSEN_Ok_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]);
static void mlfImagewatermarkinfo_psnr_mse(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void mlxImagewatermarkinfo_psnr_mse(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * Mimagewatermarkinfo(int nargout_, mxArray * varargin);
static void Mimagewatermarkinfo_imagewatermarkinfo_OpeningFcn(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles,
                                                              mxArray * varargin);
static mxArray * Mimagewatermarkinfo_imagewatermarkinfo_OutputFcn(int nargout_,
                                                                  mxArray * hObject,
                                                                  mxArray * eventdata,
                                                                  mxArray * handles);
static void Mimagewatermarkinfo_editPSNR_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void Mimagewatermarkinfo_editPSNR_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mimagewatermarkinfo_editMSE_CreateFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mimagewatermarkinfo_editMSE_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles);
static void Mimagewatermarkinfo_pushbuttonPSEN_Ok_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void Mimagewatermarkinfo_psnr_mse(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles);

static mexFunctionTableEntry local_function_table_[8]
  = { { "imagewatermarkinfo_OpeningFcn",
        mlxImagewatermarkinfo_imagewatermarkinfo_OpeningFcn, -4, 0, NULL },
      { "imagewatermarkinfo_OutputFcn",
        mlxImagewatermarkinfo_imagewatermarkinfo_OutputFcn, 3, -1, NULL },
      { "editPSNR_CreateFcn",
        mlxImagewatermarkinfo_editPSNR_CreateFcn, 3, 0, NULL },
      { "editPSNR_Callback",
        mlxImagewatermarkinfo_editPSNR_Callback, 3, 0, NULL },
      { "editMSE_CreateFcn",
        mlxImagewatermarkinfo_editMSE_CreateFcn, 3, 0, NULL },
      { "editMSE_Callback",
        mlxImagewatermarkinfo_editMSE_Callback, 3, 0, NULL },
      { "pushbuttonPSEN_Ok_Callback",
        mlxImagewatermarkinfo_pushbuttonPSEN_Ok_Callback, 3, 0, NULL },
      { "psnr_mse", mlxImagewatermarkinfo_psnr_mse, 3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_imagewatermarkinfo
  = { 8, local_function_table_ };

/*
 * The function "mlfNImagewatermarkinfo" contains the nargout interface for the
 * "imagewatermarkinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 1-48). This interface is only produced if the
 * M-function uses the special variable "nargout". The nargout interface allows
 * the number of requested outputs to be specified via the nargout argument, as
 * opposed to the normal interface which dynamically calculates the number of
 * outputs based on the number of non-NULL inputs it receives. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfNImagewatermarkinfo(int nargout,
                                 mlfVarargoutList * varargout,
                                 ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimagewatermarkinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImagewatermarkinfo" contains the normal interface for the
 * "imagewatermarkinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 1-48). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfImagewatermarkinfo(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimagewatermarkinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImagewatermarkinfo" contains the void interface for the
 * "imagewatermarkinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 1-48). The void interface is only produced if
 * the M-function uses the special variable "nargout", and has at least one
 * output. The void interface function specifies zero output arguments to the
 * implementation version of the function, and in the event that the
 * implementation version still returns an output (which, in MATLAB, would be
 * assigned to the "ans" variable), it deallocates the output. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
void mlfVImagewatermarkinfo(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimagewatermarkinfo(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImagewatermarkinfo" contains the feval interface for the
 * "imagewatermarkinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 1-48). The feval function calls the
 * implementation version of imagewatermarkinfo through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlxImagewatermarkinfo(int nlhs,
                           mxArray * plhs[],
                           int nrhs,
                           mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimagewatermarkinfo(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImagewatermarkinfo_imagewatermarkinfo_OpeningFcn" contains
 * the normal interface for the
 * "imagewatermarkinfo/imagewatermarkinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 48-71). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_imagewatermarkinfo_OpeningFcn(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles,
                                                                ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, hObject, eventdata, handles, varargin);
    Mimagewatermarkinfo_imagewatermarkinfo_OpeningFcn(
      hObject, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImagewatermarkinfo_imagewatermarkinfo_OpeningFcn" contains
 * the feval interface for the
 * "imagewatermarkinfo/imagewatermarkinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 48-71). The feval function calls the
 * implementation version of imagewatermarkinfo/imagewatermarkinfo_OpeningFcn
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_imagewatermarkinfo_OpeningFcn(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/imagewatermark"
            "info_OpeningFcn Line: 48 Column: 1 The function \"image"
            "watermarkinfo/imagewatermarkinfo_OpeningFcn\" was calle"
            "d with more than the declared number of outputs (0)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    Mimagewatermarkinfo_imagewatermarkinfo_OpeningFcn(
      mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfImagewatermarkinfo_imagewatermarkinfo_OutputFcn" contains
 * the normal interface for the
 * "imagewatermarkinfo/imagewatermarkinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 71-83). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static mxArray * mlfImagewatermarkinfo_imagewatermarkinfo_OutputFcn(mlfVarargoutList * varargout,
                                                                    mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles) {
    int nargout = 0;
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mimagewatermarkinfo_imagewatermarkinfo_OutputFcn(
          nargout, hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxImagewatermarkinfo_imagewatermarkinfo_OutputFcn" contains
 * the feval interface for the
 * "imagewatermarkinfo/imagewatermarkinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 71-83). The feval function calls the
 * implementation version of imagewatermarkinfo/imagewatermarkinfo_OutputFcn
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_imagewatermarkinfo_OutputFcn(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/imagewatermar"
            "kinfo_OutputFcn Line: 71 Column: 1 The function \"imag"
            "ewatermarkinfo/imagewatermarkinfo_OutputFcn\" was call"
            "ed with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0]
      = Mimagewatermarkinfo_imagewatermarkinfo_OutputFcn(
          nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_editPSNR_CreateFcn" contains the normal
 * interface for the "imagewatermarkinfo/editPSNR_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 83-100). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_editPSNR_CreateFcn(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_editPSNR_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_editPSNR_CreateFcn" contains the feval
 * interface for the "imagewatermarkinfo/editPSNR_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 83-100). The feval function calls the
 * implementation version of imagewatermarkinfo/editPSNR_CreateFcn through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_editPSNR_CreateFcn(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editPSNR_CreateFcn Line: "
            "83 Column: 1 The function \"imagewatermarkinfo/editPSNR_CreateFcn"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editPSNR_CreateFcn Line: "
            "83 Column: 1 The function \"imagewatermarkinfo/editPSNR_CreateFcn"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_editPSNR_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_editPSNR_Callback" contains the normal
 * interface for the "imagewatermarkinfo/editPSNR_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 100-111). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_editPSNR_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_editPSNR_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_editPSNR_Callback" contains the feval
 * interface for the "imagewatermarkinfo/editPSNR_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 100-111). The feval function calls the
 * implementation version of imagewatermarkinfo/editPSNR_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_editPSNR_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editPSNR_Callback Line: 1"
            "00 Column: 1 The function \"imagewatermarkinfo/editPSNR_Callback\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editPSNR_Callback Line: "
            "100 Column: 1 The function \"imagewatermarkinfo/editPSNR_Callback"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_editPSNR_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_editMSE_CreateFcn" contains the normal
 * interface for the "imagewatermarkinfo/editMSE_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 111-127). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_editMSE_CreateFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_editMSE_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_editMSE_CreateFcn" contains the feval
 * interface for the "imagewatermarkinfo/editMSE_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 111-127). The feval function calls the
 * implementation version of imagewatermarkinfo/editMSE_CreateFcn through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_editMSE_CreateFcn(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editMSE_CreateFcn Line: 1"
            "11 Column: 1 The function \"imagewatermarkinfo/editMSE_CreateFcn\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editMSE_CreateFcn Line: "
            "111 Column: 1 The function \"imagewatermarkinfo/editMSE_CreateFcn"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_editMSE_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_editMSE_Callback" contains the normal
 * interface for the "imagewatermarkinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 127-137). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_editMSE_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_editMSE_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_editMSE_Callback" contains the feval
 * interface for the "imagewatermarkinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 127-137). The feval function calls the
 * implementation version of imagewatermarkinfo/editMSE_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_editMSE_Callback(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editMSE_Callback Line: 1"
            "27 Column: 1 The function \"imagewatermarkinfo/editMSE_Callback\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/editMSE_Callback Line: 1"
            "27 Column: 1 The function \"imagewatermarkinfo/editMSE_Callback\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_editMSE_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_pushbuttonPSEN_Ok_Callback" contains the
 * normal interface for the "imagewatermarkinfo/pushbuttonPSEN_Ok_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imagewatermarkinfo.m" (lines 137-143). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfImagewatermarkinfo_pushbuttonPSEN_Ok_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_pushbuttonPSEN_Ok_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_pushbuttonPSEN_Ok_Callback" contains the
 * feval interface for the "imagewatermarkinfo/pushbuttonPSEN_Ok_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imagewatermarkinfo.m" (lines 137-143). The feval
 * function calls the implementation version of
 * imagewatermarkinfo/pushbuttonPSEN_Ok_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_pushbuttonPSEN_Ok_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/pushbuttonPSE"
            "N_Ok_Callback Line: 137 Column: 1 The function \"image"
            "watermarkinfo/pushbuttonPSEN_Ok_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/pushbuttonPSE"
            "N_Ok_Callback Line: 137 Column: 1 The function \"image"
            "watermarkinfo/pushbuttonPSEN_Ok_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_pushbuttonPSEN_Ok_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImagewatermarkinfo_psnr_mse" contains the normal interface
 * for the "imagewatermarkinfo/psnr_mse" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 143-177). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImagewatermarkinfo_psnr_mse(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimagewatermarkinfo_psnr_mse(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImagewatermarkinfo_psnr_mse" contains the feval interface
 * for the "imagewatermarkinfo/psnr_mse" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 143-177). The feval function calls the
 * implementation version of imagewatermarkinfo/psnr_mse through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImagewatermarkinfo_psnr_mse(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/psnr_mse Line: 143 "
            "Column: 1 The function \"imagewatermarkinfo/psnr_mse\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imagewatermarkinfo/psnr_mse Line: 143"
            " Column: 1 The function \"imagewatermarkinfo/psnr_mse\" was"
            " called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimagewatermarkinfo_psnr_mse(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "Mimagewatermarkinfo" is the implementation version of the
 * "imagewatermarkinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 1-48). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function varargout = imagewatermarkinfo(varargin)
 */
static mxArray * Mimagewatermarkinfo(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * _T0_ = NULL;
    mxArray * gui_State = NULL;
    mxArray * gui_Singleton = NULL;
    mclCopyArray(&varargin);
    /*
     * % IMAGEWATERMARKINFO M-file for imagewatermarkinfo.fig
     * %      IMAGEWATERMARKINFO, by itself, creates a new IMAGEWATERMARKINFO or raises the existing
     * %      singleton*.
     * %
     * %      H = IMAGEWATERMARKINFO returns the handle to a new IMAGEWATERMARKINFO or the handle to
     * %      the existing singleton*.
     * %
     * %      IMAGEWATERMARKINFO('CALLBACK',hObject,eventData,handles,...) calls the local
     * %      function named CALLBACK in IMAGEWATERMARKINFO.M with the given input arguments.
     * %
     * %      IMAGEWATERMARKINFO('Property','Value',...) creates a new IMAGEWATERMARKINFO or raises the
     * %      existing singleton*.  Starting from the left, property value pairs are
     * %      applied to the GUI before imagewatermarkinfo_OpeningFunction gets called.  An
     * %      unrecognized property name or invalid value makes property application
     * %      stop.  All inputs are passed to imagewatermarkinfo_OpeningFcn via varargin.
     * %
     * %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
     * %      instance to run (singleton)".
     * %
     * % See also: GUIDE, GUIDATA, GUIHANDLES
     * 
     * % Edit the above text to modify the response to help imagewatermarkinfo
     * 
     * % Last Modified by GUIDE v2.5 07-Mar-2004 02:00:55
     * 
     * % Begin initialization code - DO NOT EDIT
     * gui_Singleton = 1;
     */
    mlfAssign(&gui_Singleton, _mxarray0_);
    /*
     * gui_State = struct('gui_Name',       mfilename, ...
     */
    mlfAssign(
      &gui_State,
      mlfStruct(
        _mxarray1_,
        mxCreateString("imagewatermarkinfo"),
        _mxarray3_,
        mclVv(gui_Singleton, "gui_Singleton"),
        _mxarray5_,
        mclCreateSimpleFunctionHandle(
          mlxImagewatermarkinfo_imagewatermarkinfo_OpeningFcn,
          "imagewatermarkinfo_OpeningFcn"),
        _mxarray7_,
        mclCreateSimpleFunctionHandle(
          mlxImagewatermarkinfo_imagewatermarkinfo_OutputFcn,
          "imagewatermarkinfo_OutputFcn"),
        _mxarray9_,
        _mxarray11_,
        _mxarray12_,
        _mxarray11_,
        NULL));
    /*
     * 'gui_Singleton',  gui_Singleton, ...
     * 'gui_OpeningFcn', @imagewatermarkinfo_OpeningFcn, ...
     * 'gui_OutputFcn',  @imagewatermarkinfo_OutputFcn, ...
     * 'gui_LayoutFcn',  [] , ...
     * 'gui_Callback',   []);
     * if nargin & isstr(varargin{1})
     */
    {
        mxArray * a_ = mclInitialize(mlfScalar(nargin_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIsstr,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * gui_State.gui_Callback = str2func(varargin{1});
             */
            mlfIndexAssign(
              &gui_State,
              ".gui_Callback",
              mclFeval(
                mclValueVarargout(),
                mlxStr2func,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if nargout
     */
    if (nargout_ != 0) {
        mlfAssign(&_T0_, mlfColon(_mxarray0_, mlfScalar(nargout_), NULL));
        /*
         * [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
         */
        mlfNGui_mainfcn(
          0,
          mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
          mclVv(gui_State, "gui_State"),
          mlfIndexRef(
            mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
          NULL);
    /*
     * else
     */
    } else {
        /*
         * gui_mainfcn(gui_State, varargin{:});
         */
        mclAssignAns(
          &ans,
          mlfNGui_mainfcn(
            0,
            mclAnsVarargout(),
            mclVv(gui_State, "gui_State"),
            mlfIndexRef(
              mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(gui_Singleton);
    mxDestroyArray(gui_State);
    mxDestroyArray(_T0_);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * % End initialization code - DO NOT EDIT
     * 
     * 
     * % --- Executes just before imagewatermarkinfo is made visible.
     */
}

/*
 * The function "Mimagewatermarkinfo_imagewatermarkinfo_OpeningFcn" is the
 * implementation version of the
 * "imagewatermarkinfo/imagewatermarkinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 48-71). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function imagewatermarkinfo_OpeningFcn(hObject, eventdata, handles, varargin)
 */
static void Mimagewatermarkinfo_imagewatermarkinfo_OpeningFcn(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles,
                                                              mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * % This function has no output args, see OutputFcn.
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * % varargin   command line arguments to imagewatermarkinfo (see VARARGIN)
     * 
     * % Choose default command line output for imagewatermarkinfo
     * handles.output = hObject;
     */
    mlfIndexAssign(&handles, ".output", mclVa(hObject, "hObject"));
    /*
     * 
     * %h_image=imfinfo('mark.bmp','bmp');
     * %set(handles.editFilename,'String',h_image.Filename);
     * 
     * % Update handles structure
     * 
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * %psnr_mse(hObject,eventdata,handles);
     * 
     * % UIWAIT makes imagewatermarkinfo wait for user response (see UIRESUME)
     * % uiwait(handles.figure2);
     * 
     * 
     * % --- Outputs from this function are returned to the command line.
     */
}

/*
 * The function "Mimagewatermarkinfo_imagewatermarkinfo_OutputFcn" is the
 * implementation version of the
 * "imagewatermarkinfo/imagewatermarkinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 71-83). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function varargout = imagewatermarkinfo_OutputFcn(hObject, eventdata, handles)
 */
static mxArray * Mimagewatermarkinfo_imagewatermarkinfo_OutputFcn(int nargout_,
                                                                  mxArray * hObject,
                                                                  mxArray * eventdata,
                                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * varargout = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % varargout  cell array for returning output args (see VARARGOUT);
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Get default command line output from handles structure
     * varargout{1} = handles.output;
     */
    mlfIndexAssign(
      &varargout,
      "{?}",
      _mxarray0_,
      mlfIndexRef(mclVa(handles, "handles"), ".output"));
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimagewatermarkinfo_editPSNR_CreateFcn" is the implementation
 * version of the "imagewatermarkinfo/editPSNR_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 83-100). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function editPSNR_CreateFcn(hObject, eventdata, handles)
 */
static void Mimagewatermarkinfo_editPSNR_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editPSNR (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % set(findobj('tag','editPSNR'),'String',psnr);
     * % set(findobj('tag','editPSNR'),'String',handles.psnr_pass);
     * % set(findobj('tag','editPSNR'),'String','PSNR');
     * 
     * 
     */
}

/*
 * The function "Mimagewatermarkinfo_editPSNR_Callback" is the implementation
 * version of the "imagewatermarkinfo/editPSNR_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 100-111). It contains the actual compiled
 * code for that M-function. It is a static function and must only be called
 * from one of the interface functions, appearing below.
 */
/*
 * function editPSNR_Callback(hObject, eventdata, handles)
 */
static void Mimagewatermarkinfo_editPSNR_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editPSNR (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editPSNR as text
     * %        str2double(get(hObject,'String')) returns contents of editPSNR as a double
     * % set(findobj('tag','editPSNR'),'String',handles.psnr_pass);          
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimagewatermarkinfo_editMSE_CreateFcn" is the implementation
 * version of the "imagewatermarkinfo/editMSE_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 111-127). It contains the actual compiled
 * code for that M-function. It is a static function and must only be called
 * from one of the interface functions, appearing below.
 */
/*
 * function editMSE_CreateFcn(hObject, eventdata, handles)
 */
static void Mimagewatermarkinfo_editMSE_CreateFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editMSE (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % set(findobj('tag','editMSE'),'String',mse);
     * %set(findobj('tag','editMSE'),'String',handles.mse_pass );
     * % set(findobj('tag','editMSE'),'String','MSE');
     * 
     */
}

/*
 * The function "Mimagewatermarkinfo_editMSE_Callback" is the implementation
 * version of the "imagewatermarkinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 127-137). It contains the actual compiled
 * code for that M-function. It is a static function and must only be called
 * from one of the interface functions, appearing below.
 */
/*
 * function editMSE_Callback(hObject, eventdata,handles)
 */
static void Mimagewatermarkinfo_editMSE_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editMSE (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editMSE as text
     * %        str2double(get(hObject,'String')) returns contents of editMSE as a double
     * %set(findobj('tag','editMSE'),'String',handles.mse_pass );
     * 
     * % --- Executes on button press in pushbuttonPSEN_Ok.
     */
}

/*
 * The function "Mimagewatermarkinfo_pushbuttonPSEN_Ok_Callback" is the
 * implementation version of the
 * "imagewatermarkinfo/pushbuttonPSEN_Ok_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 137-143). It contains the actual compiled
 * code for that M-function. It is a static function and must only be called
 * from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonPSEN_Ok_Callback(hObject, eventdata, handles)
 */
static void Mimagewatermarkinfo_pushbuttonPSEN_Ok_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonPSEN_Ok (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * delete(gcf);
     */
    mlfDelete(mlfGcf(), NULL);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     */
}

/*
 * The function "Mimagewatermarkinfo_psnr_mse" is the implementation version of
 * the "imagewatermarkinfo/psnr_mse" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imagewatermarkinfo.m" (lines 143-177). It contains the actual compiled
 * code for that M-function. It is a static function and must only be called
 * from one of the interface functions, appearing below.
 */
/*
 * function psnr_mse(hObject,eventdata,handles)
 */
static void Mimagewatermarkinfo_psnr_mse(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imagewatermarkinfo);
    mxArray * ans = NULL;
    mxArray * psnr = NULL;
    mxArray * mse = NULL;
    mxArray * k2 = NULL;
    mxArray * k1 = NULL;
    mxArray * acc = NULL;
    mxArray * iscolor = NULL;
    mxArray * N = NULL;
    mxArray * im2 = NULL;
    mxArray * im1 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %im1 = imread(im1);
     * im1=imread('lena.bmp');
     */
    mlfAssign(&im1, mlfNImread(1, NULL, NULL, _mxarray21_, NULL));
    /*
     * im1 = im2double(im1);
     */
    mlfAssign(&im1, mlfIm2double(mclVv(im1, "im1"), NULL));
    /*
     * 
     * %   im2 = imread(im2);
     * im2 = imread('lenawater.bmp');
     */
    mlfAssign(&im2, mlfNImread(1, NULL, NULL, _mxarray23_, NULL));
    /*
     * im2 = im2double(im2);
     */
    mlfAssign(&im2, mlfIm2double(mclVv(im2, "im2"), NULL));
    /*
     * 
     * 
     * N = size(im1);
     */
    mlfAssign(&N, mlfSize(mclValueVarargout(), mclVv(im1, "im1"), NULL));
    /*
     * 
     * iscolor = size(N);
     */
    mlfAssign(&iscolor, mlfSize(mclValueVarargout(), mclVv(N, "N"), NULL));
    /*
     * if iscolor(2) == 3;
     */
    if (mclEqBool(mclIntArrayRef1(mclVv(iscolor, "iscolor"), 2), _mxarray25_)) {
        /*
         * im1 = im1(:,:,3);
         */
        mlfAssign(
          &im1,
          mlfIndexRef(
            mclVv(im1, "im1"),
            "(?,?,?)",
            mlfCreateColonIndex(),
            mlfCreateColonIndex(),
            _mxarray25_));
        /*
         * im2 = im2(:,:,3);
         */
        mlfAssign(
          &im2,
          mlfIndexRef(
            mclVv(im2, "im2"),
            "(?,?,?)",
            mlfCreateColonIndex(),
            mlfCreateColonIndex(),
            _mxarray25_));
    /*
     * end;
     */
    }
    /*
     * acc = 0;
     */
    mlfAssign(&acc, _mxarray18_);
    /*
     * 
     * for k1=1:N(1)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclIntArrayRef1(mclVv(N, "N"), 1));
        if (v_ > e_) {
            mlfAssign(&k1, _mxarray11_);
        } else {
            /*
             * for k2=1:N(2)
             * acc = acc+ ( im1(k1,k2) - im2(k1,k2) )^2;   
             * end
             * end
             */
            for (; ; ) {
                int v_0 = mclForIntStart(1);
                int e_0 = mclForIntEnd(mclIntArrayRef1(mclVv(N, "N"), 2));
                if (v_0 > e_0) {
                    mlfAssign(&k2, _mxarray11_);
                } else {
                    for (; ; ) {
                        mlfAssign(
                          &acc,
                          mclPlus(
                            mclVv(acc, "acc"),
                            mclMpower(
                              mclMinus(
                                mclIntArrayRef2(mclVv(im1, "im1"), v_, v_0),
                                mclIntArrayRef2(mclVv(im2, "im2"), v_, v_0)),
                              _mxarray26_)));
                        if (v_0 == e_0) {
                            break;
                        }
                        ++v_0;
                    }
                    mlfAssign(&k2, mlfScalar(v_0));
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k1, mlfScalar(v_));
        }
    }
    /*
     * 
     * mse  = acc/(N(1)*N(2));
     */
    mlfAssign(
      &mse,
      mclMrdivide(
        mclVv(acc, "acc"),
        mclMtimes(
          mclIntArrayRef1(mclVv(N, "N"), 1),
          mclIntArrayRef1(mclVv(N, "N"), 2))));
    /*
     * psnr = 10*log10((255^2)/mse);
     */
    mlfAssign(
      &psnr,
      mclMtimes(
        _mxarray27_, mlfLog10(mclMrdivide(_mxarray28_, mclVv(mse, "mse")))));
    /*
     * %   disp(mse);
     * %    disp(psnr);
     * 
     * handles.mse_pass=mse;
     */
    mlfIndexAssign(&handles, ".mse_pass", mclVv(mse, "mse"));
    /*
     * handles.psnr_pass=psnr;
     */
    mlfIndexAssign(&handles, ".psnr_pass", mclVv(psnr, "psnr"));
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * set(findobj('tag','editMSE'),'String',handles.mse_pass );
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray29_, _mxarray31_, NULL),
        _mxarray33_,
        mlfIndexRef(mclVa(handles, "handles"), ".mse_pass"),
        NULL));
    /*
     * set(findobj('tag','editPSNR'),'String',handles.psnr_pass);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray29_, _mxarray35_, NULL),
        _mxarray33_,
        mlfIndexRef(mclVa(handles, "handles"), ".psnr_pass"),
        NULL));
    mxDestroyArray(im1);
    mxDestroyArray(im2);
    mxDestroyArray(N);
    mxDestroyArray(iscolor);
    mxDestroyArray(acc);
    mxDestroyArray(k1);
    mxDestroyArray(k2);
    mxDestroyArray(mse);
    mxDestroyArray(psnr);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
