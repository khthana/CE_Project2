/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_num2ordinal.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;

static mxChar _array4_[5] = { 'f', 'i', 'r', 's', 't' };
static mxArray * _mxarray3_;

static mxChar _array6_[6] = { 's', 'e', 'c', 'o', 'n', 'd' };
static mxArray * _mxarray5_;

static mxChar _array8_[5] = { 't', 'h', 'i', 'r', 'd' };
static mxArray * _mxarray7_;

static mxChar _array10_[6] = { 'f', 'o', 'u', 'r', 't', 'h' };
static mxArray * _mxarray9_;

static mxChar _array12_[5] = { 'f', 'i', 'f', 't', 'h' };
static mxArray * _mxarray11_;

static mxChar _array14_[5] = { 's', 'i', 'x', 't', 'h' };
static mxArray * _mxarray13_;

static mxChar _array16_[7] = { 's', 'e', 'v', 'e', 'n', 't', 'h' };
static mxArray * _mxarray15_;

static mxChar _array18_[6] = { 'e', 'i', 'g', 'h', 't', 'h' };
static mxArray * _mxarray17_;

static mxChar _array20_[5] = { 'n', 'i', 'n', 't', 'h' };
static mxArray * _mxarray19_;

static mxChar _array22_[5] = { 't', 'e', 'n', 't', 'h' };
static mxArray * _mxarray21_;

static mxChar _array24_[8] = { 'e', 'l', 'e', 'v', 'e', 'n', 't', 'h' };
static mxArray * _mxarray23_;

static mxChar _array26_[7] = { 't', 'w', 'e', 'l', 'f', 't', 'h' };
static mxArray * _mxarray25_;

static mxChar _array28_[10] = { 't', 'h', 'i', 'r', 't',
                                'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray27_;

static mxChar _array30_[10] = { 'f', 'o', 'u', 'r', 't',
                                'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray29_;

static mxChar _array32_[9] = { 'f', 'i', 'f', 't', 'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray31_;

static mxChar _array34_[9] = { 's', 'i', 'x', 't', 'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray33_;

static mxChar _array36_[11] = { 's', 'e', 'v', 'e', 'n', 't',
                                'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray35_;

static mxChar _array38_[10] = { 'e', 'i', 'g', 'h', 't',
                                'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray37_;

static mxChar _array40_[10] = { 'n', 'i', 'n', 'e', 't',
                                'e', 'e', 'n', 't', 'h' };
static mxArray * _mxarray39_;

static mxChar _array42_[9] = { 't', 'w', 'e', 'n', 't', 'i', 'e', 't', 'h' };
static mxArray * _mxarray41_;

static mxArray * _array2_[20] = { NULL /*_mxarray3_*/, NULL /*_mxarray5_*/,
                                  NULL /*_mxarray7_*/, NULL /*_mxarray9_*/,
                                  NULL /*_mxarray11_*/, NULL /*_mxarray13_*/,
                                  NULL /*_mxarray15_*/, NULL /*_mxarray17_*/,
                                  NULL /*_mxarray19_*/, NULL /*_mxarray21_*/,
                                  NULL /*_mxarray23_*/, NULL /*_mxarray25_*/,
                                  NULL /*_mxarray27_*/, NULL /*_mxarray29_*/,
                                  NULL /*_mxarray31_*/, NULL /*_mxarray33_*/,
                                  NULL /*_mxarray35_*/, NULL /*_mxarray37_*/,
                                  NULL /*_mxarray39_*/, NULL /*_mxarray41_*/ };
static mxArray * _mxarray1_;

static mxChar _array46_[2] = { 't', 'h' };
static mxArray * _mxarray45_;

static mxChar _array48_[2] = { 's', 't' };
static mxArray * _mxarray47_;

static mxChar _array50_[2] = { 'n', 'd' };
static mxArray * _mxarray49_;

static mxChar _array52_[2] = { 'r', 'd' };
static mxArray * _mxarray51_;

static mxArray * _array44_[10] = { NULL /*_mxarray45_*/, NULL /*_mxarray47_*/,
                                   NULL /*_mxarray49_*/, NULL /*_mxarray51_*/,
                                   NULL /*_mxarray45_*/, NULL /*_mxarray45_*/,
                                   NULL /*_mxarray45_*/, NULL /*_mxarray45_*/,
                                   NULL /*_mxarray45_*/, NULL /*_mxarray45_*/ };
static mxArray * _mxarray43_;
static mxArray * _mxarray53_;

static mxChar _array55_[4] = { '%', 'd', '%', 's' };
static mxArray * _mxarray54_;
static mxArray * _mxarray56_;

void InitializeModule_images_private_num2ordinal(void) {
    _mxarray0_ = mclInitializeDouble(20.0);
    _mxarray3_ = mclInitializeString(5, _array4_);
    _array2_[0] = _mxarray3_;
    _mxarray5_ = mclInitializeString(6, _array6_);
    _array2_[1] = _mxarray5_;
    _mxarray7_ = mclInitializeString(5, _array8_);
    _array2_[2] = _mxarray7_;
    _mxarray9_ = mclInitializeString(6, _array10_);
    _array2_[3] = _mxarray9_;
    _mxarray11_ = mclInitializeString(5, _array12_);
    _array2_[4] = _mxarray11_;
    _mxarray13_ = mclInitializeString(5, _array14_);
    _array2_[5] = _mxarray13_;
    _mxarray15_ = mclInitializeString(7, _array16_);
    _array2_[6] = _mxarray15_;
    _mxarray17_ = mclInitializeString(6, _array18_);
    _array2_[7] = _mxarray17_;
    _mxarray19_ = mclInitializeString(5, _array20_);
    _array2_[8] = _mxarray19_;
    _mxarray21_ = mclInitializeString(5, _array22_);
    _array2_[9] = _mxarray21_;
    _mxarray23_ = mclInitializeString(8, _array24_);
    _array2_[10] = _mxarray23_;
    _mxarray25_ = mclInitializeString(7, _array26_);
    _array2_[11] = _mxarray25_;
    _mxarray27_ = mclInitializeString(10, _array28_);
    _array2_[12] = _mxarray27_;
    _mxarray29_ = mclInitializeString(10, _array30_);
    _array2_[13] = _mxarray29_;
    _mxarray31_ = mclInitializeString(9, _array32_);
    _array2_[14] = _mxarray31_;
    _mxarray33_ = mclInitializeString(9, _array34_);
    _array2_[15] = _mxarray33_;
    _mxarray35_ = mclInitializeString(11, _array36_);
    _array2_[16] = _mxarray35_;
    _mxarray37_ = mclInitializeString(10, _array38_);
    _array2_[17] = _mxarray37_;
    _mxarray39_ = mclInitializeString(10, _array40_);
    _array2_[18] = _mxarray39_;
    _mxarray41_ = mclInitializeString(9, _array42_);
    _array2_[19] = _mxarray41_;
    _mxarray1_ = mclInitializeCellVector(1, 20, _array2_);
    _mxarray45_ = mclInitializeString(2, _array46_);
    _array44_[0] = _mxarray45_;
    _mxarray47_ = mclInitializeString(2, _array48_);
    _array44_[1] = _mxarray47_;
    _mxarray49_ = mclInitializeString(2, _array50_);
    _array44_[2] = _mxarray49_;
    _mxarray51_ = mclInitializeString(2, _array52_);
    _array44_[3] = _mxarray51_;
    _array44_[4] = _mxarray45_;
    _array44_[5] = _mxarray45_;
    _array44_[6] = _mxarray45_;
    _array44_[7] = _mxarray45_;
    _array44_[8] = _mxarray45_;
    _array44_[9] = _mxarray45_;
    _mxarray43_ = mclInitializeCellVector(1, 10, _array44_);
    _mxarray53_ = mclInitializeDouble(10.0);
    _mxarray54_ = mclInitializeString(4, _array55_);
    _mxarray56_ = mclInitializeDouble(1.0);
}

void TerminateModule_images_private_num2ordinal(void) {
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_num2ordinal(int nargout_, mxArray * number);

_mexLocalFunctionTable _local_function_table_images_private_num2ordinal
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_num2ordinal" contains the normal interface
 * for the "images/private/num2ordinal" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\num2ordinal.m" (lines 1-30).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImages_private_num2ordinal(mxArray * number) {
    int nargout = 1;
    mxArray * string = NULL;
    mlfEnterNewContext(0, 1, number);
    string = Mimages_private_num2ordinal(nargout, number);
    mlfRestorePreviousContext(0, 1, number);
    return mlfReturnValue(string);
}

/*
 * The function "mlxImages_private_num2ordinal" contains the feval interface
 * for the "images/private/num2ordinal" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\num2ordinal.m" (lines 1-30). The
 * feval function calls the implementation version of
 * images/private/num2ordinal through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
void mlxImages_private_num2ordinal(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/num2ordinal Line: 1 C"
            "olumn: 1 The function \"images/private/num2ordinal\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/num2ordinal Line: 1 C"
            "olumn: 1 The function \"images/private/num2ordinal\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimages_private_num2ordinal(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_num2ordinal" is the implementation version of
 * the "images/private/num2ordinal" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\num2ordinal.m" (lines 1-30). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function string = num2ordinal(number)
 */
static mxArray * Mimages_private_num2ordinal(int nargout_, mxArray * number) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_num2ordinal);
    mxArray * string = NULL;
    mxArray * ones_digit = NULL;
    mxArray * table2 = NULL;
    mxArray * table1 = NULL;
    mclCopyArray(&number);
    /*
     * %NUM2ORDINAL Convert positive integer to ordinal string.
     * %   STRING = NUM2ORDINAL(NUMBER) converts a positive integer to an
     * %   ordinal string.  For example, NUM2ORDINAL(4) returns the string
     * %   'fourth' and NUM2ORDINAL(23) returns '23rd'.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.2 $  $Date: 2002/03/15 15:58:13 $
     * 
     * %   I/O Spec
     * %   ========
     * %   NUMBER     Scalar positive integer
     * %              Numeric
     * %
     * %   NUMBER is not checked for validity.
     * 
     * if number <= 20
     */
    if (mclLeBool(mclVa(number, "number"), _mxarray0_)) {
        /*
         * table1 = {'first' 'second' 'third' 'fourth' 'fifth' 'sixth' 'seventh' ...
         */
        mlfAssign(&table1, _mxarray1_);
        /*
         * 'eighth' 'ninth' 'tenth' 'eleventh' 'twelfth' 'thirteenth' ...
         * 'fourteenth' 'fifteenth' 'sixteenth' 'seventeenth' ...
         * 'eighteenth' 'nineteenth' 'twentieth'};
         * 
         * string = table1{number};
         */
        mlfAssign(
          &string,
          mlfIndexRef(mclVv(table1, "table1"), "{?}", mclVa(number, "number")));
    /*
     * 
     * else
     */
    } else {
        /*
         * table2 = {'th' 'st' 'nd' 'rd' 'th' 'th' 'th' 'th' 'th' 'th'};
         */
        mlfAssign(&table2, _mxarray43_);
        /*
         * ones_digit = rem(number, 10);
         */
        mlfAssign(&ones_digit, mlfRem(mclVa(number, "number"), _mxarray53_));
        /*
         * string = sprintf('%d%s',number,table2{ones_digit + 1});
         */
        mlfAssign(
          &string,
          mlfSprintf(
            NULL,
            _mxarray54_,
            mclVa(number, "number"),
            mlfIndexRef(
              mclVv(table2, "table2"),
              "{?}",
              mclPlus(mclVv(ones_digit, "ones_digit"), _mxarray56_)),
            NULL));
    /*
     * end
     */
    }
    mclValidateOutput(
      string, 1, nargout_, "string", "images/private/num2ordinal");
    mxDestroyArray(table1);
    mxDestroyArray(table2);
    mxDestroyArray(ones_digit);
    mxDestroyArray(number);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return string;
}
