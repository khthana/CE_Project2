/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#include "libmatlb.h"
#include "libsgl.h"
#include "watermark005.h"
#include "dither.h"
#include "fspecial.h"
#include "gui_mainfcn.h"
#include "guidata.h"
#include "im2double.h"
#include "imageextractinfo.h"
#include "imageinfo.h"
#include "imagewatermarkinfo.h"
#include "imcrop.h"
#include "imfilter.h"
#include "imread.h"
#include "imresize.h"
#include "imrotate.h"
#include "imshow.h"
#include "iptsetpref.h"
#include "normxcorr2.h"
#include "randint.h"
#include "rgb2gray.h"
#include "subplot.h"
#include "title.h"
#include "waitbar.h"
#include "images_private_checknargin.h"
#include "images_private_ditherc_mex_interface.h"
#include "im2uint8.h"
#include "images_private_checkinput.h"
#include "images_private_checkstrs.h"
#include "guihandles.h"
#include "openfig.h"
#include "getimage.h"
#include "getrect.h"
#include "imadd.h"
#include "images_private_imfilter_mex_mex_interface.h"
#include "imsubtract.h"
#include "padarray.h"
#include "images_private_changeclass.h"
#include "fliptform.h"
#include "makeresampler.h"
#include "maketform.h"
#include "tformarray.h"
#include "tformfwd.h"
#include "iptgetpref.h"
#include "truesize.h"
#include "images_private_iptprefs.h"
#include "images_private_iptregistry_mex_interface.h"
#include "images_private_grayto8_mex_interface.h"
#include "images_private_num2ordinal.h"
#include "strread.h"
#include "isvarname.h"
#include "movegui.h"
#include "images_private_getcurpt.h"
#include "xlim.h"
#include "ylim.h"
#include "zlim.h"
#include "imlincomb.h"
#include "images_private_mkconstarray.h"
#include "im2uint16.h"
#include "images_private_istform.h"
#include "images_private_resampsep_mex_interface.h"
#include "images_private_isresampler.h"
#include "tforminv.h"
#include "dataread_mex_interface.h"
#include "iskeyword.h"
#include "images_private_imlincombc_mex_interface.h"
#include "images_private_grayto16_mex_interface.h"
#include "libmmfile.h"
#include "libmwsglm.h"

extern _mex_information _main_info;

mxArray * GETRECT_AX = NULL;

mxArray * GETRECT_FIG = NULL;

mxArray * GETRECT_H1 = NULL;

mxArray * GETRECT_H2 = NULL;

mxArray * GETRECT_PT1 = NULL;

mxArray * GETRECT_TYPE = NULL;

static mexGlobalTableEntry global_table[6]
  = { { "GETRECT_AX", &GETRECT_AX }, { "GETRECT_FIG", &GETRECT_FIG },
      { "GETRECT_H1", &GETRECT_H1 }, { "GETRECT_H2", &GETRECT_H2 },
      { "GETRECT_PT1", &GETRECT_PT1 }, { "GETRECT_TYPE", &GETRECT_TYPE } };

static mexFunctionTableEntry function_table[65]
  = { { "watermark005", mlxWatermark005, -1, -1,
        &_local_function_table_watermark005 },
      { "dither", mlxDither, -1, -1, &_local_function_table_dither },
      { "fspecial", mlxFspecial, -1, 1, &_local_function_table_fspecial },
      { "gui_mainfcn", mlxGui_mainfcn, -2, -1,
        &_local_function_table_gui_mainfcn },
      { "guidata", mlxGuidata, 2, 1, &_local_function_table_guidata },
      { "im2double", mlxIm2double, 2, 1, &_local_function_table_im2double },
      { "imageextractinfo", mlxImageextractinfo, -1,
        -1, &_local_function_table_imageextractinfo },
      { "imageinfo", mlxImageinfo, -1, -1, &_local_function_table_imageinfo },
      { "imagewatermarkinfo", mlxImagewatermarkinfo, -1,
        -1, &_local_function_table_imagewatermarkinfo },
      { "imcrop", mlxImcrop, -1, -1, &_local_function_table_imcrop },
      { "imfilter", mlxImfilter, -1, 1, &_local_function_table_imfilter },
      { "imread", mlxImread, -1, 3, &_local_function_table_imread },
      { "imresize", mlxImresize, -1, -1, &_local_function_table_imresize },
      { "imrotate", mlxImrotate, -1, -1, &_local_function_table_imrotate },
      { "imshow", mlxImshow, -1, 1, &_local_function_table_imshow },
      { "iptsetpref", mlxIptsetpref, 2, -1,
        &_local_function_table_iptsetpref },
      { "normxcorr2", mlxNormxcorr2, -1, 1,
        &_local_function_table_normxcorr2 },
      { "randint", mlxRandint, -1, 1, &_local_function_table_randint },
      { "rgb2gray", mlxRgb2gray, 3, 1, &_local_function_table_rgb2gray },
      { "subplot", mlxSubplot, 4, 1, &_local_function_table_subplot },
      { "title", mlxTitle, -2, 1, &_local_function_table_title },
      { "waitbar", mlxWaitbar, -3, 1, &_local_function_table_waitbar },
      { "images/private/checknargin", mlxImages_private_checknargin,
        4, 0, &_local_function_table_images_private_checknargin },
      { "images/private/ditherc", mlxImages_private_ditherc, -1,
        -1, &_local_function_table_images_private_ditherc },
      { "im2uint8", mlxIm2uint8, -1, 1, &_local_function_table_im2uint8 },
      { "images/private/checkinput", mlxImages_private_checkinput,
        6, 0, &_local_function_table_images_private_checkinput },
      { "images/private/checkstrs", mlxImages_private_checkstrs,
        5, 1, &_local_function_table_images_private_checkstrs },
      { "guihandles", mlxGuihandles, 1, 1, &_local_function_table_guihandles },
      { "openfig", mlxOpenfig, 3, 1, &_local_function_table_openfig },
      { "getimage", mlxGetimage, -1, -1, &_local_function_table_getimage },
      { "getrect", mlxGetrect, -1, 1, &_local_function_table_getrect },
      { "imadd", mlxImadd, 3, 1, &_local_function_table_imadd },
      { "images/private/imfilter_mex", mlxImages_private_imfilter_mex,
        -1, -1, &_local_function_table_images_private_imfilter_mex },
      { "imsubtract", mlxImsubtract, 2, 1, &_local_function_table_imsubtract },
      { "padarray", mlxPadarray, -1, 1, &_local_function_table_padarray },
      { "images/private/changeclass", mlxImages_private_changeclass,
        -2, 1, &_local_function_table_images_private_changeclass },
      { "fliptform", mlxFliptform, 1, 1, &_local_function_table_fliptform },
      { "makeresampler", mlxMakeresampler, -1, 1,
        &_local_function_table_makeresampler },
      { "maketform", mlxMaketform, -1, 1, &_local_function_table_maketform },
      { "tformarray", mlxTformarray, 8, 1, &_local_function_table_tformarray },
      { "tformfwd", mlxTformfwd, 2, 1, &_local_function_table_tformfwd },
      { "iptgetpref", mlxIptgetpref, 1, 1, &_local_function_table_iptgetpref },
      { "truesize", mlxTruesize, -1, 0, &_local_function_table_truesize },
      { "images/private/iptprefs", mlxImages_private_iptprefs,
        0, 1, &_local_function_table_images_private_iptprefs },
      { "images/private/iptregistry", mlxImages_private_iptregistry,
        -1, -1, &_local_function_table_images_private_iptregistry },
      { "images/private/grayto8", mlxImages_private_grayto8, -1,
        -1, &_local_function_table_images_private_grayto8 },
      { "images/private/num2ordinal", mlxImages_private_num2ordinal,
        1, 1, &_local_function_table_images_private_num2ordinal },
      { "strread", mlxStrread, -1, -1, &_local_function_table_strread },
      { "isvarname", mlxIsvarname, 1, 1, &_local_function_table_isvarname },
      { "movegui", mlxMovegui, -1, 0, &_local_function_table_movegui },
      { "images/private/getcurpt", mlxImages_private_getcurpt,
        1, 2, &_local_function_table_images_private_getcurpt },
      { "xlim", mlxXlim, 2, 1, &_local_function_table_xlim },
      { "ylim", mlxYlim, 2, 1, &_local_function_table_ylim },
      { "zlim", mlxZlim, 2, 1, &_local_function_table_zlim },
      { "imlincomb", mlxImlincomb, -1, 1, &_local_function_table_imlincomb },
      { "images/private/mkconstarray", mlxImages_private_mkconstarray,
        3, 1, &_local_function_table_images_private_mkconstarray },
      { "im2uint16", mlxIm2uint16, 2, 1, &_local_function_table_im2uint16 },
      { "images/private/istform", mlxImages_private_istform,
        1, 1, &_local_function_table_images_private_istform },
      { "images/private/resampsep", mlxImages_private_resampsep,
        -1, -1, &_local_function_table_images_private_resampsep },
      { "images/private/isresampler", mlxImages_private_isresampler,
        1, 1, &_local_function_table_images_private_isresampler },
      { "tforminv", mlxTforminv, 2, 1, &_local_function_table_tforminv },
      { "dataread", mlxDataread, -1, -1, &_local_function_table_dataread },
      { "iskeyword", mlxIskeyword, 1, 1, &_local_function_table_iskeyword },
      { "images/private/imlincombc", mlxImages_private_imlincombc,
        -1, -1, &_local_function_table_images_private_imlincombc },
      { "images/private/grayto16", mlxImages_private_grayto16, -1,
        -1, &_local_function_table_images_private_grayto16 } };

static const char * path_list_[2]
  = { "k:\\matlab6p5\\toolbox\\images\\images",
      "k:\\matlab6p5\\toolbox\\matlab\\iofun" };

static _mexInitTermTableEntry init_term_table[67]
  = { { libmmfileInitialize, libmmfileTerminate },
      { libmwsglmInitialize, libmwsglmTerminate },
      { InitializeModule_watermark005, TerminateModule_watermark005 },
      { InitializeModule_dither, TerminateModule_dither },
      { InitializeModule_fspecial, TerminateModule_fspecial },
      { InitializeModule_gui_mainfcn, TerminateModule_gui_mainfcn },
      { InitializeModule_guidata, TerminateModule_guidata },
      { InitializeModule_im2double, TerminateModule_im2double },
      { InitializeModule_imageextractinfo, TerminateModule_imageextractinfo },
      { InitializeModule_imageinfo, TerminateModule_imageinfo },
      { InitializeModule_imagewatermarkinfo,
        TerminateModule_imagewatermarkinfo },
      { InitializeModule_imcrop, TerminateModule_imcrop },
      { InitializeModule_imfilter, TerminateModule_imfilter },
      { InitializeModule_imread, TerminateModule_imread },
      { InitializeModule_imresize, TerminateModule_imresize },
      { InitializeModule_imrotate, TerminateModule_imrotate },
      { InitializeModule_imshow, TerminateModule_imshow },
      { InitializeModule_iptsetpref, TerminateModule_iptsetpref },
      { InitializeModule_normxcorr2, TerminateModule_normxcorr2 },
      { InitializeModule_randint, TerminateModule_randint },
      { InitializeModule_rgb2gray, TerminateModule_rgb2gray },
      { InitializeModule_subplot, TerminateModule_subplot },
      { InitializeModule_title, TerminateModule_title },
      { InitializeModule_waitbar, TerminateModule_waitbar },
      { InitializeModule_images_private_checknargin,
        TerminateModule_images_private_checknargin },
      { InitializeModule_images_private_ditherc_mex_interface,
        TerminateModule_images_private_ditherc_mex_interface },
      { InitializeModule_im2uint8, TerminateModule_im2uint8 },
      { InitializeModule_images_private_checkinput,
        TerminateModule_images_private_checkinput },
      { InitializeModule_images_private_checkstrs,
        TerminateModule_images_private_checkstrs },
      { InitializeModule_guihandles, TerminateModule_guihandles },
      { InitializeModule_openfig, TerminateModule_openfig },
      { InitializeModule_getimage, TerminateModule_getimage },
      { InitializeModule_getrect, TerminateModule_getrect },
      { InitializeModule_imadd, TerminateModule_imadd },
      { InitializeModule_images_private_imfilter_mex_mex_interface,
        TerminateModule_images_private_imfilter_mex_mex_interface },
      { InitializeModule_imsubtract, TerminateModule_imsubtract },
      { InitializeModule_padarray, TerminateModule_padarray },
      { InitializeModule_images_private_changeclass,
        TerminateModule_images_private_changeclass },
      { InitializeModule_fliptform, TerminateModule_fliptform },
      { InitializeModule_makeresampler, TerminateModule_makeresampler },
      { InitializeModule_maketform, TerminateModule_maketform },
      { InitializeModule_tformarray, TerminateModule_tformarray },
      { InitializeModule_tformfwd, TerminateModule_tformfwd },
      { InitializeModule_iptgetpref, TerminateModule_iptgetpref },
      { InitializeModule_truesize, TerminateModule_truesize },
      { InitializeModule_images_private_iptprefs,
        TerminateModule_images_private_iptprefs },
      { InitializeModule_images_private_iptregistry_mex_interface,
        TerminateModule_images_private_iptregistry_mex_interface },
      { InitializeModule_images_private_grayto8_mex_interface,
        TerminateModule_images_private_grayto8_mex_interface },
      { InitializeModule_images_private_num2ordinal,
        TerminateModule_images_private_num2ordinal },
      { InitializeModule_strread, TerminateModule_strread },
      { InitializeModule_isvarname, TerminateModule_isvarname },
      { InitializeModule_movegui, TerminateModule_movegui },
      { InitializeModule_images_private_getcurpt,
        TerminateModule_images_private_getcurpt },
      { InitializeModule_xlim, TerminateModule_xlim },
      { InitializeModule_ylim, TerminateModule_ylim },
      { InitializeModule_zlim, TerminateModule_zlim },
      { InitializeModule_imlincomb, TerminateModule_imlincomb },
      { InitializeModule_images_private_mkconstarray,
        TerminateModule_images_private_mkconstarray },
      { InitializeModule_im2uint16, TerminateModule_im2uint16 },
      { InitializeModule_images_private_istform,
        TerminateModule_images_private_istform },
      { InitializeModule_images_private_resampsep_mex_interface,
        TerminateModule_images_private_resampsep_mex_interface },
      { InitializeModule_images_private_isresampler,
        TerminateModule_images_private_isresampler },
      { InitializeModule_tforminv, TerminateModule_tforminv },
      { InitializeModule_dataread_mex_interface,
        TerminateModule_dataread_mex_interface },
      { InitializeModule_iskeyword, TerminateModule_iskeyword },
      { InitializeModule_images_private_imlincombc_mex_interface,
        TerminateModule_images_private_imlincombc_mex_interface },
      { InitializeModule_images_private_grayto16_mex_interface,
        TerminateModule_images_private_grayto16_mex_interface } };

_mex_information _main_info
  = { 1, 65, function_table, 6, global_table, 2,
      path_list_, 67, init_term_table };

/*
 * The function "main" is a Compiler-generated main wrapper, suitable for
 * building a stand-alone application.  It calls a library function to perform
 * initialization, call the main function, and perform library termination.
 */
int main(int argc, const char * * argv) {
    return mclMainhg(argc, argv, mlxWatermark005, 1, &_main_info);
}
