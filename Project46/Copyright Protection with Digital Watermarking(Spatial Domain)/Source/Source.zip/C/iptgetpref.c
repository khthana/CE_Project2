/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "iptgetpref.h"
#include "images_private_iptprefs.h"
#include "images_private_iptregistry_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;

static mxChar _array5_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray4_;
static mxArray * _mxarray6_;

static mxChar _array8_[4] = { 'c', 'h', 'a', 'r' };
static mxArray * _mxarray7_;

static mxChar _array10_[33] = { 'P', 'r', 'e', 'f', 'e', 'r', 'e', 'n', 'c',
                                'e', ' ', 'n', 'a', 'm', 'e', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'a', ' ', 's',
                                't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray9_;

static mxChar _array12_[49] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'I',
                                'm', 'a', 'g', 'e', ' ', 'P', 'r', 'o', 'c',
                                'e', 's', 's', 'i', 'n', 'g', ' ', 'T', 'o',
                                'o', 'l', 'b', 'o', 'x', ' ', 'p', 'r', 'e',
                                'f', 'e', 'r', 'e', 'n', 'c', 'e', ' ', '"',
                                '%', 's', '"', '.' };
static mxArray * _mxarray11_;

static mxChar _array14_[51] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                ' ', 'I', 'm', 'a', 'g', 'e', ' ', 'P', 'r',
                                'o', 'c', 'e', 's', 's', 'i', 'n', 'g', ' ',
                                'T', 'o', 'o', 'l', 'b', 'o', 'x', ' ', 'p',
                                'r', 'e', 'f', 'e', 'r', 'e', 'n', 'c', 'e',
                                ' ', '"', '%', 's', '"', '.' };
static mxArray * _mxarray13_;

void InitializeModule_iptgetpref(void) {
    _mxarray0_ = mclInitializeDouble(0.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray3_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray4_ = mclInitializeString(5, _array5_);
    _mxarray6_ = mclInitializeDouble(3.0);
    _mxarray7_ = mclInitializeString(4, _array8_);
    _mxarray9_ = mclInitializeString(33, _array10_);
    _mxarray11_ = mclInitializeString(49, _array12_);
    _mxarray13_ = mclInitializeString(51, _array14_);
}

void TerminateModule_iptgetpref(void) {
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miptgetpref(int nargout_, mxArray * prefName);

_mexLocalFunctionTable _local_function_table_iptgetpref
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIptgetpref" contains the normal interface for the
 * "iptgetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptgetpref.m" (lines 1-83). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIptgetpref(mxArray * prefName) {
    int nargout = 1;
    mxArray * value = NULL;
    mlfEnterNewContext(0, 1, prefName);
    value = Miptgetpref(nargout, prefName);
    mlfRestorePreviousContext(0, 1, prefName);
    return mlfReturnValue(value);
}

/*
 * The function "mlxIptgetpref" contains the feval interface for the
 * "iptgetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptgetpref.m" (lines 1-83). The feval
 * function calls the implementation version of iptgetpref through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxIptgetpref(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: iptgetpref Line: 1 Column:"
            " 1 The function \"iptgetpref\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: iptgetpref Line: 1 Column"
            ": 1 The function \"iptgetpref\" was called with"
            " more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Miptgetpref(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Miptgetpref" is the implementation version of the "iptgetpref"
 * M-function from file "k:\matlab6p5\toolbox\images\images\iptgetpref.m"
 * (lines 1-83). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function value = iptgetpref(prefName)
 */
static mxArray * Miptgetpref(int nargout_, mxArray * prefName) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_iptgetpref);
    int nargin_ = mclNargin(1, prefName, NULL);
    mxArray * value = NULL;
    mxArray * preference = NULL;
    mxArray * matchIdx = NULL;
    mxArray * lowerNames = NULL;
    mxArray * registryContainsPreference = NULL;
    mxArray * thisField = NULL;
    mxArray * k = NULL;
    mxArray * registryFieldNames = NULL;
    mxArray * registryStruct = NULL;
    mxArray * allNames = NULL;
    mxArray * factoryPrefs = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&prefName);
    /*
     * %IPTGETPREF Get Image Processing Toolbox preference.
     * %   VALUE = IPTGETPREF(PREFNAME) returns the value of the Image
     * %   Processing Toolbox preference specified by the string
     * %   PREFNAME.  Valid preference names are 'ImshowBorder' and
     * %   'ImshowAxesVisible'.  Preference names are case insensitive
     * %   and can be abbreviated.
     * %
     * %   IPTGETPREF without an input argument displays the current
     * %   setting of all Image Processing Toolbox preferences.
     * %
     * %   Example
     * %   -------
     * %       value = iptgetpref('ImshowAxesVisible')
     * %
     * %   See also IMSHOW, IPTSETPREF.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.13 $  $Date: 2002/03/15 15:28:25 $
     * 
     * error(nargchk(0,1,nargin));
     */
    mlfError(mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)), NULL);
    /*
     * 
     * % Get IPT factory preference settings.
     * factoryPrefs = iptprefs;
     */
    mlfAssign(&factoryPrefs, mlfImages_private_iptprefs());
    /*
     * allNames = factoryPrefs(:,1);
     */
    mlfAssign(
      &allNames,
      mclArrayRef2(
        mclVv(factoryPrefs, "factoryPrefs"),
        mlfCreateColonIndex(),
        _mxarray1_));
    /*
     * 
     * % What is currently stored in the IPT registry?
     * registryStruct = iptregistry;
     */
    mlfAssign(
      &registryStruct,
      mlfNImages_private_iptregistry(0, mclValueVarargout(), NULL));
    /*
     * if (isempty(registryStruct))
     */
    if (mlfTobool(mlfIsempty(mclVv(registryStruct, "registryStruct")))) {
        /*
         * registryFieldNames = {};
         */
        mlfAssign(&registryFieldNames, _mxarray2_);
    /*
     * else
     */
    } else {
        /*
         * registryFieldNames = fieldnames(registryStruct);
         */
        mlfAssign(
          &registryFieldNames,
          mlfFieldnames(mclVv(registryStruct, "registryStruct")));
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin == 0)
     */
    if (nargin_ == 0) {
        /*
         * % Display all current preference settings.
         * value = [];
         */
        mlfAssign(&value, _mxarray3_);
        /*
         * for k = 1:length(allNames)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclLengthInt(mclVv(allNames, "allNames"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray3_);
            } else {
                /*
                 * thisField = allNames{k};
                 * registryContainsPreference = length(strmatch(thisField, ...
                 * registryFieldNames, 'exact')) > 0;
                 * if (registryContainsPreference)
                 * value = setfield(value, thisField, ...
                 * getfield(registryStruct, thisField));
                 * else
                 * % Use default value
                 * value = setfield(value, thisField, factoryPrefs{k,3}{1});
                 * end
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &thisField,
                      mlfIndexRef(
                        mclVv(allNames, "allNames"), "{?}", mlfScalar(v_)));
                    mlfAssign(
                      &registryContainsPreference,
                      mclBoolToArray(
                        mclLengthInt(
                          mlfStrmatch(
                            mclVv(thisField, "thisField"),
                            mclVv(registryFieldNames, "registryFieldNames"),
                            _mxarray4_))
                        > 0));
                    if (mlfTobool(
                          mclVv(
                            registryContainsPreference,
                            "registryContainsPreference"))) {
                        mlfAssign(
                          &value,
                          mlfSetfield(
                            mclVv(value, "value"),
                            mclVv(thisField, "thisField"),
                            mlfGetfield(
                              mclVv(registryStruct, "registryStruct"),
                              mclVv(thisField, "thisField"), NULL),
                            NULL));
                    } else {
                        mlfAssign(
                          &value,
                          mlfSetfield(
                            mclVv(value, "value"),
                            mclVv(thisField, "thisField"),
                            mlfIndexRef(
                              mclVv(factoryPrefs, "factoryPrefs"),
                              "{?,?}{?}",
                              mlfScalar(v_),
                              _mxarray6_,
                              _mxarray1_),
                            NULL));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
    /*
     * 
     * else
     */
    } else {
        /*
         * % Return specified setting.
         * if (~isa(prefName, 'char'))
         */
        if (mclNotBool(mlfIsa(mclVa(prefName, "prefName"), _mxarray7_))) {
            /*
             * error('Preference name must be a string.');
             */
            mlfError(_mxarray9_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * % Convert factory preference names to lower case.
         * lowerNames = cell(size(allNames));
         */
        mlfAssign(
          &lowerNames,
          mlfCell(
            mlfSize(mclValueVarargout(), mclVv(allNames, "allNames"), NULL),
            NULL));
        /*
         * for k = 1:length(lowerNames)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclLengthInt(mclVv(lowerNames, "lowerNames"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray3_);
            } else {
                /*
                 * lowerNames{k} = lower(allNames{k});
                 * end
                 */
                for (; ; ) {
                    mlfIndexAssign(
                      &lowerNames,
                      "{?}",
                      mlfScalar(v_),
                      mclFeval(
                        mclValueVarargout(),
                        mlxLower,
                        mlfIndexRef(
                          mclVv(allNames, "allNames"), "{?}", mlfScalar(v_)),
                        NULL));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * 
         * matchIdx = strmatch(lower(prefName), lowerNames);
         */
        mlfAssign(
          &matchIdx,
          mlfStrmatch(
            mlfLower(mclVa(prefName, "prefName")),
            mclVv(lowerNames, "lowerNames"),
            NULL));
        /*
         * if (isempty(matchIdx))
         */
        if (mlfTobool(mlfIsempty(mclVv(matchIdx, "matchIdx")))) {
            /*
             * error(sprintf(['Unknown Image Processing ' ...
             */
            mlfError(
              mlfSprintf(NULL, _mxarray11_, mclVa(prefName, "prefName"), NULL),
              NULL);
        /*
         * 'Toolbox preference "%s".'], prefName));
         * elseif (length(matchIdx) > 1)
         */
        } else if (mclLengthInt(mclVv(matchIdx, "matchIdx")) > 1) {
            /*
             * error(sprintf(['Ambiguous Image Processing ' ...
             */
            mlfError(
              mlfSprintf(NULL, _mxarray13_, mclVa(prefName, "prefName"), NULL),
              NULL);
        /*
         * 'Toolbox preference "%s".'], prefName));
         * else
         */
        } else {
            /*
             * preference = allNames{matchIdx};
             */
            mlfAssign(
              &preference,
              mlfIndexRef(
                mclVv(allNames, "allNames"),
                "{?}",
                mclVv(matchIdx, "matchIdx")));
        /*
         * end
         */
        }
        /*
         * 
         * registryContainsPreference = length(strmatch(preference, ...
         */
        mlfAssign(
          &registryContainsPreference,
          mclBoolToArray(
            mclLengthInt(
              mlfStrmatch(
                mclVv(preference, "preference"),
                mclVv(registryFieldNames, "registryFieldNames"),
                _mxarray4_))
            > 0));
        /*
         * registryFieldNames, 'exact')) > 0;
         * if (registryContainsPreference)
         */
        if (mlfTobool(
              mclVv(
                registryContainsPreference, "registryContainsPreference"))) {
            /*
             * value = getfield(registryStruct, preference);
             */
            mlfAssign(
              &value,
              mlfGetfield(
                mclVv(registryStruct, "registryStruct"),
                mclVv(preference, "preference"), NULL));
        /*
         * else
         */
        } else {
            /*
             * value = factoryPrefs{matchIdx, 3}{1};
             */
            mlfAssign(
              &value,
              mlfIndexRef(
                mclVv(factoryPrefs, "factoryPrefs"),
                "{?,?}{?}",
                mclVv(matchIdx, "matchIdx"),
                _mxarray6_,
                _mxarray1_));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(value, 1, nargout_, "value", "iptgetpref");
    mxDestroyArray(ans);
    mxDestroyArray(factoryPrefs);
    mxDestroyArray(allNames);
    mxDestroyArray(registryStruct);
    mxDestroyArray(registryFieldNames);
    mxDestroyArray(k);
    mxDestroyArray(thisField);
    mxDestroyArray(registryContainsPreference);
    mxDestroyArray(lowerNames);
    mxDestroyArray(matchIdx);
    mxDestroyArray(preference);
    mxDestroyArray(prefName);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return value;
    /*
     * 
     */
}
