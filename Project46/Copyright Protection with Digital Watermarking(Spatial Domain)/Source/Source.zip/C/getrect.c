/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "getrect.h"
#include "libsgl.h"
#include "images_private_getcurpt.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
#include "xlim.h"
#include "ylim.h"
#include "zlim.h"

extern mxArray * GETRECT_AX;
extern mxArray * GETRECT_FIG;
extern mxArray * GETRECT_H1;
extern mxArray * GETRECT_H2;
extern mxArray * GETRECT_PT1;
extern mxArray * GETRECT_TYPE;

static mxChar _array1_[4] = { 'm', 'o', 'd', 'e' };
static mxArray * _mxarray0_;

static mxChar _array3_[6] = { 'm', 'a', 'n', 'u', 'a', 'l' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray5_;

static mxChar _array8_[36] = { 'F', 'i', 'r', 's', 't', ' ', 'a', 'r', 'g',
                               'u', 'm', 'e', 'n', 't', ' ', 'i', 's', ' ',
                               'n', 'o', 't', ' ', 'a', ' ', 'v', 'a', 'l',
                               'i', 'd', ' ', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray7_;

static mxChar _array10_[6] = { 'f', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray9_;

static mxChar _array12_[11] = { 'C', 'u', 'r', 'r', 'e', 'n',
                                't', 'A', 'x', 'e', 's' };
static mxArray * _mxarray11_;

static mxChar _array14_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray13_;

static mxChar _array16_[48] = { 'F', 'i', 'r', 's', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', ' ', 's',
                                'h', 'o', 'u', 'l', 'd', ' ', 'b', 'e',
                                ' ', 'a', ' ', 'f', 'i', 'g', 'u', 'r',
                                'e', ' ', 'o', 'r', ' ', 'a', 'x', 'e',
                                's', ' ', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray15_;

static mxChar _array18_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray17_;

static mxChar _array20_[12] = { 'D', 'o', 'u', 'b', 'l', 'e',
                                'B', 'u', 'f', 'f', 'e', 'r' };
static mxArray * _mxarray19_;

static mxChar _array22_[7] = { 'P', 'o', 'i', 'n', 't', 'e', 'r' };
static mxArray * _mxarray21_;

static mxChar _array24_[9] = { 'c', 'r', 'o', 's', 's', 'h', 'a', 'i', 'r' };
static mxArray * _mxarray23_;

static mxChar _array26_[19] = { 'W', 'i', 'n', 'd', 'o', 'w', 'B',
                                'u', 't', 't', 'o', 'n', 'D', 'o',
                                'w', 'n', 'F', 'c', 'n' };
static mxArray * _mxarray25_;

static mxChar _array28_[22] = { 'g', 'e', 't', 'r', 'e', 'c', 't', '(',
                                0x0027, 'B', 'u', 't', 't', 'o', 'n',
                                'D', 'o', 'w', 'n', 0x0027, ')', ';' };
static mxArray * _mxarray27_;

static mxChar _array30_[2] = { 'o', 'n' };
static mxArray * _mxarray29_;

static mxChar _array32_[5] = { 'X', 'D', 'a', 't', 'a' };
static mxArray * _mxarray31_;

static double _array34_[5] = { 0.0, 0.0, 0.0, 0.0, 0.0 };
static mxArray * _mxarray33_;

static mxChar _array36_[5] = { 'Y', 'D', 'a', 't', 'a' };
static mxArray * _mxarray35_;

static mxChar _array38_[7] = { 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray37_;

static mxChar _array40_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray39_;

static mxChar _array42_[8] = { 'C', 'l', 'i', 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray41_;

static mxChar _array44_[5] = { 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray43_;

static mxChar _array46_[1] = { 'k' };
static mxArray * _mxarray45_;

static mxChar _array48_[9] = { 'L', 'i', 'n', 'e', 'S', 't', 'y', 'l', 'e' };
static mxArray * _mxarray47_;

static mxChar _array50_[1] = { '-' };
static mxArray * _mxarray49_;

static mxChar _array52_[1] = { 'w' };
static mxArray * _mxarray51_;

static mxChar _array54_[1] = { ':' };
static mxArray * _mxarray53_;
static mxArray * _mxarray55_;

static mxChar _array57_[8] = { 'U', 's', 'e', 'r', 'D', 'a', 't', 'a' };
static mxArray * _mxarray56_;

static mxChar _array59_[9] = { 'C', 'o', 'm', 'p', 'l', 'e', 't', 'e', 'd' };
static mxArray * _mxarray58_;

static mxChar _array61_[4] = { 't', 'r', 'a', 'p' };
static mxArray * _mxarray60_;

static mxChar _array63_[7] = { 'u', 'n', 'k', 'n', 'o', 'w', 'n' };
static mxArray * _mxarray62_;

static mxChar _array65_[2] = { 'o', 'k' };
static mxArray * _mxarray64_;

static mxChar _array67_[36] = { 'I', 'n', 't', 'e', 'r', 'r', 'u', 'p', 't',
                                'i', 'o', 'n', ' ', 'd', 'u', 'r', 'i', 'n',
                                'g', ' ', 'm', 'o', 'u', 's', 'e', ' ', 's',
                                'e', 'l', 'e', 'c', 't', 'i', 'o', 'n', '.' };
static mxArray * _mxarray66_;

static mxChar _array69_[13] = { 'I', 'n', 't', 'e', 'r', 'r', 'u',
                                'p', 't', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray68_;

static mxChar _array71_[10] = { 'B', 'u', 's', 'y', 'A',
                                'c', 't', 'i', 'o', 'n' };
static mxArray * _mxarray70_;

static mxChar _array73_[6] = { 'c', 'a', 'n', 'c', 'e', 'l' };
static mxArray * _mxarray72_;

static mxChar _array75_[13] = { 'S', 'e', 'l', 'e', 'c', 't', 'i',
                                'o', 'n', 'T', 'y', 'p', 'e' };
static mxArray * _mxarray74_;

static mxChar _array77_[21] = { 'W', 'i', 'n', 'd', 'o', 'w', 'B',
                                'u', 't', 't', 'o', 'n', 'M', 'o',
                                't', 'i', 'o', 'n', 'F', 'c', 'n' };
static mxArray * _mxarray76_;

static mxChar _array79_[24] = { 'g', 'e', 't', 'r', 'e', 'c', 't', '(',
                                0x0027, 'B', 'u', 't', 't', 'o', 'n', 'M',
                                'o', 't', 'i', 'o', 'n', 0x0027, ')', ';' };
static mxArray * _mxarray78_;

static mxChar _array81_[17] = { 'W', 'i', 'n', 'd', 'o', 'w', 'B', 'u', 't',
                                't', 'o', 'n', 'U', 'p', 'F', 'c', 'n' };
static mxArray * _mxarray80_;

static mxChar _array83_[20] = { 'g', 'e', 't', 'r', 'e', 'c', 't',
                                '(', 0x0027, 'B', 'u', 't', 't', 'o',
                                'n', 'U', 'p', 0x0027, ')', ';' };
static mxArray * _mxarray82_;

static mxChar _array85_[6] = { 'n', 'o', 'r', 'm', 'a', 'l' };
static mxArray * _mxarray84_;
static mxArray * _mxarray86_;

void InitializeModule_getrect(void) {
    _mxarray0_ = mclInitializeString(4, _array1_);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeString(6, _array6_);
    _mxarray7_ = mclInitializeString(36, _array8_);
    _mxarray9_ = mclInitializeString(6, _array10_);
    _mxarray11_ = mclInitializeString(11, _array12_);
    _mxarray13_ = mclInitializeString(4, _array14_);
    _mxarray15_ = mclInitializeString(48, _array16_);
    _mxarray17_ = mclInitializeString(4, _array18_);
    _mxarray19_ = mclInitializeString(12, _array20_);
    _mxarray21_ = mclInitializeString(7, _array22_);
    _mxarray23_ = mclInitializeString(9, _array24_);
    _mxarray25_ = mclInitializeString(19, _array26_);
    _mxarray27_ = mclInitializeString(22, _array28_);
    _mxarray29_ = mclInitializeString(2, _array30_);
    _mxarray31_ = mclInitializeString(5, _array32_);
    _mxarray33_ = mclInitializeDoubleVector(1, 5, _array34_);
    _mxarray35_ = mclInitializeString(5, _array36_);
    _mxarray37_ = mclInitializeString(7, _array38_);
    _mxarray39_ = mclInitializeString(3, _array40_);
    _mxarray41_ = mclInitializeString(8, _array42_);
    _mxarray43_ = mclInitializeString(5, _array44_);
    _mxarray45_ = mclInitializeString(1, _array46_);
    _mxarray47_ = mclInitializeString(9, _array48_);
    _mxarray49_ = mclInitializeString(1, _array50_);
    _mxarray51_ = mclInitializeString(1, _array52_);
    _mxarray53_ = mclInitializeString(1, _array54_);
    _mxarray55_ = mclInitializeDouble(0.0);
    _mxarray56_ = mclInitializeString(8, _array57_);
    _mxarray58_ = mclInitializeString(9, _array59_);
    _mxarray60_ = mclInitializeString(4, _array61_);
    _mxarray62_ = mclInitializeString(7, _array63_);
    _mxarray64_ = mclInitializeString(2, _array65_);
    _mxarray66_ = mclInitializeString(36, _array67_);
    _mxarray68_ = mclInitializeString(13, _array69_);
    _mxarray70_ = mclInitializeString(10, _array71_);
    _mxarray72_ = mclInitializeString(6, _array73_);
    _mxarray74_ = mclInitializeString(13, _array75_);
    _mxarray76_ = mclInitializeString(21, _array77_);
    _mxarray78_ = mclInitializeString(24, _array79_);
    _mxarray80_ = mclInitializeString(17, _array81_);
    _mxarray82_ = mclInitializeString(20, _array83_);
    _mxarray84_ = mclInitializeString(6, _array85_);
    _mxarray86_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
}

void TerminateModule_getrect(void) {
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static void mlfGetrect_ButtonDown(void);
static void mlxGetrect_ButtonDown(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]);
static void mlfGetrect_ButtonMotion(void);
static void mlxGetrect_ButtonMotion(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static void mlfGetrect_ButtonUp(void);
static void mlxGetrect_ButtonUp(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static mxArray * mlfGetrect_Constrain(mxArray * * ydata_out,
                                      mxArray * xdata,
                                      mxArray * ydata);
static void mlxGetrect_Constrain(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]);
static void mlfGetrect_CleanUp(mxArray * xlimmode,
                               mxArray * ylimmode,
                               mxArray * zlimmode);
static void mlxGetrect_CleanUp(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]);
static mxArray * Mgetrect(int nargout_, mxArray * varargin);
static void Mgetrect_ButtonDown(void);
static void Mgetrect_ButtonMotion(void);
static void Mgetrect_ButtonUp(void);
static mxArray * Mgetrect_Constrain(mxArray * * ydata_out,
                                    int nargout_,
                                    mxArray * xdata,
                                    mxArray * ydata);
static void Mgetrect_CleanUp(mxArray * xlimmode,
                             mxArray * ylimmode,
                             mxArray * zlimmode);

static mexFunctionTableEntry local_function_table_[5]
  = { { "ButtonDown", mlxGetrect_ButtonDown, 0, 0, NULL },
      { "ButtonMotion", mlxGetrect_ButtonMotion, 0, 0, NULL },
      { "ButtonUp", mlxGetrect_ButtonUp, 0, 0, NULL },
      { "Constrain", mlxGetrect_Constrain, 2, 2, NULL },
      { "CleanUp", mlxGetrect_CleanUp, 3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_getrect
  = { 5, local_function_table_ };

/*
 * The function "mlfGetrect" contains the normal interface for the "getrect"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getrect.m" (lines
 * 1-166). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfGetrect(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * rect = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    rect = Mgetrect(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(rect);
}

/*
 * The function "mlxGetrect" contains the feval interface for the "getrect"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getrect.m" (lines
 * 1-166). The feval function calls the implementation version of getrect
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxGetrect(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect Line: 1 Column: "
            "1 The function \"getrect\" was called with mor"
            "e than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mgetrect(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfGetrect_ButtonDown" contains the normal interface for the
 * "getrect/ButtonDown" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 166-197). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfGetrect_ButtonDown(void) {
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonDown();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlxGetrect_ButtonDown" contains the feval interface for the
 * "getrect/ButtonDown" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 166-197). The feval
 * function calls the implementation version of getrect/ButtonDown through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGetrect_ButtonDown(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonDown Line: 166 Col"
            "umn: 1 The function \"getrect/ButtonDown\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonDown Line: 166 Co"
            "lumn: 1 The function \"getrect/ButtonDown\" was calle"
            "d with more than the declared number of inputs (0)."),
          NULL);
    }
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonDown();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlfGetrect_ButtonMotion" contains the normal interface for the
 * "getrect/ButtonMotion" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 197-220). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfGetrect_ButtonMotion(void) {
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonMotion();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlxGetrect_ButtonMotion" contains the feval interface for the
 * "getrect/ButtonMotion" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 197-220). The feval
 * function calls the implementation version of getrect/ButtonMotion through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxGetrect_ButtonMotion(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonMotion Line: 197 Co"
            "lumn: 1 The function \"getrect/ButtonMotion\" was calle"
            "d with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonMotion Line: 197 Co"
            "lumn: 1 The function \"getrect/ButtonMotion\" was calle"
            "d with more than the declared number of inputs (0)."),
          NULL);
    }
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonMotion();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlfGetrect_ButtonUp" contains the normal interface for the
 * "getrect/ButtonUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 220-253). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfGetrect_ButtonUp(void) {
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonUp();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlxGetrect_ButtonUp" contains the feval interface for the
 * "getrect/ButtonUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 220-253). The feval
 * function calls the implementation version of getrect/ButtonUp through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGetrect_ButtonUp(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonUp Line: 220 Col"
            "umn: 1 The function \"getrect/ButtonUp\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/ButtonUp Line: 220 Col"
            "umn: 1 The function \"getrect/ButtonUp\" was called "
            "with more than the declared number of inputs (0)."),
          NULL);
    }
    mlfEnterNewContext(0, 0);
    Mgetrect_ButtonUp();
    mlfRestorePreviousContext(0, 0);
}

/*
 * The function "mlfGetrect_Constrain" contains the normal interface for the
 * "getrect/Constrain" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 253-274). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfGetrect_Constrain(mxArray * * ydata_out,
                                      mxArray * xdata,
                                      mxArray * ydata) {
    int nargout = 1;
    mxArray * xdata_out = NULL;
    mxArray * ydata_out__ = NULL;
    mlfEnterNewContext(1, 2, ydata_out, xdata, ydata);
    if (ydata_out != NULL) {
        ++nargout;
    }
    xdata_out = Mgetrect_Constrain(&ydata_out__, nargout, xdata, ydata);
    mlfRestorePreviousContext(1, 2, ydata_out, xdata, ydata);
    if (ydata_out != NULL) {
        mclCopyOutputArg(ydata_out, ydata_out__);
    } else {
        mxDestroyArray(ydata_out__);
    }
    return mlfReturnValue(xdata_out);
}

/*
 * The function "mlxGetrect_Constrain" contains the feval interface for the
 * "getrect/Constrain" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 253-274). The feval
 * function calls the implementation version of getrect/Constrain through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGetrect_Constrain(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/Constrain Line: 253 Col"
            "umn: 1 The function \"getrect/Constrain\" was called "
            "with more than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/Constrain Line: 253 Col"
            "umn: 1 The function \"getrect/Constrain\" was called "
            "with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mgetrect_Constrain(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfGetrect_CleanUp" contains the normal interface for the
 * "getrect/CleanUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 274-285). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfGetrect_CleanUp(mxArray * xlimmode,
                               mxArray * ylimmode,
                               mxArray * zlimmode) {
    mlfEnterNewContext(0, 3, xlimmode, ylimmode, zlimmode);
    Mgetrect_CleanUp(xlimmode, ylimmode, zlimmode);
    mlfRestorePreviousContext(0, 3, xlimmode, ylimmode, zlimmode);
}

/*
 * The function "mlxGetrect_CleanUp" contains the feval interface for the
 * "getrect/CleanUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 274-285). The feval
 * function calls the implementation version of getrect/CleanUp through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGetrect_CleanUp(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/CleanUp Line: 274 Colu"
            "mn: 1 The function \"getrect/CleanUp\" was called wi"
            "th more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getrect/CleanUp Line: 274 Col"
            "umn: 1 The function \"getrect/CleanUp\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mgetrect_CleanUp(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "Mgetrect" is the implementation version of the "getrect"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getrect.m" (lines
 * 1-166). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function rect = getrect(varargin)
 */
static mxArray * Mgetrect(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * rect = NULL;
    mxArray * ymin = NULL;
    mxArray * xmin = NULL;
    mxArray * y = NULL;
    mxArray * x = NULL;
    mxArray * errStatus = NULL;
    mxArray * errCatch = NULL;
    mxArray * state = NULL;
    mxArray * old_db = NULL;
    mxArray * zlimorigmode = NULL;
    mxArray * ylimorigmode = NULL;
    mxArray * xlimorigmode = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * %GETRECT Select rectangle with mouse.
     * %   RECT = GETRECT(FIG) lets you select a rectangle in the
     * %   current axes of figure FIG using the mouse.  Use the mouse to
     * %   click and drag the desired rectangle.  RECT is a four-element
     * %   vector with the form [xmin ymin width height].  To constrain
     * %   the rectangle to be a square, use a shift- or right-click to
     * %   begin the drag.
     * %
     * %   RECT = GETRECT(AX) lets you select a rectangle in the axes
     * %   specified by the handle AX.
     * %
     * %   See also GETLINE, GETPTS.
     * 
     * %   Callback syntaxes:
     * %        getrect('ButtonDown')
     * %        getrect('ButtonMotion')
     * %        getrect('ButtonUp')
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 5.22 $  $Date: 2002/03/15 15:27:27 $
     * 
     * global GETRECT_FIG GETRECT_AX GETRECT_H1 GETRECT_H2
     * global GETRECT_PT1 GETRECT_TYPE
     * 
     * xlimorigmode = xlim('mode');
     */
    mlfAssign(&xlimorigmode, mlfXlim(_mxarray0_, NULL));
    /*
     * ylimorigmode = ylim('mode');
     */
    mlfAssign(&ylimorigmode, mlfYlim(_mxarray0_, NULL));
    /*
     * zlimorigmode = zlim('mode');
     */
    mlfAssign(&zlimorigmode, mlfZlim(_mxarray0_, NULL));
    /*
     * xlim('manual');
     */
    mclAssignAns(&ans, mlfXlim(_mxarray2_, NULL));
    /*
     * ylim('manual');
     */
    mclAssignAns(&ans, mlfYlim(_mxarray2_, NULL));
    /*
     * zlim('manual');
     */
    mclAssignAns(&ans, mlfZlim(_mxarray2_, NULL));
    /*
     * 
     * if ((nargin >= 1) & (isstr(varargin{1})))
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ >= 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIsstr,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"), "{?}", _mxarray4_),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * % Callback invocation: 'ButtonDown', 'ButtonMotion', or 'ButtonUp'
             * feval(varargin{:});
             */
            mclAssignAns(
              &ans,
              mlfFeval(
                mclAnsVarargout(),
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
            /*
             * return;
             */
            goto return_;
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin < 1)
     */
    if (nargin_ < 1) {
        /*
         * GETRECT_AX = gca;
         */
        mlfAssign(mclPrepareGlobal(&GETRECT_AX), mlfGca(NULL));
        /*
         * GETRECT_FIG = get(GETRECT_AX, 'Parent');
         */
        mlfAssign(
          mclPrepareGlobal(&GETRECT_FIG),
          mlfNGet(1, mclVg(&GETRECT_AX, "GETRECT_AX"), _mxarray5_, NULL));
    /*
     * else
     */
    } else {
        /*
         * if (~ishandle(varargin{1}))
         */
        if (mclNotBool(
              mclFeval(
                mclValueVarargout(),
                mlxIshandle,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_),
                NULL))) {
            /*
             * CleanUp(xlimorigmode,ylimorigmode,zlimorigmode);
             */
            mlfGetrect_CleanUp(
              mclVv(xlimorigmode, "xlimorigmode"),
              mclVv(ylimorigmode, "ylimorigmode"),
              mclVv(zlimorigmode, "zlimorigmode"));
            /*
             * error('First argument is not a valid handle');
             */
            mlfError(_mxarray7_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * switch get(varargin{1}, 'Type')
         */
        {
            mxArray * v_
              = mclInitialize(
                  mlfNGet(
                    1,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray4_),
                    _mxarray17_,
                    NULL));
            if (mclSwitchCompare(v_, _mxarray9_)) {
                /*
                 * case 'figure'
                 * GETRECT_FIG = varargin{1};
                 */
                mlfAssign(
                  mclPrepareGlobal(&GETRECT_FIG),
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
                /*
                 * GETRECT_AX = get(GETRECT_FIG, 'CurrentAxes');
                 */
                mlfAssign(
                  mclPrepareGlobal(&GETRECT_AX),
                  mlfNGet(
                    1, mclVg(&GETRECT_FIG, "GETRECT_FIG"), _mxarray11_, NULL));
                /*
                 * if (isempty(GETRECT_AX))
                 */
                if (mlfTobool(mlfIsempty(mclVg(&GETRECT_AX, "GETRECT_AX")))) {
                    /*
                     * GETRECT_AX = axes('Parent', GETRECT_FIG);
                     */
                    mlfAssign(
                      mclPrepareGlobal(&GETRECT_AX),
                      mlfNAxes(
                        1,
                        _mxarray5_, mclVg(&GETRECT_FIG, "GETRECT_FIG"), NULL));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'axes'
             */
            } else if (mclSwitchCompare(v_, _mxarray13_)) {
                /*
                 * GETRECT_AX = varargin{1};
                 */
                mlfAssign(
                  mclPrepareGlobal(&GETRECT_AX),
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
                /*
                 * GETRECT_FIG = get(GETRECT_AX, 'Parent');
                 */
                mlfAssign(
                  mclPrepareGlobal(&GETRECT_FIG),
                  mlfNGet(
                    1, mclVg(&GETRECT_AX, "GETRECT_AX"), _mxarray5_, NULL));
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * CleanUp(xlimorigmode,ylimorigmode,zlimorigmode);
                 */
                mlfGetrect_CleanUp(
                  mclVv(xlimorigmode, "xlimorigmode"),
                  mclVv(ylimorigmode, "ylimorigmode"),
                  mclVv(zlimorigmode, "zlimorigmode"));
                /*
                 * error('First argument should be a figure or axes handle');
                 */
                mlfError(_mxarray15_, NULL);
            /*
             * end
             */
            }
            mxDestroyArray(v_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Remember initial figure state
     * old_db = get(GETRECT_FIG, 'DoubleBuffer');
     */
    mlfAssign(
      &old_db,
      mlfNGet(1, mclVg(&GETRECT_FIG, "GETRECT_FIG"), _mxarray19_, NULL));
    /*
     * state = uisuspend(GETRECT_FIG);
     */
    mlfAssign(&state, mlfUisuspend(mclVg(&GETRECT_FIG, "GETRECT_FIG")));
    /*
     * 
     * % Set up initial callbacks for initial stage
     * set(GETRECT_FIG, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_FIG, "GETRECT_FIG"),
        _mxarray21_,
        _mxarray23_,
        _mxarray25_,
        _mxarray27_,
        _mxarray19_,
        _mxarray29_,
        NULL));
    /*
     * 'Pointer', 'crosshair', ...
     * 'WindowButtonDownFcn', 'getrect(''ButtonDown'');', ...
     * 'DoubleBuffer', 'on');
     * 
     * % Bring target figure forward
     * figure(GETRECT_FIG);
     */
    mclAssignAns(&ans, mlfNFigure(0, mclVg(&GETRECT_FIG, "GETRECT_FIG"), NULL));
    /*
     * 
     * % Initialize the lines to be used for the drag
     * GETRECT_H1 = line('Parent', GETRECT_AX, ...
     */
    mlfAssign(
      mclPrepareGlobal(&GETRECT_H1),
      mlfNLine(
        1,
        _mxarray5_,
        mclVg(&GETRECT_AX, "GETRECT_AX"),
        _mxarray31_,
        _mxarray33_,
        _mxarray35_,
        _mxarray33_,
        _mxarray37_,
        _mxarray39_,
        _mxarray41_,
        _mxarray39_,
        _mxarray43_,
        _mxarray45_,
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 'XData', [0 0 0 0 0], ...
     * 'YData', [0 0 0 0 0], ...
     * 'Visible', 'off', ...
     * 'Clipping', 'off', ...
     * 'Color', 'k', ...
     * 'LineStyle', '-');
     * 
     * GETRECT_H2 = line('Parent', GETRECT_AX, ...
     */
    mlfAssign(
      mclPrepareGlobal(&GETRECT_H2),
      mlfNLine(
        1,
        _mxarray5_,
        mclVg(&GETRECT_AX, "GETRECT_AX"),
        _mxarray31_,
        _mxarray33_,
        _mxarray35_,
        _mxarray33_,
        _mxarray37_,
        _mxarray39_,
        _mxarray41_,
        _mxarray39_,
        _mxarray43_,
        _mxarray51_,
        _mxarray47_,
        _mxarray53_,
        NULL));
    /*
     * 'XData', [0 0 0 0 0], ...
     * 'YData', [0 0 0 0 0], ...
     * 'Visible', 'off', ...
     * 'Clipping', 'off', ...
     * 'Color', 'w', ...
     * 'LineStyle', ':');
     * 
     * 
     * % We're ready; wait for the user to do the drag
     * % Wrap the waitfor call in try-catch so
     * % that if the user Ctrl-C's we get a chance to
     * % clean up the figure.
     * errCatch = 0;
     */
    mlfAssign(&errCatch, _mxarray55_);
    /*
     * try
     */
    mlfTry {
        /*
         * waitfor(GETRECT_H1, 'UserData', 'Completed');
         */
        mlfWaitfor(mclVg(&GETRECT_H1, "GETRECT_H1"), _mxarray56_, _mxarray58_);
    /*
     * catch
     */
    } mlfCatch {
        /*
         * errCatch = 1;
         */
        mlfAssign(&errCatch, _mxarray4_);
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * % After the waitfor, if GETRECT_H1 is still valid
     * % and its UserData is 'Completed', then the user
     * % completed the drag.  If not, the user interrupted
     * % the action somehow, perhaps by a Ctrl-C in the
     * % command window or by closing the figure.
     * 
     * if (errCatch == 1)
     */
    if (mclEqBool(mclVv(errCatch, "errCatch"), _mxarray4_)) {
        /*
         * errStatus = 'trap';
         */
        mlfAssign(&errStatus, _mxarray60_);
    /*
     * 
     * elseif (~ishandle(GETRECT_H1) | ...
     */
    } else {
        mxArray * a_
          = mclInitialize(
              mclNot(mlfIshandle(mclVg(&GETRECT_H1, "GETRECT_H1"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mlfStrcmp(
                       mlfNGet(
                         1,
                         mclVg(&GETRECT_H1, "GETRECT_H1"), _mxarray56_, NULL),
                       _mxarray58_))))) {
            mxDestroyArray(a_);
            /*
             * ~strcmp(get(GETRECT_H1, 'UserData'), 'Completed'))
             * errStatus = 'unknown';
             */
            mlfAssign(&errStatus, _mxarray62_);
        /*
         * 
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * errStatus = 'ok';
             */
            mlfAssign(&errStatus, _mxarray64_);
            /*
             * x = get(GETRECT_H1, 'XData');
             */
            mlfAssign(
              &x,
              mlfNGet(1, mclVg(&GETRECT_H1, "GETRECT_H1"), _mxarray31_, NULL));
            /*
             * y = get(GETRECT_H1, 'YData');
             */
            mlfAssign(
              &y,
              mlfNGet(1, mclVg(&GETRECT_H1, "GETRECT_H1"), _mxarray35_, NULL));
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Delete the animation objects
     * if (ishandle(GETRECT_H1))
     */
    if (mlfTobool(mlfIshandle(mclVg(&GETRECT_H1, "GETRECT_H1")))) {
        /*
         * delete(GETRECT_H1);
         */
        mlfDelete(mclVg(&GETRECT_H1, "GETRECT_H1"), NULL);
    /*
     * end
     */
    }
    /*
     * if (ishandle(GETRECT_H2))
     */
    if (mlfTobool(mlfIshandle(mclVg(&GETRECT_H2, "GETRECT_H2")))) {
        /*
         * delete(GETRECT_H2);
         */
        mlfDelete(mclVg(&GETRECT_H2, "GETRECT_H2"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % Restore the figure state
     * if (ishandle(GETRECT_FIG))
     */
    if (mlfTobool(mlfIshandle(mclVg(&GETRECT_FIG, "GETRECT_FIG")))) {
        /*
         * uirestore(state);
         */
        mlfUirestore(mclVv(state, "state"), NULL);
        /*
         * set(GETRECT_FIG, 'DoubleBuffer', old_db);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVg(&GETRECT_FIG, "GETRECT_FIG"),
            _mxarray19_,
            mclVv(old_db, "old_db"),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * CleanUp(xlimorigmode,ylimorigmode,zlimorigmode);
     */
    mlfGetrect_CleanUp(
      mclVv(xlimorigmode, "xlimorigmode"),
      mclVv(ylimorigmode, "ylimorigmode"),
      mclVv(zlimorigmode, "zlimorigmode"));
    /*
     * 
     * % Depending on the error status, return the answer or generate
     * % an error message.
     * switch errStatus
     */
    {
        mxArray * v_ = mclInitialize(mclVv(errStatus, "errStatus"));
        if (mclSwitchCompare(v_, _mxarray64_)) {
            /*
             * case 'ok'
             * % Return the answer
             * xmin = min(x);
             */
            mlfAssign(&xmin, mlfMin(NULL, mclVv(x, "x"), NULL, NULL));
            /*
             * ymin = min(y);
             */
            mlfAssign(&ymin, mlfMin(NULL, mclVv(y, "y"), NULL, NULL));
            /*
             * rect = [xmin ymin max(x)-xmin max(y)-ymin];
             */
            mlfAssign(
              &rect,
              mlfHorzcat(
                mclVv(xmin, "xmin"),
                mclVv(ymin, "ymin"),
                mclMinus(
                  mlfMax(NULL, mclVv(x, "x"), NULL, NULL), mclVv(xmin, "xmin")),
                mclMinus(
                  mlfMax(NULL, mclVv(y, "y"), NULL, NULL), mclVv(ymin, "ymin")),
                NULL));
        /*
         * 
         * case 'trap'
         */
        } else if (mclSwitchCompare(v_, _mxarray60_)) {
            /*
             * % An error was trapped during the waitfor
             * error('Interruption during mouse selection.');
             */
            mlfError(_mxarray66_, NULL);
        /*
         * 
         * case 'unknown'
         */
        } else if (mclSwitchCompare(v_, _mxarray62_)) {
            /*
             * % User did something to cause the rectangle drag to
             * % terminate abnormally.  For example, we would get here
             * % if the user closed the figure in the drag.
             * error('Interruption during mouse selection.');
             */
            mlfError(_mxarray66_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * %--------------------------------------------------
     * % Subfunction ButtonDown
     * %--------------------------------------------------
     */
    return_:
    mclValidateOutput(rect, 1, nargout_, "rect", "getrect");
    mxDestroyArray(ans);
    mxDestroyArray(xlimorigmode);
    mxDestroyArray(ylimorigmode);
    mxDestroyArray(zlimorigmode);
    mxDestroyArray(old_db);
    mxDestroyArray(state);
    mxDestroyArray(errCatch);
    mxDestroyArray(errStatus);
    mxDestroyArray(x);
    mxDestroyArray(y);
    mxDestroyArray(xmin);
    mxDestroyArray(ymin);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return rect;
}

/*
 * The function "Mgetrect_ButtonDown" is the implementation version of the
 * "getrect/ButtonDown" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 166-197). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function ButtonDown
 */
static void Mgetrect_ButtonDown(void) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    mxArray * ydata = NULL;
    mxArray * xdata = NULL;
    mxArray * y2 = NULL;
    mxArray * x2 = NULL;
    mxArray * y1 = NULL;
    mxArray * x1 = NULL;
    mxArray * ans = NULL;
    /*
     * 
     * global GETRECT_FIG GETRECT_AX GETRECT_H1 GETRECT_H2
     * global GETRECT_PT1 GETRECT_TYPE
     * 
     * set(GETRECT_FIG, 'Interruptible', 'off', ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_FIG, "GETRECT_FIG"),
        _mxarray68_,
        _mxarray39_,
        _mxarray70_,
        _mxarray72_,
        NULL));
    /*
     * 'BusyAction', 'cancel');
     * 
     * [x1, y1] = getcurpt(GETRECT_AX);
     */
    mlfAssign(
      &x1, mlfImages_private_getcurpt(&y1, mclVg(&GETRECT_AX, "GETRECT_AX")));
    /*
     * GETRECT_PT1 = [x1 y1];
     */
    mlfAssign(
      mclPrepareGlobal(&GETRECT_PT1),
      mlfHorzcat(mclVv(x1, "x1"), mclVv(y1, "y1"), NULL));
    /*
     * GETRECT_TYPE = get(GETRECT_FIG, 'SelectionType');
     */
    mlfAssign(
      mclPrepareGlobal(&GETRECT_TYPE),
      mlfNGet(1, mclVg(&GETRECT_FIG, "GETRECT_FIG"), _mxarray74_, NULL));
    /*
     * x2 = x1;
     */
    mlfAssign(&x2, mclVv(x1, "x1"));
    /*
     * y2 = y1;
     */
    mlfAssign(&y2, mclVv(y1, "y1"));
    /*
     * xdata = [x1 x2 x2 x1 x1];
     */
    mlfAssign(
      &xdata,
      mlfHorzcat(
        mclVv(x1, "x1"),
        mclVv(x2, "x2"),
        mclVv(x2, "x2"),
        mclVv(x1, "x1"),
        mclVv(x1, "x1"),
        NULL));
    /*
     * ydata = [y1 y1 y2 y2 y1];
     */
    mlfAssign(
      &ydata,
      mlfHorzcat(
        mclVv(y1, "y1"),
        mclVv(y1, "y1"),
        mclVv(y2, "y2"),
        mclVv(y2, "y2"),
        mclVv(y1, "y1"),
        NULL));
    /*
     * 
     * set(GETRECT_H1, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H1, "GETRECT_H1"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        _mxarray37_,
        _mxarray29_,
        NULL));
    /*
     * 'YData', ydata, ...
     * 'Visible', 'on');
     * set(GETRECT_H2, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H2, "GETRECT_H2"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        _mxarray37_,
        _mxarray29_,
        NULL));
    /*
     * 'YData', ydata, ...
     * 'Visible', 'on');
     * 
     * % Let the motion functions take over.
     * set(GETRECT_FIG, 'WindowButtonMotionFcn', 'getrect(''ButtonMotion'');', ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_FIG, "GETRECT_FIG"),
        _mxarray76_,
        _mxarray78_,
        _mxarray80_,
        _mxarray82_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(x1);
    mxDestroyArray(y1);
    mxDestroyArray(x2);
    mxDestroyArray(y2);
    mxDestroyArray(xdata);
    mxDestroyArray(ydata);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 'WindowButtonUpFcn', 'getrect(''ButtonUp'');');
     * 
     * 
     * %-------------------------------------------------
     * % Subfunction ButtonMotion
     * %-------------------------------------------------
     */
}

/*
 * The function "Mgetrect_ButtonMotion" is the implementation version of the
 * "getrect/ButtonMotion" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 197-220). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function ButtonMotion
 */
static void Mgetrect_ButtonMotion(void) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    mxArray * ydata = NULL;
    mxArray * xdata = NULL;
    mxArray * y1 = NULL;
    mxArray * x1 = NULL;
    mxArray * y2 = NULL;
    mxArray * x2 = NULL;
    mxArray * ans = NULL;
    /*
     * 
     * global GETRECT_FIG GETRECT_AX GETRECT_H1 GETRECT_H2
     * global GETRECT_PT1 GETRECT_TYPE
     * 
     * [x2,y2] = getcurpt(GETRECT_AX);
     */
    mlfAssign(
      &x2, mlfImages_private_getcurpt(&y2, mclVg(&GETRECT_AX, "GETRECT_AX")));
    /*
     * x1 = GETRECT_PT1(1,1);
     */
    mlfAssign(&x1, mclIntArrayRef2(mclVg(&GETRECT_PT1, "GETRECT_PT1"), 1, 1));
    /*
     * y1 = GETRECT_PT1(1,2);
     */
    mlfAssign(&y1, mclIntArrayRef2(mclVg(&GETRECT_PT1, "GETRECT_PT1"), 1, 2));
    /*
     * xdata = [x1 x2 x2 x1 x1];
     */
    mlfAssign(
      &xdata,
      mlfHorzcat(
        mclVv(x1, "x1"),
        mclVv(x2, "x2"),
        mclVv(x2, "x2"),
        mclVv(x1, "x1"),
        mclVv(x1, "x1"),
        NULL));
    /*
     * ydata = [y1 y1 y2 y2 y1];
     */
    mlfAssign(
      &ydata,
      mlfHorzcat(
        mclVv(y1, "y1"),
        mclVv(y1, "y1"),
        mclVv(y2, "y2"),
        mclVv(y2, "y2"),
        mclVv(y1, "y1"),
        NULL));
    /*
     * 
     * if (~strcmp(GETRECT_TYPE, 'normal'))
     */
    if (mclNotBool(
          mlfStrcmp(mclVg(&GETRECT_TYPE, "GETRECT_TYPE"), _mxarray84_))) {
        /*
         * [xdata, ydata] = Constrain(xdata, ydata);
         */
        mlfAssign(
          &xdata,
          mlfGetrect_Constrain(
            &ydata, mclVv(xdata, "xdata"), mclVv(ydata, "ydata")));
    /*
     * end
     */
    }
    /*
     * 
     * set(GETRECT_H1, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H1, "GETRECT_H1"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        NULL));
    /*
     * 'YData', ydata);
     * set(GETRECT_H2, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H2, "GETRECT_H2"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(x2);
    mxDestroyArray(y2);
    mxDestroyArray(x1);
    mxDestroyArray(y1);
    mxDestroyArray(xdata);
    mxDestroyArray(ydata);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 'YData', ydata);
     * 
     * %--------------------------------------------------
     * % Subfunction ButtonUp
     * %--------------------------------------------------
     */
}

/*
 * The function "Mgetrect_ButtonUp" is the implementation version of the
 * "getrect/ButtonUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 220-253). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function ButtonUp
 */
static void Mgetrect_ButtonUp(void) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    mxArray * ydata = NULL;
    mxArray * xdata = NULL;
    mxArray * y1 = NULL;
    mxArray * x1 = NULL;
    mxArray * y2 = NULL;
    mxArray * x2 = NULL;
    mxArray * ans = NULL;
    /*
     * 
     * global GETRECT_FIG GETRECT_AX GETRECT_H1 GETRECT_H2
     * global GETRECT_PT1 GETRECT_TYPE
     * 
     * % Kill the motion function and discard pending events
     * set(GETRECT_FIG, 'WindowButtonMotionFcn', '', ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_FIG, "GETRECT_FIG"),
        _mxarray76_,
        _mxarray86_,
        _mxarray68_,
        _mxarray39_,
        NULL));
    /*
     * 'Interruptible', 'off');
     * 
     * % Set final line data
     * [x2,y2] = getcurpt(GETRECT_AX);
     */
    mlfAssign(
      &x2, mlfImages_private_getcurpt(&y2, mclVg(&GETRECT_AX, "GETRECT_AX")));
    /*
     * x1 = GETRECT_PT1(1,1);
     */
    mlfAssign(&x1, mclIntArrayRef2(mclVg(&GETRECT_PT1, "GETRECT_PT1"), 1, 1));
    /*
     * y1 = GETRECT_PT1(1,2);
     */
    mlfAssign(&y1, mclIntArrayRef2(mclVg(&GETRECT_PT1, "GETRECT_PT1"), 1, 2));
    /*
     * xdata = [x1 x2 x2 x1 x1];
     */
    mlfAssign(
      &xdata,
      mlfHorzcat(
        mclVv(x1, "x1"),
        mclVv(x2, "x2"),
        mclVv(x2, "x2"),
        mclVv(x1, "x1"),
        mclVv(x1, "x1"),
        NULL));
    /*
     * ydata = [y1 y1 y2 y2 y1];
     */
    mlfAssign(
      &ydata,
      mlfHorzcat(
        mclVv(y1, "y1"),
        mclVv(y1, "y1"),
        mclVv(y2, "y2"),
        mclVv(y2, "y2"),
        mclVv(y1, "y1"),
        NULL));
    /*
     * if (~strcmp(GETRECT_TYPE, 'normal'))
     */
    if (mclNotBool(
          mlfStrcmp(mclVg(&GETRECT_TYPE, "GETRECT_TYPE"), _mxarray84_))) {
        /*
         * [xdata, ydata] = Constrain(xdata, ydata);
         */
        mlfAssign(
          &xdata,
          mlfGetrect_Constrain(
            &ydata, mclVv(xdata, "xdata"), mclVv(ydata, "ydata")));
    /*
     * end
     */
    }
    /*
     * 
     * set(GETRECT_H1, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H1, "GETRECT_H1"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        NULL));
    /*
     * 'YData', ydata);
     * set(GETRECT_H2, 'XData', xdata, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVg(&GETRECT_H2, "GETRECT_H2"),
        _mxarray31_,
        mclVv(xdata, "xdata"),
        _mxarray35_,
        mclVv(ydata, "ydata"),
        NULL));
    /*
     * 'YData', ydata);
     * 
     * % Unblock execution of the main routine
     * set(GETRECT_H1, 'UserData', 'Completed');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVg(&GETRECT_H1, "GETRECT_H1"), _mxarray56_, _mxarray58_, NULL));
    mxDestroyArray(ans);
    mxDestroyArray(x2);
    mxDestroyArray(y2);
    mxDestroyArray(x1);
    mxDestroyArray(y1);
    mxDestroyArray(xdata);
    mxDestroyArray(ydata);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %-----------------------------------------------
     * % Subfunction Constrain
     * % 
     * % constrain rectangle to be a square in
     * % axes coordinates
     * %-----------------------------------------------
     */
}

/*
 * The function "Mgetrect_Constrain" is the implementation version of the
 * "getrect/Constrain" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 253-274). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [xdata_out, ydata_out] = Constrain(xdata, ydata)
 */
static mxArray * Mgetrect_Constrain(mxArray * * ydata_out,
                                    int nargout_,
                                    mxArray * xdata,
                                    mxArray * ydata) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    mxArray * xdata_out = NULL;
    mxArray * xdis = NULL;
    mxArray * ydis = NULL;
    mxArray * y2 = NULL;
    mxArray * y1 = NULL;
    mxArray * x2 = NULL;
    mxArray * x1 = NULL;
    mclCopyArray(&xdata);
    mclCopyArray(&ydata);
    /*
     * 
     * x1 = xdata(1);
     */
    mlfAssign(&x1, mclIntArrayRef1(mclVa(xdata, "xdata"), 1));
    /*
     * x2 = xdata(2);
     */
    mlfAssign(&x2, mclIntArrayRef1(mclVa(xdata, "xdata"), 2));
    /*
     * y1 = ydata(1);
     */
    mlfAssign(&y1, mclIntArrayRef1(mclVa(ydata, "ydata"), 1));
    /*
     * y2 = ydata(3);
     */
    mlfAssign(&y2, mclIntArrayRef1(mclVa(ydata, "ydata"), 3));
    /*
     * ydis = abs(y2 - y1);
     */
    mlfAssign(&ydis, mlfAbs(mclMinus(mclVv(y2, "y2"), mclVv(y1, "y1"))));
    /*
     * xdis = abs(x2 - x1);
     */
    mlfAssign(&xdis, mlfAbs(mclMinus(mclVv(x2, "x2"), mclVv(x1, "x1"))));
    /*
     * 
     * if (ydis > xdis)
     */
    if (mclGtBool(mclVv(ydis, "ydis"), mclVv(xdis, "xdis"))) {
        /*
         * x2 = x1 + sign(x2 - x1) * ydis;
         */
        mlfAssign(
          &x2,
          mclPlus(
            mclVv(x1, "x1"),
            mclMtimes(
              mlfSign(mclMinus(mclVv(x2, "x2"), mclVv(x1, "x1"))),
              mclVv(ydis, "ydis"))));
    /*
     * else
     */
    } else {
        /*
         * y2 = y1 + sign(y2 - y1) * xdis;
         */
        mlfAssign(
          &y2,
          mclPlus(
            mclVv(y1, "y1"),
            mclMtimes(
              mlfSign(mclMinus(mclVv(y2, "y2"), mclVv(y1, "y1"))),
              mclVv(xdis, "xdis"))));
    /*
     * end
     */
    }
    /*
     * 
     * xdata_out = [x1 x2 x2 x1 x1];
     */
    mlfAssign(
      &xdata_out,
      mlfHorzcat(
        mclVv(x1, "x1"),
        mclVv(x2, "x2"),
        mclVv(x2, "x2"),
        mclVv(x1, "x1"),
        mclVv(x1, "x1"),
        NULL));
    /*
     * ydata_out = [y1 y1 y2 y2 y1];
     */
    mlfAssign(
      ydata_out,
      mlfHorzcat(
        mclVv(y1, "y1"),
        mclVv(y1, "y1"),
        mclVv(y2, "y2"),
        mclVv(y2, "y2"),
        mclVv(y1, "y1"),
        NULL));
    mclValidateOutput(xdata_out, 1, nargout_, "xdata_out", "getrect/Constrain");
    mclValidateOutput(
      *ydata_out, 2, nargout_, "ydata_out", "getrect/Constrain");
    mxDestroyArray(x1);
    mxDestroyArray(x2);
    mxDestroyArray(y1);
    mxDestroyArray(y2);
    mxDestroyArray(ydis);
    mxDestroyArray(xdis);
    mxDestroyArray(ydata);
    mxDestroyArray(xdata);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return xdata_out;
    /*
     * 
     * %---------------------------------------------------
     * % Subfunction CleanUp
     * %--------------------------------------------------
     */
}

/*
 * The function "Mgetrect_CleanUp" is the implementation version of the
 * "getrect/CleanUp" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getrect.m" (lines 274-285). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function CleanUp(xlimmode,ylimmode,zlimmode)
 */
static void Mgetrect_CleanUp(mxArray * xlimmode,
                             mxArray * ylimmode,
                             mxArray * zlimmode) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getrect);
    mxArray * ans = NULL;
    mclCopyArray(&xlimmode);
    mclCopyArray(&ylimmode);
    mclCopyArray(&zlimmode);
    /*
     * 
     * xlim(xlimmode);
     */
    mclAssignAns(&ans, mlfXlim(mclVa(xlimmode, "xlimmode"), NULL));
    /*
     * ylim(ylimmode);
     */
    mclAssignAns(&ans, mlfYlim(mclVa(ylimmode, "ylimmode"), NULL));
    /*
     * zlim(zlimmode);
     */
    mclAssignAns(&ans, mlfZlim(mclVa(zlimmode, "zlimmode"), NULL));
    /*
     * % Clean up the global workspace
     * clear global GETRECT_FIG GETRECT_AX GETRECT_H1 GETRECT_H2
     */
    mlfClear(
      mclPrepareGlobal(&GETRECT_FIG),
      mclPrepareGlobal(&GETRECT_AX),
      mclPrepareGlobal(&GETRECT_H1),
      mclPrepareGlobal(&GETRECT_H2),
      NULL);
    /*
     * clear global GETRECT_PT1 GETRECT_TYPE
     */
    mlfClear(
      mclPrepareGlobal(&GETRECT_PT1), mclPrepareGlobal(&GETRECT_TYPE), NULL);
    mxDestroyArray(ans);
    mxDestroyArray(zlimmode);
    mxDestroyArray(ylimmode);
    mxDestroyArray(xlimmode);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}
