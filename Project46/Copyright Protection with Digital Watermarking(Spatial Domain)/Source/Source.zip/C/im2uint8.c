/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "im2uint8.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "images_private_grayto8_mex_interface.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array5_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray6_;

static mxChar _array9_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray8_;

static mxChar _array11_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray10_;

static mxArray * _array3_[4] = { NULL /*_mxarray4_*/, NULL /*_mxarray6_*/,
                                 NULL /*_mxarray8_*/, NULL /*_mxarray10_*/ };
static mxArray * _mxarray2_;
static mxArray * _mxarray12_;

static mxChar _array14_[5] = { 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;

static mxChar _array18_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray17_;
static mxArray * _mxarray16_;

static mxChar _array20_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray19_;

static mxChar _array22_[42] = { 'T', 'o', 'o', ' ', 'm', 'a', 'n', 'y', ' ',
                                'c', 'o', 'l', 'o', 'r', 's', ' ', 'f', 'o',
                                'r', ' ', '8', '-', 'b', 'i', 't', ' ', 'i',
                                'n', 't', 'e', 'g', 'e', 'r', ' ', 's', 't',
                                'o', 'r', 'a', 'g', 'e', '.' };
static mxArray * _mxarray21_;

static mxChar _array24_[37] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 't', 'o', 'o', 'M', 'a', 'n',
                                'y', 'C', 'o', 'l', 'o', 'r', 's', 'F',
                                'o', 'r', '8', 'b', 'i', 't', 'S', 't',
                                'o', 'r', 'a', 'g', 'e' };
static mxArray * _mxarray23_;
static mxArray * _mxarray25_;

static mxChar _array27_[48] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'd', 'e', 'x', 'e', 'd', ' ',
                                'i', 'm', 'a', 'g', 'e', ':', ' ', 'a',
                                'n', ' ', 'i', 'n', 'd', 'e', 'x', ' ',
                                'w', 'a', 's', ' ', 'l', 'e', 's', 's',
                                ' ', 't', 'h', 'a', 'n', ' ', '1', '.' };
static mxArray * _mxarray26_;

static mxChar _array29_[29] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'i', 'n', 'v', 'a', 'l', 'i',
                                'd', 'I', 'n', 'd', 'e', 'x', 'e', 'd',
                                'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray28_;

void InitializeModule_im2uint8(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray4_ = mclInitializeString(6, _array5_);
    _array3_[0] = _mxarray4_;
    _mxarray6_ = mclInitializeString(7, _array7_);
    _array3_[1] = _mxarray6_;
    _mxarray8_ = mclInitializeString(5, _array9_);
    _array3_[2] = _mxarray8_;
    _mxarray10_ = mclInitializeString(6, _array11_);
    _array3_[3] = _mxarray10_;
    _mxarray2_ = mclInitializeCellVector(1, 4, _array3_);
    _mxarray12_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray13_ = mclInitializeString(5, _array14_);
    _mxarray15_ = mclInitializeDouble(255.0);
    _mxarray17_ = mclInitializeString(7, _array18_);
    _mxarray16_ = mclInitializeCell(_mxarray17_);
    _mxarray19_ = mclInitializeString(4, _array20_);
    _mxarray21_ = mclInitializeString(42, _array22_);
    _mxarray23_ = mclInitializeString(37, _array24_);
    _mxarray25_ = mclInitializeDouble(257.0);
    _mxarray26_ = mclInitializeString(48, _array27_);
    _mxarray28_ = mclInitializeString(29, _array29_);
}

void TerminateModule_im2uint8(void) {
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mim2uint8(int nargout_, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_im2uint8
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIm2uint8" contains the normal interface for the "im2uint8"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2uint8.m" (lines
 * 1-71). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfIm2uint8(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * u = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    u = Mim2uint8(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(u);
}

/*
 * The function "mlxIm2uint8" contains the feval interface for the "im2uint8"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2uint8.m" (lines
 * 1-71). The feval function calls the implementation version of im2uint8
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIm2uint8(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: im2uint8 Line: 1 Column:"
            " 1 The function \"im2uint8\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mim2uint8(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mim2uint8" is the implementation version of the "im2uint8"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2uint8.m" (lines
 * 1-71). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function u = im2uint8(varargin)
 */
static mxArray * Mim2uint8(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_im2uint8);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * u = NULL;
    mxArray * eid = NULL;
    mxArray * msg = NULL;
    mxArray * typestr = NULL;
    mxArray * img = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * %IM2UINT8 Convert image to eight-bit unsigned integers.
     * %   IM2UINT8 takes an image as input, and returns an image of
     * %   class uint8.  If the input image is of class uint8, the
     * %   output image is identical to it.  If the input image is of
     * %   class logical, double or uint16, im2uint8 returns the
     * %   equivalent image of class uint8, rescaling or offsetting 
     * %   the data as necessary.
     * %
     * %   I2 = IM2UINT8(I1) converts the intensity image I1 to uint8,
     * %   rescaling the data if necessary.
     * %
     * %   RGB2 = IM2UINT8(RGB1) converts the truecolor image RGB1 to
     * %   uint8, rescaling the data if necessary.
     * %
     * %   BW2 = IM2UINT8(BW1) converts the binary image BW1 to uint8.
     * %
     * %   X2 = IM2UINT8(X1,'indexed') converts the indexed image X1 to
     * %   uint8, offsetting the data if necessary. Note that it is
     * %   not always possible to convert an indexed image to
     * %   uint8. If X1 is double, then the maximum value of X1 must
     * %   be 256 or less.  If X1 is uint16, the maximum value of X1
     * %   must be 255 or less.
     * %
     * %   See also DOUBLE, IM2DOUBLE, IM2UINT16, UINT8, UINT16, IMAPPROX.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.20 $  $Date: 2002/03/15 15:27:39 $
     * 
     * checknargin(1,2,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("im2uint8"));
    /*
     * 
     * img = varargin{1};
     */
    mlfAssign(
      &img, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
    /*
     * checkinput(img,{'double','logical','uint8','uint16'},{},mfilename,'Image',1);
     */
    mlfImages_private_checkinput(
      mclVv(img, "img"),
      _mxarray2_,
      _mxarray12_,
      mxCreateString("im2uint8"),
      _mxarray13_,
      _mxarray0_);
    /*
     * 
     * if isa(img, 'uint8')
     */
    if (mlfTobool(mlfIsa(mclVv(img, "img"), _mxarray8_))) {
        /*
         * u = img; 
         */
        mlfAssign(&u, mclVv(img, "img"));
    /*
     * elseif isa(img, 'logical')
     */
    } else if (mlfTobool(mlfIsa(mclVv(img, "img"), _mxarray6_))) {
        /*
         * u=uint8(img);
         */
        mlfAssign(&u, mlfUint8(mclVv(img, "img")));
        /*
         * u(img)=255;
         */
        mclArrayAssign1(&u, _mxarray15_, mclVv(img, "img"));
    /*
     * elseif isa(img, 'double') | isa(img, 'uint16')
     */
    } else {
        mxArray * a_ = mclInitialize(mlfIsa(mclVv(img, "img"), _mxarray4_));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mlfIsa(mclVv(img, "img"), _mxarray10_)))) {
            mxDestroyArray(a_);
            /*
             * if nargin==1
             */
            if (nargin_ == 1) {
                /*
                 * % intensity image; call MEX-file
                 * u = grayto8(img);
                 */
                mlfAssign(
                  &u,
                  mlfNImages_private_grayto8(
                    0, mclValueVarargout(), mclVv(img, "img"), NULL));
            /*
             * elseif nargin==2
             */
            } else if (nargin_ == 2) {
                /*
                 * typestr = varargin{2};
                 */
                mlfAssign(
                  &typestr,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
                /*
                 * checkstrs(typestr,{'indexed'},mfilename,'type',2);
                 */
                mclAssignAns(
                  &ans,
                  mlfImages_private_checkstrs(
                    mclVv(typestr, "typestr"),
                    _mxarray16_,
                    mxCreateString("im2uint8"),
                    _mxarray19_,
                    _mxarray1_));
                /*
                 * if (isa(img, 'uint16'))
                 */
                if (mlfTobool(mlfIsa(mclVv(img, "img"), _mxarray10_))) {
                    /*
                     * if (max(img(:)) > 255)
                     */
                    if (mclGtBool(
                          mlfMax(
                            NULL,
                            mclArrayRef1(
                              mclVv(img, "img"), mlfCreateColonIndex()),
                            NULL,
                            NULL),
                          _mxarray15_)) {
                        /*
                         * msg = 'Too many colors for 8-bit integer storage.';
                         */
                        mlfAssign(&msg, _mxarray21_);
                        /*
                         * eid = sprintf('Images:%s:tooManyColorsFor8bitStorage');
                         */
                        mlfAssign(&eid, mlfSprintf(NULL, _mxarray23_, NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * else
                     */
                    } else {
                        /*
                         * u = uint8(img);
                         */
                        mlfAssign(&u, mlfUint8(mclVv(img, "img")));
                    /*
                     * end
                     */
                    }
                /*
                 * else
                 */
                } else {
                    /*
                     * % img is double
                     * if max(img(:))>=257 
                     */
                    if (mclGeBool(
                          mlfMax(
                            NULL,
                            mclArrayRef1(
                              mclVv(img, "img"), mlfCreateColonIndex()),
                            NULL,
                            NULL),
                          _mxarray25_)) {
                        /*
                         * msg = 'Too many colors for 8-bit integer storage.';
                         */
                        mlfAssign(&msg, _mxarray21_);
                        /*
                         * eid = sprintf('Images:%s:tooManyColorsFor8bitStorage');
                         */
                        mlfAssign(&eid, mlfSprintf(NULL, _mxarray23_, NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * elseif min(img(:))<1
                     */
                    } else if (mclLtBool(
                                 mlfMin(
                                   NULL,
                                   mclArrayRef1(
                                     mclVv(img, "img"), mlfCreateColonIndex()),
                                   NULL,
                                   NULL),
                                 _mxarray0_)) {
                        /*
                         * msg = 'Invalid indexed image: an index was less than 1.';
                         */
                        mlfAssign(&msg, _mxarray26_);
                        /*
                         * eid = sprintf('Images:%s:invalidIndexedImage');
                         */
                        mlfAssign(&eid, mlfSprintf(NULL, _mxarray28_, NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * else
                     */
                    } else {
                        /*
                         * u = uint8(img-1);
                         */
                        mlfAssign(
                          &u,
                          mlfUint8(mclMinus(mclVv(img, "img"), _mxarray0_)));
                    /*
                     * end
                     */
                    }
                /*
                 * end
                 */
                }
            /*
             * end
             */
            }
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(u, 1, nargout_, "u", "im2uint8");
    mxDestroyArray(ans);
    mxDestroyArray(img);
    mxDestroyArray(typestr);
    mxDestroyArray(msg);
    mxDestroyArray(eid);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return u;
}
