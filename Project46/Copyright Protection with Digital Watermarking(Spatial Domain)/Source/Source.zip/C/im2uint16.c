/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "im2uint16.h"
#include "images_private_checknargin.h"
#include "images_private_grayto16_mex_interface.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array3_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray2_;

static mxChar _array5_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray4_;

static mxChar _array7_[1] = { 'i' };
static mxArray * _mxarray6_;

static mxChar _array9_[29] = { 'I', 'm', 'a', 'g', 'e', 's', ':', 'i', 'm', '2',
                               'u', 'i', 'n', 't', '1', '6', ':', 'i', 'n', 'v',
                               'a', 'l', 'i', 'd', 'I', 'n', 'p', 'u', 't' };
static mxArray * _mxarray8_;

static mxChar _array11_[23] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray10_;

static mxChar _array13_[2] = { '%', 's' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;

static mxChar _array16_[30] = { 'I', 'm', 'a', 'g', 'e', 's', ':', 'i',
                                'm', '2', 'u', 'i', 'n', 't', '1', '6',
                                ':', 't', 'o', 'o', 'M', 'a', 'n', 'y',
                                'C', 'o', 'l', 'o', 'r', 's' };
static mxArray * _mxarray15_;

static mxChar _array18_[43] = { 'T', 'o', 'o', ' ', 'm', 'a', 'n', 'y', ' ',
                                'c', 'o', 'l', 'o', 'r', 's', ' ', 'f', 'o',
                                'r', ' ', '1', '6', '-', 'b', 'i', 't', ' ',
                                'i', 'n', 't', 'e', 'g', 'e', 'r', ' ', 's',
                                't', 'o', 'r', 'a', 'g', 'e', '.' };
static mxArray * _mxarray17_;

static mxChar _array20_[29] = { 'I', 'm', 'a', 'g', 'e', 's', ':', 'i',
                                'm', '2', 'u', 'i', 'n', 't', '1', '6',
                                ':', 'i', 'n', 'v', 'a', 'l', 'i', 'd',
                                'I', 'n', 'd', 'e', 'x' };
static mxArray * _mxarray19_;

static mxChar _array22_[48] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'd', 'e', 'x', 'e', 'd', ' ',
                                'i', 'm', 'a', 'g', 'e', ':', ' ', 'a',
                                'n', ' ', 'i', 'n', 'd', 'e', 'x', ' ',
                                'w', 'a', 's', ' ', 'l', 'e', 's', 's',
                                ' ', 't', 'h', 'a', 'n', ' ', '1', '.' };
static mxArray * _mxarray21_;
static mxArray * _mxarray23_;

static mxChar _array25_[38] = { 'I', 'm', 'a', 'g', 'e', 's', ':', 'i',
                                'm', '2', 'u', 'i', 'n', 't', '1', '6',
                                ':', 'u', 'n', 's', 'u', 'p', 'p', 'o',
                                'r', 't', 'e', 'd', 'I', 'n', 'p', 'u',
                                't', 'C', 'l', 'a', 's', 's' };
static mxArray * _mxarray24_;

static mxChar _array27_[24] = { 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r',
                                't', 'e', 'd', ' ', 'i', 'n', 'p', 'u',
                                't', ' ', 'c', 'l', 'a', 's', 's', '.' };
static mxArray * _mxarray26_;

static mxChar _array29_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray28_;

void InitializeModule_im2uint16(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _mxarray4_ = mclInitializeString(5, _array5_);
    _mxarray6_ = mclInitializeString(1, _array7_);
    _mxarray8_ = mclInitializeString(29, _array9_);
    _mxarray10_ = mclInitializeString(23, _array11_);
    _mxarray12_ = mclInitializeString(2, _array13_);
    _mxarray14_ = mclInitializeDouble(65537.0);
    _mxarray15_ = mclInitializeString(30, _array16_);
    _mxarray17_ = mclInitializeString(43, _array18_);
    _mxarray19_ = mclInitializeString(29, _array20_);
    _mxarray21_ = mclInitializeString(48, _array22_);
    _mxarray23_ = mclInitializeDouble(65535.0);
    _mxarray24_ = mclInitializeString(38, _array25_);
    _mxarray26_ = mclInitializeString(24, _array27_);
    _mxarray28_ = mclInitializeString(6, _array29_);
}

void TerminateModule_im2uint16(void) {
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mim2uint16(int nargout_, mxArray * img, mxArray * typestr);

_mexLocalFunctionTable _local_function_table_im2uint16
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIm2uint16" contains the normal interface for the
 * "im2uint16" M-function from file
 * "k:\matlab6p5\toolbox\images\images\im2uint16.m" (lines 1-74). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfIm2uint16(mxArray * img, mxArray * typestr) {
    int nargout = 1;
    mxArray * u = NULL;
    mlfEnterNewContext(0, 2, img, typestr);
    u = Mim2uint16(nargout, img, typestr);
    mlfRestorePreviousContext(0, 2, img, typestr);
    return mlfReturnValue(u);
}

/*
 * The function "mlxIm2uint16" contains the feval interface for the "im2uint16"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2uint16.m" (lines
 * 1-74). The feval function calls the implementation version of im2uint16
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIm2uint16(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: im2uint16 Line: 1 Column:"
            " 1 The function \"im2uint16\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: im2uint16 Line: 1 Column:"
            " 1 The function \"im2uint16\" was called with m"
            "ore than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mim2uint16(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mim2uint16" is the implementation version of the "im2uint16"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2uint16.m" (lines
 * 1-74). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function u = im2uint16(img, typestr)
 */
static mxArray * Mim2uint16(int nargout_, mxArray * img, mxArray * typestr) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_im2uint16);
    int nargin_ = mclNargin(2, img, typestr, NULL);
    mxArray * u = NULL;
    mxArray * msg = NULL;
    mxArray * eid = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&img);
    mclCopyArray(&typestr);
    /*
     * %IM2UINT16 Convert image to sixteen-bit unsigned integers.
     * %   IM2UINT16 takes an image as input, and returns an image of
     * %   class uint16.  If the input image is of class uint16, the
     * %   output image is identical to it.  If the input image is of
     * %   class double or uint8, IM2UINT16 returns the equivalent
     * %   image of class uint16, rescaling or offsetting the data as
     * %   necessary.
     * %
     * %   I2 = IM2UINT16(I1) converts the intensity image I1 to uint16,
     * %   rescaling the data if necessary.
     * %
     * %   RGB2 = IM2UINT16(RGB1) converts the truecolor image RGB1 to
     * %   uint16, rescaling the data if necessary.
     * %
     * %   X2 = IM2UINT16(X1,'indexed') converts the indexed image X1 to
     * %   uint16, offsetting the data if necessary.  If X1 is double,
     * %   then the maximum value of X1 must be 65536 or less.
     * %
     * %   I = IM2UINT16(BW) converts the binary image BW to a uint16 intensity
     * %   image.
     * %
     * %   See also DOUBLE, IM2DOUBLE, IM2UINT8, UINT8, UINT16.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.12 $  $Date: 2002/03/15 15:27:38 $
     * 
     * checknargin(1,2,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("im2uint16"));
    /*
     * 
     * if isa(img, 'uint16')
     */
    if (mlfTobool(mlfIsa(mclVa(img, "img"), _mxarray2_))) {
        /*
         * u = img; 
         */
        mlfAssign(&u, mclVa(img, "img"));
    /*
     * 
     * elseif isa(img, 'double') | isa(img, 'uint8')
     */
    } else {
        mxArray * a_ = mclInitialize(mlfIsa(mclVa(img, "img"), _mxarray28_));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mlfIsa(mclVa(img, "img"), _mxarray4_)))) {
            mxDestroyArray(a_);
            /*
             * if nargin==1
             */
            if (nargin_ == 1) {
                /*
                 * % intensity image; call MEX-file
                 * u = grayto16(img);
                 */
                mlfAssign(
                  &u,
                  mlfNImages_private_grayto16(
                    0, mclValueVarargout(), mclVa(img, "img"), NULL));
            /*
             * 
             * elseif nargin==2
             */
            } else if (nargin_ == 2) {
                /*
                 * 
                 * if ~ischar(typestr) | (typestr(1) ~= 'i')
                 */
                mxArray * a_0
                  = mclInitialize(
                      mclNot(mlfIschar(mclVa(typestr, "typestr"))));
                if (mlfTobool(a_0)
                    || mlfTobool(
                         mclOr(
                           a_0,
                           mclNe(
                             mclIntArrayRef1(mclVa(typestr, "typestr"), 1),
                             _mxarray6_)))) {
                    mxDestroyArray(a_0);
                    /*
                     * eid = 'Images:im2uint16:invalidInput';
                     */
                    mlfAssign(&eid, _mxarray8_);
                    /*
                     * msg = 'Invalid input arguments';
                     */
                    mlfAssign(&msg, _mxarray10_);
                    /*
                     * error(eid,'%s',msg);
                     */
                    mlfError(
                      mclVv(eid, "eid"), _mxarray12_, mclVv(msg, "msg"), NULL);
                /*
                 * else 
                 */
                } else {
                    mxDestroyArray(a_0);
                    /*
                     * if (isa(img, 'uint8'))
                     */
                    if (mlfTobool(mlfIsa(mclVa(img, "img"), _mxarray4_))) {
                        /*
                         * u = uint16(img);
                         */
                        mlfAssign(&u, mlfUint16(mclVa(img, "img")));
                    /*
                     * 
                     * else
                     */
                    } else {
                        /*
                         * % img is double
                         * if max(img(:))>=65537 
                         */
                        if (mclGeBool(
                              mlfMax(
                                NULL,
                                mclArrayRef1(
                                  mclVa(img, "img"), mlfCreateColonIndex()),
                                NULL,
                                NULL),
                              _mxarray14_)) {
                            /*
                             * eid = 'Images:im2uint16:tooManyColors';
                             */
                            mlfAssign(&eid, _mxarray15_);
                            /*
                             * msg = 'Too many colors for 16-bit integer storage.';
                             */
                            mlfAssign(&msg, _mxarray17_);
                            /*
                             * error(eid,'%s',msg);
                             */
                            mlfError(
                              mclVv(eid, "eid"),
                              _mxarray12_,
                              mclVv(msg, "msg"),
                              NULL);
                        /*
                         * elseif min(img(:))<1
                         */
                        } else if (mclLtBool(
                                     mlfMin(
                                       NULL,
                                       mclArrayRef1(
                                         mclVa(img, "img"),
                                         mlfCreateColonIndex()),
                                       NULL,
                                       NULL),
                                     _mxarray0_)) {
                            /*
                             * eid = 'Images:im2uint16:invalidIndex';
                             */
                            mlfAssign(&eid, _mxarray19_);
                            /*
                             * msg = 'Invalid indexed image: an index was less than 1.';
                             */
                            mlfAssign(&msg, _mxarray21_);
                            /*
                             * error(eid,'%s',msg);
                             */
                            mlfError(
                              mclVv(eid, "eid"),
                              _mxarray12_,
                              mclVv(msg, "msg"),
                              NULL);
                        /*
                         * else
                         */
                        } else {
                            /*
                             * u = uint16(img-1);
                             */
                            mlfAssign(
                              &u,
                              mlfUint16(
                                mclMinus(mclVa(img, "img"), _mxarray0_)));
                        /*
                         * end
                         */
                        }
                    /*
                     * end
                     */
                    }
                }
            /*
             * end
             * end
             */
            }
        /*
         * 
         * elseif islogical(img)
         */
        } else {
            mxDestroyArray(a_);
            if (mlfTobool(mlfIslogical(mclVa(img, "img")))) {
                /*
                 * u = uint16(img);
                 */
                mlfAssign(&u, mlfUint16(mclVa(img, "img")));
                /*
                 * u(img) = 65535;
                 */
                mclArrayAssign1(&u, _mxarray23_, mclVa(img, "img"));
            /*
             * 
             * else
             */
            } else {
                /*
                 * eid = 'Images:im2uint16:unsupportedInputClass';
                 */
                mlfAssign(&eid, _mxarray24_);
                /*
                 * msg = 'Unsupported input class.';
                 */
                mlfAssign(&msg, _mxarray26_);
                /*
                 * error(eid,'%s',msg);
                 */
                mlfError(
                  mclVv(eid, "eid"), _mxarray12_, mclVv(msg, "msg"), NULL);
            }
        }
    /*
     * end
     */
    }
    mclValidateOutput(u, 1, nargout_, "u", "im2uint16");
    mxDestroyArray(ans);
    mxDestroyArray(eid);
    mxDestroyArray(msg);
    mxDestroyArray(typestr);
    mxDestroyArray(img);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return u;
}
