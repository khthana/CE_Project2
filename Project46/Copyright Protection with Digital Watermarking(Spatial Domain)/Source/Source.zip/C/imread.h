/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __imread_h
#define __imread_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_imread(void);
extern void TerminateModule_imread(void);
extern _mexLocalFunctionTable _local_function_table_imread;

extern mxArray * mlfNImread(int nargout,
                            mxArray * * map,
                            mxArray * * alpha,
                            ...);
extern mxArray * mlfImread(mxArray * * map, mxArray * * alpha, ...);
extern void mlfVImread(mxArray * synthetic_varargin_argument, ...);
extern void mlxImread(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
