/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imshow.h"
#include "imread.h"
#include "iptgetpref.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
#include "truesize.h"
static mxArray * _mxarray0_;

static mxChar _array2_[13] = { 'C', 'u', 'r', 'r', 'e', 'n', 't',
                               'F', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray1_;

static mxChar _array4_[8] = { 'N', 'e', 'x', 't', 'P', 'l', 'o', 't' };
static mxArray * _mxarray3_;

static mxChar _array6_[3] = { 'n', 'e', 'w' };
static mxArray * _mxarray5_;
static mxArray * _mxarray7_;
static mxArray * _mxarray8_;

static mxChar _array10_[7] = { 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray9_;

static mxChar _array12_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray11_;

static mxChar _array14_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray13_;

static mxChar _array16_[10] = { 'B', 'u', 's', 'y', 'A',
                                'c', 't', 'i', 'o', 'n' };
static mxArray * _mxarray15_;

static mxChar _array18_[6] = { 'c', 'a', 'n', 'c', 'e', 'l' };
static mxArray * _mxarray17_;

static mxChar _array20_[12] = { 'C', 'D', 'a', 't', 'a', 'M',
                                'a', 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray19_;

static mxChar _array22_[13] = { 'I', 'n', 't', 'e', 'r', 'r', 'u',
                                'p', 't', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray21_;

static mxChar _array24_[17] = { 'I', 'm', 's', 'h', 'o', 'w', 'A', 'x', 'e',
                                's', 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray23_;

static mxChar _array26_[7] = { 'T', 'i', 'c', 'k', 'D', 'i', 'r' };
static mxArray * _mxarray25_;

static mxChar _array28_[3] = { 'o', 'u', 't' };
static mxArray * _mxarray27_;

static mxChar _array30_[5] = { 'X', 'G', 'r', 'i', 'd' };
static mxArray * _mxarray29_;

static mxChar _array32_[5] = { 'Y', 'G', 'r', 'i', 'd' };
static mxArray * _mxarray31_;

static mxChar _array34_[15] = { 'D', 'a', 't', 'a', 'A', 's', 'p', 'e',
                                'c', 't', 'R', 'a', 't', 'i', 'o' };
static mxArray * _mxarray33_;

static double _array36_[3] = { 1.0, 1.0, 1.0 };
static mxArray * _mxarray35_;

static mxChar _array38_[22] = { 'P', 'l', 'o', 't', 'B', 'o', 'x', 'A',
                                's', 'p', 'e', 'c', 't', 'R', 'a', 't',
                                'i', 'o', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray37_;

static mxChar _array40_[4] = { 'a', 'u', 't', 'o' };
static mxArray * _mxarray39_;

static mxChar _array42_[5] = { 'T', 'i', 't', 'l', 'e' };
static mxArray * _mxarray41_;

static mxChar _array44_[2] = { 'o', 'n' };
static mxArray * _mxarray43_;

static mxChar _array46_[6] = { 'X', 'L', 'a', 'b', 'e', 'l' };
static mxArray * _mxarray45_;

static mxChar _array48_[6] = { 'Y', 'L', 'a', 'b', 'e', 'l' };
static mxArray * _mxarray47_;

static mxChar _array50_[8] = { 'C', 'o', 'l', 'o', 'r', 'm', 'a', 'p' };
static mxArray * _mxarray49_;

static mxChar _array52_[4] = { 'C', 'L', 'i', 'm' };
static mxArray * _mxarray51_;

static mxChar _array54_[14] = { 'I', 'm', 's', 'h', 'o', 'w', 'T',
                                'r', 'u', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray53_;

static mxChar _array56_[10] = { 'n', 'o', 't', 'r', 'u',
                                'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray55_;

static mxChar _array58_[8] = { 't', 'r', 'u', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray57_;

static mxChar _array60_[12] = { 'I', 'm', 's', 'h', 'o', 'w',
                                'B', 'o', 'r', 'd', 'e', 'r' };
static mxArray * _mxarray59_;

static mxChar _array62_[5] = { 'U', 'n', 'i', 't', 's' };
static mxArray * _mxarray61_;

static mxChar _array64_[10] = { 'n', 'o', 'r', 'm', 'a',
                                'l', 'i', 'z', 'e', 'd' };
static mxArray * _mxarray63_;

static mxChar _array66_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray65_;

static double _array68_[4] = { 0.0, 0.0, 1.0, 1.0 };
static mxArray * _mxarray67_;

static mxChar _array70_[15] = { 'r', 'e', 'p', 'l', 'a', 'c', 'e', 'c',
                                'h', 'i', 'l', 'd', 'r', 'e', 'n' };
static mxArray * _mxarray69_;

static mxChar _array72_[5] = { 't', 'i', 'g', 'h', 't' };
static mxArray * _mxarray71_;

static mxChar _array74_[6] = { 'S', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray73_;

static mxChar _array76_[11] = { 'I', 'n', 't', 'e', 'r', 'p',
                                'r', 'e', 't', 'e', 'r' };
static mxArray * _mxarray75_;

static mxChar _array78_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray77_;
static mxArray * _mxarray79_;

static mxChar _array81_[11] = { 'S', 'c', 'r', 'e', 'e', 'n',
                                'D', 'e', 'p', 't', 'h' };
static mxArray * _mxarray80_;
static mxArray * _mxarray82_;
static mxArray * _mxarray83_;
static mxArray * _mxarray84_;

static mxArray * _array86_[2] = { NULL /*_mxarray57_*/, NULL /*_mxarray55_*/ };
static mxArray * _mxarray85_;

static mxChar _array88_[26] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'o',
                                'p', 't', 'i', 'o', 'n', ' ', 's', 't', 'r',
                                'i', 'n', 'g', ' ', '"', '%', 's', '"' };
static mxArray * _mxarray87_;

static mxChar _array90_[28] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o',
                                'u', 's', ' ', 'o', 'p', 't', 'i',
                                'o', 'n', ' ', 's', 't', 'r', 'i',
                                'n', 'g', ' ', '"', '%', 's', '"' };
static mxArray * _mxarray89_;

static mxChar _array92_[44] = { 'N', 'o', 't', ' ', 'e', 'n', 'o', 'u', 'g',
                                'h', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a',
                                'r', 'g', 'u', 'm', 'e', 'n', 't', 's', '.',
                                ' ', ' ', 'S', 'e', 'e', ' ', 'H', 'E', 'L',
                                'P', ' ', 'I', 'M', 'S', 'H', 'O', 'W' };
static mxArray * _mxarray91_;
static mxArray * _mxarray93_;

static mxChar _array95_[3] = { 'r', 'g', 'b' };
static mxArray * _mxarray94_;
static mxArray * _mxarray96_;

static mxChar _array98_[9] = { 'i', 'n', 't', 'e', 'n', 's', 'i', 't', 'y' };
static mxArray * _mxarray97_;

static mxChar _array100_[6] = { 's', 'c', 'a', 'l', 'e', 'd' };
static mxArray * _mxarray99_;

static mxChar _array102_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray101_;

static double _array104_[2] = { 0.0, 1.0 };
static mxArray * _mxarray103_;

static mxChar _array106_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray105_;

static double _array108_[2] = { 0.0, 255.0 };
static mxArray * _mxarray107_;

static mxChar _array110_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray109_;

static mxChar _array112_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray111_;

static double _array114_[2] = { 0.0, 65535.0 };
static mxArray * _mxarray113_;

static mxChar _array116_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray115_;

static mxChar _array118_[6] = { 'd', 'i', 'r', 'e', 'c', 't' };
static mxArray * _mxarray117_;

static mxChar _array120_[23] = { 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r',
                                 't', 'e', 'd', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'c', 'l', 'a', 's', 's' };
static mxArray * _mxarray119_;

static double _array122_[2] = { 1.0, 2.0 };
static mxArray * _mxarray121_;

static mxChar _array124_[40] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                 'g', 'u', 'm', 'e', 'n', 't', 's', ';',
                                 ' ', 's', 'e', 'e', ' ', 'H', 'E', 'L',
                                 'P', ' ', 'I', 'M', 'S', 'H', 'O', 'W' };
static mxArray * _mxarray123_;

static mxChar _array126_[90] = { 'I', 'M', 'S', 'H', 'O', 'W', '(', 'R', ',',
                                 'G', ',', 'B', ')', ' ', 'i', 's', ' ', 'a',
                                 'n', ' ', 'o', 'b', 's', 'o', 'l', 'e', 't',
                                 'e', ' ', 's', 'y', 'n', 't', 'a', 'x', '.',
                                 ' ', 'U', 's', 'e', ' ', 'a', ' ', 't', 'h',
                                 'r', 'e', 'e', '-', 'd', 'i', 'm', 'e', 'n',
                                 's', 'i', 'o', 'n', 'a', 'l', ' ', 'a', 'r',
                                 'r', 'a', 'y', ' ', 't', 'o', ' ', 'r', 'e',
                                 'p', 'r', 'e', 's', 'e', 'n', 't', ' ', 'R',
                                 'G', 'B', ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray125_;
static mxArray * _mxarray127_;

static mxChar _array129_[41] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ', 'i',
                                 'n', 'p', 'u', 't', ' ', 'a', 'r', 'g', 'u',
                                 'm', 'e', 'n', 't', 's', '.', ' ', ' ', 'S',
                                 'e', 'e', ' ', 'H', 'E', 'L', 'P', ' ', 'I',
                                 'M', 'S', 'H', 'O', 'W' };
static mxArray * _mxarray128_;
static mxArray * _mxarray130_;

static mxChar _array132_[94] = { 'I', 'M', 'S', 'H', 'O', 'W', '(', 'x', ',',
                                 'y', ',', 'R', ',', 'G', ',', 'B', ')', ' ',
                                 'i', 's', ' ', 'a', 'n', ' ', 'o', 'b', 's',
                                 'o', 'l', 'e', 't', 'e', ' ', 's', 'y', 'n',
                                 't', 'a', 'x', '.', ' ', 'U', 's', 'e', ' ',
                                 'a', ' ', 't', 'h', 'r', 'e', 'e', '-', 'd',
                                 'i', 'm', 'e', 'n', 's', 'i', 'o', 'n', 'a',
                                 'l', ' ', 'a', 'r', 'r', 'a', 'y', ' ', 't',
                                 'o', ' ', 'r', 'e', 'p', 'r', 'e', 's', 'e',
                                 'n', 't', ' ', 'R', 'G', 'B', ' ', 'i', 'm',
                                 'a', 'g', 'e', '.' };
static mxArray * _mxarray131_;

static mxChar _array134_[42] = { 'T', 'o', 'o', ' ', 'm', 'a', 'n', 'y', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'a', 'r', 'g',
                                 'u', 'm', 'e', 'n', 't', 's', '.', ' ', ' ',
                                 'S', 'e', 'e', ' ', 'H', 'E', 'L', 'P', ' ',
                                 'I', 'M', 'S', 'H', 'O', 'W' };
static mxArray * _mxarray133_;

static mxChar _array136_[21] = { 'U', 'n', 's', 'u', 'p', 'p', 'o',
                                 'r', 't', 'e', 'd', ' ', 'd', 'i',
                                 'm', 'e', 'n', 's', 'i', 'o', 'n' };
static mxArray * _mxarray135_;

static mxChar _array138_[37] = { 'D', 'i', 's', 'p', 'l', 'a', 'y', 'i',
                                 'n', 'g', ' ', 'r', 'e', 'a', 'l', ' ',
                                 'p', 'a', 'r', 't', ' ', 'o', 'f', ' ',
                                 'c', 'o', 'm', 'p', 'l', 'e', 'x', ' ',
                                 'i', 'n', 'p', 'u', 't' };
static mxArray * _mxarray137_;

static double _array140_[2] = { -1.0, 1.0 };
static mxArray * _mxarray139_;

static mxChar _array142_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray141_;

static mxChar _array144_[5] = { 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray143_;

static mxChar _array146_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray145_;

static mxChar _array148_[9] = { 'u', 'i', 'c', 'o', 'n', 't', 'r', 'o', 'l' };
static mxArray * _mxarray147_;

static mxChar _array150_[19] = { 'D', 'e', 'f', 'a', 'u', 'l', 't',
                                 'A', 'x', 'e', 's', 'P', 'o', 's',
                                 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray149_;

void InitializeModule_imshow(void) {
    _mxarray0_ = mclInitializeDouble(0.0);
    _mxarray1_ = mclInitializeString(13, _array2_);
    _mxarray3_ = mclInitializeString(8, _array4_);
    _mxarray5_ = mclInitializeString(3, _array6_);
    _mxarray7_ = mclInitializeDouble(1.0);
    _mxarray8_ = mclInitializeDouble(2.0);
    _mxarray9_ = mclInitializeString(7, _array10_);
    _mxarray11_ = mclInitializeString(3, _array12_);
    _mxarray13_ = mclInitializeString(6, _array14_);
    _mxarray15_ = mclInitializeString(10, _array16_);
    _mxarray17_ = mclInitializeString(6, _array18_);
    _mxarray19_ = mclInitializeString(12, _array20_);
    _mxarray21_ = mclInitializeString(13, _array22_);
    _mxarray23_ = mclInitializeString(17, _array24_);
    _mxarray25_ = mclInitializeString(7, _array26_);
    _mxarray27_ = mclInitializeString(3, _array28_);
    _mxarray29_ = mclInitializeString(5, _array30_);
    _mxarray31_ = mclInitializeString(5, _array32_);
    _mxarray33_ = mclInitializeString(15, _array34_);
    _mxarray35_ = mclInitializeDoubleVector(1, 3, _array36_);
    _mxarray37_ = mclInitializeString(22, _array38_);
    _mxarray39_ = mclInitializeString(4, _array40_);
    _mxarray41_ = mclInitializeString(5, _array42_);
    _mxarray43_ = mclInitializeString(2, _array44_);
    _mxarray45_ = mclInitializeString(6, _array46_);
    _mxarray47_ = mclInitializeString(6, _array48_);
    _mxarray49_ = mclInitializeString(8, _array50_);
    _mxarray51_ = mclInitializeString(4, _array52_);
    _mxarray53_ = mclInitializeString(14, _array54_);
    _mxarray55_ = mclInitializeString(10, _array56_);
    _mxarray57_ = mclInitializeString(8, _array58_);
    _mxarray59_ = mclInitializeString(12, _array60_);
    _mxarray61_ = mclInitializeString(5, _array62_);
    _mxarray63_ = mclInitializeString(10, _array64_);
    _mxarray65_ = mclInitializeString(8, _array66_);
    _mxarray67_ = mclInitializeDoubleVector(1, 4, _array68_);
    _mxarray69_ = mclInitializeString(15, _array70_);
    _mxarray71_ = mclInitializeString(5, _array72_);
    _mxarray73_ = mclInitializeString(6, _array74_);
    _mxarray75_ = mclInitializeString(11, _array76_);
    _mxarray77_ = mclInitializeString(4, _array78_);
    _mxarray79_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray80_ = mclInitializeString(11, _array81_);
    _mxarray82_ = mclInitializeDouble(16.0);
    _mxarray83_ = mclInitializeDouble(256.0);
    _mxarray84_ = mclInitializeDouble(64.0);
    _array86_[0] = _mxarray57_;
    _array86_[1] = _mxarray55_;
    _mxarray85_ = mclInitializeCellVector(1, 2, _array86_);
    _mxarray87_ = mclInitializeString(26, _array88_);
    _mxarray89_ = mclInitializeString(28, _array90_);
    _mxarray91_ = mclInitializeString(44, _array92_);
    _mxarray93_ = mclInitializeDouble(3.0);
    _mxarray94_ = mclInitializeString(3, _array95_);
    _mxarray96_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray97_ = mclInitializeString(9, _array98_);
    _mxarray99_ = mclInitializeString(6, _array100_);
    _mxarray101_ = mclInitializeString(6, _array102_);
    _mxarray103_ = mclInitializeDoubleVector(1, 2, _array104_);
    _mxarray105_ = mclInitializeString(5, _array106_);
    _mxarray107_ = mclInitializeDoubleVector(1, 2, _array108_);
    _mxarray109_ = mclInitializeString(7, _array110_);
    _mxarray111_ = mclInitializeString(6, _array112_);
    _mxarray113_ = mclInitializeDoubleVector(1, 2, _array114_);
    _mxarray115_ = mclInitializeString(7, _array116_);
    _mxarray117_ = mclInitializeString(6, _array118_);
    _mxarray119_ = mclInitializeString(23, _array120_);
    _mxarray121_ = mclInitializeDoubleVector(1, 2, _array122_);
    _mxarray123_ = mclInitializeString(40, _array124_);
    _mxarray125_ = mclInitializeString(90, _array126_);
    _mxarray127_ = mclInitializeDouble(4.0);
    _mxarray128_ = mclInitializeString(41, _array129_);
    _mxarray130_ = mclInitializeDouble(5.0);
    _mxarray131_ = mclInitializeString(94, _array132_);
    _mxarray133_ = mclInitializeString(42, _array134_);
    _mxarray135_ = mclInitializeString(21, _array136_);
    _mxarray137_ = mclInitializeString(37, _array138_);
    _mxarray139_ = mclInitializeDoubleVector(1, 2, _array140_);
    _mxarray141_ = mclInitializeString(4, _array142_);
    _mxarray143_ = mclInitializeString(5, _array144_);
    _mxarray145_ = mclInitializeString(4, _array146_);
    _mxarray147_ = mclInitializeString(9, _array148_);
    _mxarray149_ = mclInitializeString(19, _array150_);
}

void TerminateModule_imshow(void) {
    mxDestroyArray(_mxarray149_);
    mxDestroyArray(_mxarray147_);
    mxDestroyArray(_mxarray145_);
    mxDestroyArray(_mxarray143_);
    mxDestroyArray(_mxarray141_);
    mxDestroyArray(_mxarray139_);
    mxDestroyArray(_mxarray137_);
    mxDestroyArray(_mxarray135_);
    mxDestroyArray(_mxarray133_);
    mxDestroyArray(_mxarray131_);
    mxDestroyArray(_mxarray130_);
    mxDestroyArray(_mxarray128_);
    mxDestroyArray(_mxarray127_);
    mxDestroyArray(_mxarray125_);
    mxDestroyArray(_mxarray123_);
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray119_);
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray115_);
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImshow_ParseInputs(mxArray * * cdata,
                                       mxArray * * cdatamapping,
                                       mxArray * * clim,
                                       mxArray * * map,
                                       mxArray * * xdata,
                                       mxArray * * ydata,
                                       mxArray * * filename,
                                       mxArray * * truesizeStr,
                                       ...);
static void mlxImshow_ParseInputs(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]);
static mxArray * mlfImshow_IsVector(mxArray * x);
static void mlxImshow_IsVector(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]);
static mxArray * mlfImshow_SingleImageDefaultPos(mxArray * figHandle,
                                                 mxArray * axHandle);
static void mlxImshow_SingleImageDefaultPos(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static mxArray * Mimshow(int nargout_, mxArray * varargin);
static mxArray * Mimshow_ParseInputs(mxArray * * cdata,
                                     mxArray * * cdatamapping,
                                     mxArray * * clim,
                                     mxArray * * map,
                                     mxArray * * xdata,
                                     mxArray * * ydata,
                                     mxArray * * filename,
                                     mxArray * * truesizeStr,
                                     int nargout_,
                                     mxArray * varargin);
static mxArray * Mimshow_IsVector(int nargout_, mxArray * x);
static mxArray * Mimshow_SingleImageDefaultPos(int nargout_,
                                               mxArray * figHandle,
                                               mxArray * axHandle);

static mexFunctionTableEntry local_function_table_[3]
  = { { "ParseInputs", mlxImshow_ParseInputs, -1, 9, NULL },
      { "IsVector", mlxImshow_IsVector, 1, 1, NULL },
      { "SingleImageDefaultPos",
        mlxImshow_SingleImageDefaultPos, 2, 1, NULL } };

_mexLocalFunctionTable _local_function_table_imshow
  = { 3, local_function_table_ };

/*
 * The function "mlfNImshow" contains the nargout interface for the "imshow"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imshow.m" (lines
 * 1-191). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNImshow(int nargout, ...) {
    mxArray * varargin = NULL;
    mxArray * h = NULL;
    mlfVarargin(&varargin, nargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    h = Mimshow(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(h);
}

/*
 * The function "mlfImshow" contains the normal interface for the "imshow"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imshow.m" (lines
 * 1-191). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImshow(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * h = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    h = Mimshow(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(h);
}

/*
 * The function "mlfVImshow" contains the void interface for the "imshow"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imshow.m" (lines
 * 1-191). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImshow(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * h = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    h = Mimshow(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImshow" contains the feval interface for the "imshow"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imshow.m" (lines
 * 1-191). The feval function calls the implementation version of imshow
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImshow(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow Line: 1 Column: "
            "1 The function \"imshow\" was called with mor"
            "e than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimshow(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImshow_ParseInputs" contains the normal interface for the
 * "imshow/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 191-518). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImshow_ParseInputs(mxArray * * cdata,
                                       mxArray * * cdatamapping,
                                       mxArray * * clim,
                                       mxArray * * map,
                                       mxArray * * xdata,
                                       mxArray * * ydata,
                                       mxArray * * filename,
                                       mxArray * * truesizeStr,
                                       ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * imtype = NULL;
    mxArray * cdata__ = NULL;
    mxArray * cdatamapping__ = NULL;
    mxArray * clim__ = NULL;
    mxArray * map__ = NULL;
    mxArray * xdata__ = NULL;
    mxArray * ydata__ = NULL;
    mxArray * filename__ = NULL;
    mxArray * truesizeStr__ = NULL;
    mlfVarargin(&varargin, truesizeStr, 0);
    mlfEnterNewContext(
      8,
      -1,
      cdata,
      cdatamapping,
      clim,
      map,
      xdata,
      ydata,
      filename,
      truesizeStr,
      varargin);
    if (cdata != NULL) {
        ++nargout;
    }
    if (cdatamapping != NULL) {
        ++nargout;
    }
    if (clim != NULL) {
        ++nargout;
    }
    if (map != NULL) {
        ++nargout;
    }
    if (xdata != NULL) {
        ++nargout;
    }
    if (ydata != NULL) {
        ++nargout;
    }
    if (filename != NULL) {
        ++nargout;
    }
    if (truesizeStr != NULL) {
        ++nargout;
    }
    imtype
      = Mimshow_ParseInputs(
          &cdata__,
          &cdatamapping__,
          &clim__,
          &map__,
          &xdata__,
          &ydata__,
          &filename__,
          &truesizeStr__,
          nargout,
          varargin);
    mlfRestorePreviousContext(
      8,
      0,
      cdata,
      cdatamapping,
      clim,
      map,
      xdata,
      ydata,
      filename,
      truesizeStr);
    mxDestroyArray(varargin);
    if (cdata != NULL) {
        mclCopyOutputArg(cdata, cdata__);
    } else {
        mxDestroyArray(cdata__);
    }
    if (cdatamapping != NULL) {
        mclCopyOutputArg(cdatamapping, cdatamapping__);
    } else {
        mxDestroyArray(cdatamapping__);
    }
    if (clim != NULL) {
        mclCopyOutputArg(clim, clim__);
    } else {
        mxDestroyArray(clim__);
    }
    if (map != NULL) {
        mclCopyOutputArg(map, map__);
    } else {
        mxDestroyArray(map__);
    }
    if (xdata != NULL) {
        mclCopyOutputArg(xdata, xdata__);
    } else {
        mxDestroyArray(xdata__);
    }
    if (ydata != NULL) {
        mclCopyOutputArg(ydata, ydata__);
    } else {
        mxDestroyArray(ydata__);
    }
    if (filename != NULL) {
        mclCopyOutputArg(filename, filename__);
    } else {
        mxDestroyArray(filename__);
    }
    if (truesizeStr != NULL) {
        mclCopyOutputArg(truesizeStr, truesizeStr__);
    } else {
        mxDestroyArray(truesizeStr__);
    }
    return mlfReturnValue(imtype);
}

/*
 * The function "mlxImshow_ParseInputs" contains the feval interface for the
 * "imshow/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 191-518). The feval
 * function calls the implementation version of imshow/ParseInputs through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImshow_ParseInputs(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[9];
    int i;
    if (nlhs > 9) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow/ParseInputs Line: 191 Col"
            "umn: 1 The function \"imshow/ParseInputs\" was called "
            "with more than the declared number of outputs (9)."),
          NULL);
    }
    for (i = 0; i < 9; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mimshow_ParseInputs(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          &mplhs[5],
          &mplhs[6],
          &mplhs[7],
          &mplhs[8],
          nlhs,
          mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 9 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 9; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImshow_IsVector" contains the normal interface for the
 * "imshow/IsVector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 518-526). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImshow_IsVector(mxArray * x) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, x);
    tf = Mimshow_IsVector(nargout, x);
    mlfRestorePreviousContext(0, 1, x);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImshow_IsVector" contains the feval interface for the
 * "imshow/IsVector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 518-526). The feval
 * function calls the implementation version of imshow/IsVector through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImshow_IsVector(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow/IsVector Line: 518 Colu"
            "mn: 1 The function \"imshow/IsVector\" was called wi"
            "th more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow/IsVector Line: 518 Col"
            "umn: 1 The function \"imshow/IsVector\" was called "
            "with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimshow_IsVector(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfImshow_SingleImageDefaultPos" contains the normal interface
 * for the "imshow/SingleImageDefaultPos" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 526-553). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImshow_SingleImageDefaultPos(mxArray * figHandle,
                                                 mxArray * axHandle) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 2, figHandle, axHandle);
    tf = Mimshow_SingleImageDefaultPos(nargout, figHandle, axHandle);
    mlfRestorePreviousContext(0, 2, figHandle, axHandle);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxImshow_SingleImageDefaultPos" contains the feval interface
 * for the "imshow/SingleImageDefaultPos" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 526-553). The feval
 * function calls the implementation version of imshow/SingleImageDefaultPos
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImshow_SingleImageDefaultPos(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow/SingleImageDefaultPos Line: 526"
            " Column: 1 The function \"imshow/SingleImageDefaultPos\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imshow/SingleImageDefaultPos Line: 526"
            " Column: 1 The function \"imshow/SingleImageDefaultPos\" was"
            " called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mimshow_SingleImageDefaultPos(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimshow" is the implementation version of the "imshow"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imshow.m" (lines
 * 1-191). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function h=imshow(varargin)
 */
static mxArray * Mimshow(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imshow);
    mxArray * h = NULL;
    mxArray * borderPref = NULL;
    mxArray * callTruesize = NULL;
    mxArray * singleImage = NULL;
    mxArray * autoTruesize = NULL;
    mxArray * truesizePref = NULL;
    mxArray * ans = NULL;
    mxArray * showAxes = NULL;
    mxArray * hh = NULL;
    mxArray * axHandle = NULL;
    mxArray * figHandle = NULL;
    mxArray * imsize = NULL;
    mxArray * truesizeStr = NULL;
    mxArray * filename = NULL;
    mxArray * ydata = NULL;
    mxArray * xdata = NULL;
    mxArray * map = NULL;
    mxArray * clim = NULL;
    mxArray * cdatamapping = NULL;
    mxArray * cdata = NULL;
    mxArray * imtype = NULL;
    mxArray * newFigure = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMSHOW Display image.
     * %   IMSHOW(I,N) displays the intensity image I with N discrete
     * %   levels of gray. If you omit N, IMSHOW uses 256 gray levels on
     * %   24-bit displays, or 64 gray levels on other systems.
     * %
     * %   IMSHOW(I,[LOW HIGH]) displays I as a grayscale intensity
     * %   image, specifying the data range for I. The value LOW (and
     * %   any value less than LOW) displays as black, the HIGH (and any
     * %   value greater than HIGH) displays as white, and values in
     * %   between display as intermediate shades of gray. IMSHOW uses
     * %   the default number of gray levels. If you use an empty matrix
     * %   ([]) for [LOW HIGH], IMSHOW uses [min(I(:)) max(I(:))]; the
     * %   minimum value in I displays as black, and the maximum value
     * %   displays as white.
     * %
     * %   IMSHOW(BW) displays the binary image BW. Values of 0 display
     * %   as black, and values of 1 display as white.
     * %
     * %   IMSHOW(X,MAP) displays the indexed image X with the colormap
     * %   MAP.
     * %
     * %   IMSHOW(RGB) displays the truecolor image RGB.
     * %
     * %   IMSHOW(...,DISPLAY_OPTION) displays the image, calling
     * %   TRUESIZE if DISPLAY_OPTION is 'truesize', or suppressing the
     * %   call to TRUESIZE if DISPLAY_OPTION is 'notruesize'. Either
     * %   option string can be abbreviated. If you do not supply this
     * %   argument, IMSHOW determines whether to call TRUESIZE based on
     * %   the setting of the 'ImshowTruesize' preference.
     * %
     * %   IMSHOW(x,y,A,...) uses the 2-element vectors x and y to
     * %   establish a nondefault spatial coordinate system, by
     * %   specifying the image XData and YData.  Note that x and y can 
     * %   have more than 2 elements, but only the first and last 
     * %   elements are actually used.
     * %
     * %   IMSHOW(FILENAME) displays the image stored in the graphics
     * %   file FILENAME. IMSHOW calls IMREAD to read the image from the
     * %   file, but the image data is not stored in the MATLAB
     * %   workspace. The file must be in the current directory or on
     * %   the MATLAB path.
     * %
     * %   H = IMSHOW(...) returns the handle to the image object
     * %   created by IMSHOW.
     * %
     * %   Class Support
     * %   -------------
     * %   The input image can be of class logical, uint8, uint16,
     * %   or double, and it must be nonsparse.
     * % 
     * %   Remarks
     * %   -------
     * %   You can use the IPTSETPREF function to set several toolbox
     * %   preferences that modify the behavior of IMSHOW:
     * %
     * %   - 'ImshowBorder' controls whether IMSHOW displays the image
     * %     with a border around it.
     * %
     * %   - 'ImshowAxesVisible' controls whether IMSHOW displays the
     * %     image with the axes box and tick labels.
     * %
     * %   - 'ImshowTruesize' controls whether IMSHOW calls the TRUESIZE
     * %     function.
     * %
     * %   For more information about these preferences, see the
     * %   reference entry for IPTSETPREF.
     * %
     * %   See also IMREAD, IPTGETPREF, IPTSETPREF, SUBIMAGE, TRUESIZE, WARP, IMAGE, IMAGESC.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.37 $  $Date: 2002/03/15 15:28:18 $
     * 
     * % 1. Parse input arguments
     * % 2. Get an axes to plot in.
     * % 3. Create the image and axes objects and set their display
     * %    properties.
     * % 4. If the image is alone in the figure, position the axes
     * %    according to the current IMBORDER setting and then call
     * %    TRUESIZE.
     * %
     * % Local function:
     * % ParseInputs
     * % IsVector
     * % DoTruesize
     * 
     * newFigure = isempty(get(0,'CurrentFigure')) | ...
     */
    mlfAssign(
      &newFigure,
      mclOr(
        mlfIsempty(mlfNGet(1, _mxarray0_, _mxarray1_, NULL)),
        mlfStrcmp(
          mlfNGet(
            1, mlfNGet(1, _mxarray0_, _mxarray1_, NULL), _mxarray3_, NULL),
          _mxarray5_)));
    /*
     * strcmp(get(get(0,'CurrentFigure'), 'NextPlot'), 'new');
     * 
     * [imtype, cdata, cdatamapping, clim, map, xdata, ydata, filename, ...
     * truesizeStr] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &imtype,
      mlfImshow_ParseInputs(
        &cdata,
        &cdatamapping,
        &clim,
        &map,
        &xdata,
        &ydata,
        &filename,
        &truesizeStr,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * imsize = size(cdata);
     */
    mlfAssign(
      &imsize, mlfSize(mclValueVarargout(), mclVv(cdata, "cdata"), NULL));
    /*
     * imsize = imsize(1:2);  % In case ndims(cdata) > 2
     */
    mlfAssign(
      &imsize,
      mclArrayRef1(
        mclVv(imsize, "imsize"), mlfColon(_mxarray7_, _mxarray8_, NULL)));
    /*
     * 
     * if (newFigure)
     */
    if (mlfTobool(mclVv(newFigure, "newFigure"))) {
        /*
         * figHandle = figure('Visible', 'off');
         */
        mlfAssign(&figHandle, mlfNFigure(1, _mxarray9_, _mxarray11_, NULL));
        /*
         * axHandle = axes('Parent', figHandle);
         */
        mlfAssign(
          &axHandle,
          mlfNAxes(1, _mxarray13_, mclVv(figHandle, "figHandle"), NULL));
    /*
     * else
     */
    } else {
        /*
         * axHandle = newplot;
         */
        mlfAssign(&axHandle, mlfNNewplot(1, NULL));
        /*
         * figHandle = get(axHandle, 'Parent');
         */
        mlfAssign(
          &figHandle,
          mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray13_, NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Make the image object.
     * hh = image(xdata, ydata, cdata, 'BusyAction', 'cancel', ...
     */
    mlfAssign(
      &hh,
      mlfNImage(
        1,
        mclVv(xdata, "xdata"),
        mclVv(ydata, "ydata"),
        mclVv(cdata, "cdata"),
        _mxarray15_,
        _mxarray17_,
        _mxarray13_,
        mclVv(axHandle, "axHandle"),
        _mxarray19_,
        mclVv(cdatamapping, "cdatamapping"),
        _mxarray21_,
        _mxarray11_,
        NULL));
    /*
     * 'Parent', axHandle, 'CDataMapping', cdatamapping, ...
     * 'Interruptible', 'off');
     * 
     * % Set axes and figure properties if necessary to display the 
     * % image object correctly.
     * showAxes = iptgetpref('ImshowAxesVisible');
     */
    mlfAssign(&showAxes, mlfIptgetpref(_mxarray23_));
    /*
     * set(axHandle, ...
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(axHandle, "axHandle"),
        _mxarray25_,
        _mxarray27_,
        _mxarray29_,
        _mxarray11_,
        _mxarray31_,
        _mxarray11_,
        _mxarray33_,
        _mxarray35_,
        _mxarray37_,
        _mxarray39_,
        _mxarray9_,
        mclVv(showAxes, "showAxes"),
        NULL));
    /*
     * 'TickDir', 'out', ...
     * 'XGrid', 'off', ...
     * 'YGrid', 'off', ...
     * 'DataAspectRatio', [1 1 1], ...
     * 'PlotBoxAspectRatioMode', 'auto', ...
     * 'Visible', showAxes);
     * set(get(axHandle,'Title'),'Visible','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray41_, NULL),
        _mxarray9_,
        _mxarray43_,
        NULL));
    /*
     * set(get(axHandle,'XLabel'),'Visible','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray45_, NULL),
        _mxarray9_,
        _mxarray43_,
        NULL));
    /*
     * set(get(axHandle,'YLabel'),'Visible','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray47_, NULL),
        _mxarray9_,
        _mxarray43_,
        NULL));
    /*
     * if (~isempty(map))
     */
    if (mclNotBool(mlfIsempty(mclVv(map, "map")))) {
        /*
         * set(figHandle, 'Colormap', map);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(figHandle, "figHandle"),
            _mxarray49_,
            mclVv(map, "map"),
            NULL));
    /*
     * end
     */
    }
    /*
     * if (~isempty(clim))
     */
    if (mclNotBool(mlfIsempty(mclVv(clim, "clim")))) {
        /*
         * set(axHandle, 'CLim', clim);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(axHandle, "axHandle"),
            _mxarray51_,
            mclVv(clim, "clim"),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Do truesize if called for.
     * truesizePref = iptgetpref('ImshowTruesize');
     */
    mlfAssign(&truesizePref, mlfIptgetpref(_mxarray53_));
    /*
     * autoTruesize = strcmp(truesizePref, 'auto');
     */
    mlfAssign(
      &autoTruesize,
      mlfStrcmp(mclVv(truesizePref, "truesizePref"), _mxarray39_));
    /*
     * singleImage = SingleImageDefaultPos(figHandle, axHandle);
     */
    mlfAssign(
      &singleImage,
      mlfImshow_SingleImageDefaultPos(
        mclVv(figHandle, "figHandle"), mclVv(axHandle, "axHandle")));
    /*
     * 
     * 
     * % Syntax specification overrides truesize preference setting.
     * if (strcmp(truesizeStr, 'notruesize'))
     */
    if (mlfTobool(mlfStrcmp(mclVv(truesizeStr, "truesizeStr"), _mxarray55_))) {
        /*
         * callTruesize = 0;
         */
        mlfAssign(&callTruesize, _mxarray0_);
    /*
     * 
     * elseif (strcmp(truesizeStr, 'truesize'))
     */
    } else if (mlfTobool(
                 mlfStrcmp(mclVv(truesizeStr, "truesizeStr"), _mxarray57_))) {
        /*
         * callTruesize = 1;
         */
        mlfAssign(&callTruesize, _mxarray7_);
    /*
     * 
     * else
     */
    } else {
        /*
         * % If there was no command-line override, and the truesize preference
         * % is 'on', we still might not want to call truesize if the image
         * % isn't the only thing in the figure, or if it isn't in the 
         * % default position.
         * 
         * if (autoTruesize)
         */
        if (mlfTobool(mclVv(autoTruesize, "autoTruesize"))) {
            /*
             * callTruesize = singleImage;
             */
            mlfAssign(&callTruesize, mclVv(singleImage, "singleImage"));
        /*
         * else
         */
        } else {
            /*
             * callTruesize = 0;
             */
            mlfAssign(&callTruesize, _mxarray0_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Adjust according to ImshowBorder setting, unless we don't have a single
     * % image in the default position.
     * borderPref = iptgetpref('ImshowBorder');
     */
    mlfAssign(&borderPref, mlfIptgetpref(_mxarray59_));
    /*
     * if (strcmp(borderPref, 'tight') & singleImage)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfStrcmp(mclVv(borderPref, "borderPref"), _mxarray71_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclVv(singleImage, "singleImage")))) {
            mxDestroyArray(a_);
            /*
             * % Have the image fill the figure.
             * set(axHandle, 'Units', 'normalized', 'Position', [0 0 1 1]);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(axHandle, "axHandle"),
                _mxarray61_,
                _mxarray63_,
                _mxarray65_,
                _mxarray67_,
                NULL));
            /*
             * 
             * % The next line is so that a subsequent plot(1:10) goes back
             * % to the default axes position instead of taking up the
             * % entire figure.
             * set(figHandle, 'NextPlot', 'replacechildren');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(figHandle, "figHandle"),
                _mxarray3_,
                _mxarray69_,
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (callTruesize)
     */
    if (mlfTobool(mclVv(callTruesize, "callTruesize"))) {
        /*
         * truesize(figHandle);
         */
        mlfTruesize(mclVv(figHandle, "figHandle"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if (~isempty(filename) & isempty(get(get(axHandle,'Title'),'String')))
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfIsempty(mclVv(filename, "filename"))));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfIsempty(
                     mlfNGet(
                       1,
                       mlfNGet(
                         1, mclVv(axHandle, "axHandle"), _mxarray41_, NULL),
                       _mxarray73_,
                       NULL))))) {
            mxDestroyArray(a_);
            /*
             * set(get(axHandle, 'Title'), 'String', filename, ...
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray41_, NULL),
                _mxarray73_,
                mclVv(filename, "filename"),
                _mxarray75_,
                _mxarray77_,
                _mxarray9_,
                _mxarray43_,
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * 'Interpreter', 'none', ...
     * 'Visible', 'on');
     * end
     */
    }
    /*
     * 
     * if (nargout > 0)
     */
    if (nargout_ > 0) {
        /*
         * % Only return handle if caller requested it.
         * h = hh;
         */
        mlfAssign(&h, mclVv(hh, "hh"));
    /*
     * end
     */
    }
    /*
     * 
     * if (newFigure)
     */
    if (mlfTobool(mclVv(newFigure, "newFigure"))) {
        /*
         * set(figHandle, 'Visible', 'on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVv(figHandle, "figHandle"), _mxarray9_, _mxarray43_, NULL));
    /*
     * end
     */
    }
    mclValidateOutput(h, 1, nargout_, "h", "imshow");
    mxDestroyArray(newFigure);
    mxDestroyArray(imtype);
    mxDestroyArray(cdata);
    mxDestroyArray(cdatamapping);
    mxDestroyArray(clim);
    mxDestroyArray(map);
    mxDestroyArray(xdata);
    mxDestroyArray(ydata);
    mxDestroyArray(filename);
    mxDestroyArray(truesizeStr);
    mxDestroyArray(imsize);
    mxDestroyArray(figHandle);
    mxDestroyArray(axHandle);
    mxDestroyArray(hh);
    mxDestroyArray(showAxes);
    mxDestroyArray(ans);
    mxDestroyArray(truesizePref);
    mxDestroyArray(autoTruesize);
    mxDestroyArray(singleImage);
    mxDestroyArray(callTruesize);
    mxDestroyArray(borderPref);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return h;
    /*
     * 
     * 
     * %----------------------------------------------------------------------
     * % Subfunction ParseInputs
     * %----------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mimshow_ParseInputs" is the implementation version of the
 * "imshow/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 191-518). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [imtype, cdata, cdatamapping, clim, map, xdata, ...
 */
static mxArray * Mimshow_ParseInputs(mxArray * * cdata,
                                     mxArray * * cdatamapping,
                                     mxArray * * clim,
                                     mxArray * * map,
                                     mxArray * * xdata,
                                     mxArray * * ydata,
                                     mxArray * * filename,
                                     mxArray * * truesizeStr,
                                     int nargout_,
                                     mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imshow);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * imtype = NULL;
    mxArray * ans = NULL;
    mxArray * idx = NULL;
    mxArray * strs = NULL;
    mxArray * str = NULL;
    mxArray * defGrayMapLength = NULL;
    mclCopyArray(&varargin);
    /*
     * ydata, filename, truesizeStr] =  ParseInputs(varargin);
     * 
     * filename = '';
     */
    mlfAssign(filename, _mxarray79_);
    /*
     * truesizeStr = '';
     */
    mlfAssign(truesizeStr, _mxarray79_);
    /*
     * 
     * if (get(0,'ScreenDepth') > 16)
     */
    if (mclGtBool(mlfNGet(1, _mxarray0_, _mxarray80_, NULL), _mxarray82_)) {
        /*
         * defGrayMapLength = 256;
         */
        mlfAssign(&defGrayMapLength, _mxarray83_);
    /*
     * else
     */
    } else {
        /*
         * defGrayMapLength = 64;
         */
        mlfAssign(&defGrayMapLength, _mxarray84_);
    /*
     * end
     */
    }
    /*
     * 
     * % If nargin > 1, see if there's a trailing string argument.
     * if ((nargin > 1) & (ischar(varargin{end})))
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ > 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIschar,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"),
                       "{?}",
                       mlfEnd(
                         mclVa(varargin, "varargin"), _mxarray7_, _mxarray7_)),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * str = varargin{end};
             */
            mlfAssign(
              &str,
              mlfIndexRef(
                mclVa(varargin, "varargin"),
                "{?}",
                mlfEnd(mclVa(varargin, "varargin"), _mxarray7_, _mxarray7_)));
            /*
             * varargin(end) = [];  % remove string from input arg list
             */
            mlfIndexDelete(
              &varargin,
              "(?)",
              mlfEnd(mclVa(varargin, "varargin"), _mxarray7_, _mxarray7_));
            /*
             * strs = {'truesize', 'notruesize'};
             */
            mlfAssign(&strs, _mxarray85_);
            /*
             * idx = strmatch(str, strs);
             */
            mlfAssign(
              &idx, mlfStrmatch(mclVv(str, "str"), mclVv(strs, "strs"), NULL));
            /*
             * if (isempty(idx))
             */
            if (mlfTobool(mlfIsempty(mclVv(idx, "idx")))) {
                /*
                 * error(sprintf('Unknown option string "%s"', str));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray87_, mclVv(str, "str"), NULL), NULL);
            /*
             * elseif (length(idx) > 1)
             */
            } else if (mclLengthInt(mclVv(idx, "idx")) > 1) {
                /*
                 * error(sprintf('Ambiguous option string "%s"', str));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray89_, mclVv(str, "str"), NULL), NULL);
            /*
             * else
             */
            } else {
                /*
                 * truesizeStr = strs{idx};
                 */
                mlfAssign(
                  truesizeStr,
                  mlfIndexRef(mclVv(strs, "strs"), "{?}", mclVv(idx, "idx")));
            /*
             * end
             */
            }
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * switch length(varargin)
     */
    {
        mxArray * v_
          = mclInitialize(
              mlfScalar(mclLengthInt(mclVa(varargin, "varargin"))));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 0
             * error('Not enough input arguments.  See HELP IMSHOW');
             */
            mlfError(_mxarray91_, NULL);
        /*
         * 
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray7_)) {
            /*
             * % IMSHOW(I)
             * % IMSHOW(RGB)
             * % IMSHOW(FILENAME)
             * 
             * if (isstr(varargin{1}))
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIsstr,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_),
                    NULL))) {
                /*
                 * % IMSHOW(FILENAME)
                 * filename = varargin{1};
                 */
                mlfAssign(
                  filename,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * [cdata,map] = imread(filename);
                 */
                mlfAssign(
                  cdata,
                  mlfNImread(2, map, NULL, mclVv(*filename, "filename"), NULL));
                /*
                 * xdata = (1:size(cdata,2));
                 */
                mlfAssign(
                  xdata,
                  mlfColon(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = (1:size(cdata,1));
                 */
                mlfAssign(
                  ydata,
                  mlfColon(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
                /*
                 * if (isempty(map))
                 */
                if (mlfTobool(mlfIsempty(mclVv(*map, "map")))) {
                    /*
                     * if (ndims(cdata) == 3)
                     */
                    if (mclEqBool(
                          mlfNdims(mclVv(*cdata, "cdata")), _mxarray93_)) {
                        /*
                         * imtype = 'rgb';
                         */
                        mlfAssign(&imtype, _mxarray94_);
                        /*
                         * map = [];
                         */
                        mlfAssign(map, _mxarray96_);
                    /*
                     * else
                     */
                    } else {
                        /*
                         * imtype = 'intensity';
                         */
                        mlfAssign(&imtype, _mxarray97_);
                        /*
                         * map = gray(defGrayMapLength);
                         */
                        mlfAssign(
                          map,
                          mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                    /*
                     * end
                     */
                    }
                    /*
                     * cdatamapping = 'scaled';
                     */
                    mlfAssign(cdatamapping, _mxarray99_);
                    /*
                     * if (isa(cdata, 'double'))
                     */
                    if (mlfTobool(
                          mlfIsa(mclVv(*cdata, "cdata"), _mxarray101_))) {
                        /*
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * elseif (isa(cdata, 'uint8'))
                     */
                    } else if (mlfTobool(
                                 mlfIsa(
                                   mclVv(*cdata, "cdata"), _mxarray105_))) {
                        /*
                         * clim = [0 255];
                         */
                        mlfAssign(clim, _mxarray107_);
                    /*
                     * elseif (isa(cdata, 'logical'))
                     */
                    } else if (mlfTobool(
                                 mlfIsa(
                                   mclVv(*cdata, "cdata"), _mxarray109_))) {
                        /*
                         * % Binary images are of type logical
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * elseif (isa(cdata, 'uint16'))
                     */
                    } else if (mlfTobool(
                                 mlfIsa(
                                   mclVv(*cdata, "cdata"), _mxarray111_))) {
                        /*
                         * clim = [0 65535];
                         */
                        mlfAssign(clim, _mxarray113_);
                    /*
                     * end
                     */
                    }
                /*
                 * 
                 * else
                 */
                } else {
                    /*
                     * imtype = 'indexed';
                     */
                    mlfAssign(&imtype, _mxarray115_);
                    /*
                     * cdatamapping = 'direct';
                     */
                    mlfAssign(cdatamapping, _mxarray117_);
                    /*
                     * clim = [];  % irrelevant
                     */
                    mlfAssign(clim, _mxarray96_);
                /*
                 * end
                 */
                }
            /*
             * 
             * elseif (ndims(varargin{1}) == 3)
             */
            } else if (mclEqBool(
                         mclFeval(
                           mclValueVarargout(),
                           mlxNdims,
                           mlfIndexRef(
                             mclVa(varargin, "varargin"), "{?}", _mxarray7_),
                           NULL),
                         _mxarray93_)) {
                /*
                 * % IMSHOW(RGB)
                 * imtype = 'rgb';
                 */
                mlfAssign(&imtype, _mxarray94_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'direct'; % irrelevant for RGB
                 */
                mlfAssign(cdatamapping, _mxarray117_);
                /*
                 * clim = [];               % irrelevant for RGB
                 */
                mlfAssign(clim, _mxarray96_);
                /*
                 * map = [];                % irrelevant for RGB
                 */
                mlfAssign(map, _mxarray96_);
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * else
             */
            } else {
                /*
                 * % IMSHOW(I)
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * switch class(cdata)
                 */
                {
                    mxArray * v_0
                      = mclInitialize(
                          mlfClassName(mclVv(*cdata, "cdata"), NULL));
                    if (mclSwitchCompare(v_0, _mxarray105_)) {
                        /*
                         * case 'uint8'
                         * clim = [0 255];
                         */
                        mlfAssign(clim, _mxarray107_);
                    /*
                     * case 'logical'
                     */
                    } else if (mclSwitchCompare(v_0, _mxarray109_)) {
                        /*
                         * % Binary images are of type logical
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * case 'uint16'
                     */
                    } else if (mclSwitchCompare(v_0, _mxarray111_)) {
                        /*
                         * clim = [0 65535];
                         */
                        mlfAssign(clim, _mxarray113_);
                    /*
                     * case 'double'
                     */
                    } else if (mclSwitchCompare(v_0, _mxarray101_)) {
                        /*
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * otherwise
                     */
                    } else {
                        /*
                         * error('Unsupported image class');
                         */
                        mlfError(_mxarray119_, NULL);
                    /*
                     * end
                     */
                    }
                    mxDestroyArray(v_0);
                }
                /*
                 * map = gray(defGrayMapLength);
                 */
                mlfAssign(
                  map, mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * end
             */
            }
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * % IMSHOW(X,map)
             * % IMSHOW(I,N)
             * % IMSHOW(I,[a b])
             * % IMSHOW(I,[])
             * 
             * if (prod(size(varargin{2})) == 1)
             */
            if (mclEqBool(
                  mlfProd(
                    mclFeval(
                      mclValueVarargout(),
                      mlxSize,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                      NULL),
                    NULL),
                  _mxarray7_)) {
                /*
                 * % IMSHOW(I,N)
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * switch class(cdata)
                 */
                {
                    mxArray * v_1
                      = mclInitialize(
                          mlfClassName(mclVv(*cdata, "cdata"), NULL));
                    if (mclSwitchCompare(v_1, _mxarray105_)) {
                        /*
                         * case 'uint8'
                         * clim = [0 255];
                         */
                        mlfAssign(clim, _mxarray107_);
                    /*
                     * case 'logical'
                     */
                    } else if (mclSwitchCompare(v_1, _mxarray109_)) {
                        /*
                         * % Binary images are of type logical
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * case 'uint16'
                     */
                    } else if (mclSwitchCompare(v_1, _mxarray111_)) {
                        /*
                         * clim = [0 65535];
                         */
                        mlfAssign(clim, _mxarray113_);
                    /*
                     * case 'double'
                     */
                    } else if (mclSwitchCompare(v_1, _mxarray101_)) {
                        /*
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * otherwise
                     */
                    } else {
                        /*
                         * error('Unsupported image class');
                         */
                        mlfError(_mxarray119_, NULL);
                    /*
                     * end
                     */
                    }
                    mxDestroyArray(v_1);
                }
                /*
                 * map = gray(varargin{2});
                 */
                mlfAssign(
                  map,
                  mclFeval(
                    mclValueVarargout(),
                    mlxGray,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                    NULL));
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * elseif (isequal(size(varargin{2}), [1 2]))
             */
            } else if (mlfTobool(
                         mlfIsequal(
                           mclFeval(
                             mclValueVarargout(),
                             mlxSize,
                             mlfIndexRef(
                               mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                             NULL),
                           _mxarray121_, NULL))) {
                /*
                 * % IMSHOW(I,[a b])
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * clim = varargin{2};
                 */
                mlfAssign(
                  clim,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
                /*
                 * map = gray(defGrayMapLength);
                 */
                mlfAssign(
                  map, mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * elseif (size(varargin{2},2) == 3)
             */
            } else if (mclEqBool(
                         mclFeval(
                           mclValueVarargout(),
                           mlxSize,
                           mlfIndexRef(
                             mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                           _mxarray8_,
                           NULL),
                         _mxarray93_)) {
                /*
                 * % IMSHOW(X,map)
                 * imtype = 'indexed';
                 */
                mlfAssign(&imtype, _mxarray115_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'direct';
                 */
                mlfAssign(cdatamapping, _mxarray117_);
                /*
                 * clim = [];   % irrelevant
                 */
                mlfAssign(clim, _mxarray96_);
                /*
                 * map = varargin{2};
                 */
                mlfAssign(
                  map,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * elseif (isempty(varargin{2}))
             */
            } else if (mlfTobool(
                         mclFeval(
                           mclValueVarargout(),
                           mlxIsempty,
                           mlfIndexRef(
                             mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                           NULL))) {
                /*
                 * % IMSHOW(I,[])
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{1};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * clim = [min(cdata(:)) max(cdata(:))];
                 */
                mlfAssign(
                  clim,
                  mlfHorzcat(
                    mlfMin(
                      NULL,
                      mclArrayRef1(
                        mclVv(*cdata, "cdata"), mlfCreateColonIndex()),
                      NULL,
                      NULL),
                    mlfMax(
                      NULL,
                      mclArrayRef1(
                        mclVv(*cdata, "cdata"), mlfCreateColonIndex()),
                      NULL,
                      NULL),
                    NULL));
                /*
                 * map = gray(defGrayMapLength);
                 */
                mlfAssign(
                  map, mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                /*
                 * xdata = [1 size(cdata,2)];
                 */
                mlfAssign(
                  xdata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray8_),
                    NULL));
                /*
                 * ydata = [1 size(cdata,1)];
                 */
                mlfAssign(
                  ydata,
                  mlfHorzcat(
                    _mxarray7_,
                    mlfSize(
                      mclValueVarargout(), mclVv(*cdata, "cdata"), _mxarray7_),
                    NULL));
            /*
             * 
             * else
             */
            } else {
                /*
                 * error('Invalid input arguments; see HELP IMSHOW');
                 */
                mlfError(_mxarray123_, NULL);
            /*
             * 
             * end
             */
            }
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray93_)) {
            /*
             * % IMSHOW(R,G,B) OBSOLETE
             * % IMSHOW(x,y,I)
             * % IMSHOW(x,y,RGB)
             * 
             * if (ndims(varargin{3}) == 3)
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxNdims,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray93_),
                    NULL),
                  _mxarray93_)) {
                /*
                 * % IMSHOW(x,y,RGB)
                 * imtype = 'rgb';
                 */
                mlfAssign(&imtype, _mxarray94_);
                /*
                 * cdata = varargin{3};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                /*
                 * cdatamapping = 'direct'; % irrelevant
                 */
                mlfAssign(cdatamapping, _mxarray117_);
                /*
                 * clim = [];               % irrelevant
                 */
                mlfAssign(clim, _mxarray96_);
                /*
                 * map = [];                % irrelevant
                 */
                mlfAssign(map, _mxarray96_);
                /*
                 * xdata = varargin{1};
                 */
                mlfAssign(
                  xdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * ydata = varargin{2};
                 */
                mlfAssign(
                  ydata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * 
             * elseif (IsVector(varargin{1}) & IsVector(varargin{2}))
             */
            } else {
                mxArray * a_
                  = mclInitialize(
                      mclFeval(
                        mclValueVarargout(),
                        mlxImshow_IsVector,
                        mlfIndexRef(
                          mclVa(varargin, "varargin"), "{?}", _mxarray7_),
                        NULL));
                if (mlfTobool(a_)
                    && mlfTobool(
                         mclAnd(
                           a_,
                           mclFeval(
                             mclValueVarargout(),
                             mlxImshow_IsVector,
                             mlfIndexRef(
                               mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                             NULL)))) {
                    mxDestroyArray(a_);
                    /*
                     * % IMSHOW(x,y,I)
                     * imtype = 'intensity';
                     */
                    mlfAssign(&imtype, _mxarray97_);
                    /*
                     * cdata = varargin{3};
                     */
                    mlfAssign(
                      cdata,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                    /*
                     * cdatamapping = 'scaled';
                     */
                    mlfAssign(cdatamapping, _mxarray99_);
                    /*
                     * switch class(cdata)
                     */
                    {
                        mxArray * v_2
                          = mclInitialize(
                              mlfClassName(mclVv(*cdata, "cdata"), NULL));
                        if (mclSwitchCompare(v_2, _mxarray105_)) {
                            /*
                             * case 'uint8'
                             * clim = [0 255];
                             */
                            mlfAssign(clim, _mxarray107_);
                        /*
                         * case 'logical'
                         */
                        } else if (mclSwitchCompare(v_2, _mxarray109_)) {
                            /*
                             * % Binary images are of type logical
                             * clim = [0 1];
                             */
                            mlfAssign(clim, _mxarray103_);
                        /*
                         * case 'uint16'
                         */
                        } else if (mclSwitchCompare(v_2, _mxarray111_)) {
                            /*
                             * clim = [0 65535];
                             */
                            mlfAssign(clim, _mxarray113_);
                        /*
                         * case 'double'
                         */
                        } else if (mclSwitchCompare(v_2, _mxarray101_)) {
                            /*
                             * clim = [0 1];
                             */
                            mlfAssign(clim, _mxarray103_);
                        /*
                         * otherwise
                         */
                        } else {
                            /*
                             * error('Unsupported image class');
                             */
                            mlfError(_mxarray119_, NULL);
                        /*
                         * end
                         */
                        }
                        mxDestroyArray(v_2);
                    }
                    /*
                     * map = gray(defGrayMapLength);
                     */
                    mlfAssign(
                      map,
                      mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                    /*
                     * xdata = varargin{1};
                     */
                    mlfAssign(
                      xdata,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                    /*
                     * ydata = varargin{2};
                     */
                    mlfAssign(
                      ydata,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray8_));
                /*
                 * 
                 * elseif isequal(size(varargin{1}),size(varargin{2}),size(varargin{3})),
                 */
                } else {
                    mxDestroyArray(a_);
                    if (mlfTobool(
                          mlfIsequal(
                            mclFeval(
                              mclValueVarargout(),
                              mlxSize,
                              mlfIndexRef(
                                mclVa(varargin, "varargin"), "{?}", _mxarray7_),
                              NULL),
                            mclFeval(
                              mclValueVarargout(),
                              mlxSize,
                              mlfIndexRef(
                                mclVa(varargin, "varargin"), "{?}", _mxarray8_),
                              NULL),
                            mclFeval(
                              mclValueVarargout(),
                              mlxSize,
                              mlfIndexRef(
                                mclVa(varargin, "varargin"),
                                "{?}",
                                _mxarray93_),
                              NULL),
                            NULL))) {
                        /*
                         * % IMSHOW(R,G,B)
                         * warning(['IMSHOW(R,G,B) is an obsolete syntax. ',...
                         */
                        mclAssignAns(
                          &ans, mlfNWarning(0, NULL, _mxarray125_, NULL));
                        /*
                         * 'Use a three-dimensional array to represent RGB image.']);
                         * imtype = 'rgb';
                         */
                        mlfAssign(&imtype, _mxarray94_);
                        /*
                         * cdata = cat(3,varargin{:});
                         */
                        mlfAssign(
                          cdata,
                          mlfCat(
                            _mxarray93_,
                            mlfIndexRef(
                              mclVa(varargin, "varargin"),
                              "{?}",
                              mlfCreateColonIndex()),
                            NULL));
                        /*
                         * cdatamapping = 'direct';        % irrelevant
                         */
                        mlfAssign(cdatamapping, _mxarray117_);
                        /*
                         * clim = [];                      % irrelevant
                         */
                        mlfAssign(clim, _mxarray96_);
                        /*
                         * map = [];                       % irrelevant
                         */
                        mlfAssign(map, _mxarray96_);
                        /*
                         * xdata = [1 size(cdata,2)];
                         */
                        mlfAssign(
                          xdata,
                          mlfHorzcat(
                            _mxarray7_,
                            mlfSize(
                              mclValueVarargout(),
                              mclVv(*cdata, "cdata"),
                              _mxarray8_),
                            NULL));
                        /*
                         * ydata = [1 size(cdata,1)];
                         */
                        mlfAssign(
                          ydata,
                          mlfHorzcat(
                            _mxarray7_,
                            mlfSize(
                              mclValueVarargout(),
                              mclVv(*cdata, "cdata"),
                              _mxarray7_),
                            NULL));
                    /*
                     * 
                     * else
                     */
                    } else {
                        /*
                         * error('Invalid input arguments; see HELP IMSHOW');
                         */
                        mlfError(_mxarray123_, NULL);
                    }
                }
            /*
             * 
             * end
             */
            }
        /*
         * 
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray127_)) {
            /*
             * % IMSHOW(x,y,X,MAP)
             * % IMSHOW(x,y,I,N)
             * % IMSHOW(x,y,I,[a b])
             * % IMSHOW(x,y,I,[])
             * 
             * if (prod(size(varargin{4})) == 1)
             */
            if (mclEqBool(
                  mlfProd(
                    mclFeval(
                      mclValueVarargout(),
                      mlxSize,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray127_),
                      NULL),
                    NULL),
                  _mxarray7_)) {
                /*
                 * % IMSHOW(x,y,I,N)
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{3};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * switch class(cdata)
                 */
                {
                    mxArray * v_3
                      = mclInitialize(
                          mlfClassName(mclVv(*cdata, "cdata"), NULL));
                    if (mclSwitchCompare(v_3, _mxarray105_)) {
                        /*
                         * case 'uint8'
                         * clim = [0 255];
                         */
                        mlfAssign(clim, _mxarray107_);
                    /*
                     * case 'logical'
                     */
                    } else if (mclSwitchCompare(v_3, _mxarray109_)) {
                        /*
                         * % Binary images are of type logical
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * case 'uint16'
                     */
                    } else if (mclSwitchCompare(v_3, _mxarray111_)) {
                        /*
                         * clim = [0 65535];
                         */
                        mlfAssign(clim, _mxarray113_);
                    /*
                     * case 'double'
                     */
                    } else if (mclSwitchCompare(v_3, _mxarray101_)) {
                        /*
                         * clim = [0 1];
                         */
                        mlfAssign(clim, _mxarray103_);
                    /*
                     * otherwise
                     */
                    } else {
                        /*
                         * error('Unsupported image class');
                         */
                        mlfError(_mxarray119_, NULL);
                    /*
                     * end
                     */
                    }
                    mxDestroyArray(v_3);
                }
                /*
                 * map = gray(varargin{4});
                 */
                mlfAssign(
                  map,
                  mclFeval(
                    mclValueVarargout(),
                    mlxGray,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray127_),
                    NULL));
                /*
                 * xdata = varargin{1};
                 */
                mlfAssign(
                  xdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * ydata = varargin{2};
                 */
                mlfAssign(
                  ydata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * 
             * elseif (isequal(size(varargin{4}), [1 2]))
             */
            } else if (mlfTobool(
                         mlfIsequal(
                           mclFeval(
                             mclValueVarargout(),
                             mlxSize,
                             mlfIndexRef(
                               mclVa(varargin, "varargin"),
                               "{?}",
                               _mxarray127_),
                             NULL),
                           _mxarray121_, NULL))) {
                /*
                 * % IMSHOW(x,y,I,[a b])
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{3};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * clim = varargin{4};
                 */
                mlfAssign(
                  clim,
                  mlfIndexRef(
                    mclVa(varargin, "varargin"), "{?}", _mxarray127_));
                /*
                 * map = gray(defGrayMapLength);
                 */
                mlfAssign(
                  map, mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                /*
                 * xdata = varargin{1};
                 */
                mlfAssign(
                  xdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * ydata = varargin{2};
                 */
                mlfAssign(
                  ydata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * 
             * elseif (size(varargin{4},2) == 3)
             */
            } else if (mclEqBool(
                         mclFeval(
                           mclValueVarargout(),
                           mlxSize,
                           mlfIndexRef(
                             mclVa(varargin, "varargin"), "{?}", _mxarray127_),
                           _mxarray8_,
                           NULL),
                         _mxarray93_)) {
                /*
                 * % IMSHOW(x,y,X,map)
                 * imtype = 'indexed';
                 */
                mlfAssign(&imtype, _mxarray115_);
                /*
                 * cdata = varargin{3};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                /*
                 * cdatamapping = 'direct';
                 */
                mlfAssign(cdatamapping, _mxarray117_);
                /*
                 * clim = [];                % irrelevant
                 */
                mlfAssign(clim, _mxarray96_);
                /*
                 * map = varargin{4};
                 */
                mlfAssign(
                  map,
                  mlfIndexRef(
                    mclVa(varargin, "varargin"), "{?}", _mxarray127_));
                /*
                 * xdata = varargin{1};
                 */
                mlfAssign(
                  xdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * ydata = varargin{2};
                 */
                mlfAssign(
                  ydata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * 
             * elseif (isempty(varargin{4}))
             */
            } else if (mlfTobool(
                         mclFeval(
                           mclValueVarargout(),
                           mlxIsempty,
                           mlfIndexRef(
                             mclVa(varargin, "varargin"), "{?}", _mxarray127_),
                           NULL))) {
                /*
                 * % IMSHOW(x,y,I,[])
                 * imtype = 'intensity';
                 */
                mlfAssign(&imtype, _mxarray97_);
                /*
                 * cdata = varargin{3};
                 */
                mlfAssign(
                  cdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray93_));
                /*
                 * cdatamapping = 'scaled';
                 */
                mlfAssign(cdatamapping, _mxarray99_);
                /*
                 * clim = [min(cdata(:)) max(cdata(:))];
                 */
                mlfAssign(
                  clim,
                  mlfHorzcat(
                    mlfMin(
                      NULL,
                      mclArrayRef1(
                        mclVv(*cdata, "cdata"), mlfCreateColonIndex()),
                      NULL,
                      NULL),
                    mlfMax(
                      NULL,
                      mclArrayRef1(
                        mclVv(*cdata, "cdata"), mlfCreateColonIndex()),
                      NULL,
                      NULL),
                    NULL));
                /*
                 * map = gray(defGrayMapLength);
                 */
                mlfAssign(
                  map, mlfGray(mclVv(defGrayMapLength, "defGrayMapLength")));
                /*
                 * xdata = varargin{1};
                 */
                mlfAssign(
                  xdata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * ydata = varargin{2};
                 */
                mlfAssign(
                  ydata,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * 
             * else
             */
            } else {
                /*
                 * error('Invalid input arguments.  See HELP IMSHOW');
                 */
                mlfError(_mxarray128_, NULL);
            /*
             * 
             * end
             */
            }
        /*
         * 
         * case 5
         */
        } else if (mclSwitchCompare(v_, _mxarray130_)) {
            /*
             * % IMSHOW(x,y,R,G,B) OBSOLETE
             * warning(['IMSHOW(x,y,R,G,B) is an obsolete syntax. ',...
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray131_, NULL));
            /*
             * 'Use a three-dimensional array to represent RGB image.']);
             * imtype = 'rgb';
             */
            mlfAssign(&imtype, _mxarray94_);
            /*
             * cdata = cat(3,varargin{3:5});
             */
            mlfAssign(
              cdata,
              mlfCat(
                _mxarray93_,
                mlfIndexRef(
                  mclVa(varargin, "varargin"),
                  "{?}",
                  mlfColon(_mxarray93_, _mxarray130_, NULL)),
                NULL));
            /*
             * cdatamapping = 'direct';           % irrelevant
             */
            mlfAssign(cdatamapping, _mxarray117_);
            /*
             * clim = [];                         % irrelevant
             */
            mlfAssign(clim, _mxarray96_);
            /*
             * map = [];                          % irrelevant
             */
            mlfAssign(map, _mxarray96_);
            /*
             * xdata = varargin{1};
             */
            mlfAssign(
              xdata,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * ydata = varargin{2};
             */
            mlfAssign(
              ydata,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * 
             * error('Too many input arguments.  See HELP IMSHOW');
             */
            mlfError(_mxarray133_, NULL);
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * % Check dimension support
     * 
     * if ((ndims(cdata) > 3) | ((size(cdata,3) ~= 1) & (size(cdata,3) ~= 3)))
     */
    {
        mxArray * a_
          = mclInitialize(
              mclGt(mlfNdims(mclVv(*cdata, "cdata")), _mxarray93_));
        if (mlfTobool(a_)) {
        } else {
            mxArray * b_
              = mclInitialize(
                  mclNe(
                    mlfSize(
                      mclValueVarargout(),
                      mclVv(*cdata, "cdata"),
                      _mxarray93_),
                    _mxarray7_));
            if (mlfTobool(b_)) {
                mlfAssign(
                  &b_,
                  mclAnd(
                    b_,
                    mclNe(
                      mlfSize(
                        mclValueVarargout(),
                        mclVv(*cdata, "cdata"),
                        _mxarray93_),
                      _mxarray93_)));
            } else {
                mlfAssign(&b_, mlfScalar(0));
            }
            {
                mxLogical c_0 = mlfTobool(mclOr(a_, b_));
                mxDestroyArray(b_);
                if (c_0) {
                } else {
                    mxDestroyArray(a_);
                    goto done_;
                }
            }
        }
        mxDestroyArray(a_);
        /*
         * 
         * error('Unsupported dimension')
         */
        mlfError(_mxarray135_, NULL);
        /*
         * end
         */
        done_:;
    }
    /*
     * 
     * %------------------------------------------------------------------
     * 
     * 
     * % Catch complex CData case
     * if (~isreal(cdata))
     */
    if (mclNotBool(mlfIsreal(mclVv(*cdata, "cdata")))) {
        /*
         * warning('Displaying real part of complex input');
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray137_, NULL));
        /*
         * cdata = real(cdata);
         */
        mlfAssign(cdata, mlfReal(mclVv(*cdata, "cdata")));
    /*
     * end
     */
    }
    /*
     * 
     * % Catch imshow(...,[]) case where input is constant.
     * if (~isempty(clim) & (clim(1) == clim(2)))
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIsempty(mclVv(*clim, "clim"))));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclEq(
                     mclIntArrayRef1(mclVv(*clim, "clim"), 1),
                     mclIntArrayRef1(mclVv(*clim, "clim"), 2))))) {
            mxDestroyArray(a_);
            /*
             * % Do the Handle Graphics thing --- make the range [k-1 k+1].
             * % Image will display as shade of gray.
             * clim = double(clim) + [-1 1];
             */
            mlfAssign(
              clim, mclPlus(mlfDouble(mclVv(*clim, "clim")), _mxarray139_));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(imtype, 1, nargout_, "imtype", "imshow/ParseInputs");
    mclValidateOutput(*cdata, 2, nargout_, "cdata", "imshow/ParseInputs");
    mclValidateOutput(
      *cdatamapping, 3, nargout_, "cdatamapping", "imshow/ParseInputs");
    mclValidateOutput(*clim, 4, nargout_, "clim", "imshow/ParseInputs");
    mclValidateOutput(*map, 5, nargout_, "map", "imshow/ParseInputs");
    mclValidateOutput(*xdata, 6, nargout_, "xdata", "imshow/ParseInputs");
    mclValidateOutput(*ydata, 7, nargout_, "ydata", "imshow/ParseInputs");
    mclValidateOutput(*filename, 8, nargout_, "filename", "imshow/ParseInputs");
    mclValidateOutput(
      *truesizeStr, 9, nargout_, "truesizeStr", "imshow/ParseInputs");
    mxDestroyArray(defGrayMapLength);
    mxDestroyArray(str);
    mxDestroyArray(strs);
    mxDestroyArray(idx);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return imtype;
    /*
     * 
     * 
     * %%%
     * %%% Subfunction IsVector
     * %%%
     */
}

/*
 * The function "Mimshow_IsVector" is the implementation version of the
 * "imshow/IsVector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 518-526). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function tf = IsVector(x)
 */
static mxArray * Mimshow_IsVector(int nargout_, mxArray * x) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imshow);
    mxArray * tf = NULL;
    mclCopyArray(&x);
    /*
     * %ISVECTOR True if x has only one non-singleton dimension.
     * tf = (sum(size(x)~=1) <= 1);
     */
    mlfAssign(
      &tf,
      mclLe(
        mlfSum(
          mclNe(mlfSize(mclValueVarargout(), mclVa(x, "x"), NULL), _mxarray7_),
          NULL),
        _mxarray7_));
    mclValidateOutput(tf, 1, nargout_, "tf", "imshow/IsVector");
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * 
     * %%%
     * %%% Subfunction SingleImageDefaultPos
     * %%%
     */
}

/*
 * The function "Mimshow_SingleImageDefaultPos" is the implementation version
 * of the "imshow/SingleImageDefaultPos" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imshow.m" (lines 526-553). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function tf = SingleImageDefaultPos(figHandle, axHandle)
 */
static mxArray * Mimshow_SingleImageDefaultPos(int nargout_,
                                               mxArray * figHandle,
                                               mxArray * axHandle) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imshow);
    mxArray * tf = NULL;
    mxArray * kids = NULL;
    mxArray * figKids = NULL;
    mclCopyArray(&figHandle);
    mclCopyArray(&axHandle);
    /*
     * 
     * if (length(findobj(axHandle, 'Type', 'image')) > 1)
     */
    if (mclLengthInt(
          mlfFindobj(
            mclVa(axHandle, "axHandle"), _mxarray141_, _mxarray143_, NULL))
        > 1) {
        /*
         * % More than one image in axes
         * tf = 0;
         */
        mlfAssign(&tf, _mxarray0_);
    /*
     * 
     * else
     */
    } else {
        /*
         * 
         * figKids = allchild(figHandle);
         */
        mlfAssign(&figKids, mlfAllchild(mclVa(figHandle, "figHandle")));
        /*
         * kids = [findobj(figKids, 'Type', 'axes') ;
         */
        mlfAssign(
          &kids,
          mlfVertcat(
            mlfFindobj(
              mclVv(figKids, "figKids"), _mxarray141_, _mxarray145_, NULL),
            mlfFindobj(
              mclVv(figKids, "figKids"),
              _mxarray141_,
              _mxarray147_,
              _mxarray9_,
              _mxarray43_,
              NULL),
            NULL));
        /*
         * findobj(figKids, 'Type', 'uicontrol', 'Visible', 'on')];
         * if (length(kids) > 1)
         */
        if (mclLengthInt(mclVv(kids, "kids")) > 1) {
            /*
             * % The axes isn't the only thing around, so don't truesize
             * tf = 0;
             */
            mlfAssign(&tf, _mxarray0_);
        /*
         * else
         */
        } else {
            /*
             * % Is axHandle in the default position?
             * if (isequal(get(axHandle, 'Position'), ...
             */
            if (mlfTobool(
                  mlfIsequal(
                    mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray65_, NULL),
                    mlfNGet(
                      1,
                      mlfNGet(
                        1, mclVa(axHandle, "axHandle"), _mxarray13_, NULL),
                      _mxarray149_,
                      NULL),
                    NULL))) {
                /*
                 * get(get(axHandle,'Parent'), 'DefaultAxesPosition')))
                 * % Yes, call truesize
                 * tf = 1;
                 */
                mlfAssign(&tf, _mxarray7_);
            /*
             * 
             * else
             */
            } else {
                /*
                 * % No, don't call truesize
                 * tf = 0;
                 */
                mlfAssign(&tf, _mxarray0_);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "imshow/SingleImageDefaultPos");
    mxDestroyArray(figKids);
    mxDestroyArray(kids);
    mxDestroyArray(axHandle);
    mxDestroyArray(figHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
}
