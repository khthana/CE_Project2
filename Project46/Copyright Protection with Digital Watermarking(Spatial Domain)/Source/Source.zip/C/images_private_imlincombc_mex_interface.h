/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __images_private_imlincombc_mex_interface_h
#define __images_private_imlincombc_mex_interface_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_images_private_imlincombc_mex_interface(void);
extern void TerminateModule_images_private_imlincombc_mex_interface(void);
extern _mexLocalFunctionTable _local_function_table_images_private_imlincombc;

extern mxArray * mlfNImages_private_imlincombc(int nargout,
                                               mlfVarargoutList * varargout,
                                               ...);
extern mxArray * mlfImages_private_imlincombc(mlfVarargoutList * varargout,
                                              ...);
extern void mlfVImages_private_imlincombc(mxArray * synthetic_varargin_argument,
                                          ...);
extern void mlxImages_private_imlincombc(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
