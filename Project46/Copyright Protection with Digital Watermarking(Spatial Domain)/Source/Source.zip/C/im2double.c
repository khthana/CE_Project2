/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "im2double.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array5_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray6_;

static mxChar _array9_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray8_;

static mxChar _array11_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray10_;

static mxArray * _array3_[4] = { NULL /*_mxarray4_*/, NULL /*_mxarray6_*/,
                                 NULL /*_mxarray8_*/, NULL /*_mxarray10_*/ };
static mxArray * _mxarray2_;
static mxArray * _mxarray12_;

static mxChar _array14_[5] = { 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;
static mxArray * _mxarray16_;

static mxChar _array19_[7] = { 'i', 'n', 'd', 'e', 'x', 'e', 'd' };
static mxArray * _mxarray18_;
static mxArray * _mxarray17_;

static mxChar _array21_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray20_;

void InitializeModule_im2double(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray4_ = mclInitializeString(6, _array5_);
    _array3_[0] = _mxarray4_;
    _mxarray6_ = mclInitializeString(7, _array7_);
    _array3_[1] = _mxarray6_;
    _mxarray8_ = mclInitializeString(5, _array9_);
    _array3_[2] = _mxarray8_;
    _mxarray10_ = mclInitializeString(6, _array11_);
    _array3_[3] = _mxarray10_;
    _mxarray2_ = mclInitializeCellVector(1, 4, _array3_);
    _mxarray12_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray13_ = mclInitializeString(5, _array14_);
    _mxarray15_ = mclInitializeDouble(255.0);
    _mxarray16_ = mclInitializeDouble(65535.0);
    _mxarray18_ = mclInitializeString(7, _array19_);
    _mxarray17_ = mclInitializeCell(_mxarray18_);
    _mxarray20_ = mclInitializeString(4, _array21_);
}

void TerminateModule_im2double(void) {
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mim2double(int nargout_, mxArray * img, mxArray * typestr);

_mexLocalFunctionTable _local_function_table_im2double
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfIm2double" contains the normal interface for the
 * "im2double" M-function from file
 * "k:\matlab6p5\toolbox\images\images\im2double.m" (lines 1-47). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfIm2double(mxArray * img, mxArray * typestr) {
    int nargout = 1;
    mxArray * d = NULL;
    mlfEnterNewContext(0, 2, img, typestr);
    d = Mim2double(nargout, img, typestr);
    mlfRestorePreviousContext(0, 2, img, typestr);
    return mlfReturnValue(d);
}

/*
 * The function "mlxIm2double" contains the feval interface for the "im2double"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2double.m" (lines
 * 1-47). The feval function calls the implementation version of im2double
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxIm2double(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: im2double Line: 1 Column:"
            " 1 The function \"im2double\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: im2double Line: 1 Column:"
            " 1 The function \"im2double\" was called with m"
            "ore than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mim2double(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mim2double" is the implementation version of the "im2double"
 * M-function from file "k:\matlab6p5\toolbox\images\images\im2double.m" (lines
 * 1-47). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function d = im2double(img, typestr)
 */
static mxArray * Mim2double(int nargout_, mxArray * img, mxArray * typestr) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_im2double);
    int nargin_ = mclNargin(2, img, typestr, NULL);
    mxArray * d = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&img);
    mclCopyArray(&typestr);
    /*
     * %IM2DOUBLE Convert image to double precision.
     * %   IM2DOUBLE takes an image as input, and returns an image of
     * %   class double.  If the input image is of class double, the
     * %   output image is identical to it.  If the input image is of
     * %   class logical, uint8 or uint16, im2double returns the 
     * %   equivalent image of class double, rescaling or offsetting
     * %   the data as necessary.
     * %
     * %   I2 = IM2DOUBLE(I1) converts the intensity image I1 to double
     * %   precision, rescaling the data if necessary.
     * %
     * %   RGB2 = IM2DOUBLE(RGB1) converts the truecolor image RGB1 to
     * %   double precision, rescaling the data if necessary.
     * %
     * %   BW2 = IM2DOUBLE(BW1) converts the binary image BW1 to double
     * %   precision.
     * %
     * %   X2 = IM2DOUBLE(X1,'indexed') converts the indexed image X1 to
     * %   double precision, offsetting the data if necessary.
     * % 
     * %   See also DOUBLE, IM2UINT8, UINT8.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.16 $  $Date: 2002/03/15 15:27:36 $
     * 
     * checknargin(1,2,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("im2double"));
    /*
     * checkinput(img,{'double','logical','uint8','uint16'},{},mfilename,'Image',1);
     */
    mlfImages_private_checkinput(
      mclVa(img, "img"),
      _mxarray2_,
      _mxarray12_,
      mxCreateString("im2double"),
      _mxarray13_,
      _mxarray0_);
    /*
     * 
     * if isa(img, 'double')
     */
    if (mlfTobool(mlfIsa(mclVa(img, "img"), _mxarray4_))) {
        /*
         * d = img;
         */
        mlfAssign(&d, mclVa(img, "img"));
    /*
     * elseif isa(img, 'logical')
     */
    } else if (mlfTobool(mlfIsa(mclVa(img, "img"), _mxarray6_))) {
        /*
         * d = double(img);
         */
        mlfAssign(&d, mlfDouble(mclVa(img, "img")));
    /*
     * elseif isa(img, 'uint8') | isa(img, 'uint16')
     */
    } else {
        mxArray * a_ = mclInitialize(mlfIsa(mclVa(img, "img"), _mxarray8_));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mlfIsa(mclVa(img, "img"), _mxarray10_)))) {
            mxDestroyArray(a_);
            /*
             * if nargin==1
             */
            if (nargin_ == 1) {
                /*
                 * if isa(img, 'uint8')
                 */
                if (mlfTobool(mlfIsa(mclVa(img, "img"), _mxarray8_))) {
                    /*
                     * d = double(img)/255;
                     */
                    mlfAssign(
                      &d,
                      mclMrdivide(mlfDouble(mclVa(img, "img")), _mxarray15_));
                /*
                 * else
                 */
                } else {
                    /*
                     * d = double(img)/65535;
                     */
                    mlfAssign(
                      &d,
                      mclMrdivide(mlfDouble(mclVa(img, "img")), _mxarray16_));
                /*
                 * end
                 */
                }
            /*
             * elseif nargin==2
             */
            } else if (nargin_ == 2) {
                /*
                 * checkstrs(typestr,{'indexed'},mfilename,'type',2);
                 */
                mclAssignAns(
                  &ans,
                  mlfImages_private_checkstrs(
                    mclVa(typestr, "typestr"),
                    _mxarray17_,
                    mxCreateString("im2double"),
                    _mxarray20_,
                    _mxarray1_));
                /*
                 * d = double(img)+1;
                 */
                mlfAssign(
                  &d, mclPlus(mlfDouble(mclVa(img, "img")), _mxarray0_));
            /*
             * end
             */
            }
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(d, 1, nargout_, "d", "im2double");
    mxDestroyArray(ans);
    mxDestroyArray(typestr);
    mxDestroyArray(img);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return d;
    /*
     * 
     */
}
