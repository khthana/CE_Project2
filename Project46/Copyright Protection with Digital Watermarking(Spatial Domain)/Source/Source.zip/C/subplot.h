/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __subplot_h
#define __subplot_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_subplot(void);
extern void TerminateModule_subplot(void);
extern _mexLocalFunctionTable _local_function_table_subplot;

extern mxArray * mlfNSubplot(int nargout,
                             mxArray * nrows,
                             mxArray * ncols,
                             mxArray * thisPlot,
                             mxArray * replace);
extern mxArray * mlfSubplot(mxArray * nrows,
                            mxArray * ncols,
                            mxArray * thisPlot,
                            mxArray * replace);
extern void mlfVSubplot(mxArray * nrows,
                        mxArray * ncols,
                        mxArray * thisPlot,
                        mxArray * replace);
extern void mlxSubplot(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
