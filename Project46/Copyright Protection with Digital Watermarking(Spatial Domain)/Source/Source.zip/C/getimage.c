/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "getimage.h"
#include "libsgl.h"
#include "images_private_checknargin.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static mxChar _array6_[27] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                               ':', 't', 'o', 'o', 'M', 'a', 'n', 'y', 'O',
                               'u', 't', 'p', 'u', 't', 'A', 'r', 'g', 's' };
static mxArray * _mxarray5_;

static mxChar _array8_[26] = { 'T', 'o', 'o', ' ', 'm', 'a', 'n', 'y', ' ',
                               'o', 'u', 't', 'p', 'u', 't', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;

static mxChar _array11_[8] = { 'C', 'h', 'i', 'l', 'd', 'r', 'e', 'n' };
static mxArray * _mxarray10_;

static mxChar _array13_[13] = { 'C', 'u', 'r', 'r', 'e', 'n', 't',
                                'F', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray12_;

static mxChar _array15_[4] = { 'f', 'l', 'a', 't' };
static mxArray * _mxarray14_;

static mxChar _array17_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray16_;

static mxChar _array19_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray18_;

static mxChar _array21_[11] = { 'C', 'u', 'r', 'r', 'e', 'n',
                                't', 'A', 'x', 'e', 's' };
static mxArray * _mxarray20_;

static mxChar _array23_[24] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'i', 'n', 'v', 'a', 'l', 'i',
                                'd', 'H', 'a', 'n', 'd', 'l', 'e', 'H' };
static mxArray * _mxarray22_;

static mxChar _array25_[21] = { '%', 's', ':', ' ', 'I', 'n', 'v',
                                'a', 'l', 'i', 'd', ' ', 'h', 'a',
                                'n', 'd', 'l', 'e', ' ', 'H', '.' };
static mxArray * _mxarray24_;

static mxChar _array27_[6] = { 'f', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray26_;

static mxChar _array29_[5] = { 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray28_;

static mxChar _array31_[37] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'h', 'a', 'n', 'd', 'l', 'e',
                                'H', 'M', 'u', 's', 't', 'B', 'e', 'F',
                                'i', 'g', 'A', 'x', 'e', 's', 'O', 'r',
                                'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray30_;

static mxChar _array33_[52] = { '%', 's', ':', ' ', 'I', 'n', 'p', 'u', 't',
                                ' ', 'h', 'a', 'n', 'd', 'l', 'e', ' ', 'H',
                                ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'a', ' ', 'f', 'i', 'g', 'u', 'r', 'e', ',',
                                ' ', 'a', 'x', 'e', 's', ',', ' ', 'o', 'r',
                                ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray32_;

static mxChar _array35_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray34_;

static mxChar _array37_[13] = { 'C', 'u', 'r', 'r', 'e', 'n', 't',
                                'O', 'b', 'j', 'e', 'c', 't' };
static mxArray * _mxarray36_;

static mxChar _array39_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray38_;

static mxChar _array41_[7] = { 's', 'u', 'r', 'f', 'a', 'c', 'e' };
static mxArray * _mxarray40_;

static mxChar _array43_[9] = { 'F', 'a', 'c', 'e', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray42_;

static mxChar _array45_[10] = { 't', 'e', 'x', 't', 'u',
                                'r', 'e', 'm', 'a', 'p' };
static mxArray * _mxarray44_;

static mxChar _array47_[5] = { 'C', 'D', 'a', 't', 'a' };
static mxArray * _mxarray46_;

static mxChar _array49_[5] = { 'X', 'D', 'a', 't', 'a' };
static mxArray * _mxarray48_;

static mxChar _array51_[5] = { 'Y', 'D', 'a', 't', 'a' };
static mxArray * _mxarray50_;

static mxChar _array53_[8] = { 'U', 's', 'e', 'r', 'D', 'a', 't', 'a' };
static mxArray * _mxarray52_;

static mxChar _array55_[12] = { 'C', 'D', 'a', 't', 'a', 'M',
                                'a', 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray54_;

static mxChar _array57_[6] = { 'd', 'i', 'r', 'e', 'c', 't' };
static mxArray * _mxarray56_;

static double _array59_[2] = { 1.0, 2.0 };
static mxArray * _mxarray58_;

static mxChar _array61_[8] = { 'C', 'o', 'l', 'o', 'r', 'm', 'a', 'p' };
static mxArray * _mxarray60_;

static double _array63_[2] = { 0.0, 1.0 };
static mxArray * _mxarray62_;

static mxChar _array65_[4] = { 'C', 'L', 'i', 'm' };
static mxArray * _mxarray64_;

static double _array67_[2] = { 0.0, 255.0 };
static mxArray * _mxarray66_;

static mxChar _array69_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray68_;

static double _array71_[2] = { 0.0, 65535.0 };
static mxArray * _mxarray70_;

static mxChar _array73_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray72_;

static mxChar _array75_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray74_;

void InitializeModule_getimage(void) {
    _mxarray0_ = mclInitializeDouble(0.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeDouble(2.0);
    _mxarray3_ = mclInitializeDouble(3.0);
    _mxarray4_ = mclInitializeDouble(4.0);
    _mxarray5_ = mclInitializeString(27, _array6_);
    _mxarray7_ = mclInitializeString(26, _array8_);
    _mxarray9_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray10_ = mclInitializeString(8, _array11_);
    _mxarray12_ = mclInitializeString(13, _array13_);
    _mxarray14_ = mclInitializeString(4, _array15_);
    _mxarray16_ = mclInitializeString(4, _array17_);
    _mxarray18_ = mclInitializeString(4, _array19_);
    _mxarray20_ = mclInitializeString(11, _array21_);
    _mxarray22_ = mclInitializeString(24, _array23_);
    _mxarray24_ = mclInitializeString(21, _array25_);
    _mxarray26_ = mclInitializeString(6, _array27_);
    _mxarray28_ = mclInitializeString(5, _array29_);
    _mxarray30_ = mclInitializeString(37, _array31_);
    _mxarray32_ = mclInitializeString(52, _array33_);
    _mxarray34_ = mclInitializeString(6, _array35_);
    _mxarray36_ = mclInitializeString(13, _array37_);
    _mxarray38_ = mclInitializeString(4, _array39_);
    _mxarray40_ = mclInitializeString(7, _array41_);
    _mxarray42_ = mclInitializeString(9, _array43_);
    _mxarray44_ = mclInitializeString(10, _array45_);
    _mxarray46_ = mclInitializeString(5, _array47_);
    _mxarray48_ = mclInitializeString(5, _array49_);
    _mxarray50_ = mclInitializeString(5, _array51_);
    _mxarray52_ = mclInitializeString(8, _array53_);
    _mxarray54_ = mclInitializeString(12, _array55_);
    _mxarray56_ = mclInitializeString(6, _array57_);
    _mxarray58_ = mclInitializeDoubleVector(1, 2, _array59_);
    _mxarray60_ = mclInitializeString(8, _array61_);
    _mxarray62_ = mclInitializeDoubleVector(1, 2, _array63_);
    _mxarray64_ = mclInitializeString(4, _array65_);
    _mxarray66_ = mclInitializeDoubleVector(1, 2, _array67_);
    _mxarray68_ = mclInitializeString(5, _array69_);
    _mxarray70_ = mclInitializeDoubleVector(1, 2, _array71_);
    _mxarray72_ = mclInitializeString(6, _array73_);
    _mxarray74_ = mclInitializeString(6, _array75_);
}

void TerminateModule_getimage(void) {
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfGetimage_findim(mxArray * synthetic_varargin_argument, ...);
static void mlxGetimage_findim(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]);
static mxArray * mlfGetimage_findim_in_axes(mxArray * axHandle);
static void mlxGetimage_findim_in_axes(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfGetimage_get_image_info(mxArray * * y,
                                            mxArray * * A,
                                            mxArray * * state,
                                            mxArray * him);
static void mlxGetimage_get_image_info(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * Mgetimage(int nargout_, mxArray * varargin);
static mxArray * Mgetimage_findim(int nargout_, mxArray * varargin);
static mxArray * Mgetimage_findim_in_axes(int nargout_, mxArray * axHandle);
static mxArray * Mgetimage_get_image_info(mxArray * * y,
                                          mxArray * * A,
                                          mxArray * * state,
                                          int nargout_,
                                          mxArray * him);

static mexFunctionTableEntry local_function_table_[3]
  = { { "findim", mlxGetimage_findim, -1, 1, NULL },
      { "findim_in_axes", mlxGetimage_findim_in_axes, 1, 1, NULL },
      { "get_image_info", mlxGetimage_get_image_info, 1, 4, NULL } };

_mexLocalFunctionTable _local_function_table_getimage
  = { 3, local_function_table_ };

/*
 * The function "mlfNGetimage" contains the nargout interface for the
 * "getimage" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 1-96). This interface
 * is only produced if the M-function uses the special variable "nargout". The
 * nargout interface allows the number of requested outputs to be specified via
 * the nargout argument, as opposed to the normal interface which dynamically
 * calculates the number of outputs based on the number of non-NULL inputs it
 * receives. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfNGetimage(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mgetimage(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfGetimage" contains the normal interface for the "getimage"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getimage.m" (lines
 * 1-96). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfGetimage(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mgetimage(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVGetimage" contains the void interface for the "getimage"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getimage.m" (lines
 * 1-96). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVGetimage(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mgetimage(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxGetimage" contains the feval interface for the "getimage"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getimage.m" (lines
 * 1-96). The feval function calls the implementation version of getimage
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxGetimage(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mgetimage(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfGetimage_findim" contains the normal interface for the
 * "getimage/findim" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 96-162). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfGetimage_findim(mxArray * synthetic_varargin_argument,
                                    ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * him = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    him = Mgetimage_findim(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(him);
}

/*
 * The function "mlxGetimage_findim" contains the feval interface for the
 * "getimage/findim" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 96-162). The feval
 * function calls the implementation version of getimage/findim through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGetimage_findim(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getimage/findim Line: 96 Colu"
            "mn: 1 The function \"getimage/findim\" was called w"
            "ith more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mgetimage_findim(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfGetimage_findim_in_axes" contains the normal interface for
 * the "getimage/findim_in_axes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 162-204). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfGetimage_findim_in_axes(mxArray * axHandle) {
    int nargout = 1;
    mxArray * him = NULL;
    mlfEnterNewContext(0, 1, axHandle);
    him = Mgetimage_findim_in_axes(nargout, axHandle);
    mlfRestorePreviousContext(0, 1, axHandle);
    return mlfReturnValue(him);
}

/*
 * The function "mlxGetimage_findim_in_axes" contains the feval interface for
 * the "getimage/findim_in_axes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 162-204). The feval
 * function calls the implementation version of getimage/findim_in_axes through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxGetimage_findim_in_axes(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getimage/findim_in_axes Line: 162 C"
            "olumn: 1 The function \"getimage/findim_in_axes\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getimage/findim_in_axes Line: 162 C"
            "olumn: 1 The function \"getimage/findim_in_axes\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mgetimage_findim_in_axes(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfGetimage_get_image_info" contains the normal interface for
 * the "getimage/get_image_info" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 204-284). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfGetimage_get_image_info(mxArray * * y,
                                            mxArray * * A,
                                            mxArray * * state,
                                            mxArray * him) {
    int nargout = 1;
    mxArray * x = NULL;
    mxArray * y__ = NULL;
    mxArray * A__ = NULL;
    mxArray * state__ = NULL;
    mlfEnterNewContext(3, 1, y, A, state, him);
    if (y != NULL) {
        ++nargout;
    }
    if (A != NULL) {
        ++nargout;
    }
    if (state != NULL) {
        ++nargout;
    }
    x = Mgetimage_get_image_info(&y__, &A__, &state__, nargout, him);
    mlfRestorePreviousContext(3, 1, y, A, state, him);
    if (y != NULL) {
        mclCopyOutputArg(y, y__);
    } else {
        mxDestroyArray(y__);
    }
    if (A != NULL) {
        mclCopyOutputArg(A, A__);
    } else {
        mxDestroyArray(A__);
    }
    if (state != NULL) {
        mclCopyOutputArg(state, state__);
    } else {
        mxDestroyArray(state__);
    }
    return mlfReturnValue(x);
}

/*
 * The function "mlxGetimage_get_image_info" contains the feval interface for
 * the "getimage/get_image_info" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 204-284). The feval
 * function calls the implementation version of getimage/get_image_info through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxGetimage_get_image_info(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getimage/get_image_info Line: 204 C"
            "olumn: 1 The function \"getimage/get_image_info\" was cal"
            "led with more than the declared number of outputs (4)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: getimage/get_image_info Line: 204 C"
            "olumn: 1 The function \"getimage/get_image_info\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0]
      = Mgetimage_get_image_info(
          &mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Mgetimage" is the implementation version of the "getimage"
 * M-function from file "k:\matlab6p5\toolbox\images\images\getimage.m" (lines
 * 1-96). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = getimage(varargin)
 */
static mxArray * Mgetimage(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getimage);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * msg = NULL;
    mxArray * eid = NULL;
    mxArray * state = NULL;
    mxArray * A = NULL;
    mxArray * y = NULL;
    mxArray * x = NULL;
    mxArray * him = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * %GETIMAGE Get image data from axes.
     * %   A = GETIMAGE(H) returns the first image data contained in
     * %   the Handle Graphics object H.  H can be a figure, axes,
     * %   image, or texture-mapped surface.  A is identical to the
     * %   image CData; it contains the same values and is of the same
     * %   class (uint8, uint16, double, etc.) as the image CData. 
     * %   If H is not an image or does not contain an image or 
     * %   texture-mapped surface, A is empty.
     * %
     * %   [X,Y,A] = GETIMAGE(H) returns the image XData in X and the
     * %   YData in Y. XData and YData are two-element vectors that
     * %   indicate the range of the x-axis and y-axis.
     * %
     * %   [...,A,FLAG] = GETIMAGE(H) returns an integer flag that
     * %   indicates the type of image H contains. FLAG is one of these
     * %   values:
     * %   
     * %       0   not an image; A is returned as an empty matrix
     * %
     * %       1   indexed image
     * %
     * %       2   intensity image with values in standard range ([0,1]
     * %           for double arrays, [0,255] for uint8 arrays,
     * %           [0,65535] for uint16 arrays)
     * %
     * %       3   intensity data, but not in standard range
     * %
     * %       4   RGB image
     * %
     * %   [...] = GETIMAGE returns information for the current axes. It
     * %   is equivalent to [...] = GETIMAGE(GCA).
     * %
     * %   Class Support
     * %   -------------
     * %   The output array A is of the same class as the image
     * %   CData. All other inputs and outputs are of class double.
     * %
     * %   Example
     * %   -------
     * %   After using imshow to display an image directly from a file,
     * %   use GETIMAGE to get the image data into the workspace.
     * %
     * %       imshow rice.tif
     * %       I = getimage;
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.20 $  $Date: 2002/03/15 15:27:24 $
     * 
     * % Subfunctions:
     * % - FINDIM
     * % - GET_IMAGE_INFO
     * 
     * checknargin(0,1,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("getimage"));
    /*
     * him = findim(varargin{:});
     */
    mlfAssign(
      &him,
      mlfGetimage_findim(
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * [x,y,A,state] = get_image_info(him);
     */
    mlfAssign(
      &x, mlfGetimage_get_image_info(&y, &A, &state, mclVv(him, "him")));
    /*
     * 
     * switch nargout
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargout_));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 0
             * % GETIMAGE(...)
             * varargout{1} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(A, "A"));
        /*
         * 
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray1_)) {
            /*
             * % A = GETIMAGE(...)
             * varargout{1} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(A, "A"));
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * % [A,FLAG] = GETIMAGE(...)
             * varargout{1} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(A, "A"));
            /*
             * varargout{2} = state;
             */
            mlfIndexAssign(
              &varargout, "{?}", _mxarray2_, mclVv(state, "state"));
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray3_)) {
            /*
             * % [x,y,A] = GETIMAGE(...)
             * varargout{1} = x;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(x, "x"));
            /*
             * varargout{2} = y;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray2_, mclVv(y, "y"));
            /*
             * varargout{3} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray3_, mclVv(A, "A"));
        /*
         * 
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray4_)) {
            /*
             * % [x,y,A,FLAG] = GETIMAGE(...)
             * varargout{1} = x;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(x, "x"));
            /*
             * varargout{2} = y;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray2_, mclVv(y, "y"));
            /*
             * varargout{3} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray3_, mclVv(A, "A"));
            /*
             * varargout{4} = state;
             */
            mlfIndexAssign(
              &varargout, "{?}", _mxarray4_, mclVv(state, "state"));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * eid = sprintf('Images:%s:tooManyOutputArgs',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray5_, mxCreateString("getimage"), NULL));
            /*
             * msg = 'Too many output arguments.';
             */
            mlfAssign(&msg, _mxarray7_);
            /*
             * error(eid,msg);
             */
            mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(ans);
    mxDestroyArray(him);
    mxDestroyArray(x);
    mxDestroyArray(y);
    mxDestroyArray(A);
    mxDestroyArray(state);
    mxDestroyArray(eid);
    mxDestroyArray(msg);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * %----------------------------------------------------------------------
     * % Local Function: FINDIM
     * %----------------------------------------------------------------------
     */
}

/*
 * The function "Mgetimage_findim" is the implementation version of the
 * "getimage/findim" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 96-162). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function him = findim(varargin)
 */
static mxArray * Mgetimage_findim(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getimage);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * him = NULL;
    mxArray * ans = NULL;
    mxArray * msg = NULL;
    mxArray * eid = NULL;
    mxArray * h = NULL;
    mxArray * axHandle = NULL;
    mxArray * figAxes = NULL;
    mxArray * figHandle = NULL;
    mxArray * rootKids = NULL;
    mclCopyArray(&varargin);
    /*
     * %FINDIM Find image object.
     * %   HIM = FINDIM(H) searches for a valid Handle Graphics Image
     * %   object starting from the handle H and returns its handle in
     * %   HIM. H may be the handle of a Figure, Axes, or Image object.
     * %
     * %   If H is an Image object, FINDIM returns it.
     * %
     * %   If H is an Axes object, FINDIM searches H for Image objects.
     * %   If more than one Image object is found in the Axes, FINDIM
     * %   looks to see if one of the Images is the current object. If
     * %   so, FINDIM returns that Image. Otherwise, FINDIM returns the
     * %   highest Image in the stacking order.
     * %
     * %   If H is a Figure object, FINDIM searches H's current Axes.
     * %
     * %   HIM = FINDIM searchs the current Figure.
     * 
     * him = [];
     */
    mlfAssign(&him, _mxarray9_);
    /*
     * if (nargin == 0)
     */
    if (nargin_ == 0) {
        /*
         * rootKids = get(0,'Children');
         */
        mlfAssign(&rootKids, mlfNGet(1, _mxarray0_, _mxarray10_, NULL));
        /*
         * if (~isempty(rootKids))
         */
        if (mclNotBool(mlfIsempty(mclVv(rootKids, "rootKids")))) {
            /*
             * figHandle = get(0,'CurrentFigure');
             */
            mlfAssign(&figHandle, mlfNGet(1, _mxarray0_, _mxarray12_, NULL));
            /*
             * figAxes = findobj(get(figHandle, 'Children'), 'flat', 'Type', 'axes');
             */
            mlfAssign(
              &figAxes,
              mlfFindobj(
                mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray10_, NULL),
                _mxarray14_,
                _mxarray16_,
                _mxarray18_,
                NULL));
            /*
             * if (~isempty(figAxes))
             */
            if (mclNotBool(mlfIsempty(mclVv(figAxes, "figAxes")))) {
                /*
                 * axHandle = get(figHandle, 'CurrentAxes');
                 */
                mlfAssign(
                  &axHandle,
                  mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray20_, NULL));
                /*
                 * him = findim_in_axes(axHandle);
                 */
                mlfAssign(
                  &him,
                  mlfGetimage_findim_in_axes(mclVv(axHandle, "axHandle")));
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * else
     */
    } else {
        /*
         * % User specified a handle.
         * h = varargin{1};
         */
        mlfAssign(
          &h, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
        /*
         * h = h(1);
         */
        mlfAssign(&h, mclIntArrayRef1(mclVv(h, "h"), 1));
        /*
         * if (~ishandle(h))
         */
        if (mclNotBool(mlfIshandle(mclVv(h, "h")))) {
            /*
             * eid = sprintf('Images:%s:invalidHandleH',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray22_, mxCreateString("getimage"), NULL));
            /*
             * msg = sprintf('%s: Invalid handle H.',upper(mfilename));
             */
            mlfAssign(
              &msg,
              mlfSprintf(
                NULL, _mxarray24_, mlfUpper(mxCreateString("getimage")), NULL));
            /*
             * error(eid,msg);
             */
            mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
        /*
         * end
         */
        }
        /*
         * switch get(varargin{1},'Type')
         */
        {
            mxArray * v_
              = mclInitialize(
                  mlfNGet(
                    1,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                    _mxarray16_,
                    NULL));
            if (mclSwitchCompare(v_, _mxarray26_)) {
                /*
                 * case 'figure'
                 * figHandle = varargin{1};
                 */
                mlfAssign(
                  &figHandle,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
                /*
                 * figAxes = findobj(get(figHandle, 'Children'), 'flat', 'Type', 'axes');
                 */
                mlfAssign(
                  &figAxes,
                  mlfFindobj(
                    mlfNGet(
                      1, mclVv(figHandle, "figHandle"), _mxarray10_, NULL),
                    _mxarray14_,
                    _mxarray16_,
                    _mxarray18_,
                    NULL));
                /*
                 * if (~isempty(figAxes))
                 */
                if (mclNotBool(mlfIsempty(mclVv(figAxes, "figAxes")))) {
                    /*
                     * axHandle = get(figHandle, 'CurrentAxes');
                     */
                    mlfAssign(
                      &axHandle,
                      mlfNGet(
                        1, mclVv(figHandle, "figHandle"), _mxarray20_, NULL));
                    /*
                     * him = findim_in_axes(axHandle);
                     */
                    mlfAssign(
                      &him,
                      mlfGetimage_findim_in_axes(mclVv(axHandle, "axHandle")));
                /*
                 * end
                 */
                }
            /*
             * 
             * case 'axes'
             */
            } else if (mclSwitchCompare(v_, _mxarray18_)) {
                /*
                 * axHandle = varargin{1};
                 */
                mlfAssign(
                  &axHandle,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
                /*
                 * him = findim_in_axes(axHandle);
                 */
                mlfAssign(
                  &him,
                  mlfGetimage_findim_in_axes(mclVv(axHandle, "axHandle")));
            /*
             * 
             * case 'image'
             */
            } else if (mclSwitchCompare(v_, _mxarray28_)) {
                /*
                 * him = h;
                 */
                mlfAssign(&him, mclVv(h, "h"));
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * eid = sprintf('Images:%s:handleHMustBeFigAxesOrImage',mfilename);
                 */
                mlfAssign(
                  &eid,
                  mlfSprintf(
                    NULL, _mxarray30_, mxCreateString("getimage"), NULL));
                /*
                 * msg = sprintf('%s: Input handle H must be a figure, axes, or image.',upper(mfilename));
                 */
                mlfAssign(
                  &msg,
                  mlfSprintf(
                    NULL,
                    _mxarray32_,
                    mlfUpper(mxCreateString("getimage")),
                    NULL));
                /*
                 * error(eid,msg);
                 */
                mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
            /*
             * 
             * end
             */
            }
            mxDestroyArray(v_);
        }
    /*
     * 
     * end
     */
    }
    mclValidateOutput(him, 1, nargout_, "him", "getimage/findim");
    mxDestroyArray(rootKids);
    mxDestroyArray(figHandle);
    mxDestroyArray(figAxes);
    mxDestroyArray(axHandle);
    mxDestroyArray(h);
    mxDestroyArray(eid);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return him;
    /*
     * 
     * %----------------------------------------------------------------------
     * % Local Function: FINDIM_IN_AXES
     * %----------------------------------------------------------------------
     */
}

/*
 * The function "Mgetimage_findim_in_axes" is the implementation version of the
 * "getimage/findim_in_axes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 162-204). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function him = findim_in_axes(axHandle)
 */
static mxArray * Mgetimage_findim_in_axes(int nargout_, mxArray * axHandle) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getimage);
    mxArray * him = NULL;
    mxArray * idx = NULL;
    mxArray * currentObj = NULL;
    mxArray * figHandle = NULL;
    mclCopyArray(&axHandle);
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray34_, NULL));
    /*
     * % If the current object is a texture-mapped surface, use that.
     * currentObj = get(figHandle, 'CurrentObject');
     */
    mlfAssign(
      &currentObj,
      mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray36_, NULL));
    /*
     * if (~isempty(currentObj) & strcmp(get(currentObj,'type'),'surface') & ...
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfIsempty(mclVv(currentObj, "currentObj"))));
        if (mlfTobool(a_)) {
            mlfAssign(
              &a_,
              mclAnd(
                a_,
                mlfStrcmp(
                  mlfNGet(
                    1, mclVv(currentObj, "currentObj"), _mxarray38_, NULL),
                  _mxarray40_)));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfStrcmp(
                     mlfNGet(
                       1, mclVv(currentObj, "currentObj"), _mxarray42_, NULL),
                     _mxarray44_)))) {
            mxDestroyArray(a_);
            /*
             * strcmp(get(currentObj,'FaceColor'),'texturemap'))
             * him = currentObj;
             */
            mlfAssign(&him, mclVv(currentObj, "currentObj"));
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * him = findobj(axHandle, 'Type', 'image');
             */
            mlfAssign(
              &him,
              mlfFindobj(
                mclVa(axHandle, "axHandle"), _mxarray16_, _mxarray28_, NULL));
            /*
             * if (length(him) > 1)
             */
            if (mclLengthInt(mclVv(him, "him")) > 1) {
                /*
                 * % Found more than one image in the axes.
                 * % If one of the images is the current object, use it.
                 * % Otherwise, use the first image in the stacking order.
                 * if (isempty(currentObj))
                 */
                if (mlfTobool(mlfIsempty(mclVv(currentObj, "currentObj")))) {
                    /*
                     * % No current object; use the one on top.
                     * him = him(1);
                     */
                    mlfAssign(&him, mclIntArrayRef1(mclVv(him, "him"), 1));
                /*
                 * else
                 */
                } else {
                    /*
                     * % If the current object is one of the images
                     * % we found, use it.
                     * idx = find(him == currentObj);
                     */
                    mlfAssign(
                      &idx,
                      mlfFind(
                        NULL,
                        NULL,
                        mclEq(
                          mclVv(him, "him"), mclVv(currentObj, "currentObj"))));
                    /*
                     * if (isempty(idx))
                     */
                    if (mlfTobool(mlfIsempty(mclVv(idx, "idx")))) {
                        /*
                         * him = him(1);
                         */
                        mlfAssign(&him, mclIntArrayRef1(mclVv(him, "him"), 1));
                    /*
                     * else
                     */
                    } else {
                        /*
                         * him = him(idx);
                         */
                        mlfAssign(
                          &him,
                          mclArrayRef1(mclVv(him, "him"), mclVv(idx, "idx")));
                    /*
                     * end
                     */
                    }
                /*
                 * end
                 */
                }
            /*
             * end
             */
            }
        }
    /*
     * end
     */
    }
    /*
     * if (isempty(him))
     */
    if (mlfTobool(mlfIsempty(mclVv(him, "him")))) {
        /*
         * % Didn't find an image.  Is there a texturemapped surface we can use?
         * him = findobj(axHandle, 'Type', 'surface', ...
         */
        mlfAssign(
          &him,
          mlfFindobj(
            mclVa(axHandle, "axHandle"),
            _mxarray16_,
            _mxarray40_,
            _mxarray42_,
            _mxarray44_,
            NULL));
        /*
         * 'FaceColor', 'texturemap');
         * if (~isempty(him))
         */
        if (mclNotBool(mlfIsempty(mclVv(him, "him")))) {
            /*
             * him = him(1);
             */
            mlfAssign(&him, mclIntArrayRef1(mclVv(him, "him"), 1));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(him, 1, nargout_, "him", "getimage/findim_in_axes");
    mxDestroyArray(figHandle);
    mxDestroyArray(currentObj);
    mxDestroyArray(idx);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return him;
    /*
     * 
     * 
     * %----------------------------------------------------------------------
     * % Local Function: GET_IMAGE_INFO
     * %----------------------------------------------------------------------
     */
}

/*
 * The function "Mgetimage_get_image_info" is the implementation version of the
 * "getimage/get_image_info" M-function from file
 * "k:\matlab6p5\toolbox\images\images\getimage.m" (lines 204-284). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [x,y,A,state] = get_image_info(him)
 */
static mxArray * Mgetimage_get_image_info(mxArray * * y,
                                          mxArray * * A,
                                          mxArray * * state,
                                          int nargout_,
                                          mxArray * him) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_getimage);
    mxArray * x = NULL;
    mxArray * clim = NULL;
    mxArray * hax = NULL;
    mxArray * N = NULL;
    mxArray * cdatamapping = NULL;
    mxArray * userdata = NULL;
    mclCopyArray(&him);
    /*
     * 
     * if (isempty(him))
     */
    if (mlfTobool(mlfIsempty(mclVa(him, "him")))) {
        /*
         * % We didn't find an image.
         * x = [];
         */
        mlfAssign(&x, _mxarray9_);
        /*
         * y = [];
         */
        mlfAssign(y, _mxarray9_);
        /*
         * A = [];
         */
        mlfAssign(A, _mxarray9_);
        /*
         * state = 0;
         */
        mlfAssign(state, _mxarray0_);
    /*
     * 
     * elseif (strcmp(get(him, 'Type'), 'surface'))
     */
    } else if (mlfTobool(
                 mlfStrcmp(
                   mlfNGet(1, mclVa(him, "him"), _mxarray16_, NULL),
                   _mxarray40_))) {
        /*
         * % We found a texturemapped surface object.
         * A = get(him, 'CData');
         */
        mlfAssign(A, mlfNGet(1, mclVa(him, "him"), _mxarray46_, NULL));
        /*
         * x = get(him, 'XData');
         */
        mlfAssign(&x, mlfNGet(1, mclVa(him, "him"), _mxarray48_, NULL));
        /*
         * y = get(him, 'YData');
         */
        mlfAssign(y, mlfNGet(1, mclVa(him, "him"), _mxarray50_, NULL));
        /*
         * state = 2;
         */
        mlfAssign(state, _mxarray2_);
    /*
     * 
     * else
     */
    } else {
        /*
         * % We did find an image.  Find out about it.
         * userdata = get(him, 'UserData');
         */
        mlfAssign(&userdata, mlfNGet(1, mclVa(him, "him"), _mxarray52_, NULL));
        /*
         * cdatamapping = get(him, 'CDataMapping');
         */
        mlfAssign(
          &cdatamapping, mlfNGet(1, mclVa(him, "him"), _mxarray54_, NULL));
        /*
         * x = get(him, 'XData');
         */
        mlfAssign(&x, mlfNGet(1, mclVa(him, "him"), _mxarray48_, NULL));
        /*
         * y = get(him, 'YData');
         */
        mlfAssign(y, mlfNGet(1, mclVa(him, "him"), _mxarray50_, NULL));
        /*
         * A = get(him, 'CData');
         */
        mlfAssign(A, mlfNGet(1, mclVa(him, "him"), _mxarray46_, NULL));
        /*
         * 
         * if ((ndims(A) == 3) & (size(A,3) == 3))
         */
        {
            mxArray * a_
              = mclInitialize(mclEq(mlfNdims(mclVv(*A, "A")), _mxarray3_));
            if (mlfTobool(a_)
                && mlfTobool(
                     mclAnd(
                       a_,
                       mclEq(
                         mlfSize(
                           mclValueVarargout(), mclVv(*A, "A"), _mxarray3_),
                         _mxarray3_)))) {
                mxDestroyArray(a_);
                /*
                 * % We have an RGB image
                 * state = 4;
                 */
                mlfAssign(state, _mxarray4_);
            /*
             * 
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * % Not an RGB image
                 * 
                 * if (isequal(cdatamapping,'direct'))
                 */
                if (mlfTobool(
                      mlfIsequal(
                        mclVv(cdatamapping, "cdatamapping"),
                        _mxarray56_, NULL))) {
                    /*
                     * % Do we have an indexed image or an old-style intensity
                     * % or scaled image?
                     * 
                     * if (isequal(size(userdata), [1 2]))
                     */
                    if (mlfTobool(
                          mlfIsequal(
                            mlfSize(
                              mclValueVarargout(),
                              mclVv(userdata, "userdata"),
                              NULL),
                            _mxarray58_, NULL))) {
                        /*
                         * % We have an old-style intensity or scaled image.
                         * 
                         * % How long is the colormap?
                         * N = size(get(get(get(him,'Parent'),'Parent'),'Colormap'),1);
                         */
                        mlfAssign(
                          &N,
                          mlfSize(
                            mclValueVarargout(),
                            mlfNGet(
                              1,
                              mlfNGet(
                                1,
                                mlfNGet(
                                  1, mclVa(him, "him"), _mxarray34_, NULL),
                                _mxarray34_,
                                NULL),
                              _mxarray60_,
                              NULL),
                            _mxarray1_));
                        /*
                         * 
                         * if (isequal(userdata, [0 1]))
                         */
                        if (mlfTobool(
                              mlfIsequal(
                                mclVv(userdata, "userdata"),
                                _mxarray62_, NULL))) {
                            /*
                             * % We have an old-style intensity image.
                             * A = (A-1)/(N-1);
                             */
                            mlfAssign(
                              A,
                              mclMrdivide(
                                mclMinus(mclVv(*A, "A"), _mxarray1_),
                                mclMinus(mclVv(N, "N"), _mxarray1_)));
                            /*
                             * state = 2;
                             */
                            mlfAssign(state, _mxarray2_);
                        /*
                         * 
                         * else
                         */
                        } else {
                            /*
                             * % We have an old-style scaled image.
                             * A = (A-1)*((userdata(2)-userdata(1))/(N-1))+userdata(1);
                             */
                            mlfAssign(
                              A,
                              mclPlus(
                                mclMtimes(
                                  mclMinus(mclVv(*A, "A"), _mxarray1_),
                                  mclMrdivide(
                                    mclMinus(
                                      mclIntArrayRef1(
                                        mclVv(userdata, "userdata"), 2),
                                      mclIntArrayRef1(
                                        mclVv(userdata, "userdata"), 1)),
                                    mclMinus(mclVv(N, "N"), _mxarray1_))),
                                mclIntArrayRef1(
                                  mclVv(userdata, "userdata"), 1)));
                            /*
                             * state = 3;
                             */
                            mlfAssign(state, _mxarray3_);
                        /*
                         * 
                         * end
                         */
                        }
                    /*
                     * 
                     * else
                     */
                    } else {
                        /*
                         * % We have an indexed image.
                         * state = 1;
                         */
                        mlfAssign(state, _mxarray1_);
                    /*
                     * 
                     * end
                     */
                    }
                /*
                 * 
                 * else
                 */
                } else {
                    /*
                     * % CDataMapping is 'scaled'
                     * 
                     * hax = get(him, 'Parent');
                     */
                    mlfAssign(
                      &hax, mlfNGet(1, mclVa(him, "him"), _mxarray34_, NULL));
                    /*
                     * clim = get(hax, 'CLim');
                     */
                    mlfAssign(
                      &clim, mlfNGet(1, mclVv(hax, "hax"), _mxarray64_, NULL));
                    /*
                     * if ((isa(A,'double') & isequal(clim,[0 1])) | ...
                     */
                    {
                        mxArray * a_0
                          = mclInitialize(mlfIsa(mclVv(*A, "A"), _mxarray74_));
                        if (mlfTobool(a_0)) {
                            mlfAssign(
                              &a_0,
                              mclAnd(
                                a_0,
                                mlfIsequal(
                                  mclVv(clim, "clim"), _mxarray62_, NULL)));
                        } else {
                            mlfAssign(&a_0, mlfScalar(0));
                        }
                        if (mlfTobool(a_0)) {
                            mlfAssign(&a_0, mlfScalar(1));
                        } else {
                            /*
                             * (isa(A,'uint8') & isequal(clim,[0 255])) | ...
                             */
                            mxArray * b_2
                              = mclInitialize(
                                  mlfIsa(mclVv(*A, "A"), _mxarray68_));
                            if (mlfTobool(b_2)) {
                                mlfAssign(
                                  &b_2,
                                  mclAnd(
                                    b_2,
                                    mlfIsequal(
                                      mclVv(clim, "clim"), _mxarray66_, NULL)));
                            } else {
                                mlfAssign(&b_2, mlfScalar(0));
                            }
                            mlfAssign(&a_0, mclOr(a_0, b_2));
                            mxDestroyArray(b_2);
                        }
                        if (mlfTobool(a_0)) {
                        } else {
                            /*
                             * (isa(A,'uint16') & isequal(clim,[0 65535])))
                             */
                            mxArray * b_
                              = mclInitialize(
                                  mlfIsa(mclVv(*A, "A"), _mxarray72_));
                            if (mlfTobool(b_)) {
                                mlfAssign(
                                  &b_,
                                  mclAnd(
                                    b_,
                                    mlfIsequal(
                                      mclVv(clim, "clim"), _mxarray70_, NULL)));
                            } else {
                                mlfAssign(&b_, mlfScalar(0));
                            }
                            {
                                mxLogical c_0 = mlfTobool(mclOr(a_0, b_));
                                mxDestroyArray(b_);
                                if (c_0) {
                                } else {
                                    goto l0_;
                                }
                            }
                        }
                        mxDestroyArray(a_0);
                        /*
                         * % We have an intensity image.
                         * state = 2;
                         */
                        mlfAssign(state, _mxarray2_);
                        goto return_;
                        l0_:
                        mxDestroyArray(a_0);
                        /*
                         * 
                         * else
                         * % We have a scaled image.
                         * state = 3;
                         */
                        mlfAssign(state, _mxarray3_);
                    }
                /*
                 * 
                 * end
                 * end
                 */
                }
            }
        /*
         * 
         * end
         */
        }
    /*
     * 
     * end
     */
    }
    return_:
    mclValidateOutput(x, 1, nargout_, "x", "getimage/get_image_info");
    mclValidateOutput(*y, 2, nargout_, "y", "getimage/get_image_info");
    mclValidateOutput(*A, 3, nargout_, "A", "getimage/get_image_info");
    mclValidateOutput(*state, 4, nargout_, "state", "getimage/get_image_info");
    mxDestroyArray(userdata);
    mxDestroyArray(cdatamapping);
    mxDestroyArray(N);
    mxDestroyArray(hax);
    mxDestroyArray(clim);
    mxDestroyArray(him);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return x;
}
