/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "makeresampler.h"
#include "mwservices.h"
#include "images_private_resampsep_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;

static mxChar _array4_[28] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ', 'n', 'u',
                               'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray3_;

static mxChar _array8_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray7_;

static mxChar _array10_[9] = { 'p', 'a', 'd', 'm', 'e', 't', 'h', 'o', 'd' };
static mxArray * _mxarray9_;

static mxChar _array12_[11] = { 'i', 'n', 't', 'e', 'r', 'p',
                                'o', 'l', 'a', 'n', 't' };
static mxArray * _mxarray11_;

static mxChar _array14_[5] = { 'n', 'd', 'i', 'm', 's' };
static mxArray * _mxarray13_;

static mxChar _array16_[11] = { 'r', 'e', 's', 'a', 'm', 'p',
                                'l', 'e', 'f', 'c', 'n' };
static mxArray * _mxarray15_;

static mxChar _array18_[10] = { 'c', 'u', 's', 't', 'o',
                                'm', 'd', 'a', 't', 'a' };
static mxArray * _mxarray17_;

static mxArray * _array6_[6] = { NULL /*_mxarray7_*/, NULL /*_mxarray9_*/,
                                 NULL /*_mxarray11_*/, NULL /*_mxarray13_*/,
                                 NULL /*_mxarray15_*/, NULL /*_mxarray17_*/ };
static mxArray * _mxarray5_;
static mxArray * _mxarray19_;

static mxChar _array21_[24] = { 'M', 'i', 's', 's', 'i', 'n', 'g', ' ',
                                0x0027, 'T', 'y', 'p', 'e', 0x0027, ' ', 'p',
                                'r', 'o', 'p', 'e', 'r', 't', 'y', '.' };
static mxArray * _mxarray20_;

static mxChar _array23_[9] = { 's', 'e', 'p', 'a', 'r', 'a', 'b', 'l', 'e' };
static mxArray * _mxarray22_;

static mxChar _array25_[6] = { 'c', 'u', 's', 't', 'o', 'm' };
static mxArray * _mxarray24_;

static mxChar _array27_[55] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 0x0027,
                                'T', 'y', 'p', 'e', 0x0027, ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 0x0027, 's',
                                'e', 'p', 'a', 'r', 'a', 'b', 'l', 'e',
                                0x0027, ' ', 'o', 'r', ' ', 0x0027, 'c',
                                'u', 's', 't', 'o', 'm', 0x0027, '.' };
static mxArray * _mxarray26_;

static mxChar _array29_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray28_;

static mxArray * _array31_[2] = { NULL /*_mxarray22_*/, NULL /*_mxarray24_*/ };
static mxArray * _mxarray30_;

static mxChar _array33_[6] = { 'C', 'u', 's', 't', 'o', 'm' };
static mxArray * _mxarray32_;

static mxArray * _array35_[5] = { NULL /*_mxarray7_*/, NULL /*_mxarray9_*/,
                                  NULL /*_mxarray13_*/, NULL /*_mxarray15_*/,
                                  NULL /*_mxarray17_*/ };
static mxArray * _mxarray34_;

static mxChar _array37_[9] = { 'r', 'e', 'p', 'l', 'i', 'c', 'a', 't', 'e' };
static mxArray * _mxarray36_;

static mxChar _array39_[9] = { 'P', 'a', 'd', 'M', 'e', 't', 'h', 'o', 'd' };
static mxArray * _mxarray38_;

static mxChar _array43_[4] = { 'f', 'i', 'l', 'l' };
static mxArray * _mxarray42_;

static mxChar _array45_[5] = { 'b', 'o', 'u', 'n', 'd' };
static mxArray * _mxarray44_;

static mxChar _array47_[8] = { 'c', 'i', 'r', 'c', 'u', 'l', 'a', 'r' };
static mxArray * _mxarray46_;

static mxChar _array49_[9] = { 's', 'y', 'm', 'm', 'e', 't', 'r', 'i', 'c' };
static mxArray * _mxarray48_;

static mxArray * _array41_[5] = { NULL /*_mxarray42_*/, NULL /*_mxarray44_*/,
                                  NULL /*_mxarray36_*/, NULL /*_mxarray46_*/,
                                  NULL /*_mxarray48_*/ };
static mxArray * _mxarray40_;

static mxChar _array51_[39] = { 'T', 'h', 'e', ' ', 0x0027, 'N', 'D', 'i',
                                'm', 's', 0x0027, ' ', 'p', 'r', 'o', 'p',
                                'e', 'r', 't', 'y', ' ', 'm', 'u', 's',
                                't', ' ', 'b', 'e', ' ', 's', 'p', 'e',
                                'c', 'i', 'f', 'i', 'e', 'd', '.' };
static mxArray * _mxarray50_;

static mxChar _array53_[33] = { 0x0027, 'N', 'D', 'i', 'm', 's', 0x0027,
                                ' ', 'm', 'u', 's', 't', ' ', 'h', 'a', 'v',
                                'e', ' ', 'a', ' ', 's', 'c', 'a', 'l', 'a',
                                'r', ' ', 'v', 'a', 'l', 'u', 'e', '.' };
static mxArray * _mxarray52_;

static mxChar _array55_[38] = { 0x0027, 'N', 'D', 'i', 'm', 's', 0x0027,
                                ' ', 'm', 'u', 's', 't', ' ', 'h', 'a',
                                'v', 'e', ' ', 'n', 'u', 'm', 'e', 'r',
                                'i', 'c', ',', ' ', 'r', 'e', 'a', 'l',
                                ' ', 'v', 'a', 'l', 'u', 'e', '.' };
static mxArray * _mxarray54_;

static mxChar _array57_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray56_;

static mxChar _array59_[43] = { 0x0027, 'N', 'D', 'i', 'm', 's', 0x0027, ' ',
                                'm', 'u', 's', 't', ' ', 'h', 'a', 'v', 'e',
                                ' ', 'a', ' ', 'p', 'o', 's', 'i', 't', 'i',
                                'v', 'e', ' ', 'i', 'n', 't', 'e', 'g', 'e',
                                'r', ' ', 'v', 'a', 'l', 'u', 'e', '.' };
static mxArray * _mxarray58_;

static mxChar _array61_[45] = { 'T', 'h', 'e', ' ', 0x0027, 'R', 'e', 's', 'a',
                                'm', 'p', 'l', 'e', 'F', 'c', 'n', 0x0027, ' ',
                                'p', 'r', 'o', 'p', 'e', 'r', 't', 'y', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 's',
                                'p', 'e', 'c', 'i', 'f', 'i', 'e', 'd', '.' };
static mxArray * _mxarray60_;

static mxChar _array63_[39] = { 0x0027, 'R', 'e', 's', 'a', 'm', 'p', 'l',
                                'e', 'F', 'c', 'n', 0x0027, ' ', 'm', 'u',
                                's', 't', ' ', 'h', 'a', 'v', 'e', ' ',
                                'a', ' ', 's', 'c', 'a', 'l', 'a', 'r',
                                ' ', 'v', 'a', 'l', 'u', 'e', '.' };
static mxArray * _mxarray62_;

static mxChar _array65_[15] = { 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                '_', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray64_;

static mxChar _array67_[46] = { 0x0027, 'R', 'e', 's', 'a', 'm', 'p',
                                'l', 'e', 'F', 'c', 'n', 0x0027, ' ',
                                'm', 'u', 's', 't', ' ', 'h', 'a', 'v',
                                'e', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', 'h', 'a', 'n', 'd', 'l',
                                'e', ' ', 'v', 'a', 'l', 'u', 'e', '.' };
static mxArray * _mxarray66_;

static mxChar _array69_[9] = { 'S', 'e', 'p', 'a', 'r', 'a', 'b', 'l', 'e' };
static mxArray * _mxarray68_;

static mxArray * _array71_[3] = { NULL /*_mxarray7_*/, NULL /*_mxarray11_*/,
                                  NULL /*_mxarray9_*/ };
static mxArray * _mxarray70_;

static mxChar _array73_[6] = { 'l', 'i', 'n', 'e', 'a', 'r' };
static mxArray * _mxarray72_;
static mxArray * _mxarray74_;
static double _ieee_plusinf_;
static mxArray * _mxarray75_;

static mxChar _array77_[4] = { 'c', 'e', 'l', 'l' };
static mxArray * _mxarray76_;
static mxArray * _mxarray78_;

static mxChar _array80_[11] = { 'I', 'n', 't', 'e', 'r', 'p',
                                'o', 'l', 'a', 'n', 't' };
static mxArray * _mxarray79_;

static mxChar _array84_[7] = { 'n', 'e', 'a', 'r', 'e', 's', 't' };
static mxArray * _mxarray83_;

static mxChar _array86_[5] = { 'c', 'u', 'b', 'i', 'c' };
static mxArray * _mxarray85_;

static mxArray * _array82_[3] = { NULL /*_mxarray83_*/, NULL /*_mxarray72_*/,
                                  NULL /*_mxarray85_*/ };
static mxArray * _mxarray81_;

static mxChar _array88_[68] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'I', 'N',
                                'T', 'E', 'R', 'P', 'O', 'L', 'A', 'N', 'T',
                                ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                0x0027, 'n', 'e', 'a', 'r', 'e', 's', 't',
                                0x0027, ',', ' ', 0x0027, 'l', 'i', 'n', 'e',
                                'a', 'r', 0x0027, ',', ' ', 'o', 'r', ' ',
                                0x0027, 'c', 'u', 'b', 'i', 'c', 0x0027, '.' };
static mxArray * _mxarray87_;

static mxChar _array90_[33] = { 'k', 'e', 'r', 'n', 'e', 'l', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'a', ' ', 'f',
                                'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', 'h',
                                'a', 'n', 'd', 'l', 'e', '.' };
static mxArray * _mxarray89_;
static mxArray * _mxarray91_;
static mxArray * _mxarray92_;
static mxArray * _mxarray93_;
static mxArray * _mxarray94_;

static mxChar _array96_[24] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u',
                                's', ' ', 'p', 'r', 'o', 'p', 'e', 'r',
                                't', 'y', ' ', 'n', 'a', 'm', 'e', ' ' };
static mxArray * _mxarray95_;

static mxChar _array98_[1] = { '.' };
static mxArray * _mxarray97_;

static mxChar _array100_[16] = { 'E', 'm', 'p', 't', 'y', ' ', 'v', 'a',
                                 'l', 'u', 'e', ' ', 'f', 'o', 'r', ' ' };
static mxArray * _mxarray99_;

static mxChar _array102_[9] = { 'P', 'r', 'o', 'p', 'e', 'r', 't', 'y', ' ' };
static mxArray * _mxarray101_;

static mxChar _array104_[29] = { ' ', 'i', 's', ' ', 's', 'p', 'e', 'c',
                                 'i', 'f', 'i', 'e', 'd', ' ', 'm', 'o',
                                 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                 'o', 'n', 'c', 'e', '.' };
static mxArray * _mxarray103_;

static mxChar _array106_[18] = { ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                 'a', ' ', 's', 't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray105_;

static mxChar _array108_[13] = { 'U', 'n', 'r', 'e', 'c', 'o', 'g',
                                 'n', 'i', 'z', 'e', 'd', ' ' };
static mxArray * _mxarray107_;

static mxChar _array110_[1] = { ' ' };
static mxArray * _mxarray109_;

static mxChar _array112_[10] = { 'A', 'm', 'b', 'i', 'g',
                                 'u', 'o', 'u', 's', ' ' };
static mxArray * _mxarray111_;

static mxChar _array114_[14] = { 'P', 'r', 'o', 'p', 'e', 'r', 't',
                                 'y', ' ', 'n', 'a', 'm', 'e', ' ' };
static mxArray * _mxarray113_;

static mxChar _array116_[19] = { ' ', 'i', 'g', 'n', 'o', 'r', 'e',
                                 'd', ' ', 'w', 'i', 't', 'h', ' ',
                                 't', 'y', 'p', 'e', ' ' };
static mxArray * _mxarray115_;

static mxChar _array118_[28] = { 'N', 'o', 'n', '-', 'c', 'h', 'a',
                                 'r', 'a', 'c', 't', 'e', 'r', ' ',
                                 'p', 'r', 'o', 'p', 'e', 'r', 't',
                                 'y', ' ', 'n', 'a', 'm', 'e', '.' };
static mxArray * _mxarray117_;

void InitializeModule_makeresampler(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeDouble(10.0);
    _mxarray2_ = mclInitializeDouble(0.0);
    _mxarray3_ = mclInitializeString(28, _array4_);
    _mxarray7_ = mclInitializeString(4, _array8_);
    _array6_[0] = _mxarray7_;
    _mxarray9_ = mclInitializeString(9, _array10_);
    _array6_[1] = _mxarray9_;
    _mxarray11_ = mclInitializeString(11, _array12_);
    _array6_[2] = _mxarray11_;
    _mxarray13_ = mclInitializeString(5, _array14_);
    _array6_[3] = _mxarray13_;
    _mxarray15_ = mclInitializeString(11, _array16_);
    _array6_[4] = _mxarray15_;
    _mxarray17_ = mclInitializeString(10, _array18_);
    _array6_[5] = _mxarray17_;
    _mxarray5_ = mclInitializeCellVector(1, 6, _array6_);
    _mxarray19_ = mclInitializeDouble(1.0);
    _mxarray20_ = mclInitializeString(24, _array21_);
    _mxarray22_ = mclInitializeString(9, _array23_);
    _mxarray24_ = mclInitializeString(6, _array25_);
    _mxarray26_ = mclInitializeString(55, _array27_);
    _mxarray28_ = mclInitializeString(4, _array29_);
    _array31_[0] = _mxarray22_;
    _array31_[1] = _mxarray24_;
    _mxarray30_ = mclInitializeCellVector(1, 2, _array31_);
    _mxarray32_ = mclInitializeString(6, _array33_);
    _array35_[0] = _mxarray7_;
    _array35_[1] = _mxarray9_;
    _array35_[2] = _mxarray13_;
    _array35_[3] = _mxarray15_;
    _array35_[4] = _mxarray17_;
    _mxarray34_ = mclInitializeCellVector(1, 5, _array35_);
    _mxarray36_ = mclInitializeString(9, _array37_);
    _mxarray38_ = mclInitializeString(9, _array39_);
    _mxarray42_ = mclInitializeString(4, _array43_);
    _array41_[0] = _mxarray42_;
    _mxarray44_ = mclInitializeString(5, _array45_);
    _array41_[1] = _mxarray44_;
    _array41_[2] = _mxarray36_;
    _mxarray46_ = mclInitializeString(8, _array47_);
    _array41_[3] = _mxarray46_;
    _mxarray48_ = mclInitializeString(9, _array49_);
    _array41_[4] = _mxarray48_;
    _mxarray40_ = mclInitializeCellVector(1, 5, _array41_);
    _mxarray50_ = mclInitializeString(39, _array51_);
    _mxarray52_ = mclInitializeString(33, _array53_);
    _mxarray54_ = mclInitializeString(38, _array55_);
    _mxarray56_ = mclInitializeString(6, _array57_);
    _mxarray58_ = mclInitializeString(43, _array59_);
    _mxarray60_ = mclInitializeString(45, _array61_);
    _mxarray62_ = mclInitializeString(39, _array63_);
    _mxarray64_ = mclInitializeString(15, _array65_);
    _mxarray66_ = mclInitializeString(46, _array67_);
    _mxarray68_ = mclInitializeString(9, _array69_);
    _array71_[0] = _mxarray7_;
    _array71_[1] = _mxarray11_;
    _array71_[2] = _mxarray9_;
    _mxarray70_ = mclInitializeCellVector(1, 3, _array71_);
    _mxarray72_ = mclInitializeString(6, _array73_);
    _mxarray74_ = mclInitializeDouble(1000.0);
    _ieee_plusinf_ = mclGetInf();
    _mxarray75_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray76_ = mclInitializeString(4, _array77_);
    _mxarray78_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray79_ = mclInitializeString(11, _array80_);
    _mxarray83_ = mclInitializeString(7, _array84_);
    _array82_[0] = _mxarray83_;
    _array82_[1] = _mxarray72_;
    _mxarray85_ = mclInitializeString(5, _array86_);
    _array82_[2] = _mxarray85_;
    _mxarray81_ = mclInitializeCellVector(1, 3, _array82_);
    _mxarray87_ = mclInitializeString(68, _array88_);
    _mxarray89_ = mclInitializeString(33, _array90_);
    _mxarray91_ = mclInitializeDouble(1.5);
    _mxarray92_ = mclInitializeDouble(2.5);
    _mxarray93_ = mclInitializeDouble(-.5);
    _mxarray94_ = mclInitializeDouble(4.0);
    _mxarray95_ = mclInitializeString(24, _array96_);
    _mxarray97_ = mclInitializeString(1, _array98_);
    _mxarray99_ = mclInitializeString(16, _array100_);
    _mxarray101_ = mclInitializeString(9, _array102_);
    _mxarray103_ = mclInitializeString(29, _array104_);
    _mxarray105_ = mclInitializeString(18, _array106_);
    _mxarray107_ = mclInitializeString(13, _array108_);
    _mxarray109_ = mclInitializeString(1, _array110_);
    _mxarray111_ = mclInitializeString(10, _array112_);
    _mxarray113_ = mclInitializeString(14, _array114_);
    _mxarray115_ = mclInitializeString(19, _array116_);
    _mxarray117_ = mclInitializeString(28, _array118_);
}

void TerminateModule_makeresampler(void) {
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray115_);
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfMakeresampler_MakeCustom(mxArray * property_strings, ...);
static void mlxMakeresampler_MakeCustom(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfMakeresampler_ParseSeparable(mxArray * * padmethod,
                                                 mxArray * property_strings,
                                                 ...);
static void mlxMakeresampler_ParseSeparable(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static mxArray * mlfMakeresampler_MakeSeparable(mxArray * interpolant,
                                                mxArray * padmethod);
static void mlxMakeresampler_MakeSeparable(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * mlfMakeresampler_HasCustomTable(mxArray * interpolant);
static void mlxMakeresampler_HasCustomTable(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static mxArray * mlfMakeresampler_HasCustomFunction(mxArray * interpolant);
static void mlxMakeresampler_HasCustomFunction(int nlhs,
                                               mxArray * plhs[],
                                               int nrhs,
                                               mxArray * prhs[]);
static mxArray * mlfMakeresampler_MultipleKernels(mxArray * interpolant,
                                                  mxArray * frequency);
static void mlxMakeresampler_MultipleKernels(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static mxArray * mlfMakeresampler_CustomKernel(mxArray * interpolant,
                                               mxArray * frequency);
static void mlxMakeresampler_CustomKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMakeresampler_StandardKernel(mxArray * interpolant,
                                                 mxArray * frequency);
static void mlxMakeresampler_StandardKernel(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static mxArray * mlfMakeresampler_SampleKernel(mxArray * kernel,
                                               mxArray * halfwidth,
                                               mxArray * frequency);
static void mlxMakeresampler_SampleKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMakeresampler_LinearKernel(mxArray * x);
static void mlxMakeresampler_LinearKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfMakeresampler_CubicKernel(mxArray * x);
static void mlxMakeresampler_CubicKernel(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfMakeresampler_AssignResampler(mxArray * n_dimensions,
                                                  mxArray * padmethod,
                                                  mxArray * resamp_fcn,
                                                  mxArray * rdata);
static void mlxMakeresampler_AssignResampler(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static mxArray * mlfMakeresampler_FindValue(mxArray * property_name,
                                            mxArray * property_strings,
                                            ...);
static void mlxMakeresampler_FindValue(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfMakeresampler_GetCanonicalString(mxArray * input_string,
                                                     mxArray * property_name,
                                                     mxArray * canonical_strings);
static void mlxMakeresampler_GetCanonicalString(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]);
static void mlfMakeresampler_CheckPropertyNames(mxArray * type,
                                                mxArray * valid_property_names,
                                                ...);
static void mlxMakeresampler_CheckPropertyNames(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]);
static mxArray * Mmakeresampler(int nargout_, mxArray * varargin);
static mxArray * Mmakeresampler_MakeCustom(int nargout_,
                                           mxArray * property_strings,
                                           mxArray * varargin);
static mxArray * Mmakeresampler_ParseSeparable(mxArray * * padmethod,
                                               int nargout_,
                                               mxArray * property_strings,
                                               mxArray * varargin);
static mxArray * Mmakeresampler_MakeSeparable(int nargout_,
                                              mxArray * interpolant,
                                              mxArray * padmethod);
static mxArray * Mmakeresampler_HasCustomTable(int nargout_,
                                               mxArray * interpolant);
static mxArray * Mmakeresampler_HasCustomFunction(int nargout_,
                                                  mxArray * interpolant);
static mxArray * Mmakeresampler_MultipleKernels(int nargout_,
                                                mxArray * interpolant,
                                                mxArray * frequency);
static mxArray * Mmakeresampler_CustomKernel(int nargout_,
                                             mxArray * interpolant,
                                             mxArray * frequency);
static mxArray * Mmakeresampler_StandardKernel(int nargout_,
                                               mxArray * interpolant,
                                               mxArray * frequency);
static mxArray * Mmakeresampler_SampleKernel(int nargout_,
                                             mxArray * kernel,
                                             mxArray * halfwidth,
                                             mxArray * frequency);
static mxArray * Mmakeresampler_LinearKernel(int nargout_, mxArray * x);
static mxArray * Mmakeresampler_CubicKernel(int nargout_, mxArray * x);
static mxArray * Mmakeresampler_AssignResampler(int nargout_,
                                                mxArray * n_dimensions,
                                                mxArray * padmethod,
                                                mxArray * resamp_fcn,
                                                mxArray * rdata);
static mxArray * Mmakeresampler_FindValue(int nargout_,
                                          mxArray * property_name,
                                          mxArray * property_strings,
                                          mxArray * varargin);
static mxArray * Mmakeresampler_GetCanonicalString(int nargout_,
                                                   mxArray * input_string,
                                                   mxArray * property_name,
                                                   mxArray * canonical_strings);
static void Mmakeresampler_CheckPropertyNames(mxArray * type,
                                              mxArray * valid_property_names,
                                              mxArray * varargin);

static mexFunctionTableEntry local_function_table_[15]
  = { { "MakeCustom", mlxMakeresampler_MakeCustom, -2, 1, NULL },
      { "ParseSeparable", mlxMakeresampler_ParseSeparable, -2, 2, NULL },
      { "MakeSeparable", mlxMakeresampler_MakeSeparable, 2, 1, NULL },
      { "HasCustomTable", mlxMakeresampler_HasCustomTable, 1, 1, NULL },
      { "HasCustomFunction", mlxMakeresampler_HasCustomFunction, 1, 1, NULL },
      { "MultipleKernels", mlxMakeresampler_MultipleKernels, 2, 1, NULL },
      { "CustomKernel", mlxMakeresampler_CustomKernel, 2, 1, NULL },
      { "StandardKernel", mlxMakeresampler_StandardKernel, 2, 1, NULL },
      { "SampleKernel", mlxMakeresampler_SampleKernel, 3, 1, NULL },
      { "LinearKernel", mlxMakeresampler_LinearKernel, 1, 1, NULL },
      { "CubicKernel", mlxMakeresampler_CubicKernel, 1, 1, NULL },
      { "AssignResampler", mlxMakeresampler_AssignResampler, 4, 1, NULL },
      { "FindValue", mlxMakeresampler_FindValue, -3, 1, NULL },
      { "GetCanonicalString",
        mlxMakeresampler_GetCanonicalString, 3, 1, NULL },
      { "CheckPropertyNames",
        mlxMakeresampler_CheckPropertyNames, -3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_makeresampler
  = { 15, local_function_table_ };

/*
 * The function "mlfMakeresampler" contains the normal interface for the
 * "makeresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 1-179). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfMakeresampler(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * r = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    r = Mmakeresampler(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(r);
}

/*
 * The function "mlxMakeresampler" contains the feval interface for the
 * "makeresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 1-179). The
 * feval function calls the implementation version of makeresampler through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxMakeresampler(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler Line: 1 Column"
            ": 1 The function \"makeresampler\" was called with"
            " more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mmakeresampler(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfMakeresampler_MakeCustom" contains the normal interface for
 * the "makeresampler/MakeCustom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 179-222). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_MakeCustom(mxArray * property_strings, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * r = NULL;
    mlfVarargin(&varargin, property_strings, 0);
    mlfEnterNewContext(0, -2, property_strings, varargin);
    r = Mmakeresampler_MakeCustom(nargout, property_strings, varargin);
    mlfRestorePreviousContext(0, 1, property_strings);
    mxDestroyArray(varargin);
    return mlfReturnValue(r);
}

/*
 * The function "mlxMakeresampler_MakeCustom" contains the feval interface for
 * the "makeresampler/MakeCustom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 179-222). The
 * feval function calls the implementation version of makeresampler/MakeCustom
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMakeresampler_MakeCustom(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/MakeCustom Line: 179 C"
            "olumn: 1 The function \"makeresampler/MakeCustom\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0] = Mmakeresampler_MakeCustom(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "mlfMakeresampler_ParseSeparable" contains the normal interface
 * for the "makeresampler/ParseSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 222-239). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_ParseSeparable(mxArray * * padmethod,
                                                 mxArray * property_strings,
                                                 ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * interpolant = NULL;
    mxArray * padmethod__ = NULL;
    mlfVarargin(&varargin, property_strings, 0);
    mlfEnterNewContext(1, -2, padmethod, property_strings, varargin);
    if (padmethod != NULL) {
        ++nargout;
    }
    interpolant
      = Mmakeresampler_ParseSeparable(
          &padmethod__, nargout, property_strings, varargin);
    mlfRestorePreviousContext(1, 1, padmethod, property_strings);
    mxDestroyArray(varargin);
    if (padmethod != NULL) {
        mclCopyOutputArg(padmethod, padmethod__);
    } else {
        mxDestroyArray(padmethod__);
    }
    return mlfReturnValue(interpolant);
}

/*
 * The function "mlxMakeresampler_ParseSeparable" contains the feval interface
 * for the "makeresampler/ParseSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 222-239). The
 * feval function calls the implementation version of
 * makeresampler/ParseSeparable through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_ParseSeparable(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/ParseSeparable Line: 222"
            " Column: 1 The function \"makeresampler/ParseSeparable\" was"
            " called with more than the declared number of outputs (2)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0]
      = Mmakeresampler_ParseSeparable(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "mlfMakeresampler_MakeSeparable" contains the normal interface
 * for the "makeresampler/MakeSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 239-264). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_MakeSeparable(mxArray * interpolant,
                                                mxArray * padmethod) {
    int nargout = 1;
    mxArray * r = NULL;
    mlfEnterNewContext(0, 2, interpolant, padmethod);
    r = Mmakeresampler_MakeSeparable(nargout, interpolant, padmethod);
    mlfRestorePreviousContext(0, 2, interpolant, padmethod);
    return mlfReturnValue(r);
}

/*
 * The function "mlxMakeresampler_MakeSeparable" contains the feval interface
 * for the "makeresampler/MakeSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 239-264). The
 * feval function calls the implementation version of
 * makeresampler/MakeSeparable through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_MakeSeparable(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/MakeSeparable Line: 239 "
            "Column: 1 The function \"makeresampler/MakeSeparable\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/MakeSeparable Line: 239"
            " Column: 1 The function \"makeresampler/MakeSeparable\" was"
            " called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmakeresampler_MakeSeparable(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_HasCustomTable" contains the normal interface
 * for the "makeresampler/HasCustomTable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 264-286). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_HasCustomTable(mxArray * interpolant) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, interpolant);
    q = Mmakeresampler_HasCustomTable(nargout, interpolant);
    mlfRestorePreviousContext(0, 1, interpolant);
    return mlfReturnValue(q);
}

/*
 * The function "mlxMakeresampler_HasCustomTable" contains the feval interface
 * for the "makeresampler/HasCustomTable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 264-286). The
 * feval function calls the implementation version of
 * makeresampler/HasCustomTable through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_HasCustomTable(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/HasCustomTable Line: 264"
            " Column: 1 The function \"makeresampler/HasCustomTable\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/HasCustomTable Line: 264"
            " Column: 1 The function \"makeresampler/HasCustomTable\" was"
            " called with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmakeresampler_HasCustomTable(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_HasCustomFunction" contains the normal
 * interface for the "makeresampler/HasCustomFunction" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 286-307). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_HasCustomFunction(mxArray * interpolant) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, interpolant);
    q = Mmakeresampler_HasCustomFunction(nargout, interpolant);
    mlfRestorePreviousContext(0, 1, interpolant);
    return mlfReturnValue(q);
}

/*
 * The function "mlxMakeresampler_HasCustomFunction" contains the feval
 * interface for the "makeresampler/HasCustomFunction" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 286-307). The
 * feval function calls the implementation version of
 * makeresampler/HasCustomFunction through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxMakeresampler_HasCustomFunction(int nlhs,
                                               mxArray * plhs[],
                                               int nrhs,
                                               mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/HasCustomFunction Line: 28"
            "6 Column: 1 The function \"makeresampler/HasCustomFunction\" w"
            "as called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/HasCustomFunction Line: 28"
            "6 Column: 1 The function \"makeresampler/HasCustomFunction\" w"
            "as called with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmakeresampler_HasCustomFunction(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_MultipleKernels" contains the normal
 * interface for the "makeresampler/MultipleKernels" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 307-321). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_MultipleKernels(mxArray * interpolant,
                                                  mxArray * frequency) {
    int nargout = 1;
    mxArray * K = NULL;
    mlfEnterNewContext(0, 2, interpolant, frequency);
    K = Mmakeresampler_MultipleKernels(nargout, interpolant, frequency);
    mlfRestorePreviousContext(0, 2, interpolant, frequency);
    return mlfReturnValue(K);
}

/*
 * The function "mlxMakeresampler_MultipleKernels" contains the feval interface
 * for the "makeresampler/MultipleKernels" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 307-321). The
 * feval function calls the implementation version of
 * makeresampler/MultipleKernels through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_MultipleKernels(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/MultipleKernels Line: 307"
            " Column: 1 The function \"makeresampler/MultipleKernels\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/MultipleKernels Line: 307"
            " Column: 1 The function \"makeresampler/MultipleKernels\" was"
            " called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmakeresampler_MultipleKernels(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_CustomKernel" contains the normal interface
 * for the "makeresampler/CustomKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 321-330). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_CustomKernel(mxArray * interpolant,
                                               mxArray * frequency) {
    int nargout = 1;
    mxArray * K = NULL;
    mlfEnterNewContext(0, 2, interpolant, frequency);
    K = Mmakeresampler_CustomKernel(nargout, interpolant, frequency);
    mlfRestorePreviousContext(0, 2, interpolant, frequency);
    return mlfReturnValue(K);
}

/*
 * The function "mlxMakeresampler_CustomKernel" contains the feval interface
 * for the "makeresampler/CustomKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 321-330). The
 * feval function calls the implementation version of
 * makeresampler/CustomKernel through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_CustomKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/CustomKernel Line: 321 "
            "Column: 1 The function \"makeresampler/CustomKernel\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/CustomKernel Line: 321 "
            "Column: 1 The function \"makeresampler/CustomKernel\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmakeresampler_CustomKernel(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_StandardKernel" contains the normal interface
 * for the "makeresampler/StandardKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 330-354). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_StandardKernel(mxArray * interpolant,
                                                 mxArray * frequency) {
    int nargout = 1;
    mxArray * K = NULL;
    mlfEnterNewContext(0, 2, interpolant, frequency);
    K = Mmakeresampler_StandardKernel(nargout, interpolant, frequency);
    mlfRestorePreviousContext(0, 2, interpolant, frequency);
    return mlfReturnValue(K);
}

/*
 * The function "mlxMakeresampler_StandardKernel" contains the feval interface
 * for the "makeresampler/StandardKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 330-354). The
 * feval function calls the implementation version of
 * makeresampler/StandardKernel through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_StandardKernel(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/StandardKernel Line: 330"
            " Column: 1 The function \"makeresampler/StandardKernel\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/StandardKernel Line: 330"
            " Column: 1 The function \"makeresampler/StandardKernel\" was"
            " called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmakeresampler_StandardKernel(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_SampleKernel" contains the normal interface
 * for the "makeresampler/SampleKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 354-364). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_SampleKernel(mxArray * kernel,
                                               mxArray * halfwidth,
                                               mxArray * frequency) {
    int nargout = 1;
    mxArray * positiveHalf = NULL;
    mlfEnterNewContext(0, 3, kernel, halfwidth, frequency);
    positiveHalf
      = Mmakeresampler_SampleKernel(nargout, kernel, halfwidth, frequency);
    mlfRestorePreviousContext(0, 3, kernel, halfwidth, frequency);
    return mlfReturnValue(positiveHalf);
}

/*
 * The function "mlxMakeresampler_SampleKernel" contains the feval interface
 * for the "makeresampler/SampleKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 354-364). The
 * feval function calls the implementation version of
 * makeresampler/SampleKernel through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_SampleKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/SampleKernel Line: 354 "
            "Column: 1 The function \"makeresampler/SampleKernel\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/SampleKernel Line: 354 "
            "Column: 1 The function \"makeresampler/SampleKernel\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mmakeresampler_SampleKernel(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_LinearKernel" contains the normal interface
 * for the "makeresampler/LinearKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 364-374). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_LinearKernel(mxArray * x) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 1, x);
    y = Mmakeresampler_LinearKernel(nargout, x);
    mlfRestorePreviousContext(0, 1, x);
    return mlfReturnValue(y);
}

/*
 * The function "mlxMakeresampler_LinearKernel" contains the feval interface
 * for the "makeresampler/LinearKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 364-374). The
 * feval function calls the implementation version of
 * makeresampler/LinearKernel through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_LinearKernel(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/LinearKernel Line: 364 "
            "Column: 1 The function \"makeresampler/LinearKernel\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/LinearKernel Line: 364 "
            "Column: 1 The function \"makeresampler/LinearKernel\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmakeresampler_LinearKernel(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_CubicKernel" contains the normal interface
 * for the "makeresampler/CubicKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 374-394). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_CubicKernel(mxArray * x) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 1, x);
    y = Mmakeresampler_CubicKernel(nargout, x);
    mlfRestorePreviousContext(0, 1, x);
    return mlfReturnValue(y);
}

/*
 * The function "mlxMakeresampler_CubicKernel" contains the feval interface for
 * the "makeresampler/CubicKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 374-394). The
 * feval function calls the implementation version of makeresampler/CubicKernel
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMakeresampler_CubicKernel(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/CubicKernel Line: 374 "
            "Column: 1 The function \"makeresampler/CubicKernel\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/CubicKernel Line: 374 "
            "Column: 1 The function \"makeresampler/CubicKernel\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mmakeresampler_CubicKernel(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_AssignResampler" contains the normal
 * interface for the "makeresampler/AssignResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 394-408). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_AssignResampler(mxArray * n_dimensions,
                                                  mxArray * padmethod,
                                                  mxArray * resamp_fcn,
                                                  mxArray * rdata) {
    int nargout = 1;
    mxArray * r = NULL;
    mlfEnterNewContext(0, 4, n_dimensions, padmethod, resamp_fcn, rdata);
    r
      = Mmakeresampler_AssignResampler(
          nargout, n_dimensions, padmethod, resamp_fcn, rdata);
    mlfRestorePreviousContext(0, 4, n_dimensions, padmethod, resamp_fcn, rdata);
    return mlfReturnValue(r);
}

/*
 * The function "mlxMakeresampler_AssignResampler" contains the feval interface
 * for the "makeresampler/AssignResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 394-408). The
 * feval function calls the implementation version of
 * makeresampler/AssignResampler through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxMakeresampler_AssignResampler(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/AssignResampler Line: 394"
            " Column: 1 The function \"makeresampler/AssignResampler\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/AssignResampler Line: 394"
            " Column: 1 The function \"makeresampler/AssignResampler\" was"
            " called with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mmakeresampler_AssignResampler(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_FindValue" contains the normal interface for
 * the "makeresampler/FindValue" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 408-437). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_FindValue(mxArray * property_name,
                                            mxArray * property_strings,
                                            ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * value = NULL;
    mlfVarargin(&varargin, property_strings, 0);
    mlfEnterNewContext(0, -3, property_name, property_strings, varargin);
    value
      = Mmakeresampler_FindValue(
          nargout, property_name, property_strings, varargin);
    mlfRestorePreviousContext(0, 2, property_name, property_strings);
    mxDestroyArray(varargin);
    return mlfReturnValue(value);
}

/*
 * The function "mlxMakeresampler_FindValue" contains the feval interface for
 * the "makeresampler/FindValue" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 408-437). The
 * feval function calls the implementation version of makeresampler/FindValue
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxMakeresampler_FindValue(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/FindValue Line: 408 C"
            "olumn: 1 The function \"makeresampler/FindValue\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mprhs[2] = NULL;
    mlfAssign(&mprhs[2], mclCreateVararginCell(nrhs - 2, prhs + 2));
    mplhs[0] = Mmakeresampler_FindValue(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[2]);
}

/*
 * The function "mlfMakeresampler_GetCanonicalString" contains the normal
 * interface for the "makeresampler/GetCanonicalString" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 437-459). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfMakeresampler_GetCanonicalString(mxArray * input_string,
                                                     mxArray * property_name,
                                                     mxArray * canonical_strings) {
    int nargout = 1;
    mxArray * canonical_string = NULL;
    mlfEnterNewContext(0, 3, input_string, property_name, canonical_strings);
    canonical_string
      = Mmakeresampler_GetCanonicalString(
          nargout, input_string, property_name, canonical_strings);
    mlfRestorePreviousContext(
      0, 3, input_string, property_name, canonical_strings);
    return mlfReturnValue(canonical_string);
}

/*
 * The function "mlxMakeresampler_GetCanonicalString" contains the feval
 * interface for the "makeresampler/GetCanonicalString" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 437-459). The
 * feval function calls the implementation version of
 * makeresampler/GetCanonicalString through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxMakeresampler_GetCanonicalString(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/GetCanonicalString Line: 43"
            "7 Column: 1 The function \"makeresampler/GetCanonicalString\" w"
            "as called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/GetCanonicalString Line: 43"
            "7 Column: 1 The function \"makeresampler/GetCanonicalString\" w"
            "as called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0]
      = Mmakeresampler_GetCanonicalString(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMakeresampler_CheckPropertyNames" contains the normal
 * interface for the "makeresampler/CheckPropertyNames" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 459-475). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfMakeresampler_CheckPropertyNames(mxArray * type,
                                                mxArray * valid_property_names,
                                                ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, valid_property_names, 0);
    mlfEnterNewContext(0, -3, type, valid_property_names, varargin);
    Mmakeresampler_CheckPropertyNames(type, valid_property_names, varargin);
    mlfRestorePreviousContext(0, 2, type, valid_property_names);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxMakeresampler_CheckPropertyNames" contains the feval
 * interface for the "makeresampler/CheckPropertyNames" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 459-475). The
 * feval function calls the implementation version of
 * makeresampler/CheckPropertyNames through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxMakeresampler_CheckPropertyNames(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: makeresampler/CheckPropertyNames Line: 45"
            "9 Column: 1 The function \"makeresampler/CheckPropertyNames\" w"
            "as called with more than the declared number of outputs (0)."),
          NULL);
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mprhs[2] = NULL;
    mlfAssign(&mprhs[2], mclCreateVararginCell(nrhs - 2, prhs + 2));
    Mmakeresampler_CheckPropertyNames(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    mxDestroyArray(mprhs[2]);
}

/*
 * The function "Mmakeresampler" is the implementation version of the
 * "makeresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 1-179). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function r = makeresampler( varargin )
 */
static mxArray * Mmakeresampler(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * r = NULL;
    mxArray * padmethod = NULL;
    mxArray * interpolant = NULL;
    mxArray * type = NULL;
    mxArray * property_strings = NULL;
    mxArray * npairs = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&varargin);
    /*
     * %MAKERESAMPLER Create resampling structure.
     * %   R = MAKERESAMPLER(INTERPOLANT,PADMETHOD) creates a separable
     * %   resampler structure for use with TFORMARRAY and IMTRANSFORM.
     * %   In its simplest form, INTERPOLANT can be one of these strings:
     * %   'nearest', 'linear', or 'cubic'.  INTERPOLANT specifies the
     * %   interpolating kernel that the separable resampler uses.  PADMETHOD
     * %   can be one of these strings: 'replicate', 'symmetric', 'circular',
     * %   'fill', or 'bound'.  PADMETHOD controls how the resampler to
     * %   interpolates or assigns values to output elements that map close
     * %   to or outside the edge of input array.
     * %
     * %   PADMETHOD options
     * %   -----------------
     * %   In the case of 'fill', 'replicate', 'circular', or 'symmetric',
     * %   the resampling performed by TFORMARRAY or IMTRANSFORM occurs in
     * %   two logical steps: (1) pad A infinitely to fill the entire input
     * %   transform space, then (2) evaluate the convolution of the padded
     * %   A with the resampling kernel at the output points specified by
     * %   the geometric map.  Each non-transform dimension is handled
     * %   separately.  The padding is virtual, (accomplished by remapping
     * %   array subscripts) for performance and memory efficiency.
     * %  
     * %   'circular', 'replicate', and 'symmetric' have the same meanings as
     * %   in PADARRAY as applied to the transform dimensions of A:
     * %   
     * %     'replicate' -- Repeats the outermost elements
     * %     'circular'  -- Repeats A circularly
     * %     'symmetric' -- Mirrors A repeatedly.
     * %   
     * %   'fill' generates an output array with smooth-looking edges (except
     * %   when using nearest neighbor interpolation) because for output points
     * %   that map near the edge of the input array (either inside or outside),
     * %   it combines input image and fill values .
     * %  
     * %   'bound' is like 'fill', but avoids mixing fill values and input image
     * %   values.  Points that map outside are assigned values from the fill
     * %   value array.  Points that map inside are treated as with 'replicate'. 
     * %   'bound' and 'fill' produce identical results when INTERPOLANT is
     * %   'nearest'.
     * % 
     * %   It is up to the user to implement these behaviors in the case of a
     * %   custom resampler.
     * % 
     * %   Advanced options for INTERPOLANT
     * %   --------------------------------
     * %   In general, INTERPOLANT can have one of these forms:
     * %
     * %       1. One of these strings: 'nearest', 'linear', 'cubic'
     * %
     * %       2. A cell array: {HALF_WIDTH, POSITIVE_HALF}
     * %          HALF_WIDTH is a positive scalar designating the half width of
     * %          a symmetric interpolating kernel.  POSITIVE_HALF is a vector
     * %          of values regularly sampling the kernel on the closed interval
     * %          [0 POSITIVE_HALF].
     * %
     * %       3. A cell array: {HALF_WIDTH, INTERP_FCN}
     * %          INTERP_FCN is a function handle that returns interpolating
     * %          kernel values given an array of input values in the interval 
     * %          [0 POSITIVE_HALF].
     * %
     * %       4. A cell array whose elements are one of the three forms above.
     * %
     * %   Forms 2 and 3 are used to interpolate with a custom interpolating
     * %   kernel.  Form 4 is used to specify the interpolation method
     * %   independently along each dimension.  The number of elements in the
     * %   cell array for form 4 must equal the number of transform dimensions.
     * %   For example, if INTERPOLANT is {'nearest', 'linear', {2
     * %   KERNEL_TABLE}}, then the resampler will use nearest-neighbor
     * %   interpolation along the first transform dimension, linear
     * %   interpolation along the second, and a custom table-based
     * %   interpolation along the third.
     * %
     * %   Custom resamplers
     * %   -----------------
     * %   The syntaxes described above construct a resampler structure that
     * %   uses the separable resampler function that ships with the Image
     * %   Processing Toolbox.  It is also possible to create a resampler
     * %   structure that uses a user-written resampler by using this syntax: 
     * %   R = MAKERESAMPLER(PropertyName,PropertyValue,...).  PropertyName can
     * %   be 'Type', 'PadMethod', 'Interpolant', 'NDims', 'ResampleFcn', or
     * %   'CustomData'.
     * %
     * %   'Type' can be either 'separable' or 'custom' and must always be
     * %   supplied.  If 'Type' is 'separable', the only other properties that can
     * %   be specified are 'Interpolant' and 'PadMethod', and the result is
     * %   equivalent to using the MAKERESAMPLER(INTERPOLANT,PADMETHOD) syntax.
     * %   If 'Type' is 'custom', then 'NDims' and 'ResampleFcn' are required
     * %   properties, and 'CustomData' is optional.  'NDims' is a positive
     * %   integer and indicates what dimensionality the custom resampler can
     * %   handle.  Use a value of Inf to indicate that the custom resampler can
     * %   handle any dimension.  The value of 'CustomData' is unconstrained.
     * %
     * %   'ResampleFcn' is a handle to a function that peforms the resampling.
     * %   The function will be called with the following interface:
     * %
     * %       B = RESAMPLE_FCN(A,M,TDIMS_A,TDIMS_B,FSIZE_A,FSIZE_B,F,R)
     * %
     * %   See the help for TFORMARRAY for information on the inputs A, TDIMS_A,
     * %   TDIMS_B, and F.
     * %
     * %   M is an array that maps the transform subscript space of B to the
     * %   transform subscript space of A.  If If A has N transform dimensions (N =
     * %   length(TDIMS_A)) and B has P transform dimensions (P = length(TDIMS_B)),
     * %   then NDIMS(M) = P + 1 if N > 1 and P if N == 1, and SIZE(M, P + 1) =
     * %   N.  The first P dimensions of M correspond to the output transform
     * %   space, permuted according to the order in which the the output
     * %   transform dimensions are listed in TDIMS_B.  (In general TDIMS_A and
     * %   TDIMS_B need not be sorted in ascending order, although such a
     * %   limitation may be imposed by specific resamplers.)  Thus the first P
     * %   elements of SIZE(M) determine the sizes of the transform dimensions of
     * %   B.  The input transform coordinates to which each point is mapped are
     * %   arrayed across the final dimension of M, following the order given in
     * %   TDIMS_A.  M must be double.
     * %
     * %   FSIZE_A and FSIZE_B are the full sizes of A and B, padded with 1s as
     * %   necessary to be consistent with TDIMS_A, TDIMS_B, and SIZE(A).
     * %
     * %   Example
     * %   -------
     * %   Stretch an image in the y-direction using separable resampler that
     * %   applies in cubic interpolation in the y-direction and nearest
     * %   neighbor interpolation in the x-direction. (This is equivalent to,
     * %   but faster than, applying bicubic interpolation.)
     * %
     * %       A = imread('moon.tif');
     * %       resamp = makeresampler({'nearest','cubic'},'fill');
     * %       stretch = maketform('affine',[1 0; 0 1.3; 0 0]);
     * %       B = imtransform(A,stretch,resamp);
     * %
     * %   See also IMTRANSFORM, TFORMARRAY.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.4 $ $Date: 2002/03/15 15:28:36 $
     * 
     * message = nargchk(2,10,nargin);
     */
    mlfAssign(&message, mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if mod(nargin,2) ~= 0
     */
    if (mclNeBool(
          mlfScalar(svDoubleScalarMod((double) nargin_, 2.0)), _mxarray2_)) {
        /*
         * error('Invalid number of arguments.');
         */
        mlfError(_mxarray3_, NULL);
    /*
     * end
     */
    }
    /*
     * npairs = nargin / 2;
     */
    mlfAssign(&npairs, mlfScalar(svDoubleScalarRdivide((double) nargin_, 2.0)));
    /*
     * 
     * property_strings = ...
     */
    mlfAssign(&property_strings, _mxarray5_);
    /*
     * {'type','padmethod','interpolant','ndims','resamplefcn','customdata'};
     * 
     * % Check for the shorthand syntax for separable resamplers.
     * if npairs == 1
     */
    if (mclEqBool(mclVv(npairs, "npairs"), _mxarray19_)) {
        /*
         * if ischar(varargin{1})
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxIschar,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                NULL))) {
            /*
             * if isempty(FindValue('type', property_strings, varargin{:}))
             */
            if (mlfTobool(
                  mlfIsempty(
                    mlfMakeresampler_FindValue(
                      _mxarray7_,
                      mclVv(property_strings, "property_strings"),
                      mlfIndexRef(
                        mclVa(varargin, "varargin"),
                        "{?}",
                        mlfCreateColonIndex()),
                      NULL)))) {
                /*
                 * r = MakeSeparable( varargin{1}, varargin{2} );
                 */
                mlfAssign(
                  &r,
                  mclFeval(
                    mclValueVarargout(),
                    mlxMakeresampler_MakeSeparable,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            }
        /*
         * else
         */
        } else {
            /*
             * r = MakeSeparable( varargin{1}, varargin{2} );
             */
            mlfAssign(
              &r,
              mclFeval(
                mclValueVarargout(),
                mlxMakeresampler_MakeSeparable,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL));
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Parse property name/property value syntax.
     * type = FindValue('type', property_strings, varargin{:});
     */
    mlfAssign(
      &type,
      mlfMakeresampler_FindValue(
        _mxarray7_,
        mclVv(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(type)
     */
    if (mlfTobool(mlfIsempty(mclVv(type, "type")))) {
        /*
         * error('Missing ''Type'' property.');
         */
        mlfError(_mxarray20_, NULL);
    /*
     * end
     */
    }
    /*
     * switch GetCanonicalString(type,'Type',{'separable','custom'})
     */
    {
        mxArray * v_
          = mclInitialize(
              mlfMakeresampler_GetCanonicalString(
                mclVv(type, "type"), _mxarray28_, _mxarray30_));
        if (mclSwitchCompare(v_, _mxarray22_)) {
            /*
             * case 'separable'
             * [interpolant, padmethod] = ParseSeparable( property_strings, varargin{:} );   
             */
            mlfAssign(
              &interpolant,
              mlfMakeresampler_ParseSeparable(
                &padmethod,
                mclVv(property_strings, "property_strings"),
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
            /*
             * r = MakeSeparable( interpolant, padmethod );
             */
            mlfAssign(
              &r,
              mlfMakeresampler_MakeSeparable(
                mclVv(interpolant, "interpolant"),
                mclVv(padmethod, "padmethod")));
        /*
         * case 'custom'
         */
        } else if (mclSwitchCompare(v_, _mxarray24_)) {
            /*
             * r = MakeCustom( property_strings, varargin{:} );
             */
            mlfAssign(
              &r,
              mlfMakeresampler_MakeCustom(
                mclVv(property_strings, "property_strings"),
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
        /*
         * otherwise
         */
        } else {
            /*
             * error('Internal Error: ''Type'' must be ''separable'' or ''custom''.');
             */
            mlfError(_mxarray26_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
    return_:
    mclValidateOutput(r, 1, nargout_, "r", "makeresampler");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(npairs);
    mxDestroyArray(property_strings);
    mxDestroyArray(type);
    mxDestroyArray(interpolant);
    mxDestroyArray(padmethod);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return r;
}

/*
 * The function "Mmakeresampler_MakeCustom" is the implementation version of
 * the "makeresampler/MakeCustom" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 179-222). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function r = MakeCustom( property_strings, varargin )
 */
static mxArray * Mmakeresampler_MakeCustom(int nargout_,
                                           mxArray * property_strings,
                                           mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * r = NULL;
    mxArray * rdata = NULL;
    mxArray * resample_fcn = NULL;
    mxArray * n_dimensions = NULL;
    mxArray * padmethod = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&property_strings);
    mclCopyArray(&varargin);
    /*
     * 
     * CheckPropertyNames('Custom',...
     */
    mlfMakeresampler_CheckPropertyNames(
      _mxarray32_,
      _mxarray34_,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
      NULL);
    /*
     * {'type','padmethod','ndims','resamplefcn','customdata'}, varargin{:});
     * 
     * padmethod = FindValue('padmethod', property_strings, varargin{:});
     */
    mlfAssign(
      &padmethod,
      mlfMakeresampler_FindValue(
        _mxarray9_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(padmethod)
     */
    if (mlfTobool(mlfIsempty(mclVv(padmethod, "padmethod")))) {
        /*
         * padmethod = 'replicate';
         */
        mlfAssign(&padmethod, _mxarray36_);
    /*
     * end
     */
    }
    /*
     * padmethod = GetCanonicalString( padmethod, 'PadMethod', ...
     */
    mlfAssign(
      &padmethod,
      mlfMakeresampler_GetCanonicalString(
        mclVv(padmethod, "padmethod"), _mxarray38_, _mxarray40_));
    /*
     * {'fill','bound','replicate','circular','symmetric'});
     * 
     * n_dimensions = FindValue('ndims', property_strings, varargin{:});
     */
    mlfAssign(
      &n_dimensions,
      mlfMakeresampler_FindValue(
        _mxarray13_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(n_dimensions)
     */
    if (mlfTobool(mlfIsempty(mclVv(n_dimensions, "n_dimensions")))) {
        /*
         * error('The ''NDims'' property must be specified.');
         */
        mlfError(_mxarray50_, NULL);
    /*
     * end
     */
    }
    /*
     * if length(n_dimensions) ~= 1
     */
    if (mclLengthInt(mclVv(n_dimensions, "n_dimensions")) != 1) {
        /*
         * error('''NDims'' must have a scalar value.');
         */
        mlfError(_mxarray52_, NULL);
    /*
     * end
     */
    }
    /*
     * if ~isa(n_dimensions,'double') | ~isreal(n_dimensions)
     */
    {
        mxArray * a_
          = mclInitialize(
              mclNot(
                mlfIsa(mclVv(n_dimensions, "n_dimensions"), _mxarray56_)));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(mlfIsreal(mclVv(n_dimensions, "n_dimensions")))))) {
            mxDestroyArray(a_);
            /*
             * error('''NDims'' must have numeric, real value.');
             */
            mlfError(_mxarray54_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * if n_dimensions ~= floor(n_dimensions) | n_dimensions < 1
     */
    {
        mxArray * a_
          = mclInitialize(
              mclNe(
                mclVv(n_dimensions, "n_dimensions"),
                mlfFloor(mclVv(n_dimensions, "n_dimensions"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLt(mclVv(n_dimensions, "n_dimensions"), _mxarray19_)))) {
            mxDestroyArray(a_);
            /*
             * error('''NDims'' must have a positive integer value.');
             */
            mlfError(_mxarray58_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * resample_fcn = FindValue('resamplefcn', property_strings, varargin{:});
     */
    mlfAssign(
      &resample_fcn,
      mlfMakeresampler_FindValue(
        _mxarray15_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(resample_fcn)
     */
    if (mlfTobool(mlfIsempty(mclVv(resample_fcn, "resample_fcn")))) {
        /*
         * error('The ''ResampleFcn'' property must be specified.');
         */
        mlfError(_mxarray60_, NULL);
    /*
     * end
     */
    }
    /*
     * if length(resample_fcn) ~= 1
     */
    if (mclLengthInt(mclVv(resample_fcn, "resample_fcn")) != 1) {
        /*
         * error('''ResampleFcn'' must have a scalar value.');
         */
        mlfError(_mxarray62_, NULL);
    /*
     * end
     */
    }
    /*
     * if ~isa(resample_fcn,'function_handle')
     */
    if (mclNotBool(mlfIsa(mclVv(resample_fcn, "resample_fcn"), _mxarray64_))) {
        /*
         * error('''ResampleFcn'' must have function handle value.');
         */
        mlfError(_mxarray66_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * rdata = FindValue('customdata', property_strings, varargin{:});
     */
    mlfAssign(
      &rdata,
      mlfMakeresampler_FindValue(
        _mxarray17_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * r = AssignResampler(n_dimensions, padmethod, resample_fcn, rdata);
     */
    mlfAssign(
      &r,
      mlfMakeresampler_AssignResampler(
        mclVv(n_dimensions, "n_dimensions"),
        mclVv(padmethod, "padmethod"),
        mclVv(resample_fcn, "resample_fcn"),
        mclVv(rdata, "rdata")));
    mclValidateOutput(r, 1, nargout_, "r", "makeresampler/MakeCustom");
    mxDestroyArray(ans);
    mxDestroyArray(padmethod);
    mxDestroyArray(n_dimensions);
    mxDestroyArray(resample_fcn);
    mxDestroyArray(rdata);
    mxDestroyArray(varargin);
    mxDestroyArray(property_strings);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return r;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_ParseSeparable" is the implementation version
 * of the "makeresampler/ParseSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 222-239). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [interpolant, padmethod] = ParseSeparable(property_strings, varargin)
 */
static mxArray * Mmakeresampler_ParseSeparable(mxArray * * padmethod,
                                               int nargout_,
                                               mxArray * property_strings,
                                               mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * interpolant = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&property_strings);
    mclCopyArray(&varargin);
    /*
     * 
     * CheckPropertyNames('Separable',...
     */
    mlfMakeresampler_CheckPropertyNames(
      _mxarray68_,
      _mxarray70_,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
      NULL);
    /*
     * {'type','interpolant','padmethod'}, varargin{:});
     * 
     * interpolant = FindValue('interpolant', property_strings, varargin{:});
     */
    mlfAssign(
      &interpolant,
      mlfMakeresampler_FindValue(
        _mxarray11_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(interpolant)
     */
    if (mlfTobool(mlfIsempty(mclVv(interpolant, "interpolant")))) {
        /*
         * interpolant = 'linear';
         */
        mlfAssign(&interpolant, _mxarray72_);
    /*
     * end 
     */
    }
    /*
     * 
     * padmethod = FindValue('padmethod', property_strings, varargin{:});
     */
    mlfAssign(
      padmethod,
      mlfMakeresampler_FindValue(
        _mxarray9_,
        mclVa(property_strings, "property_strings"),
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if isempty(padmethod)
     */
    if (mlfTobool(mlfIsempty(mclVv(*padmethod, "padmethod")))) {
        /*
         * padmethod = 'replicate';
         */
        mlfAssign(padmethod, _mxarray36_);
    /*
     * end
     */
    }
    mclValidateOutput(
      interpolant, 1, nargout_, "interpolant", "makeresampler/ParseSeparable");
    mclValidateOutput(
      *padmethod, 2, nargout_, "padmethod", "makeresampler/ParseSeparable");
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(property_strings);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return interpolant;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_MakeSeparable" is the implementation version of
 * the "makeresampler/MakeSeparable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 239-264). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function r = MakeSeparable( interpolant, padmethod )
 */
static mxArray * Mmakeresampler_MakeSeparable(int nargout_,
                                              mxArray * interpolant,
                                              mxArray * padmethod) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * r = NULL;
    mxArray * rdata = NULL;
    mxArray * n_dimensions = NULL;
    mxArray * standardFrequency = NULL;
    mclCopyArray(&interpolant);
    mclCopyArray(&padmethod);
    /*
     * 
     * standardFrequency = 1000;  % Standard number of samples per unit 
     */
    mlfAssign(&standardFrequency, _mxarray74_);
    /*
     * n_dimensions = inf;
     */
    mlfAssign(&n_dimensions, _mxarray75_);
    /*
     * 
     * if isa(interpolant,'cell')
     */
    if (mlfTobool(mlfIsa(mclVa(interpolant, "interpolant"), _mxarray76_))) {
        /*
         * if HasCustomTable(interpolant)
         */
        if (mlfTobool(
              mlfMakeresampler_HasCustomTable(
                mclVa(interpolant, "interpolant")))) {
            /*
             * rdata.K = interpolant;
             */
            mlfIndexAssign(&rdata, ".K", mclVa(interpolant, "interpolant"));
        /*
         * elseif HasCustomFunction(interpolant)
         */
        } else if (mlfTobool(
                     mlfMakeresampler_HasCustomFunction(
                       mclVa(interpolant, "interpolant")))) {
            /*
             * rdata.K = CustomKernel(interpolant, standardFrequency);
             */
            mlfIndexAssign(
              &rdata,
              ".K",
              mlfMakeresampler_CustomKernel(
                mclVa(interpolant, "interpolant"),
                mclVv(standardFrequency, "standardFrequency")));
        /*
         * else
         */
        } else {
            /*
             * n_dimensions = length(interpolant);
             */
            mlfAssign(
              &n_dimensions,
              mlfScalar(mclLengthInt(mclVa(interpolant, "interpolant"))));
            /*
             * rdata.K = MultipleKernels(interpolant, standardFrequency);
             */
            mlfIndexAssign(
              &rdata,
              ".K",
              mlfMakeresampler_MultipleKernels(
                mclVa(interpolant, "interpolant"),
                mclVv(standardFrequency, "standardFrequency")));
        /*
         * end
         */
        }
    /*
     * else
     */
    } else {
        /*
         * rdata.K = StandardKernel(interpolant, standardFrequency);
         */
        mlfIndexAssign(
          &rdata,
          ".K",
          mlfMakeresampler_StandardKernel(
            mclVa(interpolant, "interpolant"),
            mclVv(standardFrequency, "standardFrequency")));
    /*
     * end
     */
    }
    /*
     * 
     * padmethod = GetCanonicalString( padmethod, 'PadMethod', ...
     */
    mlfAssign(
      &padmethod,
      mlfMakeresampler_GetCanonicalString(
        mclVa(padmethod, "padmethod"), _mxarray38_, _mxarray40_));
    /*
     * {'fill','bound','replicate','circular','symmetric'});
     * 
     * r = AssignResampler(n_dimensions, padmethod, @resampsep, rdata);
     */
    mlfAssign(
      &r,
      mlfMakeresampler_AssignResampler(
        mclVv(n_dimensions, "n_dimensions"),
        mclVa(padmethod, "padmethod"),
        mclCreateSimpleFunctionHandle(mlxImages_private_resampsep, "resampsep"),
        mclVv(rdata, "rdata")));
    mclValidateOutput(r, 1, nargout_, "r", "makeresampler/MakeSeparable");
    mxDestroyArray(standardFrequency);
    mxDestroyArray(n_dimensions);
    mxDestroyArray(rdata);
    mxDestroyArray(padmethod);
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return r;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_HasCustomTable" is the implementation version
 * of the "makeresampler/HasCustomTable" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 264-286). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = HasCustomTable(interpolant)
 */
static mxArray * Mmakeresampler_HasCustomTable(int nargout_,
                                               mxArray * interpolant) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * q = NULL;
    mclCopyArray(&interpolant);
    /*
     * 
     * q = isa(interpolant,'cell');
     */
    mlfAssign(&q, mlfIsa(mclVa(interpolant, "interpolant"), _mxarray76_));
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = length(interpolant) == 2;
         */
        mlfAssign(
          &q,
          mclBoolToArray(mclLengthInt(mclVa(interpolant, "interpolant")) == 2));
    /*
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = isa(interpolant{1},'double') ...
         */
        mlfAssign(
          &q,
          mclAnd(
            mclAnd(
              mclAnd(
                mclAnd(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIsa,
                    mlfIndexRef(
                      mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                    _mxarray56_,
                    NULL),
                  mclEq(
                    mclFeval(
                      mclValueVarargout(),
                      mlxLength,
                      mlfIndexRef(
                        mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                      NULL),
                    _mxarray19_)),
                mclFeval(
                  mclValueVarargout(),
                  mlxIsreal,
                  mlfIndexRef(
                    mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                  NULL)),
              mclFeval(
                mclValueVarargout(),
                mlxIsa,
                mlfIndexRef(
                  mclVa(interpolant, "interpolant"), "{?}", _mxarray0_),
                _mxarray56_,
                NULL)),
            mclFeval(
              mclValueVarargout(),
              mlxIsreal,
              mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray0_),
              NULL)));
    /*
     * & length(interpolant{1}) == 1 ...
     * & isreal(interpolant{1}) ...
     * & isa(interpolant{2},'double') ...
     * & isreal(interpolant{2});
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = interpolant{1} > 0;
         */
        mlfAssign(
          &q,
          mclFeval(
            mclValueVarargout(),
            mlxGt,
            mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
            _mxarray2_,
            NULL));
    /*
     * end
     */
    }
    mclValidateOutput(q, 1, nargout_, "q", "makeresampler/HasCustomTable");
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_HasCustomFunction" is the implementation
 * version of the "makeresampler/HasCustomFunction" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 286-307). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = HasCustomFunction(interpolant)
 */
static mxArray * Mmakeresampler_HasCustomFunction(int nargout_,
                                                  mxArray * interpolant) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * q = NULL;
    mclCopyArray(&interpolant);
    /*
     * 
     * q = isa(interpolant,'cell');
     */
    mlfAssign(&q, mlfIsa(mclVa(interpolant, "interpolant"), _mxarray76_));
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = length(interpolant) == 2;
         */
        mlfAssign(
          &q,
          mclBoolToArray(mclLengthInt(mclVa(interpolant, "interpolant")) == 2));
    /*
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = isa(interpolant{1},'double') ...
         */
        mlfAssign(
          &q,
          mclAnd(
            mclAnd(
              mclAnd(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsa,
                  mlfIndexRef(
                    mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                  _mxarray56_,
                  NULL),
                mclEq(
                  mclFeval(
                    mclValueVarargout(),
                    mlxLength,
                    mlfIndexRef(
                      mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                    NULL),
                  _mxarray19_)),
              mclFeval(
                mclValueVarargout(),
                mlxIsreal,
                mlfIndexRef(
                  mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
                NULL)),
            mclFeval(
              mclValueVarargout(),
              mlxIsa,
              mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray0_),
              _mxarray64_,
              NULL)));
    /*
     * & length(interpolant{1}) == 1 ...
     * & isreal(interpolant{1}) ...
     * & isa(interpolant{2},'function_handle');
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = interpolant{1} > 0;
         */
        mlfAssign(
          &q,
          mclFeval(
            mclValueVarargout(),
            mlxGt,
            mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray19_),
            _mxarray2_,
            NULL));
    /*
     * end
     */
    }
    mclValidateOutput(q, 1, nargout_, "q", "makeresampler/HasCustomFunction");
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_MultipleKernels" is the implementation version
 * of the "makeresampler/MultipleKernels" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 307-321). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function K = MultipleKernels( interpolant, frequency )
 */
static mxArray * Mmakeresampler_MultipleKernels(int nargout_,
                                                mxArray * interpolant,
                                                mxArray * frequency) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * K = NULL;
    mxArray * i = NULL;
    mclCopyArray(&interpolant);
    mclCopyArray(&frequency);
    /*
     * 
     * for i = 1:length(interpolant)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVa(interpolant, "interpolant"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray78_);
        } else {
            /*
             * if HasCustomTable(interpolant{i})
             * K{i} = interpolant{i};
             * elseif HasCustomFunction(interpolant{i})
             * K{i} = CustomKernel(interpolant{i}, frequency);
             * else
             * K{i} = StandardKernel(interpolant{i}, frequency);
             * end
             * end
             */
            for (; ; ) {
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxMakeresampler_HasCustomTable,
                        mlfIndexRef(
                          mclVa(interpolant, "interpolant"),
                          "{?}",
                          mlfScalar(v_)),
                        NULL))) {
                    mlfIndexAssign(
                      &K,
                      "{?}",
                      mlfScalar(v_),
                      mlfIndexRef(
                        mclVa(interpolant, "interpolant"),
                        "{?}",
                        mlfScalar(v_)));
                } else if (mlfTobool(
                             mclFeval(
                               mclValueVarargout(),
                               mlxMakeresampler_HasCustomFunction,
                               mlfIndexRef(
                                 mclVa(interpolant, "interpolant"),
                                 "{?}",
                                 mlfScalar(v_)),
                               NULL))) {
                    mlfIndexAssign(
                      &K,
                      "{?}",
                      mlfScalar(v_),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMakeresampler_CustomKernel,
                        mlfIndexRef(
                          mclVa(interpolant, "interpolant"),
                          "{?}",
                          mlfScalar(v_)),
                        mclVa(frequency, "frequency"),
                        NULL));
                } else {
                    mlfIndexAssign(
                      &K,
                      "{?}",
                      mlfScalar(v_),
                      mclFeval(
                        mclValueVarargout(),
                        mlxMakeresampler_StandardKernel,
                        mlfIndexRef(
                          mclVa(interpolant, "interpolant"),
                          "{?}",
                          mlfScalar(v_)),
                        mclVa(frequency, "frequency"),
                        NULL));
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    mclValidateOutput(K, 1, nargout_, "K", "makeresampler/MultipleKernels");
    mxDestroyArray(i);
    mxDestroyArray(frequency);
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return K;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_CustomKernel" is the implementation version of
 * the "makeresampler/CustomKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 321-330). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function K = CustomKernel( interpolant, frequency )
 */
static mxArray * Mmakeresampler_CustomKernel(int nargout_,
                                             mxArray * interpolant,
                                             mxArray * frequency) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * K = NULL;
    mxArray * positiveHalf = NULL;
    mxArray * kernel_fcn = NULL;
    mxArray * halfwidth = NULL;
    mclCopyArray(&interpolant);
    mclCopyArray(&frequency);
    /*
     * 
     * halfwidth  = interpolant{1};
     */
    mlfAssign(
      &halfwidth,
      mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray19_));
    /*
     * kernel_fcn = interpolant{2};
     */
    mlfAssign(
      &kernel_fcn,
      mlfIndexRef(mclVa(interpolant, "interpolant"), "{?}", _mxarray0_));
    /*
     * positiveHalf = SampleKernel(kernel_fcn, halfwidth, frequency);
     */
    mlfAssign(
      &positiveHalf,
      mlfMakeresampler_SampleKernel(
        mclVv(kernel_fcn, "kernel_fcn"),
        mclVv(halfwidth, "halfwidth"),
        mclVa(frequency, "frequency")));
    /*
     * K = {halfwidth, positiveHalf};
     */
    mlfAssign(
      &K,
      mlfCellhcat(
        mclVv(halfwidth, "halfwidth"),
        mclVv(positiveHalf, "positiveHalf"),
        NULL));
    mclValidateOutput(K, 1, nargout_, "K", "makeresampler/CustomKernel");
    mxDestroyArray(halfwidth);
    mxDestroyArray(kernel_fcn);
    mxDestroyArray(positiveHalf);
    mxDestroyArray(frequency);
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return K;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_StandardKernel" is the implementation version
 * of the "makeresampler/StandardKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 330-354). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function K = StandardKernel( interpolant, frequency )
 */
static mxArray * Mmakeresampler_StandardKernel(int nargout_,
                                               mxArray * interpolant,
                                               mxArray * frequency) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * K = NULL;
    mxArray * ans = NULL;
    mxArray * positiveHalf = NULL;
    mxArray * halfwidth = NULL;
    mclCopyArray(&interpolant);
    mclCopyArray(&frequency);
    /*
     * 
     * interpolant = GetCanonicalString( interpolant, 'Interpolant', ...
     */
    mlfAssign(
      &interpolant,
      mlfMakeresampler_GetCanonicalString(
        mclVa(interpolant, "interpolant"), _mxarray79_, _mxarray81_));
    /*
     * {'nearest','linear','cubic'});
     * switch interpolant
     */
    {
        mxArray * v_ = mclInitialize(mclVa(interpolant, "interpolant"));
        if (mclSwitchCompare(v_, _mxarray83_)) {
            /*
             * case 'nearest'
             * K = [];
             */
            mlfAssign(&K, _mxarray78_);
        /*
         * 
         * case 'linear' 
         */
        } else if (mclSwitchCompare(v_, _mxarray72_)) {
            /*
             * halfwidth = 1.0;
             */
            mlfAssign(&halfwidth, _mxarray19_);
            /*
             * positiveHalf = SampleKernel(@LinearKernel, halfwidth, frequency);
             */
            mlfAssign(
              &positiveHalf,
              mlfMakeresampler_SampleKernel(
                mclCreateSimpleFunctionHandle(
                  mlxMakeresampler_LinearKernel, "LinearKernel"),
                mclVv(halfwidth, "halfwidth"),
                mclVa(frequency, "frequency")));
            /*
             * K = {halfwidth, positiveHalf};
             */
            mlfAssign(
              &K,
              mlfCellhcat(
                mclVv(halfwidth, "halfwidth"),
                mclVv(positiveHalf, "positiveHalf"),
                NULL));
        /*
         * 
         * case 'cubic'
         */
        } else if (mclSwitchCompare(v_, _mxarray85_)) {
            /*
             * halfwidth = 2.0;
             */
            mlfAssign(&halfwidth, _mxarray0_);
            /*
             * positiveHalf = SampleKernel(@CubicKernel, halfwidth, frequency);
             */
            mlfAssign(
              &positiveHalf,
              mlfMakeresampler_SampleKernel(
                mclCreateSimpleFunctionHandle(
                  mlxMakeresampler_CubicKernel, "CubicKernel"),
                mclVv(halfwidth, "halfwidth"),
                mclVa(frequency, "frequency")));
            /*
             * K = {halfwidth, positiveHalf};
             */
            mlfAssign(
              &K,
              mlfCellhcat(
                mclVv(halfwidth, "halfwidth"),
                mclVv(positiveHalf, "positiveHalf"),
                NULL));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * error('Internal Error: INTERPOLANT must be ''nearest'', ''linear'', or ''cubic''.');
             */
            mlfError(_mxarray87_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(K, 1, nargout_, "K", "makeresampler/StandardKernel");
    mxDestroyArray(halfwidth);
    mxDestroyArray(positiveHalf);
    mxDestroyArray(ans);
    mxDestroyArray(frequency);
    mxDestroyArray(interpolant);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return K;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_SampleKernel" is the implementation version of
 * the "makeresampler/SampleKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 354-364). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function positiveHalf = SampleKernel( kernel, halfwidth, frequency )
 */
static mxArray * Mmakeresampler_SampleKernel(int nargout_,
                                             mxArray * kernel,
                                             mxArray * halfwidth,
                                             mxArray * frequency) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * positiveHalf = NULL;
    mxArray * n = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&kernel);
    mclCopyArray(&halfwidth);
    mclCopyArray(&frequency);
    /*
     * 
     * if length(kernel) ~= 1 | ~isa(kernel,'function_handle')
     */
    {
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(mclLengthInt(mclVa(kernel, "kernel")) != 1));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(mlfIsa(mclVa(kernel, "kernel"), _mxarray64_))))) {
            mxDestroyArray(a_);
            /*
             * error('kernel must be a function handle.');
             */
            mlfError(_mxarray89_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * n = floor(halfwidth * frequency);
     */
    mlfAssign(
      &n,
      mlfFloor(
        mclMtimes(
          mclVa(halfwidth, "halfwidth"), mclVa(frequency, "frequency"))));
    /*
     * positiveHalf = feval( kernel, (halfwidth / n) * (0:n) ); 
     */
    mlfAssign(
      &positiveHalf,
      mlfFeval(
        mclValueVarargout(),
        mclVa(kernel, "kernel"),
        mclMtimes(
          mclMrdivide(mclVa(halfwidth, "halfwidth"), mclVv(n, "n")),
          mlfColon(_mxarray2_, mclVv(n, "n"), NULL)),
        NULL));
    mclValidateOutput(
      positiveHalf, 1, nargout_, "positiveHalf", "makeresampler/SampleKernel");
    mxDestroyArray(ans);
    mxDestroyArray(n);
    mxDestroyArray(frequency);
    mxDestroyArray(halfwidth);
    mxDestroyArray(kernel);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return positiveHalf;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_LinearKernel" is the implementation version of
 * the "makeresampler/LinearKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 364-374). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function y = LinearKernel( x )
 */
static mxArray * Mmakeresampler_LinearKernel(int nargout_, mxArray * x) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * y = NULL;
    mxArray * q = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&x);
    /*
     * 
     * y = zeros(1,length(x));
     */
    mlfAssign(
      &y, mlfZeros(_mxarray19_, mlfScalar(mclLengthInt(mclVa(x, "x"))), NULL));
    /*
     * reshape(y,size(x));
     */
    mclAssignAns(
      &ans,
      mlfReshape(
        mclVv(y, "y"),
        mlfSize(mclValueVarargout(), mclVa(x, "x"), NULL), NULL));
    /*
     * x(x < 0) = -x(x < 0);
     */
    mclArrayAssign1(
      &x,
      mclUminus(mclArrayRef1(mclVa(x, "x"), mclLt(mclVa(x, "x"), _mxarray2_))),
      mclLt(mclVa(x, "x"), _mxarray2_));
    /*
     * q = (x <= 1);
     */
    mlfAssign(&q, mclLe(mclVa(x, "x"), _mxarray19_));
    /*
     * y(q) = 1 - x(q);
     */
    mclArrayAssign1(
      &y,
      mclMinus(_mxarray19_, mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
      mclVv(q, "q"));
    mclValidateOutput(y, 1, nargout_, "y", "makeresampler/LinearKernel");
    mxDestroyArray(ans);
    mxDestroyArray(q);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return y;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_CubicKernel" is the implementation version of
 * the "makeresampler/CubicKernel" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 374-394). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function y = CubicKernel( x )
 */
static mxArray * Mmakeresampler_CubicKernel(int nargout_, mxArray * x) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * y = NULL;
    mxArray * q = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&x);
    /*
     * 
     * % There is a whole family of "cubic" interpolation kernels. The 
     * % particular kernel used here is described in the article Keys,
     * % "Cubic Convolution Interpolation for Digital Image Processing,"
     * % IEEE Transactions on Acoustics, Speech, and Signal Processing,
     * % Vol. ASSP-29, No. 6, December 1981, p. 1155.
     * 
     * y = zeros(1,length(x));
     */
    mlfAssign(
      &y, mlfZeros(_mxarray19_, mlfScalar(mclLengthInt(mclVa(x, "x"))), NULL));
    /*
     * reshape(y,size(x));
     */
    mclAssignAns(
      &ans,
      mlfReshape(
        mclVv(y, "y"),
        mlfSize(mclValueVarargout(), mclVa(x, "x"), NULL), NULL));
    /*
     * x(x < 0.0) = -x(x < 0.0);
     */
    mclArrayAssign1(
      &x,
      mclUminus(mclArrayRef1(mclVa(x, "x"), mclLt(mclVa(x, "x"), _mxarray2_))),
      mclLt(mclVa(x, "x"), _mxarray2_));
    /*
     * 
     * q = (x <= 1);            % Coefficients: 1.5, -2.5, 0.0, 1.0
     */
    mlfAssign(&q, mclLe(mclVa(x, "x"), _mxarray19_));
    /*
     * y(q) = ((1.5 * x(q) - 2.5) .* x(q)) .* x(q) + 1.0;
     */
    mclArrayAssign1(
      &y,
      mclPlus(
        mclTimes(
          mclTimes(
            mclMinus(
              mclMtimes(
                _mxarray91_, mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
              _mxarray92_),
            mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
          mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
        _mxarray19_),
      mclVv(q, "q"));
    /*
     * 
     * q = (1 < x & x <= 2);    % Coefficients: -0.5, 2.5, -4.0, 2.0
     */
    mlfAssign(
      &q,
      mclAnd(
        mclLt(_mxarray19_, mclVa(x, "x")), mclLe(mclVa(x, "x"), _mxarray0_)));
    /*
     * y(q) = ((-0.5 * x(q) + 2.5) .* x(q) - 4.0) .* x(q) + 2.0;
     */
    mclArrayAssign1(
      &y,
      mclPlus(
        mclTimes(
          mclMinus(
            mclTimes(
              mclPlus(
                mclMtimes(
                  _mxarray93_, mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
                _mxarray92_),
              mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
            _mxarray94_),
          mclArrayRef1(mclVa(x, "x"), mclVv(q, "q"))),
        _mxarray0_),
      mclVv(q, "q"));
    mclValidateOutput(y, 1, nargout_, "y", "makeresampler/CubicKernel");
    mxDestroyArray(ans);
    mxDestroyArray(q);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return y;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_AssignResampler" is the implementation version
 * of the "makeresampler/AssignResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 394-408). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function r = AssignResampler(n_dimensions, padmethod, resamp_fcn, rdata)
 */
static mxArray * Mmakeresampler_AssignResampler(int nargout_,
                                                mxArray * n_dimensions,
                                                mxArray * padmethod,
                                                mxArray * resamp_fcn,
                                                mxArray * rdata) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * r = NULL;
    mclCopyArray(&n_dimensions);
    mclCopyArray(&padmethod);
    mclCopyArray(&resamp_fcn);
    mclCopyArray(&rdata);
    /*
     * 
     * % Use this function to ensure consistency in the way we assign
     * % the fields of each resampling struct. Note that r.ndims = Inf
     * % is used to denote that the resampler supports an arbitrary
     * % number of dimensions.
     * 
     * r.ndims      = n_dimensions;
     */
    mlfIndexAssign(&r, ".ndims", mclVa(n_dimensions, "n_dimensions"));
    /*
     * r.padmethod  = padmethod;
     */
    mlfIndexAssign(&r, ".padmethod", mclVa(padmethod, "padmethod"));
    /*
     * r.resamp_fcn = resamp_fcn;
     */
    mlfIndexAssign(&r, ".resamp_fcn", mclVa(resamp_fcn, "resamp_fcn"));
    /*
     * r.rdata      = rdata;
     */
    mlfIndexAssign(&r, ".rdata", mclVa(rdata, "rdata"));
    mclValidateOutput(r, 1, nargout_, "r", "makeresampler/AssignResampler");
    mxDestroyArray(rdata);
    mxDestroyArray(resamp_fcn);
    mxDestroyArray(padmethod);
    mxDestroyArray(n_dimensions);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return r;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_FindValue" is the implementation version of the
 * "makeresampler/FindValue" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 408-437). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function value = FindValue( property_name, property_strings, varargin )
 */
static mxArray * Mmakeresampler_FindValue(int nargout_,
                                          mxArray * property_name,
                                          mxArray * property_strings,
                                          mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    int nargin_
      = mclNargin(-3, property_name, property_strings, varargin, NULL);
    mxArray * value = NULL;
    mxArray * canonical_name = NULL;
    mxArray * ans = NULL;
    mxArray * nmatch = NULL;
    mxArray * imatch = NULL;
    mxArray * current_name = NULL;
    mxArray * i = NULL;
    mclCopyArray(&property_name);
    mclCopyArray(&property_strings);
    mclCopyArray(&varargin);
    /*
     * 
     * value = [];
     */
    mlfAssign(&value, _mxarray78_);
    /*
     * for i = 1:((nargin-2)/2)
     */
    {
        int v_ = mclForIntStart(1);
        int e_
          = mclForIntEnd(
              mlfScalar(svDoubleScalarRdivide((double) (nargin_ - 2), 2.0)));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray78_);
        } else {
            /*
             * current_name = varargin{2*i-1};
             * if ischar(current_name)
             * imatch = strmatch(lower(current_name),property_strings);
             * nmatch = length(imatch);
             * if nmatch > 1
             * error(['Ambiguous property name ' current_name '.']);
             * end
             * if nmatch == 1
             * canonical_name = property_strings{imatch};
             * if strcmp(canonical_name, property_name)
             * if isempty(value)
             * if isempty(varargin{2*i})
             * error(['Empty value for ' property_name '.']);
             * end
             * value = varargin{2*i};
             * else
             * error(['Property ' property_name ' is specified more than once.']);
             * end
             * end
             * end
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &current_name,
                  mlfIndexRef(
                    mclVa(varargin, "varargin"),
                    "{?}",
                    mlfScalar(
                      svDoubleScalarMinus(
                        svDoubleScalarTimes(2.0, (double) v_), 1.0))));
                if (mlfTobool(mlfIschar(mclVv(current_name, "current_name")))) {
                    mlfAssign(
                      &imatch,
                      mlfStrmatch(
                        mlfLower(mclVv(current_name, "current_name")),
                        mclVa(property_strings, "property_strings"),
                        NULL));
                    mlfAssign(
                      &nmatch,
                      mlfScalar(mclLengthInt(mclVv(imatch, "imatch"))));
                    if (mclGtBool(mclVv(nmatch, "nmatch"), _mxarray19_)) {
                        mlfError(
                          mlfHorzcat(
                            _mxarray95_,
                            mclVv(current_name, "current_name"),
                            _mxarray97_,
                            NULL),
                          NULL);
                    }
                    if (mclEqBool(mclVv(nmatch, "nmatch"), _mxarray19_)) {
                        mlfAssign(
                          &canonical_name,
                          mlfIndexRef(
                            mclVa(property_strings, "property_strings"),
                            "{?}",
                            mclVv(imatch, "imatch")));
                        if (mlfTobool(
                              mlfStrcmp(
                                mclVv(canonical_name, "canonical_name"),
                                mclVa(property_name, "property_name")))) {
                            if (mlfTobool(mlfIsempty(mclVv(value, "value")))) {
                                if (mlfTobool(
                                      mclFeval(
                                        mclValueVarargout(),
                                        mlxIsempty,
                                        mlfIndexRef(
                                          mclVa(varargin, "varargin"),
                                          "{?}",
                                          mlfScalar(
                                            svDoubleScalarTimes(
                                              2.0, (double) v_))),
                                        NULL))) {
                                    mlfError(
                                      mlfHorzcat(
                                        _mxarray99_,
                                        mclVa(property_name, "property_name"),
                                        _mxarray97_,
                                        NULL),
                                      NULL);
                                }
                                mlfAssign(
                                  &value,
                                  mlfIndexRef(
                                    mclVa(varargin, "varargin"),
                                    "{?}",
                                    mlfScalar(
                                      svDoubleScalarTimes(2.0, (double) v_))));
                            } else {
                                mlfError(
                                  mlfHorzcat(
                                    _mxarray101_,
                                    mclVa(property_name, "property_name"),
                                    _mxarray103_,
                                    NULL),
                                  NULL);
                            }
                        }
                    }
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    mclValidateOutput(value, 1, nargout_, "value", "makeresampler/FindValue");
    mxDestroyArray(i);
    mxDestroyArray(current_name);
    mxDestroyArray(imatch);
    mxDestroyArray(nmatch);
    mxDestroyArray(ans);
    mxDestroyArray(canonical_name);
    mxDestroyArray(varargin);
    mxDestroyArray(property_strings);
    mxDestroyArray(property_name);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return value;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_GetCanonicalString" is the implementation
 * version of the "makeresampler/GetCanonicalString" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 437-459). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function canonical_string = GetCanonicalString(...
 */
static mxArray * Mmakeresampler_GetCanonicalString(int nargout_,
                                                   mxArray * input_string,
                                                   mxArray * property_name,
                                                   mxArray * canonical_strings) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    mxArray * canonical_string = NULL;
    mxArray * nmatch = NULL;
    mxArray * imatch = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&input_string);
    mclCopyArray(&property_name);
    mclCopyArray(&canonical_strings);
    /*
     * input_string, property_name, canonical_strings)
     * 
     * if ~ischar(input_string)
     */
    if (mclNotBool(mlfIschar(mclVa(input_string, "input_string")))) {
        /*
         * error([property_name ' must be a string.']);
         */
        mlfError(
          mlfHorzcat(mclVa(property_name, "property_name"), _mxarray105_, NULL),
          NULL);
    /*
     * end
     */
    }
    /*
     * 
     * imatch = strmatch(lower(input_string),canonical_strings);
     */
    mlfAssign(
      &imatch,
      mlfStrmatch(
        mlfLower(mclVa(input_string, "input_string")),
        mclVa(canonical_strings, "canonical_strings"),
        NULL));
    /*
     * nmatch = length(imatch);
     */
    mlfAssign(&nmatch, mlfScalar(mclLengthInt(mclVv(imatch, "imatch"))));
    /*
     * 
     * if nmatch == 0
     */
    if (mclEqBool(mclVv(nmatch, "nmatch"), _mxarray2_)) {
        /*
         * error(['Unrecognized ' property_name ' ' input_string '.']);
         */
        mlfError(
          mlfHorzcat(
            _mxarray107_,
            mclVa(property_name, "property_name"),
            _mxarray109_,
            mclVa(input_string, "input_string"),
            _mxarray97_,
            NULL),
          NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if nmatch > 1
     */
    if (mclGtBool(mclVv(nmatch, "nmatch"), _mxarray19_)) {
        /*
         * error(['Ambiguous ' property_name ' ' input_string '.']);
         */
        mlfError(
          mlfHorzcat(
            _mxarray111_,
            mclVa(property_name, "property_name"),
            _mxarray109_,
            mclVa(input_string, "input_string"),
            _mxarray97_,
            NULL),
          NULL);
    /*
     * end
     */
    }
    /*
     * 
     * canonical_string = canonical_strings{imatch};
     */
    mlfAssign(
      &canonical_string,
      mlfIndexRef(
        mclVa(canonical_strings, "canonical_strings"),
        "{?}",
        mclVv(imatch, "imatch")));
    mclValidateOutput(
      canonical_string,
      1,
      nargout_,
      "canonical_string",
      "makeresampler/GetCanonicalString");
    mxDestroyArray(ans);
    mxDestroyArray(imatch);
    mxDestroyArray(nmatch);
    mxDestroyArray(canonical_strings);
    mxDestroyArray(property_name);
    mxDestroyArray(input_string);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return canonical_string;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mmakeresampler_CheckPropertyNames" is the implementation
 * version of the "makeresampler/CheckPropertyNames" M-function from file
 * "k:\matlab6p5\toolbox\images\images\makeresampler.m" (lines 459-475). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function CheckPropertyNames( type, valid_property_names, varargin )
 */
static void Mmakeresampler_CheckPropertyNames(mxArray * type,
                                              mxArray * valid_property_names,
                                              mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_makeresampler);
    int nargin_ = mclNargin(-3, type, valid_property_names, varargin, NULL);
    mxArray * ans = NULL;
    mxArray * nmatch = NULL;
    mxArray * current_name = NULL;
    mxArray * i = NULL;
    mclCopyArray(&type);
    mclCopyArray(&valid_property_names);
    mclCopyArray(&varargin);
    /*
     * 
     * for i = 1:((nargin-2)/2)
     */
    {
        int v_ = mclForIntStart(1);
        int e_
          = mclForIntEnd(
              mlfScalar(svDoubleScalarRdivide((double) (nargin_ - 2), 2.0)));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray78_);
        } else {
            /*
             * current_name = varargin{2*i-1};
             * if ischar(current_name)
             * nmatch = length(strmatch(lower(current_name),valid_property_names));
             * if nmatch == 0
             * warning(['Property name ' current_name ' ignored with type ' type '.']);
             * end
             * if nmatch > 1
             * error(['Ambiguous property name ' current_name '.']);
             * end
             * else
             * error('Non-character property name.');
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &current_name,
                  mlfIndexRef(
                    mclVa(varargin, "varargin"),
                    "{?}",
                    mlfScalar(
                      svDoubleScalarMinus(
                        svDoubleScalarTimes(2.0, (double) v_), 1.0))));
                if (mlfTobool(mlfIschar(mclVv(current_name, "current_name")))) {
                    mlfAssign(
                      &nmatch,
                      mlfScalar(
                        mclLengthInt(
                          mlfStrmatch(
                            mlfLower(mclVv(current_name, "current_name")),
                            mclVa(valid_property_names, "valid_property_names"),
                            NULL))));
                    if (mclEqBool(mclVv(nmatch, "nmatch"), _mxarray2_)) {
                        mclAssignAns(
                          &ans,
                          mlfNWarning(
                            0,
                            NULL,
                            mlfHorzcat(
                              _mxarray113_,
                              mclVv(current_name, "current_name"),
                              _mxarray115_,
                              mclVa(type, "type"),
                              _mxarray97_,
                              NULL),
                            NULL));
                    }
                    if (mclGtBool(mclVv(nmatch, "nmatch"), _mxarray19_)) {
                        mlfError(
                          mlfHorzcat(
                            _mxarray95_,
                            mclVv(current_name, "current_name"),
                            _mxarray97_,
                            NULL),
                          NULL);
                    }
                } else {
                    mlfError(_mxarray117_, NULL);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    mxDestroyArray(i);
    mxDestroyArray(current_name);
    mxDestroyArray(nmatch);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(valid_property_names);
    mxDestroyArray(type);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
