/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_checkinput.h"
#include "images_private_num2ordinal.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "strread.h"
static mxArray * _persistent_checkinput_init_table__table;

static mxChar _array3_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray2_;

static mxChar _array5_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray4_;

static mxChar _array7_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray6_;

static mxChar _array9_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray8_;

static mxChar _array11_[4] = { 'i', 'n', 't', '8' };
static mxArray * _mxarray10_;

static mxChar _array13_[5] = { 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray12_;

static mxChar _array15_[5] = { 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray14_;

static mxChar _array17_[6] = { 's', 'i', 'n', 'g', 'l', 'e' };
static mxArray * _mxarray16_;

static mxArray * _array1_[8] = { NULL /*_mxarray2_*/, NULL /*_mxarray4_*/,
                                 NULL /*_mxarray6_*/, NULL /*_mxarray8_*/,
                                 NULL /*_mxarray10_*/, NULL /*_mxarray12_*/,
                                 NULL /*_mxarray14_*/, NULL /*_mxarray16_*/ };
static mxArray * _mxarray0_;
static mxArray * _mxarray18_;

static mxChar _array20_[7] = { 'n', 'u', 'm', 'e', 'r', 'i', 'c' };
static mxArray * _mxarray19_;

static mxChar _array22_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray21_;

static mxArray * _array24_[8] = { NULL /*_mxarray4_*/, NULL /*_mxarray10_*/,
                                  NULL /*_mxarray6_*/, NULL /*_mxarray12_*/,
                                  NULL /*_mxarray8_*/, NULL /*_mxarray14_*/,
                                  NULL /*_mxarray16_*/, NULL /*_mxarray2_*/ };
static mxArray * _mxarray23_;
static mxArray * _mxarray25_;

static mxChar _array27_[2] = { '%', 's' };
static mxArray * _mxarray26_;

static mxChar _array29_[12] = { 'I', 'm', 'a', 'g', 'e', 's',
                                ':', '%', 's', ':', '%', 's' };
static mxArray * _mxarray28_;

static mxChar _array31_[11] = { 'i', 'n', 'v', 'a', 'l', 'i',
                                'd', 'T', 'y', 'p', 'e' };
static mxArray * _mxarray30_;
static mxArray * _mxarray32_;

static mxChar _array34_[2] = { ',', ' ' };
static mxArray * _mxarray33_;
static mxArray * _mxarray35_;

static mxChar _array37_[47] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '%', 's', ' ', 'e', 'x', 'p', 'e',
                                'c', 't', 'e', 'd', ' ', 'i', 't', 's',
                                ' ', '%', 's', ' ', 'i', 'n', 'p', 'u',
                                't', ' ', 'a', 'r', 'g', 'u', 'm', 'e',
                                'n', 't', ',', ' ', '%', 's', ',' };
static mxArray * _mxarray36_;

static mxChar _array39_[25] = { 't', 'o', ' ', 'b', 'e', ' ', 'o', 'n', 'e',
                                ' ', 'o', 'f', ' ', 't', 'h', 'e', 's', 'e',
                                ' ', 't', 'y', 'p', 'e', 's', ':' };
static mxArray * _mxarray38_;

static mxChar _array41_[24] = { 'I', 'n', 's', 't', 'e', 'a', 'd', ' ',
                                'i', 't', 's', ' ', 't', 'y', 'p', 'e',
                                ' ', 'w', 'a', 's', ' ', '%', 's', '.' };
static mxArray * _mxarray40_;

static mxChar _array43_[20] = { '%', 's', 0x005c, 'n', '%', 's', 0x005c,
                                'n', 0x005c, 'n', ' ', ' ', '%', 's',
                                0x005c, 'n', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray42_;

static mxChar _array45_[2] = { '2', 'd' };
static mxArray * _mxarray44_;

static mxChar _array47_[9] = { 't', 'o', ' ', 'b', 'e', ' ', '%', 's', '.' };
static mxArray * _mxarray46_;

static mxChar _array49_[6] = { '%', 's', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray48_;
static mxArray * _mxarray50_;
static mxArray * _mxarray51_;

static double _array53_[2] = { 0.0, 0.0 };
static mxArray * _mxarray52_;

static mxArray * _array55_[2] = { NULL /*_mxarray2_*/, NULL /*_mxarray16_*/ };
static mxArray * _mxarray54_;

static mxChar _array59_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray58_;

static mxArray * _array57_[7] = { NULL /*_mxarray4_*/, NULL /*_mxarray10_*/,
                                  NULL /*_mxarray6_*/, NULL /*_mxarray12_*/,
                                  NULL /*_mxarray8_*/, NULL /*_mxarray14_*/,
                                  NULL /*_mxarray58_*/ };
static mxArray * _mxarray56_;

static mxChar _array61_[12] = { 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', 'R', 'e', 'a', 'l' };
static mxArray * _mxarray60_;

static mxChar _array63_[4] = { 'r', 'e', 'a', 'l' };
static mxArray * _mxarray62_;

static mxChar _array65_[14] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                'd', 'V', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray64_;

static mxChar _array67_[8] = { 'a', ' ', 'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray66_;

static mxChar _array69_[11] = { 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', 'R', 'o', 'w' };
static mxArray * _mxarray68_;

static mxChar _array71_[12] = { 'a', ' ', 'r', 'o', 'w', ' ',
                                'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray70_;

static mxChar _array73_[14] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                'd', 'C', 'o', 'l', 'u', 'm', 'n' };
static mxArray * _mxarray72_;

static mxChar _array75_[15] = { 'a', ' ', 'c', 'o', 'l', 'u', 'm', 'n',
                                ' ', 'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray74_;

static mxChar _array77_[14] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                'd', 'S', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray76_;

static mxChar _array79_[8] = { 'a', ' ', 's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray78_;

static mxChar _array81_[10] = { 'e', 'x', 'p', 'e', 'c',
                                't', 'e', 'd', '2', 'D' };
static mxArray * _mxarray80_;

static mxChar _array83_[15] = { 't', 'w', 'o', '-', 'd', 'i', 'm', 'e',
                                'n', 's', 'i', 'o', 'n', 'a', 'l' };
static mxArray * _mxarray82_;

static mxChar _array85_[17] = { 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'N',
                                'o', 'n', 's', 'p', 'a', 'r', 's', 'e' };
static mxArray * _mxarray84_;

static mxChar _array87_[9] = { 'n', 'o', 'n', 's', 'p', 'a', 'r', 's', 'e' };
static mxArray * _mxarray86_;

static mxChar _array89_[16] = { 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                                'N', 'o', 'n', 'e', 'm', 'p', 't', 'y' };
static mxArray * _mxarray88_;

static mxChar _array91_[8] = { 'n', 'o', 'n', 'e', 'm', 'p', 't', 'y' };
static mxArray * _mxarray90_;

static mxChar _array93_[15] = { 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                                'I', 'n', 't', 'e', 'g', 'e', 'r' };
static mxArray * _mxarray92_;

static mxChar _array95_[14] = { 'i', 'n', 't', 'e', 'g', 'e', 'r',
                                '-', 'v', 'a', 'l', 'u', 'e', 'd' };
static mxArray * _mxarray94_;

static mxChar _array97_[19] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                'd', 'N', 'o', 'n', 'n', 'e', 'g',
                                'a', 't', 'i', 'v', 'e' };
static mxArray * _mxarray96_;

static mxChar _array99_[11] = { 'n', 'o', 'n', 'n', 'e', 'g',
                                'a', 't', 'i', 'v', 'e' };
static mxArray * _mxarray98_;

static mxChar _array101_[16] = { 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                                 'P', 'o', 's', 'i', 't', 'i', 'v', 'e' };
static mxArray * _mxarray100_;

static mxChar _array103_[8] = { 'p', 'o', 's', 'i', 't', 'i', 'v', 'e' };
static mxArray * _mxarray102_;

static mxChar _array105_[14] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                 'd', 'N', 'o', 'n', 'N', 'a', 'N' };
static mxArray * _mxarray104_;

static mxChar _array107_[7] = { 'n', 'o', 'n', '-', 'N', 'a', 'N' };
static mxArray * _mxarray106_;

static mxChar _array109_[14] = { 'e', 'x', 'p', 'e', 'c', 't', 'e',
                                 'd', 'F', 'i', 'n', 'i', 't', 'e' };
static mxArray * _mxarray108_;

static mxChar _array111_[6] = { 'f', 'i', 'n', 'i', 't', 'e' };
static mxArray * _mxarray110_;

static mxChar _array113_[15] = { 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                                 'N', 'o', 'n', 'Z', 'e', 'r', 'o' };
static mxArray * _mxarray112_;

static mxChar _array115_[8] = { 'n', 'o', 'n', '-', 'z', 'e', 'r', 'o' };
static mxArray * _mxarray114_;

static mxChar _array117_[12] = { 'e', 'x', 'p', 'e', 'c', 't',
                                 'e', 'd', 'E', 'v', 'e', 'n' };
static mxArray * _mxarray116_;

static mxChar _array119_[4] = { 'e', 'v', 'e', 'n' };
static mxArray * _mxarray118_;

void InitializeModule_images_private_checkinput(void) {
    mclInitializePersistent(&_persistent_checkinput_init_table__table);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _array1_[0] = _mxarray2_;
    _mxarray4_ = mclInitializeString(5, _array5_);
    _array1_[1] = _mxarray4_;
    _mxarray6_ = mclInitializeString(6, _array7_);
    _array1_[2] = _mxarray6_;
    _mxarray8_ = mclInitializeString(6, _array9_);
    _array1_[3] = _mxarray8_;
    _mxarray10_ = mclInitializeString(4, _array11_);
    _array1_[4] = _mxarray10_;
    _mxarray12_ = mclInitializeString(5, _array13_);
    _array1_[5] = _mxarray12_;
    _mxarray14_ = mclInitializeString(5, _array15_);
    _array1_[6] = _mxarray14_;
    _mxarray16_ = mclInitializeString(6, _array17_);
    _array1_[7] = _mxarray16_;
    _mxarray0_ = mclInitializeCellVector(1, 8, _array1_);
    _mxarray18_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray19_ = mclInitializeString(7, _array20_);
    _mxarray21_ = mclInitializeString(5, _array22_);
    _array24_[0] = _mxarray4_;
    _array24_[1] = _mxarray10_;
    _array24_[2] = _mxarray6_;
    _array24_[3] = _mxarray12_;
    _array24_[4] = _mxarray8_;
    _array24_[5] = _mxarray14_;
    _array24_[6] = _mxarray16_;
    _array24_[7] = _mxarray2_;
    _mxarray23_ = mclInitializeCellVector(8, 1, _array24_);
    _mxarray25_ = mclInitializeCellVector(0, 0, (mxArray * *)NULL);
    _mxarray26_ = mclInitializeString(2, _array27_);
    _mxarray28_ = mclInitializeString(12, _array29_);
    _mxarray30_ = mclInitializeString(11, _array31_);
    _mxarray32_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray33_ = mclInitializeString(2, _array34_);
    _mxarray35_ = mclInitializeDouble(1.0);
    _mxarray36_ = mclInitializeString(47, _array37_);
    _mxarray38_ = mclInitializeString(25, _array39_);
    _mxarray40_ = mclInitializeString(24, _array41_);
    _mxarray42_ = mclInitializeString(20, _array43_);
    _mxarray44_ = mclInitializeString(2, _array45_);
    _mxarray46_ = mclInitializeString(9, _array47_);
    _mxarray48_ = mclInitializeString(6, _array49_);
    _mxarray50_ = mclInitializeDouble(2.0);
    _mxarray51_ = mclInitializeDouble(0.0);
    _mxarray52_ = mclInitializeDoubleVector(1, 2, _array53_);
    _array55_[0] = _mxarray2_;
    _array55_[1] = _mxarray16_;
    _mxarray54_ = mclInitializeCellVector(1, 2, _array55_);
    _array57_[0] = _mxarray4_;
    _array57_[1] = _mxarray10_;
    _array57_[2] = _mxarray6_;
    _array57_[3] = _mxarray12_;
    _array57_[4] = _mxarray8_;
    _array57_[5] = _mxarray14_;
    _mxarray58_ = mclInitializeString(7, _array59_);
    _array57_[6] = _mxarray58_;
    _mxarray56_ = mclInitializeCellVector(1, 7, _array57_);
    _mxarray60_ = mclInitializeString(12, _array61_);
    _mxarray62_ = mclInitializeString(4, _array63_);
    _mxarray64_ = mclInitializeString(14, _array65_);
    _mxarray66_ = mclInitializeString(8, _array67_);
    _mxarray68_ = mclInitializeString(11, _array69_);
    _mxarray70_ = mclInitializeString(12, _array71_);
    _mxarray72_ = mclInitializeString(14, _array73_);
    _mxarray74_ = mclInitializeString(15, _array75_);
    _mxarray76_ = mclInitializeString(14, _array77_);
    _mxarray78_ = mclInitializeString(8, _array79_);
    _mxarray80_ = mclInitializeString(10, _array81_);
    _mxarray82_ = mclInitializeString(15, _array83_);
    _mxarray84_ = mclInitializeString(17, _array85_);
    _mxarray86_ = mclInitializeString(9, _array87_);
    _mxarray88_ = mclInitializeString(16, _array89_);
    _mxarray90_ = mclInitializeString(8, _array91_);
    _mxarray92_ = mclInitializeString(15, _array93_);
    _mxarray94_ = mclInitializeString(14, _array95_);
    _mxarray96_ = mclInitializeString(19, _array97_);
    _mxarray98_ = mclInitializeString(11, _array99_);
    _mxarray100_ = mclInitializeString(16, _array101_);
    _mxarray102_ = mclInitializeString(8, _array103_);
    _mxarray104_ = mclInitializeString(14, _array105_);
    _mxarray106_ = mclInitializeString(7, _array107_);
    _mxarray108_ = mclInitializeString(14, _array109_);
    _mxarray110_ = mclInitializeString(6, _array111_);
    _mxarray112_ = mclInitializeString(15, _array113_);
    _mxarray114_ = mclInitializeString(8, _array115_);
    _mxarray116_ = mclInitializeString(12, _array117_);
    _mxarray118_ = mclInitializeString(4, _array119_);
}

void TerminateModule_images_private_checkinput(void) {
    mxDestroyArray(_mxarray118_);
    mxDestroyArray(_mxarray116_);
    mxDestroyArray(_mxarray114_);
    mxDestroyArray(_mxarray112_);
    mxDestroyArray(_mxarray110_);
    mxDestroyArray(_mxarray108_);
    mxDestroyArray(_mxarray106_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray102_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray98_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray94_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray82_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray0_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_persistent_checkinput_init_table__table);
}

static mxArray * mlfCheckinput_is_numeric(mxArray * A);
static void mlxCheckinput_is_numeric(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfCheckinput_expand_numeric(mxArray * in);
static void mlxCheckinput_expand_numeric(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static void mlfCheckinput_check_classes(mxArray * A,
                                        mxArray * classes,
                                        mxArray * function_name,
                                        mxArray * variable_name,
                                        mxArray * argument_position);
static void mlxCheckinput_check_classes(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static void mlfCheckinput_check_attributes(mxArray * A,
                                           mxArray * attributes,
                                           mxArray * function_name,
                                           mxArray * variable_name,
                                           mxArray * argument_position);
static void mlxCheckinput_check_attributes(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static mxArray * mlfCheckinput_check_real(mxArray * A);
static void mlxCheckinput_check_real(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfCheckinput_check_even(mxArray * A);
static void mlxCheckinput_check_even(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfCheckinput_check_vector(mxArray * A);
static void mlxCheckinput_check_vector(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfCheckinput_check_row(mxArray * A);
static void mlxCheckinput_check_row(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfCheckinput_check_column(mxArray * A);
static void mlxCheckinput_check_column(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfCheckinput_check_scalar(mxArray * A);
static void mlxCheckinput_check_scalar(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfCheckinput_check_2d(mxArray * A);
static void mlxCheckinput_check_2d(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * mlfCheckinput_check_nonsparse(mxArray * A);
static void mlxCheckinput_check_nonsparse(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static mxArray * mlfCheckinput_check_nonempty(mxArray * A);
static void mlxCheckinput_check_nonempty(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfCheckinput_check_integer(mxArray * A);
static void mlxCheckinput_check_integer(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfCheckinput_check_nonnegative(mxArray * A);
static void mlxCheckinput_check_nonnegative(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static mxArray * mlfCheckinput_check_positive(mxArray * A);
static void mlxCheckinput_check_positive(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfCheckinput_check_nonnan(mxArray * A);
static void mlxCheckinput_check_nonnan(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfCheckinput_check_finite(mxArray * A);
static void mlxCheckinput_check_finite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfCheckinput_check_nonzero(mxArray * A);
static void mlxCheckinput_check_nonzero(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfCheckinput_init_table(void);
static void mlxCheckinput_init_table(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static void Mimages_private_checkinput(mxArray * A,
                                       mxArray * classes,
                                       mxArray * attributes,
                                       mxArray * function_name,
                                       mxArray * variable_name,
                                       mxArray * argument_position);
static mxArray * Mcheckinput_is_numeric(int nargout_, mxArray * A);
static mxArray * Mcheckinput_expand_numeric(int nargout_, mxArray * in);
static void Mcheckinput_check_classes(mxArray * A,
                                      mxArray * classes,
                                      mxArray * function_name,
                                      mxArray * variable_name,
                                      mxArray * argument_position);
static void Mcheckinput_check_attributes(mxArray * A,
                                         mxArray * attributes,
                                         mxArray * function_name,
                                         mxArray * variable_name,
                                         mxArray * argument_position);
static mxArray * Mcheckinput_check_real(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_even(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_vector(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_row(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_column(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_scalar(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_2d(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_nonsparse(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_nonempty(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_integer(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_nonnegative(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_positive(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_nonnan(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_finite(int nargout_, mxArray * A);
static mxArray * Mcheckinput_check_nonzero(int nargout_, mxArray * A);
static mxArray * Mcheckinput_init_table(int nargout_);

static mexFunctionTableEntry local_function_table_[20]
  = { { "is_numeric", mlxCheckinput_is_numeric, 1, 1, NULL },
      { "expand_numeric", mlxCheckinput_expand_numeric, 1, 1, NULL },
      { "check_classes", mlxCheckinput_check_classes, 5, 0, NULL },
      { "check_attributes", mlxCheckinput_check_attributes, 5, 0, NULL },
      { "check_real", mlxCheckinput_check_real, 1, 1, NULL },
      { "check_even", mlxCheckinput_check_even, 1, 1, NULL },
      { "check_vector", mlxCheckinput_check_vector, 1, 1, NULL },
      { "check_row", mlxCheckinput_check_row, 1, 1, NULL },
      { "check_column", mlxCheckinput_check_column, 1, 1, NULL },
      { "check_scalar", mlxCheckinput_check_scalar, 1, 1, NULL },
      { "check_2d", mlxCheckinput_check_2d, 1, 1, NULL },
      { "check_nonsparse", mlxCheckinput_check_nonsparse, 1, 1, NULL },
      { "check_nonempty", mlxCheckinput_check_nonempty, 1, 1, NULL },
      { "check_integer", mlxCheckinput_check_integer, 1, 1, NULL },
      { "check_nonnegative", mlxCheckinput_check_nonnegative, 1, 1, NULL },
      { "check_positive", mlxCheckinput_check_positive, 1, 1, NULL },
      { "check_nonnan", mlxCheckinput_check_nonnan, 1, 1, NULL },
      { "check_finite", mlxCheckinput_check_finite, 1, 1, NULL },
      { "check_nonzero", mlxCheckinput_check_nonzero, 1, 1, NULL },
      { "init_table", mlxCheckinput_init_table, 0, 1, NULL } };

_mexLocalFunctionTable _local_function_table_images_private_checkinput
  = { 20, local_function_table_ };

/*
 * The function "mlfImages_private_checkinput" contains the normal interface
 * for the "images/private/checkinput" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 1-41). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlfImages_private_checkinput(mxArray * A,
                                  mxArray * classes,
                                  mxArray * attributes,
                                  mxArray * function_name,
                                  mxArray * variable_name,
                                  mxArray * argument_position) {
    mlfEnterNewContext(
      0,
      6,
      A,
      classes,
      attributes,
      function_name,
      variable_name,
      argument_position);
    Mimages_private_checkinput(
      A, classes, attributes, function_name, variable_name, argument_position);
    mlfRestorePreviousContext(
      0,
      6,
      A,
      classes,
      attributes,
      function_name,
      variable_name,
      argument_position);
}

/*
 * The function "mlxImages_private_checkinput" contains the feval interface for
 * the "images/private/checkinput" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 1-41). The
 * feval function calls the implementation version of images/private/checkinput
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_checkinput(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mprhs[6];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checkinput Line: 1 Co"
            "lumn: 1 The function \"images/private/checkinput\" was cal"
            "led with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 6) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checkinput Line: 1 C"
            "olumn: 1 The function \"images/private/checkinput\" was c"
            "alled with more than the declared number of inputs (6)."),
          NULL);
    }
    for (i = 0; i < 6 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 6; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(
      0, 6, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4], mprhs[5]);
    Mimages_private_checkinput(
      mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4], mprhs[5]);
    mlfRestorePreviousContext(
      0, 6, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4], mprhs[5]);
}

/*
 * The function "mlfCheckinput_is_numeric" contains the normal interface for
 * the "checkinput/is_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 41-56).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_is_numeric(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_is_numeric(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_is_numeric" contains the feval interface for the
 * "checkinput/is_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 41-56). The
 * feval function calls the implementation version of checkinput/is_numeric
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_is_numeric(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/is_numeric Line: 41 Co"
            "lumn: 1 The function \"checkinput/is_numeric\" was call"
            "ed with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/is_numeric Line: 41 Co"
            "lumn: 1 The function \"checkinput/is_numeric\" was call"
            "ed with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_is_numeric(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_expand_numeric" contains the normal interface
 * for the "checkinput/expand_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 56-72).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_expand_numeric(mxArray * in) {
    int nargout = 1;
    mxArray * out = NULL;
    mlfEnterNewContext(0, 1, in);
    out = Mcheckinput_expand_numeric(nargout, in);
    mlfRestorePreviousContext(0, 1, in);
    return mlfReturnValue(out);
}

/*
 * The function "mlxCheckinput_expand_numeric" contains the feval interface for
 * the "checkinput/expand_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 56-72). The
 * feval function calls the implementation version of checkinput/expand_numeric
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_expand_numeric(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/expand_numeric Line: 56 C"
            "olumn: 1 The function \"checkinput/expand_numeric\" was ca"
            "lled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/expand_numeric Line: 56 C"
            "olumn: 1 The function \"checkinput/expand_numeric\" was ca"
            "lled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_expand_numeric(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_classes" contains the normal interface for
 * the "checkinput/check_classes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 72-122).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlfCheckinput_check_classes(mxArray * A,
                                        mxArray * classes,
                                        mxArray * function_name,
                                        mxArray * variable_name,
                                        mxArray * argument_position) {
    mlfEnterNewContext(
      0, 5, A, classes, function_name, variable_name, argument_position);
    Mcheckinput_check_classes(
      A, classes, function_name, variable_name, argument_position);
    mlfRestorePreviousContext(
      0, 5, A, classes, function_name, variable_name, argument_position);
}

/*
 * The function "mlxCheckinput_check_classes" contains the feval interface for
 * the "checkinput/check_classes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 72-122).
 * The feval function calls the implementation version of
 * checkinput/check_classes through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_classes(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[5];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_classes Line: 72 C"
            "olumn: 1 The function \"checkinput/check_classes\" was ca"
            "lled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_classes Line: 72 C"
            "olumn: 1 The function \"checkinput/check_classes\" was ca"
            "lled with more than the declared number of inputs (5)."),
          NULL);
    }
    for (i = 0; i < 5 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 5; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    Mcheckinput_check_classes(mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mlfRestorePreviousContext(
      0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
}

/*
 * The function "mlfCheckinput_check_attributes" contains the normal interface
 * for the "checkinput/check_attributes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 122-155).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlfCheckinput_check_attributes(mxArray * A,
                                           mxArray * attributes,
                                           mxArray * function_name,
                                           mxArray * variable_name,
                                           mxArray * argument_position) {
    mlfEnterNewContext(
      0, 5, A, attributes, function_name, variable_name, argument_position);
    Mcheckinput_check_attributes(
      A, attributes, function_name, variable_name, argument_position);
    mlfRestorePreviousContext(
      0, 5, A, attributes, function_name, variable_name, argument_position);
}

/*
 * The function "mlxCheckinput_check_attributes" contains the feval interface
 * for the "checkinput/check_attributes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 122-155).
 * The feval function calls the implementation version of
 * checkinput/check_attributes through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_attributes(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[5];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_attributes Line: 122 "
            "Column: 1 The function \"checkinput/check_attributes\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_attributes Line: 122"
            " Column: 1 The function \"checkinput/check_attributes\" was"
            " called with more than the declared number of inputs (5)."),
          NULL);
    }
    for (i = 0; i < 5 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 5; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    Mcheckinput_check_attributes(
      mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mlfRestorePreviousContext(
      0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
}

/*
 * The function "mlfCheckinput_check_real" contains the normal interface for
 * the "checkinput/check_real" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 155-164).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_real(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_real(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_real" contains the feval interface for the
 * "checkinput/check_real" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 155-164).
 * The feval function calls the implementation version of checkinput/check_real
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_check_real(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_real Line: 155 Co"
            "lumn: 1 The function \"checkinput/check_real\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_real Line: 155 C"
            "olumn: 1 The function \"checkinput/check_real\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_real(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_even" contains the normal interface for
 * the "checkinput/check_even" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 164-173).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_even(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_even(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_even" contains the feval interface for the
 * "checkinput/check_even" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 164-173).
 * The feval function calls the implementation version of checkinput/check_even
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_check_even(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_even Line: 164 Co"
            "lumn: 1 The function \"checkinput/check_even\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_even Line: 164 C"
            "olumn: 1 The function \"checkinput/check_even\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_even(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_vector" contains the normal interface for
 * the "checkinput/check_vector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 173-182).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_vector(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_vector(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_vector" contains the feval interface for
 * the "checkinput/check_vector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 173-182).
 * The feval function calls the implementation version of
 * checkinput/check_vector through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_vector(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_vector Line: 173 C"
            "olumn: 1 The function \"checkinput/check_vector\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_vector Line: 173 C"
            "olumn: 1 The function \"checkinput/check_vector\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_vector(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_row" contains the normal interface for the
 * "checkinput/check_row" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 182-191).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_row(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_row(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_row" contains the feval interface for the
 * "checkinput/check_row" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 182-191).
 * The feval function calls the implementation version of checkinput/check_row
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_check_row(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_row Line: 182 Co"
            "lumn: 1 The function \"checkinput/check_row\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_row Line: 182 Co"
            "lumn: 1 The function \"checkinput/check_row\" was calle"
            "d with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_row(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_column" contains the normal interface for
 * the "checkinput/check_column" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 191-200).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_column(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_column(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_column" contains the feval interface for
 * the "checkinput/check_column" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 191-200).
 * The feval function calls the implementation version of
 * checkinput/check_column through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_column(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_column Line: 191 C"
            "olumn: 1 The function \"checkinput/check_column\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_column Line: 191 C"
            "olumn: 1 The function \"checkinput/check_column\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_column(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_scalar" contains the normal interface for
 * the "checkinput/check_scalar" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 200-209).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_scalar(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_scalar(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_scalar" contains the feval interface for
 * the "checkinput/check_scalar" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 200-209).
 * The feval function calls the implementation version of
 * checkinput/check_scalar through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_scalar(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_scalar Line: 200 C"
            "olumn: 1 The function \"checkinput/check_scalar\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_scalar Line: 200 C"
            "olumn: 1 The function \"checkinput/check_scalar\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_scalar(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_2d" contains the normal interface for the
 * "checkinput/check_2d" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 209-218).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_2d(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_2d(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_2d" contains the feval interface for the
 * "checkinput/check_2d" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 209-218).
 * The feval function calls the implementation version of checkinput/check_2d
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_check_2d(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_2d Line: 209 Co"
            "lumn: 1 The function \"checkinput/check_2d\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_2d Line: 209 Co"
            "lumn: 1 The function \"checkinput/check_2d\" was calle"
            "d with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_2d(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_nonsparse" contains the normal interface
 * for the "checkinput/check_nonsparse" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 218-227).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_nonsparse(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_nonsparse(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_nonsparse" contains the feval interface
 * for the "checkinput/check_nonsparse" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 218-227).
 * The feval function calls the implementation version of
 * checkinput/check_nonsparse through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_nonsparse(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonsparse Line: 218 "
            "Column: 1 The function \"checkinput/check_nonsparse\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonsparse Line: 218 "
            "Column: 1 The function \"checkinput/check_nonsparse\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_nonsparse(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_nonempty" contains the normal interface
 * for the "checkinput/check_nonempty" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 227-236).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_nonempty(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_nonempty(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_nonempty" contains the feval interface for
 * the "checkinput/check_nonempty" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 227-236).
 * The feval function calls the implementation version of
 * checkinput/check_nonempty through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_nonempty(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonempty Line: 227 "
            "Column: 1 The function \"checkinput/check_nonempty\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonempty Line: 227 "
            "Column: 1 The function \"checkinput/check_nonempty\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_nonempty(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_integer" contains the normal interface for
 * the "checkinput/check_integer" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 236-258).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_integer(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_integer(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_integer" contains the feval interface for
 * the "checkinput/check_integer" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 236-258).
 * The feval function calls the implementation version of
 * checkinput/check_integer through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_integer(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_integer Line: 236 C"
            "olumn: 1 The function \"checkinput/check_integer\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_integer Line: 236 "
            "Column: 1 The function \"checkinput/check_integer\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_integer(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_nonnegative" contains the normal interface
 * for the "checkinput/check_nonnegative" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 258-267).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_nonnegative(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_nonnegative(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_nonnegative" contains the feval interface
 * for the "checkinput/check_nonnegative" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 258-267).
 * The feval function calls the implementation version of
 * checkinput/check_nonnegative through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_nonnegative(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonnegative Line: 258"
            " Column: 1 The function \"checkinput/check_nonnegative\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonnegative Line: 258"
            " Column: 1 The function \"checkinput/check_nonnegative\" was"
            " called with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_nonnegative(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_positive" contains the normal interface
 * for the "checkinput/check_positive" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 267-276).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_positive(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_positive(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_positive" contains the feval interface for
 * the "checkinput/check_positive" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 267-276).
 * The feval function calls the implementation version of
 * checkinput/check_positive through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_positive(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_positive Line: 267 "
            "Column: 1 The function \"checkinput/check_positive\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_positive Line: 267 "
            "Column: 1 The function \"checkinput/check_positive\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_positive(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_nonnan" contains the normal interface for
 * the "checkinput/check_nonnan" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 276-289).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_nonnan(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_nonnan(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_nonnan" contains the feval interface for
 * the "checkinput/check_nonnan" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 276-289).
 * The feval function calls the implementation version of
 * checkinput/check_nonnan through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_nonnan(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonnan Line: 276 C"
            "olumn: 1 The function \"checkinput/check_nonnan\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonnan Line: 276 C"
            "olumn: 1 The function \"checkinput/check_nonnan\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_nonnan(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_finite" contains the normal interface for
 * the "checkinput/check_finite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 289-301).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_finite(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_finite(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_finite" contains the feval interface for
 * the "checkinput/check_finite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 289-301).
 * The feval function calls the implementation version of
 * checkinput/check_finite through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_finite(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_finite Line: 289 C"
            "olumn: 1 The function \"checkinput/check_finite\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_finite Line: 289 C"
            "olumn: 1 The function \"checkinput/check_finite\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_finite(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_check_nonzero" contains the normal interface for
 * the "checkinput/check_nonzero" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 301-310).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_check_nonzero(mxArray * A) {
    int nargout = 1;
    mxArray * tf = NULL;
    mlfEnterNewContext(0, 1, A);
    tf = Mcheckinput_check_nonzero(nargout, A);
    mlfRestorePreviousContext(0, 1, A);
    return mlfReturnValue(tf);
}

/*
 * The function "mlxCheckinput_check_nonzero" contains the feval interface for
 * the "checkinput/check_nonzero" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 301-310).
 * The feval function calls the implementation version of
 * checkinput/check_nonzero through this function. This function processes any
 * input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlxCheckinput_check_nonzero(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonzero Line: 301 C"
            "olumn: 1 The function \"checkinput/check_nonzero\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/check_nonzero Line: 301 "
            "Column: 1 The function \"checkinput/check_nonzero\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcheckinput_check_nonzero(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCheckinput_init_table" contains the normal interface for
 * the "checkinput/init_table" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 310-378).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfCheckinput_init_table(void) {
    int nargout = 1;
    mxArray * out = NULL;
    mlfEnterNewContext(0, 0);
    out = Mcheckinput_init_table(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(out);
}

/*
 * The function "mlxCheckinput_init_table" contains the feval interface for the
 * "checkinput/init_table" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 310-378).
 * The feval function calls the implementation version of checkinput/init_table
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxCheckinput_init_table(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/init_table Line: 310 Co"
            "lumn: 1 The function \"checkinput/init_table\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: checkinput/init_table Line: 310 C"
            "olumn: 1 The function \"checkinput/init_table\" was cal"
            "led with more than the declared number of inputs (0)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mcheckinput_init_table(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_checkinput" is the implementation version of
 * the "images/private/checkinput" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 1-41). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function checkinput(A, classes, attributes, function_name, ...
 */
static void Mimages_private_checkinput(mxArray * A,
                                       mxArray * classes,
                                       mxArray * attributes,
                                       mxArray * function_name,
                                       mxArray * variable_name,
                                       mxArray * argument_position) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * ans = NULL;
    mclCopyArray(&A);
    mclCopyArray(&classes);
    mclCopyArray(&attributes);
    mclCopyArray(&function_name);
    mclCopyArray(&variable_name);
    mclCopyArray(&argument_position);
    /*
     * variable_name, argument_position)
     * %CHECKINPUT Check validity of array.
     * %   CHECKINPUT(A,CLASSES,ATTRIBUTES,FUNCTION_NAME,VARIABLE_NAME, ...
     * %   ARGUMENT_POSITION) checks the validity of the array A and issues a
     * %   formatted error message if it is invalid.
     * %
     * %   CLASSES is either a space separated string or a cell array of strings
     * %   containing the set of classes that A is expected to belong to.  For
     * %   example, CLASSES could be 'uint8 double' if A can be either uint8 or
     * %   double.  CLASSES could be {'logical' 'cell'} if A can be either logical
     * %   or cell.  The string 'numeric' is interpreted as an abbreviation for all
     * %   the numeric classes.
     * %
     * %   ATTRIBUTES is either a space separated string or a cell array of strings
     * %   containing the set of attributes that A must satisfy.  To see the list of
     * %   valid attributes, see the subfunction init_table below.  For example, if
     * %   ATTRIBUTES is {'real' 'nonempty' 'finite'}, then A must be real and
     * %   nonempty, and it must contain only finite values.
     * %
     * %   FUNCTION_NAME is a string containing the function name to be used in the
     * %   formatted error message.
     * %
     * %   VARIABLE_NAME is a string containing the documented variable name to be
     * %   used in the formatted error message.
     * %
     * %   ARGUMENT_POSITION is a positive integer indicating which input argument
     * %   is being checked; it is also used in the formatted error message.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.5 $  $Date: 2002/05/20 20:27:03 $
     * 
     * % Input arguments are not checked for validity.
     * 
     * check_classes(A, classes, function_name, variable_name, argument_position);
     */
    mlfCheckinput_check_classes(
      mclVa(A, "A"),
      mclVa(classes, "classes"),
      mclVa(function_name, "function_name"),
      mclVa(variable_name, "variable_name"),
      mclVa(argument_position, "argument_position"));
    /*
     * 
     * check_attributes(A, attributes, function_name, variable_name, ...
     */
    mlfCheckinput_check_attributes(
      mclVa(A, "A"),
      mclVa(attributes, "attributes"),
      mclVa(function_name, "function_name"),
      mclVa(variable_name, "variable_name"),
      mclVa(argument_position, "argument_position"));
    mxDestroyArray(ans);
    mxDestroyArray(argument_position);
    mxDestroyArray(variable_name);
    mxDestroyArray(function_name);
    mxDestroyArray(attributes);
    mxDestroyArray(classes);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * argument_position);
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_is_numeric" is the implementation version of the
 * "checkinput/is_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 41-56). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = is_numeric(A)
 */
static mxArray * Mcheckinput_is_numeric(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mxArray * p = NULL;
    mxArray * numeric_classes = NULL;
    mclCopyArray(&A);
    /*
     * 
     * numeric_classes = {'double' 'uint8' 'uint16' 'uint32' 'int8' ...
     */
    mlfAssign(&numeric_classes, _mxarray0_);
    /*
     * 'int16' 'int32' 'single'};
     * 
     * tf = false;
     */
    mlfAssign(&tf, mlfFalse(NULL));
    /*
     * for p = 1:length(numeric_classes)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVv(numeric_classes, "numeric_classes"));
        if (v_ > e_) {
            mlfAssign(&p, _mxarray18_);
        } else {
            /*
             * if isa(A, numeric_classes{p})
             * tf = true;
             * break;
             * end
             * end
             */
            for (; ; ) {
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxIsa,
                        mclVa(A, "A"),
                        mlfIndexRef(
                          mclVv(numeric_classes, "numeric_classes"),
                          "{?}",
                          mlfScalar(v_)),
                        NULL))) {
                    mlfAssign(&tf, mlfTrue(NULL));
                    break;
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&p, mlfScalar(v_));
        }
    }
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/is_numeric");
    mxDestroyArray(numeric_classes);
    mxDestroyArray(p);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_expand_numeric" is the implementation version of
 * the "checkinput/expand_numeric" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 56-72). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = expand_numeric(in)
 */
static mxArray * Mcheckinput_expand_numeric(int nargout_, mxArray * in) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * out = NULL;
    mxArray * numeric_classes = NULL;
    mxArray * idx = NULL;
    mclCopyArray(&in);
    /*
     * % Converts the string 'numeric' to the equivalent cell array containing the
     * % names of the numeric classes.
     * 
     * out = in(:);
     */
    mlfAssign(&out, mclArrayRef1(mclVa(in, "in"), mlfCreateColonIndex()));
    /*
     * 
     * idx = strmatch('numeric', out, 'exact');
     */
    mlfAssign(&idx, mlfStrmatch(_mxarray19_, mclVv(out, "out"), _mxarray21_));
    /*
     * if (length(idx) == 1)
     */
    if (mclLengthInt(mclVv(idx, "idx")) == 1) {
        /*
         * out(idx) = [];
         */
        mlfIndexDelete(&out, "(?)", mclVv(idx, "idx"));
        /*
         * numeric_classes = {'uint8', 'int8', 'uint16', 'int16', ...
         */
        mlfAssign(&numeric_classes, _mxarray23_);
        /*
         * 'uint32', 'int32', 'single', 'double'}';
         * out = [out; numeric_classes];
         */
        mlfAssign(
          &out,
          mlfVertcat(
            mclVv(out, "out"),
            mclVv(numeric_classes, "numeric_classes"),
            NULL));
    /*
     * end
     */
    }
    mclValidateOutput(out, 1, nargout_, "out", "checkinput/expand_numeric");
    mxDestroyArray(idx);
    mxDestroyArray(numeric_classes);
    mxDestroyArray(in);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_classes" is the implementation version of
 * the "checkinput/check_classes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 72-122). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function check_classes(A, classes, function_name, ...
 */
static void Mcheckinput_check_classes(mxArray * A,
                                      mxArray * classes,
                                      mxArray * function_name,
                                      mxArray * variable_name,
                                      mxArray * argument_position) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * ans = NULL;
    mxArray * message3 = NULL;
    mxArray * message2 = NULL;
    mxArray * message1 = NULL;
    mxArray * validTypes = NULL;
    mxArray * messageId = NULL;
    mxArray * k = NULL;
    mxArray * is_valid_type = NULL;
    mclCopyArray(&A);
    mclCopyArray(&classes);
    mclCopyArray(&function_name);
    mclCopyArray(&variable_name);
    mclCopyArray(&argument_position);
    /*
     * variable_name, argument_position)
     * 
     * if isempty(classes)
     */
    if (mlfTobool(mlfIsempty(mclVa(classes, "classes")))) {
        /*
         * return
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if ischar(classes)
     */
    if (mlfTobool(mlfIschar(mclVa(classes, "classes")))) {
        /*
         * if isempty(classes)
         */
        if (mlfTobool(mlfIsempty(mclVa(classes, "classes")))) {
            /*
             * % Work around bug in strread.
             * classes = {};
             */
            mlfAssign(&classes, _mxarray25_);
        /*
         * else
         */
        } else {
            /*
             * classes = strread(classes, '%s');
             */
            mlfAssign(
              &classes,
              mlfNStrread(
                0,
                mclValueVarargout(),
                mclVa(classes, "classes"),
                _mxarray26_,
                NULL));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * is_valid_type = false;
     */
    mlfAssign(&is_valid_type, mlfFalse(NULL));
    /*
     * for k = 1:length(classes)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVa(classes, "classes"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray18_);
        } else {
            /*
             * if strcmp(classes{k}, 'numeric') && is_numeric(A)
             * is_valid_type = true;
             * break;
             * 
             * else        
             * if isa(A, classes{k})
             * is_valid_type = true;
             * break;
             * end
             * end
             * end
             */
            for (; ; ) {
                if (mclScalarToBool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxStrcmp,
                        mlfIndexRef(
                          mclVa(classes, "classes"), "{?}", mlfScalar(v_)),
                        _mxarray19_,
                        NULL))
                    && mclScalarToBool(
                         mlfCheckinput_is_numeric(mclVa(A, "A")))) {
                    mlfAssign(&is_valid_type, mlfTrue(NULL));
                    break;
                } else {
                    if (mlfTobool(
                          mclFeval(
                            mclValueVarargout(),
                            mlxIsa,
                            mclVa(A, "A"),
                            mlfIndexRef(
                              mclVa(classes, "classes"), "{?}", mlfScalar(v_)),
                            NULL))) {
                        mlfAssign(&is_valid_type, mlfTrue(NULL));
                        break;
                    }
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * if ~is_valid_type
     */
    if (mclNotBool(mclVv(is_valid_type, "is_valid_type"))) {
        /*
         * messageId = sprintf('Images:%s:%s', function_name, 'invalidType');
         */
        mlfAssign(
          &messageId,
          mlfSprintf(
            NULL,
            _mxarray28_,
            mclVa(function_name, "function_name"),
            _mxarray30_,
            NULL));
        /*
         * classes = expand_numeric(classes);
         */
        mlfAssign(
          &classes, mlfCheckinput_expand_numeric(mclVa(classes, "classes")));
        /*
         * validTypes = '';
         */
        mlfAssign(&validTypes, _mxarray32_);
        /*
         * for k = 1:length(classes)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclLengthInt(mclVa(classes, "classes"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray18_);
            } else {
                /*
                 * validTypes = [validTypes, classes{k}, ', '];
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &validTypes,
                      mlfHorzcat(
                        mclVv(validTypes, "validTypes"),
                        mlfIndexRef(
                          mclVa(classes, "classes"), "{?}", mlfScalar(v_)),
                        _mxarray33_,
                        NULL));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * validTypes(end-1:end) = [];
         */
        mlfIndexDelete(
          &validTypes,
          "(?)",
          mlfColon(
            mclMinus(
              mlfEnd(mclVv(validTypes, "validTypes"), _mxarray35_, _mxarray35_),
              _mxarray35_),
            mlfEnd(mclVv(validTypes, "validTypes"), _mxarray35_, _mxarray35_),
            NULL));
        /*
         * message1 = sprintf('Function %s expected its %s input argument, %s,', ...
         */
        mlfAssign(
          &message1,
          mlfSprintf(
            NULL,
            _mxarray36_,
            mclVa(function_name, "function_name"),
            mlfImages_private_num2ordinal(
              mclVa(argument_position, "argument_position")),
            mclVa(variable_name, "variable_name"),
            NULL));
        /*
         * function_name, ...
         * num2ordinal(argument_position), ...
         * variable_name);
         * message2 = 'to be one of these types:';
         */
        mlfAssign(&message2, _mxarray38_);
        /*
         * message3 = sprintf('Instead its type was %s.', class(A));
         */
        mlfAssign(
          &message3,
          mlfSprintf(
            NULL, _mxarray40_, mlfClassName(mclVa(A, "A"), NULL), NULL));
        /*
         * error(messageId, '%s\n%s\n\n  %s\n\n%s', message1, message2, validTypes, ...
         */
        mlfError(
          mclVv(messageId, "messageId"),
          _mxarray42_,
          mclVv(message1, "message1"),
          mclVv(message2, "message2"),
          mclVv(validTypes, "validTypes"),
          mclVv(message3, "message3"),
          NULL);
    /*
     * message3);
     * end
     */
    }
    /*
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
    return_:
    mxDestroyArray(is_valid_type);
    mxDestroyArray(k);
    mxDestroyArray(messageId);
    mxDestroyArray(validTypes);
    mxDestroyArray(message1);
    mxDestroyArray(message2);
    mxDestroyArray(message3);
    mxDestroyArray(ans);
    mxDestroyArray(argument_position);
    mxDestroyArray(variable_name);
    mxDestroyArray(function_name);
    mxDestroyArray(classes);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mcheckinput_check_attributes" is the implementation version of
 * the "checkinput/check_attributes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 122-155).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function check_attributes(A, attributes, function_name, ...
 */
static void Mcheckinput_check_attributes(mxArray * A,
                                         mxArray * attributes,
                                         mxArray * function_name,
                                         mxArray * variable_name,
                                         mxArray * argument_position) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * ans = NULL;
    mxArray * message2 = NULL;
    mxArray * message1 = NULL;
    mxArray * messageId = NULL;
    mxArray * tableEntry = NULL;
    mxArray * k = NULL;
    mxArray * table = NULL;
    mclCopyArray(&A);
    mclCopyArray(&attributes);
    mclCopyArray(&function_name);
    mclCopyArray(&variable_name);
    mclCopyArray(&argument_position);
    /*
     * variable_name, argument_position)
     * 
     * if ischar(attributes)
     */
    if (mlfTobool(mlfIschar(mclVa(attributes, "attributes")))) {
        /*
         * if isempty(attributes)
         */
        if (mlfTobool(mlfIsempty(mclVa(attributes, "attributes")))) {
            /*
             * % Work around bug in strread.
             * attributes = {};
             */
            mlfAssign(&attributes, _mxarray25_);
        /*
         * else
         */
        } else {
            /*
             * attributes = strread(attributes, '%s');
             */
            mlfAssign(
              &attributes,
              mlfNStrread(
                0,
                mclValueVarargout(),
                mclVa(attributes, "attributes"),
                _mxarray26_,
                NULL));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * table = init_table;
     */
    mlfAssign(&table, mlfCheckinput_init_table());
    /*
     * 
     * for k = 1:length(attributes)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVa(attributes, "attributes"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray18_);
        } else {
            /*
             * if strcmp(attributes{k}, '2d')
             * tableEntry = table.twod;
             * else
             * tableEntry = table.(attributes{k});
             * end
             * 
             * if ~feval(tableEntry.checkFunction, A)
             * messageId = sprintf('Images:%s:%s', function_name, ...
             * tableEntry.mnemonic);
             * message1 = sprintf('Function %s expected its %s input argument, %s,', ...
             * function_name, num2ordinal(argument_position), ...
             * variable_name);
             * message2 = sprintf('to be %s.', tableEntry.endOfMessage);
             * error(messageId, '%s\n%s', message1, message2);
             * end
             * end
             */
            for (; ; ) {
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxStrcmp,
                        mlfIndexRef(
                          mclVa(attributes, "attributes"),
                          "{?}",
                          mlfScalar(v_)),
                        _mxarray44_,
                        NULL))) {
                    mlfAssign(
                      &tableEntry, mlfIndexRef(mclVv(table, "table"), ".twod"));
                } else {
                    mlfAssign(
                      &tableEntry,
                      mlfIndexRef(
                        mclVv(table, "table"),
                        ".(?)",
                        mlfIndexRef(
                          mclVa(attributes, "attributes"),
                          "{?}",
                          mlfScalar(v_))));
                }
                if (mclNotBool(
                      mlfFeval(
                        mclValueVarargout(),
                        mlfIndexRef(
                          mclVv(tableEntry, "tableEntry"), ".checkFunction"),
                        mclVa(A, "A"),
                        NULL))) {
                    mlfAssign(
                      &messageId,
                      mlfSprintf(
                        NULL,
                        _mxarray28_,
                        mclVa(function_name, "function_name"),
                        mlfIndexRef(
                          mclVv(tableEntry, "tableEntry"), ".mnemonic"),
                        NULL));
                    mlfAssign(
                      &message1,
                      mlfSprintf(
                        NULL,
                        _mxarray36_,
                        mclVa(function_name, "function_name"),
                        mlfImages_private_num2ordinal(
                          mclVa(argument_position, "argument_position")),
                        mclVa(variable_name, "variable_name"),
                        NULL));
                    mlfAssign(
                      &message2,
                      mlfSprintf(
                        NULL,
                        _mxarray46_,
                        mlfIndexRef(
                          mclVv(tableEntry, "tableEntry"), ".endOfMessage"),
                        NULL));
                    mlfError(
                      mclVv(messageId, "messageId"),
                      _mxarray48_,
                      mclVv(message1, "message1"),
                      mclVv(message2, "message2"),
                      NULL);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    mxDestroyArray(table);
    mxDestroyArray(k);
    mxDestroyArray(tableEntry);
    mxDestroyArray(messageId);
    mxDestroyArray(message1);
    mxDestroyArray(message2);
    mxDestroyArray(ans);
    mxDestroyArray(argument_position);
    mxDestroyArray(variable_name);
    mxDestroyArray(function_name);
    mxDestroyArray(attributes);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_real" is the implementation version of the
 * "checkinput/check_real" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 155-164).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_real(A)
 */
static mxArray * Mcheckinput_check_real(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = isreal(A);
         */
        mlfAssign(&tf, mlfIsreal(mclVa(A, "A")));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_real");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_even" is the implementation version of the
 * "checkinput/check_even" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 164-173).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_even(A)
 */
static mxArray * Mcheckinput_check_even(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ~any(rem(double(A(:)),2));
         */
        mlfAssign(
          &tf,
          mclNot(
            mlfAny(
              mlfRem(
                mlfDouble(mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex())),
                _mxarray50_),
              NULL)));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_even");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_vector" is the implementation version of the
 * "checkinput/check_vector" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 173-182).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_vector(A)
 */
static mxArray * Mcheckinput_check_vector(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = (ndims(A) == 2) & (any(size(A) == 1) | all(size(A) == 0));
         */
        mlfAssign(
          &tf,
          mclAnd(
            mclEq(mlfNdims(mclVa(A, "A")), _mxarray50_),
            mclOr(
              mlfAny(
                mclEq(
                  mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL),
                  _mxarray35_),
                NULL),
              mlfAll(
                mclEq(
                  mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL),
                  _mxarray51_),
                NULL))));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_vector");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_row" is the implementation version of the
 * "checkinput/check_row" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 182-191).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_row(A)
 */
static mxArray * Mcheckinput_check_row(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = (ndims(A) == 2) & ((size(A,1) == 1) | isequal(size(A), [0 0]));
         */
        mlfAssign(
          &tf,
          mclAnd(
            mclEq(mlfNdims(mclVa(A, "A")), _mxarray50_),
            mclOr(
              mclEq(
                mlfSize(mclValueVarargout(), mclVa(A, "A"), _mxarray35_),
                _mxarray35_),
              mlfIsequal(
                mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL),
                _mxarray52_, NULL))));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_row");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_column" is the implementation version of the
 * "checkinput/check_column" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 191-200).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_column(A)
 */
static mxArray * Mcheckinput_check_column(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = (ndims(A) == 2) & ((size(A,2) == 1) | isequal(size(A), [0 0]));
         */
        mlfAssign(
          &tf,
          mclAnd(
            mclEq(mlfNdims(mclVa(A, "A")), _mxarray50_),
            mclOr(
              mclEq(
                mlfSize(mclValueVarargout(), mclVa(A, "A"), _mxarray50_),
                _mxarray35_),
              mlfIsequal(
                mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL),
                _mxarray52_, NULL))));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_column");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_scalar" is the implementation version of the
 * "checkinput/check_scalar" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 200-209).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_scalar(A)
 */
static mxArray * Mcheckinput_check_scalar(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = all(size(A) == 1);
         */
        mlfAssign(
          &tf,
          mlfAll(
            mclEq(
              mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL), _mxarray35_),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_scalar");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_2d" is the implementation version of the
 * "checkinput/check_2d" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 209-218).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_2d(A)
 */
static mxArray * Mcheckinput_check_2d(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ndims(A) == 2;
         */
        mlfAssign(&tf, mclEq(mlfNdims(mclVa(A, "A")), _mxarray50_));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_2d");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_nonsparse" is the implementation version of
 * the "checkinput/check_nonsparse" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 218-227).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_nonsparse(A)
 */
static mxArray * Mcheckinput_check_nonsparse(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ~issparse(A);
         */
        mlfAssign(&tf, mclNot(mlfIssparse(mclVa(A, "A"))));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_nonsparse");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_nonempty" is the implementation version of
 * the "checkinput/check_nonempty" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 227-236).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_nonempty(A)
 */
static mxArray * Mcheckinput_check_nonempty(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ~isempty(A);
         */
        mlfAssign(&tf, mclNot(mlfIsempty(mclVa(A, "A"))));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_nonempty");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_integer" is the implementation version of
 * the "checkinput/check_integer" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 236-258).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_integer(A)
 */
static mxArray * Mcheckinput_check_integer(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * A = A(:);
         */
        mlfAssign(&A, mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex()));
        /*
         * switch class(A)
         */
        {
            mxArray * v_ = mclInitialize(mlfClassName(mclVa(A, "A"), NULL));
            if (mclSwitchCompare(v_, _mxarray54_)) {
                /*
                 * 
                 * case {'double','single'}
                 * tf = all(floor(A) == A) & all(isfinite(A));
                 */
                mlfAssign(
                  &tf,
                  mclAnd(
                    mlfAll(mclEq(mlfFloor(mclVa(A, "A")), mclVa(A, "A")), NULL),
                    mlfAll(mlfIsfinite(mclVa(A, "A")), NULL)));
            /*
             * 
             * case {'uint8','int8','uint16','int16','uint32','int32','logical'}
             */
            } else if (mclSwitchCompare(v_, _mxarray56_)) {
                /*
                 * tf = true;
                 */
                mlfAssign(&tf, mlfTrue(NULL));
            /*
             * 
             * otherwise
             */
            } else {
                /*
                 * tf = false;
                 */
                mlfAssign(&tf, mlfFalse(NULL));
            /*
             * end
             */
            }
            mxDestroyArray(v_);
        }
    /*
     * 
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_integer");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_nonnegative" is the implementation version
 * of the "checkinput/check_nonnegative" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 258-267).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_nonnegative(A)
 */
static mxArray * Mcheckinput_check_nonnegative(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = all(A(:) >= 0);
         */
        mlfAssign(
          &tf,
          mlfAll(
            mclGe(
              mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex()), _mxarray51_),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_nonnegative");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_positive" is the implementation version of
 * the "checkinput/check_positive" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 267-276).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_positive(A)
 */
static mxArray * Mcheckinput_check_positive(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = all(A(:) > 0);
         */
        mlfAssign(
          &tf,
          mlfAll(
            mclGt(
              mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex()), _mxarray51_),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_positive");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_nonnan" is the implementation version of the
 * "checkinput/check_nonnan" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 276-289).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_nonnan(A)
 */
static mxArray * Mcheckinput_check_nonnan(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ~any(isnan(A(:)));
         */
        mlfAssign(
          &tf,
          mclNot(
            mlfAny(
              mlfIsnan(mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex())),
              NULL)));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * % if isnan isn't defined for the class of A,
         * % then we'll end up here.  If isnan isn't
         * % defined then we'll assume that A can't
         * % contain NaNs.
         * tf = true;
         */
        mlfAssign(&tf, mlfTrue(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_nonnan");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_finite" is the implementation version of the
 * "checkinput/check_finite" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 289-301).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_finite(A)
 */
static mxArray * Mcheckinput_check_finite(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = all(isfinite(A(:)));
         */
        mlfAssign(
          &tf,
          mlfAll(
            mlfIsfinite(mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex())),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * % if isfinite isn't defined for the class of A,
         * % then we'll end up here.  If isfinite isn't
         * % defined then we'll assume that A is finite.
         * tf = true;
         */
        mlfAssign(&tf, mlfTrue(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_finite");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_check_nonzero" is the implementation version of
 * the "checkinput/check_nonzero" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 301-310).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tf = check_nonzero(A)
 */
static mxArray * Mcheckinput_check_nonzero(int nargout_, mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * tf = NULL;
    mclCopyArray(&A);
    /*
     * 
     * try
     */
    mlfTry {
        /*
         * tf = ~all(A(:) == 0);
         */
        mlfAssign(
          &tf,
          mclNot(
            mlfAll(
              mclEq(
                mclArrayRef1(mclVa(A, "A"), mlfCreateColonIndex()),
                _mxarray51_),
              NULL)));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * tf = false;
         */
        mlfAssign(&tf, mlfFalse(NULL));
    /*
     * end
     */
    } mlfEndCatch
    mclValidateOutput(tf, 1, nargout_, "tf", "checkinput/check_nonzero");
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tf;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mcheckinput_init_table" is the implementation version of the
 * "checkinput/init_table" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkinput.m" (lines 310-378).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = init_table
 */
static mxArray * Mcheckinput_init_table(int nargout_) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkinput);
    mxArray * out = NULL;
    mxArray * ans = NULL;
    /*
     * 
     * persistent table
     * 
     * if isempty(table)
     */
    if (mlfTobool(
          mlfIsempty(
            mclVg(&_persistent_checkinput_init_table__table, "table")))) {
        /*
         * table.real.checkFunction        = @check_real;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".real.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_real, "check_real"));
        /*
         * table.real.mnemonic             = 'expectedReal';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".real.mnemonic",
          _mxarray60_);
        /*
         * table.real.endOfMessage         = 'real';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".real.endOfMessage",
          _mxarray62_);
        /*
         * 
         * table.vector.checkFunction      = @check_vector;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".vector.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_vector, "check_vector"));
        /*
         * table.vector.mnemonic           = 'expectedVector';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".vector.mnemonic",
          _mxarray64_);
        /*
         * table.vector.endOfMessage       = 'a vector';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".vector.endOfMessage",
          _mxarray66_);
        /*
         * 
         * table.row.checkFunction         = @check_row;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".row.checkFunction",
          mclCreateSimpleFunctionHandle(mlxCheckinput_check_row, "check_row"));
        /*
         * table.row.mnemonic              = 'expectedRow';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".row.mnemonic",
          _mxarray68_);
        /*
         * table.row.endOfMessage          = 'a row vector';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".row.endOfMessage",
          _mxarray70_);
        /*
         * 
         * table.column.checkFunction      = @check_column;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".column.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_column, "check_column"));
        /*
         * table.column.mnemonic           = 'expectedColumn';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".column.mnemonic",
          _mxarray72_);
        /*
         * table.column.endOfMessage       = 'a column vector';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".column.endOfMessage",
          _mxarray74_);
        /*
         * 
         * table.scalar.checkFunction      = @check_scalar;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".scalar.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_scalar, "check_scalar"));
        /*
         * table.scalar.mnemonic           = 'expectedScalar';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".scalar.mnemonic",
          _mxarray76_);
        /*
         * table.scalar.endOfMessage       = 'a scalar';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".scalar.endOfMessage",
          _mxarray78_);
        /*
         * 
         * table.twod.checkFunction        = @check_2d;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".twod.checkFunction",
          mclCreateSimpleFunctionHandle(mlxCheckinput_check_2d, "check_2d"));
        /*
         * table.twod.mnemonic             = 'expected2D';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".twod.mnemonic",
          _mxarray80_);
        /*
         * table.twod.endOfMessage         = 'two-dimensional';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".twod.endOfMessage",
          _mxarray82_);
        /*
         * 
         * table.nonsparse.checkFunction   = @check_nonsparse;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonsparse.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_nonsparse, "check_nonsparse"));
        /*
         * table.nonsparse.mnemonic        = 'expectedNonsparse';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonsparse.mnemonic",
          _mxarray84_);
        /*
         * table.nonsparse.endOfMessage    = 'nonsparse';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonsparse.endOfMessage",
          _mxarray86_);
        /*
         * 
         * table.nonempty.checkFunction    = @check_nonempty;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonempty.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_nonempty, "check_nonempty"));
        /*
         * table.nonempty.mnemonic         = 'expectedNonempty';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonempty.mnemonic",
          _mxarray88_);
        /*
         * table.nonempty.endOfMessage     = 'nonempty';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonempty.endOfMessage",
          _mxarray90_);
        /*
         * 
         * table.integer.checkFunction     = @check_integer;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".integer.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_integer, "check_integer"));
        /*
         * table.integer.mnemonic          = 'expectedInteger';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".integer.mnemonic",
          _mxarray92_);
        /*
         * table.integer.endOfMessage      = 'integer-valued';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".integer.endOfMessage",
          _mxarray94_);
        /*
         * 
         * table.nonnegative.checkFunction = @check_nonnegative;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnegative.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_nonnegative, "check_nonnegative"));
        /*
         * table.nonnegative.mnemonic      = 'expectedNonnegative';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnegative.mnemonic",
          _mxarray96_);
        /*
         * table.nonnegative.endOfMessage  = 'nonnegative';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnegative.endOfMessage",
          _mxarray98_);
        /*
         * 
         * table.positive.checkFunction    = @check_positive;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".positive.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_positive, "check_positive"));
        /*
         * table.positive.mnemonic         = 'expectedPositive';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".positive.mnemonic",
          _mxarray100_);
        /*
         * table.positive.endOfMessage     = 'positive';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".positive.endOfMessage",
          _mxarray102_);
        /*
         * 
         * table.nonnan.checkFunction      = @check_nonnan;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnan.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_nonnan, "check_nonnan"));
        /*
         * table.nonnan.mnemonic           = 'expectedNonNaN';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnan.mnemonic",
          _mxarray104_);
        /*
         * table.nonnan.endOfMessage       = 'non-NaN';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonnan.endOfMessage",
          _mxarray106_);
        /*
         * 
         * table.finite.checkFunction      = @check_finite;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".finite.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_finite, "check_finite"));
        /*
         * table.finite.mnemonic           = 'expectedFinite';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".finite.mnemonic",
          _mxarray108_);
        /*
         * table.finite.endOfMessage       = 'finite';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".finite.endOfMessage",
          _mxarray110_);
        /*
         * 
         * table.nonzero.checkFunction     = @check_nonzero;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonzero.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_nonzero, "check_nonzero"));
        /*
         * table.nonzero.mnemonic          = 'expectedNonZero';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonzero.mnemonic",
          _mxarray112_);
        /*
         * table.nonzero.endOfMessage      = 'non-zero';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".nonzero.endOfMessage",
          _mxarray114_);
        /*
         * 
         * table.even.checkFunction        = @check_even;
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".even.checkFunction",
          mclCreateSimpleFunctionHandle(
            mlxCheckinput_check_even, "check_even"));
        /*
         * table.even.mnemonic             = 'expectedEven';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".even.mnemonic",
          _mxarray116_);
        /*
         * table.even.endOfMessage         = 'even';
         */
        mlfIndexAssign(
          mclPrepareGlobal(&_persistent_checkinput_init_table__table),
          ".even.endOfMessage",
          _mxarray118_);
    /*
     * 
     * end
     */
    }
    /*
     * 
     * out = table;
     */
    mlfAssign(&out, mclVg(&_persistent_checkinput_init_table__table, "table"));
    mclValidateOutput(out, 1, nargout_, "out", "checkinput/init_table");
    mxDestroyArray(ans);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
}
