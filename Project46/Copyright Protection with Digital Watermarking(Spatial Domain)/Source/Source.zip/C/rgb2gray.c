/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "rgb2gray.h"
#include "im2double.h"
#include "libmatlbm.h"

static mxChar _array1_[21] = { 'N', 'e', 'e', 'd', ' ', 'i', 'n',
                               'p', 'u', 't', ' ', 'a', 'r', 'g',
                               'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray0_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static mxChar _array6_[26] = { 'W', 'r', 'o', 'n', 'g', ' ', 'n', 'u', 'm',
                               'b', 'e', 'r', ' ', 'o', 'f', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray5_;

static mxChar _array8_[91] = { 'R', 'G', 'B', '2', 'G', 'R', 'A', 'Y', '(', 'R',
                               ',', 'G', ',', 'B', ')', ' ', 'i', 's', ' ', 'a',
                               'n', ' ', 'o', 'b', 's', 'o', 'l', 'e', 't', 'e',
                               ' ', 's', 'y', 'n', 't', 'a', 'x', '.', 'U', 's',
                               'e', ' ', 'a', ' ', 't', 'h', 'r', 'e', 'e', '-',
                               'd', 'i', 'm', 'e', 'n', 's', 'i', 'o', 'n', 'a',
                               'l', ' ', 'a', 'r', 'r', 'a', 'y', ' ', 't', 'o',
                               ' ', 'r', 'e', 'p', 'r', 'e', 's', 'e', 'n', 't',
                               ' ', 'R', 'G', 'B', ' ', 'i', 'm', 'a', 'g', 'e',
                               '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[38] = { 'R', ',', ' ', 'G', ',', ' ', 'a', 'n',
                                'd', ' ', 'B', ' ', 'm', 'u', 's', 't',
                                ' ', 'a', 'l', 'l', ' ', 'b', 'e', ' ',
                                't', 'h', 'e', ' ', 's', 'a', 'm', 'e',
                                ' ', 's', 'i', 'z', 'e', '.' };
static mxArray * _mxarray9_;

static mxChar _array12_[24] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray11_;

static double _array14_[9] = { 1.0, 1.0, 1.0, .956, -.272,
                               -1.106, .621, -.647, 1.703 };
static mxArray * _mxarray13_;

static mxChar _array16_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray15_;

static mxChar _array18_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray17_;

static mxChar _array20_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray19_;
static mxArray * _mxarray21_;

void InitializeModule_rgb2gray(void) {
    _mxarray0_ = mclInitializeString(21, _array1_);
    _mxarray2_ = mclInitializeDouble(3.0);
    _mxarray3_ = mclInitializeDouble(1.0);
    _mxarray4_ = mclInitializeDouble(2.0);
    _mxarray5_ = mclInitializeString(26, _array6_);
    _mxarray7_ = mclInitializeString(91, _array8_);
    _mxarray9_ = mclInitializeString(38, _array10_);
    _mxarray11_ = mclInitializeString(24, _array12_);
    _mxarray13_ = mclInitializeDoubleVector(3, 3, _array14_);
    _mxarray15_ = mclInitializeString(5, _array16_);
    _mxarray17_ = mclInitializeString(6, _array18_);
    _mxarray19_ = mclInitializeString(6, _array20_);
    _mxarray21_ = mclInitializeDouble(0.0);
}

void TerminateModule_rgb2gray(void) {
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mrgb2gray(int nargout_, mxArray * r, mxArray * g, mxArray * b);

_mexLocalFunctionTable _local_function_table_rgb2gray
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfRgb2gray" contains the normal interface for the "rgb2gray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\rgb2gray.m" (lines
 * 1-72). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfRgb2gray(mxArray * r, mxArray * g, mxArray * b) {
    int nargout = 1;
    mxArray * a = NULL;
    mlfEnterNewContext(0, 3, r, g, b);
    a = Mrgb2gray(nargout, r, g, b);
    mlfRestorePreviousContext(0, 3, r, g, b);
    return mlfReturnValue(a);
}

/*
 * The function "mlxRgb2gray" contains the feval interface for the "rgb2gray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\rgb2gray.m" (lines
 * 1-72). The feval function calls the implementation version of rgb2gray
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxRgb2gray(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: rgb2gray Line: 1 Column:"
            " 1 The function \"rgb2gray\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: rgb2gray Line: 1 Column:"
            " 1 The function \"rgb2gray\" was called with m"
            "ore than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mrgb2gray(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mrgb2gray" is the implementation version of the "rgb2gray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\rgb2gray.m" (lines
 * 1-72). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function a = rgb2gray(r,g,b)
 */
static mxArray * Mrgb2gray(int nargout_,
                           mxArray * r,
                           mxArray * g,
                           mxArray * b) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_rgb2gray);
    int nargin_ = mclNargin(3, r, g, b, NULL);
    mxArray * a = NULL;
    mxArray * T = NULL;
    mxArray * rgb = NULL;
    mxArray * threeD = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&r);
    mclCopyArray(&g);
    mclCopyArray(&b);
    /*
     * %RGB2GRAY Convert RGB image or colormap to grayscale.
     * %   RGB2GRAY converts RGB images to grayscale by eliminating the
     * %   hue and saturation information while retaining the
     * %   luminance.
     * %
     * %   I = RGB2GRAY(RGB) converts the truecolor image RGB to the
     * %   grayscale intensity image I.
     * %
     * %   NEWMAP = RGB2GRAY(MAP) returns a grayscale colormap
     * %   equivalent to MAP.
     * %
     * %   Class Support
     * %   -------------
     * %   If the input is an RGB image, it can be of class uint8, 
     * %   uint16 or double; the output image I is of the same class 
     * %   as the input image. If the input is a colormap, the input 
     * %   and output colormaps are both of class double.
     * %
     * %   See also IND2GRAY, NTSC2RGB, RGB2IND, RGB2NTSC.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.20 $  $Date: 2002/03/15 15:29:04 $
     * 
     * if nargin==0,
     */
    if (nargin_ == 0) {
        /*
         * error('Need input arguments.');
         */
        mlfError(_mxarray0_, NULL);
    /*
     * end
     */
    }
    /*
     * threeD = (ndims(r)==3); % Determine if input includes a 3-D array 
     */
    mlfAssign(&threeD, mclEq(mlfNdims(mclVa(r, "r")), _mxarray2_));
    /*
     * 
     * if nargin==1,
     */
    if (nargin_ == 1) {
        /*
         * if threeD,
         */
        if (mlfTobool(mclVv(threeD, "threeD"))) {
            /*
             * rgb = reshape(r(:),size(r,1)*size(r,2),3);
             */
            mlfAssign(
              &rgb,
              mlfReshape(
                mclArrayRef1(mclVa(r, "r"), mlfCreateColonIndex()),
                mclMtimes(
                  mlfSize(mclValueVarargout(), mclVa(r, "r"), _mxarray3_),
                  mlfSize(mclValueVarargout(), mclVa(r, "r"), _mxarray4_)),
                _mxarray2_,
                NULL));
            /*
             * a = zeros([size(r,1), size(r,2)]);
             */
            mlfAssign(
              &a,
              mlfZeros(
                mlfHorzcat(
                  mlfSize(mclValueVarargout(), mclVa(r, "r"), _mxarray3_),
                  mlfSize(mclValueVarargout(), mclVa(r, "r"), _mxarray4_),
                  NULL),
                NULL));
        /*
         * else % Colormap
         */
        } else {
            /*
             * rgb = r;
             */
            mlfAssign(&rgb, mclVa(r, "r"));
            /*
             * a = zeros(size(r,1),1);
             */
            mlfAssign(
              &a,
              mlfZeros(
                mlfSize(mclValueVarargout(), mclVa(r, "r"), _mxarray3_),
                _mxarray3_,
                NULL));
        /*
         * end
         */
        }
    /*
     * 
     * elseif nargin==2,
     */
    } else if (nargin_ == 2) {
        /*
         * error('Wrong number of arguments.');
         */
        mlfError(_mxarray5_, NULL);
    /*
     * 
     * elseif nargin==3,
     */
    } else if (nargin_ == 3) {
        /*
         * warning(['RGB2GRAY(R,G,B) is an obsolete syntax.',...
         */
        mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray7_, NULL));
        /*
         * 'Use a three-dimensional array to represent RGB image.']);
         * if (any(size(r)~=size(g)) | any(size(r)~=size(b))),
         */
        {
            mxArray * a_
              = mclInitialize(
                  mlfAny(
                    mclNe(
                      mlfSize(mclValueVarargout(), mclVa(r, "r"), NULL),
                      mlfSize(mclValueVarargout(), mclVa(g, "g"), NULL)),
                    NULL));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mlfAny(
                         mclNe(
                           mlfSize(mclValueVarargout(), mclVa(r, "r"), NULL),
                           mlfSize(mclValueVarargout(), mclVa(b, "b"), NULL)),
                         NULL)))) {
                mxDestroyArray(a_);
                /*
                 * error('R, G, and B must all be the same size.')
                 */
                mlfError(_mxarray9_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * rgb = [r(:), g(:), b(:)];
         */
        mlfAssign(
          &rgb,
          mlfHorzcat(
            mclArrayRef1(mclVa(r, "r"), mlfCreateColonIndex()),
            mclArrayRef1(mclVa(g, "g"), mlfCreateColonIndex()),
            mclArrayRef1(mclVa(b, "b"), mlfCreateColonIndex()),
            NULL));
        /*
         * a = zeros(size(r));
         */
        mlfAssign(
          &a,
          mlfZeros(mlfSize(mclValueVarargout(), mclVa(r, "r"), NULL), NULL));
    /*
     * else
     */
    } else {
        /*
         * error('Invalid input arguments.');
         */
        mlfError(_mxarray11_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * T = inv([1.0 0.956 0.621; 1.0 -0.272 -0.647; 1.0 -1.106 1.703]);
     */
    mlfAssign(&T, mlfInv(_mxarray13_));
    /*
     * 
     * if isa(rgb, 'uint8')  
     */
    if (mlfTobool(mlfIsa(mclVv(rgb, "rgb"), _mxarray15_))) {
        /*
         * a = uint8(reshape(double(rgb)*T(1,:)', size(a)));
         */
        mlfAssign(
          &a,
          mlfUint8(
            mlfReshape(
              mlf_times_transpose(
                mlfDouble(mclVv(rgb, "rgb")),
                mclArrayRef2(mclVv(T, "T"), _mxarray3_, mlfCreateColonIndex()),
                _mxarray4_),
              mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL), NULL)));
    /*
     * elseif isa(rgb, 'uint16')
     */
    } else if (mlfTobool(mlfIsa(mclVv(rgb, "rgb"), _mxarray17_))) {
        /*
         * a = uint16(reshape(double(rgb)*T(1,:)', size(a)));
         */
        mlfAssign(
          &a,
          mlfUint16(
            mlfReshape(
              mlf_times_transpose(
                mlfDouble(mclVv(rgb, "rgb")),
                mclArrayRef2(mclVv(T, "T"), _mxarray3_, mlfCreateColonIndex()),
                _mxarray4_),
              mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL), NULL)));
    /*
     * elseif isa(rgb, 'double')    
     */
    } else if (mlfTobool(mlfIsa(mclVv(rgb, "rgb"), _mxarray19_))) {
        /*
         * a = reshape(rgb*T(1,:)', size(a));
         */
        mlfAssign(
          &a,
          mlfReshape(
            mlf_times_transpose(
              mclVv(rgb, "rgb"),
              mclArrayRef2(mclVv(T, "T"), _mxarray3_, mlfCreateColonIndex()),
              _mxarray4_),
            mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL), NULL));
        /*
         * a = min(max(a,0),1);
         */
        mlfAssign(
          &a,
          mlfMin(
            NULL,
            mlfMax(NULL, mclVv(a, "a"), _mxarray21_, NULL),
            _mxarray3_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if ((nargin==1) & (~threeD)),    % rgb2gray(MAP)
     */
    {
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ == 1));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclNot(mclVv(threeD, "threeD"))))) {
            mxDestroyArray(a_);
            /*
             * if ~isa(a, 'double')
             */
            if (mclNotBool(mlfIsa(mclVv(a, "a"), _mxarray19_))) {
                /*
                 * a = im2double(a);
                 */
                mlfAssign(&a, mlfIm2double(mclVv(a, "a"), NULL));
            /*
             * end
             */
            }
            /*
             * a = [a,a,a];
             */
            mlfAssign(
              &a,
              mlfHorzcat(mclVv(a, "a"), mclVv(a, "a"), mclVv(a, "a"), NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(a, 1, nargout_, "a", "rgb2gray");
    mxDestroyArray(ans);
    mxDestroyArray(threeD);
    mxDestroyArray(rgb);
    mxDestroyArray(T);
    mxDestroyArray(b);
    mxDestroyArray(g);
    mxDestroyArray(r);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return a;
    /*
     * 
     */
}
