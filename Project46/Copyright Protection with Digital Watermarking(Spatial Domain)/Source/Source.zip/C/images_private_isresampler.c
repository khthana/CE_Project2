/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_isresampler.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[6] = { 's', 't', 'r', 'u', 'c', 't' };
static mxArray * _mxarray0_;

static mxChar _array3_[5] = { 'n', 'd', 'i', 'm', 's' };
static mxArray * _mxarray2_;

static mxChar _array5_[9] = { 'p', 'a', 'd', 'm', 'e', 't', 'h', 'o', 'd' };
static mxArray * _mxarray4_;

static mxChar _array7_[10] = { 'r', 'e', 's', 'a', 'm',
                               'p', '_', 'f', 'c', 'n' };
static mxArray * _mxarray6_;

static mxChar _array9_[5] = { 'r', 'd', 'a', 't', 'a' };
static mxArray * _mxarray8_;

static mxChar _array11_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray10_;
static mxArray * _mxarray12_;

static mxChar _array14_[4] = { 'c', 'h', 'a', 'r' };
static mxArray * _mxarray13_;

static mxChar _array16_[15] = { 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                '_', 'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray15_;
static double _ieee_plusinf_;
static mxArray * _mxarray17_;

static mxChar _array21_[4] = { 'f', 'i', 'l', 'l' };
static mxArray * _mxarray20_;

static mxChar _array23_[5] = { 'b', 'o', 'u', 'n', 'd' };
static mxArray * _mxarray22_;

static mxChar _array25_[9] = { 'r', 'e', 'p', 'l', 'i', 'c', 'a', 't', 'e' };
static mxArray * _mxarray24_;

static mxChar _array27_[8] = { 'c', 'i', 'r', 'c', 'u', 'l', 'a', 'r' };
static mxArray * _mxarray26_;

static mxChar _array29_[9] = { 's', 'y', 'm', 'm', 'e', 't', 'r', 'i', 'c' };
static mxArray * _mxarray28_;

static mxArray * _array19_[5] = { NULL /*_mxarray20_*/, NULL /*_mxarray22_*/,
                                  NULL /*_mxarray24_*/, NULL /*_mxarray26_*/,
                                  NULL /*_mxarray28_*/ };
static mxArray * _mxarray18_;

static mxChar _array31_[5] = { 'e', 'x', 'a', 'c', 't' };
static mxArray * _mxarray30_;

void InitializeModule_images_private_isresampler(void) {
    _mxarray0_ = mclInitializeString(6, _array1_);
    _mxarray2_ = mclInitializeString(5, _array3_);
    _mxarray4_ = mclInitializeString(9, _array5_);
    _mxarray6_ = mclInitializeString(10, _array7_);
    _mxarray8_ = mclInitializeString(5, _array9_);
    _mxarray10_ = mclInitializeString(6, _array11_);
    _mxarray12_ = mclInitializeDouble(1.0);
    _mxarray13_ = mclInitializeString(4, _array14_);
    _mxarray15_ = mclInitializeString(15, _array16_);
    _ieee_plusinf_ = mclGetInf();
    _mxarray17_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray20_ = mclInitializeString(4, _array21_);
    _array19_[0] = _mxarray20_;
    _mxarray22_ = mclInitializeString(5, _array23_);
    _array19_[1] = _mxarray22_;
    _mxarray24_ = mclInitializeString(9, _array25_);
    _array19_[2] = _mxarray24_;
    _mxarray26_ = mclInitializeString(8, _array27_);
    _array19_[3] = _mxarray26_;
    _mxarray28_ = mclInitializeString(9, _array29_);
    _array19_[4] = _mxarray28_;
    _mxarray18_ = mclInitializeCellVector(1, 5, _array19_);
    _mxarray30_ = mclInitializeString(5, _array31_);
}

void TerminateModule_images_private_isresampler(void) {
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_isresampler(int nargout_, mxArray * R);

_mexLocalFunctionTable _local_function_table_images_private_isresampler
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_isresampler" contains the normal interface
 * for the "images/private/isresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\isresampler.m" (lines 1-44).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImages_private_isresampler(mxArray * R) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, R);
    q = Mimages_private_isresampler(nargout, R);
    mlfRestorePreviousContext(0, 1, R);
    return mlfReturnValue(q);
}

/*
 * The function "mlxImages_private_isresampler" contains the feval interface
 * for the "images/private/isresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\isresampler.m" (lines 1-44). The
 * feval function calls the implementation version of
 * images/private/isresampler through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
void mlxImages_private_isresampler(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/isresampler Line: 1 C"
            "olumn: 1 The function \"images/private/isresampler\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/isresampler Line: 1 C"
            "olumn: 1 The function \"images/private/isresampler\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimages_private_isresampler(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_isresampler" is the implementation version of
 * the "images/private/isresampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\isresampler.m" (lines 1-44). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = isresampler(R)
 */
static mxArray * Mimages_private_isresampler(int nargout_, mxArray * R) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_isresampler);
    mxArray * q = NULL;
    mclCopyArray(&R);
    /*
     * %ISRESAMPLER True for valid resampling structure.
     * %   ISRESAMPLER(R) returns 1 if R is a valid resampler struct, such as
     * %   one created by MAKERESAMPLER, and 0 otherwise.
     * % 
     * %   See also MAKERESAMPLER.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.3 $ $Date: 2002/03/15 15:57:49 $
     * 
     * q = isa(R,'struct') ...
     */
    mlfAssign(
      &q,
      mclAnd(
        mclAnd(
          mclAnd(
            mclAnd(
              mlfIsa(mclVa(R, "R"), _mxarray0_),
              mlfIsfield(mclVa(R, "R"), _mxarray2_)),
            mlfIsfield(mclVa(R, "R"), _mxarray4_)),
          mlfIsfield(mclVa(R, "R"), _mxarray6_)),
        mlfIsfield(mclVa(R, "R"), _mxarray8_)));
    /*
     * & isfield(R,'ndims') ...
     * & isfield(R,'padmethod') ...
     * & isfield(R,'resamp_fcn') ...
     * & isfield(R,'rdata');
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = (length(R) == 1);
         */
        mlfAssign(&q, mclBoolToArray(mclLengthInt(mclVa(R, "R")) == 1));
    /*
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = ~isempty(R.ndims) ...
         */
        mlfAssign(
          &q,
          mclAnd(
            mclAnd(
              mclNot(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mlfIndexRef(mclVa(R, "R"), ".ndims"),
                  NULL)),
              mclNot(
                mclFeval(
                  mclValueVarargout(),
                  mlxIsempty,
                  mlfIndexRef(mclVa(R, "R"), ".resamp_fcn"),
                  NULL))),
            mclNot(
              mclFeval(
                mclValueVarargout(),
                mlxIsempty,
                mlfIndexRef(mclVa(R, "R"), ".padmethod"),
                NULL))));
    /*
     * & ~isempty(R.resamp_fcn) ...
     * & ~isempty(R.padmethod);
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = isa(R.ndims,'double')     ...
         */
        mlfAssign(
          &q,
          mclAnd(
            mclAnd(
              mclAnd(
                mclAnd(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIsa,
                    mlfIndexRef(mclVa(R, "R"), ".ndims"),
                    _mxarray10_,
                    NULL),
                  mclEq(
                    mclFeval(
                      mclValueVarargout(),
                      mlxLength,
                      mlfIndexRef(mclVa(R, "R"), ".ndims"),
                      NULL),
                    _mxarray12_)),
                mclFeval(
                  mclValueVarargout(),
                  mlxIsreal,
                  mlfIndexRef(mclVa(R, "R"), ".ndims"),
                  NULL)),
              mclFeval(
                mclValueVarargout(),
                mlxIsa,
                mlfIndexRef(mclVa(R, "R"), ".padmethod"),
                _mxarray13_,
                NULL)),
            mclFeval(
              mclValueVarargout(),
              mlxIsa,
              mlfIndexRef(mclVa(R, "R"), ".resamp_fcn"),
              _mxarray15_,
              NULL)));
    /*
     * & length(R.ndims) == 1    ...
     * & isreal(R.ndims)         ...
     * & isa(R.padmethod,'char') ...
     * & isa(R.resamp_fcn,'function_handle');
     * end
     */
    }
    /*
     * 
     * if (q & R.ndims ~= Inf)
     */
    {
        mxArray * a_ = mclInitialize(mclVv(q, "q"));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxNe,
                     mlfIndexRef(mclVa(R, "R"), ".ndims"),
                     _mxarray17_,
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * q = R.ndims == floor(R.ndims) ...
             */
            mlfAssign(
              &q,
              mclAnd(
                mclFeval(
                  mclValueVarargout(),
                  mlxEq,
                  mlfIndexRef(mclVa(R, "R"), ".ndims"),
                  mclFeval(
                    mclValueVarargout(),
                    mlxFloor,
                    mlfIndexRef(mclVa(R, "R"), ".ndims"),
                    NULL),
                  NULL),
                mclFeval(
                  mclValueVarargout(),
                  mlxGe,
                  mlfIndexRef(mclVa(R, "R"), ".ndims"),
                  _mxarray12_,
                  NULL)));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * & R.ndims >= 1;
     * end
     */
    }
    /*
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = (length(strmatch(R.padmethod,...
         */
        mlfAssign(
          &q,
          mclBoolToArray(
            mclLengthInt(
              mclFeval(
                mclValueVarargout(),
                mlxStrmatch,
                mlfIndexRef(mclVa(R, "R"), ".padmethod"),
                _mxarray18_,
                _mxarray30_,
                NULL))
            == 1));
    /*
     * {'fill','bound','replicate','circular','symmetric'},'exact')) == 1);
     * end
     */
    }
    mclValidateOutput(q, 1, nargout_, "q", "images/private/isresampler");
    mxDestroyArray(R);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
}
