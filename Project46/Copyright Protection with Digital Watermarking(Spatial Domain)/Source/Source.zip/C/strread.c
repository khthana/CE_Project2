/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "strread.h"
#include "dataread_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static double _ieee_plusinf_;
static mxArray * _mxarray1_;

static mxChar _array3_[6] = { 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray2_;

void InitializeModule_strread(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _ieee_plusinf_ = mclGetInf();
    _mxarray1_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray2_ = mclInitializeString(6, _array3_);
}

void TerminateModule_strread(void) {
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mstrread(int nargout_, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_strread
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNStrread" contains the nargout interface for the "strread"
 * M-function from file "k:\matlab6p5\toolbox\matlab\iofun\strread.m" (lines
 * 1-52). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNStrread(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mstrread(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfStrread" contains the normal interface for the "strread"
 * M-function from file "k:\matlab6p5\toolbox\matlab\iofun\strread.m" (lines
 * 1-52). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfStrread(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mstrread(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVStrread" contains the void interface for the "strread"
 * M-function from file "k:\matlab6p5\toolbox\matlab\iofun\strread.m" (lines
 * 1-52). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVStrread(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mstrread(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxStrread" contains the feval interface for the "strread"
 * M-function from file "k:\matlab6p5\toolbox\matlab\iofun\strread.m" (lines
 * 1-52). The feval function calls the implementation version of strread
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxStrread(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mstrread(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mstrread" is the implementation version of the "strread"
 * M-function from file "k:\matlab6p5\toolbox\matlab\iofun\strread.m" (lines
 * 1-52). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = strread(varargin);
 */
static mxArray * Mstrread(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_strread);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * _T0_ = NULL;
    mxArray * nlhs = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * %STRREAD Read formatted data from string.
     * %    A = STRREAD('STRING')
     * %    A = STRREAD('STRING','',N)
     * %    A = STRREAD('STRING','',param,value, ...)
     * %    A = STRREAD('STRING','',N,param,value, ...) reads numeric data from
     * %    the STRING into a single variable.  If the string contains any text data,
     * %    an error is produced.
     * %
     * %    [A,B,C, ...] = STRREAD('STRING','FORMAT')
     * %    [A,B,C, ...] = STRREAD('STRING','FORMAT',N)
     * %    [A,B,C, ...] = STRREAD('STRING','FORMAT',param,value, ...)
     * %    [A,B,C, ...] = STRREAD('STRING','FORMAT',N,param,value, ...) reads
     * %    data from the STRING into the variables A,B,C,etc.  The type of each
     * %    return argument is given by the FORMAT string.  The number of return
     * %    arguments must match the number of conversion specifiers in the FORMAT
     * %    string.  If there are fewer fields in the string than matching conversion
     * %    specifiers in the format string, an error is produced.
     * %
     * %    If N is specified, the format string is reused N times.  If N is -1 (or
     * %    not specified) STRREAD reads the entire string.
     * %
     * %    Example
     * %
     * %      s = sprintf('a,1,2\nb,3,4\n');
     * %      [a,b,c] = strread(s,'%s%d%d','delimiter',',')
     * %
     * %   See TEXTREAD for more examples and definition of terms.
     * %
     * %   See also TEXTREAD, SSCANF, FILEFORMATS.
     * 
     * %   Copyright 1984-2002 The MathWorks, Inc. 
     * %   $Revision: 1.6 $ $Date: 2002/06/05 20:10:15 $
     * 
     * %   Implemented as a mex file.
     * 
     * % do some preliminary error checking
     * error(nargchk(1,inf,nargin));
     */
    mlfError(mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)), NULL);
    /*
     * 
     * % allow empty string to pass through untouched
     * if isempty(varargin{1})
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxIsempty,
            mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
            NULL))) {
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if nargout == 0
     */
    if (nargout_ == 0) {
        /*
         * nlhs = 1;
         */
        mlfAssign(&nlhs, _mxarray0_);
    /*
     * else
     */
    } else {
        /*
         * nlhs = nargout;
         */
        mlfAssign(&nlhs, mlfScalar(nargout_));
    /*
     * end
     */
    }
    mlfAssign(&_T0_, mlfColon(_mxarray0_, mclVv(nlhs, "nlhs"), NULL));
    /*
     * 
     * [varargout{1:nlhs}]=dataread('string',varargin{:});
     */
    mlfNDataread(
      0,
      mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
      _mxarray2_,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
      NULL);
    return_:
    mxDestroyArray(ans);
    mxDestroyArray(nlhs);
    mxDestroyArray(_T0_);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
}
