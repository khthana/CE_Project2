/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __strread_h
#define __strread_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_strread(void);
extern void TerminateModule_strread(void);
extern _mexLocalFunctionTable _local_function_table_strread;

extern mxArray * mlfNStrread(int nargout, mlfVarargoutList * varargout, ...);
extern mxArray * mlfStrread(mlfVarargoutList * varargout, ...);
extern void mlfVStrread(mxArray * synthetic_varargin_argument, ...);
extern void mlxStrread(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
