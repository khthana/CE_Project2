/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "fliptform.h"
#include "images_private_checknargin.h"
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "maketform.h"
static mxArray * _mxarray0_;

static mxChar _array2_[32] = { 'T', ' ', 'm', 'u', 's', 't', ' ', 'b',
                               'e', ' ', 'a', ' ', 's', 'i', 'n', 'g',
                               'l', 'e', ' ', 'T', 'F', 'O', 'R', 'M',
                               ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray1_;

static mxChar _array4_[34] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                               ':', 't', 'M', 'u', 's', 't', 'B', 'e', 'S',
                               'i', 'n', 'g', 'l', 'e', 'T', 'f', 'o', 'r',
                               'm', 'S', 't', 'r', 'u', 'c', 't' };
static mxArray * _mxarray3_;

static mxChar _array6_[6] = { 'c', 'u', 's', 't', 'o', 'm' };
static mxArray * _mxarray5_;

void InitializeModule_fliptform(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeString(32, _array2_);
    _mxarray3_ = mclInitializeString(34, _array4_);
    _mxarray5_ = mclInitializeString(6, _array6_);
}

void TerminateModule_fliptform(void) {
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mfliptform(int nargout_, mxArray * t);

_mexLocalFunctionTable _local_function_table_fliptform
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfFliptform" contains the normal interface for the
 * "fliptform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\fliptform.m" (lines 1-31). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfFliptform(mxArray * t) {
    int nargout = 1;
    mxArray * tflip = NULL;
    mlfEnterNewContext(0, 1, t);
    tflip = Mfliptform(nargout, t);
    mlfRestorePreviousContext(0, 1, t);
    return mlfReturnValue(tflip);
}

/*
 * The function "mlxFliptform" contains the feval interface for the "fliptform"
 * M-function from file "k:\matlab6p5\toolbox\images\images\fliptform.m" (lines
 * 1-31). The feval function calls the implementation version of fliptform
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxFliptform(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: fliptform Line: 1 Column:"
            " 1 The function \"fliptform\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: fliptform Line: 1 Column:"
            " 1 The function \"fliptform\" was called with m"
            "ore than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mfliptform(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mfliptform" is the implementation version of the "fliptform"
 * M-function from file "k:\matlab6p5\toolbox\images\images\fliptform.m" (lines
 * 1-31). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tflip = fliptform( t )
 */
static mxArray * Mfliptform(int nargout_, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_fliptform);
    int nargin_ = mclNargin(1, t, NULL);
    mxArray * tflip = NULL;
    mxArray * eid = NULL;
    mxArray * msg = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&t);
    /*
     * %FLIPTFORM Flip the input and output roles of a TFORM structure.
     * %   TFLIP = FLIPTFORM(T) creates a new spatial transformation structure (a
     * %   "TFORM struct") by flipping the roles of the inputs and outputs in an
     * %   existing TFORM struct.
     * %
     * %   Example
     * %   -------
     * %       T = maketform('affine',[.5 0 0; .5 2 0; 0 0 1]);
     * %       T2 = fliptform(T);
     * %
     * %   The following are equivalent:
     * %       x = tformfwd([-3 7],T)
     * %       x = tforminv([-3 7],T2)
     * %
     * %   See also MAKETFORM, TFORMFWD, TFORMINV.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.8 $ $Date: 2002/03/15 15:27:15 $
     * 
     * checknargin(1,1,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray0_, mlfScalar(nargin_), mxCreateString("fliptform"));
    /*
     * 
     * if ~istform(t) | (length(t) ~= 1)
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfImages_private_istform(mclVa(t, "t"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclBoolToArray(mclLengthInt(mclVa(t, "t")) != 1)))) {
            mxDestroyArray(a_);
            /*
             * msg = 'T must be a single TFORM struct.';
             */
            mlfAssign(&msg, _mxarray1_);
            /*
             * eid = sprintf('Images:%s:tMustBeSingleTformStruct',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray3_, mxCreateString("fliptform"), NULL));
            /*
             * error(eid, msg);
             */
            mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * tflip = maketform('custom', t.ndims_out, t.ndims_in, t.inverse_fcn, ...
     */
    mlfAssign(
      &tflip,
      mlfMaketform(
        _mxarray5_,
        mlfIndexRef(mclVa(t, "t"), ".ndims_out"),
        mlfIndexRef(mclVa(t, "t"), ".ndims_in"),
        mlfIndexRef(mclVa(t, "t"), ".inverse_fcn"),
        mlfIndexRef(mclVa(t, "t"), ".forward_fcn"),
        mlfIndexRef(mclVa(t, "t"), ".tdata"),
        NULL));
    mclValidateOutput(tflip, 1, nargout_, "tflip", "fliptform");
    mxDestroyArray(ans);
    mxDestroyArray(msg);
    mxDestroyArray(eid);
    mxDestroyArray(t);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tflip;
    /*
     * t.forward_fcn, t.tdata);
     */
}
