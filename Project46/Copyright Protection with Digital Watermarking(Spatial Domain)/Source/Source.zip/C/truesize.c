/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "truesize.h"
#include "libsgl.h"
#include "iptgetpref.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static double _array6_[2] = { 1.0, 2.0 };
static mxArray * _mxarray5_;

static mxChar _array8_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray7_;

static mxChar _array10_[6] = { 'f', 'i', 'g', 'u', 'r', 'e' };
static mxArray * _mxarray9_;

static mxChar _array12_[33] = { 'F', 'I', 'G', ' ', 'm', 'u', 's', 't', ' ',
                                'b', 'e', ' ', 'a', ' ', 'v', 'a', 'l', 'i',
                                'd', ' ', 'f', 'i', 'g', 'u', 'r', 'e', ' ',
                                'h', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray11_;

static mxChar _array14_[11] = { 'C', 'u', 'r', 'r', 'e', 'n',
                                't', 'A', 'x', 'e', 's' };
static mxArray * _mxarray13_;

static mxChar _array16_[26] = { 'C', 'u', 'r', 'r', 'e', 'n', 't', ' ', 'f',
                                'i', 'g', 'u', 'r', 'e', ' ', 'h', 'a', 's',
                                ' ', 'n', 'o', ' ', 'a', 'x', 'e', 's' };
static mxArray * _mxarray15_;

static mxChar _array18_[31] = { 'R', 'E', 'Q', 'S', 'I', 'Z', 'E', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                                'a', ' ', '1', '-', 'b', 'y', '-', '2',
                                ' ', 'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray17_;

static mxChar _array20_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray19_;

static mxChar _array22_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray21_;

static mxChar _array24_[5] = { 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray23_;

static mxChar _array26_[7] = { 's', 'u', 'r', 'f', 'a', 'c', 'e' };
static mxArray * _mxarray25_;

static mxChar _array28_[9] = { 'F', 'a', 'c', 'e', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray27_;

static mxChar _array30_[10] = { 't', 'e', 'x', 't', 'u',
                                'r', 'e', 'm', 'a', 'p' };
static mxArray * _mxarray29_;

static mxChar _array32_[3] = { 'T', 'a', 'g' };
static mxArray * _mxarray31_;

static mxChar _array34_[12] = { 'T', 'M', 'W', '_', 'C', 'O',
                                'L', 'O', 'R', 'B', 'A', 'R' };
static mxArray * _mxarray33_;

static mxChar _array36_[49] = { 'N', 'o', ' ', 'i', 'm', 'a', 'g', 'e', 's',
                                ' ', 'o', 'r', ' ', 't', 'e', 'x', 't', 'u',
                                'r', 'e', 'm', 'a', 'p', 'p', 'e', 'd', ' ',
                                's', 'u', 'r', 'f', 'a', 'c', 'e', 's', ' ',
                                'i', 'n', ' ', 't', 'h', 'e', ' ', 'f', 'i',
                                'g', 'u', 'r', 'e' };
static mxArray * _mxarray35_;

static mxChar _array38_[4] = { 'f', 'l', 'a', 't' };
static mxArray * _mxarray37_;

static mxChar _array40_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray39_;

static mxChar _array42_[9] = { 'u', 'i', 'c', 'o', 'n', 't', 'r', 'o', 'l' };
static mxArray * _mxarray41_;

static mxChar _array44_[7] = { 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray43_;

static mxChar _array46_[2] = { 'o', 'n' };
static mxArray * _mxarray45_;

static mxChar _array48_[6] = { 'u', 'i', 'm', 'e', 'n', 'u' };
static mxArray * _mxarray47_;

static mxChar _array50_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray49_;

static mxChar _array52_[5] = { 'C', 'D', 'a', 't', 'a' };
static mxArray * _mxarray51_;
static mxArray * _mxarray53_;

static mxChar _array55_[5] = { 'U', 'n', 'i', 't', 's' };
static mxArray * _mxarray54_;

static mxChar _array57_[6] = { 'p', 'i', 'x', 'e', 'l', 's' };
static mxArray * _mxarray56_;

static mxChar _array59_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray58_;
static mxArray * _mxarray60_;
static mxArray * _mxarray61_;
static mxArray * _mxarray62_;
static mxArray * _mxarray63_;

static mxChar _array65_[10] = { 'S', 'c', 'r', 'e', 'e',
                                'n', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray64_;
static double _ieee_plusinf_;
static mxArray * _mxarray66_;
static mxArray * _mxarray67_;

static mxChar _array69_[19] = { 'D', 'e', 'f', 'a', 'u', 'l', 't',
                                'A', 'x', 'e', 's', 'P', 'o', 's',
                                'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray68_;
static mxArray * _mxarray70_;

static mxChar _array72_[8] = { 'N', 'e', 'x', 't', 'P', 'l', 'o', 't' };
static mxArray * _mxarray71_;

static mxChar _array74_[15] = { 'r', 'e', 'p', 'l', 'a', 'c', 'e', 'c',
                                'h', 'i', 'l', 'd', 'r', 'e', 'n' };
static mxArray * _mxarray73_;

static mxChar _array76_[15] = { 'T', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                                'W', 'a', 'r', 'n', 'i', 'n', 'g' };
static mxArray * _mxarray75_;

static mxChar _array78_[35] = { 'I', 'm', 'a', 'g', 'e', ' ', 'i', 's', ' ',
                                't', 'o', 'o', ' ', 'b', 'i', 'g', ' ', 't',
                                'o', ' ', 'f', 'i', 't', ' ', 'o', 'n', ' ',
                                's', 'c', 'r', 'e', 'e', 'n', ';', ' ' };
static mxArray * _mxarray77_;

static mxChar _array80_[25] = { 'd', 'i', 's', 'p', 'l', 'a', 'y', 'i', 'n',
                                'g', ' ', 'a', 't', ' ', '%', 'd', '%', '%',
                                ' ', 's', 'c', 'a', 'l', 'e', '.' };
static mxArray * _mxarray79_;

static double _array82_[2] = { 2.0, 1.0 };
static mxArray * _mxarray81_;
static mxArray * _mxarray83_;

static mxChar _array85_[10] = { 'n', 'o', 'r', 'm', 'a',
                                'l', 'i', 'z', 'e', 'd' };
static mxArray * _mxarray84_;

static mxChar _array87_[48] = { 'I', 'm', 'a', 'g', 'e', ' ', 'i', 's',
                                ' ', 't', 'o', 'o', ' ', 's', 'm', 'a',
                                'l', 'l', ' ', 'f', 'o', 'r', ' ', 't',
                                'r', 'u', 'e', 's', 'i', 'z', 'e', ' ',
                                'f', 'i', 'g', 'u', 'r', 'e', ' ', 's',
                                'c', 'a', 'l', 'i', 'n', 'g', ';', ' ' };
static mxArray * _mxarray86_;

static mxChar _array89_[27] = { 0x005c, 'n', 'd', 'i', 's', 'p', 'l', 'a', 'y',
                                'i', 'n', 'g', ' ', 'a', 't', ' ', '%', 'd',
                                '%', '%', ' ', 's', 'c', 'a', 'l', 'e', '.' };
static mxArray * _mxarray88_;
static mxArray * _mxarray90_;

static mxChar _array92_[8] = { 'v', 'e', 'r', 't', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray91_;

static mxChar _array94_[10] = { 'h', 'o', 'r', 'i', 'z',
                                'o', 'n', 't', 'a', 'l' };
static mxArray * _mxarray93_;

static mxChar _array96_[21] = { 'F', 'a', 'c', 't', 'o', 'r', 'y',
                                'F', 'i', 'g', 'u', 'r', 'e', 'P',
                                'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray95_;

static mxChar _array98_[19] = { 'F', 'a', 'c', 't', 'o', 'r', 'y',
                                'A', 'x', 'e', 's', 'P', 'o', 's',
                                'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray97_;

void InitializeModule_truesize(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeDouble(3.0);
    _mxarray3_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray4_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray5_ = mclInitializeDoubleVector(1, 2, _array6_);
    _mxarray7_ = mclInitializeString(4, _array8_);
    _mxarray9_ = mclInitializeString(6, _array10_);
    _mxarray11_ = mclInitializeString(33, _array12_);
    _mxarray13_ = mclInitializeString(11, _array14_);
    _mxarray15_ = mclInitializeString(26, _array16_);
    _mxarray17_ = mclInitializeString(31, _array18_);
    _mxarray19_ = mclInitializeString(6, _array20_);
    _mxarray21_ = mclInitializeString(4, _array22_);
    _mxarray23_ = mclInitializeString(5, _array24_);
    _mxarray25_ = mclInitializeString(7, _array26_);
    _mxarray27_ = mclInitializeString(9, _array28_);
    _mxarray29_ = mclInitializeString(10, _array30_);
    _mxarray31_ = mclInitializeString(3, _array32_);
    _mxarray33_ = mclInitializeString(12, _array34_);
    _mxarray35_ = mclInitializeString(49, _array36_);
    _mxarray37_ = mclInitializeString(4, _array38_);
    _mxarray39_ = mclInitializeString(4, _array40_);
    _mxarray41_ = mclInitializeString(9, _array42_);
    _mxarray43_ = mclInitializeString(7, _array44_);
    _mxarray45_ = mclInitializeString(2, _array46_);
    _mxarray47_ = mclInitializeString(6, _array48_);
    _mxarray49_ = mclInitializeString(3, _array50_);
    _mxarray51_ = mclInitializeString(5, _array52_);
    _mxarray53_ = mclInitializeDouble(0.0);
    _mxarray54_ = mclInitializeString(5, _array55_);
    _mxarray56_ = mclInitializeString(6, _array57_);
    _mxarray58_ = mclInitializeString(8, _array59_);
    _mxarray60_ = mclInitializeDouble(10.0);
    _mxarray61_ = mclInitializeDouble(50.0);
    _mxarray62_ = mclInitializeDouble(30.0);
    _mxarray63_ = mclInitializeDouble(128.0);
    _mxarray64_ = mclInitializeString(10, _array65_);
    _ieee_plusinf_ = mclGetInf();
    _mxarray66_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray67_ = mclInitializeDouble(100.0);
    _mxarray68_ = mclInitializeString(19, _array69_);
    _mxarray70_ = mclInitializeDouble(4.0);
    _mxarray71_ = mclInitializeString(8, _array72_);
    _mxarray73_ = mclInitializeString(15, _array74_);
    _mxarray75_ = mclInitializeString(15, _array76_);
    _mxarray77_ = mclInitializeString(35, _array78_);
    _mxarray79_ = mclInitializeString(25, _array80_);
    _mxarray81_ = mclInitializeDoubleVector(1, 2, _array82_);
    _mxarray83_ = mclInitializeDouble(2.220446049250313e-16);
    _mxarray84_ = mclInitializeString(10, _array85_);
    _mxarray86_ = mclInitializeString(48, _array87_);
    _mxarray88_ = mclInitializeString(27, _array89_);
    _mxarray90_ = mclInitializeDouble(20.0);
    _mxarray91_ = mclInitializeString(8, _array92_);
    _mxarray93_ = mclInitializeString(10, _array94_);
    _mxarray95_ = mclInitializeString(21, _array96_);
    _mxarray97_ = mclInitializeString(19, _array98_);
}

void TerminateModule_truesize(void) {
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray84_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfTruesize_ParseInputs(mxArray * * imHandle,
                                         mxArray * * colorbarHandle,
                                         mxArray * * imSize,
                                         mxArray * * resizeType,
                                         mxArray * * msg,
                                         ...);
static void mlxTruesize_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static void mlfTruesize_Resize1(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize);
static void mlxTruesize_Resize1(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void mlfTruesize_Resize2(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize);
static void mlxTruesize_Resize2(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void mlfTruesize_Resize3(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize,
                                mxArray * colorbarHandle);
static void mlxTruesize_Resize3(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]);
static void Mtruesize(mxArray * varargin);
static mxArray * Mtruesize_ParseInputs(mxArray * * imHandle,
                                       mxArray * * colorbarHandle,
                                       mxArray * * imSize,
                                       mxArray * * resizeType,
                                       mxArray * * msg,
                                       int nargout_,
                                       mxArray * varargin);
static void Mtruesize_Resize1(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize);
static void Mtruesize_Resize2(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize);
static void Mtruesize_Resize3(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize,
                              mxArray * colorbarHandle);

static mexFunctionTableEntry local_function_table_[4]
  = { { "ParseInputs", mlxTruesize_ParseInputs, -1, 6, NULL },
      { "Resize1", mlxTruesize_Resize1, 3, 0, NULL },
      { "Resize2", mlxTruesize_Resize2, 3, 0, NULL },
      { "Resize3", mlxTruesize_Resize3, 4, 0, NULL } };

_mexLocalFunctionTable _local_function_table_truesize
  = { 4, local_function_table_ };

/*
 * The function "mlfTruesize" contains the normal interface for the "truesize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\truesize.m" (lines
 * 1-55). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlfTruesize(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    Mtruesize(varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxTruesize" contains the feval interface for the "truesize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\truesize.m" (lines
 * 1-55). The feval function calls the implementation version of truesize
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxTruesize(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize Line: 1 Column:"
            " 1 The function \"truesize\" was called with m"
            "ore than the declared number of outputs (0)."),
          NULL);
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    Mtruesize(mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfTruesize_ParseInputs" contains the normal interface for the
 * "truesize/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 55-176). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTruesize_ParseInputs(mxArray * * imHandle,
                                         mxArray * * colorbarHandle,
                                         mxArray * * imSize,
                                         mxArray * * resizeType,
                                         mxArray * * msg,
                                         ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * axHandle = NULL;
    mxArray * imHandle__ = NULL;
    mxArray * colorbarHandle__ = NULL;
    mxArray * imSize__ = NULL;
    mxArray * resizeType__ = NULL;
    mxArray * msg__ = NULL;
    mlfVarargin(&varargin, msg, 0);
    mlfEnterNewContext(
      5, -1, imHandle, colorbarHandle, imSize, resizeType, msg, varargin);
    if (imHandle != NULL) {
        ++nargout;
    }
    if (colorbarHandle != NULL) {
        ++nargout;
    }
    if (imSize != NULL) {
        ++nargout;
    }
    if (resizeType != NULL) {
        ++nargout;
    }
    if (msg != NULL) {
        ++nargout;
    }
    axHandle
      = Mtruesize_ParseInputs(
          &imHandle__,
          &colorbarHandle__,
          &imSize__,
          &resizeType__,
          &msg__,
          nargout,
          varargin);
    mlfRestorePreviousContext(
      5, 0, imHandle, colorbarHandle, imSize, resizeType, msg);
    mxDestroyArray(varargin);
    if (imHandle != NULL) {
        mclCopyOutputArg(imHandle, imHandle__);
    } else {
        mxDestroyArray(imHandle__);
    }
    if (colorbarHandle != NULL) {
        mclCopyOutputArg(colorbarHandle, colorbarHandle__);
    } else {
        mxDestroyArray(colorbarHandle__);
    }
    if (imSize != NULL) {
        mclCopyOutputArg(imSize, imSize__);
    } else {
        mxDestroyArray(imSize__);
    }
    if (resizeType != NULL) {
        mclCopyOutputArg(resizeType, resizeType__);
    } else {
        mxDestroyArray(resizeType__);
    }
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(axHandle);
}

/*
 * The function "mlxTruesize_ParseInputs" contains the feval interface for the
 * "truesize/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 55-176). The feval
 * function calls the implementation version of truesize/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTruesize_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[6];
    int i;
    if (nlhs > 6) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/ParseInputs Line: 55 Col"
            "umn: 1 The function \"truesize/ParseInputs\" was called"
            " with more than the declared number of outputs (6)."),
          NULL);
    }
    for (i = 0; i < 6; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mtruesize_ParseInputs(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          &mplhs[5],
          nlhs,
          mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 6 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 6; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfTruesize_Resize1" contains the normal interface for the
 * "truesize/Resize1" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 176-317). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize1(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize) {
    mlfEnterNewContext(0, 3, axHandle, imHandle, imSize);
    Mtruesize_Resize1(axHandle, imHandle, imSize);
    mlfRestorePreviousContext(0, 3, axHandle, imHandle, imSize);
}

/*
 * The function "mlxTruesize_Resize1" contains the feval interface for the
 * "truesize/Resize1" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 176-317). The feval
 * function calls the implementation version of truesize/Resize1 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize1(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize1 Line: 176 Col"
            "umn: 1 The function \"truesize/Resize1\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize1 Line: 176 Col"
            "umn: 1 The function \"truesize/Resize1\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mtruesize_Resize1(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfTruesize_Resize2" contains the normal interface for the
 * "truesize/Resize2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 317-439). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize2(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize) {
    mlfEnterNewContext(0, 3, axHandle, imHandle, imSize);
    Mtruesize_Resize2(axHandle, imHandle, imSize);
    mlfRestorePreviousContext(0, 3, axHandle, imHandle, imSize);
}

/*
 * The function "mlxTruesize_Resize2" contains the feval interface for the
 * "truesize/Resize2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 317-439). The feval
 * function calls the implementation version of truesize/Resize2 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize2(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize2 Line: 317 Col"
            "umn: 1 The function \"truesize/Resize2\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize2 Line: 317 Col"
            "umn: 1 The function \"truesize/Resize2\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mtruesize_Resize2(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfTruesize_Resize3" contains the normal interface for the
 * "truesize/Resize3" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 439-585). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTruesize_Resize3(mxArray * axHandle,
                                mxArray * imHandle,
                                mxArray * imSize,
                                mxArray * colorbarHandle) {
    mlfEnterNewContext(0, 4, axHandle, imHandle, imSize, colorbarHandle);
    Mtruesize_Resize3(axHandle, imHandle, imSize, colorbarHandle);
    mlfRestorePreviousContext(0, 4, axHandle, imHandle, imSize, colorbarHandle);
}

/*
 * The function "mlxTruesize_Resize3" contains the feval interface for the
 * "truesize/Resize3" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 439-585). The feval
 * function calls the implementation version of truesize/Resize3 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxTruesize_Resize3(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize3 Line: 439 Col"
            "umn: 1 The function \"truesize/Resize3\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: truesize/Resize3 Line: 439 Col"
            "umn: 1 The function \"truesize/Resize3\" was called "
            "with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    Mtruesize_Resize3(mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
}

/*
 * The function "Mtruesize" is the implementation version of the "truesize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\truesize.m" (lines
 * 1-55). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function truesize(varargin)
 */
static void Mtruesize(mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_truesize);
    mxArray * ans = NULL;
    mxArray * msg = NULL;
    mxArray * resizeType = NULL;
    mxArray * imSize = NULL;
    mxArray * colorbarHandle = NULL;
    mxArray * imHandle = NULL;
    mxArray * axHandle = NULL;
    mclCopyArray(&varargin);
    /*
     * %TRUESIZE Adjust display size of image.
     * %   TRUESIZE(FIG,[MROWS NCOLS]) adjusts the display size of an
     * %   image. FIG is a figure containing a single image or a single 
     * %   image with a colorbar. [MROWS MCOLS] is a 1-by-2 vector that
     * %   specifies the requested screen area (in pixels) that the
     * %   image should occupy.
     * %
     * %   TRUESIZE(FIG) uses the image height and width for 
     * %   [MROWS MCOLS]. This results in the display having one screen
     * %   pixel for each image pixel.
     * %
     * %   If you omit the figure argument, TRUESIZE works on the
     * %   current figure.
     * %
     * %   Remarks
     * %   -------
     * %   If the 'TruesizeWarning' toolbox preference is 'on', TRUESIZE
     * %   displays a warning if the image is too large to fit on the
     * %   screen. (The entire image is still displayed, but at less
     * %   than true size.) If 'TruesizeWarning' is 'off', TRUESIZE does
     * %   not display the warning. Note that this preference applies
     * %   even when you call TRUESIZE indirectly, such as through
     * %   IMSHOW.
     * %
     * %   See also IMSHOW, IPTSETPREF, IPTGETPREF.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 5.25 $  $Date: 2002/03/15 15:29:25 $
     * 
     * [axHandle, imHandle, colorbarHandle, imSize, resizeType, msg] = ...
     * ParseInputs(varargin{:});
     */
    mlfAssign(
      &axHandle,
      mlfTruesize_ParseInputs(
        &imHandle,
        &colorbarHandle,
        &imSize,
        &resizeType,
        &msg,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if (~isempty(msg))
     */
    if (mclNotBool(mlfIsempty(mclVv(msg, "msg")))) {
        /*
         * error(msg);
         */
        mlfError(mclVv(msg, "msg"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * switch resizeType
     */
    {
        mxArray * v_ = mclInitialize(mclVv(resizeType, "resizeType"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1
             * % Figure contains one image and nothing else
             * Resize1(axHandle, imHandle, imSize);
             */
            mlfTruesize_Resize1(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"));
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray1_)) {
            /*
             * % Figure contains other noncolorbar axes
             * % or uicontrols.
             * Resize2(axHandle, imHandle, imSize);
             */
            mlfTruesize_Resize2(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"));
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * % Figure contains one image and a colorbar.
             * Resize3(axHandle, imHandle, imSize, colorbarHandle);
             */
            mlfTruesize_Resize3(
              mclVv(axHandle, "axHandle"),
              mclVv(imHandle, "imHandle"),
              mclVv(imSize, "imSize"),
              mclVv(colorbarHandle, "colorbarHandle"));
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(axHandle);
    mxDestroyArray(imHandle);
    mxDestroyArray(colorbarHandle);
    mxDestroyArray(imSize);
    mxDestroyArray(resizeType);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %--------------------------------------------
     * % Subfunction ParseInputs
     * %--------------------------------------------
     */
}

/*
 * The function "Mtruesize_ParseInputs" is the implementation version of the
 * "truesize/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 55-176). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [axHandle,imHandle,colorbarHandle,imSize,resizeType,msg] = ...
 */
static mxArray * Mtruesize_ParseInputs(mxArray * * imHandle,
                                       mxArray * * colorbarHandle,
                                       mxArray * * imSize,
                                       mxArray * * resizeType,
                                       mxArray * * msg,
                                       int nargout_,
                                       mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_truesize);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * axHandle = NULL;
    mxArray * otherKids = NULL;
    mxArray * invisUicontrolKids = NULL;
    mxArray * uimenuKids = NULL;
    mxArray * colorbarAxes = NULL;
    mxArray * figKids = NULL;
    mxArray * k = NULL;
    mxArray * h = NULL;
    mxArray * figHandle = NULL;
    mclCopyArray(&varargin);
    /*
     * ParseInputs(varargin)
     * 
     * imSize = [];
     */
    mlfAssign(imSize, _mxarray3_);
    /*
     * colorbarHandle = [];
     */
    mlfAssign(colorbarHandle, _mxarray3_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray4_);
    /*
     * axHandle = [];
     */
    mlfAssign(&axHandle, _mxarray3_);
    /*
     * imHandle = [];
     */
    mlfAssign(imHandle, _mxarray3_);
    /*
     * resizeType = [];
     */
    mlfAssign(resizeType, _mxarray3_);
    /*
     * 
     * if (nargin == 0)
     */
    if (nargin_ == 0) {
        /*
         * axHandle = gca;
         */
        mlfAssign(&axHandle, mlfGca(NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin >= 1)
     */
    if (nargin_ >= 1) {
        /*
         * if ((nargin == 1) & isequal(size(varargin{1}), [1 2]))
         */
        mxArray * a_ = mclInitialize(mclBoolToArray(nargin_ == 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfIsequal(
                     mclFeval(
                       mclValueVarargout(),
                       mlxSize,
                       mlfIndexRef(
                         mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                       NULL),
                     _mxarray5_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * % truesize([M N])
             * figHandle = gcf;
             */
            mlfAssign(&figHandle, mlfGcf());
            /*
             * imSize = varargin{1};
             */
            mlfAssign(
              imSize,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * 
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * % truesize(FIG, ...)
             * if (~ishandle(varargin{1}) | ~strcmp(get(varargin{1},'type'),'figure'))
             */
            {
                mxArray * a_0
                  = mclInitialize(
                      mclNot(
                        mclFeval(
                          mclValueVarargout(),
                          mlxIshandle,
                          mlfIndexRef(
                            mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                          NULL)));
                if (mlfTobool(a_0)
                    || mlfTobool(
                         mclOr(
                           a_0,
                           mclNot(
                             mlfStrcmp(
                               mlfNGet(
                                 1,
                                 mlfIndexRef(
                                   mclVa(varargin, "varargin"),
                                   "{?}",
                                   _mxarray0_),
                                 _mxarray7_,
                                 NULL),
                               _mxarray9_))))) {
                    mxDestroyArray(a_0);
                    /*
                     * msg = 'FIG must be a valid figure handle';
                     */
                    mlfAssign(msg, _mxarray11_);
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * else
                 */
                } else {
                    mxDestroyArray(a_0);
                    /*
                     * figHandle = varargin{1};
                     */
                    mlfAssign(
                      &figHandle,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", _mxarray0_));
                }
            /*
             * end
             */
            }
        }
        /*
         * end
         * 
         * axHandle = get(figHandle, 'CurrentAxes');
         */
        mlfAssign(
          &axHandle,
          mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray13_, NULL));
        /*
         * if (isempty(axHandle))
         */
        if (mlfTobool(mlfIsempty(mclVv(axHandle, "axHandle")))) {
            /*
             * msg = 'Current figure has no axes';
             */
            mlfAssign(msg, _mxarray15_);
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (nargin >= 2)
     */
    if (nargin_ >= 2) {
        /*
         * imSize = varargin{2};
         */
        mlfAssign(
          imSize, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
        /*
         * if (~isequal(size(imSize), [1 2]))
         */
        if (mclNotBool(
              mlfIsequal(
                mlfSize(mclValueVarargout(), mclVv(*imSize, "imSize"), NULL),
                _mxarray5_, NULL))) {
            /*
             * msg = 'REQSIZE must be a 1-by-2 vector';
             */
            mlfAssign(msg, _mxarray17_);
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVv(axHandle, "axHandle"), _mxarray19_, NULL));
    /*
     * 
     * % Find all the images and texturemapped surfaces
     * % in the current figure.  These are the candidates.
     * h = [findobj(figHandle, 'Type', 'image') ;
     */
    mlfAssign(
      &h,
      mlfVertcat(
        mlfFindobj(
          mclVv(figHandle, "figHandle"), _mxarray21_, _mxarray23_, NULL),
        mlfFindobj(
          mclVv(figHandle, "figHandle"),
          _mxarray21_,
          _mxarray25_,
          _mxarray27_,
          _mxarray29_,
          NULL),
        NULL));
    /*
     * findobj(figHandle, 'Type', 'surface', ...
     * 'FaceColor', 'texturemap')];
     * 
     * % If there's a colorbar, ignore it.
     * colorbarHandle = findobj(figHandle, 'type', 'image', ...
     */
    mlfAssign(
      colorbarHandle,
      mlfFindobj(
        mclVv(figHandle, "figHandle"),
        _mxarray7_,
        _mxarray23_,
        _mxarray31_,
        _mxarray33_,
        NULL));
    /*
     * 'Tag', 'TMW_COLORBAR');
     * if (~isempty(colorbarHandle))
     */
    if (mclNotBool(mlfIsempty(mclVv(*colorbarHandle, "colorbarHandle")))) {
        /*
         * for k = 1:length(colorbarHandle)
         */
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVv(*colorbarHandle, "colorbarHandle"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray3_);
        } else {
            /*
             * h(h == colorbarHandle(k)) = [];
             * end
             */
            for (; ; ) {
                mlfIndexDelete(
                  &h,
                  "(?)",
                  mclEq(
                    mclVv(h, "h"),
                    mclIntArrayRef1(
                      mclVv(*colorbarHandle, "colorbarHandle"), v_)));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (isempty(h))
     */
    if (mlfTobool(mlfIsempty(mclVv(h, "h")))) {
        /*
         * msg = 'No images or texturemapped surfaces in the figure';
         */
        mlfAssign(msg, _mxarray35_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * % Start with the first object on the list as the
     * % initial candidate.  If it's not in the current
     * % axes, look for another one that is.
     * imHandle = h(1);
     */
    mlfAssign(imHandle, mclIntArrayRef1(mclVv(h, "h"), 1));
    /*
     * if (get(imHandle,'Parent') ~= axHandle)
     */
    if (mclNeBool(
          mlfNGet(1, mclVv(*imHandle, "imHandle"), _mxarray19_, NULL),
          mclVv(axHandle, "axHandle"))) {
        /*
         * for k = 2:length(h)
         */
        int v_ = mclForIntStart(2);
        int e_ = mclLengthInt(mclVv(h, "h"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray3_);
        } else {
            /*
             * if (get(h(k),'Parent') == axHandle)
             * imHandle = h(k);
             * break;
             * end
             * end
             */
            for (; ; ) {
                if (mclEqBool(
                      mlfNGet(
                        1,
                        mclIntArrayRef1(mclVv(h, "h"), v_), _mxarray19_, NULL),
                      mclVv(axHandle, "axHandle"))) {
                    mlfAssign(imHandle, mclIntArrayRef1(mclVv(h, "h"), v_));
                    break;
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    /*
     * end
     */
    }
    /*
     * 
     * figKids = allchild(figHandle);
     */
    mlfAssign(&figKids, mlfAllchild(mclVv(figHandle, "figHandle")));
    /*
     * if ((length(findobj(figKids, 'flat', 'Type', 'axes')) == 1) & ...
     */
    if (mclLengthInt(
          mlfFindobj(
            mclVv(figKids, "figKids"),
            _mxarray37_,
            _mxarray21_,
            _mxarray39_,
            NULL))
        == 1
        && mclLengthInt(
             mlfFindobj(
               mclVv(figKids, "figKids"),
               _mxarray37_,
               _mxarray21_,
               _mxarray41_,
               _mxarray43_,
               _mxarray45_,
               NULL))
           == 0
        && mclLengthInt(mclVv(*imHandle, "imHandle")) == 1) {
        /*
         * (length(findobj(figKids, 'flat', 'Type', 'uicontrol', ...
         * 'Visible', 'on')) == 0) & ...
         * (length(imHandle) == 1))
         * % Resize type 1
         * % Figure contains only one axes object, which contains only
         * % one image.
         * resizeType = 1;
         */
        mlfAssign(resizeType, _mxarray0_);
    /*
     * 
     * elseif (isempty(colorbarHandle))
     */
    } else if (mlfTobool(
                 mlfIsempty(mclVv(*colorbarHandle, "colorbarHandle")))) {
        /*
         * % Figure contains other objects and not a colorbar.
         * resizeType = 2;
         */
        mlfAssign(resizeType, _mxarray1_);
    /*
     * 
     * else
     */
    } else {
        /*
         * % Figure contains a colorbar.  Do we have a one image
         * % one colorbar situation?
         * if (length(colorbarHandle) > 1)
         */
        if (mclLengthInt(mclVv(*colorbarHandle, "colorbarHandle")) > 1) {
            /*
             * % No
             * resizeType = 2;
             */
            mlfAssign(resizeType, _mxarray1_);
        /*
         * else
         */
        } else {
            /*
             * colorbarAxes = get(colorbarHandle, 'Parent');
             */
            mlfAssign(
              &colorbarAxes,
              mlfNGet(
                1,
                mclVv(*colorbarHandle, "colorbarHandle"), _mxarray19_, NULL));
            /*
             * uimenuKids = findobj(figKids, 'flat', 'Type', 'uimenu');
             */
            mlfAssign(
              &uimenuKids,
              mlfFindobj(
                mclVv(figKids, "figKids"),
                _mxarray37_,
                _mxarray21_,
                _mxarray47_,
                NULL));
            /*
             * invisUicontrolKids = findobj(figKids, 'flat', 'Type', 'uicontrol', ...
             */
            mlfAssign(
              &invisUicontrolKids,
              mlfFindobj(
                mclVv(figKids, "figKids"),
                _mxarray37_,
                _mxarray21_,
                _mxarray41_,
                _mxarray43_,
                _mxarray49_,
                NULL));
            /*
             * 'Visible', 'off');
             * otherKids = setdiff(figKids, ...
             */
            mlfAssign(
              &otherKids,
              mlfNSetdiff(
                1,
                NULL,
                mclVv(figKids, "figKids"),
                mlfVertcat(
                  mclVv(uimenuKids, "uimenuKids"),
                  mclVv(colorbarAxes, "colorbarAxes"),
                  mclVv(axHandle, "axHandle"),
                  mclVv(invisUicontrolKids, "invisUicontrolKids"),
                  NULL),
                NULL));
            /*
             * [uimenuKids ; colorbarAxes ; axHandle ; invisUicontrolKids]);
             * if (length(otherKids) > 1)
             */
            if (mclLengthInt(mclVv(otherKids, "otherKids")) > 1) {
                /*
                 * % No
                 * resizeType = 2;
                 */
                mlfAssign(resizeType, _mxarray1_);
            /*
             * else
             */
            } else {
                /*
                 * % Yes, one image and one colorbar
                 * resizeType = 3;
                 */
                mlfAssign(resizeType, _mxarray2_);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * %--------------------------------------------
     * % Subfunction Resize1
     * %--------------------------------------------
     */
    return_:
    mclValidateOutput(
      axHandle, 1, nargout_, "axHandle", "truesize/ParseInputs");
    mclValidateOutput(
      *imHandle, 2, nargout_, "imHandle", "truesize/ParseInputs");
    mclValidateOutput(
      *colorbarHandle, 3, nargout_, "colorbarHandle", "truesize/ParseInputs");
    mclValidateOutput(*imSize, 4, nargout_, "imSize", "truesize/ParseInputs");
    mclValidateOutput(
      *resizeType, 5, nargout_, "resizeType", "truesize/ParseInputs");
    mclValidateOutput(*msg, 6, nargout_, "msg", "truesize/ParseInputs");
    mxDestroyArray(figHandle);
    mxDestroyArray(h);
    mxDestroyArray(k);
    mxDestroyArray(figKids);
    mxDestroyArray(colorbarAxes);
    mxDestroyArray(uimenuKids);
    mxDestroyArray(invisUicontrolKids);
    mxDestroyArray(otherKids);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return axHandle;
}

/*
 * The function "Mtruesize_Resize1" is the implementation version of the
 * "truesize/Resize1" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 176-317). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize1(axHandle, imHandle, imSize)
 */
static void Mtruesize_Resize1(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_truesize);
    mxArray * message = NULL;
    mxArray * deltaY = NULL;
    mxArray * deltaX = NULL;
    mxArray * newFigHeight = NULL;
    mxArray * newFigWidth = NULL;
    mxArray * gutterHeight = NULL;
    mxArray * gutterWidth = NULL;
    mxArray * nonzeroGutters = NULL;
    mxArray * defAxesPos = NULL;
    mxArray * done = NULL;
    mxArray * scale = NULL;
    mxArray * screenHeight = NULL;
    mxArray * screenWidth = NULL;
    mxArray * screenSize = NULL;
    mxArray * gutterTop = NULL;
    mxArray * gutterBottom = NULL;
    mxArray * gutterRight = NULL;
    mxArray * gutterLeft = NULL;
    mxArray * figPos = NULL;
    mxArray * minFigHeight = NULL;
    mxArray * minFigWidth = NULL;
    mxArray * figTopBorder = NULL;
    mxArray * figBottomBorder = NULL;
    mxArray * figRightBorder = NULL;
    mxArray * figLeftBorder = NULL;
    mxArray * rootUnits = NULL;
    mxArray * figUnits = NULL;
    mxArray * figHandle = NULL;
    mxArray * axPos = NULL;
    mxArray * ans = NULL;
    mxArray * axUnits = NULL;
    mxArray * imageHeight = NULL;
    mxArray * imageWidth = NULL;
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    /*
     * % Resize figure containing a single axes
     * % object with a single image.
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mlfIsempty(mclVa(imSize, "imSize")))) {
        /*
         * % How big is the image?
         * imageWidth = size(get(imHandle, 'CData'), 2);
         */
        mlfAssign(
          &imageWidth,
          mlfSize(
            mclValueVarargout(),
            mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray51_, NULL),
            _mxarray1_));
        /*
         * imageHeight = size(get(imHandle, 'CData'), 1);
         */
        mlfAssign(
          &imageHeight,
          mlfSize(
            mclValueVarargout(),
            mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray51_, NULL),
            _mxarray0_));
    /*
     * else
     */
    } else {
        /*
         * imageWidth = imSize(2);
         */
        mlfAssign(&imageWidth, mclIntArrayRef1(mclVa(imSize, "imSize"), 2));
        /*
         * imageHeight = imSize(1);
         */
        mlfAssign(&imageHeight, mclIntArrayRef1(mclVa(imSize, "imSize"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * if (imageWidth * imageHeight == 0)
     */
    if (mclEqBool(
          mclMtimes(
            mclVv(imageWidth, "imageWidth"), mclVv(imageHeight, "imageHeight")),
          _mxarray53_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray54_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * axPos = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPos, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray58_, NULL));
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray19_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray54_, NULL));
    /*
     * rootUnits = get(0, 'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray53_, _mxarray54_, NULL));
    /*
     * set(figHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * set(0, 'Units', 'pixels');
     */
    mclAssignAns(&ans, mlfNSet(0, _mxarray53_, _mxarray54_, _mxarray56_, NULL));
    /*
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     */
    mlfAssign(&figLeftBorder, _mxarray60_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray60_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray60_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray61_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray62_));
    /*
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     */
    mlfAssign(&minFigWidth, _mxarray63_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray63_);
    /*
     * 
     * % What are the gutter sizes?
     * figPos = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPos, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray58_, NULL));
    /*
     * gutterLeft = max(axPos(1) - 1, 0);
     */
    mlfAssign(
      &gutterLeft,
      mlfMax(
        NULL,
        mclMinus(mclIntArrayRef1(mclVv(axPos, "axPos"), 1), _mxarray0_),
        _mxarray53_,
        NULL));
    /*
     * gutterRight = max(figPos(3) - (axPos(1) + axPos(3)) + 1, 0);
     */
    mlfAssign(
      &gutterRight,
      mlfMax(
        NULL,
        mclPlus(
          mclMinus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 3),
            mclPlus(
              mclIntArrayRef1(mclVv(axPos, "axPos"), 1),
              mclIntArrayRef1(mclVv(axPos, "axPos"), 3))),
          _mxarray0_),
        _mxarray53_,
        NULL));
    /*
     * gutterBottom = max(axPos(2) - 1, 0);
     */
    mlfAssign(
      &gutterBottom,
      mlfMax(
        NULL,
        mclMinus(mclIntArrayRef1(mclVv(axPos, "axPos"), 2), _mxarray0_),
        _mxarray53_,
        NULL));
    /*
     * gutterTop = max(figPos(4) - (axPos(2) + axPos(4)) + 1, 0);
     */
    mlfAssign(
      &gutterTop,
      mlfMax(
        NULL,
        mclPlus(
          mclMinus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 4),
            mclPlus(
              mclIntArrayRef1(mclVv(axPos, "axPos"), 2),
              mclIntArrayRef1(mclVv(axPos, "axPos"), 4))),
          _mxarray0_),
        _mxarray53_,
        NULL));
    /*
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray53_, _mxarray64_, NULL));
    /*
     * screenWidth = screenSize(3);
     */
    mlfAssign(
      &screenWidth, mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3));
    /*
     * screenHeight = screenSize(4);
     */
    mlfAssign(
      &screenHeight, mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4));
    /*
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     */
    {
        mxArray * a_
          = mclInitialize(
              mclLe(mclVv(screenWidth, "screenWidth"), _mxarray0_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLe(mclVv(screenHeight, "screenHeight"), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * screenWidth = Inf;
             */
            mlfAssign(&screenWidth, _mxarray66_);
            /*
             * screenHeight = Inf;
             */
            mlfAssign(&screenHeight, _mxarray66_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * scale = 100;
     */
    mlfAssign(&scale, _mxarray67_);
    /*
     * done = 0;
     */
    mlfAssign(&done, _mxarray53_);
    /*
     * defAxesPos = get(0,'DefaultAxesPosition');
     */
    mlfAssign(&defAxesPos, mlfNGet(1, _mxarray53_, _mxarray68_, NULL));
    /*
     * nonzeroGutters = (gutterLeft > 0);
     */
    mlfAssign(
      &nonzeroGutters, mclGt(mclVv(gutterLeft, "gutterLeft"), _mxarray53_));
    /*
     * while (~done)
     */
    while (mclNotBool(mclVv(done, "done"))) {
        /*
         * if (nonzeroGutters)
         */
        if (mlfTobool(mclVv(nonzeroGutters, "nonzeroGutters"))) {
            /*
             * gutterWidth = round((1 - defAxesPos(3)) * imageWidth / defAxesPos(3));
             */
            mlfAssign(
              &gutterWidth,
              mlfRound(
                mclMrdivide(
                  mclMtimes(
                    mclMinus(
                      _mxarray0_,
                      mclIntArrayRef1(mclVv(defAxesPos, "defAxesPos"), 3)),
                    mclVv(imageWidth, "imageWidth")),
                  mclIntArrayRef1(mclVv(defAxesPos, "defAxesPos"), 3))));
            /*
             * gutterHeight = round((1 - defAxesPos(4)) * imageHeight / defAxesPos(4));
             */
            mlfAssign(
              &gutterHeight,
              mlfRound(
                mclMrdivide(
                  mclMtimes(
                    mclMinus(
                      _mxarray0_,
                      mclIntArrayRef1(mclVv(defAxesPos, "defAxesPos"), 4)),
                    mclVv(imageHeight, "imageHeight")),
                  mclIntArrayRef1(mclVv(defAxesPos, "defAxesPos"), 4))));
            /*
             * newFigWidth = imageWidth + gutterWidth;
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclVv(imageWidth, "imageWidth"),
                mclVv(gutterWidth, "gutterWidth")));
            /*
             * newFigHeight = imageHeight + gutterHeight;
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclVv(imageHeight, "imageHeight"),
                mclVv(gutterHeight, "gutterHeight")));
        /*
         * else
         */
        } else {
            /*
             * newFigWidth = imageWidth;
             */
            mlfAssign(&newFigWidth, mclVv(imageWidth, "imageWidth"));
            /*
             * newFigHeight = imageHeight;
             */
            mlfAssign(&newFigHeight, mclVv(imageHeight, "imageHeight"));
        /*
         * end
         */
        }
        /*
         * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclGt(
                    mclPlus(
                      mclPlus(
                        mclVv(newFigWidth, "newFigWidth"),
                        mclVv(figLeftBorder, "figLeftBorder")),
                      mclVv(figRightBorder, "figRightBorder")),
                    mclVv(screenWidth, "screenWidth")));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclGt(
                         mclPlus(
                           mclPlus(
                             mclVv(newFigHeight, "newFigHeight"),
                             mclVv(figBottomBorder, "figBottomBorder")),
                           mclVv(figTopBorder, "figTopBorder")),
                         mclVv(screenHeight, "screenHeight"))))) {
                mxDestroyArray(a_);
                /*
                 * ((newFigHeight + figBottomBorder + figTopBorder) > screenHeight))
                 * scale = 3 * scale / 4;
                 */
                mlfAssign(
                  &scale,
                  mclMrdivide(
                    mclMtimes(_mxarray2_, mclVv(scale, "scale")), _mxarray70_));
                /*
                 * imageWidth = round(imageWidth * scale / 100);
                 */
                mlfAssign(
                  &imageWidth,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageWidth, "imageWidth"), mclVv(scale, "scale")),
                      _mxarray67_)));
                /*
                 * imageHeight = round(imageHeight * scale / 100);
                 */
                mlfAssign(
                  &imageHeight,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageHeight, "imageHeight"),
                        mclVv(scale, "scale")),
                      _mxarray67_)));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * done = 1;
                 */
                mlfAssign(&done, _mxarray0_);
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     */
    mlfAssign(
      &newFigWidth,
      mlfMax(
        NULL,
        mclVv(newFigWidth, "newFigWidth"),
        mclVv(minFigWidth, "minFigWidth"),
        NULL));
    /*
     * newFigHeight = max(newFigHeight, minFigHeight);
     */
    mlfAssign(
      &newFigHeight,
      mlfMax(
        NULL,
        mclVv(newFigHeight, "newFigHeight"),
        mclVv(minFigHeight, "minFigHeight"),
        NULL));
    /*
     * 
     * figPos(1) = max(1, figPos(1) - floor((newFigWidth - figPos(3))/2));
     */
    mclIntArrayAssign1(
      &figPos,
      mlfMax(
        NULL,
        _mxarray0_,
        mclMinus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 1),
          mlfFloor(
            mclMrdivide(
              mclMinus(
                mclVv(newFigWidth, "newFigWidth"),
                mclIntArrayRef1(mclVv(figPos, "figPos"), 3)),
              _mxarray1_))),
        NULL),
      1);
    /*
     * figPos(2) = max(1, figPos(2) - floor((newFigHeight - figPos(4))/2));
     */
    mclIntArrayAssign1(
      &figPos,
      mlfMax(
        NULL,
        _mxarray0_,
        mclMinus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 2),
          mlfFloor(
            mclMrdivide(
              mclMinus(
                mclVv(newFigHeight, "newFigHeight"),
                mclIntArrayRef1(mclVv(figPos, "figPos"), 4)),
              _mxarray1_))),
        NULL),
      2);
    /*
     * figPos(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPos, mclVv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPos(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPos, mclVv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 1),
          mclIntArrayRef1(mclVv(figPos, "figPos"), 3))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray53_)) {
        /*
         * figPos(1) = figPos(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 1),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 2),
          mclIntArrayRef1(mclVv(figPos, "figPos"), 4))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray53_)) {
        /*
         * figPos(2) = figPos(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 2),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * % Figure out where to place the axes object in the
     * % resized figure
     * gutterWidth = figPos(3) - imageWidth;
     */
    mlfAssign(
      &gutterWidth,
      mclMinus(
        mclIntArrayRef1(mclVv(figPos, "figPos"), 3),
        mclVv(imageWidth, "imageWidth")));
    /*
     * gutterHeight = figPos(4) - imageHeight;
     */
    mlfAssign(
      &gutterHeight,
      mclMinus(
        mclIntArrayRef1(mclVv(figPos, "figPos"), 4),
        mclVv(imageHeight, "imageHeight")));
    /*
     * gutterLeft = floor(gutterWidth/2);
     */
    mlfAssign(
      &gutterLeft,
      mlfFloor(mclMrdivide(mclVv(gutterWidth, "gutterWidth"), _mxarray1_)));
    /*
     * gutterBottom = floor(gutterHeight/2);
     */
    mlfAssign(
      &gutterBottom,
      mlfFloor(mclMrdivide(mclVv(gutterHeight, "gutterHeight"), _mxarray1_)));
    /*
     * 
     * axPos(1) = gutterLeft + 1;
     */
    mclIntArrayAssign1(
      &axPos, mclPlus(mclVv(gutterLeft, "gutterLeft"), _mxarray0_), 1);
    /*
     * axPos(2) = gutterBottom + 1;
     */
    mclIntArrayAssign1(
      &axPos, mclPlus(mclVv(gutterBottom, "gutterBottom"), _mxarray0_), 2);
    /*
     * axPos(3) = imageWidth;
     */
    mclIntArrayAssign1(&axPos, mclVv(imageWidth, "imageWidth"), 3);
    /*
     * axPos(4) = imageHeight;
     */
    mclIntArrayAssign1(&axPos, mclVv(imageHeight, "imageHeight"), 4);
    /*
     * 
     * set(figHandle, 'Position', figPos)
     */
    mclPrintAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray58_,
        mclVv(figPos, "figPos"),
        NULL));
    /*
     * set(axHandle, 'Position', axPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray58_,
        mclVv(axPos, "axPos"),
        NULL));
    /*
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug   -SLE
     */
    mlfDrawnow(NULL);
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray54_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray54_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray53_, _mxarray54_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray71_, _mxarray73_, NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless warning is disabled
     * % according to toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVv(scale, "scale"), _mxarray67_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_, mlfStrcmp(mlfIptgetpref(_mxarray75_), _mxarray45_)))) {
            mxDestroyArray(a_);
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray77_,
                mlfSprintf(
                  NULL, _mxarray79_, mlfFloor(mclVv(scale, "scale")), NULL),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', floor(scale))];
             * warning(message);
             */
            mclAssignAns(
              &ans, mlfNWarning(0, NULL, mclVv(message, "message"), NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * %--------------------------------------------
     * % Subfunction Resize2
     * %--------------------------------------------
     * % Resize figure containing multiple axes or
     * % other objects.  Basically we're going to
     * % compute a global figure scaling factor
     * % that will bring the target image into
     * % truesize mode.  This works reasonably well
     * % for subplot-type figures as long as all
     * % the images have the same size.  This is
     * % basically the guts of truesize.m from IPT
     * % version 1.
     */
    return_:
    mxDestroyArray(imageWidth);
    mxDestroyArray(imageHeight);
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPos);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(figPos);
    mxDestroyArray(gutterLeft);
    mxDestroyArray(gutterRight);
    mxDestroyArray(gutterBottom);
    mxDestroyArray(gutterTop);
    mxDestroyArray(screenSize);
    mxDestroyArray(screenWidth);
    mxDestroyArray(screenHeight);
    mxDestroyArray(scale);
    mxDestroyArray(done);
    mxDestroyArray(defAxesPos);
    mxDestroyArray(nonzeroGutters);
    mxDestroyArray(gutterWidth);
    mxDestroyArray(gutterHeight);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(message);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mtruesize_Resize2" is the implementation version of the
 * "truesize/Resize2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 317-439). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize2(axHandle, imHandle, imSize)
 */
static void Mtruesize_Resize2(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_truesize);
    mxArray * message = NULL;
    mxArray * deltaY = NULL;
    mxArray * deltaX = NULL;
    mxArray * scale = NULL;
    mxArray * scaleY = NULL;
    mxArray * scaleX = NULL;
    mxArray * minFigHeight = NULL;
    mxArray * minFigWidth = NULL;
    mxArray * figTopBorder = NULL;
    mxArray * figBottomBorder = NULL;
    mxArray * figRightBorder = NULL;
    mxArray * figLeftBorder = NULL;
    mxArray * newFigHeight = NULL;
    mxArray * newFigWidth = NULL;
    mxArray * dy = NULL;
    mxArray * dx = NULL;
    mxArray * screenSize = NULL;
    mxArray * figPosition = NULL;
    mxArray * rootUnits = NULL;
    mxArray * figUnits = NULL;
    mxArray * figHandle = NULL;
    mxArray * axPosition = NULL;
    mxArray * ans = NULL;
    mxArray * axUnits = NULL;
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    /*
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mlfIsempty(mclVa(imSize, "imSize")))) {
        /*
         * imSize = size(get(imHandle, 'CData'));
         */
        mlfAssign(
          &imSize,
          mlfSize(
            mclValueVarargout(),
            mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray51_, NULL),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if (prod(imSize) == 0)
     */
    if (mclEqBool(mlfProd(mclVa(imSize, "imSize"), NULL), _mxarray53_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray54_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * axPosition = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPosition, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray58_, NULL));
    /*
     * % Do we need to do anything?
     * if norm(axPosition(3:4) - [imSize([2 1])]) < sqrt(eps)
     */
    if (mclLtBool(
          mlfNorm(
            mclMinus(
              mclArrayRef1(
                mclVv(axPosition, "axPosition"),
                mlfColon(_mxarray2_, _mxarray70_, NULL)),
              mclArrayRef1(mclVa(imSize, "imSize"), _mxarray81_)),
            NULL),
          mlfSqrt(_mxarray83_))) {
        /*
         * set(axHandle, 'Units', axUnits)
         */
        mclPrintAns(
          &ans,
          mlfNSet(
            0,
            mclVa(axHandle, "axHandle"),
            _mxarray54_,
            mclVv(axUnits, "axUnits"),
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray19_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray54_, NULL));
    /*
     * rootUnits = get(0,'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray53_, _mxarray54_, NULL));
    /*
     * set(axHandle, 'Units', 'normalized');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray54_, _mxarray84_, NULL));
    /*
     * axPosition = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPosition, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray58_, NULL));
    /*
     * set([figHandle 0], 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfHorzcat(mclVv(figHandle, "figHandle"), _mxarray53_, NULL),
        _mxarray54_,
        _mxarray56_,
        NULL));
    /*
     * figPosition = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPosition,
      mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray58_, NULL));
    /*
     * screenSize = get(0,'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray53_, _mxarray64_, NULL));
    /*
     * 
     * % What should the new figure size be?
     * dx = ceil(imSize(2)/axPosition(3) - figPosition(3));
     */
    mlfAssign(
      &dx,
      mlfCeil(
        mclMinus(
          mclMrdivide(
            mclIntArrayRef1(mclVa(imSize, "imSize"), 2),
            mclIntArrayRef1(mclVv(axPosition, "axPosition"), 3)),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 3))));
    /*
     * dy = ceil(imSize(1)/axPosition(4) - figPosition(4));
     */
    mlfAssign(
      &dy,
      mlfCeil(
        mclMinus(
          mclMrdivide(
            mclIntArrayRef1(mclVa(imSize, "imSize"), 1),
            mclIntArrayRef1(mclVv(axPosition, "axPosition"), 4)),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 4))));
    /*
     * newFigWidth = figPosition(3) + dx;
     */
    mlfAssign(
      &newFigWidth,
      mclPlus(
        mclIntArrayRef1(mclVv(figPosition, "figPosition"), 3),
        mclVv(dx, "dx")));
    /*
     * newFigHeight = figPosition(4) + dy;
     */
    mlfAssign(
      &newFigHeight,
      mclPlus(
        mclIntArrayRef1(mclVv(figPosition, "figPosition"), 4),
        mclVv(dy, "dy")));
    /*
     * 
     * % Is the new figure size too big or too small?
     * figLeftBorder = 10;
     */
    mlfAssign(&figLeftBorder, _mxarray60_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray60_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray60_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray61_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray62_));
    /*
     * minFigWidth = 128;
     */
    mlfAssign(&minFigWidth, _mxarray63_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray63_);
    /*
     * 
     * if ((newFigWidth + figLeftBorder + figRightBorder) > screenSize(3))
     */
    if (mclGtBool(
          mclPlus(
            mclPlus(
              mclVv(newFigWidth, "newFigWidth"),
              mclVv(figLeftBorder, "figLeftBorder")),
            mclVv(figRightBorder, "figRightBorder")),
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3))) {
        /*
         * scaleX = (screenSize(3) - figLeftBorder - figRightBorder) / newFigWidth;
         */
        mlfAssign(
          &scaleX,
          mclMrdivide(
            mclMinus(
              mclMinus(
                mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
                mclVv(figLeftBorder, "figLeftBorder")),
              mclVv(figRightBorder, "figRightBorder")),
            mclVv(newFigWidth, "newFigWidth")));
    /*
     * else
     */
    } else {
        /*
         * scaleX = 1;
         */
        mlfAssign(&scaleX, _mxarray0_);
    /*
     * end
     */
    }
    /*
     * 
     * if ((newFigHeight + figBottomBorder + figTopBorder) > screenSize(4))
     */
    if (mclGtBool(
          mclPlus(
            mclPlus(
              mclVv(newFigHeight, "newFigHeight"),
              mclVv(figBottomBorder, "figBottomBorder")),
            mclVv(figTopBorder, "figTopBorder")),
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4))) {
        /*
         * scaleY = (screenSize(4) - figBottomBorder - figTopBorder) / newFigHeight;
         */
        mlfAssign(
          &scaleY,
          mclMrdivide(
            mclMinus(
              mclMinus(
                mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
                mclVv(figBottomBorder, "figBottomBorder")),
              mclVv(figTopBorder, "figTopBorder")),
            mclVv(newFigHeight, "newFigHeight")));
    /*
     * else
     */
    } else {
        /*
         * scaleY = 1;
         */
        mlfAssign(&scaleY, _mxarray0_);
    /*
     * end
     */
    }
    /*
     * 
     * if (newFigWidth < minFigWidth)
     */
    if (mclLtBool(
          mclVv(newFigWidth, "newFigWidth"),
          mclVv(minFigWidth, "minFigWidth"))) {
        /*
         * scaleX = minFigWidth / newFigWidth;
         */
        mlfAssign(
          &scaleX,
          mclMrdivide(
            mclVv(minFigWidth, "minFigWidth"),
            mclVv(newFigWidth, "newFigWidth")));
    /*
     * end
     */
    }
    /*
     * if (newFigHeight < minFigHeight)
     */
    if (mclLtBool(
          mclVv(newFigHeight, "newFigHeight"),
          mclVv(minFigHeight, "minFigHeight"))) {
        /*
         * scaleY = minFigHeight / newFigHeight;
         */
        mlfAssign(
          &scaleY,
          mclMrdivide(
            mclVv(minFigHeight, "minFigHeight"),
            mclVv(newFigHeight, "newFigHeight")));
    /*
     * end
     */
    }
    /*
     * 
     * if (min(scaleX, scaleY) < 1)
     */
    if (mclLtBool(
          mlfMin(NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL),
          _mxarray0_)) {
        /*
         * % Yes, the new figure is too big for the screen.
         * scale = min(scaleX, scaleY);
         */
        mlfAssign(
          &scale,
          mlfMin(NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL));
        /*
         * newFigWidth = floor(newFigWidth * scale);
         */
        mlfAssign(
          &newFigWidth,
          mlfFloor(
            mclMtimes(
              mclVv(newFigWidth, "newFigWidth"), mclVv(scale, "scale"))));
        /*
         * newFigHeight = floor(newFigHeight * scale);
         */
        mlfAssign(
          &newFigHeight,
          mlfFloor(
            mclMtimes(
              mclVv(newFigHeight, "newFigHeight"), mclVv(scale, "scale"))));
    /*
     * elseif (max(scaleX, scaleY) > 1)
     */
    } else if (mclGtBool(
                 mlfMax(
                   NULL,
                   mclVv(scaleX, "scaleX"),
                   mclVv(scaleY, "scaleY"),
                   NULL),
                 _mxarray0_)) {
        /*
         * % Yes, the new figure is too small.
         * scale = max(scaleX, scaleY);
         */
        mlfAssign(
          &scale,
          mlfMax(NULL, mclVv(scaleX, "scaleX"), mclVv(scaleY, "scaleY"), NULL));
        /*
         * newFigWidth = floor(newFigWidth * scale);
         */
        mlfAssign(
          &newFigWidth,
          mlfFloor(
            mclMtimes(
              mclVv(newFigWidth, "newFigWidth"), mclVv(scale, "scale"))));
        /*
         * newFigHeight = floor(newFigHeight * scale);
         */
        mlfAssign(
          &newFigHeight,
          mlfFloor(
            mclMtimes(
              mclVv(newFigHeight, "newFigHeight"), mclVv(scale, "scale"))));
    /*
     * else
     */
    } else {
        /*
         * scale = 1;
         */
        mlfAssign(&scale, _mxarray0_);
    /*
     * end
     */
    }
    /*
     * 
     * figPosition(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPosition, mclVv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPosition(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPosition, mclVv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPosition(1) + figPosition(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 1),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 3))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray53_)) {
        /*
         * figPosition(1) = figPosition(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPosition,
          mclPlus(
            mclIntArrayRef1(mclVv(figPosition, "figPosition"), 1),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPosition(2) + figPosition(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 2),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 4))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray53_)) {
        /*
         * figPosition(2) = figPosition(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPosition,
          mclPlus(
            mclIntArrayRef1(mclVv(figPosition, "figPosition"), 2),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * % Change axes position to get exactly one pixel per image pixel.
     * % That is, as long as scale = 1.
     * dx = scale*imSize(2)/figPosition(3) - axPosition(3);
     */
    mlfAssign(
      &dx,
      mclMinus(
        mclMrdivide(
          mclMtimes(
            mclVv(scale, "scale"), mclIntArrayRef1(mclVa(imSize, "imSize"), 2)),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 3)),
        mclIntArrayRef1(mclVv(axPosition, "axPosition"), 3)));
    /*
     * dy = scale*imSize(1)/figPosition(4) - axPosition(4);
     */
    mlfAssign(
      &dy,
      mclMinus(
        mclMrdivide(
          mclMtimes(
            mclVv(scale, "scale"), mclIntArrayRef1(mclVa(imSize, "imSize"), 1)),
          mclIntArrayRef1(mclVv(figPosition, "figPosition"), 4)),
        mclIntArrayRef1(mclVv(axPosition, "axPosition"), 4)));
    /*
     * axPosition = axPosition + [-dx/2 -dy/2 dx dy];
     */
    mlfAssign(
      &axPosition,
      mclPlus(
        mclVv(axPosition, "axPosition"),
        mlfHorzcat(
          mclMrdivide(mclUminus(mclVv(dx, "dx")), _mxarray1_),
          mclMrdivide(mclUminus(mclVv(dy, "dy")), _mxarray1_),
          mclVv(dx, "dx"),
          mclVv(dy, "dy"),
          NULL)));
    /*
     * 
     * % OK, make the changes
     * set(axHandle, 'Position', axPosition);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray58_,
        mclVv(axPosition, "axPosition"),
        NULL));
    /*
     * set(figHandle, 'Position', figPosition);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray58_,
        mclVv(figPosition, "figPosition"),
        NULL));
    /*
     * 
     * % Restore the original units
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray54_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray54_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray53_, _mxarray54_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if (strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    if (mlfTobool(mlfStrcmp(mlfIptgetpref(_mxarray75_), _mxarray45_))) {
        /*
         * if (scale < 1)
         */
        if (mclLtBool(mclVv(scale, "scale"), _mxarray0_)) {
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray77_,
                mlfSprintf(
                  NULL,
                  _mxarray79_,
                  mlfRound(mclMtimes(_mxarray67_, mclVv(scale, "scale"))),
                  NULL),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', round(100*scale))];
             * warning(message);
             */
            mclAssignAns(
              &ans, mlfNWarning(0, NULL, mclVv(message, "message"), NULL));
        /*
         * elseif (scale > 1)
         */
        } else if (mclGtBool(mclVv(scale, "scale"), _mxarray0_)) {
            /*
             * message = ['Image is too small for truesize figure scaling; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray86_,
                mlfSprintf(
                  NULL,
                  _mxarray88_,
                  mlfRound(mclMtimes(_mxarray67_, mclVv(scale, "scale"))),
                  NULL),
                NULL));
            /*
             * sprintf('\ndisplaying at %d%% scale.', round(100*scale))];
             * warning(message);
             */
            mclAssignAns(
              &ans, mlfNWarning(0, NULL, mclVv(message, "message"), NULL));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * %--------------------------------------------
     * % Subfunction Resize3
     * %--------------------------------------------
     */
    return_:
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPosition);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(figPosition);
    mxDestroyArray(screenSize);
    mxDestroyArray(dx);
    mxDestroyArray(dy);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(scaleX);
    mxDestroyArray(scaleY);
    mxDestroyArray(scale);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(message);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mtruesize_Resize3" is the implementation version of the
 * "truesize/Resize3" M-function from file
 * "k:\matlab6p5\toolbox\images\images\truesize.m" (lines 439-585). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function Resize3(axHandle, imHandle, imSize, colorbarHandle)
 */
static void Mtruesize_Resize3(mxArray * axHandle,
                              mxArray * imHandle,
                              mxArray * imSize,
                              mxArray * colorbarHandle) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_truesize);
    mxArray * message = NULL;
    mxArray * height = NULL;
    mxArray * width = NULL;
    mxArray * bottom = NULL;
    mxArray * left = NULL;
    mxArray * deltaY = NULL;
    mxArray * deltaX = NULL;
    mxArray * newFigHeight = NULL;
    mxArray * newFigWidth = NULL;
    mxArray * done = NULL;
    mxArray * scale = NULL;
    mxArray * screenHeight = NULL;
    mxArray * screenWidth = NULL;
    mxArray * screenSize = NULL;
    mxArray * gutterTop = NULL;
    mxArray * gutterBottom = NULL;
    mxArray * gutterRight = NULL;
    mxArray * gutterLeft = NULL;
    mxArray * defAxPos = NULL;
    mxArray * defFigPos = NULL;
    mxArray * orientation = NULL;
    mxArray * figPos = NULL;
    mxArray * caxPos = NULL;
    mxArray * rootUnits = NULL;
    mxArray * caxUnits = NULL;
    mxArray * figUnits = NULL;
    mxArray * figHandle = NULL;
    mxArray * caxHandle = NULL;
    mxArray * colorbarWidth = NULL;
    mxArray * colorbarGap = NULL;
    mxArray * minFigHeight = NULL;
    mxArray * minFigWidth = NULL;
    mxArray * figTopBorder = NULL;
    mxArray * figBottomBorder = NULL;
    mxArray * figRightBorder = NULL;
    mxArray * figLeftBorder = NULL;
    mxArray * axPos = NULL;
    mxArray * ans = NULL;
    mxArray * axUnits = NULL;
    mxArray * imageHeight = NULL;
    mxArray * imageWidth = NULL;
    mclCopyArray(&axHandle);
    mclCopyArray(&imHandle);
    mclCopyArray(&imSize);
    mclCopyArray(&colorbarHandle);
    /*
     * % Resize figure containing an image, a colorbar, 
     * % and nothing else.
     * 
     * if (isempty(imSize))
     */
    if (mlfTobool(mlfIsempty(mclVa(imSize, "imSize")))) {
        /*
         * % How big is the image?
         * imageWidth = size(get(imHandle, 'CData'), 2);
         */
        mlfAssign(
          &imageWidth,
          mlfSize(
            mclValueVarargout(),
            mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray51_, NULL),
            _mxarray1_));
        /*
         * imageHeight = size(get(imHandle, 'CData'), 1);
         */
        mlfAssign(
          &imageHeight,
          mlfSize(
            mclValueVarargout(),
            mlfNGet(1, mclVa(imHandle, "imHandle"), _mxarray51_, NULL),
            _mxarray0_));
    /*
     * else
     */
    } else {
        /*
         * imageWidth = imSize(2);
         */
        mlfAssign(&imageWidth, mclIntArrayRef1(mclVa(imSize, "imSize"), 2));
        /*
         * imageHeight = imSize(1);
         */
        mlfAssign(&imageHeight, mclIntArrayRef1(mclVa(imSize, "imSize"), 1));
    /*
     * end
     */
    }
    /*
     * 
     * if (imageWidth * imageHeight == 0)
     */
    if (mclEqBool(
          mclMtimes(
            mclVv(imageWidth, "imageWidth"), mclVv(imageHeight, "imageHeight")),
          _mxarray53_)) {
        /*
         * % Don't try to handle the degenerate case.
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * axUnits = get(axHandle, 'Units');
     */
    mlfAssign(
      &axUnits, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray54_, NULL));
    /*
     * set(axHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(0, mclVa(axHandle, "axHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * axPos = get(axHandle, 'Position');
     */
    mlfAssign(
      &axPos, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray58_, NULL));
    /*
     * 
     * figLeftBorder = 10;  % assume left figure decorations are 10 pixels
     */
    mlfAssign(&figLeftBorder, _mxarray60_);
    /*
     * figRightBorder = 10;
     */
    mlfAssign(&figRightBorder, _mxarray60_);
    /*
     * figBottomBorder = 10;
     */
    mlfAssign(&figBottomBorder, _mxarray60_);
    /*
     * figTopBorder = 50;
     */
    mlfAssign(&figTopBorder, _mxarray61_);
    /*
     * figTopBorder = figTopBorder + 30;  % scribe hack
     */
    mlfAssign(
      &figTopBorder, mclPlus(mclVv(figTopBorder, "figTopBorder"), _mxarray62_));
    /*
     * 
     * minFigWidth = 128; % don't try to display a figure smaller than this.
     */
    mlfAssign(&minFigWidth, _mxarray63_);
    /*
     * minFigHeight = 128;
     */
    mlfAssign(&minFigHeight, _mxarray63_);
    /*
     * 
     * colorbarGap = 30;   % pixels
     */
    mlfAssign(&colorbarGap, _mxarray62_);
    /*
     * colorbarWidth = 20; % pixels
     */
    mlfAssign(&colorbarWidth, _mxarray90_);
    /*
     * 
     * caxHandle = get(colorbarHandle, 'Parent');
     */
    mlfAssign(
      &caxHandle,
      mlfNGet(1, mclVa(colorbarHandle, "colorbarHandle"), _mxarray19_, NULL));
    /*
     * figHandle = get(axHandle, 'Parent');
     */
    mlfAssign(
      &figHandle, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray19_, NULL));
    /*
     * figUnits = get(figHandle, 'Units');
     */
    mlfAssign(
      &figUnits, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray54_, NULL));
    /*
     * caxUnits = get(caxHandle, 'Units');
     */
    mlfAssign(
      &caxUnits, mlfNGet(1, mclVv(caxHandle, "caxHandle"), _mxarray54_, NULL));
    /*
     * rootUnits = get(0, 'Units');
     */
    mlfAssign(&rootUnits, mlfNGet(1, _mxarray53_, _mxarray54_, NULL));
    /*
     * set(figHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * set(0, 'Units', 'pixels');
     */
    mclAssignAns(&ans, mlfNSet(0, _mxarray53_, _mxarray54_, _mxarray56_, NULL));
    /*
     * set(caxHandle, 'Units', 'pixels');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(caxHandle, "caxHandle"), _mxarray54_, _mxarray56_, NULL));
    /*
     * 
     * caxPos = get(caxHandle, 'Position');
     */
    mlfAssign(
      &caxPos, mlfNGet(1, mclVv(caxHandle, "caxHandle"), _mxarray58_, NULL));
    /*
     * figPos = get(figHandle, 'Position');
     */
    mlfAssign(
      &figPos, mlfNGet(1, mclVv(figHandle, "figHandle"), _mxarray58_, NULL));
    /*
     * 
     * if ((axPos(1) + axPos(3)) < caxPos(1))
     */
    if (mclLtBool(
          mclPlus(
            mclIntArrayRef1(mclVv(axPos, "axPos"), 1),
            mclIntArrayRef1(mclVv(axPos, "axPos"), 3)),
          mclIntArrayRef1(mclVv(caxPos, "caxPos"), 1))) {
        /*
         * orientation = 'vertical';
         */
        mlfAssign(&orientation, _mxarray91_);
    /*
     * else
     */
    } else {
        /*
         * orientation = 'horizontal';
         */
        mlfAssign(&orientation, _mxarray93_);
    /*
     * end
     */
    }
    /*
     * 
     * % Use MATLAB's default gutters
     * defFigPos = get(0,'FactoryFigurePosition');
     */
    mlfAssign(&defFigPos, mlfNGet(1, _mxarray53_, _mxarray95_, NULL));
    /*
     * defAxPos = get(0,'FactoryAxesPosition');
     */
    mlfAssign(&defAxPos, mlfNGet(1, _mxarray53_, _mxarray97_, NULL));
    /*
     * gutterLeft = round(defAxPos(1) * defFigPos(3));
     */
    mlfAssign(
      &gutterLeft,
      mlfRound(
        mclMtimes(
          mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 1),
          mclIntArrayRef1(mclVv(defFigPos, "defFigPos"), 3))));
    /*
     * gutterRight = round((1 - defAxPos(1) - defAxPos(3)) * defFigPos(3));
     */
    mlfAssign(
      &gutterRight,
      mlfRound(
        mclMtimes(
          mclMinus(
            mclMinus(
              _mxarray0_, mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 1)),
            mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 3)),
          mclIntArrayRef1(mclVv(defFigPos, "defFigPos"), 3))));
    /*
     * gutterBottom = round(defAxPos(2) * defFigPos(4));
     */
    mlfAssign(
      &gutterBottom,
      mlfRound(
        mclMtimes(
          mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 2),
          mclIntArrayRef1(mclVv(defFigPos, "defFigPos"), 4))));
    /*
     * gutterTop = round((1 - defAxPos(2) - defAxPos(4)) * defFigPos(4));
     */
    mlfAssign(
      &gutterTop,
      mlfRound(
        mclMtimes(
          mclMinus(
            mclMinus(
              _mxarray0_, mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 2)),
            mclIntArrayRef1(mclVv(defAxPos, "defAxPos"), 4)),
          mclIntArrayRef1(mclVv(defFigPos, "defFigPos"), 4))));
    /*
     * 
     * % What are the screen dimensions
     * screenSize = get(0, 'ScreenSize');
     */
    mlfAssign(&screenSize, mlfNGet(1, _mxarray53_, _mxarray64_, NULL));
    /*
     * screenWidth = screenSize(3);
     */
    mlfAssign(
      &screenWidth, mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3));
    /*
     * screenHeight = screenSize(4);
     */
    mlfAssign(
      &screenHeight, mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4));
    /*
     * if ((screenWidth <= 1) | (screenHeight <= 1))
     */
    {
        mxArray * a_
          = mclInitialize(
              mclLe(mclVv(screenWidth, "screenWidth"), _mxarray0_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLe(mclVv(screenHeight, "screenHeight"), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * screenWidth = Inf;
             */
            mlfAssign(&screenWidth, _mxarray66_);
            /*
             * screenHeight = Inf;
             */
            mlfAssign(&screenHeight, _mxarray66_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * scale = 100;
     */
    mlfAssign(&scale, _mxarray67_);
    /*
     * done = 0;
     */
    mlfAssign(&done, _mxarray53_);
    /*
     * while (~done)
     */
    while (mclNotBool(mclVv(done, "done"))) {
        /*
         * if (strcmp(orientation, 'vertical'))
         */
        if (mlfTobool(
              mlfStrcmp(mclVv(orientation, "orientation"), _mxarray91_))) {
            /*
             * newFigWidth = imageWidth + gutterLeft + gutterRight + ...
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclPlus(
                  mclPlus(
                    mclPlus(
                      mclVv(imageWidth, "imageWidth"),
                      mclVv(gutterLeft, "gutterLeft")),
                    mclVv(gutterRight, "gutterRight")),
                  mclVv(colorbarGap, "colorbarGap")),
                mclVv(colorbarWidth, "colorbarWidth")));
            /*
             * colorbarGap + colorbarWidth;
             * newFigHeight = imageHeight + gutterBottom + gutterTop;
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclPlus(
                  mclVv(imageHeight, "imageHeight"),
                  mclVv(gutterBottom, "gutterBottom")),
                mclVv(gutterTop, "gutterTop")));
        /*
         * else
         */
        } else {
            /*
             * newFigWidth = imageWidth + gutterLeft + gutterRight;
             */
            mlfAssign(
              &newFigWidth,
              mclPlus(
                mclPlus(
                  mclVv(imageWidth, "imageWidth"),
                  mclVv(gutterLeft, "gutterLeft")),
                mclVv(gutterRight, "gutterRight")));
            /*
             * newFigHeight = imageHeight + gutterBottom + gutterTop + ...
             */
            mlfAssign(
              &newFigHeight,
              mclPlus(
                mclPlus(
                  mclPlus(
                    mclPlus(
                      mclVv(imageHeight, "imageHeight"),
                      mclVv(gutterBottom, "gutterBottom")),
                    mclVv(gutterTop, "gutterTop")),
                  mclVv(colorbarGap, "colorbarGap")),
                mclVv(colorbarWidth, "colorbarWidth")));
        /*
         * colorbarGap + colorbarWidth;
         * end
         */
        }
        /*
         * if (((newFigWidth + figLeftBorder + figRightBorder) > screenWidth) | ...
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclGt(
                    mclPlus(
                      mclPlus(
                        mclVv(newFigWidth, "newFigWidth"),
                        mclVv(figLeftBorder, "figLeftBorder")),
                      mclVv(figRightBorder, "figRightBorder")),
                    mclVv(screenWidth, "screenWidth")));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mclGt(
                         mclPlus(
                           mclPlus(
                             mclVv(newFigHeight, "newFigHeight"),
                             mclVv(figBottomBorder, "figBottomBorder")),
                           mclVv(figTopBorder, "figTopBorder")),
                         mclVv(screenHeight, "screenHeight"))))) {
                mxDestroyArray(a_);
                /*
                 * ((newFigHeight + figBottomBorder + figTopBorder) > ...
                 * screenHeight))
                 * scale = 3 * scale / 4;
                 */
                mlfAssign(
                  &scale,
                  mclMrdivide(
                    mclMtimes(_mxarray2_, mclVv(scale, "scale")), _mxarray70_));
                /*
                 * imageWidth = round(imageWidth * scale / 100);
                 */
                mlfAssign(
                  &imageWidth,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageWidth, "imageWidth"), mclVv(scale, "scale")),
                      _mxarray67_)));
                /*
                 * imageHeight = round(imageHeight * scale / 100);
                 */
                mlfAssign(
                  &imageHeight,
                  mlfRound(
                    mclMrdivide(
                      mclMtimes(
                        mclVv(imageHeight, "imageHeight"),
                        mclVv(scale, "scale")),
                      _mxarray67_)));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * done = 1;
                 */
                mlfAssign(&done, _mxarray0_);
            }
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * newFigWidth = max(newFigWidth, minFigWidth);
     */
    mlfAssign(
      &newFigWidth,
      mlfMax(
        NULL,
        mclVv(newFigWidth, "newFigWidth"),
        mclVv(minFigWidth, "minFigWidth"),
        NULL));
    /*
     * newFigHeight = max(newFigHeight, minFigHeight);
     */
    mlfAssign(
      &newFigHeight,
      mlfMax(
        NULL,
        mclVv(newFigHeight, "newFigHeight"),
        mclVv(minFigHeight, "minFigHeight"),
        NULL));
    /*
     * figPos(3) = newFigWidth;
     */
    mclIntArrayAssign1(&figPos, mclVv(newFigWidth, "newFigWidth"), 3);
    /*
     * figPos(4) = newFigHeight;
     */
    mclIntArrayAssign1(&figPos, mclVv(newFigHeight, "newFigHeight"), 4);
    /*
     * 
     * % Translate figure position if necessary
     * deltaX = (screenSize(3) - figRightBorder) - (figPos(1) + figPos(3));
     */
    mlfAssign(
      &deltaX,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
          mclVv(figRightBorder, "figRightBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 1),
          mclIntArrayRef1(mclVv(figPos, "figPos"), 3))));
    /*
     * if (deltaX < 0)
     */
    if (mclLtBool(mclVv(deltaX, "deltaX"), _mxarray53_)) {
        /*
         * figPos(1) = figPos(1) + deltaX;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 1),
            mclVv(deltaX, "deltaX")),
          1);
    /*
     * end
     */
    }
    /*
     * deltaY = (screenSize(4) - figTopBorder) - (figPos(2) + figPos(4));
     */
    mlfAssign(
      &deltaY,
      mclMinus(
        mclMinus(
          mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
          mclVv(figTopBorder, "figTopBorder")),
        mclPlus(
          mclIntArrayRef1(mclVv(figPos, "figPos"), 2),
          mclIntArrayRef1(mclVv(figPos, "figPos"), 4))));
    /*
     * if (deltaY < 0)
     */
    if (mclLtBool(mclVv(deltaY, "deltaY"), _mxarray53_)) {
        /*
         * figPos(2) = figPos(2) + deltaY;
         */
        mclIntArrayAssign1(
          &figPos,
          mclPlus(
            mclIntArrayRef1(mclVv(figPos, "figPos"), 2),
            mclVv(deltaY, "deltaY")),
          2);
    /*
     * end
     */
    }
    /*
     * 
     * axPos = [gutterLeft gutterBottom imageWidth imageHeight];
     */
    mlfAssign(
      &axPos,
      mlfHorzcat(
        mclVv(gutterLeft, "gutterLeft"),
        mclVv(gutterBottom, "gutterBottom"),
        mclVv(imageWidth, "imageWidth"),
        mclVv(imageHeight, "imageHeight"),
        NULL));
    /*
     * 
     * if (strcmp(orientation, 'vertical'))
     */
    if (mlfTobool(mlfStrcmp(mclVv(orientation, "orientation"), _mxarray91_))) {
        /*
         * left = gutterLeft + imageWidth + colorbarGap;
         */
        mlfAssign(
          &left,
          mclPlus(
            mclPlus(
              mclVv(gutterLeft, "gutterLeft"), mclVv(imageWidth, "imageWidth")),
            mclVv(colorbarGap, "colorbarGap")));
        /*
         * bottom = gutterBottom;
         */
        mlfAssign(&bottom, mclVv(gutterBottom, "gutterBottom"));
        /*
         * width = colorbarWidth;
         */
        mlfAssign(&width, mclVv(colorbarWidth, "colorbarWidth"));
        /*
         * height = imageHeight;
         */
        mlfAssign(&height, mclVv(imageHeight, "imageHeight"));
    /*
     * else
     */
    } else {
        /*
         * left = gutterLeft;
         */
        mlfAssign(&left, mclVv(gutterLeft, "gutterLeft"));
        /*
         * bottom = gutterBottom;
         */
        mlfAssign(&bottom, mclVv(gutterBottom, "gutterBottom"));
        /*
         * width = imageWidth;
         */
        mlfAssign(&width, mclVv(imageWidth, "imageWidth"));
        /*
         * height = colorbarWidth;
         */
        mlfAssign(&height, mclVv(colorbarWidth, "colorbarWidth"));
        /*
         * axPos(2) = axPos(2) + colorbarGap + colorbarWidth;
         */
        mclIntArrayAssign1(
          &axPos,
          mclPlus(
            mclPlus(
              mclIntArrayRef1(mclVv(axPos, "axPos"), 2),
              mclVv(colorbarGap, "colorbarGap")),
            mclVv(colorbarWidth, "colorbarWidth")),
          2);
    /*
     * end
     */
    }
    /*
     * caxPos = [left bottom width height];
     */
    mlfAssign(
      &caxPos,
      mlfHorzcat(
        mclVv(left, "left"),
        mclVv(bottom, "bottom"),
        mclVv(width, "width"),
        mclVv(height, "height"),
        NULL));
    /*
     * 
     * set(figHandle, 'Position', figPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray58_,
        mclVv(figPos, "figPos"),
        NULL));
    /*
     * set(axHandle, 'Position', axPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray58_,
        mclVv(axPos, "axPos"),
        NULL));
    /*
     * set(caxHandle, 'Position', caxPos);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(caxHandle, "caxHandle"),
        _mxarray58_,
        mclVv(caxPos, "caxPos"),
        NULL));
    /*
     * 
     * % Restore the units
     * drawnow;  % necessary to work around HG bug      -SLE
     */
    mlfDrawnow(NULL);
    /*
     * set(figHandle, 'Units', figUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(figHandle, "figHandle"),
        _mxarray54_,
        mclVv(figUnits, "figUnits"),
        NULL));
    /*
     * set(axHandle, 'Units', axUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVa(axHandle, "axHandle"),
        _mxarray54_,
        mclVv(axUnits, "axUnits"),
        NULL));
    /*
     * set(caxHandle, 'Units', caxUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(caxHandle, "caxHandle"),
        _mxarray54_,
        mclVv(caxUnits, "caxUnits"),
        NULL));
    /*
     * set(0, 'Units', rootUnits);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, _mxarray53_, _mxarray54_, mclVv(rootUnits, "rootUnits"), NULL));
    /*
     * 
     * % Set the nextplot property of the figure so that the
     * % axes object gets deleted and replaced for the next plot.
     * % That way, the new plot gets drawn in the default position.
     * set(figHandle, 'NextPlot', 'replacechildren');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0, mclVv(figHandle, "figHandle"), _mxarray71_, _mxarray73_, NULL));
    /*
     * 
     * % Warn if the display is not truesize, unless the truesize warning
     * % has been disabled according to a toolbox preference setting.
     * if ((scale < 100) & strcmp(iptgetpref('TruesizeWarning'), 'on'))
     */
    {
        mxArray * a_ = mclInitialize(mclLt(mclVv(scale, "scale"), _mxarray67_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_, mlfStrcmp(mlfIptgetpref(_mxarray75_), _mxarray45_)))) {
            mxDestroyArray(a_);
            /*
             * message = ['Image is too big to fit on screen; ', ...
             */
            mlfAssign(
              &message,
              mlfHorzcat(
                _mxarray77_,
                mlfSprintf(
                  NULL, _mxarray79_, mlfFloor(mclVv(scale, "scale")), NULL),
                NULL));
            /*
             * sprintf('displaying at %d%% scale.', floor(scale))];
             * warning(message);
             */
            mclAssignAns(
              &ans, mlfNWarning(0, NULL, mclVv(message, "message"), NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    return_:
    mxDestroyArray(imageWidth);
    mxDestroyArray(imageHeight);
    mxDestroyArray(axUnits);
    mxDestroyArray(ans);
    mxDestroyArray(axPos);
    mxDestroyArray(figLeftBorder);
    mxDestroyArray(figRightBorder);
    mxDestroyArray(figBottomBorder);
    mxDestroyArray(figTopBorder);
    mxDestroyArray(minFigWidth);
    mxDestroyArray(minFigHeight);
    mxDestroyArray(colorbarGap);
    mxDestroyArray(colorbarWidth);
    mxDestroyArray(caxHandle);
    mxDestroyArray(figHandle);
    mxDestroyArray(figUnits);
    mxDestroyArray(caxUnits);
    mxDestroyArray(rootUnits);
    mxDestroyArray(caxPos);
    mxDestroyArray(figPos);
    mxDestroyArray(orientation);
    mxDestroyArray(defFigPos);
    mxDestroyArray(defAxPos);
    mxDestroyArray(gutterLeft);
    mxDestroyArray(gutterRight);
    mxDestroyArray(gutterBottom);
    mxDestroyArray(gutterTop);
    mxDestroyArray(screenSize);
    mxDestroyArray(screenWidth);
    mxDestroyArray(screenHeight);
    mxDestroyArray(scale);
    mxDestroyArray(done);
    mxDestroyArray(newFigWidth);
    mxDestroyArray(newFigHeight);
    mxDestroyArray(deltaX);
    mxDestroyArray(deltaY);
    mxDestroyArray(left);
    mxDestroyArray(bottom);
    mxDestroyArray(width);
    mxDestroyArray(height);
    mxDestroyArray(message);
    mxDestroyArray(colorbarHandle);
    mxDestroyArray(imSize);
    mxDestroyArray(imHandle);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
