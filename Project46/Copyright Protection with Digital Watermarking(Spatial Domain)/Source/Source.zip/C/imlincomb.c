/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imlincomb.h"
#include "mwservices.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "images_private_imlincombc_mex_interface.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static double _ieee_plusinf_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;

static mxChar _array6_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray5_;

static mxChar _array8_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray7_;

static mxChar _array10_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray9_;

static mxChar _array12_[4] = { 'i', 'n', 't', '8' };
static mxArray * _mxarray11_;

static mxChar _array14_[5] = { 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray13_;

static mxChar _array16_[5] = { 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray15_;

static mxChar _array18_[6] = { 's', 'i', 'n', 'g', 'l', 'e' };
static mxArray * _mxarray17_;

static mxChar _array20_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray19_;

static mxArray * _array4_[8] = { NULL /*_mxarray5_*/, NULL /*_mxarray7_*/,
                                 NULL /*_mxarray9_*/, NULL /*_mxarray11_*/,
                                 NULL /*_mxarray13_*/, NULL /*_mxarray15_*/,
                                 NULL /*_mxarray17_*/, NULL /*_mxarray19_*/ };
static mxArray * _mxarray3_;

static mxChar _array22_[12] = { 'O', 'U', 'T', 'P', 'U', 'T',
                                '_', 'C', 'L', 'A', 'S', 'S' };
static mxArray * _mxarray21_;
static mxArray * _mxarray23_;
static mxArray * _mxarray24_;

static mxChar _array26_[21] = { 'r', 'e', 'a', 'l', ' ', 'n', 'o',
                                'n', 's', 'p', 'a', 'r', 's', 'e',
                                ' ', 's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray25_;

static mxChar _array28_[3] = { 'K', '%', 'd' };
static mxArray * _mxarray27_;

void InitializeModule_imlincomb(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _ieee_plusinf_ = mclGetInf();
    _mxarray1_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray2_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeString(5, _array6_);
    _array4_[0] = _mxarray5_;
    _mxarray7_ = mclInitializeString(6, _array8_);
    _array4_[1] = _mxarray7_;
    _mxarray9_ = mclInitializeString(6, _array10_);
    _array4_[2] = _mxarray9_;
    _mxarray11_ = mclInitializeString(4, _array12_);
    _array4_[3] = _mxarray11_;
    _mxarray13_ = mclInitializeString(5, _array14_);
    _array4_[4] = _mxarray13_;
    _mxarray15_ = mclInitializeString(5, _array16_);
    _array4_[5] = _mxarray15_;
    _mxarray17_ = mclInitializeString(6, _array18_);
    _array4_[6] = _mxarray17_;
    _mxarray19_ = mclInitializeString(6, _array20_);
    _array4_[7] = _mxarray19_;
    _mxarray3_ = mclInitializeCellVector(1, 8, _array4_);
    _mxarray21_ = mclInitializeString(12, _array22_);
    _mxarray23_ = mclInitializeDouble(3.0);
    _mxarray24_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray25_ = mclInitializeString(21, _array26_);
    _mxarray27_ = mclInitializeString(3, _array28_);
}

void TerminateModule_imlincomb(void) {
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImlincomb_ParseInputs(mxArray * * scalars,
                                          mxArray * * output_class,
                                          ...);
static void mlxImlincomb_ParseInputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * Mimlincomb(int nargout_, mxArray * varargin);
static mxArray * Mimlincomb_ParseInputs(mxArray * * scalars,
                                        mxArray * * output_class,
                                        int nargout_,
                                        mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "ParseInputs", mlxImlincomb_ParseInputs, -1, 3, NULL } };

_mexLocalFunctionTable _local_function_table_imlincomb
  = { 1, local_function_table_ };

/*
 * The function "mlfImlincomb" contains the normal interface for the
 * "imlincomb" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines 1-75). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfImlincomb(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * Z = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    Z = Mimlincomb(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(Z);
}

/*
 * The function "mlxImlincomb" contains the feval interface for the "imlincomb"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines
 * 1-75). The feval function calls the implementation version of imlincomb
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImlincomb(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imlincomb Line: 1 Column:"
            " 1 The function \"imlincomb\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimlincomb(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImlincomb_ParseInputs" contains the normal interface for
 * the "imlincomb/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines 75-97). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImlincomb_ParseInputs(mxArray * * scalars,
                                          mxArray * * output_class,
                                          ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * images = NULL;
    mxArray * scalars__ = NULL;
    mxArray * output_class__ = NULL;
    mlfVarargin(&varargin, output_class, 0);
    mlfEnterNewContext(2, -1, scalars, output_class, varargin);
    if (scalars != NULL) {
        ++nargout;
    }
    if (output_class != NULL) {
        ++nargout;
    }
    images
      = Mimlincomb_ParseInputs(&scalars__, &output_class__, nargout, varargin);
    mlfRestorePreviousContext(2, 0, scalars, output_class);
    mxDestroyArray(varargin);
    if (scalars != NULL) {
        mclCopyOutputArg(scalars, scalars__);
    } else {
        mxDestroyArray(scalars__);
    }
    if (output_class != NULL) {
        mclCopyOutputArg(output_class, output_class__);
    } else {
        mxDestroyArray(output_class__);
    }
    return mlfReturnValue(images);
}

/*
 * The function "mlxImlincomb_ParseInputs" contains the feval interface for the
 * "imlincomb/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines 75-97). The feval
 * function calls the implementation version of imlincomb/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImlincomb_ParseInputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imlincomb/ParseInputs Line: 75 Co"
            "lumn: 1 The function \"imlincomb/ParseInputs\" was call"
            "ed with more than the declared number of outputs (3)."),
          NULL);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimlincomb_ParseInputs(&mplhs[1], &mplhs[2], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mimlincomb" is the implementation version of the "imlincomb"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines
 * 1-75). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function Z = imlincomb(varargin)
 */
static mxArray * Mimlincomb(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imlincomb);
    mxArray * Z = NULL;
    mxArray * output_class = NULL;
    mxArray * scalars = NULL;
    mxArray * images = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMLINCOMB Compute linear combination of images.
     * %   Z = IMLINCOMB(K1,A1,K2,A2, ..., Kn,An) computes K1*A1 + K2*A2 + ... +
     * %   Kn*An.  A1, A2, ..., An are real, nonsparse, numeric arrays with the
     * %   same class and size, and K1, K2, ..., Kn are real double scalars.  Z
     * %   has the same size and class as A1.
     * %
     * %   Z = IMLINCOMB(K1,A1,K2,A2, ..., Kn,An,K) computes K1*A1 + K2*A2 +
     * %   ... + Kn*An + K.
     * %
     * %   Z = IMLINCOMB(..., OUTPUT_CLASS) lets you specify the class of Z.
     * %   OUTPUT_CLASS is a string containing the name of a numeric class.
     * %
     * %   Use IMLINCOMB to perform a series of arithmetic operations on a pair
     * %   of images, rather than nesting calls to individual arithmetic
     * %   functions, such as IMADD and IMMULTIPLY.  When you nest calls to the
     * %   arithmetic functions, and the input arrays have integer class,then
     * %   each function truncates and rounds the result before passing it to
     * %   the next function, thus losing accuracy in the final result.
     * %   IMLINCOMB performs all the arithmetic operations at once before
     * %   truncating and rounding the final result.
     * %
     * %   Each element of the output, Z, is computed individually in
     * %   double-precision floating point.  When Z is an integer array, elements
     * %   of Z that exceed the range of the integer type are truncated, and
     * %   fractional values are rounded.
     * %
     * %   Example 1
     * %   ---------
     * %   Scale an image by a factor of two.
     * %
     * %       I = imread('cameraman.tif');
     * %       J = imlincomb(2,I);
     * %       imshow(J)
     * %
     * %   Example 2
     * %   ---------
     * %   Form a difference image with the zero value shifted to 128.
     * %
     * %       I = imread('cameraman.tif');
     * %       J = uint8(filter2(fspecial('gaussian'), I));
     * %       K = imlincomb(1,I,-1,J,128); % K(r,c) = I(r,c) - J(r,c) + 128
     * %       imshow(K)
     * %
     * %   Example 3
     * %   ---------
     * %   Add two images with a specified output class.
     * %
     * %       I = imread('rice.tif');
     * %       J = imread('cameraman.tif');
     * %       K = imlincomb(1,I,1,J,'uint16');
     * %       imshow(K,[])
     * %
     * %   See also IMADD, IMCOMPLEMENT, IMDIVIDE, IMMULTIPLY, IMSUBTRACT.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.12 $  $Date: 2002/03/15 15:28:03 $
     * 
     * % I/O spec
     * % ========
     * % A1, ...       Real, numeric, full arrays
     * %               Logical arrays also allowed, and are converted to uint8.
     * %
     * % K1, ...       Real, double scalars
     * %
     * % OUTPUT_CLASS  Case-insensitive nonambiguous abbreviation of one of
     * %               these strings: uint8, uint16, uint32, int8, int16, int32,
     * %               single, double
     * 
     * [images, scalars, output_class] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &images,
      mlfImlincomb_ParseInputs(
        &scalars,
        &output_class,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * Z = imlincombc(images, scalars, output_class);
     */
    mlfAssign(
      &Z,
      mlfNImages_private_imlincombc(
        0,
        mclValueVarargout(),
        mclVv(images, "images"),
        mclVv(scalars, "scalars"),
        mclVv(output_class, "output_class"),
        NULL));
    mclValidateOutput(Z, 1, nargout_, "Z", "imlincomb");
    mxDestroyArray(images);
    mxDestroyArray(scalars);
    mxDestroyArray(output_class);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return Z;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mimlincomb_ParseInputs" is the implementation version of the
 * "imlincomb/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imlincomb.m" (lines 75-97). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [images, scalars, output_class] = ParseInputs(varargin)
 */
static mxArray * Mimlincomb_ParseInputs(mxArray * * scalars,
                                        mxArray * * output_class,
                                        int nargout_,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imlincomb);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * images = NULL;
    mxArray * p = NULL;
    mxArray * valid_strings = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * checknargin(2, Inf, nargin, mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("imlincomb"));
    /*
     * 
     * if ischar(varargin{end})
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxIschar,
            mlfIndexRef(
              mclVa(varargin, "varargin"),
              "{?}",
              mlfEnd(mclVa(varargin, "varargin"), _mxarray2_, _mxarray2_)),
            NULL))) {
        /*
         * valid_strings = {'uint8' 'uint16' 'uint32' 'int8' 'int16' 'int32' ...
         */
        mlfAssign(&valid_strings, _mxarray3_);
        /*
         * 'single' 'double'};
         * output_class = checkstrs(varargin{end}, valid_strings, mfilename, ...
         */
        mlfAssign(
          output_class,
          mclFeval(
            mclValueVarargout(),
            mlxImages_private_checkstrs,
            mlfIndexRef(
              mclVa(varargin, "varargin"),
              "{?}",
              mlfEnd(mclVa(varargin, "varargin"), _mxarray2_, _mxarray2_)),
            mclVv(valid_strings, "valid_strings"),
            mxCreateString("imlincomb"),
            _mxarray21_,
            _mxarray23_,
            NULL));
        /*
         * 'OUTPUT_CLASS', 3);
         * varargin(end) = [];
         */
        mlfIndexDelete(
          &varargin,
          "(?)",
          mlfEnd(mclVa(varargin, "varargin"), _mxarray2_, _mxarray2_));
    /*
     * else
     */
    } else {
        /*
         * output_class = class(varargin{2});
         */
        mlfAssign(
          output_class,
          mclFeval(
            mclValueVarargout(),
            mlxClassName,
            mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * images = varargin(2:2:end);
     */
    mlfAssign(
      &images,
      mclArrayRef1(
        mclVa(varargin, "varargin"),
        mlfColon(
          _mxarray0_,
          _mxarray0_,
          mlfEnd(mclVa(varargin, "varargin"), _mxarray2_, _mxarray2_))));
    /*
     * 
     * for p = 1:2:length(varargin)
     */
    {
        int v_ = mclForIntStart(1);
        int i_ = 2;
        int e_
          = mclForIntIntEnd(
              v_, i_, mlfScalar(mclLengthInt(mclVa(varargin, "varargin"))));
        if (e_ == mclIntMin()) {
            mlfAssign(&p, _mxarray24_);
        } else {
            /*
             * checkinput(varargin{p}, 'double', 'real nonsparse scalar', ...
             * mfilename, sprintf('K%d', (p+1)/2), p);
             * end
             */
            for (; ; ) {
                mclFeval(
                  mclAnsVarargout(),
                  mlxImages_private_checkinput,
                  mlfIndexRef(
                    mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                  _mxarray19_,
                  _mxarray25_,
                  mxCreateString("imlincomb"),
                  mlfSprintf(
                    NULL,
                    _mxarray27_,
                    mlfScalar(svDoubleScalarRdivide((double) (v_ + 1), 2.0)),
                    NULL),
                  mlfScalar(v_),
                  NULL);
                if (v_ == e_) {
                    break;
                }
                v_ += i_;
            }
            mlfAssign(&p, mlfScalar(v_));
        }
    }
    /*
     * 
     * scalars = [varargin{1:2:end}];
     */
    mlfAssign(
      scalars,
      mlfHorzcat(
        mlfIndexRef(
          mclVa(varargin, "varargin"),
          "{?}",
          mlfColon(
            _mxarray2_,
            _mxarray0_,
            mlfEnd(mclVa(varargin, "varargin"), _mxarray2_, _mxarray2_))),
        NULL));
    mclValidateOutput(images, 1, nargout_, "images", "imlincomb/ParseInputs");
    mclValidateOutput(
      *scalars, 2, nargout_, "scalars", "imlincomb/ParseInputs");
    mclValidateOutput(
      *output_class, 3, nargout_, "output_class", "imlincomb/ParseInputs");
    mxDestroyArray(ans);
    mxDestroyArray(valid_strings);
    mxDestroyArray(p);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return images;
}
