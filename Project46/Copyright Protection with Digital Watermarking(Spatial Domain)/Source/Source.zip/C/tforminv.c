/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "tforminv.h"
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[32] = { 'T', ' ', 'm', 'u', 's', 't', ' ', 'b',
                               'e', ' ', 'a', ' ', 's', 'i', 'n', 'g',
                               'l', 'e', ' ', 'T', 'F', 'O', 'R', 'M',
                               ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray1_;

static mxChar _array4_[46] = { 'X', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                               'a', ' ', 'r', 'e', 'a', 'l', '-', 'v', 'a', 'l',
                               'u', 'e', 'd', ' ', 'a', 'r', 'r', 'a', 'y', ' ',
                               'o', 'f', ' ', 'c', 'l', 'a', 's', 's', ' ', 'd',
                               'o', 'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray3_;

static mxChar _array6_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray5_;

static mxChar _array8_[33] = { 'A', 'l', 'l', ' ', 'e', 'l', 'e', 'm', 'e',
                               'n', 't', 's', ' ', 'o', 'f', ' ', 'X', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'f',
                               'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[42] = { 'T', 0x0027, 's', ' ', 0x0027, 'i', 'n', 'v',
                                'e', 'r', 's', 'e', '_', 'f', 'c', 'n',
                                0x0027, ' ', 'f', 'i', 'e', 'l', 'd', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'n',
                                'o', 'n', '-', 'e', 'm', 'p', 't', 'y', '.' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[41] = { 'S', 'I', 'Z', 'E', '(', 'X', ')', ' ', 'i',
                                's', ' ', 'i', 'n', 'c', 'o', 'n', 's', 'i',
                                's', 't', 'e', 'n', 't', ' ', 'w', 'i', 't',
                                'h', ' ', 'T', '.', 'n', 'd', 'i', 'm', 's',
                                '_', 'o', 'u', 't', '.' };
static mxArray * _mxarray12_;

void InitializeModule_tforminv(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeString(32, _array2_);
    _mxarray3_ = mclInitializeString(46, _array4_);
    _mxarray5_ = mclInitializeString(6, _array6_);
    _mxarray7_ = mclInitializeString(33, _array8_);
    _mxarray9_ = mclInitializeString(42, _array10_);
    _mxarray11_ = mclInitializeDouble(1.0);
    _mxarray12_ = mclInitializeString(41, _array13_);
}

void TerminateModule_tforminv(void) {
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mtforminv(int nargout_, mxArray * X, mxArray * t);

_mexLocalFunctionTable _local_function_table_tforminv
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfTforminv" contains the normal interface for the "tforminv"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tforminv.m" (lines
 * 1-98). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfTforminv(mxArray * X, mxArray * t) {
    int nargout = 1;
    mxArray * U = NULL;
    mlfEnterNewContext(0, 2, X, t);
    U = Mtforminv(nargout, X, t);
    mlfRestorePreviousContext(0, 2, X, t);
    return mlfReturnValue(U);
}

/*
 * The function "mlxTforminv" contains the feval interface for the "tforminv"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tforminv.m" (lines
 * 1-98). The feval function calls the implementation version of tforminv
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxTforminv(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tforminv Line: 1 Column:"
            " 1 The function \"tforminv\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tforminv Line: 1 Column:"
            " 1 The function \"tforminv\" was called with m"
            "ore than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtforminv(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mtforminv" is the implementation version of the "tforminv"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tforminv.m" (lines
 * 1-98). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function U = tforminv( X, t )
 */
static mxArray * Mtforminv(int nargout_, mxArray * X, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tforminv);
    int nargin_ = mclNargin(2, X, t, NULL);
    mxArray * U = NULL;
    mxArray * D = NULL;
    mxArray * N = NULL;
    mxArray * S = NULL;
    mxArray * M = NULL;
    mxArray * L = NULL;
    mxArray * P = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&X);
    mclCopyArray(&t);
    /*
     * %TFORMINV Apply inverse spatial transformation.
     * %   If X is a matrix, U = TFORMINV( X, T ) applies the inverse
     * %   transformation defined in T to each row of X.  T is a TFORM struct
     * %   created with MAKETFORM, FLIPTFORM, or CP2TFORM.  X is
     * %   M-by-T.ndims_out; each row of X represents a point in T's output space.
     * %   U is an M-by-T.ndims_out matrix; each row of U represents a point in T's
     * %   input space, and is the inverse transformation of the corresponding row
     * %   of X.
     * %
     * %   If X is an (N+1)-dimensional array (including an implicit trailing
     * %   singleton dimension if T.ndims_out is 1), then TFORMINV applies the
     * %   transformation to each point X(P1,P2,...,PN,:).  SIZE(X,N+1) must equal
     * %   T.ndims_in.  U is an (N+1)-dimensional array containing the results of
     * %   each transformation in U(P1,P2,...PN,:).  SIZE(U,I) equals SIZE(X,I) for
     * %   I = 1,...,N and SIZE(U,N+1) equals T.ndims_in.
     * % 
     * %   Example
     * %   -------
     * %   Create an affine transformation that maps the triangle with vertices
     * %   (0,0), (6,3), (-2,5) to the triangle with vertices (-1,-1), (0,-10),
     * %   (-2,5):
     * %
     * %       u = [0 0; 6 3; -2 5];
     * %       x = [-1 -1; 0 -10; 4 4];
     * %       tform = maketform('affine',u,x);
     * %   
     * %   Validate the mapping by applying TFORMINV to x:
     * %
     * %       tforminv(x,tform)  % Result should equal u
     * %
     * %   See also TFORMINV, MAKETFORM, FLIPTFORM, CP2TFORM.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.9 $ $Date: 2002/03/15 15:29:22 $
     * 
     * message = nargchk(2,2,nargin);
     */
    mlfAssign(&message, mlfNargchk(_mxarray0_, _mxarray0_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~istform(t) | (length(t) ~= 1)
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfImages_private_istform(mclVa(t, "t"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclBoolToArray(mclLengthInt(mclVa(t, "t")) != 1)))) {
            mxDestroyArray(a_);
            /*
             * error('T must be a single TFORM struct.');
             */
            mlfError(_mxarray1_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~isa(X,'double') | ~isreal(X)
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIsa(mclVa(X, "X"), _mxarray5_)));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mclNot(mlfIsreal(mclVa(X, "X")))))) {
            mxDestroyArray(a_);
            /*
             * error('X must be a real-valued array of class double.');
             */
            mlfError(_mxarray3_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~all(isfinite(X))
     */
    if (mclNotBool(mlfAll(mlfIsfinite(mclVa(X, "X")), NULL))) {
        /*
         * error('All elements of X must be finite.');
         */
        mlfError(_mxarray7_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if isempty(t.inverse_fcn)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxIsempty,
            mlfIndexRef(mclVa(t, "t"), ".inverse_fcn"),
            NULL))) {
        /*
         * error('T''s ''inverse_fcn'' field must be non-empty.')
         */
        mlfError(_mxarray9_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * P = t.ndims_in;
     */
    mlfAssign(&P, mlfIndexRef(mclVa(t, "t"), ".ndims_in"));
    /*
     * L = t.ndims_out;
     */
    mlfAssign(&L, mlfIndexRef(mclVa(t, "t"), ".ndims_out"));
    /*
     * M = ndims(X);
     */
    mlfAssign(&M, mlfNdims(mclVa(X, "X")));
    /*
     * S = size(X);
     */
    mlfAssign(&S, mlfSize(mclValueVarargout(), mclVa(X, "X"), NULL));
    /*
     * 
     * if S(M) > 1
     */
    if (mclGtBool(mclArrayRef1(mclVv(S, "S"), mclVv(M, "M")), _mxarray11_)) {
        /*
         * if L == 1;
         */
        if (mclEqBool(mclVv(L, "L"), _mxarray11_)) {
            /*
             * N = M;         % PROD(S) points in 1-D
             */
            mlfAssign(&N, mclVv(M, "M"));
        /*
         * elseif L == S(M)
         */
        } else if (mclEqBool(
                     mclVv(L, "L"),
                     mclArrayRef1(mclVv(S, "S"), mclVv(M, "M")))) {
            /*
             * N = M - 1;     % PROD(S(1:M-1)) points in L-D
             */
            mlfAssign(&N, mclMinus(mclVv(M, "M"), _mxarray11_));
        /*
         * else
         */
        } else {
            /*
             * error('SIZE(X) is inconsistent with T.ndims_out.');
             */
            mlfError(_mxarray12_, NULL);
        /*
         * end
         */
        }
        /*
         * D = S(1:N);
         */
        mlfAssign(
          &D,
          mclArrayRef1(
            mclVv(S, "S"), mlfColon(_mxarray11_, mclVv(N, "N"), NULL)));
    /*
     * else % S == [S(1) 1]
     */
    } else {
        /*
         * if L == 1
         */
        if (mclEqBool(mclVv(L, "L"), _mxarray11_)) {
            /*
             * D = S(1);      % S(1) points in 1-D
             */
            mlfAssign(&D, mclIntArrayRef1(mclVv(S, "S"), 1));
        /*
         * elseif L == S(1)
         */
        } else if (mclEqBool(
                     mclVv(L, "L"), mclIntArrayRef1(mclVv(S, "S"), 1))) {
            /*
             * D = 1;         % 1 point in L-D
             */
            mlfAssign(&D, _mxarray11_);
        /*
         * else
         */
        } else {
            /*
             * error('SIZE(X) is inconsistent with T.ndims_out.');
             */
            mlfError(_mxarray12_, NULL);
        /*
         * end        
         */
        }
        /*
         * N = 1;
         */
        mlfAssign(&N, _mxarray11_);
    /*
     * end
     */
    }
    /*
     * 
     * % Now D contains the sizes of the first N dimensions of X.
     * % Reshape X to collapse the first N dimensions into a single column.
     * % Each row of X is now a coordinate vector in t's output space.
     * 
     * X = reshape( X, [prod(D) L] );
     */
    mlfAssign(
      &X,
      mlfReshape(
        mclVa(X, "X"),
        mlfHorzcat(mlfProd(mclVv(D, "D"), NULL), mclVv(L, "L"), NULL), NULL));
    /*
     * 
     * % Apply the forward transformation, mapping X from the output
     * % space to the input space.
     * 
     * U = feval(t.inverse_fcn, X, t);
     */
    mlfAssign(
      &U,
      mlfFeval(
        mclValueVarargout(),
        mlfIndexRef(mclVa(t, "t"), ".inverse_fcn"),
        mclVa(X, "X"),
        mclVa(t, "t"),
        NULL));
    /*
     * 
     * % U is an array in which each row is a coordinate vector t's input
     * % space. Reshape U to be D(1) x D(2) x ... x D(N) x P.
     * 
     * U = reshape( U, [D P] );
     */
    mlfAssign(
      &U,
      mlfReshape(
        mclVv(U, "U"), mlfHorzcat(mclVv(D, "D"), mclVv(P, "P"), NULL), NULL));
    mclValidateOutput(U, 1, nargout_, "U", "tforminv");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(P);
    mxDestroyArray(L);
    mxDestroyArray(M);
    mxDestroyArray(S);
    mxDestroyArray(N);
    mxDestroyArray(D);
    mxDestroyArray(t);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return U;
}
