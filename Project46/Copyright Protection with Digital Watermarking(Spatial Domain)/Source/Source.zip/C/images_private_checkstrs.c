/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_checkstrs.h"
#include "images_private_checkinput.h"
#include "images_private_num2ordinal.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[4] = { 'c', 'h', 'a', 'r' };
static mxArray * _mxarray0_;

static mxChar _array3_[3] = { 'r', 'o', 'w' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;

static mxChar _array8_[2] = { ',', ' ' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;

static mxChar _array11_[47] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '%', 's', ' ', 'e', 'x', 'p', 'e',
                                'c', 't', 'e', 'd', ' ', 'i', 't', 's',
                                ' ', '%', 's', ' ', 'i', 'n', 'p', 'u',
                                't', ' ', 'a', 'r', 'g', 'u', 'm', 'e',
                                'n', 't', ',', ' ', '%', 's', ',' };
static mxArray * _mxarray10_;

static mxChar _array13_[30] = { 't', 'o', ' ', 'm', 'a', 't', 'c', 'h',
                                ' ', 'o', 'n', 'e', ' ', 'o', 'f', ' ',
                                't', 'h', 'e', 's', 'e', ' ', 's', 't',
                                'r', 'i', 'n', 'g', 's', ':' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;

static mxChar _array16_[56] = { 'T', 'h', 'e', ' ', 'i', 'n', 'p', 'u', 't',
                                ',', ' ', 0x0027, '%', 's', 0x0027, ',',
                                ' ', 'd', 'i', 'd', ' ', 'n', 'o', 't', ' ',
                                'm', 'a', 't', 'c', 'h', ' ', 'a', 'n', 'y',
                                ' ', 'o', 'f', ' ', 't', 'h', 'e', ' ', 'v',
                                'a', 'l', 'i', 'd', ' ', 's', 't', 'r', 'i',
                                'n', 'g', 's', '.' };
static mxArray * _mxarray15_;

static mxChar _array18_[34] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'u', 'n', 'r', 'e', 'c', 'o', 'g', 'n',
                                'i', 'z', 'e', 'd', 'S', 't', 'r', 'i', 'n',
                                'g', 'C', 'h', 'o', 'i', 'c', 'e' };
static mxArray * _mxarray17_;

static mxChar _array20_[52] = { 'T', 'h', 'e', ' ', 'i', 'n', 'p', 'u', 't',
                                ',', ' ', 0x0027, '%', 's', 0x0027, ',', ' ',
                                'm', 'a', 't', 'c', 'h', 'e', 'd', ' ', 'm',
                                'o', 'r', 'e', ' ', 't', 'h', 'a', 'n', ' ',
                                'o', 'n', 'e', ' ', 'v', 'a', 'l', 'i', 'd',
                                ' ', 's', 't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray19_;

static mxChar _array22_[31] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'a', 'm', 'b', 'i', 'g', 'u',
                                'o', 'u', 's', 'S', 't', 'r', 'i', 'n',
                                'g', 'C', 'h', 'o', 'i', 'c', 'e' };
static mxArray * _mxarray21_;

static mxChar _array24_[20] = { '%', 's', 0x005c, 'n', '%', 's', 0x005c,
                                'n', 0x005c, 'n', ' ', ' ', '%', 's',
                                0x005c, 'n', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray23_;

void InitializeModule_images_private_checkstrs(void) {
    _mxarray0_ = mclInitializeString(4, _array1_);
    _mxarray2_ = mclInitializeString(3, _array3_);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray6_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray7_ = mclInitializeString(2, _array8_);
    _mxarray9_ = mclInitializeDouble(2.0);
    _mxarray10_ = mclInitializeString(47, _array11_);
    _mxarray12_ = mclInitializeString(30, _array13_);
    _mxarray14_ = mclInitializeDouble(0.0);
    _mxarray15_ = mclInitializeString(56, _array16_);
    _mxarray17_ = mclInitializeString(34, _array18_);
    _mxarray19_ = mclInitializeString(52, _array20_);
    _mxarray21_ = mclInitializeString(31, _array22_);
    _mxarray23_ = mclInitializeString(20, _array24_);
}

void TerminateModule_images_private_checkstrs(void) {
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_checkstrs(int nargout_,
                                           mxArray * in,
                                           mxArray * valid_strings,
                                           mxArray * function_name,
                                           mxArray * variable_name,
                                           mxArray * argument_position);

_mexLocalFunctionTable _local_function_table_images_private_checkstrs
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_checkstrs" contains the normal interface for
 * the "images/private/checkstrs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkstrs.m" (lines 1-61). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImages_private_checkstrs(mxArray * in,
                                      mxArray * valid_strings,
                                      mxArray * function_name,
                                      mxArray * variable_name,
                                      mxArray * argument_position) {
    int nargout = 1;
    mxArray * out = NULL;
    mlfEnterNewContext(
      0, 5, in, valid_strings, function_name, variable_name, argument_position);
    out
      = Mimages_private_checkstrs(
          nargout,
          in,
          valid_strings,
          function_name,
          variable_name,
          argument_position);
    mlfRestorePreviousContext(
      0, 5, in, valid_strings, function_name, variable_name, argument_position);
    return mlfReturnValue(out);
}

/*
 * The function "mlxImages_private_checkstrs" contains the feval interface for
 * the "images/private/checkstrs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkstrs.m" (lines 1-61). The
 * feval function calls the implementation version of images/private/checkstrs
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_checkstrs(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]) {
    mxArray * mprhs[5];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checkstrs Line: 1 Co"
            "lumn: 1 The function \"images/private/checkstrs\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checkstrs Line: 1 Co"
            "lumn: 1 The function \"images/private/checkstrs\" was cal"
            "led with more than the declared number of inputs (5)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 5 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 5; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mplhs[0]
      = Mimages_private_checkstrs(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mlfRestorePreviousContext(
      0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_checkstrs" is the implementation version of
 * the "images/private/checkstrs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checkstrs.m" (lines 1-61). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = checkstrs(in, valid_strings, function_name, ...
 */
static mxArray * Mimages_private_checkstrs(int nargout_,
                                           mxArray * in,
                                           mxArray * valid_strings,
                                           mxArray * function_name,
                                           mxArray * variable_name,
                                           mxArray * argument_position) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checkstrs);
    mxArray * out = NULL;
    mxArray * id = NULL;
    mxArray * msg3 = NULL;
    mxArray * msg2 = NULL;
    mxArray * msg1 = NULL;
    mxArray * k = NULL;
    mxArray * list = NULL;
    mxArray * num_matches = NULL;
    mxArray * idx = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&in);
    mclCopyArray(&valid_strings);
    mclCopyArray(&function_name);
    mclCopyArray(&variable_name);
    mclCopyArray(&argument_position);
    /*
     * variable_name, argument_position)
     * %CHECKSTRS Check validity of option string.
     * %   OUT = CHECKSTRS(IN,VALID_STRINGS,FUNCTION_NAME,VARIABLE_NAME, ...
     * %   ARGUMENT_POSITION) checks the validity of the option string IN.  It
     * %   returns the matching string in VALID_STRINGS in OUT.  CHECKSTRS looks
     * %   for a case-insensitive nonambiguous match between IN and the strings
     * %   in VALID_STRINGS.
     * %
     * %   VALID_STRINGS is a cell array containing strings.
     * %
     * %   FUNCTION_NAME is a string containing the function name to be used in the
     * %   formatted error message.
     * %
     * %   VARIABLE_NAME is a string containing the documented variable name to be
     * %   used in the formatted error message.
     * %
     * %   ARGUMENT_POSITION is a positive integer indicating which input argument
     * %   is being checked; it is also used in the formatted error message.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.3 $  $Date: 2002/03/15 15:57:05 $
     * 
     * % Except for IN, input arguments are not checked for validity.
     * 
     * checkinput(in, 'char', 'row', function_name, variable_name, argument_position);
     */
    mlfImages_private_checkinput(
      mclVa(in, "in"),
      _mxarray0_,
      _mxarray2_,
      mclVa(function_name, "function_name"),
      mclVa(variable_name, "variable_name"),
      mclVa(argument_position, "argument_position"));
    /*
     * 
     * idx = strmatch(lower(in), valid_strings);
     */
    mlfAssign(
      &idx,
      mlfStrmatch(
        mlfLower(mclVa(in, "in")),
        mclVa(valid_strings, "valid_strings"),
        NULL));
    /*
     * 
     * num_matches = prod(size(idx));
     */
    mlfAssign(
      &num_matches,
      mlfProd(mlfSize(mclValueVarargout(), mclVv(idx, "idx"), NULL), NULL));
    /*
     * 
     * if num_matches == 1
     */
    if (mclEqBool(mclVv(num_matches, "num_matches"), _mxarray4_)) {
        /*
         * out = valid_strings{idx};
         */
        mlfAssign(
          &out,
          mlfIndexRef(
            mclVa(valid_strings, "valid_strings"), "{?}", mclVv(idx, "idx")));
    /*
     * 
     * else
     */
    } else {
        /*
         * % Convert valid_strings to a single string containing a space-separated list
         * % of valid strings.
         * list = '';
         */
        mlfAssign(&list, _mxarray5_);
        /*
         * for k = 1:length(valid_strings)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclLengthInt(mclVa(valid_strings, "valid_strings"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray6_);
            } else {
                /*
                 * list = [list ', ' valid_strings{k}];
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &list,
                      mlfHorzcat(
                        mclVv(list, "list"),
                        _mxarray7_,
                        mlfIndexRef(
                          mclVa(valid_strings, "valid_strings"),
                          "{?}",
                          mlfScalar(v_)),
                        NULL));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * list(1:2) = [];
         */
        mlfIndexDelete(&list, "(?)", mlfColon(_mxarray4_, _mxarray9_, NULL));
        /*
         * 
         * msg1 = sprintf('Function %s expected its %s input argument, %s,', ...
         */
        mlfAssign(
          &msg1,
          mlfSprintf(
            NULL,
            _mxarray10_,
            mclVa(function_name, "function_name"),
            mlfImages_private_num2ordinal(
              mclVa(argument_position, "argument_position")),
            mclVa(variable_name, "variable_name"),
            NULL));
        /*
         * function_name, num2ordinal(argument_position), ...
         * variable_name);
         * msg2 = 'to match one of these strings:';
         */
        mlfAssign(&msg2, _mxarray12_);
        /*
         * 
         * if num_matches == 0
         */
        if (mclEqBool(mclVv(num_matches, "num_matches"), _mxarray14_)) {
            /*
             * msg3 = sprintf('The input, ''%s'', did not match any of the valid strings.', in);
             */
            mlfAssign(
              &msg3, mlfSprintf(NULL, _mxarray15_, mclVa(in, "in"), NULL));
            /*
             * id = sprintf('Images:%s:unrecognizedStringChoice', function_name);
             */
            mlfAssign(
              &id,
              mlfSprintf(
                NULL,
                _mxarray17_,
                mclVa(function_name, "function_name"),
                NULL));
        /*
         * 
         * else
         */
        } else {
            /*
             * msg3 = sprintf('The input, ''%s'', matched more than one valid string.', in);
             */
            mlfAssign(
              &msg3, mlfSprintf(NULL, _mxarray19_, mclVa(in, "in"), NULL));
            /*
             * id = sprintf('Images:%s:ambiguousStringChoice', function_name);
             */
            mlfAssign(
              &id,
              mlfSprintf(
                NULL,
                _mxarray21_,
                mclVa(function_name, "function_name"),
                NULL));
        /*
         * end
         */
        }
        /*
         * 
         * error(id,'%s\n%s\n\n  %s\n\n%s', msg1, msg2, list, msg3);
         */
        mlfError(
          mclVv(id, "id"),
          _mxarray23_,
          mclVv(msg1, "msg1"),
          mclVv(msg2, "msg2"),
          mclVv(list, "list"),
          mclVv(msg3, "msg3"),
          NULL);
    /*
     * end
     */
    }
    mclValidateOutput(out, 1, nargout_, "out", "images/private/checkstrs");
    mxDestroyArray(ans);
    mxDestroyArray(idx);
    mxDestroyArray(num_matches);
    mxDestroyArray(list);
    mxDestroyArray(k);
    mxDestroyArray(msg1);
    mxDestroyArray(msg2);
    mxDestroyArray(msg3);
    mxDestroyArray(id);
    mxDestroyArray(argument_position);
    mxDestroyArray(variable_name);
    mxDestroyArray(function_name);
    mxDestroyArray(valid_strings);
    mxDestroyArray(in);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     * 
     */
}
