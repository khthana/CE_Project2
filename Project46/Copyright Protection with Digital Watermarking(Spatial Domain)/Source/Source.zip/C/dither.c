/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "dither.h"
#include "im2uint8.h"
#include "images_private_checknargin.h"
#include "images_private_ditherc_mex_interface.h"
#include "imshow.h"
#include "libmatlbm.h"
#include "libmwsglm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;

static mxChar _array8_[24] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                               's', ':', 'o', 'b', 's', 'o', 'l', 'e',
                               't', 'e', 'S', 'y', 'n', 't', 'a', 'x' };
static mxArray * _mxarray7_;

static mxChar _array10_[92] = { 'D', 'I', 'T', 'H', 'E', 'R', '(', 'R', ',',
                                'G', ',', 'B', ',', 'm', ')', ' ', 'i', 's',
                                ' ', 'a', 'n', ' ', 'o', 'b', 's', 'o', 'l',
                                'e', 't', 'e', ' ', 's', 'y', 'n', 't', 'a',
                                'x', '.', ' ', 'U', 's', 'e', ' ', 'a', ' ',
                                't', 'h', 'r', 'e', 'e', '-', 'd', 'i', 'm',
                                'e', 'n', 's', 'i', 'o', 'n', 'a', 'l', ' ',
                                'a', 'r', 'r', 'a', 'y', ' ', 't', 'o', ' ',
                                'r', 'e', 'p', 'r', 'e', 's', 'e', 'n', 't',
                                ' ', 'R', 'G', 'B', ' ', 'i', 'm', 'a', 'g',
                                'e', '.' };
static mxArray * _mxarray9_;

static mxChar _array12_[98] = { 'D', 'I', 'T', 'H', 'E', 'R', '(', 'R', ',',
                                'G', ',', 'B', ',', 'm', ',', 'q', 'm', ',',
                                'q', 'e', ')', ' ', 'i', 's', ' ', 'a', 'n',
                                ' ', 'o', 'b', 's', 'o', 'l', 'e', 't', 'e',
                                ' ', 's', 'y', 'n', 't', 'a', 'x', '.', ' ',
                                'U', 's', 'e', ' ', 'a', ' ', 't', 'h', 'r',
                                'e', 'e', '-', 'd', 'i', 'm', 'e', 'n', 's',
                                'i', 'o', 'n', 'a', 'l', ' ', 'a', 'r', 'r',
                                'a', 'y', ' ', 't', 'o', ' ', 'r', 'e', 'p',
                                'r', 'e', 's', 'e', 'n', 't', ' ', 'R', 'G',
                                'B', ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray11_;

static mxChar _array14_[22] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'i', 'n', 'v', 'a', 'l', 'i',
                                'd', 'I', 'n', 'p', 'u', 't' };
static mxArray * _mxarray13_;

static mxChar _array16_[39] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's', ' ',
                                'i', 'n', ' ', 'f', 'u', 'n', 'c', 't',
                                'i', 'o', 'n', ' ', '%', 's', '.' };
static mxArray * _mxarray15_;

static mxChar _array18_[23] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'i', 'm', 'a', 'g', 'e', 'M',
                                'u', 's', 't', 'B', 'e', '2', 'D' };
static mxArray * _mxarray17_;

static mxChar _array20_[67] = { 'D', 'I', 'T', 'H', 'E', 'R', '(', 'I', ')',
                                ':', ' ', 't', 'h', 'e', ' ', 'i', 'n', 't',
                                'e', 'n', 's', 'i', 't', 'y', ' ', 'i', 'm',
                                'a', 'g', 'e', ' ', 'I', ' ', 'h', 'a', 's',
                                ' ', 't', 'o', ' ', 'b', 'e', ' ', 'a', ' ',
                                't', 'w', 'o', '-', 'd', 'i', 'm', 'e', 'n',
                                's', 'i', 'o', 'n', 'a', 'l', ' ', 'a', 'r',
                                'r', 'a', 'y', '.' };
static mxArray * _mxarray19_;

static mxChar _array22_[23] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 'i', 'm', 'a', 'g', 'e', 'M',
                                'u', 's', 't', 'B', 'e', '3', 'D' };
static mxArray * _mxarray21_;

static mxChar _array24_[67] = { 'D', 'I', 'T', 'H', 'E', 'R', '(', 'R', 'G',
                                'B', ',', 'm', 'a', 'p', ')', ':', ' ', 't',
                                'h', 'e', ' ', 'R', 'G', 'B', ' ', 'i', 'm',
                                'a', 'g', 'e', ' ', 'h', 'a', 's', ' ', 't',
                                'o', ' ', 'b', 'e', ' ', 'a', ' ', 't', 'h',
                                'r', 'e', 'e', '-', 'd', 'i', 'm', 'e', 'n',
                                's', 'i', 'o', 'n', 'a', 'l', ' ', 'a', 'r',
                                'r', 'a', 'y', '.' };
static mxArray * _mxarray23_;

static mxChar _array26_[26] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'c', 'o', 'l', 'o', 'r', 'm', 'a', 'p',
                                'M', 'u', 's', 't', 'B', 'e', '2', 'D' };
static mxArray * _mxarray25_;

static mxChar _array28_[95] = { 'I', 'n', ' ', 'f', 'u', 'n', 'c', 't', 'i',
                                'o', 'n', ' ', '%', 's', ',', ' ', 'i', 'n',
                                'p', 'u', 't', ' ', 'c', 'o', 'l', 'o', 'r',
                                'm', 'a', 'p', ' ', 'h', 'a', 's', ' ', 't',
                                'o', ' ', 'b', 'e', ' ', 'a', ' ', '2', 'D',
                                ' ', 'a', 'r', 'r', 'a', 'y', ' ', 'w', 'i',
                                't', 'h', ' ', 'a', 't', ' ', 'l', 'e', 'a',
                                's', 't', ' ', '2', ' ', 'r', 'o', 'w', 's',
                                ' ', 'a', 'n', 'd', ' ', 'e', 'x', 'a', 'c',
                                't', 'l', 'y', ' ', '3', ' ', 'c', 'o', 'l',
                                'u', 'm', 'n', 's', '.' };
static mxArray * _mxarray27_;

void InitializeModule_dither(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeDouble(6.0);
    _mxarray3_ = mclInitializeDouble(5.0);
    _mxarray4_ = mclInitializeDouble(8.0);
    _mxarray5_ = mclInitializeDouble(4.0);
    _mxarray6_ = mclInitializeDouble(3.0);
    _mxarray7_ = mclInitializeString(24, _array8_);
    _mxarray9_ = mclInitializeString(92, _array10_);
    _mxarray11_ = mclInitializeString(98, _array12_);
    _mxarray13_ = mclInitializeString(22, _array14_);
    _mxarray15_ = mclInitializeString(39, _array16_);
    _mxarray17_ = mclInitializeString(23, _array18_);
    _mxarray19_ = mclInitializeString(67, _array20_);
    _mxarray21_ = mclInitializeString(23, _array22_);
    _mxarray23_ = mclInitializeString(67, _array24_);
    _mxarray25_ = mclInitializeString(26, _array26_);
    _mxarray27_ = mclInitializeString(95, _array28_);
}

void TerminateModule_dither(void) {
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfDither_parse_inputs(mxArray * * m,
                                        mxArray * * qm,
                                        mxArray * * qe,
                                        ...);
static void mlxDither_parse_inputs(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * Mdither(int nargout_, mxArray * varargin);
static mxArray * Mdither_parse_inputs(mxArray * * m,
                                      mxArray * * qm,
                                      mxArray * * qe,
                                      int nargout_,
                                      mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "parse_inputs", mlxDither_parse_inputs, -1, 4, NULL } };

_mexLocalFunctionTable _local_function_table_dither
  = { 1, local_function_table_ };

/*
 * The function "mlfNDither" contains the nargout interface for the "dither"
 * M-function from file "k:\matlab6p5\toolbox\images\images\dither.m" (lines
 * 1-62). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNDither(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mdither(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfDither" contains the normal interface for the "dither"
 * M-function from file "k:\matlab6p5\toolbox\images\images\dither.m" (lines
 * 1-62). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfDither(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mdither(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVDither" contains the void interface for the "dither"
 * M-function from file "k:\matlab6p5\toolbox\images\images\dither.m" (lines
 * 1-62). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVDither(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mdither(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxDither" contains the feval interface for the "dither"
 * M-function from file "k:\matlab6p5\toolbox\images\images\dither.m" (lines
 * 1-62). The feval function calls the implementation version of dither through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxDither(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mdither(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfDither_parse_inputs" contains the normal interface for the
 * "dither/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\dither.m" (lines 62-127). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfDither_parse_inputs(mxArray * * m,
                                        mxArray * * qm,
                                        mxArray * * qe,
                                        ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * X = NULL;
    mxArray * m__ = NULL;
    mxArray * qm__ = NULL;
    mxArray * qe__ = NULL;
    mlfVarargin(&varargin, qe, 0);
    mlfEnterNewContext(3, -1, m, qm, qe, varargin);
    if (m != NULL) {
        ++nargout;
    }
    if (qm != NULL) {
        ++nargout;
    }
    if (qe != NULL) {
        ++nargout;
    }
    X = Mdither_parse_inputs(&m__, &qm__, &qe__, nargout, varargin);
    mlfRestorePreviousContext(3, 0, m, qm, qe);
    mxDestroyArray(varargin);
    if (m != NULL) {
        mclCopyOutputArg(m, m__);
    } else {
        mxDestroyArray(m__);
    }
    if (qm != NULL) {
        mclCopyOutputArg(qm, qm__);
    } else {
        mxDestroyArray(qm__);
    }
    if (qe != NULL) {
        mclCopyOutputArg(qe, qe__);
    } else {
        mxDestroyArray(qe__);
    }
    return mlfReturnValue(X);
}

/*
 * The function "mlxDither_parse_inputs" contains the feval interface for the
 * "dither/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\dither.m" (lines 62-127). The feval
 * function calls the implementation version of dither/parse_inputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxDither_parse_inputs(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: dither/parse_inputs Line: 62 Col"
            "umn: 1 The function \"dither/parse_inputs\" was called"
            " with more than the declared number of outputs (4)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mdither_parse_inputs(&mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mdither" is the implementation version of the "dither"
 * M-function from file "k:\matlab6p5\toolbox\images\images\dither.m" (lines
 * 1-62). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout=dither(varargin)
 */
static mxArray * Mdither(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_dither);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * map = NULL;
    mxArray * im = NULL;
    mxArray * qe = NULL;
    mxArray * qm = NULL;
    mxArray * m = NULL;
    mxArray * X = NULL;
    mclCopyArray(&varargin);
    /*
     * %DITHER Convert image using dithering.
     * %   X = DITHER(RGB,MAP) creates an indexed image approximation of
     * %   the RGB image in the array RGB by dithering the colors in
     * %   colormap MAP.  MAP cannot have more than 65536 colors.
     * %
     * %   X = DITHER(RGB,MAP,Qm,Qe) creates an indexed image from RGB,
     * %   specifying the parameters Qm and Qe. Qm specifies the number
     * %   of quantization bits to use along each color axis for the
     * %   inverse color map, and Qe specifies the number of
     * %   quantization bits to use for the color space error
     * %   calculations.  If Qe < Qm, dithering cannot be performed and
     * %   an undithered indexed image is returned in X.  If you omit
     * %   these parameters, DITHER uses the default values Qm = 5, 
     * %   Qe = 8.
     * %
     * %   BW = DITHER(I) converts the intensity image in the matrix I
     * %   to the binary image BW by dithering.
     * %
     * %   Class Support
     * %   -------------
     * %   The input image (RGB or I) can be of class uint8, uint16, or
     * %   double. All other input arguments must be of class
     * %   double. The output image (X or BW) is of class logical if it is
     * %   a binary image or uint8 if it is an indexed image with 256 or fewer
     * %   colors; otherwise its class is uint16.
     * %
     * %   See also RGB2IND.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.24 $  $Date: 2002/03/15 15:27:09 $
     * 
     * %   References: 
     * %      R. W. Floyd and L. Steinberg, "An Adaptive Algorithm for
     * %         Spatial Gray Scale," International Symposium Digest of Technical
     * %         Papers, Society for Information Displays, 36.  1975.
     * %      Spencer W. Thomas, "Efficient Inverse Color Map Computation",
     * %         Graphics Gems II, (ed. James Arvo), Academic Press: Boston.
     * %         1991. (includes source code)
     * 
     * [X,m,qm,qe] = parse_inputs(varargin{:});
     */
    mlfAssign(
      &X,
      mlfDither_parse_inputs(
        &m,
        &qm,
        &qe,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * if ndims(X)==2,% Convert intensity image to binary by dithering
     */
    if (mclEqBool(mlfNdims(mclVv(X, "X")), _mxarray0_)) {
        /*
         * im = logical(ditherc(X,m,qm,qe));
         */
        mlfAssign(
          &im,
          mlfLogical(
            mlfNImages_private_ditherc(
              0,
              mclValueVarargout(),
              mclVv(X, "X"),
              mclVv(m, "m"),
              mclVv(qm, "qm"),
              mclVv(qe, "qe"),
              NULL)));
        /*
         * map = 2;
         */
        mlfAssign(&map, _mxarray0_);
    /*
     * else % Create an indexed image from RGB 
     */
    } else {
        /*
         * im = ditherc(X,m,qm,qe);
         */
        mlfAssign(
          &im,
          mlfNImages_private_ditherc(
            0,
            mclValueVarargout(),
            mclVv(X, "X"),
            mclVv(m, "m"),
            mclVv(qm, "qm"),
            mclVv(qe, "qe"),
            NULL));
        /*
         * map = m;
         */
        mlfAssign(&map, mclVv(m, "m"));
    /*
     * end
     */
    }
    /*
     * 
     * if nargout==0,
     */
    if (nargout_ == 0) {
        /*
         * imshow(im,map);
         */
        mclAssignAns(
          &ans, mlfNImshow(0, mclVv(im, "im"), mclVv(map, "map"), NULL));
    /*
     * else 
     */
    } else {
        /*
         * varargout{1} = im;
         */
        mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(im, "im"));
    /*
     * end
     */
    }
    mxDestroyArray(X);
    mxDestroyArray(m);
    mxDestroyArray(qm);
    mxDestroyArray(qe);
    mxDestroyArray(im);
    mxDestroyArray(map);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %
     * %  Function: parse_inputs
     * %
     * 
     */
}

/*
 * The function "Mdither_parse_inputs" is the implementation version of the
 * "dither/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\dither.m" (lines 62-127). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [X,m,qm,qe] = parse_inputs(varargin)
 */
static mxArray * Mdither_parse_inputs(mxArray * * m,
                                      mxArray * * qm,
                                      mxArray * * qe,
                                      int nargout_,
                                      mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_dither);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * X = NULL;
    mxArray * msg = NULL;
    mxArray * eid = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * % Outputs:  X  the input RGB (3D) or intensity image (2D)
     * %           m  colormap (:,3)
     * %           qm number of quantization bits for colormap
     * %           qe number of quantization bits for errors, qe>qm
     * 
     * checknargin(1,6,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray1_, _mxarray2_, mlfScalar(nargin_), mxCreateString("dither"));
    /*
     * 
     * % Default values:
     * qm = 5;
     */
    mlfAssign(qm, _mxarray3_);
    /*
     * qe = 8;
     */
    mlfAssign(qe, _mxarray4_);
    /*
     * 
     * switch nargin
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray1_)) {
            /*
             * case 1,                        % dither(I)
             * X = varargin{1};
             */
            mlfAssign(
              &X, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * m = gray(2); 
             */
            mlfAssign(m, mlfGray(_mxarray0_));
        /*
         * case 2,                        % dither(RGB,m)
         */
        } else if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * X = varargin{1};
             */
            mlfAssign(
              &X, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * m = varargin{2};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
        /*
         * case 4,
         */
        } else if (mclSwitchCompare(v_, _mxarray5_)) {
            /*
             * if length(varargin{4})==1,   % dither(RGB,m,qm,qe)
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxLength,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_),
                    NULL),
                  _mxarray1_)) {
                /*
                 * X = varargin{1};
                 */
                mlfAssign(
                  &X,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
                /*
                 * m = varargin{2};
                 */
                mlfAssign(
                  m,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
                /*
                 * qm = varargin{3};
                 */
                mlfAssign(
                  qm,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray6_));
                /*
                 * qe = varargin{4};
                 */
                mlfAssign(
                  qe,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_));
            /*
             * else                        % dither(R,G,B,m) OBSOLETE
             */
            } else {
                /*
                 * eid = sprintf('Images:%s:obsoleteSyntax',mfilename);
                 */
                mlfAssign(
                  &eid,
                  mlfSprintf(NULL, _mxarray7_, mxCreateString("dither"), NULL));
                /*
                 * msg = ['DITHER(R,G,B,m) is an obsolete syntax. ',...
                 */
                mlfAssign(&msg, _mxarray9_);
                /*
                 * 'Use a three-dimensional array to represent RGB image.'];
                 * warning(eid,msg);
                 */
                mclAssignAns(
                  &ans,
                  mlfNWarning(
                    0, NULL, mclVv(eid, "eid"), mclVv(msg, "msg"), NULL));
                /*
                 * X = cat(3,varargin{1},varargin{2},varargin{3});
                 */
                mlfAssign(
                  &X,
                  mlfCat(
                    _mxarray6_,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray6_),
                    NULL));
                /*
                 * m = varargin{4};
                 */
                mlfAssign(
                  m,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_));
            /*
             * end;
             */
            }
        /*
         * case 6,                       % dither(R,G,B,m,qm,qe) OBSOLETE
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * eid = sprintf('Images:%s:obsoleteSyntax',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray7_, mxCreateString("dither"), NULL));
            /*
             * msg = ['DITHER(R,G,B,m,qm,qe) is an obsolete syntax. ',...
             */
            mlfAssign(&msg, _mxarray11_);
            mclPrintArray(mclVv(msg, "msg"), "msg");
            /*
             * 'Use a three-dimensional array to represent RGB image.']
             * warning(eid, msg);
             */
            mclAssignAns(
              &ans,
              mlfNWarning(0, NULL, mclVv(eid, "eid"), mclVv(msg, "msg"), NULL));
            /*
             * X = cat(3,varargin{1},varargin{2},varargin{3});
             */
            mlfAssign(
              &X,
              mlfCat(
                _mxarray6_,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray6_),
                NULL));
            /*
             * m = varargin{4};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_));
            /*
             * qm = varargin{5};
             */
            mlfAssign(
              qm, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray3_));
            /*
             * qe = varargin{6};
             */
            mlfAssign(
              qe, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_));
        /*
         * otherwise,
         */
        } else {
            /*
             * eid = sprintf('Images:%s:invalidInput',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray13_, mxCreateString("dither"), NULL));
            /*
             * error(eid,'Invalid input arguments in function %s.',mfilename);
             */
            mlfError(
              mclVv(eid, "eid"), _mxarray15_, mxCreateString("dither"), NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * % Check validity of the input parameters 
     * if (ndims(X)==3)&(nargin==1),
     */
    {
        mxArray * a_
          = mclInitialize(mclEq(mlfNdims(mclVv(X, "X")), _mxarray6_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclBoolToArray(nargin_ == 1)))) {
            mxDestroyArray(a_);
            /*
             * eid = sprintf('Images:%s:imageMustBe2D',mfilename);  
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray17_, mxCreateString("dither"), NULL));
            /*
             * error(eid,'DITHER(I): the intensity image I has to be a two-dimensional array.');
             */
            mlfError(mclVv(eid, "eid"), _mxarray19_, NULL);
        /*
         * elseif (ndims(X)==2)&(nargin==2),
         */
        } else {
            mxDestroyArray(a_);
            {
                mxArray * a_0
                  = mclInitialize(mclEq(mlfNdims(mclVv(X, "X")), _mxarray0_));
                if (mlfTobool(a_0)
                    && mlfTobool(mclAnd(a_0, mclBoolToArray(nargin_ == 2)))) {
                    mxDestroyArray(a_0);
                    /*
                     * eid = sprintf('Images:%s:imageMustBe3D',mfilename);  
                     */
                    mlfAssign(
                      &eid,
                      mlfSprintf(
                        NULL, _mxarray21_, mxCreateString("dither"), NULL));
                    /*
                     * error(eid,'DITHER(RGB,map): the RGB image has to be a three-dimensional array.');
                     */
                    mlfError(mclVv(eid, "eid"), _mxarray23_, NULL);
                } else {
                    mxDestroyArray(a_0);
                }
            }
        }
    /*
     * end;
     */
    }
    /*
     * 
     * X = im2uint8(X);
     */
    mlfAssign(&X, mlfIm2uint8(mclVv(X, "X"), NULL));
    /*
     * 
     * if (size(m,2) ~= 3)|(size(m,1)==1)|ndims(m)>2,
     */
    {
        mxArray * a_
          = mclInitialize(
              mclNe(
                mlfSize(mclValueVarargout(), mclVv(*m, "m"), _mxarray0_),
                _mxarray6_));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_,
              mclOr(
                a_,
                mclEq(
                  mlfSize(mclValueVarargout(), mclVv(*m, "m"), _mxarray1_),
                  _mxarray1_)));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(a_, mclGt(mlfNdims(mclVv(*m, "m")), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * eid = sprintf('Images:%s:colormapMustBe2D',mfilename);  
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray25_, mxCreateString("dither"), NULL));
            /*
             * error(eid,['In function %s, input colormap has to be a ',...
             */
            mlfError(
              mclVv(eid, "eid"), _mxarray27_, mxCreateString("dither"), NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * '2D array with at least 2 rows and exactly 3 columns.'], mfilename);
     * end;
     */
    }
    mclValidateOutput(X, 1, nargout_, "X", "dither/parse_inputs");
    mclValidateOutput(*m, 2, nargout_, "m", "dither/parse_inputs");
    mclValidateOutput(*qm, 3, nargout_, "qm", "dither/parse_inputs");
    mclValidateOutput(*qe, 4, nargout_, "qe", "dither/parse_inputs");
    mxDestroyArray(ans);
    mxDestroyArray(eid);
    mxDestroyArray(msg);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}
