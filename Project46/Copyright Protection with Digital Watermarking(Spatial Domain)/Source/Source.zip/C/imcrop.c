/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imcrop.h"
#include "getimage.h"
#include "getrect.h"
#include "images_private_checknargin.h"
#include "imshow.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;

static mxChar _array4_[47] = { 'T', 'h', 'e', ' ', 'c', 'r', 'o', 'p', ' ', 'r',
                               'e', 'c', 't', 'a', 'n', 'g', 'l', 'e', ' ', 'd',
                               'o', 'e', 's', ' ', 'n', 'o', 't', ' ', 'i', 'n',
                               't', 'e', 'r', 's', 'e', 'c', 't', ' ', 't', 'h',
                               'e', ' ', 'i', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray3_;

static mxChar _array6_[39] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's', ':',
                               'c', 'r', 'o', 'p', 'R', 'e', 'c', 't', 'D', 'o',
                               'e', 's', 'N', 'o', 't', 'I', 'n', 't', 'e', 'r',
                               's', 'e', 'c', 't', 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray5_;
static mxArray * _mxarray7_;
static mxArray * _mxarray8_;
static mxArray * _mxarray9_;

static mxChar _array11_[25] = { 'T', 'o', 'o', ' ', 'm', 'a', 'n', 'y', ' ',
                                'o', 'u', 't', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray10_;

static mxChar _array13_[32] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 't', 'o', 'o', 'M', 'a', 'n',
                                'y', 'O', 'u', 't', 'p', 'u', 't', 'A',
                                'r', 'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;

static mxChar _array16_[34] = { 'N', 'o', ' ', 'i', 'm', 'a', 'g', 'e', ' ',
                                'f', 'o', 'u', 'n', 'd', ' ', 'i', 'n', ' ',
                                't', 'h', 'e', ' ', 'c', 'u', 'r', 'r', 'e',
                                'n', 't', ' ', 'a', 'x', 'e', 's' };
static mxArray * _mxarray15_;

static mxChar _array18_[35] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'n', 'o', 'I', 'm', 'a', 'g', 'e', 'F',
                                'o', 'u', 'n', 'd', 'I', 'n', 'C', 'u', 'r',
                                'r', 'e', 'n', 't', 'A', 'x', 'e', 's' };
static mxArray * _mxarray17_;

static mxChar _array20_[20] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd',
                                ' ', 'i', 'n', 'p', 'u', 't', ' ',
                                'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray19_;

static mxChar _array22_[27] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'i', 'n', 'v', 'a', 'l', 'i', 'd', 'I',
                                'n', 'p', 'u', 't', 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray21_;

void InitializeModule_imcrop(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray2_ = mclInitializeDouble(0.0);
    _mxarray3_ = mclInitializeString(47, _array4_);
    _mxarray5_ = mclInitializeString(39, _array6_);
    _mxarray7_ = mclInitializeDouble(2.0);
    _mxarray8_ = mclInitializeDouble(4.0);
    _mxarray9_ = mclInitializeDouble(3.0);
    _mxarray10_ = mclInitializeString(25, _array11_);
    _mxarray12_ = mclInitializeString(32, _array13_);
    _mxarray14_ = mclInitializeDouble(5.0);
    _mxarray15_ = mclInitializeString(34, _array16_);
    _mxarray17_ = mclInitializeString(35, _array18_);
    _mxarray19_ = mclInitializeString(20, _array20_);
    _mxarray21_ = mclInitializeString(27, _array22_);
}

void TerminateModule_imcrop(void) {
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImcrop_ParseInputs(mxArray * * y,
                                       mxArray * * a,
                                       mxArray * * cm,
                                       mxArray * * rect,
                                       ...);
static void mlxImcrop_ParseInputs(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]);
static void mlfImcrop_CheckCData(mxArray * cdata);
static void mlxImcrop_CheckCData(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]);
static mxArray * Mimcrop(int nargout_, mxArray * varargin);
static mxArray * Mimcrop_ParseInputs(mxArray * * y,
                                     mxArray * * a,
                                     mxArray * * cm,
                                     mxArray * * rect,
                                     int nargout_,
                                     mxArray * varargin);
static void Mimcrop_CheckCData(mxArray * cdata);

static mexFunctionTableEntry local_function_table_[2]
  = { { "ParseInputs", mlxImcrop_ParseInputs, -1, 5, NULL },
      { "CheckCData", mlxImcrop_CheckCData, 1, 0, NULL } };

_mexLocalFunctionTable _local_function_table_imcrop
  = { 2, local_function_table_ };

/*
 * The function "mlfNImcrop" contains the nargout interface for the "imcrop"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines
 * 1-160). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNImcrop(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimcrop(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImcrop" contains the normal interface for the "imcrop"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines
 * 1-160). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImcrop(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimcrop(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImcrop" contains the void interface for the "imcrop"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines
 * 1-160). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImcrop(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimcrop(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImcrop" contains the feval interface for the "imcrop"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines
 * 1-160). The feval function calls the implementation version of imcrop
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImcrop(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimcrop(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImcrop_ParseInputs" contains the normal interface for the
 * "imcrop/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 160-256). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImcrop_ParseInputs(mxArray * * y,
                                       mxArray * * a,
                                       mxArray * * cm,
                                       mxArray * * rect,
                                       ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * x = NULL;
    mxArray * y__ = NULL;
    mxArray * a__ = NULL;
    mxArray * cm__ = NULL;
    mxArray * rect__ = NULL;
    mlfVarargin(&varargin, rect, 0);
    mlfEnterNewContext(4, -1, y, a, cm, rect, varargin);
    if (y != NULL) {
        ++nargout;
    }
    if (a != NULL) {
        ++nargout;
    }
    if (cm != NULL) {
        ++nargout;
    }
    if (rect != NULL) {
        ++nargout;
    }
    x = Mimcrop_ParseInputs(&y__, &a__, &cm__, &rect__, nargout, varargin);
    mlfRestorePreviousContext(4, 0, y, a, cm, rect);
    mxDestroyArray(varargin);
    if (y != NULL) {
        mclCopyOutputArg(y, y__);
    } else {
        mxDestroyArray(y__);
    }
    if (a != NULL) {
        mclCopyOutputArg(a, a__);
    } else {
        mxDestroyArray(a__);
    }
    if (cm != NULL) {
        mclCopyOutputArg(cm, cm__);
    } else {
        mxDestroyArray(cm__);
    }
    if (rect != NULL) {
        mclCopyOutputArg(rect, rect__);
    } else {
        mxDestroyArray(rect__);
    }
    return mlfReturnValue(x);
}

/*
 * The function "mlxImcrop_ParseInputs" contains the feval interface for the
 * "imcrop/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 160-256). The feval
 * function calls the implementation version of imcrop/ParseInputs through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImcrop_ParseInputs(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[5];
    int i;
    if (nlhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imcrop/ParseInputs Line: 160 Col"
            "umn: 1 The function \"imcrop/ParseInputs\" was called "
            "with more than the declared number of outputs (5)."),
          NULL);
    }
    for (i = 0; i < 5; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mimcrop_ParseInputs(
          &mplhs[1], &mplhs[2], &mplhs[3], &mplhs[4], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 5 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 5; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImcrop_CheckCData" contains the normal interface for the
 * "imcrop/CheckCData" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 256-269). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfImcrop_CheckCData(mxArray * cdata) {
    mlfEnterNewContext(0, 1, cdata);
    Mimcrop_CheckCData(cdata);
    mlfRestorePreviousContext(0, 1, cdata);
}

/*
 * The function "mlxImcrop_CheckCData" contains the feval interface for the
 * "imcrop/CheckCData" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 256-269). The feval
 * function calls the implementation version of imcrop/CheckCData through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImcrop_CheckCData(int nlhs,
                                 mxArray * plhs[],
                                 int nrhs,
                                 mxArray * prhs[]) {
    mxArray * mprhs[1];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imcrop/CheckCData Line: 256 Col"
            "umn: 1 The function \"imcrop/CheckCData\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imcrop/CheckCData Line: 256 Col"
            "umn: 1 The function \"imcrop/CheckCData\" was called "
            "with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    Mimcrop_CheckCData(mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
}

/*
 * The function "Mimcrop" is the implementation version of the "imcrop"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines
 * 1-160). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = imcrop(varargin)
 */
static mxArray * Mimcrop(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imcrop);
    mxArray * varargout = NULL;
    mxArray * eid = NULL;
    mxArray * ans = NULL;
    mxArray * wid = NULL;
    mxArray * msg = NULL;
    mxArray * b = NULL;
    mxArray * c2 = NULL;
    mxArray * r2 = NULL;
    mxArray * c1 = NULL;
    mxArray * r1 = NULL;
    mxArray * pixelWidth = NULL;
    mxArray * pixelHeight = NULL;
    mxArray * pixelsPerHorizUnit = NULL;
    mxArray * pixelsPerVerticalUnit = NULL;
    mxArray * ymax = NULL;
    mxArray * xmax = NULL;
    mxArray * ymin = NULL;
    mxArray * xmin = NULL;
    mxArray * o = NULL;
    mxArray * n = NULL;
    mxArray * m = NULL;
    mxArray * rect = NULL;
    mxArray * cm = NULL;
    mxArray * a = NULL;
    mxArray * y = NULL;
    mxArray * x = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMCROP Crop image.
     * %   IMCROP crops an image to a specified rectangle. In the
     * %   syntaxes below, IMCROP displays the input image and waits for
     * %   you to specify the crop rectangle with the mouse:
     * %
     * %        I2 = IMCROP(I)
     * %        X2 = IMCROP(X,MAP)
     * %        RGB2 = IMCROP(RGB)
     * %
     * %   If you omit the input arguments, IMCROP operates on the image
     * %   in the current axes.
     * %
     * %   To specify the rectangle:
     * %
     * %   - For a single-button mouse, press the mouse button and drag
     * %     to define the crop rectangle. Finish by releasing the mouse
     * %     button.
     * %
     * %   - For a 2- or 3-button mouse, press the left mouse button and
     * %     drag to define the crop rectangle. Finish by releasing the
     * %     mouse button.
     * %
     * %   If you hold down the SHIFT key while dragging, or if you
     * %   press the right mouse button on a 2- or 3-button mouse,
     * %   IMCROP constrains the bounding rectangle to be a square.
     * %
     * %   When you release the mouse button, IMCROP returns the cropped
     * %   image in the supplied output argument. If you do not supply
     * %   an output argument, IMCROP displays the output image in a new
     * %   figure.
     * %
     * %   You can also specify the cropping rectangle noninteractively,
     * %   using these syntaxes:
     * %
     * %        I2 = IMCROP(I,RECT)
     * %        X2 = IMCROP(X,MAP,RECT)
     * %        RGB2 = IMCROP(RGB,RECT)
     * %
     * %   RECT is a 4-element vector with the form [XMIN YMIN WIDTH
     * %   HEIGHT]; these values are specified in spatial coordinates.
     * %
     * %   To specify a nondefault spatial coordinate system for the
     * %   input image, precede the other input arguments with two
     * %   2-element vectors specifying the XData and YData:
     * %
     * %        [...] = IMCROP(X,Y,...)
     * %
     * %   If you supply additional output arguments, IMCROP returns
     * %   information about the selected rectangle and the coordinate
     * %   system of the input image:
     * %
     * %        [A,RECT] = IMCROP(...)
     * %        [X,Y,A,RECT] = IMCROP(...)
     * %
     * %   A is the output image. X and Y are the XData and YData of the
     * %   input image.
     * %
     * %   Remarks
     * %   -------
     * %   Because RECT is specified in terms of spatial coordinates,
     * %   the WIDTH and HEIGHT of RECT do not always correspond exactly
     * %   with the size of the output image. For example, suppose RECT
     * %   is [20 20 40 30], using the default spatial coordinate
     * %   system. The upper left corner of the specified rectangle is
     * %   the center of the pixel (20,20) and the lower right corner is
     * %   the center of the pixel (50,60). The resulting output image
     * %   is 31-by-41, not 30-by-40, because the output image includes
     * %   all pixels in the input that are completely or partially
     * %   enclosed by the rectangle.
     * %
     * %   Class Support
     * %   -------------
     * %   A must be a real image of class logical, uint8, uint16, 
     * %   or double. The output image B is of the same class as A.
     * %   RECT is always of class double.
     * %
     * %   Example
     * %   -------
     * %        I = imread('ic.tif');
     * %        I2 = imcrop(I,[60 40 100 90]);
     * %        imshow(I), figure, imshow(I2)
     * %
     * %   See also ZOOM.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.21 $  $Date: 2002/03/15 15:27:50 $
     * 
     * [x,y,a,cm,rect] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &x,
      mlfImcrop_ParseInputs(
        &y,
        &a,
        &cm,
        &rect,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * [m,n,o] = size(a);
     */
    mlfSize(mlfVarargout(&m, &n, &o, NULL), mclVv(a, "a"), NULL);
    /*
     * xmin = min(x(:)); ymin = min(y(:));
     */
    mlfAssign(
      &xmin,
      mlfMin(
        NULL, mclArrayRef1(mclVv(x, "x"), mlfCreateColonIndex()), NULL, NULL));
    mlfAssign(
      &ymin,
      mlfMin(
        NULL, mclArrayRef1(mclVv(y, "y"), mlfCreateColonIndex()), NULL, NULL));
    /*
     * xmax = max(x(:)); ymax = max(y(:));
     */
    mlfAssign(
      &xmax,
      mlfMax(
        NULL, mclArrayRef1(mclVv(x, "x"), mlfCreateColonIndex()), NULL, NULL));
    mlfAssign(
      &ymax,
      mlfMax(
        NULL, mclArrayRef1(mclVv(y, "y"), mlfCreateColonIndex()), NULL, NULL));
    /*
     * % Transform rectangle into row and column indices.
     * if (m == 1)
     */
    if (mclEqBool(mclVv(m, "m"), _mxarray0_)) {
        /*
         * pixelsPerVerticalUnit = 1;
         */
        mlfAssign(&pixelsPerVerticalUnit, _mxarray0_);
    /*
     * else
     */
    } else {
        /*
         * pixelsPerVerticalUnit = (m - 1) / (ymax - ymin);
         */
        mlfAssign(
          &pixelsPerVerticalUnit,
          mclMrdivide(
            mclMinus(mclVv(m, "m"), _mxarray0_),
            mclMinus(mclVv(ymax, "ymax"), mclVv(ymin, "ymin"))));
    /*
     * end
     */
    }
    /*
     * if (n == 1)
     */
    if (mclEqBool(mclVv(n, "n"), _mxarray0_)) {
        /*
         * pixelsPerHorizUnit = 1;
         */
        mlfAssign(&pixelsPerHorizUnit, _mxarray0_);
    /*
     * else
     */
    } else {
        /*
         * pixelsPerHorizUnit = (n - 1) / (xmax - xmin);
         */
        mlfAssign(
          &pixelsPerHorizUnit,
          mclMrdivide(
            mclMinus(mclVv(n, "n"), _mxarray0_),
            mclMinus(mclVv(xmax, "xmax"), mclVv(xmin, "xmin"))));
    /*
     * end
     */
    }
    /*
     * pixelHeight = rect(4) * pixelsPerVerticalUnit;
     */
    mlfAssign(
      &pixelHeight,
      mclMtimes(
        mclIntArrayRef1(mclVv(rect, "rect"), 4),
        mclVv(pixelsPerVerticalUnit, "pixelsPerVerticalUnit")));
    /*
     * pixelWidth = rect(3) * pixelsPerHorizUnit;
     */
    mlfAssign(
      &pixelWidth,
      mclMtimes(
        mclIntArrayRef1(mclVv(rect, "rect"), 3),
        mclVv(pixelsPerHorizUnit, "pixelsPerHorizUnit")));
    /*
     * r1 = (rect(2) - ymin) * pixelsPerVerticalUnit + 1;
     */
    mlfAssign(
      &r1,
      mclPlus(
        mclMtimes(
          mclMinus(
            mclIntArrayRef1(mclVv(rect, "rect"), 2), mclVv(ymin, "ymin")),
          mclVv(pixelsPerVerticalUnit, "pixelsPerVerticalUnit")),
        _mxarray0_));
    /*
     * c1 = (rect(1) - xmin) * pixelsPerHorizUnit + 1;
     */
    mlfAssign(
      &c1,
      mclPlus(
        mclMtimes(
          mclMinus(
            mclIntArrayRef1(mclVv(rect, "rect"), 1), mclVv(xmin, "xmin")),
          mclVv(pixelsPerHorizUnit, "pixelsPerHorizUnit")),
        _mxarray0_));
    /*
     * r2 = round(r1 + pixelHeight);
     */
    mlfAssign(
      &r2,
      mlfRound(mclPlus(mclVv(r1, "r1"), mclVv(pixelHeight, "pixelHeight"))));
    /*
     * c2 = round(c1 + pixelWidth);
     */
    mlfAssign(
      &c2, mlfRound(mclPlus(mclVv(c1, "c1"), mclVv(pixelWidth, "pixelWidth"))));
    /*
     * r1 = round(r1);
     */
    mlfAssign(&r1, mlfRound(mclVv(r1, "r1")));
    /*
     * c1 = round(c1);
     */
    mlfAssign(&c1, mlfRound(mclVv(c1, "c1")));
    /*
     * % Check for selected rectangle completely outside the image
     * if ((r1 > m) | (r2 < 1) | (c1 > n) | (c2 < 1))
     */
    {
        mxArray * a_ = mclInitialize(mclGt(mclVv(r1, "r1"), mclVv(m, "m")));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclLt(mclVv(r2, "r2"), _mxarray0_)));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclGt(mclVv(c1, "c1"), mclVv(n, "n"))));
        }
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mclLt(mclVv(c2, "c2"), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * b = [];
             */
            mlfAssign(&b, _mxarray1_);
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * r1 = max(r1, 1);
             */
            mlfAssign(&r1, mlfMax(NULL, mclVv(r1, "r1"), _mxarray0_, NULL));
            /*
             * r2 = min(r2, m);
             */
            mlfAssign(&r2, mlfMin(NULL, mclVv(r2, "r2"), mclVv(m, "m"), NULL));
            /*
             * c1 = max(c1, 1);
             */
            mlfAssign(&c1, mlfMax(NULL, mclVv(c1, "c1"), _mxarray0_, NULL));
            /*
             * c2 = min(c2, n);
             */
            mlfAssign(&c2, mlfMin(NULL, mclVv(c2, "c2"), mclVv(n, "n"), NULL));
            /*
             * b = a(r1:r2, c1:c2, :);
             */
            mlfAssign(
              &b,
              mlfIndexRef(
                mclVv(a, "a"),
                "(?,?,?)",
                mlfColon(mclVv(r1, "r1"), mclVv(r2, "r2"), NULL),
                mlfColon(mclVv(c1, "c1"), mclVv(c2, "c2"), NULL),
                mlfCreateColonIndex()));
        }
    /*
     * end
     */
    }
    /*
     * 
     * switch nargout 
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargout_));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 0
             * if (isempty(b))
             */
            if (mlfTobool(mlfIsempty(mclVv(b, "b")))) {
                /*
                 * msg = 'The crop rectangle does not intersect the image';
                 */
                mlfAssign(&msg, _mxarray3_);
                /*
                 * wid = sprintf('Images:%s:cropRectDoesNotIntersectImage',mfilename);
                 */
                mlfAssign(
                  &wid,
                  mlfSprintf(NULL, _mxarray5_, mxCreateString("imcrop"), NULL));
                /*
                 * warning(wid,msg);
                 */
                mclAssignAns(
                  &ans,
                  mlfNWarning(
                    0, NULL, mclVv(wid, "wid"), mclVv(msg, "msg"), NULL));
            /*
             * end
             */
            }
            /*
             * figure;
             */
            mclAssignAns(&ans, mlfNFigure(0, NULL));
            /*
             * if (~isempty(cm))
             */
            if (mclNotBool(mlfIsempty(mclVv(cm, "cm")))) {
                /*
                 * imshow(b,cm)
                 */
                mclPrintAns(
                  &ans, mlfNImshow(0, mclVv(b, "b"), mclVv(cm, "cm"), NULL));
            /*
             * else
             */
            } else {
                /*
                 * imshow(b);
                 */
                mclAssignAns(&ans, mlfNImshow(0, mclVv(b, "b"), NULL));
            /*
             * end
             */
            }
        /*
         * 
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * varargout{1} = b;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray0_, mclVv(b, "b"));
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray7_)) {
            /*
             * varargout{1} = b;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray0_, mclVv(b, "b"));
            /*
             * varargout{2} = rect;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray7_, mclVv(rect, "rect"));
        /*
         * 
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * varargout{1} = x;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray0_, mclVv(x, "x"));
            /*
             * varargout{2} = y;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray7_, mclVv(y, "y"));
            /*
             * varargout{3} = b;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray9_, mclVv(b, "b"));
            /*
             * varargout{4} = rect;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray8_, mclVv(rect, "rect"));
        /*
         * 
         * otherwise
         */
        } else {
            /*
             * msg = 'Too many output arguments';
             */
            mlfAssign(&msg, _mxarray10_);
            /*
             * eid = sprintf('Images:%s:tooManyOutputArguments',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray12_, mxCreateString("imcrop"), NULL));
            /*
             * error(eid,msg);
             */
            mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(x);
    mxDestroyArray(y);
    mxDestroyArray(a);
    mxDestroyArray(cm);
    mxDestroyArray(rect);
    mxDestroyArray(m);
    mxDestroyArray(n);
    mxDestroyArray(o);
    mxDestroyArray(xmin);
    mxDestroyArray(ymin);
    mxDestroyArray(xmax);
    mxDestroyArray(ymax);
    mxDestroyArray(pixelsPerVerticalUnit);
    mxDestroyArray(pixelsPerHorizUnit);
    mxDestroyArray(pixelHeight);
    mxDestroyArray(pixelWidth);
    mxDestroyArray(r1);
    mxDestroyArray(c1);
    mxDestroyArray(r2);
    mxDestroyArray(c2);
    mxDestroyArray(b);
    mxDestroyArray(msg);
    mxDestroyArray(wid);
    mxDestroyArray(ans);
    mxDestroyArray(eid);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * %%%
     * %%% Subfunction ParseInputs
     * %%%
     */
}

/*
 * The function "Mimcrop_ParseInputs" is the implementation version of the
 * "imcrop/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 160-256). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [x,y,a,cm,rect] = ParseInputs(varargin)
 */
static mxArray * Mimcrop_ParseInputs(mxArray * * y,
                                     mxArray * * a,
                                     mxArray * * cm,
                                     mxArray * * rect,
                                     int nargout_,
                                     mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imcrop);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * x = NULL;
    mxArray * eid = NULL;
    mxArray * msg = NULL;
    mxArray * ans = NULL;
    mxArray * flag = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * x = [];
     */
    mlfAssign(&x, _mxarray1_);
    /*
     * y = [];
     */
    mlfAssign(y, _mxarray1_);
    /*
     * a = [];
     */
    mlfAssign(a, _mxarray1_);
    /*
     * flag = 0;
     */
    mlfAssign(&flag, _mxarray2_);
    /*
     * cm = [];
     */
    mlfAssign(cm, _mxarray1_);
    /*
     * rect = [];
     */
    mlfAssign(rect, _mxarray1_);
    /*
     * 
     * checknargin(0,5,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray2_, _mxarray14_, mlfScalar(nargin_), mxCreateString("imcrop"));
    /*
     * 
     * switch nargin
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 0
             * % IMCROP
             * % Get information from current figure
             * [x,y,a,flag] = getimage;
             */
            mlfNGetimage(0, mlfVarargout(&x, y, a, &flag, NULL), NULL);
            /*
             * if (flag == 0)
             */
            if (mclEqBool(mclVv(flag, "flag"), _mxarray2_)) {
                /*
                 * msg = 'No image found in the current axes';
                 */
                mlfAssign(&msg, _mxarray15_);
                /*
                 * eid = sprintf('Images:%s:noImageFoundInCurrentAxes',mfilename);
                 */
                mlfAssign(
                  &eid,
                  mlfSprintf(
                    NULL, _mxarray17_, mxCreateString("imcrop"), NULL));
                /*
                 * error(eid,msg);
                 */
                mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
            /*
             * end
             */
            }
            /*
             * if (flag == 1)
             */
            if (mclEqBool(mclVv(flag, "flag"), _mxarray0_)) {
                /*
                 * % input image is indexed; get its colormap;
                 * cm = colormap;
                 */
                mlfAssign(cm, mlfNColormap(1, NULL, NULL));
            /*
             * end
             */
            }
            /*
             * rect = getrect(gcf);
             */
            mlfAssign(rect, mlfGetrect(mlfGcf(), NULL));
        /*
         * 
         * case 1
         */
        } else if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * % IMCROP(I) or IMCROP(RGB)
             * a = varargin{1};
             */
            mlfAssign(
              a, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * x = [1 size(a,2)];
             */
            mlfAssign(
              &x,
              mlfHorzcat(
                _mxarray0_,
                mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray7_),
                NULL));
            /*
             * y = [1 size(a,1)];
             */
            mlfAssign(
              y,
              mlfHorzcat(
                _mxarray0_,
                mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray0_),
                NULL));
            /*
             * CheckCData(a);
             */
            mlfImcrop_CheckCData(mclVv(*a, "a"));
            /*
             * imshow(a);
             */
            mclAssignAns(&ans, mlfNImshow(0, mclVv(*a, "a"), NULL));
            /*
             * rect = getrect(gcf);
             */
            mlfAssign(rect, mlfGetrect(mlfGcf(), NULL));
        /*
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray7_)) {
            /*
             * % IMCROP(X,MAP) or IMCROP(I,RECT) or IMCROP(RGB,RECT)
             * a = varargin{1};
             */
            mlfAssign(
              a, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * x = [1 size(a,2)];
             */
            mlfAssign(
              &x,
              mlfHorzcat(
                _mxarray0_,
                mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray7_),
                NULL));
            /*
             * y = [1 size(a,1)];
             */
            mlfAssign(
              y,
              mlfHorzcat(
                _mxarray0_,
                mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray0_),
                NULL));
            /*
             * if (size(varargin{2},2) == 3)
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxSize,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_),
                    _mxarray7_,
                    NULL),
                  _mxarray9_)) {
                /*
                 * % IMCROP(X,MAP)
                 * cm = varargin{2};
                 */
                mlfAssign(
                  cm,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * CheckCData(a);
                 */
                mlfImcrop_CheckCData(mclVv(*a, "a"));
                /*
                 * imshow(a,cm);
                 */
                mclAssignAns(
                  &ans, mlfNImshow(0, mclVv(*a, "a"), mclVv(*cm, "cm"), NULL));
                /*
                 * rect = getrect(gcf);
                 */
                mlfAssign(rect, mlfGetrect(mlfGcf(), NULL));
            /*
             * else
             */
            } else {
                /*
                 * rect = varargin{2};
                 */
                mlfAssign(
                  rect,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * end
             */
            }
        /*
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray9_)) {
            /*
             * % IMCROP(x,y,RGB) or IMCROP(X,MAP,RECT)
             * if (size(varargin{3},3) == 3)
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxSize,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray9_),
                    _mxarray9_,
                    NULL),
                  _mxarray9_)) {
                /*
                 * % IMCROP(x,y,RGB)
                 * x = varargin{1};
                 */
                mlfAssign(
                  &x,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
                /*
                 * y = varargin{2};
                 */
                mlfAssign(
                  y,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * a = varargin{3};
                 */
                mlfAssign(
                  a,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray9_));
                /*
                 * CheckCData(a);
                 */
                mlfImcrop_CheckCData(mclVv(*a, "a"));
                /*
                 * imshow(x,y,a);
                 */
                mclAssignAns(
                  &ans,
                  mlfNImshow(
                    0, mclVv(x, "x"), mclVv(*y, "y"), mclVv(*a, "a"), NULL));
                /*
                 * rect = getrect(gcf);
                 */
                mlfAssign(rect, mlfGetrect(mlfGcf(), NULL));
            /*
             * else
             */
            } else {
                /*
                 * % IMCROP(X,MAP,RECT)
                 * a = varargin{1};
                 */
                mlfAssign(
                  a,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
                /*
                 * cm = varargin{2};
                 */
                mlfAssign(
                  cm,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
                /*
                 * rect = varargin{3};
                 */
                mlfAssign(
                  rect,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray9_));
                /*
                 * x = [1 size(a,2)];
                 */
                mlfAssign(
                  &x,
                  mlfHorzcat(
                    _mxarray0_,
                    mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray7_),
                    NULL));
                /*
                 * y = [1 size(a,1)];
                 */
                mlfAssign(
                  y,
                  mlfHorzcat(
                    _mxarray0_,
                    mlfSize(mclValueVarargout(), mclVv(*a, "a"), _mxarray0_),
                    NULL));
            /*
             * end
             */
            }
        /*
         * 
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * % IMCROP(x,y,I,RECT) or IMCROP(x,y,RGB,RECT)
             * x = varargin{1};
             */
            mlfAssign(
              &x, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * y = varargin{2};
             */
            mlfAssign(
              y, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * a = varargin{3};
             */
            mlfAssign(
              a, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray9_));
            /*
             * rect = varargin{4};
             */
            mlfAssign(
              rect,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
        /*
         * 
         * case 5
         */
        } else if (mclSwitchCompare(v_, _mxarray14_)) {
            /*
             * % IMCROP(x,y,X,MAP,RECT)
             * x = varargin{1};
             */
            mlfAssign(
              &x, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * y = varargin{2};
             */
            mlfAssign(
              y, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * a = varargin{3};
             */
            mlfAssign(
              a, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray9_));
            /*
             * cm = varargin{4};
             */
            mlfAssign(
              cm, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray8_));
            /*
             * rect = varargin{5};
             */
            mlfAssign(
              rect,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray14_));
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * % In some cases CheckCData gets called twice.  This could be avoided with
     * % more complex logic, but the check is quick and the code is simpler this
     * % way.  -sle
     * CheckCData(a);
     */
    mlfImcrop_CheckCData(mclVv(*a, "a"));
    mclValidateOutput(x, 1, nargout_, "x", "imcrop/ParseInputs");
    mclValidateOutput(*y, 2, nargout_, "y", "imcrop/ParseInputs");
    mclValidateOutput(*a, 3, nargout_, "a", "imcrop/ParseInputs");
    mclValidateOutput(*cm, 4, nargout_, "cm", "imcrop/ParseInputs");
    mclValidateOutput(*rect, 5, nargout_, "rect", "imcrop/ParseInputs");
    mxDestroyArray(flag);
    mxDestroyArray(ans);
    mxDestroyArray(msg);
    mxDestroyArray(eid);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return x;
    /*
     * 
     * 
     * %%%
     * %%% Subfunction CheckCData
     * %%%
     */
}

/*
 * The function "Mimcrop_CheckCData" is the implementation version of the
 * "imcrop/CheckCData" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imcrop.m" (lines 256-269). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function CheckCData(cdata)
 */
static void Mimcrop_CheckCData(mxArray * cdata) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imcrop);
    mxArray * ans = NULL;
    mxArray * eid = NULL;
    mxArray * msg = NULL;
    mxArray * is_rgb = NULL;
    mxArray * is_2d = NULL;
    mxArray * right_type = NULL;
    mclCopyArray(&cdata);
    /*
     * 
     * right_type = (isnumeric(cdata) | islogical(cdata)) & isreal(cdata) & ...
     */
    mlfAssign(
      &right_type,
      mclAnd(
        mclAnd(
          mclOr(
            mlfIsnumeric(mclVa(cdata, "cdata")),
            mlfIslogical(mclVa(cdata, "cdata"))),
          mlfIsreal(mclVa(cdata, "cdata"))),
        mclNot(mlfIssparse(mclVa(cdata, "cdata")))));
    /*
     * ~issparse(cdata);
     * 
     * is_2d = ndims(cdata) == 2;
     */
    mlfAssign(&is_2d, mclEq(mlfNdims(mclVa(cdata, "cdata")), _mxarray7_));
    /*
     * is_rgb = (ndims(cdata) == 3) & (size(cdata,3) == 3);
     */
    mlfAssign(
      &is_rgb,
      mclAnd(
        mclEq(mlfNdims(mclVa(cdata, "cdata")), _mxarray9_),
        mclEq(
          mlfSize(mclValueVarargout(), mclVa(cdata, "cdata"), _mxarray9_),
          _mxarray9_)));
    /*
     * 
     * if ~right_type | ~(is_2d | is_rgb)
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mclVv(right_type, "right_type")));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclNot(
                     mclOr(
                       mclVv(is_2d, "is_2d"), mclVv(is_rgb, "is_rgb")))))) {
            mxDestroyArray(a_);
            /*
             * msg = 'Invalid input image.';
             */
            mlfAssign(&msg, _mxarray19_);
            /*
             * eid = sprintf('Images:%s:invalidInputImage',mfilename);
             */
            mlfAssign(
              &eid,
              mlfSprintf(NULL, _mxarray21_, mxCreateString("imcrop"), NULL));
            /*
             * error(eid, msg);
             */
            mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mxDestroyArray(right_type);
    mxDestroyArray(is_2d);
    mxDestroyArray(is_rgb);
    mxDestroyArray(msg);
    mxDestroyArray(eid);
    mxDestroyArray(ans);
    mxDestroyArray(cdata);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
