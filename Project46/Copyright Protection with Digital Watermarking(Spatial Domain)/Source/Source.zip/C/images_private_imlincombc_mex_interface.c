/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_imlincombc_mex_interface.h"

void InitializeModule_images_private_imlincombc_mex_interface(void) {
}

void TerminateModule_images_private_imlincombc_mex_interface(void) {
}

static mxArray * Mimages_private_imlincombc(int nargout_, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_images_private_imlincombc
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNImages_private_imlincombc" contains the nargout interface
 * for the "images/private/imlincombc" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\imlincombc.dll" (lines 0-0).
 * This interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNImages_private_imlincombc(int nargout,
                                        mlfVarargoutList * varargout,
                                        ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mimages_private_imlincombc(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImages_private_imlincombc" contains the normal interface
 * for the "images/private/imlincombc" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\imlincombc.dll" (lines 0-0).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImages_private_imlincombc(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mimages_private_imlincombc(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImages_private_imlincombc" contains the void interface for
 * the "images/private/imlincombc" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\imlincombc.dll" (lines 0-0). The
 * void interface is only produced if the M-function uses the special variable
 * "nargout", and has at least one output. The void interface function
 * specifies zero output arguments to the implementation version of the
 * function, and in the event that the implementation version still returns an
 * output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImages_private_imlincombc(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimages_private_imlincombc(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImages_private_imlincombc" contains the feval interface for
 * the "images/private/imlincombc" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\imlincombc.dll" (lines 0-0). The
 * feval function calls the implementation version of images/private/imlincombc
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_imlincombc(int nlhs,
                                  mxArray * plhs[],
                                  int nrhs,
                                  mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimages_private_imlincombc(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mimages_private_imlincombc" is the implementation version of
 * the "images/private/imlincombc" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\imlincombc.dll" (lines 1-1). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
static mxArray * Mimages_private_imlincombc(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_imlincombc);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return mclCExecMexFunction("images/private/imlincombc", nargout_, varargin);
}
