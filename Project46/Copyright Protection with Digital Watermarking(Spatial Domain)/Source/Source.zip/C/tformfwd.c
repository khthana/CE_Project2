/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "tformfwd.h"
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[32] = { 'T', ' ', 'm', 'u', 's', 't', ' ', 'b',
                               'e', ' ', 'a', ' ', 's', 'i', 'n', 'g',
                               'l', 'e', ' ', 'T', 'F', 'O', 'R', 'M',
                               ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray1_;

static mxChar _array4_[46] = { 'U', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e', ' ',
                               'a', ' ', 'r', 'e', 'a', 'l', '-', 'v', 'a', 'l',
                               'u', 'e', 'd', ' ', 'a', 'r', 'r', 'a', 'y', ' ',
                               'o', 'f', ' ', 'c', 'l', 'a', 's', 's', ' ', 'd',
                               'o', 'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray3_;

static mxChar _array6_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray5_;

static mxChar _array8_[33] = { 'A', 'l', 'l', ' ', 'e', 'l', 'e', 'm', 'e',
                               'n', 't', 's', ' ', 'o', 'f', ' ', 'U', ' ',
                               'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'f',
                               'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[42] = { 'T', 0x0027, 's', ' ', 0x0027, 'f', 'o', 'r',
                                'w', 'a', 'r', 'd', '_', 'f', 'c', 'n',
                                0x0027, ' ', 'f', 'i', 'e', 'l', 'd', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'n',
                                'o', 'n', '-', 'e', 'm', 'p', 't', 'y', '.' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[40] = { 'S', 'I', 'Z', 'E', '(', 'U', ')', ' ',
                                'i', 's', ' ', 'i', 'n', 'c', 'o', 'n',
                                's', 'i', 's', 't', 'e', 'n', 't', ' ',
                                'w', 'i', 't', 'h', ' ', 'T', '.', 'n',
                                'd', 'i', 'm', 's', '_', 'i', 'n', '.' };
static mxArray * _mxarray12_;

void InitializeModule_tformfwd(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeString(32, _array2_);
    _mxarray3_ = mclInitializeString(46, _array4_);
    _mxarray5_ = mclInitializeString(6, _array6_);
    _mxarray7_ = mclInitializeString(33, _array8_);
    _mxarray9_ = mclInitializeString(42, _array10_);
    _mxarray11_ = mclInitializeDouble(1.0);
    _mxarray12_ = mclInitializeString(40, _array13_);
}

void TerminateModule_tformfwd(void) {
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mtformfwd(int nargout_, mxArray * U, mxArray * t);

_mexLocalFunctionTable _local_function_table_tformfwd
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfTformfwd" contains the normal interface for the "tformfwd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformfwd.m" (lines
 * 1-97). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfTformfwd(mxArray * U, mxArray * t) {
    int nargout = 1;
    mxArray * X = NULL;
    mlfEnterNewContext(0, 2, U, t);
    X = Mtformfwd(nargout, U, t);
    mlfRestorePreviousContext(0, 2, U, t);
    return mlfReturnValue(X);
}

/*
 * The function "mlxTformfwd" contains the feval interface for the "tformfwd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformfwd.m" (lines
 * 1-97). The feval function calls the implementation version of tformfwd
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxTformfwd(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformfwd Line: 1 Column:"
            " 1 The function \"tformfwd\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformfwd Line: 1 Column:"
            " 1 The function \"tformfwd\" was called with m"
            "ore than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformfwd(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mtformfwd" is the implementation version of the "tformfwd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformfwd.m" (lines
 * 1-97). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function X = tformfwd( U, t )
 */
static mxArray * Mtformfwd(int nargout_, mxArray * U, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformfwd);
    int nargin_ = mclNargin(2, U, t, NULL);
    mxArray * X = NULL;
    mxArray * D = NULL;
    mxArray * N = NULL;
    mxArray * S = NULL;
    mxArray * M = NULL;
    mxArray * L = NULL;
    mxArray * P = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&U);
    mclCopyArray(&t);
    /*
     * %TFORMFWD Apply forward spatial transformation.
     * %   If U is a matrix, X = TFORMFWD(U,T) applies the forward transformation
     * %   defined in T to each row of U.  T is a TFORM struct created with
     * %   MAKETFORM, FLIPTFORM, or CP2TFORM.  U is an M-by-T.ndims_in matrix; each
     * %   row of U represents a point in T's input space.  X is an
     * %   M-by-T.ndims_out matrix; each row of X represents a point in T's output
     * %   space, and is the forward transformation of the corresponding row of U.
     * %
     * %   If U is an (N+1)-dimensional array (including an implicit trailing
     * %   singleton dimension if T.ndims_in is 1), then TFORMFWD applies the
     * %   transformation to each point U(P1,P2,...,PN,:).  SIZE(U,N+1) must equal
     * %   T.ndims_in.  X is an (N+1)-dimensional array containing the results of
     * %   each transformation in X(P1,P2,...PN,:).  SIZE(X,I) equals SIZE(U,I) for
     * %   I = 1,...,N and SIZE(X,N+1) equals T.ndims_out.
     * % 
     * %   Example
     * %   -------
     * %   Create an affine transformation that maps the triangle with vertices
     * %   (0,0), (6,3), (-2,5) to the triangle with vertices (-1,-1), (0,-10),
     * %   (-2,5):
     * %
     * %       u = [0 0; 6 3; -2 5];
     * %       x = [-1 -1; 0 -10; 4 4];
     * %       tform = maketform('affine',u,x);
     * %   
     * %   Validate the mapping by applying TFORMFWD to u:
     * %
     * %       tformfwd(u,tform)  % Result should equal x
     * %
     * %   See also TFORMINV, MAKETFORM, FLIPTFORM, CP2TFORM.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.8 $ $Date: 2002/03/15 15:29:21 $
     * 
     * message = nargchk(2,2,nargin);
     */
    mlfAssign(&message, mlfNargchk(_mxarray0_, _mxarray0_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~istform(t) | (length(t) ~= 1)
     */
    {
        mxArray * a_
          = mclInitialize(mclNot(mlfImages_private_istform(mclVa(t, "t"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclBoolToArray(mclLengthInt(mclVa(t, "t")) != 1)))) {
            mxDestroyArray(a_);
            /*
             * error('T must be a single TFORM struct.');
             */
            mlfError(_mxarray1_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~isa(U,'double') | ~isreal(U)
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIsa(mclVa(U, "U"), _mxarray5_)));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mclNot(mlfIsreal(mclVa(U, "U")))))) {
            mxDestroyArray(a_);
            /*
             * error('U must be a real-valued array of class double.');
             */
            mlfError(_mxarray3_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~all(isfinite(U))
     */
    if (mclNotBool(mlfAll(mlfIsfinite(mclVa(U, "U")), NULL))) {
        /*
         * error('All elements of U must be finite.');
         */
        mlfError(_mxarray7_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if isempty(t.forward_fcn)
     */
    if (mlfTobool(
          mclFeval(
            mclValueVarargout(),
            mlxIsempty,
            mlfIndexRef(mclVa(t, "t"), ".forward_fcn"),
            NULL))) {
        /*
         * error('T''s ''forward_fcn'' field must be non-empty.')
         */
        mlfError(_mxarray9_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * P = t.ndims_in;
     */
    mlfAssign(&P, mlfIndexRef(mclVa(t, "t"), ".ndims_in"));
    /*
     * L = t.ndims_out;
     */
    mlfAssign(&L, mlfIndexRef(mclVa(t, "t"), ".ndims_out"));
    /*
     * M = ndims(U);
     */
    mlfAssign(&M, mlfNdims(mclVa(U, "U")));
    /*
     * S = size(U);
     */
    mlfAssign(&S, mlfSize(mclValueVarargout(), mclVa(U, "U"), NULL));
    /*
     * 
     * if S(M) > 1
     */
    if (mclGtBool(mclArrayRef1(mclVv(S, "S"), mclVv(M, "M")), _mxarray11_)) {
        /*
         * if P == 1;
         */
        if (mclEqBool(mclVv(P, "P"), _mxarray11_)) {
            /*
             * N = M;         % PROD(S) points in 1-D
             */
            mlfAssign(&N, mclVv(M, "M"));
        /*
         * elseif P == S(M)
         */
        } else if (mclEqBool(
                     mclVv(P, "P"),
                     mclArrayRef1(mclVv(S, "S"), mclVv(M, "M")))) {
            /*
             * N = M - 1;     % PROD(S(1:M-1)) points in P-D
             */
            mlfAssign(&N, mclMinus(mclVv(M, "M"), _mxarray11_));
        /*
         * else
         */
        } else {
            /*
             * error('SIZE(U) is inconsistent with T.ndims_in.');
             */
            mlfError(_mxarray12_, NULL);
        /*
         * end
         */
        }
        /*
         * D = S(1:N);
         */
        mlfAssign(
          &D,
          mclArrayRef1(
            mclVv(S, "S"), mlfColon(_mxarray11_, mclVv(N, "N"), NULL)));
    /*
     * else % S == [S(1) 1]
     */
    } else {
        /*
         * if P == 1
         */
        if (mclEqBool(mclVv(P, "P"), _mxarray11_)) {
            /*
             * D = S(1);      % S(1) points in 1-D
             */
            mlfAssign(&D, mclIntArrayRef1(mclVv(S, "S"), 1));
        /*
         * elseif P == S(1)
         */
        } else if (mclEqBool(
                     mclVv(P, "P"), mclIntArrayRef1(mclVv(S, "S"), 1))) {
            /*
             * D = 1;         % 1 point in P-D
             */
            mlfAssign(&D, _mxarray11_);
        /*
         * else
         */
        } else {
            /*
             * error('SIZE(U) is inconsistent with T.ndims_in.');
             */
            mlfError(_mxarray12_, NULL);
        /*
         * end        
         */
        }
        /*
         * N = 1;
         */
        mlfAssign(&N, _mxarray11_);
    /*
     * end
     */
    }
    /*
     * 
     * % Now D contains the sizes of the first N dimensions of U.
     * % Reshape U to collapse the first N dimensions into a single column.
     * % Each row of U is now a coordinate vector in t's input space.
     * 
     * U = reshape( U, [prod(D) P] );
     */
    mlfAssign(
      &U,
      mlfReshape(
        mclVa(U, "U"),
        mlfHorzcat(mlfProd(mclVv(D, "D"), NULL), mclVv(P, "P"), NULL), NULL));
    /*
     * 
     * % Apply the forward transformation, mapping U from the input
     * % space to the output space.
     * 
     * X = feval(t.forward_fcn, U, t);
     */
    mlfAssign(
      &X,
      mlfFeval(
        mclValueVarargout(),
        mlfIndexRef(mclVa(t, "t"), ".forward_fcn"),
        mclVa(U, "U"),
        mclVa(t, "t"),
        NULL));
    /*
     * 
     * % X is an array in which each row is a coordinate vector t's output
     * % space. Reshape X to be D(1) x D(2) x ... x D(N) x L.
     * 
     * X = reshape( X, [D L] );
     */
    mlfAssign(
      &X,
      mlfReshape(
        mclVv(X, "X"), mlfHorzcat(mclVv(D, "D"), mclVv(L, "L"), NULL), NULL));
    mclValidateOutput(X, 1, nargout_, "X", "tformfwd");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(P);
    mxDestroyArray(L);
    mxDestroyArray(M);
    mxDestroyArray(S);
    mxDestroyArray(N);
    mxDestroyArray(D);
    mxDestroyArray(t);
    mxDestroyArray(U);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return X;
}
