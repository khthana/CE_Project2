/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imsubtract.h"
#include "imlincomb.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray1_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

void InitializeModule_imsubtract(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeString(6, _array2_);
    _mxarray3_ = mclInitializeDouble(1.0);
    _mxarray4_ = mclInitializeDouble(-1.0);
}

void TerminateModule_imsubtract(void) {
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimsubtract(int nargout_, mxArray * X, mxArray * Y);

_mexLocalFunctionTable _local_function_table_imsubtract
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImsubtract" contains the normal interface for the
 * "imsubtract" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imsubtract.m" (lines 1-45). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImsubtract(mxArray * X, mxArray * Y) {
    int nargout = 1;
    mxArray * Z = NULL;
    mlfEnterNewContext(0, 2, X, Y);
    Z = Mimsubtract(nargout, X, Y);
    mlfRestorePreviousContext(0, 2, X, Y);
    return mlfReturnValue(Z);
}

/*
 * The function "mlxImsubtract" contains the feval interface for the
 * "imsubtract" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imsubtract.m" (lines 1-45). The feval
 * function calls the implementation version of imsubtract through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxImsubtract(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imsubtract Line: 1 Column:"
            " 1 The function \"imsubtract\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imsubtract Line: 1 Column"
            ": 1 The function \"imsubtract\" was called with"
            " more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mimsubtract(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimsubtract" is the implementation version of the "imsubtract"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imsubtract.m"
 * (lines 1-45). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function Z = imsubtract(X,Y)
 */
static mxArray * Mimsubtract(int nargout_, mxArray * X, mxArray * Y) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imsubtract);
    int nargin_ = mclNargin(2, X, Y, NULL);
    mxArray * Z = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&X);
    mclCopyArray(&Y);
    /*
     * %IMSUBTRACT Subtract two images, or subtract constant from image.
     * %   Z = IMSUBTRACT(X,Y) subtracts each element in array Y from the
     * %   corresponding element in array X and returns the difference in the
     * %   corresponding element of the output array Z.  X and Y are real,
     * %   nonsparse, numeric arrays of the same size and class, or Y is a
     * %   double scalar.  The output array, Z, has the same size and class as
     * %   X. 
     * %
     * %   If X is an integer array, then elements of the output that exceed the
     * %   range of the integer type are truncated, and fractional values are
     * %   rounded.
     * %
     * %   If X and Y are double arrays, then you can use the expression X - Y
     * %   instead of this function.
     * %
     * %   Example
     * %   -------
     * %   Estimate and subtract the background of the rice image:
     * %       I = imread('rice.tif');
     * %       blocks = blkproc(I,[32 32],'min(x(:))');
     * %       background = imresize(blocks,[256 256],'bilinear');
     * %       Ip = imsubtract(I,background);
     * %       imshow(Ip,[])
     * %
     * %   Subtract a constant value from the rice image:
     * %       I = imread('rice.tif');
     * %       Iq = imsubtract(I,50);
     * %       subplot(1,2,1), imshow(I)
     * %       subplot(1,2,2), imshow(Iq)
     * %
     * %   See also IMADD, IMCOMPLEMENT, IMDIVIDE, IMLINCOMB, IMMULTIPLY.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc. 
     * %   $Revision: 1.9 $  $Date: 2002/03/15 15:28:20 $
     * 
     * error(nargchk(2,2,nargin))
     */
    mlfError(mlfNargchk(_mxarray0_, _mxarray0_, mlfScalar(nargin_)), NULL);
    /*
     * 
     * if (prod(size(Y)) == 1) & strcmp(class(Y),'double')
     */
    {
        mxArray * a_
          = mclInitialize(
              mclEq(
                mlfProd(
                  mlfSize(mclValueVarargout(), mclVa(Y, "Y"), NULL), NULL),
                _mxarray3_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfStrcmp(
                     mlfClassName(mclVa(Y, "Y"), NULL), _mxarray1_)))) {
            mxDestroyArray(a_);
            /*
             * Z = imlincomb(1.0, X, -Y);
             */
            mlfAssign(
              &Z,
              mlfImlincomb(
                _mxarray3_, mclVa(X, "X"), mclUminus(mclVa(Y, "Y")), NULL));
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * Z = imlincomb(1.0, X, -1.0, Y);
             */
            mlfAssign(
              &Z,
              mlfImlincomb(
                _mxarray3_, mclVa(X, "X"), _mxarray4_, mclVa(Y, "Y"), NULL));
        }
    /*
     * end
     */
    }
    mclValidateOutput(Z, 1, nargout_, "Z", "imsubtract");
    mxDestroyArray(ans);
    mxDestroyArray(Y);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return Z;
    /*
     * 
     */
}
