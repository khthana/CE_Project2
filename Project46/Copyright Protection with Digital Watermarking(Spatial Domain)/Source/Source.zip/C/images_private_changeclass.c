/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_changeclass.h"
#include "im2double.h"
#include "im2uint16.h"
#include "im2uint8.h"
#include "libmatlbm.h"

static mxChar _array1_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray0_;

static mxChar _array3_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray2_;

static mxChar _array5_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[27] = { 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r', 't',
                               'e', 'd', ' ', 'I', 'P', 'T', ' ', 'd', 'a',
                               't', 'a', ' ', 'c', 'l', 'a', 's', 's', '.' };
static mxArray * _mxarray6_;

void InitializeModule_images_private_changeclass(void) {
    _mxarray0_ = mclInitializeString(5, _array1_);
    _mxarray2_ = mclInitializeString(6, _array3_);
    _mxarray4_ = mclInitializeString(6, _array5_);
    _mxarray6_ = mclInitializeString(27, _array7_);
}

void TerminateModule_images_private_changeclass(void) {
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_changeclass(int nargout_,
                                             mxArray * class0,
                                             mxArray * varargin);

_mexLocalFunctionTable _local_function_table_images_private_changeclass
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_changeclass" contains the normal interface
 * for the "images/private/changeclass" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\changeclass.m" (lines 1-21).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImages_private_changeclass(mxArray * class0, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * image = NULL;
    mlfVarargin(&varargin, class0, 0);
    mlfEnterNewContext(0, -2, class0, varargin);
    image = Mimages_private_changeclass(nargout, class0, varargin);
    mlfRestorePreviousContext(0, 1, class0);
    mxDestroyArray(varargin);
    return mlfReturnValue(image);
}

/*
 * The function "mlxImages_private_changeclass" contains the feval interface
 * for the "images/private/changeclass" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\changeclass.m" (lines 1-21). The
 * feval function calls the implementation version of
 * images/private/changeclass through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
void mlxImages_private_changeclass(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/changeclass Line: 1 C"
            "olumn: 1 The function \"images/private/changeclass\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0] = Mimages_private_changeclass(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[1]);
}

/*
 * The function "Mimages_private_changeclass" is the implementation version of
 * the "images/private/changeclass" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\changeclass.m" (lines 1-21). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function image = changeclass(class, varargin)
 */
static mxArray * Mimages_private_changeclass(int nargout_,
                                             mxArray * class0,
                                             mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_changeclass);
    mxArray * image = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&class0);
    mclCopyArray(&varargin);
    /*
     * %CHANGECLASS will change the storage class of an image.
     * %   I2 = CHANGECLASS(CLASS, I);
     * %   RGB2 = CHANGECLASS(CLASS, RGB);
     * %   BW2 = CHANGECLASS(CLASS, BW);
     * %   X2 = CHANGECLASS(CLASS, X, 'indexed');
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.8 $  $Date: 2002/03/15 15:57:03 $
     * 
     * switch class
     */
    {
        mxArray * v_ = mclInitialize(mclVa(class0, "class"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 'uint8'
             * image = im2uint8(varargin{:});
             */
            mlfAssign(
              &image,
              mlfIm2uint8(
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
        /*
         * case 'uint16'
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * image = im2uint16(varargin{:});
             */
            mlfAssign(
              &image,
              mclFeval(
                mclValueVarargout(),
                mlxIm2uint16,
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
        /*
         * case 'double'
         */
        } else if (mclSwitchCompare(v_, _mxarray4_)) {
            /*
             * image = im2double(varargin{:});
             */
            mlfAssign(
              &image,
              mclFeval(
                mclValueVarargout(),
                mlxIm2double,
                mlfIndexRef(
                  mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
                NULL));
        /*
         * otherwise
         */
        } else {
            /*
             * error('Unsupported IPT data class.');
             */
            mlfError(_mxarray6_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(
      image, 1, nargout_, "image", "images/private/changeclass");
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(class0);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return image;
}
