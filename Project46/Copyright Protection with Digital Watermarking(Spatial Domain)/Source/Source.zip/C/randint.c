/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "randint.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static mxChar _array6_[1] = { '/' };
static mxArray * _mxarray5_;
static mxArray * _mxarray7_;

static mxChar _array9_[1] = { 'n' };
static mxArray * _mxarray8_;

static mxChar _array11_[36] = { 'O', 'n', 'l', 'y', ' ', 'n', 'u', 'm', 'e',
                                'r', 'i', 'c', ' ', 'a', 'r', 'g', 'u', 'm',
                                'e', 'n', 't', 's', ' ', 'a', 'r', 'e', ' ',
                                'a', 'c', 'c', 'e', 'p', 't', 'e', 'd', '.' };
static mxArray * _mxarray10_;

static mxChar _array13_[3] = { 'n', '/', 'n' };
static mxArray * _mxarray12_;

static mxChar _array15_[5] = { 'n', '/', 'n', '/', 'n' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;

static mxChar _array18_[7] = { 'n', '/', 'n', '/', 'n', '/', 'n' };
static mxArray * _mxarray17_;

static mxChar _array20_[13] = { 'S', 'y', 'n', 't', 'a', 'x', ' ',
                                'e', 'r', 'r', 'o', 'r', '.' };
static mxArray * _mxarray19_;

static double _array22_[2] = { 0.0, 1.0 };
static mxArray * _mxarray21_;

static mxChar _array24_[33] = { 'M', 'a', 't', 'r', 'i', 'x', ' ', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', 's', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'f',
                                'i', 'n', 'i', 't', 'e', '.' };
static mxArray * _mxarray23_;

static mxChar _array26_[40] = { 'M', 'a', 't', 'r', 'i', 'x', ' ', 'd',
                                'i', 'm', 'e', 'n', 's', 'i', 'o', 'n',
                                's', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'r', 'e', 'a', 'l', ' ', 'i',
                                'n', 't', 'e', 'g', 'e', 'r', 's', '.' };
static mxArray * _mxarray25_;

static mxChar _array28_[35] = { 'M', 'a', 't', 'r', 'i', 'x', ' ', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', 's', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'p',
                                'o', 's', 'i', 't', 'i', 'v', 'e', '.' };
static mxArray * _mxarray27_;

static mxChar _array30_[34] = { 'M', 'a', 't', 'r', 'i', 'x', ' ', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', 's', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 's',
                                'c', 'a', 'l', 'a', 'r', 's', '.' };
static mxArray * _mxarray29_;

static mxChar _array32_[61] = { 'T', 'h', 'e', ' ', 'R', 'A', 'N', 'G', 'E',
                                ' ', 'p', 'a', 'r', 'a', 'm', 'e', 't', 'e',
                                'r', ' ', 's', 'h', 'o', 'u', 'l', 'd', ' ',
                                'c', 'o', 'n', 't', 'a', 'i', 'n', ' ', 'n',
                                'o', ' ', 'm', 'o', 'r', 'e', ' ', 't', 'h',
                                'a', 'n', ' ', 't', 'w', 'o', ' ', 'e', 'l',
                                'e', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray31_;

static mxChar _array34_[59] = { 'T', 'h', 'e', ' ', 'R', 'A', 'N', 'G', 'E',
                                ' ', 'p', 'a', 'r', 'a', 'm', 'e', 't', 'e',
                                'r', ' ', 'm', 'u', 's', 't', ' ', 'o', 'n',
                                'l', 'y', ' ', 'c', 'o', 'n', 't', 'a', 'i',
                                'n', ' ', 'r', 'e', 'a', 'l', ' ', 'f', 'i',
                                'n', 'i', 't', 'e', ' ', 'i', 'n', 't', 'e',
                                'g', 'e', 'r', 's', '.' };
static mxArray * _mxarray33_;

static double _array36_[2] = { 0.0, 0.0 };
static mxArray * _mxarray35_;

static mxChar _array38_[5] = { 's', 't', 'a', 't', 'e' };
static mxArray * _mxarray37_;

void InitializeModule_randint(void) {
    _mxarray0_ = mclInitializeDouble(0.0);
    _mxarray1_ = mclInitializeDouble(4.0);
    _mxarray2_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray3_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray4_ = mclInitializeDouble(1.0);
    _mxarray5_ = mclInitializeString(1, _array6_);
    _mxarray7_ = mclInitializeDouble(2.0);
    _mxarray8_ = mclInitializeString(1, _array9_);
    _mxarray10_ = mclInitializeString(36, _array11_);
    _mxarray12_ = mclInitializeString(3, _array13_);
    _mxarray14_ = mclInitializeString(5, _array15_);
    _mxarray16_ = mclInitializeDouble(3.0);
    _mxarray17_ = mclInitializeString(7, _array18_);
    _mxarray19_ = mclInitializeString(13, _array20_);
    _mxarray21_ = mclInitializeDoubleVector(1, 2, _array22_);
    _mxarray23_ = mclInitializeString(33, _array24_);
    _mxarray25_ = mclInitializeString(40, _array26_);
    _mxarray27_ = mclInitializeString(35, _array28_);
    _mxarray29_ = mclInitializeString(34, _array30_);
    _mxarray31_ = mclInitializeString(61, _array32_);
    _mxarray33_ = mclInitializeString(59, _array34_);
    _mxarray35_ = mclInitializeDoubleVector(1, 2, _array36_);
    _mxarray37_ = mclInitializeString(5, _array38_);
}

void TerminateModule_randint(void) {
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mrandint(int nargout_, mxArray * varargin);

_mexLocalFunctionTable _local_function_table_randint
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfRandint" contains the normal interface for the "randint"
 * M-function from file "k:\matlab6p5\toolbox\comm\comm\randint.m" (lines
 * 1-151). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfRandint(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * out = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    out = Mrandint(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(out);
}

/*
 * The function "mlxRandint" contains the feval interface for the "randint"
 * M-function from file "k:\matlab6p5\toolbox\comm\comm\randint.m" (lines
 * 1-151). The feval function calls the implementation version of randint
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxRandint(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: randint Line: 1 Column: "
            "1 The function \"randint\" was called with mor"
            "e than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mrandint(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mrandint" is the implementation version of the "randint"
 * M-function from file "k:\matlab6p5\toolbox\comm\comm\randint.m" (lines
 * 1-151). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = randint(varargin);
 */
static mxArray * Mrandint(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_randint);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * out = NULL;
    mxArray * r = NULL;
    mxArray * distance = NULL;
    mxArray * len_range = NULL;
    mxArray * i = NULL;
    mxArray * state = NULL;
    mxArray * range = NULL;
    mxArray * n = NULL;
    mxArray * m = NULL;
    mxArray * sigStr = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * %RANDINT Generate matrix of uniformly distributed random integers.
     * %   OUT = RANDINT generates a "0" or "1" with equal probability.
     * %
     * %   OUT = RANDINT(M) generates an M-by-M matrix of random binary numbers.
     * %   "0" and "1" occur with equal probability.
     * %
     * %   OUT = RANDINT(M,N) generates an M-by-N matrix of random binary numbers.
     * %   "0" and "1" occur with equal probability.
     * %
     * %   OUT = RANDINT(M,N,RANGE) generates an M-by-N matrix of random integers.
     * %
     * %   RANGE can be either a scalar or a two-element vector:
     * %   Scalar : If RANGE is a positive integer, then the output integer
     * %            range is [0, RANGE-1].  If RANGE is a negative integer,
     * %            then the output integer range is [RANGE+1, 0].
     * %   Vector : If RANGE is a two-element vector, then the output
     * %            integer range is [RANGE(1), RANGE(2)].
     * %
     * %   OUT = RANDINT(M,N,RANGE,STATE) resets the state of RAND to STATE.
     * %
     * %   Examples:
     * %   � out = randint(2,3)               � out = randint(2,3,4)
     * %   out =                              out =
     * %        0     0     1                      1     0     3
     * %        1     0     1                      2     3     1
     * %
     * %   � out = randint(2,3,-4)            � out = randint(2,3,[-2 2])
     * %   out =                              out =
     * %       -3    -1    -2                     -1     0    -2
     * %       -2     0     0                      1     2     1
     * %
     * %   See also RAND, RANDSRC, RANDERR.
     * 
     * %   Copyright 1996-2002 The MathWorks, Inc.
     * %   $Revision: 1.19 $  $Date: 2002/03/07 15:38:08 $
     * 
     * 
     * % Basic function setup.
     * error(nargchk(0,4,nargin));
     */
    mlfError(mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)), NULL);
    /*
     * 
     * % --- Placeholder for the signature string.
     * sigStr = '';
     */
    mlfAssign(&sigStr, _mxarray2_);
    /*
     * m = [];
     */
    mlfAssign(&m, _mxarray3_);
    /*
     * n = [];
     */
    mlfAssign(&n, _mxarray3_);
    /*
     * range = [];
     */
    mlfAssign(&range, _mxarray3_);
    /*
     * state = [];
     */
    mlfAssign(&state, _mxarray3_);
    {
        /*
         * 
         * % --- Identify string and numeric arguments
         * for i=1:nargin
         */
        int v_ = mclForIntStart(1);
        int e_ = nargin_;
        if (v_ > e_) {
            mlfAssign(&i, _mxarray3_);
        } else {
            /*
             * if(i>1)
             * sigStr(size(sigStr,2)+1) = '/';
             * end;
             * % --- Assign the string and numeric flags
             * if(isnumeric(varargin{i}))
             * sigStr(size(sigStr,2)+1) = 'n';
             * else
             * error('Only numeric arguments are accepted.');
             * end;
             * end;
             */
            for (; ; ) {
                if (mclGtBool(mlfScalar(v_), _mxarray4_)) {
                    mclArrayAssign1(
                      &sigStr,
                      _mxarray5_,
                      mclPlus(
                        mlfSize(
                          mclValueVarargout(),
                          mclVv(sigStr, "sigStr"),
                          _mxarray7_),
                        _mxarray4_));
                }
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxIsnumeric,
                        mlfIndexRef(
                          mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                        NULL))) {
                    mclArrayAssign1(
                      &sigStr,
                      _mxarray8_,
                      mclPlus(
                        mlfSize(
                          mclValueVarargout(),
                          mclVv(sigStr, "sigStr"),
                          _mxarray7_),
                        _mxarray4_));
                } else {
                    mlfError(_mxarray10_, NULL);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * 
     * % --- Identify parameter signitures and assign values to variables
     * switch sigStr
     */
    {
        mxArray * v_ = mclInitialize(mclVv(sigStr, "sigStr"));
        if (mclSwitchCompare(v_, _mxarray2_)) {
        /*
         * % --- randint
         * case ''
         * 
         * % --- randint(m)
         * case 'n'
         */
        } else if (mclSwitchCompare(v_, _mxarray8_)) {
            /*
             * m		= varargin{1};
             */
            mlfAssign(
              &m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
        /*
         * 
         * % --- randint(m, n)
         * case 'n/n'
         */
        } else if (mclSwitchCompare(v_, _mxarray12_)) {
            /*
             * m		= varargin{1};
             */
            mlfAssign(
              &m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
            /*
             * n		= varargin{2};
             */
            mlfAssign(
              &n, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
        /*
         * 
         * % --- randint(m, n, range)
         * case 'n/n/n'
         */
        } else if (mclSwitchCompare(v_, _mxarray14_)) {
            /*
             * m		= varargin{1};
             */
            mlfAssign(
              &m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
            /*
             * n  	= varargin{2};
             */
            mlfAssign(
              &n, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * range = varargin{3};
             */
            mlfAssign(
              &range,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * 
         * % --- randint(m, n, range, state)
         * case 'n/n/n/n'
         */
        } else if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * m		= varargin{1};
             */
            mlfAssign(
              &m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray4_));
            /*
             * n		= varargin{2};
             */
            mlfAssign(
              &n, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray7_));
            /*
             * range = varargin{3};
             */
            mlfAssign(
              &range,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
            /*
             * state = varargin{4};
             */
            mlfAssign(
              &state,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
        /*
         * 
         * % --- If the parameter list does not match one of these signatures.
         * otherwise
         */
        } else {
            /*
             * error('Syntax error.');
             */
            mlfError(_mxarray19_, NULL);
        /*
         * end;
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * if isempty(m)
     */
    if (mlfTobool(mlfIsempty(mclVv(m, "m")))) {
        /*
         * m = 1;
         */
        mlfAssign(&m, _mxarray4_);
    /*
     * end
     */
    }
    /*
     * if isempty(n)
     */
    if (mlfTobool(mlfIsempty(mclVv(n, "n")))) {
        /*
         * n = m;
         */
        mlfAssign(&n, mclVv(m, "m"));
    /*
     * end
     */
    }
    /*
     * if isempty(range)
     */
    if (mlfTobool(mlfIsempty(mclVv(range, "range")))) {
        /*
         * range = [0, 1];
         */
        mlfAssign(&range, _mxarray21_);
    /*
     * end
     */
    }
    /*
     * 
     * len_range = size(range,1) * size(range,2);
     */
    mlfAssign(
      &len_range,
      mclMtimes(
        mlfSize(mclValueVarargout(), mclVv(range, "range"), _mxarray4_),
        mlfSize(mclValueVarargout(), mclVv(range, "range"), _mxarray7_)));
    /*
     * 
     * % Typical error-checking.
     * if (~isfinite(m)) | (~isfinite(n))
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIsfinite(mclVv(m, "m"))));
        if (mlfTobool(a_)
            || mlfTobool(mclOr(a_, mclNot(mlfIsfinite(mclVv(n, "n")))))) {
            mxDestroyArray(a_);
            /*
             * error('Matrix dimensions must be finite.');
             */
            mlfError(_mxarray23_, NULL);
        /*
         * elseif (floor(m) ~= m) | (floor(n) ~= n) | (~isreal(m)) | (~isreal(n))
         */
        } else {
            mxDestroyArray(a_);
            {
                mxArray * a_0
                  = mclInitialize(
                      mclNe(mlfFloor(mclVv(m, "m")), mclVv(m, "m")));
                if (mlfTobool(a_0)) {
                    mlfAssign(&a_0, mlfScalar(1));
                } else {
                    mlfAssign(
                      &a_0,
                      mclOr(
                        a_0, mclNe(mlfFloor(mclVv(n, "n")), mclVv(n, "n"))));
                }
                if (mlfTobool(a_0)) {
                    mlfAssign(&a_0, mlfScalar(1));
                } else {
                    mlfAssign(
                      &a_0, mclOr(a_0, mclNot(mlfIsreal(mclVv(m, "m")))));
                }
                if (mlfTobool(a_0)
                    || mlfTobool(
                         mclOr(a_0, mclNot(mlfIsreal(mclVv(n, "n")))))) {
                    mxDestroyArray(a_0);
                    /*
                     * error('Matrix dimensions must be real integers.');
                     */
                    mlfError(_mxarray25_, NULL);
                /*
                 * elseif (m < 0) | (n < 0)
                 */
                } else {
                    mxDestroyArray(a_0);
                    {
                        mxArray * a_1
                          = mclInitialize(mclLt(mclVv(m, "m"), _mxarray0_));
                        if (mlfTobool(a_1)
                            || mlfTobool(
                                 mclOr(
                                   a_1, mclLt(mclVv(n, "n"), _mxarray0_)))) {
                            mxDestroyArray(a_1);
                            /*
                             * error('Matrix dimensions must be positive.');
                             */
                            mlfError(_mxarray27_, NULL);
                        /*
                         * elseif (length(m) > 1) | (length(n) > 1)
                         */
                        } else {
                            mxDestroyArray(a_1);
                            if (mclLengthInt(mclVv(m, "m")) > 1
                                || mclLengthInt(mclVv(n, "n")) > 1) {
                                /*
                                 * error('Matrix dimensions must be scalars.');
                                 */
                                mlfError(_mxarray29_, NULL);
                            /*
                             * elseif len_range > 2
                             */
                            } else if (mclGtBool(
                                         mclVv(len_range, "len_range"),
                                         _mxarray7_)) {
                                /*
                                 * error('The RANGE parameter should contain no more than two elements.');
                                 */
                                mlfError(_mxarray31_, NULL);
                            /*
                             * elseif max(max(floor(range) ~= range)) | (~isreal(range)) | (~isfinite(range))
                             */
                            } else {
                                mxArray * a_2
                                  = mclInitialize(
                                      mlfMax(
                                        NULL,
                                        mlfMax(
                                          NULL,
                                          mclNe(
                                            mlfFloor(mclVv(range, "range")),
                                            mclVv(range, "range")),
                                          NULL,
                                          NULL),
                                        NULL,
                                        NULL));
                                if (mlfTobool(a_2)) {
                                    mlfAssign(&a_2, mlfScalar(1));
                                } else {
                                    mlfAssign(
                                      &a_2,
                                      mclOr(
                                        a_2,
                                        mclNot(
                                          mlfIsreal(mclVv(range, "range")))));
                                }
                                if (mlfTobool(a_2)
                                    || mlfTobool(
                                         mclOr(
                                           a_2,
                                           mclNot(
                                             mlfIsfinite(
                                               mclVv(range, "range")))))) {
                                    mxDestroyArray(a_2);
                                    /*
                                     * error('The RANGE parameter must only contain real finite integers.');
                                     */
                                    mlfError(_mxarray33_, NULL);
                                } else {
                                    mxDestroyArray(a_2);
                                }
                            }
                        }
                    }
                }
            }
        }
    /*
     * end
     */
    }
    /*
     * 
     * % If the RANGE is specified as a scalar.
     * if len_range < 2
     */
    if (mclLtBool(mclVv(len_range, "len_range"), _mxarray7_)) {
        /*
         * if range < 0
         */
        if (mclLtBool(mclVv(range, "range"), _mxarray0_)) {
            /*
             * range = [range+1, 0];
             */
            mlfAssign(
              &range,
              mlfHorzcat(
                mclPlus(mclVv(range, "range"), _mxarray4_), _mxarray0_, NULL));
        /*
         * elseif range > 0
         */
        } else if (mclGtBool(mclVv(range, "range"), _mxarray0_)) {
            /*
             * range = [0, range-1];
             */
            mlfAssign(
              &range,
              mlfHorzcat(
                _mxarray0_, mclMinus(mclVv(range, "range"), _mxarray4_), NULL));
        /*
         * else
         */
        } else {
            /*
             * range = [0, 0];    % Special case of zero range.
             */
            mlfAssign(&range, _mxarray35_);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Make sure RANGE is ordered properly.
     * range = sort(range);
     */
    mlfAssign(&range, mlfSort(NULL, mclVv(range, "range"), NULL));
    /*
     * 
     * % Calculate the range the distance for the random number generator.
     * distance = range(2) - range(1);
     */
    mlfAssign(
      &distance,
      mclMinus(
        mclIntArrayRef1(mclVv(range, "range"), 2),
        mclIntArrayRef1(mclVv(range, "range"), 1)));
    /*
     * 
     * % Set the initial state if specified.
     * if ~isempty(state)
     */
    if (mclNotBool(mlfIsempty(mclVv(state, "state")))) {
        /*
         * rand('state', state);
         */
        mclAssignAns(
          &ans, mlfNRand(0, _mxarray37_, mclVv(state, "state"), NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Generate the random numbers.
     * r = floor(rand(m, n) * (distance+1));
     */
    mlfAssign(
      &r,
      mlfFloor(
        mclMtimes(
          mlfNRand(1, mclVv(m, "m"), mclVv(n, "n"), NULL),
          mclPlus(mclVv(distance, "distance"), _mxarray4_))));
    /*
     * 
     * % Offset the numbers to the specified value.
     * out = ones(m,n)*range(1);
     */
    mlfAssign(
      &out,
      mclMtimes(
        mlfOnes(mclVv(m, "m"), mclVv(n, "n"), NULL),
        mclIntArrayRef1(mclVv(range, "range"), 1)));
    /*
     * out = out + r;
     */
    mlfAssign(&out, mclPlus(mclVv(out, "out"), mclVv(r, "r")));
    mclValidateOutput(out, 1, nargout_, "out", "randint");
    mxDestroyArray(ans);
    mxDestroyArray(sigStr);
    mxDestroyArray(m);
    mxDestroyArray(n);
    mxDestroyArray(range);
    mxDestroyArray(state);
    mxDestroyArray(i);
    mxDestroyArray(len_range);
    mxDestroyArray(distance);
    mxDestroyArray(r);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     * % [EOF] randint.m
     */
}
