/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imadd.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "imlincomb.h"
#include "libmatlbm.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array5_[5] = { 'u', 'i', 'n', 't', '8' };
static mxArray * _mxarray4_;

static mxChar _array7_[6] = { 'u', 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray6_;

static mxChar _array9_[6] = { 'u', 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray8_;

static mxChar _array11_[4] = { 'i', 'n', 't', '8' };
static mxArray * _mxarray10_;

static mxChar _array13_[5] = { 'i', 'n', 't', '1', '6' };
static mxArray * _mxarray12_;

static mxChar _array15_[5] = { 'i', 'n', 't', '3', '2' };
static mxArray * _mxarray14_;

static mxChar _array17_[6] = { 's', 'i', 'n', 'g', 'l', 'e' };
static mxArray * _mxarray16_;

static mxChar _array19_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray18_;

static mxArray * _array3_[8] = { NULL /*_mxarray4_*/, NULL /*_mxarray6_*/,
                                 NULL /*_mxarray8_*/, NULL /*_mxarray10_*/,
                                 NULL /*_mxarray12_*/, NULL /*_mxarray14_*/,
                                 NULL /*_mxarray16_*/, NULL /*_mxarray18_*/ };
static mxArray * _mxarray2_;

static mxChar _array21_[12] = { 'O', 'U', 'T', 'P', 'U', 'T',
                                '_', 'C', 'L', 'A', 'S', 'S' };
static mxArray * _mxarray20_;
static mxArray * _mxarray22_;

void InitializeModule_imadd(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeDouble(3.0);
    _mxarray4_ = mclInitializeString(5, _array5_);
    _array3_[0] = _mxarray4_;
    _mxarray6_ = mclInitializeString(6, _array7_);
    _array3_[1] = _mxarray6_;
    _mxarray8_ = mclInitializeString(6, _array9_);
    _array3_[2] = _mxarray8_;
    _mxarray10_ = mclInitializeString(4, _array11_);
    _array3_[3] = _mxarray10_;
    _mxarray12_ = mclInitializeString(5, _array13_);
    _array3_[4] = _mxarray12_;
    _mxarray14_ = mclInitializeString(5, _array15_);
    _array3_[5] = _mxarray14_;
    _mxarray16_ = mclInitializeString(6, _array17_);
    _array3_[6] = _mxarray16_;
    _mxarray18_ = mclInitializeString(6, _array19_);
    _array3_[7] = _mxarray18_;
    _mxarray2_ = mclInitializeCellVector(1, 8, _array3_);
    _mxarray20_ = mclInitializeString(12, _array21_);
    _mxarray22_ = mclInitializeDouble(1.0);
}

void TerminateModule_imadd(void) {
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimadd(int nargout_,
                        mxArray * X,
                        mxArray * Y,
                        mxArray * output_class);

_mexLocalFunctionTable _local_function_table_imadd
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImadd" contains the normal interface for the "imadd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imadd.m" (lines
 * 1-68). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImadd(mxArray * X, mxArray * Y, mxArray * output_class) {
    int nargout = 1;
    mxArray * Z = NULL;
    mlfEnterNewContext(0, 3, X, Y, output_class);
    Z = Mimadd(nargout, X, Y, output_class);
    mlfRestorePreviousContext(0, 3, X, Y, output_class);
    return mlfReturnValue(Z);
}

/*
 * The function "mlxImadd" contains the feval interface for the "imadd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imadd.m" (lines
 * 1-68). The feval function calls the implementation version of imadd through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxImadd(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imadd Line: 1 Column: 1 The function \"imadd"
            "\" was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imadd Line: 1 Column: 1 The function \"imadd"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mimadd(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimadd" is the implementation version of the "imadd"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imadd.m" (lines
 * 1-68). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function Z = imadd(X,Y,output_class)
 */
static mxArray * Mimadd(int nargout_,
                        mxArray * X,
                        mxArray * Y,
                        mxArray * output_class) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imadd);
    int nargin_ = mclNargin(3, X, Y, output_class, NULL);
    mxArray * Z = NULL;
    mxArray * valid_strings = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&X);
    mclCopyArray(&Y);
    mclCopyArray(&output_class);
    /*
     * %IMADD Add two images, or add constant to image.
     * %   Z = IMADD(X,Y) adds each element in array X to the corresponding      
     * %   element in array Y and returns the sum in the corresponding element
     * %   of the output array Z.  X and Y are real, nonsparse, numeric arrays
     * %   with the same size and class, or Y is a scalar double.  Z has the
     * %   same size and class as X.
     * %
     * %   Z = IMADD(X,Y,OUTPUT_CLASS) specifies the desired output class of Z.
     * %   OUTPUT_CLASS must be one of the following strings: 'uint8', 'uint16',
     * %   'uint32', 'int8', 'int16', and 'int32', 'single, 'double'.
     * %
     * %   If Z is an integer array, then elements in the output that exceed the
     * %   range of the integer type are truncated, and fractional values are
     * %   rounded.
     * %
     * %   If X and Y are double arrays, you can use the expression X+Y instead of
     * %   this function.
     * %
     * %   Example 1
     * %   ---------
     * %   Add two images together:
     * %
     * %       I = imread('rice.tif');
     * %       J = imread('cameraman.tif');
     * %       K = imadd(I,J);
     * %       imshow(K)
     * %
     * %   Example 2
     * %   ---------
     * %   Add two images together and specify an output class:
     * %
     * %       I = imread('rice.tif');
     * %       J = imread('cameraman.tif');
     * %       K = imadd(I,J,'uint16');
     * %       imshow(K,[])
     * %
     * %   Example 3
     * %   ---------
     * %   Add a constant to an image:
     * %
     * %       I = imread('rice.tif');
     * %       J = imadd(I,50);
     * %       subplot(1,2,1), imshow(I)
     * %       subplot(1,2,2), imshow(J)
     * %
     * %   See also IMABSDIFF, IMCOMPLEMENT, IMDIVIDE, IMLINCOMB, IMMULTIPLY, IMSUBTRACT.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.9 $  $Date: 2002/03/15 15:27:41 $
     * 
     * checknargin(2, 3, nargin, mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray0_, _mxarray1_, mlfScalar(nargin_), mxCreateString("imadd"));
    /*
     * 
     * if (nargin < 3)
     */
    if (nargin_ < 3) {
        /*
         * output_class = class(X);
         */
        mlfAssign(&output_class, mlfClassName(mclVa(X, "X"), NULL));
    /*
     * else
     */
    } else {
        /*
         * valid_strings = {'uint8' 'uint16' 'uint32' 'int8' 'int16' 'int32' ...
         */
        mlfAssign(&valid_strings, _mxarray2_);
        /*
         * 'single' 'double'};
         * output_class = checkstrs(output_class, valid_strings, mfilename, ...
         */
        mlfAssign(
          &output_class,
          mlfImages_private_checkstrs(
            mclVa(output_class, "output_class"),
            mclVv(valid_strings, "valid_strings"),
            mxCreateString("imadd"),
            _mxarray20_,
            _mxarray1_));
    /*
     * 'OUTPUT_CLASS', 3);
     * end
     */
    }
    /*
     * 
     * if (prod(size(Y)) == 1) & isa(Y, 'double')
     */
    {
        mxArray * a_
          = mclInitialize(
              mclEq(
                mlfProd(
                  mlfSize(mclValueVarargout(), mclVa(Y, "Y"), NULL), NULL),
                _mxarray22_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mlfIsa(mclVa(Y, "Y"), _mxarray18_)))) {
            mxDestroyArray(a_);
            /*
             * Z = imlincomb(1.0, X, Y, output_class);
             */
            mlfAssign(
              &Z,
              mlfImlincomb(
                _mxarray22_,
                mclVa(X, "X"),
                mclVa(Y, "Y"),
                mclVa(output_class, "output_class"),
                NULL));
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * Z = imlincomb(1.0, X, 1.0, Y, output_class);
             */
            mlfAssign(
              &Z,
              mlfImlincomb(
                _mxarray22_,
                mclVa(X, "X"),
                _mxarray22_,
                mclVa(Y, "Y"),
                mclVa(output_class, "output_class"),
                NULL));
        }
    /*
     * end
     */
    }
    mclValidateOutput(Z, 1, nargout_, "Z", "imadd");
    mxDestroyArray(ans);
    mxDestroyArray(valid_strings);
    mxDestroyArray(output_class);
    mxDestroyArray(Y);
    mxDestroyArray(X);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return Z;
}
