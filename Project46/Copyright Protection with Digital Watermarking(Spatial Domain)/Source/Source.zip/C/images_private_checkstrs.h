/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __images_private_checkstrs_h
#define __images_private_checkstrs_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_images_private_checkstrs(void);
extern void TerminateModule_images_private_checkstrs(void);
extern _mexLocalFunctionTable _local_function_table_images_private_checkstrs;

extern mxArray * mlfImages_private_checkstrs(mxArray * in,
                                             mxArray * valid_strings,
                                             mxArray * function_name,
                                             mxArray * variable_name,
                                             mxArray * argument_position);
extern void mlxImages_private_checkstrs(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
