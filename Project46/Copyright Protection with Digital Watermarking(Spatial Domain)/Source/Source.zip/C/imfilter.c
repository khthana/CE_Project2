/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imfilter.h"
#include "imadd.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "images_private_imfilter_mex_mex_interface.h"
#include "imsubtract.h"
#include "libmatlbm.h"
#include "padarray.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static mxChar _array6_[35] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                               ':', 'n', 'e', 'g', 'a', 't', 'i', 'v', 'e',
                               'D', 'i', 'm', 'e', 'n', 's', 'i', 'o', 'n',
                               'B', 'a', 'd', 'S', 'i', 'z', 'e', 'B' };
static mxArray * _mxarray5_;

static mxChar _array8_[126] = { 'E', 'r', 'r', 'o', 'r', ' ', 'i', 'n', ' ',
                                's', 'i', 'z', 'e', ' ', 'o', 'f', ' ', 'B',
                                '.', ' ', ' ', 'A', 't', ' ', 'l', 'e', 'a',
                                's', 't', ' ', 'o', 'n', 'e', ' ', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', ' ', 'i',
                                's', ' ', 'n', 'e', 'g', 'a', 't', 'i', 'v',
                                'e', '.', ' ', 0x005c, 'n', 0x0027, 'F',
                                'u', 'l', 'l', 0x0027, ' ', 'o', 'u', 't',
                                'p', 'u', 't', ' ', 's', 'i', 'z', 'e', ' ',
                                'c', 'a', 'l', 'c', 'u', 'l', 'a', 't', 'i',
                                'o', 'n', ' ', 'i', 's', ':', ' ', 's', 'i',
                                'z', 'e', '(', 'B', ')', ' ', '=', ' ', 's',
                                'i', 'z', 'e', '(', 'A', ')', ' ', '+', ' ',
                                's', 'i', 'z', 'e', '(', 'H', ')', ' ', '-',
                                ' ', '1', '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[4] = { 'b', 'o', 't', 'h' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array15_[7] = { 'n', 'u', 'm', 'e', 'r', 'i', 'c' };
static mxArray * _mxarray14_;

static mxChar _array17_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray16_;

static mxArray * _array13_[2] = { NULL /*_mxarray14_*/, NULL /*_mxarray16_*/ };
static mxArray * _mxarray12_;

static mxChar _array20_[9] = { 'n', 'o', 'n', 's', 'p', 'a', 'r', 's', 'e' };
static mxArray * _mxarray19_;
static mxArray * _mxarray18_;

static mxChar _array22_[1] = { 'A' };
static mxArray * _mxarray21_;

static mxChar _array25_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray24_;
static mxArray * _mxarray23_;

static mxChar _array27_[1] = { 'H' };
static mxArray * _mxarray26_;

static mxChar _array29_[4] = { 's', 'a', 'm', 'e' };
static mxArray * _mxarray28_;

static mxChar _array31_[4] = { 'c', 'o', 'r', 'r' };
static mxArray * _mxarray30_;

static mxChar _array35_[9] = { 'r', 'e', 'p', 'l', 'i', 'c', 'a', 't', 'e' };
static mxArray * _mxarray34_;

static mxChar _array37_[9] = { 's', 'y', 'm', 'm', 'e', 't', 'r', 'i', 'c' };
static mxArray * _mxarray36_;

static mxChar _array39_[8] = { 'c', 'i', 'r', 'c', 'u', 'l', 'a', 'r' };
static mxArray * _mxarray38_;

static mxChar _array41_[4] = { 'c', 'o', 'n', 'v' };
static mxArray * _mxarray40_;

static mxChar _array43_[4] = { 'f', 'u', 'l', 'l' };
static mxArray * _mxarray42_;

static mxArray * _array33_[7] = { NULL /*_mxarray34_*/, NULL /*_mxarray36_*/,
                                  NULL /*_mxarray38_*/, NULL /*_mxarray40_*/,
                                  NULL /*_mxarray30_*/, NULL /*_mxarray42_*/,
                                  NULL /*_mxarray28_*/ };
static mxArray * _mxarray32_;
static mxArray * _mxarray44_;

static mxChar _array46_[6] = { 'O', 'P', 'T', 'I', 'O', 'N' };
static mxArray * _mxarray45_;

static mxArray * _array48_[3] = { NULL /*_mxarray34_*/, NULL /*_mxarray36_*/,
                                  NULL /*_mxarray38_*/ };
static mxArray * _mxarray47_;

static mxArray * _array50_[2] = { NULL /*_mxarray42_*/, NULL /*_mxarray28_*/ };
static mxArray * _mxarray49_;

static mxArray * _array52_[2] = { NULL /*_mxarray40_*/, NULL /*_mxarray30_*/ };
static mxArray * _mxarray51_;
static mxArray * _mxarray53_;

void InitializeModule_imfilter(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(8.0);
    _mxarray2_ = mclInitializeDouble(2.0);
    _mxarray3_ = mclInitializeDouble(4.0);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeString(35, _array6_);
    _mxarray7_ = mclInitializeString(126, _array8_);
    _mxarray9_ = mclInitializeString(4, _array10_);
    _mxarray11_ = mclInitializeDouble(5.0);
    _mxarray14_ = mclInitializeString(7, _array15_);
    _array13_[0] = _mxarray14_;
    _mxarray16_ = mclInitializeString(7, _array17_);
    _array13_[1] = _mxarray16_;
    _mxarray12_ = mclInitializeCellVector(1, 2, _array13_);
    _mxarray19_ = mclInitializeString(9, _array20_);
    _mxarray18_ = mclInitializeCell(_mxarray19_);
    _mxarray21_ = mclInitializeString(1, _array22_);
    _mxarray24_ = mclInitializeString(6, _array25_);
    _mxarray23_ = mclInitializeCell(_mxarray24_);
    _mxarray26_ = mclInitializeString(1, _array27_);
    _mxarray28_ = mclInitializeString(4, _array29_);
    _mxarray30_ = mclInitializeString(4, _array31_);
    _mxarray34_ = mclInitializeString(9, _array35_);
    _array33_[0] = _mxarray34_;
    _mxarray36_ = mclInitializeString(9, _array37_);
    _array33_[1] = _mxarray36_;
    _mxarray38_ = mclInitializeString(8, _array39_);
    _array33_[2] = _mxarray38_;
    _mxarray40_ = mclInitializeString(4, _array41_);
    _array33_[3] = _mxarray40_;
    _array33_[4] = _mxarray30_;
    _mxarray42_ = mclInitializeString(4, _array43_);
    _array33_[5] = _mxarray42_;
    _array33_[6] = _mxarray28_;
    _mxarray32_ = mclInitializeCellVector(1, 7, _array33_);
    _mxarray44_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray45_ = mclInitializeString(6, _array46_);
    _array48_[0] = _mxarray34_;
    _array48_[1] = _mxarray36_;
    _array48_[2] = _mxarray38_;
    _mxarray47_ = mclInitializeCellVector(1, 3, _array48_);
    _array50_[0] = _mxarray42_;
    _array50_[1] = _mxarray28_;
    _mxarray49_ = mclInitializeCellVector(1, 2, _array50_);
    _array52_[0] = _mxarray40_;
    _array52_[1] = _mxarray30_;
    _mxarray51_ = mclInitializeCellVector(1, 2, _array52_);
    _mxarray53_ = mclInitializeCell(_mxarray14_);
}

void TerminateModule_imfilter(void) {
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImfilter_parse_inputs(mxArray * * h,
                                          mxArray * * boundary,
                                          mxArray * * flags,
                                          mxArray * a_in,
                                          mxArray * h_in,
                                          ...);
static void mlxImfilter_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * Mimfilter(int nargout_, mxArray * varargin);
static mxArray * Mimfilter_parse_inputs(mxArray * * h,
                                        mxArray * * boundary,
                                        mxArray * * flags,
                                        int nargout_,
                                        mxArray * a_in,
                                        mxArray * h_in,
                                        mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "parse_inputs", mlxImfilter_parse_inputs, -3, 4, NULL } };

_mexLocalFunctionTable _local_function_table_imfilter
  = { 1, local_function_table_ };

/*
 * The function "mlfImfilter" contains the normal interface for the "imfilter"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines
 * 1-217). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImfilter(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * b = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    b = Mimfilter(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(b);
}

/*
 * The function "mlxImfilter" contains the feval interface for the "imfilter"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines
 * 1-217). The feval function calls the implementation version of imfilter
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImfilter(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imfilter Line: 1 Column:"
            " 1 The function \"imfilter\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimfilter(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImfilter_parse_inputs" contains the normal interface for
 * the "imfilter/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines 217-262). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImfilter_parse_inputs(mxArray * * h,
                                          mxArray * * boundary,
                                          mxArray * * flags,
                                          mxArray * a_in,
                                          mxArray * h_in,
                                          ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * a = NULL;
    mxArray * h__ = NULL;
    mxArray * boundary__ = NULL;
    mxArray * flags__ = NULL;
    mlfVarargin(&varargin, h_in, 0);
    mlfEnterNewContext(3, -3, h, boundary, flags, a_in, h_in, varargin);
    if (h != NULL) {
        ++nargout;
    }
    if (boundary != NULL) {
        ++nargout;
    }
    if (flags != NULL) {
        ++nargout;
    }
    a
      = Mimfilter_parse_inputs(
          &h__, &boundary__, &flags__, nargout, a_in, h_in, varargin);
    mlfRestorePreviousContext(3, 2, h, boundary, flags, a_in, h_in);
    mxDestroyArray(varargin);
    if (h != NULL) {
        mclCopyOutputArg(h, h__);
    } else {
        mxDestroyArray(h__);
    }
    if (boundary != NULL) {
        mclCopyOutputArg(boundary, boundary__);
    } else {
        mxDestroyArray(boundary__);
    }
    if (flags != NULL) {
        mclCopyOutputArg(flags, flags__);
    } else {
        mxDestroyArray(flags__);
    }
    return mlfReturnValue(a);
}

/*
 * The function "mlxImfilter_parse_inputs" contains the feval interface for the
 * "imfilter/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines 217-262). The feval
 * function calls the implementation version of imfilter/parse_inputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImfilter_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imfilter/parse_inputs Line: 217 Co"
            "lumn: 1 The function \"imfilter/parse_inputs\" was calle"
            "d with more than the declared number of outputs (4)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mprhs[2] = NULL;
    mlfAssign(&mprhs[2], mclCreateVararginCell(nrhs - 2, prhs + 2));
    mplhs[0]
      = Mimfilter_parse_inputs(
          &mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[2]);
}

/*
 * The function "Mimfilter" is the implementation version of the "imfilter"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines
 * 1-217). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function b = imfilter(varargin)
 */
static mxArray * Mimfilter(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imfilter);
    mxArray * b = NULL;
    mxArray * b2 = NULL;
    mxArray * b1 = NULL;
    mxArray * conn = NULL;
    mxArray * conn_logical = NULL;
    mxArray * start = NULL;
    mxArray * ans = NULL;
    mxArray * msg = NULL;
    mxArray * eid = NULL;
    mxArray * filter_center = NULL;
    mxArray * pad = NULL;
    mxArray * im_size = NULL;
    mxArray * size_a = NULL;
    mxArray * size_h = NULL;
    mxArray * rank_h = NULL;
    mxArray * rank_a = NULL;
    mxArray * flags = NULL;
    mxArray * boundary = NULL;
    mxArray * h = NULL;
    mxArray * a = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMFILTER Multidimensional image filtering.
     * %   B = IMFILTER(A,H) filters the multidimensional array A with the
     * %   multidimensional filter H.  A can be logical or it can be a 
     * %   nonsparse numeric array of any class and dimension.  The result, 
     * %   B, has the same size and class as A.
     * %
     * %   Each element of the output, B, is computed using double-precision
     * %   floating point.  If A is an integer or logical array, then output 
     * %   elements that exceed the range of the given type are truncated, 
     * %   and fractional values are rounded.
     * %
     * %   B = IMFILTER(A,H,OPTION1,OPTION2,...) performs multidimensional
     * %   filtering according to the specified options.  Option arguments can
     * %   have the following values:
     * %
     * %   - Boundary options
     * %
     * %       X            Input array values outside the bounds of the array
     * %                    are implicitly assumed to have the value X.  When no
     * %                    boundary option is specified, IMFILTER uses X = 0.
     * %
     * %       'symmetric'  Input array values outside the bounds of the array
     * %                    are computed by mirror-reflecting the array across
     * %                    the array border.
     * %
     * %       'replicate'  Input array values outside the bounds of the array
     * %                    are assumed to equal the nearest array border
     * %                    value.
     * %
     * %       'circular'   Input array values outside the bounds of the array
     * %                    are computed by implicitly assuming the input array
     * %                    is periodic.
     * %
     * %   - Output size options
     * %     (Output size options for IMFILTER are analogous to the SHAPE option
     * %     in the functions CONV2 and FILTER2.)
     * %
     * %       'same'       The output array is the same size as the input
     * %                    array.  This is the default behavior when no output
     * %                    size options are specified.
     * %
     * %       'full'       The output array is the full filtered result, and so
     * %                    is larger than the input array.
     * %
     * %   - Correlation and convolution
     * %
     * %       'corr'       IMFILTER performs multidimensional filtering using
     * %                    correlation, which is the same way that FILTER2
     * %                    performs filtering.  When no correlation or
     * %                    convolution option is specified, IMFILTER uses
     * %                    correlation.
     * %
     * %       'conv'       IMFILTER performs multidimensional filtering using
     * %                    convolution.
     * %
     * %   Example 
     * %   -------------
     * %       rgb = imread('flowers.tif'); 
     * %       h = fspecial('motion',50,45); 
     * %       rgb2 = imfilter(rgb,h); 
     * %       imshow(rgb), title('Original') 
     * %       figure, imshow(rgb2), title('Filtered') 
     * %       rgb3 = imfilter(rgb,h,'replicate'); 
     * %       figure, imshow(rgb3), title('Filtered with boundary replication')
     * %
     * %   See also CONV2, CONVN, FILTER2. 
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc. 
     * %   $Revision: 1.9 $  $Date: 2002/03/26 16:03:14 $
     * 
     * % Testing notes
     * % Syntaxes
     * % --------
     * % B = imfilter(A,H)
     * % B = imfilter(A,H,Option1, Option2,...)
     * %
     * % A:       numeric, full, N-D array.  May not be uint64 or int64 class.  May be
     * %          empty. May contain Infs and Nans. May be complex. Required.
     * %         
     * % H:       numeric, full, N-D array.  Must be double.  May be
     * %          empty. May contain Infs and Nans. May be complex. Required.
     * %
     * % A and H are not required to have the same number of dimensions. 
     * %
     * % OptionN  string or a scalar number. Not case sensitive. Optional.  An
     * %          error if not recognized.  While there may be up to three options
     * %          specified, this is left unchecked and the last option specified
     * %          is used.  Conflicting or inconsistent options are not checked.
     * %
     * %        A choice between these options for boundary options
     * %        'Symmetric' 
     * %        'Replicate'
     * %        'Circular'
     * %         Scalar #  - Default to zero.
     * %       A choice between these strings for output options
     * %        'Full'
     * %        'Same'  - default
     * %       A choice between these strings for functionality options
     * %        'Conv' 
     * %        'Corr'  - default       
     * %
     * % B:   N-D array the same class as A.  If the 'Same' output option was
     * %      specified, B is the same size as A.  If the 'Full' output option was
     * %      specified the size of B is size(A)+size(H)-1, remembering that if
     * %      size(A)~=size(B) then the missing dimensions have a size of 1.
     * %
     * % 
     * % IMFILTER should use a significantly less amount of memory than CONVN. 
     * 
     * [a,h,boundary,flags] = parse_inputs(varargin{:});
     */
    mclFeval(
      mlfVarargout(&a, &h, &boundary, &flags, NULL),
      mlxImfilter_parse_inputs,
      mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
      NULL);
    /*
     * 
     * 
     * rank_a = ndims(a);
     */
    mlfAssign(&rank_a, mlfNdims(mclVv(a, "a")));
    /*
     * rank_h = ndims(h);
     */
    mlfAssign(&rank_h, mlfNdims(mclVv(h, "h")));
    /*
     * 
     * % Pad dimensions with ones if filter and image rank are different
     * size_h = [size(h) ones(1,rank_a-rank_h)];
     */
    mlfAssign(
      &size_h,
      mlfHorzcat(
        mlfSize(mclValueVarargout(), mclVv(h, "h"), NULL),
        mlfOnes(
          _mxarray0_,
          mclMinus(mclVv(rank_a, "rank_a"), mclVv(rank_h, "rank_h")),
          NULL),
        NULL));
    /*
     * size_a = [size(a) ones(1,rank_h-rank_a)];
     */
    mlfAssign(
      &size_a,
      mlfHorzcat(
        mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL),
        mlfOnes(
          _mxarray0_,
          mclMinus(mclVv(rank_h, "rank_h"), mclVv(rank_a, "rank_a")),
          NULL),
        NULL));
    /*
     * 
     * if bitand(flags,8)
     */
    if (mlfTobool(mlfBitand(mclVv(flags, "flags"), _mxarray1_))) {
        /*
         * %Full output
         * im_size = size_a+size_h-1;
         */
        mlfAssign(
          &im_size,
          mclMinus(
            mclPlus(mclVv(size_a, "size_a"), mclVv(size_h, "size_h")),
            _mxarray0_));
        /*
         * pad = [size(h)-1 ones(1,rank_a-rank_h)];
         */
        mlfAssign(
          &pad,
          mlfHorzcat(
            mclMinus(
              mlfSize(mclValueVarargout(), mclVv(h, "h"), NULL), _mxarray0_),
            mlfOnes(
              _mxarray0_,
              mclMinus(mclVv(rank_a, "rank_a"), mclVv(rank_h, "rank_h")),
              NULL),
            NULL));
    /*
     * else
     */
    } else {
        /*
         * %Same output
         * im_size = size(a);
         */
        mlfAssign(&im_size, mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL));
        /*
         * %Calculate the number of pad pixels
         * filter_center = floor((size(h)+1)/2);
         */
        mlfAssign(
          &filter_center,
          mlfFloor(
            mclMrdivide(
              mclPlus(
                mlfSize(mclValueVarargout(), mclVv(h, "h"), NULL), _mxarray0_),
              _mxarray2_)));
        /*
         * pad = [size(h)-filter_center ones(1,rank_a-rank_h)];
         */
        mlfAssign(
          &pad,
          mlfHorzcat(
            mclMinus(
              mlfSize(mclValueVarargout(), mclVv(h, "h"), NULL),
              mclVv(filter_center, "filter_center")),
            mlfOnes(
              _mxarray0_,
              mclMinus(mclVv(rank_a, "rank_a"), mclVv(rank_h, "rank_h")),
              NULL),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * %Empty Inputs
     * % 'Same' output then size(b) = size(a)
     * % 'Full' output then size(b) = size(h)+size(a)-1 
     * if isempty(a)
     */
    if (mlfTobool(mlfIsempty(mclVv(a, "a")))) {
        /*
         * if bitand(flags,4) %Same
         */
        if (mlfTobool(mlfBitand(mclVv(flags, "flags"), _mxarray3_))) {
            /*
             * b = a;
             */
            mlfAssign(&b, mclVv(a, "a"));
        /*
         * else %Full
         */
        } else {
            /*
             * if all(im_size>0)
             */
            if (mlfTobool(
                  mlfAll(mclGt(mclVv(im_size, "im_size"), _mxarray4_), NULL))) {
                /*
                 * b = a;
                 */
                mlfAssign(&b, mclVv(a, "a"));
                /*
                 * b = b(:);
                 */
                mlfAssign(
                  &b, mclArrayRef1(mclVv(b, "b"), mlfCreateColonIndex()));
                /*
                 * b(prod(im_size)) = 0;
                 */
                mclArrayAssign1(
                  &b, _mxarray4_, mlfProd(mclVv(im_size, "im_size"), NULL));
                /*
                 * b = reshape(b,im_size);
                 */
                mlfAssign(
                  &b,
                  mlfReshape(mclVv(b, "b"), mclVv(im_size, "im_size"), NULL));
            /*
             * elseif all(im_size>=0)
             */
            } else if (mlfTobool(
                         mlfAll(
                           mclGe(mclVv(im_size, "im_size"), _mxarray4_),
                           NULL))) {
                /*
                 * b = feval(class(a),zeros(im_size));
                 */
                mlfAssign(
                  &b,
                  mlfFeval(
                    mclValueVarargout(),
                    mlfClassName(mclVv(a, "a"), NULL),
                    mlfZeros(mclVv(im_size, "im_size"), NULL),
                    NULL));
            /*
             * else
             */
            } else {
                /*
                 * eid = sprintf('Images:%s:negativeDimensionBadSizeB',mfilename);
                 */
                mlfAssign(
                  &eid,
                  mlfSprintf(
                    NULL, _mxarray5_, mxCreateString("imfilter"), NULL));
                /*
                 * msg = 'Error in size of B.  At least one dimension is negative. \n''Full'' output size calculation is: size(B) = size(A) + size(H) - 1.';
                 */
                mlfAssign(&msg, _mxarray7_);
                /*
                 * error(eid,msg);
                 */
                mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if  isempty(h)
     */
    if (mlfTobool(mlfIsempty(mclVv(h, "h")))) {
        /*
         * if bitand(flags,4) %Same
         */
        if (mlfTobool(mlfBitand(mclVv(flags, "flags"), _mxarray3_))) {
            /*
             * b = a;
             */
            mlfAssign(&b, mclVv(a, "a"));
            /*
             * b(:) = 0;
             */
            mclArrayAssign1(&b, _mxarray4_, mlfCreateColonIndex());
        /*
         * else %Full
         */
        } else {
            /*
             * if all(im_size>0)
             */
            if (mlfTobool(
                  mlfAll(mclGt(mclVv(im_size, "im_size"), _mxarray4_), NULL))) {
                /*
                 * b = a;
                 */
                mlfAssign(&b, mclVv(a, "a"));
                /*
                 * if im_size<size_a  %Output is smaller than input
                 */
                if (mclLtBool(
                      mclVv(im_size, "im_size"), mclVv(size_a, "size_a"))) {
                    /*
                     * b(:) = [];
                     */
                    mlfIndexDelete(&b, "(?)", mlfCreateColonIndex());
                /*
                 * else %Grow the array, is this a no-op?
                 */
                } else {
                    /*
                     * b(:) = 0;
                     */
                    mclArrayAssign1(&b, _mxarray4_, mlfCreateColonIndex());
                    /*
                     * b = b(:);
                     */
                    mlfAssign(
                      &b, mclArrayRef1(mclVv(b, "b"), mlfCreateColonIndex()));
                /*
                 * end
                 */
                }
                /*
                 * b(prod(im_size)) = 0;
                 */
                mclArrayAssign1(
                  &b, _mxarray4_, mlfProd(mclVv(im_size, "im_size"), NULL));
                /*
                 * b = reshape(b,im_size);
                 */
                mlfAssign(
                  &b,
                  mlfReshape(mclVv(b, "b"), mclVv(im_size, "im_size"), NULL));
            /*
             * elseif all(im_size>=0)
             */
            } else if (mlfTobool(
                         mlfAll(
                           mclGe(mclVv(im_size, "im_size"), _mxarray4_),
                           NULL))) {
                /*
                 * b = feval(class(a),zeros(im_size));
                 */
                mlfAssign(
                  &b,
                  mlfFeval(
                    mclValueVarargout(),
                    mlfClassName(mclVv(a, "a"), NULL),
                    mlfZeros(mclVv(im_size, "im_size"), NULL),
                    NULL));
            /*
             * else
             */
            } else {
                /*
                 * eid = sprintf('Images:%s:negativeDimensionBadSizeB',mfilename);
                 */
                mlfAssign(
                  &eid,
                  mlfSprintf(
                    NULL, _mxarray5_, mxCreateString("imfilter"), NULL));
                /*
                 * msg = 'Error in size of B.  At least one dimension is negative. \n''Full'' output size calculation is: size(B) = size(A) + size(H) - 1.';
                 */
                mlfAssign(&msg, _mxarray7_);
                /*
                 * error(eid,msg);
                 */
                mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
            /*
             * end
             */
            }
        /*
         * end
         */
        }
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * im_size = int32(im_size);
     */
    mlfAssign(&im_size, mlfInt32(mclVv(im_size, "im_size")));
    /*
     * 
     * %Starting point in padded image, zero based.
     * start = int32(pad);
     */
    mlfAssign(&start, mlfInt32(mclVv(pad, "pad")));
    /*
     * 
     * %Pad image
     * a = padarray(a,pad,boundary,'both');
     */
    mlfAssign(
      &a,
      mlfPadarray(
        mclVv(a, "a"),
        mclVv(pad, "pad"),
        mclVv(boundary, "boundary"),
        _mxarray9_,
        NULL));
    /*
     * 
     * %Create connectivity matrix.  Only use nonzero values of the filter.
     * conn_logical = h~=0;
     */
    mlfAssign(&conn_logical, mclNe(mclVv(h, "h"), _mxarray4_));
    /*
     * conn = double( conn_logical );  %input to the mex file must be double
     */
    mlfAssign(&conn, mlfDouble(mclVv(conn_logical, "conn_logical")));
    /*
     * 
     * % Seperate real and imaginary parts of the filter (h) in the M-code and
     * % filter imaginary and real parts of the image (a) in the mex code. 
     * b1 = imfilter_mex(a,im_size,real(h(conn_logical)),conn,start,flags);
     */
    mlfAssign(
      &b1,
      mlfNImages_private_imfilter_mex(
        0,
        mclValueVarargout(),
        mclVv(a, "a"),
        mclVv(im_size, "im_size"),
        mlfReal(
          mclArrayRef1(mclVv(h, "h"), mclVv(conn_logical, "conn_logical"))),
        mclVv(conn, "conn"),
        mclVv(start, "start"),
        mclVv(flags, "flags"),
        NULL));
    /*
     * 
     * if ~isreal(h)
     */
    if (mclNotBool(mlfIsreal(mclVv(h, "h")))) {
        /*
         * b2 = imfilter_mex(a,im_size,imag(h(conn_logical)),conn,start,flags);
         */
        mlfAssign(
          &b2,
          mlfNImages_private_imfilter_mex(
            0,
            mclValueVarargout(),
            mclVv(a, "a"),
            mclVv(im_size, "im_size"),
            mlfImag(
              mclArrayRef1(mclVv(h, "h"), mclVv(conn_logical, "conn_logical"))),
            mclVv(conn, "conn"),
            mclVv(start, "start"),
            mclVv(flags, "flags"),
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * %If input is not complex, the output should not be complex. COMPLEX always
     * %creates an imaginary part even if the imaginary part is zeros.
     * if isreal(h)
     */
    if (mlfTobool(mlfIsreal(mclVv(h, "h")))) {
        /*
         * % b will always be real
         * b = b1;
         */
        mlfAssign(&b, mclVv(b1, "b1"));
    /*
     * elseif isreal(a)
     */
    } else if (mlfTobool(mlfIsreal(mclVv(a, "a")))) {
        /*
         * % b1 and b2 will always be real. b will always be complex
         * b = complex(b1,b2);
         */
        mlfAssign(&b, mlfComplex(mclVv(b1, "b1"), mclVv(b2, "b2")));
    /*
     * else
     */
    } else {
        /*
         * % b1 and/or b2 may be complex.  b will always be complex
         * b = complex(imsubtract(real(b1),imag(b2)),imadd(imag(b1),real(b2)));
         */
        mlfAssign(
          &b,
          mlfComplex(
            mlfImsubtract(mlfReal(mclVv(b1, "b1")), mlfImag(mclVv(b2, "b2"))),
            mlfImadd(
              mlfImag(mclVv(b1, "b1")), mlfReal(mclVv(b2, "b2")), NULL)));
    /*
     * end
     */
    }
    /*
     * 
     * %======================================================================
     * 
     */
    return_:
    mclValidateOutput(b, 1, nargout_, "b", "imfilter");
    mxDestroyArray(a);
    mxDestroyArray(h);
    mxDestroyArray(boundary);
    mxDestroyArray(flags);
    mxDestroyArray(rank_a);
    mxDestroyArray(rank_h);
    mxDestroyArray(size_h);
    mxDestroyArray(size_a);
    mxDestroyArray(im_size);
    mxDestroyArray(pad);
    mxDestroyArray(filter_center);
    mxDestroyArray(eid);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(start);
    mxDestroyArray(conn_logical);
    mxDestroyArray(conn);
    mxDestroyArray(b1);
    mxDestroyArray(b2);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
}

/*
 * The function "Mimfilter_parse_inputs" is the implementation version of the
 * "imfilter/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imfilter.m" (lines 217-262). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [a,h,boundary,flags ] = parse_inputs(a,h,varargin)
 */
static mxArray * Mimfilter_parse_inputs(mxArray * * h,
                                        mxArray * * boundary,
                                        mxArray * * flags,
                                        int nargout_,
                                        mxArray * a_in,
                                        mxArray * h_in,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imfilter);
    int nargin_ = mclNargin(-3, a_in, h_in, varargin, NULL);
    mxArray * a = NULL;
    mxArray * string = NULL;
    mxArray * k = NULL;
    mxArray * allStrings = NULL;
    mxArray * do_fcn = NULL;
    mxArray * output = NULL;
    mxArray * ans = NULL;
    mclCopyInputArg(&a, a_in);
    mclCopyInputArg(h, h_in);
    mclCopyArray(&varargin);
    /*
     * 
     * checknargin(2,5,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray2_, _mxarray11_, mlfScalar(nargin_), mxCreateString("imfilter"));
    /*
     * 
     * checkinput(a,{'numeric' 'logical'},{'nonsparse'},mfilename,'A',1);
     */
    mlfImages_private_checkinput(
      mclVa(a, "a"),
      _mxarray12_,
      _mxarray18_,
      mxCreateString("imfilter"),
      _mxarray21_,
      _mxarray0_);
    /*
     * checkinput(h,{'double'},{'nonsparse'},mfilename,'H',2);
     */
    mlfImages_private_checkinput(
      mclVa(*h, "h"),
      _mxarray23_,
      _mxarray18_,
      mxCreateString("imfilter"),
      _mxarray26_,
      _mxarray2_);
    /*
     * 
     * %Assign defaults
     * flags = 0;
     */
    mlfAssign(flags, _mxarray4_);
    /*
     * boundary = 0;  %Scalar value of zero
     */
    mlfAssign(boundary, _mxarray4_);
    /*
     * output = 'same';
     */
    mlfAssign(&output, _mxarray28_);
    /*
     * do_fcn = 'corr';
     */
    mlfAssign(&do_fcn, _mxarray30_);
    /*
     * 
     * allStrings = {'replicate', 'symmetric', 'circular', 'conv', 'corr', ...
     */
    mlfAssign(&allStrings, _mxarray32_);
    /*
     * 'full','same'};
     * 
     * for k = 1:length(varargin)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVa(varargin, "varargin"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray44_);
        } else {
            /*
             * if ischar(varargin{k})
             * string = checkstrs(varargin{k}, allStrings,...
             * mfilename, 'OPTION',k+2);
             * switch string
             * case {'replicate', 'symmetric', 'circular'}
             * boundary = string;
             * case {'full','same'}
             * output = string;
             * case {'conv','corr'}
             * do_fcn = string;
             * end
             * else
             * checkinput(varargin{k},{'numeric'},{'nonsparse'},mfilename,'OPTION',k+2);
             * boundary = varargin{k};
             * end %else
             * end
             */
            for (; ; ) {
                if (mlfTobool(
                      mclFeval(
                        mclValueVarargout(),
                        mlxIschar,
                        mlfIndexRef(
                          mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                        NULL))) {
                    mlfAssign(
                      &string,
                      mclFeval(
                        mclValueVarargout(),
                        mlxImages_private_checkstrs,
                        mlfIndexRef(
                          mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                        mclVv(allStrings, "allStrings"),
                        mxCreateString("imfilter"),
                        _mxarray45_,
                        mlfScalar(v_ + 2),
                        NULL));
                    {
                        mxArray * v_0 = mclInitialize(mclVv(string, "string"));
                        if (mclSwitchCompare(v_0, _mxarray47_)) {
                            mlfAssign(boundary, mclVv(string, "string"));
                        } else if (mclSwitchCompare(v_0, _mxarray49_)) {
                            mlfAssign(&output, mclVv(string, "string"));
                        } else if (mclSwitchCompare(v_0, _mxarray51_)) {
                            mlfAssign(&do_fcn, mclVv(string, "string"));
                        }
                        mxDestroyArray(v_0);
                    }
                } else {
                    mclFeval(
                      mclAnsVarargout(),
                      mlxImages_private_checkinput,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                      _mxarray53_,
                      _mxarray18_,
                      mxCreateString("imfilter"),
                      _mxarray45_,
                      mlfScalar(v_ + 2),
                      NULL);
                    mlfAssign(
                      boundary,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)));
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * if strcmp(output,'full')
     */
    if (mlfTobool(mlfStrcmp(mclVv(output, "output"), _mxarray42_))) {
        /*
         * flags = bitor(flags,8);
         */
        mlfAssign(flags, mlfBitor(mclVv(*flags, "flags"), _mxarray1_));
    /*
     * elseif strcmp(output,'same');
     */
    } else if (mlfTobool(mlfStrcmp(mclVv(output, "output"), _mxarray28_))) {
        /*
         * flags = bitor(flags,4);
         */
        mlfAssign(flags, mlfBitor(mclVv(*flags, "flags"), _mxarray3_));
    /*
     * end
     */
    }
    /*
     * 
     * if strcmp(do_fcn,'conv')
     */
    if (mlfTobool(mlfStrcmp(mclVv(do_fcn, "do_fcn"), _mxarray40_))) {
        /*
         * flags = bitor(flags,2);
         */
        mlfAssign(flags, mlfBitor(mclVv(*flags, "flags"), _mxarray2_));
    /*
     * elseif strcmp(do_fcn,'corr')
     */
    } else if (mlfTobool(mlfStrcmp(mclVv(do_fcn, "do_fcn"), _mxarray30_))) {
        /*
         * flags = bitor(flags,0);
         */
        mlfAssign(flags, mlfBitor(mclVv(*flags, "flags"), _mxarray4_));
    /*
     * end
     */
    }
    mclValidateOutput(a, 1, nargout_, "a", "imfilter/parse_inputs");
    mclValidateOutput(*h, 2, nargout_, "h", "imfilter/parse_inputs");
    mclValidateOutput(
      *boundary, 3, nargout_, "boundary", "imfilter/parse_inputs");
    mclValidateOutput(*flags, 4, nargout_, "flags", "imfilter/parse_inputs");
    mxDestroyArray(ans);
    mxDestroyArray(output);
    mxDestroyArray(do_fcn);
    mxDestroyArray(allStrings);
    mxDestroyArray(k);
    mxDestroyArray(string);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return a;
}
