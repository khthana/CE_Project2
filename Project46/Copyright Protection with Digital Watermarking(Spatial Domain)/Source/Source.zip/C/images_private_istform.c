/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[6] = { 's', 't', 'r', 'u', 'c', 't' };
static mxArray * _mxarray0_;

static mxChar _array3_[8] = { 'n', 'd', 'i', 'm', 's', '_', 'i', 'n' };
static mxArray * _mxarray2_;

static mxChar _array5_[9] = { 'n', 'd', 'i', 'm', 's', '_', 'o', 'u', 't' };
static mxArray * _mxarray4_;

static mxChar _array7_[11] = { 'f', 'o', 'r', 'w', 'a', 'r',
                               'd', '_', 'f', 'c', 'n' };
static mxArray * _mxarray6_;

static mxChar _array9_[11] = { 'i', 'n', 'v', 'e', 'r', 's',
                               'e', '_', 'f', 'c', 'n' };
static mxArray * _mxarray8_;

static mxChar _array11_[5] = { 't', 'd', 'a', 't', 'a' };
static mxArray * _mxarray10_;

void InitializeModule_images_private_istform(void) {
    _mxarray0_ = mclInitializeString(6, _array1_);
    _mxarray2_ = mclInitializeString(8, _array3_);
    _mxarray4_ = mclInitializeString(9, _array5_);
    _mxarray6_ = mclInitializeString(11, _array7_);
    _mxarray8_ = mclInitializeString(11, _array9_);
    _mxarray10_ = mclInitializeString(5, _array11_);
}

void TerminateModule_images_private_istform(void) {
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_istform(int nargout_, mxArray * t);

_mexLocalFunctionTable _local_function_table_images_private_istform
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_istform" contains the normal interface for
 * the "images/private/istform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\istform.m" (lines 1-17). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImages_private_istform(mxArray * t) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, t);
    q = Mimages_private_istform(nargout, t);
    mlfRestorePreviousContext(0, 1, t);
    return mlfReturnValue(q);
}

/*
 * The function "mlxImages_private_istform" contains the feval interface for
 * the "images/private/istform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\istform.m" (lines 1-17). The
 * feval function calls the implementation version of images/private/istform
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_istform(int nlhs,
                               mxArray * plhs[],
                               int nrhs,
                               mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/istform Line: 1 Col"
            "umn: 1 The function \"images/private/istform\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/istform Line: 1 Co"
            "lumn: 1 The function \"images/private/istform\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimages_private_istform(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_istform" is the implementation version of the
 * "images/private/istform" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\istform.m" (lines 1-17). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function q = istform(t)
 */
static mxArray * Mimages_private_istform(int nargout_, mxArray * t) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_istform);
    mxArray * q = NULL;
    mclCopyArray(&t);
    /*
     * %ISTFORM True for valid geometric transformation structure.
     * %   ISTFORM(T) returns 1 if R is a valid geometric transformation structure,
     * %   such as one created by MAKETFORM, and 0 otherwise.
     * % 
     * %   See also MAKETFORM, TFORMFWD, TFORMINV, FLIPTFORM.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.3 $ $Date: 2002/03/15 15:57:50 $
     * 
     * q = isa(t,'struct') ...
     */
    mlfAssign(
      &q,
      mclAnd(
        mclAnd(
          mclAnd(
            mclAnd(
              mclAnd(
                mlfIsa(mclVa(t, "t"), _mxarray0_),
                mlfIsfield(mclVa(t, "t"), _mxarray2_)),
              mlfIsfield(mclVa(t, "t"), _mxarray4_)),
            mlfIsfield(mclVa(t, "t"), _mxarray6_)),
          mlfIsfield(mclVa(t, "t"), _mxarray8_)),
        mlfIsfield(mclVa(t, "t"), _mxarray10_)));
    mclValidateOutput(q, 1, nargout_, "q", "images/private/istform");
    mxDestroyArray(t);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
    /*
     * & isfield(t,'ndims_in') ...
     * & isfield(t,'ndims_out') ...
     * & isfield(t,'forward_fcn') ...
     * & isfield(t,'inverse_fcn') ...
     * & isfield(t,'tdata');
     */
}
