/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "waitbar.h"
#include "mwservices.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
#include "title.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array3_[24] = { 'I', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't', 's', ' ',
                               'o', 'f', ' ', 't', 'y', 'p', 'e', ' ' };
static mxArray * _mxarray2_;

static mxChar _array5_[11] = { ' ', 'n', 'o', 't', ' ', 'v',
                               'a', 'l', 'i', 'd', '.' };
static mxArray * _mxarray4_;
static mxArray * _mxarray6_;

static mxChar _array8_[4] = { 'f', 'l', 'a', 't' };
static mxArray * _mxarray7_;

static mxChar _array10_[3] = { 'T', 'a', 'g' };
static mxArray * _mxarray9_;

static mxChar _array12_[10] = { 'T', 'M', 'W', 'W', 'a',
                                'i', 't', 'b', 'a', 'r' };
static mxArray * _mxarray11_;

static mxChar _array14_[7] = { 'W', 'a', 'i', 't', 'b', 'a', 'r' };
static mxArray * _mxarray13_;

static mxChar _array16_[26] = { 'I', 'n', 'p', 'u', 't', ' ', 'a', 'r', 'g',
                                'u', 'm', 'e', 'n', 't', 's', ' ', 'n', 'o',
                                't', ' ', 'v', 'a', 'l', 'i', 'd', '.' };
static mxArray * _mxarray15_;
static mxArray * _mxarray17_;

static mxChar _array19_[4] = { 'T', 'y', 'p', 'e' };
static mxArray * _mxarray18_;

static mxChar _array21_[5] = { 'p', 'a', 't', 'c', 'h' };
static mxArray * _mxarray20_;

static mxChar _array23_[4] = { 'l', 'i', 'n', 'e' };
static mxArray * _mxarray22_;

static mxChar _array25_[30] = { 'C', 'o', 'u', 'l', 'd', 'n', 0x0027,
                                't', ' ', 'f', 'i', 'n', 'd', ' ', 'w',
                                'a', 'i', 't', 'b', 'a', 'r', ' ', 'h',
                                'a', 'n', 'd', 'l', 'e', 's', '.' };
static mxArray * _mxarray24_;

static mxChar _array27_[5] = { 'X', 'D', 'a', 't', 'a' };
static mxArray * _mxarray26_;

static mxChar _array29_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray28_;

static mxChar _array31_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray30_;

static mxChar _array33_[5] = { 't', 'i', 't', 'l', 'e' };
static mxArray * _mxarray32_;

static mxChar _array35_[6] = { 's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray34_;

static mxChar _array37_[57] = { 'O', 'p', 't', 'i', 'o', 'n', 'a', 'l', ' ',
                                'i', 'n', 'i', 't', 'i', 'a', 'l', 'i', 'z',
                                'a', 't', 'i', 'o', 'n', ' ', 'a', 'r', 'g',
                                'u', 'm', 'e', 'n', 't', 's', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'p', 'a', 's',
                                's', 'e', 'd', ' ', 'i', 'n', ' ', 'p', 'a',
                                'i', 'r', 's' };
static mxArray * _mxarray36_;

static mxChar _array39_[5] = { 'U', 'n', 'i', 't', 's' };
static mxArray * _mxarray38_;

static mxChar _array41_[6] = { 'p', 'o', 'i', 'n', 't', 's' };
static mxArray * _mxarray40_;

static mxChar _array43_[10] = { 'S', 'c', 'r', 'e', 'e',
                                'n', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray42_;

static mxChar _array45_[19] = { 'F', 'a', 'c', 't', 'o', 'r', 'y',
                                'A', 'x', 'e', 's', 'F', 'o', 'n',
                                't', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray44_;
static mxArray * _mxarray46_;

static mxChar _array48_[19] = { 'S', 'c', 'r', 'e', 'e', 'n', 'P',
                                'i', 'x', 'e', 'l', 's', 'P', 'e',
                                'r', 'I', 'n', 'c', 'h' };
static mxArray * _mxarray47_;
static mxArray * _mxarray49_;
static mxArray * _mxarray50_;

static mxChar _array52_[10] = { 'B', 'u', 's', 'y', 'A',
                                'c', 't', 'i', 'o', 'n' };
static mxArray * _mxarray51_;

static mxChar _array54_[5] = { 'q', 'u', 'e', 'u', 'e' };
static mxArray * _mxarray53_;

static mxChar _array56_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray55_;

static mxChar _array58_[6] = { 'R', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray57_;

static mxChar _array60_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray59_;

static mxChar _array62_[9] = { 'C', 'r', 'e', 'a', 't', 'e', 'F', 'c', 'n' };
static mxArray * _mxarray61_;
static mxArray * _mxarray63_;

static mxChar _array65_[11] = { 'N', 'u', 'm', 'b', 'e', 'r',
                                'T', 'i', 't', 'l', 'e' };
static mxArray * _mxarray64_;

static mxChar _array67_[13] = { 'I', 'n', 't', 'e', 'g', 'e', 'r',
                                'H', 'a', 'n', 'd', 'l', 'e' };
static mxArray * _mxarray66_;

static mxChar _array69_[7] = { 'M', 'e', 'n', 'u', 'B', 'a', 'r' };
static mxArray * _mxarray68_;

static mxChar _array71_[4] = { 'n', 'o', 'n', 'e' };
static mxArray * _mxarray70_;

static mxChar _array73_[13] = { 'I', 'n', 't', 'e', 'r', 'r', 'u',
                                'p', 't', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray72_;

static mxChar _array75_[7] = { 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray74_;
static mxArray * _mxarray76_;
static mxArray * _mxarray77_;
static mxArray * _mxarray78_;

static mxChar _array80_[15] = { 'C', 'l', 'o', 's', 'e', 'R', 'e', 'q',
                                'u', 'e', 's', 't', 'F', 'c', 'n' };
static mxArray * _mxarray79_;

static mxChar _array82_[6] = { 'P', 'a', 'r', 'e', 'n', 't' };
static mxArray * _mxarray81_;

static mxChar _array84_[8] = { 'C', 'a', 'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray83_;

static mxChar _array86_[13] = { 'B', 'u', 't', 't', 'o', 'n', 'D',
                                'o', 'w', 'n', 'F', 'c', 'n' };
static mxArray * _mxarray85_;

static mxChar _array88_[6] = { 'E', 'n', 'a', 'b', 'l', 'e' };
static mxArray * _mxarray87_;

static mxChar _array90_[2] = { 'o', 'n' };
static mxArray * _mxarray89_;
static mxArray * _mxarray91_;
static mxArray * _mxarray92_;

static mxChar _array94_[6] = { 'S', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray93_;

static mxChar _array96_[6] = { 'C', 'a', 'n', 'c', 'e', 'l' };
static mxArray * _mxarray95_;

static mxChar _array98_[22] = { 'T', 'M', 'W', 'W', 'a', 'i', 't', 'b',
                                'a', 'r', 'C', 'a', 'n', 'c', 'e', 'l',
                                'B', 'u', 't', 't', 'o', 'n' };
static mxArray * _mxarray97_;

static mxChar _array100_[15] = { 'c', 'r', 'e', 'a', 't', 'e', 'c', 'a',
                                 'n', 'c', 'e', 'l', 'b', 't', 'n' };
static mxArray * _mxarray99_;

static mxChar _array102_[33] = { 'W', 'a', 'r', 'n', 'i', 'n', 'g', ':', ' ',
                                 'c', 'o', 'u', 'l', 'd', ' ', 'n', 'o', 't',
                                 ' ', 's', 'e', 't', ' ', 'p', 'r', 'o', 'p',
                                 'e', 'r', 't', 'y', ' ', 0x0027 };
static mxArray * _mxarray101_;

static mxChar _array104_[14] = { 0x0027, ' ', 'w', 'i', 't', 'h', ' ',
                                 'v', 'a', 'l', 'u', 'e', ' ', 0x0027 };
static mxArray * _mxarray103_;

static mxChar _array106_[1] = { 0x0027 };
static mxArray * _mxarray105_;

static double _array108_[4] = { .05, .3, .9, .2 };
static mxArray * _mxarray107_;
static mxArray * _mxarray109_;
static mxArray * _mxarray110_;

static mxChar _array112_[4] = { 'X', 'L', 'i', 'm' };
static mxArray * _mxarray111_;

static double _array114_[2] = { 0.0, 100.0 };
static mxArray * _mxarray113_;

static mxChar _array116_[4] = { 'Y', 'L', 'i', 'm' };
static mxArray * _mxarray115_;

static double _array118_[2] = { 0.0, 1.0 };
static mxArray * _mxarray117_;

static mxChar _array120_[3] = { 'B', 'o', 'x' };
static mxArray * _mxarray119_;

static mxChar _array122_[6] = { 'P', 'o', 'i', 'n', 't', 's' };
static mxArray * _mxarray121_;

static mxChar _array124_[8] = { 'F', 'o', 'n', 't', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray123_;

static mxChar _array126_[9] = { 'X', 'T', 'i', 'c', 'k', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray125_;

static mxChar _array128_[6] = { 'm', 'a', 'n', 'u', 'a', 'l' };
static mxArray * _mxarray127_;

static mxChar _array130_[9] = { 'Y', 'T', 'i', 'c', 'k', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray129_;

static mxChar _array132_[5] = { 'X', 'T', 'i', 'c', 'k' };
static mxArray * _mxarray131_;

static mxChar _array134_[5] = { 'Y', 'T', 'i', 'c', 'k' };
static mxArray * _mxarray133_;

static mxChar _array136_[14] = { 'X', 'T', 'i', 'c', 'k', 'L', 'a',
                                 'b', 'e', 'l', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray135_;

static mxChar _array138_[10] = { 'X', 'T', 'i', 'c', 'k',
                                 'L', 'a', 'b', 'e', 'l' };
static mxArray * _mxarray137_;

static mxChar _array140_[14] = { 'Y', 'T', 'i', 'c', 'k', 'L', 'a',
                                 'b', 'e', 'l', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray139_;

static mxChar _array142_[10] = { 'Y', 'T', 'i', 'c', 'k',
                                 'L', 'a', 'b', 'e', 'l' };
static mxArray * _mxarray141_;

static mxChar _array144_[6] = { 'E', 'x', 't', 'e', 'n', 't' };
static mxArray * _mxarray143_;
static mxArray * _mxarray145_;
static mxArray * _mxarray146_;
static mxArray * _mxarray147_;
static mxArray * _mxarray148_;

static double _array150_[2] = { 1.0, 3.0 };
static mxArray * _mxarray149_;

static double _array152_[4] = { 0.0, 0.0, 1.0, 1.0 };
static mxArray * _mxarray151_;

static double _array154_[5] = { 100.0, 0.0, 0.0, 100.0, 100.0 };
static mxArray * _mxarray153_;

static double _array156_[5] = { 0.0, 0.0, 1.0, 1.0, 0.0 };
static mxArray * _mxarray155_;

static mxChar _array158_[1] = { 'r' };
static mxArray * _mxarray157_;

static mxChar _array160_[9] = { 'E', 'd', 'g', 'e', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray159_;

static mxChar _array162_[9] = { 'E', 'r', 'a', 's', 'e', 'M', 'o', 'd', 'e' };
static mxArray * _mxarray161_;

static mxChar _array164_[5] = { 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray163_;

static mxChar _array166_[6] = { 'X', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray165_;

static mxChar _array168_[16] = { 'H', 'a', 'n', 'd', 'l', 'e', 'V', 'i',
                                 's', 'i', 'b', 'i', 'l', 'i', 't', 'y' };
static mxArray * _mxarray167_;

static mxChar _array170_[8] = { 'c', 'a', 'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray169_;

static mxChar _array172_[7] = { 'v', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray171_;

void InitializeModule_waitbar(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeString(24, _array3_);
    _mxarray4_ = mclInitializeString(11, _array5_);
    _mxarray6_ = mclInitializeDouble(0.0);
    _mxarray7_ = mclInitializeString(4, _array8_);
    _mxarray9_ = mclInitializeString(3, _array10_);
    _mxarray11_ = mclInitializeString(10, _array12_);
    _mxarray13_ = mclInitializeString(7, _array14_);
    _mxarray15_ = mclInitializeString(26, _array16_);
    _mxarray17_ = mclInitializeDouble(100.0);
    _mxarray18_ = mclInitializeString(4, _array19_);
    _mxarray20_ = mclInitializeString(5, _array21_);
    _mxarray22_ = mclInitializeString(4, _array23_);
    _mxarray24_ = mclInitializeString(30, _array25_);
    _mxarray26_ = mclInitializeString(5, _array27_);
    _mxarray28_ = mclInitializeString(4, _array29_);
    _mxarray30_ = mclInitializeString(4, _array31_);
    _mxarray32_ = mclInitializeString(5, _array33_);
    _mxarray34_ = mclInitializeString(6, _array35_);
    _mxarray36_ = mclInitializeString(57, _array37_);
    _mxarray38_ = mclInitializeString(5, _array39_);
    _mxarray40_ = mclInitializeString(6, _array41_);
    _mxarray42_ = mclInitializeString(10, _array43_);
    _mxarray44_ = mclInitializeString(19, _array45_);
    _mxarray46_ = mclInitializeDouble(72.0);
    _mxarray47_ = mclInitializeString(19, _array48_);
    _mxarray49_ = mclInitializeDouble(360.0);
    _mxarray50_ = mclInitializeDouble(75.0);
    _mxarray51_ = mclInitializeString(10, _array52_);
    _mxarray53_ = mclInitializeString(5, _array54_);
    _mxarray55_ = mclInitializeString(8, _array56_);
    _mxarray57_ = mclInitializeString(6, _array58_);
    _mxarray59_ = mclInitializeString(3, _array60_);
    _mxarray61_ = mclInitializeString(9, _array62_);
    _mxarray63_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray64_ = mclInitializeString(11, _array65_);
    _mxarray66_ = mclInitializeString(13, _array67_);
    _mxarray68_ = mclInitializeString(7, _array69_);
    _mxarray70_ = mclInitializeString(4, _array71_);
    _mxarray72_ = mclInitializeString(13, _array73_);
    _mxarray74_ = mclInitializeString(7, _array75_);
    _mxarray76_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray77_ = mclInitializeDouble(23.0);
    _mxarray78_ = mclInitializeDouble(60.0);
    _mxarray79_ = mclInitializeString(15, _array80_);
    _mxarray81_ = mclInitializeString(6, _array82_);
    _mxarray83_ = mclInitializeString(8, _array84_);
    _mxarray85_ = mclInitializeString(13, _array86_);
    _mxarray87_ = mclInitializeString(6, _array88_);
    _mxarray89_ = mclInitializeString(2, _array90_);
    _mxarray91_ = mclInitializeDouble(1.4);
    _mxarray92_ = mclInitializeDouble(7.0);
    _mxarray93_ = mclInitializeString(6, _array94_);
    _mxarray95_ = mclInitializeString(6, _array96_);
    _mxarray97_ = mclInitializeString(22, _array98_);
    _mxarray99_ = mclInitializeString(15, _array100_);
    _mxarray101_ = mclInitializeString(33, _array102_);
    _mxarray103_ = mclInitializeString(14, _array104_);
    _mxarray105_ = mclInitializeString(1, _array106_);
    _mxarray107_ = mclInitializeDoubleVector(1, 4, _array108_);
    _mxarray109_ = mclInitializeDouble(3.0);
    _mxarray110_ = mclInitializeDouble(4.0);
    _mxarray111_ = mclInitializeString(4, _array112_);
    _mxarray113_ = mclInitializeDoubleVector(1, 2, _array114_);
    _mxarray115_ = mclInitializeString(4, _array116_);
    _mxarray117_ = mclInitializeDoubleVector(1, 2, _array118_);
    _mxarray119_ = mclInitializeString(3, _array120_);
    _mxarray121_ = mclInitializeString(6, _array122_);
    _mxarray123_ = mclInitializeString(8, _array124_);
    _mxarray125_ = mclInitializeString(9, _array126_);
    _mxarray127_ = mclInitializeString(6, _array128_);
    _mxarray129_ = mclInitializeString(9, _array130_);
    _mxarray131_ = mclInitializeString(5, _array132_);
    _mxarray133_ = mclInitializeString(5, _array134_);
    _mxarray135_ = mclInitializeString(14, _array136_);
    _mxarray137_ = mclInitializeString(10, _array138_);
    _mxarray139_ = mclInitializeString(14, _array140_);
    _mxarray141_ = mclInitializeString(10, _array142_);
    _mxarray143_ = mclInitializeString(6, _array144_);
    _mxarray145_ = mclInitializeDouble(5.0);
    _mxarray146_ = mclInitializeLogical(true);
    _mxarray147_ = mclInitializeLogical(false);
    _mxarray148_ = mclInitializeDouble(1.1);
    _mxarray149_ = mclInitializeDoubleVector(1, 2, _array150_);
    _mxarray151_ = mclInitializeDoubleVector(1, 4, _array152_);
    _mxarray153_ = mclInitializeDoubleVector(1, 5, _array154_);
    _mxarray155_ = mclInitializeDoubleVector(1, 5, _array156_);
    _mxarray157_ = mclInitializeString(1, _array158_);
    _mxarray159_ = mclInitializeString(9, _array160_);
    _mxarray161_ = mclInitializeString(9, _array162_);
    _mxarray163_ = mclInitializeString(5, _array164_);
    _mxarray165_ = mclInitializeString(6, _array166_);
    _mxarray167_ = mclInitializeString(16, _array168_);
    _mxarray169_ = mclInitializeString(8, _array170_);
    _mxarray171_ = mclInitializeString(7, _array172_);
}

void TerminateModule_waitbar(void) {
    mxDestroyArray(_mxarray171_);
    mxDestroyArray(_mxarray169_);
    mxDestroyArray(_mxarray167_);
    mxDestroyArray(_mxarray165_);
    mxDestroyArray(_mxarray163_);
    mxDestroyArray(_mxarray161_);
    mxDestroyArray(_mxarray159_);
    mxDestroyArray(_mxarray157_);
    mxDestroyArray(_mxarray155_);
    mxDestroyArray(_mxarray153_);
    mxDestroyArray(_mxarray151_);
    mxDestroyArray(_mxarray149_);
    mxDestroyArray(_mxarray148_);
    mxDestroyArray(_mxarray147_);
    mxDestroyArray(_mxarray146_);
    mxDestroyArray(_mxarray145_);
    mxDestroyArray(_mxarray143_);
    mxDestroyArray(_mxarray141_);
    mxDestroyArray(_mxarray139_);
    mxDestroyArray(_mxarray137_);
    mxDestroyArray(_mxarray135_);
    mxDestroyArray(_mxarray133_);
    mxDestroyArray(_mxarray131_);
    mxDestroyArray(_mxarray129_);
    mxDestroyArray(_mxarray127_);
    mxDestroyArray(_mxarray125_);
    mxDestroyArray(_mxarray123_);
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray119_);
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray115_);
    mxDestroyArray(_mxarray113_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray110_);
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mwaitbar(int nargout_,
                          mxArray * x,
                          mxArray * whichbar,
                          mxArray * varargin);

_mexLocalFunctionTable _local_function_table_waitbar
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNWaitbar" contains the nargout interface for the "waitbar"
 * M-function from file "k:\matlab6p5\toolbox\matlab\uitools\waitbar.m" (lines
 * 1-233). This interface is only produced if the M-function uses the special
 * variable "nargout". The nargout interface allows the number of requested
 * outputs to be specified via the nargout argument, as opposed to the normal
 * interface which dynamically calculates the number of outputs based on the
 * number of non-NULL inputs it receives. This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfNWaitbar(int nargout, mxArray * x, mxArray * whichbar, ...) {
    mxArray * varargin = NULL;
    mxArray * fout = NULL;
    mlfVarargin(&varargin, whichbar, 0);
    mlfEnterNewContext(0, -3, x, whichbar, varargin);
    fout = Mwaitbar(nargout, x, whichbar, varargin);
    mlfRestorePreviousContext(0, 2, x, whichbar);
    mxDestroyArray(varargin);
    return mlfReturnValue(fout);
}

/*
 * The function "mlfWaitbar" contains the normal interface for the "waitbar"
 * M-function from file "k:\matlab6p5\toolbox\matlab\uitools\waitbar.m" (lines
 * 1-233). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfWaitbar(mxArray * x, mxArray * whichbar, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * fout = NULL;
    mlfVarargin(&varargin, whichbar, 0);
    mlfEnterNewContext(0, -3, x, whichbar, varargin);
    fout = Mwaitbar(nargout, x, whichbar, varargin);
    mlfRestorePreviousContext(0, 2, x, whichbar);
    mxDestroyArray(varargin);
    return mlfReturnValue(fout);
}

/*
 * The function "mlfVWaitbar" contains the void interface for the "waitbar"
 * M-function from file "k:\matlab6p5\toolbox\matlab\uitools\waitbar.m" (lines
 * 1-233). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVWaitbar(mxArray * x, mxArray * whichbar, ...) {
    mxArray * varargin = NULL;
    mxArray * fout = NULL;
    mlfVarargin(&varargin, whichbar, 0);
    mlfEnterNewContext(0, -3, x, whichbar, varargin);
    fout = Mwaitbar(0, x, whichbar, varargin);
    mlfRestorePreviousContext(0, 2, x, whichbar);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxWaitbar" contains the feval interface for the "waitbar"
 * M-function from file "k:\matlab6p5\toolbox\matlab\uitools\waitbar.m" (lines
 * 1-233). The feval function calls the implementation version of waitbar
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxWaitbar(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: waitbar Line: 1 Column: "
            "1 The function \"waitbar\" was called with mor"
            "e than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mprhs[2] = NULL;
    mlfAssign(&mprhs[2], mclCreateVararginCell(nrhs - 2, prhs + 2));
    mplhs[0] = Mwaitbar(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[2]);
}

/*
 * The function "Mwaitbar" is the implementation version of the "waitbar"
 * M-function from file "k:\matlab6p5\toolbox\matlab\uitools\waitbar.m" (lines
 * 1-233). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function fout = waitbar(x,whichbar, varargin)
 */
static mxArray * Mwaitbar(int nargout_,
                          mxArray * x,
                          mxArray * whichbar,
                          mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_waitbar);
    int nargin_ = mclNargin(-3, x, whichbar, varargin, NULL);
    mxArray * fout = NULL;
    mxArray * yline = NULL;
    mxArray * ypatch = NULL;
    mxArray * figPosDirty = NULL;
    mxArray * titleHeight = NULL;
    mxArray * tExtent = NULL;
    mxArray * oldTitleUnits = NULL;
    mxArray * tHandle = NULL;
    mxArray * h = NULL;
    mxArray * axPos = NULL;
    mxArray * axNorm = NULL;
    mxArray * cancelButt = NULL;
    mxArray * callbackFcn = NULL;
    mxArray * newPos = NULL;
    mxArray * cancelBtnWidth = NULL;
    mxArray * cancelBtnHeight = NULL;
    mxArray * ii = NULL;
    mxArray * cancelBtnCreated = NULL;
    mxArray * valueList = NULL;
    mxArray * propList = NULL;
    mxArray * pos = NULL;
    mxArray * height = NULL;
    mxArray * width = NULL;
    mxArray * pointsPerPixel = NULL;
    mxArray * axFontSize = NULL;
    mxArray * screenSize = NULL;
    mxArray * oldRootUnits = NULL;
    mxArray * vertMargin = NULL;
    mxArray * hTitle = NULL;
    mxArray * hAxes = NULL;
    mxArray * xline = NULL;
    mxArray * xpatch = NULL;
    mxArray * l = NULL;
    mxArray * p = NULL;
    mxArray * ans = NULL;
    mxArray * f = NULL;
    mxArray * name = NULL;
    mxArray * type = NULL;
    mclCopyArray(&x);
    mclCopyArray(&whichbar);
    mclCopyArray(&varargin);
    /*
     * %WAITBAR Display wait bar.
     * %   H = WAITBAR(X,'title', property, value, property, value, ...) 
     * %   creates and displays a waitbar of fractional length X.  The 
     * %   handle to the waitbar figure is returned in H.
     * %   X should be between 0 and 1.  Optional arguments property and 
     * %   value allow to set corresponding waitbar figure properties.
     * %   Property can also be an action keyword 'CreateCancelBtn', in 
     * %   which case a cancel button will be added to the figure, and 
     * %   the passed value string will be executed upon clicking on the 
     * %   cancel button or the close figure button.
     * %
     * %   WAITBAR(X) will set the length of the bar in the most recently
     * %   created waitbar window to the fractional length X.
     * %
     * %   WAITBAR(X,H) will set the length of the bar in waitbar H
     * %   to the fractional length X.
     * %
     * %   WAITBAR(X,H,'updated title') will update the title text in
     * %   the waitbar figure, in addition to setting the fractional
     * %   length to X.
     * %
     * %   WAITBAR is typically used inside a FOR loop that performs a 
     * %   lengthy computation.  A sample usage is shown below:
     * %
     * %       h = waitbar(0,'Please wait...');
     * %       for i=1:100,
     * %           % computation here %
     * %           waitbar(i/100,h)
     * %       end
     * %       close(h)
     * 
     * %   Clay M. Thompson 11-9-92
     * %   Vlad Kolesnikov  06-7-99
     * %   Copyright 1984-2002 The MathWorks, Inc.
     * %   $Revision: 1.23 $  $Date: 2002/04/09 01:36:16 $
     * 
     * if nargin>=2
     */
    if (nargin_ >= 2) {
        /*
         * if ischar(whichbar)
         */
        if (mlfTobool(mlfIschar(mclVa(whichbar, "whichbar")))) {
            /*
             * type=2; %we are initializing
             */
            mlfAssign(&type, _mxarray0_);
            /*
             * name=whichbar;
             */
            mlfAssign(&name, mclVa(whichbar, "whichbar"));
        /*
         * elseif isnumeric(whichbar)
         */
        } else if (mlfTobool(mlfIsnumeric(mclVa(whichbar, "whichbar")))) {
            /*
             * type=1; %we are updating, given a handle
             */
            mlfAssign(&type, _mxarray1_);
            /*
             * f=whichbar;
             */
            mlfAssign(&f, mclVa(whichbar, "whichbar"));
        /*
         * else
         */
        } else {
            /*
             * error(['Input arguments of type ' class(whichbar) ' not valid.'])
             */
            mlfError(
              mlfHorzcat(
                _mxarray2_,
                mlfClassName(mclVa(whichbar, "whichbar"), NULL),
                _mxarray4_,
                NULL),
              NULL);
        /*
         * end
         */
        }
    /*
     * elseif nargin==1
     */
    } else if (nargin_ == 1) {
        /*
         * f = findobj(allchild(0),'flat','Tag','TMWWaitbar');
         */
        mlfAssign(
          &f,
          mlfFindobj(
            mlfAllchild(_mxarray6_),
            _mxarray7_,
            _mxarray9_,
            _mxarray11_,
            NULL));
        /*
         * 
         * if isempty(f)
         */
        if (mlfTobool(mlfIsempty(mclVv(f, "f")))) {
            /*
             * type=2;
             */
            mlfAssign(&type, _mxarray0_);
            /*
             * name='Waitbar';
             */
            mlfAssign(&name, _mxarray13_);
        /*
         * else
         */
        } else {
            /*
             * type=1;
             */
            mlfAssign(&type, _mxarray1_);
            /*
             * f=f(1);
             */
            mlfAssign(&f, mclIntArrayRef1(mclVv(f, "f"), 1));
        /*
         * end   
         */
        }
    /*
     * else
     */
    } else {
        /*
         * error('Input arguments not valid.');
         */
        mlfError(_mxarray15_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * x = max(0,min(100*x,100));
     */
    mlfAssign(
      &x,
      mlfMax(
        NULL,
        _mxarray6_,
        mlfMin(NULL, mclMtimes(_mxarray17_, mclVa(x, "x")), _mxarray17_, NULL),
        NULL));
    /*
     * 
     * switch type
     */
    {
        mxArray * v_ = mclInitialize(mclVv(type, "type"));
        if (mclSwitchCompare(v_, _mxarray1_)) {
            /*
             * case 1,  % waitbar(x)    update
             * p = findobj(f,'Type','patch');
             */
            mlfAssign(
              &p, mlfFindobj(mclVv(f, "f"), _mxarray18_, _mxarray20_, NULL));
            /*
             * l = findobj(f,'Type','line');
             */
            mlfAssign(
              &l, mlfFindobj(mclVv(f, "f"), _mxarray18_, _mxarray22_, NULL));
            /*
             * if isempty(f) | isempty(p) | isempty(l), 
             */
            {
                mxArray * a_ = mclInitialize(mlfIsempty(mclVv(f, "f")));
                if (mlfTobool(a_)) {
                    mlfAssign(&a_, mlfScalar(1));
                } else {
                    mlfAssign(&a_, mclOr(a_, mlfIsempty(mclVv(p, "p"))));
                }
                if (mlfTobool(a_)
                    || mlfTobool(mclOr(a_, mlfIsempty(mclVv(l, "l"))))) {
                    mxDestroyArray(a_);
                    /*
                     * error('Couldn''t find waitbar handles.'); 
                     */
                    mlfError(_mxarray24_, NULL);
                } else {
                    mxDestroyArray(a_);
                }
            /*
             * end
             */
            }
            /*
             * xpatch = get(p,'XData');
             */
            mlfAssign(&xpatch, mlfNGet(1, mclVv(p, "p"), _mxarray26_, NULL));
            /*
             * xpatch = [0 x x 0];
             */
            mlfAssign(
              &xpatch,
              mlfHorzcat(
                _mxarray6_, mclVa(x, "x"), mclVa(x, "x"), _mxarray6_, NULL));
            /*
             * set(p,'XData',xpatch)
             */
            mclPrintAns(
              &ans,
              mlfNSet(
                0, mclVv(p, "p"), _mxarray26_, mclVv(xpatch, "xpatch"), NULL));
            /*
             * xline = get(l,'XData');
             */
            mlfAssign(&xline, mlfNGet(1, mclVv(l, "l"), _mxarray26_, NULL));
            /*
             * set(l,'XData',xline);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0, mclVv(l, "l"), _mxarray26_, mclVv(xline, "xline"), NULL));
            /*
             * 
             * if nargin>2,
             */
            if (nargin_ > 2) {
                /*
                 * % Update waitbar title:
                 * hAxes = findobj(f,'type','axes');
                 */
                mlfAssign(
                  &hAxes,
                  mlfFindobj(mclVv(f, "f"), _mxarray28_, _mxarray30_, NULL));
                /*
                 * hTitle = get(hAxes,'title');
                 */
                mlfAssign(
                  &hTitle,
                  mlfNGet(1, mclVv(hAxes, "hAxes"), _mxarray32_, NULL));
                /*
                 * set(hTitle,'string',varargin{1});
                 */
                mclAssignAns(
                  &ans,
                  mlfNSet(
                    0,
                    mclVv(hTitle, "hTitle"),
                    _mxarray34_,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                    NULL));
            /*
             * end
             */
            }
        /*
         * 
         * case 2,  % waitbar(x,name)  initialize
         */
        } else if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * vertMargin = 0;
             */
            mlfAssign(&vertMargin, _mxarray6_);
            /*
             * if nargin > 2,
             */
            if (nargin_ > 2) {
                /*
                 * % we have optional arguments: property-value pairs
                 * if rem (nargin, 2 ) ~= 0
                 */
                if (mclNeBool(
                      mlfScalar(svDoubleScalarRem((double) nargin_, 2.0)),
                      _mxarray6_)) {
                    /*
                     * error( 'Optional initialization arguments must be passed in pairs' );
                     */
                    mlfError(_mxarray36_, NULL);
                /*
                 * end
                 */
                }
            /*
             * end
             */
            }
            /*
             * 
             * oldRootUnits = get(0,'Units');
             */
            mlfAssign(&oldRootUnits, mlfNGet(1, _mxarray6_, _mxarray38_, NULL));
            /*
             * 
             * set(0, 'Units', 'points');
             */
            mclAssignAns(
              &ans, mlfNSet(0, _mxarray6_, _mxarray38_, _mxarray40_, NULL));
            /*
             * screenSize = get(0,'ScreenSize');
             */
            mlfAssign(&screenSize, mlfNGet(1, _mxarray6_, _mxarray42_, NULL));
            /*
             * 
             * axFontSize=get(0,'FactoryAxesFontSize');
             */
            mlfAssign(&axFontSize, mlfNGet(1, _mxarray6_, _mxarray44_, NULL));
            /*
             * 
             * pointsPerPixel = 72/get(0,'ScreenPixelsPerInch');
             */
            mlfAssign(
              &pointsPerPixel,
              mclMrdivide(
                _mxarray46_, mlfNGet(1, _mxarray6_, _mxarray47_, NULL)));
            /*
             * 
             * width = 360 * pointsPerPixel;
             */
            mlfAssign(
              &width,
              mclMtimes(_mxarray49_, mclVv(pointsPerPixel, "pointsPerPixel")));
            /*
             * height = 75 * pointsPerPixel;
             */
            mlfAssign(
              &height,
              mclMtimes(_mxarray50_, mclVv(pointsPerPixel, "pointsPerPixel")));
            /*
             * pos = [screenSize(3)/2-width/2 screenSize(4)/2-height/2 width height];
             */
            mlfAssign(
              &pos,
              mlfHorzcat(
                mclMinus(
                  mclMrdivide(
                    mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
                    _mxarray0_),
                  mclMrdivide(mclVv(width, "width"), _mxarray0_)),
                mclMinus(
                  mclMrdivide(
                    mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
                    _mxarray0_),
                  mclMrdivide(mclVv(height, "height"), _mxarray0_)),
                mclVv(width, "width"),
                mclVv(height, "height"),
                NULL));
            /*
             * 
             * f = figure(...
             */
            mlfAssign(
              &f,
              mlfNFigure(
                1,
                _mxarray38_,
                _mxarray40_,
                _mxarray51_,
                _mxarray53_,
                _mxarray55_,
                mclVv(pos, "pos"),
                _mxarray57_,
                _mxarray59_,
                _mxarray61_,
                _mxarray63_,
                _mxarray64_,
                _mxarray59_,
                _mxarray66_,
                _mxarray59_,
                _mxarray68_,
                _mxarray70_,
                _mxarray9_,
                _mxarray11_,
                _mxarray72_,
                _mxarray59_,
                _mxarray74_,
                _mxarray59_,
                NULL));
            /*
             * 'Units', 'points', ...
             * 'BusyAction', 'queue', ...
             * 'Position', pos, ...
             * 'Resize','off', ...
             * 'CreateFcn','', ...
             * 'NumberTitle','off', ...
             * 'IntegerHandle','off', ...
             * 'MenuBar', 'none', ...
             * 'Tag','TMWWaitbar',...
             * 'Interruptible', 'off', ...
             * 'Visible','off');
             * 
             * %%%%%%%%%%%%%%%%%%%%%
             * % set figure properties as passed to the fcn
             * % pay special attention to the 'cancel' request
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * if nargin > 2,
             */
            if (nargin_ > 2) {
                /*
                 * propList = varargin(1:2:end);
                 */
                mlfAssign(
                  &propList,
                  mclArrayRef1(
                    mclVa(varargin, "varargin"),
                    mlfColon(
                      _mxarray1_,
                      _mxarray0_,
                      mlfEnd(
                        mclVa(varargin, "varargin"), _mxarray1_, _mxarray1_))));
                /*
                 * valueList = varargin(2:2:end);
                 */
                mlfAssign(
                  &valueList,
                  mclArrayRef1(
                    mclVa(varargin, "varargin"),
                    mlfColon(
                      _mxarray0_,
                      _mxarray0_,
                      mlfEnd(
                        mclVa(varargin, "varargin"), _mxarray1_, _mxarray1_))));
                /*
                 * cancelBtnCreated = 0;
                 */
                mlfAssign(&cancelBtnCreated, _mxarray6_);
                /*
                 * for ii = 1:length( propList )
                 */
                {
                    int v_0 = mclForIntStart(1);
                    int e_ = mclLengthInt(mclVv(propList, "propList"));
                    if (v_0 > e_) {
                        mlfAssign(&ii, _mxarray76_);
                    } else {
                        /*
                         * try
                         * if strcmp(lower(propList{ii}), 'createcancelbtn' ) & ~cancelBtnCreated
                         * cancelBtnHeight = 23 * pointsPerPixel;
                         * cancelBtnWidth = 60 * pointsPerPixel;
                         * newPos = pos;
                         * vertMargin = vertMargin + cancelBtnHeight;
                         * newPos(4) = newPos(4)+vertMargin;
                         * callbackFcn = [valueList{ii}];
                         * set( f, 'Position', newPos, 'CloseRequestFcn', callbackFcn );
                         * cancelButt = uicontrol('Parent',f, ...
                         * 'Units','points', ...
                         * 'Callback',callbackFcn, ...
                         * 'ButtonDownFcn', callbackFcn, ...
                         * 'Enable','on', ...
                         * 'Interruptible','off', ...
                         * 'Position', [pos(3)-cancelBtnWidth*1.4, 7,  ...
                         * cancelBtnWidth, cancelBtnHeight], ...
                         * 'String','Cancel', ...
                         * 'Tag','TMWWaitbarCancelButton');
                         * cancelBtnCreated = 1;
                         * else
                         * % simply set the prop/value pair of the figure
                         * set( f, propList{ii}, valueList{ii});
                         * end
                         * catch
                         * disp ( ['Warning: could not set property ''' propList{ii} ''' with value ''' num2str(valueList{ii}) '''' ] );
                         * end
                         * end
                         */
                        for (; ; ) {
                            mlfTry {
                                mxArray * a_
                                  = mclInitialize(
                                      mlfStrcmp(
                                        mclFeval(
                                          mclValueVarargout(),
                                          mlxLower,
                                          mlfIndexRef(
                                            mclVv(propList, "propList"),
                                            "{?}",
                                            mlfScalar(v_0)),
                                          NULL),
                                        _mxarray99_));
                                if (mlfTobool(a_)
                                    && mlfTobool(
                                         mclAnd(
                                           a_,
                                           mclNot(
                                             mclVv(
                                               cancelBtnCreated,
                                               "cancelBtnCreated"))))) {
                                    mxDestroyArray(a_);
                                    mlfAssign(
                                      &cancelBtnHeight,
                                      mclMtimes(
                                        _mxarray77_,
                                        mclVv(
                                          pointsPerPixel, "pointsPerPixel")));
                                    mlfAssign(
                                      &cancelBtnWidth,
                                      mclMtimes(
                                        _mxarray78_,
                                        mclVv(
                                          pointsPerPixel, "pointsPerPixel")));
                                    mlfAssign(&newPos, mclVv(pos, "pos"));
                                    mlfAssign(
                                      &vertMargin,
                                      mclPlus(
                                        mclVv(vertMargin, "vertMargin"),
                                        mclVv(
                                          cancelBtnHeight, "cancelBtnHeight")));
                                    mclIntArrayAssign1(
                                      &newPos,
                                      mclPlus(
                                        mclIntArrayRef1(
                                          mclVv(newPos, "newPos"), 4),
                                        mclVv(vertMargin, "vertMargin")),
                                      4);
                                    mlfAssign(
                                      &callbackFcn,
                                      mlfHorzcat(
                                        mlfIndexRef(
                                          mclVv(valueList, "valueList"),
                                          "{?}",
                                          mlfScalar(v_0)),
                                        NULL));
                                    mclAssignAns(
                                      &ans,
                                      mlfNSet(
                                        0,
                                        mclVv(f, "f"),
                                        _mxarray55_,
                                        mclVv(newPos, "newPos"),
                                        _mxarray79_,
                                        mclVv(callbackFcn, "callbackFcn"),
                                        NULL));
                                    mlfAssign(
                                      &cancelButt,
                                      mlfNUicontrol(
                                        1,
                                        _mxarray81_,
                                        mclVv(f, "f"),
                                        _mxarray38_,
                                        _mxarray40_,
                                        _mxarray83_,
                                        mclVv(callbackFcn, "callbackFcn"),
                                        _mxarray85_,
                                        mclVv(callbackFcn, "callbackFcn"),
                                        _mxarray87_,
                                        _mxarray89_,
                                        _mxarray72_,
                                        _mxarray59_,
                                        _mxarray55_,
                                        mlfHorzcat(
                                          mclMinus(
                                            mclIntArrayRef1(
                                              mclVv(pos, "pos"), 3),
                                            mclMtimes(
                                              mclVv(
                                                cancelBtnWidth,
                                                "cancelBtnWidth"),
                                              _mxarray91_)),
                                          _mxarray92_,
                                          mclVv(
                                            cancelBtnWidth, "cancelBtnWidth"),
                                          mclVv(
                                            cancelBtnHeight, "cancelBtnHeight"),
                                          NULL),
                                        _mxarray93_,
                                        _mxarray95_,
                                        _mxarray9_,
                                        _mxarray97_,
                                        NULL));
                                    mlfAssign(&cancelBtnCreated, _mxarray1_);
                                } else {
                                    mxDestroyArray(a_);
                                    mclAssignAns(
                                      &ans,
                                      mlfNSet(
                                        0,
                                        mclVv(f, "f"),
                                        mlfIndexRef(
                                          mclVv(propList, "propList"),
                                          "{?}",
                                          mlfScalar(v_0)),
                                        mlfIndexRef(
                                          mclVv(valueList, "valueList"),
                                          "{?}",
                                          mlfScalar(v_0)),
                                        NULL));
                                }
                            } mlfCatch {
                                mlfDisp(
                                  mlfHorzcat(
                                    _mxarray101_,
                                    mlfIndexRef(
                                      mclVv(propList, "propList"),
                                      "{?}",
                                      mlfScalar(v_0)),
                                    _mxarray103_,
                                    mclFeval(
                                      mclValueVarargout(),
                                      mlxNum2str,
                                      mlfIndexRef(
                                        mclVv(valueList, "valueList"),
                                        "{?}",
                                        mlfScalar(v_0)),
                                      NULL),
                                    _mxarray105_,
                                    NULL));
                            } mlfEndCatch
                            if (v_0 == e_) {
                                break;
                            }
                            ++v_0;
                        }
                        mlfAssign(&ii, mlfScalar(v_0));
                    }
                }
            /*
             * end  
             */
            }
            /*
             * 
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
             * 
             * 
             * colormap([]);
             */
            mclAssignAns(&ans, mlfNColormap(0, _mxarray76_, NULL));
            /*
             * 
             * axNorm=[.05 .3 .9 .2];
             */
            mlfAssign(&axNorm, _mxarray107_);
            /*
             * axPos=axNorm.*[pos(3:4),pos(3:4)] + [0 vertMargin 0 0];
             */
            mlfAssign(
              &axPos,
              mclPlus(
                mclTimes(
                  mclVv(axNorm, "axNorm"),
                  mlfHorzcat(
                    mclArrayRef1(
                      mclVv(pos, "pos"),
                      mlfColon(_mxarray109_, _mxarray110_, NULL)),
                    mclArrayRef1(
                      mclVv(pos, "pos"),
                      mlfColon(_mxarray109_, _mxarray110_, NULL)),
                    NULL)),
                mlfHorzcat(
                  _mxarray6_,
                  mclVv(vertMargin, "vertMargin"),
                  _mxarray6_,
                  _mxarray6_,
                  NULL)));
            /*
             * 
             * h = axes('XLim',[0 100],...
             */
            mlfAssign(
              &h,
              mlfNAxes(
                1,
                _mxarray111_,
                _mxarray113_,
                _mxarray115_,
                _mxarray117_,
                _mxarray119_,
                _mxarray89_,
                _mxarray38_,
                _mxarray121_,
                _mxarray123_,
                mclVv(axFontSize, "axFontSize"),
                _mxarray55_,
                mclVv(axPos, "axPos"),
                _mxarray125_,
                _mxarray127_,
                _mxarray129_,
                _mxarray127_,
                _mxarray131_,
                _mxarray76_,
                _mxarray133_,
                _mxarray76_,
                _mxarray135_,
                _mxarray127_,
                _mxarray137_,
                _mxarray76_,
                _mxarray139_,
                _mxarray127_,
                _mxarray141_,
                _mxarray76_,
                NULL));
            /*
             * 'YLim',[0 1],...
             * 'Box','on', ...
             * 'Units','Points',...
             * 'FontSize', axFontSize,...
             * 'Position',axPos,...
             * 'XTickMode','manual',...
             * 'YTickMode','manual',...
             * 'XTick',[],...
             * 'YTick',[],...
             * 'XTickLabelMode','manual',...
             * 'XTickLabel',[],...
             * 'YTickLabelMode','manual',...
             * 'YTickLabel',[]);
             * 
             * tHandle=title(name);
             */
            mlfAssign(&tHandle, mlfNTitle(1, mclVv(name, "name"), NULL));
            /*
             * tHandle=get(h,'title');
             */
            mlfAssign(&tHandle, mlfNGet(1, mclVv(h, "h"), _mxarray32_, NULL));
            /*
             * oldTitleUnits=get(tHandle,'Units');
             */
            mlfAssign(
              &oldTitleUnits,
              mlfNGet(1, mclVv(tHandle, "tHandle"), _mxarray38_, NULL));
            /*
             * set(tHandle,...
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(tHandle, "tHandle"),
                _mxarray38_,
                _mxarray40_,
                _mxarray93_,
                mclVv(name, "name"),
                NULL));
            /*
             * 'Units',      'points',...
             * 'String',     name);
             * 
             * tExtent=get(tHandle,'Extent');
             */
            mlfAssign(
              &tExtent,
              mlfNGet(1, mclVv(tHandle, "tHandle"), _mxarray143_, NULL));
            /*
             * set(tHandle,'Units',oldTitleUnits);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(tHandle, "tHandle"),
                _mxarray38_,
                mclVv(oldTitleUnits, "oldTitleUnits"),
                NULL));
            /*
             * 
             * titleHeight=tExtent(4)+axPos(2)+axPos(4)+5;
             */
            mlfAssign(
              &titleHeight,
              mclPlus(
                mclPlus(
                  mclPlus(
                    mclIntArrayRef1(mclVv(tExtent, "tExtent"), 4),
                    mclIntArrayRef1(mclVv(axPos, "axPos"), 2)),
                  mclIntArrayRef1(mclVv(axPos, "axPos"), 4)),
                _mxarray145_));
            /*
             * if titleHeight>pos(4)
             */
            if (mclGtBool(
                  mclVv(titleHeight, "titleHeight"),
                  mclIntArrayRef1(mclVv(pos, "pos"), 4))) {
                /*
                 * pos(4)=titleHeight;
                 */
                mclIntArrayAssign1(&pos, mclVv(titleHeight, "titleHeight"), 4);
                /*
                 * pos(2)=screenSize(4)/2-pos(4)/2;
                 */
                mclIntArrayAssign1(
                  &pos,
                  mclMinus(
                    mclMrdivide(
                      mclIntArrayRef1(mclVv(screenSize, "screenSize"), 4),
                      _mxarray0_),
                    mclMrdivide(
                      mclIntArrayRef1(mclVv(pos, "pos"), 4), _mxarray0_)),
                  2);
                /*
                 * figPosDirty=logical(1);
                 */
                mlfAssign(&figPosDirty, _mxarray146_);
            /*
             * else
             */
            } else {
                /*
                 * figPosDirty=logical(0);
                 */
                mlfAssign(&figPosDirty, _mxarray147_);
            /*
             * end
             */
            }
            /*
             * 
             * if tExtent(3)>pos(3)*1.10;
             */
            if (mclGtBool(
                  mclIntArrayRef1(mclVv(tExtent, "tExtent"), 3),
                  mclMtimes(
                    mclIntArrayRef1(mclVv(pos, "pos"), 3), _mxarray148_))) {
                /*
                 * pos(3)=min(tExtent(3)*1.10,screenSize(3));
                 */
                mclIntArrayAssign1(
                  &pos,
                  mlfMin(
                    NULL,
                    mclMtimes(
                      mclIntArrayRef1(mclVv(tExtent, "tExtent"), 3),
                      _mxarray148_),
                    mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
                    NULL),
                  3);
                /*
                 * pos(1)=screenSize(3)/2-pos(3)/2;
                 */
                mclIntArrayAssign1(
                  &pos,
                  mclMinus(
                    mclMrdivide(
                      mclIntArrayRef1(mclVv(screenSize, "screenSize"), 3),
                      _mxarray0_),
                    mclMrdivide(
                      mclIntArrayRef1(mclVv(pos, "pos"), 3), _mxarray0_)),
                  1);
                /*
                 * 
                 * axPos([1,3])=axNorm([1,3])*pos(3);
                 */
                mclArrayAssign1(
                  &axPos,
                  mclMtimes(
                    mclArrayRef1(mclVv(axNorm, "axNorm"), _mxarray149_),
                    mclIntArrayRef1(mclVv(pos, "pos"), 3)),
                  _mxarray149_);
                /*
                 * set(h,'Position',axPos);
                 */
                mclAssignAns(
                  &ans,
                  mlfNSet(
                    0,
                    mclVv(h, "h"),
                    _mxarray55_,
                    mclVv(axPos, "axPos"),
                    NULL));
                /*
                 * 
                 * figPosDirty=logical(1);
                 */
                mlfAssign(&figPosDirty, _mxarray146_);
            /*
             * end
             */
            }
            /*
             * 
             * if figPosDirty
             */
            if (mlfTobool(mclVv(figPosDirty, "figPosDirty"))) {
                /*
                 * set(f,'Position',pos);
                 */
                mclAssignAns(
                  &ans,
                  mlfNSet(
                    0, mclVv(f, "f"), _mxarray55_, mclVv(pos, "pos"), NULL));
            /*
             * end
             */
            }
            /*
             * 
             * xpatch = [0 x x 0];
             */
            mlfAssign(
              &xpatch,
              mlfHorzcat(
                _mxarray6_, mclVa(x, "x"), mclVa(x, "x"), _mxarray6_, NULL));
            /*
             * ypatch = [0 0 1 1];
             */
            mlfAssign(&ypatch, _mxarray151_);
            /*
             * xline = [100 0 0 100 100];
             */
            mlfAssign(&xline, _mxarray153_);
            /*
             * yline = [0 0 1 1 0];
             */
            mlfAssign(&yline, _mxarray155_);
            /*
             * 
             * p = patch(xpatch,ypatch,'r','EdgeColor','r','EraseMode','none');
             */
            mlfAssign(
              &p,
              mlfNPatch(
                1,
                mclVv(xpatch, "xpatch"),
                mclVv(ypatch, "ypatch"),
                _mxarray157_,
                _mxarray159_,
                _mxarray157_,
                _mxarray161_,
                _mxarray70_,
                NULL));
            /*
             * l = line(xline,yline,'EraseMode','none');
             */
            mlfAssign(
              &l,
              mlfNLine(
                1,
                mclVv(xline, "xline"),
                mclVv(yline, "yline"),
                _mxarray161_,
                _mxarray70_,
                NULL));
            /*
             * set(l,'Color',get(gca,'XColor'));
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(l, "l"),
                _mxarray163_,
                mlfNGet(1, mlfGca(NULL), _mxarray165_, NULL),
                NULL));
            /*
             * 
             * 
             * set(f,'HandleVisibility','callback','visible','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(f, "f"),
                _mxarray167_,
                _mxarray169_,
                _mxarray171_,
                _mxarray89_,
                NULL));
            /*
             * 
             * set(0, 'Units', oldRootUnits);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                _mxarray6_,
                _mxarray38_,
                mclVv(oldRootUnits, "oldRootUnits"),
                NULL));
        /*
         * end  % case
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * drawnow;
     */
    mlfDrawnow(NULL);
    /*
     * 
     * if nargout==1,
     */
    if (nargout_ == 1) {
        /*
         * fout = f;
         */
        mlfAssign(&fout, mclVv(f, "f"));
    /*
     * end
     */
    }
    mclValidateOutput(fout, 1, nargout_, "fout", "waitbar");
    mxDestroyArray(type);
    mxDestroyArray(name);
    mxDestroyArray(f);
    mxDestroyArray(ans);
    mxDestroyArray(p);
    mxDestroyArray(l);
    mxDestroyArray(xpatch);
    mxDestroyArray(xline);
    mxDestroyArray(hAxes);
    mxDestroyArray(hTitle);
    mxDestroyArray(vertMargin);
    mxDestroyArray(oldRootUnits);
    mxDestroyArray(screenSize);
    mxDestroyArray(axFontSize);
    mxDestroyArray(pointsPerPixel);
    mxDestroyArray(width);
    mxDestroyArray(height);
    mxDestroyArray(pos);
    mxDestroyArray(propList);
    mxDestroyArray(valueList);
    mxDestroyArray(cancelBtnCreated);
    mxDestroyArray(ii);
    mxDestroyArray(cancelBtnHeight);
    mxDestroyArray(cancelBtnWidth);
    mxDestroyArray(newPos);
    mxDestroyArray(callbackFcn);
    mxDestroyArray(cancelButt);
    mxDestroyArray(axNorm);
    mxDestroyArray(axPos);
    mxDestroyArray(h);
    mxDestroyArray(tHandle);
    mxDestroyArray(oldTitleUnits);
    mxDestroyArray(tExtent);
    mxDestroyArray(titleHeight);
    mxDestroyArray(figPosDirty);
    mxDestroyArray(ypatch);
    mxDestroyArray(yline);
    mxDestroyArray(varargin);
    mxDestroyArray(whichbar);
    mxDestroyArray(x);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return fout;
}
