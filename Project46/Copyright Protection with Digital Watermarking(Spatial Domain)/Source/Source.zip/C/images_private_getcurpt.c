/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_getcurpt.h"
#include "libmatlbm.h"

static mxChar _array1_[12] = { 'C', 'u', 'r', 'r', 'e', 'n',
                               't', 'P', 'o', 'i', 'n', 't' };
static mxArray * _mxarray0_;

void InitializeModule_images_private_getcurpt(void) {
    _mxarray0_ = mclInitializeString(12, _array1_);
}

void TerminateModule_images_private_getcurpt(void) {
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mimages_private_getcurpt(mxArray * * y,
                                          int nargout_,
                                          mxArray * axHandle);

_mexLocalFunctionTable _local_function_table_images_private_getcurpt
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_getcurpt" contains the normal interface for
 * the "images/private/getcurpt" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\getcurpt.m" (lines 1-18). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImages_private_getcurpt(mxArray * * y, mxArray * axHandle) {
    int nargout = 1;
    mxArray * x = NULL;
    mxArray * y__ = NULL;
    mlfEnterNewContext(1, 1, y, axHandle);
    if (y != NULL) {
        ++nargout;
    }
    x = Mimages_private_getcurpt(&y__, nargout, axHandle);
    mlfRestorePreviousContext(1, 1, y, axHandle);
    if (y != NULL) {
        mclCopyOutputArg(y, y__);
    } else {
        mxDestroyArray(y__);
    }
    return mlfReturnValue(x);
}

/*
 * The function "mlxImages_private_getcurpt" contains the feval interface for
 * the "images/private/getcurpt" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\getcurpt.m" (lines 1-18). The
 * feval function calls the implementation version of images/private/getcurpt
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_getcurpt(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/getcurpt Line: 1 Co"
            "lumn: 1 The function \"images/private/getcurpt\" was cal"
            "led with more than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/getcurpt Line: 1 Co"
            "lumn: 1 The function \"images/private/getcurpt\" was cal"
            "led with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mimages_private_getcurpt(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "Mimages_private_getcurpt" is the implementation version of the
 * "images/private/getcurpt" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\getcurpt.m" (lines 1-18). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [x,y] = getcurpt(axHandle)
 */
static mxArray * Mimages_private_getcurpt(mxArray * * y,
                                          int nargout_,
                                          mxArray * axHandle) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_getcurpt);
    mxArray * x = NULL;
    mxArray * pt = NULL;
    mclCopyArray(&axHandle);
    /*
     * %GETCURPT Get current point.
     * %   [X,Y] = GETCURPT(AXHANDLE) gets the x- and y-coordinates of
     * %   the current point of AXHANDLE.  GETCURPT compensates these
     * %   coordinates for the fact that get(gca,'CurrentPoint') returns
     * %   the data-space coordinates of the idealized left edge of the
     * %   screen pixel that the user clicked on.  For IPT functions, we
     * %   want the coordinates of the idealized center of the screen
     * %   pixel that the user clicked on.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.9 $  $Date: 2002/03/15 15:57:43 $
     * 
     * pt = get(axHandle, 'CurrentPoint');
     */
    mlfAssign(&pt, mlfNGet(1, mclVa(axHandle, "axHandle"), _mxarray0_, NULL));
    /*
     * x = pt(1,1);
     */
    mlfAssign(&x, mclIntArrayRef2(mclVv(pt, "pt"), 1, 1));
    /*
     * y = pt(1,2);
     */
    mlfAssign(y, mclIntArrayRef2(mclVv(pt, "pt"), 1, 2));
    mclValidateOutput(x, 1, nargout_, "x", "images/private/getcurpt");
    mclValidateOutput(*y, 2, nargout_, "y", "images/private/getcurpt");
    mxDestroyArray(pt);
    mxDestroyArray(axHandle);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return x;
    /*
     * 
     */
}
