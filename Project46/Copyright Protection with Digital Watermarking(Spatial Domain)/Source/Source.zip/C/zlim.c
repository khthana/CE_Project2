/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "zlim.h"
#include "libsgl.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[4] = { 'z', 'l', 'i', 'm' };
static mxArray * _mxarray0_;

static mxChar _array3_[4] = { 't', 'y', 'p', 'e' };
static mxArray * _mxarray2_;

static mxChar _array5_[4] = { 'a', 'x', 'e', 's' };
static mxArray * _mxarray4_;

static mxChar _array7_[25] = { 'W', 'r', 'o', 'n', 'g', ' ', 'n', 'u', 'm',
                               'b', 'e', 'r', ' ', 'o', 'f', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray6_;

static mxChar _array9_[4] = { 'm', 'o', 'd', 'e' };
static mxArray * _mxarray8_;

static mxChar _array11_[8] = { 'z', 'l', 'i', 'm', 'm', 'o', 'd', 'e' };
static mxArray * _mxarray10_;

void InitializeModule_zlim(void) {
    _mxarray0_ = mclInitializeString(4, _array1_);
    _mxarray2_ = mclInitializeString(4, _array3_);
    _mxarray4_ = mclInitializeString(4, _array5_);
    _mxarray6_ = mclInitializeString(25, _array7_);
    _mxarray8_ = mclInitializeString(4, _array9_);
    _mxarray10_ = mclInitializeString(8, _array11_);
}

void TerminateModule_zlim(void) {
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mzlim(int nargout_, mxArray * arg1, mxArray * arg2);

_mexLocalFunctionTable _local_function_table_zlim
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfZlim" contains the normal interface for the "zlim"
 * M-function from file "k:\matlab6p5\toolbox\matlab\graph3d\zlim.m" (lines
 * 1-47). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfZlim(mxArray * arg1, mxArray * arg2) {
    int nargout = 1;
    mxArray * a = NULL;
    mlfEnterNewContext(0, 2, arg1, arg2);
    a = Mzlim(nargout, arg1, arg2);
    mlfRestorePreviousContext(0, 2, arg1, arg2);
    return mlfReturnValue(a);
}

/*
 * The function "mlxZlim" contains the feval interface for the "zlim"
 * M-function from file "k:\matlab6p5\toolbox\matlab\graph3d\zlim.m" (lines
 * 1-47). The feval function calls the implementation version of zlim through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxZlim(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: zlim Line: 1 Column: 1 The function \"zlim\""
            " was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: zlim Line: 1 Column: 1 The function \"zlim"
            "\" was called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mzlim(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mzlim" is the implementation version of the "zlim" M-function
 * from file "k:\matlab6p5\toolbox\matlab\graph3d\zlim.m" (lines 1-47). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function a = zlim(arg1, arg2)
 */
static mxArray * Mzlim(int nargout_, mxArray * arg1, mxArray * arg2) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_zlim);
    int nargin_ = mclNargin(2, arg1, arg2, NULL);
    mxArray * a = NULL;
    mxArray * ans = NULL;
    mxArray * val = NULL;
    mxArray * ax = NULL;
    mclCopyArray(&arg1);
    mclCopyArray(&arg2);
    /*
     * %ZLIM Z limits.
     * %   ZL = ZLIM             gets the z limits of the current axes.
     * %   ZLIM([ZMIN ZMAX])     sets the z limits.
     * %   ZLMODE = ZLIM('mode') gets the z limits mode.
     * %   ZLIM(mode)            sets the z limits mode.
     * %                            (mode can be 'auto' or 'manual')
     * %   ZLIM(AX,...)          uses axes AX instead of current axes.
     * %
     * %   ZLIM sets or gets the ZLim or ZLimMode property of an axes.
     * %
     * %   See also PBASPECT, DASPECT, XLIM, YLIM.
     * 
     * %   Copyright 1984-2002 The MathWorks, Inc. 
     * %   $Revision: 1.7 $  $Date: 2002/04/08 22:00:18 $
     * 
     * if nargin == 0
     */
    if (nargin_ == 0) {
        /*
         * a = get(gca,'zlim');
         */
        mlfAssign(&a, mlfNGet(1, mlfGca(NULL), _mxarray0_, NULL));
    /*
     * else
     */
    } else {
        /*
         * if length(arg1)==1 & ishandle(arg1) & strcmp(get(arg1, 'type'), 'axes')
         */
        mxArray * a_
          = mclInitialize(
              mclBoolToArray(mclLengthInt(mclVa(arg1, "arg1")) == 1));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mclAnd(a_, mlfIshandle(mclVa(arg1, "arg1"))));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfStrcmp(
                     mlfNGet(1, mclVa(arg1, "arg1"), _mxarray2_, NULL),
                     _mxarray4_)))) {
            mxDestroyArray(a_);
            /*
             * ax = arg1;
             */
            mlfAssign(&ax, mclVa(arg1, "arg1"));
            /*
             * if nargin==2
             */
            if (nargin_ == 2) {
                /*
                 * val = arg2;
                 */
                mlfAssign(&val, mclVa(arg2, "arg2"));
            /*
             * else
             */
            } else {
                /*
                 * a = get(ax,'zlim');
                 */
                mlfAssign(&a, mlfNGet(1, mclVv(ax, "ax"), _mxarray0_, NULL));
                /*
                 * return
                 */
                goto return_;
            /*
             * end
             */
            }
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * if nargin==2
             */
            if (nargin_ == 2) {
                /*
                 * error('Wrong number of arguments')
                 */
                mlfError(_mxarray6_, NULL);
            /*
             * else
             */
            } else {
                /*
                 * ax = gca;
                 */
                mlfAssign(&ax, mlfGca(NULL));
                /*
                 * val = arg1;
                 */
                mlfAssign(&val, mclVa(arg1, "arg1"));
            /*
             * end
             */
            }
        }
        /*
         * end
         * 
         * if isstr(val)
         */
        if (mlfTobool(mlfIsstr(mclVv(val, "val")))) {
            /*
             * if(strcmp(val,'mode'))
             */
            if (mlfTobool(mlfStrcmp(mclVv(val, "val"), _mxarray8_))) {
                /*
                 * a = get(ax,'zlimmode');
                 */
                mlfAssign(&a, mlfNGet(1, mclVv(ax, "ax"), _mxarray10_, NULL));
            /*
             * else
             */
            } else {
                /*
                 * set(ax,'zlimmode',val);
                 */
                mclAssignAns(
                  &ans,
                  mlfNSet(
                    0, mclVv(ax, "ax"), _mxarray10_, mclVv(val, "val"), NULL));
            /*
             * end
             */
            }
        /*
         * else
         */
        } else {
            /*
             * set(ax,'zlim',val);
             */
            mclAssignAns(
              &ans,
              mlfNSet(0, mclVv(ax, "ax"), _mxarray0_, mclVv(val, "val"), NULL));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    return_:
    mclValidateOutput(a, 1, nargout_, "a", "zlim");
    mxDestroyArray(ax);
    mxDestroyArray(val);
    mxDestroyArray(ans);
    mxDestroyArray(arg2);
    mxDestroyArray(arg1);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return a;
}
