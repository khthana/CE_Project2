/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imageinfo.h"
#include "gui_mainfcn.h"
#include "guidata.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[8] = { 'g', 'u', 'i', '_', 'N', 'a', 'm', 'e' };
static mxArray * _mxarray1_;

static mxChar _array4_[13] = { 'g', 'u', 'i', '_', 'S', 'i', 'n',
                               'g', 'l', 'e', 't', 'o', 'n' };
static mxArray * _mxarray3_;

static mxChar _array6_[14] = { 'g', 'u', 'i', '_', 'O', 'p', 'e',
                               'n', 'i', 'n', 'g', 'F', 'c', 'n' };
static mxArray * _mxarray5_;

static mxChar _array8_[13] = { 'g', 'u', 'i', '_', 'O', 'u', 't',
                               'p', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray7_;

static mxChar _array10_[13] = { 'g', 'u', 'i', '_', 'L', 'a', 'y',
                                'o', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[12] = { 'g', 'u', 'i', '_', 'C', 'a',
                                'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray12_;

static mxChar _array15_[15] = { 'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray14_;

static mxChar _array17_[5] = { 'w', 'h', 'i', 't', 'e' };
static mxArray * _mxarray16_;
static mxArray * _mxarray18_;

static mxChar _array20_[31] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', 'U',
                                'i', 'c', 'o', 'n', 't', 'r', 'o', 'l',
                                'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray19_;

void InitializeModule_imageinfo(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeString(8, _array2_);
    _mxarray3_ = mclInitializeString(13, _array4_);
    _mxarray5_ = mclInitializeString(14, _array6_);
    _mxarray7_ = mclInitializeString(13, _array8_);
    _mxarray9_ = mclInitializeString(13, _array10_);
    _mxarray11_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray12_ = mclInitializeString(12, _array13_);
    _mxarray14_ = mclInitializeString(15, _array15_);
    _mxarray16_ = mclInitializeString(5, _array17_);
    _mxarray18_ = mclInitializeDouble(0.0);
    _mxarray19_ = mclInitializeString(31, _array20_);
}

void TerminateModule_imageinfo(void) {
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static void mlfImageinfo_imageinfo_OpeningFcn(mxArray * hObject,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              ...);
static void mlxImageinfo_imageinfo_OpeningFcn(int nlhs,
                                              mxArray * plhs[],
                                              int nrhs,
                                              mxArray * prhs[]);
static mxArray * mlfImageinfo_imageinfo_OutputFcn(mlfVarargoutList * varargout,
                                                  mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void mlxImageinfo_imageinfo_OutputFcn(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static void mlfImageinfo_editFileModifyDate_CreateFcn(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxImageinfo_editFileModifyDate_CreateFcn(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfImageinfo_editFileModifyDate_Callback(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles);
static void mlxImageinfo_editFileModifyDate_Callback(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]);
static void mlfImageinfo_editImageFormat_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void mlxImageinfo_editImageFormat_CreateFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]);
static void mlfImageinfo_editImageFormat_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void mlxImageinfo_editImageFormat_Callback(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]);
static void mlfImageinfo_editFileSize_CreateFcn(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles);
static void mlxImageinfo_editFileSize_CreateFcn(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]);
static void mlfImageinfo_editFileSize_Callback(mxArray * hObject,
                                               mxArray * eventdata,
                                               mxArray * handles);
static void mlxImageinfo_editFileSize_Callback(int nlhs,
                                               mxArray * plhs[],
                                               int nrhs,
                                               mxArray * prhs[]);
static void mlfImageinfo_editImageHeight_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void mlxImageinfo_editImageHeight_CreateFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]);
static void mlfImageinfo_editImageHeight_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void mlxImageinfo_editImageHeight_Callback(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]);
static void mlfImageinfo_editImageWidth_CreateFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void mlxImageinfo_editImageWidth_CreateFcn(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]);
static void mlfImageinfo_editImageWidth_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles);
static void mlxImageinfo_editImageWidth_Callback(int nlhs,
                                                 mxArray * plhs[],
                                                 int nrhs,
                                                 mxArray * prhs[]);
static void mlfImageinfo_editImageFormatVersion_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void mlxImageinfo_editImageFormatVersion_CreateFcn(int nlhs,
                                                          mxArray * plhs[],
                                                          int nrhs,
                                                          mxArray * prhs[]);
static void mlfImageinfo_editImageFormatVersion_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void mlxImageinfo_editImageFormatVersion_Callback(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]);
static void mlfImageinfo_editImageCompressionType_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxImageinfo_editImageCompressionType_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfImageinfo_editImageCompressionType_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void mlxImageinfo_editImageCompressionType_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static void mlfImageinfo_editPSNR_CreateFcn(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxImageinfo_editPSNR_CreateFcn(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfImageinfo_editPSNR_Callback(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void mlxImageinfo_editPSNR_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static void mlfImageinfo_editMSE_CreateFcn(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void mlxImageinfo_editMSE_CreateFcn(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]);
static void mlfImageinfo_editMSE_Callback(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void mlxImageinfo_editMSE_Callback(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static void mlfImageinfo_pushbuttonInfoOK_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void mlxImageinfo_pushbuttonInfoOK_Callback(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]);
static mxArray * Mimageinfo(int nargout_, mxArray * varargin);
static void Mimageinfo_imageinfo_OpeningFcn(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles,
                                            mxArray * varargin);
static mxArray * Mimageinfo_imageinfo_OutputFcn(int nargout_,
                                                mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles);
static void Mimageinfo_editFileModifyDate_CreateFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mimageinfo_editFileModifyDate_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void Mimageinfo_editImageFormat_CreateFcn(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles);
static void Mimageinfo_editImageFormat_Callback(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles);
static void Mimageinfo_editFileSize_CreateFcn(mxArray * hObject,
                                              mxArray * eventdata,
                                              mxArray * handles);
static void Mimageinfo_editFileSize_Callback(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles);
static void Mimageinfo_editImageHeight_CreateFcn(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles);
static void Mimageinfo_editImageHeight_Callback(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles);
static void Mimageinfo_editImageWidth_CreateFcn(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles);
static void Mimageinfo_editImageWidth_Callback(mxArray * hObject,
                                               mxArray * eventdata,
                                               mxArray * handles);
static void Mimageinfo_editImageFormatVersion_CreateFcn(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void Mimageinfo_editImageFormatVersion_Callback(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles);
static void Mimageinfo_editImageCompressionType_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mimageinfo_editImageCompressionType_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void Mimageinfo_editPSNR_CreateFcn(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mimageinfo_editPSNR_Callback(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles);
static void Mimageinfo_editMSE_CreateFcn(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles);
static void Mimageinfo_editMSE_Callback(mxArray * hObject,
                                        mxArray * eventdata,
                                        mxArray * handles);
static void Mimageinfo_pushbuttonInfoOK_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles);

static mexFunctionTableEntry local_function_table_[21]
  = { { "imageinfo_OpeningFcn",
        mlxImageinfo_imageinfo_OpeningFcn, -4, 0, NULL },
      { "imageinfo_OutputFcn", mlxImageinfo_imageinfo_OutputFcn, 3, -1, NULL },
      { "editFileModifyDate_CreateFcn",
        mlxImageinfo_editFileModifyDate_CreateFcn, 3, 0, NULL },
      { "editFileModifyDate_Callback",
        mlxImageinfo_editFileModifyDate_Callback, 3, 0, NULL },
      { "editImageFormat_CreateFcn",
        mlxImageinfo_editImageFormat_CreateFcn, 3, 0, NULL },
      { "editImageFormat_Callback",
        mlxImageinfo_editImageFormat_Callback, 3, 0, NULL },
      { "editFileSize_CreateFcn",
        mlxImageinfo_editFileSize_CreateFcn, 3, 0, NULL },
      { "editFileSize_Callback",
        mlxImageinfo_editFileSize_Callback, 3, 0, NULL },
      { "editImageHeight_CreateFcn",
        mlxImageinfo_editImageHeight_CreateFcn, 3, 0, NULL },
      { "editImageHeight_Callback",
        mlxImageinfo_editImageHeight_Callback, 3, 0, NULL },
      { "editImageWidth_CreateFcn",
        mlxImageinfo_editImageWidth_CreateFcn, 3, 0, NULL },
      { "editImageWidth_Callback",
        mlxImageinfo_editImageWidth_Callback, 3, 0, NULL },
      { "editImageFormatVersion_CreateFcn",
        mlxImageinfo_editImageFormatVersion_CreateFcn, 3, 0, NULL },
      { "editImageFormatVersion_Callback",
        mlxImageinfo_editImageFormatVersion_Callback, 3, 0, NULL },
      { "editImageCompressionType_CreateFcn",
        mlxImageinfo_editImageCompressionType_CreateFcn, 3, 0, NULL },
      { "editImageCompressionType_Callback",
        mlxImageinfo_editImageCompressionType_Callback, 3, 0, NULL },
      { "editPSNR_CreateFcn", mlxImageinfo_editPSNR_CreateFcn, 3, 0, NULL },
      { "editPSNR_Callback", mlxImageinfo_editPSNR_Callback, 3, 0, NULL },
      { "editMSE_CreateFcn", mlxImageinfo_editMSE_CreateFcn, 3, 0, NULL },
      { "editMSE_Callback", mlxImageinfo_editMSE_Callback, 3, 0, NULL },
      { "pushbuttonInfoOK_Callback",
        mlxImageinfo_pushbuttonInfoOK_Callback, 3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_imageinfo
  = { 21, local_function_table_ };

/*
 * The function "mlfNImageinfo" contains the nargout interface for the
 * "imageinfo" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\imageinfo.m" (lines 1-48). This interface
 * is only produced if the M-function uses the special variable "nargout". The
 * nargout interface allows the number of requested outputs to be specified via
 * the nargout argument, as opposed to the normal interface which dynamically
 * calculates the number of outputs based on the number of non-NULL inputs it
 * receives. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfNImageinfo(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimageinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImageinfo" contains the normal interface for the
 * "imageinfo" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\imageinfo.m" (lines 1-48). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfImageinfo(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimageinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImageinfo" contains the void interface for the "imageinfo"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 1-48). The void interface is only
 * produced if the M-function uses the special variable "nargout", and has at
 * least one output. The void interface function specifies zero output
 * arguments to the implementation version of the function, and in the event
 * that the implementation version still returns an output (which, in MATLAB,
 * would be assigned to the "ans" variable), it deallocates the output. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlfVImageinfo(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimageinfo(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImageinfo" contains the feval interface for the "imageinfo"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 1-48). The feval function calls
 * the implementation version of imageinfo through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
void mlxImageinfo(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimageinfo(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImageinfo_imageinfo_OpeningFcn" contains the normal
 * interface for the "imageinfo/imageinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 48-70). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_imageinfo_OpeningFcn(mxArray * hObject,
                                              mxArray * eventdata,
                                              mxArray * handles,
                                              ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, hObject, eventdata, handles, varargin);
    Mimageinfo_imageinfo_OpeningFcn(hObject, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImageinfo_imageinfo_OpeningFcn" contains the feval
 * interface for the "imageinfo/imageinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 48-70). The feval function calls the implementation
 * version of imageinfo/imageinfo_OpeningFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_imageinfo_OpeningFcn(int nlhs,
                                              mxArray * plhs[],
                                              int nrhs,
                                              mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/imageinfo_OpeningFcn Line: 48"
            " Column: 1 The function \"imageinfo/imageinfo_OpeningFcn\" wa"
            "s called with more than the declared number of outputs (0)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    Mimageinfo_imageinfo_OpeningFcn(mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfImageinfo_imageinfo_OutputFcn" contains the normal
 * interface for the "imageinfo/imageinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 70-81). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static mxArray * mlfImageinfo_imageinfo_OutputFcn(mlfVarargoutList * varargout,
                                                  mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    int nargout = 0;
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mimageinfo_imageinfo_OutputFcn(nargout, hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxImageinfo_imageinfo_OutputFcn" contains the feval interface
 * for the "imageinfo/imageinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 70-81). The feval function calls the implementation
 * version of imageinfo/imageinfo_OutputFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_imageinfo_OutputFcn(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/imageinfo_OutputFcn Line: 70"
            " Column: 1 The function \"imageinfo/imageinfo_OutputFcn\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0]
      = Mimageinfo_imageinfo_OutputFcn(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editFileModifyDate_CreateFcn" contains the normal
 * interface for the "imageinfo/editFileModifyDate_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 81-96). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editFileModifyDate_CreateFcn(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editFileModifyDate_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editFileModifyDate_CreateFcn" contains the feval
 * interface for the "imageinfo/editFileModifyDate_CreateFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 81-96). The feval function calls the implementation
 * version of imageinfo/editFileModifyDate_CreateFcn through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxImageinfo_editFileModifyDate_CreateFcn(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileModifyDate"
            "_CreateFcn Line: 81 Column: 1 The function \"image"
            "info/editFileModifyDate_CreateFcn\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileModifyDate_CreateFcn Line:"
            " 81 Column: 1 The function \"imageinfo/editFileModifyDate_CreateFc"
            "n\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editFileModifyDate_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editFileModifyDate_Callback" contains the normal
 * interface for the "imageinfo/editFileModifyDate_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 96-106). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editFileModifyDate_Callback(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editFileModifyDate_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editFileModifyDate_Callback" contains the feval
 * interface for the "imageinfo/editFileModifyDate_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 96-106). The feval function calls the implementation
 * version of imageinfo/editFileModifyDate_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editFileModifyDate_Callback(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileModifyDate_Callback Line: "
            "96 Column: 1 The function \"imageinfo/editFileModifyDate_Callback"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileModifyDate_Callback Line: "
            "96 Column: 1 The function \"imageinfo/editFileModifyDate_Callback"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editFileModifyDate_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageFormat_CreateFcn" contains the normal
 * interface for the "imageinfo/editImageFormat_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 106-121). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageFormat_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageFormat_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageFormat_CreateFcn" contains the feval
 * interface for the "imageinfo/editImageFormat_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 106-121). The feval function calls the implementation
 * version of imageinfo/editImageFormat_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageFormat_CreateFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormat_CreateFcn Line: 1"
            "06 Column: 1 The function \"imageinfo/editImageFormat_CreateFcn\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormat_CreateFcn Line: 1"
            "06 Column: 1 The function \"imageinfo/editImageFormat_CreateFcn\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageFormat_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageFormat_Callback" contains the normal
 * interface for the "imageinfo/editImageFormat_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 121-131). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageFormat_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageFormat_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageFormat_Callback" contains the feval
 * interface for the "imageinfo/editImageFormat_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 121-131). The feval function calls the implementation
 * version of imageinfo/editImageFormat_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageFormat_Callback(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormat_Callback Line: 1"
            "21 Column: 1 The function \"imageinfo/editImageFormat_Callback\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormat_Callback Line: 1"
            "21 Column: 1 The function \"imageinfo/editImageFormat_Callback\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageFormat_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editFileSize_CreateFcn" contains the normal
 * interface for the "imageinfo/editFileSize_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 131-146). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editFileSize_CreateFcn(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editFileSize_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editFileSize_CreateFcn" contains the feval
 * interface for the "imageinfo/editFileSize_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 131-146). The feval function calls the implementation
 * version of imageinfo/editFileSize_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editFileSize_CreateFcn(int nlhs,
                                                mxArray * plhs[],
                                                int nrhs,
                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileSize_CreateFcn Line: 13"
            "1 Column: 1 The function \"imageinfo/editFileSize_CreateFcn\" w"
            "as called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileSize_CreateFcn Line: 13"
            "1 Column: 1 The function \"imageinfo/editFileSize_CreateFcn\" w"
            "as called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editFileSize_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editFileSize_Callback" contains the normal
 * interface for the "imageinfo/editFileSize_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 146-156). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editFileSize_Callback(mxArray * hObject,
                                               mxArray * eventdata,
                                               mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editFileSize_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editFileSize_Callback" contains the feval
 * interface for the "imageinfo/editFileSize_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 146-156). The feval function calls the implementation
 * version of imageinfo/editFileSize_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editFileSize_Callback(int nlhs,
                                               mxArray * plhs[],
                                               int nrhs,
                                               mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileSize_Callback Line: 14"
            "6 Column: 1 The function \"imageinfo/editFileSize_Callback\" w"
            "as called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editFileSize_Callback Line: 14"
            "6 Column: 1 The function \"imageinfo/editFileSize_Callback\" w"
            "as called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editFileSize_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageHeight_CreateFcn" contains the normal
 * interface for the "imageinfo/editImageHeight_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 156-171). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageHeight_CreateFcn(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageHeight_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageHeight_CreateFcn" contains the feval
 * interface for the "imageinfo/editImageHeight_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 156-171). The feval function calls the implementation
 * version of imageinfo/editImageHeight_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageHeight_CreateFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageHeight_CreateFcn Line: 1"
            "56 Column: 1 The function \"imageinfo/editImageHeight_CreateFcn\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageHeight_CreateFcn Line: 1"
            "56 Column: 1 The function \"imageinfo/editImageHeight_CreateFcn\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageHeight_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageHeight_Callback" contains the normal
 * interface for the "imageinfo/editImageHeight_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 171-181). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageHeight_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageHeight_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageHeight_Callback" contains the feval
 * interface for the "imageinfo/editImageHeight_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 171-181). The feval function calls the implementation
 * version of imageinfo/editImageHeight_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageHeight_Callback(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageHeight_Callback Line: 1"
            "71 Column: 1 The function \"imageinfo/editImageHeight_Callback\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageHeight_Callback Line: 1"
            "71 Column: 1 The function \"imageinfo/editImageHeight_Callback\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageHeight_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageWidth_CreateFcn" contains the normal
 * interface for the "imageinfo/editImageWidth_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 181-196). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageWidth_CreateFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageWidth_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageWidth_CreateFcn" contains the feval
 * interface for the "imageinfo/editImageWidth_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 181-196). The feval function calls the implementation
 * version of imageinfo/editImageWidth_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageWidth_CreateFcn(int nlhs,
                                                  mxArray * plhs[],
                                                  int nrhs,
                                                  mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageWidth_CreateFcn Line: 1"
            "81 Column: 1 The function \"imageinfo/editImageWidth_CreateFcn\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageWidth_CreateFcn Line: 1"
            "81 Column: 1 The function \"imageinfo/editImageWidth_CreateFcn\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageWidth_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageWidth_Callback" contains the normal
 * interface for the "imageinfo/editImageWidth_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 196-206). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editImageWidth_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageWidth_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageWidth_Callback" contains the feval
 * interface for the "imageinfo/editImageWidth_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 196-206). The feval function calls the implementation
 * version of imageinfo/editImageWidth_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageWidth_Callback(int nlhs,
                                                 mxArray * plhs[],
                                                 int nrhs,
                                                 mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageWidth_Callback Line: 19"
            "6 Column: 1 The function \"imageinfo/editImageWidth_Callback\" w"
            "as called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageWidth_Callback Line: 1"
            "96 Column: 1 The function \"imageinfo/editImageWidth_Callback\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageWidth_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageFormatVersion_CreateFcn" contains the
 * normal interface for the "imageinfo/editImageFormatVersion_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 206-221). This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlfImageinfo_editImageFormatVersion_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageFormatVersion_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageFormatVersion_CreateFcn" contains the
 * feval interface for the "imageinfo/editImageFormatVersion_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 206-221). The feval function
 * calls the implementation version of
 * imageinfo/editImageFormatVersion_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageFormatVersion_CreateFcn(int nlhs,
                                                          mxArray * plhs[],
                                                          int nrhs,
                                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormatVersi"
            "on_CreateFcn Line: 206 Column: 1 The function \"imag"
            "einfo/editImageFormatVersion_CreateFcn\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormatVersi"
            "on_CreateFcn Line: 206 Column: 1 The function \"imag"
            "einfo/editImageFormatVersion_CreateFcn\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageFormatVersion_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageFormatVersion_Callback" contains the
 * normal interface for the "imageinfo/editImageFormatVersion_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 221-231). This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlfImageinfo_editImageFormatVersion_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageFormatVersion_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageFormatVersion_Callback" contains the
 * feval interface for the "imageinfo/editImageFormatVersion_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 221-231). The feval function
 * calls the implementation version of
 * imageinfo/editImageFormatVersion_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageFormatVersion_Callback(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormatVersi"
            "on_Callback Line: 221 Column: 1 The function \"image"
            "info/editImageFormatVersion_Callback\" was called wi"
            "th more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageFormatVersi"
            "on_Callback Line: 221 Column: 1 The function \"image"
            "info/editImageFormatVersion_Callback\" was called wi"
            "th more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageFormatVersion_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageCompressionType_CreateFcn" contains the
 * normal interface for the "imageinfo/editImageCompressionType_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 231-246). This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlfImageinfo_editImageCompressionType_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageCompressionType_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageCompressionType_CreateFcn" contains the
 * feval interface for the "imageinfo/editImageCompressionType_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 231-246). The feval function
 * calls the implementation version of
 * imageinfo/editImageCompressionType_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageCompressionType_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageCompressionT"
            "ype_CreateFcn Line: 231 Column: 1 The function \"imag"
            "einfo/editImageCompressionType_CreateFcn\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageCompressionT"
            "ype_CreateFcn Line: 231 Column: 1 The function \"imag"
            "einfo/editImageCompressionType_CreateFcn\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageCompressionType_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editImageCompressionType_Callback" contains the
 * normal interface for the "imageinfo/editImageCompressionType_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 246-258). This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
static void mlfImageinfo_editImageCompressionType_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editImageCompressionType_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editImageCompressionType_Callback" contains the
 * feval interface for the "imageinfo/editImageCompressionType_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 246-258). The feval function
 * calls the implementation version of
 * imageinfo/editImageCompressionType_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_editImageCompressionType_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageCompressionT"
            "ype_Callback Line: 246 Column: 1 The function \"image"
            "info/editImageCompressionType_Callback\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editImageCompressionT"
            "ype_Callback Line: 246 Column: 1 The function \"image"
            "info/editImageCompressionType_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editImageCompressionType_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editPSNR_CreateFcn" contains the normal interface
 * for the "imageinfo/editPSNR_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 258-273). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editPSNR_CreateFcn(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editPSNR_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editPSNR_CreateFcn" contains the feval interface
 * for the "imageinfo/editPSNR_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 258-273). The feval function calls the implementation
 * version of imageinfo/editPSNR_CreateFcn through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxImageinfo_editPSNR_CreateFcn(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editPSNR_CreateFcn Line: 258"
            " Column: 1 The function \"imageinfo/editPSNR_CreateFcn\" was"
            " called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editPSNR_CreateFcn Line: 258"
            " Column: 1 The function \"imageinfo/editPSNR_CreateFcn\" was"
            " called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editPSNR_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editPSNR_Callback" contains the normal interface
 * for the "imageinfo/editPSNR_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 273-283). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editPSNR_Callback(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editPSNR_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editPSNR_Callback" contains the feval interface
 * for the "imageinfo/editPSNR_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 273-283). The feval function calls the implementation
 * version of imageinfo/editPSNR_Callback through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxImageinfo_editPSNR_Callback(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editPSNR_Callback Line: 273 "
            "Column: 1 The function \"imageinfo/editPSNR_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editPSNR_Callback Line: 273"
            " Column: 1 The function \"imageinfo/editPSNR_Callback\" was"
            " called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editPSNR_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editMSE_CreateFcn" contains the normal interface
 * for the "imageinfo/editMSE_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 283-298). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editMSE_CreateFcn(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editMSE_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editMSE_CreateFcn" contains the feval interface
 * for the "imageinfo/editMSE_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 283-298). The feval function calls the implementation
 * version of imageinfo/editMSE_CreateFcn through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxImageinfo_editMSE_CreateFcn(int nlhs,
                                           mxArray * plhs[],
                                           int nrhs,
                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editMSE_CreateFcn Line: 283 "
            "Column: 1 The function \"imageinfo/editMSE_CreateFcn\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editMSE_CreateFcn Line: 283"
            " Column: 1 The function \"imageinfo/editMSE_CreateFcn\" was"
            " called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editMSE_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_editMSE_Callback" contains the normal interface
 * for the "imageinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 298-308). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_editMSE_Callback(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_editMSE_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_editMSE_Callback" contains the feval interface
 * for the "imageinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 298-308). The feval function calls the implementation
 * version of imageinfo/editMSE_Callback through this function. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlxImageinfo_editMSE_Callback(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editMSE_Callback Line: 298 "
            "Column: 1 The function \"imageinfo/editMSE_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/editMSE_Callback Line: 298 "
            "Column: 1 The function \"imageinfo/editMSE_Callback\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_editMSE_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageinfo_pushbuttonInfoOK_Callback" contains the normal
 * interface for the "imageinfo/pushbuttonInfoOK_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 308-312). This function processes any input arguments
 * and passes them to the implementation version of the function, appearing
 * above.
 */
static void mlfImageinfo_pushbuttonInfoOK_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageinfo_pushbuttonInfoOK_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageinfo_pushbuttonInfoOK_Callback" contains the feval
 * interface for the "imageinfo/pushbuttonInfoOK_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 308-312). The feval function calls the implementation
 * version of imageinfo/pushbuttonInfoOK_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageinfo_pushbuttonInfoOK_Callback(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/pushbuttonInfoOK_Callback Line: 3"
            "08 Column: 1 The function \"imageinfo/pushbuttonInfoOK_Callback\""
            " was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageinfo/pushbuttonInfoOK_Callback Line: 3"
            "08 Column: 1 The function \"imageinfo/pushbuttonInfoOK_Callback\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageinfo_pushbuttonInfoOK_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "Mimageinfo" is the implementation version of the "imageinfo"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 1-48). It contains the actual
 * compiled code for that M-function. It is a static function and must only be
 * called from one of the interface functions, appearing below.
 */
/*
 * function varargout = imageinfo(varargin)
 */
static mxArray * Mimageinfo(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * _T0_ = NULL;
    mxArray * gui_State = NULL;
    mxArray * gui_Singleton = NULL;
    mclCopyArray(&varargin);
    /*
     * % IMAGEINFO M-file for imageinfo.fig
     * %      IMAGEINFO, by itself, creates a new IMAGEINFO or raises the existing
     * %      singleton*.
     * %
     * %      H = IMAGEINFO returns the handle to a new IMAGEINFO or the handle to
     * %      the existing singleton*.
     * %
     * %      IMAGEINFO('CALLBACK',hObject,eventData,handles,...) calls the local
     * %      function named CALLBACK in IMAGEINFO.M with the given input arguments.
     * %
     * %      IMAGEINFO('Property','Value',...) creates a new IMAGEINFO or raises the
     * %      existing singleton*.  Starting from the left, property value pairs are
     * %      applied to the GUI before imageinfo_OpeningFunction gets called.  An
     * %      unrecognized property name or invalid value makes property application
     * %      stop.  All inputs are passed to imageinfo_OpeningFcn via varargin.
     * %
     * %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
     * %      instance to run (singleton)".
     * %
     * % See also: GUIDE, GUIDATA, GUIHANDLES
     * 
     * % Edit the above text to modify the response to help imageinfo
     * 
     * % Last Modified by GUIDE v2.5 07-Mar-2004 00:58:55
     * 
     * % Begin initialization code - DO NOT EDIT
     * gui_Singleton = 1;
     */
    mlfAssign(&gui_Singleton, _mxarray0_);
    /*
     * gui_State = struct('gui_Name',       mfilename, ...
     */
    mlfAssign(
      &gui_State,
      mlfStruct(
        _mxarray1_,
        mxCreateString("imageinfo"),
        _mxarray3_,
        mclVv(gui_Singleton, "gui_Singleton"),
        _mxarray5_,
        mclCreateSimpleFunctionHandle(
          mlxImageinfo_imageinfo_OpeningFcn, "imageinfo_OpeningFcn"),
        _mxarray7_,
        mclCreateSimpleFunctionHandle(
          mlxImageinfo_imageinfo_OutputFcn, "imageinfo_OutputFcn"),
        _mxarray9_,
        _mxarray11_,
        _mxarray12_,
        _mxarray11_,
        NULL));
    /*
     * 'gui_Singleton',  gui_Singleton, ...
     * 'gui_OpeningFcn', @imageinfo_OpeningFcn, ...
     * 'gui_OutputFcn',  @imageinfo_OutputFcn, ...
     * 'gui_LayoutFcn',  [] , ...
     * 'gui_Callback',   []);
     * if nargin & isstr(varargin{1})
     */
    {
        mxArray * a_ = mclInitialize(mlfScalar(nargin_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIsstr,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * gui_State.gui_Callback = str2func(varargin{1});
             */
            mlfIndexAssign(
              &gui_State,
              ".gui_Callback",
              mclFeval(
                mclValueVarargout(),
                mlxStr2func,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if nargout
     */
    if (nargout_ != 0) {
        mlfAssign(&_T0_, mlfColon(_mxarray0_, mlfScalar(nargout_), NULL));
        /*
         * [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
         */
        mlfNGui_mainfcn(
          0,
          mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
          mclVv(gui_State, "gui_State"),
          mlfIndexRef(
            mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
          NULL);
    /*
     * else
     */
    } else {
        /*
         * gui_mainfcn(gui_State, varargin{:});
         */
        mclAssignAns(
          &ans,
          mlfNGui_mainfcn(
            0,
            mclAnsVarargout(),
            mclVv(gui_State, "gui_State"),
            mlfIndexRef(
              mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(gui_Singleton);
    mxDestroyArray(gui_State);
    mxDestroyArray(_T0_);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * % End initialization code - DO NOT EDIT
     * 
     * 
     * % --- Executes just before imageinfo is made visible.
     */
}

/*
 * The function "Mimageinfo_imageinfo_OpeningFcn" is the implementation version
 * of the "imageinfo/imageinfo_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 48-70). It contains the actual compiled code for that
 * M-function. It is a static function and must only be called from one of the
 * interface functions, appearing below.
 */
/*
 * function imageinfo_OpeningFcn(hObject, eventdata, handles, varargin)
 */
static void Mimageinfo_imageinfo_OpeningFcn(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles,
                                            mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * % This function has no output args, see OutputFcn.
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * % varargin   command line arguments to imageinfo (see VARARGIN)
     * 
     * % Choose default command line output for imageinfo
     * handles.output = hObject;
     */
    mlfIndexAssign(&handles, ".output", mclVa(hObject, "hObject"));
    /*
     * 
     * %h_image=imfinfo('mark.bmp','bmp');
     * %set(handles.editFilename,'String',h_image.Filename);
     * 
     * % Update handles structure
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % UIWAIT makes imageinfo wait for user response (see UIRESUME)
     * % uiwait(handles.figure2);
     * 
     * 
     * 
     * % --- Outputs from this function are returned to the command line.
     */
}

/*
 * The function "Mimageinfo_imageinfo_OutputFcn" is the implementation version
 * of the "imageinfo/imageinfo_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 70-81). It contains the actual compiled code for that
 * M-function. It is a static function and must only be called from one of the
 * interface functions, appearing below.
 */
/*
 * function varargout = imageinfo_OutputFcn(hObject, eventdata, handles)
 */
static mxArray * Mimageinfo_imageinfo_OutputFcn(int nargout_,
                                                mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * varargout = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % varargout  cell array for returning output args (see VARARGOUT);
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Get default command line output from handles structure
     * varargout{1} = handles.output;
     */
    mlfIndexAssign(
      &varargout,
      "{?}",
      _mxarray0_,
      mlfIndexRef(mclVa(handles, "handles"), ".output"));
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editFileModifyDate_CreateFcn" is the implementation
 * version of the "imageinfo/editFileModifyDate_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 81-96). It contains the actual compiled code for that
 * M-function. It is a static function and must only be called from one of the
 * interface functions, appearing below.
 */
/*
 * function editFileModifyDate_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editFileModifyDate_CreateFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editFileModifyDate (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editFileModifyDate_Callback" is the implementation
 * version of the "imageinfo/editFileModifyDate_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 96-106). It contains the actual compiled code for that
 * M-function. It is a static function and must only be called from one of the
 * interface functions, appearing below.
 */
/*
 * function editFileModifyDate_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editFileModifyDate_Callback(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editFileModifyDate (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editFileModifyDate as text
     * %        str2double(get(hObject,'String')) returns contents of editFileModifyDate as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editImageFormat_CreateFcn" is the implementation
 * version of the "imageinfo/editImageFormat_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 106-121). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageFormat_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageFormat_CreateFcn(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editImageFormat (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editImageFormat_Callback" is the implementation
 * version of the "imageinfo/editImageFormat_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 121-131). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageFormat_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageFormat_Callback(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editImageFormat (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editImageFormat as text
     * %        str2double(get(hObject,'String')) returns contents of editImageFormat as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editFileSize_CreateFcn" is the implementation
 * version of the "imageinfo/editFileSize_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 131-146). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editFileSize_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editFileSize_CreateFcn(mxArray * hObject,
                                              mxArray * eventdata,
                                              mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editFileSize (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editFileSize_Callback" is the implementation
 * version of the "imageinfo/editFileSize_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 146-156). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editFileSize_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editFileSize_Callback(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editFileSize (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editFileSize as text
     * %        str2double(get(hObject,'String')) returns contents of editFileSize as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editImageHeight_CreateFcn" is the implementation
 * version of the "imageinfo/editImageHeight_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 156-171). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageHeight_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageHeight_CreateFcn(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editImageHeight (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editImageHeight_Callback" is the implementation
 * version of the "imageinfo/editImageHeight_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 171-181). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageHeight_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageHeight_Callback(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editImageHeight (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editImageHeight as text
     * %        str2double(get(hObject,'String')) returns contents of editImageHeight as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editImageWidth_CreateFcn" is the implementation
 * version of the "imageinfo/editImageWidth_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 181-196). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageWidth_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageWidth_CreateFcn(mxArray * hObject,
                                                mxArray * eventdata,
                                                mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editImageWidth (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editImageWidth_Callback" is the implementation
 * version of the "imageinfo/editImageWidth_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 196-206). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editImageWidth_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageWidth_Callback(mxArray * hObject,
                                               mxArray * eventdata,
                                               mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editImageWidth (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editImageWidth as text
     * %        str2double(get(hObject,'String')) returns contents of editImageWidth as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editImageFormatVersion_CreateFcn" is the
 * implementation version of the "imageinfo/editImageFormatVersion_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 206-221). It contains the actual
 * compiled code for that M-function. It is a static function and must only be
 * called from one of the interface functions, appearing below.
 */
/*
 * function editImageFormatVersion_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageFormatVersion_CreateFcn(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editImageFormatVersion (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editImageFormatVersion_Callback" is the
 * implementation version of the "imageinfo/editImageFormatVersion_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 221-231). It contains the actual
 * compiled code for that M-function. It is a static function and must only be
 * called from one of the interface functions, appearing below.
 */
/*
 * function editImageFormatVersion_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageFormatVersion_Callback(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editImageFormatVersion (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editImageFormatVersion as text
     * %        str2double(get(hObject,'String')) returns contents of editImageFormatVersion as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editImageCompressionType_CreateFcn" is the
 * implementation version of the "imageinfo/editImageCompressionType_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 231-246). It contains the actual
 * compiled code for that M-function. It is a static function and must only be
 * called from one of the interface functions, appearing below.
 */
/*
 * function editImageCompressionType_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageCompressionType_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editImageCompressionType (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editImageCompressionType_Callback" is the
 * implementation version of the "imageinfo/editImageCompressionType_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageinfo.m" (lines 246-258). It contains the actual
 * compiled code for that M-function. It is a static function and must only be
 * called from one of the interface functions, appearing below.
 */
/*
 * function editImageCompressionType_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editImageCompressionType_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editImageCompressionType (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editImageCompressionType as text
     * %        str2double(get(hObject,'String')) returns contents of editImageCompressionType as a double
     * 
     * 
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editPSNR_CreateFcn" is the implementation version
 * of the "imageinfo/editPSNR_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 258-273). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editPSNR_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editPSNR_CreateFcn(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editPSNR (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editPSNR_Callback" is the implementation version of
 * the "imageinfo/editPSNR_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 273-283). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editPSNR_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editPSNR_Callback(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editPSNR (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editPSNR as text
     * %        str2double(get(hObject,'String')) returns contents of editPSNR as a double
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageinfo_editMSE_CreateFcn" is the implementation version of
 * the "imageinfo/editMSE_CreateFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 283-298). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editMSE_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageinfo_editMSE_CreateFcn(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editMSE (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageinfo_editMSE_Callback" is the implementation version of
 * the "imageinfo/editMSE_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 298-308). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function editMSE_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_editMSE_Callback(mxArray * hObject,
                                        mxArray * eventdata,
                                        mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editMSE (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editMSE as text
     * %        str2double(get(hObject,'String')) returns contents of editMSE as a double
     * 
     * 
     * % --- Executes on button press in pushbuttonInfoOK.
     */
}

/*
 * The function "Mimageinfo_pushbuttonInfoOK_Callback" is the implementation
 * version of the "imageinfo/pushbuttonInfoOK_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageinfo.m" (lines 308-312). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function pushbuttonInfoOK_Callback(hObject, eventdata, handles)
 */
static void Mimageinfo_pushbuttonInfoOK_Callback(mxArray * hObject,
                                                 mxArray * eventdata,
                                                 mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imageinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonInfoOK (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * delete(gcf);
     */
    mlfDelete(mlfGcf(), NULL);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
