/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_iptprefs.h"
#include "libmatlbm.h"

static mxChar _array3_[12] = { 'I', 'm', 's', 'h', 'o', 'w',
                               'B', 'o', 'r', 'd', 'e', 'r' };
static mxArray * _mxarray2_;

static mxChar _array5_[17] = { 'I', 'm', 's', 'h', 'o', 'w', 'A', 'x', 'e',
                               's', 'V', 'i', 's', 'i', 'b', 'l', 'e' };
static mxArray * _mxarray4_;

static mxChar _array7_[14] = { 'I', 'm', 's', 'h', 'o', 'w', 'T',
                               'r', 'u', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray6_;

static mxChar _array9_[15] = { 'T', 'r', 'u', 'e', 's', 'i', 'z', 'e',
                               'W', 'a', 'r', 'n', 'i', 'n', 'g' };
static mxArray * _mxarray8_;

static mxChar _array13_[5] = { 't', 'i', 'g', 'h', 't' };
static mxArray * _mxarray12_;

static mxChar _array15_[5] = { 'l', 'o', 'o', 's', 'e' };
static mxArray * _mxarray14_;

static mxArray * _array11_[2] = { NULL /*_mxarray12_*/, NULL /*_mxarray14_*/ };
static mxArray * _mxarray10_;

static mxChar _array19_[2] = { 'o', 'n' };
static mxArray * _mxarray18_;

static mxChar _array21_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray20_;

static mxArray * _array17_[2] = { NULL /*_mxarray18_*/, NULL /*_mxarray20_*/ };
static mxArray * _mxarray16_;

static mxChar _array25_[4] = { 'a', 'u', 't', 'o' };
static mxArray * _mxarray24_;

static mxChar _array27_[6] = { 'm', 'a', 'n', 'u', 'a', 'l' };
static mxArray * _mxarray26_;

static mxArray * _array23_[2] = { NULL /*_mxarray24_*/, NULL /*_mxarray26_*/ };
static mxArray * _mxarray22_;
static mxArray * _mxarray28_;
static mxArray * _mxarray29_;
static mxArray * _mxarray30_;
static mxArray * _mxarray31_;

static mxArray * _array1_[12] = { NULL /*_mxarray2_*/, NULL /*_mxarray4_*/,
                                  NULL /*_mxarray6_*/, NULL /*_mxarray8_*/,
                                  NULL /*_mxarray10_*/, NULL /*_mxarray16_*/,
                                  NULL /*_mxarray22_*/, NULL /*_mxarray16_*/,
                                  NULL /*_mxarray28_*/, NULL /*_mxarray29_*/,
                                  NULL /*_mxarray30_*/, NULL /*_mxarray31_*/ };
static mxArray * _mxarray0_;

void InitializeModule_images_private_iptprefs(void) {
    _mxarray2_ = mclInitializeString(12, _array3_);
    _array1_[0] = _mxarray2_;
    _mxarray4_ = mclInitializeString(17, _array5_);
    _array1_[1] = _mxarray4_;
    _mxarray6_ = mclInitializeString(14, _array7_);
    _array1_[2] = _mxarray6_;
    _mxarray8_ = mclInitializeString(15, _array9_);
    _array1_[3] = _mxarray8_;
    _mxarray12_ = mclInitializeString(5, _array13_);
    _array11_[0] = _mxarray12_;
    _mxarray14_ = mclInitializeString(5, _array15_);
    _array11_[1] = _mxarray14_;
    _mxarray10_ = mclInitializeCellVector(2, 1, _array11_);
    _array1_[4] = _mxarray10_;
    _mxarray18_ = mclInitializeString(2, _array19_);
    _array17_[0] = _mxarray18_;
    _mxarray20_ = mclInitializeString(3, _array21_);
    _array17_[1] = _mxarray20_;
    _mxarray16_ = mclInitializeCellVector(2, 1, _array17_);
    _array1_[5] = _mxarray16_;
    _mxarray24_ = mclInitializeString(4, _array25_);
    _array23_[0] = _mxarray24_;
    _mxarray26_ = mclInitializeString(6, _array27_);
    _array23_[1] = _mxarray26_;
    _mxarray22_ = mclInitializeCellVector(2, 1, _array23_);
    _array1_[6] = _mxarray22_;
    _array1_[7] = _mxarray16_;
    _mxarray28_ = mclInitializeCell(_mxarray14_);
    _array1_[8] = _mxarray28_;
    _mxarray29_ = mclInitializeCell(_mxarray20_);
    _array1_[9] = _mxarray29_;
    _mxarray30_ = mclInitializeCell(_mxarray24_);
    _array1_[10] = _mxarray30_;
    _mxarray31_ = mclInitializeCell(_mxarray18_);
    _array1_[11] = _mxarray31_;
    _mxarray0_ = mclInitializeCellVector(4, 3, _array1_);
}

void TerminateModule_images_private_iptprefs(void) {
    mxDestroyArray(_mxarray0_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
}

static mxArray * Mimages_private_iptprefs(int nargout_);

_mexLocalFunctionTable _local_function_table_images_private_iptprefs
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_iptprefs" contains the normal interface for
 * the "images/private/iptprefs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\iptprefs.m" (lines 1-30). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfImages_private_iptprefs(void) {
    int nargout = 1;
    mxArray * preferences = NULL;
    mlfEnterNewContext(0, 0);
    preferences = Mimages_private_iptprefs(nargout);
    mlfRestorePreviousContext(0, 0);
    return mlfReturnValue(preferences);
}

/*
 * The function "mlxImages_private_iptprefs" contains the feval interface for
 * the "images/private/iptprefs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\iptprefs.m" (lines 1-30). The
 * feval function calls the implementation version of images/private/iptprefs
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImages_private_iptprefs(int nlhs,
                                mxArray * plhs[],
                                int nrhs,
                                mxArray * prhs[]) {
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/iptprefs Line: 1 Co"
            "lumn: 1 The function \"images/private/iptprefs\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/iptprefs Line: 1 Co"
            "lumn: 1 The function \"images/private/iptprefs\" was cal"
            "led with more than the declared number of inputs (0)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mplhs[0] = Mimages_private_iptprefs(nlhs);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_iptprefs" is the implementation version of the
 * "images/private/iptprefs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\iptprefs.m" (lines 1-30). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function preferences = iptprefs
 */
static mxArray * Mimages_private_iptprefs(int nargout_) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_iptprefs);
    mxArray * preferences = NULL;
    /*
     * %IPTPREFS Image Processing Toolbox preference settings.
     * %   IPTPREFS returns a 3-column cell array containing the Image
     * %   Processing Toolbox preference settings.  Each row contains
     * %   information about a single preference.  
     * %   
     * %   The first column of each row contains a string indicating the
     * %   name of the preference.  The second column of each row is a
     * %   cell array containing the set of acceptable values for that
     * %   preference setting.  An empty cell array indicates that the
     * %   preference does not have a fixed set of values.  
     * %
     * %   The third column of each row contains a single-element cell
     * %   array containing the default value for the preference.  An
     * %   empy cell array indicates that the preference does not have a
     * %   default value.
     * %
     * %   See also IPTSETPREF, IPTGETPREF.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.14 $  $Date: 2002/03/15 15:57:48 $
     * 
     * preferences = { ...
     */
    mlfAssign(&preferences, _mxarray0_);
    mclValidateOutput(
      preferences, 1, nargout_, "preferences", "images/private/iptprefs");
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return preferences;
    /*
     * 'ImshowBorder',        {'tight'; 'loose'},        {'loose'}
     * 'ImshowAxesVisible',   {'on'; 'off'},             {'off'}
     * 'ImshowTruesize',      {'auto'; 'manual'},        {'auto'}
     * 'TruesizeWarning',     {'on'; 'off'},             {'on'}
     * };
     * 
     */
}
