/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "tformarray.h"
#include "mwservices.h"
#include "images_private_isresampler.h"
#include "images_private_istform.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "tforminv.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;

static mxChar _array5_[1] = { ':' };
static mxArray * _mxarray4_;
static mxArray * _mxarray3_;
static mxArray * _mxarray6_;

static mxChar _array8_[54] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l', ' ',
                               'E', 'r', 'r', 'o', 'r', ':', ' ', 'C', 'O',
                               'M', 'B', 'I', 'N', 'E', 'D', 'G', 'R', 'I',
                               'D', ' ', 'c', 'a', 'l', 'l', 'e', 'd', ' ',
                               'w', 'i', 't', 'h', ' ', 'n', 'o', ' ', 'a',
                               'r', 'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;
static mxArray * _mxarray10_;

static mxChar _array12_[46] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l',
                                ' ', 'E', 'r', 'r', 'o', 'r', ':', ' ',
                                'B', 'l', 'o', 'c', 'k', ' ', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', ' ',
                                'b', 'e', 'l', 'o', 'w', ' ', 'm', 'i',
                                'n', 'i', 'm', 'u', 'm', '.' };
static mxArray * _mxarray11_;

static mxChar _array14_[50] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l', ' ',
                                'E', 'r', 'r', 'o', 'r', ':', ' ', 'F', 'a',
                                'i', 'l', 'e', 'd', ' ', 't', 'o', ' ', 'i',
                                't', 'e', 'r', 'a', 't', 'e', ' ', 'o', 'v',
                                'e', 'r', ' ', 'a', 'l', 'l', ' ', 'b', 'l',
                                'o', 'c', 'k', 's', '.' };
static mxArray * _mxarray13_;

static mxChar _array16_[46] = { 'I', 'n', 't', 'e', 'r', 'n', 'a', 'l',
                                ' ', 'E', 'r', 'r', 'o', 'r', ':', ' ',
                                'N', ' ', 'a', 'n', 'd', ' ', 'L', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'o', 't',
                                'h', ' ', 'b', 'e', ' ', 'p', 'o', 's',
                                'i', 't', 'i', 'v', 'e', '.' };
static mxArray * _mxarray15_;

static mxChar _array18_[58] = { 'T', 'D', 'I', 'M', 'S', '_', 'A', ' ', 'm',
                                'u', 's', 't', ' ', 'b', 'e', ' ', 'a', ' ',
                                'r', 'o', 'w', ' ', 'v', 'e', 'c', 't', 'o',
                                'r', ' ', 'o', 'f', ' ', 'f', 'i', 'n', 'i',
                                't', 'e', ',', ' ', 'p', 'o', 's', 'i', 't',
                                'i', 'v', 'e', ' ', 'i', 'n', 't', 'e', 'g',
                                'e', 'r', 's', '.' };
static mxArray * _mxarray17_;

static mxChar _array20_[58] = { 'T', 'D', 'I', 'M', 'S', '_', 'B', ' ', 'm',
                                'u', 's', 't', ' ', 'b', 'e', ' ', 'a', ' ',
                                'r', 'o', 'w', ' ', 'v', 'e', 'c', 't', 'o',
                                'r', ' ', 'o', 'f', ' ', 'f', 'i', 'n', 'i',
                                't', 'e', ',', ' ', 'p', 'o', 's', 'i', 't',
                                'i', 'v', 'e', ' ', 'i', 'n', 't', 'e', 'g',
                                'e', 'r', 's', '.' };
static mxArray * _mxarray19_;

static mxChar _array22_[37] = { 'A', 'l', 'l', ' ', 'v', 'a', 'l', 'u',
                                'e', 's', ' ', 'i', 'n', ' ', 'T', 'D',
                                'I', 'M', 'S', '_', 'A', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'u', 'n',
                                'i', 'q', 'u', 'e', '.' };
static mxArray * _mxarray21_;

static mxChar _array24_[37] = { 'A', 'l', 'l', ' ', 'v', 'a', 'l', 'u',
                                'e', 's', ' ', 'i', 'n', ' ', 'T', 'D',
                                'I', 'M', 'S', '_', 'B', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'u', 'n',
                                'i', 'q', 'u', 'e', '.' };
static mxArray * _mxarray23_;

static mxChar _array26_[63] = { 'B', 'o', 't', 'h', ' ', 'T', 'M', 'A', 'P',
                                '_', 'B', ' ', 'a', 'n', 'd', ' ', 'T', 'S',
                                'I', 'Z', 'E', '_', 'B', ' ', 'a', 'r', 'e',
                                ' ', 'n', 'o', 'n', '-', 'e', 'm', 'p', 't',
                                'y', ';', ' ', 'T', 'S', 'I', 'Z', 'E', '_',
                                'B', ' ', 'w', 'i', 'l', 'l', ' ', 'b', 'e',
                                ' ', 'i', 'g', 'n', 'o', 'r', 'e', 'd', '.' };
static mxArray * _mxarray25_;

static mxChar _array28_[70] = { 'T', 'M', 'A', 'P', '_', 'B', ' ', 'm', 'u',
                                's', 't', ' ', 'b', 'e', ' ', 'a', ' ', 'n',
                                'o', 'n', '-', 's', 'p', 'a', 'r', 's', 'e',
                                ',', ' ', 'f', 'i', 'n', 'i', 't', 'e', ' ',
                                'r', 'e', 'a', 'l', '-', 'v', 'a', 'l', 'u',
                                'e', 'd', ' ', 'a', 'r', 'r', 'a', 'y', ' ',
                                'o', 'f', ' ', 'c', 'l', 'a', 's', 's', ' ',
                                'd', 'o', 'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray27_;

static mxChar _array30_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray29_;

static mxChar _array32_[69] = { 'S', 'I', 'Z', 'E', '(', 'T', 'M', 'A', 'P',
                                '_', 'B', ')', ' ', 'i', 's', ' ', 'i', 'n',
                                'c', 'o', 'n', 's', 'i', 's', 't', 'e', 'n',
                                't', ' ', 'w', 'i', 't', 'h', ' ', 'L', 'E',
                                'N', 'G', 'T', 'H', '(', 'T', 'D', 'I', 'M',
                                'S', '_', 'A', ')', ' ', 'o', 'r', ' ', 'L',
                                'E', 'N', 'G', 'T', 'H', '(', 'T', 'D', 'I',
                                'M', 'S', '_', 'B', ')', '.' };
static mxArray * _mxarray31_;

static mxChar _array34_[60] = { 'N', 'D', 'I', 'M', 'S', '(', 'T', 'M', 'A',
                                'P', '_', 'B', ')', ' ', 'i', 's', ' ', 'i',
                                'n', 'c', 'o', 'n', 's', 'i', 's', 't', 'e',
                                'n', 't', ' ', 'w', 'i', 't', 'h', ' ', 'T',
                                'D', 'I', 'M', 'S', '_', 'B', ' ', 'a', 'n',
                                'd', ' ', 'S', 'I', 'Z', 'E', '(', 'T', 'M',
                                'A', 'P', '_', 'B', ')', '.' };
static mxArray * _mxarray33_;

static mxChar _array36_[30] = { 'T', ' ', 'i', 's', ' ', 'n', 'o', 't',
                                ' ', 'a', ' ', 'v', 'a', 'l', 'i', 'd',
                                ' ', 'T', 'F', 'O', 'R', 'M', ' ', 's',
                                't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray35_;

static mxChar _array38_[32] = { 'T', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'a', ' ', 's', 'i', 'n', 'g',
                                'l', 'e', ' ', 'T', 'F', 'O', 'R', 'M',
                                ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray37_;

static mxChar _array40_[38] = { 'T', '.', 'N', 'D', 'I', 'M', 'S', '_',
                                'I', 'N', ' ', 'm', 'u', 's', 't', ' ',
                                'm', 'a', 't', 'c', 'h', ' ', 'L', 'E',
                                'N', 'G', 'T', 'H', '(', 'T', 'D', 'I',
                                'M', 'S', '_', 'A', ')', '.' };
static mxArray * _mxarray39_;

static mxChar _array42_[65] = { 'T', '.', 'N', 'D', 'I', 'M', 'S', '_', 'O',
                                'U', 'T', ' ', 'i', 's', ' ', 'i', 'n', 'c',
                                'o', 'n', 's', 'i', 's', 't', 'e', 'n', 't',
                                ' ', 'w', 'i', 't', 'h', ' ', 'L', 'E', 'N',
                                'G', 'T', 'H', '(', 'T', 'D', 'I', 'M', 'S',
                                '_', 'B', ')', ' ', 'o', 'r', ' ', 'S', 'I',
                                'Z', 'E', '(', 'T', 'M', 'A', 'P', '_', 'B',
                                ')', '.' };
static mxArray * _mxarray41_;

static mxChar _array44_[58] = { 'T', 'S', 'I', 'Z', 'E', '_', 'B', ' ', 'm',
                                'u', 's', 't', ' ', 'b', 'e', ' ', 'a', ' ',
                                'r', 'o', 'w', ' ', 'v', 'e', 'c', 't', 'o',
                                'r', ' ', 'o', 'f', ' ', 'f', 'i', 'n', 'i',
                                't', 'e', ',', ' ', 'p', 'o', 's', 'i', 't',
                                'i', 'v', 'e', ' ', 'i', 'n', 't', 'e', 'g',
                                'e', 'r', 's', '.' };
static mxArray * _mxarray43_;

static mxChar _array46_[42] = { 'L', 'e', 'n', 'g', 't', 'h', 's', ' ', 'o',
                                'f', ' ', 'T', 'S', 'I', 'Z', 'E', '_', 'B',
                                ' ', 'a', 'n', 'd', ' ', 'T', 'D', 'I', 'M',
                                'S', '_', 'B', ' ', 'm', 'u', 's', 't', ' ',
                                'm', 'a', 't', 'c', 'h', '.' };
static mxArray * _mxarray45_;

static mxChar _array48_[48] = { 'A', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 'a', ' ', 'n', 'o', 'n', '-',
                                's', 'p', 'a', 'r', 's', 'e', ' ', 'n',
                                'u', 'm', 'e', 'r', 'i', 'c', ' ', 'o',
                                'r', ' ', 'l', 'o', 'g', 'i', 'c', 'a',
                                'l', ' ', 'a', 'r', 'r', 'a', 'y', '.' };
static mxArray * _mxarray47_;

static mxChar _array50_[35] = { 'R', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', 'a', ' ', 'v', 'a', 'l', 'i', 'd', ' ',
                                'r', 'e', 's', 'a', 'm', 'p', 'l', 'e', 'r',
                                ' ', 's', 't', 'r', 'u', 'c', 't', '.' };
static mxArray * _mxarray49_;

static mxChar _array52_[48] = { 'R', 0x0027, 's', ' ', 0x0027, 'n', 'd',
                                'i', 'm', 's', 0x0027, ' ', 'f', 'i', 'e',
                                'l', 'd', ' ', 'd', 'o', 'e', 's', 'n',
                                0x0027, 't', ' ', 'm', 'a', 't', 'c', 'h',
                                ' ', 'L', 'E', 'N', 'G', 'T', 'H', '(', 'T',
                                'D', 'I', 'M', 'S', '_', 'A', ')', '.' };
static mxArray * _mxarray51_;
static double _ieee_plusinf_;
static mxArray * _mxarray53_;

static mxChar _array55_[45] = { 'F', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', 'a', ' ', 'n', 'o', 'n', '-', 's', 'p',
                                'a', 'r', 's', 'e', ' ', 'a', 'r', 'r', 'a',
                                'y', ' ', 'o', 'f', ' ', 'c', 'l', 'a', 's',
                                's', ' ', 'd', 'o', 'u', 'b', 'l', 'e', '.' };
static mxArray * _mxarray54_;

static mxChar _array57_[57] = { 'S', 'I', 'Z', 'E', '(', 'F', ')', ' ', 'i',
                                's', ' ', 'i', 'n', 'c', 'o', 'n', 's', 'i',
                                's', 't', 'e', 'n', 't', ' ', 'w', 'i', 't',
                                'h', ' ', 't', 'h', 'e', ' ', 'n', 'o', 'n',
                                '-', 't', 'r', 'a', 'n', 'f', 'o', 'r', 'm',
                                ' ', 's', 'i', 'z', 'e', 's', ' ', 'o', 'f',
                                ' ', 'A', '.' };
static mxArray * _mxarray56_;

void InitializeModule_tformarray(void) {
    _mxarray0_ = mclInitializeDouble(8.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray4_ = mclInitializeString(1, _array5_);
    _mxarray3_ = mclInitializeCell(_mxarray4_);
    _mxarray6_ = mclInitializeDouble(0.0);
    _mxarray7_ = mclInitializeString(54, _array8_);
    _mxarray9_ = mclInitializeDouble(20.0);
    _mxarray10_ = mclInitializeDouble(2.0);
    _mxarray11_ = mclInitializeString(46, _array12_);
    _mxarray13_ = mclInitializeString(50, _array14_);
    _mxarray15_ = mclInitializeString(46, _array16_);
    _mxarray17_ = mclInitializeString(58, _array18_);
    _mxarray19_ = mclInitializeString(58, _array20_);
    _mxarray21_ = mclInitializeString(37, _array22_);
    _mxarray23_ = mclInitializeString(37, _array24_);
    _mxarray25_ = mclInitializeString(63, _array26_);
    _mxarray27_ = mclInitializeString(70, _array28_);
    _mxarray29_ = mclInitializeString(6, _array30_);
    _mxarray31_ = mclInitializeString(69, _array32_);
    _mxarray33_ = mclInitializeString(60, _array34_);
    _mxarray35_ = mclInitializeString(30, _array36_);
    _mxarray37_ = mclInitializeString(32, _array38_);
    _mxarray39_ = mclInitializeString(38, _array40_);
    _mxarray41_ = mclInitializeString(65, _array42_);
    _mxarray43_ = mclInitializeString(58, _array44_);
    _mxarray45_ = mclInitializeString(42, _array46_);
    _mxarray47_ = mclInitializeString(48, _array48_);
    _mxarray49_ = mclInitializeString(35, _array50_);
    _mxarray51_ = mclInitializeString(48, _array52_);
    _ieee_plusinf_ = mclGetInf();
    _mxarray53_ = mclInitializeDouble(_ieee_plusinf_);
    _mxarray54_ = mclInitializeString(45, _array55_);
    _mxarray56_ = mclInitializeString(57, _array57_);
}

void TerminateModule_tformarray(void) {
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfTformarray_resample(mxArray * A,
                                        mxArray * M,
                                        mxArray * tdims_A,
                                        mxArray * tdims_B,
                                        mxArray * fsize_A,
                                        mxArray * fsize_B,
                                        mxArray * F,
                                        mxArray * R);
static void mlxTformarray_resample(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * mlfTformarray_ConstructSubscripts(mxArray * * S,
                                                   mxArray * fsize_B,
                                                   mxArray * tdims_B,
                                                   mxArray * lo,
                                                   mxArray * hi);
static void mlxTformarray_ConstructSubscripts(int nlhs,
                                              mxArray * plhs[],
                                              int nrhs,
                                              mxArray * prhs[]);
static mxArray * mlfTformarray_ConstructGrid(mxArray * lo, mxArray * hi);
static void mlxTformarray_ConstructGrid(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfTformarray_CombinedGrid(mxArray * synthetic_varargin_argument,
                                            ...);
static void mlxTformarray_CombinedGrid(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static mxArray * mlfTformarray_GetBlocking(mxArray * tsize, mxArray * P);
static void mlxTformarray_GetBlocking(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static mxArray * mlfTformarray_GetBlockLimits(mxArray * * hi,
                                              mxArray * tsize_B,
                                              mxArray * blockingfactors);
static void mlxTformarray_GetBlockLimits(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfTformarray_fullsizes(mxArray * * fsize_B,
                                         mxArray * * osize,
                                         mxArray * size_A,
                                         mxArray * tsize_B,
                                         mxArray * tdims_A,
                                         mxArray * tdims_B);
static void mlxTformarray_fullsizes(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfTformarray_PredictNDimsG(mxArray * N, mxArray * L);
static void mlxTformarray_PredictNDimsG(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]);
static mxArray * mlfTformarray_CheckDimsAndSizes(mxArray * tdims_A,
                                                 mxArray * tdims_B,
                                                 mxArray * tsize_B_in,
                                                 mxArray * tmap_B,
                                                 mxArray * T);
static void mlxTformarray_CheckDimsAndSizes(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfTformarray_CheckInputArray(mxArray * A);
static void mlxTformarray_CheckInputArray(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]);
static void mlfTformarray_CheckResampler(mxArray * R, mxArray * tdims_A);
static void mlxTformarray_CheckResampler(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfTformarray_CheckFillArray(mxArray * F_in, mxArray * osize);
static void mlxTformarray_CheckFillArray(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static mxArray * mlfTformarray_IsFinitePositiveIntegerRowVector(mxArray * v);
static void mlxTformarray_IsFinitePositiveIntegerRowVector(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static mxArray * Mtformarray(int nargout_,
                             mxArray * A,
                             mxArray * T,
                             mxArray * R,
                             mxArray * tdims_A,
                             mxArray * tdims_B,
                             mxArray * tsize_B,
                             mxArray * tmap_B,
                             mxArray * F);
static mxArray * Mtformarray_resample(int nargout_,
                                      mxArray * A,
                                      mxArray * M,
                                      mxArray * tdims_A,
                                      mxArray * tdims_B,
                                      mxArray * fsize_A,
                                      mxArray * fsize_B,
                                      mxArray * F,
                                      mxArray * R);
static mxArray * Mtformarray_ConstructSubscripts(mxArray * * S,
                                                 int nargout_,
                                                 mxArray * fsize_B,
                                                 mxArray * tdims_B,
                                                 mxArray * lo,
                                                 mxArray * hi);
static mxArray * Mtformarray_ConstructGrid(int nargout_,
                                           mxArray * lo,
                                           mxArray * hi);
static mxArray * Mtformarray_CombinedGrid(int nargout_, mxArray * varargin);
static mxArray * Mtformarray_GetBlocking(int nargout_,
                                         mxArray * tsize,
                                         mxArray * P);
static mxArray * Mtformarray_GetBlockLimits(mxArray * * hi,
                                            int nargout_,
                                            mxArray * tsize_B,
                                            mxArray * blockingfactors);
static mxArray * Mtformarray_fullsizes(mxArray * * fsize_B,
                                       mxArray * * osize,
                                       int nargout_,
                                       mxArray * size_A,
                                       mxArray * tsize_B,
                                       mxArray * tdims_A,
                                       mxArray * tdims_B);
static mxArray * Mtformarray_PredictNDimsG(int nargout_,
                                           mxArray * N,
                                           mxArray * L);
static mxArray * Mtformarray_CheckDimsAndSizes(int nargout_,
                                               mxArray * tdims_A,
                                               mxArray * tdims_B,
                                               mxArray * tsize_B_in,
                                               mxArray * tmap_B,
                                               mxArray * T);
static void Mtformarray_CheckInputArray(mxArray * A);
static void Mtformarray_CheckResampler(mxArray * R, mxArray * tdims_A);
static mxArray * Mtformarray_CheckFillArray(int nargout_,
                                            mxArray * F_in,
                                            mxArray * osize);
static mxArray * Mtformarray_IsFinitePositiveIntegerRowVector(int nargout_,
                                                              mxArray * v);

static mexFunctionTableEntry local_function_table_[13]
  = { { "resample", mlxTformarray_resample, 8, 1, NULL },
      { "ConstructSubscripts", mlxTformarray_ConstructSubscripts, 4, 2, NULL },
      { "ConstructGrid", mlxTformarray_ConstructGrid, 2, 1, NULL },
      { "CombinedGrid", mlxTformarray_CombinedGrid, -1, 1, NULL },
      { "GetBlocking", mlxTformarray_GetBlocking, 2, 1, NULL },
      { "GetBlockLimits", mlxTformarray_GetBlockLimits, 2, 2, NULL },
      { "fullsizes", mlxTformarray_fullsizes, 4, 3, NULL },
      { "PredictNDimsG", mlxTformarray_PredictNDimsG, 2, 1, NULL },
      { "CheckDimsAndSizes", mlxTformarray_CheckDimsAndSizes, 5, 1, NULL },
      { "CheckInputArray", mlxTformarray_CheckInputArray, 1, 0, NULL },
      { "CheckResampler", mlxTformarray_CheckResampler, 2, 0, NULL },
      { "CheckFillArray", mlxTformarray_CheckFillArray, 2, 1, NULL },
      { "IsFinitePositiveIntegerRowVector",
        mlxTformarray_IsFinitePositiveIntegerRowVector, 1, 1, NULL } };

_mexLocalFunctionTable _local_function_table_tformarray
  = { 13, local_function_table_ };

/*
 * The function "mlfTformarray" contains the normal interface for the
 * "tformarray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 1-254). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfTformarray(mxArray * A,
                        mxArray * T,
                        mxArray * R,
                        mxArray * tdims_A,
                        mxArray * tdims_B,
                        mxArray * tsize_B,
                        mxArray * tmap_B,
                        mxArray * F) {
    int nargout = 1;
    mxArray * B = NULL;
    mlfEnterNewContext(0, 8, A, T, R, tdims_A, tdims_B, tsize_B, tmap_B, F);
    B = Mtformarray(nargout, A, T, R, tdims_A, tdims_B, tsize_B, tmap_B, F);
    mlfRestorePreviousContext(
      0, 8, A, T, R, tdims_A, tdims_B, tsize_B, tmap_B, F);
    return mlfReturnValue(B);
}

/*
 * The function "mlxTformarray" contains the feval interface for the
 * "tformarray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 1-254). The feval
 * function calls the implementation version of tformarray through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxTformarray(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[8];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray Line: 1 Column:"
            " 1 The function \"tformarray\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 8) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray Line: 1 Column"
            ": 1 The function \"tformarray\" was called with"
            " more than the declared number of inputs (8)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 8 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 8; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(
      0,
      8,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7]);
    mplhs[0]
      = Mtformarray(
          nlhs,
          mprhs[0],
          mprhs[1],
          mprhs[2],
          mprhs[3],
          mprhs[4],
          mprhs[5],
          mprhs[6],
          mprhs[7]);
    mlfRestorePreviousContext(
      0,
      8,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_resample" contains the normal interface for the
 * "tformarray/resample" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 254-264). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_resample(mxArray * A,
                                        mxArray * M,
                                        mxArray * tdims_A,
                                        mxArray * tdims_B,
                                        mxArray * fsize_A,
                                        mxArray * fsize_B,
                                        mxArray * F,
                                        mxArray * R) {
    int nargout = 1;
    mxArray * B = NULL;
    mlfEnterNewContext(0, 8, A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R);
    B
      = Mtformarray_resample(
          nargout, A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R);
    mlfRestorePreviousContext(
      0, 8, A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R);
    return mlfReturnValue(B);
}

/*
 * The function "mlxTformarray_resample" contains the feval interface for the
 * "tformarray/resample" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 254-264). The feval
 * function calls the implementation version of tformarray/resample through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTformarray_resample(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[8];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/resample Line: 254 Co"
            "lumn: 1 The function \"tformarray/resample\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 8) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/resample Line: 254 Co"
            "lumn: 1 The function \"tformarray/resample\" was calle"
            "d with more than the declared number of inputs (8)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 8 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 8; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(
      0,
      8,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7]);
    mplhs[0]
      = Mtformarray_resample(
          nlhs,
          mprhs[0],
          mprhs[1],
          mprhs[2],
          mprhs[3],
          mprhs[4],
          mprhs[5],
          mprhs[6],
          mprhs[7]);
    mlfRestorePreviousContext(
      0,
      8,
      mprhs[0],
      mprhs[1],
      mprhs[2],
      mprhs[3],
      mprhs[4],
      mprhs[5],
      mprhs[6],
      mprhs[7]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_ConstructSubscripts" contains the normal
 * interface for the "tformarray/ConstructSubscripts" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 264-281). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_ConstructSubscripts(mxArray * * S,
                                                   mxArray * fsize_B,
                                                   mxArray * tdims_B,
                                                   mxArray * lo,
                                                   mxArray * hi) {
    int nargout = 1;
    mxArray * bsize_B = NULL;
    mxArray * S__ = NULL;
    mlfEnterNewContext(1, 4, S, fsize_B, tdims_B, lo, hi);
    if (S != NULL) {
        ++nargout;
    }
    bsize_B
      = Mtformarray_ConstructSubscripts(
          &S__, nargout, fsize_B, tdims_B, lo, hi);
    mlfRestorePreviousContext(1, 4, S, fsize_B, tdims_B, lo, hi);
    if (S != NULL) {
        mclCopyOutputArg(S, S__);
    } else {
        mxDestroyArray(S__);
    }
    return mlfReturnValue(bsize_B);
}

/*
 * The function "mlxTformarray_ConstructSubscripts" contains the feval
 * interface for the "tformarray/ConstructSubscripts" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 264-281). The feval
 * function calls the implementation version of tformarray/ConstructSubscripts
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_ConstructSubscripts(int nlhs,
                                              mxArray * plhs[],
                                              int nrhs,
                                              mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/ConstructSubscripts Line: 264"
            " Column: 1 The function \"tformarray/ConstructSubscripts\" was"
            " called with more than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/ConstructSubscripts Line: 26"
            "4 Column: 1 The function \"tformarray/ConstructSubscripts\" w"
            "as called with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mtformarray_ConstructSubscripts(
          &mplhs[1], nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfTformarray_ConstructGrid" contains the normal interface for
 * the "tformarray/ConstructGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 281-296). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_ConstructGrid(mxArray * lo, mxArray * hi) {
    int nargout = 1;
    mxArray * G = NULL;
    mlfEnterNewContext(0, 2, lo, hi);
    G = Mtformarray_ConstructGrid(nargout, lo, hi);
    mlfRestorePreviousContext(0, 2, lo, hi);
    return mlfReturnValue(G);
}

/*
 * The function "mlxTformarray_ConstructGrid" contains the feval interface for
 * the "tformarray/ConstructGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 281-296). The feval
 * function calls the implementation version of tformarray/ConstructGrid
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_ConstructGrid(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/ConstructGrid Line: 281 C"
            "olumn: 1 The function \"tformarray/ConstructGrid\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/ConstructGrid Line: 281 "
            "Column: 1 The function \"tformarray/ConstructGrid\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformarray_ConstructGrid(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_CombinedGrid" contains the normal interface for
 * the "tformarray/CombinedGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 296-348). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_CombinedGrid(mxArray * synthetic_varargin_argument,
                                            ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * G = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    G = Mtformarray_CombinedGrid(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(G);
}

/*
 * The function "mlxTformarray_CombinedGrid" contains the feval interface for
 * the "tformarray/CombinedGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 296-348). The feval
 * function calls the implementation version of tformarray/CombinedGrid through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTformarray_CombinedGrid(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CombinedGrid Line: 296 C"
            "olumn: 1 The function \"tformarray/CombinedGrid\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mtformarray_CombinedGrid(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfTformarray_GetBlocking" contains the normal interface for
 * the "tformarray/GetBlocking" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 348-476). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_GetBlocking(mxArray * tsize, mxArray * P) {
    int nargout = 1;
    mxArray * blockingfactors = NULL;
    mlfEnterNewContext(0, 2, tsize, P);
    blockingfactors = Mtformarray_GetBlocking(nargout, tsize, P);
    mlfRestorePreviousContext(0, 2, tsize, P);
    return mlfReturnValue(blockingfactors);
}

/*
 * The function "mlxTformarray_GetBlocking" contains the feval interface for
 * the "tformarray/GetBlocking" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 348-476). The feval
 * function calls the implementation version of tformarray/GetBlocking through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTformarray_GetBlocking(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/GetBlocking Line: 348 C"
            "olumn: 1 The function \"tformarray/GetBlocking\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/GetBlocking Line: 348 C"
            "olumn: 1 The function \"tformarray/GetBlocking\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformarray_GetBlocking(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_GetBlockLimits" contains the normal interface
 * for the "tformarray/GetBlockLimits" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 476-509). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_GetBlockLimits(mxArray * * hi,
                                              mxArray * tsize_B,
                                              mxArray * blockingfactors) {
    int nargout = 1;
    mxArray * lo = NULL;
    mxArray * hi__ = NULL;
    mlfEnterNewContext(1, 2, hi, tsize_B, blockingfactors);
    if (hi != NULL) {
        ++nargout;
    }
    lo = Mtformarray_GetBlockLimits(&hi__, nargout, tsize_B, blockingfactors);
    mlfRestorePreviousContext(1, 2, hi, tsize_B, blockingfactors);
    if (hi != NULL) {
        mclCopyOutputArg(hi, hi__);
    } else {
        mxDestroyArray(hi__);
    }
    return mlfReturnValue(lo);
}

/*
 * The function "mlxTformarray_GetBlockLimits" contains the feval interface for
 * the "tformarray/GetBlockLimits" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 476-509). The feval
 * function calls the implementation version of tformarray/GetBlockLimits
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_GetBlockLimits(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/GetBlockLimits Line: 476 "
            "Column: 1 The function \"tformarray/GetBlockLimits\" was c"
            "alled with more than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/GetBlockLimits Line: 476 "
            "Column: 1 The function \"tformarray/GetBlockLimits\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformarray_GetBlockLimits(&mplhs[1], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfTformarray_fullsizes" contains the normal interface for the
 * "tformarray/fullsizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 509-568). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_fullsizes(mxArray * * fsize_B,
                                         mxArray * * osize,
                                         mxArray * size_A,
                                         mxArray * tsize_B,
                                         mxArray * tdims_A,
                                         mxArray * tdims_B) {
    int nargout = 1;
    mxArray * fsize_A = NULL;
    mxArray * fsize_B__ = NULL;
    mxArray * osize__ = NULL;
    mlfEnterNewContext(2, 4, fsize_B, osize, size_A, tsize_B, tdims_A, tdims_B);
    if (fsize_B != NULL) {
        ++nargout;
    }
    if (osize != NULL) {
        ++nargout;
    }
    fsize_A
      = Mtformarray_fullsizes(
          &fsize_B__, &osize__, nargout, size_A, tsize_B, tdims_A, tdims_B);
    mlfRestorePreviousContext(
      2, 4, fsize_B, osize, size_A, tsize_B, tdims_A, tdims_B);
    if (fsize_B != NULL) {
        mclCopyOutputArg(fsize_B, fsize_B__);
    } else {
        mxDestroyArray(fsize_B__);
    }
    if (osize != NULL) {
        mclCopyOutputArg(osize, osize__);
    } else {
        mxDestroyArray(osize__);
    }
    return mlfReturnValue(fsize_A);
}

/*
 * The function "mlxTformarray_fullsizes" contains the feval interface for the
 * "tformarray/fullsizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 509-568). The feval
 * function calls the implementation version of tformarray/fullsizes through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxTformarray_fullsizes(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/fullsizes Line: 509 Co"
            "lumn: 1 The function \"tformarray/fullsizes\" was calle"
            "d with more than the declared number of outputs (3)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/fullsizes Line: 509 Co"
            "lumn: 1 The function \"tformarray/fullsizes\" was calle"
            "d with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mtformarray_fullsizes(
          &mplhs[1], &mplhs[2], nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfTformarray_PredictNDimsG" contains the normal interface for
 * the "tformarray/PredictNDimsG" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 568-582). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_PredictNDimsG(mxArray * N, mxArray * L) {
    int nargout = 1;
    mxArray * K = NULL;
    mlfEnterNewContext(0, 2, N, L);
    K = Mtformarray_PredictNDimsG(nargout, N, L);
    mlfRestorePreviousContext(0, 2, N, L);
    return mlfReturnValue(K);
}

/*
 * The function "mlxTformarray_PredictNDimsG" contains the feval interface for
 * the "tformarray/PredictNDimsG" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 568-582). The feval
 * function calls the implementation version of tformarray/PredictNDimsG
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_PredictNDimsG(int nlhs,
                                        mxArray * plhs[],
                                        int nrhs,
                                        mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/PredictNDimsG Line: 568 C"
            "olumn: 1 The function \"tformarray/PredictNDimsG\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/PredictNDimsG Line: 568 "
            "Column: 1 The function \"tformarray/PredictNDimsG\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformarray_PredictNDimsG(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_CheckDimsAndSizes" contains the normal interface
 * for the "tformarray/CheckDimsAndSizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 582-664). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_CheckDimsAndSizes(mxArray * tdims_A,
                                                 mxArray * tdims_B,
                                                 mxArray * tsize_B_in,
                                                 mxArray * tmap_B,
                                                 mxArray * T) {
    int nargout = 1;
    mxArray * tsize_B = NULL;
    mlfEnterNewContext(0, 5, tdims_A, tdims_B, tsize_B_in, tmap_B, T);
    tsize_B
      = Mtformarray_CheckDimsAndSizes(
          nargout, tdims_A, tdims_B, tsize_B_in, tmap_B, T);
    mlfRestorePreviousContext(0, 5, tdims_A, tdims_B, tsize_B_in, tmap_B, T);
    return mlfReturnValue(tsize_B);
}

/*
 * The function "mlxTformarray_CheckDimsAndSizes" contains the feval interface
 * for the "tformarray/CheckDimsAndSizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 582-664). The feval
 * function calls the implementation version of tformarray/CheckDimsAndSizes
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_CheckDimsAndSizes(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[5];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckDimsAndSizes Line: 582"
            " Column: 1 The function \"tformarray/CheckDimsAndSizes\" was"
            " called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckDimsAndSizes Line: 582"
            " Column: 1 The function \"tformarray/CheckDimsAndSizes\" was"
            " called with more than the declared number of inputs (5)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 5 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 5; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mplhs[0]
      = Mtformarray_CheckDimsAndSizes(
          nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    mlfRestorePreviousContext(
      0, 5, mprhs[0], mprhs[1], mprhs[2], mprhs[3], mprhs[4]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_CheckInputArray" contains the normal interface
 * for the "tformarray/CheckInputArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 664-672). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTformarray_CheckInputArray(mxArray * A) {
    mlfEnterNewContext(0, 1, A);
    Mtformarray_CheckInputArray(A);
    mlfRestorePreviousContext(0, 1, A);
}

/*
 * The function "mlxTformarray_CheckInputArray" contains the feval interface
 * for the "tformarray/CheckInputArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 664-672). The feval
 * function calls the implementation version of tformarray/CheckInputArray
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_CheckInputArray(int nlhs,
                                          mxArray * plhs[],
                                          int nrhs,
                                          mxArray * prhs[]) {
    mxArray * mprhs[1];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckInputArray Line: 664 "
            "Column: 1 The function \"tformarray/CheckInputArray\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckInputArray Line: 664 "
            "Column: 1 The function \"tformarray/CheckInputArray\" was c"
            "alled with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    Mtformarray_CheckInputArray(mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
}

/*
 * The function "mlfTformarray_CheckResampler" contains the normal interface
 * for the "tformarray/CheckResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 672-684). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlfTformarray_CheckResampler(mxArray * R, mxArray * tdims_A) {
    mlfEnterNewContext(0, 2, R, tdims_A);
    Mtformarray_CheckResampler(R, tdims_A);
    mlfRestorePreviousContext(0, 2, R, tdims_A);
}

/*
 * The function "mlxTformarray_CheckResampler" contains the feval interface for
 * the "tformarray/CheckResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 672-684). The feval
 * function calls the implementation version of tformarray/CheckResampler
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_CheckResampler(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[2];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckResampler Line: 672 "
            "Column: 1 The function \"tformarray/CheckResampler\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckResampler Line: 672 "
            "Column: 1 The function \"tformarray/CheckResampler\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    Mtformarray_CheckResampler(mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
}

/*
 * The function "mlfTformarray_CheckFillArray" contains the normal interface
 * for the "tformarray/CheckFillArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 684-715). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfTformarray_CheckFillArray(mxArray * F_in, mxArray * osize) {
    int nargout = 1;
    mxArray * F = NULL;
    mlfEnterNewContext(0, 2, F_in, osize);
    F = Mtformarray_CheckFillArray(nargout, F_in, osize);
    mlfRestorePreviousContext(0, 2, F_in, osize);
    return mlfReturnValue(F);
}

/*
 * The function "mlxTformarray_CheckFillArray" contains the feval interface for
 * the "tformarray/CheckFillArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 684-715). The feval
 * function calls the implementation version of tformarray/CheckFillArray
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxTformarray_CheckFillArray(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckFillArray Line: 684 "
            "Column: 1 The function \"tformarray/CheckFillArray\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/CheckFillArray Line: 684 "
            "Column: 1 The function \"tformarray/CheckFillArray\" was c"
            "alled with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mtformarray_CheckFillArray(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfTformarray_IsFinitePositiveIntegerRowVector" contains the
 * normal interface for the "tformarray/IsFinitePositiveIntegerRowVector"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformarray.m"
 * (lines 715-729). This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static mxArray * mlfTformarray_IsFinitePositiveIntegerRowVector(mxArray * v) {
    int nargout = 1;
    mxArray * q = NULL;
    mlfEnterNewContext(0, 1, v);
    q = Mtformarray_IsFinitePositiveIntegerRowVector(nargout, v);
    mlfRestorePreviousContext(0, 1, v);
    return mlfReturnValue(q);
}

/*
 * The function "mlxTformarray_IsFinitePositiveIntegerRowVector" contains the
 * feval interface for the "tformarray/IsFinitePositiveIntegerRowVector"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformarray.m"
 * (lines 715-729). The feval function calls the implementation version of
 * tformarray/IsFinitePositiveIntegerRowVector through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxTformarray_IsFinitePositiveIntegerRowVector(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/IsFinitePositiveInte"
            "gerRowVector Line: 715 Column: 1 The function \"tform"
            "array/IsFinitePositiveIntegerRowVector\" was called w"
            "ith more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: tformarray/IsFinitePositiveInte"
            "gerRowVector Line: 715 Column: 1 The function \"tform"
            "array/IsFinitePositiveIntegerRowVector\" was called w"
            "ith more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mtformarray_IsFinitePositiveIntegerRowVector(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mtformarray" is the implementation version of the "tformarray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformarray.m"
 * (lines 1-254). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function B = tformarray( A, T, R, tdims_A, tdims_B, tsize_B, tmap_B, F )
 */
static mxArray * Mtformarray(int nargout_,
                             mxArray * A,
                             mxArray * T,
                             mxArray * R,
                             mxArray * tdims_A,
                             mxArray * tdims_B,
                             mxArray * tsize_B,
                             mxArray * tmap_B,
                             mxArray * F) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    int nargin_
      = mclNargin(8, A, T, R, tdims_A, tdims_B, tsize_B, tmap_B, F, NULL);
    mxArray * B = NULL;
    mxArray * S = NULL;
    mxArray * bsize_B = NULL;
    mxArray * i = NULL;
    mxArray * M = NULL;
    mxArray * lo = NULL;
    mxArray * hi = NULL;
    mxArray * G = NULL;
    mxArray * blockingfactors = NULL;
    mxArray * nBlocks = NULL;
    mxArray * osize = NULL;
    mxArray * fsize_B = NULL;
    mxArray * fsize_A = NULL;
    mxArray * ans = NULL;
    mxArray * message = NULL;
    mclCopyArray(&A);
    mclCopyArray(&T);
    mclCopyArray(&R);
    mclCopyArray(&tdims_A);
    mclCopyArray(&tdims_B);
    mclCopyArray(&tsize_B);
    mclCopyArray(&tmap_B);
    mclCopyArray(&F);
    /*
     * %TFORMARRAY Geometric transformation of a multidimensional array. 
     * %   B = TFORMARRAY(A,T,R,TDIMS_A,TDIMS_B,TSIZE_B,TMAP_B,F) applies
     * %   a geometric transformation to array A to produce array B.
     * %
     * %   TFORMARRAY is like IMTRANSFORM, but is intended for problems
     * %   involving higher-dimensioned arrays or mixed input/output
     * %   dimensionality, or requiring greater user control or customization.
     * %   (Anything -- and more -- that can be accomplished with IMTRANSFORM
     * %   can be accomplished with a combination of MAKETFORM, MAKERESAMPLER,
     * %   FINDBOUNDS, and TFORMARRAY, but for many tasks involving 2-D images,
     * %   IMTRANSFORM is simpler.)
     * %
     * %   Brief description of inputs
     * %   ---------------------------
     * %   A         Input array or image
     * %   T         Geometric transformation, typically created with
     * %             MAKETFORM
     * %   R         Resampler, typically created with MAKERESAMPLER
     * %   TDIMS_A   Row vector listing the input transform dimensions
     * %   TDIMS_B   Row vector listing the output transform dimensions
     * %   TSIZE_B   Output array size in the transform dimensions
     * %   TMAP_B    Array of point locations in output space; can be used as an
     * %             alternative way to specify a geometric transformation
     * %   F         Array of fill values
     * %
     * %   Detailed description of inputs
     * %   ------------------------------
     * %   A         A can be any nonsparse numeric array, and can be real or
     * %             complex. It can also be logical.
     * %
     * %   T         T is a structure that defines a particular geometric
     * %             transformation.  For each location in the output transform
     * %             subscript space (as defined by TDIMS_B and TSIZE_B),
     * %             TFORMARRAY uses T and the function TFORMINV to compute the
     * %             corresponding location in the input transform subscript
     * %             space (as defined by TDIMS_A and SIZE(A)).
     * %
     * %             If T is empty, then TFORMARRAY operates as a direct resampling
     * %             function, applying the resampler defined in R to compute
     * %             values at each transform space location defined in TMAP_B 
     * %             (if TMAP_B is non-empty) or at each location in the output
     * %             transform subscript grid.
     * %
     * %   R         R is a structure that defines how to interpolate values of
     * %             the input array at specified locations.  R is usually
     * %             created with MAKERESAMPLER, which allows fine control
     * %             over how to interpolate along each dimension, as well as
     * %             what input array values to use when interpolating close the
     * %             edge of the array.
     * %
     * %   TDIMS_A   TDIMS_A and TDIMS_B indicate which dimensions of the input
     * %   TDIMS_B   and output arrays are involved in the geometric
     * %             transformation.  Each element must be unique, and must be a
     * %             positive integer.  The entries need not be listed in
     * %             increasing order, but the order matters.  It specifies the
     * %             precise correspondence between dimensions of arrays A and B
     * %             and the input and output spaces of the transformer, T.
     * %             LENGTH(TDIMS_A) must equal T.ndims_in, and LENGTH(TDIMS_B)
     * %             must equal T.ndims_out.
     * %
     * %             Suppose, for example, that T is a 2-D transformation,
     * %             TDIMS_A = [2 1], and TDIMS_B = [1 2].  Then the column
     * %             dimension and row dimension of A correspond to the first
     * %             and second transformation input-space dimensions,
     * %             respectively.  The row and column dimensions of B
     * %             correspond to the first and second output-space
     * %             dimensions, respectively.
     * %
     * %   TSIZE_B   TSIZE_B specifies the size of the array B along the
     * %             output-space transform dimensions.  Note that the size of B
     * %             along nontransform dimensions is taken directly from the
     * %             size of A along those dimensions.  If, for example, T is a
     * %             2-D transformation, size(A) = [480 640 3 10], TDIMS_B is
     * %             [2 1], and TSIZE_B is [300 200], then size(B) is [200 300 3].
     * %
     * %   TMAP_B    TMAP_B is an optional array that provides an alternative
     * %             way of specifying the correspondence between the position
     * %             of elements of B and the location in output transform
     * %             space.  TMAP_B can be used, for example, to compute the
     * %             result of an image warp at a set of arbitrary locations in
     * %             output space.  If TMAP_B is not empty, then the size of
     * %             TMAP_B takes the form: 
     * %
     * %                 [D1 D2 D3 ... DN L]
     * %
     * %             where N equals length(TDIMS_B).  The vector [D1 D2 ... DN]
     * %             is used in place of TSIZE_B.  If TMAP_B is not empty, then
     * %             TSIZE_B should be [].
     * %
     * %             The value of L depends on whether or not T is empty.  If T
     * %             is not empty, then L is T.ndims_out, and each L-dimension
     * %             point in TMAP_B is transformed to an input-space location
     * %             using T.  If T is empty, then L is LENGTH(TDIMS_A), and
     * %             each L-dimensional point in TMAP_B is used directly as a
     * %             location in input space.
     * %
     * %   F         F is a double-precision array containing fill values.
     * %             The fill values in F may be used in three situations:
     * %
     * %             (1) When a separable resampler is created with MAKERESAMPLER
     * %                 and its PADMETHOD is set to either 'fill' or 'bound',
     * % 
     * %             (2) When a custom resampler is used that supports the 'fill'
     * %                 or 'bound' pad methods (with behavior that is specific
     * %                 to the customization), or
     * % 
     * %             (3) When the map from the transform dimensions of B
     * %                 to the transform dimensions of A is deliberately
     * %                 undefined for some points. Such points are encoded in
     * %                 the input transform space by NaNs in either TMAP_B or
     * %                 in the output of TFORMINV.
     * %
     * %             In the first two cases, fill values are used to compute values
     * %             for output locations that map outside or near edges of the input
     * %             array.  Fill values are copied into B when output locations map
     * %             well outside the input array.  Type 'help makeresampler' for
     * %             further details on 'fill' and 'bound'.
     * %
     * %             F can be a scalar (including NaN), in which case its value
     * %             is replicated across all the nontransform dimensions.  Or F
     * %             can be a nonscalar whose size depends on size(A) in the
     * %             nontransform dimensions.  Specifically, if K is the J-th
     * %             nontransform dimension of A, then SIZE(F,J) must be either
     * %             SIZE(A,K) or 1.  As a convenience to the user, TFORMARRAY
     * %             replicates F across any dimensions with unit size such that
     * %             after the replication SIZE(F,J) equals size(A,K).
     * %
     * %             For example, suppose A represents 10 RGB images and has
     * %             size 200-by-200-by-3-by-10, T is a 2-D transformation, and
     * %             TDIMS_A and TDIMS_B are both [1 2].  In other words,
     * %             TFORMARRAY will apply the same 2-D transform to each color
     * %             plane of each of the 10 RGB images.  In this situation you
     * %             have several options for F:
     * %
     * %             - F can be a scalar, in which case the same fill value
     * %               is used for each color plane of all 10 images.
     * %
     * %             - F can be a 3-by-1 vector, [R G B]'.  Then R, G, and B
     * %               will be used as the fill values for the corresponding
     * %               color planes of each of the 10 images.  This can be
     * %               interpreted as specifying an RGB "fill color," with
     * %               the same color used for all 10 images.
     * %
     * %             - F can be a 1-by-10 vector.  This can be interpreted as
     * %               specifying a different fill value for each of 10
     * %               images, with that fill value being used for all three
     * %               color planes.  (Each image gets a distinct grayscale
     * %               fill-color.)
     * %
     * %             - F can be a 3-by-10 matrix, which can be interpreted as
     * %               supplying a different RGB fill-color for each of the
     * %               10 images.
     * %
     * %   Example
     * %   -------
     * %   Create a 2-by-2 checkerboard image where each square is 20 pixels
     * %   wide, then transform it with a projective transformation.  Use a
     * %   pad method of 'circular' when creating a resampler, so that the
     * %   output appears to be a perspective view of an infinite checkerboard.
     * %   Swap the output dimensions.  Specify a 100-by-100 output image.
     * %   Leave TMAP_B empty, since TSIZE_B is specified.  Leave the fill
     * %   value empty, since it won't be needed.
     * %
     * %       I = checkerboard(20,1,1);
     * %       figure; imshow(I)
     * %       T = maketform('projective',[1 1; 41 1; 41 41;   1 41],...
     * %                                  [5 5; 40 5; 35 30; -10 30]);
     * %       R = makeresampler('cubic','circular');
     * %       J = tformarray(I,T,R,[1 2],[2 1],[100 100],[],[]);
     * %       figure; imshow(J)
     * %
     * %   See also IMTRANSFORM, MAKERESAMPLER, MAKETFORM, FINDBOUNDS.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.9 $ $Date: 2002/03/15 15:29:20 $
     * 
     * % Start checking the inputs.
     * message = nargchk(8,8,nargin);
     */
    mlfAssign(&message, mlfNargchk(_mxarray0_, _mxarray0_, mlfScalar(nargin_)));
    /*
     * if ~isempty(message)
     */
    if (mclNotBool(mlfIsempty(mclVv(message, "message")))) {
        /*
         * error(message);
         */
        mlfError(mclVv(message, "message"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % Construct a new tsize_B if tmap_B is non-empty.
     * tsize_B = CheckDimsAndSizes( tdims_A, tdims_B, tsize_B, tmap_B, T );
     */
    mlfAssign(
      &tsize_B,
      mlfTformarray_CheckDimsAndSizes(
        mclVa(tdims_A, "tdims_A"),
        mclVa(tdims_B, "tdims_B"),
        mclVa(tsize_B, "tsize_B"),
        mclVa(tmap_B, "tmap_B"),
        mclVa(T, "T")));
    /*
     * 
     * % Get the 'full sizes' of A and B and their non-transform sizes (osize).
     * [fsize_A, fsize_B, osize] = fullsizes(size(A), tsize_B, tdims_A, tdims_B);
     */
    mlfAssign(
      &fsize_A,
      mlfTformarray_fullsizes(
        &fsize_B,
        &osize,
        mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL),
        mclVa(tsize_B, "tsize_B"),
        mclVa(tdims_A, "tdims_A"),
        mclVa(tdims_B, "tdims_B")));
    /*
     * 
     * % Finish checking the inputs.
     * CheckInputArray( A );
     */
    mlfTformarray_CheckInputArray(mclVa(A, "A"));
    /*
     * CheckResampler( R, tdims_A );
     */
    mlfTformarray_CheckResampler(mclVa(R, "R"), mclVa(tdims_A, "tdims_A"));
    /*
     * F = CheckFillArray( F, osize );
     */
    mlfAssign(
      &F, mlfTformarray_CheckFillArray(mclVa(F, "F"), mclVv(osize, "osize")));
    /*
     * 
     * % Determine blocking, if any.
     * if ~isempty(tmap_B)
     */
    if (mclNotBool(mlfIsempty(mclVa(tmap_B, "tmap_B")))) {
        /*
         * nBlocks = 1;  % Must process in a single block if tmap_B is supplied.
         */
        mlfAssign(&nBlocks, _mxarray1_);
    /*
     * else
     */
    } else {
        /*
         * blockingfactors = GetBlocking(tsize_B,max(length(tdims_A),length(tdims_B)));
         */
        mlfAssign(
          &blockingfactors,
          mlfTformarray_GetBlocking(
            mclVa(tsize_B, "tsize_B"),
            mlfScalar(
              svDoubleScalarMax(
                (double) mclLengthInt(mclVa(tdims_A, "tdims_A")),
                (double) mclLengthInt(mclVa(tdims_B, "tdims_B"))))));
        /*
         * nBlocks = prod(blockingfactors);
         */
        mlfAssign(
          &nBlocks, mlfProd(mclVv(blockingfactors, "blockingfactors"), NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % If there is no tmap_B, process large arrays in multiple blocks to conserve
     * % the memory required by the output grid G and its mapping to the input
     * % space M.  Otherwise, do the resampling in one large block.
     * if nBlocks == 1
     */
    if (mclEqBool(mclVv(nBlocks, "nBlocks"), _mxarray1_)) {
        /*
         * % If not already supplied in tmap_B, construct a grid G mapping B's
         * % transform subscripts to T's output space or (if T = []) directly to
         * % A's transform subscripts.
         * if ~isempty(tmap_B)
         */
        if (mclNotBool(mlfIsempty(mclVa(tmap_B, "tmap_B")))) {
            /*
             * G = tmap_B;
             */
            mlfAssign(&G, mclVa(tmap_B, "tmap_B"));
        /*
         * else
         */
        } else {
            /*
             * hi = tsize_B;
             */
            mlfAssign(&hi, mclVa(tsize_B, "tsize_B"));
            /*
             * lo = ones(1,length(hi));
             */
            mlfAssign(
              &lo,
              mlfOnes(
                _mxarray1_, mlfScalar(mclLengthInt(mclVv(hi, "hi"))), NULL));
            /*
             * G = ConstructGrid(lo,hi);
             */
            mlfAssign(
              &G,
              mlfTformarray_ConstructGrid(mclVv(lo, "lo"), mclVv(hi, "hi")));
        /*
         * end
         */
        }
        /*
         * 
         * % If there is a tform, use it to extend the map in G to A's
         * % transform subscripts.
         * if ~isempty(T)
         */
        if (mclNotBool(mlfIsempty(mclVa(T, "T")))) {
            /*
             * M = tforminv(G,T);
             */
            mlfAssign(&M, mlfTforminv(mclVv(G, "G"), mclVa(T, "T")));
        /*
         * else
         */
        } else {
            /*
             * M = G;
             */
            mlfAssign(&M, mclVv(G, "G"));
        /*
         * end
         */
        }
        /*
         * G = []; % Free memory used by G (which is no longer needed).
         */
        mlfAssign(&G, _mxarray2_);
        /*
         * 
         * % Resample A using the map M and resampler R.
         * B = resample(A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R);
         */
        mlfAssign(
          &B,
          mlfTformarray_resample(
            mclVa(A, "A"),
            mclVv(M, "M"),
            mclVa(tdims_A, "tdims_A"),
            mclVa(tdims_B, "tdims_B"),
            mclVv(fsize_A, "fsize_A"),
            mclVv(fsize_B, "fsize_B"),
            mclVa(F, "F"),
            mclVa(R, "R")));
    /*
     * else
     */
    } else {
        /*
         * % Pre-allocate B with size fsize_B and class(B) = class(A).
         * B(prod(fsize_B)) = A(1);
         */
        mclArrayAssign1(
          &B,
          mclIntArrayRef1(mclVa(A, "A"), 1),
          mlfProd(mclVv(fsize_B, "fsize_B"), NULL));
        /*
         * B = reshape(B,fsize_B);
         */
        mlfAssign(
          &B, mlfReshape(mclVv(B, "B"), mclVv(fsize_B, "fsize_B"), NULL));
        /*
         * 
         * % Loop over blocks in output transform space... 
         * [lo, hi] = GetBlockLimits(tsize_B, blockingfactors);
         */
        mlfAssign(
          &lo,
          mlfTformarray_GetBlockLimits(
            &hi,
            mclVa(tsize_B, "tsize_B"),
            mclVv(blockingfactors, "blockingfactors")));
        /*
         * for i = 1:nBlocks
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(nBlocks, "nBlocks"));
            if (v_ > e_) {
                mlfAssign(&i, _mxarray2_);
            } else {
                /*
                 * % Construct the geometric map for the current block.
                 * G = ConstructGrid(lo(i,:),hi(i,:));
                 * if ~isempty(T)
                 * M = tforminv(G,T);
                 * else
                 * M = G;
                 * end
                 * G = []; % Free memory used by G (which is no longer needed).
                 * 
                 * % Construct size and subscript arrays for the block, then resample.
                 * [bsize_B, S] = ConstructSubscripts(fsize_B, tdims_B, lo(i,:), hi(i,:));
                 * B(S{:}) = resample(A, M, tdims_A, tdims_B, fsize_A, bsize_B, F, R);
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &G,
                      mlfTformarray_ConstructGrid(
                        mclArrayRef2(
                          mclVv(lo, "lo"),
                          mlfScalar(v_),
                          mlfCreateColonIndex()),
                        mclArrayRef2(
                          mclVv(hi, "hi"),
                          mlfScalar(v_),
                          mlfCreateColonIndex())));
                    if (mclNotBool(mlfIsempty(mclVa(T, "T")))) {
                        mlfAssign(
                          &M, mlfTforminv(mclVv(G, "G"), mclVa(T, "T")));
                    } else {
                        mlfAssign(&M, mclVv(G, "G"));
                    }
                    mlfAssign(&G, _mxarray2_);
                    mlfAssign(
                      &bsize_B,
                      mlfTformarray_ConstructSubscripts(
                        &S,
                        mclVv(fsize_B, "fsize_B"),
                        mclVa(tdims_B, "tdims_B"),
                        mclArrayRef2(
                          mclVv(lo, "lo"),
                          mlfScalar(v_),
                          mlfCreateColonIndex()),
                        mclArrayRef2(
                          mclVv(hi, "hi"),
                          mlfScalar(v_),
                          mlfCreateColonIndex())));
                    mclArrayAssign1(
                      &B,
                      mlfTformarray_resample(
                        mclVa(A, "A"),
                        mclVv(M, "M"),
                        mclVa(tdims_A, "tdims_A"),
                        mclVa(tdims_B, "tdims_B"),
                        mclVv(fsize_A, "fsize_A"),
                        mclVv(bsize_B, "bsize_B"),
                        mclVa(F, "F"),
                        mclVa(R, "R")),
                      mlfIndexRef(mclVv(S, "S"), "{?}", mlfCreateColonIndex()));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&i, mlfScalar(v_));
            }
        }
    /*
     * end
     */
    }
    mclValidateOutput(B, 1, nargout_, "B", "tformarray");
    mxDestroyArray(message);
    mxDestroyArray(ans);
    mxDestroyArray(fsize_A);
    mxDestroyArray(fsize_B);
    mxDestroyArray(osize);
    mxDestroyArray(nBlocks);
    mxDestroyArray(blockingfactors);
    mxDestroyArray(G);
    mxDestroyArray(hi);
    mxDestroyArray(lo);
    mxDestroyArray(M);
    mxDestroyArray(i);
    mxDestroyArray(bsize_B);
    mxDestroyArray(S);
    mxDestroyArray(F);
    mxDestroyArray(tmap_B);
    mxDestroyArray(tsize_B);
    mxDestroyArray(tdims_B);
    mxDestroyArray(tdims_A);
    mxDestroyArray(R);
    mxDestroyArray(T);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return B;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_resample" is the implementation version of the
 * "tformarray/resample" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 254-264). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function B = resample( A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R )
 */
static mxArray * Mtformarray_resample(int nargout_,
                                      mxArray * A,
                                      mxArray * M,
                                      mxArray * tdims_A,
                                      mxArray * tdims_B,
                                      mxArray * fsize_A,
                                      mxArray * fsize_B,
                                      mxArray * F,
                                      mxArray * R) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * B = NULL;
    mclCopyArray(&A);
    mclCopyArray(&M);
    mclCopyArray(&tdims_A);
    mclCopyArray(&tdims_B);
    mclCopyArray(&fsize_A);
    mclCopyArray(&fsize_B);
    mclCopyArray(&F);
    mclCopyArray(&R);
    /*
     * 
     * % Evaluates the resampling function defined in the resampler R at
     * % each point in the subscript map M and replicated across all the
     * % non-transform dimensions of A, producing a warped version of A in B.
     * 
     * B = feval(R.resamp_fcn, A, M, tdims_A, tdims_B, fsize_A, fsize_B, F, R );
     */
    mlfAssign(
      &B,
      mlfFeval(
        mclValueVarargout(),
        mlfIndexRef(mclVa(R, "R"), ".resamp_fcn"),
        mclVa(A, "A"),
        mclVa(M, "M"),
        mclVa(tdims_A, "tdims_A"),
        mclVa(tdims_B, "tdims_B"),
        mclVa(fsize_A, "fsize_A"),
        mclVa(fsize_B, "fsize_B"),
        mclVa(F, "F"),
        mclVa(R, "R"),
        NULL));
    mclValidateOutput(B, 1, nargout_, "B", "tformarray/resample");
    mxDestroyArray(R);
    mxDestroyArray(F);
    mxDestroyArray(fsize_B);
    mxDestroyArray(fsize_A);
    mxDestroyArray(tdims_B);
    mxDestroyArray(tdims_A);
    mxDestroyArray(M);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return B;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_ConstructSubscripts" is the implementation version
 * of the "tformarray/ConstructSubscripts" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 264-281). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [bsize_B, S] = ConstructSubscripts( fsize_B, tdims_B, lo, hi )
 */
static mxArray * Mtformarray_ConstructSubscripts(mxArray * * S,
                                                 int nargout_,
                                                 mxArray * fsize_B,
                                                 mxArray * tdims_B,
                                                 mxArray * lo,
                                                 mxArray * hi) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * bsize_B = NULL;
    mxArray * i = NULL;
    mxArray * fdims_B = NULL;
    mclCopyArray(&fsize_B);
    mclCopyArray(&tdims_B);
    mclCopyArray(&lo);
    mclCopyArray(&hi);
    /*
     * 
     * % Determines the size of the block of array B bounded by the values in
     * % vectors LO and HI, and constructs an array of subscripts for assigning
     * % an array into that block.
     * 
     * bsize_B = fsize_B;
     */
    mlfAssign(&bsize_B, mclVa(fsize_B, "fsize_B"));
    /*
     * bsize_B(tdims_B) = hi - lo + 1;
     */
    mclArrayAssign1(
      &bsize_B,
      mclPlus(mclMinus(mclVa(hi, "hi"), mclVa(lo, "lo")), _mxarray1_),
      mclVa(tdims_B, "tdims_B"));
    /*
     * 
     * fdims_B = length(fsize_B);
     */
    mlfAssign(&fdims_B, mlfScalar(mclLengthInt(mclVa(fsize_B, "fsize_B"))));
    /*
     * S = repmat({':'},[1,fdims_B]);
     */
    mlfAssign(
      S,
      mlfRepmat(
        _mxarray3_,
        mlfHorzcat(_mxarray1_, mclVv(fdims_B, "fdims_B"), NULL),
        NULL));
    /*
     * for i = 1:length(tdims_B)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVa(tdims_B, "tdims_B"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray2_);
        } else {
            /*
             * S{tdims_B(i)} = lo(i) : hi(i);
             * end
             */
            for (; ; ) {
                mlfIndexAssign(
                  S,
                  "{?}",
                  mclIntArrayRef1(mclVa(tdims_B, "tdims_B"), v_),
                  mlfColon(
                    mclIntArrayRef1(mclVa(lo, "lo"), v_),
                    mclIntArrayRef1(mclVa(hi, "hi"), v_),
                    NULL));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    mclValidateOutput(
      bsize_B, 1, nargout_, "bsize_B", "tformarray/ConstructSubscripts");
    mclValidateOutput(*S, 2, nargout_, "S", "tformarray/ConstructSubscripts");
    mxDestroyArray(fdims_B);
    mxDestroyArray(i);
    mxDestroyArray(hi);
    mxDestroyArray(lo);
    mxDestroyArray(tdims_B);
    mxDestroyArray(fsize_B);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return bsize_B;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_ConstructGrid" is the implementation version of
 * the "tformarray/ConstructGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 281-296). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function G = ConstructGrid( lo, hi )
 */
static mxArray * Mtformarray_ConstructGrid(int nargout_,
                                           mxArray * lo,
                                           mxArray * hi) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * G = NULL;
    mxArray * E = NULL;
    mxArray * i = NULL;
    mxArray * N = NULL;
    mclCopyArray(&lo);
    mclCopyArray(&hi);
    /*
     * 
     * % Constructs a regular grid from the range of subscripts defined by
     * % vectors LO and HI, and packs the result into a single array, G.
     * % G is D(1) x D(2) x ... x D(N) x N where D(k) is the length of
     * % lo(k):hi(k) and N is the length of LO and HI.
     * 
     * N = length(hi);
     */
    mlfAssign(&N, mlfScalar(mclLengthInt(mclVa(hi, "hi"))));
    /*
     * for i = 1:N;
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(N, "N"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray2_);
        } else {
            /*
             * E{i} = lo(i):hi(i);  % The subscript range for each dimension
             * end
             */
            for (; ; ) {
                mlfIndexAssign(
                  &E,
                  "{?}",
                  mlfScalar(v_),
                  mlfColon(
                    mclIntArrayRef1(mclVa(lo, "lo"), v_),
                    mclIntArrayRef1(mclVa(hi, "hi"), v_),
                    NULL));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * G = CombinedGrid(E{:});
     */
    mlfAssign(
      &G,
      mlfTformarray_CombinedGrid(
        mlfIndexRef(mclVv(E, "E"), "{?}", mlfCreateColonIndex()), NULL));
    mclValidateOutput(G, 1, nargout_, "G", "tformarray/ConstructGrid");
    mxDestroyArray(N);
    mxDestroyArray(i);
    mxDestroyArray(E);
    mxDestroyArray(hi);
    mxDestroyArray(lo);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return G;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_CombinedGrid" is the implementation version of the
 * "tformarray/CombinedGrid" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 296-348). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function G = CombinedGrid(varargin)
 */
static mxArray * Mtformarray_CombinedGrid(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * G = NULL;
    mxArray * x = NULL;
    mxArray * colons = NULL;
    mxArray * D = NULL;
    mxArray * i = NULL;
    mxArray * ans = NULL;
    mxArray * N = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % If N >= 2, G = COMBINEDGRID(x1,x2,...,xN) is a memory-efficient
     * % equivalent to:
     * %
     * %   G = cell(N,1);
     * %   [G{:}] = ndgrid(x1,x2,...,xN);
     * %   G = cat(N + 1, G{:});
     * %
     * % (where x{i} = varargin{i} and D(i) is the number of
     * % elements in x{}).
     * %
     * % If N == 1, COMBINEDGRID returns x1 as a column vector. (The code
     * % with NDGRID replicates x1 across N columns, returning an N-by-N
     * % matrix -- which is inappropriate for our application.)
     * %
     * % N == 0 is not allowed.
     * 
     * N = length(varargin);
     */
    mlfAssign(&N, mlfScalar(mclLengthInt(mclVa(varargin, "varargin"))));
    /*
     * if N == 0
     */
    if (mclEqBool(mclVv(N, "N"), _mxarray6_)) {
        /*
         * error('Internal Error: COMBINEDGRID called with no arguments.');
         */
        mlfError(_mxarray7_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * for i=1:N
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(N, "N"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray2_);
        } else {
            /*
             * D(1,i) = prod(size(varargin{i}));
             * end
             */
            for (; ; ) {
                mclIntArrayAssign2(
                  &D,
                  mlfProd(
                    mclFeval(
                      mclValueVarargout(),
                      mlxSize,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"), "{?}", mlfScalar(v_)),
                      NULL),
                    NULL),
                  1,
                  v_);
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * 
     * if N == 1
     */
    if (mclEqBool(mclVv(N, "N"), _mxarray1_)) {
        /*
         * % Special handling required to avoid calling RESHAPE
         * % with a single-element size vector.
         * G = varargin{1}(:);
         */
        mlfAssign(
          &G,
          mlfIndexRef(
            mclVa(varargin, "varargin"),
            "{?}(?)",
            _mxarray1_,
            mlfCreateColonIndex()));
    /*
     * else
     */
    } else {
        /*
         * % Pre-allocate the output array.
         * G = zeros([D N]);
         */
        mlfAssign(
          &G, mlfZeros(mlfHorzcat(mclVv(D, "D"), mclVv(N, "N"), NULL), NULL));
        /*
         * 
         * % Prepare to generate a comma-separated list of N colons.
         * colons = repmat({':'},[1 N]);
         */
        mlfAssign(
          &colons,
          mlfRepmat(
            _mxarray3_, mlfHorzcat(_mxarray1_, mclVv(N, "N"), NULL), NULL));
        /*
         * 
         * for i=1:N
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(N, "N"));
            if (v_ > e_) {
                mlfAssign(&i, _mxarray2_);
            } else {
                /*
                 * % Extract the i-th vector, reshape it to run along the
                 * % i-th dimension (adding singleton dimensions as needed),
                 * % replicate it across all the other dimensions, and
                 * % copy it to G(:,:,...,:,i) -- with N colons.
                 * x = varargin{i}(:);
                 * x = reshape( x, [ones(1,i-1) D(i) ones(1,N-i)] );
                 * x = repmat(  x, [ D(1:i-1)    1     D(i+1:N) ] );
                 * G(colons{:},i) = x;
                 * end
                 */
                for (; ; ) {
                    mlfAssign(
                      &x,
                      mlfIndexRef(
                        mclVa(varargin, "varargin"),
                        "{?}(?)",
                        mlfScalar(v_),
                        mlfCreateColonIndex()));
                    mlfAssign(
                      &x,
                      mlfReshape(
                        mclVv(x, "x"),
                        mlfHorzcat(
                          mlfOnes(_mxarray1_, mlfScalar(v_ - 1), NULL),
                          mclIntArrayRef1(mclVv(D, "D"), v_),
                          mlfOnes(
                            _mxarray1_,
                            mclMinus(mclVv(N, "N"), mlfScalar(v_)),
                            NULL),
                          NULL),
                        NULL));
                    mlfAssign(
                      &x,
                      mlfRepmat(
                        mclVv(x, "x"),
                        mlfHorzcat(
                          mclArrayRef1(
                            mclVv(D, "D"),
                            mlfColon(_mxarray1_, mlfScalar(v_ - 1), NULL)),
                          _mxarray1_,
                          mclArrayRef1(
                            mclVv(D, "D"),
                            mlfColon(mlfScalar(v_ + 1), mclVv(N, "N"), NULL)),
                          NULL),
                        NULL));
                    mclArrayAssign2(
                      &G,
                      mclVv(x, "x"),
                      mlfIndexRef(
                        mclVv(colons, "colons"), "{?}", mlfCreateColonIndex()),
                      mlfScalar(v_));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&i, mlfScalar(v_));
            }
        }
    /*
     * end
     */
    }
    mclValidateOutput(G, 1, nargout_, "G", "tformarray/CombinedGrid");
    mxDestroyArray(N);
    mxDestroyArray(ans);
    mxDestroyArray(i);
    mxDestroyArray(D);
    mxDestroyArray(colons);
    mxDestroyArray(x);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return G;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_GetBlocking" is the implementation version of the
 * "tformarray/GetBlocking" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 348-476). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function blockingfactors = GetBlocking( tsize, P )
 */
static mxArray * Mtformarray_GetBlocking(int nargout_,
                                         mxArray * tsize,
                                         mxArray * P) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * blockingfactors = NULL;
    mxArray * ans = NULL;
    mxArray * k = NULL;
    mxArray * i = NULL;
    mxArray * D = NULL;
    mxArray * B = NULL;
    mxArray * N = NULL;
    mxArray * L = NULL;
    mxArray * qDivisible = NULL;
    mxArray * Nm = NULL;
    mxArray * Nt = NULL;
    mclCopyArray(&tsize);
    mclCopyArray(&P);
    /*
     * 
     * % With large input arrays, the memory used by the grid and/or map
     * % (G and M) in the main function can be substantial and may exceed
     * % the memory used by the input and output images -- depending on the
     * % number of input transform dimensions, the number of non-transform
     * % dimensions, and the storage class of the input and output arrays.
     * % So the main function may compute the map block-by-block, resample
     * % the input for just that block, and assign the result to a pre-allocated
     * % output array.  We define the blocks by slicing the output transform space
     * % along lines, planes, or hyperplanes normal to each of the subscript
     * % axes.  We call the number of regions created by the slicing along a
     * % given axis the 'blocking factor' for that dimension.  (If no slices
     * % are made, the blocking factor is 1.  If all the blocking factors are
     * % 1 (which can be tested by checking if prod(blockingfactors) == 1),
     * % then the output array is small enough to process as a single block.)
     * % The blockingfactors array created by this function has the same
     * % size as TSIZE, and its dimensions are ordered as in TSIZE.
     * %
     * % This particular implementation has the following properties:
     * % - All blocking factors are powers of 2
     * % - After excluding very narrow dimensions, it slices across the
     * %   remaining dimensions to defined blocks whose dimensions tend
     * %   toward equality. (Of course, for large aspect ratios and relatively
     * %   few blocks, the result may not actually get very close to equality.)
     * 
     * % Control parameters
     * Nt = 20;  % Defines target block size
     */
    mlfAssign(&Nt, _mxarray9_);
    /*
     * Nm =  2;  % Defines cut-off to avoid blocking on narrow dimensions
     */
    mlfAssign(&Nm, _mxarray10_);
    /*
     * % The largest block will be on the order of 2^Nt doubles (but may be
     * % somewhat larger).  Any dimensions with size less than 2^Nm (= 4)
     * % will have blocking factors of 1.  They are tagged by zeros in the
     * % qDivisible array below.
     * 
     * % Separate the dimensions that are too narrow to divide into blocks.
     * qDivisible = tsize > 2^(Nm+1);
     */
    mlfAssign(
      &qDivisible,
      mclGt(
        mclVa(tsize, "tsize"),
        mclMpower(_mxarray10_, mclPlus(mclVv(Nm, "Nm"), _mxarray1_))));
    /*
     * L = sum(qDivisible);
     */
    mlfAssign(&L, mlfSum(mclVv(qDivisible, "qDivisible"), NULL));
    /*
     * 
     * % The number of blocks will be 2^N.  As a goal, each block will
     * % contain on the order of 2^Nt values, but larger blocks may be
     * % needed to avoid subdividing narrow dimensions too finely.
     * %
     * % If all dimensions are large, then we'd like something like
     * %
     * %   (1) N = floor(log2(prod(tsize)/(2^Nt/P)));
     * %
     * % That's because we'd like prod(size(M)) / 2^N to be on the order of 2^Nt,
     * % and prod(size(M)) = prod(tsize) * P.  The following slightly more complex
     * % formula is equivalent to (1), but divides out the non-divisible dimensions
     * %
     * %   (2) N = floor(log2(prod(tsize(qDivisible)) / ...
     * %                             (2^Nt/(P*prod(tsize(~qDivisible)))))); 
     * %
     * % However, it is possible that we might not be able to block an image as
     * % finely as we'd like if its size is due to having many small dimensions
     * % rather than a few large ones.  That's why the actual formula for N in
     * % the next line of code replaces the numerator in (2) with 2^((Nm+1)*L)
     * % if this quantity is larger. In such a case, we'd have
     * %
     * %   (3) N = floor(log2(prod(tsize(qDivisible)) / 2^((Nm+1)*L)));
     * %
     * % and would have to make do with fewer blocks in order to ensure a minimum
     * % block size greater than or equal to 2^Nm.  The fact that our block sizes
     * % always satisfy this constraint is proved in the comments at the end of
     * % this function.
     * 
     * N = floor(log2(prod(tsize(qDivisible)) / ...
     */
    mlfAssign(
      &N,
      mlfFloor(
        mlfLog2(
          NULL,
          mclMrdivide(
            mlfProd(
              mclArrayRef1(
                mclVa(tsize, "tsize"), mclVv(qDivisible, "qDivisible")),
              NULL),
            mlfMax(
              NULL,
              mclMrdivide(
                mclMpower(_mxarray10_, mclVv(Nt, "Nt")),
                mclMtimes(
                  mclVa(P, "P"),
                  mlfProd(
                    mclArrayRef1(
                      mclVa(tsize, "tsize"),
                      mclNot(mclVv(qDivisible, "qDivisible"))),
                    NULL))),
              mclMpower(
                _mxarray10_,
                mclMtimes(mclPlus(mclVv(Nm, "Nm"), _mxarray1_), mclVv(L, "L"))),
              NULL)))));
    /*
     * max( (2^Nt)/(P*prod(tsize(~qDivisible))), 2^((Nm+1)*L) )));
     * 
     * % Initialize the blocking factor for the each divisible dimensions
     * % as unity.  Iterate N times, each time multiplying one of the
     * % blocking factors by 2.  The choice of which to multiply is driven
     * % by the goal of making the final set of average divisible block
     * % dimensions (stored in D at the end of the iteration) as uniform
     * % as possible.
     * B = ones(1,L);
     */
    mlfAssign(&B, mlfOnes(_mxarray1_, mclVv(L, "L"), NULL));
    /*
     * D = tsize(qDivisible);
     */
    mlfAssign(
      &D, mclArrayRef1(mclVa(tsize, "tsize"), mclVv(qDivisible, "qDivisible")));
    /*
     * for i = 1:N
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(N, "N"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray2_);
        } else {
            /*
             * k = find(D == max(D));
             * k = k(1);  % Take the first if there is more than one maximum
             * B(k) = B(k) * 2;
             * D(k) = D(k) / 2;
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &k,
                  mlfFind(
                    NULL,
                    NULL,
                    mclEq(
                      mclVv(D, "D"), mlfMax(NULL, mclVv(D, "D"), NULL, NULL))));
                mlfAssign(&k, mclIntArrayRef1(mclVv(k, "k"), 1));
                mclArrayAssign1(
                  &B,
                  mclMtimes(
                    mclArrayRef1(mclVv(B, "B"), mclVv(k, "k")), _mxarray10_),
                  mclVv(k, "k"));
                mclArrayAssign1(
                  &D,
                  mclMrdivide(
                    mclArrayRef1(mclVv(D, "D"), mclVv(k, "k")), _mxarray10_),
                  mclVv(k, "k"));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * blockingfactors( qDivisible) = B;
     */
    mclArrayAssign1(
      &blockingfactors, mclVv(B, "B"), mclVv(qDivisible, "qDivisible"));
    /*
     * blockingfactors(~qDivisible) = 1;
     */
    mclArrayAssign1(
      &blockingfactors, _mxarray1_, mclNot(mclVv(qDivisible, "qDivisible")));
    /*
     * 
     * % Assertion: After the loop is complete, all(D >= 2^Nm).
     * if any(D < 2^Nm)
     */
    if (mlfTobool(
          mlfAny(
            mclLt(mclVv(D, "D"), mclMpower(_mxarray10_, mclVv(Nm, "Nm"))),
            NULL))) {
        /*
         * error('Internal Error: Block dimension below minimum.');
         */
        mlfError(_mxarray11_, NULL);
    /*
     * end
     */
    }
    mclValidateOutput(
      blockingfactors,
      1,
      nargout_,
      "blockingfactors",
      "tformarray/GetBlocking");
    mxDestroyArray(Nt);
    mxDestroyArray(Nm);
    mxDestroyArray(qDivisible);
    mxDestroyArray(L);
    mxDestroyArray(N);
    mxDestroyArray(B);
    mxDestroyArray(D);
    mxDestroyArray(i);
    mxDestroyArray(k);
    mxDestroyArray(ans);
    mxDestroyArray(P);
    mxDestroyArray(tsize);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return blockingfactors;
    /*
     * 
     * % Let Dmin = min(D) after the loop is complete.  Dmin is the smallest
     * % average block size among the 'divisible' dimensions.  The following
     * % is a proof that Dmin >= 2^Nm.
     * %
     * % There are two possibilities: Either the blocking factor corresponding
     * % to Dmin is 1 or it is not.  If the blocking factor is 1, the proof
     * % is trival: Dmin > 2^(Nm+1) > 2^Nm (otherwise this dimension would
     * % not be included by virtue of qDivisible being false). Otherwise,
     * % because the algorithm continually divides the largest
     * % element of D by 2, it is clear that when the loop is complete
     * %
     * %   (1)  Dmin >= (1/2) * max(D).
     * %
     * % max(D) must equal or exceed the geometric mean of D,
     * %
     * %   (2)  max(D) >= (prod(D))^(1/L).
     * %
     * % From the formula for N,
     * %
     * %   (3)  N <= log2(prod(tsize(qDivisible)) / 2^((Nm+1)*L)).
     * %
     * % Because exactly N divisions by 2 occur in the loop,
     * %
     * %   (4)  prod(tsize(qDivisible) = (2^N) * prod(D);
     * %
     * % Combining (3) and (4),
     * %
     * %   (5)  prod(D) >= 2^((Nm+1)*L).
     * %
     * % Combining (1), (2), and (5) completes the proof,
     * %
     * %   (6)  Dmin >= (1/2) * max(D)
     * %             >= (1/2)*(prod(D))^(1/L)
     * %             >= (1/2)*(2^((Nm+1)*L))^(1/L) = 2^Nm.
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_GetBlockLimits" is the implementation version of
 * the "tformarray/GetBlockLimits" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 476-509). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [lo, hi] = GetBlockLimits( tsize_B, blockingfactors )
 */
static mxArray * Mtformarray_GetBlockLimits(mxArray * * hi,
                                            int nargout_,
                                            mxArray * tsize_B,
                                            mxArray * blockingfactors) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * lo = NULL;
    mxArray * ans = NULL;
    mxArray * qUpperLim = NULL;
    mxArray * k = NULL;
    mxArray * i = NULL;
    mxArray * nBlocks = NULL;
    mxArray * delta = NULL;
    mxArray * blocksubs = NULL;
    mxArray * blocksizes = NULL;
    mxArray * N = NULL;
    mclCopyArray(&tsize_B);
    mclCopyArray(&blockingfactors);
    /*
     * 
     * % Construct matrices LO and HI containing the lower and upper limits for
     * % each block, making sure to enlarge the upper limit of the right-most
     * % block in each dimension as needed to reach the edge of the image.
     * % LO and HI are each nBlocks-by-N.
     * 
     * N = length(tsize_B);
     */
    mlfAssign(&N, mlfScalar(mclLengthInt(mclVa(tsize_B, "tsize_B"))));
    /*
     * blocksizes = floor(tsize_B ./ blockingfactors);
     */
    mlfAssign(
      &blocksizes,
      mlfFloor(
        mclRdivide(
          mclVa(tsize_B, "tsize_B"),
          mclVa(blockingfactors, "blockingfactors"))));
    /*
     * blocksubs  = [0 ones( 1,N-1)];
     */
    mlfAssign(
      &blocksubs,
      mlfHorzcat(
        _mxarray6_,
        mlfOnes(_mxarray1_, mclMinus(mclVv(N, "N"), _mxarray1_), NULL),
        NULL));
    /*
     * delta      = [1 zeros(1,N-1)];
     */
    mlfAssign(
      &delta,
      mlfHorzcat(
        _mxarray1_,
        mlfZeros(_mxarray1_, mclMinus(mclVv(N, "N"), _mxarray1_), NULL),
        NULL));
    /*
     * nBlocks = prod(blockingfactors);
     */
    mlfAssign(
      &nBlocks, mlfProd(mclVa(blockingfactors, "blockingfactors"), NULL));
    /*
     * lo = zeros(nBlocks,N);
     */
    mlfAssign(&lo, mlfZeros(mclVv(nBlocks, "nBlocks"), mclVv(N, "N"), NULL));
    /*
     * hi = zeros(nBlocks,N);
     */
    mlfAssign(hi, mlfZeros(mclVv(nBlocks, "nBlocks"), mclVv(N, "N"), NULL));
    /*
     * for i = 1:nBlocks;
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(nBlocks, "nBlocks"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray2_);
        } else {
            /*
             * blocksubs = blocksubs + delta;
             * while any(blocksubs > blockingfactors)
             * % 'Carry' to higher dimensions as required.
             * k = find(blocksubs > blockingfactors);
             * blocksubs(k) = 1;
             * blocksubs(k+1) = blocksubs(k+1) + 1;
             * end
             * lo(i,:) = 1 + (blocksubs - 1) .* blocksizes;
             * hi(i,:) = blocksubs .* blocksizes;
             * qUpperLim = blocksubs == blockingfactors;
             * hi(i,qUpperLim) = tsize_B(qUpperLim);
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &blocksubs,
                  mclPlus(
                    mclVv(blocksubs, "blocksubs"), mclVv(delta, "delta")));
                while (mlfTobool(
                         mlfAny(
                           mclGt(
                             mclVv(blocksubs, "blocksubs"),
                             mclVa(blockingfactors, "blockingfactors")),
                           NULL))) {
                    mlfAssign(
                      &k,
                      mlfFind(
                        NULL,
                        NULL,
                        mclGt(
                          mclVv(blocksubs, "blocksubs"),
                          mclVa(blockingfactors, "blockingfactors"))));
                    mclArrayAssign1(&blocksubs, _mxarray1_, mclVv(k, "k"));
                    mclArrayAssign1(
                      &blocksubs,
                      mclPlus(
                        mclArrayRef1(
                          mclVv(blocksubs, "blocksubs"),
                          mclPlus(mclVv(k, "k"), _mxarray1_)),
                        _mxarray1_),
                      mclPlus(mclVv(k, "k"), _mxarray1_));
                }
                mclArrayAssign2(
                  &lo,
                  mclPlus(
                    _mxarray1_,
                    mclTimes(
                      mclMinus(mclVv(blocksubs, "blocksubs"), _mxarray1_),
                      mclVv(blocksizes, "blocksizes"))),
                  mlfScalar(v_),
                  mlfCreateColonIndex());
                mclArrayAssign2(
                  hi,
                  mclTimes(
                    mclVv(blocksubs, "blocksubs"),
                    mclVv(blocksizes, "blocksizes")),
                  mlfScalar(v_),
                  mlfCreateColonIndex());
                mlfAssign(
                  &qUpperLim,
                  mclEq(
                    mclVv(blocksubs, "blocksubs"),
                    mclVa(blockingfactors, "blockingfactors")));
                mclArrayAssign2(
                  hi,
                  mclArrayRef1(
                    mclVa(tsize_B, "tsize_B"), mclVv(qUpperLim, "qUpperLim")),
                  mlfScalar(v_),
                  mclVv(qUpperLim, "qUpperLim"));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * if any(blocksubs ~= blockingfactors)
     */
    if (mlfTobool(
          mlfAny(
            mclNe(
              mclVv(blocksubs, "blocksubs"),
              mclVa(blockingfactors, "blockingfactors")),
            NULL))) {
        /*
         * error('Internal Error: Failed to iterate over all blocks.');
         */
        mlfError(_mxarray13_, NULL);
    /*
     * end
     */
    }
    mclValidateOutput(lo, 1, nargout_, "lo", "tformarray/GetBlockLimits");
    mclValidateOutput(*hi, 2, nargout_, "hi", "tformarray/GetBlockLimits");
    mxDestroyArray(N);
    mxDestroyArray(blocksizes);
    mxDestroyArray(blocksubs);
    mxDestroyArray(delta);
    mxDestroyArray(nBlocks);
    mxDestroyArray(i);
    mxDestroyArray(k);
    mxDestroyArray(qUpperLim);
    mxDestroyArray(ans);
    mxDestroyArray(blockingfactors);
    mxDestroyArray(tsize_B);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return lo;
    /*
     * 
     * %--------------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_fullsizes" is the implementation version of the
 * "tformarray/fullsizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 509-568). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [fsize_A, fsize_B, osize] = fullsizes(size_A, tsize_B, tdims_A, tdims_B)
 */
static mxArray * Mtformarray_fullsizes(mxArray * * fsize_B,
                                       mxArray * * osize,
                                       int nargout_,
                                       mxArray * size_A,
                                       mxArray * tsize_B,
                                       mxArray * tdims_A,
                                       mxArray * tdims_B) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * fsize_A = NULL;
    mxArray * index = NULL;
    mxArray * sdims_B = NULL;
    mxArray * padding = NULL;
    mxArray * isT_B = NULL;
    mxArray * fdims_B = NULL;
    mxArray * ndims_B = NULL;
    mxArray * fdims_A = NULL;
    mxArray * ndims_A = NULL;
    mclCopyArray(&size_A);
    mclCopyArray(&tsize_B);
    mclCopyArray(&tdims_A);
    mclCopyArray(&tdims_B);
    /*
     * 
     * % Constructs row vectors indicating the full sizes of A and B (FSIZE_A and
     * % FSIZE_B), including trailing singleton dimensions. Also constructs a row
     * % vector (OSIZE) listing (in order) the sizes of the non-transform
     * % dimensions of both A and B.
     * %
     * % There are two ways for trailing singletons to arise: (1) values in
     * % TDIMS_A exceed the length of SIZE_A or values in TDIMS_B exceed the
     * % length of TSIZE_B plus the number on non-transform dimensions of A and
     * % (2) all dimensions of A are transform dimensions (e.g., A is a grayscale
     * % image) -- in this case a trailing singleton is added to A and then
     * % transferred to B.
     * %
     * % Example:
     * %
     * %   [fsize_A, fsize_B] = ...
     * %      fullsizes( [7 512 512 512 3 20 ], [200 300], [2 3 4], [1 2] );
     * %
     * %   returns fsize_A = [  7   512   512   512     3    20]
     * %   and     fsize_B = [200   300     7     3    20]
     * %   and     osize   = [  7     3    20].
     * 
     * % Actual dimensionality of input array
     * ndims_A = length(size_A);
     */
    mlfAssign(&ndims_A, mlfScalar(mclLengthInt(mclVa(size_A, "size_A"))));
    /*
     * 
     * % 'Full' dimensionality of input array --
     * % Increase ndims(A) as needed, to allow for the largest
     * % transform dimensions as specified in tdims_A, then
     * % make sure there is at least one non-transform dimension.
     * fdims_A = max([ndims_A max(tdims_A)]); 
     */
    mlfAssign(
      &fdims_A,
      mlfMax(
        NULL,
        mlfHorzcat(
          mclVv(ndims_A, "ndims_A"),
          mlfMax(NULL, mclVa(tdims_A, "tdims_A"), NULL, NULL),
          NULL),
        NULL,
        NULL));
    /*
     * if fdims_A == length(tdims_A)
     */
    if (mclEqBool(
          mclVv(fdims_A, "fdims_A"),
          mlfScalar(mclLengthInt(mclVa(tdims_A, "tdims_A"))))) {
        /*
         * fdims_A = fdims_A + 1;
         */
        mlfAssign(&fdims_A, mclPlus(mclVv(fdims_A, "fdims_A"), _mxarray1_));
    /*
     * end
     */
    }
    /*
     * 
     * % 'Full' size of input array --
     * % Pad size_A with ones (as needed) to allow for values
     * % in tdims_A that are higher than ndims(A):
     * fsize_A = [size_A ones(1,fdims_A - ndims_A)];
     */
    mlfAssign(
      &fsize_A,
      mlfHorzcat(
        mclVa(size_A, "size_A"),
        mlfOnes(
          _mxarray1_,
          mclMinus(mclVv(fdims_A, "fdims_A"), mclVv(ndims_A, "ndims_A")),
          NULL),
        NULL));
    /*
     * 
     * % The non-transform sizes of A and B:
     * osize = fsize_A(~ismember(1:fdims_A,tdims_A));
     */
    mlfAssign(
      osize,
      mclArrayRef1(
        mclVv(fsize_A, "fsize_A"),
        mclNot(
          mlfNIsmember(
            1,
            NULL,
            mlfColon(_mxarray1_, mclVv(fdims_A, "fdims_A"), NULL),
            mclVa(tdims_A, "tdims_A"),
            NULL))));
    /*
     * 
     * % The minimum ndims of B:
     * ndims_B = length(osize) + length(tdims_B);
     */
    mlfAssign(
      &ndims_B,
      mlfScalar(
        mclLengthInt(mclVv(*osize, "osize"))
        + mclLengthInt(mclVa(tdims_B, "tdims_B"))));
    /*
     * 
     * % Increase ndims_B as needed, to allow for the largest
     * % transform dimensions as specified in tdims_B:
     * fdims_B = max(ndims_B, max(tdims_B)); 
     */
    mlfAssign(
      &fdims_B,
      mlfMax(
        NULL,
        mclVv(ndims_B, "ndims_B"),
        mlfMax(NULL, mclVa(tdims_B, "tdims_B"), NULL, NULL),
        NULL));
    /*
     * 
     * % The full size of B, including possible padding:
     * isT_B = ismember(1:fdims_B, tdims_B);
     */
    mlfAssign(
      &isT_B,
      mlfNIsmember(
        1,
        NULL,
        mlfColon(_mxarray1_, mclVv(fdims_B, "fdims_B"), NULL),
        mclVa(tdims_B, "tdims_B"),
        NULL));
    /*
     * padding = ones(1,fdims_B - (length(osize) + length(tsize_B)));
     */
    mlfAssign(
      &padding,
      mlfOnes(
        _mxarray1_,
        mclMinus(
          mclVv(fdims_B, "fdims_B"),
          mlfScalar(
            mclLengthInt(mclVv(*osize, "osize"))
            + mclLengthInt(mclVa(tsize_B, "tsize_B")))),
        NULL));
    /*
     * [sdims_B index] = sort(tdims_B);
     */
    mlfAssign(&sdims_B, mlfSort(&index, mclVa(tdims_B, "tdims_B"), NULL));
    /*
     * fsize_B( isT_B) = tsize_B(index);
     */
    mclArrayAssign1(
      fsize_B,
      mclArrayRef1(mclVa(tsize_B, "tsize_B"), mclVv(index, "index")),
      mclVv(isT_B, "isT_B"));
    /*
     * fsize_B(~isT_B) = [osize padding];
     */
    mclArrayAssign1(
      fsize_B,
      mlfHorzcat(mclVv(*osize, "osize"), mclVv(padding, "padding"), NULL),
      mclNot(mclVv(isT_B, "isT_B")));
    mclValidateOutput(fsize_A, 1, nargout_, "fsize_A", "tformarray/fullsizes");
    mclValidateOutput(*fsize_B, 2, nargout_, "fsize_B", "tformarray/fullsizes");
    mclValidateOutput(*osize, 3, nargout_, "osize", "tformarray/fullsizes");
    mxDestroyArray(ndims_A);
    mxDestroyArray(fdims_A);
    mxDestroyArray(ndims_B);
    mxDestroyArray(fdims_B);
    mxDestroyArray(isT_B);
    mxDestroyArray(padding);
    mxDestroyArray(sdims_B);
    mxDestroyArray(index);
    mxDestroyArray(tdims_B);
    mxDestroyArray(tdims_A);
    mxDestroyArray(tsize_B);
    mxDestroyArray(size_A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return fsize_A;
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_PredictNDimsG" is the implementation version of
 * the "tformarray/PredictNDimsG" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 568-582). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function K = PredictNDimsG( N, L )
 */
static mxArray * Mtformarray_PredictNDimsG(int nargout_,
                                           mxArray * N,
                                           mxArray * L) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * K = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&N);
    mclCopyArray(&L);
    /*
     * 
     * if N == 1
     */
    if (mclEqBool(mclVa(N, "N"), _mxarray1_)) {
        /*
         * K = 2;
         */
        mlfAssign(&K, _mxarray10_);
    /*
     * elseif N > 1 & L == 1
     */
    } else {
        mxArray * a_ = mclInitialize(mclGt(mclVa(N, "N"), _mxarray1_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclEq(mclVa(L, "L"), _mxarray1_)))) {
            mxDestroyArray(a_);
            /*
             * K = N;
             */
            mlfAssign(&K, mclVa(N, "N"));
        /*
         * elseif N > 1 & L > 1
         */
        } else {
            mxDestroyArray(a_);
            {
                mxArray * a_0 = mclInitialize(mclGt(mclVa(N, "N"), _mxarray1_));
                if (mlfTobool(a_0)
                    && mlfTobool(
                         mclAnd(a_0, mclGt(mclVa(L, "L"), _mxarray1_)))) {
                    mxDestroyArray(a_0);
                    /*
                     * K = N + 1;
                     */
                    mlfAssign(&K, mclPlus(mclVa(N, "N"), _mxarray1_));
                /*
                 * else
                 */
                } else {
                    mxDestroyArray(a_0);
                    /*
                     * error('Internal Error: N and L must both be positive.');
                     */
                    mlfError(_mxarray15_, NULL);
                }
            }
        }
    /*
     * end
     */
    }
    mclValidateOutput(K, 1, nargout_, "K", "tformarray/PredictNDimsG");
    mxDestroyArray(ans);
    mxDestroyArray(L);
    mxDestroyArray(N);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return K;
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_CheckDimsAndSizes" is the implementation version
 * of the "tformarray/CheckDimsAndSizes" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 582-664). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function tsize_B = CheckDimsAndSizes( tdims_A, tdims_B, tsize_B, tmap_B, T )
 */
static mxArray * Mtformarray_CheckDimsAndSizes(int nargout_,
                                               mxArray * tdims_A,
                                               mxArray * tdims_B,
                                               mxArray * tsize_B_in,
                                               mxArray * tmap_B,
                                               mxArray * T) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * tsize_B = NULL;
    mxArray * size_G = NULL;
    mxArray * L = NULL;
    mxArray * N = NULL;
    mxArray * P = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&tdims_A);
    mclCopyArray(&tdims_B);
    mclCopyInputArg(&tsize_B, tsize_B_in);
    mclCopyArray(&tmap_B);
    mclCopyArray(&T);
    /*
     * 
     * % Check dimensions
     * if ~IsFinitePositiveIntegerRowVector( tdims_A )
     */
    if (mclNotBool(
          mlfTformarray_IsFinitePositiveIntegerRowVector(
            mclVa(tdims_A, "tdims_A")))) {
        /*
         * error('TDIMS_A must be a row vector of finite, positive integers.');
         */
        mlfError(_mxarray17_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if ~IsFinitePositiveIntegerRowVector( tdims_B )
     */
    if (mclNotBool(
          mlfTformarray_IsFinitePositiveIntegerRowVector(
            mclVa(tdims_B, "tdims_B")))) {
        /*
         * error('TDIMS_B must be a row vector of finite, positive integers.');
         */
        mlfError(_mxarray19_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * P = length(tdims_A);
     */
    mlfAssign(&P, mlfScalar(mclLengthInt(mclVa(tdims_A, "tdims_A"))));
    /*
     * N = length(tdims_B);
     */
    mlfAssign(&N, mlfScalar(mclLengthInt(mclVa(tdims_B, "tdims_B"))));
    /*
     * 
     * if length(unique(tdims_A)) ~= P
     */
    if (mclNeBool(
          mlfScalar(
            mclLengthInt(
              mlfNUnique(1, NULL, NULL, mclVa(tdims_A, "tdims_A"), NULL))),
          mclVv(P, "P"))) {
        /*
         * error('All values in TDIMS_A must be unique.');
         */
        mlfError(_mxarray21_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * if length(unique(tdims_B)) ~= N
     */
    if (mclNeBool(
          mlfScalar(
            mclLengthInt(
              mlfNUnique(1, NULL, NULL, mclVa(tdims_B, "tdims_B"), NULL))),
          mclVv(N, "N"))) {
        /*
         * error('All values in TDIMS_B must be unique.');
         */
        mlfError(_mxarray23_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % If tmap_B is supplied, ignore the input value of tsize_B and 
     * % construct tsize_B from tmap_B instead. Allow for the possibility
     * % that the last dimension of tmap_B is a singleton by copying no
     * % more than N values from size(tmap_B).
     * 
     * if isempty(tmap_B)
     */
    if (mlfTobool(mlfIsempty(mclVa(tmap_B, "tmap_B")))) {
        /*
         * L = N;
         */
        mlfAssign(&L, mclVv(N, "N"));
    /*
     * else
     */
    } else {
        /*
         * if ~isempty(tsize_B)
         */
        if (mclNotBool(mlfIsempty(mclVa(tsize_B, "tsize_B")))) {
            /*
             * warning('Both TMAP_B and TSIZE_B are non-empty; TSIZE_B will be ignored.');
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray25_, NULL));
        /*
         * end
         */
        }
        /*
         * 
         * if ~isa(tmap_B,'double') | ~isreal(tmap_B) | issparse(tmap_B) | any(isinf(tmap_B(:)))
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclNot(mlfIsa(mclVa(tmap_B, "tmap_B"), _mxarray29_)));
            if (mlfTobool(a_)) {
                mlfAssign(&a_, mlfScalar(1));
            } else {
                mlfAssign(
                  &a_, mclOr(a_, mclNot(mlfIsreal(mclVa(tmap_B, "tmap_B")))));
            }
            if (mlfTobool(a_)) {
                mlfAssign(&a_, mlfScalar(1));
            } else {
                mlfAssign(&a_, mclOr(a_, mlfIssparse(mclVa(tmap_B, "tmap_B"))));
            }
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mlfAny(
                         mlfIsinf(
                           mclArrayRef1(
                             mclVa(tmap_B, "tmap_B"), mlfCreateColonIndex())),
                         NULL)))) {
                mxDestroyArray(a_);
                /*
                 * error('TMAP_B must be a non-sparse, finite real-valued array of class double.');
                 */
                mlfError(_mxarray27_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * 
         * L = size(tmap_B,N+1);
         */
        mlfAssign(
          &L,
          mlfSize(
            mclValueVarargout(),
            mclVa(tmap_B, "tmap_B"),
            mclPlus(mclVv(N, "N"), _mxarray1_)));
        /*
         * 
         * if isempty(T) & L ~= P
         */
        {
            mxArray * a_ = mclInitialize(mlfIsempty(mclVa(T, "T")));
            if (mlfTobool(a_)
                && mlfTobool(
                     mclAnd(a_, mclNe(mclVv(L, "L"), mclVv(P, "P"))))) {
                mxDestroyArray(a_);
                /*
                 * error('SIZE(TMAP_B) is inconsistent with LENGTH(TDIMS_A) or LENGTH(TDIMS_B).');
                 */
                mlfError(_mxarray31_, NULL);
            } else {
                mxDestroyArray(a_);
            }
        /*
         * end
         */
        }
        /*
         * 
         * if ndims(tmap_B) ~= PredictNDimsG(N,L)
         */
        if (mclNeBool(
              mlfNdims(mclVa(tmap_B, "tmap_B")),
              mlfTformarray_PredictNDimsG(mclVv(N, "N"), mclVv(L, "L")))) {
            /*
             * error('NDIMS(TMAP_B) is inconsistent with TDIMS_B and SIZE(TMAP_B).');
             */
            mlfError(_mxarray33_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * size_G = size(tmap_B);
         */
        mlfAssign(
          &size_G, mlfSize(mclValueVarargout(), mclVa(tmap_B, "tmap_B"), NULL));
        /*
         * tsize_B(1:N) = size_G(1:N);
         */
        mclArrayAssign1(
          &tsize_B,
          mclArrayRef1(
            mclVv(size_G, "size_G"), mlfColon(_mxarray1_, mclVv(N, "N"), NULL)),
          mlfColon(_mxarray1_, mclVv(N, "N"), NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Check T
     * if ~isempty(T)
     */
    if (mclNotBool(mlfIsempty(mclVa(T, "T")))) {
        /*
         * if ~istform(T)
         */
        if (mclNotBool(mlfImages_private_istform(mclVa(T, "T")))) {
            /*
             * error('T is not a valid TFORM struct.');
             */
            mlfError(_mxarray35_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * if length(T) > 1
         */
        if (mclLengthInt(mclVa(T, "T")) > 1) {
            /*
             * error('T must be a single TFORM struct.');
             */
            mlfError(_mxarray37_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * if T.ndims_in ~= P
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxNe,
                mlfIndexRef(mclVa(T, "T"), ".ndims_in"),
                mclVv(P, "P"),
                NULL))) {
            /*
             * error('T.NDIMS_IN must match LENGTH(TDIMS_A).');
             */
            mlfError(_mxarray39_, NULL);
        /*
         * end
         */
        }
        /*
         * 
         * if T.ndims_out ~= L
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxNe,
                mlfIndexRef(mclVa(T, "T"), ".ndims_out"),
                mclVv(L, "L"),
                NULL))) {
            /*
             * error('T.NDIMS_OUT is inconsistent with LENGTH(TDIMS_B) or SIZE(TMAP_B).');
             */
            mlfError(_mxarray41_, NULL);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    /*
     * 
     * if ~IsFinitePositiveIntegerRowVector( tsize_B )
     */
    if (mclNotBool(
          mlfTformarray_IsFinitePositiveIntegerRowVector(
            mclVa(tsize_B, "tsize_B")))) {
        /*
         * error('TSIZE_B must be a row vector of finite, positive integers.');
         */
        mlfError(_mxarray43_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % tsize_B and tdims_B must have the same length.
     * if length(tsize_B) ~= N
     */
    if (mclNeBool(
          mlfScalar(mclLengthInt(mclVa(tsize_B, "tsize_B"))), mclVv(N, "N"))) {
        /*
         * error('Lengths of TSIZE_B and TDIMS_B must match.');
         */
        mlfError(_mxarray45_, NULL);
    /*
     * end
     */
    }
    mclValidateOutput(
      tsize_B, 1, nargout_, "tsize_B", "tformarray/CheckDimsAndSizes");
    mxDestroyArray(ans);
    mxDestroyArray(P);
    mxDestroyArray(N);
    mxDestroyArray(L);
    mxDestroyArray(size_G);
    mxDestroyArray(T);
    mxDestroyArray(tmap_B);
    mxDestroyArray(tdims_B);
    mxDestroyArray(tdims_A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return tsize_B;
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_CheckInputArray" is the implementation version of
 * the "tformarray/CheckInputArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 664-672). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function CheckInputArray( A )
 */
static void Mtformarray_CheckInputArray(mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * ans = NULL;
    mclCopyArray(&A);
    /*
     * 
     * if (~isnumeric(A) & ~islogical(A)) | issparse(A)
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIsnumeric(mclVa(A, "A"))));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mclAnd(a_, mclNot(mlfIslogical(mclVa(A, "A")))));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_) || mlfTobool(mclOr(a_, mlfIssparse(mclVa(A, "A"))))) {
            mxDestroyArray(a_);
            /*
             * error('A must be a non-sparse numeric or logical array.');
             */
            mlfError(_mxarray47_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_CheckResampler" is the implementation version of
 * the "tformarray/CheckResampler" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 672-684). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function CheckResampler( R, tdims_A )
 */
static void Mtformarray_CheckResampler(mxArray * R, mxArray * tdims_A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * ans = NULL;
    mclCopyArray(&R);
    mclCopyArray(&tdims_A);
    /*
     * 
     * if ~isresampler(R) | (length(R) ~= 1)
     */
    {
        mxArray * a_
          = mclInitialize(
              mclNot(mlfImages_private_isresampler(mclVa(R, "R"))));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_, mclBoolToArray(mclLengthInt(mclVa(R, "R")) != 1)))) {
            mxDestroyArray(a_);
            /*
             * error('R must be a valid resampler struct.');
             */
            mlfError(_mxarray49_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if R.ndims ~= Inf & R.ndims ~= length(tdims_A)
     */
    {
        mxArray * a_
          = mclInitialize(
              mclFeval(
                mclValueVarargout(),
                mlxNe,
                mlfIndexRef(mclVa(R, "R"), ".ndims"),
                _mxarray53_,
                NULL));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxNe,
                     mlfIndexRef(mclVa(R, "R"), ".ndims"),
                     mlfScalar(mclLengthInt(mclVa(tdims_A, "tdims_A"))),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * error('R''s ''ndims'' field doesn''t match LENGTH(TDIMS_A).');
             */
            mlfError(_mxarray51_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(tdims_A);
    mxDestroyArray(R);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_CheckFillArray" is the implementation version of
 * the "tformarray/CheckFillArray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\tformarray.m" (lines 684-715). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function F = CheckFillArray( F, osize )
 */
static mxArray * Mtformarray_CheckFillArray(int nargout_,
                                            mxArray * F_in,
                                            mxArray * osize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * F = NULL;
    mxArray * q = NULL;
    mxArray * N = NULL;
    mxArray * last = NULL;
    mxArray * size_F = NULL;
    mxArray * ans = NULL;
    mclCopyInputArg(&F, F_in);
    mclCopyArray(&osize);
    /*
     * 
     * if isempty(F)
     */
    if (mlfTobool(mlfIsempty(mclVa(F, "F")))) {
        /*
         * F = 0;
         */
        mlfAssign(&F, _mxarray6_);
    /*
     * else
     */
    } else {
        /*
         * if ~isa(F,'double') | issparse(F)
         */
        mxArray * a_
          = mclInitialize(mclNot(mlfIsa(mclVa(F, "F"), _mxarray29_)));
        if (mlfTobool(a_) || mlfTobool(mclOr(a_, mlfIssparse(mclVa(F, "F"))))) {
            mxDestroyArray(a_);
            /*
             * error('F must be a non-sparse array of class double.');
             */
            mlfError(_mxarray54_, NULL);
        } else {
            mxDestroyArray(a_);
        }
        /*
         * end
         * 
         * % Validate SIZE(F), stripping off trailing singletons.
         * size_F = size(F);
         */
        mlfAssign(&size_F, mlfSize(mclValueVarargout(), mclVa(F, "F"), NULL));
        /*
         * last = max([1 find(size_F ~= 1)]);
         */
        mlfAssign(
          &last,
          mlfMax(
            NULL,
            mlfHorzcat(
              _mxarray1_,
              mlfFind(NULL, NULL, mclNe(mclVv(size_F, "size_F"), _mxarray1_)),
              NULL),
            NULL,
            NULL));
        /*
         * size_F = size_F(1:last);
         */
        mlfAssign(
          &size_F,
          mclArrayRef1(
            mclVv(size_F, "size_F"),
            mlfColon(_mxarray1_, mclVv(last, "last"), NULL)));
        /*
         * 
         * % SIZE_F can't be longer than OSIZE.
         * N = length(osize);
         */
        mlfAssign(&N, mlfScalar(mclLengthInt(mclVa(osize, "osize"))));
        /*
         * q = (length(size_F) <= N);
         */
        mlfAssign(
          &q,
          mclLe(
            mlfScalar(mclLengthInt(mclVv(size_F, "size_F"))), mclVv(N, "N")));
        /*
         * if q
         */
        if (mlfTobool(mclVv(q, "q"))) {
            /*
             * % Add (back) enough singletons to make size_F the same length as OSIZE.
             * size_F = [size_F ones(1,N-length(size_F))];
             */
            mlfAssign(
              &size_F,
              mlfHorzcat(
                mclVv(size_F, "size_F"),
                mlfOnes(
                  _mxarray1_,
                  mclMinus(
                    mclVv(N, "N"),
                    mlfScalar(mclLengthInt(mclVv(size_F, "size_F")))),
                  NULL),
                NULL));
            /*
             * 
             * % Each value in SIZE_F must be unity (or zero), or must match OSIZE.
             * q = all(size_F == 1 | size_F == osize);
             */
            mlfAssign(
              &q,
              mlfAll(
                mclOr(
                  mclEq(mclVv(size_F, "size_F"), _mxarray1_),
                  mclEq(mclVv(size_F, "size_F"), mclVa(osize, "osize"))),
                NULL));
        /*
         * end
         */
        }
        /*
         * if ~q
         */
        if (mclNotBool(mclVv(q, "q"))) {
            /*
             * error('SIZE(F) is inconsistent with the non-tranform sizes of A.');
             */
            mlfError(_mxarray56_, NULL);
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mclValidateOutput(F, 1, nargout_, "F", "tformarray/CheckFillArray");
    mxDestroyArray(ans);
    mxDestroyArray(size_F);
    mxDestroyArray(last);
    mxDestroyArray(N);
    mxDestroyArray(q);
    mxDestroyArray(osize);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return F;
    /*
     * 
     * %---------------------------------------------------------------------
     * 
     */
}

/*
 * The function "Mtformarray_IsFinitePositiveIntegerRowVector" is the
 * implementation version of the "tformarray/IsFinitePositiveIntegerRowVector"
 * M-function from file "k:\matlab6p5\toolbox\images\images\tformarray.m"
 * (lines 715-729). It contains the actual compiled code for that M-function.
 * It is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function q = IsFinitePositiveIntegerRowVector( v )
 */
static mxArray * Mtformarray_IsFinitePositiveIntegerRowVector(int nargout_,
                                                              mxArray * v) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_tformarray);
    mxArray * q = NULL;
    mclCopyArray(&v);
    /*
     * 
     * q = isa(v,'double')   ...
     */
    mlfAssign(
      &q,
      mclAnd(
        mclAnd(
          mclAnd(
            mclAnd(
              mlfIsa(mclVa(v, "v"), _mxarray29_),
              mclNot(mlfIssparse(mclVa(v, "v")))),
            mclEq(mlfNdims(mclVa(v, "v")), _mxarray10_)),
          mclEq(
            mlfSize(mclValueVarargout(), mclVa(v, "v"), _mxarray1_),
            _mxarray1_)),
        mclGe(
          mlfSize(mclValueVarargout(), mclVa(v, "v"), _mxarray10_),
          _mxarray1_)));
    /*
     * & ~issparse(v)    ...
     * & ndims(v) == 2   ...
     * & size(v,1) == 1  ...
     * & size(v,2) >= 1;
     * 
     * if q
     */
    if (mlfTobool(mclVv(q, "q"))) {
        /*
         * q = ~(~isreal(v)            ...
         */
        mlfAssign(
          &q,
          mclNot(
            mclOr(
              mclOr(
                mclOr(
                  mclNot(mlfIsreal(mclVa(v, "v"))),
                  mclNot(
                    mlfAll(
                      mclEq(mclVa(v, "v"), mlfFloor(mclVa(v, "v"))), NULL))),
                mclNot(mlfAll(mlfIsfinite(mclVa(v, "v")), NULL))),
              mlfAny(mclLt(mclVa(v, "v"), _mxarray1_), NULL))));
    /*
     * | ~all(v == floor(v)) ...
     * | ~all(isfinite(v))   ...
     * | any(v < 1));
     * end
     */
    }
    mclValidateOutput(
      q, 1, nargout_, "q", "tformarray/IsFinitePositiveIntegerRowVector");
    mxDestroyArray(v);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return q;
}
