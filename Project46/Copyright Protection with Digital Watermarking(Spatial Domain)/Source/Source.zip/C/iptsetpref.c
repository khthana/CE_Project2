/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "iptsetpref.h"
#include "images_private_iptprefs.h"
#include "images_private_iptregistry_mex_interface.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;

static mxChar _array3_[51] = { 'F', 'i', 'r', 's', 't', ' ', 'i', 'n', 'p',
                               'u', 't', ' ', 'a', 'r', 'g', 'u', 'm', 'e',
                               'n', 't', ' ', 'm', 'u', 's', 't', ' ', 'b',
                               'e', ' ', 'a', ' ', 'p', 'r', 'o', 'p', 'e',
                               'r', 't', 'y', ' ', 'n', 'a', 'm', 'e', ' ',
                               's', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;

static mxChar _array6_[49] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'I', 'm',
                               'a', 'g', 'e', ' ', 'P', 'r', 'o', 'c', 'e', 's',
                               's', 'i', 'n', 'g', ' ', 'T', 'o', 'o', 'l', 'b',
                               'o', 'x', ' ', 'p', 'r', 'e', 'f', 'e', 'r', 'e',
                               'n', 'c', 'e', ' ', '"', '%', 's', '"', '.' };
static mxArray * _mxarray5_;

static mxChar _array8_[51] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                               ' ', 'I', 'm', 'a', 'g', 'e', ' ', 'P', 'r',
                               'o', 'c', 'e', 's', 's', 'i', 'n', 'g', ' ',
                               'T', 'o', 'o', 'l', 'b', 'o', 'x', ' ', 'p',
                               'r', 'e', 'f', 'e', 'r', 'e', 'n', 'c', 'e',
                               ' ', '"', '%', 's', '"', '.' };
static mxArray * _mxarray7_;
static mxArray * _mxarray9_;

static mxChar _array11_[49] = { 'T', 'h', 'e', ' ', 'I', 'm', 'a', 'g', 'e',
                                ' ', 'P', 'r', 'o', 'c', 'e', 's', 's', 'i',
                                'n', 'g', ' ', 'T', 'o', 'o', 'l', 'b', 'o',
                                'x', ' ', 'p', 'r', 'e', 'f', 'e', 'r', 'e',
                                'n', 'c', 'e', ' ', 's', 'e', 't', 't', 'i',
                                'n', 'g', 0x005c, 'n' };
static mxArray * _mxarray10_;

static mxChar _array13_[43] = { '"', '%', 's', '"', ' ', 'd', 'o', 'e', 's',
                                ' ', 'n', 'o', 't', ' ', 'h', 'a', 'v', 'e',
                                ' ', 'a', ' ', 'f', 'i', 'x', 'e', 'd', ' ',
                                's', 'e', 't', ' ', 'o', 'f', ' ', 'v', 'a',
                                'l', 'u', 'e', 's', '.', 0x005c, 'n' };
static mxArray * _mxarray12_;

static mxChar _array15_[1] = { '[' };
static mxArray * _mxarray14_;

static mxChar _array17_[6] = { ' ', '{', '%', 's', '}', ' ' };
static mxArray * _mxarray16_;

static mxChar _array19_[4] = { ' ', '%', 's', ' ' };
static mxArray * _mxarray18_;

static mxChar _array21_[1] = { '|' };
static mxArray * _mxarray20_;

static mxChar _array23_[3] = { ']', 0x005c, 'n' };
static mxArray * _mxarray22_;
static mxArray * _mxarray24_;

static mxChar _array26_[64] = { 'U', 'n', 'a', 'c', 'c', 'e', 'p', 't',
                                'a', 'b', 'l', 'e', ' ', 'v', 'a', 'l',
                                'u', 'e', ' ', 'f', 'o', 'r', ' ', 'I',
                                'm', 'a', 'g', 'e', ' ', 'P', 'r', 'o',
                                'c', 'e', 's', 's', 'i', 'n', 'g', ' ',
                                'T', 'o', 'o', 'l', 'b', 'o', 'x', ' ',
                                'p', 'r', 'e', 'f', 'e', 'r', 'e', 'n',
                                'c', 'e', ' ', '"', '%', 's', '"', '.' };
static mxArray * _mxarray25_;

void InitializeModule_iptsetpref(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeString(51, _array3_);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray5_ = mclInitializeString(49, _array6_);
    _mxarray7_ = mclInitializeString(51, _array8_);
    _mxarray9_ = mclInitializeDouble(3.0);
    _mxarray10_ = mclInitializeString(49, _array11_);
    _mxarray12_ = mclInitializeString(43, _array13_);
    _mxarray14_ = mclInitializeString(1, _array15_);
    _mxarray16_ = mclInitializeString(6, _array17_);
    _mxarray18_ = mclInitializeString(4, _array19_);
    _mxarray20_ = mclInitializeString(1, _array21_);
    _mxarray22_ = mclInitializeString(3, _array23_);
    _mxarray24_ = mclInitializeDouble(0.0);
    _mxarray25_ = mclInitializeString(64, _array26_);
}

void TerminateModule_iptsetpref(void) {
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Miptsetpref(int nargout_, mxArray * prefName, mxArray * value);

_mexLocalFunctionTable _local_function_table_iptsetpref
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfNIptsetpref" contains the nargout interface for the
 * "iptsetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptsetpref.m" (lines 1-139). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNIptsetpref(int nargout,
                         mlfVarargoutList * varargout,
                         mxArray * prefName,
                         mxArray * value) {
    mlfEnterNewContext(0, 2, prefName, value);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Miptsetpref(nargout, prefName, value);
    mlfRestorePreviousContext(0, 2, prefName, value);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfIptsetpref" contains the normal interface for the
 * "iptsetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptsetpref.m" (lines 1-139). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfIptsetpref(mlfVarargoutList * varargout,
                        mxArray * prefName,
                        mxArray * value) {
    int nargout = 0;
    mlfEnterNewContext(0, 2, prefName, value);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Miptsetpref(nargout, prefName, value);
    mlfRestorePreviousContext(0, 2, prefName, value);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVIptsetpref" contains the void interface for the
 * "iptsetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptsetpref.m" (lines 1-139). The void
 * interface is only produced if the M-function uses the special variable
 * "nargout", and has at least one output. The void interface function
 * specifies zero output arguments to the implementation version of the
 * function, and in the event that the implementation version still returns an
 * output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVIptsetpref(mxArray * prefName, mxArray * value) {
    mxArray * varargout = NULL;
    mlfEnterNewContext(0, 2, prefName, value);
    varargout = Miptsetpref(0, prefName, value);
    mlfRestorePreviousContext(0, 2, prefName, value);
    mxDestroyArray(varargout);
}

/*
 * The function "mlxIptsetpref" contains the feval interface for the
 * "iptsetpref" M-function from file
 * "k:\matlab6p5\toolbox\images\images\iptsetpref.m" (lines 1-139). The feval
 * function calls the implementation version of iptsetpref through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxIptsetpref(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: iptsetpref Line: 1 Column"
            ": 1 The function \"iptsetpref\" was called with"
            " more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Miptsetpref(nlhs, mprhs[0], mprhs[1]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
}

/*
 * The function "Miptsetpref" is the implementation version of the "iptsetpref"
 * M-function from file "k:\matlab6p5\toolbox\images\images\iptsetpref.m"
 * (lines 1-139). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function varargout = iptsetpref(prefName, value)
 */
static mxArray * Miptsetpref(int nargout_,
                             mxArray * prefName,
                             mxArray * value) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_iptsetpref);
    int nargin_ = mclNargin(2, prefName, value, NULL);
    mxArray * varargout = NULL;
    mxArray * valueIsAcceptable = NULL;
    mxArray * notLast = NULL;
    mxArray * isDefault = NULL;
    mxArray * thisValue = NULL;
    mxArray * defaultValue = NULL;
    mxArray * allowedValues = NULL;
    mxArray * preference = NULL;
    mxArray * matchIdx = NULL;
    mxArray * k = NULL;
    mxArray * lowerNames = NULL;
    mxArray * allNames = NULL;
    mxArray * factoryPrefs = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&prefName);
    mclCopyArray(&value);
    /*
     * %IPTSETPREF Set Image Processing Toolbox preference.
     * %   IPTSETPREF(PREFNAME,VALUE) sets the Image Processing Toolbox
     * %   preference specified by the string PREFNAME to VALUE. The
     * %   setting persists until the end of the current MATLAB session,
     * %   or until you change the setting. (To make the value persist
     * %   between sessions, put the command in your startup.m file.)
     * %
     * %   Preference names are case insensitive and can be
     * %   abbreviated.
     * %
     * %   The following preference values can be set:
     * %
     * %   'ImshowBorder'        'loose' (default) or 'tight'
     * %
     * %        If 'ImshowBorder' is 'loose', IMSHOW displays images
     * %        with a border between the image and the edges of the
     * %        figure window, thus leaving room for axes labels,
     * %        titles, etc. If 'ImshowBorder' is 'tight', then IMSHOW
     * %        adjusts the figure size so that the image entirely fills
     * %        the figure. (However, there may still be a border if the
     * %        image is very small, or if there are other objects
     * %        besides the image and its axes in the figure.)
     * %
     * %   'ImshowAxesVisible'   'on' or 'off' (default)
     * %
     * %        If 'ImshowAxesVisible' is 'on', IMSHOW displays images
     * %        with the axes box and tick labels.  If
     * %        'ImShowAxesVisible' is 'off', IMSHOW displays images
     * %        without the axes box and tick labels.
     * %
     * %   'ImshowTruesize'      'auto' (default) or 'manual'
     * %
     * %        If 'ImshowTruesize' is 'manual', IMSHOW does not call
     * %        TRUESIZE. If 'ImshowTruesize' is 'auto', IMSHOW
     * %        automatically decides whether to call TRUESIZE. (IMSHOW
     * %        calls TRUESIZE if there will be no other objects in the
     * %        resulting figure besides the image and its axes.) You can
     * %        override this setting for an individual display by
     * %        specifying the DISPLAY_OPTION argument to IMSHOW, or you
     * %        can call TRUESIZE manually after displaying the image.
     * %
     * %   'TruesizeWarning'     'on' (default) or 'off'
     * %
     * %        If 'TruesizeWarning' is 'on', TRUESIZE displays a
     * %        warning if the image is too large to fit on the
     * %        screen. If 'TruesizeWarning' is 'off', TRUESIZE does not
     * %        display the warning. Note that this preference applies
     * %        even when you call TRUESIZE indirectly, such as through
     * %        IMSHOW.
     * %
     * %   IPTSETPREF(PREFNAME) displays the valid values for PREFNAME.
     * %
     * %   Example
     * %   -------
     * %       iptsetpref('ImshowBorder', 'tight')
     * %
     * %   See also IMSHOW, IPTGETPREF, TRUESIZE.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.17 $  $Date: 2002/03/15 15:28:27 $
     * 
     * error(nargchk(1,2,nargin));
     */
    mlfError(mlfNargchk(_mxarray0_, _mxarray1_, mlfScalar(nargin_)), NULL);
    /*
     * 
     * if (~ischar(prefName))
     */
    if (mclNotBool(mlfIschar(mclVa(prefName, "prefName")))) {
        /*
         * error('First input argument must be a property name string');
         */
        mlfError(_mxarray2_, NULL);
    /*
     * end
     */
    }
    /*
     * 
     * % Get factory IPT preference settings.
     * factoryPrefs = iptprefs;  
     */
    mlfAssign(&factoryPrefs, mlfImages_private_iptprefs());
    /*
     * allNames = factoryPrefs(:,1);
     */
    mlfAssign(
      &allNames,
      mclArrayRef2(
        mclVv(factoryPrefs, "factoryPrefs"),
        mlfCreateColonIndex(),
        _mxarray0_));
    /*
     * 
     * % Convert factory preference names to lower case.
     * lowerNames = cell(size(allNames));
     */
    mlfAssign(
      &lowerNames,
      mlfCell(
        mlfSize(mclValueVarargout(), mclVv(allNames, "allNames"), NULL), NULL));
    /*
     * for k = 1:length(lowerNames)
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclLengthInt(mclVv(lowerNames, "lowerNames"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray4_);
        } else {
            /*
             * lowerNames{k} = lower(allNames{k});
             * end
             */
            for (; ; ) {
                mlfIndexAssign(
                  &lowerNames,
                  "{?}",
                  mlfScalar(v_),
                  mclFeval(
                    mclValueVarargout(),
                    mlxLower,
                    mlfIndexRef(
                      mclVv(allNames, "allNames"), "{?}", mlfScalar(v_)),
                    NULL));
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * matchIdx = strmatch(lower(prefName), lowerNames);
     */
    mlfAssign(
      &matchIdx,
      mlfStrmatch(
        mlfLower(mclVa(prefName, "prefName")),
        mclVv(lowerNames, "lowerNames"),
        NULL));
    /*
     * if (isempty(matchIdx))
     */
    if (mlfTobool(mlfIsempty(mclVv(matchIdx, "matchIdx")))) {
        /*
         * error(sprintf('Unknown Image Processing Toolbox preference "%s".', prefName));
         */
        mlfError(
          mlfSprintf(NULL, _mxarray5_, mclVa(prefName, "prefName"), NULL),
          NULL);
    /*
     * elseif (length(matchIdx) > 1)
     */
    } else if (mclLengthInt(mclVv(matchIdx, "matchIdx")) > 1) {
        /*
         * error(sprintf('Ambiguous Image Processing Toolbox preference "%s".', prefName));
         */
        mlfError(
          mlfSprintf(NULL, _mxarray7_, mclVa(prefName, "prefName"), NULL),
          NULL);
    /*
     * else
     */
    } else {
        /*
         * preference = allNames{matchIdx};
         */
        mlfAssign(
          &preference,
          mlfIndexRef(
            mclVv(allNames, "allNames"), "{?}", mclVv(matchIdx, "matchIdx")));
    /*
     * end
     */
    }
    /*
     * 
     * allowedValues = factoryPrefs{matchIdx, 2};
     */
    mlfAssign(
      &allowedValues,
      mlfIndexRef(
        mclVv(factoryPrefs, "factoryPrefs"),
        "{?,?}",
        mclVv(matchIdx, "matchIdx"),
        _mxarray1_));
    /*
     * 
     * if (nargin == 1)
     */
    if (nargin_ == 1) {
        /*
         * if (nargout == 0)
         */
        if (nargout_ == 0) {
            /*
             * % Print possible settings
             * defaultValue = factoryPrefs{matchIdx, 3};
             */
            mlfAssign(
              &defaultValue,
              mlfIndexRef(
                mclVv(factoryPrefs, "factoryPrefs"),
                "{?,?}",
                mclVv(matchIdx, "matchIdx"),
                _mxarray9_));
            /*
             * if (isempty(allowedValues))
             */
            if (mlfTobool(mlfIsempty(mclVv(allowedValues, "allowedValues")))) {
                /*
                 * fprintf('The Image Processing Toolbox preference setting\n');
                 */
                mclAssignAns(&ans, mlfNFprintf(0, _mxarray10_, NULL));
                /*
                 * fprintf('"%s" does not have a fixed set of values.\n', preference);
                 */
                mclAssignAns(
                  &ans,
                  mlfNFprintf(
                    0, _mxarray12_, mclVv(preference, "preference"), NULL));
            /*
             * else
             */
            } else {
                /*
                 * fprintf('[');
                 */
                mclAssignAns(&ans, mlfNFprintf(0, _mxarray14_, NULL));
                /*
                 * for k = 1:length(allowedValues)
                 */
                {
                    int v_ = mclForIntStart(1);
                    int e_
                      = mclLengthInt(mclVv(allowedValues, "allowedValues"));
                    if (v_ > e_) {
                        mlfAssign(&k, _mxarray4_);
                    } else {
                        /*
                         * thisValue = allowedValues{k};
                         * isDefault = ~isempty(defaultValue) & ...
                         * isequal(defaultValue{1}, thisValue);
                         * if (isDefault)
                         * fprintf(' {%s} ', num2str(thisValue));
                         * else
                         * fprintf(' %s ', num2str(thisValue));
                         * end
                         * notLast = k ~= length(allowedValues);
                         * if (notLast)
                         * fprintf('|');
                         * end
                         * end
                         */
                        for (; ; ) {
                            mlfAssign(
                              &thisValue,
                              mlfIndexRef(
                                mclVv(allowedValues, "allowedValues"),
                                "{?}",
                                mlfScalar(v_)));
                            mlfAssign(
                              &isDefault,
                              mclAnd(
                                mclNot(
                                  mlfIsempty(
                                    mclVv(defaultValue, "defaultValue"))),
                                mclFeval(
                                  mclValueVarargout(),
                                  mlxIsequal,
                                  mlfIndexRef(
                                    mclVv(defaultValue, "defaultValue"),
                                    "{?}",
                                    _mxarray0_),
                                  mclVv(thisValue, "thisValue"),
                                  NULL)));
                            if (mlfTobool(mclVv(isDefault, "isDefault"))) {
                                mclAssignAns(
                                  &ans,
                                  mlfNFprintf(
                                    0,
                                    _mxarray16_,
                                    mlfNum2str(
                                      mclVv(thisValue, "thisValue"), NULL),
                                    NULL));
                            } else {
                                mclAssignAns(
                                  &ans,
                                  mlfNFprintf(
                                    0,
                                    _mxarray18_,
                                    mlfNum2str(
                                      mclVv(thisValue, "thisValue"), NULL),
                                    NULL));
                            }
                            mlfAssign(
                              &notLast,
                              mclBoolToArray(
                                v_
                                != mclLengthInt(
                                     mclVv(allowedValues, "allowedValues"))));
                            if (mlfTobool(mclVv(notLast, "notLast"))) {
                                mclAssignAns(
                                  &ans, mlfNFprintf(0, _mxarray20_, NULL));
                            }
                            if (v_ == e_) {
                                break;
                            }
                            ++v_;
                        }
                        mlfAssign(&k, mlfScalar(v_));
                    }
                }
                /*
                 * fprintf(']\n');
                 */
                mclAssignAns(&ans, mlfNFprintf(0, _mxarray22_, NULL));
            /*
             * end
             */
            }
        /*
         * 
         * else
         */
        } else {
            /*
             * % Return possible values as cell array.
             * varargout{1} = factoryPrefs{matchIdx,2};
             */
            mlfIndexAssign(
              &varargout,
              "{?}",
              _mxarray0_,
              mlfIndexRef(
                mclVv(factoryPrefs, "factoryPrefs"),
                "{?,?}",
                mclVv(matchIdx, "matchIdx"),
                _mxarray1_));
        /*
         * end
         */
        }
    /*
     * 
     * else
     */
    } else {
        /*
         * % Syntax: IPTSETPREF(PREFNAME,VALUE)
         * 
         * valueIsAcceptable = 0;
         */
        mlfAssign(&valueIsAcceptable, _mxarray24_);
        /*
         * for k = 1:length(allowedValues)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclLengthInt(mclVv(allowedValues, "allowedValues"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray4_);
            } else {
                /*
                 * if (isequal(value, allowedValues{k}))
                 * valueIsAcceptable = 1;
                 * iptregistry(setfield(iptregistry, preference, value));
                 * break;
                 * end
                 * end
                 */
                for (; ; ) {
                    if (mlfTobool(
                          mlfIsequal(
                            mclVa(value, "value"),
                            mlfIndexRef(
                              mclVv(allowedValues, "allowedValues"),
                              "{?}",
                              mlfScalar(v_)),
                            NULL))) {
                        mlfAssign(&valueIsAcceptable, _mxarray0_);
                        mclAssignAns(
                          &ans,
                          mlfNImages_private_iptregistry(
                            0,
                            mclAnsVarargout(),
                            mlfSetfield(
                              mlfNImages_private_iptregistry(
                                0, mclValueVarargout(), NULL),
                              mclVv(preference, "preference"),
                              mclVa(value, "value"),
                              NULL),
                            NULL));
                        break;
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * 
         * if (~valueIsAcceptable)
         */
        if (mclNotBool(mclVv(valueIsAcceptable, "valueIsAcceptable"))) {
            /*
             * error(sprintf(['Unacceptable value for Image Processing' ...
             */
            mlfError(
              mlfSprintf(
                NULL, _mxarray25_, mclVv(preference, "preference"), NULL),
              NULL);
        /*
         * ' Toolbox preference "%s".'], preference));
         * end
         */
        }
    /*
     * 
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(factoryPrefs);
    mxDestroyArray(allNames);
    mxDestroyArray(lowerNames);
    mxDestroyArray(k);
    mxDestroyArray(matchIdx);
    mxDestroyArray(preference);
    mxDestroyArray(allowedValues);
    mxDestroyArray(defaultValue);
    mxDestroyArray(thisValue);
    mxDestroyArray(isDefault);
    mxDestroyArray(notLast);
    mxDestroyArray(valueIsAcceptable);
    mxDestroyArray(value);
    mxDestroyArray(prefName);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
}
