/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __imcrop_h
#define __imcrop_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_imcrop(void);
extern void TerminateModule_imcrop(void);
extern _mexLocalFunctionTable _local_function_table_imcrop;

extern mxArray * mlfNImcrop(int nargout, mlfVarargoutList * varargout, ...);
extern mxArray * mlfImcrop(mlfVarargoutList * varargout, ...);
extern void mlfVImcrop(mxArray * synthetic_varargin_argument, ...);
extern void mlxImcrop(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
