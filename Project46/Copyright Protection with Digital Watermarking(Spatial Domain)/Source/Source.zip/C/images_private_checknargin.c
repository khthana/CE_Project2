/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_checknargin.h"
#include "libmatlbm.h"

static mxChar _array1_[22] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                               's', ':', 't', 'o', 'o', 'F', 'e', 'w',
                               'I', 'n', 'p', 'u', 't', 's' };
static mxArray * _mxarray0_;
static mxArray * _mxarray2_;

static mxChar _array4_[46] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', '%',
                               's', ' ', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                               ' ', 'a', 't', ' ', 'l', 'e', 'a', 's', 't', ' ',
                               '1', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                               'g', 'u', 'm', 'e', 'n', 't' };
static mxArray * _mxarray3_;

static mxChar _array6_[48] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ', '%',
                               's', ' ', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
                               ' ', 'a', 't', ' ', 'l', 'e', 'a', 's', 't', ' ',
                               '%', 'd', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a',
                               'r', 'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray5_;

static mxChar _array8_[45] = { 'b', 'u', 't', ' ', 'w', 'a', 's', ' ', 'c',
                               'a', 'l', 'l', 'e', 'd', ' ', 'i', 'n', 's',
                               't', 'e', 'a', 'd', ' ', 'w', 'i', 't', 'h',
                               ' ', '1', ' ', 'i', 'n', 'p', 'u', 't', ' ',
                               'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', '.' };
static mxArray * _mxarray7_;

static mxChar _array10_[47] = { 'b', 'u', 't', ' ', 'w', 'a', 's', ' ',
                                'c', 'a', 'l', 'l', 'e', 'd', ' ', 'i',
                                'n', 's', 't', 'e', 'a', 'd', ' ', 'w',
                                'i', 't', 'h', ' ', '%', 'd', ' ', 'i',
                                'n', 'p', 'u', 't', ' ', 'a', 'r', 'g',
                                'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray9_;

static mxChar _array12_[6] = { '%', 's', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray11_;

static mxChar _array14_[23] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%',
                                's', ':', 't', 'o', 'o', 'M', 'a', 'n',
                                'y', 'I', 'n', 'p', 'u', 't', 's' };
static mxArray * _mxarray13_;

static mxChar _array16_[45] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '%', 's', ' ', 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', ' ', 'a', 't', ' ', 'm', 'o', 's',
                                't', ' ', '1', ' ', 'i', 'n', 'p', 'u', 't',
                                ' ', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't' };
static mxArray * _mxarray15_;

static mxChar _array18_[47] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n',
                                ' ', '%', 's', ' ', 'e', 'x', 'p', 'e',
                                'c', 't', 'e', 'd', ' ', 'a', 't', ' ',
                                'm', 'o', 's', 't', ' ', '%', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's' };
static mxArray * _mxarray17_;

void InitializeModule_images_private_checknargin(void) {
    _mxarray0_ = mclInitializeString(22, _array1_);
    _mxarray2_ = mclInitializeDouble(1.0);
    _mxarray3_ = mclInitializeString(46, _array4_);
    _mxarray5_ = mclInitializeString(48, _array6_);
    _mxarray7_ = mclInitializeString(45, _array8_);
    _mxarray9_ = mclInitializeString(47, _array10_);
    _mxarray11_ = mclInitializeString(6, _array12_);
    _mxarray13_ = mclInitializeString(23, _array14_);
    _mxarray15_ = mclInitializeString(45, _array16_);
    _mxarray17_ = mclInitializeString(47, _array18_);
}

void TerminateModule_images_private_checknargin(void) {
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static void Mimages_private_checknargin(mxArray * low,
                                        mxArray * high,
                                        mxArray * numInputs,
                                        mxArray * function_name);

_mexLocalFunctionTable _local_function_table_images_private_checknargin
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_checknargin" contains the normal interface
 * for the "images/private/checknargin" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checknargin.m" (lines 1-59).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlfImages_private_checknargin(mxArray * low,
                                   mxArray * high,
                                   mxArray * numInputs,
                                   mxArray * function_name) {
    mlfEnterNewContext(0, 4, low, high, numInputs, function_name);
    Mimages_private_checknargin(low, high, numInputs, function_name);
    mlfRestorePreviousContext(0, 4, low, high, numInputs, function_name);
}

/*
 * The function "mlxImages_private_checknargin" contains the feval interface
 * for the "images/private/checknargin" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checknargin.m" (lines 1-59). The
 * feval function calls the implementation version of
 * images/private/checknargin through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
void mlxImages_private_checknargin(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checknargin Line: 1 C"
            "olumn: 1 The function \"images/private/checknargin\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/checknargin Line: 1 C"
            "olumn: 1 The function \"images/private/checknargin\" was c"
            "alled with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    Mimages_private_checknargin(mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
}

/*
 * The function "Mimages_private_checknargin" is the implementation version of
 * the "images/private/checknargin" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\checknargin.m" (lines 1-59). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function checknargin(low, high, numInputs, function_name)
 */
static void Mimages_private_checknargin(mxArray * low,
                                        mxArray * high,
                                        mxArray * numInputs,
                                        mxArray * function_name) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_checknargin);
    mxArray * ans = NULL;
    mxArray * msg2 = NULL;
    mxArray * msg1 = NULL;
    mxArray * msgId = NULL;
    mclCopyArray(&low);
    mclCopyArray(&high);
    mclCopyArray(&numInputs);
    mclCopyArray(&function_name);
    /*
     * %CHECKNARGIN Check number of input arguments.
     * %   CHECKNARGIN(LOW,HIGH,NUM_INPUTS,FUNCTION_NAME) checks whether NUM_INPUTS
     * %   is in the range indicated by LOW and HIGH.  If not, CHECKNARGIN issues a
     * %   formatted error message using the string in FUNCTION_NAME.
     * %
     * %   LOW should be a scalar nonnegative integer.
     * %
     * %   HIGH should be a scalar nonnegative integer or Inf.
     * %
     * %   FUNCTION_NAME should be a string.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.2 $  $Date: 2002/03/15 15:57:05 $
     * 
     * % Input arguments are not checked for validity.
     * 
     * if numInputs < low
     */
    if (mclLtBool(mclVa(numInputs, "numInputs"), mclVa(low, "low"))) {
        /*
         * msgId = sprintf('Images:%s:tooFewInputs', function_name);
         */
        mlfAssign(
          &msgId,
          mlfSprintf(
            NULL, _mxarray0_, mclVa(function_name, "function_name"), NULL));
        /*
         * if low == 1
         */
        if (mclEqBool(mclVa(low, "low"), _mxarray2_)) {
            /*
             * msg1 = sprintf('Function %s expected at least 1 input argument', ...
             */
            mlfAssign(
              &msg1,
              mlfSprintf(
                NULL, _mxarray3_, mclVa(function_name, "function_name"), NULL));
        /*
         * function_name);
         * else
         */
        } else {
            /*
             * msg1 = sprintf('Function %s expected at least %d input arguments', ...
             */
            mlfAssign(
              &msg1,
              mlfSprintf(
                NULL,
                _mxarray5_,
                mclVa(function_name, "function_name"),
                mclVa(low, "low"),
                NULL));
        /*
         * function_name, low);
         * end
         */
        }
        /*
         * 
         * if numInputs == 1
         */
        if (mclEqBool(mclVa(numInputs, "numInputs"), _mxarray2_)) {
            /*
             * msg2 = 'but was called instead with 1 input argument.';
             */
            mlfAssign(&msg2, _mxarray7_);
        /*
         * else
         */
        } else {
            /*
             * msg2 = sprintf('but was called instead with %d input arguments.', ...
             */
            mlfAssign(
              &msg2,
              mlfSprintf(
                NULL, _mxarray9_, mclVa(numInputs, "numInputs"), NULL));
        /*
         * numInputs);
         * end
         */
        }
        /*
         * 
         * error(msgId, '%s\n%s', msg1, msg2);
         */
        mlfError(
          mclVv(msgId, "msgId"),
          _mxarray11_,
          mclVv(msg1, "msg1"),
          mclVv(msg2, "msg2"),
          NULL);
    /*
     * 
     * elseif numInputs > high
     */
    } else if (mclGtBool(mclVa(numInputs, "numInputs"), mclVa(high, "high"))) {
        /*
         * msgId = sprintf('Images:%s:tooManyInputs', function_name);
         */
        mlfAssign(
          &msgId,
          mlfSprintf(
            NULL, _mxarray13_, mclVa(function_name, "function_name"), NULL));
        /*
         * 
         * if high == 1
         */
        if (mclEqBool(mclVa(high, "high"), _mxarray2_)) {
            /*
             * msg1 = sprintf('Function %s expected at most 1 input argument', ...
             */
            mlfAssign(
              &msg1,
              mlfSprintf(
                NULL,
                _mxarray15_,
                mclVa(function_name, "function_name"),
                NULL));
        /*
         * function_name);
         * else
         */
        } else {
            /*
             * msg1 = sprintf('Function %s expected at most %d input arguments', ...
             */
            mlfAssign(
              &msg1,
              mlfSprintf(
                NULL,
                _mxarray17_,
                mclVa(function_name, "function_name"),
                mclVa(high, "high"),
                NULL));
        /*
         * function_name, high);
         * end
         */
        }
        /*
         * 
         * if numInputs == 1
         */
        if (mclEqBool(mclVa(numInputs, "numInputs"), _mxarray2_)) {
            /*
             * msg2 = 'but was called instead with 1 input argument.';
             */
            mlfAssign(&msg2, _mxarray7_);
        /*
         * else
         */
        } else {
            /*
             * msg2 = sprintf('but was called instead with %d input arguments.', ...
             */
            mlfAssign(
              &msg2,
              mlfSprintf(
                NULL, _mxarray9_, mclVa(numInputs, "numInputs"), NULL));
        /*
         * numInputs);
         * end
         */
        }
        /*
         * 
         * error(msgId, '%s\n%s', msg1, msg2);
         */
        mlfError(
          mclVv(msgId, "msgId"),
          _mxarray11_,
          mclVv(msg1, "msg1"),
          mclVv(msg2, "msg2"),
          NULL);
    /*
     * end
     */
    }
    mxDestroyArray(msgId);
    mxDestroyArray(msg1);
    mxDestroyArray(msg2);
    mxDestroyArray(ans);
    mxDestroyArray(function_name);
    mxDestroyArray(numInputs);
    mxDestroyArray(high);
    mxDestroyArray(low);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}
