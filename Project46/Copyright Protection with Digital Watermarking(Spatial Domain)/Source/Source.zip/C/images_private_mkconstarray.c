/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:08 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "images_private_mkconstarray.h"
#include "libmatlbm.h"
#include "libmmfile.h"

void InitializeModule_images_private_mkconstarray(void) {
}

void TerminateModule_images_private_mkconstarray(void) {
}

static mxArray * Mimages_private_mkconstarray(int nargout_,
                                              mxArray * class0,
                                              mxArray * value,
                                              mxArray * size);

_mexLocalFunctionTable _local_function_table_images_private_mkconstarray
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfImages_private_mkconstarray" contains the normal interface
 * for the "images/private/mkconstarray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\mkconstarray.m" (lines 1-11).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImages_private_mkconstarray(mxArray * class0,
                                         mxArray * value,
                                         mxArray * size) {
    int nargout = 1;
    mxArray * out = NULL;
    mlfEnterNewContext(0, 3, class0, value, size);
    out = Mimages_private_mkconstarray(nargout, class0, value, size);
    mlfRestorePreviousContext(0, 3, class0, value, size);
    return mlfReturnValue(out);
}

/*
 * The function "mlxImages_private_mkconstarray" contains the feval interface
 * for the "images/private/mkconstarray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\mkconstarray.m" (lines 1-11).
 * The feval function calls the implementation version of
 * images/private/mkconstarray through this function. This function processes
 * any input arguments and passes them to the implementation version of the
 * function, appearing above.
 */
void mlxImages_private_mkconstarray(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/mkconstarray Line: 1 C"
            "olumn: 1 The function \"images/private/mkconstarray\" was c"
            "alled with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: images/private/mkconstarray Line: 1 C"
            "olumn: 1 The function \"images/private/mkconstarray\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mimages_private_mkconstarray(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimages_private_mkconstarray" is the implementation version of
 * the "images/private/mkconstarray" M-function from file
 * "k:\matlab6p5\toolbox\images\images\private\mkconstarray.m" (lines 1-11). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function out = mkconstarray(class, value, size)
 */
static mxArray * Mimages_private_mkconstarray(int nargout_,
                                              mxArray * class0,
                                              mxArray * value,
                                              mxArray * size) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_images_private_mkconstarray);
    mxArray * out = NULL;
    mclCopyArray(&class0);
    mclCopyArray(&value);
    mclCopyArray(&size);
    /*
     * %MKCONSTARRAY creates a constant array of a specified numeric class.
     * %   A = MKCONSTARRAY(CLASS, VALUE, SIZE) creates a constant array 
     * %   of value VALUE and of size SIZE.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.8 $  $Date: 2002/03/15 15:58:11 $
     * 
     * out = repmat(feval(class, value), size);
     */
    mlfAssign(
      &out,
      mlfRepmat(
        mlfFeval(
          mclValueVarargout(),
          mclVa(class0, "class"),
          mclVa(value, "value"),
          NULL),
        mclVa(size, "size"),
        NULL));
    mclValidateOutput(out, 1, nargout_, "out", "images/private/mkconstarray");
    mxDestroyArray(size);
    mxDestroyArray(value);
    mxDestroyArray(class0);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return out;
    /*
     * 
     */
}
