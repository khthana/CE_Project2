/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imresize.h"
#include "fliptform.h"
#include "im2double.h"
#include "images_private_changeclass.h"
#include "images_private_checkinput.h"
#include "imfilter.h"
#include "imshow.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "makeresampler.h"
#include "maketform.h"
#include "tformarray.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;

static mxChar _array4_[1] = { 'n' };
static mxArray * _mxarray3_;

static mxChar _array6_[52] = { 'I', 'n', 'p', 'u', 't', ' ', 'i', 's', ' ',
                               't', 'o', 'o', ' ', 's', 'm', 'a', 'l', 'l',
                               ' ', 'f', 'o', 'r', ' ', 'b', 'i', 'l', 'i',
                               'n', 'e', 'a', 'r', ' ', 'o', 'r', ' ', 'b',
                               'i', 'c', 'u', 'b', 'i', 'c', ' ', 'm', 'e',
                               't', 'h', 'o', 'd', ';', 0x005c, 'n' };
static mxArray * _mxarray5_;

static mxChar _array8_[40] = { 'u', 's', 'i', 'n', 'g', ' ', 'n', 'e', 'a',
                               'r', 'e', 's', 't', '-', 'n', 'e', 'i', 'g',
                               'h', 'b', 'o', 'r', ' ', 'm', 'e', 't', 'h',
                               'o', 'd', ' ', 'i', 'n', 's', 't', 'e', 'a',
                               'd', '.', 0x005c, 'n' };
static mxArray * _mxarray7_;

static mxChar _array10_[7] = { 'n', 'e', 'a', 'r', 'e', 's', 't' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[1] = { 'b' };
static mxArray * _mxarray12_;

static mxChar _array15_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;

static mxChar _array21_[3] = { 'b', 'o', 'x' };
static mxArray * _mxarray20_;

static double _array23_[2] = { 0.0, 0.0 };
static mxArray * _mxarray22_;

static mxChar _array25_[6] = { 'a', 'f', 'f', 'i', 'n', 'e' };
static mxArray * _mxarray24_;

static mxChar _array27_[9] = { 'c', 'o', 'm', 'p', 'o', 's', 'i', 't', 'e' };
static mxArray * _mxarray26_;

static mxChar _array29_[7] = { 'b', 'i', 'c', 'u', 'b', 'i', 'c' };
static mxArray * _mxarray28_;

static mxChar _array31_[5] = { 'c', 'u', 'b', 'i', 'c' };
static mxArray * _mxarray30_;

static mxChar _array33_[9] = { 'r', 'e', 'p', 'l', 'i', 'c', 'a', 't', 'e' };
static mxArray * _mxarray32_;

static mxChar _array35_[6] = { 'l', 'i', 'n', 'e', 'a', 'r' };
static mxArray * _mxarray34_;

static double _array37_[2] = { 1.0, 2.0 };
static mxArray * _mxarray36_;
static mxArray * _mxarray38_;

static mxChar _array40_[127] = { '[', 'R', '1', ',', 'G', '1', ',', 'B', '1',
                                 ']', ' ', '=', ' ', 'I', 'M', 'R', 'E', 'S',
                                 'I', 'Z', 'E', '(', 'R', ',', 'G', ',', 'B',
                                 ',', '.', '.', '.', ')', ' ', 'i', 's', ' ',
                                 'a', 'n', ' ', 'o', 'b', 's', 'o', 'l', 'e',
                                 't', 'e', ' ', 's', 'y', 'n', 't', 'a', 'x',
                                 '.', ' ', 'U', 's', 'e', ' ', 'a', ' ', 't',
                                 'h', 'r', 'e', 'e', '-', 'd', 'i', 'm', 'e',
                                 'n', 's', 'i', 'o', 'n', 'a', 'l', ' ', 'a',
                                 'r', 'r', 'a', 'y', ' ', 't', 'o', ' ', 'r',
                                 'e', 'p', 'r', 'e', 's', 'e', 'n', 't', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'a', 'n', 'd',
                                 ' ', 'o', 'u', 't', 'p', 'u', 't', ' ', 'R',
                                 'G', 'B', ' ', 'i', 'm', 'a', 'g', 'e', 's',
                                 '.' };
static mxArray * _mxarray39_;
static mxArray * _mxarray41_;

static mxChar _array43_[93] = { 'I', 'M', 'R', 'E', 'S', 'I', 'Z', 'E', '(',
                                'R', ',', 'G', ',', 'B', ',', 'M', ')', ' ',
                                'i', 's', ' ', 'a', 'n', ' ', 'o', 'b', 's',
                                'o', 'l', 'e', 't', 'e', ' ', 's', 'y', 'n',
                                't', 'a', 'x', '.', 'U', 's', 'e', ' ', 'a',
                                ' ', 't', 'h', 'r', 'e', 'e', '-', 'd', 'i',
                                'm', 'e', 'n', 's', 'i', 'o', 'n', 'a', 'l',
                                ' ', 'a', 'r', 'r', 'a', 'y', ' ', 't', 'o',
                                ' ', 'r', 'e', 'p', 'r', 'e', 's', 'e', 'n',
                                't', ' ', 'R', 'G', 'B', ' ', 'i', 'm', 'a',
                                'g', 'e', '.' };
static mxArray * _mxarray42_;
static mxArray * _mxarray44_;

static mxChar _array46_[103] = { 'I', 'M', 'R', 'E', 'S', 'I', 'Z', 'E', '(',
                                 'R', ',', 'G', ',', 'B', ',', 'M', ',',
                                 0x0027, 'm', 'e', 't', 'h', 'o', 'd',
                                 0x0027, ')', ' ', 'i', 's', ' ', 'a', 'n',
                                 ' ', 'o', 'b', 's', 'o', 'l', 'e', 't', 'e',
                                 ' ', 's', 'y', 'n', 't', 'a', 'x', '.', ' ',
                                 'U', 's', 'e', ' ', 'a', ' ', 't', 'h', 'r',
                                 'e', 'e', '-', 'd', 'i', 'm', 'e', 'n', 's',
                                 'i', 'o', 'n', 'a', 'l', ' ', 'a', 'r', 'r',
                                 'a', 'y', ' ', 't', 'o', ' ', 'r', 'e', 'p',
                                 'r', 'e', 's', 'e', 'n', 't', ' ', 'R', 'G',
                                 'B', ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray45_;

static mxChar _array48_[104] = { 'I', 'M', 'R', 'E', 'S', 'I', 'Z', 'E', '(',
                                 'R', ',', 'G', ',', 'B', ',', 'M', ',',
                                 0x0027, 'm', 'e', 't', 'h', 'o', 'd', 0x0027,
                                 ',', 'H', ')', ' ', 'i', 's', ' ', 'a', 'n',
                                 ' ', 'o', 'b', 's', 'o', 'l', 'e', 't', 'e',
                                 ' ', 's', 'y', 'n', 't', 'a', 'x', '.', 'U',
                                 's', 'e', ' ', 'a', ' ', 't', 'h', 'r', 'e',
                                 'e', '-', 'd', 'i', 'm', 'e', 'n', 's', 'i',
                                 'o', 'n', 'a', 'l', ' ', 'a', 'r', 'r', 'a',
                                 'y', ' ', 't', 'o', ' ', 'r', 'e', 'p', 'r',
                                 'e', 's', 'e', 'n', 't', ' ', 'R', 'G', 'B',
                                 ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray47_;

static mxChar _array50_[24] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray49_;

static mxChar _array54_[7] = { 'n', 'u', 'm', 'e', 'r', 'i', 'c' };
static mxArray * _mxarray53_;

static mxChar _array56_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray55_;

static mxArray * _array52_[2] = { NULL /*_mxarray53_*/, NULL /*_mxarray55_*/ };
static mxArray * _mxarray51_;

static mxChar _array59_[9] = { 'n', 'o', 'n', 's', 'p', 'a', 'r', 's', 'e' };
static mxArray * _mxarray58_;
static mxArray * _mxarray57_;

static mxChar _array61_[1] = { 'A' };
static mxArray * _mxarray60_;

static mxChar _array63_[61] = { 'M', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', 'e', 'i', 't', 'h', 'e', 'r', ' ', 'a',
                                ' ', 's', 'c', 'a', 'l', 'a', 'r', ' ', 'm',
                                'u', 'l', 't', 'i', 'p', 'l', 'i', 'e', 'r',
                                ' ', 'o', 'r', ' ', 'a', ' ', '1', '-', 'b',
                                'y', '-', '2', ' ', 's', 'i', 'z', 'e', ' ',
                                'v', 'e', 'c', 't', 'o', 'r', '.' };
static mxArray * _mxarray62_;

static mxChar _array67_[8] = { 'b', 'i', 'l', 'i', 'n', 'e', 'a', 'r' };
static mxArray * _mxarray66_;

static mxArray * _array65_[3] = { NULL /*_mxarray9_*/, NULL /*_mxarray66_*/,
                                  NULL /*_mxarray28_*/ };
static mxArray * _mxarray64_;

static mxChar _array69_[32] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ',
                                'i', 'n', 't', 'e', 'r', 'p', 'o', 'l',
                                'a', 't', 'i', 'o', 'n', ' ', 'm', 'e',
                                't', 'h', 'o', 'd', ':', ' ', '%', 's' };
static mxArray * _mxarray68_;

static mxChar _array71_[34] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                ' ', 'i', 'n', 't', 'e', 'r', 'p', 'o', 'l',
                                'a', 't', 'i', 'o', 'n', ' ', 'm', 'e', 't',
                                'h', 'o', 'd', ':', ' ', '%', 's' };
static mxArray * _mxarray70_;

static mxChar _array73_[40] = { 'I', 'n', 't', 'e', 'r', 'p', 'o', 'l',
                                'a', 't', 'i', 'o', 'n', ' ', 'm', 'e',
                                't', 'h', 'o', 'd', ' ', 'h', 'a', 's',
                                ' ', 't', 'o', ' ', 'b', 'e', ' ', 'a',
                                ' ', 's', 't', 'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray72_;

static mxChar _array75_[53] = { 'F', 'i', 'l', 't', 'e', 'r', ' ', 'o', 'r',
                                'd', 'e', 'r', ' ', 'h', 'a', 's', ' ', 't',
                                'o', ' ', 'b', 'e', ' ', 'a', ' ', 'n', 'o',
                                'n', '-', 'n', 'e', 'g', 'a', 't', 'i', 'v',
                                'e', ' ', 'i', 'n', 't', 'e', 'g', 'e', 'r',
                                ',', ' ', 'n', 'o', 't', ' ', '%', 'g' };
static mxArray * _mxarray74_;

static mxChar _array77_[29] = { 'F', 'i', 'l', 't', 'e', 'r', ' ', 'h',
                                'a', 's', ' ', 't', 'o', ' ', 'b', 'e',
                                ' ', 'a', ' ', '2', '-', 'D', ' ', 'a',
                                'r', 'r', 'a', 'y', '.' };
static mxArray * _mxarray76_;
static mxArray * _mxarray78_;
static mxArray * _mxarray79_;
static mxArray * _mxarray80_;
static mxArray * _mxarray81_;

void InitializeModule_imresize(void) {
    _mxarray0_ = mclInitializeDouble(0.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeDouble(2.0);
    _mxarray3_ = mclInitializeString(1, _array4_);
    _mxarray5_ = mclInitializeString(52, _array6_);
    _mxarray7_ = mclInitializeString(40, _array8_);
    _mxarray9_ = mclInitializeString(7, _array10_);
    _mxarray11_ = mclInitializeDouble(4.0);
    _mxarray12_ = mclInitializeString(1, _array13_);
    _mxarray14_ = mclInitializeString(6, _array15_);
    _mxarray16_ = mclInitializeDouble(11.0);
    _mxarray17_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray18_ = mclInitializeDouble(2.220446049250313e-16);
    _mxarray19_ = mclInitializeDouble(3.0);
    _mxarray20_ = mclInitializeString(3, _array21_);
    _mxarray22_ = mclInitializeDoubleVector(1, 2, _array23_);
    _mxarray24_ = mclInitializeString(6, _array25_);
    _mxarray26_ = mclInitializeString(9, _array27_);
    _mxarray28_ = mclInitializeString(7, _array29_);
    _mxarray30_ = mclInitializeString(5, _array31_);
    _mxarray32_ = mclInitializeString(9, _array33_);
    _mxarray34_ = mclInitializeString(6, _array35_);
    _mxarray36_ = mclInitializeDoubleVector(1, 2, _array37_);
    _mxarray38_ = mclInitializeDouble(.5);
    _mxarray39_ = mclInitializeString(127, _array40_);
    _mxarray41_ = mclInitializeDouble(6.0);
    _mxarray42_ = mclInitializeString(93, _array43_);
    _mxarray44_ = mclInitializeDouble(5.0);
    _mxarray45_ = mclInitializeString(103, _array46_);
    _mxarray47_ = mclInitializeString(104, _array48_);
    _mxarray49_ = mclInitializeString(24, _array50_);
    _mxarray53_ = mclInitializeString(7, _array54_);
    _array52_[0] = _mxarray53_;
    _mxarray55_ = mclInitializeString(7, _array56_);
    _array52_[1] = _mxarray55_;
    _mxarray51_ = mclInitializeCellVector(1, 2, _array52_);
    _mxarray58_ = mclInitializeString(9, _array59_);
    _mxarray57_ = mclInitializeCell(_mxarray58_);
    _mxarray60_ = mclInitializeString(1, _array61_);
    _mxarray62_ = mclInitializeString(61, _array63_);
    _array65_[0] = _mxarray9_;
    _mxarray66_ = mclInitializeString(8, _array67_);
    _array65_[1] = _mxarray66_;
    _array65_[2] = _mxarray28_;
    _mxarray64_ = mclInitializeCellVector(1, 3, _array65_);
    _mxarray68_ = mclInitializeString(32, _array69_);
    _mxarray70_ = mclInitializeString(34, _array71_);
    _mxarray72_ = mclInitializeString(40, _array73_);
    _mxarray74_ = mclInitializeString(53, _array75_);
    _mxarray76_ = mclInitializeString(29, _array77_);
    _mxarray78_ = mclInitializeDouble(3.141592653589793);
    _mxarray79_ = mclInitializeDouble(.54);
    _mxarray80_ = mclInitializeDouble(.46);
    _mxarray81_ = mclInitializeDouble(6.283185307179586);
}

void TerminateModule_imresize(void) {
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray80_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray78_);
    mxDestroyArray(_mxarray76_);
    mxDestroyArray(_mxarray74_);
    mxDestroyArray(_mxarray72_);
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray64_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray62_);
    mxDestroyArray(_mxarray60_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray58_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImresize_parse_inputs(mxArray * * m,
                                          mxArray * * method,
                                          mxArray * * h,
                                          ...);
static void mlxImresize_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfImresize_DesignFilter(mxArray * N, mxArray * Wn);
static void mlxImresize_DesignFilter(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * Mimresize(int nargout_, mxArray * varargin);
static mxArray * Mimresize_parse_inputs(mxArray * * m,
                                        mxArray * * method,
                                        mxArray * * h,
                                        int nargout_,
                                        mxArray * varargin);
static mxArray * Mimresize_DesignFilter(int nargout_,
                                        mxArray * N,
                                        mxArray * Wn);

static mexFunctionTableEntry local_function_table_[2]
  = { { "parse_inputs", mlxImresize_parse_inputs, -1, 4, NULL },
      { "DesignFilter", mlxImresize_DesignFilter, 2, 1, NULL } };

_mexLocalFunctionTable _local_function_table_imresize
  = { 2, local_function_table_ };

/*
 * The function "mlfNImresize" contains the nargout interface for the
 * "imresize" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 1-172). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNImresize(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimresize(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImresize" contains the normal interface for the "imresize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imresize.m" (lines
 * 1-172). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImresize(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimresize(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImresize" contains the void interface for the "imresize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imresize.m" (lines
 * 1-172). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImresize(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimresize(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImresize" contains the feval interface for the "imresize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imresize.m" (lines
 * 1-172). The feval function calls the implementation version of imresize
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImresize(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimresize(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImresize_parse_inputs" contains the normal interface for
 * the "imresize/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 172-252). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImresize_parse_inputs(mxArray * * m,
                                          mxArray * * method,
                                          mxArray * * h,
                                          ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * A = NULL;
    mxArray * m__ = NULL;
    mxArray * method__ = NULL;
    mxArray * h__ = NULL;
    mlfVarargin(&varargin, h, 0);
    mlfEnterNewContext(3, -1, m, method, h, varargin);
    if (m != NULL) {
        ++nargout;
    }
    if (method != NULL) {
        ++nargout;
    }
    if (h != NULL) {
        ++nargout;
    }
    A = Mimresize_parse_inputs(&m__, &method__, &h__, nargout, varargin);
    mlfRestorePreviousContext(3, 0, m, method, h);
    mxDestroyArray(varargin);
    if (m != NULL) {
        mclCopyOutputArg(m, m__);
    } else {
        mxDestroyArray(m__);
    }
    if (method != NULL) {
        mclCopyOutputArg(method, method__);
    } else {
        mxDestroyArray(method__);
    }
    if (h != NULL) {
        mclCopyOutputArg(h, h__);
    } else {
        mxDestroyArray(h__);
    }
    return mlfReturnValue(A);
}

/*
 * The function "mlxImresize_parse_inputs" contains the feval interface for the
 * "imresize/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 172-252). The feval
 * function calls the implementation version of imresize/parse_inputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImresize_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imresize/parse_inputs Line: 172 Co"
            "lumn: 1 The function \"imresize/parse_inputs\" was calle"
            "d with more than the declared number of outputs (4)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mimresize_parse_inputs(
          &mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImresize_DesignFilter" contains the normal interface for
 * the "imresize/DesignFilter" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 252-266). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImresize_DesignFilter(mxArray * N, mxArray * Wn) {
    int nargout = 1;
    mxArray * b = NULL;
    mlfEnterNewContext(0, 2, N, Wn);
    b = Mimresize_DesignFilter(nargout, N, Wn);
    mlfRestorePreviousContext(0, 2, N, Wn);
    return mlfReturnValue(b);
}

/*
 * The function "mlxImresize_DesignFilter" contains the feval interface for the
 * "imresize/DesignFilter" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 252-266). The feval
 * function calls the implementation version of imresize/DesignFilter through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImresize_DesignFilter(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imresize/DesignFilter Line: 252 Co"
            "lumn: 1 The function \"imresize/DesignFilter\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imresize/DesignFilter Line: 252 C"
            "olumn: 1 The function \"imresize/DesignFilter\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mimresize_DesignFilter(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mimresize" is the implementation version of the "imresize"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imresize.m" (lines
 * 1-172). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = imresize(varargin)
 */
static mxArray * Mimresize(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imresize);
    mxArray * varargout = NULL;
    mxArray * R = NULL;
    mxArray * T = NULL;
    mxArray * scale = NULL;
    mxArray * boxB = NULL;
    mxArray * boxA = NULL;
    mxArray * sc = NULL;
    mxArray * hh = NULL;
    mxArray * k = NULL;
    mxArray * drec = NULL;
    mxArray * custm_flt = NULL;
    mxArray * nonzero_odr = NULL;
    mxArray * defflt_reducedim = NULL;
    mxArray * bi_interp = NULL;
    mxArray * ans = NULL;
    mxArray * sn = NULL;
    mxArray * thirdD = NULL;
    mxArray * so = NULL;
    mxArray * logicalIn = NULL;
    mxArray * classChanged = NULL;
    mxArray * inputClass = NULL;
    mxArray * h = NULL;
    mxArray * method = NULL;
    mxArray * m = NULL;
    mxArray * A = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMRESIZE Resize image.
     * %   IMRESIZE resizes an image of any type using the specified
     * %   interpolation method. Supported interpolation methods
     * %   include:
     * %
     * %        'nearest'  (default) nearest neighbor interpolation
     * %
     * %        'bilinear' bilinear interpolation
     * %
     * %        'bicubic'  bicubic interpolation
     * %
     * %   B = IMRESIZE(A,M,METHOD) returns an image that is M times the
     * %   size of A. If M is between 0 and 1.0, B is smaller than A. If
     * %   M is greater than 1.0, B is larger than A. If METHOD is
     * %   omitted, IMRESIZE uses nearest neighbor interpolation.
     * %
     * %   B = IMRESIZE(A,[MROWS MCOLS],METHOD) returns an image of size
     * %   MROWS-by-MCOLS. If the specified size does not produce the
     * %   same aspect ratio as the input image has, the output image is
     * %   distorted.
     * %
     * %   When the specified output size is smaller than the size of
     * %   the input image, and METHOD is 'bilinear' or 'bicubic',
     * %   IMRESIZE applies a lowpass filter before interpolation to
     * %   reduce aliasing. The default filter size is 11-by-11.
     * %
     * %   You can specify a different order for the default filter
     * %   using:
     * %
     * %        [...] = IMRESIZE(...,METHOD,N)
     * %
     * %   N is an integer scalar specifying the size of the filter,
     * %   which is N-by-N. If N is 0, IMRESIZE omits the filtering
     * %   step.
     * %
     * %   You can also specify your own filter H using:
     * %
     * %        [...] = IMRESIZE(...,METHOD,H)
     * %
     * %   H is any two-dimensional FIR filter (such as those returned
     * %   by FTRANS2, FWIND1, FWIND2, or FSAMP2).
     * %
     * %   Class Support
     * %   -------------
     * %   The input image A can be numeric or logical and it must be 
     * %   nonsparse. The output image is of the same class as the 
     * %   input image.
     * %
     * %   See also IMROTATE, IMTRANSFORM, TFORMARRAY
     * 
     * %   Obsolete Syntaxes:
     * %
     * %   [R1,G1,B1] = IMRESIZE(R,G,B,M,'method') or 
     * %   [R1,G1,B1] = IMRESIZE(R,G,B,[MROWS NCOLS],'method') resizes
     * %   the RGB image in the matrices R,G,B.  'bilinear' is the
     * %   default interpolation method.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.30 $  $Date: 2002/03/28 21:32:58 $
     * 
     * [A,m,method,h] = parse_inputs(varargin{:});
     */
    mlfAssign(
      &A,
      mlfImresize_parse_inputs(
        &m,
        &method,
        &h,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * % Preserve classes
     * inputClass = class(A);
     */
    mlfAssign(&inputClass, mlfClassName(mclVv(A, "A"), NULL));
    /*
     * classChanged = 0;
     */
    mlfAssign(&classChanged, _mxarray0_);
    /*
     * logicalIn = islogical(A);
     */
    mlfAssign(&logicalIn, mlfIslogical(mclVv(A, "A")));
    /*
     * 
     * 
     * % Define old and new image sizes, and actual scaling
     * [so(1),so(2),thirdD] = size(A);% old image size
     */
    mlfSize(
      mlfIndexVarargout(
        &so, "(?)", _mxarray1_, &so, "(?)", _mxarray2_, &thirdD, "", NULL),
      mclVv(A, "A"),
      NULL);
    /*
     * if length(m)==1,% m is a multiplier
     */
    if (mclLengthInt(mclVv(m, "m")) == 1) {
        /*
         * sn = max(floor(m*so(1:2)),1);% new image size=(integer>0)
         */
        mlfAssign(
          &sn,
          mlfMax(
            NULL,
            mlfFloor(
              mclMtimes(
                mclVv(m, "m"),
                mclArrayRef1(
                  mclVv(so, "so"), mlfColon(_mxarray1_, _mxarray2_, NULL)))),
            _mxarray1_,
            NULL));
    /*
     * else            % m is new image size
     */
    } else {
        /*
         * sn = m;
         */
        mlfAssign(&sn, mclVv(m, "m"));
    /*
     * end
     */
    }
    /*
     * 
     * if any(sn<4) & any(sn<so) & method(1)~='n',
     */
    {
        mxArray * a_
          = mclInitialize(mlfAny(mclLt(mclVv(sn, "sn"), _mxarray11_), NULL));
        if (mlfTobool(a_)) {
            mlfAssign(
              &a_,
              mclAnd(
                a_, mlfAny(mclLt(mclVv(sn, "sn"), mclVv(so, "so")), NULL)));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclNe(
                     mclIntArrayRef1(mclVv(method, "method"), 1),
                     _mxarray3_)))) {
            mxDestroyArray(a_);
            /*
             * fprintf('Input is too small for bilinear or bicubic method;\n');
             */
            mclAssignAns(&ans, mlfNFprintf(0, _mxarray5_, NULL));
            /*
             * fprintf('using nearest-neighbor method instead.\n');
             */
            mclAssignAns(&ans, mlfNFprintf(0, _mxarray7_, NULL));
            /*
             * method = 'nearest';
             */
            mlfAssign(&method, _mxarray9_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Filtering is under the following conditions
     * bi_interp = (method(1)=='b'); % non-default interpolation only
     */
    mlfAssign(
      &bi_interp,
      mclEq(mclIntArrayRef1(mclVv(method, "method"), 1), _mxarray12_));
    /*
     * defflt_reducedim=(length(h)<2)&any(sn<so);%default filter & reduced image
     */
    mlfAssign(
      &defflt_reducedim,
      mclAnd(
        mclBoolToArray(mclLengthInt(mclVv(h, "h")) < 2),
        mlfAny(mclLt(mclVv(sn, "sn"), mclVv(so, "so")), NULL)));
    /*
     * if length(h)==1,
     */
    if (mclLengthInt(mclVv(h, "h")) == 1) {
        /*
         * nonzero_odr = (h~=0);     % non-zero filter order
         */
        mlfAssign(&nonzero_odr, mclNe(mclVv(h, "h"), _mxarray0_));
    /*
     * else 
     */
    } else {
        /*
         * nonzero_odr = 1;
         */
        mlfAssign(&nonzero_odr, _mxarray1_);
    /*
     * end;
     */
    }
    /*
     * custm_flt = (length(h)>1);%custom supplied filter H
     */
    mlfAssign(&custm_flt, mclBoolToArray(mclLengthInt(mclVv(h, "h")) > 1));
    /*
     * 
     * if bi_interp&nonzero_odr&any([defflt_reducedim,custm_flt]),
     */
    {
        mxArray * a_ = mclInitialize(mclVv(bi_interp, "bi_interp"));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mclAnd(a_, mclVv(nonzero_odr, "nonzero_odr")));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mlfAny(
                     mlfHorzcat(
                       mclVv(defflt_reducedim, "defflt_reducedim"),
                       mclVv(custm_flt, "custm_flt"),
                       NULL),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * if (~isa(A,'double')),%change format to double to perform imfilter
             */
            if (mclNotBool(mlfIsa(mclVv(A, "A"), _mxarray14_))) {
                /*
                 * A = im2double(A);
                 */
                mlfAssign(&A, mlfIm2double(mclVv(A, "A"), NULL));
                /*
                 * classChanged = 1;
                 */
                mlfAssign(&classChanged, _mxarray1_);
            /*
             * end
             */
            }
            /*
             * 
             * if defflt_reducedim,%Design anti-aliasing filter for reduced image
             */
            if (mlfTobool(mclVv(defflt_reducedim, "defflt_reducedim"))) {
                /*
                 * drec = find(sn<so);% find direction of filtering
                 */
                mlfAssign(
                  &drec,
                  mlfFind(NULL, NULL, mclLt(mclVv(sn, "sn"), mclVv(so, "so"))));
                /*
                 * for k = drec,% create filter for drec-direction
                 */
                {
                    mclForLoopIterator viter__;
                    for (mclForStart(&viter__, mclVv(drec, "drec"), NULL, NULL);
                         mclForNext(&viter__, &k);
                         ) {
                        /*
                         * if isempty(h),% make filter order corresponding to scale
                         */
                        if (mlfTobool(mlfIsempty(mclVv(h, "h")))) {
                            /*
                             * h = 11;
                             */
                            mlfAssign(&h, _mxarray16_);
                        /*
                         * end;
                         */
                        }
                        /*
                         * hh(k,:) = DesignFilter(h,sn(k)/so(k));
                         */
                        mclArrayAssign2(
                          &hh,
                          mlfImresize_DesignFilter(
                            mclVv(h, "h"),
                            mclMrdivide(
                              mclArrayRef1(mclVv(sn, "sn"), mclVv(k, "k")),
                              mclArrayRef1(mclVv(so, "so"), mclVv(k, "k")))),
                          mclVv(k, "k"),
                          mlfCreateColonIndex());
                    /*
                     * end;
                     */
                    }
                    mclDestroyForLoopIterator(viter__);
                }
                /*
                 * if length(drec)==1,%filters in one direction only
                 */
                if (mclLengthInt(mclVv(drec, "drec")) == 1) {
                    /*
                     * % first direction is column, second is row
                     * h = reshape(hh(k,:),(h-1)*(k==1)+1,(h-1)*(k==2)+1);
                     */
                    mlfAssign(
                      &h,
                      mlfReshape(
                        mclArrayRef2(
                          mclVv(hh, "hh"),
                          mclVv(k, "k"),
                          mlfCreateColonIndex()),
                        mclPlus(
                          mclMtimes(
                            mclMinus(mclVv(h, "h"), _mxarray1_),
                            mclEq(mclVv(k, "k"), _mxarray1_)),
                          _mxarray1_),
                        mclPlus(
                          mclMtimes(
                            mclMinus(mclVv(h, "h"), _mxarray1_),
                            mclEq(mclVv(k, "k"), _mxarray2_)),
                          _mxarray1_),
                        NULL));
                /*
                 * else % filters in both directions
                 */
                } else {
                    /*
                     * for k=1:thirdD,%loop if A matrix is 3D
                     */
                    int v_ = mclForIntStart(1);
                    int e_ = mclForIntEnd(mclVv(thirdD, "thirdD"));
                    if (v_ > e_) {
                        mlfAssign(&k, _mxarray17_);
                    } else {
                        /*
                         * A(:,:,k) = imfilter(imfilter(A(:,:,k), hh(2,:)),hh(1,:).');
                         * end
                         */
                        for (; ; ) {
                            mlfIndexAssign(
                              &A,
                              "(?,?,?)",
                              mlfCreateColonIndex(),
                              mlfCreateColonIndex(),
                              mlfScalar(v_),
                              mlfImfilter(
                                mlfImfilter(
                                  mlfIndexRef(
                                    mclVv(A, "A"),
                                    "(?,?,?)",
                                    mlfCreateColonIndex(),
                                    mlfCreateColonIndex(),
                                    mlfScalar(v_)),
                                  mclArrayRef2(
                                    mclVv(hh, "hh"),
                                    _mxarray2_,
                                    mlfCreateColonIndex()),
                                  NULL),
                                mlfTranspose(
                                  mclArrayRef2(
                                    mclVv(hh, "hh"),
                                    _mxarray1_,
                                    mlfCreateColonIndex())),
                                NULL));
                            if (v_ == e_) {
                                break;
                            }
                            ++v_;
                        }
                        mlfAssign(&k, mlfScalar(v_));
                    }
                /*
                 * end;
                 */
                }
            /*
             * end;
             */
            }
            /*
             * if custm_flt|(defflt_reducedim&(length(drec)==1)),%filters in one direction
             */
            {
                mxArray * a_0 = mclInitialize(mclVv(custm_flt, "custm_flt"));
                if (mlfTobool(a_0)) {
                } else {
                    mxArray * b_
                      = mclInitialize(
                          mclVv(defflt_reducedim, "defflt_reducedim"));
                    if (mlfTobool(b_)) {
                        mlfAssign(
                          &b_,
                          mclAnd(
                            b_,
                            mclBoolToArray(
                              mclLengthInt(mclVv(drec, "drec")) == 1)));
                    } else {
                        mlfAssign(&b_, mlfScalar(0));
                    }
                    {
                        mxLogical c_0 = mlfTobool(mclOr(a_0, b_));
                        mxDestroyArray(b_);
                        if (c_0) {
                        } else {
                            mxDestroyArray(a_0);
                            goto done_;
                        }
                    }
                }
                mxDestroyArray(a_0);
                /*
                 * for k=1:thirdD,%loop if A matrix is 3D
                 */
                {
                    int v_ = mclForIntStart(1);
                    int e_ = mclForIntEnd(mclVv(thirdD, "thirdD"));
                    if (v_ > e_) {
                        mlfAssign(&k, _mxarray17_);
                    } else {
                        /*
                         * A(:,:,k) = imfilter(A(:,:,k),h);
                         * end
                         */
                        for (; ; ) {
                            mlfIndexAssign(
                              &A,
                              "(?,?,?)",
                              mlfCreateColonIndex(),
                              mlfCreateColonIndex(),
                              mlfScalar(v_),
                              mlfImfilter(
                                mlfIndexRef(
                                  mclVv(A, "A"),
                                  "(?,?,?)",
                                  mlfCreateColonIndex(),
                                  mlfCreateColonIndex(),
                                  mlfScalar(v_)),
                                mclVv(h, "h"),
                                NULL));
                            if (v_ == e_) {
                                break;
                            }
                            ++v_;
                        }
                        mlfAssign(&k, mlfScalar(v_));
                    }
                }
                /*
                 * end;
                 */
                done_:;
            }
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end;
     */
    }
    /*
     * 
     * % Interpolation
     * if method(1)=='n', % nearest neighbor (default)
     */
    if (mclEqBool(mclIntArrayRef1(mclVv(method, "method"), 1), _mxarray3_)) {
        /*
         * sc = so./sn + eps;% actual scaling between images, eps is needed
         */
        mlfAssign(
          &sc,
          mclPlus(mclRdivide(mclVv(so, "so"), mclVv(sn, "sn")), _mxarray18_));
        /*
         * A = A(floor(sc(1)/2:sc(1):end)+1,floor(sc(2)/2:sc(2):end)+1,:);
         */
        mlfAssign(
          &A,
          mlfIndexRef(
            mclVv(A, "A"),
            "(?,?,?)",
            mclPlus(
              mlfFloor(
                mlfColon(
                  mclMrdivide(mclIntArrayRef1(mclVv(sc, "sc"), 1), _mxarray2_),
                  mclIntArrayRef1(mclVv(sc, "sc"), 1),
                  mlfEnd(mclVv(A, "A"), _mxarray1_, _mxarray19_))),
              _mxarray1_),
            mclPlus(
              mlfFloor(
                mlfColon(
                  mclMrdivide(mclIntArrayRef1(mclVv(sc, "sc"), 2), _mxarray2_),
                  mclIntArrayRef1(mclVv(sc, "sc"), 2),
                  mlfEnd(mclVv(A, "A"), _mxarray2_, _mxarray19_))),
              _mxarray1_),
            mlfCreateColonIndex()));
    /*
     * else               % bilinear or bicubic
     */
    } else {
        /*
         * sc = (so-1)./(sn-1);% scaling for tformarray
         */
        mlfAssign(
          &sc,
          mclRdivide(
            mclMinus(mclVv(so, "so"), _mxarray1_),
            mclMinus(mclVv(sn, "sn"), _mxarray1_)));
        /*
         * boxA  = maketform('box',so,[0 0],so-1);
         */
        mlfAssign(
          &boxA,
          mlfMaketform(
            _mxarray20_,
            mclVv(so, "so"),
            _mxarray22_,
            mclMinus(mclVv(so, "so"), _mxarray1_),
            NULL));
        /*
         * boxB  = maketform('box',sn,[0 0],sn-1);
         */
        mlfAssign(
          &boxB,
          mlfMaketform(
            _mxarray20_,
            mclVv(sn, "sn"),
            _mxarray22_,
            mclMinus(mclVv(sn, "sn"), _mxarray1_),
            NULL));
        /*
         * scale = maketform('affine',diag(1./[sc 1]));
         */
        mlfAssign(
          &scale,
          mlfMaketform(
            _mxarray24_,
            mlfDiag(
              mclRdivide(
                _mxarray1_, mlfHorzcat(mclVv(sc, "sc"), _mxarray1_, NULL)),
              NULL),
            NULL));
        /*
         * 
         * T = maketform('composite',[fliptform(boxB),scale,boxA]);
         */
        mlfAssign(
          &T,
          mlfMaketform(
            _mxarray26_,
            mlfHorzcat(
              mlfFliptform(mclVv(boxB, "boxB")),
              mclVv(scale, "scale"),
              mclVv(boxA, "boxA"),
              NULL),
            NULL));
        /*
         * 
         * if strcmp(method,'bicubic')
         */
        if (mlfTobool(mlfStrcmp(mclVv(method, "method"), _mxarray28_))) {
            /*
             * R = makeresampler('cubic','replicate');
             */
            mlfAssign(&R, mlfMakeresampler(_mxarray30_, _mxarray32_, NULL));
        /*
         * else
         */
        } else {
            /*
             * R = makeresampler('linear','replicate');    
             */
            mlfAssign(&R, mlfMakeresampler(_mxarray34_, _mxarray32_, NULL));
        /*
         * end
         */
        }
        /*
         * 
         * A = tformarray(A, T, R, [1 2], [1 2], sn, [], []);
         */
        mlfAssign(
          &A,
          mlfTformarray(
            mclVv(A, "A"),
            mclVv(T, "T"),
            mclVv(R, "R"),
            _mxarray36_,
            _mxarray36_,
            mclVv(sn, "sn"),
            _mxarray17_,
            _mxarray17_));
    /*
     * end;
     */
    }
    /*
     * 
     * % Change format from double back to the original
     * if logicalIn,  % output should be logical (i.e. binary image)
     */
    if (mlfTobool(mclVv(logicalIn, "logicalIn"))) {
        /*
         * if ~islogical(A) % A became double because of imfilter, turn it back to logical
         */
        if (mclNotBool(mlfIslogical(mclVv(A, "A")))) {
            /*
             * A = A>.5;
             */
            mlfAssign(&A, mclGt(mclVv(A, "A"), _mxarray38_));
        /*
         * end
         */
        }
    /*
     * elseif classChanged,
     */
    } else if (mlfTobool(mclVv(classChanged, "classChanged"))) {
        /*
         * A = changeclass(inputClass, A);
         */
        mlfAssign(
          &A,
          mlfImages_private_changeclass(
            mclVv(inputClass, "inputClass"), mclVv(A, "A"), NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % Output
     * if (nargout == 0)
     */
    if (nargout_ == 0) {
        /*
         * imshow(A);
         */
        mclAssignAns(&ans, mlfNImshow(0, mclVv(A, "A"), NULL));
    /*
     * elseif ((ndims(A)==3) & (nargout == 3))
     */
    } else {
        mxArray * a_
          = mclInitialize(mclEq(mlfNdims(mclVv(A, "A")), _mxarray19_));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mclBoolToArray(nargout_ == 3)))) {
            mxDestroyArray(a_);
            /*
             * warning(['[R1,G1,B1] = IMRESIZE(R,G,B,...) is an obsolete syntax. ',...
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray39_, NULL));
            /*
             * 'Use a three-dimensional array to represent input and output RGB images.']);
             * varargout{1} = A(:,:,1);
             */
            mlfIndexAssign(
              &varargout,
              "{?}",
              _mxarray1_,
              mlfIndexRef(
                mclVv(A, "A"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray1_));
            /*
             * varargout{2} = A(:,:,2);
             */
            mlfIndexAssign(
              &varargout,
              "{?}",
              _mxarray2_,
              mlfIndexRef(
                mclVv(A, "A"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray2_));
            /*
             * varargout{3} = A(:,:,3);
             */
            mlfIndexAssign(
              &varargout,
              "{?}",
              _mxarray19_,
              mlfIndexRef(
                mclVv(A, "A"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray19_));
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * varargout{1} = A;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray1_, mclVv(A, "A"));
        }
    /*
     * end
     */
    }
    mxDestroyArray(A);
    mxDestroyArray(m);
    mxDestroyArray(method);
    mxDestroyArray(h);
    mxDestroyArray(inputClass);
    mxDestroyArray(classChanged);
    mxDestroyArray(logicalIn);
    mxDestroyArray(so);
    mxDestroyArray(thirdD);
    mxDestroyArray(sn);
    mxDestroyArray(ans);
    mxDestroyArray(bi_interp);
    mxDestroyArray(defflt_reducedim);
    mxDestroyArray(nonzero_odr);
    mxDestroyArray(custm_flt);
    mxDestroyArray(drec);
    mxDestroyArray(k);
    mxDestroyArray(hh);
    mxDestroyArray(sc);
    mxDestroyArray(boxA);
    mxDestroyArray(boxB);
    mxDestroyArray(scale);
    mxDestroyArray(T);
    mxDestroyArray(R);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %
     * %  Function: parse_inputs
     * %
     * 
     */
}

/*
 * The function "Mimresize_parse_inputs" is the implementation version of the
 * "imresize/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 172-252). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [A,m,method,h] = parse_inputs(varargin)
 */
static mxArray * Mimresize_parse_inputs(mxArray * * m,
                                        mxArray * * method,
                                        mxArray * * h,
                                        int nargout_,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imresize);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * A = NULL;
    mxArray * idx = NULL;
    mxArray * strings = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * % Outputs:  A       the input image
     * %           m       the resize scaling factor or the new size
     * %           method  interpolation method (nearest,bilinear,bicubic)
     * %           h       if 0, skip filtering; if non-zero scalar, use filter 
     * %                   of size h; if empty, use filter of size 11; 
     * %                   otherwise h is the anti-aliasing filter provided by user
     * % Defaults:
     * method = 'nearest';
     */
    mlfAssign(method, _mxarray9_);
    /*
     * h = [];
     */
    mlfAssign(h, _mxarray17_);
    /*
     * 
     * error(nargchk(2,6,nargin));
     */
    mlfError(mlfNargchk(_mxarray2_, _mxarray41_, mlfScalar(nargin_)), NULL);
    /*
     * switch nargin
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * case 2,                   % imresize(A,m)
             * A = varargin{1};
             */
            mlfAssign(
              &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * m = varargin{2};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_));
        /*
         * case 3,                   % imresize(A,m,method)
         */
        } else if (mclSwitchCompare(v_, _mxarray19_)) {
            /*
             * A = varargin{1};
             */
            mlfAssign(
              &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * m = varargin{2};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_));
            /*
             * method = varargin{3};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_));
        /*
         * case 4,
         */
        } else if (mclSwitchCompare(v_, _mxarray11_)) {
            /*
             * if isstr(varargin{3}), % imresize(A,m,method,h)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIsstr,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                    NULL))) {
                /*
                 * A = varargin{1};
                 */
                mlfAssign(
                  &A,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
                /*
                 * m = varargin{2};
                 */
                mlfAssign(
                  m,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_));
                /*
                 * method = varargin{3};
                 */
                mlfAssign(
                  method,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_));
                /*
                 * h = varargin{4};
                 */
                mlfAssign(
                  h,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray11_));
            /*
             * else                   % imresize(r,g,b,m) OBSOLETE
             */
            } else {
                /*
                 * warning(['IMRESIZE(R,G,B,M) is an obsolete syntax.',...
                 */
                mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray42_, NULL));
                /*
                 * 'Use a three-dimensional array to represent RGB image.']);
                 * A = cat(3,varargin{1},varargin{2},varargin{3});
                 */
                mlfAssign(
                  &A,
                  mlfCat(
                    _mxarray19_,
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                    mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_),
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                    NULL));
                /*
                 * m = varargin{4};
                 */
                mlfAssign(
                  m,
                  mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray11_));
            /*
             * end
             */
            }
        /*
         * case 5,                   % imresize(r,g,b,m,'method')  OBSOLETE
         */
        } else if (mclSwitchCompare(v_, _mxarray44_)) {
            /*
             * warning(['IMRESIZE(R,G,B,M,''method'') is an obsolete syntax. ',...
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray45_, NULL));
            /*
             * 'Use a three-dimensional array to represent RGB image.']);
             * A = cat(3,varargin{1},varargin{2},varargin{3});
             */
            mlfAssign(
              &A,
              mlfCat(
                _mxarray19_,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                NULL));
            /*
             * m = varargin{4};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray11_));
            /*
             * method = varargin{5};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray44_));
        /*
         * case 6,                   % imresize(r,g,b,m,'method',h)  OBSOLETE
         */
        } else if (mclSwitchCompare(v_, _mxarray41_)) {
            /*
             * warning(['IMRESIZE(R,G,B,M,''method'',H) is an obsolete syntax.',...
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray47_, NULL));
            /*
             * 'Use a three-dimensional array to represent RGB image.']);
             * A = cat(3,varargin{1},varargin{2},varargin{3});
             */
            mlfAssign(
              &A,
              mlfCat(
                _mxarray19_,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_),
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray19_),
                NULL));
            /*
             * m = varargin{4};
             */
            mlfAssign(
              m, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray11_));
            /*
             * method = varargin{5};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray44_));
            /*
             * h = varargin{6};
             */
            mlfAssign(
              h, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray41_));
        /*
         * otherwise,
         */
        } else {
            /*
             * error('Invalid input arguments.');
             */
            mlfError(_mxarray49_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * checkinput(A,{'numeric', 'logical'},{'nonsparse'},mfilename,'A',1);
     */
    mlfImages_private_checkinput(
      mclVv(A, "A"),
      _mxarray51_,
      _mxarray57_,
      mxCreateString("imresize"),
      _mxarray60_,
      _mxarray1_);
    /*
     * 
     * % Check validity of the input parameters 
     * if (length(m)==0)|(ndims(m)>2)|any(m<=0)|length(m(:))>2,
     */
    {
        mxArray * a_
          = mclInitialize(mclBoolToArray(mclLengthInt(mclVv(*m, "m")) == 0));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_, mclOr(a_, mclGt(mlfNdims(mclVv(*m, "m")), _mxarray2_)));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(
              &a_, mclOr(a_, mlfAny(mclLe(mclVv(*m, "m"), _mxarray0_), NULL)));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclBoolToArray(
                     mclLengthInt(
                       mclArrayRef1(mclVv(*m, "m"), mlfCreateColonIndex()))
                     > 2)))) {
            mxDestroyArray(a_);
            /*
             * error('M must be either a scalar multiplier or a 1-by-2 size vector.');
             */
            mlfError(_mxarray62_, NULL);
        /*
         * elseif length(m)==2,% make sure that m is a row of non-negative integers
         */
        } else {
            mxDestroyArray(a_);
            if (mclLengthInt(mclVv(*m, "m")) == 2) {
                /*
                 * m = ceil(m(:).');
                 */
                mlfAssign(
                  m,
                  mlfCeil(
                    mlfTranspose(
                      mclArrayRef1(mclVv(*m, "m"), mlfCreateColonIndex()))));
            }
        }
    /*
     * end;
     */
    }
    /*
     * 
     * if ischar(method),
     */
    if (mlfTobool(mlfIschar(mclVv(*method, "method")))) {
        /*
         * strings = {'nearest','bilinear','bicubic'};
         */
        mlfAssign(&strings, _mxarray64_);
        /*
         * idx = strmatch(lower(method),strings);
         */
        mlfAssign(
          &idx,
          mlfStrmatch(
            mlfLower(mclVv(*method, "method")),
            mclVv(strings, "strings"),
            NULL));
        /*
         * if isempty(idx),
         */
        if (mlfTobool(mlfIsempty(mclVv(idx, "idx")))) {
            /*
             * error(sprintf('Unknown interpolation method: %s',method));
             */
            mlfError(
              mlfSprintf(NULL, _mxarray68_, mclVv(*method, "method"), NULL),
              NULL);
        /*
         * elseif length(idx)>1,
         */
        } else if (mclLengthInt(mclVv(idx, "idx")) > 1) {
            /*
             * error(sprintf('Ambiguous interpolation method: %s',method));
             */
            mlfError(
              mlfSprintf(NULL, _mxarray70_, mclVv(*method, "method"), NULL),
              NULL);
        /*
         * else
         */
        } else {
            /*
             * method = strings{idx};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVv(strings, "strings"), "{?}", mclVv(idx, "idx")));
        /*
         * end  
         */
        }
    /*
     * else
     */
    } else {
        /*
         * error(sprintf('Interpolation method has to be a string.'));  
         */
        mlfError(mlfSprintf(NULL, _mxarray72_, NULL), NULL);
    /*
     * end;
     */
    }
    /*
     * 
     * if length(h)==1,% represents filter order
     */
    if (mclLengthInt(mclVv(*h, "h")) == 1) {
        /*
         * if (h<0)|(h~=round(h)),
         */
        mxArray * a_ = mclInitialize(mclLt(mclVv(*h, "h"), _mxarray0_));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(a_, mclNe(mclVv(*h, "h"), mlfRound(mclVv(*h, "h")))))) {
            mxDestroyArray(a_);
            /*
             * error(sprintf('Filter order has to be a non-negative integer, not %g',h));
             */
            mlfError(mlfSprintf(NULL, _mxarray74_, mclVv(*h, "h"), NULL), NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end;
     * elseif (length(h)>1)&(ndims(h)>2),% custom supplied filter
     */
    } else {
        mxArray * a_
          = mclInitialize(mclBoolToArray(mclLengthInt(mclVv(*h, "h")) > 1));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(a_, mclGt(mlfNdims(mclVv(*h, "h")), _mxarray2_)))) {
            mxDestroyArray(a_);
            /*
             * error('Filter has to be a 2-D array.');
             */
            mlfError(_mxarray76_, NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(A, 1, nargout_, "A", "imresize/parse_inputs");
    mclValidateOutput(*m, 2, nargout_, "m", "imresize/parse_inputs");
    mclValidateOutput(*method, 3, nargout_, "method", "imresize/parse_inputs");
    mclValidateOutput(*h, 4, nargout_, "h", "imresize/parse_inputs");
    mxDestroyArray(ans);
    mxDestroyArray(strings);
    mxDestroyArray(idx);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
    /*
     * 
     */
}

/*
 * The function "Mimresize_DesignFilter" is the implementation version of the
 * "imresize/DesignFilter" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imresize.m" (lines 252-266). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function b = DesignFilter(N,Wn)
 */
static mxArray * Mimresize_DesignFilter(int nargout_,
                                        mxArray * N,
                                        mxArray * Wn) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imresize);
    mxArray * b = NULL;
    mxArray * wind = NULL;
    mxArray * vec2 = NULL;
    mxArray * vec = NULL;
    mxArray * odd = NULL;
    mclCopyArray(&N);
    mclCopyArray(&Wn);
    /*
     * % Modified from SPT v3 fir1.m and hanning.m
     * % first creates only first half of the filter 
     * % and later mirrows it to the other half
     * 
     * odd = rem(N,2);
     */
    mlfAssign(&odd, mlfRem(mclVa(N, "N"), _mxarray2_));
    /*
     * vec = [1:floor(N/2)];
     */
    mlfAssign(
      &vec,
      mlfColon(
        _mxarray1_, mlfFloor(mclMrdivide(mclVa(N, "N"), _mxarray2_)), NULL));
    /*
     * vec2 = pi*(vec-(1-odd)/2);
     */
    mlfAssign(
      &vec2,
      mclMtimes(
        _mxarray78_,
        mclMinus(
          mclVv(vec, "vec"),
          mclMrdivide(mclMinus(_mxarray1_, mclVv(odd, "odd")), _mxarray2_))));
    /*
     * 
     * wind = .54-.46*cos(2*pi*(vec-1)/(N-1));
     */
    mlfAssign(
      &wind,
      mclMinus(
        _mxarray79_,
        mclMtimes(
          _mxarray80_,
          mlfCos(
            mclMrdivide(
              mclMtimes(_mxarray81_, mclMinus(mclVv(vec, "vec"), _mxarray1_)),
              mclMinus(mclVa(N, "N"), _mxarray1_))))));
    /*
     * b = [fliplr(sin(Wn*vec2)./vec2).*wind Wn];% first half is ready
     */
    mlfAssign(
      &b,
      mlfHorzcat(
        mclTimes(
          mlfFliplr(
            mclRdivide(
              mlfSin(mclMtimes(mclVa(Wn, "Wn"), mclVv(vec2, "vec2"))),
              mclVv(vec2, "vec2"))),
          mclVv(wind, "wind")),
        mclVa(Wn, "Wn"),
        NULL));
    /*
     * b = b([vec floor(N/2)+[1:odd] fliplr(vec)]);% entire filter
     */
    mlfAssign(
      &b,
      mclArrayRef1(
        mclVv(b, "b"),
        mlfHorzcat(
          mclVv(vec, "vec"),
          mclPlus(
            mlfFloor(mclMrdivide(mclVa(N, "N"), _mxarray2_)),
            mlfColon(_mxarray1_, mclVv(odd, "odd"), NULL)),
          mlfFliplr(mclVv(vec, "vec")),
          NULL)));
    /*
     * b = b/abs(polyval(b,1));% norm
     */
    mlfAssign(
      &b,
      mclMrdivide(
        mclVv(b, "b"),
        mlfAbs(mlfNPolyval(1, NULL, mclVv(b, "b"), _mxarray1_, NULL, NULL))));
    mclValidateOutput(b, 1, nargout_, "b", "imresize/DesignFilter");
    mxDestroyArray(odd);
    mxDestroyArray(vec);
    mxDestroyArray(vec2);
    mxDestroyArray(wind);
    mxDestroyArray(Wn);
    mxDestroyArray(N);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     */
}
