/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:05 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "watermark005.h"
#include "libsgl.h"
#include "dither.h"
#include "fspecial.h"
#include "gui_mainfcn.h"
#include "guidata.h"
#include "im2double.h"
#include "imageextractinfo.h"
#include "imageinfo.h"
#include "imagewatermarkinfo.h"
#include "imcrop.h"
#include "imfilter.h"
#include "imread.h"
#include "imresize.h"
#include "imrotate.h"
#include "imshow.h"
#include "iptsetpref.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "libmwsglm.h"
#include "normxcorr2.h"
#include "randint.h"
#include "rgb2gray.h"
#include "subplot.h"
#include "title.h"
#include "waitbar.h"
static mxArray * _mxarray0_;

static mxChar _array2_[8] = { 'g', 'u', 'i', '_', 'N', 'a', 'm', 'e' };
static mxArray * _mxarray1_;

static mxChar _array4_[13] = { 'g', 'u', 'i', '_', 'S', 'i', 'n',
                               'g', 'l', 'e', 't', 'o', 'n' };
static mxArray * _mxarray3_;

static mxChar _array6_[14] = { 'g', 'u', 'i', '_', 'O', 'p', 'e',
                               'n', 'i', 'n', 'g', 'F', 'c', 'n' };
static mxArray * _mxarray5_;

static mxChar _array8_[13] = { 'g', 'u', 'i', '_', 'O', 'u', 't',
                               'p', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray7_;

static mxChar _array10_[13] = { 'g', 'u', 'i', '_', 'L', 'a', 'y',
                                'o', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[12] = { 'g', 'u', 'i', '_', 'C', 'a',
                                'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray12_;
static mxArray * _mxarray14_;

static mxChar _array16_[7] = { 'd', 'e', 'f', 'a', 'u', 'l', 't' };
static mxArray * _mxarray15_;

static mxChar _array20_[5] = { '*', '.', 'b', 'm', 'p' };
static mxArray * _mxarray19_;

static mxChar _array22_[12] = { '*', '.', 'j', 'p', 'g', ';',
                                '*', '.', 'j', 'p', 'e', 'g' };
static mxArray * _mxarray21_;

static mxChar _array24_[13] = { 'B', 'i', 't', 'm', 'a', 'p', '(',
                                '*', '.', 'b', 'm', 'p', ')' };
static mxArray * _mxarray23_;

static mxChar _array26_[18] = { 'J', 'P', 'E', 'G', '(', '*', '.', 'j', 'p',
                                'g', ',', '*', '.', 'j', 'p', 'e', 'g', ')' };
static mxArray * _mxarray25_;

static mxArray * _array18_[4] = { NULL /*_mxarray19_*/, NULL /*_mxarray21_*/,
                                  NULL /*_mxarray23_*/, NULL /*_mxarray25_*/ };
static mxArray * _mxarray17_;

static mxChar _array28_[13] = { 'C', 'h', 'o', 'o', 's', 'e', ' ',
                                'a', ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray27_;

static mxChar _array30_[41] = { 'S', 't', 'a', 't', 'u', 's', '>', '>', 'F',
                                'i', 'l', 'e', ' ', 'n', 'o', 't', ' ', 'O',
                                'p', 'e', 'n', '.', '.', '.', 'P', 'l', 'e',
                                'a', 's', 'e', ' ', 't', 'r', 'y', ' ', 'a',
                                'g', 'a', 'i', 'n', '.' };
static mxArray * _mxarray29_;

static mxChar _array32_[13] = { 'S', 't', 'a', 't', 'u', 's', '>',
                                '>', 'F', 'i', 'l', 'e', ' ' };
static mxArray * _mxarray31_;

static mxChar _array34_[21] = { ' ', 'h', 'a', 'v', 'e', ' ', 'a',
                                'l', 'r', 'e', 'a', 'd', 'y', ' ',
                                'o', 'p', 'e', 'n', 'n', 'e', 'd' };
static mxArray * _mxarray33_;

static mxChar _array36_[8] = { 'P', 'o', 's', 'i', 't', 'i', 'o', 'n' };
static mxArray * _mxarray35_;

static double _array38_[4] = { .03, .55, .3, .3 };
static mxArray * _mxarray37_;

static mxChar _array40_[12] = { 'I', 'm', 's', 'h', 'o', 'w',
                                'B', 'o', 'r', 'd', 'e', 'r' };
static mxArray * _mxarray39_;

static mxChar _array42_[5] = { 't', 'i', 'g', 'h', 't' };
static mxArray * _mxarray41_;

static mxChar _array44_[3] = { 't', 'a', 'g' };
static mxArray * _mxarray43_;

static mxChar _array46_[22] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                'o', 'n', 'A', 'd', 'd', 'W', 'a', 't',
                                'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray45_;

static mxChar _array48_[6] = { 'E', 'n', 'a', 'b', 'l', 'e' };
static mxArray * _mxarray47_;

static mxChar _array50_[2] = { 'o', 'n' };
static mxArray * _mxarray49_;

static mxChar _array52_[21] = { 'p', 'o', 'p', 'u', 'p', 'm', 'e',
                                'n', 'u', 'B', 'l', 'o', 'c', 'k',
                                'S', 'i', 'z', 'e', 'A', 'd', 'd' };
static mxArray * _mxarray51_;

static mxChar _array54_[17] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                'n', 'E', 'x', 't', 'r', 'a', 'c', 't' };
static mxArray * _mxarray53_;

static mxChar _array56_[21] = { 'p', 'o', 'p', 'u', 'p', 'm', 'e',
                                'n', 'u', 'A', 't', 't', 'a', 'c',
                                'k', 'M', 'e', 't', 'h', 'o', 'd' };
static mxArray * _mxarray55_;

static mxChar _array58_[21] = { 'p', 'o', 'p', 'u', 'p', 'm', 'e',
                                'n', 'u', 'B', 'l', 'o', 'c', 'k',
                                'S', 'i', 'z', 'e', 'E', 'x', 't' };
static mxArray * _mxarray57_;

static mxChar _array60_[23] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                'o', 'n', 'O', 'r', 'i', 'g', 'i', 'n',
                                'a', 'l', '_', 'i', 'n', 'f', 'o' };
static mxArray * _mxarray59_;

static mxChar _array62_[26] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                'n', 'S', 'h', 'o', 'w', 'R', 'e', 'a', 'l',
                                'O', 'r', 'i', 'g', 'i', 'n', 'a', 'l' };
static mxArray * _mxarray61_;

static mxChar _array64_[21] = { 'S', 't', 'a', 't', 'u', 's', '>',
                                '>', 'F', 'i', 'l', 'e', ' ', 'n',
                                'o', 't', ' ', 'O', 'p', 'e', 'n' };
static mxArray * _mxarray63_;

static double _array66_[4] = { .35, .55, .3, .3 };
static mxArray * _mxarray65_;

static mxChar _array68_[3] = { 'o', 'f', 'f' };
static mxArray * _mxarray67_;

static mxChar _array70_[24] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                'o', 'n', 'W', 'a', 't', 'e', 'r', 'm',
                                'a', 'r', 'k', '_', 'i', 'n', 'f', 'o' };
static mxArray * _mxarray69_;

static mxChar _array72_[27] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                'n', 'S', 'h', 'o', 'w', 'R', 'e', 'a', 'l',
                                'W', 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray71_;

static mxChar _array74_[15] = { 'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray73_;

static mxChar _array76_[5] = { 'w', 'h', 'i', 't', 'e' };
static mxArray * _mxarray75_;

static mxChar _array78_[31] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', 'U',
                                'i', 'c', 'o', 'n', 't', 'r', 'o', 'l',
                                'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray77_;

static mxChar _array80_[5] = { 'V', 'a', 'l', 'u', 'e' };
static mxArray * _mxarray79_;

static mxChar _array82_[6] = { 'S', 't', 'r', 'i', 'n', 'g' };
static mxArray * _mxarray81_;

static mxChar _array84_[1] = { '1' };
static mxArray * _mxarray83_;
static mxArray * _mxarray85_;

static mxChar _array87_[1] = { '2' };
static mxArray * _mxarray86_;
static mxArray * _mxarray88_;
static mxArray * _mxarray89_;

static mxChar _array91_[1] = { '4' };
static mxArray * _mxarray90_;
static mxArray * _mxarray92_;

static mxChar _array94_[1] = { '8' };
static mxArray * _mxarray93_;
static mxArray * _mxarray95_;
static mxArray * _mxarray96_;

static mxChar _array98_[2] = { '1', '6' };
static mxArray * _mxarray97_;
static mxArray * _mxarray99_;
static mxArray * _mxarray100_;

static mxChar _array102_[2] = { '3', '2' };
static mxArray * _mxarray101_;
static mxArray * _mxarray103_;
static mxArray * _mxarray104_;

static mxChar _array106_[2] = { '6', '4' };
static mxArray * _mxarray105_;
static mxArray * _mxarray107_;

static mxChar _array109_[3] = { '1', '2', '8' };
static mxArray * _mxarray108_;
static mxArray * _mxarray110_;
static mxArray * _mxarray111_;

static mxChar _array113_[3] = { '2', '5', '6' };
static mxArray * _mxarray112_;

static mxChar _array115_[8] = { '1', '2', '3', '4', '5', '6', '7', '8' };
static mxArray * _mxarray114_;

static mxChar _array118_[68] = { 'P', 'l', 'e', 'a', 's', 'e', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'p', 'a', 's', 's', 'w',
                                 'o', 'r', 'd', ' ', 'f', 'o', 'r', ' ', 'a',
                                 'd', 'd', 'i', 'n', 'g', ' ', 'w', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k', ' ', 'i', 'm',
                                 'a', 'g', 'e', '(', 'R', 'e', 'c', 'o', 'm',
                                 'm', 'a', 'n', 'd', ' ', '8', ' ', 'D', 'i',
                                 'g', 'i', 't', 's', ')' };
static mxArray * _mxarray117_;
static mxArray * _mxarray116_;

static mxChar _array120_[35] = { 'I', 'n', 'p', 'u', 't', ' ', 'p', 'a', 's',
                                 's', 'w', 'o', 'r', 'd', ' ', 't', 'o', ' ',
                                 'p', 'r', 'o', 't', 'e', 'c', 't', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray119_;

static mxChar _array122_[50] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c', 'e',
                                 'l', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'p',
                                 'a', 's', 's', 'w', 'o', 'r', 'd', ' ', 'p',
                                 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'w', 'i',
                                 'l', 'l', ' ', 'd', 'o', ' ', 'n', 'o', 't',
                                 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray121_;

static mxChar _array124_[22] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ', 'i',
                                 'n', 'p', 'u', 't', ' ', 'P', 'a', 's',
                                 's', 'w', 'o', 'r', 'd', ' ' };
static mxArray * _mxarray123_;

static mxChar _array126_[4] = { 'w', 'a', 'r', 'n' };
static mxArray * _mxarray125_;

static mxChar _array128_[5] = { 'm', 'o', 'd', 'a', 'l' };
static mxArray * _mxarray127_;
static mxArray * _mxarray130_;
static mxArray * _mxarray129_;

static mxChar _array132_[61] = { 'Y', 'o', 'u', ' ', 'd', 'o', 'n', 0x0027, 't',
                                 ' ', 'e', 'n', 't', 'e', 'r', ' ', 'y', 'o',
                                 'u', 'r', ' ', 'p', 'a', 's', 's', 'w', 'o',
                                 'r', 'd', '.', 'W', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'o', 'u', 'l', 'd', 'n', 0x0027, 't',
                                 ' ', 's', 'e', 'c', 'u', 'r', 'e' };
static mxArray * _mxarray131_;

static mxChar _array134_[16] = { 'P', 'a', 's', 's', 'w', 'o', 'r', 'd',
                                 ' ', 'i', 'n', 'v', 'a', 'l', 'i', 'd' };
static mxArray * _mxarray133_;

static mxChar _array137_[60] = { 'P', 'l', 'e', 'a', 's', 'e', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'p', 'e', 'r', 'c', 'e',
                                 'n', 't', ' ', 'f', 'o', 'r', ' ', 'a', 'd',
                                 'd', 'i', 'n', 'g', ' ', 'w', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k', ' ', 'i', 'm', 'a',
                                 'g', 'e', '(', 'd', 'e', 'f', 'u', 'a', 'l',
                                 't', ' ', '9', '5', '%', ')' };
static mxArray * _mxarray136_;
static mxArray * _mxarray135_;

static mxChar _array139_[30] = { 'I', 'n', 'p', 'u', 't', ' ', 'p', 'e',
                                 'r', 'c', 'e', 'n', 't', ' ', 't', 'o',
                                 ' ', 'a', 'd', 'd', ' ', 'w', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray138_;

static mxChar _array142_[2] = { '9', '5' };
static mxArray * _mxarray141_;
static mxArray * _mxarray140_;

static mxChar _array144_[66] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c', 'e',
                                 'l', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'p',
                                 'e', 'r', 'c', 'e', 'n', 't', ' ', 't', 'o',
                                 ' ', 'a', 'd', 'd', ' ', 'w', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k', '.', ' ', 'P', 'r',
                                 'o', 'g', 'r', 'a', 'm', ' ', 'w', 'i', 'l',
                                 'l', ' ', 'd', 'o', ' ', 'n', 'o', 't', 'h',
                                 'i', 'n', 'g' };
static mxArray * _mxarray143_;

static mxChar _array146_[28] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'p',
                                 'e', 'r', 'c', 'e', 'n', 't', ' ',
                                 'a', 'd', 'd', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray145_;

static mxChar _array148_[65] = { 'Y', 'o', 'u', ' ', 'd', 'o', 'n', 0x0027,
                                 't', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'p',
                                 'e', 'r', 'c', 'e', 'n', 't', ' ', 't', 'o',
                                 ' ', 'a', 'd', 'd', 'i', 'n', 'g', '.', ' ',
                                 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'w',
                                 'i', 'l', 'l', ' ', 'u', 's', 'e', ' ', 'd',
                                 'e', 'f', 'u', 'a', 'l', 't', '(', '1', '0',
                                 '0', '%', ')' };
static mxArray * _mxarray147_;

static mxChar _array150_[25] = { 'P', 'e', 'r', 'c', 'e', 'n', 't', ' ', 'a',
                                 'd', 'd', 'i', 'n', 'g', ' ', 'i', 's', ' ',
                                 'i', 'n', 'v', 'a', 'l', 'i', 'd' };
static mxArray * _mxarray149_;

static mxChar _array152_[3] = { '1', '0', '0' };
static mxArray * _mxarray151_;

static mxChar _array154_[39] = { 'P', 'l', 'e', 'a', 's', 'e', ' ', 'w',
                                 'a', 'i', 't', '.', '.', '.', ' ', 'P',
                                 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'i',
                                 's', ' ', ' ', 'p', 'r', 'o', 'c', 'e',
                                 's', 's', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray153_;

static mxChar _array156_[9] = { 't', 'r', 'u', 'e', 'c', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray155_;
static mxArray * _mxarray157_;

static mxChar _array159_[63] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'C',
                                 'a', 'n', 0x0027, 't', ' ', 'i', 'n', 'i', 't',
                                 'i', 'a', 'l', ' ', 's', 'o', 'm', 'e', ' ',
                                 'p', 'a', 'r', 'a', 'm', 'e', 't', 'e', 'r',
                                 's', '.', 'P', 'r', 'o', 'c', 'e', 's', 's',
                                 ' ', 'w', 'i', 'l', 'l', ' ', 'b', 'e', ' ',
                                 'c', 'a', 'n', 'c', 'e', 'l', '.', '.', '.' };
static mxArray * _mxarray158_;

static mxChar _array161_[25] = { 'E', 'r', 'r', 'o', 'r', ' ', 'i', 'n', 'i',
                                 't', 'i', 'a', 'l', ' ', 'p', 'a', 'r', 'a',
                                 'm', 'e', 't', 'e', 'r', 's', ' ' };
static mxArray * _mxarray160_;

static mxChar _array163_[5] = { 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray162_;

static mxChar _array165_[39] = { 'M', 'i', 's', 's', ' ', 'M', 'a', 't',
                                 'c', 'h', ' ', 'b', 'e', 't', 'w', 'e',
                                 'e', 'n', ' ', 'B', 'L', 'O', 'C', 'K',
                                 ' ', 'a', 'n', 'd', ' ', 'I', 'M', 'A',
                                 'G', 'E', ' ', 's', 'i', 'z', 'e' };
static mxArray * _mxarray164_;

static mxChar _array167_[5] = { 'E', 'R', 'R', 'O', 'R' };
static mxArray * _mxarray166_;
static mxArray * _mxarray168_;
static mxArray * _mxarray169_;
static mxArray * _mxarray170_;

static mxChar _array172_[43] = { 'I', 'n', 'i', 't', 'i', 'a', 'l', ' ', 'B',
                                 'l', 'o', 'c', 'k', ' ', 'f', 'o', 'r', ' ',
                                 'a', 'd', 'd', 'i', 'n', 'g', ' ', 'h', 'a',
                                 's', ' ', 's', 'o', 'm', 'e', ' ', 'e', 'r',
                                 'r', 'o', 'r', 's', '.', '.', '.' };
static mxArray * _mxarray171_;

static mxChar _array174_[19] = { 'E', 'R', 'R', 'O', 'R', ' ', 'I',
                                 'n', 'i', 't', 'i', 'a', 'l', ' ',
                                 'B', 'l', 'c', 'o', 'k' };
static mxArray * _mxarray173_;

static mxChar _array176_[13] = { 'r', 'e', 'a', 'l', '_', 'm', 'a',
                                 'r', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray175_;

static mxChar _array178_[3] = { 'b', 'm', 'p' };
static mxArray * _mxarray177_;

static mxChar _array180_[46] = { 'C', 'h', 'e', 'c', 'k', ' ', 'a', 'n',
                                 'd', ' ', 'c', 'o', 'n', 'v', 'e', 'r',
                                 't', ' ', 'w', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'h', 'a', 's', ' ',
                                 's', 'o', 'm', 'e', ' ', 'e', 'r', 'r',
                                 'o', 'r', 's', '.', '.', '.' };
static mxArray * _mxarray179_;

static mxChar _array182_[24] = { 'E', 'R', 'R', 'O', 'R', ' ', 'c', 'h',
                                 'e', 'c', 'k', 'i', 'n', 'g', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray181_;
static mxArray * _mxarray183_;
static mxArray * _mxarray184_;
static mxArray * _mxarray185_;

static mxChar _array187_[34] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 's', 'u', 'c',
                                 'c', 'e', 'e', 'd', ' ', 't', 'h', 'i', 's',
                                 ' ', 'a', 'c', 't', 'i', 'o', 'n', ' ' };
static mxArray * _mxarray186_;

static mxChar _array189_[21] = { 'E', 'r', 'r', 'o', 'r', ' ', 's',
                                 'o', 'm', 'e', ' ', 'p', 'a', 'r',
                                 'a', 'm', 'e', 't', 'e', 'r', 's' };
static mxArray * _mxarray188_;

static mxChar _array191_[21] = { 'P', 'r', 'o', 'c', 'e', 's', 's',
                                 ' ', 'i', 's', ' ', 's', 'u', 'c',
                                 'c', 'e', 's', 's', 'f', 'u', 'l' };
static mxArray * _mxarray190_;

static double _array193_[4] = { .03, .075, .3, .3 };
static mxArray * _mxarray192_;

static mxChar _array195_[20] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w',
                                 'i', 't', 'h', ' ', 'W', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray194_;

static mxChar _array197_[23] = { 'i', 'm', 'a', 'g', 'e', '_', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', '_',
                                 'b', 'a', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray196_;

static mxChar _array199_[32] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'S', 'a', 'v', 'e', 'I', 'm',
                                 'a', 'g', 'e', 'W', 'i', 't', 'h', 'W',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray198_;

static mxChar _array201_[33] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'I', 'm', 'a', 'g', 'e', 'W', 'i', 't',
                                 'h', 'W', 'a', 't', 'e', 'r', 'm', 'a', 'r',
                                 'k', '_', 'i', 'n', 'f', 'o' };
static mxArray * _mxarray200_;

static mxChar _array203_[36] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'S', 'h', 'o', 'w', 'R', 'e', 'a', 'l',
                                 'I', 'm', 'a', 'g', 'e', 'W', 'i', 't', 'h',
                                 'W', 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray202_;

static mxArray * _array205_[2] = { NULL /*_mxarray19_*/, NULL /*_mxarray23_*/ };
static mxArray * _mxarray204_;

static mxChar _array207_[11] = { 'S', 'a', 'v', 'e', ' ', 'a',
                                 ' ', 'f', 'i', 'l', 'e' };
static mxArray * _mxarray206_;

static mxChar _array209_[56] = { 'S', 't', 'a', 't', 'u', 's', '>', '>',
                                 ' ', 'F', 'i', 'l', 'e', ' ', 'i', 's',
                                 ' ', 'n', 'o', 't', ' ', 's', 'a', 'v',
                                 'i', 'n', 'g', ' ', 'r', 'i', 'g', 'h',
                                 't', ' ', 'n', 'o', 'w', '.', '.', '.',
                                 'P', 'l', 'e', 'a', 's', 'e', ' ', 't',
                                 'r', 'y', ' ', 'a', 'g', 'a', 'i', 'n' };
static mxArray * _mxarray208_;

static mxChar _array211_[14] = { 'S', 't', 'a', 't', 'u', 's', '>',
                                 '>', ' ', 'F', 'i', 'l', 'e', ' ' };
static mxArray * _mxarray210_;

static mxChar _array213_[4] = { '.', 'b', 'm', 'p' };
static mxArray * _mxarray212_;

static mxChar _array215_[14] = { ' ', 'a', 'l', 'r', 'e', 'a', 'd',
                                 'y', ' ', 's', 'a', 'v', 'e', 'd' };
static mxArray * _mxarray214_;

static mxChar _array217_[88] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'p', 'r',
                                 'o', 'c', 'e', 's', 's', 'i', 'n', 'g', ' ',
                                 'e', 'x', 't', 'r', 'a', 'c', 't', 'e', 'd',
                                 ' ', 'w', 'a', 't', 'e', 'r', 'm', 'a', 'r',
                                 'k', ' ', 'P', 'r', 'o', 'g', 'r', 'a', 'm',
                                 ' ', 'E', 'r', 'r', 'o', 'r', '.', '.', 'P',
                                 'l', 'e', 'a', 's', 'e', ' ', 'c', 'l', 'o',
                                 's', 'e', ' ', 'a', 'n', 'd', ' ', 'o', 'p',
                                 'e', 'n', ' ', 'p', 'r', 'o', 'g', 'r', 'a',
                                 'm', ' ', 'a', 'g', 'a', 'i', 'n', '.' };
static mxArray * _mxarray216_;

static mxChar _array219_[21] = { 'P', 'r', 'o', 'c', 'e', 's', 's',
                                 ' ', 'h', 'a', 'v', 'e', ' ', 'a',
                                 'n', ' ', 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray218_;
static mxArray * _mxarray220_;

static mxChar _array222_[6] = { 'r', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray221_;

static mxChar _array224_[4] = { 'c', 'r', 'o', 'p' };
static mxArray * _mxarray223_;

static mxChar _array226_[6] = { 'r', 'o', 't', 'a', 't', 'e' };
static mxArray * _mxarray225_;

static mxChar _array229_[92] = { 'P', 'l', 'e', 'a', 's', 'e', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'a', 'n', 'g', 'l', 'e',
                                 ' ', 't', 'h', 'a', 't', ' ', 'p', 'i', 'c',
                                 't', 'u', 'r', 'e', ' ', 'h', 'a', 'd', ' ',
                                 'b', 'e', 'e', 'n', ' ', 'r', 'o', 't', 'a',
                                 't', 'e', ' ', 'f', 'o', 'r', ' ', 'e', 'x',
                                 't', 'r', 'a', 'c', 't', ' ', 'w', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k', ' ', 'i', 'm',
                                 'a', 'g', 'e', '(', 'A', 'n', 'g', 'l', 'e',
                                 ' ', 'i', 'n', ' ', 'D', 'e', 'g', 'r', 'e',
                                 'e', ')' };
static mxArray * _mxarray228_;
static mxArray * _mxarray227_;

static mxChar _array231_[32] = { 'I', 'n', 'p', 'u', 't', ' ', 'a', 'n',
                                 'g', 'l', 'e', ' ', 't', 'o', ' ', 'e',
                                 'x', 't', 'r', 'a', 'c', 't', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray230_;

static mxChar _array233_[47] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c',
                                 'e', 'l', ' ', 'i', 'n', 'p', 'u', 't',
                                 ' ', 'a', 'n', 'g', 'l', 'e', ' ', 'p',
                                 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'w',
                                 'i', 'l', 'l', ' ', 'd', 'o', ' ', 'n',
                                 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray232_;

static mxChar _array235_[19] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'a',
                                 'n', 'g', 'l', 'e', ' ' };
static mxArray * _mxarray234_;

static mxChar _array237_[53] = { 'Y', 'o', 'u', ' ', 'd', 'o', 'n', 0x0027,
                                 't', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'a',
                                 'n', 'g', 'l', 'e', ' ', 'i', 'n', 't', 'e',
                                 'g', 'e', 'r', ' ', 'p', 'r', 'o', 'g', 'r',
                                 'a', 'm', ' ', 'w', 'i', 'l', 'l', ' ', 'd',
                                 'o', ' ', 'n', 'o', 't', 'h', 'i', 'n', 'g' };
static mxArray * _mxarray236_;

static mxChar _array239_[18] = { 'A', 'n', 'g', 'l', 'e', ' ', 'R', 'o', 't',
                                 'a', 't', 'e', ' ', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray238_;

static mxChar _array241_[33] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', ' ', 'i',
                                 'n', 'p', 'u', 't', ' ', 'a', 'n', 'g', 'l',
                                 'e', ' ', 'o', 'n', 'l', 'y', ' ', '0', '-',
                                 '3', '6', '0', '.', '.', '.' };
static mxArray * _mxarray240_;

static mxChar _array243_[24] = { 'A', 'n', 'g', 'l', 'e', ' ', 'R', 'o',
                                 't', 'a', 't', 'e', ' ', 'I', 'n', 'p',
                                 'u', 't', ' ', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray242_;
static mxArray * _mxarray244_;
static mxArray * _mxarray245_;
static mxArray * _mxarray246_;
static mxArray * _mxarray247_;

static mxChar _array249_[34] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'f',
                                 'o', 'u', 'n', 'd', ' ', 'a', 't', 't', 'a',
                                 'c', 'k', ' ', 'm', 'o', 'd', 'e', ' ', 'e',
                                 'r', 'r', 'o', 'r', '.', '.', '.' };
static mxArray * _mxarray248_;

static mxChar _array251_[17] = { 'A', 't', 't', 'a', 'c', 'k', ' ', 'm', 'o',
                                 'd', 'e', ' ', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray250_;

static double _array253_[4] = { .35, .075, .3, .3 };
static mxArray * _mxarray252_;

static mxChar _array255_[19] = { 'E', 'x', 't', 'r', 'a', 'c', 't',
                                 'e', 'd', ' ', 'W', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray254_;

static mxChar _array257_[31] = { 'i', 'm', 'a', 'g', 'e', '_', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', '_',
                                 'e', 'x', 't', 'r', 'a', 'c', 't', '_',
                                 'b', 'a', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray256_;

static mxChar _array259_[23] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'S', 'a', 'v', 'e', 'E', 'x',
                                 't', 'r', 'a', 'c', 't', 'e', 'd' };
static mxArray * _mxarray258_;

static mxChar _array261_[33] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'E', 'x', 't', 'r', 'a', 'c', 't', 'e',
                                 'd', 'W', 'a', 't', 'e', 'r', 'm', 'a', 'r',
                                 'k', '_', 'i', 'n', 'f', 'o' };
static mxArray * _mxarray260_;

static mxChar _array263_[25] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'S', 'h', 'o', 'w', 'R', 'e', 'a', 'l',
                                 'E', 'x', 't', 'r', 'a', 'c', 't' };
static mxArray * _mxarray262_;

static mxChar _array265_[23] = { 'i', 'm', 'a', 'g', 'e', '_', 'e', 'x',
                                 't', 'r', 'a', 'c', 't', 'e', 'd', '_',
                                 'b', 'a', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray264_;

static mxChar _array267_[66] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'h',
                                 'a', 'v', 'e', ' ', 'e', 'r', 'r', 'o', 'r',
                                 '.', '.', '.', 'A', 'n', 'd', ' ', 'c', 'a',
                                 'n', 0x0027, 't', ' ', 'b', 'e', ' ', 'p',
                                 'r', 'o', 'c', 'e', 's', 's', 'i', 'n', 'g',
                                 '.', 'C', 'l', 'o', 's', 'e', ' ', 'a', 'n',
                                 'd', ' ', 'O', 'p', 'e', 'n', ' ', 'a', 'g',
                                 'a', 'i', 'n', ' ' };
static mxArray * _mxarray266_;

static mxChar _array269_[13] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm',
                                 ' ', 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray268_;

static mxChar _array271_[54] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o', 'w',
                                 ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w', 'i',
                                 't', 'h', ' ', 'w', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r',
                                 ' ', 'S', 'a', 'v', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray270_;

static mxChar _array273_[44] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e', ' ',
                                 'w', 'i', 't', 'h', ' ', 'w', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k', ' ', 'a', 'f', 't',
                                 'e', 'r', ' ', 'S', 'a', 'v', 'i', 'n', 'g' };
static mxArray * _mxarray272_;

static mxChar _array275_[53] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o',
                                 'w', ' ', 'e', 'x', 't', 'r', 'a', 'c', 't',
                                 'e', 'd', ' ', 'w', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r',
                                 ' ', 'S', 'a', 'v', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray274_;

static mxChar _array277_[43] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'e', 'x', 't', 'r', 'a', 'c',
                                 't', 'e', 'd', ' ', 'w', 'a', 't', 'e', 'r',
                                 'm', 'a', 'r', 'k', ' ', 'a', 'f', 't', 'e',
                                 'r', ' ', 'S', 'a', 'v', 'i', 'n', 'g' };
static mxArray * _mxarray276_;

static mxChar _array279_[8] = { 'S', 't', 'a', 't', 'u', 's', '>', '>' };
static mxArray * _mxarray278_;

static mxChar _array281_[5] = { 'F', 'i', 'l', 'e', ' ' };
static mxArray * _mxarray280_;

static mxChar _array283_[16] = { ' ', 'a', 'l', 'r', 'e', 'a', 'd', 'y',
                                 ' ', 'o', 'p', 'e', 'n', 'n', 'e', 'd' };
static mxArray * _mxarray282_;

static mxChar _array285_[16] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'R', 'e', 's', 'i', 'z', 'e' };
static mxArray * _mxarray284_;

static mxChar _array287_[16] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'R', 'o', 't', 'a', 't', 'e' };
static mxArray * _mxarray286_;

static mxChar _array289_[16] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'F', 'i', 'l', 't', 'e', 'r' };
static mxArray * _mxarray288_;

static mxChar _array291_[14] = { 'p', 'u', 's', 'h', 'b', 'u', 't',
                                 't', 'o', 'n', 'C', 'r', 'o', 'p' };
static mxArray * _mxarray290_;

static mxChar _array293_[25] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'J', 'P', 'E', 'G', 'C', 'o', 'm', 'p',
                                 'r', 'e', 's', 's', 'i', 'o', 'n' };
static mxArray * _mxarray292_;

static mxChar _array295_[44] = { 'Y', 'o', 'u', ' ', 'm', 'u', 's', 't', ' ',
                                 'o', 'p', 'e', 'n', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ', 'f',
                                 'i', 'r', 's', 't', '.', '.', '.', ' ' };
static mxArray * _mxarray294_;

static mxChar _array297_[36] = { 'F', 'o', 'r', 'g', 'o', 't', ' ', 't', 'o',
                                 ' ', 'o', 'p', 'e', 'n', ' ', 'i', 'm', 'a',
                                 'g', 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ' };
static mxArray * _mxarray296_;

static mxChar _array299_[30] = { 'C', 'r', 'o', 'p', ' ', 'I', 'm', 'a',
                                 'g', 'e', ' ', 'w', 'i', 't', 'h', ' ',
                                 'W', 'a', 't', 'e', 'r', 'm', 'a', 'r',
                                 'k', ' ', 'h', 'e', 'r', 'e' };
static mxArray * _mxarray298_;

static mxChar _array301_[91] = { 'T', 'h', 'i', 's', ' ', 'f', 'u', 'n', 'c',
                                 't', 'i', 'o', 'n', ' ', 'D', 'o', 'n',
                                 0x0027, 't', ' ', 's', 'u', 'p', 'p', 'o',
                                 'r', 't', ' ', 'i', 'n', ' ', 'S', 't', 'a',
                                 'n', 'd', ' ', 'A', 'l', 'o', 'n', 'e', ' ',
                                 'A', 'p', 'p', 'l', 'i', 'c', 'a', 't', 'i',
                                 'o', 'n', ' ', '.', '.', '.', 'P', 'l', 'e',
                                 'a', 's', 'e', ' ', 'r', 'u', 'n', ' ', 'i',
                                 'n', ' ', 'M', 'A', 'T', 'L', 'A', 'B', ' ',
                                 'e', 'n', 'v', 'i', 'r', 'o', 'n', 'm', 'e',
                                 'n', 't', ' ' };
static mxArray * _mxarray300_;

static mxChar _array303_[25] = { 'A', 'p', 'p', 'l', 'i', 'c', 'a', 't', 'i',
                                 'o', 'n', ' ', 'S', 'u', 'p', 'p', 'o', 'r',
                                 't', ' ', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray302_;

static mxChar _array305_[29] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'S', 'a', 'v', 'e', 'A', 't',
                                 't', 'a', 'c', 'k', 'w', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray304_;

static mxChar _array307_[36] = { 'S', 't', 'a', 't', 'u', 's', '>', '>', 'F',
                                 'i', 'l', 'e', ' ', 'i', 's', ' ', 'n', 'o',
                                 't', ' ', 's', 'a', 'v', 'i', 'n', 'g', ' ',
                                 'r', 'i', 'g', 'h', 't', ' ', 'n', 'o', 'w' };
static mxArray * _mxarray306_;

static mxChar _array309_[24] = { 'i', 'm', 'a', 'g', 'e', '_', 'C', 'r',
                                 'o', 'p', 'A', 't', 't', 'a', 'c', 'k',
                                 '_', 'b', 'a', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray308_;

static mxChar _array311_[35] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r', ' ',
                                 'c', 'r', 'o', 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray310_;

static mxChar _array313_[56] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'c', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'c', 'r',
                                 'o', 'p', 'p', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray312_;

static mxChar _array315_[46] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's',
                                 'h', 'o', 'w', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'a', 'f', 't', 'e', 'r', ' ', 'c',
                                 'r', 'o', 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray314_;

static mxChar _array317_[41] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'S', 'a', 'v', 'e', 'd', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'c', 'r', 'o',
                                 'p', 'p', 'i', 'n', 'g' };
static mxArray * _mxarray316_;

static mxChar _array319_[70] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'p',
                                 'r', 'o', 'c', 'e', 's', 's', ' ', 'e', 'r',
                                 'r', 'o', 'r', ' ', 'o', 'r', ' ', 'D', 'o',
                                 'n', 0x0027, 't', ' ', 's', 'u', 'p', 'p',
                                 'o', 'r', 't', ' ', 'i', 'n', ' ', 'S', 't',
                                 'a', 'n', 'd', ' ', 'A', 'l', 'o', 'n', 'e',
                                 ' ', 'A', 'p', 'p', 'l', 'i', 'c', 'a', 't',
                                 'i', 'o', 'n', ' ', '.', '.', '.', ' ' };
static mxArray * _mxarray318_;

static mxChar _array321_[30] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'e', 'r', 'r', 'o', 'r', ' ', 'O', 'r',
                                 ' ', 'S', 'u', 'p', 'p', 'o', 'r', 't',
                                 ' ', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray320_;

static mxChar _array324_[71] = { 'I', 'n', 'p', 'u', 't', ' ', 'S', 'i', 'z',
                                 'e', ' ', 'I', 'm', 'a', 'g', 'e', '.', '.',
                                 '.', '<', 'D', 'e', 'c', 'r', 'e', 'a', 'e',
                                 's', ' ', 'S', 'i', 'z', 'e', '(', '0', '<',
                                 'S', 'i', 'z', 'e', '<', '=', '1', ')', '>',
                                 '.', '.', '.', '<', 'I', 'n', 'c', 'r', 'e',
                                 'a', 's', 'e', ' ', 'S', 'i', 'z', 'e', '(',
                                 'S', 'i', 'z', 'e', '>', '1', ')', '>' };
static mxArray * _mxarray323_;
static mxArray * _mxarray322_;

static mxChar _array326_[16] = { 'I', 'n', 'p', 'u', 't', ' ', 'S', 'i',
                                 'z', 'e', ' ', 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray325_;
static mxArray * _mxarray327_;

static mxChar _array329_[55] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c',
                                 'e', 'l', ' ', 'i', 'n', 'p', 'u', 't',
                                 ' ', 'r', 'e', 's', 'i', 'z', 'e', ' ',
                                 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'p',
                                 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'w',
                                 'i', 'l', 'l', ' ', 'd', 'o', ' ', 'n',
                                 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray328_;

static mxChar _array331_[20] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ',
                                 'i', 'n', 'p', 'u', 't', ' ', 'r',
                                 'e', 's', 'i', 'z', 'e', ' ' };
static mxArray * _mxarray330_;

static mxChar _array333_[58] = { 'Y', 'o', 'u', ' ', 'd', 'o', 'n', 0x0027,
                                 't', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'r',
                                 'e', 's', 'i', 'z', 'e', ' ', 'n', 'u', 'm',
                                 'b', 'e', 'r', '.', ' ', 'P', 'r', 'o', 'g',
                                 'r', 'a', 'm', ' ', 'w', 'i', 'l', 'l', ' ',
                                 'u', 's', 'e', ' ', 'd', 'e', 'f', 'u', 'a',
                                 'l', 't', '(', '1', ')' };
static mxArray * _mxarray332_;

static mxChar _array335_[24] = { 'R', 'e', 's', 'i', 'z', 'e', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ', 'i', 's',
                                 ' ', 'i', 'n', 'v', 'a', 'l', 'i', 'd' };
static mxArray * _mxarray334_;

static mxChar _array337_[62] = { 'Y', 'o', 'u', ' ', ' ', 'i', 'n', 'p', 'u',
                                 't', ' ', 'n', 'o', 't', ' ', 'a', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ', 'f', 'o', 'r',
                                 ' ', 'r', 'e', 's', 'i', 'z', 'i', 'n', 'g',
                                 ' ', ' ', 'p', 'r', 'o', 'g', 'r', 'a', 'm',
                                 ' ', 'w', 'i', 'l', 'l', ' ', 'd', 'o', ' ',
                                 'n', 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray336_;

static mxChar _array339_[72] = { 'Y', 'o', 'u', ' ', ' ', 'i', 'n', 'p', 'u',
                                 't', ' ', 'r', 'e', 's', 'i', 'z', 'e', ' ',
                                 'n', 'u', 'm', 'b', 'e', 'r', ' ', 'n', 'o',
                                 't', ' ', 'a', ' ', 'p', 'o', 's', 'i', 't',
                                 'i', 'v', 'e', ' ', 'i', 'n', 't', 'e', 'g',
                                 'e', 'r', ' ', 'p', 'r', 'o', 'g', 'r', 'a',
                                 'm', ' ', 'w', 'i', 'l', 'l', ' ', 'd', 'o',
                                 ' ', 'n', 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray338_;

static mxChar _array341_[20] = { 'E', 'r', 'r', 'o', 'r', ' ', 'r',
                                 'e', 's', 'i', 'z', 'e', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ' };
static mxArray * _mxarray340_;

static mxChar _array343_[108] = { ' ', 'M', 'a', 'x', 'i', 'm', 'u', 'm', ' ',
                                  'v', 'a', 'r', 'i', 'a', 'b', 'l', 'e', ' ',
                                  's', 'i', 'z', 'e', ' ', 'a', 'l', 'l', 'o',
                                  'w', 'e', 'd', ' ', 'b', 'y', ' ', 't', 'h',
                                  'e', ' ', 'p', 'r', 'o', 'g', 'r', 'a', 'm',
                                  ' ', 'i', 's', ' ', 'e', 'x', 'c', 'e', 'e',
                                  'd', 'e', 'd', ' ', 'O', 'r', ' ', 's', 'o',
                                  'm', 'e', ' ', 'p', 'a', 'r', 'a', 'm', 'e',
                                  't', 'e', 'r', 's', ' ', 'e', 'r', 'r', 'o',
                                  'r', '.', ' ', 'P', 'r', 'o', 'g', 'r', 'a',
                                  'm', ' ', 'w', 'i', 'l', 'l', ' ', 'd', 'o',
                                  ' ', 'n', 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray342_;

static mxChar _array345_[35] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r', ' ',
                                 'r', 'e', 's', 'i', 'z', 'i', 'n', 'g' };
static mxArray * _mxarray344_;

static mxChar _array347_[56] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'c', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'r', 'e',
                                 's', 'i', 'z', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray346_;

static mxChar _array349_[46] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's',
                                 'h', 'o', 'w', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'a', 'f', 't', 'e', 'r', ' ', 'r',
                                 'e', 's', 'i', 'z', 'i', 'n', 'g' };
static mxArray * _mxarray348_;

static mxChar _array351_[41] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'S', 'a', 'v', 'e', 'd', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'r', 'e', 's',
                                 'i', 'z', 'i', 'n', 'g' };
static mxArray * _mxarray350_;

static mxChar _array353_[7] = { 'a', 'v', 'e', 'r', 'a', 'g', 'e' };
static mxArray * _mxarray352_;

static mxChar _array355_[26] = { 'i', 'm', 'a', 'g', 'e', '_', 'F', 'i', 'l',
                                 't', 'e', 'r', 'A', 't', 't', 'a', 'c', 'k',
                                 '_', 'b', 'a', 'k', '.', 'j', 'p', 'g' };
static mxArray * _mxarray354_;

static mxChar _array357_[33] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r', ' ',
                                 'f', 'i', 'l', 't', 'e', 'r' };
static mxArray * _mxarray356_;

static mxChar _array359_[53] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o',
                                 'w', ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w',
                                 'i', 't', 'h', ' ', 'w', 'a', 't', 'e', 'r',
                                 'm', 'a', 'r', 'k', ' ', 'A', 'f', 't', 'e',
                                 'r', ' ', 'f', 'i', 'l', 't', 'e', 'r', '.' };
static mxArray * _mxarray358_;

static mxChar _array361_[45] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o',
                                 'w', ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w',
                                 'i', 't', 'h', ' ', 'w', 'a', 't', 'e', 'r',
                                 'm', 'a', 'r', 'k', ' ', 'a', 'f', 't', 'e',
                                 'r', ' ', 'f', 'i', 'l', 't', 'e', 'r', '.' };
static mxArray * _mxarray360_;

static mxChar _array363_[42] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'S', 'a', 'v', 'e', 'd', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'F', 'i', 'l',
                                 't', 'e', 'r', 'e', 'd', ' ' };
static mxArray * _mxarray362_;

static mxChar _array365_[56] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'c', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'F', 'i',
                                 'l', 't', 'e', 'r', 'e', 'd', '.', ' ' };
static mxArray * _mxarray364_;

static mxChar _array367_[46] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's',
                                 'h', 'o', 'w', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'a', 'f', 't', 'e', 'r', ' ', 'F',
                                 'i', 'l', 't', 'e', 'r', 'e', 'd' };
static mxArray * _mxarray366_;

static mxChar _array369_[27] = { 'R', 'o', 't', 'a', 't', 'e', ' ', 'I', 'm',
                                 'a', 'g', 'e', ' ', 'w', 'i', 't', 'h', ' ',
                                 'W', 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray368_;

static mxChar _array371_[49] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 'o', 'p', 'e',
                                 'n', ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w',
                                 'i', 't', 'h', ' ', 'w', 'a', 't', 'e', 'r',
                                 'm', 'a', 'r', 'k', ' ', 't', 'o', ' ', 'c',
                                 'r', 'o', 'p', '.', ' ' };
static mxArray * _mxarray370_;

static mxChar _array373_[39] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'o',
                                 'p', 'e', 'n', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 't', 'o', ' ', 'c', 'r', 'o', 'p' };
static mxArray * _mxarray372_;

static mxChar _array376_[67] = { 'I', 'n', 'p', 'u', 't', ' ', 'A', 'n', 'g',
                                 'l', 'e', ' ', 'd', 'e', 'g', 'r', 'e', 'e',
                                 ' ', 'i', 'n', ' ', 'a', ' ', 'c', 'o', 'u',
                                 'n', 't', 'e', 'r', '-', 'c', 'l', 'o', 'c',
                                 'k', 'w', 'i', 's', 'e', ' ', 'd', 'i', 'r',
                                 'e', 'c', 't', 'i', 'o', 'n', '(', '0', '<',
                                 '=', 'A', 'n', 'g', 'l', 'e', '<', '=', '3',
                                 '6', '0', ')', ' ' };
static mxArray * _mxarray375_;
static mxArray * _mxarray374_;

static mxChar _array378_[18] = { 'I', 'n', 'p', 'u', 't', ' ', 'A', 'n', 'g',
                                 'l', 'e', ' ', 'D', 'e', 'g', 'r', 'e', 'e' };
static mxArray * _mxarray377_;

static mxChar _array381_[1] = { '0' };
static mxArray * _mxarray380_;
static mxArray * _mxarray379_;

static mxChar _array383_[48] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c',
                                 'e', 'l', ' ', 'i', 'n', 'p', 'u', 't',
                                 ' ', 'r', 'o', 't', 'a', 't', 'e', ' ',
                                 'p', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'w', 'i', 'l', 'l', ' ', 'd', 'o', ' ',
                                 'n', 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray382_;

static mxChar _array385_[29] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ', 'r',
                                 'o', 't', 'a', 't', 'e', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'P', 'a', 's', 's',
                                 'w', 'o', 'r', 'd', ' ' };
static mxArray * _mxarray384_;

static mxChar _array387_[62] = { 'Y', 'o', 'u', ' ', ' ', 'i', 'n', 'p', 'u',
                                 't', ' ', 'r', 'o', 't', 'a', 't', 'e', ' ',
                                 'a', 'n', 'g', 'l', 'e', ' ', 'n', 'o', 't',
                                 ' ', 'a', ' ', 'i', 'n', 't', 'e', 'g', 'e',
                                 'r', '.', 'P', 'r', 'o', 'g', 'r', 'a', 'm',
                                 ' ', 'w', 'i', 'l', 'l', ' ', 'd', 'o', ' ',
                                 'n', 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray386_;

static mxChar _array389_[18] = { 'E', 'r', 'r', 'o', 'r', ' ', 'r', 'o', 't',
                                 'a', 't', 'e', ' ', 'i', 'n', 'p', 'u', 't' };
static mxArray * _mxarray388_;

static mxChar _array391_[34] = { 'I', 'n', 'p', 'u', 't', ' ', 'm', 'u', 's',
                                 't', ' ', 'b', 'e', 't', 'w', 'e', 'e', 'n',
                                 ' ', '0', ' ', 't', 'o', ' ', '3', '6', '0',
                                 ' ', 'D', 'e', 'g', 'r', 'e', 'e' };
static mxArray * _mxarray390_;

static mxChar _array393_[31] = { 'I', 'n', 'p', 'u', 't', ' ', 'A', 'n',
                                 'g', 'l', 'e', ' ', 'D', 'e', 'g', 'r',
                                 'e', 'e', ' ', 'O', 'u', 't', ' ', 'o',
                                 'f', ' ', 'R', 'a', 'n', 'g', 'e' };
static mxArray * _mxarray392_;

static mxChar _array395_[41] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 'p', 'r', 'o',
                                 'c', 'e', 's', 's', ' ', 'r', 'o', 't', 'a',
                                 't', 'e', ' ', 'a', 't', 't', 'a', 'c', 'k',
                                 'i', 'n', 'g', ' ', '.', ' ' };
static mxArray * _mxarray394_;

static mxChar _array397_[22] = { 'S', 'o', 'm', 'e', ' ', 'p', 'a', 'r',
                                 'a', 'm', 'e', 't', 'e', 'r', ' ', 'e',
                                 'r', 'r', 'o', 'r', '.', '.' };
static mxArray * _mxarray396_;

static mxChar _array399_[26] = { 'i', 'm', 'a', 'g', 'e', '_', 'R', 'o', 't',
                                 'a', 't', 'e', 'A', 't', 't', 'a', 'c', 'k',
                                 '_', 'b', 'a', 'k', '.', 'b', 'm', 'p' };
static mxArray * _mxarray398_;

static mxChar _array401_[35] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r', ' ',
                                 'r', 'o', 't', 'a', 't', 'i', 'n', 'g' };
static mxArray * _mxarray400_;

static mxChar _array403_[56] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'c', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'r', 'o',
                                 't', 'a', 't', 'i', 'n', 'g', '.', ' ' };
static mxArray * _mxarray402_;

static mxChar _array405_[46] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's',
                                 'h', 'o', 'w', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'a', 'f', 't', 'e', 'r', ' ', 'r',
                                 'o', 't', 'a', 't', 'i', 'n', 'g' };
static mxArray * _mxarray404_;

static mxChar _array407_[41] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'S', 'a', 'v', 'e', 'd', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'r', 'o', 't',
                                 'a', 't', 'i', 'n', 'g' };
static mxArray * _mxarray406_;

static mxChar _array409_[4] = { 'N', 'a', 'm', 'e' };
static mxArray * _mxarray408_;

static mxChar _array411_[29] = { 'S', 'h', 'o', 'w', ' ', 'R', 'e', 'a',
                                 'l', ' ', 'O', 'r', 'i', 'g', 'i', 'n',
                                 'a', 'l', ' ', 'I', 'a', 'm', 'g', 'e',
                                 ' ', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray410_;

static mxChar _array413_[51] = { 'S', 't', 'a', 't', 'u', 's', '>', '>', 'S',
                                 'h', 'o', 'w', ' ', 'r', 'e', 'a', 'l', ' ',
                                 'o', 'r', 'i', 'g', 'i', 'n', 'a', 'l', ' ',
                                 'i', 'm', 'a', 'g', 'e', ' ', 'h', 'a', 'v',
                                 'e', ' ', 'a', 'l', 'r', 'e', 'a', 'd', 'y',
                                 ' ', 's', 'h', 'o', 'w', 'n' };
static mxArray * _mxarray412_;

static mxChar _array416_[41] = { 'I', 'n', 'p', 'u', 't', ' ', 'q', 'u', 'a',
                                 'l', 'i', 't', 'y', ' ', 'o', 'f', ' ', 'c',
                                 'o', 'm', 'p', 'r', 'e', 's', 's', 'i', 'o',
                                 'n', ' ', 'J', 'P', 'E', 'G', ' ', '(', '0',
                                 '-', '1', '0', '0', ')' };
static mxArray * _mxarray415_;
static mxArray * _mxarray414_;

static mxChar _array418_[31] = { 'I', 'n', 'p', 'u', 't', ' ', ' ', 'Q',
                                 'u', 'a', 'l', 'i', 't', 'y', ' ', 'J',
                                 'P', 'E', 'G', ' ', 'c', 'o', 'm', 'p',
                                 'r', 'e', 's', 's', 'i', 'o', 'n' };
static mxArray * _mxarray417_;
static mxArray * _mxarray419_;

static mxChar _array421_[61] = { 'Y', 'o', 'u', ' ', 'c', 'a', 'n', 'c', 'e',
                                 'l', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'J',
                                 'P', 'E', 'G', ' ', 'Q', 'u', 'a', 'l', 'i',
                                 't', 'y', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                 ' ', 'p', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'w', 'i', 'l', 'l', ' ', 'd', 'o', ' ', 'n',
                                 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray420_;

static mxChar _array423_[26] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'J', 'P', 'E', 'G', ' ',
                                 'Q', 'u', 'a', 'l', 'i', 't', 'y', ' ' };
static mxArray * _mxarray422_;

static mxChar _array425_[66] = { 'Y', 'o', 'u', ' ', 'd', 'o', 'n', 0x0027,
                                 't', ' ', 'i', 'n', 'p', 'u', 't', ' ', 'J',
                                 'P', 'E', 'G', ' ', 'Q', 'u', 'a', 'l', 'i',
                                 't', 'y', ' ', 'n', 'u', 'm', 'b', 'e', 'r',
                                 '.', ' ', 'P', 'r', 'o', 'g', 'r', 'a', 'm',
                                 ' ', 'w', 'i', 'l', 'l', ' ', 'u', 's', 'e',
                                 ' ', 'd', 'e', 'f', 'u', 'a', 'l', 't', '(',
                                 '1', '0', '0', ')' };
static mxArray * _mxarray424_;

static mxChar _array427_[29] = { 'P', 'E', 'G', ' ', 'Q', 'u', 'a', 'l',
                                 'i', 't', 'y', ' ', 'n', 'u', 'm', 'b',
                                 'e', 'r', ' ', 'i', 's', ' ', 'i', 'n',
                                 'v', 'a', 'l', 'i', 'd' };
static mxArray * _mxarray426_;

static mxChar _array429_[70] = { 'Y', 'o', 'u', ' ', ' ', 'i', 'n', 'p', 'u',
                                 't', ' ', 'n', 'o', 't', ' ', 'a', ' ', 'n',
                                 'u', 'm', 'b', 'e', 'r', ' ', 'f', 'o', 'r',
                                 ' ', 'J', 'P', 'E', 'G', ' ', 'c', 'o', 'm',
                                 'p', 'r', 'e', 's', 's', 'i', 'o', 'n', ' ',
                                 ' ', 'p', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'w', 'i', 'l', 'l', ' ', 'd', 'o', ' ', 'n',
                                 'o', 't', 'h', 'i', 'n', 'g', ' ' };
static mxArray * _mxarray428_;

static mxChar _array431_[25] = { 'C', 'a', 'n', 'c', 'e', 'l', ' ', 'i', 'n',
                                 'p', 'u', 't', ' ', 'J', 'P', 'E', 'G', ' ',
                                 'Q', 'u', 'a', 'l', 'i', 't', 'y' };
static mxArray * _mxarray430_;

static mxChar _array433_[67] = { 'Y', 'o', 'u', ' ', ' ', 'i', 'n', 'p', 'u',
                                 't', ' ', 'J', 'P', 'E', 'G', ' ', 'Q', 'u',
                                 'a', 'l', 'i', 't', 'y', ' ', 'n', 'u', 'm',
                                 'b', 'e', 'r', ' ', 'o', 'u', 't', ' ', 'o',
                                 'f', ' ', 'r', 'a', 'n', 'g', ' ', 'p', 'r',
                                 'o', 'g', 'r', 'a', 'm', ' ', 'w', 'i', 'l',
                                 'l', ' ', 'd', 'o', ' ', 'n', 'o', 't', 'h',
                                 'i', 'n', 'g', ' ' };
static mxArray * _mxarray432_;

static mxChar _array435_[26] = { 'E', 'r', 'r', 'o', 'r', ' ', 'J', 'P', 'E',
                                 'G', ' ', 'Q', 'u', 'a', 'l', 'i', 't', 'y',
                                 ' ', 'n', 'u', 'm', 'b', 'e', 'r', ' ' };
static mxArray * _mxarray434_;

static mxChar _array439_[5] = { '*', '.', 'j', 'p', 'g' };
static mxArray * _mxarray438_;

static mxChar _array441_[15] = { 'j', 'p', 'e', 'g', ',', 'j', 'p', 'g',
                                 '(', '*', '.', 'j', 'p', 'g', ')' };
static mxArray * _mxarray440_;

static mxArray * _array437_[2] = { NULL /*_mxarray438_*/,
                                   NULL /*_mxarray440_*/ };
static mxArray * _mxarray436_;

static mxChar _array443_[24] = { 'i', 'm', 'a', 'g', 'e', '_', 'J', 'P',
                                 'E', 'G', 'A', 't', 't', 'a', 'c', 'k',
                                 '_', 'b', 'a', 'k', '.', 'j', 'p', 'g' };
static mxArray * _mxarray442_;

static mxChar _array445_[7] = { 'Q', 'u', 'a', 'l', 'i', 't', 'y' };
static mxArray * _mxarray444_;

static mxChar _array447_[43] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r', ' ',
                                 'J', 'P', 'E', 'G', ' ', 'c', 'o', 'm', 'p',
                                 'r', 'e', 's', 's', 'i', 'o', 'n' };
static mxArray * _mxarray446_;

static mxChar _array449_[63] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ', 'c',
                                 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o', 'w',
                                 ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w', 'i',
                                 't', 'h', ' ', 'w', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'A', 'f', 't', 'e', 'r',
                                 ' ', 'J', 'P', 'E', 'G', ' ', 'c', 'o', 'm',
                                 'p', 'r', 'e', 's', 's', 'i', 'o', 'n', '.' };
static mxArray * _mxarray448_;

static mxChar _array451_[55] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's',
                                 'h', 'o', 'w', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'w', 'i', 't', 'h', ' ', 'w',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'a', 'f', 't', 'e', 'r', ' ', 'J',
                                 'P', 'E', 'G', ' ', 'c', 'o', 'm', 'p',
                                 'r', 'e', 's', 's', 'i', 'o', 'n', '.' };
static mxArray * _mxarray450_;

static mxChar _array453_[4] = { '.', 'j', 'p', 'g' };
static mxArray * _mxarray452_;

static mxChar _array455_[49] = { 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'S', 'a', 'v', 'e', 'd', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'J', 'P', 'E',
                                 'G', ' ', 'c', 'o', 'm', 'p', 'r', 'e', 's',
                                 's', 'i', 'o', 'n' };
static mxArray * _mxarray454_;

static mxChar _array457_[64] = { 'P', 'r', 'o', 'g', 'r', 'a', 'm', ' ',
                                 'c', 'a', 'n', 0x0027, 't', ' ', 's', 'h',
                                 'o', 'w', ' ', 'i', 'm', 'a', 'g', 'e',
                                 ' ', 'w', 'i', 't', 'h', ' ', 'w', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k', ' ',
                                 'A', 'f', 't', 'e', 'r', ' ', 'J', 'P',
                                 'E', 'G', ' ', 'c', 'o', 'm', 'p', 'r',
                                 'e', 's', 's', 'i', 'o', 'n', '.', ' ' };
static mxArray * _mxarray456_;

static mxChar _array459_[54] = { 'C', 'a', 'n', 0x0027, 't', ' ', 's', 'h', 'o',
                                 'w', ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'w',
                                 'i', 't', 'h', ' ', 'w', 'a', 't', 'e', 'r',
                                 'm', 'a', 'r', 'k', ' ', 'a', 'f', 't', 'e',
                                 'r', ' ', 'J', 'P', 'E', 'G', ' ', 'c', 'o',
                                 'm', 'p', 'r', 'e', 's', 's', 'i', 'o', 'n' };
static mxArray * _mxarray458_;

static mxChar _array461_[30] = { 'S', 'h', 'o', 'w', ' ', 'R', 'e', 'a',
                                 'l', ' ', 'W', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'I', 'a', 'm', 'g',
                                 'e', ' ', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray460_;

static mxChar _array463_[52] = { 'S', 't', 'a', 't', 'u', 's', '>', '>', 'S',
                                 'h', 'o', 'w', ' ', 'r', 'e', 'a', 'l', ' ',
                                 'w', 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'i', 'm', 'a', 'g', 'e', ' ', 'h', 'a',
                                 'v', 'e', ' ', 'a', 'l', 'r', 'e', 'a', 'd',
                                 'y', ' ', 's', 'h', 'o', 'w', 'n' };
static mxArray * _mxarray462_;

static mxChar _array465_[41] = { 'S', 'h', 'o', 'w', ' ', 'R', 'e', 'a', 'l',
                                 ' ', 'I', 'm', 'a', 'g', 'e', ' ', 'w', 'i',
                                 't', 'h', ' ', 'W', 'a', 't', 'e', 'r', 'm',
                                 'a', 'r', 'k', ' ', 'I', 'm', 'a', 'g', 'e',
                                 ' ', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray464_;

static mxChar _array467_[57] = { 'S', 't', 'a', 't', 'u', 's', '>', '>', 'S',
                                 'h', 'o', 'w', ' ', 'r', 'e', 'a', 'l', ' ',
                                 'i', 'm', 'a', 'g', 'e', ' ', 'w', 'i', 't',
                                 'h', ' ', 'w', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', ' ', 'h', 'a', 'v', 'e', ' ', 'a',
                                 'l', 'r', 'e', 'a', 'd', 'y', ' ', 's', 'h',
                                 'o', 'w', 'n' };
static mxArray * _mxarray466_;

static mxChar _array469_[40] = { 'S', 'h', 'o', 'w', ' ', 'R', 'e', 'a',
                                 'l', ' ', 'E', 'x', 't', 'r', 'a', 'c',
                                 't', 'e', 'd', ' ', 'W', 'a', 't', 'e',
                                 'r', 'm', 'a', 'r', 'k', ' ', 'I', 'm',
                                 'a', 'g', 'e', ' ', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray468_;

static mxChar _array471_[10] = { 'E', 'x', 'i', 't', ' ',
                                 'N', 'o', 'w', ' ', '?' };
static mxArray * _mxarray470_;

static mxChar _array473_[22] = { 'E', 'x', 'i', 't', ' ', 'W', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k', ' ', 'P',
                                 'r', 'o', 'g', 'r', 'a', 'm' };
static mxArray * _mxarray472_;

static mxChar _array475_[3] = { 'Y', 'e', 's' };
static mxArray * _mxarray474_;

static mxChar _array477_[2] = { 'N', 'o' };
static mxArray * _mxarray476_;

static mxChar _array479_[6] = { 'f', 'i', 'l', 't', 'e', 'r' };
static mxArray * _mxarray478_;

static mxChar _array481_[16] = { 'j', 'p', 'e', 'g', '_', 'c', 'o', 'm',
                                 'p', 'r', 'e', 's', 's', 'i', 'o', 'n' };
static mxArray * _mxarray480_;

static mxChar _array483_[29] = { 'Y', 'o', 'u', ' ', 'a', 'r', 'e', 'n',
                                 0x0027, 't', ' ', 'o', 'p', 'e', 'n',
                                 'i', 'n', 'g', ' ', 'i', 'm', 'a', 'g',
                                 'e', ' ', 'n', 'o', 'w', '.' };
static mxArray * _mxarray482_;

static mxChar _array485_[20] = { 'F', 'o', 'r', 'g', 'o', 't', ' ',
                                 't', 'o', ' ', 'o', 'p', 'e', 'n',
                                 ' ', 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray484_;

static mxChar _array487_[19] = { 'I', 'm', 'a', 'g', 'e', ' ', 'h',
                                 'a', 'v', 'e', ' ', 'a', 'n', ' ',
                                 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray486_;

static mxChar _array489_[29] = { 'C', 'a', 'n', 0x0027, 'd', 'i', 's',
                                 'p', 'l', 'a', 'y', ' ', 'i', 'm', 'a',
                                 'g', 'e', ' ', 'i', 'n', 'f', 'o', 'r',
                                 'm', 'a', 't', 'i', 'o', 'n' };
static mxArray * _mxarray488_;

static mxChar _array491_[83] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'd', 'i',
                                 's', 'p', 'l', 'a', 'y', ' ', 'P', 'S', 'N',
                                 'R', ' ', 'a', 'n', 'd', ' ', 'M', 'S', 'E',
                                 '.', '.', '.', 'Y', 'o', 'u', ' ', 'm', 'u',
                                 's', 't', ' ', 'o', 'p', 'e', 'n', ' ', 'O',
                                 'r', 'i', 'g', 'i', 'n', 'a', 'l', ' ', 'I',
                                 'm', 'a', 'g', 'e', ' ', 'a', 'n', 'd', ' ',
                                 'I', 'm', 'a', 'g', 'e', ' ', 'W', 'i', 't',
                                 'h', ' ', 'w', 'a', 't', 'e', 'r', 'm', 'a',
                                 'r', 'k', '.' };
static mxArray * _mxarray490_;

static mxChar _array493_[26] = { 'P', 'S', 'N', 'R', ' ', 'a', 'n', 'd', ' ',
                                 'M', 'S', 'E', ' ', 'h', 'a', 'v', 'e', ' ',
                                 'a', 'n', ' ', 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray492_;

static mxChar _array495_[87] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'd', 'i',
                                 's', 'p', 'l', 'a', 'y', ' ', 'S', 'i', 'm',
                                 'i', 'l', 'a', 'r', 'i', 't', 'y', '.', '.',
                                 '.', 'Y', 'o', 'u', ' ', 'm', 'u', 's', 't',
                                 ' ', 'o', 'p', 'e', 'n', ' ', 'W', 'a', 't',
                                 'e', 'r', 'm', 'a', 'r', 'k', ' ', 'I', 'm',
                                 'a', 'g', 'e', ' ', 'a', 'n', 'd', ' ', 'E',
                                 'x', 't', 'r', 'a', 'c', 't', 'e', 'd', ' ',
                                 'w', 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k',
                                 ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray494_;

static mxChar _array497_[24] = { 'S', 'i', 'm', 'i', 'l', 'a', 'r', 'i',
                                 't', 'y', ' ', 'h', 'a', 'v', 'e', ' ',
                                 'a', 'n', ' ', 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray496_;

static mxChar _array499_[20] = { 'n', 'o', 't', ' ', 'd', 'e', 'l',
                                 'e', 't', 'e', ' ', 'h', 'a', 'n',
                                 'd', 'l', 'e', 's', ' ', '1' };
static mxArray * _mxarray498_;

static mxChar _array501_[20] = { 'n', 'o', 't', ' ', 'd', 'e', 'l',
                                 'e', 't', 'e', ' ', 'h', 'a', 'n',
                                 'd', 'l', 'e', 's', ' ', '2' };
static mxArray * _mxarray500_;

static mxChar _array503_[20] = { 'n', 'o', 't', ' ', 'd', 'e', 'l',
                                 'e', 't', 'e', ' ', 'h', 'a', 'n',
                                 'd', 'l', 'e', 's', ' ', '3' };
static mxArray * _mxarray502_;

static mxChar _array505_[20] = { 'n', 'o', 't', ' ', 'd', 'e', 'l',
                                 'e', 't', 'e', ' ', 'h', 'a', 'n',
                                 'd', 'l', 'e', 's', ' ', '4' };
static mxArray * _mxarray504_;

static mxChar _array507_[15] = { 'n', 'o', 't', ' ', 'd', 'e', 'l', 'e',
                                 't', 'e', ' ', 'c', 'r', 'o', 'p' };
static mxArray * _mxarray506_;

static mxChar _array509_[20] = { 'n', 'o', 't', ' ', 'd', 'e', 'l',
                                 'e', 't', 'e', ' ', 'h', 'a', 'n',
                                 'd', 'l', 'e', 's', ' ', '5' };
static mxArray * _mxarray508_;

static mxChar _array511_[5] = { 'A', 'f', 't', 'e', 'r' };
static mxArray * _mxarray510_;

static mxChar _array513_[12] = { 'e', 'd', 'i', 't', 'F', 'i',
                                 'l', 'e', 'n', 'a', 'm', 'e' };
static mxArray * _mxarray512_;

static mxChar _array515_[18] = { 'e', 'd', 'i', 't', 'F', 'i', 'l', 'e', 'M',
                                 'o', 'd', 'i', 'f', 'y', 'D', 'a', 't', 'e' };
static mxArray * _mxarray514_;

static mxChar _array517_[12] = { 'e', 'd', 'i', 't', 'F', 'i',
                                 'l', 'e', 'S', 'i', 'z', 'e' };
static mxArray * _mxarray516_;

static mxChar _array519_[15] = { 'e', 'd', 'i', 't', 'I', 'm', 'a', 'g',
                                 'e', 'F', 'o', 'r', 'm', 'a', 't' };
static mxArray * _mxarray518_;

static mxChar _array521_[22] = { 'e', 'd', 'i', 't', 'I', 'm', 'a', 'g',
                                 'e', 'F', 'o', 'r', 'm', 'a', 't', 'V',
                                 'e', 'r', 's', 'i', 'o', 'n' };
static mxArray * _mxarray520_;

static mxChar _array523_[53] = { 'I', 't', 0x0027, 's', ' ', 'n', 'o', 't', ' ',
                                 'b', 'i', 't', 'm', 'a', 'p', ' ', 'i', 'm',
                                 'a', 'g', 'e', '.', 'S', 'o', ' ', 'C', 'a',
                                 'n', 0x0027, 't', ' ', 'i', 'd', 'e', 'n', 't',
                                 'i', 'f', 'y', ' ', 'F', 'o', 'r', 'm', 'a',
                                 't', 'V', 'e', 'r', 's', 'i', 'o', 'n' };
static mxArray * _mxarray522_;

static mxChar _array525_[14] = { 'e', 'd', 'i', 't', 'I', 'm', 'a',
                                 'g', 'e', 'W', 'i', 'd', 't', 'h' };
static mxArray * _mxarray524_;

static mxChar _array527_[15] = { 'e', 'd', 'i', 't', 'I', 'm', 'a', 'g',
                                 'e', 'H', 'e', 'i', 'g', 'h', 't' };
static mxArray * _mxarray526_;

static mxChar _array529_[24] = { 'e', 'd', 'i', 't', 'I', 'm', 'a', 'g',
                                 'e', 'C', 'o', 'm', 'p', 'r', 'e', 's',
                                 's', 'i', 'o', 'n', 'T', 'y', 'p', 'e' };
static mxArray * _mxarray528_;

static mxChar _array531_[55] = { 'I', 't', 0x0027, 's', ' ', 'n', 'o', 't',
                                 ' ', 'b', 'i', 't', 'm', 'a', 'p', ' ',
                                 'i', 'm', 'a', 'g', 'e', '.', 'S', 'o',
                                 ' ', 'C', 'a', 'n', 0x0027, 't', ' ', 'i',
                                 'd', 'e', 'n', 't', 'i', 'f', 'y', ' ',
                                 'C', 'o', 'm', 'p', 'r', 'e', 's', 's',
                                 'i', 'o', 'n', 'T', 'y', 'p', 'e' };
static mxArray * _mxarray530_;
static mxArray * _mxarray532_;
static mxArray * _mxarray533_;

static mxChar _array535_[8] = { 'e', 'd', 'i', 't', 'P', 'S', 'N', 'R' };
static mxArray * _mxarray534_;

static mxChar _array537_[7] = { 'e', 'd', 'i', 't', 'M', 'S', 'E' };
static mxArray * _mxarray536_;

static mxChar _array539_[85] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'd', 'i',
                                 's', 'p', 'l', 'a', 'y', ' ', 'P', 'S', 'N',
                                 'R', ' ', 'a', 'n', 'd', ' ', 'M', 'S', 'E',
                                 '.', '.', '.', 'S', 'o', 'm', 'e', ' ', 'p',
                                 'a', 'r', 'a', 'm', 'e', 't', 'e', 'r', 's',
                                 ' ', 'a', 'r', 'e', ' ', 'm', 'i', 's', 's',
                                 'i', 'n', 'g', ' ', 'O', 'r', ' ', 'p', 'r',
                                 'o', 'g', 'r', 'a', 'm', ' ', 'c', 'a', 'n',
                                 0x0027, 't', ' ', 'r', 'e', 'a', 'd', ' ',
                                 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray538_;

static mxChar _array541_[22] = { 'P', 'S', 'N', 'R', ' ', 'M', 'S', 'E',
                                 ' ', 'h', 'a', 'v', 'e', ' ', 'a', 'n',
                                 ' ', 'e', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray540_;

static mxChar _array543_[14] = { 'e', 'd', 'i', 't', 'S', 'i', 'm',
                                 'i', 'l', 'a', 'r', 'i', 't', 'y' };
static mxArray * _mxarray542_;

static mxChar _array545_[83] = { 'C', 'a', 'n', 0x0027, 't', ' ', 'd', 'i',
                                 's', 'p', 'l', 'a', 'y', ' ', 'S', 'i', 'm',
                                 'i', 'l', 'a', 'r', 'i', 't', 'y', '.', '.',
                                 '.', 'S', 'o', 'm', 'e', ' ', 'p', 'a', 'r',
                                 'a', 'm', 'e', 't', 'e', 'r', 's', ' ', 'a',
                                 'r', 'e', ' ', 'm', 'i', 's', 's', 'i', 'n',
                                 'g', ' ', 'O', 'r', ' ', 'p', 'r', 'o', 'g',
                                 'r', 'a', 'm', ' ', 'c', 'a', 'n', 0x0027,
                                 't', ' ', 'r', 'e', 'a', 'd', ' ', 'i', 'm',
                                 'a', 'g', 'e', '.' };
static mxArray * _mxarray544_;

static mxChar _array547_[6] = { 'F', 'i', 'l', 'e', ' ', ' ' };
static mxArray * _mxarray546_;

static mxChar _array549_[18] = { 'S', 'a', 'v', 'e', ' ', 'A', 't', 't', 'a',
                                 'c', 'k', 'i', 'n', 'g', ' ', 'a', 't', ' ' };
static mxArray * _mxarray548_;

static mxChar _array551_[22] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'O', 'p', 'e', 'n', 'O', 'r',
                                 'i', 'g', 'i', 'n', 'a', 'l' };
static mxArray * _mxarray550_;

static mxChar _array553_[23] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'O', 'p', 'e', 'n', 'W', 'a',
                                 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray552_;

static mxChar _array555_[32] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't',
                                 'o', 'n', 'O', 'p', 'e', 'n', 'I', 'm',
                                 'a', 'g', 'e', 'W', 'i', 't', 'h', 'W',
                                 'a', 't', 'e', 'r', 'm', 'a', 'r', 'k' };
static mxArray * _mxarray554_;

static mxChar _array557_[28] = { 'p', 'u', 's', 'h', 'b', 'u', 't',
                                 't', 'o', 'n', 'O', 'p', 'e', 'n',
                                 'E', 'x', 't', 'r', 'a', 'c', 't',
                                 'e', 'd', 'I', 'm', 'a', 'g', 'e' };
static mxArray * _mxarray556_;

static mxChar _array559_[18] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'P', 'S', 'N', 'R', '_', 'M', 'S', 'E' };
static mxArray * _mxarray558_;

static mxChar _array561_[20] = { 'p', 'u', 's', 'h', 'b', 'u', 't',
                                 't', 'o', 'n', 'S', 'i', 'm', 'i',
                                 'l', 'a', 'r', 'i', 't', 'y' };
static mxArray * _mxarray560_;

static mxChar _array563_[18] = { 'p', 'u', 's', 'h', 'b', 'u', 't', 't', 'o',
                                 'n', 'C', 'l', 'e', 'a', 'r', 'A', 'l', 'l' };
static mxArray * _mxarray562_;

static mxChar _array565_[14] = { 'p', 'u', 's', 'h', 'b', 'u', 't',
                                 't', 'o', 'n', 'E', 'x', 'i', 't' };
static mxArray * _mxarray564_;

void InitializeModule_watermark005(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeString(8, _array2_);
    _mxarray3_ = mclInitializeString(13, _array4_);
    _mxarray5_ = mclInitializeString(14, _array6_);
    _mxarray7_ = mclInitializeString(13, _array8_);
    _mxarray9_ = mclInitializeString(13, _array10_);
    _mxarray11_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray12_ = mclInitializeString(12, _array13_);
    _mxarray14_ = mclInitializeDouble(0.0);
    _mxarray15_ = mclInitializeString(7, _array16_);
    _mxarray19_ = mclInitializeString(5, _array20_);
    _array18_[0] = _mxarray19_;
    _mxarray21_ = mclInitializeString(12, _array22_);
    _array18_[1] = _mxarray21_;
    _mxarray23_ = mclInitializeString(13, _array24_);
    _array18_[2] = _mxarray23_;
    _mxarray25_ = mclInitializeString(18, _array26_);
    _array18_[3] = _mxarray25_;
    _mxarray17_ = mclInitializeCellVector(2, 2, _array18_);
    _mxarray27_ = mclInitializeString(13, _array28_);
    _mxarray29_ = mclInitializeString(41, _array30_);
    _mxarray31_ = mclInitializeString(13, _array32_);
    _mxarray33_ = mclInitializeString(21, _array34_);
    _mxarray35_ = mclInitializeString(8, _array36_);
    _mxarray37_ = mclInitializeDoubleVector(1, 4, _array38_);
    _mxarray39_ = mclInitializeString(12, _array40_);
    _mxarray41_ = mclInitializeString(5, _array42_);
    _mxarray43_ = mclInitializeString(3, _array44_);
    _mxarray45_ = mclInitializeString(22, _array46_);
    _mxarray47_ = mclInitializeString(6, _array48_);
    _mxarray49_ = mclInitializeString(2, _array50_);
    _mxarray51_ = mclInitializeString(21, _array52_);
    _mxarray53_ = mclInitializeString(17, _array54_);
    _mxarray55_ = mclInitializeString(21, _array56_);
    _mxarray57_ = mclInitializeString(21, _array58_);
    _mxarray59_ = mclInitializeString(23, _array60_);
    _mxarray61_ = mclInitializeString(26, _array62_);
    _mxarray63_ = mclInitializeString(21, _array64_);
    _mxarray65_ = mclInitializeDoubleVector(1, 4, _array66_);
    _mxarray67_ = mclInitializeString(3, _array68_);
    _mxarray69_ = mclInitializeString(24, _array70_);
    _mxarray71_ = mclInitializeString(27, _array72_);
    _mxarray73_ = mclInitializeString(15, _array74_);
    _mxarray75_ = mclInitializeString(5, _array76_);
    _mxarray77_ = mclInitializeString(31, _array78_);
    _mxarray79_ = mclInitializeString(5, _array80_);
    _mxarray81_ = mclInitializeString(6, _array82_);
    _mxarray83_ = mclInitializeString(1, _array84_);
    _mxarray85_ = mclInitializeDouble(2.0);
    _mxarray86_ = mclInitializeString(1, _array87_);
    _mxarray88_ = mclInitializeDouble(3.0);
    _mxarray89_ = mclInitializeDouble(4.0);
    _mxarray90_ = mclInitializeString(1, _array91_);
    _mxarray92_ = mclInitializeDouble(8.0);
    _mxarray93_ = mclInitializeString(1, _array94_);
    _mxarray95_ = mclInitializeDouble(5.0);
    _mxarray96_ = mclInitializeDouble(16.0);
    _mxarray97_ = mclInitializeString(2, _array98_);
    _mxarray99_ = mclInitializeDouble(6.0);
    _mxarray100_ = mclInitializeDouble(32.0);
    _mxarray101_ = mclInitializeString(2, _array102_);
    _mxarray103_ = mclInitializeDouble(7.0);
    _mxarray104_ = mclInitializeDouble(64.0);
    _mxarray105_ = mclInitializeString(2, _array106_);
    _mxarray107_ = mclInitializeDouble(128.0);
    _mxarray108_ = mclInitializeString(3, _array109_);
    _mxarray110_ = mclInitializeDouble(9.0);
    _mxarray111_ = mclInitializeDouble(256.0);
    _mxarray112_ = mclInitializeString(3, _array113_);
    _mxarray114_ = mclInitializeString(8, _array115_);
    _mxarray117_ = mclInitializeString(68, _array118_);
    _mxarray116_ = mclInitializeCell(_mxarray117_);
    _mxarray119_ = mclInitializeString(35, _array120_);
    _mxarray121_ = mclInitializeString(50, _array122_);
    _mxarray123_ = mclInitializeString(22, _array124_);
    _mxarray125_ = mclInitializeString(4, _array126_);
    _mxarray127_ = mclInitializeString(5, _array128_);
    _mxarray130_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray129_ = mclInitializeCell(_mxarray130_);
    _mxarray131_ = mclInitializeString(61, _array132_);
    _mxarray133_ = mclInitializeString(16, _array134_);
    _mxarray136_ = mclInitializeString(60, _array137_);
    _mxarray135_ = mclInitializeCell(_mxarray136_);
    _mxarray138_ = mclInitializeString(30, _array139_);
    _mxarray141_ = mclInitializeString(2, _array142_);
    _mxarray140_ = mclInitializeCell(_mxarray141_);
    _mxarray143_ = mclInitializeString(66, _array144_);
    _mxarray145_ = mclInitializeString(28, _array146_);
    _mxarray147_ = mclInitializeString(65, _array148_);
    _mxarray149_ = mclInitializeString(25, _array150_);
    _mxarray151_ = mclInitializeString(3, _array152_);
    _mxarray153_ = mclInitializeString(39, _array154_);
    _mxarray155_ = mclInitializeString(9, _array156_);
    _mxarray157_ = mclInitializeDouble(.1);
    _mxarray158_ = mclInitializeString(63, _array159_);
    _mxarray160_ = mclInitializeString(25, _array161_);
    _mxarray162_ = mclInitializeString(5, _array163_);
    _mxarray164_ = mclInitializeString(39, _array165_);
    _mxarray166_ = mclInitializeString(5, _array167_);
    _mxarray168_ = mclInitializeDouble(.3);
    _mxarray169_ = mclInitializeDouble(100.0);
    _mxarray170_ = mclInitializeDouble(.5);
    _mxarray171_ = mclInitializeString(43, _array172_);
    _mxarray173_ = mclInitializeString(19, _array174_);
    _mxarray175_ = mclInitializeString(13, _array176_);
    _mxarray177_ = mclInitializeString(3, _array178_);
    _mxarray179_ = mclInitializeString(46, _array180_);
    _mxarray181_ = mclInitializeString(24, _array182_);
    _mxarray183_ = mclInitializeDouble(.7);
    _mxarray184_ = mclInitializeDouble(.01);
    _mxarray185_ = mclInitializeDouble(.9);
    _mxarray186_ = mclInitializeString(34, _array187_);
    _mxarray188_ = mclInitializeString(21, _array189_);
    _mxarray190_ = mclInitializeString(21, _array191_);
    _mxarray192_ = mclInitializeDoubleVector(1, 4, _array193_);
    _mxarray194_ = mclInitializeString(20, _array195_);
    _mxarray196_ = mclInitializeString(23, _array197_);
    _mxarray198_ = mclInitializeString(32, _array199_);
    _mxarray200_ = mclInitializeString(33, _array201_);
    _mxarray202_ = mclInitializeString(36, _array203_);
    _array205_[0] = _mxarray19_;
    _array205_[1] = _mxarray23_;
    _mxarray204_ = mclInitializeCellVector(1, 2, _array205_);
    _mxarray206_ = mclInitializeString(11, _array207_);
    _mxarray208_ = mclInitializeString(56, _array209_);
    _mxarray210_ = mclInitializeString(14, _array211_);
    _mxarray212_ = mclInitializeString(4, _array213_);
    _mxarray214_ = mclInitializeString(14, _array215_);
    _mxarray216_ = mclInitializeString(88, _array217_);
    _mxarray218_ = mclInitializeString(21, _array219_);
    _mxarray220_ = mclInitializeDouble(.05);
    _mxarray221_ = mclInitializeString(6, _array222_);
    _mxarray223_ = mclInitializeString(4, _array224_);
    _mxarray225_ = mclInitializeString(6, _array226_);
    _mxarray228_ = mclInitializeString(92, _array229_);
    _mxarray227_ = mclInitializeCell(_mxarray228_);
    _mxarray230_ = mclInitializeString(32, _array231_);
    _mxarray232_ = mclInitializeString(47, _array233_);
    _mxarray234_ = mclInitializeString(19, _array235_);
    _mxarray236_ = mclInitializeString(53, _array237_);
    _mxarray238_ = mclInitializeString(18, _array239_);
    _mxarray240_ = mclInitializeString(33, _array241_);
    _mxarray242_ = mclInitializeString(24, _array243_);
    _mxarray244_ = mclInitializeDouble(360.0);
    _mxarray245_ = mclInitializeDouble(90.0);
    _mxarray246_ = mclInitializeDouble(180.0);
    _mxarray247_ = mclInitializeDouble(270.0);
    _mxarray248_ = mclInitializeString(34, _array249_);
    _mxarray250_ = mclInitializeString(17, _array251_);
    _mxarray252_ = mclInitializeDoubleVector(1, 4, _array253_);
    _mxarray254_ = mclInitializeString(19, _array255_);
    _mxarray256_ = mclInitializeString(31, _array257_);
    _mxarray258_ = mclInitializeString(23, _array259_);
    _mxarray260_ = mclInitializeString(33, _array261_);
    _mxarray262_ = mclInitializeString(25, _array263_);
    _mxarray264_ = mclInitializeString(23, _array265_);
    _mxarray266_ = mclInitializeString(66, _array267_);
    _mxarray268_ = mclInitializeString(13, _array269_);
    _mxarray270_ = mclInitializeString(54, _array271_);
    _mxarray272_ = mclInitializeString(44, _array273_);
    _mxarray274_ = mclInitializeString(53, _array275_);
    _mxarray276_ = mclInitializeString(43, _array277_);
    _mxarray278_ = mclInitializeString(8, _array279_);
    _mxarray280_ = mclInitializeString(5, _array281_);
    _mxarray282_ = mclInitializeString(16, _array283_);
    _mxarray284_ = mclInitializeString(16, _array285_);
    _mxarray286_ = mclInitializeString(16, _array287_);
    _mxarray288_ = mclInitializeString(16, _array289_);
    _mxarray290_ = mclInitializeString(14, _array291_);
    _mxarray292_ = mclInitializeString(25, _array293_);
    _mxarray294_ = mclInitializeString(44, _array295_);
    _mxarray296_ = mclInitializeString(36, _array297_);
    _mxarray298_ = mclInitializeString(30, _array299_);
    _mxarray300_ = mclInitializeString(91, _array301_);
    _mxarray302_ = mclInitializeString(25, _array303_);
    _mxarray304_ = mclInitializeString(29, _array305_);
    _mxarray306_ = mclInitializeString(36, _array307_);
    _mxarray308_ = mclInitializeString(24, _array309_);
    _mxarray310_ = mclInitializeString(35, _array311_);
    _mxarray312_ = mclInitializeString(56, _array313_);
    _mxarray314_ = mclInitializeString(46, _array315_);
    _mxarray316_ = mclInitializeString(41, _array317_);
    _mxarray318_ = mclInitializeString(70, _array319_);
    _mxarray320_ = mclInitializeString(30, _array321_);
    _mxarray323_ = mclInitializeString(71, _array324_);
    _mxarray322_ = mclInitializeCell(_mxarray323_);
    _mxarray325_ = mclInitializeString(16, _array326_);
    _mxarray327_ = mclInitializeCell(_mxarray83_);
    _mxarray328_ = mclInitializeString(55, _array329_);
    _mxarray330_ = mclInitializeString(20, _array331_);
    _mxarray332_ = mclInitializeString(58, _array333_);
    _mxarray334_ = mclInitializeString(24, _array335_);
    _mxarray336_ = mclInitializeString(62, _array337_);
    _mxarray338_ = mclInitializeString(72, _array339_);
    _mxarray340_ = mclInitializeString(20, _array341_);
    _mxarray342_ = mclInitializeString(108, _array343_);
    _mxarray344_ = mclInitializeString(35, _array345_);
    _mxarray346_ = mclInitializeString(56, _array347_);
    _mxarray348_ = mclInitializeString(46, _array349_);
    _mxarray350_ = mclInitializeString(41, _array351_);
    _mxarray352_ = mclInitializeString(7, _array353_);
    _mxarray354_ = mclInitializeString(26, _array355_);
    _mxarray356_ = mclInitializeString(33, _array357_);
    _mxarray358_ = mclInitializeString(53, _array359_);
    _mxarray360_ = mclInitializeString(45, _array361_);
    _mxarray362_ = mclInitializeString(42, _array363_);
    _mxarray364_ = mclInitializeString(56, _array365_);
    _mxarray366_ = mclInitializeString(46, _array367_);
    _mxarray368_ = mclInitializeString(27, _array369_);
    _mxarray370_ = mclInitializeString(49, _array371_);
    _mxarray372_ = mclInitializeString(39, _array373_);
    _mxarray375_ = mclInitializeString(67, _array376_);
    _mxarray374_ = mclInitializeCell(_mxarray375_);
    _mxarray377_ = mclInitializeString(18, _array378_);
    _mxarray380_ = mclInitializeString(1, _array381_);
    _mxarray379_ = mclInitializeCell(_mxarray380_);
    _mxarray382_ = mclInitializeString(48, _array383_);
    _mxarray384_ = mclInitializeString(29, _array385_);
    _mxarray386_ = mclInitializeString(62, _array387_);
    _mxarray388_ = mclInitializeString(18, _array389_);
    _mxarray390_ = mclInitializeString(34, _array391_);
    _mxarray392_ = mclInitializeString(31, _array393_);
    _mxarray394_ = mclInitializeString(41, _array395_);
    _mxarray396_ = mclInitializeString(22, _array397_);
    _mxarray398_ = mclInitializeString(26, _array399_);
    _mxarray400_ = mclInitializeString(35, _array401_);
    _mxarray402_ = mclInitializeString(56, _array403_);
    _mxarray404_ = mclInitializeString(46, _array405_);
    _mxarray406_ = mclInitializeString(41, _array407_);
    _mxarray408_ = mclInitializeString(4, _array409_);
    _mxarray410_ = mclInitializeString(29, _array411_);
    _mxarray412_ = mclInitializeString(51, _array413_);
    _mxarray415_ = mclInitializeString(41, _array416_);
    _mxarray414_ = mclInitializeCell(_mxarray415_);
    _mxarray417_ = mclInitializeString(31, _array418_);
    _mxarray419_ = mclInitializeCell(_mxarray151_);
    _mxarray420_ = mclInitializeString(61, _array421_);
    _mxarray422_ = mclInitializeString(26, _array423_);
    _mxarray424_ = mclInitializeString(66, _array425_);
    _mxarray426_ = mclInitializeString(29, _array427_);
    _mxarray428_ = mclInitializeString(70, _array429_);
    _mxarray430_ = mclInitializeString(25, _array431_);
    _mxarray432_ = mclInitializeString(67, _array433_);
    _mxarray434_ = mclInitializeString(26, _array435_);
    _mxarray438_ = mclInitializeString(5, _array439_);
    _array437_[0] = _mxarray438_;
    _mxarray440_ = mclInitializeString(15, _array441_);
    _array437_[1] = _mxarray440_;
    _mxarray436_ = mclInitializeCellVector(1, 2, _array437_);
    _mxarray442_ = mclInitializeString(24, _array443_);
    _mxarray444_ = mclInitializeString(7, _array445_);
    _mxarray446_ = mclInitializeString(43, _array447_);
    _mxarray448_ = mclInitializeString(63, _array449_);
    _mxarray450_ = mclInitializeString(55, _array451_);
    _mxarray452_ = mclInitializeString(4, _array453_);
    _mxarray454_ = mclInitializeString(49, _array455_);
    _mxarray456_ = mclInitializeString(64, _array457_);
    _mxarray458_ = mclInitializeString(54, _array459_);
    _mxarray460_ = mclInitializeString(30, _array461_);
    _mxarray462_ = mclInitializeString(52, _array463_);
    _mxarray464_ = mclInitializeString(41, _array465_);
    _mxarray466_ = mclInitializeString(57, _array467_);
    _mxarray468_ = mclInitializeString(40, _array469_);
    _mxarray470_ = mclInitializeString(10, _array471_);
    _mxarray472_ = mclInitializeString(22, _array473_);
    _mxarray474_ = mclInitializeString(3, _array475_);
    _mxarray476_ = mclInitializeString(2, _array477_);
    _mxarray478_ = mclInitializeString(6, _array479_);
    _mxarray480_ = mclInitializeString(16, _array481_);
    _mxarray482_ = mclInitializeString(29, _array483_);
    _mxarray484_ = mclInitializeString(20, _array485_);
    _mxarray486_ = mclInitializeString(19, _array487_);
    _mxarray488_ = mclInitializeString(29, _array489_);
    _mxarray490_ = mclInitializeString(83, _array491_);
    _mxarray492_ = mclInitializeString(26, _array493_);
    _mxarray494_ = mclInitializeString(87, _array495_);
    _mxarray496_ = mclInitializeString(24, _array497_);
    _mxarray498_ = mclInitializeString(20, _array499_);
    _mxarray500_ = mclInitializeString(20, _array501_);
    _mxarray502_ = mclInitializeString(20, _array503_);
    _mxarray504_ = mclInitializeString(20, _array505_);
    _mxarray506_ = mclInitializeString(15, _array507_);
    _mxarray508_ = mclInitializeString(20, _array509_);
    _mxarray510_ = mclInitializeString(5, _array511_);
    _mxarray512_ = mclInitializeString(12, _array513_);
    _mxarray514_ = mclInitializeString(18, _array515_);
    _mxarray516_ = mclInitializeString(12, _array517_);
    _mxarray518_ = mclInitializeString(15, _array519_);
    _mxarray520_ = mclInitializeString(22, _array521_);
    _mxarray522_ = mclInitializeString(53, _array523_);
    _mxarray524_ = mclInitializeString(14, _array525_);
    _mxarray526_ = mclInitializeString(15, _array527_);
    _mxarray528_ = mclInitializeString(24, _array529_);
    _mxarray530_ = mclInitializeString(55, _array531_);
    _mxarray532_ = mclInitializeDouble(10.0);
    _mxarray533_ = mclInitializeDouble(65025.0);
    _mxarray534_ = mclInitializeString(8, _array535_);
    _mxarray536_ = mclInitializeString(7, _array537_);
    _mxarray538_ = mclInitializeString(85, _array539_);
    _mxarray540_ = mclInitializeString(22, _array541_);
    _mxarray542_ = mclInitializeString(14, _array543_);
    _mxarray544_ = mclInitializeString(83, _array545_);
    _mxarray546_ = mclInitializeString(6, _array547_);
    _mxarray548_ = mclInitializeString(18, _array549_);
    _mxarray550_ = mclInitializeString(22, _array551_);
    _mxarray552_ = mclInitializeString(23, _array553_);
    _mxarray554_ = mclInitializeString(32, _array555_);
    _mxarray556_ = mclInitializeString(28, _array557_);
    _mxarray558_ = mclInitializeString(18, _array559_);
    _mxarray560_ = mclInitializeString(20, _array561_);
    _mxarray562_ = mclInitializeString(18, _array563_);
    _mxarray564_ = mclInitializeString(14, _array565_);
}

void TerminateModule_watermark005(void) {
    mxDestroyArray(_mxarray564_);
    mxDestroyArray(_mxarray562_);
    mxDestroyArray(_mxarray560_);
    mxDestroyArray(_mxarray558_);
    mxDestroyArray(_mxarray556_);
    mxDestroyArray(_mxarray554_);
    mxDestroyArray(_mxarray552_);
    mxDestroyArray(_mxarray550_);
    mxDestroyArray(_mxarray548_);
    mxDestroyArray(_mxarray546_);
    mxDestroyArray(_mxarray544_);
    mxDestroyArray(_mxarray542_);
    mxDestroyArray(_mxarray540_);
    mxDestroyArray(_mxarray538_);
    mxDestroyArray(_mxarray536_);
    mxDestroyArray(_mxarray534_);
    mxDestroyArray(_mxarray533_);
    mxDestroyArray(_mxarray532_);
    mxDestroyArray(_mxarray530_);
    mxDestroyArray(_mxarray528_);
    mxDestroyArray(_mxarray526_);
    mxDestroyArray(_mxarray524_);
    mxDestroyArray(_mxarray522_);
    mxDestroyArray(_mxarray520_);
    mxDestroyArray(_mxarray518_);
    mxDestroyArray(_mxarray516_);
    mxDestroyArray(_mxarray514_);
    mxDestroyArray(_mxarray512_);
    mxDestroyArray(_mxarray510_);
    mxDestroyArray(_mxarray508_);
    mxDestroyArray(_mxarray506_);
    mxDestroyArray(_mxarray504_);
    mxDestroyArray(_mxarray502_);
    mxDestroyArray(_mxarray500_);
    mxDestroyArray(_mxarray498_);
    mxDestroyArray(_mxarray496_);
    mxDestroyArray(_mxarray494_);
    mxDestroyArray(_mxarray492_);
    mxDestroyArray(_mxarray490_);
    mxDestroyArray(_mxarray488_);
    mxDestroyArray(_mxarray486_);
    mxDestroyArray(_mxarray484_);
    mxDestroyArray(_mxarray482_);
    mxDestroyArray(_mxarray480_);
    mxDestroyArray(_mxarray478_);
    mxDestroyArray(_mxarray476_);
    mxDestroyArray(_mxarray474_);
    mxDestroyArray(_mxarray472_);
    mxDestroyArray(_mxarray470_);
    mxDestroyArray(_mxarray468_);
    mxDestroyArray(_mxarray466_);
    mxDestroyArray(_mxarray464_);
    mxDestroyArray(_mxarray462_);
    mxDestroyArray(_mxarray460_);
    mxDestroyArray(_mxarray458_);
    mxDestroyArray(_mxarray456_);
    mxDestroyArray(_mxarray454_);
    mxDestroyArray(_mxarray452_);
    mxDestroyArray(_mxarray450_);
    mxDestroyArray(_mxarray448_);
    mxDestroyArray(_mxarray446_);
    mxDestroyArray(_mxarray444_);
    mxDestroyArray(_mxarray442_);
    mxDestroyArray(_mxarray436_);
    mxDestroyArray(_mxarray440_);
    mxDestroyArray(_mxarray438_);
    mxDestroyArray(_mxarray434_);
    mxDestroyArray(_mxarray432_);
    mxDestroyArray(_mxarray430_);
    mxDestroyArray(_mxarray428_);
    mxDestroyArray(_mxarray426_);
    mxDestroyArray(_mxarray424_);
    mxDestroyArray(_mxarray422_);
    mxDestroyArray(_mxarray420_);
    mxDestroyArray(_mxarray419_);
    mxDestroyArray(_mxarray417_);
    mxDestroyArray(_mxarray414_);
    mxDestroyArray(_mxarray415_);
    mxDestroyArray(_mxarray412_);
    mxDestroyArray(_mxarray410_);
    mxDestroyArray(_mxarray408_);
    mxDestroyArray(_mxarray406_);
    mxDestroyArray(_mxarray404_);
    mxDestroyArray(_mxarray402_);
    mxDestroyArray(_mxarray400_);
    mxDestroyArray(_mxarray398_);
    mxDestroyArray(_mxarray396_);
    mxDestroyArray(_mxarray394_);
    mxDestroyArray(_mxarray392_);
    mxDestroyArray(_mxarray390_);
    mxDestroyArray(_mxarray388_);
    mxDestroyArray(_mxarray386_);
    mxDestroyArray(_mxarray384_);
    mxDestroyArray(_mxarray382_);
    mxDestroyArray(_mxarray379_);
    mxDestroyArray(_mxarray380_);
    mxDestroyArray(_mxarray377_);
    mxDestroyArray(_mxarray374_);
    mxDestroyArray(_mxarray375_);
    mxDestroyArray(_mxarray372_);
    mxDestroyArray(_mxarray370_);
    mxDestroyArray(_mxarray368_);
    mxDestroyArray(_mxarray366_);
    mxDestroyArray(_mxarray364_);
    mxDestroyArray(_mxarray362_);
    mxDestroyArray(_mxarray360_);
    mxDestroyArray(_mxarray358_);
    mxDestroyArray(_mxarray356_);
    mxDestroyArray(_mxarray354_);
    mxDestroyArray(_mxarray352_);
    mxDestroyArray(_mxarray350_);
    mxDestroyArray(_mxarray348_);
    mxDestroyArray(_mxarray346_);
    mxDestroyArray(_mxarray344_);
    mxDestroyArray(_mxarray342_);
    mxDestroyArray(_mxarray340_);
    mxDestroyArray(_mxarray338_);
    mxDestroyArray(_mxarray336_);
    mxDestroyArray(_mxarray334_);
    mxDestroyArray(_mxarray332_);
    mxDestroyArray(_mxarray330_);
    mxDestroyArray(_mxarray328_);
    mxDestroyArray(_mxarray327_);
    mxDestroyArray(_mxarray325_);
    mxDestroyArray(_mxarray322_);
    mxDestroyArray(_mxarray323_);
    mxDestroyArray(_mxarray320_);
    mxDestroyArray(_mxarray318_);
    mxDestroyArray(_mxarray316_);
    mxDestroyArray(_mxarray314_);
    mxDestroyArray(_mxarray312_);
    mxDestroyArray(_mxarray310_);
    mxDestroyArray(_mxarray308_);
    mxDestroyArray(_mxarray306_);
    mxDestroyArray(_mxarray304_);
    mxDestroyArray(_mxarray302_);
    mxDestroyArray(_mxarray300_);
    mxDestroyArray(_mxarray298_);
    mxDestroyArray(_mxarray296_);
    mxDestroyArray(_mxarray294_);
    mxDestroyArray(_mxarray292_);
    mxDestroyArray(_mxarray290_);
    mxDestroyArray(_mxarray288_);
    mxDestroyArray(_mxarray286_);
    mxDestroyArray(_mxarray284_);
    mxDestroyArray(_mxarray282_);
    mxDestroyArray(_mxarray280_);
    mxDestroyArray(_mxarray278_);
    mxDestroyArray(_mxarray276_);
    mxDestroyArray(_mxarray274_);
    mxDestroyArray(_mxarray272_);
    mxDestroyArray(_mxarray270_);
    mxDestroyArray(_mxarray268_);
    mxDestroyArray(_mxarray266_);
    mxDestroyArray(_mxarray264_);
    mxDestroyArray(_mxarray262_);
    mxDestroyArray(_mxarray260_);
    mxDestroyArray(_mxarray258_);
    mxDestroyArray(_mxarray256_);
    mxDestroyArray(_mxarray254_);
    mxDestroyArray(_mxarray252_);
    mxDestroyArray(_mxarray250_);
    mxDestroyArray(_mxarray248_);
    mxDestroyArray(_mxarray247_);
    mxDestroyArray(_mxarray246_);
    mxDestroyArray(_mxarray245_);
    mxDestroyArray(_mxarray244_);
    mxDestroyArray(_mxarray242_);
    mxDestroyArray(_mxarray240_);
    mxDestroyArray(_mxarray238_);
    mxDestroyArray(_mxarray236_);
    mxDestroyArray(_mxarray234_);
    mxDestroyArray(_mxarray232_);
    mxDestroyArray(_mxarray230_);
    mxDestroyArray(_mxarray227_);
    mxDestroyArray(_mxarray228_);
    mxDestroyArray(_mxarray225_);
    mxDestroyArray(_mxarray223_);
    mxDestroyArray(_mxarray221_);
    mxDestroyArray(_mxarray220_);
    mxDestroyArray(_mxarray218_);
    mxDestroyArray(_mxarray216_);
    mxDestroyArray(_mxarray214_);
    mxDestroyArray(_mxarray212_);
    mxDestroyArray(_mxarray210_);
    mxDestroyArray(_mxarray208_);
    mxDestroyArray(_mxarray206_);
    mxDestroyArray(_mxarray204_);
    mxDestroyArray(_mxarray202_);
    mxDestroyArray(_mxarray200_);
    mxDestroyArray(_mxarray198_);
    mxDestroyArray(_mxarray196_);
    mxDestroyArray(_mxarray194_);
    mxDestroyArray(_mxarray192_);
    mxDestroyArray(_mxarray190_);
    mxDestroyArray(_mxarray188_);
    mxDestroyArray(_mxarray186_);
    mxDestroyArray(_mxarray185_);
    mxDestroyArray(_mxarray184_);
    mxDestroyArray(_mxarray183_);
    mxDestroyArray(_mxarray181_);
    mxDestroyArray(_mxarray179_);
    mxDestroyArray(_mxarray177_);
    mxDestroyArray(_mxarray175_);
    mxDestroyArray(_mxarray173_);
    mxDestroyArray(_mxarray171_);
    mxDestroyArray(_mxarray170_);
    mxDestroyArray(_mxarray169_);
    mxDestroyArray(_mxarray168_);
    mxDestroyArray(_mxarray166_);
    mxDestroyArray(_mxarray164_);
    mxDestroyArray(_mxarray162_);
    mxDestroyArray(_mxarray160_);
    mxDestroyArray(_mxarray158_);
    mxDestroyArray(_mxarray157_);
    mxDestroyArray(_mxarray155_);
    mxDestroyArray(_mxarray153_);
    mxDestroyArray(_mxarray151_);
    mxDestroyArray(_mxarray149_);
    mxDestroyArray(_mxarray147_);
    mxDestroyArray(_mxarray145_);
    mxDestroyArray(_mxarray143_);
    mxDestroyArray(_mxarray140_);
    mxDestroyArray(_mxarray141_);
    mxDestroyArray(_mxarray138_);
    mxDestroyArray(_mxarray135_);
    mxDestroyArray(_mxarray136_);
    mxDestroyArray(_mxarray133_);
    mxDestroyArray(_mxarray131_);
    mxDestroyArray(_mxarray129_);
    mxDestroyArray(_mxarray130_);
    mxDestroyArray(_mxarray127_);
    mxDestroyArray(_mxarray125_);
    mxDestroyArray(_mxarray123_);
    mxDestroyArray(_mxarray121_);
    mxDestroyArray(_mxarray119_);
    mxDestroyArray(_mxarray116_);
    mxDestroyArray(_mxarray117_);
    mxDestroyArray(_mxarray114_);
    mxDestroyArray(_mxarray112_);
    mxDestroyArray(_mxarray111_);
    mxDestroyArray(_mxarray110_);
    mxDestroyArray(_mxarray108_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray104_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray100_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray96_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray92_);
    mxDestroyArray(_mxarray90_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray88_);
    mxDestroyArray(_mxarray86_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static void mlfWatermark005_watermark005_OpeningFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles,
                                                    ...);
static void mlxWatermark005_watermark005_OpeningFcn(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static mxArray * mlfWatermark005_watermark005_OutputFcn(mlfVarargoutList * varargout,
                                                        mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxWatermark005_watermark005_OutputFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]);
static void mlfWatermark005_pushbuttonOpenOriginal_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxWatermark005_pushbuttonOpenOriginal_Callback(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfWatermark005_pushbuttonOpenWatermark_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void mlxWatermark005_pushbuttonOpenWatermark_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSize_CreateFcn(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void mlxWatermark005_popupmenuBlockSize_CreateFcn(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSize_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxWatermark005_popupmenuBlockSize_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]);
static void mlfWatermark005_pushbuttonAddWatermark_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxWatermark005_pushbuttonAddWatermark_Callback(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfWatermark005_pushbuttonExtract_Callback(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles);
static void mlxWatermark005_pushbuttonExtract_Callback(int nlhs,
                                                       mxArray * plhs[],
                                                       int nrhs,
                                                       mxArray * prhs[]);
static void mlfWatermark005_pushbuttonSaveImageWithWatermark_Callback(mxArray * hObject,
                                                                      mxArray * eventdata,
                                                                      mxArray * handles);
static void mlxWatermark005_pushbuttonSaveImageWithWatermark_Callback(int nlhs,
                                                                      mxArray * plhs[],
                                                                      int nrhs,
                                                                      mxArray * prhs[]);
static void mlfWatermark005_pushbuttonSaveExtracted_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void mlxWatermark005_pushbuttonSaveExtracted_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]);
static void mlfWatermark005_pushbuttonOpenImageWithWatermark_Callback(mxArray * hObject,
                                                                      mxArray * eventdata,
                                                                      mxArray * handles);
static void mlxWatermark005_pushbuttonOpenImageWithWatermark_Callback(int nlhs,
                                                                      mxArray * plhs[],
                                                                      int nrhs,
                                                                      mxArray * prhs[]);
static void mlfWatermark005_pushbuttonCrop_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_pushbuttonCrop_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_pushbuttonResize_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_pushbuttonResize_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_pushbuttonFilter_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_pushbuttonFilter_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_pushbuttonRotate_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_pushbuttonRotate_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_pushbuttonShowRealOriginal_Callback(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles);
static void mlxWatermark005_pushbuttonShowRealOriginal_Callback(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]);
static void mlfWatermark005_pushbuttonJPEGCompression_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles);
static void mlxWatermark005_pushbuttonJPEGCompression_Callback(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]);
static void mlfWatermark005_pushbuttonShowRealWatermark_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles);
static void mlxWatermark005_pushbuttonShowRealWatermark_Callback(int nlhs,
                                                                 mxArray * plhs[],
                                                                 int nrhs,
                                                                 mxArray * prhs[]);
static void mlfWatermark005_pushbuttonShowRealImageWithWatermark_Callback(mxArray * hObject,
                                                                          mxArray * eventdata,
                                                                          mxArray * handles);
static void mlxWatermark005_pushbuttonShowRealImageWithWatermark_Callback(int nlhs,
                                                                          mxArray * plhs[],
                                                                          int nrhs,
                                                                          mxArray * prhs[]);
static void mlfWatermark005_pushbuttonShowRealExtract_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles);
static void mlxWatermark005_pushbuttonShowRealExtract_Callback(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]);
static void mlfWatermark005_pushbuttonExit_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_pushbuttonExit_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_radiobuttonDefualt_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxWatermark005_radiobuttonDefualt_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]);
static void mlfWatermark005_popupmenuAttackMethod_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxWatermark005_popupmenuAttackMethod_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfWatermark005_popupmenuAttackMethod_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void mlxWatermark005_popupmenuAttackMethod_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static void mlfWatermark005_pushbuttonOriginal_info_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void mlxWatermark005_pushbuttonOriginal_info_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]);
static void mlfWatermark005_pushbuttonWatermark_info_Callback(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles);
static void mlxWatermark005_pushbuttonWatermark_info_Callback(int nlhs,
                                                              mxArray * plhs[],
                                                              int nrhs,
                                                              mxArray * prhs[]);
static void mlfWatermark005_pushbuttonImageWithWatermark_info_Callback(mxArray * hObject,
                                                                       mxArray * eventdata,
                                                                       mxArray * handles);
static void mlxWatermark005_pushbuttonImageWithWatermark_info_Callback(int nlhs,
                                                                       mxArray * plhs[],
                                                                       int nrhs,
                                                                       mxArray * prhs[]);
static void mlfWatermark005_pushbuttonExtractedWatermark_info_Callback(mxArray * hObject,
                                                                       mxArray * eventdata,
                                                                       mxArray * handles);
static void mlxWatermark005_pushbuttonExtractedWatermark_info_Callback(int nlhs,
                                                                       mxArray * plhs[],
                                                                       int nrhs,
                                                                       mxArray * prhs[]);
static void mlfWatermark005_pushbuttonPSNR_MSE_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxWatermark005_pushbuttonPSNR_MSE_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]);
static void mlfWatermark005_pushbuttonSimilarity_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void mlxWatermark005_pushbuttonSimilarity_Callback(int nlhs,
                                                          mxArray * plhs[],
                                                          int nrhs,
                                                          mxArray * prhs[]);
static void mlfWatermark005_pushbuttonClearAll_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxWatermark005_pushbuttonClearAll_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]);
static void mlfWatermark005_imageInformation(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles);
static void mlxWatermark005_imageInformation(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static void mlfWatermark005_imageWatermarkInformation(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_imageWatermarkInformation(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_imageExtractInformation(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_imageExtractInformation(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_pushbuttonOpenExtractedImage_Callback(mxArray * hObject,
                                                                  mxArray * eventdata,
                                                                  mxArray * handles);
static void mlxWatermark005_pushbuttonOpenExtractedImage_Callback(int nlhs,
                                                                  mxArray * plhs[],
                                                                  int nrhs,
                                                                  mxArray * prhs[]);
static void mlfWatermark005_pushbuttonSaveAttackwatermark_Callback(mxArray * hObject,
                                                                   mxArray * eventdata,
                                                                   mxArray * handles);
static void mlxWatermark005_pushbuttonSaveAttackwatermark_Callback(int nlhs,
                                                                   mxArray * plhs[],
                                                                   int nrhs,
                                                                   mxArray * prhs[]);
static void mlfWatermark005_disOpenImage(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles);
static void mlxWatermark005_disOpenImage(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static void mlfWatermark005_disAddWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_disAddWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_disExtWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_disExtWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_disUtilityAttackWatermark(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_disUtilityAttackWatermark(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_disUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles);
static void mlxWatermark005_disUtilityAttackExceptSaveWatermark(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]);
static void mlfWatermark005_disUtilityMainWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_disUtilityMainWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_disInfoOriginal(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_disInfoOriginal(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_disInfoWatermark(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles);
static void mlxWatermark005_disInfoWatermark(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static void mlfWatermark005_disInfoImageWithWatermrk(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles);
static void mlxWatermark005_disInfoImageWithWatermrk(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]);
static void mlfWatermark005_disInfoExtractWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_disInfoExtractWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_EnaOpenImage(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles);
static void mlxWatermark005_EnaOpenImage(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]);
static void mlfWatermark005_EnaAddWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_EnaAddWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_EnaExtWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_EnaExtWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_EnaUtilityAttackWatermark(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void mlxWatermark005_EnaUtilityAttackWatermark(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]);
static void mlfWatermark005_EnaUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles);
static void mlxWatermark005_EnaUtilityAttackExceptSaveWatermark(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]);
static void mlfWatermark005_EnaUtilityMainWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_EnaUtilityMainWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_EnaInfoOriginal(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles);
static void mlxWatermark005_EnaInfoOriginal(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]);
static void mlfWatermark005_EnaInfoWatermark(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles);
static void mlxWatermark005_EnaInfoWatermark(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]);
static void mlfWatermark005_EnaInfoImageWithWatermrk(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles);
static void mlxWatermark005_EnaInfoImageWithWatermrk(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]);
static void mlfWatermark005_EnaInfoExtractWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void mlxWatermark005_EnaInfoExtractWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]);
static void mlfWatermark005_startAgain(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles);
static void mlxWatermark005_startAgain(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSizeAdd_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxWatermark005_popupmenuBlockSizeAdd_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSizeAdd_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void mlxWatermark005_popupmenuBlockSizeAdd_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSizeExt_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void mlxWatermark005_popupmenuBlockSizeExt_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static void mlfWatermark005_popupmenuBlockSizeExt_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void mlxWatermark005_popupmenuBlockSizeExt_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static mxArray * Mwatermark005(int nargout_, mxArray * varargin);
static void Mwatermark005_watermark005_OpeningFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles,
                                                  mxArray * varargin);
static mxArray * Mwatermark005_watermark005_OutputFcn(int nargout_,
                                                      mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void Mwatermark005_pushbuttonOpenOriginal_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mwatermark005_pushbuttonOpenWatermark_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void Mwatermark005_popupmenuBlockSize_CreateFcn(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles);
static void Mwatermark005_popupmenuBlockSize_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void Mwatermark005_pushbuttonAddWatermark_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mwatermark005_pushbuttonExtract_Callback(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles);
static void Mwatermark005_pushbuttonSaveImageWithWatermark_Callback(mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles);
static void Mwatermark005_pushbuttonSaveExtracted_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void Mwatermark005_pushbuttonOpenImageWithWatermark_Callback(mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles);
static void Mwatermark005_pushbuttonCrop_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_pushbuttonResize_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_pushbuttonFilter_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_pushbuttonRotate_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_pushbuttonShowRealOriginal_Callback(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles);
static void Mwatermark005_pushbuttonJPEGCompression_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void Mwatermark005_pushbuttonShowRealWatermark_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles);
static void Mwatermark005_pushbuttonShowRealImageWithWatermark_Callback(mxArray * hObject,
                                                                        mxArray * eventdata,
                                                                        mxArray * handles);
static void Mwatermark005_pushbuttonShowRealExtract_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles);
static void Mwatermark005_pushbuttonExit_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_radiobuttonDefualt_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void Mwatermark005_popupmenuAttackMethod_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mwatermark005_popupmenuAttackMethod_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void Mwatermark005_pushbuttonOriginal_info_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles);
static void Mwatermark005_pushbuttonWatermark_info_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles);
static void Mwatermark005_pushbuttonImageWithWatermark_info_Callback(mxArray * hObject,
                                                                     mxArray * eventdata,
                                                                     mxArray * handles);
static void Mwatermark005_pushbuttonExtractedWatermark_info_Callback(mxArray * hObject,
                                                                     mxArray * eventdata,
                                                                     mxArray * handles);
static void Mwatermark005_pushbuttonPSNR_MSE_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void Mwatermark005_pushbuttonSimilarity_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void Mwatermark005_pushbuttonClearAll_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);
static void Mwatermark005_imageInformation(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void Mwatermark005_imageWatermarkInformation(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_imageExtractInformation(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_pushbuttonOpenExtractedImage_Callback(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles);
static void Mwatermark005_pushbuttonSaveAttackwatermark_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles);
static void Mwatermark005_disOpenImage(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles);
static void Mwatermark005_disAddWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_disExtWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_disUtilityAttackWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_disUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles);
static void Mwatermark005_disUtilityMainWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_disInfoOriginal(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_disInfoWatermark(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void Mwatermark005_disInfoImageWithWatermrk(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void Mwatermark005_disInfoExtractWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_EnaOpenImage(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles);
static void Mwatermark005_EnaAddWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_EnaExtWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_EnaUtilityAttackWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles);
static void Mwatermark005_EnaUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles);
static void Mwatermark005_EnaUtilityMainWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_EnaInfoOriginal(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles);
static void Mwatermark005_EnaInfoWatermark(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles);
static void Mwatermark005_EnaInfoImageWithWatermrk(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles);
static void Mwatermark005_EnaInfoExtractWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles);
static void Mwatermark005_startAgain(mxArray * hObject,
                                     mxArray * eventdata,
                                     mxArray * handles);
static void Mwatermark005_popupmenuBlockSizeAdd_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mwatermark005_popupmenuBlockSizeAdd_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void Mwatermark005_popupmenuBlockSizeExt_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles);
static void Mwatermark005_popupmenuBlockSizeExt_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);

static mexFunctionTableEntry local_function_table_[61]
  = { { "watermark005_OpeningFcn",
        mlxWatermark005_watermark005_OpeningFcn, -4, 0, NULL },
      { "watermark005_OutputFcn",
        mlxWatermark005_watermark005_OutputFcn, 3, -1, NULL },
      { "pushbuttonOpenOriginal_Callback",
        mlxWatermark005_pushbuttonOpenOriginal_Callback, 3, 0, NULL },
      { "pushbuttonOpenWatermark_Callback",
        mlxWatermark005_pushbuttonOpenWatermark_Callback, 3, 0, NULL },
      { "popupmenuBlockSize_CreateFcn",
        mlxWatermark005_popupmenuBlockSize_CreateFcn, 3, 0, NULL },
      { "popupmenuBlockSize_Callback",
        mlxWatermark005_popupmenuBlockSize_Callback, 3, 0, NULL },
      { "pushbuttonAddWatermark_Callback",
        mlxWatermark005_pushbuttonAddWatermark_Callback, 3, 0, NULL },
      { "pushbuttonExtract_Callback",
        mlxWatermark005_pushbuttonExtract_Callback, 3, 0, NULL },
      { "pushbuttonSaveImageWithWatermark_Callback",
        mlxWatermark005_pushbuttonSaveImageWithWatermark_Callback,
        3, 0, NULL },
      { "pushbuttonSaveExtracted_Callback",
        mlxWatermark005_pushbuttonSaveExtracted_Callback, 3, 0, NULL },
      { "pushbuttonOpenImageWithWatermark_Callback",
        mlxWatermark005_pushbuttonOpenImageWithWatermark_Callback,
        3, 0, NULL },
      { "pushbuttonCrop_Callback",
        mlxWatermark005_pushbuttonCrop_Callback, 3, 0, NULL },
      { "pushbuttonResize_Callback",
        mlxWatermark005_pushbuttonResize_Callback, 3, 0, NULL },
      { "pushbuttonFilter_Callback",
        mlxWatermark005_pushbuttonFilter_Callback, 3, 0, NULL },
      { "pushbuttonRotate_Callback",
        mlxWatermark005_pushbuttonRotate_Callback, 3, 0, NULL },
      { "pushbuttonShowRealOriginal_Callback",
        mlxWatermark005_pushbuttonShowRealOriginal_Callback, 3, 0, NULL },
      { "pushbuttonJPEGCompression_Callback",
        mlxWatermark005_pushbuttonJPEGCompression_Callback, 3, 0, NULL },
      { "pushbuttonShowRealWatermark_Callback",
        mlxWatermark005_pushbuttonShowRealWatermark_Callback, 3, 0, NULL },
      { "pushbuttonShowRealImageWithWatermark_Callback",
        mlxWatermark005_pushbuttonShowRealImageWithWatermark_Callback,
        3, 0, NULL },
      { "pushbuttonShowRealExtract_Callback",
        mlxWatermark005_pushbuttonShowRealExtract_Callback, 3, 0, NULL },
      { "pushbuttonExit_Callback",
        mlxWatermark005_pushbuttonExit_Callback, 3, 0, NULL },
      { "radiobuttonDefualt_Callback",
        mlxWatermark005_radiobuttonDefualt_Callback, 3, 0, NULL },
      { "popupmenuAttackMethod_CreateFcn",
        mlxWatermark005_popupmenuAttackMethod_CreateFcn, 3, 0, NULL },
      { "popupmenuAttackMethod_Callback",
        mlxWatermark005_popupmenuAttackMethod_Callback, 3, 0, NULL },
      { "pushbuttonOriginal_info_Callback",
        mlxWatermark005_pushbuttonOriginal_info_Callback, 3, 0, NULL },
      { "pushbuttonWatermark_info_Callback",
        mlxWatermark005_pushbuttonWatermark_info_Callback, 3, 0, NULL },
      { "pushbuttonImageWithWatermark_info_Callback",
        mlxWatermark005_pushbuttonImageWithWatermark_info_Callback,
        3, 0, NULL },
      { "pushbuttonExtractedWatermark_info_Callback",
        mlxWatermark005_pushbuttonExtractedWatermark_info_Callback,
        3, 0, NULL },
      { "pushbuttonPSNR_MSE_Callback",
        mlxWatermark005_pushbuttonPSNR_MSE_Callback, 3, 0, NULL },
      { "pushbuttonSimilarity_Callback",
        mlxWatermark005_pushbuttonSimilarity_Callback, 3, 0, NULL },
      { "pushbuttonClearAll_Callback",
        mlxWatermark005_pushbuttonClearAll_Callback, 3, 0, NULL },
      { "imageInformation", mlxWatermark005_imageInformation, 3, 0, NULL },
      { "imageWatermarkInformation",
        mlxWatermark005_imageWatermarkInformation, 3, 0, NULL },
      { "imageExtractInformation",
        mlxWatermark005_imageExtractInformation, 3, 0, NULL },
      { "pushbuttonOpenExtractedImage_Callback",
        mlxWatermark005_pushbuttonOpenExtractedImage_Callback, 3, 0, NULL },
      { "pushbuttonSaveAttackwatermark_Callback",
        mlxWatermark005_pushbuttonSaveAttackwatermark_Callback, 3, 0, NULL },
      { "disOpenImage", mlxWatermark005_disOpenImage, 3, 0, NULL },
      { "disAddWatermark", mlxWatermark005_disAddWatermark, 3, 0, NULL },
      { "disExtWatermark", mlxWatermark005_disExtWatermark, 3, 0, NULL },
      { "disUtilityAttackWatermark",
        mlxWatermark005_disUtilityAttackWatermark, 3, 0, NULL },
      { "disUtilityAttackExceptSaveWatermark",
        mlxWatermark005_disUtilityAttackExceptSaveWatermark, 3, 0, NULL },
      { "disUtilityMainWatermark",
        mlxWatermark005_disUtilityMainWatermark, 3, 0, NULL },
      { "disInfoOriginal", mlxWatermark005_disInfoOriginal, 3, 0, NULL },
      { "disInfoWatermark", mlxWatermark005_disInfoWatermark, 3, 0, NULL },
      { "disInfoImageWithWatermrk",
        mlxWatermark005_disInfoImageWithWatermrk, 3, 0, NULL },
      { "disInfoExtractWatermark",
        mlxWatermark005_disInfoExtractWatermark, 3, 0, NULL },
      { "EnaOpenImage", mlxWatermark005_EnaOpenImage, 3, 0, NULL },
      { "EnaAddWatermark", mlxWatermark005_EnaAddWatermark, 3, 0, NULL },
      { "EnaExtWatermark", mlxWatermark005_EnaExtWatermark, 3, 0, NULL },
      { "EnaUtilityAttackWatermark",
        mlxWatermark005_EnaUtilityAttackWatermark, 3, 0, NULL },
      { "EnaUtilityAttackExceptSaveWatermark",
        mlxWatermark005_EnaUtilityAttackExceptSaveWatermark, 3, 0, NULL },
      { "EnaUtilityMainWatermark",
        mlxWatermark005_EnaUtilityMainWatermark, 3, 0, NULL },
      { "EnaInfoOriginal", mlxWatermark005_EnaInfoOriginal, 3, 0, NULL },
      { "EnaInfoWatermark", mlxWatermark005_EnaInfoWatermark, 3, 0, NULL },
      { "EnaInfoImageWithWatermrk",
        mlxWatermark005_EnaInfoImageWithWatermrk, 3, 0, NULL },
      { "EnaInfoExtractWatermark",
        mlxWatermark005_EnaInfoExtractWatermark, 3, 0, NULL },
      { "startAgain", mlxWatermark005_startAgain, 3, 0, NULL },
      { "popupmenuBlockSizeAdd_CreateFcn",
        mlxWatermark005_popupmenuBlockSizeAdd_CreateFcn, 3, 0, NULL },
      { "popupmenuBlockSizeAdd_Callback",
        mlxWatermark005_popupmenuBlockSizeAdd_Callback, 3, 0, NULL },
      { "popupmenuBlockSizeExt_CreateFcn",
        mlxWatermark005_popupmenuBlockSizeExt_CreateFcn, 3, 0, NULL },
      { "popupmenuBlockSizeExt_Callback",
        mlxWatermark005_popupmenuBlockSizeExt_Callback, 3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_watermark005
  = { 61, local_function_table_ };

/*
 * The function "mlfNWatermark005" contains the nargout interface for the
 * "watermark005" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\watermark005.m" (lines 1-48). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNWatermark005(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mwatermark005(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfWatermark005" contains the normal interface for the
 * "watermark005" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\watermark005.m" (lines 1-48). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfWatermark005(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mwatermark005(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVWatermark005" contains the void interface for the
 * "watermark005" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\watermark005.m" (lines 1-48). The void
 * interface is only produced if the M-function uses the special variable
 * "nargout", and has at least one output. The void interface function
 * specifies zero output arguments to the implementation version of the
 * function, and in the event that the implementation version still returns an
 * output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVWatermark005(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mwatermark005(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxWatermark005" contains the feval interface for the
 * "watermark005" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\watermark005.m" (lines 1-48). The feval
 * function calls the implementation version of watermark005 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxWatermark005(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mwatermark005(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfWatermark005_watermark005_OpeningFcn" contains the normal
 * interface for the "watermark005/watermark005_OpeningFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 48-112). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_watermark005_OpeningFcn(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles,
                                                    ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, hObject, eventdata, handles, varargin);
    Mwatermark005_watermark005_OpeningFcn(
      hObject, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxWatermark005_watermark005_OpeningFcn" contains the feval
 * interface for the "watermark005/watermark005_OpeningFcn" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 48-112). The feval function calls the
 * implementation version of watermark005/watermark005_OpeningFcn through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_watermark005_OpeningFcn(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/watermark005_OpeningFcn Line: 4"
            "8 Column: 1 The function \"watermark005/watermark005_OpeningFcn\" "
            "was called with more than the declared number of outputs (0)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    Mwatermark005_watermark005_OpeningFcn(
      mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfWatermark005_watermark005_OutputFcn" contains the normal
 * interface for the "watermark005/watermark005_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 112-123). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static mxArray * mlfWatermark005_watermark005_OutputFcn(mlfVarargoutList * varargout,
                                                        mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    int nargout = 0;
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mwatermark005_watermark005_OutputFcn(
          nargout, hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxWatermark005_watermark005_OutputFcn" contains the feval
 * interface for the "watermark005/watermark005_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 112-123). The feval function calls the
 * implementation version of watermark005/watermark005_OutputFcn through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_watermark005_OutputFcn(int nlhs,
                                                   mxArray * plhs[],
                                                   int nrhs,
                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/watermark005_OutputFcn Line: 1"
            "12 Column: 1 The function \"watermark005/watermark005_OutputFcn\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0]
      = Mwatermark005_watermark005_OutputFcn(
          nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonOpenOriginal_Callback" contains the
 * normal interface for the "watermark005/pushbuttonOpenOriginal_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 123-180). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonOpenOriginal_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonOpenOriginal_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonOpenOriginal_Callback" contains the
 * feval interface for the "watermark005/pushbuttonOpenOriginal_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 123-180). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonOpenOriginal_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonOpenOriginal_Callback(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenOrig"
            "inal_Callback Line: 123 Column: 1 The function \"wate"
            "rmark005/pushbuttonOpenOriginal_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenOrig"
            "inal_Callback Line: 123 Column: 1 The function \"wate"
            "rmark005/pushbuttonOpenOriginal_Callback\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonOpenOriginal_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonOpenWatermark_Callback" contains the
 * normal interface for the "watermark005/pushbuttonOpenWatermark_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 180-227). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonOpenWatermark_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonOpenWatermark_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonOpenWatermark_Callback" contains the
 * feval interface for the "watermark005/pushbuttonOpenWatermark_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 180-227). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonOpenWatermark_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonOpenWatermark_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenWater"
            "mark_Callback Line: 180 Column: 1 The function \"water"
            "mark005/pushbuttonOpenWatermark_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenWater"
            "mark_Callback Line: 180 Column: 1 The function \"water"
            "mark005/pushbuttonOpenWatermark_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonOpenWatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSize_CreateFcn" contains the
 * normal interface for the "watermark005/popupmenuBlockSize_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 227-243). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSize_CreateFcn(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSize_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSize_CreateFcn" contains the
 * feval interface for the "watermark005/popupmenuBlockSize_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 227-243). The feval function
 * calls the implementation version of
 * watermark005/popupmenuBlockSize_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSize_CreateFcn(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSiz"
            "e_CreateFcn Line: 227 Column: 1 The function \"water"
            "mark005/popupmenuBlockSize_CreateFcn\" was called wi"
            "th more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSiz"
            "e_CreateFcn Line: 227 Column: 1 The function \"water"
            "mark005/popupmenuBlockSize_CreateFcn\" was called wi"
            "th more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSize_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSize_Callback" contains the
 * normal interface for the "watermark005/popupmenuBlockSize_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 243-300). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSize_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSize_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSize_Callback" contains the
 * feval interface for the "watermark005/popupmenuBlockSize_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 243-300). The feval function
 * calls the implementation version of watermark005/popupmenuBlockSize_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSize_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSi"
            "ze_Callback Line: 243 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSize_Callback\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSi"
            "ze_Callback Line: 243 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSize_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSize_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonAddWatermark_Callback" contains the
 * normal interface for the "watermark005/pushbuttonAddWatermark_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 300-679). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonAddWatermark_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonAddWatermark_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonAddWatermark_Callback" contains the
 * feval interface for the "watermark005/pushbuttonAddWatermark_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 300-679). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonAddWatermark_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonAddWatermark_Callback(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonAddWater"
            "mark_Callback Line: 300 Column: 1 The function \"wate"
            "rmark005/pushbuttonAddWatermark_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonAddWater"
            "mark_Callback Line: 300 Column: 1 The function \"wate"
            "rmark005/pushbuttonAddWatermark_Callback\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonAddWatermark_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonExtract_Callback" contains the
 * normal interface for the "watermark005/pushbuttonExtract_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 679-992). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonExtract_Callback(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonExtract_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonExtract_Callback" contains the feval
 * interface for the "watermark005/pushbuttonExtract_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 679-992). The feval function calls the
 * implementation version of watermark005/pushbuttonExtract_Callback through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonExtract_Callback(int nlhs,
                                                       mxArray * plhs[],
                                                       int nrhs,
                                                       mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExtrac"
            "t_Callback Line: 679 Column: 1 The function \"water"
            "mark005/pushbuttonExtract_Callback\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExtrac"
            "t_Callback Line: 679 Column: 1 The function \"water"
            "mark005/pushbuttonExtract_Callback\" was called wit"
            "h more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonExtract_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonSaveImageWithWatermark_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonSaveImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 992-1023). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonSaveImageWithWatermark_Callback(mxArray * hObject,
                                                                      mxArray * eventdata,
                                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonSaveImageWithWatermark_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonSaveImageWithWatermark_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonSaveImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 992-1023). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonSaveImageWithWatermark_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonSaveImageWithWatermark_Callback(int nlhs,
                                                                      mxArray * plhs[],
                                                                      int nrhs,
                                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveImageWith"
            "Watermark_Callback Line: 992 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveImageWithWatermark_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveImageWith"
            "Watermark_Callback Line: 992 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveImageWithWatermark_Callback\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonSaveImageWithWatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonSaveExtracted_Callback" contains the
 * normal interface for the "watermark005/pushbuttonSaveExtracted_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1023-1062). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonSaveExtracted_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonSaveExtracted_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonSaveExtracted_Callback" contains the
 * feval interface for the "watermark005/pushbuttonSaveExtracted_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1023-1062). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonSaveExtracted_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonSaveExtracted_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveExtra"
            "cted_Callback Line: 1023 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveExtracted_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveExtra"
            "cted_Callback Line: 1023 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveExtracted_Callback\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonSaveExtracted_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonOpenImageWithWatermark_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonOpenImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1062-1145). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonOpenImageWithWatermark_Callback(mxArray * hObject,
                                                                      mxArray * eventdata,
                                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonOpenImageWithWatermark_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonOpenImageWithWatermark_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonOpenImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1062-1145). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonOpenImageWithWatermark_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonOpenImageWithWatermark_Callback(int nlhs,
                                                                      mxArray * plhs[],
                                                                      int nrhs,
                                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenImageWithW"
            "atermark_Callback Line: 1062 Column: 1 The function \"water"
            "mark005/pushbuttonOpenImageWithWatermark_Callback\" was cal"
            "led with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenImageWith"
            "Watermark_Callback Line: 1062 Column: 1 The function \"wat"
            "ermark005/pushbuttonOpenImageWithWatermark_Callback\" was "
            "called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonOpenImageWithWatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonCrop_Callback" contains the normal
 * interface for the "watermark005/pushbuttonCrop_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1145-1251). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonCrop_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonCrop_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonCrop_Callback" contains the feval
 * interface for the "watermark005/pushbuttonCrop_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1145-1251). The feval function calls the
 * implementation version of watermark005/pushbuttonCrop_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonCrop_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonCrop_Callback Line: 1"
            "145 Column: 1 The function \"watermark005/pushbuttonCrop_Callback"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonCrop_Callback Line: 1"
            "145 Column: 1 The function \"watermark005/pushbuttonCrop_Callback"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonCrop_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonResize_Callback" contains the normal
 * interface for the "watermark005/pushbuttonResize_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1251-1366). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonResize_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonResize_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonResize_Callback" contains the feval
 * interface for the "watermark005/pushbuttonResize_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1251-1366). The feval function calls the
 * implementation version of watermark005/pushbuttonResize_Callback through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonResize_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonResize"
            "_Callback Line: 1251 Column: 1 The function \"water"
            "mark005/pushbuttonResize_Callback\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonResiz"
            "e_Callback Line: 1251 Column: 1 The function \"wat"
            "ermark005/pushbuttonResize_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonResize_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonFilter_Callback" contains the normal
 * interface for the "watermark005/pushbuttonFilter_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1366-1448). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonFilter_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonFilter_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonFilter_Callback" contains the feval
 * interface for the "watermark005/pushbuttonFilter_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1366-1448). The feval function calls the
 * implementation version of watermark005/pushbuttonFilter_Callback through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonFilter_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonFilter"
            "_Callback Line: 1366 Column: 1 The function \"water"
            "mark005/pushbuttonFilter_Callback\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonFilte"
            "r_Callback Line: 1366 Column: 1 The function \"wat"
            "ermark005/pushbuttonFilter_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonFilter_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonRotate_Callback" contains the normal
 * interface for the "watermark005/pushbuttonRotate_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1448-1561). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonRotate_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonRotate_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonRotate_Callback" contains the feval
 * interface for the "watermark005/pushbuttonRotate_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1448-1561). The feval function calls the
 * implementation version of watermark005/pushbuttonRotate_Callback through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonRotate_Callback(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonRotate"
            "_Callback Line: 1448 Column: 1 The function \"water"
            "mark005/pushbuttonRotate_Callback\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonRotat"
            "e_Callback Line: 1448 Column: 1 The function \"wat"
            "ermark005/pushbuttonRotate_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonRotate_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonShowRealOriginal_Callback" contains
 * the normal interface for the
 * "watermark005/pushbuttonShowRealOriginal_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1561-1571). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonShowRealOriginal_Callback(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonShowRealOriginal_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonShowRealOriginal_Callback" contains
 * the feval interface for the
 * "watermark005/pushbuttonShowRealOriginal_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1561-1571). The feval function calls the
 * implementation version of watermark005/pushbuttonShowRealOriginal_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonShowRealOriginal_Callback(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealOri"
            "ginal_Callback Line: 1561 Column: 1 The function \"water"
            "mark005/pushbuttonShowRealOriginal_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealOr"
            "iginal_Callback Line: 1561 Column: 1 The function \"wat"
            "ermark005/pushbuttonShowRealOriginal_Callback\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonShowRealOriginal_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonJPEGCompression_Callback" contains
 * the normal interface for the
 * "watermark005/pushbuttonJPEGCompression_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1571-1687). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonJPEGCompression_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonJPEGCompression_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonJPEGCompression_Callback" contains
 * the feval interface for the
 * "watermark005/pushbuttonJPEGCompression_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1571-1687). The feval function calls the
 * implementation version of watermark005/pushbuttonJPEGCompression_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonJPEGCompression_Callback(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonJPEGCompre"
            "ssion_Callback Line: 1571 Column: 1 The function \"wate"
            "rmark005/pushbuttonJPEGCompression_Callback\" was calle"
            "d with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonJPEGCompre"
            "ssion_Callback Line: 1571 Column: 1 The function \"wate"
            "rmark005/pushbuttonJPEGCompression_Callback\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonJPEGCompression_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonShowRealWatermark_Callback" contains
 * the normal interface for the
 * "watermark005/pushbuttonShowRealWatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1687-1696). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonShowRealWatermark_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonShowRealWatermark_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonShowRealWatermark_Callback" contains
 * the feval interface for the
 * "watermark005/pushbuttonShowRealWatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1687-1696). The feval function calls the
 * implementation version of watermark005/pushbuttonShowRealWatermark_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonShowRealWatermark_Callback(int nlhs,
                                                                 mxArray * plhs[],
                                                                 int nrhs,
                                                                 mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealWat"
            "ermark_Callback Line: 1687 Column: 1 The function \"wate"
            "rmark005/pushbuttonShowRealWatermark_Callback\" was call"
            "ed with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealWat"
            "ermark_Callback Line: 1687 Column: 1 The function \"wate"
            "rmark005/pushbuttonShowRealWatermark_Callback\" was call"
            "ed with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonShowRealWatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonShowRealImageWithWatermark_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonShowRealImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1696-1704). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonShowRealImageWithWatermark_Callback(mxArray * hObject,
                                                                          mxArray * eventdata,
                                                                          mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonShowRealImageWithWatermark_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonShowRealImageWithWatermark_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonShowRealImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1696-1704). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonShowRealImageWithWatermark_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonShowRealImageWithWatermark_Callback(int nlhs,
                                                                          mxArray * plhs[],
                                                                          int nrhs,
                                                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealImageWit"
            "hWatermark_Callback Line: 1696 Column: 1 The function \"water"
            "mark005/pushbuttonShowRealImageWithWatermark_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealImageWi"
            "thWatermark_Callback Line: 1696 Column: 1 The function \"wat"
            "ermark005/pushbuttonShowRealImageWithWatermark_Callback\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonShowRealImageWithWatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonShowRealExtract_Callback" contains
 * the normal interface for the
 * "watermark005/pushbuttonShowRealExtract_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1704-1711). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonShowRealExtract_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonShowRealExtract_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonShowRealExtract_Callback" contains
 * the feval interface for the
 * "watermark005/pushbuttonShowRealExtract_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1704-1711). The feval function calls the
 * implementation version of watermark005/pushbuttonShowRealExtract_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonShowRealExtract_Callback(int nlhs,
                                                               mxArray * plhs[],
                                                               int nrhs,
                                                               mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealEx"
            "tract_Callback Line: 1704 Column: 1 The function \"wate"
            "rmark005/pushbuttonShowRealExtract_Callback\" was calle"
            "d with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonShowRealEx"
            "tract_Callback Line: 1704 Column: 1 The function \"wate"
            "rmark005/pushbuttonShowRealExtract_Callback\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonShowRealExtract_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonExit_Callback" contains the normal
 * interface for the "watermark005/pushbuttonExit_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1711-1727). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonExit_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonExit_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonExit_Callback" contains the feval
 * interface for the "watermark005/pushbuttonExit_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1711-1727). The feval function calls the
 * implementation version of watermark005/pushbuttonExit_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonExit_Callback(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExit_Callback Line: 1"
            "711 Column: 1 The function \"watermark005/pushbuttonExit_Callback"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExit_Callback Line: 1"
            "711 Column: 1 The function \"watermark005/pushbuttonExit_Callback"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonExit_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_radiobuttonDefualt_Callback" contains the
 * normal interface for the "watermark005/radiobuttonDefualt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1727-1736). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_radiobuttonDefualt_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_radiobuttonDefualt_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_radiobuttonDefualt_Callback" contains the
 * feval interface for the "watermark005/radiobuttonDefualt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1727-1736). The feval function
 * calls the implementation version of watermark005/radiobuttonDefualt_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_radiobuttonDefualt_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/radiobuttonDefual"
            "t_Callback Line: 1727 Column: 1 The function \"water"
            "mark005/radiobuttonDefualt_Callback\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/radiobuttonDefua"
            "lt_Callback Line: 1727 Column: 1 The function \"wat"
            "ermark005/radiobuttonDefualt_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_radiobuttonDefualt_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuAttackMethod_CreateFcn" contains the
 * normal interface for the "watermark005/popupmenuAttackMethod_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1736-1754). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuAttackMethod_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuAttackMethod_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuAttackMethod_CreateFcn" contains the
 * feval interface for the "watermark005/popupmenuAttackMethod_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1736-1754). The feval function
 * calls the implementation version of
 * watermark005/popupmenuAttackMethod_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuAttackMethod_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuAttackMeth"
            "od_CreateFcn Line: 1736 Column: 1 The function \"water"
            "mark005/popupmenuAttackMethod_CreateFcn\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuAttackMet"
            "hod_CreateFcn Line: 1736 Column: 1 The function \"wat"
            "ermark005/popupmenuAttackMethod_CreateFcn\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuAttackMethod_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuAttackMethod_Callback" contains the
 * normal interface for the "watermark005/popupmenuAttackMethod_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1754-1786). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuAttackMethod_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuAttackMethod_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuAttackMethod_Callback" contains the
 * feval interface for the "watermark005/popupmenuAttackMethod_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1754-1786). The feval function
 * calls the implementation version of
 * watermark005/popupmenuAttackMethod_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuAttackMethod_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuAttackMet"
            "hod_Callback Line: 1754 Column: 1 The function \"wate"
            "rmark005/popupmenuAttackMethod_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuAttackMet"
            "hod_Callback Line: 1754 Column: 1 The function \"wate"
            "rmark005/popupmenuAttackMethod_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuAttackMethod_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonOriginal_info_Callback" contains the
 * normal interface for the "watermark005/pushbuttonOriginal_info_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1786-1799). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonOriginal_info_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonOriginal_info_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonOriginal_info_Callback" contains the
 * feval interface for the "watermark005/pushbuttonOriginal_info_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1786-1799). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonOriginal_info_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonOriginal_info_Callback(int nlhs,
                                                             mxArray * plhs[],
                                                             int nrhs,
                                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOriginal_"
            "info_Callback Line: 1786 Column: 1 The function \"wate"
            "rmark005/pushbuttonOriginal_info_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOriginal_"
            "info_Callback Line: 1786 Column: 1 The function \"wate"
            "rmark005/pushbuttonOriginal_info_Callback\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonOriginal_info_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonWatermark_info_Callback" contains
 * the normal interface for the
 * "watermark005/pushbuttonWatermark_info_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1799-1813). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonWatermark_info_Callback(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonWatermark_info_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonWatermark_info_Callback" contains
 * the feval interface for the "watermark005/pushbuttonWatermark_info_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1799-1813). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonWatermark_info_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonWatermark_info_Callback(int nlhs,
                                                              mxArray * plhs[],
                                                              int nrhs,
                                                              mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonWatermark_"
            "info_Callback Line: 1799 Column: 1 The function \"water"
            "mark005/pushbuttonWatermark_info_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonWatermark"
            "_info_Callback Line: 1799 Column: 1 The function \"wat"
            "ermark005/pushbuttonWatermark_info_Callback\" was call"
            "ed with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonWatermark_info_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonImageWithWatermark_info_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonImageWithWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1813-1828). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonImageWithWatermark_info_Callback(mxArray * hObject,
                                                                       mxArray * eventdata,
                                                                       mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonImageWithWatermark_info_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonImageWithWatermark_info_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonImageWithWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1813-1828). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonImageWithWatermark_info_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonImageWithWatermark_info_Callback(int nlhs,
                                                                       mxArray * plhs[],
                                                                       int nrhs,
                                                                       mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonImageWithWater"
            "mark_info_Callback Line: 1813 Column: 1 The function \"wate"
            "rmark005/pushbuttonImageWithWatermark_info_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonImageWithWater"
            "mark_info_Callback Line: 1813 Column: 1 The function \"wate"
            "rmark005/pushbuttonImageWithWatermark_info_Callback\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonImageWithWatermark_info_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonExtractedWatermark_info_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonExtractedWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1828-1842). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonExtractedWatermark_info_Callback(mxArray * hObject,
                                                                       mxArray * eventdata,
                                                                       mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonExtractedWatermark_info_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonExtractedWatermark_info_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonExtractedWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1828-1842). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonExtractedWatermark_info_Callback through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonExtractedWatermark_info_Callback(int nlhs,
                                                                       mxArray * plhs[],
                                                                       int nrhs,
                                                                       mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExtractedWater"
            "mark_info_Callback Line: 1828 Column: 1 The function \"wate"
            "rmark005/pushbuttonExtractedWatermark_info_Callback\" was c"
            "alled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonExtractedWater"
            "mark_info_Callback Line: 1828 Column: 1 The function \"wate"
            "rmark005/pushbuttonExtractedWatermark_info_Callback\" was c"
            "alled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonExtractedWatermark_info_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonPSNR_MSE_Callback" contains the
 * normal interface for the "watermark005/pushbuttonPSNR_MSE_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1842-1866). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonPSNR_MSE_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonPSNR_MSE_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonPSNR_MSE_Callback" contains the
 * feval interface for the "watermark005/pushbuttonPSNR_MSE_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1842-1866). The feval function
 * calls the implementation version of watermark005/pushbuttonPSNR_MSE_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonPSNR_MSE_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonPSNR_MS"
            "E_Callback Line: 1842 Column: 1 The function \"water"
            "mark005/pushbuttonPSNR_MSE_Callback\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonPSNR_M"
            "SE_Callback Line: 1842 Column: 1 The function \"wat"
            "ermark005/pushbuttonPSNR_MSE_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonPSNR_MSE_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonSimilarity_Callback" contains the
 * normal interface for the "watermark005/pushbuttonSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1866-1885). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonSimilarity_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonSimilarity_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonSimilarity_Callback" contains the
 * feval interface for the "watermark005/pushbuttonSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1866-1885). The feval function
 * calls the implementation version of
 * watermark005/pushbuttonSimilarity_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonSimilarity_Callback(int nlhs,
                                                          mxArray * plhs[],
                                                          int nrhs,
                                                          mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSimilari"
            "ty_Callback Line: 1866 Column: 1 The function \"water"
            "mark005/pushbuttonSimilarity_Callback\" was called wi"
            "th more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSimilar"
            "ity_Callback Line: 1866 Column: 1 The function \"wat"
            "ermark005/pushbuttonSimilarity_Callback\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonSimilarity_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonClearAll_Callback" contains the
 * normal interface for the "watermark005/pushbuttonClearAll_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1885-2015). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_pushbuttonClearAll_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonClearAll_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonClearAll_Callback" contains the
 * feval interface for the "watermark005/pushbuttonClearAll_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1885-2015). The feval function
 * calls the implementation version of watermark005/pushbuttonClearAll_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonClearAll_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonClearAl"
            "l_Callback Line: 1885 Column: 1 The function \"water"
            "mark005/pushbuttonClearAll_Callback\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonClearA"
            "ll_Callback Line: 1885 Column: 1 The function \"wat"
            "ermark005/pushbuttonClearAll_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonClearAll_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_imageInformation" contains the normal
 * interface for the "watermark005/imageInformation" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2015-2046). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_imageInformation(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_imageInformation(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_imageInformation" contains the feval interface
 * for the "watermark005/imageInformation" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2015-2046). The feval function calls the
 * implementation version of watermark005/imageInformation through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_imageInformation(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageInformation Line: 201"
            "5 Column: 1 The function \"watermark005/imageInformation\" wa"
            "s called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageInformation Line: 201"
            "5 Column: 1 The function \"watermark005/imageInformation\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_imageInformation(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_imageWatermarkInformation" contains the normal
 * interface for the "watermark005/imageWatermarkInformation" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2046-2128). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_imageWatermarkInformation(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_imageWatermarkInformation(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_imageWatermarkInformation" contains the feval
 * interface for the "watermark005/imageWatermarkInformation" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2046-2128). The feval function calls the
 * implementation version of watermark005/imageWatermarkInformation through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_imageWatermarkInformation(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageWatermarkIn"
            "formation Line: 2046 Column: 1 The function \"water"
            "mark005/imageWatermarkInformation\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageWatermarkI"
            "nformation Line: 2046 Column: 1 The function \"wat"
            "ermark005/imageWatermarkInformation\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_imageWatermarkInformation(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_imageExtractInformation" contains the normal
 * interface for the "watermark005/imageExtractInformation" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2128-2174). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_imageExtractInformation(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_imageExtractInformation(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_imageExtractInformation" contains the feval
 * interface for the "watermark005/imageExtractInformation" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2128-2174). The feval function calls the
 * implementation version of watermark005/imageExtractInformation through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_imageExtractInformation(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageExtractInformation Line: 2"
            "128 Column: 2 The function \"watermark005/imageExtractInformation"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/imageExtractInformation Line: 2"
            "128 Column: 2 The function \"watermark005/imageExtractInformation"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_imageExtractInformation(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonOpenExtractedImage_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonOpenExtractedImage_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2174-2209). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonOpenExtractedImage_Callback(mxArray * hObject,
                                                                  mxArray * eventdata,
                                                                  mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonOpenExtractedImage_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonOpenExtractedImage_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonOpenExtractedImage_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2174-2209). The feval function calls the
 * implementation version of watermark005/pushbuttonOpenExtractedImage_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonOpenExtractedImage_Callback(int nlhs,
                                                                  mxArray * plhs[],
                                                                  int nrhs,
                                                                  mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenExtracte"
            "dImage_Callback Line: 2174 Column: 1 The function \"water"
            "mark005/pushbuttonOpenExtractedImage_Callback\" was calle"
            "d with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonOpenExtract"
            "edImage_Callback Line: 2174 Column: 1 The function \"wat"
            "ermark005/pushbuttonOpenExtractedImage_Callback\" was ca"
            "lled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonOpenExtractedImage_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_pushbuttonSaveAttackwatermark_Callback"
 * contains the normal interface for the
 * "watermark005/pushbuttonSaveAttackwatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2209-2248). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_pushbuttonSaveAttackwatermark_Callback(mxArray * hObject,
                                                                   mxArray * eventdata,
                                                                   mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_pushbuttonSaveAttackwatermark_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_pushbuttonSaveAttackwatermark_Callback"
 * contains the feval interface for the
 * "watermark005/pushbuttonSaveAttackwatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2209-2248). The feval function calls the
 * implementation version of
 * watermark005/pushbuttonSaveAttackwatermark_Callback through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_pushbuttonSaveAttackwatermark_Callback(int nlhs,
                                                                   mxArray * plhs[],
                                                                   int nrhs,
                                                                   mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveAttackwa"
            "termark_Callback Line: 2209 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveAttackwatermark_Callback\" was cal"
            "led with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/pushbuttonSaveAttackwa"
            "termark_Callback Line: 2209 Column: 1 The function \"wate"
            "rmark005/pushbuttonSaveAttackwatermark_Callback\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_pushbuttonSaveAttackwatermark_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disOpenImage" contains the normal interface
 * for the "watermark005/disOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2248-2262). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disOpenImage(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disOpenImage(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disOpenImage" contains the feval interface for
 * the "watermark005/disOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2248-2262). The feval function calls the
 * implementation version of watermark005/disOpenImage through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disOpenImage(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disOpenImage Line: 2248 "
            "Column: 1 The function \"watermark005/disOpenImage\" was ca"
            "lled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disOpenImage Line: 2248"
            " Column: 1 The function \"watermark005/disOpenImage\" was "
            "called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disOpenImage(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disAddWatermark" contains the normal interface
 * for the "watermark005/disAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2262-2278). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disAddWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disAddWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disAddWatermark" contains the feval interface
 * for the "watermark005/disAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2262-2278). The feval function calls the
 * implementation version of watermark005/disAddWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disAddWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disAddWatermark Line: 2262"
            " Column: 1 The function \"watermark005/disAddWatermark\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disAddWatermark Line: 226"
            "2 Column: 1 The function \"watermark005/disAddWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disAddWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disExtWatermark" contains the normal interface
 * for the "watermark005/disExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2278-2298). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disExtWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disExtWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disExtWatermark" contains the feval interface
 * for the "watermark005/disExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2278-2298). The feval function calls the
 * implementation version of watermark005/disExtWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disExtWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disExtWatermark Line: 2278"
            " Column: 1 The function \"watermark005/disExtWatermark\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disExtWatermark Line: 227"
            "8 Column: 1 The function \"watermark005/disExtWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disExtWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disUtilityAttackWatermark" contains the normal
 * interface for the "watermark005/disUtilityAttackWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2298-2317). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disUtilityAttackWatermark(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disUtilityAttackWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disUtilityAttackWatermark" contains the feval
 * interface for the "watermark005/disUtilityAttackWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2298-2317). The feval function calls the
 * implementation version of watermark005/disUtilityAttackWatermark through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_disUtilityAttackWatermark(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityAttack"
            "Watermark Line: 2298 Column: 1 The function \"water"
            "mark005/disUtilityAttackWatermark\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityAttac"
            "kWatermark Line: 2298 Column: 1 The function \"wat"
            "ermark005/disUtilityAttackWatermark\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disUtilityAttackWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disUtilityAttackExceptSaveWatermark" contains
 * the normal interface for the
 * "watermark005/disUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2317-2333). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disUtilityAttackExceptSaveWatermark(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disUtilityAttackExceptSaveWatermark" contains
 * the feval interface for the
 * "watermark005/disUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2317-2333). The feval function calls the
 * implementation version of watermark005/disUtilityAttackExceptSaveWatermark
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_disUtilityAttackExceptSaveWatermark(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityAttackExcep"
            "tSaveWatermark Line: 2317 Column: 1 The function \"water"
            "mark005/disUtilityAttackExceptSaveWatermark\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityAttackExce"
            "ptSaveWatermark Line: 2317 Column: 1 The function \"wat"
            "ermark005/disUtilityAttackExceptSaveWatermark\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disUtilityAttackExceptSaveWatermark(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disUtilityMainWatermark" contains the normal
 * interface for the "watermark005/disUtilityMainWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2333-2350). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disUtilityMainWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disUtilityMainWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disUtilityMainWatermark" contains the feval
 * interface for the "watermark005/disUtilityMainWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2333-2350). The feval function calls the
 * implementation version of watermark005/disUtilityMainWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disUtilityMainWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityMainWatermark Line: 2"
            "333 Column: 1 The function \"watermark005/disUtilityMainWatermark"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disUtilityMainWatermark Line: 2"
            "333 Column: 1 The function \"watermark005/disUtilityMainWatermark"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disUtilityMainWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disInfoOriginal" contains the normal interface
 * for the "watermark005/disInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2350-2357). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disInfoOriginal(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disInfoOriginal(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disInfoOriginal" contains the feval interface
 * for the "watermark005/disInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2350-2357). The feval function calls the
 * implementation version of watermark005/disInfoOriginal through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disInfoOriginal(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoOriginal Line: 2350"
            " Column: 1 The function \"watermark005/disInfoOriginal\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoOriginal Line: 235"
            "0 Column: 1 The function \"watermark005/disInfoOriginal\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disInfoOriginal(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disInfoWatermark" contains the normal
 * interface for the "watermark005/disInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2357-2365). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disInfoWatermark(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disInfoWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disInfoWatermark" contains the feval interface
 * for the "watermark005/disInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2357-2365). The feval function calls the
 * implementation version of watermark005/disInfoWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disInfoWatermark(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoWatermark Line: 235"
            "7 Column: 1 The function \"watermark005/disInfoWatermark\" wa"
            "s called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoWatermark Line: 235"
            "7 Column: 1 The function \"watermark005/disInfoWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disInfoWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disInfoImageWithWatermrk" contains the normal
 * interface for the "watermark005/disInfoImageWithWatermrk" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2365-2373). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disInfoImageWithWatermrk(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disInfoImageWithWatermrk(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disInfoImageWithWatermrk" contains the feval
 * interface for the "watermark005/disInfoImageWithWatermrk" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2365-2373). The feval function calls the
 * implementation version of watermark005/disInfoImageWithWatermrk through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disInfoImageWithWatermrk(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoImageWit"
            "hWatermrk Line: 2365 Column: 1 The function \"wate"
            "rmark005/disInfoImageWithWatermrk\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoImageWithWatermrk Line: "
            "2365 Column: 1 The function \"watermark005/disInfoImageWithWatermr"
            "k\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disInfoImageWithWatermrk(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_disInfoExtractWatermark" contains the normal
 * interface for the "watermark005/disInfoExtractWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2373-2384). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_disInfoExtractWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_disInfoExtractWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_disInfoExtractWatermark" contains the feval
 * interface for the "watermark005/disInfoExtractWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2373-2384). The feval function calls the
 * implementation version of watermark005/disInfoExtractWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_disInfoExtractWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoExtractWatermark Line: 2"
            "373 Column: 1 The function \"watermark005/disInfoExtractWatermark"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/disInfoExtractWatermark Line: 2"
            "373 Column: 1 The function \"watermark005/disInfoExtractWatermark"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_disInfoExtractWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaOpenImage" contains the normal interface
 * for the "watermark005/EnaOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2384-2399). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaOpenImage(mxArray * hObject,
                                         mxArray * eventdata,
                                         mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaOpenImage(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaOpenImage" contains the feval interface for
 * the "watermark005/EnaOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2384-2399). The feval function calls the
 * implementation version of watermark005/EnaOpenImage through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaOpenImage(int nlhs,
                                         mxArray * plhs[],
                                         int nrhs,
                                         mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaOpenImage Line: 2384 "
            "Column: 1 The function \"watermark005/EnaOpenImage\" was ca"
            "lled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaOpenImage Line: 2384"
            " Column: 1 The function \"watermark005/EnaOpenImage\" was "
            "called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaOpenImage(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaAddWatermark" contains the normal interface
 * for the "watermark005/EnaAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2399-2413). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaAddWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaAddWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaAddWatermark" contains the feval interface
 * for the "watermark005/EnaAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2399-2413). The feval function calls the
 * implementation version of watermark005/EnaAddWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaAddWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaAddWatermark Line: 2399"
            " Column: 1 The function \"watermark005/EnaAddWatermark\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaAddWatermark Line: 239"
            "9 Column: 1 The function \"watermark005/EnaAddWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaAddWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaExtWatermark" contains the normal interface
 * for the "watermark005/EnaExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2413-2428). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaExtWatermark(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaExtWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaExtWatermark" contains the feval interface
 * for the "watermark005/EnaExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2413-2428). The feval function calls the
 * implementation version of watermark005/EnaExtWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaExtWatermark(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaExtWatermark Line: 2413"
            " Column: 1 The function \"watermark005/EnaExtWatermark\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaExtWatermark Line: 241"
            "3 Column: 1 The function \"watermark005/EnaExtWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaExtWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaUtilityAttackWatermark" contains the normal
 * interface for the "watermark005/EnaUtilityAttackWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2428-2447). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaUtilityAttackWatermark(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaUtilityAttackWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaUtilityAttackWatermark" contains the feval
 * interface for the "watermark005/EnaUtilityAttackWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2428-2447). The feval function calls the
 * implementation version of watermark005/EnaUtilityAttackWatermark through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaUtilityAttackWatermark(int nlhs,
                                                      mxArray * plhs[],
                                                      int nrhs,
                                                      mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityAttack"
            "Watermark Line: 2428 Column: 1 The function \"water"
            "mark005/EnaUtilityAttackWatermark\" was called with"
            " more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityAttac"
            "kWatermark Line: 2428 Column: 1 The function \"wat"
            "ermark005/EnaUtilityAttackWatermark\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaUtilityAttackWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaUtilityAttackExceptSaveWatermark" contains
 * the normal interface for the
 * "watermark005/EnaUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2447-2463). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaUtilityAttackExceptSaveWatermark(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaUtilityAttackExceptSaveWatermark" contains
 * the feval interface for the
 * "watermark005/EnaUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2447-2463). The feval function calls the
 * implementation version of watermark005/EnaUtilityAttackExceptSaveWatermark
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaUtilityAttackExceptSaveWatermark(int nlhs,
                                                                mxArray * plhs[],
                                                                int nrhs,
                                                                mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityAttackExcep"
            "tSaveWatermark Line: 2447 Column: 1 The function \"water"
            "mark005/EnaUtilityAttackExceptSaveWatermark\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityAttackExce"
            "ptSaveWatermark Line: 2447 Column: 1 The function \"wat"
            "ermark005/EnaUtilityAttackExceptSaveWatermark\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaUtilityAttackExceptSaveWatermark(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaUtilityMainWatermark" contains the normal
 * interface for the "watermark005/EnaUtilityMainWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2463-2480). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaUtilityMainWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaUtilityMainWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaUtilityMainWatermark" contains the feval
 * interface for the "watermark005/EnaUtilityMainWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2463-2480). The feval function calls the
 * implementation version of watermark005/EnaUtilityMainWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaUtilityMainWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityMainWatermark Line: 2"
            "463 Column: 1 The function \"watermark005/EnaUtilityMainWatermark"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaUtilityMainWatermark Line: 2"
            "463 Column: 1 The function \"watermark005/EnaUtilityMainWatermark"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaUtilityMainWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaInfoOriginal" contains the normal interface
 * for the "watermark005/EnaInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2480-2487). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaInfoOriginal(mxArray * hObject,
                                            mxArray * eventdata,
                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaInfoOriginal(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaInfoOriginal" contains the feval interface
 * for the "watermark005/EnaInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2480-2487). The feval function calls the
 * implementation version of watermark005/EnaInfoOriginal through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaInfoOriginal(int nlhs,
                                            mxArray * plhs[],
                                            int nrhs,
                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoOriginal Line: 2480"
            " Column: 1 The function \"watermark005/EnaInfoOriginal\" was "
            "called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoOriginal Line: 248"
            "0 Column: 1 The function \"watermark005/EnaInfoOriginal\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaInfoOriginal(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaInfoWatermark" contains the normal
 * interface for the "watermark005/EnaInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2487-2495). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaInfoWatermark(mxArray * hObject,
                                             mxArray * eventdata,
                                             mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaInfoWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaInfoWatermark" contains the feval interface
 * for the "watermark005/EnaInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2487-2495). The feval function calls the
 * implementation version of watermark005/EnaInfoWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaInfoWatermark(int nlhs,
                                             mxArray * plhs[],
                                             int nrhs,
                                             mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoWatermark Line: 248"
            "7 Column: 1 The function \"watermark005/EnaInfoWatermark\" wa"
            "s called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoWatermark Line: 248"
            "7 Column: 1 The function \"watermark005/EnaInfoWatermark\" wa"
            "s called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaInfoWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaInfoImageWithWatermrk" contains the normal
 * interface for the "watermark005/EnaInfoImageWithWatermrk" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2495-2503). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaInfoImageWithWatermrk(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaInfoImageWithWatermrk(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaInfoImageWithWatermrk" contains the feval
 * interface for the "watermark005/EnaInfoImageWithWatermrk" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2495-2503). The feval function calls the
 * implementation version of watermark005/EnaInfoImageWithWatermrk through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaInfoImageWithWatermrk(int nlhs,
                                                     mxArray * plhs[],
                                                     int nrhs,
                                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoImageWit"
            "hWatermrk Line: 2495 Column: 1 The function \"wate"
            "rmark005/EnaInfoImageWithWatermrk\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoImageWithWatermrk Line: "
            "2495 Column: 1 The function \"watermark005/EnaInfoImageWithWatermr"
            "k\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaInfoImageWithWatermrk(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_EnaInfoExtractWatermark" contains the normal
 * interface for the "watermark005/EnaInfoExtractWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2503-2512). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_EnaInfoExtractWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_EnaInfoExtractWatermark(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_EnaInfoExtractWatermark" contains the feval
 * interface for the "watermark005/EnaInfoExtractWatermark" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2503-2512). The feval function calls the
 * implementation version of watermark005/EnaInfoExtractWatermark through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_EnaInfoExtractWatermark(int nlhs,
                                                    mxArray * plhs[],
                                                    int nrhs,
                                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoExtractWatermark Line: 2"
            "503 Column: 1 The function \"watermark005/EnaInfoExtractWatermark"
            "\" was called with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/EnaInfoExtractWatermark Line: 2"
            "503 Column: 1 The function \"watermark005/EnaInfoExtractWatermark"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_EnaInfoExtractWatermark(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_startAgain" contains the normal interface for
 * the "watermark005/startAgain" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2512-2528). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfWatermark005_startAgain(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_startAgain(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_startAgain" contains the feval interface for
 * the "watermark005/startAgain" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2512-2528). The feval function calls the
 * implementation version of watermark005/startAgain through this function.
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxWatermark005_startAgain(int nlhs,
                                       mxArray * plhs[],
                                       int nrhs,
                                       mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/startAgain Line: 2512 "
            "Column: 1 The function \"watermark005/startAgain\" was ca"
            "lled with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/startAgain Line: 2512 "
            "Column: 1 The function \"watermark005/startAgain\" was ca"
            "lled with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_startAgain(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSizeAdd_CreateFcn" contains the
 * normal interface for the "watermark005/popupmenuBlockSizeAdd_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2528-2543). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSizeAdd_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSizeAdd_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSizeAdd_CreateFcn" contains the
 * feval interface for the "watermark005/popupmenuBlockSizeAdd_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2528-2543). The feval function
 * calls the implementation version of
 * watermark005/popupmenuBlockSizeAdd_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSizeAdd_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSizeA"
            "dd_CreateFcn Line: 2528 Column: 1 The function \"water"
            "mark005/popupmenuBlockSizeAdd_CreateFcn\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Add_CreateFcn Line: 2528 Column: 1 The function \"wat"
            "ermark005/popupmenuBlockSizeAdd_CreateFcn\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSizeAdd_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSizeAdd_Callback" contains the
 * normal interface for the "watermark005/popupmenuBlockSizeAdd_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2543-2576). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSizeAdd_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSizeAdd_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSizeAdd_Callback" contains the
 * feval interface for the "watermark005/popupmenuBlockSizeAdd_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2543-2576). The feval function
 * calls the implementation version of
 * watermark005/popupmenuBlockSizeAdd_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSizeAdd_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Add_Callback Line: 2543 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSizeAdd_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Add_Callback Line: 2543 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSizeAdd_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSizeAdd_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSizeExt_CreateFcn" contains the
 * normal interface for the "watermark005/popupmenuBlockSizeExt_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2576-2591). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSizeExt_CreateFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSizeExt_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSizeExt_CreateFcn" contains the
 * feval interface for the "watermark005/popupmenuBlockSizeExt_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2576-2591). The feval function
 * calls the implementation version of
 * watermark005/popupmenuBlockSizeExt_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSizeExt_CreateFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSizeE"
            "xt_CreateFcn Line: 2576 Column: 1 The function \"water"
            "mark005/popupmenuBlockSizeExt_CreateFcn\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Ext_CreateFcn Line: 2576 Column: 1 The function \"wat"
            "ermark005/popupmenuBlockSizeExt_CreateFcn\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSizeExt_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfWatermark005_popupmenuBlockSizeExt_Callback" contains the
 * normal interface for the "watermark005/popupmenuBlockSizeExt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2591-2619). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfWatermark005_popupmenuBlockSizeExt_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mwatermark005_popupmenuBlockSizeExt_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxWatermark005_popupmenuBlockSizeExt_Callback" contains the
 * feval interface for the "watermark005/popupmenuBlockSizeExt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2591-2619). The feval function
 * calls the implementation version of
 * watermark005/popupmenuBlockSizeExt_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxWatermark005_popupmenuBlockSizeExt_Callback(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Ext_Callback Line: 2591 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSizeExt_Callback\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: watermark005/popupmenuBlockSize"
            "Ext_Callback Line: 2591 Column: 1 The function \"wate"
            "rmark005/popupmenuBlockSizeExt_Callback\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mwatermark005_popupmenuBlockSizeExt_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "Mwatermark005" is the implementation version of the
 * "watermark005" M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ
 * compile ���ѧ�����ź��� cpp h\watermark005.m" (lines 1-48). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function varargout = watermark005(varargin)
 */
static mxArray * Mwatermark005(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * _T0_ = NULL;
    mxArray * gui_State = NULL;
    mxArray * gui_Singleton = NULL;
    mclCopyArray(&varargin);
    /*
     * % WATERMARK005 M-file for watermark005.fig
     * %      WATERMARK005, by itself, creates a new WATERMARK005 or raises the existing
     * %      singleton*.
     * %
     * %      H = WATERMARK005 returns the handle to a new WATERMARK005 or the handle to
     * %      the existing singleton*.
     * %
     * %      WATERMARK005('CALLBACK',hObject,eventData,handles,...) calls the local
     * %      function named CALLBACK in WATERMARK005.M with the given input arguments.
     * %
     * %      WATERMARK005('Property','Value',...) creates a new WATERMARK005 or raises the
     * %      existing singleton*.  Starting from the left, property value pairs are
     * %      applied to the GUI before watermark005_OpeningFunction gets called.  An
     * %      unrecognized property name or invalid value makes property application
     * %      stop.  All inputs are passed to watermark005_OpeningFcn via varargin.
     * %
     * %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
     * %      instance to run (singleton)".
     * %
     * % See also: GUIDE, GUIDATA, GUIHANDLES
     * 
     * % Edit the above text to modify the response to help watermark005
     * 
     * % Last Modified by GUIDE v2.5 23-Mar-2004 16:16:50
     * 
     * % Begin initialization code - DO NOT EDIT
     * gui_Singleton = 1;
     */
    mlfAssign(&gui_Singleton, _mxarray0_);
    /*
     * gui_State = struct('gui_Name',       mfilename, ...
     */
    mlfAssign(
      &gui_State,
      mlfStruct(
        _mxarray1_,
        mxCreateString("watermark005"),
        _mxarray3_,
        mclVv(gui_Singleton, "gui_Singleton"),
        _mxarray5_,
        mclCreateSimpleFunctionHandle(
          mlxWatermark005_watermark005_OpeningFcn, "watermark005_OpeningFcn"),
        _mxarray7_,
        mclCreateSimpleFunctionHandle(
          mlxWatermark005_watermark005_OutputFcn, "watermark005_OutputFcn"),
        _mxarray9_,
        _mxarray11_,
        _mxarray12_,
        _mxarray11_,
        NULL));
    /*
     * 'gui_Singleton',  gui_Singleton, ...
     * 'gui_OpeningFcn', @watermark005_OpeningFcn, ...
     * 'gui_OutputFcn',  @watermark005_OutputFcn, ...
     * 'gui_LayoutFcn',  [] , ...
     * 'gui_Callback',   []);
     * if nargin & isstr(varargin{1})
     */
    {
        mxArray * a_ = mclInitialize(mlfScalar(nargin_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIsstr,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * gui_State.gui_Callback = str2func(varargin{1});
             */
            mlfIndexAssign(
              &gui_State,
              ".gui_Callback",
              mclFeval(
                mclValueVarargout(),
                mlxStr2func,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if nargout
     */
    if (nargout_ != 0) {
        mlfAssign(&_T0_, mlfColon(_mxarray0_, mlfScalar(nargout_), NULL));
        /*
         * [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
         */
        mlfNGui_mainfcn(
          0,
          mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
          mclVv(gui_State, "gui_State"),
          mlfIndexRef(
            mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
          NULL);
    /*
     * else
     */
    } else {
        /*
         * gui_mainfcn(gui_State, varargin{:});
         */
        mclAssignAns(
          &ans,
          mlfNGui_mainfcn(
            0,
            mclAnsVarargout(),
            mclVv(gui_State, "gui_State"),
            mlfIndexRef(
              mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(gui_Singleton);
    mxDestroyArray(gui_State);
    mxDestroyArray(_T0_);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * % End initialization code - DO NOT EDIT
     * 
     * 
     * % --- Executes just before watermark005 is made visible.
     */
}

/*
 * The function "Mwatermark005_watermark005_OpeningFcn" is the implementation
 * version of the "watermark005/watermark005_OpeningFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 48-112). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function watermark005_OpeningFcn(hObject, eventdata, handles, varargin)
 */
static void Mwatermark005_watermark005_OpeningFcn(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles,
                                                  mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * % This function has no output args, see OutputFcn.
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * % varargin   command line arguments to watermark005 (see VARARGIN)
     * 
     * % Choose default command line output for watermark005
     * handles.output = hObject;
     */
    mlfIndexAssign(&handles, ".output", mclVa(hObject, "hObject"));
    /*
     * %handles.temp_popupblocksize=2;% we add
     * 
     * % Update handles structure
     * %define my data for initialize
     * handles.bool_openOriginal=0;
     */
    mlfIndexAssign(&handles, ".bool_openOriginal", _mxarray14_);
    /*
     * handles.bool_openWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openWatermark", _mxarray14_);
    /*
     * handles.bool_openImageWithWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openImageWithWatermark", _mxarray14_);
    /*
     * handles.bool_openExtractWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openExtractWatermark", _mxarray14_);
    /*
     * 
     * %check attack method
     * handles.bool_cropAlready=0;
     */
    mlfIndexAssign(&handles, ".bool_cropAlready", _mxarray14_);
    /*
     * handles.bool_rotateAlready=0;
     */
    mlfIndexAssign(&handles, ".bool_rotateAlready", _mxarray14_);
    /*
     * handles.bool_filterAlready=0;
     */
    mlfIndexAssign(&handles, ".bool_filterAlready", _mxarray14_);
    /*
     * handles.bool_resizeAlready=0;
     */
    mlfIndexAssign(&handles, ".bool_resizeAlready", _mxarray14_);
    /*
     * handles.bool_JPEGAlready=0;
     */
    mlfIndexAssign(&handles, ".bool_JPEGAlready", _mxarray14_);
    /*
     * 
     * %check save image
     * handles.bool_addWatermarkSave=0;
     */
    mlfIndexAssign(&handles, ".bool_addWatermarkSave", _mxarray14_);
    /*
     * handles.bool_extractWatermarkSave=0;
     */
    mlfIndexAssign(&handles, ".bool_extractWatermarkSave", _mxarray14_);
    /*
     * handles.bool_AttackWatermarkSave=0;
     */
    mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
    /*
     * handles.bool_cropAttackSave=0;
     */
    mlfIndexAssign(&handles, ".bool_cropAttackSave", _mxarray14_);
    /*
     * handles.bool_rotateAttackSave=0;
     */
    mlfIndexAssign(&handles, ".bool_rotateAttackSave", _mxarray14_);
    /*
     * handles.bool_filterAttackSave=0;
     */
    mlfIndexAssign(&handles, ".bool_filterAttackSave", _mxarray14_);
    /*
     * handles.bool_resizeAttackSave=0;
     */
    mlfIndexAssign(&handles, ".bool_resizeAttackSave", _mxarray14_);
    /*
     * handles.bool_JPEGAttackSave=0;
     */
    mlfIndexAssign(&handles, ".bool_JPEGAttackSave", _mxarray14_);
    /*
     * %handles.current_filename1='';
     * %handles.current_filename3='';
     * 
     * 
     * %block size add
     * handles.temp_popupblocksizeAdd=1;
     */
    mlfIndexAssign(&handles, ".temp_popupblocksizeAdd", _mxarray0_);
    /*
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * %block size extracted
     * handles.temp_popupblocksizeExt=1;
     */
    mlfIndexAssign(&handles, ".temp_popupblocksizeExt", _mxarray0_);
    /*
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * 
     * 
     * %attack mode
     * handles.current_AttackMode='default';
     */
    mlfIndexAssign(&handles, ".current_AttackMode", _mxarray15_);
    /*
     * 
     * %sizeblock
     * handles.temp_popupblocksize=1;% we add for initial blocksize by defualt is 1
     */
    mlfIndexAssign(&handles, ".temp_popupblocksize", _mxarray0_);
    /*
     * 
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * % UIWAIT makes watermark005 wait for user response (see UIRESUME)
     * % uiwait(handles.figure1);
     * 
     * 
     * % --- Outputs from this function are returned to the command line.
     */
}

/*
 * The function "Mwatermark005_watermark005_OutputFcn" is the implementation
 * version of the "watermark005/watermark005_OutputFcn" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 112-123). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function varargout = watermark005_OutputFcn(hObject, eventdata, handles)
 */
static mxArray * Mwatermark005_watermark005_OutputFcn(int nargout_,
                                                      mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * varargout = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % varargout  cell array for returning output args (see VARARGOUT);
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Get default command line output from handles structure
     * varargout{1} = handles.output;
     */
    mlfIndexAssign(
      &varargout,
      "{?}",
      _mxarray0_,
      mlfIndexRef(mclVa(handles, "handles"), ".output"));
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * 
     * % --- Executes on button press in pushbuttonOpenOriginal.
     */
}

/*
 * The function "Mwatermark005_pushbuttonOpenOriginal_Callback" is the
 * implementation version of the "watermark005/pushbuttonOpenOriginal_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 123-180). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonOpenOriginal_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonOpenOriginal_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * image_x1 = NULL;
    mxArray * temp_path1 = NULL;
    mxArray * ans = NULL;
    mxArray * pathname1 = NULL;
    mxArray * filename1 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonOpenOriginal (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * [filename1,pathname1]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
     */
    mlfAssign(
      &filename1,
      mlfUigetfile(&pathname1, _mxarray17_, _mxarray27_, NULL, NULL));
    /*
     * if isequal(filename1,0)|isequal(pathname1,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename1, "filename1"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname1, "pathname1"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File not Open...Please try again.');
             */
            mlfDisp(_mxarray29_);
            /*
             * handles.bool_openOriginal=0;%Not open origianl image 
             */
            mlfIndexAssign(&handles, ".bool_openOriginal", _mxarray14_);
            /*
             * return;
             */
            goto return_;
        /*
         * 
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>>File ', pathname1, filename1, ' have already openned'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray31_,
                mclVv(pathname1, "pathname1"),
                mclVv(filename1, "filename1"),
                _mxarray33_,
                NULL));
            /*
             * temp_path1=[pathname1 filename1];
             */
            mlfAssign(
              &temp_path1,
              mlfHorzcat(
                mclVv(pathname1, "pathname1"),
                mclVv(filename1, "filename1"),
                NULL));
            /*
             * handles.current_filename1 = temp_path1;
             */
            mlfIndexAssign(
              &handles, ".current_filename1", mclVv(temp_path1, "temp_path1"));
        }
    /*
     * end
     */
    }
    /*
     * 
     * image_x1=imread(handles.current_filename1);
     */
    mlfAssign(
      &image_x1,
      mlfNImread(
        1,
        NULL,
        NULL,
        mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"),
        NULL));
    /*
     * %handles.h_subplotOriginal=subplot('Position',[0.03 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(temp_path1),title(filename1);
     * handles.h_subplotOriginal=subplot('Position',[0.03 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x1),title(filename1);
     */
    mlfIndexAssign(
      &handles,
      ".h_subplotOriginal",
      mlfNSubplot(1, _mxarray35_, _mxarray37_, NULL, NULL));
    mclPrintArray(mclVa(handles, "handles"), "handles");
    mclPrintAns(
      &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
    mclPrintAns(&ans, mlfNImshow(0, mclVv(image_x1, "image_x1"), NULL));
    mclAssignAns(&ans, mlfNTitle(0, mclVv(filename1, "filename1"), NULL));
    /*
     * clc;
     */
    mlfClc();
    /*
     * 
     * handles.bool_openOriginal=1;%set open origianl image already
     */
    mlfIndexAssign(&handles, ".bool_openOriginal", _mxarray0_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%        set button active
     * 
     * %enable pushbuttonAddWatermark
     * if (handles.bool_openOriginal) &&(handles.bool_openWatermark)
     */
    if (mclScalarToBool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))
        && mclScalarToBool(
             mlfIndexRef(mclVa(handles, "handles"), ".bool_openWatermark"))) {
        /*
         * 
         * %Enaable pushbuttonAddWatermark
         * set(findobj('tag','pushbuttonAddWatermark'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray45_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %Enaable popupmenuBlockSizeAdd
         * set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray51_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * 
     * if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
     */
    if (mclScalarToBool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))
        && mclScalarToBool(
             mlfIndexRef(
               mclVa(handles, "handles"), ".bool_openImageWithWatermark"))) {
        /*
         * %enable pushbuttonExtract
         * set(findobj('tag','pushbuttonExtract'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray53_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable popupmenuAttackMethod
         * set(findobj('tag','popupmenuAttackMethod'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray55_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %Enaable popupmenuBlockSizeExt
         * set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray57_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * if (handles.bool_openOriginal)
     */
    if (mlfTobool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))) {
        /*
         * %enable pushbuttonOriginal_info
         * set(findobj('tag','pushbuttonOriginal_info'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray59_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * %enable pushbuttonShowRealOriginal
         * set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray61_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * % --- Executes on button press in pushbuttonOpenWatermark.
     */
    return_:
    mxDestroyArray(filename1);
    mxDestroyArray(pathname1);
    mxDestroyArray(ans);
    mxDestroyArray(temp_path1);
    mxDestroyArray(image_x1);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonOpenWatermark_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonOpenWatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 180-227). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function pushbuttonOpenWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonOpenWatermark_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * h_enablepushbuttonShowRealWatermark = NULL;
    mxArray * h_enablepushbuttonWatermark_info = NULL;
    mxArray * h_enablepushbuttonAddWatermark = NULL;
    mxArray * image_x2 = NULL;
    mxArray * ans = NULL;
    mxArray * temp_path2 = NULL;
    mxArray * pathname2 = NULL;
    mxArray * filename2 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonOpenWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %[filename2,pathname2]=uigetfile({'*.bmp','Bitmap(*.bmp)'},'Choose a file');
     * [filename2,pathname2]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
     */
    mlfAssign(
      &filename2,
      mlfUigetfile(&pathname2, _mxarray17_, _mxarray27_, NULL, NULL));
    /*
     * temp_path2=[pathname2 filename2];
     */
    mlfAssign(
      &temp_path2,
      mlfHorzcat(
        mclVv(pathname2, "pathname2"), mclVv(filename2, "filename2"), NULL));
    /*
     * if isequal(filename2,0)|isequal(pathname2,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename2, "filename2"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname2, "pathname2"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File not Open');
             */
            mlfDisp(_mxarray63_);
            /*
             * handles.bool_openWatermark=0;;%Not open watermark image
             */
            mlfIndexAssign(&handles, ".bool_openWatermark", _mxarray14_);
            /*
             * return;
             */
            goto return_;
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>>File ', pathname2, filename2, ' have already openned'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray31_,
                mclVv(pathname2, "pathname2"),
                mclVv(filename2, "filename2"),
                _mxarray33_,
                NULL));
            /*
             * temp_path2=[pathname2 filename2];
             */
            mlfAssign(
              &temp_path2,
              mlfHorzcat(
                mclVv(pathname2, "pathname2"),
                mclVv(filename2, "filename2"),
                NULL));
            /*
             * handles.current_filename2 = temp_path2;
             */
            mlfIndexAssign(
              &handles, ".current_filename2", mclVv(temp_path2, "temp_path2"));
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * image_x2=imread(handles.current_filename2);
     */
    mlfAssign(
      &image_x2,
      mlfNImread(
        1,
        NULL,
        NULL,
        mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"),
        NULL));
    /*
     * %handles.h_subplotWatermark=subplot('Position',[0.35 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(temp_path2),title(filename2);
     * handles.h_subplotWatermark=subplot('Position',[0.35 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x2),title(filename2);
     */
    mlfIndexAssign(
      &handles,
      ".h_subplotWatermark",
      mlfNSubplot(1, _mxarray35_, _mxarray65_, NULL, NULL));
    mclPrintArray(mclVa(handles, "handles"), "handles");
    mclPrintAns(
      &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
    mclPrintAns(&ans, mlfNImshow(0, mclVv(image_x2, "image_x2"), NULL));
    mclAssignAns(&ans, mlfNTitle(0, mclVv(filename2, "filename2"), NULL));
    /*
     * clc;
     */
    mlfClc();
    /*
     * 
     * handles.bool_openWatermark=1;%set open watermark image already
     */
    mlfIndexAssign(&handles, ".bool_openWatermark", _mxarray0_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * if (handles.bool_openOriginal) &&(handles.bool_openWatermark)
     */
    if (mclScalarToBool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))
        && mclScalarToBool(
             mlfIndexRef(mclVa(handles, "handles"), ".bool_openWatermark"))) {
        /*
         * %enable pushbuttonAddWatermark
         * h_enablepushbuttonAddWatermark=findobj('tag','pushbuttonAddWatermark','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonAddWatermark,
          mlfFindobj(_mxarray43_, _mxarray45_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonAddWatermark,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonAddWatermark, "h_enablepushbuttonAddWatermark"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %Enaable popupmenuBlockSizeAdd
         * set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray51_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * 
     * end
     */
    }
    /*
     * if (handles.bool_openWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openWatermark"))) {
        /*
         * %enable pushbuttonWatermark_info
         * h_enablepushbuttonWatermark_info=findobj('tag','pushbuttonWatermark_info','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonWatermark_info,
          mlfFindobj(_mxarray43_, _mxarray69_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonWatermark_info,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonWatermark_info,
              "h_enablepushbuttonWatermark_info"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonShowRealWatermark
         * h_enablepushbuttonShowRealWatermark=findobj('tag','pushbuttonShowRealWatermark','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonShowRealWatermark,
          mlfFindobj(_mxarray43_, _mxarray71_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonShowRealWatermark,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonShowRealWatermark,
              "h_enablepushbuttonShowRealWatermark"),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
    return_:
    mxDestroyArray(filename2);
    mxDestroyArray(pathname2);
    mxDestroyArray(temp_path2);
    mxDestroyArray(ans);
    mxDestroyArray(image_x2);
    mxDestroyArray(h_enablepushbuttonAddWatermark);
    mxDestroyArray(h_enablepushbuttonWatermark_info);
    mxDestroyArray(h_enablepushbuttonShowRealWatermark);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_popupmenuBlockSize_CreateFcn" is the
 * implementation version of the "watermark005/popupmenuBlockSize_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 227-243). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSize_CreateFcn(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSize_CreateFcn(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSize (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: popupmenu controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray73_, _mxarray75_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray73_,
            mlfNGet(1, _mxarray14_, _mxarray77_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * %set(hObject, 'String', {'plot(rand(5))', 'plot(sin(1:0.01:25))', 'comet(cos(1:.01:10))', 'bar(1:10)', 'plot(membrane)', 'surf(peaks)'});
     * 
     * 
     * % --- Executes on selection change in popupmenuBlockSize.
     */
}

/*
 * The function "Mwatermark005_popupmenuBlockSize_Callback" is the
 * implementation version of the "watermark005/popupmenuBlockSize_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 243-300). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSize_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSize_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * block_size = NULL;
    mxArray * popup_sel_index = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSize (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: contents = get(hObject,'String') returns popupmenuBlockSize contents as cell array
     * %        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSize
     * 
     * %all_choices = get(handles.my_menu, 'String')
     * %current_choice = all_choices{get(handles.my_menu, 'Value')};
     * %temp_popup_sel_index = get(handles.popupmenuBlockSize, 'Value');
     * 
     * 
     * popup_sel_index = get(handles.popupmenuBlockSize,'Value');
     */
    mlfAssign(
      &popup_sel_index,
      mlfNGet(
        1,
        mlfIndexRef(mclVa(handles, "handles"), ".popupmenuBlockSize"),
        _mxarray79_,
        NULL));
    /*
     * %popup_sel_index = get(hObject,'Value');
     * %msgbox(popup_sel_index);
     * 
     * switch popup_sel_index
     */
    {
        mxArray * v_ = mclInitialize(mclVv(popup_sel_index, "popup_sel_index"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1
             * block_size=1;
             */
            mlfAssign(&block_size, _mxarray0_);
            /*
             * set(handles.editBlockSize,'String','1');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray83_,
                NULL));
        /*
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray85_)) {
            /*
             * block_size=2;
             */
            mlfAssign(&block_size, _mxarray85_);
            /*
             * set(handles.editBlockSize,'String','2');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray86_,
                NULL));
        /*
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray88_)) {
            /*
             * block_size=4;
             */
            mlfAssign(&block_size, _mxarray89_);
            /*
             * set(handles.editBlockSize,'String','4');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray90_,
                NULL));
        /*
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray89_)) {
            /*
             * block_size=8;
             */
            mlfAssign(&block_size, _mxarray92_);
            /*
             * set(handles.editBlockSize,'String','8');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray93_,
                NULL));
        /*
         * case 5
         */
        } else if (mclSwitchCompare(v_, _mxarray95_)) {
            /*
             * block_size=16;
             */
            mlfAssign(&block_size, _mxarray96_);
            /*
             * set(handles.editBlockSize,'String','16');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray97_,
                NULL));
        /*
         * case 6
         */
        } else if (mclSwitchCompare(v_, _mxarray99_)) {
            /*
             * block_size=32;
             */
            mlfAssign(&block_size, _mxarray100_);
            /*
             * set(handles.editBlockSize,'String','32');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray101_,
                NULL));
        /*
         * case 7
         */
        } else if (mclSwitchCompare(v_, _mxarray103_)) {
            /*
             * block_size=64;
             */
            mlfAssign(&block_size, _mxarray104_);
            /*
             * set(handles.editBlockSize,'String','64');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray105_,
                NULL));
        /*
         * case 8
         */
        } else if (mclSwitchCompare(v_, _mxarray92_)) {
            /*
             * block_size=128;
             */
            mlfAssign(&block_size, _mxarray107_);
            /*
             * set(handles.editBlockSize,'String','128');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray108_,
                NULL));
        /*
         * case 9
         */
        } else if (mclSwitchCompare(v_, _mxarray110_)) {
            /*
             * block_size=256;
             */
            mlfAssign(&block_size, _mxarray111_);
            /*
             * set(handles.editBlockSize,'String','256');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray112_,
                NULL));
        /*
         * otherwise
         */
        } else {
            /*
             * block_size=2;
             */
            mlfAssign(&block_size, _mxarray85_);
            /*
             * set(handles.editBlockSize,'String','2');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".editBlockSize"),
                _mxarray81_,
                _mxarray86_,
                NULL));
        /*
         * end 
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * %msgbox(block_size);     
     * 
     * handles.temp_popupblocksize=block_size;
     */
    mlfIndexAssign(
      &handles, ".temp_popupblocksize", mclVv(block_size, "block_size"));
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(popup_sel_index);
    mxDestroyArray(block_size);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonAddWatermark.
     */
}

/*
 * The function "Mwatermark005_pushbuttonAddWatermark_Callback" is the
 * implementation version of the "watermark005/pushbuttonAddWatermark_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 300-679). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonAddWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonAddWatermark_Callback(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWrite = NULL;
    mxArray * pathname3 = NULL;
    mxArray * filename3 = NULL;
    mxArray * h_enablepopupmenuAttackMethod = NULL;
    mxArray * h_enableExtract = NULL;
    mxArray * h_enablepushbuttonShowRealImageWithWatermark = NULL;
    mxArray * h_enablepushbuttonImageWithWatermark_info = NULL;
    mxArray * h_enableSaveImageWithWatermark = NULL;
    mxArray * n = NULL;
    mxArray * m = NULL;
    mxArray * s = NULL;
    mxArray * n_block = NULL;
    mxArray * seed = NULL;
    mxArray * rand_size = NULL;
    mxArray * marked_im5 = NULL;
    mxArray * bin_mark = NULL;
    mxArray * wm_info = NULL;
    mxArray * tmp = NULL;
    mxArray * l = NULL;
    mxArray * g_avg = NULL;
    mxArray * g_min = NULL;
    mxArray * g_max = NULL;
    mxArray * num_adding = NULL;
    mxArray * num_block = NULL;
    mxArray * arg5 = NULL;
    mxArray * j = NULL;
    mxArray * x = NULL;
    mxArray * k = NULL;
    mxArray * max_block = NULL;
    mxArray * block_per_col = NULL;
    mxArray * block_per_row = NULL;
    mxArray * block_size = NULL;
    mxArray * watermark = NULL;
    mxArray * type = NULL;
    mxArray * im_size_col = NULL;
    mxArray * im_size_row = NULL;
    mxArray * im5_col = NULL;
    mxArray * im5 = NULL;
    mxArray * im5_info = NULL;
    mxArray * infile = NULL;
    mxArray * i = NULL;
    mxArray * total_key = NULL;
    mxArray * key_size = NULL;
    mxArray * h_waitAdd = NULL;
    mxArray * h_percentinvalid = NULL;
    mxArray * percent = NULL;
    mxArray * temp_percentAnswer = NULL;
    mxArray * percentNum_lines = NULL;
    mxArray * defPercent = NULL;
    mxArray * dlgPercent_title = NULL;
    mxArray * percentPrompt = NULL;
    mxArray * h_passwdinvalid = NULL;
    mxArray * key = NULL;
    mxArray * ans = NULL;
    mxArray * temp_keyAnswer = NULL;
    mxArray * keyNum_lines = NULL;
    mxArray * dlgKey_title = NULL;
    mxArray * keyPrompt = NULL;
    mxArray * defaultKey = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonAddWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * %function add(infile,outfile,key,arg4,arg5);
     * %infile->name of input file to be added watermark
     * %outfile->name of output file after adding
     * %arg4=>watermark (file name) to be added in host image
     * %arg5=>percent of adding is valid from 1-100
     * 
     * %%%%%%%%%%Begin Add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * 
     * %%%%%%%%%Manage input%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%%Begin  Manage Key   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * try
     */
    mlfTry {
        /*
         * defaultKey='12345678';
         */
        mlfAssign(&defaultKey, _mxarray114_);
        /*
         * %prompt = {'Enter matrix size:','Enter colormap name:'};
         * %dlg_title = 'Input for peaks function';
         * %num_lines= 1;
         * %def     = {'20','hsv'};
         * %answer  = inputdlg(prompt,dlg_title,num_lines,def);
         * keyPrompt={'Please input password for adding watermark image(Recommand 8 Digits)'};
         */
        mlfAssign(&keyPrompt, _mxarray116_);
        /*
         * dlgKey_title='Input password to protect watermark';
         */
        mlfAssign(&dlgKey_title, _mxarray119_);
        /*
         * keyNum_lines=1;
         */
        mlfAssign(&keyNum_lines, _mxarray0_);
        /*
         * 
         * temp_keyAnswer=inputdlg(keyPrompt,dlgKey_title,keyNum_lines);
         */
        mlfAssign(
          &temp_keyAnswer,
          mlfNInputdlg(
            1,
            mclVv(keyPrompt, "keyPrompt"),
            mclVv(dlgKey_title, "dlgKey_title"),
            mclVv(keyNum_lines, "keyNum_lines"),
            NULL,
            NULL));
        /*
         * 
         * if isempty(temp_keyAnswer)
         */
        if (mlfTobool(mlfIsempty(mclVv(temp_keyAnswer, "temp_keyAnswer")))) {
            /*
             * msgbox('You cancel input password program will do nothing ','Cancel input Password ','warn','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray121_,
                _mxarray123_,
                _mxarray125_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end;    
         */
        }
        /*
         * if isequal(temp_keyAnswer,{''})  
         */
        if (mlfTobool(
              mlfIsequal(
                mclVv(temp_keyAnswer, "temp_keyAnswer"), _mxarray129_, NULL))) {
            /*
             * key=defaultKey;
             */
            mlfAssign(&key, mclVv(defaultKey, "defaultKey"));
            /*
             * h_passwdinvalid=msgbox('You don''t enter your password.Watermark image wouldn''t secure','Password invalid','warn','modal');
             */
            mlfAssign(
              &h_passwdinvalid,
              mlfNMsgbox(
                0,
                mclValueVarargout(),
                _mxarray131_,
                _mxarray133_,
                _mxarray125_,
                _mxarray127_,
                NULL));
            /*
             * uiwait(h_passwdinvalid);
             */
            mlfUiwait(mclVv(h_passwdinvalid, "h_passwdinvalid"));
        /*
         * else 
         */
        } else {
            /*
             * if isnan(str2double(temp_keyAnswer))
             */
            if (mlfTobool(
                  mlfIsnan(
                    mlfStr2double(mclVv(temp_keyAnswer, "temp_keyAnswer"))))) {
                /*
                 * key=defaultKey;
                 */
                mlfAssign(&key, mclVv(defaultKey, "defaultKey"));
            /*
             * %disp('nan');
             * else
             */
            } else {
                /*
                 * key=temp_keyAnswer;
                 */
                mlfAssign(&key, mclVv(temp_keyAnswer, "temp_keyAnswer"));
            /*
             * %disp('not nan');
             * end
             */
            }
        /*
         * end    
         */
        }
        /*
         * 
         * key=temp_keyAnswer;
         */
        mlfAssign(&key, mclVv(temp_keyAnswer, "temp_keyAnswer"));
        /*
         * 
         * 
         * 
         * 
         * 
         * key=str2double(key);
         */
        mlfAssign(&key, mlfStr2double(mclVv(key, "key")));
        /*
         * 
         * %%%%%%%%%End  Manage Key   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%Begin percent to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * percentPrompt={'Please input percent for adding watermark image(defualt 95%)'};
         */
        mlfAssign(&percentPrompt, _mxarray135_);
        /*
         * dlgPercent_title='Input percent to add watermark';
         */
        mlfAssign(&dlgPercent_title, _mxarray138_);
        /*
         * defPercent     = {'95'};
         */
        mlfAssign(&defPercent, _mxarray140_);
        /*
         * percentNum_lines=1;
         */
        mlfAssign(&percentNum_lines, _mxarray0_);
        /*
         * 
         * 
         * temp_percentAnswer=inputdlg(percentPrompt,dlgPercent_title,percentNum_lines,defPercent);
         */
        mlfAssign(
          &temp_percentAnswer,
          mlfNInputdlg(
            1,
            mclVv(percentPrompt, "percentPrompt"),
            mclVv(dlgPercent_title, "dlgPercent_title"),
            mclVv(percentNum_lines, "percentNum_lines"),
            mclVv(defPercent, "defPercent"),
            NULL));
        /*
         * 
         * if isempty(temp_percentAnswer)
         */
        if (mlfTobool(
              mlfIsempty(mclVv(temp_percentAnswer, "temp_percentAnswer")))) {
            /*
             * msgbox('You cancel input percent to add watermark. Program will do nothing','Cancel input percent adding ','warn','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray143_,
                _mxarray145_,
                _mxarray125_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end;    
         */
        }
        /*
         * if isequal(temp_percentAnswer,{''})
         */
        if (mlfTobool(
              mlfIsequal(
                mclVv(temp_percentAnswer, "temp_percentAnswer"),
                _mxarray129_, NULL))) {
            /*
             * percent=defPercent;
             */
            mlfAssign(&percent, mclVv(defPercent, "defPercent"));
            /*
             * h_percentinvalid=msgbox('You don''t input percent to adding. Program will use defualt(100%)','Percent adding is invalid','warn','modal');
             */
            mlfAssign(
              &h_percentinvalid,
              mlfNMsgbox(
                0,
                mclValueVarargout(),
                _mxarray147_,
                _mxarray149_,
                _mxarray125_,
                _mxarray127_,
                NULL));
            /*
             * uiwait(h_percentinvalid);
             */
            mlfUiwait(mclVv(h_percentinvalid, "h_percentinvalid"));
        /*
         * else 
         */
        } else {
            /*
             * if isnan(str2double(temp_percentAnswer))
             */
            if (mlfTobool(
                  mlfIsnan(
                    mlfStr2double(
                      mclVv(temp_percentAnswer, "temp_percentAnswer"))))) {
                /*
                 * percent='100';
                 */
                mlfAssign(&percent, _mxarray151_);
            /*
             * else
             */
            } else {
                /*
                 * percent=temp_percentAnswer;
                 */
                mlfAssign(
                  &percent, mclVv(temp_percentAnswer, "temp_percentAnswer"));
            /*
             * end   
             */
            }
        /*
         * end
         */
        }
        /*
         * %%%%%%%%%%End percent to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%Begin process to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%% Begin check initial paramter for adding %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * try
         */
        mlfTry {
            /*
             * h_waitAdd = waitbar(0,'Please wait... Program is  processing. ');
             */
            mlfAssign(
              &h_waitAdd, mlfNWaitbar(1, _mxarray14_, _mxarray153_, NULL));
            /*
             * 
             * percent=str2double(percent);%change string to integer
             */
            mlfAssign(&percent, mlfStr2double(mclVv(percent, "percent")));
            /*
             * key = double(key);
             */
            mlfAssign(&key, mlfDouble(mclVv(key, "key")));
            /*
             * 
             * %%%%%%%%%%%Initial key %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * key_size = size(key);
             */
            mlfAssign(
              &key_size, mlfSize(mclValueVarargout(), mclVv(key, "key"), NULL));
            /*
             * key_size = key_size(2);
             */
            mlfAssign(
              &key_size, mclIntArrayRef1(mclVv(key_size, "key_size"), 2));
            /*
             * total_key = '';
             */
            mlfAssign(&total_key, _mxarray130_);
            /*
             * for i=1:key_size
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = mclForIntEnd(mclVv(key_size, "key_size"));
                if (v_ > e_) {
                    mlfAssign(&i, _mxarray11_);
                } else {
                    /*
                     * total_key = strcat(total_key,int2str(key(i)));
                     * end;
                     */
                    for (; ; ) {
                        mlfAssign(
                          &total_key,
                          mlfStrcat(
                            mclVv(total_key, "total_key"),
                            mlfInt2str(mclIntArrayRef1(mclVv(key, "key"), v_)),
                            NULL));
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&i, mlfScalar(v_));
                }
            }
            /*
             * %total_key = double(total_key);
             * total_key = str2num(total_key);
             */
            mlfAssign(
              &total_key, mlfStr2num(NULL, mclVv(total_key, "total_key")));
            /*
             * 
             * %%%%%%%%%%read  image%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * infile=handles.current_filename1;% original image
             */
            mlfAssign(
              &infile,
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"));
            /*
             * im5_info = imfinfo(infile);
             */
            mlfAssign(
              &im5_info, mlfNImfinfo(1, NULL, mclVv(infile, "infile"), NULL));
            /*
             * im5 = imread(infile);
             */
            mlfAssign(
              &im5, mlfNImread(1, NULL, NULL, mclVv(infile, "infile"), NULL));
            /*
             * 
             * im5 = im2double(im5);
             */
            mlfAssign(&im5, mlfIm2double(mclVv(im5, "im5"), NULL));
            /*
             * if strcmp(im5_info.ColorType,'truecolor')==1;
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxStrcmp,
                    mlfIndexRef(mclVv(im5_info, "im5_info"), ".ColorType"),
                    _mxarray155_,
                    NULL),
                  _mxarray0_)) {
                /*
                 * im5_col = im5;
                 */
                mlfAssign(&im5_col, mclVv(im5, "im5"));
                /*
                 * im5 = im5_col(:,:,3);
                 */
                mlfAssign(
                  &im5,
                  mlfIndexRef(
                    mclVv(im5_col, "im5_col"),
                    "(?,?,?)",
                    mlfCreateColonIndex(),
                    mlfCreateColonIndex(),
                    _mxarray88_));
            /*
             * end;
             */
            }
            /*
             * waitbar(0.1,h_waitAdd);
             */
            mclAssignAns(
              &ans,
              mlfNWaitbar(
                0, _mxarray157_, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * 
             * %%%%define image type
             * im_size_row = im5_info.Width;
             */
            mlfAssign(
              &im_size_row, mlfIndexRef(mclVv(im5_info, "im5_info"), ".Width"));
            /*
             * im_size_col = im5_info.Height;
             */
            mlfAssign(
              &im_size_col,
              mlfIndexRef(mclVv(im5_info, "im5_info"), ".Height"));
            /*
             * type = im5_info.Format;
             */
            mlfAssign(
              &type, mlfIndexRef(mclVv(im5_info, "im5_info"), ".Format"));
            /*
             * 
             * watermark=handles.current_filename2;%watermark image
             */
            mlfAssign(
              &watermark,
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"));
            /*
             * 
             * %%%%%%%%%% block size fix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * block_size = handles.temp_popupblocksizeAdd;
             */
            mlfAssign(
              &block_size,
              mlfIndexRef(
                mclVa(handles, "handles"), ".temp_popupblocksizeAdd"));
        /*
         * 
         * catch
         */
        } mlfCatch {
            /*
             * close(h_waitAdd);
             */
            mclAssignAns(
              &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * msgbox('Program Can''t initial some parameters.Process will be cancel...','Error initial parameters ','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray158_,
                _mxarray160_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * %%%%%%%%%%%End check initial paramters for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * 
         * %%%%%%%%%%%%%%%%%%%Begin block information%%%%%%%%%%%%%%%%%%
         * if mod(im_size_row,block_size)==0 & mod(im_size_col,block_size)==0;
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclEq(
                    mlfMod(
                      mclVv(im_size_row, "im_size_row"),
                      mclVv(block_size, "block_size")),
                    _mxarray14_));
            if (mlfTobool(a_)
                && mlfTobool(
                     mclAnd(
                       a_,
                       mclEq(
                         mlfMod(
                           mclVv(im_size_col, "im_size_col"),
                           mclVv(block_size, "block_size")),
                         _mxarray14_)))) {
                mxDestroyArray(a_);
                /*
                 * block_per_row = im_size_row/block_size;
                 */
                mlfAssign(
                  &block_per_row,
                  mclMrdivide(
                    mclVv(im_size_row, "im_size_row"),
                    mclVv(block_size, "block_size")));
                /*
                 * block_per_col = im_size_col/block_size;
                 */
                mlfAssign(
                  &block_per_col,
                  mclMrdivide(
                    mclVv(im_size_col, "im_size_col"),
                    mclVv(block_size, "block_size")));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * close(h_waitAdd); 
                 */
                mclAssignAns(
                  &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
                /*
                 * msgbox('Miss Match between BLOCK and IMAGE size','ERROR','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray164_,
                    _mxarray166_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                mclExitTryBlock();
                /*
                 * return;
                 */
                goto return_;
            }
        /*
         * end;
         */
        }
        /*
         * %%%%%%%%%%%%%%%%%%%End block information%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%%Begin check initial block for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * try
         */
        mlfTry {
            /*
             * if block_per_row>=block_per_col;
             */
            if (mclGeBool(
                  mclVv(block_per_row, "block_per_row"),
                  mclVv(block_per_col, "block_per_col"))) {
                /*
                 * max_block = block_per_row;
                 */
                mlfAssign(&max_block, mclVv(block_per_row, "block_per_row"));
            /*
             * else
             */
            } else {
                /*
                 * max_block = block_per_col;
                 */
                mlfAssign(&max_block, mclVv(block_per_col, "block_per_col"));
            /*
             * end;
             */
            }
            /*
             * k=1;
             */
            mlfAssign(&k, _mxarray0_);
            /*
             * x(1:max_block,1:block_size)=0;
             */
            mclArrayAssign2(
              &x,
              _mxarray14_,
              mlfColon(_mxarray0_, mclVv(max_block, "max_block"), NULL),
              mlfColon(_mxarray0_, mclVv(block_size, "block_size"), NULL));
            /*
             * for i = 1:max_block;
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = mclForIntEnd(mclVv(max_block, "max_block"));
                if (v_ > e_) {
                    mlfAssign(&i, _mxarray11_);
                } else {
                    /*
                     * for j = 1:block_size;
                     * x(i,j)=k;
                     * k = k+1;
                     * end;
                     * end;
                     */
                    for (; ; ) {
                        int v_0 = mclForIntStart(1);
                        int e_0 = mclForIntEnd(mclVv(block_size, "block_size"));
                        if (v_0 > e_0) {
                            mlfAssign(&j, _mxarray11_);
                        } else {
                            for (; ; ) {
                                mclIntArrayAssign2(&x, mclVv(k, "k"), v_, v_0);
                                mlfAssign(
                                  &k, mclPlus(mclVv(k, "k"), _mxarray0_));
                                if (v_0 == e_0) {
                                    break;
                                }
                                ++v_0;
                            }
                            mlfAssign(&j, mlfScalar(v_0));
                        }
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&i, mlfScalar(v_));
                }
            }
            /*
             * 
             * 
             * waitbar(0.3,h_waitAdd);
             */
            mclAssignAns(
              &ans,
              mlfNWaitbar(
                0, _mxarray168_, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * 
             * %%%%%%%%%%%%Begin convert percent to number of block%%%%%%%%%%%%%%%%%%%%%%
             * 
             * arg5=percent;%percent to add
             */
            mlfAssign(&arg5, mclVv(percent, "percent"));
            /*
             * num_block = block_per_row*block_per_col;
             */
            mlfAssign(
              &num_block,
              mclMtimes(
                mclVv(block_per_row, "block_per_row"),
                mclVv(block_per_col, "block_per_col")));
            /*
             * num_adding = arg5*num_block/100;
             */
            mlfAssign(
              &num_adding,
              mclMrdivide(
                mclMtimes(mclVv(arg5, "arg5"), mclVv(num_block, "num_block")),
                _mxarray169_));
            /*
             * num_adding = floor(num_adding);
             */
            mlfAssign(&num_adding, mlfFloor(mclVv(num_adding, "num_adding")));
            /*
             * 
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * g_max(1:block_per_col,1:block_per_row) = 0;
             */
            mclArrayAssign2(
              &g_max,
              _mxarray14_,
              mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
              mlfColon(
                _mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
            /*
             * g_min(1:block_per_col,1:block_per_row) = 0;
             */
            mclArrayAssign2(
              &g_min,
              _mxarray14_,
              mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
              mlfColon(
                _mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
            /*
             * g_avg(1:block_per_col,1:block_per_row) = 0;
             */
            mclArrayAssign2(
              &g_avg,
              _mxarray14_,
              mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
              mlfColon(
                _mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
            /*
             * 
             * for k = 1:block_per_col;
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = mclForIntEnd(mclVv(block_per_col, "block_per_col"));
                if (v_ > e_) {
                    mlfAssign(&k, _mxarray11_);
                } else {
                    /*
                     * for l = 1:block_per_row;
                     * tmp= max(im5(x(k,:),x(l,:)));
                     * g_max(k,l)= max(tmp);
                     * 
                     * tmp= min(im5(x(k,:),x(l,:)));
                     * g_min(k,l)= min(tmp);
                     * 
                     * tmp= sum(im5(x(k,:),x(l,:)));
                     * tmp= sum(tmp);
                     * g_avg(k,l)= tmp/(block_size*block_size);
                     * end;
                     * end;
                     */
                    for (; ; ) {
                        int v_1 = mclForIntStart(1);
                        int e_1
                          = mclForIntEnd(
                              mclVv(block_per_row, "block_per_row"));
                        if (v_1 > e_1) {
                            mlfAssign(&l, _mxarray11_);
                        } else {
                            for (; ; ) {
                                mlfAssign(
                                  &tmp,
                                  mlfMax(
                                    NULL,
                                    mclArrayRef2(
                                      mclVv(im5, "im5"),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_),
                                        mlfCreateColonIndex()),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_1),
                                        mlfCreateColonIndex())),
                                    NULL,
                                    NULL));
                                mclIntArrayAssign2(
                                  &g_max,
                                  mlfMax(NULL, mclVv(tmp, "tmp"), NULL, NULL),
                                  v_,
                                  v_1);
                                mlfAssign(
                                  &tmp,
                                  mlfMin(
                                    NULL,
                                    mclArrayRef2(
                                      mclVv(im5, "im5"),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_),
                                        mlfCreateColonIndex()),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_1),
                                        mlfCreateColonIndex())),
                                    NULL,
                                    NULL));
                                mclIntArrayAssign2(
                                  &g_min,
                                  mlfMin(NULL, mclVv(tmp, "tmp"), NULL, NULL),
                                  v_,
                                  v_1);
                                mlfAssign(
                                  &tmp,
                                  mlfSum(
                                    mclArrayRef2(
                                      mclVv(im5, "im5"),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_),
                                        mlfCreateColonIndex()),
                                      mclArrayRef2(
                                        mclVv(x, "x"),
                                        mlfScalar(v_1),
                                        mlfCreateColonIndex())),
                                    NULL));
                                mlfAssign(
                                  &tmp, mlfSum(mclVv(tmp, "tmp"), NULL));
                                mclIntArrayAssign2(
                                  &g_avg,
                                  mclMrdivide(
                                    mclVv(tmp, "tmp"),
                                    mclMtimes(
                                      mclVv(block_size, "block_size"),
                                      mclVv(block_size, "block_size"))),
                                  v_,
                                  v_1);
                                if (v_1 == e_1) {
                                    break;
                                }
                                ++v_1;
                            }
                            mlfAssign(&l, mlfScalar(v_1));
                        }
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&k, mlfScalar(v_));
                }
            }
            /*
             * 
             * waitbar(0.5,h_waitAdd);
             */
            mclAssignAns(
              &ans,
              mlfNWaitbar(
                0, _mxarray170_, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * 
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * wm_info = imfinfo(watermark);
             */
            mlfAssign(
              &wm_info,
              mlfNImfinfo(1, NULL, mclVv(watermark, "watermark"), NULL));
            /*
             * bin_mark = imread(watermark,wm_info.Format);
             */
            mlfAssign(
              &bin_mark,
              mlfNImread(
                1,
                NULL,
                NULL,
                mclVv(watermark, "watermark"),
                mlfIndexRef(mclVv(wm_info, "wm_info"), ".Format"),
                NULL));
        /*
         * %bin_mark=imread(watermark);
         * catch
         */
        } mlfCatch {
            /*
             * close(h_waitAdd); 
             */
            mclAssignAns(
              &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * msgbox('Initial Block for adding has some errors...','ERROR Initial Blcok','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray171_,
                _mxarray173_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * %%%%%%%%%%%End check initial block for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%%Begin check and convert watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%% Begin check and convert watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * try
         */
        mlfTry {
            /*
             * if strcmp(wm_info.ColorType,'truecolor')==1;
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxStrcmp,
                    mlfIndexRef(mclVv(wm_info, "wm_info"), ".ColorType"),
                    _mxarray155_,
                    NULL),
                  _mxarray0_)) {
                /*
                 * bin_mark = rgb2gray(bin_mark);
                 */
                mlfAssign(
                  &bin_mark,
                  mlfRgb2gray(mclVv(bin_mark, "bin_mark"), NULL, NULL));
                /*
                 * bin_mark = dither(bin_mark);
                 */
                mlfAssign(
                  &bin_mark,
                  mlfNDither(
                    0, mclValueVarargout(), mclVv(bin_mark, "bin_mark"), NULL));
            /*
             * else 
             */
            } else {
                /*
                 * bin_mark = dither(bin_mark);
                 */
                mlfAssign(
                  &bin_mark,
                  mlfNDither(
                    0, mclValueVarargout(), mclVv(bin_mark, "bin_mark"), NULL));
            /*
             * end;
             */
            }
            /*
             * 
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * bin_mark = imresize(bin_mark,[block_per_col block_per_row]);
             */
            mlfAssign(
              &bin_mark,
              mlfNImresize(
                0,
                mclValueVarargout(),
                mclVv(bin_mark, "bin_mark"),
                mlfHorzcat(
                  mclVv(block_per_col, "block_per_col"),
                  mclVv(block_per_row, "block_per_row"),
                  NULL),
                NULL));
            /*
             * imwrite(bin_mark,'real_mark.bmp','bmp');
             */
            mlfImwrite(
              mclVv(bin_mark, "bin_mark"), _mxarray175_, _mxarray177_, NULL);
            /*
             * marked_im5 = im5;
             */
            mlfAssign(&marked_im5, mclVv(im5, "im5"));
        /*
         * catch
         */
        } mlfCatch {
            /*
             * close(h_waitAdd); 
             */
            mclAssignAns(
              &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * msgbox('Check and convert watermark has some errors...','ERROR checking watermark','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray179_,
                _mxarray181_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * %%%%%%%%%%%Begin check and convert watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%%Begin Check initial random    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%Begin initial random%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * try
         */
        mlfTry {
            /*
             * rand_size = 1;%mean 10,000 blocks,should not more than sqrt(n_block)
             */
            mlfAssign(&rand_size, _mxarray0_);
            /*
             * seed = total_key;%key
             */
            mlfAssign(&seed, mclVv(total_key, "total_key"));
            /*
             * n_block = num_adding;
             */
            mlfAssign(&n_block, mclVv(num_adding, "num_adding"));
            /*
             * s = randint(1,n_block,[1,num_block],seed);
             */
            mlfAssign(
              &s,
              mlfRandint(
                _mxarray0_,
                mclVv(n_block, "n_block"),
                mlfHorzcat(_mxarray0_, mclVv(num_block, "num_block"), NULL),
                mclVv(seed, "seed"),
                NULL));
            /*
             * if arg5==100;
             */
            if (mclEqBool(mclVv(arg5, "arg5"), _mxarray169_)) {
                /*
                 * s = randperm(num_block);
                 */
                mlfAssign(&s, mlfRandperm(mclVv(num_block, "num_block")));
            /*
             * end;
             */
            }
            /*
             * 
             * 
             * %%%%%%%%End initial random%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * waitbar(0.7,h_waitAdd);
             */
            mclAssignAns(
              &ans,
              mlfNWaitbar(
                0, _mxarray183_, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * 
             * 
             * for m = 1:1;      
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = 1;
                if (v_ > e_) {
                    mlfAssign(&m, _mxarray11_);
                } else {
                    /*
                     * for n = 1:n_block;
                     * k = ceil(s(m,n)/block_per_row);
                     * l = mod(s(m,n),block_per_row);
                     * if l == 0; 
                     * l = block_per_row; 
                     * end;
                     * for i = x(k,:);
                     * for j = x(l,:);
                     * 
                     * if bin_mark(k,l) == 1;%white
                     * if im5(i,j) > g_avg(k,l);
                     * marked_im5(i,j) = g_max(k,l);
                     * else    
                     * marked_im5(i,j) = im5(i,j) + 0.0100;
                     * end;
                     * elseif bin_mark(k,l) == 0;%black
                     * if im5(i,j) < g_avg(k,l);
                     * marked_im5(i,j) = g_min(k,l);%0.0005;
                     * else
                     * marked_im5(i,j) = im5(i,j) - 0.0100;
                     * end;
                     * end;
                     * 
                     * end;
                     * end;
                     * end;
                     * end;
                     */
                    for (; ; ) {
                        int v_2 = mclForIntStart(1);
                        int e_2 = mclForIntEnd(mclVv(n_block, "n_block"));
                        if (v_2 > e_2) {
                            mlfAssign(&n, _mxarray11_);
                        } else {
                            for (; ; ) {
                                mlfAssign(
                                  &k,
                                  mlfCeil(
                                    mclMrdivide(
                                      mclIntArrayRef2(mclVv(s, "s"), v_, v_2),
                                      mclVv(block_per_row, "block_per_row"))));
                                mlfAssign(
                                  &l,
                                  mlfMod(
                                    mclIntArrayRef2(mclVv(s, "s"), v_, v_2),
                                    mclVv(block_per_row, "block_per_row")));
                                if (mclEqBool(mclVv(l, "l"), _mxarray14_)) {
                                    mlfAssign(
                                      &l,
                                      mclVv(block_per_row, "block_per_row"));
                                }
                                {
                                    mclForLoopIterator viter__;
                                    for (mclForStart(
                                           &viter__,
                                           mclArrayRef2(
                                             mclVv(x, "x"),
                                             mclVv(k, "k"),
                                             mlfCreateColonIndex()),
                                           NULL,
                                           NULL);
                                         mclForNext(&viter__, &i);
                                         ) {
                                        mclForLoopIterator viter__0;
                                        for (mclForStart(
                                               &viter__0,
                                               mclArrayRef2(
                                                 mclVv(x, "x"),
                                                 mclVv(l, "l"),
                                                 mlfCreateColonIndex()),
                                               NULL,
                                               NULL);
                                             mclForNext(&viter__0, &j);
                                             ) {
                                            if (mclEqBool(
                                                  mclArrayRef2(
                                                    mclVv(bin_mark, "bin_mark"),
                                                    mclVv(k, "k"),
                                                    mclVv(l, "l")),
                                                  _mxarray0_)) {
                                                if (mclGtBool(
                                                      mclArrayRef2(
                                                        mclVv(im5, "im5"),
                                                        mclVv(i, "i"),
                                                        mclVv(j, "j")),
                                                      mclArrayRef2(
                                                        mclVv(g_avg, "g_avg"),
                                                        mclVv(k, "k"),
                                                        mclVv(l, "l")))) {
                                                    mclArrayAssign2(
                                                      &marked_im5,
                                                      mclArrayRef2(
                                                        mclVv(g_max, "g_max"),
                                                        mclVv(k, "k"),
                                                        mclVv(l, "l")),
                                                      mclVv(i, "i"),
                                                      mclVv(j, "j"));
                                                } else {
                                                    mclArrayAssign2(
                                                      &marked_im5,
                                                      mclPlus(
                                                        mclArrayRef2(
                                                          mclVv(im5, "im5"),
                                                          mclVv(i, "i"),
                                                          mclVv(j, "j")),
                                                        _mxarray184_),
                                                      mclVv(i, "i"),
                                                      mclVv(j, "j"));
                                                }
                                            } else if (mclEqBool(
                                                         mclArrayRef2(
                                                           mclVv(
                                                             bin_mark,
                                                             "bin_mark"),
                                                           mclVv(k, "k"),
                                                           mclVv(l, "l")),
                                                         _mxarray14_)) {
                                                if (mclLtBool(
                                                      mclArrayRef2(
                                                        mclVv(im5, "im5"),
                                                        mclVv(i, "i"),
                                                        mclVv(j, "j")),
                                                      mclArrayRef2(
                                                        mclVv(g_avg, "g_avg"),
                                                        mclVv(k, "k"),
                                                        mclVv(l, "l")))) {
                                                    mclArrayAssign2(
                                                      &marked_im5,
                                                      mclArrayRef2(
                                                        mclVv(g_min, "g_min"),
                                                        mclVv(k, "k"),
                                                        mclVv(l, "l")),
                                                      mclVv(i, "i"),
                                                      mclVv(j, "j"));
                                                } else {
                                                    mclArrayAssign2(
                                                      &marked_im5,
                                                      mclMinus(
                                                        mclArrayRef2(
                                                          mclVv(im5, "im5"),
                                                          mclVv(i, "i"),
                                                          mclVv(j, "j")),
                                                        _mxarray184_),
                                                      mclVv(i, "i"),
                                                      mclVv(j, "j"));
                                                }
                                            }
                                        }
                                        mclDestroyForLoopIterator(viter__0);
                                    }
                                    mclDestroyForLoopIterator(viter__);
                                }
                                if (v_2 == e_2) {
                                    break;
                                }
                                ++v_2;
                            }
                            mlfAssign(&n, mlfScalar(v_2));
                        }
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&m, mlfScalar(v_));
                }
            }
            /*
             * 
             * waitbar(0.9,h_waitAdd);
             */
            mclAssignAns(
              &ans,
              mlfNWaitbar(
                0, _mxarray185_, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * 
             * 
             * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             * 
             * if strcmp(im5_info.ColorType,'truecolor')==1;
             */
            if (mclEqBool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxStrcmp,
                    mlfIndexRef(mclVv(im5_info, "im5_info"), ".ColorType"),
                    _mxarray155_,
                    NULL),
                  _mxarray0_)) {
                /*
                 * im5_col(:,:,3)=marked_im5;
                 */
                mlfIndexAssign(
                  &im5_col,
                  "(?,?,?)",
                  mlfCreateColonIndex(),
                  mlfCreateColonIndex(),
                  _mxarray88_,
                  mclVv(marked_im5, "marked_im5"));
                /*
                 * marked_im5 = im5_col;
                 */
                mlfAssign(&marked_im5, mclVv(im5_col, "im5_col"));
            /*
             * end;
             */
            }
        /*
         * 
         * catch 
         */
        } mlfCatch {
            /*
             * close(h_waitAdd); 
             */
            mclAssignAns(
              &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
            /*
             * msgbox('Program can''t succeed this action ','Error some parameters','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray186_,
                _mxarray188_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * 
         * waitbar(1,h_waitAdd,'Process is successful');
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(
            0, _mxarray0_, mclVv(h_waitAdd, "h_waitAdd"), _mxarray190_, NULL));
        /*
         * delete(h_waitAdd);
         */
        mlfDelete(mclVv(h_waitAdd, "h_waitAdd"), NULL);
        /*
         * 
         * %%%%%%%%%%%End Check initial random    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %show image with watermark 
         * try
         */
        mlfTry {
            /*
             * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title('Image with Watermark');
             */
            mlfIndexAssign(
              &handles,
              ".h_subplotImageWithWatermark",
              mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
            mclPrintArray(mclVa(handles, "handles"), "handles");
            mclPrintAns(
              &ans,
              mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
            mclPrintAns(
              &ans, mlfNImshow(0, mclVv(marked_im5, "marked_im5"), NULL));
            mclAssignAns(&ans, mlfNTitle(0, _mxarray194_, NULL));
        /*
         * %clc;
         * catch 
         */
        } mlfCatch {
            /*
             * %    imshow(marked_im5);
             * %delete(handles.h_subplotImageWithWatermark);
             * handles.current_filename3='image_watermark_bak.bmp';
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray196_);
            /*
             * imwrite(marked_im5,handles.current_filename3,'bmp')
             */
            mlfImwrite(
              mclVv(marked_im5, "marked_im5"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
              _mxarray177_,
              NULL);
            /*
             * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark');      
             */
            mlfIndexAssign(
              &handles,
              ".h_subplotImageWithWatermark",
              mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
            mclPrintArray(mclVa(handles, "handles"), "handles");
            mclPrintAns(
              &ans,
              mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
            mclPrintAns(
              &ans,
              mlfNImshow(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
                NULL));
            mclAssignAns(&ans, mlfNTitle(0, _mxarray194_, NULL));
        /*
         * %h_waitShowImageWithWatermark=msgbox('Program can''t show image in current windows..','Error Show image','error','modal');
         * %        uiwait(h_waitShowImageWithWatermark);
         * %       pushbuttonClearAll_Callback;
         * end    
         */
        } mlfEndCatch
        /*
         * 
         * %%%%%%%%Begin Set Active Button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * handles.bool_openImageWithWatermark=1;%already open Image with watermark
         */
        mlfIndexAssign(&handles, ".bool_openImageWithWatermark", _mxarray0_);
        /*
         * 
         * handles.current_marked_im5=marked_im5;%image with watermark
         */
        mlfIndexAssign(
          &handles, ".current_marked_im5", mclVv(marked_im5, "marked_im5"));
        /*
         * 
         * %enable pushbuttonSaveImageWithWatermark
         * h_enableSaveImageWithWatermark=findobj('tag','pushbuttonSaveImageWithWatermark','Enable','off');
         */
        mlfAssign(
          &h_enableSaveImageWithWatermark,
          mlfFindobj(
            _mxarray43_, _mxarray198_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enableSaveImageWithWatermark,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enableSaveImageWithWatermark, "h_enableSaveImageWithWatermark"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonImageWithWatermark_info
         * h_enablepushbuttonImageWithWatermark_info=findobj('tag','pushbuttonImageWithWatermark_info','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonImageWithWatermark_info,
          mlfFindobj(
            _mxarray43_, _mxarray200_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonImageWithWatermark_info,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonImageWithWatermark_info,
              "h_enablepushbuttonImageWithWatermark_info"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonShowRealImageWithWatermark
         * h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonShowRealImageWithWatermark,
          mlfFindobj(
            _mxarray43_, _mxarray202_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonShowRealImageWithWatermark,
              "h_enablepushbuttonShowRealImageWithWatermark"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * 
         * if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
         */
        if (mclScalarToBool(
              mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))
            && mclScalarToBool(
                 mlfIndexRef(
                   mclVa(handles, "handles"),
                   ".bool_openImageWithWatermark"))) {
            /*
             * %enable pushbuttonExtract
             * h_enableExtract=findobj('tag','pushbuttonExtract','Enable','off');
             */
            mlfAssign(
              &h_enableExtract,
              mlfFindobj(
                _mxarray43_, _mxarray53_, _mxarray47_, _mxarray67_, NULL));
            /*
             * set(h_enableExtract,'Enable','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(h_enableExtract, "h_enableExtract"),
                _mxarray47_,
                _mxarray49_,
                NULL));
            /*
             * %enable popupmenuAttackMethod
             * h_enablepopupmenuAttackMethod=findobj('tag','popupmenuAttackMethod','Enable','off');
             */
            mlfAssign(
              &h_enablepopupmenuAttackMethod,
              mlfFindobj(
                _mxarray43_, _mxarray55_, _mxarray47_, _mxarray67_, NULL));
            /*
             * set(h_enablepopupmenuAttackMethod,'Enable','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mclVv(
                  h_enablepopupmenuAttackMethod,
                  "h_enablepopupmenuAttackMethod"),
                _mxarray47_,
                _mxarray49_,
                NULL));
            /*
             * 
             * %Enaable popupmenuBlockSizeExt
             * set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray57_, NULL),
                _mxarray47_,
                _mxarray49_,
                NULL));
        /*
         * 
         * end
         */
        }
        /*
         * 
         * %%%%%%%End Set Active Button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%%%%%%Begin Save image with watermark   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
         */
        mlfAssign(
          &filename3,
          mlfUiputfile(&pathname3, _mxarray204_, _mxarray206_, NULL, NULL));
        mclPrintArray(mclVv(filename3, "filename3"), "filename3");
        mclPrintArray(mclVv(pathname3, "pathname3"), "pathname3");
        /*
         * if isequal(filename3,0)|isequal(pathname3,0)
         */
        {
            mxArray * a_
              = mclInitialize(
                  mlfIsequal(
                    mclVv(filename3, "filename3"), _mxarray14_, NULL));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mlfIsequal(
                         mclVv(pathname3, "pathname3"), _mxarray14_, NULL)))) {
                mxDestroyArray(a_);
                /*
                 * disp('Status>> File is not saving right now...Please try again');
                 */
                mlfDisp(_mxarray208_);
                /*
                 * handles.bool_addWatermarkSave=0;%not save adding watermark
                 */
                mlfIndexAssign(&handles, ".bool_addWatermarkSave", _mxarray14_);
                /*
                 * handles.current_filename3='image_watermark_bak.bmp';
                 */
                mlfIndexAssign(&handles, ".current_filename3", _mxarray196_);
                /*
                 * imwrite(handles.current_marked_im5,handles.current_filename3,'bmp')
                 */
                mlfImwrite(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_marked_im5"),
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
                  _mxarray177_,
                  NULL);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
                mclExitTryBlock();
                /*
                 * return;
                 */
                goto return_;
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * disp(['Status>> File ', pathname3, filename3,'.bmp',' already saved'])
                 */
                mlfDisp(
                  mlfHorzcat(
                    _mxarray210_,
                    mclVv(pathname3, "pathname3"),
                    mclVv(filename3, "filename3"),
                    _mxarray212_,
                    _mxarray214_,
                    NULL));
                /*
                 * filenameWrite=[pathname3 filename3 '.bmp'];
                 */
                mlfAssign(
                  &filenameWrite,
                  mlfHorzcat(
                    mclVv(pathname3, "pathname3"),
                    mclVv(filename3, "filename3"),
                    _mxarray212_,
                    NULL));
                /*
                 * imwrite(handles.current_marked_im5,filenameWrite,'bmp')
                 */
                mlfImwrite(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_marked_im5"),
                  mclVv(filenameWrite, "filenameWrite"),
                  _mxarray177_,
                  NULL);
                /*
                 * title([filename3 '.bmp']);
                 */
                mclAssignAns(
                  &ans,
                  mlfNTitle(
                    0,
                    mlfHorzcat(
                      mclVv(filename3, "filename3"), _mxarray212_, NULL),
                    NULL));
                /*
                 * handles.bool_addWatermarkSave=1;%already save adding watermark
                 */
                mlfIndexAssign(&handles, ".bool_addWatermarkSave", _mxarray0_);
                /*
                 * handles.current_filename3 = filenameWrite;
                 */
                mlfIndexAssign(
                  &handles,
                  ".current_filename3",
                  mclVv(filenameWrite, "filenameWrite"));
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            }
        /*
         * end
         */
        }
    /*
     * catch
     */
    } mlfCatch {
        /*
         * try
         */
        mlfTry {
            /*
             * close(h_waitAdd);
             */
            mclAssignAns(
              &ans, mlfNClose(0, mclVv(h_waitAdd, "h_waitAdd"), NULL));
        /*
         * catch            
         */
        } mlfCatch {
            /*
             * msgbox('Program Can''t initial some parameters.Process will be cancel...','Error initial parameters ','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray158_,
                _mxarray160_,
                _mxarray162_,
                _mxarray127_,
                NULL));
        /*
         * return;
         * end
         */
        } mlfEndCatch
    /*
     * end        
     */
    } mlfEndCatch
    /*
     * %%%%%%%%%End Save image with watermark   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * 
     * %%%%%%%%%%%End Add watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * 
     * 
     * % --- Executes on button press in pushbuttonExtract.
     */
    return_:
    mxDestroyArray(defaultKey);
    mxDestroyArray(keyPrompt);
    mxDestroyArray(dlgKey_title);
    mxDestroyArray(keyNum_lines);
    mxDestroyArray(temp_keyAnswer);
    mxDestroyArray(ans);
    mxDestroyArray(key);
    mxDestroyArray(h_passwdinvalid);
    mxDestroyArray(percentPrompt);
    mxDestroyArray(dlgPercent_title);
    mxDestroyArray(defPercent);
    mxDestroyArray(percentNum_lines);
    mxDestroyArray(temp_percentAnswer);
    mxDestroyArray(percent);
    mxDestroyArray(h_percentinvalid);
    mxDestroyArray(h_waitAdd);
    mxDestroyArray(key_size);
    mxDestroyArray(total_key);
    mxDestroyArray(i);
    mxDestroyArray(infile);
    mxDestroyArray(im5_info);
    mxDestroyArray(im5);
    mxDestroyArray(im5_col);
    mxDestroyArray(im_size_row);
    mxDestroyArray(im_size_col);
    mxDestroyArray(type);
    mxDestroyArray(watermark);
    mxDestroyArray(block_size);
    mxDestroyArray(block_per_row);
    mxDestroyArray(block_per_col);
    mxDestroyArray(max_block);
    mxDestroyArray(k);
    mxDestroyArray(x);
    mxDestroyArray(j);
    mxDestroyArray(arg5);
    mxDestroyArray(num_block);
    mxDestroyArray(num_adding);
    mxDestroyArray(g_max);
    mxDestroyArray(g_min);
    mxDestroyArray(g_avg);
    mxDestroyArray(l);
    mxDestroyArray(tmp);
    mxDestroyArray(wm_info);
    mxDestroyArray(bin_mark);
    mxDestroyArray(marked_im5);
    mxDestroyArray(rand_size);
    mxDestroyArray(seed);
    mxDestroyArray(n_block);
    mxDestroyArray(s);
    mxDestroyArray(m);
    mxDestroyArray(n);
    mxDestroyArray(h_enableSaveImageWithWatermark);
    mxDestroyArray(h_enablepushbuttonImageWithWatermark_info);
    mxDestroyArray(h_enablepushbuttonShowRealImageWithWatermark);
    mxDestroyArray(h_enableExtract);
    mxDestroyArray(h_enablepopupmenuAttackMethod);
    mxDestroyArray(filename3);
    mxDestroyArray(pathname3);
    mxDestroyArray(filenameWrite);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonExtract_Callback" is the
 * implementation version of the "watermark005/pushbuttonExtract_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 679-992). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonExtract_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonExtract_Callback(mxArray * hObject,
                                                     mxArray * eventdata,
                                                     mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWrite = NULL;
    mxArray * pathname4 = NULL;
    mxArray * filename4 = NULL;
    mxArray * h_enablepushbuttonShowRealExtract = NULL;
    mxArray * h_enablepushbuttonExtractedWatermark_info = NULL;
    mxArray * h_enablepushbuttonSaveExtracted = NULL;
    mxArray * sum_go = NULL;
    mxArray * sum_gw = NULL;
    mxArray * extracted_mark = NULL;
    mxArray * l = NULL;
    mxArray * g_avg = NULL;
    mxArray * g_min = NULL;
    mxArray * g_max = NULL;
    mxArray * j = NULL;
    mxArray * i = NULL;
    mxArray * x = NULL;
    mxArray * k = NULL;
    mxArray * max_block = NULL;
    mxArray * block_per_col = NULL;
    mxArray * block_per_row = NULL;
    mxArray * im6_width = NULL;
    mxArray * im6_height = NULL;
    mxArray * im6_size = NULL;
    mxArray * doub_rotateDegree = NULL;
    mxArray * temp_rotateAnswer = NULL;
    mxArray * rotateNum_lines = NULL;
    mxArray * dlgRotate_title = NULL;
    mxArray * rotatePrompt = NULL;
    mxArray * yend = NULL;
    mxArray * ybegin = NULL;
    mxArray * xend = NULL;
    mxArray * xbegin = NULL;
    mxArray * yoffset = NULL;
    mxArray * xoffset = NULL;
    mxArray * offset = NULL;
    mxArray * rect_offset = NULL;
    mxArray * corr_offset = NULL;
    mxArray * xpeak = NULL;
    mxArray * ypeak = NULL;
    mxArray * imax = NULL;
    mxArray * max_c = NULL;
    mxArray * c = NULL;
    mxArray * sub_tmp2 = NULL;
    mxArray * sub_tmp = NULL;
    mxArray * rect_tmp2 = NULL;
    mxArray * rect_tmp = NULL;
    mxArray * tmp2_size = NULL;
    mxArray * tmp_size = NULL;
    mxArray * tmp2 = NULL;
    mxArray * tmp = NULL;
    mxArray * im6_back = NULL;
    mxArray * block_size = NULL;
    mxArray * im_size_col = NULL;
    mxArray * im_size_row = NULL;
    mxArray * im6_col = NULL;
    mxArray * im5_col = NULL;
    mxArray * im5 = NULL;
    mxArray * im6 = NULL;
    mxArray * attack = NULL;
    mxArray * im6_info = NULL;
    mxArray * im5_info = NULL;
    mxArray * h_waitExt = NULL;
    mxArray * ans = NULL;
    mxArray * org_im = NULL;
    mxArray * marked_im = NULL;
    mxArray * attack_type = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonExtract (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * 
     * %function ext(marked_im,org_im,outfile,attack_type);
     * %mark_im-> watermarked image that watermark will be extracted
     * %org_im-> original image that have no this watermark
     * %outfile-> file name that wanna save the extracted watermark
     * %attack type -> type of attack need to be identified
     * %   -'resize' if watermarked image is resized
     * %   -'crop' if watermarked image is cropped
     * %   -0-360 if watermarked image is rotated the angle need to be filled
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%%%%%%%%%%%%%%%%% Begin initial variable   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * try
     */
    mlfTry {
        /*
         * attack_type=handles.current_AttackMode;%attack type
         */
        mlfAssign(
          &attack_type,
          mlfIndexRef(mclVa(handles, "handles"), ".current_AttackMode"));
        /*
         * try
         */
        mlfTry {
            /*
             * marked_im=handles.current_filename3;%image with watermark image
             */
            mlfAssign(
              &marked_im,
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"));
            /*
             * 
             * org_im=handles.current_filename1;%original image
             */
            mlfAssign(
              &org_im,
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"));
        /*
         * catch
         */
        } mlfCatch {
            /*
             * msgbox('Can''t processing extracted watermark Program Error..Please close and open program again.','Process have an error','error','modal') 
             */
            mclPrintAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray216_,
                _mxarray218_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * h_waitExt = waitbar(0,'Please wait... Program is  processing. ');
         */
        mlfAssign(&h_waitExt, mlfNWaitbar(1, _mxarray14_, _mxarray153_, NULL));
        /*
         * 
         * waitbar(0.05,h_waitExt);
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(0, _mxarray220_, mclVv(h_waitExt, "h_waitExt"), NULL));
        /*
         * 
         * im5_info = imfinfo(org_im);%im5 original image
         */
        mlfAssign(
          &im5_info, mlfNImfinfo(1, NULL, mclVv(org_im, "org_im"), NULL));
        /*
         * im6_info = imfinfo(marked_im);%im6 image with watermark
         */
        mlfAssign(
          &im6_info, mlfNImfinfo(1, NULL, mclVv(marked_im, "marked_im"), NULL));
        /*
         * 
         * attack = attack_type;%attack mode
         */
        mlfAssign(&attack, mclVv(attack_type, "attack_type"));
        /*
         * 
         * im6 = imread(marked_im,im6_info.Format);% read image with watermark
         */
        mlfAssign(
          &im6,
          mlfNImread(
            1,
            NULL,
            NULL,
            mclVv(marked_im, "marked_im"),
            mlfIndexRef(mclVv(im6_info, "im6_info"), ".Format"),
            NULL));
        /*
         * im6 = im2double(im6);
         */
        mlfAssign(&im6, mlfIm2double(mclVv(im6, "im6"), NULL));
        /*
         * 
         * im5 = imread(org_im,im5_info.Format);%read original image
         */
        mlfAssign(
          &im5,
          mlfNImread(
            1,
            NULL,
            NULL,
            mclVv(org_im, "org_im"),
            mlfIndexRef(mclVv(im5_info, "im5_info"), ".Format"),
            NULL));
        /*
         * im5 = im2double(im5);
         */
        mlfAssign(&im5, mlfIm2double(mclVv(im5, "im5"), NULL));
        /*
         * 
         * 
         * 
         * 
         * %%%%%%%%%%%%%%%    color image  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * if strcmp(im5_info.ColorType,'truecolor')==1;
         */
        if (mclEqBool(
              mclFeval(
                mclValueVarargout(),
                mlxStrcmp,
                mlfIndexRef(mclVv(im5_info, "im5_info"), ".ColorType"),
                _mxarray155_,
                NULL),
              _mxarray0_)) {
            /*
             * im5_col = im5;
             */
            mlfAssign(&im5_col, mclVv(im5, "im5"));
            /*
             * im5 = im5_col(:,:,3);
             */
            mlfAssign(
              &im5,
              mlfIndexRef(
                mclVv(im5_col, "im5_col"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray88_));
        /*
         * end;
         */
        }
        /*
         * if strcmp(im6_info.ColorType,'truecolor')==1;
         */
        if (mclEqBool(
              mclFeval(
                mclValueVarargout(),
                mlxStrcmp,
                mlfIndexRef(mclVv(im6_info, "im6_info"), ".ColorType"),
                _mxarray155_,
                NULL),
              _mxarray0_)) {
            /*
             * im6_col = im6;
             */
            mlfAssign(&im6_col, mclVv(im6, "im6"));
            /*
             * im6 = im6_col(:,:,3);
             */
            mlfAssign(
              &im6,
              mlfIndexRef(
                mclVv(im6_col, "im6_col"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray88_));
        /*
         * end;
         */
        }
        /*
         * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * im_size_row = im5_info.Width;
         */
        mlfAssign(
          &im_size_row, mlfIndexRef(mclVv(im5_info, "im5_info"), ".Width"));
        /*
         * im_size_col = im5_info.Height;
         */
        mlfAssign(
          &im_size_col, mlfIndexRef(mclVv(im5_info, "im5_info"), ".Height"));
        /*
         * 
         * block_size = handles.temp_popupblocksizeExt;
         */
        mlfAssign(
          &block_size,
          mlfIndexRef(mclVa(handles, "handles"), ".temp_popupblocksizeExt"));
        /*
         * 
         * 
         * %%%%%%%%%%%%%%%%%%%%%%% End initial variable   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * 
         * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * %%%%%%%%%%%%%%%%% Begin Check Attack mode   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %%%%% detect attacked image and recover %%%%%%%
         * try
         */
        mlfTry {
            /*
             * %%%%% detect resize %%%%%%%
             * if strcmp(attack,'resize')==1;
             */
            if (mclEqBool(
                  mlfStrcmp(mclVv(attack, "attack"), _mxarray221_),
                  _mxarray0_)) {
                /*
                 * im6_back = im6;
                 */
                mlfAssign(&im6_back, mclVv(im6, "im6"));
                /*
                 * im6 = imresize(im6,[im_size_col,im_size_row]);
                 */
                mlfAssign(
                  &im6,
                  mlfNImresize(
                    0,
                    mclValueVarargout(),
                    mclVv(im6, "im6"),
                    mlfHorzcat(
                      mclVv(im_size_col, "im_size_col"),
                      mclVv(im_size_row, "im_size_row"),
                      NULL),
                    NULL));
            /*
             * end;
             */
            }
            /*
             * 
             * %%%%% detect crop %%%%%%%
             * if strcmp(attack,'crop')==1;
             */
            if (mclEqBool(
                  mlfStrcmp(mclVv(attack, "attack"), _mxarray223_),
                  _mxarray0_)) {
                /*
                 * im6_back = im6;
                 */
                mlfAssign(&im6_back, mclVv(im6, "im6"));
                /*
                 * 
                 * tmp = im6;%image with watermark
                 */
                mlfAssign(&tmp, mclVv(im6, "im6"));
                /*
                 * tmp2 = im5;%original image
                 */
                mlfAssign(&tmp2, mclVv(im5, "im5"));
                /*
                 * tmp = im2double(tmp);
                 */
                mlfAssign(&tmp, mlfIm2double(mclVv(tmp, "tmp"), NULL));
                /*
                 * tmp2 = im2double(tmp2);
                 */
                mlfAssign(&tmp2, mlfIm2double(mclVv(tmp2, "tmp2"), NULL));
                /*
                 * tmp_size = size(tmp);
                 */
                mlfAssign(
                  &tmp_size,
                  mlfSize(mclValueVarargout(), mclVv(tmp, "tmp"), NULL));
                /*
                 * tmp2_size = size(tmp2);
                 */
                mlfAssign(
                  &tmp2_size,
                  mlfSize(mclValueVarargout(), mclVv(tmp2, "tmp2"), NULL));
                /*
                 * rect_tmp = [3 3 (tmp_size(2)-3) (tmp_size(1)-3)];
                 */
                mlfAssign(
                  &rect_tmp,
                  mlfHorzcat(
                    _mxarray88_,
                    _mxarray88_,
                    mclMinus(
                      mclIntArrayRef1(mclVv(tmp_size, "tmp_size"), 2),
                      _mxarray88_),
                    mclMinus(
                      mclIntArrayRef1(mclVv(tmp_size, "tmp_size"), 1),
                      _mxarray88_),
                    NULL));
                /*
                 * rect_tmp2 = [3 3 (tmp2_size(2)-3) (tmp2_size(1)-3)];
                 */
                mlfAssign(
                  &rect_tmp2,
                  mlfHorzcat(
                    _mxarray88_,
                    _mxarray88_,
                    mclMinus(
                      mclIntArrayRef1(mclVv(tmp2_size, "tmp2_size"), 2),
                      _mxarray88_),
                    mclMinus(
                      mclIntArrayRef1(mclVv(tmp2_size, "tmp2_size"), 1),
                      _mxarray88_),
                    NULL));
                /*
                 * sub_tmp = imcrop(tmp,rect_tmp);
                 */
                mlfAssign(
                  &sub_tmp,
                  mlfNImcrop(
                    0,
                    mclValueVarargout(),
                    mclVv(tmp, "tmp"),
                    mclVv(rect_tmp, "rect_tmp"),
                    NULL));
                /*
                 * sub_tmp2 = imcrop(tmp2,rect_tmp2);
                 */
                mlfAssign(
                  &sub_tmp2,
                  mlfNImcrop(
                    0,
                    mclValueVarargout(),
                    mclVv(tmp2, "tmp2"),
                    mclVv(rect_tmp2, "rect_tmp2"),
                    NULL));
                /*
                 * 
                 * 
                 * c = normxcorr2(sub_tmp(:,:),sub_tmp2(:,:));
                 */
                mlfAssign(
                  &c,
                  mlfNormxcorr2(
                    mclArrayRef2(
                      mclVv(sub_tmp, "sub_tmp"),
                      mlfCreateColonIndex(),
                      mlfCreateColonIndex()),
                    mclArrayRef2(
                      mclVv(sub_tmp2, "sub_tmp2"),
                      mlfCreateColonIndex(),
                      mlfCreateColonIndex()),
                    NULL));
                /*
                 * [max_c,imax] = max(abs(c(:)));
                 */
                mlfAssign(
                  &max_c,
                  mlfMax(
                    &imax,
                    mlfAbs(mclArrayRef1(mclVv(c, "c"), mlfCreateColonIndex())),
                    NULL,
                    NULL));
                /*
                 * [ypeak,xpeak]=ind2sub(size(c),imax(1));
                 */
                mlfNInd2sub(
                  0,
                  mlfVarargout(&ypeak, &xpeak, NULL),
                  mlfSize(mclValueVarargout(), mclVv(c, "c"), NULL),
                  mclIntArrayRef1(mclVv(imax, "imax"), 1));
                /*
                 * 
                 * corr_offset = [(xpeak-size(sub_tmp,2)) (ypeak-size(sub_tmp,1))];
                 */
                mlfAssign(
                  &corr_offset,
                  mlfHorzcat(
                    mclMinus(
                      mclVv(xpeak, "xpeak"),
                      mlfSize(
                        mclValueVarargout(),
                        mclVv(sub_tmp, "sub_tmp"),
                        _mxarray85_)),
                    mclMinus(
                      mclVv(ypeak, "ypeak"),
                      mlfSize(
                        mclValueVarargout(),
                        mclVv(sub_tmp, "sub_tmp"),
                        _mxarray0_)),
                    NULL));
                /*
                 * rect_offset = [(rect_tmp2(1)-rect_tmp(1)) (rect_tmp2(2)-rect_tmp(2))];
                 */
                mlfAssign(
                  &rect_offset,
                  mlfHorzcat(
                    mclMinus(
                      mclIntArrayRef1(mclVv(rect_tmp2, "rect_tmp2"), 1),
                      mclIntArrayRef1(mclVv(rect_tmp, "rect_tmp"), 1)),
                    mclMinus(
                      mclIntArrayRef1(mclVv(rect_tmp2, "rect_tmp2"), 2),
                      mclIntArrayRef1(mclVv(rect_tmp, "rect_tmp"), 2)),
                    NULL));
                /*
                 * 
                 * offset = corr_offset+rect_offset;
                 */
                mlfAssign(
                  &offset,
                  mclPlus(
                    mclVv(corr_offset, "corr_offset"),
                    mclVv(rect_offset, "rect_offset")));
                /*
                 * xoffset = offset(1);
                 */
                mlfAssign(
                  &xoffset, mclIntArrayRef1(mclVv(offset, "offset"), 1));
                /*
                 * yoffset = offset(2);
                 */
                mlfAssign(
                  &yoffset, mclIntArrayRef1(mclVv(offset, "offset"), 2));
                /*
                 * 
                 * xbegin = xoffset + 1;
                 */
                mlfAssign(
                  &xbegin, mclPlus(mclVv(xoffset, "xoffset"), _mxarray0_));
                /*
                 * xend = xoffset+size(tmp,2);
                 */
                mlfAssign(
                  &xend,
                  mclPlus(
                    mclVv(xoffset, "xoffset"),
                    mlfSize(
                      mclValueVarargout(), mclVv(tmp, "tmp"), _mxarray85_)));
                /*
                 * ybegin = yoffset+1;
                 */
                mlfAssign(
                  &ybegin, mclPlus(mclVv(yoffset, "yoffset"), _mxarray0_));
                /*
                 * yend = yoffset+size(tmp,1);
                 */
                mlfAssign(
                  &yend,
                  mclPlus(
                    mclVv(yoffset, "yoffset"),
                    mlfSize(
                      mclValueVarargout(), mclVv(tmp, "tmp"), _mxarray0_)));
                /*
                 * 
                 * tmp2(:,:) = 1;%original image
                 */
                mclArrayAssign2(
                  &tmp2,
                  _mxarray0_,
                  mlfCreateColonIndex(),
                  mlfCreateColonIndex());
                /*
                 * tmp2(ybegin:yend,xbegin:xend) = tmp;
                 */
                mclArrayAssign2(
                  &tmp2,
                  mclVv(tmp, "tmp"),
                  mlfColon(mclVv(ybegin, "ybegin"), mclVv(yend, "yend"), NULL),
                  mlfColon(mclVv(xbegin, "xbegin"), mclVv(xend, "xend"), NULL));
                /*
                 * im6 =tmp2;%image with watermark
                 */
                mlfAssign(&im6, mclVv(tmp2, "tmp2"));
            /*
             * end;
             */
            }
            /*
             * 
             * %%%%% detect rotate %%%%%%%
             * if strcmp(attack,'rotate')==1;
             */
            if (mclEqBool(
                  mlfStrcmp(mclVv(attack, "attack"), _mxarray225_),
                  _mxarray0_)) {
                /*
                 * 
                 * rotatePrompt={'Please input angle that picture had been rotate for extract watermark image(Angle in Degree)'};
                 */
                mlfAssign(&rotatePrompt, _mxarray227_);
                /*
                 * dlgRotate_title='Input angle to extract watermark';
                 */
                mlfAssign(&dlgRotate_title, _mxarray230_);
                /*
                 * %defRotate     = {'90'};
                 * rotateNum_lines=1;
                 */
                mlfAssign(&rotateNum_lines, _mxarray0_);
                /*
                 * 
                 * %%%% input Rotate number %%%%%%%%%%%
                 * temp_rotateAnswer=inputdlg(rotatePrompt,dlgRotate_title,rotateNum_lines);
                 */
                mlfAssign(
                  &temp_rotateAnswer,
                  mlfNInputdlg(
                    1,
                    mclVv(rotatePrompt, "rotatePrompt"),
                    mclVv(dlgRotate_title, "dlgRotate_title"),
                    mclVv(rotateNum_lines, "rotateNum_lines"),
                    NULL,
                    NULL));
                /*
                 * 
                 * if isempty(temp_rotateAnswer)
                 */
                if (mlfTobool(
                      mlfIsempty(
                        mclVv(temp_rotateAnswer, "temp_rotateAnswer")))) {
                    /*
                     * msgbox('You cancel input angle program will do nothing ','Cancel input angle ','warn','modal');
                     */
                    mclAssignAns(
                      &ans,
                      mlfNMsgbox(
                        0,
                        mclAnsVarargout(),
                        _mxarray232_,
                        _mxarray234_,
                        _mxarray125_,
                        _mxarray127_,
                        NULL));
                    /*
                     * delete(h_waitExt);
                     */
                    mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
                    mclExitTryBlock();
                    mclExitTryBlock();
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * end;    
                 */
                }
                /*
                 * 
                 * if isequal(temp_rotateAnswer,{''})
                 */
                if (mlfTobool(
                      mlfIsequal(
                        mclVv(temp_rotateAnswer, "temp_rotateAnswer"),
                        _mxarray129_, NULL))) {
                    /*
                     * % rotate=defaultRotate;
                     * msgbox('You don''t input angle integer program will do nothing','Angle Rotate Error','error','modal');
                     */
                    mclAssignAns(
                      &ans,
                      mlfNMsgbox(
                        0,
                        mclAnsVarargout(),
                        _mxarray236_,
                        _mxarray238_,
                        _mxarray162_,
                        _mxarray127_,
                        NULL));
                    /*
                     * delete(h_waitExt);
                     */
                    mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
                    mclExitTryBlock();
                    mclExitTryBlock();
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * else 
                 */
                } else {
                    /*
                     * if isnan(str2double(temp_rotateAnswer))
                     */
                    if (mlfTobool(
                          mlfIsnan(
                            mlfStr2double(
                              mclVv(
                                temp_rotateAnswer, "temp_rotateAnswer"))))) {
                        /*
                         * msgbox('You can input angle only 0-360...','Angle Rotate Input Error','error','modal');
                         */
                        mclAssignAns(
                          &ans,
                          mlfNMsgbox(
                            0,
                            mclAnsVarargout(),
                            _mxarray240_,
                            _mxarray242_,
                            _mxarray162_,
                            _mxarray127_,
                            NULL));
                        /*
                         * delete(h_waitExt);
                         */
                        mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
                        mclExitTryBlock();
                        mclExitTryBlock();
                        /*
                         * return;
                         */
                        goto return_;
                    /*
                     * end;
                     */
                    }
                /*
                 * end;
                 */
                }
                /*
                 * 
                 * %str_rotateDegree=temp_rotateAnswer;
                 * doub_rotateDegree=str2double(temp_rotateAnswer);
                 */
                mlfAssign(
                  &doub_rotateDegree,
                  mlfStr2double(mclVv(temp_rotateAnswer, "temp_rotateAnswer")));
                /*
                 * 
                 * im6_back = im6;%image with watermark
                 */
                mlfAssign(&im6_back, mclVv(im6, "im6"));
                /*
                 * doub_rotateDegree = 360-doub_rotateDegree;
                 */
                mlfAssign(
                  &doub_rotateDegree,
                  mclMinus(
                    _mxarray244_,
                    mclVv(doub_rotateDegree, "doub_rotateDegree")));
                /*
                 * im6 = imrotate(im6,doub_rotateDegree);
                 */
                mlfAssign(
                  &im6,
                  mlfNImrotate(
                    0,
                    mclValueVarargout(),
                    mclVv(im6, "im6"),
                    mclVv(doub_rotateDegree, "doub_rotateDegree"),
                    NULL));
                /*
                 * if doub_rotateDegree~=0 && doub_rotateDegree~=90 && doub_rotateDegree~=180 && doub_rotateDegree~=270 && doub_rotateDegree~=360;
                 */
                if (mclScalarToBool(
                      mclNe(
                        mclVv(doub_rotateDegree, "doub_rotateDegree"),
                        _mxarray14_))
                    && mclScalarToBool(
                         mclNe(
                           mclVv(doub_rotateDegree, "doub_rotateDegree"),
                           _mxarray245_))
                    && mclScalarToBool(
                         mclNe(
                           mclVv(doub_rotateDegree, "doub_rotateDegree"),
                           _mxarray246_))
                    && mclScalarToBool(
                         mclNe(
                           mclVv(doub_rotateDegree, "doub_rotateDegree"),
                           _mxarray247_))
                    && mclScalarToBool(
                         mclNe(
                           mclVv(doub_rotateDegree, "doub_rotateDegree"),
                           _mxarray244_))) {
                    /*
                     * im6_size = size(im6);
                     */
                    mlfAssign(
                      &im6_size,
                      mlfSize(mclValueVarargout(), mclVv(im6, "im6"), NULL));
                    /*
                     * im6_height = im6_size(1);
                     */
                    mlfAssign(
                      &im6_height,
                      mclIntArrayRef1(mclVv(im6_size, "im6_size"), 1));
                    /*
                     * im6_width = im6_size(2);
                     */
                    mlfAssign(
                      &im6_width,
                      mclIntArrayRef1(mclVv(im6_size, "im6_size"), 2));
                    /*
                     * im6_height = ceil((im6_height-im_size_col)/2);
                     */
                    mlfAssign(
                      &im6_height,
                      mlfCeil(
                        mclMrdivide(
                          mclMinus(
                            mclVv(im6_height, "im6_height"),
                            mclVv(im_size_col, "im_size_col")),
                          _mxarray85_)));
                    /*
                     * im6_width = ceil((im6_width-im_size_row)/2);
                     */
                    mlfAssign(
                      &im6_width,
                      mlfCeil(
                        mclMrdivide(
                          mclMinus(
                            mclVv(im6_width, "im6_width"),
                            mclVv(im_size_row, "im_size_row")),
                          _mxarray85_)));
                    /*
                     * im6 = imcrop(im6,[im6_width im6_height im_size_col-1 im_size_row-1]);
                     */
                    mlfAssign(
                      &im6,
                      mlfNImcrop(
                        0,
                        mclValueVarargout(),
                        mclVv(im6, "im6"),
                        mlfHorzcat(
                          mclVv(im6_width, "im6_width"),
                          mclVv(im6_height, "im6_height"),
                          mclMinus(
                            mclVv(im_size_col, "im_size_col"), _mxarray0_),
                          mclMinus(
                            mclVv(im_size_row, "im_size_row"), _mxarray0_),
                          NULL),
                        NULL));
                /*
                 * end;
                 */
                }
            /*
             * end;
             */
            }
        /*
         * catch
         */
        } mlfCatch {
            /*
             * msgbox('Program found attack mode error...','Attack mode Error','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray248_,
                _mxarray250_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            /*
             * delete(h_waitExt);
             */
            mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
            mclExitTryBlock();
            /*
             * return;
             */
            goto return_;
        /*
         * end
         */
        } mlfEndCatch
        /*
         * waitbar(0.3,h_waitExt);
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(0, _mxarray168_, mclVv(h_waitExt, "h_waitExt"), NULL));
        /*
         * %%%%%%%%%%%%%%%%% End Check Attack mode   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * 
         * %marked_im_size_row = im6_info.Width;
         * %marked_im_size_col = im6_info.Height;
         * %===========find g_max,g_min and g_avg of orginal image================
         * if mod(im_size_row,block_size)==0 & mod(im_size_col,block_size)==0;
         */
        {
            mxArray * a_
              = mclInitialize(
                  mclEq(
                    mlfMod(
                      mclVv(im_size_row, "im_size_row"),
                      mclVv(block_size, "block_size")),
                    _mxarray14_));
            if (mlfTobool(a_)
                && mlfTobool(
                     mclAnd(
                       a_,
                       mclEq(
                         mlfMod(
                           mclVv(im_size_col, "im_size_col"),
                           mclVv(block_size, "block_size")),
                         _mxarray14_)))) {
                mxDestroyArray(a_);
                /*
                 * block_per_row = im_size_row/block_size;
                 */
                mlfAssign(
                  &block_per_row,
                  mclMrdivide(
                    mclVv(im_size_row, "im_size_row"),
                    mclVv(block_size, "block_size")));
                /*
                 * block_per_col = im_size_col/block_size;
                 */
                mlfAssign(
                  &block_per_col,
                  mclMrdivide(
                    mclVv(im_size_col, "im_size_col"),
                    mclVv(block_size, "block_size")));
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * msgbox('Miss Match between BLOCK and IMAGE size','ERROR','error');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray164_,
                    _mxarray166_,
                    _mxarray162_,
                    NULL));
                mclExitTryBlock();
                /*
                 * return;
                 */
                goto return_;
            }
        /*
         * end;
         */
        }
        /*
         * if block_per_row>=block_per_col;
         */
        if (mclGeBool(
              mclVv(block_per_row, "block_per_row"),
              mclVv(block_per_col, "block_per_col"))) {
            /*
             * max_block = block_per_row;
             */
            mlfAssign(&max_block, mclVv(block_per_row, "block_per_row"));
        /*
         * else
         */
        } else {
            /*
             * max_block = block_per_col;
             */
            mlfAssign(&max_block, mclVv(block_per_col, "block_per_col"));
        /*
         * end;
         */
        }
        /*
         * k=1;
         */
        mlfAssign(&k, _mxarray0_);
        /*
         * x(1:max_block,1:block_size)=0;
         */
        mclArrayAssign2(
          &x,
          _mxarray14_,
          mlfColon(_mxarray0_, mclVv(max_block, "max_block"), NULL),
          mlfColon(_mxarray0_, mclVv(block_size, "block_size"), NULL));
        /*
         * for i = 1:max_block;
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(max_block, "max_block"));
            if (v_ > e_) {
                mlfAssign(&i, _mxarray11_);
            } else {
                /*
                 * for j = 1:block_size;
                 * x(i,j)=k;
                 * k = k+1;
                 * end;
                 * end;
                 */
                for (; ; ) {
                    int v_3 = mclForIntStart(1);
                    int e_3 = mclForIntEnd(mclVv(block_size, "block_size"));
                    if (v_3 > e_3) {
                        mlfAssign(&j, _mxarray11_);
                    } else {
                        for (; ; ) {
                            mclIntArrayAssign2(&x, mclVv(k, "k"), v_, v_3);
                            mlfAssign(&k, mclPlus(mclVv(k, "k"), _mxarray0_));
                            if (v_3 == e_3) {
                                break;
                            }
                            ++v_3;
                        }
                        mlfAssign(&j, mlfScalar(v_3));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&i, mlfScalar(v_));
            }
        }
        /*
         * g_max(1:block_per_col,1:block_per_row) = 0;
         */
        mclArrayAssign2(
          &g_max,
          _mxarray14_,
          mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
          mlfColon(_mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
        /*
         * g_min(1:block_per_col,1:block_per_row) = 0;
         */
        mclArrayAssign2(
          &g_min,
          _mxarray14_,
          mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
          mlfColon(_mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
        /*
         * g_avg(1:block_per_col,1:block_per_row) = 0;
         */
        mclArrayAssign2(
          &g_avg,
          _mxarray14_,
          mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
          mlfColon(_mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
        /*
         * 
         * waitbar(0.5,h_waitExt);
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(0, _mxarray170_, mclVv(h_waitExt, "h_waitExt"), NULL));
        /*
         * for k = 1:block_per_col;
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(block_per_col, "block_per_col"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray11_);
            } else {
                /*
                 * for l = 1:block_per_row;
                 * tmp= max(im5(x(k,:),x(l,:)));
                 * g_max(k,l)= max(tmp);
                 * 
                 * tmp= min(im5(x(k,:),x(l,:)));
                 * g_min(k,l)= min(tmp);
                 * 
                 * tmp= sum(im5(x(k,:),x(l,:)));
                 * tmp= sum(tmp);
                 * g_avg(k,l)= tmp/(block_size*block_size);
                 * end;
                 * end;
                 */
                for (; ; ) {
                    int v_4 = mclForIntStart(1);
                    int e_4
                      = mclForIntEnd(mclVv(block_per_row, "block_per_row"));
                    if (v_4 > e_4) {
                        mlfAssign(&l, _mxarray11_);
                    } else {
                        for (; ; ) {
                            mlfAssign(
                              &tmp,
                              mlfMax(
                                NULL,
                                mclArrayRef2(
                                  mclVv(im5, "im5"),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_),
                                    mlfCreateColonIndex()),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_4),
                                    mlfCreateColonIndex())),
                                NULL,
                                NULL));
                            mclIntArrayAssign2(
                              &g_max,
                              mlfMax(NULL, mclVv(tmp, "tmp"), NULL, NULL),
                              v_,
                              v_4);
                            mlfAssign(
                              &tmp,
                              mlfMin(
                                NULL,
                                mclArrayRef2(
                                  mclVv(im5, "im5"),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_),
                                    mlfCreateColonIndex()),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_4),
                                    mlfCreateColonIndex())),
                                NULL,
                                NULL));
                            mclIntArrayAssign2(
                              &g_min,
                              mlfMin(NULL, mclVv(tmp, "tmp"), NULL, NULL),
                              v_,
                              v_4);
                            mlfAssign(
                              &tmp,
                              mlfSum(
                                mclArrayRef2(
                                  mclVv(im5, "im5"),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_),
                                    mlfCreateColonIndex()),
                                  mclArrayRef2(
                                    mclVv(x, "x"),
                                    mlfScalar(v_4),
                                    mlfCreateColonIndex())),
                                NULL));
                            mlfAssign(&tmp, mlfSum(mclVv(tmp, "tmp"), NULL));
                            mclIntArrayAssign2(
                              &g_avg,
                              mclMrdivide(
                                mclVv(tmp, "tmp"),
                                mclMtimes(
                                  mclVv(block_size, "block_size"),
                                  mclVv(block_size, "block_size"))),
                              v_,
                              v_4);
                            if (v_4 == e_4) {
                                break;
                            }
                            ++v_4;
                        }
                        mlfAssign(&l, mlfScalar(v_4));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * 
         * waitbar(0.7,h_waitExt);
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(0, _mxarray183_, mclVv(h_waitExt, "h_waitExt"), NULL));
        /*
         * %%%%%%%%%%%%extract watermark by assummimg that size of w_im and o_im is equal%%%%%%%%%%%%%%%%%%%%%%%%%%
         * extracted_mark(1:block_per_col,1:block_per_row) = 1;
         */
        mclArrayAssign2(
          &extracted_mark,
          _mxarray0_,
          mlfColon(_mxarray0_, mclVv(block_per_col, "block_per_col"), NULL),
          mlfColon(_mxarray0_, mclVv(block_per_row, "block_per_row"), NULL));
        /*
         * sum_gw = 0;
         */
        mlfAssign(&sum_gw, _mxarray14_);
        /*
         * sum_go = 0;
         */
        mlfAssign(&sum_go, _mxarray14_);
        /*
         * %=======initial random===========================
         * % rand_size = 60;%mean 10,000 blocks,should not more than sqrt(n_block)
         * % seed = 18;
         * % n_block = block_per_row*block_per_col;
         * % s = randint(rand_size,rand_size,[1,n_block],seed);
         * % %================================================
         * for k = 1:block_per_col;
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(block_per_col, "block_per_col"));
            if (v_ > e_) {
                mlfAssign(&k, _mxarray11_);
            } else {
                /*
                 * for l = 1:block_per_row;
                 * for i = x(k,:);
                 * for j = x(l,:);
                 * sum_gw = sum_gw + im6(i,j);%marked image
                 * sum_go = sum_go + im5(i,j);%original image
                 * end;
                 * end;
                 * if sum_gw < sum_go;
                 * extracted_mark(k,l) = 0;%black
                 * elseif sum_gw >= sum_go;
                 * extracted_mark(k,l) = 1;%white
                 * end;
                 * sum_gw = 0;
                 * sum_go = 0;
                 * 
                 * end;
                 * end;
                 */
                for (; ; ) {
                    int v_5 = mclForIntStart(1);
                    int e_5
                      = mclForIntEnd(mclVv(block_per_row, "block_per_row"));
                    if (v_5 > e_5) {
                        mlfAssign(&l, _mxarray11_);
                    } else {
                        for (; ; ) {
                            mclForLoopIterator viter__;
                            for (mclForStart(
                                   &viter__,
                                   mclArrayRef2(
                                     mclVv(x, "x"),
                                     mlfScalar(v_),
                                     mlfCreateColonIndex()),
                                   NULL,
                                   NULL);
                                 mclForNext(&viter__, &i);
                                 ) {
                                mclForLoopIterator viter__1;
                                for (mclForStart(
                                       &viter__1,
                                       mclArrayRef2(
                                         mclVv(x, "x"),
                                         mlfScalar(v_5),
                                         mlfCreateColonIndex()),
                                       NULL,
                                       NULL);
                                     mclForNext(&viter__1, &j);
                                     ) {
                                    mlfAssign(
                                      &sum_gw,
                                      mclPlus(
                                        mclVv(sum_gw, "sum_gw"),
                                        mclArrayRef2(
                                          mclVv(im6, "im6"),
                                          mclVv(i, "i"),
                                          mclVv(j, "j"))));
                                    mlfAssign(
                                      &sum_go,
                                      mclPlus(
                                        mclVv(sum_go, "sum_go"),
                                        mclArrayRef2(
                                          mclVv(im5, "im5"),
                                          mclVv(i, "i"),
                                          mclVv(j, "j"))));
                                }
                                mclDestroyForLoopIterator(viter__1);
                            }
                            mclDestroyForLoopIterator(viter__);
                            if (mclLtBool(
                                  mclVv(sum_gw, "sum_gw"),
                                  mclVv(sum_go, "sum_go"))) {
                                mclIntArrayAssign2(
                                  &extracted_mark, _mxarray14_, v_, v_5);
                            } else if (mclGeBool(
                                         mclVv(sum_gw, "sum_gw"),
                                         mclVv(sum_go, "sum_go"))) {
                                mclIntArrayAssign2(
                                  &extracted_mark, _mxarray0_, v_, v_5);
                            }
                            mlfAssign(&sum_gw, _mxarray14_);
                            mlfAssign(&sum_go, _mxarray14_);
                            if (v_5 == e_5) {
                                break;
                            }
                            ++v_5;
                        }
                        mlfAssign(&l, mlfScalar(v_5));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k, mlfScalar(v_));
            }
        }
        /*
         * waitbar(0.9,h_waitExt);
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(0, _mxarray185_, mclVv(h_waitExt, "h_waitExt"), NULL));
        /*
         * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         * if strcmp(im5_info.ColorType,'truecolor')==1;
         */
        if (mclEqBool(
              mclFeval(
                mclValueVarargout(),
                mlxStrcmp,
                mlfIndexRef(mclVv(im5_info, "im5_info"), ".ColorType"),
                _mxarray155_,
                NULL),
              _mxarray0_)) {
            /*
             * im5 = im5_col;
             */
            mlfAssign(&im5, mclVv(im5_col, "im5_col"));
        /*
         * end;
         */
        }
        /*
         * if strcmp(im6_info.ColorType,'truecolor')==1;
         */
        if (mclEqBool(
              mclFeval(
                mclValueVarargout(),
                mlxStrcmp,
                mlfIndexRef(mclVv(im6_info, "im6_info"), ".ColorType"),
                _mxarray155_,
                NULL),
              _mxarray0_)) {
            /*
             * im6 = im6_col;
             */
            mlfAssign(&im6, mclVv(im6_col, "im6_col"));
        /*
         * end;
         */
        }
        /*
         * waitbar(1,h_waitExt,'Process is successful');
         */
        mclAssignAns(
          &ans,
          mlfNWaitbar(
            0, _mxarray0_, mclVv(h_waitExt, "h_waitExt"), _mxarray190_, NULL));
        /*
         * delete(h_waitExt);
         */
        mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
        /*
         * 
         * 
         * 
         * try
         */
        mlfTry {
            /*
             * handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(extracted_mark),title('Extracted Watermark');
             */
            mlfIndexAssign(
              &handles,
              ".h_subplotExtractedWatermark",
              mlfNSubplot(1, _mxarray35_, _mxarray252_, NULL, NULL));
            mclPrintArray(mclVa(handles, "handles"), "handles");
            mclPrintAns(
              &ans,
              mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
            mclPrintAns(
              &ans,
              mlfNImshow(0, mclVv(extracted_mark, "extracted_mark"), NULL));
            mclAssignAns(&ans, mlfNTitle(0, _mxarray254_, NULL));
            /*
             * clc;
             */
            mlfClc();
        /*
         * 
         * catch 
         */
        } mlfCatch {
            /*
             * 
             * handles.current_filename4='image_watermark_extract_bak.bmp';
             */
            mlfIndexAssign(&handles, ".current_filename4", _mxarray256_);
            /*
             * imwrite(extracted_mark,handles.current_filename4,'bmp')
             */
            mlfImwrite(
              mclVv(extracted_mark, "extracted_mark"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"),
              _mxarray177_,
              NULL);
            /*
             * handles.h_subplotExtractedWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename4),title('Extracted Watermark');      
             */
            mlfIndexAssign(
              &handles,
              ".h_subplotExtractedWatermark",
              mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
            mclPrintArray(mclVa(handles, "handles"), "handles");
            mclPrintAns(
              &ans,
              mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
            mclPrintAns(
              &ans,
              mlfNImshow(
                0,
                mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"),
                NULL));
            mclAssignAns(&ans, mlfNTitle(0, _mxarray254_, NULL));
        /*
         * end    
         */
        } mlfEndCatch
        /*
         * 
         * 
         * 
         * 
         * 
         * 
         * handles.bool_openExtractWatermark=1;%set open extracted watermark image already
         */
        mlfIndexAssign(&handles, ".bool_openExtractWatermark", _mxarray0_);
        /*
         * handles.current_extracted_mark=extracted_mark;
         */
        mlfIndexAssign(
          &handles,
          ".current_extracted_mark",
          mclVv(extracted_mark, "extracted_mark"));
        /*
         * 
         * 
         * 
         * %enable pushbuttonSaveExtracted
         * h_enablepushbuttonSaveExtracted=findobj('tag','pushbuttonSaveExtracted','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonSaveExtracted,
          mlfFindobj(
            _mxarray43_, _mxarray258_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonSaveExtracted,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonSaveExtracted,
              "h_enablepushbuttonSaveExtracted"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonExtractedWatermark_info
         * h_enablepushbuttonExtractedWatermark_info=findobj('tag','pushbuttonExtractedWatermark_info','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonExtractedWatermark_info,
          mlfFindobj(
            _mxarray43_, _mxarray260_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonExtractedWatermark_info,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonExtractedWatermark_info,
              "h_enablepushbuttonExtractedWatermark_info"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonShowRealExtract
         * h_enablepushbuttonShowRealExtract=findobj('tag','pushbuttonShowRealExtract','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonShowRealExtract,
          mlfFindobj(
            _mxarray43_, _mxarray262_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonShowRealExtract,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonShowRealExtract,
              "h_enablepushbuttonShowRealExtract"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * [filename4,pathname4]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
         */
        mlfAssign(
          &filename4,
          mlfUiputfile(&pathname4, _mxarray204_, _mxarray206_, NULL, NULL));
        mclPrintArray(mclVv(filename4, "filename4"), "filename4");
        mclPrintArray(mclVv(pathname4, "pathname4"), "pathname4");
        /*
         * if isequal(filename4,0)|isequal(pathname4,0)
         */
        {
            mxArray * a_
              = mclInitialize(
                  mlfIsequal(
                    mclVv(filename4, "filename4"), _mxarray14_, NULL));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mlfIsequal(
                         mclVv(pathname4, "pathname4"), _mxarray14_, NULL)))) {
                mxDestroyArray(a_);
                /*
                 * disp('Status>> File is not saving right now...Please try again');
                 */
                mlfDisp(_mxarray208_);
                /*
                 * handles.bool_extractWatermarkSave=0;%not save extracted watermark
                 */
                mlfIndexAssign(
                  &handles, ".bool_extractWatermarkSave", _mxarray14_);
                /*
                 * handles.current_filename4='image_extracted_bak.bmp';
                 */
                mlfIndexAssign(&handles, ".current_filename4", _mxarray264_);
                /*
                 * imwrite(handles.current_extracted_mark,handles.current_filename4,'bmp')
                 */
                mlfImwrite(
                  mlfIndexRef(
                    mclVa(handles, "handles"), ".current_extracted_mark"),
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"),
                  _mxarray177_,
                  NULL);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
                mclExitTryBlock();
                /*
                 * return;
                 */
                goto return_;
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * disp(['Status>> File ', pathname4, filename4,'.bmp',' already saved'])
                 */
                mlfDisp(
                  mlfHorzcat(
                    _mxarray210_,
                    mclVv(pathname4, "pathname4"),
                    mclVv(filename4, "filename4"),
                    _mxarray212_,
                    _mxarray214_,
                    NULL));
                /*
                 * filenameWrite=[pathname4 filename4 '.bmp'];
                 */
                mlfAssign(
                  &filenameWrite,
                  mlfHorzcat(
                    mclVv(pathname4, "pathname4"),
                    mclVv(filename4, "filename4"),
                    _mxarray212_,
                    NULL));
                /*
                 * imwrite(handles.current_extracted_mark,filenameWrite,'bmp')
                 */
                mlfImwrite(
                  mlfIndexRef(
                    mclVa(handles, "handles"), ".current_extracted_mark"),
                  mclVv(filenameWrite, "filenameWrite"),
                  _mxarray177_,
                  NULL);
                /*
                 * title([filename4 '.bmp']);
                 */
                mclAssignAns(
                  &ans,
                  mlfNTitle(
                    0,
                    mlfHorzcat(
                      mclVv(filename4, "filename4"), _mxarray212_, NULL),
                    NULL));
                /*
                 * handles.bool_extractWatermarkSave=1;%already save extracted watermark
                 */
                mlfIndexAssign(
                  &handles, ".bool_extractWatermarkSave", _mxarray0_);
                /*
                 * handles.current_filename4 = filenameWrite;
                 */
                mlfIndexAssign(
                  &handles,
                  ".current_filename4",
                  mclVv(filenameWrite, "filenameWrite"));
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            }
        /*
         * end
         */
        }
    /*
     * catch            
     */
    } mlfCatch {
        /*
         * msgbox('Program have error...And can''t be processing.Close and Open again ','Program error','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray266_,
            _mxarray268_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * delete(h_waitExt);
         */
        mlfDelete(mclVv(h_waitExt, "h_waitExt"), NULL);
    /*
     * return;
     * end
     */
    } mlfEndCatch
    /*
     * %[0.03 0.55  0.3 0.3]1
     * %[0.35 0.55  0.3 0.3]2
     * %[0.03 0.075  0.3 0.3]3
     * %[0.35 0.075  0.3 0.3]4
     * %==============================================================================================================================
     * 
     * % --- Executes on button press in pushbuttonSaveImageWithWatermark.
     */
    return_:
    mxDestroyArray(attack_type);
    mxDestroyArray(marked_im);
    mxDestroyArray(org_im);
    mxDestroyArray(ans);
    mxDestroyArray(h_waitExt);
    mxDestroyArray(im5_info);
    mxDestroyArray(im6_info);
    mxDestroyArray(attack);
    mxDestroyArray(im6);
    mxDestroyArray(im5);
    mxDestroyArray(im5_col);
    mxDestroyArray(im6_col);
    mxDestroyArray(im_size_row);
    mxDestroyArray(im_size_col);
    mxDestroyArray(block_size);
    mxDestroyArray(im6_back);
    mxDestroyArray(tmp);
    mxDestroyArray(tmp2);
    mxDestroyArray(tmp_size);
    mxDestroyArray(tmp2_size);
    mxDestroyArray(rect_tmp);
    mxDestroyArray(rect_tmp2);
    mxDestroyArray(sub_tmp);
    mxDestroyArray(sub_tmp2);
    mxDestroyArray(c);
    mxDestroyArray(max_c);
    mxDestroyArray(imax);
    mxDestroyArray(ypeak);
    mxDestroyArray(xpeak);
    mxDestroyArray(corr_offset);
    mxDestroyArray(rect_offset);
    mxDestroyArray(offset);
    mxDestroyArray(xoffset);
    mxDestroyArray(yoffset);
    mxDestroyArray(xbegin);
    mxDestroyArray(xend);
    mxDestroyArray(ybegin);
    mxDestroyArray(yend);
    mxDestroyArray(rotatePrompt);
    mxDestroyArray(dlgRotate_title);
    mxDestroyArray(rotateNum_lines);
    mxDestroyArray(temp_rotateAnswer);
    mxDestroyArray(doub_rotateDegree);
    mxDestroyArray(im6_size);
    mxDestroyArray(im6_height);
    mxDestroyArray(im6_width);
    mxDestroyArray(block_per_row);
    mxDestroyArray(block_per_col);
    mxDestroyArray(max_block);
    mxDestroyArray(k);
    mxDestroyArray(x);
    mxDestroyArray(i);
    mxDestroyArray(j);
    mxDestroyArray(g_max);
    mxDestroyArray(g_min);
    mxDestroyArray(g_avg);
    mxDestroyArray(l);
    mxDestroyArray(extracted_mark);
    mxDestroyArray(sum_gw);
    mxDestroyArray(sum_go);
    mxDestroyArray(h_enablepushbuttonSaveExtracted);
    mxDestroyArray(h_enablepushbuttonExtractedWatermark_info);
    mxDestroyArray(h_enablepushbuttonShowRealExtract);
    mxDestroyArray(filename4);
    mxDestroyArray(pathname4);
    mxDestroyArray(filenameWrite);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonSaveImageWithWatermark_Callback" is
 * the implementation version of the
 * "watermark005/pushbuttonSaveImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 992-1023). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function pushbuttonSaveImageWithWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonSaveImageWithWatermark_Callback(mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWrite = NULL;
    mxArray * ans = NULL;
    mxArray * pathname3 = NULL;
    mxArray * filename3 = NULL;
    mxArray * marked_im5 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonSaveImageWithWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * handles=guidata(hObject);
     */
    mlfAssign(&handles, mlfNGuidata(1, mclVa(hObject, "hObject"), NULL));
    /*
     * marked_im5=handles.current_marked_im5;
     */
    mlfAssign(
      &marked_im5,
      mlfIndexRef(mclVa(handles, "handles"), ".current_marked_im5"));
    /*
     * [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filename3,
      mlfUiputfile(&pathname3, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filename3, "filename3"), "filename3");
    mclPrintArray(mclVv(pathname3, "pathname3"), "pathname3");
    /*
     * if isequal(filename3,0)|isequal(pathname3,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename3, "filename3"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname3, "pathname3"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>> File is not saving right now...Please try again');
             */
            mlfDisp(_mxarray208_);
            /*
             * handles.bool_addWatermarkSave=0;%not save adding watermark
             */
            mlfIndexAssign(&handles, ".bool_addWatermarkSave", _mxarray14_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>> File ', pathname3, filename3, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray210_,
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                _mxarray214_,
                NULL));
            /*
             * filenameWrite=[pathname3 filename3 '.bmp'];
             */
            mlfAssign(
              &filenameWrite,
              mlfHorzcat(
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                _mxarray212_,
                NULL));
            /*
             * imwrite(marked_im5,filenameWrite,'bmp')
             */
            mlfImwrite(
              mclVv(marked_im5, "marked_im5"),
              mclVv(filenameWrite, "filenameWrite"),
              _mxarray177_,
              NULL);
            /*
             * handles.current_filename3 = filenameWrite;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWrite, "filenameWrite"));
            /*
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title('Image with Watermark');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans, mlfNImshow(0, mclVv(marked_im5, "marked_im5"), NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray194_, NULL));
                /*
                 * title([filename3 '.bmp']);
                 */
                mclAssignAns(
                  &ans,
                  mlfNTitle(
                    0,
                    mlfHorzcat(
                      mclVv(filename3, "filename3"), _mxarray212_, NULL),
                    NULL));
                /*
                 * clc;
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After Saving. ','Can''t show image with watermark after Saving','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray270_,
                    _mxarray272_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        }
    /*
     * 
     * end
     */
    }
    /*
     * 
     * 
     * % --- Executes on button press in pushbuttonSaveExtracted.
     */
    return_:
    mxDestroyArray(marked_im5);
    mxDestroyArray(filename3);
    mxDestroyArray(pathname3);
    mxDestroyArray(ans);
    mxDestroyArray(filenameWrite);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonSaveExtracted_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonSaveExtracted_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1023-1062). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonSaveExtracted_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonSaveExtracted_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWrite = NULL;
    mxArray * ans = NULL;
    mxArray * pathname4 = NULL;
    mxArray * filename4 = NULL;
    mxArray * extracted_mark = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonSaveExtracted (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * handles=guidata(hObject);
     */
    mlfAssign(&handles, mlfNGuidata(1, mclVa(hObject, "hObject"), NULL));
    /*
     * extracted_mark=handles.current_extracted_mark;
     */
    mlfAssign(
      &extracted_mark,
      mlfIndexRef(mclVa(handles, "handles"), ".current_extracted_mark"));
    /*
     * [filename4,pathname4]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filename4,
      mlfUiputfile(&pathname4, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filename4, "filename4"), "filename4");
    mclPrintArray(mclVv(pathname4, "pathname4"), "pathname4");
    /*
     * if isequal(filename4,0)|isequal(pathname4,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename4, "filename4"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname4, "pathname4"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>> File is not saving right now...Please try again');
             */
            mlfDisp(_mxarray208_);
            /*
             * handles.bool_extractWatermarkSave=0;%not save extracted watermark
             */
            mlfIndexAssign(&handles, ".bool_extractWatermarkSave", _mxarray14_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>> File ', pathname4, filename4, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray210_,
                mclVv(pathname4, "pathname4"),
                mclVv(filename4, "filename4"),
                _mxarray214_,
                NULL));
            /*
             * filenameWrite=[pathname4 filename4 '.bmp'];
             */
            mlfAssign(
              &filenameWrite,
              mlfHorzcat(
                mclVv(pathname4, "pathname4"),
                mclVv(filename4, "filename4"),
                _mxarray212_,
                NULL));
            /*
             * imwrite(extracted_mark,filenameWrite,'bmp')
             */
            mlfImwrite(
              mclVv(extracted_mark, "extracted_mark"),
              mclVv(filenameWrite, "filenameWrite"),
              _mxarray177_,
              NULL);
            /*
             * handles.current_filename4 = filenameWrite;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename4",
              mclVv(filenameWrite, "filenameWrite"));
            /*
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(extracted_mark),title('Extracted Watermark');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotExtractedWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray252_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(0, mclVv(extracted_mark, "extracted_mark"), NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray254_, NULL));
                /*
                 * title([filename4 '.bmp']);
                 */
                mclAssignAns(
                  &ans,
                  mlfNTitle(
                    0,
                    mlfHorzcat(
                      mclVv(filename4, "filename4"), _mxarray212_, NULL),
                    NULL));
                /*
                 * clc;
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show extracted watermark After Saving. ','Can''t show extracted watermark after Saving','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray274_,
                    _mxarray276_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        }
    /*
     * 
     * end
     */
    }
    /*
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     * 
     * 
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonOpenImageWithWatermark.
     */
    return_:
    mxDestroyArray(extracted_mark);
    mxDestroyArray(filename4);
    mxDestroyArray(pathname4);
    mxDestroyArray(ans);
    mxDestroyArray(filenameWrite);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonOpenImageWithWatermark_Callback" is
 * the implementation version of the
 * "watermark005/pushbuttonOpenImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1062-1145). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonOpenImageWithWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonOpenImageWithWatermark_Callback(mxArray * hObject,
                                                                    mxArray * eventdata,
                                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * h_enablepushbuttonJPEGCompression = NULL;
    mxArray * h_enablepushbuttonCrop = NULL;
    mxArray * h_enablepushbuttonFilter = NULL;
    mxArray * h_enablepushbuttonRotate = NULL;
    mxArray * h_enablepushbuttonResize = NULL;
    mxArray * h_enablepushbuttonShowRealImageWithWatermark = NULL;
    mxArray * h_enablepushbuttonImageWithWatermark_info = NULL;
    mxArray * h_enablepopupmenuAttackMethod = NULL;
    mxArray * h_enableExtract = NULL;
    mxArray * image_x3 = NULL;
    mxArray * temp_path3 = NULL;
    mxArray * ans = NULL;
    mxArray * pathname3 = NULL;
    mxArray * filename3 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonOpenImageWithWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * [filename3,pathname3]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
     */
    mlfAssign(
      &filename3,
      mlfUigetfile(&pathname3, _mxarray17_, _mxarray27_, NULL, NULL));
    /*
     * if isequal(filename3,0)|isequal(pathname3,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename3, "filename3"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname3, "pathname3"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File not Open');
             */
            mlfDisp(_mxarray63_);
            /*
             * handles.bool_openImageWithWatermark=0;%Not open Image with watermark image
             */
            mlfIndexAssign(
              &handles, ".bool_openImageWithWatermark", _mxarray14_);
            /*
             * return;
             */
            goto return_;
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>>','File ', pathname3, filename3, ' already openned'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray280_,
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                _mxarray282_,
                NULL));
            /*
             * temp_path3=[pathname3 filename3];
             */
            mlfAssign(
              &temp_path3,
              mlfHorzcat(
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                NULL));
            /*
             * handles.current_filename3 = temp_path3;
             */
            mlfIndexAssign(
              &handles, ".current_filename3", mclVv(temp_path3, "temp_path3"));
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        }
    /*
     * end
     */
    }
    /*
     * 
     * image_x3=imread(handles.current_filename3);
     */
    mlfAssign(
      &image_x3,
      mlfNImread(
        1,
        NULL,
        NULL,
        mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
        NULL));
    /*
     * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x3),title(filename3);
     */
    mlfIndexAssign(
      &handles,
      ".h_subplotImageWithWatermark",
      mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
    mclPrintArray(mclVa(handles, "handles"), "handles");
    mclPrintAns(
      &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
    mclPrintAns(&ans, mlfNImshow(0, mclVv(image_x3, "image_x3"), NULL));
    mclAssignAns(&ans, mlfNTitle(0, mclVv(filename3, "filename3"), NULL));
    /*
     * clc;
     */
    mlfClc();
    /*
     * 
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * handles.bool_openImageWithWatermark=1;% open Image with watermark image already
     */
    mlfIndexAssign(&handles, ".bool_openImageWithWatermark", _mxarray0_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
     */
    if (mclScalarToBool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))
        && mclScalarToBool(
             mlfIndexRef(
               mclVa(handles, "handles"), ".bool_openImageWithWatermark"))) {
        /*
         * 
         * %enable pushbuttonExtract
         * h_enableExtract=findobj('tag','pushbuttonExtract','Enable','off');
         */
        mlfAssign(
          &h_enableExtract,
          mlfFindobj(_mxarray43_, _mxarray53_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enableExtract,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(h_enableExtract, "h_enableExtract"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable popupmenuAttackMethod
         * h_enablepopupmenuAttackMethod=findobj('tag','popupmenuAttackMethod','Enable','off');
         */
        mlfAssign(
          &h_enablepopupmenuAttackMethod,
          mlfFindobj(_mxarray43_, _mxarray55_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepopupmenuAttackMethod,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepopupmenuAttackMethod, "h_enablepopupmenuAttackMethod"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %Enaable popupmenuBlockSizeExt
         * set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray57_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * if (handles.bool_openImageWithWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(
            mclVa(handles, "handles"), ".bool_openImageWithWatermark"))) {
        /*
         * %enable pushbuttonImageWithWatermark_info
         * h_enablepushbuttonImageWithWatermark_info=findobj('tag','pushbuttonImageWithWatermark_info','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonImageWithWatermark_info,
          mlfFindobj(
            _mxarray43_, _mxarray200_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonImageWithWatermark_info,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonImageWithWatermark_info,
              "h_enablepushbuttonImageWithWatermark_info"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonShowRealImageWithWatermark
         * h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonShowRealImageWithWatermark,
          mlfFindobj(
            _mxarray43_, _mxarray202_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonShowRealImageWithWatermark,
              "h_enablepushbuttonShowRealImageWithWatermark"),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * 
     * %enable pushbuttonShowRealImageWithWatermark
     * h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonShowRealImageWithWatermark,
      mlfFindobj(_mxarray43_, _mxarray202_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(
          h_enablepushbuttonShowRealImageWithWatermark,
          "h_enablepushbuttonShowRealImageWithWatermark"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%%%%%%%%%%          Enable Attack Watermark        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                           
     * %enable pushbuttonResize
     * h_enablepushbuttonResize=findobj('tag','pushbuttonResize','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonResize,
      mlfFindobj(_mxarray43_, _mxarray284_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonResize,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(h_enablepushbuttonResize, "h_enablepushbuttonResize"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %enable pushbuttonRotate
     * h_enablepushbuttonRotate=findobj('tag','pushbuttonRotate','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonRotate,
      mlfFindobj(_mxarray43_, _mxarray286_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonRotate,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(h_enablepushbuttonRotate, "h_enablepushbuttonRotate"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %enable pushbuttonFilter
     * h_enablepushbuttonFilter=findobj('tag','pushbuttonFilter','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonFilter,
      mlfFindobj(_mxarray43_, _mxarray288_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonFilter,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(h_enablepushbuttonFilter, "h_enablepushbuttonFilter"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %enable h_enablepushbuttonCrop
     * h_enablepushbuttonCrop=findobj('tag','pushbuttonCrop','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonCrop,
      mlfFindobj(_mxarray43_, _mxarray290_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonCrop,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(h_enablepushbuttonCrop, "h_enablepushbuttonCrop"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %enable h_enablepushbuttonJPEGCompression
     * h_enablepushbuttonJPEGCompression=findobj('tag','pushbuttonJPEGCompression','Enable','off');
     */
    mlfAssign(
      &h_enablepushbuttonJPEGCompression,
      mlfFindobj(_mxarray43_, _mxarray292_, _mxarray47_, _mxarray67_, NULL));
    /*
     * set(h_enablepushbuttonJPEGCompression,'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mclVv(
          h_enablepushbuttonJPEGCompression,
          "h_enablepushbuttonJPEGCompression"),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * 
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonCrop.
     */
    return_:
    mxDestroyArray(filename3);
    mxDestroyArray(pathname3);
    mxDestroyArray(ans);
    mxDestroyArray(temp_path3);
    mxDestroyArray(image_x3);
    mxDestroyArray(h_enableExtract);
    mxDestroyArray(h_enablepopupmenuAttackMethod);
    mxDestroyArray(h_enablepushbuttonImageWithWatermark_info);
    mxDestroyArray(h_enablepushbuttonShowRealImageWithWatermark);
    mxDestroyArray(h_enablepushbuttonResize);
    mxDestroyArray(h_enablepushbuttonRotate);
    mxDestroyArray(h_enablepushbuttonFilter);
    mxDestroyArray(h_enablepushbuttonCrop);
    mxDestroyArray(h_enablepushbuttonJPEGCompression);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonCrop_Callback" is the implementation
 * version of the "watermark005/pushbuttonCrop_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1145-1251). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonCrop_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonCrop_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWriteCrop = NULL;
    mxArray * temp_pathCrop = NULL;
    mxArray * pathnameCrop = NULL;
    mxArray * filenameCrop = NULL;
    mxArray * imageCropped = NULL;
    mxArray * ans = NULL;
    mxArray * imageCrop = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonCrop (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %im_NameCrop=handles.current_filename3;
     * 
     * try
     */
    mlfTry {
        /*
         * 
         * imageCrop=imread(handles.current_filename3);
         */
        mlfAssign(
          &imageCrop,
          mlfNImread(
            1,
            NULL,
            NULL,
            mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray294_,
            _mxarray296_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * try
     */
    mlfTry {
        /*
         * 
         * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(imageCrop),title('Crop Image with Watermark here');
         */
        mlfIndexAssign(
          &handles,
          ".h_subplotImageWithWatermark",
          mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
        mclPrintArray(mclVa(handles, "handles"), "handles");
        mclPrintAns(
          &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
        mclPrintAns(&ans, mlfNImshow(0, mclVv(imageCrop, "imageCrop"), NULL));
        mclAssignAns(&ans, mlfNTitle(0, _mxarray298_, NULL));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * %imageCropped=imcrop(handles.h_subplotImageWithWatermark )     ;
         * imageCropped=imcrop(imageCrop);      
         */
        mlfAssign(
          &imageCropped,
          mlfNImcrop(
            0, mclValueVarargout(), mclVv(imageCrop, "imageCrop"), NULL));
    /*
     * 
     * catch
     */
    } mlfCatch {
        /*
         * %msgbox('Program can''t open image with watermark to crop.','Can''t open image with watermark to crop','error','modal');
         * msgbox('This function Don''t support in Stand Alone Application ...Please run in MATLAB environment ','Application Support Error','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray300_,
            _mxarray302_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * %pushbuttonClearAll_Callback;
         * startAgain;
         */
        mlfWatermark005_startAgain(NULL, NULL, NULL);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * %diable button;
     * %disp('0k');
     * disOpenImage;
     */
    mlfWatermark005_disOpenImage(NULL, NULL, NULL);
    /*
     * disAddWatermark;
     */
    mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
    /*
     * disExtWatermark;
     */
    mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
    /*
     * disUtilityAttackWatermark;
     */
    mlfWatermark005_disUtilityAttackWatermark(NULL, NULL, NULL);
    /*
     * disUtilityMainWatermark;
     */
    mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
    /*
     * disInfoOriginal;
     */
    mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
    /*
     * disInfoWatermark;
     */
    mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
    /*
     * disInfoImageWithWatermrk;
     */
    mlfWatermark005_disInfoImageWithWatermrk(NULL, NULL, NULL);
    /*
     * disInfoExtractWatermark;
     */
    mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
    /*
     * 
     * 
     * try
     */
    mlfTry {
        /*
         * 
         * handles.bool_openImageWithWatermark=1;
         */
        mlfIndexAssign(&handles, ".bool_openImageWithWatermark", _mxarray0_);
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * 
         * %enable pushbuttonSaveAttackwatermark
         * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray304_, NULL),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * [filenameCrop,pathnameCrop]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
         */
        mlfAssign(
          &filenameCrop,
          mlfUiputfile(&pathnameCrop, _mxarray204_, _mxarray206_, NULL, NULL));
        mclPrintArray(mclVv(filenameCrop, "filenameCrop"), "filenameCrop");
        mclPrintArray(mclVv(pathnameCrop, "pathnameCrop"), "pathnameCrop");
        /*
         * if isequal(filenameCrop,0)|isequal(filenameCrop,0)
         */
        {
            mxArray * a_
              = mclInitialize(
                  mlfIsequal(
                    mclVv(filenameCrop, "filenameCrop"), _mxarray14_, NULL));
            if (mlfTobool(a_)
                || mlfTobool(
                     mclOr(
                       a_,
                       mlfIsequal(
                         mclVv(filenameCrop, "filenameCrop"),
                         _mxarray14_, NULL)))) {
                mxDestroyArray(a_);
                /*
                 * disp('Status>>File is not saving right now');
                 */
                mlfDisp(_mxarray306_);
                /*
                 * handles.bool_cropAttackSave=0;;%not save crop attack watermark
                 */
                mlfIndexAssign(&handles, ".bool_cropAttackSave", _mxarray14_);
                /*
                 * handles.bool_AttackWatermarkSave=0;%not save attack watermark
                 */
                mlfIndexAssign(
                  &handles, ".bool_AttackWatermarkSave", _mxarray14_);
                /*
                 * handles.current_filename3='image_CropAttack_bak.bmp';
                 */
                mlfIndexAssign(&handles, ".current_filename3", _mxarray308_);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
                /*
                 * imwrite(imageCropped,handles.current_filename3,'bmp')
                 */
                mlfImwrite(
                  mclVv(imageCropped, "imageCropped"),
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
                  _mxarray177_,
                  NULL);
                /*
                 * %disable button
                 * disOpenImage;
                 */
                mlfWatermark005_disOpenImage(NULL, NULL, NULL);
                /*
                 * disAddWatermark;
                 */
                mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
                /*
                 * disExtWatermark;
                 */
                mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
                /*
                 * disUtilityAttackExceptSaveWatermark;
                 */
                mlfWatermark005_disUtilityAttackExceptSaveWatermark(
                  NULL, NULL, NULL);
                /*
                 * disUtilityMainWatermark;
                 */
                mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
                /*
                 * disInfoOriginal;
                 */
                mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
                /*
                 * disInfoWatermark;
                 */
                mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
                /*
                 * disInfoExtractWatermark;
                 */
                mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
                /*
                 * 
                 * %            pushbuttonClearAll_Callback;
                 * 
                 * try
                 */
                mlfTry {
                    /*
                     * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After cropping');
                     */
                    mlfIndexAssign(
                      &handles,
                      ".h_subplotImageWithWatermark",
                      mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                    mclPrintArray(mclVa(handles, "handles"), "handles");
                    mclPrintAns(
                      &ans,
                      mlfNIptsetpref(
                        0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                    mclPrintAns(
                      &ans,
                      mlfNImshow(
                        0,
                        mlfIndexRef(
                          mclVa(handles, "handles"), ".current_filename3"),
                        NULL));
                    mclAssignAns(&ans, mlfNTitle(0, _mxarray310_, NULL));
                    /*
                     * clc;
                     */
                    mlfClc();
                /*
                 * catch
                 */
                } mlfCatch {
                    /*
                     * msgbox('Program can''t show image with watermark After cropping. ','Can''t show image with watermark after cropping','error','modal');
                     */
                    mclAssignAns(
                      &ans,
                      mlfNMsgbox(
                        0,
                        mclAnsVarargout(),
                        _mxarray312_,
                        _mxarray314_,
                        _mxarray162_,
                        _mxarray127_,
                        NULL));
                    mclExitTryBlock();
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * end
                 */
                } mlfEndCatch
                mclExitTryBlock();
                /*
                 * return;
                 */
                goto return_;
            /*
             * else
             */
            } else {
                mxDestroyArray(a_);
                /*
                 * temp_pathCrop=[pathnameCrop filenameCrop];
                 */
                mlfAssign(
                  &temp_pathCrop,
                  mlfHorzcat(
                    mclVv(pathnameCrop, "pathnameCrop"),
                    mclVv(filenameCrop, "filenameCrop"),
                    NULL));
                /*
                 * filenameWriteCrop=[pathnameCrop filenameCrop '.bmp'];
                 */
                mlfAssign(
                  &filenameWriteCrop,
                  mlfHorzcat(
                    mclVv(pathnameCrop, "pathnameCrop"),
                    mclVv(filenameCrop, "filenameCrop"),
                    _mxarray212_,
                    NULL));
                /*
                 * disp([filenameWriteCrop]);
                 */
                mlfDisp(mclVv(filenameWriteCrop, "filenameWriteCrop"));
                /*
                 * imwrite(imageCropped,filenameWriteCrop,'bmp')
                 */
                mlfImwrite(
                  mclVv(imageCropped, "imageCropped"),
                  mclVv(filenameWriteCrop, "filenameWriteCrop"),
                  _mxarray177_,
                  NULL);
                /*
                 * handles.current_filename3=filenameWriteCrop;
                 */
                mlfIndexAssign(
                  &handles,
                  ".current_filename3",
                  mclVv(filenameWriteCrop, "filenameWriteCrop"));
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
                /*
                 * disp(['Status>>','File ', filenameWriteCrop, ' already saved'])
                 */
                mlfDisp(
                  mlfHorzcat(
                    _mxarray278_,
                    _mxarray280_,
                    mclVv(filenameWriteCrop, "filenameWriteCrop"),
                    _mxarray214_,
                    NULL));
                /*
                 * handles.bool_cropAttackSave=1;% save crop attack watermark
                 */
                mlfIndexAssign(&handles, ".bool_cropAttackSave", _mxarray0_);
                /*
                 * handles.bool_AttackWatermarkSave=1;%not save attack watermark
                 */
                mlfIndexAssign(
                  &handles, ".bool_AttackWatermarkSave", _mxarray0_);
                /*
                 * %eanble button
                 * EnaOpenImage;
                 */
                mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
                /*
                 * EnaUtilityAttackWatermark;
                 */
                mlfWatermark005_EnaUtilityAttackWatermark(NULL, NULL, NULL);
                /*
                 * EnaUtilityMainWatermark;
                 */
                mlfWatermark005_EnaUtilityMainWatermark(NULL, NULL, NULL);
                /*
                 * EnaInfoImageWithWatermrk;
                 */
                mlfWatermark005_EnaInfoImageWithWatermrk(NULL, NULL, NULL);
                /*
                 * 
                 * try 
                 */
                mlfTry {
                    /*
                     * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After cropping');
                     */
                    mlfIndexAssign(
                      &handles,
                      ".h_subplotImageWithWatermark",
                      mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                    mclPrintArray(mclVa(handles, "handles"), "handles");
                    mclPrintAns(
                      &ans,
                      mlfNIptsetpref(
                        0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                    mclPrintAns(
                      &ans,
                      mlfNImshow(
                        0,
                        mlfIndexRef(
                          mclVa(handles, "handles"), ".current_filename3"),
                        NULL));
                    mclAssignAns(&ans, mlfNTitle(0, _mxarray316_, NULL));
                    /*
                     * clc;    
                     */
                    mlfClc();
                /*
                 * catch
                 */
                } mlfCatch {
                    /*
                     * msgbox('Program can''t show image with watermark After cropping. ','Can''t show image with watermark after cropping','error','modal');
                     */
                    mclAssignAns(
                      &ans,
                      mlfNMsgbox(
                        0,
                        mclAnsVarargout(),
                        _mxarray312_,
                        _mxarray314_,
                        _mxarray162_,
                        _mxarray127_,
                        NULL));
                    mclExitTryBlock();
                    /*
                     * return;
                     */
                    goto return_;
                /*
                 * end
                 */
                } mlfEndCatch
            }
        /*
         * end
         */
        }
    /*
     * catch        
     */
    } mlfCatch {
        /*
         * msgbox('Program process error or Don''t support in Stand Alone Application ... ','Program error Or Support Error','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray318_,
            _mxarray320_,
            _mxarray125_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    /*
     * 
     * % --- Executes on button press in pushbuttonResize.
     */
    return_:
    mxDestroyArray(imageCrop);
    mxDestroyArray(ans);
    mxDestroyArray(imageCropped);
    mxDestroyArray(filenameCrop);
    mxDestroyArray(pathnameCrop);
    mxDestroyArray(temp_pathCrop);
    mxDestroyArray(filenameWriteCrop);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonResize_Callback" is the implementation
 * version of the "watermark005/pushbuttonResize_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1251-1366). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonResize_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonResize_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWriteResize = NULL;
    mxArray * temp_pathResize = NULL;
    mxArray * pathnameResize = NULL;
    mxArray * filenameResize = NULL;
    mxArray * imageResized = NULL;
    mxArray * h_resizeAnswerinvalid = NULL;
    mxArray * resizeAnswer = NULL;
    mxArray * temp_resizeAnswer = NULL;
    mxArray * resizeNum_lines = NULL;
    mxArray * defResize = NULL;
    mxArray * dlgResize_title = NULL;
    mxArray * resizePrompt = NULL;
    mxArray * ans = NULL;
    mxArray * imageResize = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonResize (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * try
     */
    mlfTry {
        /*
         * imageResize=imread(handles.current_filename3);
         */
        mlfAssign(
          &imageResize,
          mlfNImread(
            1,
            NULL,
            NULL,
            mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray294_,
            _mxarray296_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * 
     * resizePrompt={'Input Size Image...<Decreaes Size(0<Size<=1)>...<Increase Size(Size>1)>'};
     */
    mlfAssign(&resizePrompt, _mxarray322_);
    /*
     * dlgResize_title='Input Size Image';
     */
    mlfAssign(&dlgResize_title, _mxarray325_);
    /*
     * defResize     = {'1'};
     */
    mlfAssign(&defResize, _mxarray327_);
    /*
     * resizeNum_lines=1;
     */
    mlfAssign(&resizeNum_lines, _mxarray0_);
    /*
     * 
     * temp_resizeAnswer=inputdlg(resizePrompt,dlgResize_title,resizeNum_lines,defResize);
     */
    mlfAssign(
      &temp_resizeAnswer,
      mlfNInputdlg(
        1,
        mclVv(resizePrompt, "resizePrompt"),
        mclVv(dlgResize_title, "dlgResize_title"),
        mclVv(resizeNum_lines, "resizeNum_lines"),
        mclVv(defResize, "defResize"),
        NULL));
    /*
     * 
     * 
     * if isempty(temp_resizeAnswer)
     */
    if (mlfTobool(mlfIsempty(mclVv(temp_resizeAnswer, "temp_resizeAnswer")))) {
        /*
         * msgbox('You cancel input resize number program will do nothing ','Cancel input resize ','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray328_,
            _mxarray330_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end;    
     */
    }
    /*
     * 
     * resizeAnswer=str2num(temp_resizeAnswer{1});%first input array
     */
    mlfAssign(
      &resizeAnswer,
      mclFeval(
        mclValueVarargout(),
        mlxStr2num,
        mlfIndexRef(
          mclVv(temp_resizeAnswer, "temp_resizeAnswer"), "{?}", _mxarray0_),
        NULL));
    /*
     * if isequal(temp_resizeAnswer,{''})
     */
    if (mlfTobool(
          mlfIsequal(
            mclVv(temp_resizeAnswer, "temp_resizeAnswer"),
            _mxarray129_, NULL))) {
        /*
         * resizeAnswer=1;
         */
        mlfAssign(&resizeAnswer, _mxarray0_);
        /*
         * h_resizeAnswerinvalid=msgbox('You don''t input resize number. Program will use defualt(1)','Resize number is invalid','warn','modal');
         */
        mlfAssign(
          &h_resizeAnswerinvalid,
          mlfNMsgbox(
            0,
            mclValueVarargout(),
            _mxarray332_,
            _mxarray334_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * uiwait(h_resizeAnswerinvalid);
         */
        mlfUiwait(mclVv(h_resizeAnswerinvalid, "h_resizeAnswerinvalid"));
    /*
     * else   
     */
    } else {
        /*
         * if isnan(str2double(temp_resizeAnswer))
         */
        if (mlfTobool(
              mlfIsnan(
                mlfStr2double(
                  mclVv(temp_resizeAnswer, "temp_resizeAnswer"))))) {
            /*
             * msgbox('You  input not a number for resizing  program will do nothing ','Cancel input Password ','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray336_,
                _mxarray123_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            /*
             * return;
             */
            goto return_;
        /*
         * end   
         */
        }
    /*
     * end             
     */
    }
    /*
     * 
     * 
     * 
     * 
     * if  resizeAnswer <= 0
     */
    if (mclLeBool(mclVv(resizeAnswer, "resizeAnswer"), _mxarray14_)) {
        /*
         * msgbox('You  input resize number not a positive integer program will do nothing ','Error resize number ','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray338_,
            _mxarray340_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * try  
         */
        mlfTry {
            /*
             * imageResized=imresize(imageResize,resizeAnswer);
             */
            mlfAssign(
              &imageResized,
              mlfNImresize(
                0,
                mclValueVarargout(),
                mclVv(imageResize, "imageResize"),
                mclVv(resizeAnswer, "resizeAnswer"),
                NULL));
        /*
         * catch
         */
        } mlfCatch {
            /*
             * msgbox(' Maximum variable size allowed by the program is exceeded Or some parameters error. Program will do nothing ','Error resize number ','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray342_,
                _mxarray340_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            /*
             * return;
             */
            goto return_;
        /*
         * end              
         */
        } mlfEndCatch
    /*
     * end
     */
    }
    /*
     * 
     * %enable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * [filenameResize,pathnameResize]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filenameResize,
      mlfUiputfile(&pathnameResize, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filenameResize, "filenameResize"), "filenameResize");
    mclPrintArray(mclVv(pathnameResize, "pathnameResize"), "pathnameResize");
    /*
     * if isequal(filenameResize,0)|isequal(pathnameResize,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(
                mclVv(filenameResize, "filenameResize"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathnameResize, "pathnameResize"),
                     _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File is not saving right now');
             */
            mlfDisp(_mxarray306_);
            /*
             * 
             * 
             * 
             * handles.bool_resizeAttackSave=0;%not save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_resizeAttackSave", _mxarray14_);
            /*
             * handles.bool_AttackWatermarkSave=0;%not save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
            /*
             * handles.current_filename3='image_CropAttack_bak.bmp';
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray308_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * imwrite(imageResized,handles.current_filename3,'bmp')
             */
            mlfImwrite(
              mclVv(imageResized, "imageResized"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
              _mxarray177_,
              NULL);
            /*
             * %disable button
             * disOpenImage;
             */
            mlfWatermark005_disOpenImage(NULL, NULL, NULL);
            /*
             * disAddWatermark;
             */
            mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
            /*
             * disExtWatermark;
             */
            mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
            /*
             * disUtilityAttackExceptSaveWatermark;
             */
            mlfWatermark005_disUtilityAttackExceptSaveWatermark(
              NULL, NULL, NULL);
            /*
             * disUtilityMainWatermark;
             */
            mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * disInfoOriginal;
             */
            mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
            /*
             * disInfoWatermark;
             */
            mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
            /*
             * disInfoExtractWatermark;
             */
            mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
            /*
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After resizing');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray344_, NULL));
                /*
                 * clc;
                 */
                mlfClc();
                /*
                 * handles.bool_openImageWithWatermark=1;
                 */
                mlfIndexAssign(
                  &handles, ".bool_openImageWithWatermark", _mxarray0_);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After resizing. ','Can''t show image with watermark after resizing','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray346_,
                    _mxarray348_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * temp_pathResize=[pathnameResize filenameResize];
             */
            mlfAssign(
              &temp_pathResize,
              mlfHorzcat(
                mclVv(pathnameResize, "pathnameResize"),
                mclVv(filenameResize, "filenameResize"),
                NULL));
            /*
             * filenameWriteResize=[pathnameResize filenameResize '.bmp'];
             */
            mlfAssign(
              &filenameWriteResize,
              mlfHorzcat(
                mclVv(pathnameResize, "pathnameResize"),
                mclVv(filenameResize, "filenameResize"),
                _mxarray212_,
                NULL));
            /*
             * disp([filenameWriteResize]);
             */
            mlfDisp(mclVv(filenameWriteResize, "filenameWriteResize"));
            /*
             * imwrite(imageResized,filenameWriteResize,'bmp')
             */
            mlfImwrite(
              mclVv(imageResized, "imageResized"),
              mclVv(filenameWriteResize, "filenameWriteResize"),
              _mxarray177_,
              NULL);
            /*
             * handles.current_filename3=filenameWriteResize;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWriteResize, "filenameWriteResize"));
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disp(['Status>>','File ', filenameWriteResize, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray280_,
                mclVv(filenameWriteResize, "filenameWriteResize"),
                _mxarray214_,
                NULL));
            /*
             * handles.bool_resizeAttackSave=1;% save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_resizeAttackSave", _mxarray0_);
            /*
             * handles.bool_AttackWatermarkSave=1;%save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray0_);
            /*
             * 
             * %eanble button
             * EnaOpenImage;
             */
            mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
            /*
             * EnaUtilityAttackWatermark;
             */
            mlfWatermark005_EnaUtilityAttackWatermark(NULL, NULL, NULL);
            /*
             * EnaUtilityMainWatermark;
             */
            mlfWatermark005_EnaUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * try 
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After resizing');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray350_, NULL));
                /*
                 * clc;    
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After resizing. ','Can''t show image with watermark after resizing','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray346_,
                    _mxarray348_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
            /*
             * return;
             * end
             */
            } mlfEndCatch
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonFilter.
     */
    return_:
    mxDestroyArray(imageResize);
    mxDestroyArray(ans);
    mxDestroyArray(resizePrompt);
    mxDestroyArray(dlgResize_title);
    mxDestroyArray(defResize);
    mxDestroyArray(resizeNum_lines);
    mxDestroyArray(temp_resizeAnswer);
    mxDestroyArray(resizeAnswer);
    mxDestroyArray(h_resizeAnswerinvalid);
    mxDestroyArray(imageResized);
    mxDestroyArray(filenameResize);
    mxDestroyArray(pathnameResize);
    mxDestroyArray(temp_pathResize);
    mxDestroyArray(filenameWriteResize);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonFilter_Callback" is the implementation
 * version of the "watermark005/pushbuttonFilter_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1366-1448). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonFilter_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonFilter_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWriteFiltered = NULL;
    mxArray * pathnameFiltered = NULL;
    mxArray * filenameFiltered = NULL;
    mxArray * imageFiltered = NULL;
    mxArray * h_filter = NULL;
    mxArray * ans = NULL;
    mxArray * imageFilter = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonFilter (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * 
     * try
     */
    mlfTry {
        /*
         * imageFilter=imread(handles.current_filename3);
         */
        mlfAssign(
          &imageFilter,
          mlfNImread(
            1,
            NULL,
            NULL,
            mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray294_,
            _mxarray296_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * h_filter=fspecial('average');
     */
    mlfAssign(&h_filter, mlfFspecial(_mxarray352_, NULL));
    /*
     * 
     * %Enaable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * 
     * try
     */
    mlfTry {
        /*
         * imageFiltered=imfilter(imageFilter,h_filter);
         */
        mlfAssign(
          &imageFiltered,
          mlfImfilter(
            mclVv(imageFilter, "imageFilter"),
            mclVv(h_filter, "h_filter"),
            NULL));
    /*
     * catch  
     */
    } mlfCatch {
        /*
         * %msgbox('Program have some parameter error ','Process error','error','modal');
         * msgbox('This function Don''t support in Stand Alone Application ...Please run in MATLAB environment ','Application Support Error','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray300_,
            _mxarray302_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end        
     */
    } mlfEndCatch
    /*
     * [filenameFiltered,pathnameFiltered]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filenameFiltered,
      mlfUiputfile(&pathnameFiltered, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(
      mclVv(filenameFiltered, "filenameFiltered"), "filenameFiltered");
    mclPrintArray(
      mclVv(pathnameFiltered, "pathnameFiltered"), "pathnameFiltered");
    /*
     * if isequal(filenameFiltered,0)|isequal(pathnameFiltered,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(
                mclVv(filenameFiltered, "filenameFiltered"),
                _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathnameFiltered, "pathnameFiltered"),
                     _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File is not saving right now');
             */
            mlfDisp(_mxarray306_);
            /*
             * handles.bool_filterAttackSave=0;%not save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_filterAttackSave", _mxarray14_);
            /*
             * handles.bool_AttackWatermarkSave=0;%not save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
            /*
             * handles.current_filename3='image_FilterAttack_bak.jpg';
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray354_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * imwrite(imageFiltered,handles.current_filename3,'bmp');
             */
            mlfImwrite(
              mclVv(imageFiltered, "imageFiltered"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
              _mxarray177_,
              NULL);
            /*
             * %disable button
             * disOpenImage;
             */
            mlfWatermark005_disOpenImage(NULL, NULL, NULL);
            /*
             * disAddWatermark;
             */
            mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
            /*
             * disExtWatermark;
             */
            mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
            /*
             * disUtilityAttackExceptSaveWatermark;
             */
            mlfWatermark005_disUtilityAttackExceptSaveWatermark(
              NULL, NULL, NULL);
            /*
             * disUtilityMainWatermark;
             */
            mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * disInfoOriginal;
             */
            mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
            /*
             * disInfoWatermark;
             */
            mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
            /*
             * disInfoExtractWatermark;
             */
            mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
            /*
             * 
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After filter');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray356_, NULL));
                /*
                 * clc;
                 */
                mlfClc();
                /*
                 * handles.bool_openImageWithWatermark=1;
                 */
                mlfIndexAssign(
                  &handles, ".bool_openImageWithWatermark", _mxarray0_);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After filter.' ,'Can''t show image with watermark after filter.','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray358_,
                    _mxarray360_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * %temp_pathFiltered=[pathnameFiltered filenameFiltered];
             * filenameWriteFiltered=[pathnameFiltered filenameFiltered '.bmp'];
             */
            mlfAssign(
              &filenameWriteFiltered,
              mlfHorzcat(
                mclVv(pathnameFiltered, "pathnameFiltered"),
                mclVv(filenameFiltered, "filenameFiltered"),
                _mxarray212_,
                NULL));
            /*
             * 
             * imwrite(imageFiltered,filenameWriteFiltered,'bmp');
             */
            mlfImwrite(
              mclVv(imageFiltered, "imageFiltered"),
              mclVv(filenameWriteFiltered, "filenameWriteFiltered"),
              _mxarray177_,
              NULL);
            /*
             * 
             * handles.current_filename3=filenameWriteFiltered;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWriteFiltered, "filenameWriteFiltered"));
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disp(['Status>>','File ', filenameWriteFiltered, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray280_,
                mclVv(filenameWriteFiltered, "filenameWriteFiltered"),
                _mxarray214_,
                NULL));
            /*
             * handles.bool_JPEGAttackSave=1;% save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_JPEGAttackSave", _mxarray0_);
            /*
             * handles.bool_AttackWatermarkSave=1;%save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray0_);
            /*
             * 
             * %eanble button
             * EnaOpenImage;
             */
            mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
            /*
             * EnaUtilityAttackWatermark;
             */
            mlfWatermark005_EnaUtilityAttackWatermark(NULL, NULL, NULL);
            /*
             * EnaUtilityMainWatermark;
             */
            mlfWatermark005_EnaUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * try 
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After Filtered ');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray362_, NULL));
                /*
                 * clc;    
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After Filtered. ','Can''t show image with watermark after Filtered','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray364_,
                    _mxarray366_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
            /*
             * return;
             * end
             */
            } mlfEndCatch
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonFilter.
     */
    return_:
    mxDestroyArray(imageFilter);
    mxDestroyArray(ans);
    mxDestroyArray(h_filter);
    mxDestroyArray(imageFiltered);
    mxDestroyArray(filenameFiltered);
    mxDestroyArray(pathnameFiltered);
    mxDestroyArray(filenameWriteFiltered);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonRotate_Callback" is the implementation
 * version of the "watermark005/pushbuttonRotate_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1448-1561). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonRotate_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonRotate_Callback(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWriteRotate = NULL;
    mxArray * temp_pathRotate = NULL;
    mxArray * pathnameRotate = NULL;
    mxArray * filenameRotate = NULL;
    mxArray * imageRotated = NULL;
    mxArray * rotateAnswer = NULL;
    mxArray * temp_rotateAnswer = NULL;
    mxArray * rotateNum_lines = NULL;
    mxArray * defRotate = NULL;
    mxArray * dlgRotate_title = NULL;
    mxArray * rotatePrompt = NULL;
    mxArray * ans = NULL;
    mxArray * imageRotate = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonRotate (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * imageRotate=imread(handles.current_filename3);
         */
        mlfAssign(
          &imageRotate,
          mlfNImread(
            1,
            NULL,
            NULL,
            mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray294_,
            _mxarray296_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * %%%%%%%%%%%%%%%% rotate  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * try
     */
    mlfTry {
        /*
         * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(imageRotate),title('Rotate Image with Watermark');
         */
        mlfIndexAssign(
          &handles,
          ".h_subplotImageWithWatermark",
          mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
        mclPrintArray(mclVa(handles, "handles"), "handles");
        mclPrintAns(
          &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
        mclPrintAns(
          &ans, mlfNImshow(0, mclVv(imageRotate, "imageRotate"), NULL));
        mclAssignAns(&ans, mlfNTitle(0, _mxarray368_, NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Program can''t open image with watermark to crop. ','Can''t open image with watermark to crop','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray370_,
            _mxarray372_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * %enable pushbuttonSaveImageWithWatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * 
     * 
     * 
     * %imageRotate=imread(handles.current_filename3);
     * rotatePrompt={'Input Angle degree in a counter-clockwise direction(0<=Angle<=360) '};
     */
    mlfAssign(&rotatePrompt, _mxarray374_);
    /*
     * dlgRotate_title='Input Angle Degree';
     */
    mlfAssign(&dlgRotate_title, _mxarray377_);
    /*
     * defRotate     = {'0'};
     */
    mlfAssign(&defRotate, _mxarray379_);
    /*
     * rotateNum_lines=1;
     */
    mlfAssign(&rotateNum_lines, _mxarray0_);
    /*
     * 
     * %input rotate number
     * temp_rotateAnswer=inputdlg(rotatePrompt,dlgRotate_title,rotateNum_lines,defRotate);
     */
    mlfAssign(
      &temp_rotateAnswer,
      mlfNInputdlg(
        1,
        mclVv(rotatePrompt, "rotatePrompt"),
        mclVv(dlgRotate_title, "dlgRotate_title"),
        mclVv(rotateNum_lines, "rotateNum_lines"),
        mclVv(defRotate, "defRotate"),
        NULL));
    /*
     * 
     * if isempty(temp_rotateAnswer)
     */
    if (mlfTobool(mlfIsempty(mclVv(temp_rotateAnswer, "temp_rotateAnswer")))) {
        /*
         * msgbox('You cancel input rotate program will do nothing ','Cancel rotate input Password ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray382_,
            _mxarray384_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end;    
     */
    }
    /*
     * if isnan(str2double(temp_rotateAnswer{1}))
     */
    if (mlfTobool(
          mlfIsnan(
            mclFeval(
              mclValueVarargout(),
              mlxStr2double,
              mlfIndexRef(
                mclVv(temp_rotateAnswer, "temp_rotateAnswer"),
                "{?}",
                _mxarray0_),
              NULL)))) {
        /*
         * msgbox('You  input rotate angle not a integer.Program will do nothing ','Error rotate input','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray386_,
            _mxarray388_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * rotateAnswer=str2num(temp_rotateAnswer{1});%first input array
     */
    mlfAssign(
      &rotateAnswer,
      mclFeval(
        mclValueVarargout(),
        mlxStr2num,
        mlfIndexRef(
          mclVv(temp_rotateAnswer, "temp_rotateAnswer"), "{?}", _mxarray0_),
        NULL));
    /*
     * 
     * if  (rotateAnswer > 360) || (rotateAnswer < 0)
     */
    if (mclScalarToBool(
          mclGt(mclVv(rotateAnswer, "rotateAnswer"), _mxarray244_))
        || mclScalarToBool(
             mclLt(mclVv(rotateAnswer, "rotateAnswer"), _mxarray14_))) {
        /*
         * msgbox('Input must between 0 to 360 Degree','Input Angle Degree Out of Range','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray390_,
            _mxarray392_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * else
     */
    } else {
        /*
         * try
         */
        mlfTry {
            /*
             * imageRotated=imrotate(imageRotate,rotateAnswer);
             */
            mlfAssign(
              &imageRotated,
              mlfNImrotate(
                0,
                mclValueVarargout(),
                mclVv(imageRotate, "imageRotate"),
                mclVv(rotateAnswer, "rotateAnswer"),
                NULL));
            /*
             * 
             * %enable pushbuttonSaveAttackwatermark
             * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray304_, NULL),
                _mxarray47_,
                _mxarray49_,
                NULL));
        /*
         * 
         * catch
         */
        } mlfCatch {
            /*
             * msgbox('Program can''t process rotate attacking . ','Some parameter error..','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray394_,
                _mxarray396_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            /*
             * return;
             */
            goto return_;
        /*
         * end            
         */
        } mlfEndCatch
    /*
     * end
     */
    }
    /*
     * 
     * %enable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * [filenameRotate,pathnameRotate]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filenameRotate,
      mlfUiputfile(&pathnameRotate, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filenameRotate, "filenameRotate"), "filenameRotate");
    mclPrintArray(mclVv(pathnameRotate, "pathnameRotate"), "pathnameRotate");
    /*
     * if isequal(filenameRotate,0)|isequal(pathnameRotate,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(
                mclVv(filenameRotate, "filenameRotate"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathnameRotate, "pathnameRotate"),
                     _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File is not saving right now');
             */
            mlfDisp(_mxarray306_);
            /*
             * handles.bool_AttackWatermarkSave=0;%not save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
            /*
             * handles.current_filename3='image_RotateAttack_bak.bmp';
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray398_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * imwrite(imageRotated,handles.current_filename3,'bmp')
             */
            mlfImwrite(
              mclVv(imageRotated, "imageRotated"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
              _mxarray177_,
              NULL);
            /*
             * %disable button
             * disOpenImage;
             */
            mlfWatermark005_disOpenImage(NULL, NULL, NULL);
            /*
             * disAddWatermark;
             */
            mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
            /*
             * disExtWatermark;
             */
            mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
            /*
             * disUtilityAttackExceptSaveWatermark;
             */
            mlfWatermark005_disUtilityAttackExceptSaveWatermark(
              NULL, NULL, NULL);
            /*
             * disUtilityMainWatermark;
             */
            mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * disInfoOriginal;
             */
            mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
            /*
             * disInfoWatermark;
             */
            mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
            /*
             * disInfoExtractWatermark;
             */
            mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
            /*
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After rotating');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray400_, NULL));
                /*
                 * clc;
                 */
                mlfClc();
                /*
                 * handles.bool_openImageWithWatermark=1;
                 */
                mlfIndexAssign(
                  &handles, ".bool_openImageWithWatermark", _mxarray0_);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After rotating. ','Can''t show image with watermark after rotating','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray402_,
                    _mxarray404_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
        /*
         * return;
         * 
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * temp_pathRotate=[pathnameRotate filenameRotate];
             */
            mlfAssign(
              &temp_pathRotate,
              mlfHorzcat(
                mclVv(pathnameRotate, "pathnameRotate"),
                mclVv(filenameRotate, "filenameRotate"),
                NULL));
            /*
             * filenameWriteRotate=[pathnameRotate filenameRotate '.bmp'];
             */
            mlfAssign(
              &filenameWriteRotate,
              mlfHorzcat(
                mclVv(pathnameRotate, "pathnameRotate"),
                mclVv(filenameRotate, "filenameRotate"),
                _mxarray212_,
                NULL));
            /*
             * imwrite(imageRotated,filenameWriteRotate,'bmp')
             */
            mlfImwrite(
              mclVv(imageRotated, "imageRotated"),
              mclVv(filenameWriteRotate, "filenameWriteRotate"),
              _mxarray177_,
              NULL);
            /*
             * handles.current_filename3=filenameWriteRotate;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWriteRotate, "filenameWriteRotate"));
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disp(['Status>>','File ', filenameWriteRotate, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray280_,
                mclVv(filenameWriteRotate, "filenameWriteRotate"),
                _mxarray214_,
                NULL));
            /*
             * handles.bool_AttackWatermarkSave=1;% save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray0_);
            /*
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After rotating');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray406_, NULL));
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After rotating. ','Can''t show image with watermark after rotating','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray402_,
                    _mxarray404_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
            /*
             * return;
             * end
             */
            } mlfEndCatch
        }
    /*
     * end
     */
    }
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonShowRealOriginal.
     */
    return_:
    mxDestroyArray(imageRotate);
    mxDestroyArray(ans);
    mxDestroyArray(rotatePrompt);
    mxDestroyArray(dlgRotate_title);
    mxDestroyArray(defRotate);
    mxDestroyArray(rotateNum_lines);
    mxDestroyArray(temp_rotateAnswer);
    mxDestroyArray(rotateAnswer);
    mxDestroyArray(imageRotated);
    mxDestroyArray(filenameRotate);
    mxDestroyArray(pathnameRotate);
    mxDestroyArray(temp_pathRotate);
    mxDestroyArray(filenameWriteRotate);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonShowRealOriginal_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonShowRealOriginal_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1561-1571). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonShowRealOriginal_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonShowRealOriginal_Callback(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonShowRealOriginal (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %figure('Name','Watermarked Image')
     * %h_realSizeOriginal=figure('Name','Show Real Original Iamge Size'),imshow(handles.current_filename1);
     * figure('Name','Show Real Original Iamge Size'),imshow(handles.current_filename1);
     */
    mclPrintAns(&ans, mlfNFigure(0, _mxarray408_, _mxarray410_, NULL));
    mclAssignAns(
      &ans,
      mlfNImshow(
        0, mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"), NULL));
    /*
     * disp(['Status>>Show real original image have already shown'])
     */
    mlfDisp(_mxarray412_);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonJPEGCompression.
     */
}

/*
 * The function "Mwatermark005_pushbuttonJPEGCompression_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonJPEGCompression_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1571-1687). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonJPEGCompression_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonJPEGCompression_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWriteJPEG = NULL;
    mxArray * temp_pathJPEG = NULL;
    mxArray * pathnameJPEG = NULL;
    mxArray * filenameJPEG = NULL;
    mxArray * q = NULL;
    mxArray * h_jpegAnswerinvalid = NULL;
    mxArray * jpegAnswer = NULL;
    mxArray * temp_jpegAnswer = NULL;
    mxArray * jpegNum_lines = NULL;
    mxArray * defJpeg = NULL;
    mxArray * dlgJpeg_title = NULL;
    mxArray * jpegPrompt = NULL;
    mxArray * ans = NULL;
    mxArray * imageJPEG = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonJPEGCompression (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %function jpeg(infile,percent,outfile)
     * %file to be compressed
     * %jpeg output file name
     * %output image quality 1-100
     * %q = 100-percent;
     * %in_info = imfinfo(infile);
     * %im = imread(infile,in_info.Format);
     * %imwrite(im,outfile,'Quality',q);
     * 
     * %jpeg_outfile='default.jpg';
     * 
     * try
     */
    mlfTry {
        /*
         * imageJPEG=imread(handles.current_filename3);
         */
        mlfAssign(
          &imageJPEG,
          mlfNImread(
            1,
            NULL,
            NULL,
            mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
            NULL));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray294_,
            _mxarray296_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * 
     * 
     * jpegPrompt={'Input quality of compression JPEG (0-100)'};
     */
    mlfAssign(&jpegPrompt, _mxarray414_);
    /*
     * dlgJpeg_title='Input  Quality JPEG compression';
     */
    mlfAssign(&dlgJpeg_title, _mxarray417_);
    /*
     * defJpeg     = {'100'};
     */
    mlfAssign(&defJpeg, _mxarray419_);
    /*
     * jpegNum_lines=1;
     */
    mlfAssign(&jpegNum_lines, _mxarray0_);
    /*
     * 
     * %input jpeg percent number
     * temp_jpegAnswer=inputdlg(jpegPrompt,dlgJpeg_title,jpegNum_lines,defJpeg);
     */
    mlfAssign(
      &temp_jpegAnswer,
      mlfNInputdlg(
        1,
        mclVv(jpegPrompt, "jpegPrompt"),
        mclVv(dlgJpeg_title, "dlgJpeg_title"),
        mclVv(jpegNum_lines, "jpegNum_lines"),
        mclVv(defJpeg, "defJpeg"),
        NULL));
    /*
     * 
     * if isempty(temp_jpegAnswer)
     */
    if (mlfTobool(mlfIsempty(mclVv(temp_jpegAnswer, "temp_jpegAnswer")))) {
        /*
         * msgbox('You cancel input JPEG Quality number program will do nothing ','Cancel input JPEG Quality ','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray420_,
            _mxarray422_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end;    
     */
    }
    /*
     * 
     * jpegAnswer=str2num(temp_jpegAnswer{1});%first input array
     */
    mlfAssign(
      &jpegAnswer,
      mclFeval(
        mclValueVarargout(),
        mlxStr2num,
        mlfIndexRef(
          mclVv(temp_jpegAnswer, "temp_jpegAnswer"), "{?}", _mxarray0_),
        NULL));
    /*
     * 
     * if isequal(temp_jpegAnswer,{''})
     */
    if (mlfTobool(
          mlfIsequal(
            mclVv(temp_jpegAnswer, "temp_jpegAnswer"), _mxarray129_, NULL))) {
        /*
         * jpegAnswer=100;
         */
        mlfAssign(&jpegAnswer, _mxarray169_);
        /*
         * h_jpegAnswerinvalid=msgbox('You don''t input JPEG Quality number. Program will use defualt(100)','PEG Quality number is invalid','warn','modal');
         */
        mlfAssign(
          &h_jpegAnswerinvalid,
          mlfNMsgbox(
            0,
            mclValueVarargout(),
            _mxarray424_,
            _mxarray426_,
            _mxarray125_,
            _mxarray127_,
            NULL));
        /*
         * uiwait(h_jpegAnswerinvalid);
         */
        mlfUiwait(mclVv(h_jpegAnswerinvalid, "h_jpegAnswerinvalid"));
    /*
     * else  if  isnan(str2double(temp_jpegAnswer))
     */
    } else {
        if (mlfTobool(
              mlfIsnan(
                mlfStr2double(mclVv(temp_jpegAnswer, "temp_jpegAnswer"))))) {
            /*
             * msgbox('You  input not a number for JPEG compression  program will do nothing ','Cancel input JPEG Quality','error','modal');
             */
            mclAssignAns(
              &ans,
              mlfNMsgbox(
                0,
                mclAnsVarargout(),
                _mxarray428_,
                _mxarray430_,
                _mxarray162_,
                _mxarray127_,
                NULL));
            /*
             * return;
             */
            goto return_;
        /*
         * end   
         */
        }
    /*
     * end        
     */
    }
    /*
     * 
     * 
     * if  (jpegAnswer < 0) ||(jpegAnswer>100) 
     */
    if (mclScalarToBool(mclLt(mclVv(jpegAnswer, "jpegAnswer"), _mxarray14_))
        || mclScalarToBool(
             mclGt(mclVv(jpegAnswer, "jpegAnswer"), _mxarray169_))) {
        /*
         * msgbox('You  input JPEG Quality number out of rang program will do nothing ','Error JPEG Quality number ','error','modal');
         */
        mclAssignAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray432_,
            _mxarray434_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * q = 100-jpegAnswer;
     */
    mlfAssign(&q, mclMinus(_mxarray169_, mclVv(jpegAnswer, "jpegAnswer")));
    /*
     * 
     * %Enaable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * [filenameJPEG,pathnameJPEG]=uiputfile({'*.jpg','jpeg,jpg(*.jpg)'},'Save a file')
     */
    mlfAssign(
      &filenameJPEG,
      mlfUiputfile(&pathnameJPEG, _mxarray436_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filenameJPEG, "filenameJPEG"), "filenameJPEG");
    mclPrintArray(mclVv(pathnameJPEG, "pathnameJPEG"), "pathnameJPEG");
    /*
     * if isequal(filenameJPEG,0)|isequal(pathnameJPEG,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(
                mclVv(filenameJPEG, "filenameJPEG"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathnameJPEG, "pathnameJPEG"),
                     _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File is not saving right now');
             */
            mlfDisp(_mxarray306_);
            /*
             * 
             * 
             * 
             * handles.bool_JPEGAttackSave=0;%not save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_JPEGAttackSave", _mxarray14_);
            /*
             * handles.bool_AttackWatermarkSave=0;%not save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
            /*
             * handles.current_filename3='image_JPEGAttack_bak.jpg';
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray442_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * imwrite(imageJPEG,handles.current_filename3,'Quality',q);
             */
            mlfImwrite(
              mclVv(imageJPEG, "imageJPEG"),
              mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
              _mxarray444_,
              mclVv(q, "q"),
              NULL);
            /*
             * %disable button
             * disOpenImage;
             */
            mlfWatermark005_disOpenImage(NULL, NULL, NULL);
            /*
             * disAddWatermark;
             */
            mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
            /*
             * disExtWatermark;
             */
            mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
            /*
             * disUtilityAttackExceptSaveWatermark;
             */
            mlfWatermark005_disUtilityAttackExceptSaveWatermark(
              NULL, NULL, NULL);
            /*
             * disUtilityMainWatermark;
             */
            mlfWatermark005_disUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * disInfoOriginal;
             */
            mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
            /*
             * disInfoWatermark;
             */
            mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
            /*
             * disInfoExtractWatermark;
             */
            mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
            /*
             * 
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After JPEG compression');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray446_, NULL));
                /*
                 * clc;
                 */
                mlfClc();
                /*
                 * handles.bool_openImageWithWatermark=1;
                 */
                mlfIndexAssign(
                  &handles, ".bool_openImageWithWatermark", _mxarray0_);
                /*
                 * guidata(hObject,handles);
                 */
                mclAssignAns(
                  &ans,
                  mlfNGuidata(
                    0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After JPEG compression.' ,'Can''t show image with watermark after JPEG compression.','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray448_,
                    _mxarray450_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * temp_pathJPEG=[pathnameJPEG filenameJPEG];
             */
            mlfAssign(
              &temp_pathJPEG,
              mlfHorzcat(
                mclVv(pathnameJPEG, "pathnameJPEG"),
                mclVv(filenameJPEG, "filenameJPEG"),
                NULL));
            /*
             * filenameWriteJPEG=[pathnameJPEG filenameJPEG '.jpg'];
             */
            mlfAssign(
              &filenameWriteJPEG,
              mlfHorzcat(
                mclVv(pathnameJPEG, "pathnameJPEG"),
                mclVv(filenameJPEG, "filenameJPEG"),
                _mxarray452_,
                NULL));
            /*
             * 
             * imwrite(imageJPEG,filenameWriteJPEG,'Quality',q);
             */
            mlfImwrite(
              mclVv(imageJPEG, "imageJPEG"),
              mclVv(filenameWriteJPEG, "filenameWriteJPEG"),
              _mxarray444_,
              mclVv(q, "q"),
              NULL);
            /*
             * 
             * handles.current_filename3=filenameWriteJPEG;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWriteJPEG, "filenameWriteJPEG"));
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disp(['Status>>','File ', filenameWriteJPEG, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray280_,
                mclVv(filenameWriteJPEG, "filenameWriteJPEG"),
                _mxarray214_,
                NULL));
            /*
             * handles.bool_JPEGAttackSave=1;% save crop attack watermark
             */
            mlfIndexAssign(&handles, ".bool_JPEGAttackSave", _mxarray0_);
            /*
             * handles.bool_AttackWatermarkSave=1;%save  attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray0_);
            /*
             * 
             * %eanble button
             * EnaOpenImage;
             */
            mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
            /*
             * EnaUtilityAttackWatermark;
             */
            mlfWatermark005_EnaUtilityAttackWatermark(NULL, NULL, NULL);
            /*
             * EnaUtilityMainWatermark;
             */
            mlfWatermark005_EnaUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * try 
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After JPEG compression');
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans,
                  mlfNImshow(
                    0,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL));
                mclAssignAns(&ans, mlfNTitle(0, _mxarray454_, NULL));
                /*
                 * clc;    
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After JPEG compression. ','Can''t show image with watermark after JPEG compression','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray456_,
                    _mxarray458_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
            /*
             * return;
             * end
             */
            } mlfEndCatch
        }
    /*
     * end
     */
    }
    /*
     * 
     * % --- Executes on button press in pushbuttonShowRealWatermark.
     */
    return_:
    mxDestroyArray(imageJPEG);
    mxDestroyArray(ans);
    mxDestroyArray(jpegPrompt);
    mxDestroyArray(dlgJpeg_title);
    mxDestroyArray(defJpeg);
    mxDestroyArray(jpegNum_lines);
    mxDestroyArray(temp_jpegAnswer);
    mxDestroyArray(jpegAnswer);
    mxDestroyArray(h_jpegAnswerinvalid);
    mxDestroyArray(q);
    mxDestroyArray(filenameJPEG);
    mxDestroyArray(pathnameJPEG);
    mxDestroyArray(temp_pathJPEG);
    mxDestroyArray(filenameWriteJPEG);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonShowRealWatermark_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonShowRealWatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1687-1696). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonShowRealWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonShowRealWatermark_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonShowRealWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %h_realSizeWatermark=figure('Name','Show Real Watermark Iamge Size'),imshow(handles.current_filename2);
     * figure('Name','Show Real Watermark Iamge Size'),imshow(handles.current_filename2);
     */
    mclPrintAns(&ans, mlfNFigure(0, _mxarray408_, _mxarray460_, NULL));
    mclAssignAns(
      &ans,
      mlfNImshow(
        0, mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"), NULL));
    /*
     * disp(['Status>>Show real watermark image have already shown'])
     */
    mlfDisp(_mxarray462_);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonShowRealImageWithWatermark.
     */
}

/*
 * The function "Mwatermark005_pushbuttonShowRealImageWithWatermark_Callback"
 * is the implementation version of the
 * "watermark005/pushbuttonShowRealImageWithWatermark_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1696-1704). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonShowRealImageWithWatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonShowRealImageWithWatermark_Callback(mxArray * hObject,
                                                                        mxArray * eventdata,
                                                                        mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * h_realSizeImageWithWatermark = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonShowRealImageWithWatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * h_realSizeImageWithWatermark=figure('Name','Show Real Image with Watermark Image Size'),imshow(handles.current_filename3);
     */
    mlfAssign(
      &h_realSizeImageWithWatermark,
      mlfNFigure(1, _mxarray408_, _mxarray464_, NULL));
    mclPrintArray(
      mclVv(h_realSizeImageWithWatermark, "h_realSizeImageWithWatermark"),
      "h_realSizeImageWithWatermark");
    mclAssignAns(
      &ans,
      mlfNImshow(
        0, mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"), NULL));
    /*
     * disp(['Status>>Show real image with watermark have already shown'])
     */
    mlfDisp(_mxarray466_);
    mxDestroyArray(h_realSizeImageWithWatermark);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonShowRealExtract.
     */
}

/*
 * The function "Mwatermark005_pushbuttonShowRealExtract_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonShowRealExtract_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1704-1711). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonShowRealExtract_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonShowRealExtract_Callback(mxArray * hObject,
                                                             mxArray * eventdata,
                                                             mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * h_realSizeExtract = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonShowRealExtract (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * h_realSizeExtract=figure('Name','Show Real Extracted Watermark Image Size'),imshow(handles.current_filename4);
     */
    mlfAssign(
      &h_realSizeExtract, mlfNFigure(1, _mxarray408_, _mxarray468_, NULL));
    mclPrintArray(
      mclVv(h_realSizeExtract, "h_realSizeExtract"), "h_realSizeExtract");
    mclAssignAns(
      &ans,
      mlfNImshow(
        0, mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"), NULL));
    mxDestroyArray(h_realSizeExtract);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonExit.
     */
}

/*
 * The function "Mwatermark005_pushbuttonExit_Callback" is the implementation
 * version of the "watermark005/pushbuttonExit_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1711-1727). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonExit_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonExit_Callback(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * exit_button = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonExit (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * exit_button=questdlg('Exit Now ?','Exit Watermark Program','Yes','No','No');
     */
    mlfAssign(
      &exit_button,
      mlfNQuestdlg(
        1,
        _mxarray470_,
        _mxarray472_,
        _mxarray474_,
        _mxarray476_,
        _mxarray476_,
        NULL));
    /*
     * switch exit_button
     */
    {
        mxArray * v_ = mclInitialize(mclVv(exit_button, "exit_button"));
        if (mclSwitchCompare(v_, _mxarray474_)) {
            /*
             * case 'Yes'
             * delete(handles.figure1);
             */
            mlfDelete(mlfIndexRef(mclVa(handles, "handles"), ".figure1"), NULL);
        /*
         * case 'No'
         */
        } else if (mclSwitchCompare(v_, _mxarray476_)) {
        /*
         * return
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(exit_button);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * % --- Executes on button press in radiobuttonDefualt.
     */
}

/*
 * The function "Mwatermark005_radiobuttonDefualt_Callback" is the
 * implementation version of the "watermark005/radiobuttonDefualt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1727-1736). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function radiobuttonDefualt_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_radiobuttonDefualt_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to radiobuttonDefualt (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hint: get(hObject,'Value') returns toggle state of radiobuttonDefualt
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mwatermark005_popupmenuAttackMethod_CreateFcn" is the
 * implementation version of the "watermark005/popupmenuAttackMethod_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1736-1754). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuAttackMethod_CreateFcn(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuAttackMethod_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuAttackMethod (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: popupmenu controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray73_, _mxarray75_, NULL));
    /*
     * % handles.current_AttackMode='default';
     * %guidata(hObject,handles);
     * 
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray73_,
            mlfNGet(1, _mxarray14_, _mxarray77_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * % --- Executes on selection change in popupmenuAttackMethod.
     */
}

/*
 * The function "Mwatermark005_popupmenuAttackMethod_Callback" is the
 * implementation version of the "watermark005/popupmenuAttackMethod_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1754-1786). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuAttackMethod_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuAttackMethod_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * popup_sel_index = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuAttackMethod (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: contents = get(hObject,'String') returns popupmenuAttackMethod contents as cell array
     * %        contents{get(hObject,'Value')} returns selected item from popupmenuAttackMethod
     * popup_sel_index = get(handles.popupmenuAttackMethod,'Value');
     */
    mlfAssign(
      &popup_sel_index,
      mlfNGet(
        1,
        mlfIndexRef(mclVa(handles, "handles"), ".popupmenuAttackMethod"),
        _mxarray79_,
        NULL));
    /*
     * %popup_sel_index = get(hObject,'Value');
     * %msgbox(popup_sel_index);
     * 
     * switch popup_sel_index
     */
    {
        mxArray * v_ = mclInitialize(mclVv(popup_sel_index, "popup_sel_index"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1
             * handles.current_AttackMode='default';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray15_);
        /*
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray85_)) {
            /*
             * handles.current_AttackMode='resize';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray221_);
        /*
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray88_)) {
            /*
             * handles.current_AttackMode='rotate';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray225_);
        /*
         * %set(handles.editrotateDegree,'Enable','on');
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray89_)) {
            /*
             * handles.current_AttackMode='crop';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray223_);
        /*
         * case 5
         */
        } else if (mclSwitchCompare(v_, _mxarray95_)) {
            /*
             * handles.current_AttackMode='filter';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray478_);
        /*
         * case 6
         */
        } else if (mclSwitchCompare(v_, _mxarray99_)) {
            /*
             * handles.current_AttackMode='jpeg_compression';
             */
            mlfIndexAssign(&handles, ".current_AttackMode", _mxarray480_);
        /*
         * end 
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(popup_sel_index);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonOriginal_info.
     */
}

/*
 * The function "Mwatermark005_pushbuttonOriginal_info_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonOriginal_info_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1786-1799). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonOriginal_info_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonOriginal_info_Callback(mxArray * hObject,
                                                           mxArray * eventdata,
                                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonOriginal_info (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * handles.image_temp_info=handles.current_filename1;
         */
        mlfIndexAssign(
          &handles,
          ".image_temp_info",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * imageInformation(hObject, eventdata, handles);
         */
        mlfWatermark005_imageInformation(
          mclVa(hObject, "hObject"),
          mclVa(eventdata, "eventdata"),
          mclVa(handles, "handles"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You aren''t opening image now.','Forgot to open Image','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray482_,
            _mxarray484_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % --- Executes on button press in pushbuttonWatermark_info.
     */
}

/*
 * The function "Mwatermark005_pushbuttonWatermark_info_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonWatermark_info_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1799-1813). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonWatermark_info_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonWatermark_info_Callback(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonWatermark_info (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * handles.image_temp_info=handles.current_filename2;
         */
        mlfIndexAssign(
          &handles,
          ".image_temp_info",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * imageInformation(hObject, eventdata, handles);
         */
        mlfWatermark005_imageInformation(
          mclVa(hObject, "hObject"),
          mclVa(eventdata, "eventdata"),
          mclVa(handles, "handles"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('You aren''t opening image now.','Forgot to open Image','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray482_,
            _mxarray484_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonImageWithWatermark_info.
     */
}

/*
 * The function "Mwatermark005_pushbuttonImageWithWatermark_info_Callback" is
 * the implementation version of the
 * "watermark005/pushbuttonImageWithWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1813-1828). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonImageWithWatermark_info_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonImageWithWatermark_info_Callback(mxArray * hObject,
                                                                     mxArray * eventdata,
                                                                     mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonImageWithWatermark_info (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * handles.image_temp_info=handles.current_filename3;
         */
        mlfIndexAssign(
          &handles,
          ".image_temp_info",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * imageInformation(hObject, eventdata, handles);
         */
        mlfWatermark005_imageInformation(
          mclVa(hObject, "hObject"),
          mclVa(eventdata, "eventdata"),
          mclVa(handles, "handles"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Image have an error','Can''display image information','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray486_,
            _mxarray488_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * % --- Executes on button press in pushbuttonExtractedWatermark_info.
     */
}

/*
 * The function "Mwatermark005_pushbuttonExtractedWatermark_info_Callback" is
 * the implementation version of the
 * "watermark005/pushbuttonExtractedWatermark_info_Callback" M-function from
 * file "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 1828-1842). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonExtractedWatermark_info_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonExtractedWatermark_info_Callback(mxArray * hObject,
                                                                     mxArray * eventdata,
                                                                     mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonExtractedWatermark_info (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * handles.image_temp_info=handles.current_filename4;
         */
        mlfIndexAssign(
          &handles,
          ".image_temp_info",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * imageInformation(hObject, eventdata, handles);
         */
        mlfWatermark005_imageInformation(
          mclVa(hObject, "hObject"),
          mclVa(eventdata, "eventdata"),
          mclVa(handles, "handles"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Image have an error','Can''display image information','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray486_,
            _mxarray488_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * % --- Executes on button press in pushbuttonPSNR_MSE.
     */
}

/*
 * The function "Mwatermark005_pushbuttonPSNR_MSE_Callback" is the
 * implementation version of the "watermark005/pushbuttonPSNR_MSE_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1842-1866). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonPSNR_MSE_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonPSNR_MSE_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonPSNR_MSE (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try
     */
    mlfTry {
        /*
         * % handles.image_psnr_original=handles.current_filename1;
         * %handles.image_psnr_image_watermark=handles.current_filename3;
         * %guidata(hObject,handles);
         * disp(handles.current_filename1);
         */
        mclFeval(
          mclAnsVarargout(),
          mlxDisp,
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"),
          NULL);
        /*
         * disp(handles.current_filename3);
         */
        mclFeval(
          mclAnsVarargout(),
          mlxDisp,
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
          NULL);
        /*
         * clc;
         */
        mlfClc();
        /*
         * %find PSNR and MSE
         * imageWatermarkInformation(hObject,eventdata, handles);
         */
        mlfWatermark005_imageWatermarkInformation(
          mclVa(hObject, "hObject"),
          mclVa(eventdata, "eventdata"),
          mclVa(handles, "handles"));
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Can''t display PSNR and MSE...You must open Original Image and Image With watermark.','PSNR and MSE have an error','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray490_,
            _mxarray492_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonSimilarity.
     */
}

/*
 * The function "Mwatermark005_pushbuttonSimilarity_Callback" is the
 * implementation version of the "watermark005/pushbuttonSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1866-1885). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonSimilarity_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonSimilarity_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonSimilarity (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * try  
     */
    mlfTry {
        /*
         * handles.image_similarity_original=handles.current_filename2;%watermark image
         */
        mlfIndexAssign(
          &handles,
          ".image_similarity_original",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"));
        /*
         * handles.image_similarity_image_watermark=handles.current_filename4;%extracted watermark
         */
        mlfIndexAssign(
          &handles,
          ".image_similarity_image_watermark",
          mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * %    disp(handles.image_similarity_original);
     * %   disp(handles.image_similarity_image_watermark);
     * 
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Can''t display Similarity...You must open Watermark Image and Extracted watermark image.','Similarity have an error','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray494_,
            _mxarray496_,
            _mxarray162_,
            _mxarray127_,
            NULL));
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    } mlfEndCatch
    /*
     * %call function find similarity
     * imageExtractInformation(hObject,eventdata, handles);
     */
    mlfWatermark005_imageExtractInformation(
      mclVa(hObject, "hObject"),
      mclVa(eventdata, "eventdata"),
      mclVa(handles, "handles"));
    /*
     * 
     * % --- Executes on button press in pushbuttonClearAll.
     */
    return_:
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonClearAll_Callback" is the
 * implementation version of the "watermark005/pushbuttonClearAll_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 1885-2015). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function pushbuttonClearAll_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonClearAll_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonClearAll (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * %disp('%%% before     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
     * %disp(handles);
     * %try
     * if (handles.bool_openOriginal)
     */
    if (mlfTobool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openOriginal"))) {
        /*
         * try
         */
        mlfTry {
            /*
             * if ishandle(handles.h_subplotOriginal)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".h_subplotOriginal"),
                    NULL))) {
                /*
                 * delete(handles.h_subplotOriginal);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".h_subplotOriginal"),
                  NULL);
            /*
             * end                    
             */
            }
            /*
             * handles.current_filename1='';
             */
            mlfIndexAssign(&handles, ".current_filename1", _mxarray130_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disInfoOriginal;
             */
            mlfWatermark005_disInfoOriginal(NULL, NULL, NULL);
            /*
             * if ishandle(handles.current_filename1)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename1"),
                    NULL))) {
                /*
                 * delete(handles.current_filename1);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"),
                  NULL);
            /*
             * end 
             */
            }
        /*
         * catch
         */
        } mlfCatch {
            /*
             * disp('not delete handles 1' );    
             */
            mlfDisp(_mxarray498_);
        /*
         * end    
         */
        } mlfEndCatch
    /*
     * end
     */
    }
    /*
     * 
     * if (handles.bool_openWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(mclVa(handles, "handles"), ".bool_openWatermark"))) {
        /*
         * try
         */
        mlfTry {
            /*
             * if ishandle(handles.h_subplotWatermark)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".h_subplotWatermark"),
                    NULL))) {
                /*
                 * delete(handles.h_subplotWatermark);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".h_subplotWatermark"),
                  NULL);
            /*
             * end
             */
            }
            /*
             * handles.current_filename2=''
             */
            mlfIndexAssign(&handles, ".current_filename2", _mxarray130_);
            mclPrintArray(mclVa(handles, "handles"), "handles");
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disInfoWatermark;
             */
            mlfWatermark005_disInfoWatermark(NULL, NULL, NULL);
            /*
             * if ishandle(handles.current_filename2)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename2"),
                    NULL))) {
                /*
                 * delete(handles.current_filename2);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename2"),
                  NULL);
            /*
             * end            
             */
            }
        /*
         * catch                
         */
        } mlfCatch {
            /*
             * disp('not delete handles 2');
             */
            mlfDisp(_mxarray500_);
        /*
         * end
         */
        } mlfEndCatch
    /*
     * end             
     */
    }
    /*
     * 
     * if (handles.bool_openImageWithWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(
            mclVa(handles, "handles"), ".bool_openImageWithWatermark"))) {
        /*
         * try
         */
        mlfTry {
            /*
             * if ishandle(handles.h_subplotImageWithWatermark)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"),
                      ".h_subplotImageWithWatermark"),
                    NULL))) {
                /*
                 * delete(handles.h_subplotImageWithWatermark);
                 */
                mlfDelete(
                  mlfIndexRef(
                    mclVa(handles, "handles"), ".h_subplotImageWithWatermark"),
                  NULL);
            /*
             * end                        
             */
            }
            /*
             * handles.current_filename3=''
             */
            mlfIndexAssign(&handles, ".current_filename3", _mxarray130_);
            mclPrintArray(mclVa(handles, "handles"), "handles");
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disInfoImageWithWatermrk;
             */
            mlfWatermark005_disInfoImageWithWatermrk(NULL, NULL, NULL);
            /*
             * if ishandle(handles.current_filename3)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename3"),
                    NULL))) {
                /*
                 * delete(handles.current_filename3);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
                  NULL);
            /*
             * end                
             */
            }
        /*
         * catch 
         */
        } mlfCatch {
            /*
             * disp('not delete handles 3');
             */
            mlfDisp(_mxarray502_);
        /*
         * end                    
         */
        } mlfEndCatch
    /*
     * end    
     */
    }
    /*
     * 
     * if(handles.bool_openExtractWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(
            mclVa(handles, "handles"), ".bool_openExtractWatermark"))) {
        /*
         * 
         * try
         */
        mlfTry {
            /*
             * if ishandle(handles.h_subplotExtractedWatermark)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"),
                      ".h_subplotExtractedWatermark"),
                    NULL))) {
                /*
                 * delete(handles.h_subplotExtractedWatermark);
                 */
                mlfDelete(
                  mlfIndexRef(
                    mclVa(handles, "handles"), ".h_subplotExtractedWatermark"),
                  NULL);
            /*
             * end
             */
            }
            /*
             * handles.current_filename4=''
             */
            mlfIndexAssign(&handles, ".current_filename4", _mxarray130_);
            mclPrintArray(mclVa(handles, "handles"), "handles");
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
            /*
             * disInfoExtractWatermark;
             */
            mlfWatermark005_disInfoExtractWatermark(NULL, NULL, NULL);
            /*
             * if ishandle(handles.current_filename4)
             */
            if (mlfTobool(
                  mclFeval(
                    mclValueVarargout(),
                    mlxIshandle,
                    mlfIndexRef(
                      mclVa(handles, "handles"), ".current_filename4"),
                    NULL))) {
                /*
                 * delete(handles.current_filename4);
                 */
                mlfDelete(
                  mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"),
                  NULL);
            /*
             * end
             */
            }
        /*
         * catch                            
         */
        } mlfCatch {
            /*
             * disp('not delete handles 4');  
             */
            mlfDisp(_mxarray504_);
        /*
         * end
         */
        } mlfEndCatch
    /*
     * end
     */
    }
    /*
     * 
     * %delete show of crop
     * try
     */
    mlfTry {
        /*
         * delete(handles.h_subplotImageWithWatermark);
         */
        mlfDelete(
          mlfIndexRef(
            mclVa(handles, "handles"), ".h_subplotImageWithWatermark"),
          NULL);
    /*
     * catch
     */
    } mlfCatch {
        /*
         * disp('not delete crop');
         */
        mlfDisp(_mxarray506_);
    /*
     * end
     */
    } mlfEndCatch
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * disp('not delete handles 5');
     */
    mlfDisp(_mxarray508_);
    /*
     * disp(handles);
     */
    mlfDisp(mclVa(handles, "handles"));
    /*
     * handles.bool_openOriginal=0;
     */
    mlfIndexAssign(&handles, ".bool_openOriginal", _mxarray14_);
    /*
     * handles.bool_openWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openWatermark", _mxarray14_);
    /*
     * handles.bool_openImageWithWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openImageWithWatermark", _mxarray14_);
    /*
     * handles.bool_openExtractWatermark=0;
     */
    mlfIndexAssign(&handles, ".bool_openExtractWatermark", _mxarray14_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * 
     * %reset attack popup
     * set(findobj('tag','popupmenuAttackMethod'),'Value',1.0);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray55_, NULL),
        _mxarray79_,
        _mxarray0_,
        NULL));
    /*
     * %attack mode
     * handles.current_AttackMode='default';
     */
    mlfIndexAssign(&handles, ".current_AttackMode", _mxarray15_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * %block size add
     * handles.temp_popupblocksizeAdd=1;
     */
    mlfIndexAssign(&handles, ".temp_popupblocksizeAdd", _mxarray0_);
    /*
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * %block size extracted
     * handles.temp_popupblocksizeExt=1;
     */
    mlfIndexAssign(&handles, ".temp_popupblocksizeExt", _mxarray0_);
    /*
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * disAddWatermark;
     */
    mlfWatermark005_disAddWatermark(NULL, NULL, NULL);
    /*
     * disExtWatermark;
     */
    mlfWatermark005_disExtWatermark(NULL, NULL, NULL);
    /*
     * 
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','off'),
     */
    mclPrintAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * disp('After');
     */
    mlfDisp(_mxarray510_);
    /*
     * disp(handles);
     */
    mlfDisp(mclVa(handles, "handles"));
    /*
     * 
     * clear;
     */
    mlfClear(&ans, &eventdata, &hObject, &handles, NULL);
    /*
     * clc;
     */
    mlfClc();
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * %catch  
     * %    msgbox('Program detect some errors and will terminate program.','Program Error','error','modal') 
     * %   delete(handles.figure1);
     * %end
     * 
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%%%%%%%%%%%%%%my Function
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * 
     * %%%%%%%%   Find Image information(Property) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mwatermark005_imageInformation" is the implementation version
 * of the "watermark005/imageInformation" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2015-2046). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function imageInformation(hObject, eventdata, handles)
 */
static void Mwatermark005_imageInformation(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * h_figImageInfo = NULL;
    mxArray * h_image = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * h_image=imfinfo(handles.image_temp_info);
     */
    mlfAssign(
      &h_image,
      mclFeval(
        mclValueVarargout(),
        mlxImfinfo,
        mlfIndexRef(mclVa(handles, "handles"), ".image_temp_info"),
        NULL));
    /*
     * 
     * h_figImageInfo=imageinfo;%call function
     */
    mlfAssign(&h_figImageInfo, mlfNImageinfo(0, mclValueVarargout(), NULL));
    /*
     * if gcf==h_figImageInfo
     */
    if (mclEqBool(mlfGcf(), mclVv(h_figImageInfo, "h_figImageInfo"))) {
        /*
         * set(findobj('tag','editFilename'),'String',h_image.Filename);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray512_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".Filename"),
            NULL));
        /*
         * set(findobj('tag','editFileModifyDate'),'String',h_image.FileModDate);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray514_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".FileModDate"),
            NULL));
        /*
         * set(findobj('tag','editFileSize'),'String',h_image.FileSize);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray516_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".FileSize"),
            NULL));
        /*
         * set(findobj('tag','editImageFormat'),'String',h_image.Format);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray518_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".Format"),
            NULL));
        /*
         * if h_image.Format =='bmp'
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxEq,
                mlfIndexRef(mclVv(h_image, "h_image"), ".Format"),
                _mxarray177_,
                NULL))) {
            /*
             * set(findobj('tag','editImageFormatVersion'),'String',h_image.FormatVersion);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray520_, NULL),
                _mxarray81_,
                mlfIndexRef(mclVv(h_image, "h_image"), ".FormatVersion"),
                NULL));
        /*
         * else
         */
        } else {
            /*
             * set(findobj('tag','editImageFormatVersion'),'String','It''s not bitmap image.So Can''t identify FormatVersion');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray520_, NULL),
                _mxarray81_,
                _mxarray522_,
                NULL));
        /*
         * end
         */
        }
        /*
         * set(findobj('tag','editImageWidth'),'String',h_image.Width);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray524_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".Width"),
            NULL));
        /*
         * set(findobj('tag','editImageHeight'),'String',h_image.Height);
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mlfFindobj(_mxarray43_, _mxarray526_, NULL),
            _mxarray81_,
            mlfIndexRef(mclVv(h_image, "h_image"), ".Height"),
            NULL));
        /*
         * if h_image.Format =='bmp'
         */
        if (mlfTobool(
              mclFeval(
                mclValueVarargout(),
                mlxEq,
                mlfIndexRef(mclVv(h_image, "h_image"), ".Format"),
                _mxarray177_,
                NULL))) {
            /*
             * set(findobj('tag','editImageCompressionType'),'String',h_image.CompressionType);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray528_, NULL),
                _mxarray81_,
                mlfIndexRef(mclVv(h_image, "h_image"), ".CompressionType"),
                NULL));
        /*
         * else
         */
        } else {
            /*
             * set(findobj('tag','editImageCompressionType'),'String','It''s not bitmap image.So Can''t identify CompressionType');
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray528_, NULL),
                _mxarray81_,
                _mxarray530_,
                NULL));
        /*
         * end
         */
        }
    /*
     * end
     */
    }
    mxDestroyArray(h_image);
    mxDestroyArray(h_figImageInfo);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%% FIND PSNR AND MSE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
     * %im1  - Original image file name
     * % im2  - Watermarked image file name
     * % mse  � Mean Square Error
     * % psnr � Peak Signal to Noise Ratio
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */
}

/*
 * The function "Mwatermark005_imageWatermarkInformation" is the implementation
 * version of the "watermark005/imageWatermarkInformation" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2046-2128). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function imageWatermarkInformation(hObject, eventdata, handles)
 */
static void Mwatermark005_imageWatermarkInformation(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * h_figWatermarkImageInfo = NULL;
    mxArray * ans = NULL;
    mxArray * psnr = NULL;
    mxArray * mse = NULL;
    mxArray * k2 = NULL;
    mxArray * k1 = NULL;
    mxArray * acc = NULL;
    mxArray * iscolor = NULL;
    mxArray * N = NULL;
    mxArray * im2 = NULL;
    mxArray * im1 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * try    
     */
    mlfTry {
        /*
         * %    im1= handles.image_psnr_original;
         * im1= handles.current_filename1;
         */
        mlfAssign(
          &im1, mlfIndexRef(mclVa(handles, "handles"), ".current_filename1"));
        /*
         * %    im2= handles.image_psnr_image_watermark;
         * im2= handles.current_filename3;
         */
        mlfAssign(
          &im2, mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"));
        /*
         * 
         * im1 = imread(im1);
         */
        mlfAssign(&im1, mlfNImread(1, NULL, NULL, mclVv(im1, "im1"), NULL));
        /*
         * im1 = im2double(im1);
         */
        mlfAssign(&im1, mlfIm2double(mclVv(im1, "im1"), NULL));
        /*
         * 
         * im2 = imread(im2);
         */
        mlfAssign(&im2, mlfNImread(1, NULL, NULL, mclVv(im2, "im2"), NULL));
        /*
         * im2 = im2double(im2);
         */
        mlfAssign(&im2, mlfIm2double(mclVv(im2, "im2"), NULL));
        /*
         * 
         * 
         * N = size(im1);
         */
        mlfAssign(&N, mlfSize(mclValueVarargout(), mclVv(im1, "im1"), NULL));
        /*
         * 
         * iscolor = size(N);
         */
        mlfAssign(&iscolor, mlfSize(mclValueVarargout(), mclVv(N, "N"), NULL));
        /*
         * if iscolor(2) == 3;
         */
        if (mclEqBool(
              mclIntArrayRef1(mclVv(iscolor, "iscolor"), 2), _mxarray88_)) {
            /*
             * im1 = im1(:,:,3);
             */
            mlfAssign(
              &im1,
              mlfIndexRef(
                mclVv(im1, "im1"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray88_));
            /*
             * im2 = im2(:,:,3);
             */
            mlfAssign(
              &im2,
              mlfIndexRef(
                mclVv(im2, "im2"),
                "(?,?,?)",
                mlfCreateColonIndex(),
                mlfCreateColonIndex(),
                _mxarray88_));
        /*
         * end;
         */
        }
        /*
         * acc = 0;
         */
        mlfAssign(&acc, _mxarray14_);
        /*
         * 
         * for k1=1:N(1)
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclIntArrayRef1(mclVv(N, "N"), 1));
            if (v_ > e_) {
                mlfAssign(&k1, _mxarray11_);
            } else {
                /*
                 * for k2=1:N(2)
                 * acc = acc+ ( im1(k1,k2) - im2(k1,k2) )^2;   
                 * end
                 * end
                 */
                for (; ; ) {
                    int v_6 = mclForIntStart(1);
                    int e_6 = mclForIntEnd(mclIntArrayRef1(mclVv(N, "N"), 2));
                    if (v_6 > e_6) {
                        mlfAssign(&k2, _mxarray11_);
                    } else {
                        for (; ; ) {
                            mlfAssign(
                              &acc,
                              mclPlus(
                                mclVv(acc, "acc"),
                                mclMpower(
                                  mclMinus(
                                    mclIntArrayRef2(mclVv(im1, "im1"), v_, v_6),
                                    mclIntArrayRef2(
                                      mclVv(im2, "im2"), v_, v_6)),
                                  _mxarray85_)));
                            if (v_6 == e_6) {
                                break;
                            }
                            ++v_6;
                        }
                        mlfAssign(&k2, mlfScalar(v_6));
                    }
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&k1, mlfScalar(v_));
            }
        }
        /*
         * 
         * mse  = acc/(N(1)*N(2));
         */
        mlfAssign(
          &mse,
          mclMrdivide(
            mclVv(acc, "acc"),
            mclMtimes(
              mclIntArrayRef1(mclVv(N, "N"), 1),
              mclIntArrayRef1(mclVv(N, "N"), 2))));
        /*
         * psnr = 10*log10((255^2)/mse);
         */
        mlfAssign(
          &psnr,
          mclMtimes(
            _mxarray532_,
            mlfLog10(mclMrdivide(_mxarray533_, mclVv(mse, "mse")))));
        /*
         * %    disp(mse);
         * %   disp(psnr);
         * 
         * handles.mse_pass=mse;
         */
        mlfIndexAssign(&handles, ".mse_pass", mclVv(mse, "mse"));
        /*
         * handles.psnr_pass=psnr;
         */
        mlfIndexAssign(&handles, ".psnr_pass", mclVv(psnr, "psnr"));
        /*
         * guidata(hObject,handles);
         */
        mclAssignAns(
          &ans,
          mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * 
         * %      IMAGEWATERMARKINFO('CALLBACK',hObject,eventData,handles,...) calls the local
         * %      function named CALLBACK in IMAGEWATERMARKINFO.M with the given input arguments.
         * 
         * % imagewatermarkinfo('CALLBACK',hObject,eventData,handles,...) calls the local   
         * %imagewatermarkinfo('imagewatermarkinfo_OpeningFcn',hObject,eventData,handles, varargin)   
         * 
         * %imagewatermarkinfo('editPSNR_CreateFcn',hObject,eventData,handles)
         * %imagewatermarkinfo('editPSNR_CreateFcn',hObject,eventData,handles)
         * 
         * %function imagewatermarkinfo_OpeningFcn
         * %function editPSNR_CreateFcn
         * %function editMSE_CreateFcn
         * 
         * %    h_figWatermarkImageInfo=open('imagewatermarkinfo.fig');
         * h_figWatermarkImageInfo=imagewatermarkinfo;
         */
        mlfAssign(
          &h_figWatermarkImageInfo,
          mlfNImagewatermarkinfo(0, mclValueVarargout(), NULL));
        /*
         * 
         * 
         * if gcf==h_figWatermarkImageInfo
         */
        if (mclEqBool(
              mlfGcf(),
              mclVv(h_figWatermarkImageInfo, "h_figWatermarkImageInfo"))) {
            /*
             * set(findobj('tag','editPSNR'),'String',psnr);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray534_, NULL),
                _mxarray81_,
                mclVv(psnr, "psnr"),
                NULL));
            /*
             * set(findobj('tag','editMSE'),'String',mse);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray536_, NULL),
                _mxarray81_,
                mclVv(mse, "mse"),
                NULL));
        /*
         * %           set(findobj(h_figWatermarkImageInfo,'tag','editPSNR'),'String',psnr);
         * %           set(findobj(h_figWatermarkImageInfo,'tag','editMSE'),'String',mse);
         * % set(findobj(gcf,handles.editPSNR),'String',psnr);
         * %  set(findobj(gcf,handles.editMSE),'String',mse);
         * end    
         */
        }
    /*
     * %end
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Can''t display PSNR and MSE...Some parameters are missing Or program can''t read image.','PSNR MSE have an error','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray538_,
            _mxarray540_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(im1);
    mxDestroyArray(im2);
    mxDestroyArray(N);
    mxDestroyArray(iscolor);
    mxDestroyArray(acc);
    mxDestroyArray(k1);
    mxDestroyArray(k2);
    mxDestroyArray(mse);
    mxDestroyArray(psnr);
    mxDestroyArray(ans);
    mxDestroyArray(h_figWatermarkImageInfo);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %%%%%%%% FIND similarity  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
     * % function similarity(org,ext)
     */
}

/*
 * The function "Mwatermark005_imageExtractInformation" is the implementation
 * version of the "watermark005/imageExtractInformation" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2128-2174). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function imageExtractInformation(hObject,eventdata,handles)
 */
static void Mwatermark005_imageExtractInformation(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * h_figImageExtractinfo = NULL;
    mxArray * sim_out = NULL;
    mxArray * i = NULL;
    mxArray * sim_im2 = NULL;
    mxArray * sim_im1 = NULL;
    mxArray * n = NULL;
    mxArray * m = NULL;
    mxArray * ext = NULL;
    mxArray * org = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %org-> original watermark file name
     * %ext-> extracted image file name
     * %SIM Summary of this function goes here
     * %  Detailed explanation goes here
     * try
     */
    mlfTry {
        /*
         * org= handles.image_similarity_original;%original image
         */
        mlfAssign(
          &org,
          mlfIndexRef(mclVa(handles, "handles"), ".image_similarity_original"));
        /*
         * ext=handles.image_similarity_image_watermark;%extracted image
         */
        mlfAssign(
          &ext,
          mlfIndexRef(
            mclVa(handles, "handles"), ".image_similarity_image_watermark"));
        /*
         * 
         * if ischar(ext);
         */
        if (mlfTobool(mlfIschar(mclVv(ext, "ext")))) {
            /*
             * ext = imread(ext);
             */
            mlfAssign(&ext, mlfNImread(1, NULL, NULL, mclVv(ext, "ext"), NULL));
        /*
         * end;
         */
        }
        /*
         * if ischar(org);
         */
        if (mlfTobool(mlfIschar(mclVv(org, "org")))) {
            /*
             * org = imread(org);
             */
            mlfAssign(&org, mlfNImread(1, NULL, NULL, mclVv(org, "org"), NULL));
        /*
         * end;
         */
        }
        /*
         * [m,n] = size(ext);
         */
        mlfSize(mlfVarargout(&m, &n, NULL), mclVv(ext, "ext"), NULL);
        /*
         * org=imresize(org,[m n]);
         */
        mlfAssign(
          &org,
          mlfNImresize(
            0,
            mclValueVarargout(),
            mclVv(org, "org"),
            mlfHorzcat(mclVv(m, "m"), mclVv(n, "n"), NULL),
            NULL));
        /*
         * %m = row number
         * %n = column number
         * sim_im1(1:m*n)=1;
         */
        mclArrayAssign1(
          &sim_im1,
          _mxarray0_,
          mlfColon(_mxarray0_, mclMtimes(mclVv(m, "m"), mclVv(n, "n")), NULL));
        /*
         * sim_im2(1:m*n)=1;
         */
        mclArrayAssign1(
          &sim_im2,
          _mxarray0_,
          mlfColon(_mxarray0_, mclMtimes(mclVv(m, "m"), mclVv(n, "n")), NULL));
        /*
         * 
         * for i = 1:m ;
         */
        {
            int v_ = mclForIntStart(1);
            int e_ = mclForIntEnd(mclVv(m, "m"));
            if (v_ > e_) {
                mlfAssign(&i, _mxarray11_);
            } else {
                /*
                 * sim_im1((n*(i-1)+1):(i*n)) = org(i,:);
                 * sim_im2((n*(i-1)+1):(i*n)) = ext(i,:);
                 * end;
                 */
                for (; ; ) {
                    mclArrayAssign1(
                      &sim_im1,
                      mclArrayRef2(
                        mclVv(org, "org"),
                        mlfScalar(v_),
                        mlfCreateColonIndex()),
                      mlfColon(
                        mclPlus(
                          mclMtimes(mclVv(n, "n"), mlfScalar(v_ - 1)),
                          _mxarray0_),
                        mclMtimes(mlfScalar(v_), mclVv(n, "n")),
                        NULL));
                    mclArrayAssign1(
                      &sim_im2,
                      mclArrayRef2(
                        mclVv(ext, "ext"),
                        mlfScalar(v_),
                        mlfCreateColonIndex()),
                      mlfColon(
                        mclPlus(
                          mclMtimes(mclVv(n, "n"), mlfScalar(v_ - 1)),
                          _mxarray0_),
                        mclMtimes(mlfScalar(v_), mclVv(n, "n")),
                        NULL));
                    if (v_ == e_) {
                        break;
                    }
                    ++v_;
                }
                mlfAssign(&i, mlfScalar(v_));
            }
        }
        /*
         * 
         * %sim_out = (sim_im1*sim_im2)/sqrt(sim_im2*sim_im2)
         * sim_out = ( dot(sim_im1,sim_im2)/sqrt( dot(sim_im2,sim_im2) ) )/( dot(sim_im1,sim_im1)/sqrt( dot(sim_im1,sim_im1) ) );
         */
        mlfAssign(
          &sim_out,
          mclMrdivide(
            mclMrdivide(
              mlfDot(
                mclVv(sim_im1, "sim_im1"), mclVv(sim_im2, "sim_im2"), NULL),
              mlfSqrt(
                mlfDot(
                  mclVv(sim_im2, "sim_im2"), mclVv(sim_im2, "sim_im2"), NULL))),
            mclMrdivide(
              mlfDot(
                mclVv(sim_im1, "sim_im1"), mclVv(sim_im1, "sim_im1"), NULL),
              mlfSqrt(
                mlfDot(
                  mclVv(sim_im1, "sim_im1"),
                  mclVv(sim_im1, "sim_im1"),
                  NULL)))));
        /*
         * 
         * handles.similarity_pass=sim_out;
         */
        mlfIndexAssign(&handles, ".similarity_pass", mclVv(sim_out, "sim_out"));
        /*
         * 
         * 
         * h_figImageExtractinfo=imageextractinfo;%handles function imageextractinfo
         */
        mlfAssign(
          &h_figImageExtractinfo,
          mlfNImageextractinfo(0, mclValueVarargout(), NULL));
        /*
         * 
         * 
         * if gcf==h_figImageExtractinfo
         */
        if (mclEqBool(
              mlfGcf(),
              mclVv(h_figImageExtractinfo, "h_figImageExtractinfo"))) {
            /*
             * set(findobj('tag','editSimilarity'),'String',handles.similarity_pass);
             */
            mclAssignAns(
              &ans,
              mlfNSet(
                0,
                mlfFindobj(_mxarray43_, _mxarray542_, NULL),
                _mxarray81_,
                mlfIndexRef(mclVa(handles, "handles"), ".similarity_pass"),
                NULL));
        /*
         * end    
         */
        }
    /*
     * catch
     */
    } mlfCatch {
        /*
         * msgbox('Can''t display Similarity...Some parameters are missing Or program can''t read image.','PSNR MSE have an error','error','modal') 
         */
        mclPrintAns(
          &ans,
          mlfNMsgbox(
            0,
            mclAnsVarargout(),
            _mxarray544_,
            _mxarray540_,
            _mxarray162_,
            _mxarray127_,
            NULL));
    /*
     * return;
     * end
     */
    } mlfEndCatch
    mxDestroyArray(org);
    mxDestroyArray(ext);
    mxDestroyArray(m);
    mxDestroyArray(n);
    mxDestroyArray(sim_im1);
    mxDestroyArray(sim_im2);
    mxDestroyArray(i);
    mxDestroyArray(sim_out);
    mxDestroyArray(h_figImageExtractinfo);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * % --- Executes on button press in pushbuttonOpenExtractedImage.
     */
}

/*
 * The function "Mwatermark005_pushbuttonOpenExtractedImage_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonOpenExtractedImage_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2174-2209). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonOpenExtractedImage_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonOpenExtractedImage_Callback(mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * h_enablepushbuttonShowRealExtract = NULL;
    mxArray * h_enablepushbuttonExtractedWatermark_info = NULL;
    mxArray * image_x4 = NULL;
    mxArray * temp_path4 = NULL;
    mxArray * ans = NULL;
    mxArray * pathname4 = NULL;
    mxArray * filename4 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonOpenExtractedImage (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * [filename4,pathname4]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
     */
    mlfAssign(
      &filename4,
      mlfUigetfile(&pathname4, _mxarray17_, _mxarray27_, NULL, NULL));
    /*
     * %msgbox(disp(filename4);
     * if isequal(filename4,0)|isequal(pathname4,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename4, "filename4"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname4, "pathname4"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>>File not Open');
             */
            mlfDisp(_mxarray63_);
            /*
             * handles.bool_openExtractWatermark=0;%not open extracted image
             */
            mlfIndexAssign(&handles, ".bool_openExtractWatermark", _mxarray14_);
            /*
             * return;
             */
            goto return_;
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>>','File  ', pathname4, filename4, ' already openned'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray278_,
                _mxarray546_,
                mclVv(pathname4, "pathname4"),
                mclVv(filename4, "filename4"),
                _mxarray282_,
                NULL));
            /*
             * temp_path4=[pathname4 filename4];
             */
            mlfAssign(
              &temp_path4,
              mlfHorzcat(
                mclVv(pathname4, "pathname4"),
                mclVv(filename4, "filename4"),
                NULL));
            /*
             * handles.current_filename4 = temp_path4;
             */
            mlfIndexAssign(
              &handles, ".current_filename4", mclVv(temp_path4, "temp_path4"));
        }
    /*
     * end
     */
    }
    /*
     * 
     * image_x4=imread(handles.current_filename4);
     */
    mlfAssign(
      &image_x4,
      mlfNImread(
        1,
        NULL,
        NULL,
        mlfIndexRef(mclVa(handles, "handles"), ".current_filename4"),
        NULL));
    /*
     * %[0.35 0.075  0.3 0.3]4
     * handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x4),title(filename4);
     */
    mlfIndexAssign(
      &handles,
      ".h_subplotExtractedWatermark",
      mlfNSubplot(1, _mxarray35_, _mxarray252_, NULL, NULL));
    mclPrintArray(mclVa(handles, "handles"), "handles");
    mclPrintAns(
      &ans, mlfNIptsetpref(0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
    mclPrintAns(&ans, mlfNImshow(0, mclVv(image_x4, "image_x4"), NULL));
    mclAssignAns(&ans, mlfNTitle(0, mclVv(filename4, "filename4"), NULL));
    /*
     * clc;
     */
    mlfClc();
    /*
     * 
     * handles.bool_openExtractWatermark=1;%set open extracted image already
     */
    mlfIndexAssign(&handles, ".bool_openExtractWatermark", _mxarray0_);
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * if(handles.bool_openExtractWatermark)
     */
    if (mlfTobool(
          mlfIndexRef(
            mclVa(handles, "handles"), ".bool_openExtractWatermark"))) {
        /*
         * %enable pushbuttonExtractedWatermark_info
         * h_enablepushbuttonExtractedWatermark_info=findobj('tag','pushbuttonExtractedWatermark_info','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonExtractedWatermark_info,
          mlfFindobj(
            _mxarray43_, _mxarray260_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonExtractedWatermark_info,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonExtractedWatermark_info,
              "h_enablepushbuttonExtractedWatermark_info"),
            _mxarray47_,
            _mxarray49_,
            NULL));
        /*
         * 
         * %enable pushbuttonShowRealExtract
         * h_enablepushbuttonShowRealExtract=findobj('tag','pushbuttonShowRealExtract','Enable','off');
         */
        mlfAssign(
          &h_enablepushbuttonShowRealExtract,
          mlfFindobj(
            _mxarray43_, _mxarray262_, _mxarray47_, _mxarray67_, NULL));
        /*
         * set(h_enablepushbuttonShowRealExtract,'Enable','on');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVv(
              h_enablepushbuttonShowRealExtract,
              "h_enablepushbuttonShowRealExtract"),
            _mxarray47_,
            _mxarray49_,
            NULL));
    /*
     * end
     */
    }
    /*
     * 
     * 
     * % --- Executes on button press in pushbuttonSaveAttackwatermark.
     */
    return_:
    mxDestroyArray(filename4);
    mxDestroyArray(pathname4);
    mxDestroyArray(ans);
    mxDestroyArray(temp_path4);
    mxDestroyArray(image_x4);
    mxDestroyArray(h_enablepushbuttonExtractedWatermark_info);
    mxDestroyArray(h_enablepushbuttonShowRealExtract);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_pushbuttonSaveAttackwatermark_Callback" is the
 * implementation version of the
 * "watermark005/pushbuttonSaveAttackwatermark_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2209-2248). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonSaveAttackwatermark_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_pushbuttonSaveAttackwatermark_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * filenameWrite = NULL;
    mxArray * ans = NULL;
    mxArray * pathname3 = NULL;
    mxArray * filename3 = NULL;
    mxArray * marked_im5 = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonSaveAttackwatermark (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * 
     * handles=guidata(hObject);
     */
    mlfAssign(&handles, mlfNGuidata(1, mclVa(hObject, "hObject"), NULL));
    /*
     * marked_im5=imread(handles.current_filename3);
     */
    mlfAssign(
      &marked_im5,
      mlfNImread(
        1,
        NULL,
        NULL,
        mlfIndexRef(mclVa(handles, "handles"), ".current_filename3"),
        NULL));
    /*
     * [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     */
    mlfAssign(
      &filename3,
      mlfUiputfile(&pathname3, _mxarray204_, _mxarray206_, NULL, NULL));
    mclPrintArray(mclVv(filename3, "filename3"), "filename3");
    mclPrintArray(mclVv(pathname3, "pathname3"), "pathname3");
    /*
     * if isequal(filename3,0)|isequal(pathname3,0)
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfIsequal(mclVv(filename3, "filename3"), _mxarray14_, NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfIsequal(
                     mclVv(pathname3, "pathname3"), _mxarray14_, NULL)))) {
            mxDestroyArray(a_);
            /*
             * disp('Status>> File is not saving right now...Please try again');
             */
            mlfDisp(_mxarray208_);
            /*
             * handles.bool_AttackWatermarkSave=0;%not save attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray14_);
            /*
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        /*
         * return;
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * disp(['Status>> File ', pathname3, filename3, ' already saved'])
             */
            mlfDisp(
              mlfHorzcat(
                _mxarray210_,
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                _mxarray214_,
                NULL));
            /*
             * filenameWrite=[pathname3 filename3 '.bmp'];
             */
            mlfAssign(
              &filenameWrite,
              mlfHorzcat(
                mclVv(pathname3, "pathname3"),
                mclVv(filename3, "filename3"),
                _mxarray212_,
                NULL));
            /*
             * imwrite(marked_im5,filenameWrite,'bmp')
             */
            mlfImwrite(
              mclVv(marked_im5, "marked_im5"),
              mclVv(filenameWrite, "filenameWrite"),
              _mxarray177_,
              NULL);
            /*
             * handles.current_filename3 = filenameWrite;
             */
            mlfIndexAssign(
              &handles,
              ".current_filename3",
              mclVv(filenameWrite, "filenameWrite"));
            /*
             * handles.bool_AttackWatermarkSave=1;% save attack watermark
             */
            mlfIndexAssign(&handles, ".bool_AttackWatermarkSave", _mxarray0_);
            /*
             * EnaOpenImage;
             */
            mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
            /*
             * EnaUtilityAttackWatermark;
             */
            mlfWatermark005_EnaUtilityAttackWatermark(NULL, NULL, NULL);
            /*
             * EnaUtilityMainWatermark;
             */
            mlfWatermark005_EnaUtilityMainWatermark(NULL, NULL, NULL);
            /*
             * EnaInfoImageWithWatermrk;
             */
            mlfWatermark005_EnaInfoImageWithWatermrk(NULL, NULL, NULL);
            /*
             * 
             * try
             */
            mlfTry {
                /*
                 * handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title(['Save Attacking at ' filename3 '.bmp']);
                 */
                mlfIndexAssign(
                  &handles,
                  ".h_subplotImageWithWatermark",
                  mlfNSubplot(1, _mxarray35_, _mxarray192_, NULL, NULL));
                mclPrintArray(mclVa(handles, "handles"), "handles");
                mclPrintAns(
                  &ans,
                  mlfNIptsetpref(
                    0, mclAnsVarargout(), _mxarray39_, _mxarray41_));
                mclPrintAns(
                  &ans, mlfNImshow(0, mclVv(marked_im5, "marked_im5"), NULL));
                mclAssignAns(
                  &ans,
                  mlfNTitle(
                    0,
                    mlfHorzcat(
                      _mxarray548_,
                      mclVv(filename3, "filename3"),
                      _mxarray212_,
                      NULL),
                    NULL));
                /*
                 * clc;
                 */
                mlfClc();
            /*
             * catch
             */
            } mlfCatch {
                /*
                 * msgbox('Program can''t show image with watermark After Saving. ','Can''t show image with watermark after Saving','error','modal');
                 */
                mclAssignAns(
                  &ans,
                  mlfNMsgbox(
                    0,
                    mclAnsVarargout(),
                    _mxarray270_,
                    _mxarray272_,
                    _mxarray162_,
                    _mxarray127_,
                    NULL));
                /*
                 * return;
                 */
                goto return_;
            /*
             * end
             */
            } mlfEndCatch
            /*
             * 
             * guidata(hObject,handles);
             */
            mclAssignAns(
              &ans,
              mlfNGuidata(
                0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
        }
    /*
     * 
     * end
     */
    }
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     * %%%%%%%%%%%%%%%%%%%%%%% Disable button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
     */
    return_:
    mxDestroyArray(marked_im5);
    mxDestroyArray(filename3);
    mxDestroyArray(pathname3);
    mxDestroyArray(ans);
    mxDestroyArray(filenameWrite);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_disOpenImage" is the implementation version of
 * the "watermark005/disOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2248-2262). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disOpenImage(hObject, eventdata, handles)
 */
static void Mwatermark005_disOpenImage(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %disable pushbuttonOpenOriginal
     * set(findobj('tag','pushbuttonOpenOriginal'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray550_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonOpenWatermark
     * set(findobj('tag','pushbuttonOpenWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray552_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonOpenImageWithWatermark
     * set(findobj('tag','pushbuttonOpenImageWithWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray554_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonOpenExtractedImage
     * set(findobj('tag','pushbuttonOpenExtractedImage'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray556_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_disAddWatermark" is the implementation version
 * of the "watermark005/disAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2262-2278). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disAddWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_disAddWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable popupmenuBlockSizeAdd
     * set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray51_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %Enaable popupmenuBlockSizeAdd
     * set(findobj('tag','popupmenuBlockSizeAdd'),'Value',1.0);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray51_, NULL),
        _mxarray79_,
        _mxarray0_,
        NULL));
    /*
     * 
     * 
     * %disable pushbuttonAddWatermark
     * set(findobj('tag','pushbuttonAddWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray45_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonSaveImageWithWatermark
     * set(findobj('tag','pushbuttonSaveImageWithWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray198_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_disExtWatermark" is the implementation version
 * of the "watermark005/disExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2278-2298). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disExtWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_disExtWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * 
     * 
     * %disable popupmenuBlockSizeExt
     * set(findobj('tag','popupmenuBlockSizeExt'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray57_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable popupmenuBlockSizeExt
     * set(findobj('tag','popupmenuBlockSizeExt'),'Value',1.0);
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray57_, NULL),
        _mxarray79_,
        _mxarray0_,
        NULL));
    /*
     * 
     * %disable popupmenuAttackMethod
     * set(findobj('tag','popupmenuAttackMethod'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray55_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonExtract
     * set(findobj('tag','pushbuttonExtract'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray53_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonSaveExtracted
     * set(findobj('tag','pushbuttonSaveExtracted'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray258_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_disUtilityAttackWatermark" is the implementation
 * version of the "watermark005/disUtilityAttackWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2298-2317). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disUtilityAttackWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_disUtilityAttackWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %disable pushbuttonCrop
     * set(findobj('tag','pushbuttonCrop'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray290_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * %disable pushbuttonRotate
     * set(findobj('tag','pushbuttonRotate'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray286_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonFilter
     * set(findobj('tag','pushbuttonFilter'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray288_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonResize
     * set(findobj('tag','pushbuttonResize'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray284_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonJPEGCompression
     * set(findobj('tag','pushbuttonJPEGCompression'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray292_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_disUtilityAttackExceptSaveWatermark" is the
 * implementation version of the
 * "watermark005/disUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2317-2333). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disUtilityAttackExceptSaveWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_disUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %disable pushbuttonCrop
     * set(findobj('tag','pushbuttonCrop'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray290_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * %disable pushbuttonRotate
     * set(findobj('tag','pushbuttonRotate'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray286_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonFilter
     * set(findobj('tag','pushbuttonFilter'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray288_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonResize
     * set(findobj('tag','pushbuttonResize'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray284_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonJPEGCompression
     * set(findobj('tag','pushbuttonJPEGCompression'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray292_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
     */
}

/*
 * The function "Mwatermark005_disUtilityMainWatermark" is the implementation
 * version of the "watermark005/disUtilityMainWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2333-2350). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disUtilityMainWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_disUtilityMainWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %disable pushbuttonPSNR_MSE
     * set(findobj('tag','pushbuttonPSNR_MSE'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray558_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * 
     * %disable pushbuttonSimilarity
     * set(findobj('tag','pushbuttonSimilarity'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray560_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * 
     * %disable pushbuttonClearAll
     * set(findobj('tag','pushbuttonClearAll'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray562_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonExit
     * set(findobj('tag','pushbuttonExit'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray564_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
     */
}

/*
 * The function "Mwatermark005_disInfoOriginal" is the implementation version
 * of the "watermark005/disInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2350-2357). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disInfoOriginal(hObject, eventdata, handles)             
 */
static void Mwatermark005_disInfoOriginal(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %disable pushbuttonOriginal_info
     * set(findobj('tag','pushbuttonOriginal_info'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray59_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonShowRealOriginal
     * set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray61_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_disInfoWatermark" is the implementation version
 * of the "watermark005/disInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2357-2365). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disInfoWatermark(hObject, eventdata, handles)                         
 */
static void Mwatermark005_disInfoWatermark(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %disable pushbuttonWatermark_info
     * set(findobj('tag','pushbuttonWatermark_info'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray69_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonShowRealWatermark
     * set(findobj('tag','pushbuttonShowRealWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray71_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     */
}

/*
 * The function "Mwatermark005_disInfoImageWithWatermrk" is the implementation
 * version of the "watermark005/disInfoImageWithWatermrk" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2365-2373). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disInfoImageWithWatermrk(hObject, eventdata, handles)                          
 */
static void Mwatermark005_disInfoImageWithWatermrk(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %disable pushbuttonImageWithWatermark_info
     * set(findobj('tag','pushbuttonImageWithWatermark_info'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray200_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonShowRealImageWithWatermark
     * set(findobj('tag','pushbuttonShowRealImageWithWatermark'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray202_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     */
}

/*
 * The function "Mwatermark005_disInfoExtractWatermark" is the implementation
 * version of the "watermark005/disInfoExtractWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2373-2384). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function disInfoExtractWatermark(hObject, eventdata, handles)                          
 */
static void Mwatermark005_disInfoExtractWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %disable pushbuttonExtractedWatermark_info
     * set(findobj('tag','pushbuttonExtractedWatermark_info'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray260_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    /*
     * 
     * %disable pushbuttonShowRealExtract
     * set(findobj('tag','pushbuttonShowRealExtract'),'Enable','off');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray262_, NULL),
        _mxarray47_,
        _mxarray67_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     * %%%%%%%%%%%%%%%%%%%%%%% Enable button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                            
     * 
     */
}

/*
 * The function "Mwatermark005_EnaOpenImage" is the implementation version of
 * the "watermark005/EnaOpenImage" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2384-2399). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaOpenImage(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaOpenImage(mxArray * hObject,
                                       mxArray * eventdata,
                                       mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonOpenOriginal
     * set(findobj('tag','pushbuttonOpenOriginal'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray550_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonOpenWatermark
     * set(findobj('tag','pushbuttonOpenWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray552_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonOpenImageWithWatermark
     * set(findobj('tag','pushbuttonOpenImageWithWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray554_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonOpenExtractedImage
     * set(findobj('tag','pushbuttonOpenExtractedImage'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray556_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_EnaAddWatermark" is the implementation version
 * of the "watermark005/EnaAddWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2399-2413). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaAddWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaAddWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable popupmenuBlockSizeAdd
     * set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray51_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonAddWatermark
     * set(findobj('tag','pushbuttonAddWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray45_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonSaveImageWithWatermark
     * set(findobj('tag','pushbuttonSaveImageWithWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray198_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_EnaExtWatermark" is the implementation version
 * of the "watermark005/EnaExtWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2413-2428). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaExtWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaExtWatermark(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable popupmenuBlockSizeExt
     * set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray57_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable popupmenuAttackMethod
     * set(findobj('tag','popupmenuAttackMethod'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray55_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonExtract
     * set(findobj('tag','pushbuttonExtract'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray53_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonSaveExtracted
     * set(findobj('tag','pushbuttonSaveExtracted'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray258_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_EnaUtilityAttackWatermark" is the implementation
 * version of the "watermark005/EnaUtilityAttackWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2428-2447). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaUtilityAttackWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaUtilityAttackWatermark(mxArray * hObject,
                                                    mxArray * eventdata,
                                                    mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %Enaable pushbuttonCrop
     * set(findobj('tag','pushbuttonCrop'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray290_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * %Enaable pushbuttonRotate
     * set(findobj('tag','pushbuttonRotate'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray286_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonFilter
     * set(findobj('tag','pushbuttonFilter'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray288_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonResize
     * set(findobj('tag','pushbuttonResize'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray284_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonJPEGCompression
     * set(findobj('tag','pushbuttonJPEGCompression'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray292_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonSaveAttackwatermark
     * set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray304_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
     */
}

/*
 * The function "Mwatermark005_EnaUtilityAttackExceptSaveWatermark" is the
 * implementation version of the
 * "watermark005/EnaUtilityAttackExceptSaveWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2447-2463). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaUtilityAttackExceptSaveWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaUtilityAttackExceptSaveWatermark(mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * %Enaable pushbuttonCrop
     * set(findobj('tag','pushbuttonCrop'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray290_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * %Enaable pushbuttonRotate
     * set(findobj('tag','pushbuttonRotate'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray286_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonFilter
     * set(findobj('tag','pushbuttonFilter'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray288_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonResize
     * set(findobj('tag','pushbuttonResize'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray284_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonJPEGCompression
     * set(findobj('tag','pushbuttonJPEGCompression'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray292_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
     */
}

/*
 * The function "Mwatermark005_EnaUtilityMainWatermark" is the implementation
 * version of the "watermark005/EnaUtilityMainWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2463-2480). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaUtilityMainWatermark(hObject, eventdata, handles)
 */
static void Mwatermark005_EnaUtilityMainWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonPSNR_MSE
     * set(findobj('tag','pushbuttonPSNR_MSE'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray558_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * 
     * %Enaable pushbuttonSimilarity
     * set(findobj('tag','pushbuttonSimilarity'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray560_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * 
     * %Enaable pushbuttonClearAll
     * set(findobj('tag','pushbuttonClearAll'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray562_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonExit
     * set(findobj('tag','pushbuttonExit'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray564_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
     */
}

/*
 * The function "Mwatermark005_EnaInfoOriginal" is the implementation version
 * of the "watermark005/EnaInfoOriginal" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2480-2487). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaInfoOriginal(hObject, eventdata, handles)             
 */
static void Mwatermark005_EnaInfoOriginal(mxArray * hObject,
                                          mxArray * eventdata,
                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonOriginal_info
     * set(findobj('tag','pushbuttonOriginal_info'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray59_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonShowRealOriginal
     * set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray61_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}

/*
 * The function "Mwatermark005_EnaInfoWatermark" is the implementation version
 * of the "watermark005/EnaInfoWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2487-2495). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaInfoWatermark(hObject, eventdata, handles)                         
 */
static void Mwatermark005_EnaInfoWatermark(mxArray * hObject,
                                           mxArray * eventdata,
                                           mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonWatermark_info
     * set(findobj('tag','pushbuttonWatermark_info'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray69_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonShowRealWatermark
     * set(findobj('tag','pushbuttonShowRealWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray71_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     */
}

/*
 * The function "Mwatermark005_EnaInfoImageWithWatermrk" is the implementation
 * version of the "watermark005/EnaInfoImageWithWatermrk" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2495-2503). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaInfoImageWithWatermrk(hObject, eventdata, handles)                          
 */
static void Mwatermark005_EnaInfoImageWithWatermrk(mxArray * hObject,
                                                   mxArray * eventdata,
                                                   mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonImageWithWatermark_info
     * set(findobj('tag','pushbuttonImageWithWatermark_info'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray200_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonShowRealImageWithWatermark
     * set(findobj('tag','pushbuttonShowRealImageWithWatermark'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray202_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     */
}

/*
 * The function "Mwatermark005_EnaInfoExtractWatermark" is the implementation
 * version of the "watermark005/EnaInfoExtractWatermark" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2503-2512). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function EnaInfoExtractWatermark(hObject, eventdata, handles)                          
 */
static void Mwatermark005_EnaInfoExtractWatermark(mxArray * hObject,
                                                  mxArray * eventdata,
                                                  mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * %Enaable pushbuttonExtractedWatermark_info
     * set(findobj('tag','pushbuttonExtractedWatermark_info'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray260_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    /*
     * 
     * %Enaable pushbuttonShowRealExtract
     * set(findobj('tag','pushbuttonShowRealExtract'),'Enable','on');
     */
    mclAssignAns(
      &ans,
      mlfNSet(
        0,
        mlfFindobj(_mxarray43_, _mxarray262_, NULL),
        _mxarray47_,
        _mxarray49_,
        NULL));
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     */
}

/*
 * The function "Mwatermark005_startAgain" is the implementation version of the
 * "watermark005/startAgain" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\watermark005.m" (lines 2512-2528). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function startAgain(hObject, eventdata, handles)    
 */
static void Mwatermark005_startAgain(mxArray * hObject,
                                     mxArray * eventdata,
                                     mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * 
     * pushbuttonClearAll_Callback;
     */
    mlfWatermark005_pushbuttonClearAll_Callback(NULL, NULL, NULL);
    /*
     * EnaOpenImage;
     */
    mlfWatermark005_EnaOpenImage(NULL, NULL, NULL);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mwatermark005_popupmenuBlockSizeAdd_CreateFcn" is the
 * implementation version of the "watermark005/popupmenuBlockSizeAdd_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2528-2543). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSizeAdd_CreateFcn(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSizeAdd_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSizeAdd (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: popupmenu controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray73_, _mxarray75_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray73_,
            mlfNGet(1, _mxarray14_, _mxarray77_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * % --- Executes on selection change in popupmenuBlockSizeAdd.
     */
}

/*
 * The function "Mwatermark005_popupmenuBlockSizeAdd_Callback" is the
 * implementation version of the "watermark005/popupmenuBlockSizeAdd_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2543-2576). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSizeAdd_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSizeAdd_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * block_size_add = NULL;
    mxArray * popup_sel_index_add = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSizeAdd (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: contents = get(hObject,'String') returns popupmenuBlockSizeAdd contents as cell array
     * %        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSizeAdd
     * 
     * popup_sel_index_add = get(handles.popupmenuBlockSizeAdd,'Value');
     */
    mlfAssign(
      &popup_sel_index_add,
      mlfNGet(
        1,
        mlfIndexRef(mclVa(handles, "handles"), ".popupmenuBlockSizeAdd"),
        _mxarray79_,
        NULL));
    /*
     * 
     * switch popup_sel_index_add
     */
    {
        mxArray * v_
          = mclInitialize(mclVv(popup_sel_index_add, "popup_sel_index_add"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1
             * block_size_add=1;
             */
            mlfAssign(&block_size_add, _mxarray0_);
        /*
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray85_)) {
            /*
             * block_size_add=2;
             */
            mlfAssign(&block_size_add, _mxarray85_);
        /*
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray88_)) {
            /*
             * block_size_add=4;
             */
            mlfAssign(&block_size_add, _mxarray89_);
        /*
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray89_)) {
            /*
             * block_size_add=8;
             */
            mlfAssign(&block_size_add, _mxarray92_);
        /*
         * otherwise
         */
        } else {
            /*
             * block_size_add=1;
             */
            mlfAssign(&block_size_add, _mxarray0_);
        /*
         * 
         * end 
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * 
     * handles.temp_popupblocksizeAdd=block_size_add;
     */
    mlfIndexAssign(
      &handles,
      ".temp_popupblocksizeAdd",
      mclVv(block_size_add, "block_size_add"));
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * 
     * disp(handles.temp_popupblocksizeAdd);
     */
    mclFeval(
      mclAnsVarargout(),
      mlxDisp,
      mlfIndexRef(mclVa(handles, "handles"), ".temp_popupblocksizeAdd"),
      NULL);
    mxDestroyArray(popup_sel_index_add);
    mxDestroyArray(block_size_add);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mwatermark005_popupmenuBlockSizeExt_CreateFcn" is the
 * implementation version of the "watermark005/popupmenuBlockSizeExt_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2576-2591). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSizeExt_CreateFcn(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSizeExt_CreateFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSizeExt (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: popupmenu controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray73_, _mxarray75_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray73_,
            mlfNGet(1, _mxarray14_, _mxarray77_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * % --- Executes on selection change in popupmenuBlockSizeExt.
     */
}

/*
 * The function "Mwatermark005_popupmenuBlockSizeExt_Callback" is the
 * implementation version of the "watermark005/popupmenuBlockSizeExt_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\watermark005.m" (lines 2591-2619). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function popupmenuBlockSizeExt_Callback(hObject, eventdata, handles)
 */
static void Mwatermark005_popupmenuBlockSizeExt_Callback(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_watermark005);
    mxArray * ans = NULL;
    mxArray * block_size_ext = NULL;
    mxArray * popup_sel_index_ext = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to popupmenuBlockSizeExt (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: contents = get(hObject,'String') returns popupmenuBlockSizeExt contents as cell array
     * %        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSizeExt
     * 
     * popup_sel_index_ext = get(handles.popupmenuBlockSizeExt,'Value');
     */
    mlfAssign(
      &popup_sel_index_ext,
      mlfNGet(
        1,
        mlfIndexRef(mclVa(handles, "handles"), ".popupmenuBlockSizeExt"),
        _mxarray79_,
        NULL));
    /*
     * 
     * switch popup_sel_index_ext
     */
    {
        mxArray * v_
          = mclInitialize(mclVv(popup_sel_index_ext, "popup_sel_index_ext"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 1
             * block_size_ext=1;
             */
            mlfAssign(&block_size_ext, _mxarray0_);
        /*
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray85_)) {
            /*
             * block_size_ext=2;
             */
            mlfAssign(&block_size_ext, _mxarray85_);
        /*
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray88_)) {
            /*
             * block_size_ext=4;
             */
            mlfAssign(&block_size_ext, _mxarray89_);
        /*
         * case 4
         */
        } else if (mclSwitchCompare(v_, _mxarray89_)) {
            /*
             * block_size_ext=8;
             */
            mlfAssign(&block_size_ext, _mxarray92_);
        /*
         * otherwise
         */
        } else {
            /*
             * block_size_ext=1;
             */
            mlfAssign(&block_size_ext, _mxarray0_);
        /*
         * 
         * end 
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * 
     * handles.temp_popupblocksizeExt=block_size_ext;
     */
    mlfIndexAssign(
      &handles,
      ".temp_popupblocksizeExt",
      mclVv(block_size_ext, "block_size_ext"));
    /*
     * guidata(hObject,handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    /*
     * disp(handles.temp_popupblocksizeExt);
     */
    mclFeval(
      mclAnsVarargout(),
      mlxDisp,
      mlfIndexRef(mclVa(handles, "handles"), ".temp_popupblocksizeExt"),
      NULL);
    mxDestroyArray(popup_sel_index_ext);
    mxDestroyArray(block_size_ext);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
}
