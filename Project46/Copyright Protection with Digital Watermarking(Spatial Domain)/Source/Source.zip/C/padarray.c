/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "padarray.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "images_private_mkconstarray.h"
#include "libmatlbm.h"

static mxChar _array1_[4] = { 'b', 'o', 't', 'h' };
static mxArray * _mxarray0_;
static mxArray * _mxarray2_;

static mxChar _array4_[8] = { 'c', 'o', 'n', 's', 't', 'a', 'n', 't' };
static mxArray * _mxarray3_;

static mxChar _array6_[8] = { 'c', 'i', 'r', 'c', 'u', 'l', 'a', 'r' };
static mxArray * _mxarray5_;

static mxChar _array8_[9] = { 's', 'y', 'm', 'm', 'e', 't', 'r', 'i', 'c' };
static mxArray * _mxarray7_;

static mxChar _array10_[9] = { 'r', 'e', 'p', 'l', 'i', 'c', 'a', 't', 'e' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;
static mxArray * _mxarray12_;

static mxChar _array14_[3] = { 'p', 'r', 'e' };
static mxArray * _mxarray13_;

static mxChar _array16_[4] = { 'p', 'o', 's', 't' };
static mxArray * _mxarray15_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;

static mxChar _array22_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray21_;
static mxArray * _mxarray20_;

static mxChar _array26_[4] = { 'r', 'e', 'a', 'l' };
static mxArray * _mxarray25_;

static mxChar _array28_[6] = { 'v', 'e', 'c', 't', 'o', 'r' };
static mxArray * _mxarray27_;

static mxChar _array30_[6] = { 'n', 'o', 'n', 'n', 'a', 'n' };
static mxArray * _mxarray29_;

static mxChar _array32_[11] = { 'n', 'o', 'n', 'n', 'e', 'g',
                                'a', 't', 'i', 'v', 'e' };
static mxArray * _mxarray31_;

static mxChar _array34_[7] = { 'i', 'n', 't', 'e', 'g', 'e', 'r' };
static mxArray * _mxarray33_;

static mxArray * _array24_[5] = { NULL /*_mxarray25_*/, NULL /*_mxarray27_*/,
                                  NULL /*_mxarray29_*/, NULL /*_mxarray31_*/,
                                  NULL /*_mxarray33_*/ };
static mxArray * _mxarray23_;

static mxChar _array36_[7] = { 'P', 'A', 'D', 'S', 'I', 'Z', 'E' };
static mxArray * _mxarray35_;
static mxArray * _mxarray37_;

static mxChar _array41_[7] = { 'n', 'u', 'm', 'e', 'r', 'i', 'c' };
static mxArray * _mxarray40_;

static mxChar _array43_[7] = { 'l', 'o', 'g', 'i', 'c', 'a', 'l' };
static mxArray * _mxarray42_;

static mxArray * _array39_[2] = { NULL /*_mxarray40_*/, NULL /*_mxarray42_*/ };
static mxArray * _mxarray38_;

static mxChar _array46_[6] = { 's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray45_;
static mxArray * _mxarray44_;

static mxChar _array48_[6] = { 'P', 'A', 'D', 'V', 'A', 'L' };
static mxArray * _mxarray47_;

static mxArray * _array50_[6] = { NULL /*_mxarray5_*/, NULL /*_mxarray9_*/,
                                  NULL /*_mxarray7_*/, NULL /*_mxarray13_*/,
                                  NULL /*_mxarray15_*/, NULL /*_mxarray0_*/ };
static mxArray * _mxarray49_;

static mxChar _array52_[19] = { 'M', 'E', 'T', 'H', 'O', 'D', ' ',
                                'o', 'r', ' ', 'D', 'I', 'R', 'E',
                                'C', 'T', 'I', 'O', 'N' };
static mxArray * _mxarray51_;

static mxArray * _array54_[3] = { NULL /*_mxarray5_*/, NULL /*_mxarray9_*/,
                                  NULL /*_mxarray7_*/ };
static mxArray * _mxarray53_;

static mxArray * _array56_[3] = { NULL /*_mxarray13_*/, NULL /*_mxarray15_*/,
                                  NULL /*_mxarray0_*/ };
static mxArray * _mxarray55_;

static mxChar _array58_[31] = { 'I', 'm', 'a', 'g', 'e', 's', ':', 'p',
                                'a', 'd', 'a', 'r', 'r', 'a', 'y', ':',
                                'u', 'n', 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', 'E', 'r', 'r', 'o', 'r' };
static mxArray * _mxarray57_;

static mxChar _array60_[2] = { '%', 's' };
static mxArray * _mxarray59_;

static mxChar _array62_[23] = { 'U', 'n', 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', ' ', 'l', 'o', 'g', 'i', 'c',
                                ' ', 'e', 'r', 'r', 'o', 'r', '.' };
static mxArray * _mxarray61_;

static mxChar _array64_[35] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'b', 'a', 'd', 'T', 'y', 'p', 'e', 'F',
                                'o', 'r', 'C', 'o', 'n', 's', 't', 'a', 'n',
                                't', 'P', 'a', 'd', 'd', 'i', 'n', 'g' };
static mxArray * _mxarray63_;

static mxChar _array66_[35] = { 'F', 'u', 'n', 'c', 't', 'i', 'o', 'n', ' ',
                                '%', 's', ' ', 'e', 'x', 'p', 'e', 'c', 't',
                                'e', 'd', ' ', 'A', ' ', '(', 'a', 'r', 'g',
                                'u', 'm', 'e', 'n', 't', ' ', '1', ')' };
static mxArray * _mxarray65_;

static mxChar _array68_[46] = { 't', 'o', ' ', 'b', 'e', ' ', 'n', 'u',
                                'm', 'e', 'r', 'i', 'c', ' ', 'o', 'r',
                                ' ', 'l', 'o', 'g', 'i', 'c', 'a', 'l',
                                ' ', 'f', 'o', 'r', ' ', 'c', 'o', 'n',
                                's', 't', 'a', 'n', 't', ' ', 'p', 'a',
                                'd', 'd', 'i', 'n', 'g', '.' };
static mxArray * _mxarray67_;

static mxChar _array70_[6] = { '%', 's', 0x005c, 'n', '%', 's' };
static mxArray * _mxarray69_;

void InitializeModule_padarray(void) {
    _mxarray0_ = mclInitializeString(4, _array1_);
    _mxarray2_ = mclInitializeDouble(2.0);
    _mxarray3_ = mclInitializeString(8, _array4_);
    _mxarray5_ = mclInitializeString(8, _array6_);
    _mxarray7_ = mclInitializeString(9, _array8_);
    _mxarray9_ = mclInitializeString(9, _array10_);
    _mxarray11_ = mclInitializeDouble(1.0);
    _mxarray12_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray13_ = mclInitializeString(3, _array14_);
    _mxarray15_ = mclInitializeString(4, _array16_);
    _mxarray17_ = mclInitializeDouble(0.0);
    _mxarray18_ = mclInitializeDouble(-1.0);
    _mxarray19_ = mclInitializeDouble(4.0);
    _mxarray21_ = mclInitializeString(6, _array22_);
    _mxarray20_ = mclInitializeCell(_mxarray21_);
    _mxarray25_ = mclInitializeString(4, _array26_);
    _array24_[0] = _mxarray25_;
    _mxarray27_ = mclInitializeString(6, _array28_);
    _array24_[1] = _mxarray27_;
    _mxarray29_ = mclInitializeString(6, _array30_);
    _array24_[2] = _mxarray29_;
    _mxarray31_ = mclInitializeString(11, _array32_);
    _array24_[3] = _mxarray31_;
    _mxarray33_ = mclInitializeString(7, _array34_);
    _array24_[4] = _mxarray33_;
    _mxarray23_ = mclInitializeCellVector(1, 5, _array24_);
    _mxarray35_ = mclInitializeString(7, _array36_);
    _mxarray37_ = mclInitializeDouble(3.0);
    _mxarray40_ = mclInitializeString(7, _array41_);
    _array39_[0] = _mxarray40_;
    _mxarray42_ = mclInitializeString(7, _array43_);
    _array39_[1] = _mxarray42_;
    _mxarray38_ = mclInitializeCellVector(1, 2, _array39_);
    _mxarray45_ = mclInitializeString(6, _array46_);
    _mxarray44_ = mclInitializeCell(_mxarray45_);
    _mxarray47_ = mclInitializeString(6, _array48_);
    _array50_[0] = _mxarray5_;
    _array50_[1] = _mxarray9_;
    _array50_[2] = _mxarray7_;
    _array50_[3] = _mxarray13_;
    _array50_[4] = _mxarray15_;
    _array50_[5] = _mxarray0_;
    _mxarray49_ = mclInitializeCellVector(1, 6, _array50_);
    _mxarray51_ = mclInitializeString(19, _array52_);
    _array54_[0] = _mxarray5_;
    _array54_[1] = _mxarray9_;
    _array54_[2] = _mxarray7_;
    _mxarray53_ = mclInitializeCellVector(1, 3, _array54_);
    _array56_[0] = _mxarray13_;
    _array56_[1] = _mxarray15_;
    _array56_[2] = _mxarray0_;
    _mxarray55_ = mclInitializeCellVector(1, 3, _array56_);
    _mxarray57_ = mclInitializeString(31, _array58_);
    _mxarray59_ = mclInitializeString(2, _array60_);
    _mxarray61_ = mclInitializeString(23, _array62_);
    _mxarray63_ = mclInitializeString(35, _array64_);
    _mxarray65_ = mclInitializeString(35, _array66_);
    _mxarray67_ = mclInitializeString(46, _array68_);
    _mxarray69_ = mclInitializeString(6, _array70_);
}

void TerminateModule_padarray(void) {
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray51_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray45_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray23_);
    mxDestroyArray(_mxarray33_);
    mxDestroyArray(_mxarray31_);
    mxDestroyArray(_mxarray29_);
    mxDestroyArray(_mxarray27_);
    mxDestroyArray(_mxarray25_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfPadarray_ConstantPad(mxArray * a,
                                         mxArray * padSize,
                                         mxArray * padVal,
                                         mxArray * direction);
static void mlxPadarray_ConstantPad(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfPadarray_CircularPad(mxArray * a,
                                         mxArray * padSize,
                                         mxArray * direction);
static void mlxPadarray_CircularPad(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfPadarray_SymmetricPad(mxArray * a,
                                          mxArray * padSize,
                                          mxArray * direction);
static void mlxPadarray_SymmetricPad(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfPadarray_ReplicatePad(mxArray * a,
                                          mxArray * padSize,
                                          mxArray * direction);
static void mlxPadarray_ReplicatePad(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfPadarray_ParseInputs(mxArray * * method,
                                         mxArray * * padSize,
                                         mxArray * * padVal,
                                         mxArray * * direction,
                                         ...);
static void mlxPadarray_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * Mpadarray(int nargout_, mxArray * varargin);
static mxArray * Mpadarray_ConstantPad(int nargout_,
                                       mxArray * a,
                                       mxArray * padSize,
                                       mxArray * padVal,
                                       mxArray * direction);
static mxArray * Mpadarray_CircularPad(int nargout_,
                                       mxArray * a,
                                       mxArray * padSize,
                                       mxArray * direction);
static mxArray * Mpadarray_SymmetricPad(int nargout_,
                                        mxArray * a,
                                        mxArray * padSize,
                                        mxArray * direction);
static mxArray * Mpadarray_ReplicatePad(int nargout_,
                                        mxArray * a,
                                        mxArray * padSize,
                                        mxArray * direction);
static mxArray * Mpadarray_ParseInputs(mxArray * * method,
                                       mxArray * * padSize,
                                       mxArray * * padVal,
                                       mxArray * * direction,
                                       int nargout_,
                                       mxArray * varargin);

static mexFunctionTableEntry local_function_table_[5]
  = { { "ConstantPad", mlxPadarray_ConstantPad, 4, 1, NULL },
      { "CircularPad", mlxPadarray_CircularPad, 3, 1, NULL },
      { "SymmetricPad", mlxPadarray_SymmetricPad, 3, 1, NULL },
      { "ReplicatePad", mlxPadarray_ReplicatePad, 3, 1, NULL },
      { "ParseInputs", mlxPadarray_ParseInputs, -1, 5, NULL } };

_mexLocalFunctionTable _local_function_table_padarray
  = { 5, local_function_table_ };

/*
 * The function "mlfPadarray" contains the normal interface for the "padarray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\padarray.m" (lines
 * 1-100). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfPadarray(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * b = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    b = Mpadarray(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(b);
}

/*
 * The function "mlxPadarray" contains the feval interface for the "padarray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\padarray.m" (lines
 * 1-100). The feval function calls the implementation version of padarray
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxPadarray(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray Line: 1 Column:"
            " 1 The function \"padarray\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mpadarray(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfPadarray_ConstantPad" contains the normal interface for the
 * "padarray/ConstantPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 100-134). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfPadarray_ConstantPad(mxArray * a,
                                         mxArray * padSize,
                                         mxArray * padVal,
                                         mxArray * direction) {
    int nargout = 1;
    mxArray * b = NULL;
    mlfEnterNewContext(0, 4, a, padSize, padVal, direction);
    b = Mpadarray_ConstantPad(nargout, a, padSize, padVal, direction);
    mlfRestorePreviousContext(0, 4, a, padSize, padVal, direction);
    return mlfReturnValue(b);
}

/*
 * The function "mlxPadarray_ConstantPad" contains the feval interface for the
 * "padarray/ConstantPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 100-134). The feval
 * function calls the implementation version of padarray/ConstantPad through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxPadarray_ConstantPad(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[4];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/ConstantPad Line: 100 Co"
            "lumn: 1 The function \"padarray/ConstantPad\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/ConstantPad Line: 100 Co"
            "lumn: 1 The function \"padarray/ConstantPad\" was calle"
            "d with more than the declared number of inputs (4)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 4 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 4; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mplhs[0]
      = Mpadarray_ConstantPad(nlhs, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 4, mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfPadarray_CircularPad" contains the normal interface for the
 * "padarray/CircularPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 134-163). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfPadarray_CircularPad(mxArray * a,
                                         mxArray * padSize,
                                         mxArray * direction) {
    int nargout = 1;
    mxArray * b = NULL;
    mlfEnterNewContext(0, 3, a, padSize, direction);
    b = Mpadarray_CircularPad(nargout, a, padSize, direction);
    mlfRestorePreviousContext(0, 3, a, padSize, direction);
    return mlfReturnValue(b);
}

/*
 * The function "mlxPadarray_CircularPad" contains the feval interface for the
 * "padarray/CircularPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 134-163). The feval
 * function calls the implementation version of padarray/CircularPad through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxPadarray_CircularPad(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/CircularPad Line: 134 Co"
            "lumn: 1 The function \"padarray/CircularPad\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/CircularPad Line: 134 Co"
            "lumn: 1 The function \"padarray/CircularPad\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mpadarray_CircularPad(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfPadarray_SymmetricPad" contains the normal interface for
 * the "padarray/SymmetricPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 163-191). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfPadarray_SymmetricPad(mxArray * a,
                                          mxArray * padSize,
                                          mxArray * direction) {
    int nargout = 1;
    mxArray * b = NULL;
    mlfEnterNewContext(0, 3, a, padSize, direction);
    b = Mpadarray_SymmetricPad(nargout, a, padSize, direction);
    mlfRestorePreviousContext(0, 3, a, padSize, direction);
    return mlfReturnValue(b);
}

/*
 * The function "mlxPadarray_SymmetricPad" contains the feval interface for the
 * "padarray/SymmetricPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 163-191). The feval
 * function calls the implementation version of padarray/SymmetricPad through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxPadarray_SymmetricPad(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/SymmetricPad Line: 163 Co"
            "lumn: 1 The function \"padarray/SymmetricPad\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/SymmetricPad Line: 163 C"
            "olumn: 1 The function \"padarray/SymmetricPad\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mpadarray_SymmetricPad(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfPadarray_ReplicatePad" contains the normal interface for
 * the "padarray/ReplicatePad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 191-219). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfPadarray_ReplicatePad(mxArray * a,
                                          mxArray * padSize,
                                          mxArray * direction) {
    int nargout = 1;
    mxArray * b = NULL;
    mlfEnterNewContext(0, 3, a, padSize, direction);
    b = Mpadarray_ReplicatePad(nargout, a, padSize, direction);
    mlfRestorePreviousContext(0, 3, a, padSize, direction);
    return mlfReturnValue(b);
}

/*
 * The function "mlxPadarray_ReplicatePad" contains the feval interface for the
 * "padarray/ReplicatePad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 191-219). The feval
 * function calls the implementation version of padarray/ReplicatePad through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxPadarray_ReplicatePad(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/ReplicatePad Line: 191 Co"
            "lumn: 1 The function \"padarray/ReplicatePad\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/ReplicatePad Line: 191 C"
            "olumn: 1 The function \"padarray/ReplicatePad\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mpadarray_ReplicatePad(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfPadarray_ParseInputs" contains the normal interface for the
 * "padarray/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 219-282). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfPadarray_ParseInputs(mxArray * * method,
                                         mxArray * * padSize,
                                         mxArray * * padVal,
                                         mxArray * * direction,
                                         ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * a = NULL;
    mxArray * method__ = NULL;
    mxArray * padSize__ = NULL;
    mxArray * padVal__ = NULL;
    mxArray * direction__ = NULL;
    mlfVarargin(&varargin, direction, 0);
    mlfEnterNewContext(4, -1, method, padSize, padVal, direction, varargin);
    if (method != NULL) {
        ++nargout;
    }
    if (padSize != NULL) {
        ++nargout;
    }
    if (padVal != NULL) {
        ++nargout;
    }
    if (direction != NULL) {
        ++nargout;
    }
    a
      = Mpadarray_ParseInputs(
          &method__, &padSize__, &padVal__, &direction__, nargout, varargin);
    mlfRestorePreviousContext(4, 0, method, padSize, padVal, direction);
    mxDestroyArray(varargin);
    if (method != NULL) {
        mclCopyOutputArg(method, method__);
    } else {
        mxDestroyArray(method__);
    }
    if (padSize != NULL) {
        mclCopyOutputArg(padSize, padSize__);
    } else {
        mxDestroyArray(padSize__);
    }
    if (padVal != NULL) {
        mclCopyOutputArg(padVal, padVal__);
    } else {
        mxDestroyArray(padVal__);
    }
    if (direction != NULL) {
        mclCopyOutputArg(direction, direction__);
    } else {
        mxDestroyArray(direction__);
    }
    return mlfReturnValue(a);
}

/*
 * The function "mlxPadarray_ParseInputs" contains the feval interface for the
 * "padarray/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 219-282). The feval
 * function calls the implementation version of padarray/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxPadarray_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[5];
    int i;
    if (nlhs > 5) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: padarray/ParseInputs Line: 219 Co"
            "lumn: 1 The function \"padarray/ParseInputs\" was calle"
            "d with more than the declared number of outputs (5)."),
          NULL);
    }
    for (i = 0; i < 5; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mpadarray_ParseInputs(
          &mplhs[1], &mplhs[2], &mplhs[3], &mplhs[4], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 5 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 5; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mpadarray" is the implementation version of the "padarray"
 * M-function from file "k:\matlab6p5\toolbox\images\images\padarray.m" (lines
 * 1-100). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function b = padarray(varargin)
 */
static mxArray * Mpadarray(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    mxArray * b = NULL;
    mxArray * sizeB = NULL;
    mxArray * direction = NULL;
    mxArray * padVal = NULL;
    mxArray * padSize = NULL;
    mxArray * method = NULL;
    mxArray * a = NULL;
    mclCopyArray(&varargin);
    /*
     * %PADARRAY Pad an array.
     * %   B = PADARRAY(A,PADSIZE) pads array A with PADSIZE(k) number of zeros
     * %   along the k-th dimension of A.  PADSIZE should be a vector of
     * %   positive integers.
     * %
     * %   B = PADARRAY(A,PADSIZE,PADVAL) pads array A with PADVAL (a scalar)
     * %   instead of with zeros.
     * %
     * %   B = PADARRAY(A,PADSIZE,PADVAL,DIRECTION) pads A in the direction
     * %   specified by the string DIRECTION.  DIRECTION can be one of the
     * %   following strings.  
     * %
     * %       String values for DIRECTION
     * %       'pre'         Pads before the first array element along each
     * %                     dimension .
     * %       'post'        Pads after the last array element along each
     * %                     dimension. 
     * %       'both'        Pads before the first array element and after the
     * %                     last array element along each dimension.
     * %
     * %   By default, DIRECTION is 'post'.
     * %
     * %   B = PADARRAY(A,PADSIZE,METHOD,DIRECTION) pads array A using the
     * %   specified METHOD.  METHOD can be one of these strings:
     * %
     * %       String values for METHOD
     * %       'circular'    Pads with circular repetion of elements.
     * %       'replicate'   Repeats border elements of A.
     * %       'symmetric'   Pads array with mirror reflections of itself. 
     * % 
     * %   Class Support
     * %   -------------
     * %   When padding with a constant value, A can be numeric or logical.
     * %   When padding using the 'circular', 'replicate', or 'symmetric'
     * %   methods, A can be of any class.  B is of the same class as A.
     * %
     * %   Example
     * %   -------
     * %   Add three elements of padding to the beginning of a vector.  The
     * %   padding elements contain mirror copies of the array.
     * %
     * %       b = padarray([1 2 3 4],3,'symmetric','pre')
     * %
     * %   Add three elements of padding to the end of the first dimension of
     * %   the array and two elements of padding to the end of the second
     * %   dimension.  Use the value of the last array element as the padding
     * %   value.
     * %
     * %       B = padarray([1 2; 3 4],[3 2],'replicate','post')
     * %
     * %   Add three elements of padding to each dimension of a
     * %   three-dimensional array.  Each pad element contains the value 0.
     * %
     * %       A = [1 2; 3 4];
     * %       B = [5 6; 7 8];
     * %       C = cat(3,A,B)
     * %       D = padarray(C,[3 3],0,'both')
     * %
     * %   See also CIRCSHIFT, IMFILTER.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 1.11 $  $Date: 2002/03/15 15:28:49 $
     * 
     * [a, method, padSize, padVal, direction] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &a,
      mlfPadarray_ParseInputs(
        &method,
        &padSize,
        &padVal,
        &direction,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * if isempty(a),% treat empty matrix similar for any method
     */
    if (mlfTobool(mlfIsempty(mclVv(a, "a")))) {
        /*
         * 
         * if strcmp(direction,'both')
         */
        if (mlfTobool(mlfStrcmp(mclVv(direction, "direction"), _mxarray0_))) {
            /*
             * sizeB = size(a) + 2*padSize;
             */
            mlfAssign(
              &sizeB,
              mclPlus(
                mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL),
                mclMtimes(_mxarray2_, mclVv(padSize, "padSize"))));
        /*
         * else
         */
        } else {
            /*
             * sizeB = size(a) + padSize;
             */
            mlfAssign(
              &sizeB,
              mclPlus(
                mlfSize(mclValueVarargout(), mclVv(a, "a"), NULL),
                mclVv(padSize, "padSize")));
        /*
         * end
         */
        }
        /*
         * 
         * b = mkconstarray(class(a), padVal, sizeB);
         */
        mlfAssign(
          &b,
          mlfImages_private_mkconstarray(
            mlfClassName(mclVv(a, "a"), NULL),
            mclVv(padVal, "padVal"),
            mclVv(sizeB, "sizeB")));
    /*
     * 
     * else
     */
    } else {
        /*
         * switch method
         */
        mxArray * v_ = mclInitialize(mclVv(method, "method"));
        if (mclSwitchCompare(v_, _mxarray3_)) {
            /*
             * case 'constant'
             * b = ConstantPad(a, padSize, padVal, direction);
             */
            mlfAssign(
              &b,
              mlfPadarray_ConstantPad(
                mclVv(a, "a"),
                mclVv(padSize, "padSize"),
                mclVv(padVal, "padVal"),
                mclVv(direction, "direction")));
        /*
         * 
         * case 'circular'
         */
        } else if (mclSwitchCompare(v_, _mxarray5_)) {
            /*
             * b = CircularPad(a, padSize, direction);
             */
            mlfAssign(
              &b,
              mlfPadarray_CircularPad(
                mclVv(a, "a"),
                mclVv(padSize, "padSize"),
                mclVv(direction, "direction")));
        /*
         * 
         * case 'symmetric'
         */
        } else if (mclSwitchCompare(v_, _mxarray7_)) {
            /*
             * b = SymmetricPad(a, padSize, direction);
             */
            mlfAssign(
              &b,
              mlfPadarray_SymmetricPad(
                mclVv(a, "a"),
                mclVv(padSize, "padSize"),
                mclVv(direction, "direction")));
        /*
         * 
         * case 'replicate'
         */
        } else if (mclSwitchCompare(v_, _mxarray9_)) {
            /*
             * b = ReplicatePad(a, padSize, direction);
             */
            mlfAssign(
              &b,
              mlfPadarray_ReplicatePad(
                mclVv(a, "a"),
                mclVv(padSize, "padSize"),
                mclVv(direction, "direction")));
        /*
         * end      
         */
        }
        mxDestroyArray(v_);
    /*
     * end
     */
    }
    /*
     * 
     * if (islogical(a))
     */
    if (mlfTobool(mlfIslogical(mclVv(a, "a")))) {
        /*
         * b = logical(b);
         */
        mlfAssign(&b, mlfLogical(mclVv(b, "b")));
    /*
     * end
     */
    }
    mclValidateOutput(b, 1, nargout_, "b", "padarray");
    mxDestroyArray(a);
    mxDestroyArray(method);
    mxDestroyArray(padSize);
    mxDestroyArray(padVal);
    mxDestroyArray(direction);
    mxDestroyArray(sizeB);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     * %%%
     * %%% ConstantPad
     * %%%
     */
}

/*
 * The function "Mpadarray_ConstantPad" is the implementation version of the
 * "padarray/ConstantPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 100-134). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function b = ConstantPad(a, padSize, padVal, direction)
 */
static mxArray * Mpadarray_ConstantPad(int nargout_,
                                       mxArray * a,
                                       mxArray * padSize,
                                       mxArray * padVal,
                                       mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    mxArray * b = NULL;
    mxArray * M = NULL;
    mxArray * k = NULL;
    mxArray * sizeB = NULL;
    mxArray * idx = NULL;
    mxArray * numDims = NULL;
    mclCopyArray(&a);
    mclCopyArray(&padSize);
    mclCopyArray(&padVal);
    mclCopyArray(&direction);
    /*
     * 
     * numDims = prod(size(padSize));
     */
    mlfAssign(
      &numDims,
      mlfProd(
        mlfSize(mclValueVarargout(), mclVa(padSize, "padSize"), NULL), NULL));
    /*
     * 
     * % Form index vectors to subsasgn input array into output array.
     * % Also compute the size of the output array.
     * idx   = cell(1,numDims);
     */
    mlfAssign(&idx, mlfCell(_mxarray11_, mclVv(numDims, "numDims"), NULL));
    /*
     * sizeB = zeros(1,numDims);
     */
    mlfAssign(&sizeB, mlfZeros(_mxarray11_, mclVv(numDims, "numDims"), NULL));
    /*
     * for k = 1:numDims
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numDims, "numDims"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray12_);
        } else {
            /*
             * M = size(a,k);
             * switch direction
             * case 'pre'
             * idx{k}   = (1:M) + padSize(k);
             * sizeB(k) = M + padSize(k);
             * 
             * case 'post'
             * idx{k}   = 1:M;
             * sizeB(k) = M + padSize(k);
             * 
             * case 'both'
             * idx{k}   = (1:M) + padSize(k);
             * sizeB(k) = M + 2*padSize(k);
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &M,
                  mlfSize(mclValueVarargout(), mclVa(a, "a"), mlfScalar(v_)));
                {
                    mxArray * v_0
                      = mclInitialize(mclVa(direction, "direction"));
                    if (mclSwitchCompare(v_0, _mxarray13_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclPlus(
                            mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                            mclIntArrayRef1(mclVa(padSize, "padSize"), v_)));
                        mclIntArrayAssign1(
                          &sizeB,
                          mclPlus(
                            mclVv(M, "M"),
                            mclIntArrayRef1(mclVa(padSize, "padSize"), v_)),
                          v_);
                    } else if (mclSwitchCompare(v_0, _mxarray15_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mlfColon(_mxarray11_, mclVv(M, "M"), NULL));
                        mclIntArrayAssign1(
                          &sizeB,
                          mclPlus(
                            mclVv(M, "M"),
                            mclIntArrayRef1(mclVa(padSize, "padSize"), v_)),
                          v_);
                    } else if (mclSwitchCompare(v_0, _mxarray0_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclPlus(
                            mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                            mclIntArrayRef1(mclVa(padSize, "padSize"), v_)));
                        mclIntArrayAssign1(
                          &sizeB,
                          mclPlus(
                            mclVv(M, "M"),
                            mclMtimes(
                              _mxarray2_,
                              mclIntArrayRef1(mclVa(padSize, "padSize"), v_))),
                          v_);
                    }
                    mxDestroyArray(v_0);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * 
     * % Initialize output array with the padding value.  Make sure the
     * % output array is the same type as the input.
     * b         = mkconstarray(class(a), padVal, sizeB);
     */
    mlfAssign(
      &b,
      mlfImages_private_mkconstarray(
        mlfClassName(mclVa(a, "a"), NULL),
        mclVa(padVal, "padVal"),
        mclVv(sizeB, "sizeB")));
    /*
     * b(idx{:}) = a;
     */
    mclArrayAssign1(
      &b,
      mclVa(a, "a"),
      mlfIndexRef(mclVv(idx, "idx"), "{?}", mlfCreateColonIndex()));
    mclValidateOutput(b, 1, nargout_, "b", "padarray/ConstantPad");
    mxDestroyArray(numDims);
    mxDestroyArray(idx);
    mxDestroyArray(sizeB);
    mxDestroyArray(k);
    mxDestroyArray(M);
    mxDestroyArray(direction);
    mxDestroyArray(padVal);
    mxDestroyArray(padSize);
    mxDestroyArray(a);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     * 
     * %%%
     * %%% CircularPad
     * %%%
     */
}

/*
 * The function "Mpadarray_CircularPad" is the implementation version of the
 * "padarray/CircularPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 134-163). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function b = CircularPad(a, padSize, direction)
 */
static mxArray * Mpadarray_CircularPad(int nargout_,
                                       mxArray * a,
                                       mxArray * padSize,
                                       mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    mxArray * b = NULL;
    mxArray * p = NULL;
    mxArray * dimNums = NULL;
    mxArray * M = NULL;
    mxArray * k = NULL;
    mxArray * idx = NULL;
    mxArray * numDims = NULL;
    mclCopyArray(&a);
    mclCopyArray(&padSize);
    mclCopyArray(&direction);
    /*
     * 
     * numDims = prod(size(padSize));
     */
    mlfAssign(
      &numDims,
      mlfProd(
        mlfSize(mclValueVarargout(), mclVa(padSize, "padSize"), NULL), NULL));
    /*
     * 
     * % Form index vectors to subsasgn input array into output array.
     * % Also compute the size of the output array.
     * idx   = cell(1,numDims);
     */
    mlfAssign(&idx, mlfCell(_mxarray11_, mclVv(numDims, "numDims"), NULL));
    /*
     * for k = 1:numDims
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numDims, "numDims"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray12_);
        } else {
            /*
             * M = size(a,k);
             * dimNums = [1:M];
             * p = padSize(k);
             * 
             * switch direction
             * case 'pre'
             * idx{k}   = dimNums(mod([-p:M-1], M) + 1);
             * 
             * case 'post'
             * idx{k}   = dimNums(mod([0:M+p-1], M) + 1);
             * 
             * case 'both'
             * idx{k}   = dimNums(mod([-p:M+p-1], M) + 1);
             * 
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &M,
                  mlfSize(mclValueVarargout(), mclVa(a, "a"), mlfScalar(v_)));
                mlfAssign(&dimNums, mlfColon(_mxarray11_, mclVv(M, "M"), NULL));
                mlfAssign(&p, mclIntArrayRef1(mclVa(padSize, "padSize"), v_));
                {
                    mxArray * v_1
                      = mclInitialize(mclVa(direction, "direction"));
                    if (mclSwitchCompare(v_1, _mxarray13_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  mclUminus(mclVv(p, "p")),
                                  mclMinus(mclVv(M, "M"), _mxarray11_),
                                  NULL),
                                mclVv(M, "M")),
                              _mxarray11_)));
                    } else if (mclSwitchCompare(v_1, _mxarray15_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  _mxarray17_,
                                  mclMinus(
                                    mclPlus(mclVv(M, "M"), mclVv(p, "p")),
                                    _mxarray11_),
                                  NULL),
                                mclVv(M, "M")),
                              _mxarray11_)));
                    } else if (mclSwitchCompare(v_1, _mxarray0_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  mclUminus(mclVv(p, "p")),
                                  mclMinus(
                                    mclPlus(mclVv(M, "M"), mclVv(p, "p")),
                                    _mxarray11_),
                                  NULL),
                                mclVv(M, "M")),
                              _mxarray11_)));
                    }
                    mxDestroyArray(v_1);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * b = a(idx{:});
     */
    mlfAssign(
      &b,
      mclArrayRef1(
        mclVa(a, "a"),
        mlfIndexRef(mclVv(idx, "idx"), "{?}", mlfCreateColonIndex())));
    mclValidateOutput(b, 1, nargout_, "b", "padarray/CircularPad");
    mxDestroyArray(numDims);
    mxDestroyArray(idx);
    mxDestroyArray(k);
    mxDestroyArray(M);
    mxDestroyArray(dimNums);
    mxDestroyArray(p);
    mxDestroyArray(direction);
    mxDestroyArray(padSize);
    mxDestroyArray(a);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     * %%%
     * %%% SymmetricPad
     * %%%
     */
}

/*
 * The function "Mpadarray_SymmetricPad" is the implementation version of the
 * "padarray/SymmetricPad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 163-191). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function b = SymmetricPad(a, padSize, direction)
 */
static mxArray * Mpadarray_SymmetricPad(int nargout_,
                                        mxArray * a,
                                        mxArray * padSize,
                                        mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    mxArray * b = NULL;
    mxArray * p = NULL;
    mxArray * dimNums = NULL;
    mxArray * M = NULL;
    mxArray * k = NULL;
    mxArray * idx = NULL;
    mxArray * numDims = NULL;
    mclCopyArray(&a);
    mclCopyArray(&padSize);
    mclCopyArray(&direction);
    /*
     * 
     * numDims = prod(size(padSize));
     */
    mlfAssign(
      &numDims,
      mlfProd(
        mlfSize(mclValueVarargout(), mclVa(padSize, "padSize"), NULL), NULL));
    /*
     * 
     * % Form index vectors to subsasgn input array into output array.
     * % Also compute the size of the output array.
     * idx   = cell(1,numDims);
     */
    mlfAssign(&idx, mlfCell(_mxarray11_, mclVv(numDims, "numDims"), NULL));
    /*
     * for k = 1:numDims
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numDims, "numDims"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray12_);
        } else {
            /*
             * M = size(a,k);
             * dimNums = [1:M M:-1:1];
             * p = padSize(k);
             * 
             * switch direction
             * case 'pre'
             * idx{k}   = dimNums(mod([-p:M-1], 2*M) + 1);
             * 
             * case 'post'
             * idx{k}   = dimNums(mod([0:M+p-1], 2*M) + 1);
             * 
             * case 'both'
             * idx{k}   = dimNums(mod([-p:M+p-1], 2*M) + 1);
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &M,
                  mlfSize(mclValueVarargout(), mclVa(a, "a"), mlfScalar(v_)));
                mlfAssign(
                  &dimNums,
                  mlfHorzcat(
                    mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                    mlfColon(mclVv(M, "M"), _mxarray18_, _mxarray11_),
                    NULL));
                mlfAssign(&p, mclIntArrayRef1(mclVa(padSize, "padSize"), v_));
                {
                    mxArray * v_2
                      = mclInitialize(mclVa(direction, "direction"));
                    if (mclSwitchCompare(v_2, _mxarray13_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  mclUminus(mclVv(p, "p")),
                                  mclMinus(mclVv(M, "M"), _mxarray11_),
                                  NULL),
                                mclMtimes(_mxarray2_, mclVv(M, "M"))),
                              _mxarray11_)));
                    } else if (mclSwitchCompare(v_2, _mxarray15_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  _mxarray17_,
                                  mclMinus(
                                    mclPlus(mclVv(M, "M"), mclVv(p, "p")),
                                    _mxarray11_),
                                  NULL),
                                mclMtimes(_mxarray2_, mclVv(M, "M"))),
                              _mxarray11_)));
                    } else if (mclSwitchCompare(v_2, _mxarray0_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mclArrayRef1(
                            mclVv(dimNums, "dimNums"),
                            mclPlus(
                              mlfMod(
                                mlfColon(
                                  mclUminus(mclVv(p, "p")),
                                  mclMinus(
                                    mclPlus(mclVv(M, "M"), mclVv(p, "p")),
                                    _mxarray11_),
                                  NULL),
                                mclMtimes(_mxarray2_, mclVv(M, "M"))),
                              _mxarray11_)));
                    }
                    mxDestroyArray(v_2);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * b = a(idx{:});
     */
    mlfAssign(
      &b,
      mclArrayRef1(
        mclVa(a, "a"),
        mlfIndexRef(mclVv(idx, "idx"), "{?}", mlfCreateColonIndex())));
    mclValidateOutput(b, 1, nargout_, "b", "padarray/SymmetricPad");
    mxDestroyArray(numDims);
    mxDestroyArray(idx);
    mxDestroyArray(k);
    mxDestroyArray(M);
    mxDestroyArray(dimNums);
    mxDestroyArray(p);
    mxDestroyArray(direction);
    mxDestroyArray(padSize);
    mxDestroyArray(a);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     * %%%
     * %%% ReplicatePad
     * %%%
     */
}

/*
 * The function "Mpadarray_ReplicatePad" is the implementation version of the
 * "padarray/ReplicatePad" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 191-219). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function b = ReplicatePad(a, padSize, direction)
 */
static mxArray * Mpadarray_ReplicatePad(int nargout_,
                                        mxArray * a,
                                        mxArray * padSize,
                                        mxArray * direction) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    mxArray * b = NULL;
    mxArray * onesVector = NULL;
    mxArray * p = NULL;
    mxArray * M = NULL;
    mxArray * k = NULL;
    mxArray * idx = NULL;
    mxArray * numDims = NULL;
    mclCopyArray(&a);
    mclCopyArray(&padSize);
    mclCopyArray(&direction);
    /*
     * 
     * numDims = prod(size(padSize));
     */
    mlfAssign(
      &numDims,
      mlfProd(
        mlfSize(mclValueVarargout(), mclVa(padSize, "padSize"), NULL), NULL));
    /*
     * 
     * % Form index vectors to subsasgn input array into output array.
     * % Also compute the size of the output array.
     * idx   = cell(1,numDims);
     */
    mlfAssign(&idx, mlfCell(_mxarray11_, mclVv(numDims, "numDims"), NULL));
    /*
     * for k = 1:numDims
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVv(numDims, "numDims"));
        if (v_ > e_) {
            mlfAssign(&k, _mxarray12_);
        } else {
            /*
             * M = size(a,k);
             * p = padSize(k);
             * onesVector = ones(1,p);
             * 
             * switch direction
             * case 'pre'
             * idx{k}   = [onesVector 1:M];
             * 
             * case 'post'
             * idx{k}   = [1:M M*onesVector];
             * 
             * case 'both'
             * idx{k}   = [onesVector 1:M M*onesVector];
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &M,
                  mlfSize(mclValueVarargout(), mclVa(a, "a"), mlfScalar(v_)));
                mlfAssign(&p, mclIntArrayRef1(mclVa(padSize, "padSize"), v_));
                mlfAssign(
                  &onesVector, mlfOnes(_mxarray11_, mclVv(p, "p"), NULL));
                {
                    mxArray * v_3
                      = mclInitialize(mclVa(direction, "direction"));
                    if (mclSwitchCompare(v_3, _mxarray13_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mlfHorzcat(
                            mclVv(onesVector, "onesVector"),
                            mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                            NULL));
                    } else if (mclSwitchCompare(v_3, _mxarray15_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mlfHorzcat(
                            mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                            mclMtimes(
                              mclVv(M, "M"), mclVv(onesVector, "onesVector")),
                            NULL));
                    } else if (mclSwitchCompare(v_3, _mxarray0_)) {
                        mlfIndexAssign(
                          &idx,
                          "{?}",
                          mlfScalar(v_),
                          mlfHorzcat(
                            mclVv(onesVector, "onesVector"),
                            mlfColon(_mxarray11_, mclVv(M, "M"), NULL),
                            mclMtimes(
                              mclVv(M, "M"), mclVv(onesVector, "onesVector")),
                            NULL));
                    }
                    mxDestroyArray(v_3);
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&k, mlfScalar(v_));
        }
    }
    /*
     * b = a(idx{:});
     */
    mlfAssign(
      &b,
      mclArrayRef1(
        mclVa(a, "a"),
        mlfIndexRef(mclVv(idx, "idx"), "{?}", mlfCreateColonIndex())));
    mclValidateOutput(b, 1, nargout_, "b", "padarray/ReplicatePad");
    mxDestroyArray(numDims);
    mxDestroyArray(idx);
    mxDestroyArray(k);
    mxDestroyArray(M);
    mxDestroyArray(p);
    mxDestroyArray(onesVector);
    mxDestroyArray(direction);
    mxDestroyArray(padSize);
    mxDestroyArray(a);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return b;
    /*
     * 
     * %%%
     * %%% ParseInputs
     * %%%
     */
}

/*
 * The function "Mpadarray_ParseInputs" is the implementation version of the
 * "padarray/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\padarray.m" (lines 219-282). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [a, method, padSize, padVal, direction] = ParseInputs(varargin)
 */
static mxArray * Mpadarray_ParseInputs(mxArray * * method,
                                       mxArray * * padSize,
                                       mxArray * * padVal,
                                       mxArray * * direction,
                                       int nargout_,
                                       mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_padarray);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * a = NULL;
    mxArray * msg2 = NULL;
    mxArray * msg1 = NULL;
    mxArray * id = NULL;
    mxArray * string = NULL;
    mxArray * validStrings = NULL;
    mxArray * k = NULL;
    mxArray * firstStringToProcess = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % default values
     * a         = [];
     */
    mlfAssign(&a, _mxarray12_);
    /*
     * method    = 'constant';
     */
    mlfAssign(method, _mxarray3_);
    /*
     * padSize   = [];
     */
    mlfAssign(padSize, _mxarray12_);
    /*
     * padVal    = 0;
     */
    mlfAssign(padVal, _mxarray17_);
    /*
     * direction = 'both';
     */
    mlfAssign(direction, _mxarray0_);
    /*
     * 
     * checknargin(2,4,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray2_, _mxarray19_, mlfScalar(nargin_), mxCreateString("padarray"));
    /*
     * 
     * a = varargin{1};
     */
    mlfAssign(&a, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray11_));
    /*
     * 
     * padSize = varargin{2};
     */
    mlfAssign(
      padSize, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray2_));
    /*
     * checkinput(padSize, {'double'}, {'real' 'vector' 'nonnan' 'nonnegative' ...
     */
    mlfImages_private_checkinput(
      mclVv(*padSize, "padSize"),
      _mxarray20_,
      _mxarray23_,
      mxCreateString("padarray"),
      _mxarray35_,
      _mxarray2_);
    /*
     * 'integer'}, mfilename, 'PADSIZE', 2);
     * 
     * % Preprocess the padding size
     * if (prod(size(padSize)) < ndims(a))
     */
    if (mclLtBool(
          mlfProd(
            mlfSize(mclValueVarargout(), mclVv(*padSize, "padSize"), NULL),
            NULL),
          mlfNdims(mclVv(a, "a")))) {
        /*
         * padSize           = padSize(:);
         */
        mlfAssign(
          padSize,
          mclArrayRef1(mclVv(*padSize, "padSize"), mlfCreateColonIndex()));
        /*
         * padSize(ndims(a)) = 0;
         */
        mclArrayAssign1(padSize, _mxarray17_, mlfNdims(mclVv(a, "a")));
    /*
     * end
     */
    }
    /*
     * 
     * if nargin > 2
     */
    if (nargin_ > 2) {
        /*
         * 
         * firstStringToProcess = 3;
         */
        mlfAssign(&firstStringToProcess, _mxarray37_);
        /*
         * 
         * if ~ischar(varargin{3})
         */
        if (mclNotBool(
              mclFeval(
                mclValueVarargout(),
                mlxIschar,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray37_),
                NULL))) {
            /*
             * % Third input must be pad value.
             * padVal = varargin{3};
             */
            mlfAssign(
              padVal,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray37_));
            /*
             * checkinput(padVal, {'numeric' 'logical'}, {'scalar'}, ...
             */
            mlfImages_private_checkinput(
              mclVv(*padVal, "padVal"),
              _mxarray38_,
              _mxarray44_,
              mxCreateString("padarray"),
              _mxarray47_,
              _mxarray37_);
            /*
             * mfilename, 'PADVAL', 3);
             * 
             * firstStringToProcess = 4;
             */
            mlfAssign(&firstStringToProcess, _mxarray19_);
        /*
         * 
         * end
         */
        }
        /*
         * 
         * for k = firstStringToProcess:nargin
         */
        {
            mclForLoopIterator viter__;
            for (mclForStart(
                   &viter__,
                   mclVv(firstStringToProcess, "firstStringToProcess"),
                   mlfScalar(nargin_),
                   NULL);
                 mclForNext(&viter__, &k);
                 ) {
                /*
                 * validStrings = {'circular' 'replicate' 'symmetric' 'pre' ...
                 */
                mlfAssign(&validStrings, _mxarray49_);
                /*
                 * 'post' 'both'};
                 * string = checkstrs(varargin{k}, validStrings, mfilename, ...
                 */
                mlfAssign(
                  &string,
                  mclFeval(
                    mclValueVarargout(),
                    mlxImages_private_checkstrs,
                    mlfIndexRef(
                      mclVa(varargin, "varargin"), "{?}", mclVv(k, "k")),
                    mclVv(validStrings, "validStrings"),
                    mxCreateString("padarray"),
                    _mxarray51_,
                    mclVv(k, "k"),
                    NULL));
                /*
                 * 'METHOD or DIRECTION', k);
                 * switch string
                 */
                {
                    mxArray * v_ = mclInitialize(mclVv(string, "string"));
                    if (mclSwitchCompare(v_, _mxarray53_)) {
                        /*
                         * case {'circular' 'replicate' 'symmetric'}
                         * method = string;
                         */
                        mlfAssign(method, mclVv(string, "string"));
                    /*
                     * 
                     * case {'pre' 'post' 'both'}
                     */
                    } else if (mclSwitchCompare(v_, _mxarray55_)) {
                        /*
                         * direction = string;
                         */
                        mlfAssign(direction, mclVv(string, "string"));
                    /*
                     * 
                     * otherwise
                     */
                    } else {
                        /*
                         * error('Images:padarray:unexpectedError', '%s', ...
                         */
                        mlfError(_mxarray57_, _mxarray59_, _mxarray61_, NULL);
                    /*
                     * 'Unexpected logic error.')
                     * end
                     */
                    }
                    mxDestroyArray(v_);
                }
            /*
             * end
             */
            }
            mclDestroyForLoopIterator(viter__);
        }
    /*
     * end
     */
    }
    /*
     * 
     * % Check the input array type
     * if strcmp(method,'constant') & ~(isnumeric(a) | islogical(a))
     */
    {
        mxArray * a_
          = mclInitialize(mlfStrcmp(mclVv(*method, "method"), _mxarray3_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclNot(
                     mclOr(
                       mlfIsnumeric(mclVv(a, "a")),
                       mlfIslogical(mclVv(a, "a"))))))) {
            mxDestroyArray(a_);
            /*
             * id = sprintf('Images:%s:badTypeForConstantPadding', mfilename);
             */
            mlfAssign(
              &id,
              mlfSprintf(NULL, _mxarray63_, mxCreateString("padarray"), NULL));
            /*
             * msg1 = sprintf('Function %s expected A (argument 1)',mfilename);
             */
            mlfAssign(
              &msg1,
              mlfSprintf(NULL, _mxarray65_, mxCreateString("padarray"), NULL));
            /*
             * msg2 = 'to be numeric or logical for constant padding.';
             */
            mlfAssign(&msg2, _mxarray67_);
            /*
             * error(id,'%s\n%s',msg1,msg2);
             */
            mlfError(
              mclVv(id, "id"),
              _mxarray69_,
              mclVv(msg1, "msg1"),
              mclVv(msg2, "msg2"),
              NULL);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    mclValidateOutput(a, 1, nargout_, "a", "padarray/ParseInputs");
    mclValidateOutput(*method, 2, nargout_, "method", "padarray/ParseInputs");
    mclValidateOutput(*padSize, 3, nargout_, "padSize", "padarray/ParseInputs");
    mclValidateOutput(*padVal, 4, nargout_, "padVal", "padarray/ParseInputs");
    mclValidateOutput(
      *direction, 5, nargout_, "direction", "padarray/ParseInputs");
    mxDestroyArray(ans);
    mxDestroyArray(firstStringToProcess);
    mxDestroyArray(k);
    mxDestroyArray(validStrings);
    mxDestroyArray(string);
    mxDestroyArray(id);
    mxDestroyArray(msg1);
    mxDestroyArray(msg2);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return a;
}
