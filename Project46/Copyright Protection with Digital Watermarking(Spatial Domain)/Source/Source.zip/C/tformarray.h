/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:07 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#ifndef __tformarray_h
#define __tformarray_h 1

#ifdef __cplusplus
extern "C" {
#endif

#include "libmatlb.h"

extern void InitializeModule_tformarray(void);
extern void TerminateModule_tformarray(void);
extern _mexLocalFunctionTable _local_function_table_tformarray;

extern mxArray * mlfTformarray(mxArray * A,
                               mxArray * T,
                               mxArray * R,
                               mxArray * tdims_A,
                               mxArray * tdims_B,
                               mxArray * tsize_B,
                               mxArray * tmap_B,
                               mxArray * F);
extern void mlxTformarray(int nlhs,
                          mxArray * plhs[],
                          int nrhs,
                          mxArray * prhs[]);

#ifdef __cplusplus
}
#endif

#endif
