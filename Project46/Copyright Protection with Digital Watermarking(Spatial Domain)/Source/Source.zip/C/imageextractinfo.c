/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imageextractinfo.h"
#include "gui_mainfcn.h"
#include "guidata.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;

static mxChar _array2_[8] = { 'g', 'u', 'i', '_', 'N', 'a', 'm', 'e' };
static mxArray * _mxarray1_;

static mxChar _array4_[13] = { 'g', 'u', 'i', '_', 'S', 'i', 'n',
                               'g', 'l', 'e', 't', 'o', 'n' };
static mxArray * _mxarray3_;

static mxChar _array6_[14] = { 'g', 'u', 'i', '_', 'O', 'p', 'e',
                               'n', 'i', 'n', 'g', 'F', 'c', 'n' };
static mxArray * _mxarray5_;

static mxChar _array8_[13] = { 'g', 'u', 'i', '_', 'O', 'u', 't',
                               'p', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray7_;

static mxChar _array10_[13] = { 'g', 'u', 'i', '_', 'L', 'a', 'y',
                                'o', 'u', 't', 'F', 'c', 'n' };
static mxArray * _mxarray9_;
static mxArray * _mxarray11_;

static mxChar _array13_[12] = { 'g', 'u', 'i', '_', 'C', 'a',
                                'l', 'l', 'b', 'a', 'c', 'k' };
static mxArray * _mxarray12_;

static mxChar _array15_[15] = { 'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray14_;

static mxChar _array17_[5] = { 'w', 'h', 'i', 't', 'e' };
static mxArray * _mxarray16_;
static mxArray * _mxarray18_;

static mxChar _array20_[31] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', 'U',
                                'i', 'c', 'o', 'n', 't', 'r', 'o', 'l',
                                'B', 'a', 'c', 'k', 'g', 'r', 'o', 'u',
                                'n', 'd', 'C', 'o', 'l', 'o', 'r' };
static mxArray * _mxarray19_;

void InitializeModule_imageextractinfo(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeString(8, _array2_);
    _mxarray3_ = mclInitializeString(13, _array4_);
    _mxarray5_ = mclInitializeString(14, _array6_);
    _mxarray7_ = mclInitializeString(13, _array8_);
    _mxarray9_ = mclInitializeString(13, _array10_);
    _mxarray11_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray12_ = mclInitializeString(12, _array13_);
    _mxarray14_ = mclInitializeString(15, _array15_);
    _mxarray16_ = mclInitializeString(5, _array17_);
    _mxarray18_ = mclInitializeDouble(0.0);
    _mxarray19_ = mclInitializeString(31, _array20_);
}

void TerminateModule_imageextractinfo(void) {
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray12_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static void mlfImageextractinfo_imageextractinfo_OpeningFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles,
                                                            ...);
static void mlxImageextractinfo_imageextractinfo_OpeningFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]);
static mxArray * mlfImageextractinfo_imageextractinfo_OutputFcn(mlfVarargoutList * varargout,
                                                                mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles);
static void mlxImageextractinfo_imageextractinfo_OutputFcn(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]);
static void mlfImageextractinfo_pushbuttonSimilarity_Ok_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles);
static void mlxImageextractinfo_pushbuttonSimilarity_Ok_Callback(int nlhs,
                                                                 mxArray * plhs[],
                                                                 int nrhs,
                                                                 mxArray * prhs[]);
static void mlfImageextractinfo_editSimilarity_CreateFcn(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles);
static void mlxImageextractinfo_editSimilarity_CreateFcn(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]);
static void mlfImageextractinfo_editSimilarity_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles);
static void mlxImageextractinfo_editSimilarity_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]);
static mxArray * Mimageextractinfo(int nargout_, mxArray * varargin);
static void Mimageextractinfo_imageextractinfo_OpeningFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles,
                                                          mxArray * varargin);
static mxArray * Mimageextractinfo_imageextractinfo_OutputFcn(int nargout_,
                                                              mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles);
static void Mimageextractinfo_pushbuttonSimilarity_Ok_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles);
static void Mimageextractinfo_editSimilarity_CreateFcn(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles);
static void Mimageextractinfo_editSimilarity_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles);

static mexFunctionTableEntry local_function_table_[5]
  = { { "imageextractinfo_OpeningFcn",
        mlxImageextractinfo_imageextractinfo_OpeningFcn, -4, 0, NULL },
      { "imageextractinfo_OutputFcn",
        mlxImageextractinfo_imageextractinfo_OutputFcn, 3, -1, NULL },
      { "pushbuttonSimilarity_Ok_Callback",
        mlxImageextractinfo_pushbuttonSimilarity_Ok_Callback, 3, 0, NULL },
      { "editSimilarity_CreateFcn",
        mlxImageextractinfo_editSimilarity_CreateFcn, 3, 0, NULL },
      { "editSimilarity_Callback",
        mlxImageextractinfo_editSimilarity_Callback, 3, 0, NULL } };

_mexLocalFunctionTable _local_function_table_imageextractinfo
  = { 5, local_function_table_ };

/*
 * The function "mlfNImageextractinfo" contains the nargout interface for the
 * "imageextractinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 1-48). This interface is only produced if the
 * M-function uses the special variable "nargout". The nargout interface allows
 * the number of requested outputs to be specified via the nargout argument, as
 * opposed to the normal interface which dynamically calculates the number of
 * outputs based on the number of non-NULL inputs it receives. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
mxArray * mlfNImageextractinfo(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimageextractinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImageextractinfo" contains the normal interface for the
 * "imageextractinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 1-48). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
mxArray * mlfImageextractinfo(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimageextractinfo(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImageextractinfo" contains the void interface for the
 * "imageextractinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 1-48). The void interface is only produced if
 * the M-function uses the special variable "nargout", and has at least one
 * output. The void interface function specifies zero output arguments to the
 * implementation version of the function, and in the event that the
 * implementation version still returns an output (which, in MATLAB, would be
 * assigned to the "ans" variable), it deallocates the output. This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
void mlfVImageextractinfo(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimageextractinfo(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImageextractinfo" contains the feval interface for the
 * "imageextractinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 1-48). The feval function calls the
 * implementation version of imageextractinfo through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
void mlxImageextractinfo(int nlhs,
                         mxArray * plhs[],
                         int nrhs,
                         mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimageextractinfo(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImageextractinfo_imageextractinfo_OpeningFcn" contains the
 * normal interface for the "imageextractinfo/imageextractinfo_OpeningFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 48-71). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfImageextractinfo_imageextractinfo_OpeningFcn(mxArray * hObject,
                                                            mxArray * eventdata,
                                                            mxArray * handles,
                                                            ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, handles, 0);
    mlfEnterNewContext(0, -4, hObject, eventdata, handles, varargin);
    Mimageextractinfo_imageextractinfo_OpeningFcn(
      hObject, eventdata, handles, varargin);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImageextractinfo_imageextractinfo_OpeningFcn" contains the
 * feval interface for the "imageextractinfo/imageextractinfo_OpeningFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 48-71). The feval function
 * calls the implementation version of
 * imageextractinfo/imageextractinfo_OpeningFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageextractinfo_imageextractinfo_OpeningFcn(int nlhs,
                                                            mxArray * plhs[],
                                                            int nrhs,
                                                            mxArray * prhs[]) {
    mxArray * mprhs[4];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/imageextractin"
            "fo_OpeningFcn Line: 48 Column: 1 The function \"image"
            "extractinfo/imageextractinfo_OpeningFcn\" was called "
            "with more than the declared number of outputs (0)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mprhs[3] = NULL;
    mlfAssign(&mprhs[3], mclCreateVararginCell(nrhs - 3, prhs + 3));
    Mimageextractinfo_imageextractinfo_OpeningFcn(
      mprhs[0], mprhs[1], mprhs[2], mprhs[3]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mxDestroyArray(mprhs[3]);
}

/*
 * The function "mlfImageextractinfo_imageextractinfo_OutputFcn" contains the
 * normal interface for the "imageextractinfo/imageextractinfo_OutputFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 71-84). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static mxArray * mlfImageextractinfo_imageextractinfo_OutputFcn(mlfVarargoutList * varargout,
                                                                mxArray * hObject,
                                                                mxArray * eventdata,
                                                                mxArray * handles) {
    int nargout = 0;
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout)
      = Mimageextractinfo_imageextractinfo_OutputFcn(
          nargout, hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlxImageextractinfo_imageextractinfo_OutputFcn" contains the
 * feval interface for the "imageextractinfo/imageextractinfo_OutputFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 71-84). The feval function
 * calls the implementation version of
 * imageextractinfo/imageextractinfo_OutputFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageextractinfo_imageextractinfo_OutputFcn(int nlhs,
                                                           mxArray * plhs[],
                                                           int nrhs,
                                                           mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/imageextracti"
            "nfo_OutputFcn Line: 71 Column: 1 The function \"imag"
            "eextractinfo/imageextractinfo_OutputFcn\" was called"
            " with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0]
      = Mimageextractinfo_imageextractinfo_OutputFcn(
          nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageextractinfo_pushbuttonSimilarity_Ok_Callback" contains
 * the normal interface for the
 * "imageextractinfo/pushbuttonSimilarity_Ok_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 84-93). This function processes any input
 * arguments and passes them to the implementation version of the function,
 * appearing above.
 */
static void mlfImageextractinfo_pushbuttonSimilarity_Ok_Callback(mxArray * hObject,
                                                                 mxArray * eventdata,
                                                                 mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageextractinfo_pushbuttonSimilarity_Ok_Callback(
      hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageextractinfo_pushbuttonSimilarity_Ok_Callback" contains
 * the feval interface for the
 * "imageextractinfo/pushbuttonSimilarity_Ok_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 84-93). The feval function calls the
 * implementation version of imageextractinfo/pushbuttonSimilarity_Ok_Callback
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
static void mlxImageextractinfo_pushbuttonSimilarity_Ok_Callback(int nlhs,
                                                                 mxArray * plhs[],
                                                                 int nrhs,
                                                                 mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/pushbuttonSimilar"
            "ity_Ok_Callback Line: 84 Column: 1 The function \"imagee"
            "xtractinfo/pushbuttonSimilarity_Ok_Callback\" was called"
            " with more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/pushbuttonSimila"
            "rity_Ok_Callback Line: 84 Column: 1 The function \"imag"
            "eextractinfo/pushbuttonSimilarity_Ok_Callback\" was cal"
            "led with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageextractinfo_pushbuttonSimilarity_Ok_Callback(
      mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageextractinfo_editSimilarity_CreateFcn" contains the
 * normal interface for the "imageextractinfo/editSimilarity_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 93-108). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfImageextractinfo_editSimilarity_CreateFcn(mxArray * hObject,
                                                         mxArray * eventdata,
                                                         mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageextractinfo_editSimilarity_CreateFcn(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageextractinfo_editSimilarity_CreateFcn" contains the
 * feval interface for the "imageextractinfo/editSimilarity_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 93-108). The feval
 * function calls the implementation version of
 * imageextractinfo/editSimilarity_CreateFcn through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageextractinfo_editSimilarity_CreateFcn(int nlhs,
                                                         mxArray * plhs[],
                                                         int nrhs,
                                                         mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/editSimilarit"
            "y_CreateFcn Line: 93 Column: 1 The function \"imagee"
            "xtractinfo/editSimilarity_CreateFcn\" was called wit"
            "h more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/editSimilari"
            "ty_CreateFcn Line: 93 Column: 1 The function \"imag"
            "eextractinfo/editSimilarity_CreateFcn\" was called "
            "with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageextractinfo_editSimilarity_CreateFcn(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "mlfImageextractinfo_editSimilarity_Callback" contains the
 * normal interface for the "imageextractinfo/editSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 108-117). This function
 * processes any input arguments and passes them to the implementation version
 * of the function, appearing above.
 */
static void mlfImageextractinfo_editSimilarity_Callback(mxArray * hObject,
                                                        mxArray * eventdata,
                                                        mxArray * handles) {
    mlfEnterNewContext(0, 3, hObject, eventdata, handles);
    Mimageextractinfo_editSimilarity_Callback(hObject, eventdata, handles);
    mlfRestorePreviousContext(0, 3, hObject, eventdata, handles);
}

/*
 * The function "mlxImageextractinfo_editSimilarity_Callback" contains the
 * feval interface for the "imageextractinfo/editSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 108-117). The feval
 * function calls the implementation version of
 * imageextractinfo/editSimilarity_Callback through this function. This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static void mlxImageextractinfo_editSimilarity_Callback(int nlhs,
                                                        mxArray * plhs[],
                                                        int nrhs,
                                                        mxArray * prhs[]) {
    mxArray * mprhs[3];
    int i;
    if (nlhs > 0) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/editSimilari"
            "ty_Callback Line: 108 Column: 1 The function \"imag"
            "eextractinfo/editSimilarity_Callback\" was called w"
            "ith more than the declared number of outputs (0)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imageextractinfo/editSimilari"
            "ty_Callback Line: 108 Column: 1 The function \"imag"
            "eextractinfo/editSimilarity_Callback\" was called w"
            "ith more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    Mimageextractinfo_editSimilarity_Callback(mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
}

/*
 * The function "Mimageextractinfo" is the implementation version of the
 * "imageextractinfo" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 1-48). It contains the actual compiled code for
 * that M-function. It is a static function and must only be called from one of
 * the interface functions, appearing below.
 */
/*
 * function varargout = imageextractinfo(varargin)
 */
static mxArray * Mimageextractinfo(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * _T0_ = NULL;
    mxArray * gui_State = NULL;
    mxArray * gui_Singleton = NULL;
    mclCopyArray(&varargin);
    /*
     * % IMAGEEXTRACTINFO M-file for imageextractinfo.fig
     * %      IMAGEEXTRACTINFO, by itself, creates a new IMAGEEXTRACTINFO or raises the existing
     * %      singleton*.
     * %
     * %      H = IMAGEEXTRACTINFO returns the handle to a new IMAGEEXTRACTINFO or the handle to
     * %      the existing singleton*.
     * %
     * %      IMAGEEXTRACTINFO('CALLBACK',hObject,eventData,handles,...) calls the local
     * %      function named CALLBACK in IMAGEEXTRACTINFO.M with the given input arguments.
     * %
     * %      IMAGEEXTRACTINFO('Property','Value',...) creates a new IMAGEEXTRACTINFO or raises the
     * %      existing singleton*.  Starting from the left, property value pairs are
     * %      applied to the GUI before imageextractinfo_OpeningFunction gets called.  An
     * %      unrecognized property name or invalid value makes property application
     * %      stop.  All inputs are passed to imageextractinfo_OpeningFcn via varargin.
     * %
     * %      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
     * %      instance to run (singleton)".
     * %
     * % See also: GUIDE, GUIDATA, GUIHANDLES
     * 
     * % Edit the above text to modify the response to help imageextractinfo
     * 
     * % Last Modified by GUIDE v2.5 08-Mar-2004 02:00:11
     * 
     * % Begin initialization code - DO NOT EDIT
     * gui_Singleton = 1;
     */
    mlfAssign(&gui_Singleton, _mxarray0_);
    /*
     * gui_State = struct('gui_Name',       mfilename, ...
     */
    mlfAssign(
      &gui_State,
      mlfStruct(
        _mxarray1_,
        mxCreateString("imageextractinfo"),
        _mxarray3_,
        mclVv(gui_Singleton, "gui_Singleton"),
        _mxarray5_,
        mclCreateSimpleFunctionHandle(
          mlxImageextractinfo_imageextractinfo_OpeningFcn,
          "imageextractinfo_OpeningFcn"),
        _mxarray7_,
        mclCreateSimpleFunctionHandle(
          mlxImageextractinfo_imageextractinfo_OutputFcn,
          "imageextractinfo_OutputFcn"),
        _mxarray9_,
        _mxarray11_,
        _mxarray12_,
        _mxarray11_,
        NULL));
    /*
     * 'gui_Singleton',  gui_Singleton, ...
     * 'gui_OpeningFcn', @imageextractinfo_OpeningFcn, ...
     * 'gui_OutputFcn',  @imageextractinfo_OutputFcn, ...
     * 'gui_LayoutFcn',  [] , ...
     * 'gui_Callback',   []);
     * if nargin & isstr(varargin{1})
     */
    {
        mxArray * a_ = mclInitialize(mlfScalar(nargin_));
        if (mlfTobool(a_)
            && mlfTobool(
                 mclAnd(
                   a_,
                   mclFeval(
                     mclValueVarargout(),
                     mlxIsstr,
                     mlfIndexRef(
                       mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * gui_State.gui_Callback = str2func(varargin{1});
             */
            mlfIndexAssign(
              &gui_State,
              ".gui_Callback",
              mclFeval(
                mclValueVarargout(),
                mlxStr2func,
                mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_),
                NULL));
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if nargout
     */
    if (nargout_ != 0) {
        mlfAssign(&_T0_, mlfColon(_mxarray0_, mlfScalar(nargout_), NULL));
        /*
         * [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
         */
        mlfNGui_mainfcn(
          0,
          mlfIndexVarargout(&varargout, "{?}", _T0_, NULL),
          mclVv(gui_State, "gui_State"),
          mlfIndexRef(
            mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
          NULL);
    /*
     * else
     */
    } else {
        /*
         * gui_mainfcn(gui_State, varargin{:});
         */
        mclAssignAns(
          &ans,
          mlfNGui_mainfcn(
            0,
            mclAnsVarargout(),
            mclVv(gui_State, "gui_State"),
            mlfIndexRef(
              mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(gui_Singleton);
    mxDestroyArray(gui_State);
    mxDestroyArray(_T0_);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * % End initialization code - DO NOT EDIT
     * 
     * 
     * % --- Executes just before imageextractinfo is made visible.
     */
}

/*
 * The function "Mimageextractinfo_imageextractinfo_OpeningFcn" is the
 * implementation version of the "imageextractinfo/imageextractinfo_OpeningFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 48-71). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function imageextractinfo_OpeningFcn(hObject, eventdata, handles, varargin)
 */
static void Mimageextractinfo_imageextractinfo_OpeningFcn(mxArray * hObject,
                                                          mxArray * eventdata,
                                                          mxArray * handles,
                                                          mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mclCopyArray(&varargin);
    /*
     * % This function has no output args, see OutputFcn.
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * % varargin   command line arguments to imageextractinfo (see VARARGIN)
     * 
     * % Choose default command line output for imageextractinfo
     * handles.output = hObject;
     */
    mlfIndexAssign(&handles, ".output", mclVa(hObject, "hObject"));
    /*
     * 
     * %h_image=imfinfo('mark.bmp','bmp');
     * %set(handles.editFilename,'String',h_image.Filename);
     * 
     * % Update handles structure
     * 
     * guidata(hObject, handles);
     */
    mclAssignAns(
      &ans,
      mlfNGuidata(0, mclVa(hObject, "hObject"), mclVa(handles, "handles")));
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * %psnr_mse(hObject,eventdata,handles);
     * 
     * % UIWAIT makes imageextractinfo wait for user response (see UIRESUME)
     * % uiwait(handles.figure2);
     * 
     * 
     * % --- Outputs from this function are returned to the command line.
     */
}

/*
 * The function "Mimageextractinfo_imageextractinfo_OutputFcn" is the
 * implementation version of the "imageextractinfo/imageextractinfo_OutputFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 71-84). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function varargout = imageextractinfo_OutputFcn(hObject, eventdata, handles)
 */
static mxArray * Mimageextractinfo_imageextractinfo_OutputFcn(int nargout_,
                                                              mxArray * hObject,
                                                              mxArray * eventdata,
                                                              mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    mxArray * varargout = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % varargout  cell array for returning output args (see VARARGOUT);
     * % hObject    handle to figure
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Get default command line output from handles structure
     * varargout{1} = handles.output;
     */
    mlfIndexAssign(
      &varargout,
      "{?}",
      _mxarray0_,
      mlfIndexRef(mclVa(handles, "handles"), ".output"));
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * 
     * 
     * 
     * % --- Executes on button press in pushbuttonSimilarity_Ok.
     */
}

/*
 * The function "Mimageextractinfo_pushbuttonSimilarity_Ok_Callback" is the
 * implementation version of the
 * "imageextractinfo/pushbuttonSimilarity_Ok_Callback" M-function from file
 * "k:\distribute\versionstandalone\��ѧ�ҡ compile ���ѧ�����ź��� cpp
 * h\imageextractinfo.m" (lines 84-93). It contains the actual compiled code
 * for that M-function. It is a static function and must only be called from
 * one of the interface functions, appearing below.
 */
/*
 * function pushbuttonSimilarity_Ok_Callback(hObject, eventdata, handles)
 */
static void Mimageextractinfo_pushbuttonSimilarity_Ok_Callback(mxArray * hObject,
                                                               mxArray * eventdata,
                                                               mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to pushbuttonSimilarity_Ok (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * delete(gcf);
     */
    mlfDelete(mlfGcf(), NULL);
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     * % --- Executes during object creation, after setting all properties.
     */
}

/*
 * The function "Mimageextractinfo_editSimilarity_CreateFcn" is the
 * implementation version of the "imageextractinfo/editSimilarity_CreateFcn"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 93-108). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function editSimilarity_CreateFcn(hObject, eventdata, handles)
 */
static void Mimageextractinfo_editSimilarity_CreateFcn(mxArray * hObject,
                                                       mxArray * eventdata,
                                                       mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    mxArray * ans = NULL;
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    /*
     * % hObject    handle to editSimilarity (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    empty - handles not created until after all CreateFcns called
     * 
     * % Hint: edit controls usually have a white background on Windows.
     * %       See ISPC and COMPUTER.
     * if ispc
     */
    if (mlfTobool(mlfIspc())) {
        /*
         * set(hObject,'BackgroundColor','white');
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0, mclVa(hObject, "hObject"), _mxarray14_, _mxarray16_, NULL));
    /*
     * else
     */
    } else {
        /*
         * set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
         */
        mclAssignAns(
          &ans,
          mlfNSet(
            0,
            mclVa(hObject, "hObject"),
            _mxarray14_,
            mlfNGet(1, _mxarray18_, _mxarray19_, NULL),
            NULL));
    /*
     * end
     */
    }
    mxDestroyArray(ans);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * 
     * 
     * 
     */
}

/*
 * The function "Mimageextractinfo_editSimilarity_Callback" is the
 * implementation version of the "imageextractinfo/editSimilarity_Callback"
 * M-function from file "k:\distribute\versionstandalone\��ѧ�ҡ compile
 * ��ѧ�����ź��� cpp h\imageextractinfo.m" (lines 108-117). It contains the
 * actual compiled code for that M-function. It is a static function and must
 * only be called from one of the interface functions, appearing below.
 */
/*
 * function editSimilarity_Callback(hObject, eventdata, handles)
 */
static void Mimageextractinfo_editSimilarity_Callback(mxArray * hObject,
                                                      mxArray * eventdata,
                                                      mxArray * handles) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(
          &_local_function_table_imageextractinfo);
    mclCopyArray(&hObject);
    mclCopyArray(&eventdata);
    mclCopyArray(&handles);
    mxDestroyArray(handles);
    mxDestroyArray(eventdata);
    mxDestroyArray(hObject);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    /*
     * % hObject    handle to editSimilarity (see GCBO)
     * % eventdata  reserved - to be defined in a future version of MATLAB
     * % handles    structure with handles and user data (see GUIDATA)
     * 
     * % Hints: get(hObject,'String') returns contents of editSimilarity as text
     * %        str2double(get(hObject,'String')) returns contents of editSimilarity as a double
     * 
     * 
     */
}
