/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "fspecial.h"
#include "images_private_checkinput.h"
#include "images_private_checknargin.h"
#include "images_private_checkstrs.h"
#include "libmatlbm.h"
#include "libmmfile.h"

static mxChar _array1_[7] = { 'a', 'v', 'e', 'r', 'a', 'g', 'e' };
static mxArray * _mxarray0_;

static mxChar _array3_[4] = { 'd', 'i', 's', 'k' };
static mxArray * _mxarray2_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;
static mxArray * _mxarray8_;
static mxArray * _mxarray9_;
static mxArray * _mxarray10_;

static mxChar _array12_[8] = { 'g', 'a', 'u', 's', 's', 'i', 'a', 'n' };
static mxArray * _mxarray11_;
static mxArray * _mxarray13_;

static mxChar _array15_[9] = { 'l', 'a', 'p', 'l', 'a', 'c', 'i', 'a', 'n' };
static mxArray * _mxarray14_;
static mxArray * _mxarray16_;

static mxChar _array18_[3] = { 'l', 'o', 'g' };
static mxArray * _mxarray17_;

static mxChar _array20_[6] = { 'm', 'o', 't', 'i', 'o', 'n' };
static mxArray * _mxarray19_;
static mxArray * _mxarray21_;

static mxChar _array23_[7] = { 'p', 'r', 'e', 'w', 'i', 't', 't' };
static mxArray * _mxarray22_;

static double _array25_[9] = { 1.0, 0.0, -1.0, 1.0, 0.0, -1.0, 1.0, 0.0, -1.0 };
static mxArray * _mxarray24_;

static mxChar _array27_[5] = { 's', 'o', 'b', 'e', 'l' };
static mxArray * _mxarray26_;

static double _array29_[9] = { 1.0, 0.0, -1.0, 2.0, 0.0, -2.0, 1.0, 0.0, -1.0 };
static mxArray * _mxarray28_;

static mxChar _array31_[7] = { 'u', 'n', 's', 'h', 'a', 'r', 'p' };
static mxArray * _mxarray30_;

static double _array33_[9] = { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0 };
static mxArray * _mxarray32_;
static mxArray * _mxarray34_;
static mxArray * _mxarray35_;
static mxArray * _mxarray36_;

static mxArray * _array38_[9] = { NULL /*_mxarray11_*/, NULL /*_mxarray26_*/,
                                  NULL /*_mxarray22_*/, NULL /*_mxarray14_*/,
                                  NULL /*_mxarray17_*/, NULL /*_mxarray0_*/,
                                  NULL /*_mxarray30_*/, NULL /*_mxarray2_*/,
                                  NULL /*_mxarray19_*/ };
static mxArray * _mxarray37_;

static mxChar _array40_[4] = { 'T', 'Y', 'P', 'E' };
static mxArray * _mxarray39_;

static double _array42_[2] = { 3.0, 3.0 };
static mxArray * _mxarray41_;
static mxArray * _mxarray43_;

static mxArray * _array45_[2] = { NULL /*_mxarray14_*/, NULL /*_mxarray30_*/ };
static mxArray * _mxarray44_;
static mxArray * _mxarray46_;

static double _array48_[2] = { 5.0, 5.0 };
static mxArray * _mxarray47_;
static mxArray * _mxarray49_;

static mxArray * _array51_[2] = { NULL /*_mxarray26_*/, NULL /*_mxarray22_*/ };
static mxArray * _mxarray50_;

static mxChar _array53_[47] = { '%', 's', ':', ' ', 'T', 'o', 'o', ' ',
                                'm', 'a', 'n', 'y', ' ', 'a', 'r', 'g',
                                'u', 'm', 'e', 'n', 't', 's', ' ', 'f',
                                'o', 'r', ' ', 't', 'h', 'i', 's', ' ',
                                't', 'y', 'p', 'e', ' ', 'o', 'f', ' ',
                                'f', 'i', 'l', 't', 'e', 'r', '.' };
static mxArray * _mxarray52_;

static mxChar _array55_[34] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 't', 'o', 'o', 'M', 'a', 'n', 'y', 'A',
                                'r', 'g', 's', 'F', 'o', 'r', 'T', 'h', 'i',
                                's', 'F', 'i', 'l', 't', 'e', 'r' };
static mxArray * _mxarray54_;

static mxChar _array58_[6] = { 'd', 'o', 'u', 'b', 'l', 'e' };
static mxArray * _mxarray57_;
static mxArray * _mxarray56_;

static mxChar _array62_[11] = { 'n', 'o', 'n', 'n', 'e', 'g',
                                'a', 't', 'i', 'v', 'e' };
static mxArray * _mxarray61_;

static mxChar _array64_[4] = { 'r', 'e', 'a', 'l' };
static mxArray * _mxarray63_;

static mxChar _array66_[8] = { 'n', 'o', 'n', 'e', 'm', 'p', 't', 'y' };
static mxArray * _mxarray65_;

static mxChar _array68_[6] = { 'f', 'i', 'n', 'i', 't', 'e' };
static mxArray * _mxarray67_;

static mxChar _array70_[6] = { 's', 'c', 'a', 'l', 'a', 'r' };
static mxArray * _mxarray69_;

static mxArray * _array60_[5] = { NULL /*_mxarray61_*/, NULL /*_mxarray63_*/,
                                  NULL /*_mxarray65_*/, NULL /*_mxarray67_*/,
                                  NULL /*_mxarray69_*/ };
static mxArray * _mxarray59_;

static mxChar _array72_[5] = { 'A', 'L', 'P', 'H', 'A' };
static mxArray * _mxarray71_;

static mxChar _array74_[60] = { '%', 's', ':', ' ', 'A', 'L', 'P', 'H', 'A',
                                ' ', 's', 'h', 'o', 'u', 'l', 'd', ' ', 'b',
                                'e', ' ', 'l', 'e', 's', 's', ' ', 't', 'h',
                                'a', 'n', ' ', 'o', 'r', ' ', 'e', 'q', 'u',
                                'a', 'l', ' ', '1', ' ', 'a', 'n', 'd', ' ',
                                'g', 'r', 'e', 'a', 't', 'e', 'r', ' ', 't',
                                'h', 'a', 'n', ' ', '0', '.' };
static mxArray * _mxarray73_;

static mxChar _array76_[25] = { 'I', 'm', 'a', 'g', 'e', 's', ':', '%', 's',
                                ':', 'o', 'u', 't', 'O', 'f', 'R', 'a', 'n',
                                'g', 'e', 'A', 'l', 'p', 'h', 'a' };
static mxArray * _mxarray75_;

static mxArray * _array78_[2] = { NULL /*_mxarray2_*/, NULL /*_mxarray19_*/ };
static mxArray * _mxarray77_;

static mxChar _array82_[8] = { 'p', 'o', 's', 'i', 't', 'i', 'v', 'e' };
static mxArray * _mxarray81_;

static mxArray * _array80_[5] = { NULL /*_mxarray81_*/, NULL /*_mxarray67_*/,
                                  NULL /*_mxarray63_*/, NULL /*_mxarray65_*/,
                                  NULL /*_mxarray69_*/ };
static mxArray * _mxarray79_;

static mxChar _array84_[13] = { 'R', 'A', 'D', 'I', 'U', 'S', ' ',
                                'o', 'r', ' ', 'L', 'E', 'N' };
static mxArray * _mxarray83_;

static mxArray * _array86_[3] = { NULL /*_mxarray11_*/, NULL /*_mxarray17_*/,
                                  NULL /*_mxarray0_*/ };
static mxArray * _mxarray85_;

static mxChar _array90_[7] = { 'i', 'n', 't', 'e', 'g', 'e', 'r' };
static mxArray * _mxarray89_;

static mxArray * _array88_[5] = { NULL /*_mxarray81_*/, NULL /*_mxarray67_*/,
                                  NULL /*_mxarray63_*/, NULL /*_mxarray65_*/,
                                  NULL /*_mxarray89_*/ };
static mxArray * _mxarray87_;

static mxChar _array92_[5] = { 'H', 'S', 'I', 'Z', 'E' };
static mxArray * _mxarray91_;

static mxChar _array94_[34] = { 'H', 'S', 'I', 'Z', 'E', ' ', 's', 'h', 'o',
                                'u', 'l', 'd', ' ', 'h', 'a', 'v', 'e', ' ',
                                '1', ' ', 'o', 'r', ' ', '2', ' ', 'e', 'l',
                                'e', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray93_;

static mxChar _array96_[20] = { 'I', 'm', 'a', 'g', 'e', 's', ':',
                                '%', 's', ':', 'w', 'r', 'o', 'n',
                                'g', 'S', 'i', 'z', 'e', 'N' };
static mxArray * _mxarray95_;

static mxChar _array98_[3] = { 'L', 'E', 'N' };
static mxArray * _mxarray97_;

static mxArray * _array100_[4] = { NULL /*_mxarray63_*/, NULL /*_mxarray65_*/,
                                   NULL /*_mxarray67_*/, NULL /*_mxarray69_*/ };
static mxArray * _mxarray99_;

static mxChar _array102_[5] = { 'T', 'H', 'E', 'T', 'A' };
static mxArray * _mxarray101_;

static mxArray * _array104_[2] = { NULL /*_mxarray11_*/, NULL /*_mxarray17_*/ };
static mxArray * _mxarray103_;

static mxChar _array106_[1] = { 'N' };
static mxArray * _mxarray105_;

static mxChar _array108_[5] = { 'S', 'I', 'G', 'M', 'A' };
static mxArray * _mxarray107_;

static mxChar _array110_[43] = { '%', 's', ':', ' ', 's', 'i', 'z', 'e', '(',
                                 'N', ')', ' ', 's', 'h', 'o', 'u', 'l', 'd',
                                 ' ', 'b', 'e', ' ', 'l', 'e', 's', 's', ' ',
                                 't', 'h', 'a', 'n', ' ', 'o', 'r', ' ', 'e',
                                 'q', 'u', 'a', 'l', ' ', '2', '.' };
static mxArray * _mxarray109_;

void InitializeModule_fspecial(void) {
    _mxarray0_ = mclInitializeString(7, _array1_);
    _mxarray2_ = mclInitializeString(4, _array3_);
    _mxarray4_ = mclInitializeDouble(.5);
    _mxarray5_ = mclInitializeDouble(2.0);
    _mxarray6_ = mclInitializeDouble(.25);
    _mxarray7_ = mclInitializeDouble(0.0);
    _mxarray8_ = mclInitializeDouble(3.141592653589793);
    _mxarray9_ = mclInitializeDouble(1.5707963267948966);
    _mxarray10_ = mclInitializeDouble(1.0);
    _mxarray11_ = mclInitializeString(8, _array12_);
    _mxarray13_ = mclInitializeDouble(2.220446049250313e-16);
    _mxarray14_ = mclInitializeString(9, _array15_);
    _mxarray16_ = mclInitializeDouble(-4.0);
    _mxarray17_ = mclInitializeString(3, _array18_);
    _mxarray19_ = mclInitializeString(6, _array20_);
    _mxarray21_ = mclInitializeDouble(180.0);
    _mxarray22_ = mclInitializeString(7, _array23_);
    _mxarray24_ = mclInitializeDoubleVector(3, 3, _array25_);
    _mxarray26_ = mclInitializeString(5, _array27_);
    _mxarray28_ = mclInitializeDoubleVector(3, 3, _array29_);
    _mxarray30_ = mclInitializeString(7, _array31_);
    _mxarray32_ = mclInitializeDoubleVector(3, 3, _array33_);
    _mxarray34_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray35_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray36_ = mclInitializeDouble(3.0);
    _array38_[0] = _mxarray11_;
    _array38_[1] = _mxarray26_;
    _array38_[2] = _mxarray22_;
    _array38_[3] = _mxarray14_;
    _array38_[4] = _mxarray17_;
    _array38_[5] = _mxarray0_;
    _array38_[6] = _mxarray30_;
    _array38_[7] = _mxarray2_;
    _array38_[8] = _mxarray19_;
    _mxarray37_ = mclInitializeCellVector(1, 9, _array38_);
    _mxarray39_ = mclInitializeString(4, _array40_);
    _mxarray41_ = mclInitializeDoubleVector(1, 2, _array42_);
    _mxarray43_ = mclInitializeDouble(5.0);
    _array45_[0] = _mxarray14_;
    _array45_[1] = _mxarray30_;
    _mxarray44_ = mclInitializeCellVector(1, 2, _array45_);
    _mxarray46_ = mclInitializeDouble(.2);
    _mxarray47_ = mclInitializeDoubleVector(1, 2, _array48_);
    _mxarray49_ = mclInitializeDouble(9.0);
    _array51_[0] = _mxarray26_;
    _array51_[1] = _mxarray22_;
    _mxarray50_ = mclInitializeCellVector(1, 2, _array51_);
    _mxarray52_ = mclInitializeString(47, _array53_);
    _mxarray54_ = mclInitializeString(34, _array55_);
    _mxarray57_ = mclInitializeString(6, _array58_);
    _mxarray56_ = mclInitializeCell(_mxarray57_);
    _mxarray61_ = mclInitializeString(11, _array62_);
    _array60_[0] = _mxarray61_;
    _mxarray63_ = mclInitializeString(4, _array64_);
    _array60_[1] = _mxarray63_;
    _mxarray65_ = mclInitializeString(8, _array66_);
    _array60_[2] = _mxarray65_;
    _mxarray67_ = mclInitializeString(6, _array68_);
    _array60_[3] = _mxarray67_;
    _mxarray69_ = mclInitializeString(6, _array70_);
    _array60_[4] = _mxarray69_;
    _mxarray59_ = mclInitializeCellVector(1, 5, _array60_);
    _mxarray71_ = mclInitializeString(5, _array72_);
    _mxarray73_ = mclInitializeString(60, _array74_);
    _mxarray75_ = mclInitializeString(25, _array76_);
    _array78_[0] = _mxarray2_;
    _array78_[1] = _mxarray19_;
    _mxarray77_ = mclInitializeCellVector(1, 2, _array78_);
    _mxarray81_ = mclInitializeString(8, _array82_);
    _array80_[0] = _mxarray81_;
    _array80_[1] = _mxarray67_;
    _array80_[2] = _mxarray63_;
    _array80_[3] = _mxarray65_;
    _array80_[4] = _mxarray69_;
    _mxarray79_ = mclInitializeCellVector(1, 5, _array80_);
    _mxarray83_ = mclInitializeString(13, _array84_);
    _array86_[0] = _mxarray11_;
    _array86_[1] = _mxarray17_;
    _array86_[2] = _mxarray0_;
    _mxarray85_ = mclInitializeCellVector(1, 3, _array86_);
    _array88_[0] = _mxarray81_;
    _array88_[1] = _mxarray67_;
    _array88_[2] = _mxarray63_;
    _array88_[3] = _mxarray65_;
    _mxarray89_ = mclInitializeString(7, _array90_);
    _array88_[4] = _mxarray89_;
    _mxarray87_ = mclInitializeCellVector(1, 5, _array88_);
    _mxarray91_ = mclInitializeString(5, _array92_);
    _mxarray93_ = mclInitializeString(34, _array94_);
    _mxarray95_ = mclInitializeString(20, _array96_);
    _mxarray97_ = mclInitializeString(3, _array98_);
    _array100_[0] = _mxarray63_;
    _array100_[1] = _mxarray65_;
    _array100_[2] = _mxarray67_;
    _array100_[3] = _mxarray69_;
    _mxarray99_ = mclInitializeCellVector(1, 4, _array100_);
    _mxarray101_ = mclInitializeString(5, _array102_);
    _array104_[0] = _mxarray11_;
    _array104_[1] = _mxarray17_;
    _mxarray103_ = mclInitializeCellVector(1, 2, _array104_);
    _mxarray105_ = mclInitializeString(1, _array106_);
    _mxarray107_ = mclInitializeString(5, _array108_);
    _mxarray109_ = mclInitializeString(43, _array110_);
}

void TerminateModule_fspecial(void) {
    mxDestroyArray(_mxarray109_);
    mxDestroyArray(_mxarray107_);
    mxDestroyArray(_mxarray105_);
    mxDestroyArray(_mxarray103_);
    mxDestroyArray(_mxarray101_);
    mxDestroyArray(_mxarray99_);
    mxDestroyArray(_mxarray97_);
    mxDestroyArray(_mxarray95_);
    mxDestroyArray(_mxarray93_);
    mxDestroyArray(_mxarray91_);
    mxDestroyArray(_mxarray87_);
    mxDestroyArray(_mxarray89_);
    mxDestroyArray(_mxarray85_);
    mxDestroyArray(_mxarray83_);
    mxDestroyArray(_mxarray79_);
    mxDestroyArray(_mxarray81_);
    mxDestroyArray(_mxarray77_);
    mxDestroyArray(_mxarray75_);
    mxDestroyArray(_mxarray73_);
    mxDestroyArray(_mxarray71_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray69_);
    mxDestroyArray(_mxarray67_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray56_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray54_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray49_);
    mxDestroyArray(_mxarray47_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray43_);
    mxDestroyArray(_mxarray41_);
    mxDestroyArray(_mxarray39_);
    mxDestroyArray(_mxarray37_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray35_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray21_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray14_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfFspecial_ParseInputs(mxArray * * p2, mxArray * * p3, ...);
static void mlxFspecial_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * Mfspecial(int nargout_, mxArray * varargin);
static mxArray * Mfspecial_ParseInputs(mxArray * * p2,
                                       mxArray * * p3,
                                       int nargout_,
                                       mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "ParseInputs", mlxFspecial_ParseInputs, -1, 3, NULL } };

_mexLocalFunctionTable _local_function_table_fspecial
  = { 1, local_function_table_ };

/*
 * The function "mlfFspecial" contains the normal interface for the "fspecial"
 * M-function from file "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines
 * 1-235). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfFspecial(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * h = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    h = Mfspecial(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(h);
}

/*
 * The function "mlxFspecial" contains the feval interface for the "fspecial"
 * M-function from file "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines
 * 1-235). The feval function calls the implementation version of fspecial
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxFspecial(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: fspecial Line: 1 Column:"
            " 1 The function \"fspecial\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mfspecial(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfFspecial_ParseInputs" contains the normal interface for the
 * "fspecial/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines 235-354). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfFspecial_ParseInputs(mxArray * * p2, mxArray * * p3, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * type = NULL;
    mxArray * p2__ = NULL;
    mxArray * p3__ = NULL;
    mlfVarargin(&varargin, p3, 0);
    mlfEnterNewContext(2, -1, p2, p3, varargin);
    if (p2 != NULL) {
        ++nargout;
    }
    if (p3 != NULL) {
        ++nargout;
    }
    type = Mfspecial_ParseInputs(&p2__, &p3__, nargout, varargin);
    mlfRestorePreviousContext(2, 0, p2, p3);
    mxDestroyArray(varargin);
    if (p2 != NULL) {
        mclCopyOutputArg(p2, p2__);
    } else {
        mxDestroyArray(p2__);
    }
    if (p3 != NULL) {
        mclCopyOutputArg(p3, p3__);
    } else {
        mxDestroyArray(p3__);
    }
    return mlfReturnValue(type);
}

/*
 * The function "mlxFspecial_ParseInputs" contains the feval interface for the
 * "fspecial/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines 235-354). The feval
 * function calls the implementation version of fspecial/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxFspecial_ParseInputs(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: fspecial/ParseInputs Line: 235 Co"
            "lumn: 1 The function \"fspecial/ParseInputs\" was calle"
            "d with more than the declared number of outputs (3)."),
          NULL);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mfspecial_ParseInputs(&mplhs[1], &mplhs[2], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mfspecial" is the implementation version of the "fspecial"
 * M-function from file "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines
 * 1-235). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function h = fspecial(varargin)
 */
static mxArray * Mfspecial(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_fspecial);
    mxArray * h = NULL;
    mxArray * x2lastpix = NULL;
    mxArray * lastpix = NULL;
    mxArray * dist2line = NULL;
    mxArray * sy = NULL;
    mxArray * sx = NULL;
    mxArray * linewdt = NULL;
    mxArray * xsign = NULL;
    mxArray * sinphi = NULL;
    mxArray * cosphi = NULL;
    mxArray * phi = NULL;
    mxArray * half = NULL;
    mxArray * len = NULL;
    mxArray * std2 = NULL;
    mxArray * h2 = NULL;
    mxArray * h1 = NULL;
    mxArray * alpha = NULL;
    mxArray * sumh = NULL;
    mxArray * arg = NULL;
    mxArray * std = NULL;
    mxArray * sg0 = NULL;
    mxArray * m1n = NULL;
    mxArray * sgrid = NULL;
    mxArray * m2 = NULL;
    mxArray * m1 = NULL;
    mxArray * minxy = NULL;
    mxArray * maxxy = NULL;
    mxArray * y = NULL;
    mxArray * x = NULL;
    mxArray * crad = NULL;
    mxArray * rad = NULL;
    mxArray * siz = NULL;
    mxArray * p3 = NULL;
    mxArray * p2 = NULL;
    mxArray * type = NULL;
    mclCopyArray(&varargin);
    /*
     * %FSPECIAL Create 2-D special filters.
     * %   H = FSPECIAL(TYPE) creates a two-dimensional filter H of the
     * %   specified type. Possible values for TYPE are:
     * %
     * %     'average'   averaging filter
     * %     'disk'      circular averaging filter
     * %     'gaussian'  Gaussian lowpass filter
     * %     'laplacian' filter approximating the 2-D Laplacian operator
     * %     'log'       Laplacian of Gaussian filter
     * %     'motion'    motion filter
     * %     'prewitt'   Prewitt horizontal edge-emphasizing filter
     * %     'sobel'     Sobel horizontal edge-emphasizing filter
     * %     'unsharp'   unsharp contrast enhancement filter
     * %
     * %   Depending on TYPE, FSPECIAL may take additional parameters
     * %   which you can supply.  These parameters all have default
     * %   values. 
     * %
     * %   H = FSPECIAL('average',HSIZE) returns an averaging filter H of size
     * %   HSIZE. HSIZE can be a vector specifying the number of rows and columns in
     * %   H or a scalar, in which case H is a square matrix.
     * %   The default HSIZE is [3 3].
     * %
     * %   H = FSPECIAL('disk',RADIUS) returns a circular averaging filter
     * %   (pillbox) within the square matrix of side 2*RADIUS+1.
     * %   The default RADIUS is 5.
     * %
     * %   H = FSPECIAL('gaussian',HSIZE,SIGMA) returns a rotationally
     * %   symmetric Gaussian lowpass filter  of size HSIZE with standard
     * %   deviation SIGMA (positive). HSIZE can be a vector specifying the
     * %   number of rows and columns in H or a scalar, in which case H is a
     * %   square matrix.
     * %   The default HSIZE is [3 3], the default SIGMA is 0.5.
     * %
     * %   H = FSPECIAL('laplacian',ALPHA) returns a 3-by-3 filter
     * %   approximating the shape of the two-dimensional Laplacian
     * %   operator. The parameter ALPHA controls the shape of the
     * %   Laplacian and must be in the range 0.0 to 1.0.
     * %   The default ALPHA is 0.2.
     * %
     * %   H = FSPECIAL('log',HSIZE,SIGMA) returns a rotationally symmetric
     * %   Laplacian of Gaussian filter of size HSIZE with standard deviation
     * %   SIGMA (positive). HSIZE can be a vector specifying the number of rows
     * %   and columns in H or a scalar, in which case H is a square matrix.
     * %   The default HSIZE is [5 5], the default SIGMA is 0.5.
     * %
     * %   H = FSPECIAL('motion',LEN,THETA) returns a filter to approximate, once
     * %   convolved with an image, the linear motion of a camera by LEN pixels,
     * %   with an angle of THETA degrees in a counter-clockwise direction. The
     * %   filter becomes a vector for horizontal and vertical motions.  The
     * %   default LEN is 9, the default THETA is 0, which corresponds to a
     * %   horizontal motion of 9 pixels.
     * %
     * %   H = FSPECIAL('prewitt') returns 3-by-3 filter that emphasizes
     * %   horizontal edges by approximating a vertical gradient. If you need to
     * %   emphasize vertical edges, transpose the filter H: H'.
     * %
     * %       [1 1 1;0 0 0;-1 -1 -1].
     * %
     * %   H = FSPECIAL('sobel') returns 3-by-3 filter that emphasizes
     * %   horizontal edges utilizing the smoothing effect by approximating a
     * %   vertical gradient. If you need to emphasize vertical edges, transpose
     * %   the filter H: H'.
     * %
     * %       [1 2 1;0 0 0;-1 -2 -1].
     * %
     * %   H = FSPECIAL('unsharp',ALPHA) returns a 3-by-3 unsharp contrast
     * %   enhancement filter. FSPECIAL creates the unsharp filter from the
     * %   negative of the Laplacian filter with parameter ALPHA. ALPHA controls
     * %   the shape of the Laplacian and must be in the range 0.0 to 1.0.
     * %   The default ALPHA is 0.2.
     * %
     * %   Class Support
     * %   -------------
     * %   H is of class double.
     * %
     * %   Example
     * %   -------
     * %      I = imread('saturn.tif');
     * %      subplot(2,2,1);imshow(I);title('Original Image'); 
     * %      H = fspecial('motion',50,45);
     * %      MotionBlur = imfilter(I,H);
     * %      subplot(2,2,2);imshow(MotionBlur);title('Motion Blurred Image');
     * %      H = fspecial('disk',10);
     * %      blurred = imfilter(I,H);
     * %      subplot(2,2,3);imshow(blurred);title('Blurred Image');
     * %      H = fspecial('unsharp');
     * %      sharpened = imfilter(I,H);
     * %      subplot(2,2,4);imshow(sharpened);title('Sharpened Image');
     * %       
     * %   See also CONV2, EDGE, FILTER2, FSAMP2, FWIND1, FWIND2, IMFILTER.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.28 $  $Date: 2002/03/15 15:27:18 $
     * 
     * [type, p2, p3] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &type,
      mlfFspecial_ParseInputs(
        &p2,
        &p3,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * switch type
     */
    {
        mxArray * v_ = mclInitialize(mclVv(type, "type"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 'average' % Smoothing filter
             * siz = p2;
             */
            mlfAssign(&siz, mclVv(p2, "p2"));
            /*
             * h   = ones(siz)/prod(siz);
             */
            mlfAssign(
              &h,
              mclMrdivide(
                mlfOnes(mclVv(siz, "siz"), NULL),
                mlfProd(mclVv(siz, "siz"), NULL)));
        /*
         * 
         * case 'disk' % Disk filter
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * rad   = p2;
             */
            mlfAssign(&rad, mclVv(p2, "p2"));
            /*
             * crad  = ceil(rad-0.5);
             */
            mlfAssign(&crad, mlfCeil(mclMinus(mclVv(rad, "rad"), _mxarray4_)));
            /*
             * [x,y] = meshgrid(-crad:crad,-crad:crad);
             */
            mlfAssign(
              &x,
              mlfNMeshgrid(
                2,
                &y,
                NULL,
                mlfColon(
                  mclUminus(mclVv(crad, "crad")), mclVv(crad, "crad"), NULL),
                mlfColon(
                  mclUminus(mclVv(crad, "crad")), mclVv(crad, "crad"), NULL),
                NULL));
            /*
             * maxxy = max(abs(x),abs(y));
             */
            mlfAssign(
              &maxxy,
              mlfMax(NULL, mlfAbs(mclVv(x, "x")), mlfAbs(mclVv(y, "y")), NULL));
            /*
             * minxy = min(abs(x),abs(y));
             */
            mlfAssign(
              &minxy,
              mlfMin(NULL, mlfAbs(mclVv(x, "x")), mlfAbs(mclVv(y, "y")), NULL));
            /*
             * m1 = (rad^2 <  (maxxy+0.5).^2 + (minxy-0.5).^2).*(minxy-0.5) + ...
             */
            mlfAssign(
              &m1,
              mclPlus(
                mclTimes(
                  mclLt(
                    mclMpower(mclVv(rad, "rad"), _mxarray5_),
                    mclPlus(
                      mlfPower(
                        mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_), _mxarray5_),
                      mlfPower(
                        mclMinus(mclVv(minxy, "minxy"), _mxarray4_),
                        _mxarray5_))),
                  mclMinus(mclVv(minxy, "minxy"), _mxarray4_)),
                mclTimes(
                  mclGe(
                    mclMpower(mclVv(rad, "rad"), _mxarray5_),
                    mclPlus(
                      mlfPower(
                        mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_), _mxarray5_),
                      mlfPower(
                        mclMinus(mclVv(minxy, "minxy"), _mxarray4_),
                        _mxarray5_))),
                  mlfSqrt(
                    mclMinus(
                      mclMpower(mclVv(rad, "rad"), _mxarray5_),
                      mlfPower(
                        mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_),
                        _mxarray5_))))));
            /*
             * (rad^2 >= (maxxy+0.5).^2 + (minxy-0.5).^2).* ...
             * sqrt(rad^2 - (maxxy + 0.5).^2);
             * m2 = (rad^2 >  (maxxy-0.5).^2 + (minxy+0.5).^2).*(minxy+0.5) + ...
             */
            mlfAssign(
              &m2,
              mclPlus(
                mclTimes(
                  mclGt(
                    mclMpower(mclVv(rad, "rad"), _mxarray5_),
                    mclPlus(
                      mlfPower(
                        mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                        _mxarray5_),
                      mlfPower(
                        mclPlus(mclVv(minxy, "minxy"), _mxarray4_),
                        _mxarray5_))),
                  mclPlus(mclVv(minxy, "minxy"), _mxarray4_)),
                mclTimes(
                  mclLe(
                    mclMpower(mclVv(rad, "rad"), _mxarray5_),
                    mclPlus(
                      mlfPower(
                        mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                        _mxarray5_),
                      mlfPower(
                        mclPlus(mclVv(minxy, "minxy"), _mxarray4_),
                        _mxarray5_))),
                  mlfSqrt(
                    mclMinus(
                      mclMpower(mclVv(rad, "rad"), _mxarray5_),
                      mlfPower(
                        mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                        _mxarray5_))))));
            /*
             * (rad^2 <= (maxxy-0.5).^2 + (minxy+0.5).^2).* ...
             * sqrt(rad^2 - (maxxy - 0.5).^2);
             * sgrid = (rad^2*(0.5*(asin(m2/rad) - asin(m1/rad)) + ...
             */
            mlfAssign(
              &sgrid,
              mclTimes(
                mclPlus(
                  mclMinus(
                    mclMtimes(
                      mclMpower(mclVv(rad, "rad"), _mxarray5_),
                      mclPlus(
                        mclMtimes(
                          _mxarray4_,
                          mclMinus(
                            mlfAsin(
                              mclMrdivide(mclVv(m2, "m2"), mclVv(rad, "rad"))),
                            mlfAsin(
                              mclMrdivide(
                                mclVv(m1, "m1"), mclVv(rad, "rad"))))),
                        mclMtimes(
                          _mxarray6_,
                          mclMinus(
                            mlfSin(
                              mclMtimes(
                                _mxarray5_,
                                mlfAsin(
                                  mclMrdivide(
                                    mclVv(m2, "m2"), mclVv(rad, "rad"))))),
                            mlfSin(
                              mclMtimes(
                                _mxarray5_,
                                mlfAsin(
                                  mclMrdivide(
                                    mclVv(m1, "m1"), mclVv(rad, "rad"))))))))),
                    mclTimes(
                      mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                      mclMinus(mclVv(m2, "m2"), mclVv(m1, "m1")))),
                  mclPlus(
                    mclMinus(mclVv(m1, "m1"), mclVv(minxy, "minxy")),
                    _mxarray4_)),
                mclOr(
                  mclAnd(
                    mclLt(
                      mclMpower(mclVv(rad, "rad"), _mxarray5_),
                      mclPlus(
                        mlfPower(
                          mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_),
                          _mxarray5_),
                        mlfPower(
                          mclPlus(mclVv(minxy, "minxy"), _mxarray4_),
                          _mxarray5_))),
                    mclGt(
                      mclMpower(mclVv(rad, "rad"), _mxarray5_),
                      mclPlus(
                        mlfPower(
                          mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                          _mxarray5_),
                        mlfPower(
                          mclMinus(mclVv(minxy, "minxy"), _mxarray4_),
                          _mxarray5_)))),
                  mclAnd(
                    mclAnd(
                      mclEq(mclVv(minxy, "minxy"), _mxarray7_),
                      mclLt(
                        mclMinus(mclVv(maxxy, "maxxy"), _mxarray4_),
                        mclVv(rad, "rad"))),
                    mclGe(
                      mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_),
                      mclVv(rad, "rad"))))));
            /*
             * 0.25*(sin(2*asin(m2/rad)) - sin(2*asin(m1/rad)))) - ...
             * (maxxy-0.5).*(m2-m1) + (m1-minxy+0.5)) ... 
             * .*((((rad^2 < (maxxy+0.5).^2 + (minxy+0.5).^2) & ...
             * (rad^2 > (maxxy-0.5).^2 + (minxy-0.5).^2)) | ...
             * ((minxy==0)&(maxxy-0.5 < rad)&(maxxy+0.5>=rad))));
             * sgrid = sgrid + ((maxxy+0.5).^2 + (minxy+0.5).^2 < rad^2);
             */
            mlfAssign(
              &sgrid,
              mclPlus(
                mclVv(sgrid, "sgrid"),
                mclLt(
                  mclPlus(
                    mlfPower(
                      mclPlus(mclVv(maxxy, "maxxy"), _mxarray4_), _mxarray5_),
                    mlfPower(
                      mclPlus(mclVv(minxy, "minxy"), _mxarray4_), _mxarray5_)),
                  mclMpower(mclVv(rad, "rad"), _mxarray5_))));
            /*
             * sgrid(crad+1,crad+1) = min(pi*rad^2,pi/2);
             */
            mclArrayAssign2(
              &sgrid,
              mlfMin(
                NULL,
                mclMtimes(_mxarray8_, mclMpower(mclVv(rad, "rad"), _mxarray5_)),
                _mxarray9_,
                NULL),
              mclPlus(mclVv(crad, "crad"), _mxarray10_),
              mclPlus(mclVv(crad, "crad"), _mxarray10_));
            /*
             * if ((crad>0) & (rad > crad-0.5) & (rad^2 < (crad-0.5)^2+0.25)) 
             */
            {
                mxArray * a_
                  = mclInitialize(mclGt(mclVv(crad, "crad"), _mxarray7_));
                if (mlfTobool(a_)) {
                    mlfAssign(
                      &a_,
                      mclAnd(
                        a_,
                        mclGt(
                          mclVv(rad, "rad"),
                          mclMinus(mclVv(crad, "crad"), _mxarray4_))));
                } else {
                    mlfAssign(&a_, mlfScalar(0));
                }
                if (mlfTobool(a_)
                    && mlfTobool(
                         mclAnd(
                           a_,
                           mclLt(
                             mclMpower(mclVv(rad, "rad"), _mxarray5_),
                             mclPlus(
                               mclMpower(
                                 mclMinus(mclVv(crad, "crad"), _mxarray4_),
                                 _mxarray5_),
                               _mxarray6_))))) {
                    mxDestroyArray(a_);
                    /*
                     * m1  = sqrt(rad^2 - (crad - 0.5).^2);
                     */
                    mlfAssign(
                      &m1,
                      mlfSqrt(
                        mclMinus(
                          mclMpower(mclVv(rad, "rad"), _mxarray5_),
                          mlfPower(
                            mclMinus(mclVv(crad, "crad"), _mxarray4_),
                            _mxarray5_))));
                    /*
                     * m1n = m1/rad;
                     */
                    mlfAssign(
                      &m1n, mclMrdivide(mclVv(m1, "m1"), mclVv(rad, "rad")));
                    /*
                     * sg0 = 2*(rad^2*(0.5*asin(m1n) + 0.25*sin(2*asin(m1n)))-m1*(crad-0.5));
                     */
                    mlfAssign(
                      &sg0,
                      mclMtimes(
                        _mxarray5_,
                        mclMinus(
                          mclMtimes(
                            mclMpower(mclVv(rad, "rad"), _mxarray5_),
                            mclPlus(
                              mclMtimes(_mxarray4_, mlfAsin(mclVv(m1n, "m1n"))),
                              mclMtimes(
                                _mxarray6_,
                                mlfSin(
                                  mclMtimes(
                                    _mxarray5_, mlfAsin(mclVv(m1n, "m1n"))))))),
                          mclMtimes(
                            mclVv(m1, "m1"),
                            mclMinus(mclVv(crad, "crad"), _mxarray4_)))));
                    /*
                     * sgrid(2*crad+1,crad+1) = sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclVv(sg0, "sg0"),
                      mclPlus(
                        mclMtimes(_mxarray5_, mclVv(crad, "crad")),
                        _mxarray10_),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_));
                    /*
                     * sgrid(crad+1,2*crad+1) = sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclVv(sg0, "sg0"),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_),
                      mclPlus(
                        mclMtimes(_mxarray5_, mclVv(crad, "crad")),
                        _mxarray10_));
                    /*
                     * sgrid(crad+1,1)        = sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclVv(sg0, "sg0"),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_),
                      _mxarray10_);
                    /*
                     * sgrid(1,crad+1)        = sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclVv(sg0, "sg0"),
                      _mxarray10_,
                      mclPlus(mclVv(crad, "crad"), _mxarray10_));
                    /*
                     * sgrid(2*crad,crad+1)   = sgrid(2*crad,crad+1) - sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclMinus(
                        mclArrayRef2(
                          mclVv(sgrid, "sgrid"),
                          mclMtimes(_mxarray5_, mclVv(crad, "crad")),
                          mclPlus(mclVv(crad, "crad"), _mxarray10_)),
                        mclVv(sg0, "sg0")),
                      mclMtimes(_mxarray5_, mclVv(crad, "crad")),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_));
                    /*
                     * sgrid(crad+1,2*crad)   = sgrid(crad+1,2*crad) - sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclMinus(
                        mclArrayRef2(
                          mclVv(sgrid, "sgrid"),
                          mclPlus(mclVv(crad, "crad"), _mxarray10_),
                          mclMtimes(_mxarray5_, mclVv(crad, "crad"))),
                        mclVv(sg0, "sg0")),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_),
                      mclMtimes(_mxarray5_, mclVv(crad, "crad")));
                    /*
                     * sgrid(crad+1,2)        = sgrid(crad+1,2)      - sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclMinus(
                        mclArrayRef2(
                          mclVv(sgrid, "sgrid"),
                          mclPlus(mclVv(crad, "crad"), _mxarray10_),
                          _mxarray5_),
                        mclVv(sg0, "sg0")),
                      mclPlus(mclVv(crad, "crad"), _mxarray10_),
                      _mxarray5_);
                    /*
                     * sgrid(2,crad+1)        = sgrid(2,crad+1)      - sg0;
                     */
                    mclArrayAssign2(
                      &sgrid,
                      mclMinus(
                        mclArrayRef2(
                          mclVv(sgrid, "sgrid"),
                          _mxarray5_,
                          mclPlus(mclVv(crad, "crad"), _mxarray10_)),
                        mclVv(sg0, "sg0")),
                      _mxarray5_,
                      mclPlus(mclVv(crad, "crad"), _mxarray10_));
                } else {
                    mxDestroyArray(a_);
                }
            /*
             * end
             */
            }
            /*
             * sgrid(crad+1,crad+1) = min(sgrid(crad+1,crad+1),1);
             */
            mclArrayAssign2(
              &sgrid,
              mlfMin(
                NULL,
                mclArrayRef2(
                  mclVv(sgrid, "sgrid"),
                  mclPlus(mclVv(crad, "crad"), _mxarray10_),
                  mclPlus(mclVv(crad, "crad"), _mxarray10_)),
                _mxarray10_,
                NULL),
              mclPlus(mclVv(crad, "crad"), _mxarray10_),
              mclPlus(mclVv(crad, "crad"), _mxarray10_));
            /*
             * h = sgrid/sum(sgrid(:));
             */
            mlfAssign(
              &h,
              mclMrdivide(
                mclVv(sgrid, "sgrid"),
                mlfSum(
                  mclArrayRef1(mclVv(sgrid, "sgrid"), mlfCreateColonIndex()),
                  NULL)));
        /*
         * 
         * case 'gaussian' % Gaussian filter
         */
        } else if (mclSwitchCompare(v_, _mxarray11_)) {
            /*
             * 
             * siz   = (p2-1)/2;
             */
            mlfAssign(
              &siz,
              mclMrdivide(mclMinus(mclVv(p2, "p2"), _mxarray10_), _mxarray5_));
            /*
             * std   = p3;
             */
            mlfAssign(&std, mclVv(p3, "p3"));
            /*
             * 
             * [x,y] = meshgrid(-siz(2):siz(2),-siz(1):siz(1));
             */
            mlfAssign(
              &x,
              mlfNMeshgrid(
                2,
                &y,
                NULL,
                mlfColon(
                  mclUminus(mclIntArrayRef1(mclVv(siz, "siz"), 2)),
                  mclIntArrayRef1(mclVv(siz, "siz"), 2),
                  NULL),
                mlfColon(
                  mclUminus(mclIntArrayRef1(mclVv(siz, "siz"), 1)),
                  mclIntArrayRef1(mclVv(siz, "siz"), 1),
                  NULL),
                NULL));
            /*
             * arg   = -(x.*x + y.*y)/(2*std*std);
             */
            mlfAssign(
              &arg,
              mclMrdivide(
                mclUminus(
                  mclPlus(
                    mclTimes(mclVv(x, "x"), mclVv(x, "x")),
                    mclTimes(mclVv(y, "y"), mclVv(y, "y")))),
                mclMtimes(
                  mclMtimes(_mxarray5_, mclVv(std, "std")),
                  mclVv(std, "std"))));
            /*
             * 
             * h     = exp(arg);
             */
            mlfAssign(&h, mlfExp(mclVv(arg, "arg")));
            /*
             * h(h<eps*max(h(:))) = 0;
             */
            mclArrayAssign1(
              &h,
              _mxarray7_,
              mclLt(
                mclVv(h, "h"),
                mclMtimes(
                  _mxarray13_,
                  mlfMax(
                    NULL,
                    mclArrayRef1(mclVv(h, "h"), mlfCreateColonIndex()),
                    NULL,
                    NULL))));
            /*
             * 
             * sumh = sum(h(:));
             */
            mlfAssign(
              &sumh,
              mlfSum(mclArrayRef1(mclVv(h, "h"), mlfCreateColonIndex()), NULL));
            /*
             * if sumh ~= 0,
             */
            if (mclNeBool(mclVv(sumh, "sumh"), _mxarray7_)) {
                /*
                 * h  = h/sumh;
                 */
                mlfAssign(&h, mclMrdivide(mclVv(h, "h"), mclVv(sumh, "sumh")));
            /*
             * end;
             */
            }
        /*
         * 
         * case 'laplacian' % Laplacian filter
         */
        } else if (mclSwitchCompare(v_, _mxarray14_)) {
            /*
             * alpha = p2;
             */
            mlfAssign(&alpha, mclVv(p2, "p2"));
            /*
             * alpha = max(0,min(alpha,1));
             */
            mlfAssign(
              &alpha,
              mlfMax(
                NULL,
                _mxarray7_,
                mlfMin(NULL, mclVv(alpha, "alpha"), _mxarray10_, NULL),
                NULL));
            /*
             * h1    = alpha/(alpha+1); h2 = (1-alpha)/(alpha+1);
             */
            mlfAssign(
              &h1,
              mclMrdivide(
                mclVv(alpha, "alpha"),
                mclPlus(mclVv(alpha, "alpha"), _mxarray10_)));
            mlfAssign(
              &h2,
              mclMrdivide(
                mclMinus(_mxarray10_, mclVv(alpha, "alpha")),
                mclPlus(mclVv(alpha, "alpha"), _mxarray10_)));
            /*
             * h     = [h1 h2 h1;h2 -4/(alpha+1) h2;h1 h2 h1];
             */
            mlfAssign(
              &h,
              mlfVertcat(
                mlfHorzcat(
                  mclVv(h1, "h1"), mclVv(h2, "h2"), mclVv(h1, "h1"), NULL),
                mlfHorzcat(
                  mclVv(h2, "h2"),
                  mclMrdivide(
                    _mxarray16_, mclPlus(mclVv(alpha, "alpha"), _mxarray10_)),
                  mclVv(h2, "h2"),
                  NULL),
                mlfHorzcat(
                  mclVv(h1, "h1"), mclVv(h2, "h2"), mclVv(h1, "h1"), NULL),
                NULL));
        /*
         * 
         * case 'log' % Laplacian of Gaussian
         */
        } else if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * % first calculate Gaussian
             * siz   = (p2-1)/2;
             */
            mlfAssign(
              &siz,
              mclMrdivide(mclMinus(mclVv(p2, "p2"), _mxarray10_), _mxarray5_));
            /*
             * std2   = p3^2;
             */
            mlfAssign(&std2, mclMpower(mclVv(p3, "p3"), _mxarray5_));
            /*
             * 
             * [x,y] = meshgrid(-siz(2):siz(2),-siz(1):siz(1));
             */
            mlfAssign(
              &x,
              mlfNMeshgrid(
                2,
                &y,
                NULL,
                mlfColon(
                  mclUminus(mclIntArrayRef1(mclVv(siz, "siz"), 2)),
                  mclIntArrayRef1(mclVv(siz, "siz"), 2),
                  NULL),
                mlfColon(
                  mclUminus(mclIntArrayRef1(mclVv(siz, "siz"), 1)),
                  mclIntArrayRef1(mclVv(siz, "siz"), 1),
                  NULL),
                NULL));
            /*
             * arg   = -(x.*x + y.*y)/(2*std2);
             */
            mlfAssign(
              &arg,
              mclMrdivide(
                mclUminus(
                  mclPlus(
                    mclTimes(mclVv(x, "x"), mclVv(x, "x")),
                    mclTimes(mclVv(y, "y"), mclVv(y, "y")))),
                mclMtimes(_mxarray5_, mclVv(std2, "std2"))));
            /*
             * 
             * h     = exp(arg);
             */
            mlfAssign(&h, mlfExp(mclVv(arg, "arg")));
            /*
             * h(h<eps*max(h(:))) = 0;
             */
            mclArrayAssign1(
              &h,
              _mxarray7_,
              mclLt(
                mclVv(h, "h"),
                mclMtimes(
                  _mxarray13_,
                  mlfMax(
                    NULL,
                    mclArrayRef1(mclVv(h, "h"), mlfCreateColonIndex()),
                    NULL,
                    NULL))));
            /*
             * 
             * sumh = sum(h(:));
             */
            mlfAssign(
              &sumh,
              mlfSum(mclArrayRef1(mclVv(h, "h"), mlfCreateColonIndex()), NULL));
            /*
             * if sumh ~= 0,
             */
            if (mclNeBool(mclVv(sumh, "sumh"), _mxarray7_)) {
                /*
                 * h  = h/sumh;
                 */
                mlfAssign(&h, mclMrdivide(mclVv(h, "h"), mclVv(sumh, "sumh")));
            /*
             * end;
             */
            }
            /*
             * % now calculate Laplacian     
             * h1 = h.*(x.*x + y.*y - 2*std2)/(std2^2);
             */
            mlfAssign(
              &h1,
              mclMrdivide(
                mclTimes(
                  mclVv(h, "h"),
                  mclMinus(
                    mclPlus(
                      mclTimes(mclVv(x, "x"), mclVv(x, "x")),
                      mclTimes(mclVv(y, "y"), mclVv(y, "y"))),
                    mclMtimes(_mxarray5_, mclVv(std2, "std2")))),
                mclMpower(mclVv(std2, "std2"), _mxarray5_)));
            /*
             * h     = h1 - sum(h1(:))/prod(p2); % make the filter sum to zero
             */
            mlfAssign(
              &h,
              mclMinus(
                mclVv(h1, "h1"),
                mclMrdivide(
                  mlfSum(
                    mclArrayRef1(mclVv(h1, "h1"), mlfCreateColonIndex()), NULL),
                  mlfProd(mclVv(p2, "p2"), NULL))));
        /*
         * 
         * case 'motion' % Motion filter uses bilinear interpolation
         */
        } else if (mclSwitchCompare(v_, _mxarray19_)) {
            /*
             * len = max(1,p2);
             */
            mlfAssign(&len, mlfMax(NULL, _mxarray10_, mclVv(p2, "p2"), NULL));
            /*
             * half = (len-1)/2;% rotate half length around center
             */
            mlfAssign(
              &half,
              mclMrdivide(
                mclMinus(mclVv(len, "len"), _mxarray10_), _mxarray5_));
            /*
             * phi = mod(p3,180)/180*pi;
             */
            mlfAssign(
              &phi,
              mclMtimes(
                mclMrdivide(mlfMod(mclVv(p3, "p3"), _mxarray21_), _mxarray21_),
                _mxarray8_));
            /*
             * 
             * cosphi = cos(phi);
             */
            mlfAssign(&cosphi, mlfCos(mclVv(phi, "phi")));
            /*
             * sinphi = sin(phi);
             */
            mlfAssign(&sinphi, mlfSin(mclVv(phi, "phi")));
            /*
             * xsign = sign(cosphi);
             */
            mlfAssign(&xsign, mlfSign(mclVv(cosphi, "cosphi")));
            /*
             * linewdt = 1;
             */
            mlfAssign(&linewdt, _mxarray10_);
            /*
             * 
             * % define mesh for the half matrix, eps takes care of the right size
             * % for 0 & 90 rotation
             * sx = fix(half*cosphi + linewdt*xsign - len*eps);
             */
            mlfAssign(
              &sx,
              mlfFix(
                mclMinus(
                  mclPlus(
                    mclMtimes(mclVv(half, "half"), mclVv(cosphi, "cosphi")),
                    mclMtimes(
                      mclVv(linewdt, "linewdt"), mclVv(xsign, "xsign"))),
                  mclMtimes(mclVv(len, "len"), _mxarray13_))));
            /*
             * sy = fix(half*sinphi + linewdt - len*eps);
             */
            mlfAssign(
              &sy,
              mlfFix(
                mclMinus(
                  mclPlus(
                    mclMtimes(mclVv(half, "half"), mclVv(sinphi, "sinphi")),
                    mclVv(linewdt, "linewdt")),
                  mclMtimes(mclVv(len, "len"), _mxarray13_))));
            /*
             * [x y] = meshgrid([0:xsign:sx],[0:sy]);
             */
            mlfAssign(
              &x,
              mlfNMeshgrid(
                2,
                &y,
                NULL,
                mlfColon(_mxarray7_, mclVv(xsign, "xsign"), mclVv(sx, "sx")),
                mlfColon(_mxarray7_, mclVv(sy, "sy"), NULL),
                NULL));
            /*
             * 
             * % define shortest distance from a pixel to the rotated line 
             * dist2line = (y*cosphi-x*sinphi);% distance perpendicular to the line
             */
            mlfAssign(
              &dist2line,
              mclMinus(
                mclMtimes(mclVv(y, "y"), mclVv(cosphi, "cosphi")),
                mclMtimes(mclVv(x, "x"), mclVv(sinphi, "sinphi"))));
            /*
             * 
             * rad = sqrt(x.^2 + y.^2);
             */
            mlfAssign(
              &rad,
              mlfSqrt(
                mclPlus(
                  mlfPower(mclVv(x, "x"), _mxarray5_),
                  mlfPower(mclVv(y, "y"), _mxarray5_))));
            /*
             * % find points beyond the line's end-point but within the line width
             * lastpix = find((rad >= half)&(abs(dist2line)<=linewdt));
             */
            mlfAssign(
              &lastpix,
              mlfFind(
                NULL,
                NULL,
                mclAnd(
                  mclGe(mclVv(rad, "rad"), mclVv(half, "half")),
                  mclLe(
                    mlfAbs(mclVv(dist2line, "dist2line")),
                    mclVv(linewdt, "linewdt")))));
            /*
             * %distance to the line's end-point parallel to the line 
             * x2lastpix = half - abs((x(lastpix) + dist2line(lastpix)*sinphi)/cosphi);
             */
            mlfAssign(
              &x2lastpix,
              mclMinus(
                mclVv(half, "half"),
                mlfAbs(
                  mclMrdivide(
                    mclPlus(
                      mclArrayRef1(mclVv(x, "x"), mclVv(lastpix, "lastpix")),
                      mclMtimes(
                        mclArrayRef1(
                          mclVv(dist2line, "dist2line"),
                          mclVv(lastpix, "lastpix")),
                        mclVv(sinphi, "sinphi"))),
                    mclVv(cosphi, "cosphi")))));
            /*
             * 
             * dist2line(lastpix) = sqrt(dist2line(lastpix).^2 + x2lastpix.^2);
             */
            mclArrayAssign1(
              &dist2line,
              mlfSqrt(
                mclPlus(
                  mlfPower(
                    mclArrayRef1(
                      mclVv(dist2line, "dist2line"), mclVv(lastpix, "lastpix")),
                    _mxarray5_),
                  mlfPower(mclVv(x2lastpix, "x2lastpix"), _mxarray5_))),
              mclVv(lastpix, "lastpix"));
            /*
             * dist2line = linewdt + eps - abs(dist2line);
             */
            mlfAssign(
              &dist2line,
              mclMinus(
                mclPlus(mclVv(linewdt, "linewdt"), _mxarray13_),
                mlfAbs(mclVv(dist2line, "dist2line"))));
            /*
             * dist2line(dist2line<0) = 0;% zero out anything beyond line width
             */
            mclArrayAssign1(
              &dist2line,
              _mxarray7_,
              mclLt(mclVv(dist2line, "dist2line"), _mxarray7_));
            /*
             * 
             * % unfold half-matrix to the full size
             * h = rot90(dist2line,2);
             */
            mlfAssign(&h, mlfRot90(mclVv(dist2line, "dist2line"), _mxarray5_));
            /*
             * h(end+[1:end]-1,end+[1:end]-1) = dist2line;
             */
            mclArrayAssign2(
              &h,
              mclVv(dist2line, "dist2line"),
              mclMinus(
                mclPlus(
                  mlfEnd(mclVv(h, "h"), _mxarray10_, _mxarray5_),
                  mlfColon(
                    _mxarray10_,
                    mlfEnd(mclVv(h, "h"), _mxarray10_, _mxarray5_),
                    NULL)),
                _mxarray10_),
              mclMinus(
                mclPlus(
                  mlfEnd(mclVv(h, "h"), _mxarray5_, _mxarray5_),
                  mlfColon(
                    _mxarray10_,
                    mlfEnd(mclVv(h, "h"), _mxarray5_, _mxarray5_),
                    NULL)),
                _mxarray10_));
            /*
             * h = h./(sum(h(:)) + eps*len*len);
             */
            mlfAssign(
              &h,
              mclRdivide(
                mclVv(h, "h"),
                mclPlus(
                  mlfSum(
                    mclArrayRef1(mclVv(h, "h"), mlfCreateColonIndex()), NULL),
                  mclMtimes(
                    mclMtimes(_mxarray13_, mclVv(len, "len")),
                    mclVv(len, "len")))));
            /*
             * 
             * if cosphi>0,
             */
            if (mclGtBool(mclVv(cosphi, "cosphi"), _mxarray7_)) {
                /*
                 * h = flipud(h);
                 */
                mlfAssign(&h, mlfFlipud(mclVv(h, "h")));
            /*
             * end
             */
            }
        /*
         * 
         * case 'prewitt' % Prewitt filter
         */
        } else if (mclSwitchCompare(v_, _mxarray22_)) {
            /*
             * h = [1 1 1;0 0 0;-1 -1 -1];
             */
            mlfAssign(&h, _mxarray24_);
        /*
         * 
         * case 'sobel' % Sobel filter
         */
        } else if (mclSwitchCompare(v_, _mxarray26_)) {
            /*
             * h = [1 2 1;0 0 0;-1 -2 -1];
             */
            mlfAssign(&h, _mxarray28_);
        /*
         * 
         * case 'unsharp' % Unsharp filter
         */
        } else if (mclSwitchCompare(v_, _mxarray30_)) {
            /*
             * alpha = p2;
             */
            mlfAssign(&alpha, mclVv(p2, "p2"));
            /*
             * h     = [0 0 0;0 1 0;0 0 0] - fspecial('laplacian',alpha);
             */
            mlfAssign(
              &h,
              mclMinus(
                _mxarray32_,
                mlfFspecial(_mxarray14_, mclVv(alpha, "alpha"), NULL)));
        /*
         * 
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(h, 1, nargout_, "h", "fspecial");
    mxDestroyArray(type);
    mxDestroyArray(p2);
    mxDestroyArray(p3);
    mxDestroyArray(siz);
    mxDestroyArray(rad);
    mxDestroyArray(crad);
    mxDestroyArray(x);
    mxDestroyArray(y);
    mxDestroyArray(maxxy);
    mxDestroyArray(minxy);
    mxDestroyArray(m1);
    mxDestroyArray(m2);
    mxDestroyArray(sgrid);
    mxDestroyArray(m1n);
    mxDestroyArray(sg0);
    mxDestroyArray(std);
    mxDestroyArray(arg);
    mxDestroyArray(sumh);
    mxDestroyArray(alpha);
    mxDestroyArray(h1);
    mxDestroyArray(h2);
    mxDestroyArray(std2);
    mxDestroyArray(len);
    mxDestroyArray(half);
    mxDestroyArray(phi);
    mxDestroyArray(cosphi);
    mxDestroyArray(sinphi);
    mxDestroyArray(xsign);
    mxDestroyArray(linewdt);
    mxDestroyArray(sx);
    mxDestroyArray(sy);
    mxDestroyArray(dist2line);
    mxDestroyArray(lastpix);
    mxDestroyArray(x2lastpix);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return h;
    /*
     * 
     * 
     * %%%
     * %%% ParseInputs
     * %%%
     */
}

/*
 * The function "Mfspecial_ParseInputs" is the implementation version of the
 * "fspecial/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\fspecial.m" (lines 235-354). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [type, p2, p3] = ParseInputs(varargin)
 */
static mxArray * Mfspecial_ParseInputs(mxArray * * p2,
                                       mxArray * * p3,
                                       int nargout_,
                                       mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_fspecial);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * type = NULL;
    mxArray * eid = NULL;
    mxArray * msg = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % default values
     * type      = '';
     */
    mlfAssign(&type, _mxarray34_);
    /*
     * p2        = [];
     */
    mlfAssign(p2, _mxarray35_);
    /*
     * p3        = [];
     */
    mlfAssign(p3, _mxarray35_);
    /*
     * 
     * % Check the number of input arguments.
     * checknargin(1,3,nargin,mfilename);
     */
    mlfImages_private_checknargin(
      _mxarray10_, _mxarray36_, mlfScalar(nargin_), mxCreateString("fspecial"));
    /*
     * 
     * % Determine filter type from the user supplied string.
     * type = varargin{1};
     */
    mlfAssign(
      &type, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray10_));
    /*
     * type = checkstrs(type,{'gaussian','sobel','prewitt','laplacian','log',...
     */
    mlfAssign(
      &type,
      mlfImages_private_checkstrs(
        mclVv(type, "type"),
        _mxarray37_,
        mxCreateString("fspecial"),
        _mxarray39_,
        _mxarray10_));
    /*
     * 'average','unsharp','disk','motion'},mfilename,'TYPE',1);
     * 
     * % default values
     * switch type
     */
    {
        mxArray * v_ = mclInitialize(mclVv(type, "type"));
        if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * case 'average'
             * p2 = [3 3];  % siz
             */
            mlfAssign(p2, _mxarray41_);
        /*
         * 
         * case 'disk'
         */
        } else if (mclSwitchCompare(v_, _mxarray2_)) {
            /*
             * p2 = 5;      % rad
             */
            mlfAssign(p2, _mxarray43_);
        /*
         * 
         * case 'gaussian'
         */
        } else if (mclSwitchCompare(v_, _mxarray11_)) {
            /*
             * p2 = [3 3];  % siz
             */
            mlfAssign(p2, _mxarray41_);
            /*
             * p3 = 0.5;    % std
             */
            mlfAssign(p3, _mxarray4_);
        /*
         * 
         * case {'laplacian', 'unsharp'}
         */
        } else if (mclSwitchCompare(v_, _mxarray44_)) {
            /*
             * p2 = 1/5;    % alpha
             */
            mlfAssign(p2, _mxarray46_);
        /*
         * 
         * case 'log'
         */
        } else if (mclSwitchCompare(v_, _mxarray17_)) {
            /*
             * p2 = [5 5];  % siz
             */
            mlfAssign(p2, _mxarray47_);
            /*
             * p3 = 0.5;    % std
             */
            mlfAssign(p3, _mxarray4_);
        /*
         * 
         * case 'motion'
         */
        } else if (mclSwitchCompare(v_, _mxarray19_)) {
            /*
             * p2 = 9;     % len
             */
            mlfAssign(p2, _mxarray49_);
            /*
             * p3 = 0;      % theta
             */
            mlfAssign(p3, _mxarray7_);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * 
     * switch nargin
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray10_)) {
        /*
         * case 1
         * % FSPECIAL('average')
         * % FSPECIAL('disk')
         * % FSPECIAL('gaussian')
         * % FSPECIAL('laplacian')
         * % FSPECIAL('log')
         * % FSPECIAL('motion')
         * % FSPECIAL('prewitt')
         * % FSPECIAL('sobel')
         * % FSPECIAL('unsharp')
         * % Nothing to do here; the default values have 
         * % already been assigned.        
         * 
         * case 2
         */
        } else if (mclSwitchCompare(v_, _mxarray5_)) {
            /*
             * % FSPECIAL('average',N)
             * % FSPECIAL('disk',RADIUS)
             * % FSPECIAL('gaussian',N)
             * % FSPECIAL('laplacian',ALPHA)
             * % FSPECIAL('log',N)
             * % FSPECIAL('motion',LEN)
             * % FSPECIAL('unsharp',ALPHA)
             * p2 = varargin{2};
             */
            mlfAssign(
              p2, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_));
            /*
             * 
             * switch type
             */
            {
                mxArray * v_0 = mclInitialize(mclVv(type, "type"));
                if (mclSwitchCompare(v_0, _mxarray50_)) {
                    /*
                     * case {'sobel','prewitt'}
                     * msg = sprintf('%s: Too many arguments for this type of filter.', upper(mfilename));
                     */
                    mlfAssign(
                      &msg,
                      mlfSprintf(
                        NULL,
                        _mxarray52_,
                        mlfUpper(mxCreateString("fspecial")),
                        NULL));
                    /*
                     * eid = sprintf('Images:%s:tooManyArgsForThisFilter', mfilename);
                     */
                    mlfAssign(
                      &eid,
                      mlfSprintf(
                        NULL, _mxarray54_, mxCreateString("fspecial"), NULL));
                    /*
                     * error(eid,msg);
                     */
                    mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                /*
                 * case {'laplacian','unsharp'}
                 */
                } else if (mclSwitchCompare(v_0, _mxarray44_)) {
                    /*
                     * checkinput(p2,{'double'},{'nonnegative','real',...
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p2, "p2"),
                      _mxarray56_,
                      _mxarray59_,
                      mxCreateString("fspecial"),
                      _mxarray71_,
                      _mxarray5_);
                    /*
                     * 'nonempty','finite','scalar'},...
                     * mfilename,'ALPHA',2);
                     * if  p2 > 1
                     */
                    if (mclGtBool(mclVv(*p2, "p2"), _mxarray10_)) {
                        /*
                         * msg = sprintf('%s: ALPHA should be less than or equal 1 and greater than 0.', upper(mfilename));
                         */
                        mlfAssign(
                          &msg,
                          mlfSprintf(
                            NULL,
                            _mxarray73_,
                            mlfUpper(mxCreateString("fspecial")),
                            NULL));
                        /*
                         * eid = sprintf('Images:%s:outOfRangeAlpha', mfilename);
                         */
                        mlfAssign(
                          &eid,
                          mlfSprintf(
                            NULL,
                            _mxarray75_,
                            mxCreateString("fspecial"),
                            NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * end
                     */
                    }
                /*
                 * case {'disk','motion'}
                 */
                } else if (mclSwitchCompare(v_0, _mxarray77_)) {
                    /*
                     * checkinput(p2,{'double'},{'positive','finite','real','nonempty','scalar'},mfilename,'RADIUS or LEN',2);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p2, "p2"),
                      _mxarray56_,
                      _mxarray79_,
                      mxCreateString("fspecial"),
                      _mxarray83_,
                      _mxarray5_);
                /*
                 * case {'gaussian','log','average'}
                 */
                } else if (mclSwitchCompare(v_0, _mxarray85_)) {
                    /*
                     * checkinput(p2,{'double'},{'positive','finite','real','nonempty','integer'},mfilename,'HSIZE',2);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p2, "p2"),
                      _mxarray56_,
                      _mxarray87_,
                      mxCreateString("fspecial"),
                      _mxarray91_,
                      _mxarray5_);
                    /*
                     * if prod(size(p2)) > 2
                     */
                    if (mclGtBool(
                          mlfProd(
                            mlfSize(
                              mclValueVarargout(), mclVv(*p2, "p2"), NULL),
                            NULL),
                          _mxarray5_)) {
                        /*
                         * msg = 'HSIZE should have 1 or 2 elements.';
                         */
                        mlfAssign(&msg, _mxarray93_);
                        /*
                         * eid = sprintf('Images:%s:wrongSizeN', mfilename);
                         */
                        mlfAssign(
                          &eid,
                          mlfSprintf(
                            NULL,
                            _mxarray95_,
                            mxCreateString("fspecial"),
                            NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * elseif (prod(size(p2))==1)
                     */
                    } else if (mclEqBool(
                                 mlfProd(
                                   mlfSize(
                                     mclValueVarargout(),
                                     mclVv(*p2, "p2"),
                                     NULL),
                                   NULL),
                                 _mxarray10_)) {
                        /*
                         * p2 = [p2 p2]; 
                         */
                        mlfAssign(
                          p2,
                          mlfHorzcat(mclVv(*p2, "p2"), mclVv(*p2, "p2"), NULL));
                    /*
                     * end
                     */
                    }
                /*
                 * end       
                 */
                }
                mxDestroyArray(v_0);
            }
        /*
         * 
         * 
         * case 3
         */
        } else if (mclSwitchCompare(v_, _mxarray36_)) {
            /*
             * % FSPECIAL('gaussian',N,SIGMA)
             * % FSPECIAL('log',N,SIGMA)
             * % FSPECIAL('motion',LEN,THETA)
             * p2 = varargin{2};
             */
            mlfAssign(
              p2, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray5_));
            /*
             * p3 = varargin{3};
             */
            mlfAssign(
              p3, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray36_));
            /*
             * 
             * switch type
             */
            {
                mxArray * v_1 = mclInitialize(mclVv(type, "type"));
                if (mclSwitchCompare(v_1, _mxarray19_)) {
                    /*
                     * case 'motion'
                     * checkinput(p2,{'double'},{'positive','finite','real','nonempty','scalar'},mfilename,'LEN',2);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p2, "p2"),
                      _mxarray56_,
                      _mxarray79_,
                      mxCreateString("fspecial"),
                      _mxarray97_,
                      _mxarray5_);
                    /*
                     * checkinput(p3,{'double'},{'real','nonempty','finite','scalar'},mfilename,'THETA',3);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p3, "p3"),
                      _mxarray56_,
                      _mxarray99_,
                      mxCreateString("fspecial"),
                      _mxarray101_,
                      _mxarray36_);
                /*
                 * case {'gaussian','log'}
                 */
                } else if (mclSwitchCompare(v_1, _mxarray103_)) {
                    /*
                     * checkinput(p2,{'double'},{'positive','finite','real','nonempty','integer'},mfilename,'N',2);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p2, "p2"),
                      _mxarray56_,
                      _mxarray87_,
                      mxCreateString("fspecial"),
                      _mxarray105_,
                      _mxarray5_);
                    /*
                     * checkinput(p3,{'double'},{'positive','finite','real','nonempty','scalar'},mfilename,'SIGMA',3);
                     */
                    mlfImages_private_checkinput(
                      mclVv(*p3, "p3"),
                      _mxarray56_,
                      _mxarray79_,
                      mxCreateString("fspecial"),
                      _mxarray107_,
                      _mxarray36_);
                    /*
                     * if prod(size(p2)) > 2
                     */
                    if (mclGtBool(
                          mlfProd(
                            mlfSize(
                              mclValueVarargout(), mclVv(*p2, "p2"), NULL),
                            NULL),
                          _mxarray5_)) {
                        /*
                         * msg = sprintf('%s: size(N) should be less than or equal 2.', upper(mfilename));
                         */
                        mlfAssign(
                          &msg,
                          mlfSprintf(
                            NULL,
                            _mxarray109_,
                            mlfUpper(mxCreateString("fspecial")),
                            NULL));
                        /*
                         * eid = sprintf('Images:%s:wrongSizeN', mfilename);
                         */
                        mlfAssign(
                          &eid,
                          mlfSprintf(
                            NULL,
                            _mxarray95_,
                            mxCreateString("fspecial"),
                            NULL));
                        /*
                         * error(eid,msg);
                         */
                        mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                    /*
                     * elseif (prod(size(p2))==1)
                     */
                    } else if (mclEqBool(
                                 mlfProd(
                                   mlfSize(
                                     mclValueVarargout(),
                                     mclVv(*p2, "p2"),
                                     NULL),
                                   NULL),
                                 _mxarray10_)) {
                        /*
                         * p2 = [p2 p2]; 
                         */
                        mlfAssign(
                          p2,
                          mlfHorzcat(mclVv(*p2, "p2"), mclVv(*p2, "p2"), NULL));
                    /*
                     * end
                     */
                    }
                /*
                 * otherwise   
                 */
                } else {
                    /*
                     * msg = sprintf('%s: Too many arguments for this type of filter.', upper(mfilename));
                     */
                    mlfAssign(
                      &msg,
                      mlfSprintf(
                        NULL,
                        _mxarray52_,
                        mlfUpper(mxCreateString("fspecial")),
                        NULL));
                    /*
                     * eid = sprintf('Images:%s:tooManyArgsForThisFilter', mfilename);
                     */
                    mlfAssign(
                      &eid,
                      mlfSprintf(
                        NULL, _mxarray54_, mxCreateString("fspecial"), NULL));
                    /*
                     * error(eid,msg);
                     */
                    mlfError(mclVv(eid, "eid"), mclVv(msg, "msg"), NULL);
                /*
                 * end
                 */
                }
                mxDestroyArray(v_1);
            }
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mclValidateOutput(type, 1, nargout_, "type", "fspecial/ParseInputs");
    mclValidateOutput(*p2, 2, nargout_, "p2", "fspecial/ParseInputs");
    mclValidateOutput(*p3, 3, nargout_, "p3", "fspecial/ParseInputs");
    mxDestroyArray(ans);
    mxDestroyArray(msg);
    mxDestroyArray(eid);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return type;
}
