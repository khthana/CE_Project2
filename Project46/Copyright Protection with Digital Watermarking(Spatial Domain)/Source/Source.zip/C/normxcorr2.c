/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "normxcorr2.h"
#include "libmatlbm.h"
#include "libmmfile.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;
static mxArray * _mxarray7_;
static mxArray * _mxarray8_;

static mxChar _array10_[42] = { 'T', 'E', 'M', 'P', 'L', 'A', 'T', 'E', ' ',
                                'm', 'u', 's', 't', ' ', 'b', 'e', ' ', 'a',
                                ' ', '2', '-', 'D', ',', ' ', 'r', 'e', 'a',
                                'l', ',', ' ', 'f', 'u', 'l', 'l', ' ', 'm',
                                'a', 't', 'r', 'i', 'x', '.' };
static mxArray * _mxarray9_;

static mxChar _array12_[35] = { 'A', ' ', 'm', 'u', 's', 't', ' ', 'b', 'e',
                                ' ', 'a', ' ', '2', '-', 'D', ',', ' ', 'r',
                                'e', 'a', 'l', ',', ' ', 'f', 'u', 'l', 'l',
                                ' ', 'm', 'a', 't', 'r', 'i', 'x', '.' };
static mxArray * _mxarray11_;

static mxChar _array14_[42] = { 'T', 'E', 'M', 'P', 'L', 'A', 'T', 'E', ' ',
                                'a', 'n', 'd', ' ', 'A', ' ', 'm', 'a', 'y',
                                ' ', 'n', 'o', 't', ' ', 'c', 'o', 'n', 't',
                                'a', 'i', 'n', ' ', 'N', 'a', 'N', ' ', 'o',
                                'r', ' ', 'I', 'n', 'f', '.' };
static mxArray * _mxarray13_;

static mxChar _array16_[42] = { 'T', 'E', 'M', 'P', 'L', 'A', 'T', 'E', ' ',
                                'm', 'u', 's', 't', ' ', 'c', 'o', 'n', 't',
                                'a', 'i', 'n', ' ', 'a', 't', ' ', 'l', 'e',
                                'a', 's', 't', ' ', '2', ' ', 'e', 'l', 'e',
                                'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray15_;

static mxChar _array18_[46] = { 'T', 'h', 'e', ' ', 'v', 'a', 'l', 'u',
                                'e', 's', ' ', 'o', 'f', ' ', 'T', 'E',
                                'M', 'P', 'L', 'A', 'T', 'E', ' ', 'c',
                                'a', 'n', 'n', 'o', 't', ' ', 'a', 'l',
                                'l', ' ', 'b', 'e', ' ', 't', 'h', 'e',
                                ' ', 's', 'a', 'm', 'e', '.' };
static mxArray * _mxarray17_;

static mxChar _array20_[48] = { 'A', ' ', 'm', 'u', 's', 't', ' ', 'b',
                                'e', ' ', 't', 'h', 'e', ' ', 's', 'a',
                                'm', 'e', ' ', 's', 'i', 'z', 'e', ' ',
                                'o', 'r', ' ', 'l', 'a', 'r', 'g', 'e',
                                'r', ' ', 't', 'h', 'a', 'n', ' ', 'T',
                                'E', 'M', 'P', 'L', 'A', 'T', 'E', '.' };
static mxArray * _mxarray19_;

void InitializeModule_normxcorr2(void) {
    _mxarray0_ = mclInitializeDouble(2.0);
    _mxarray1_ = mclInitializeDouble(1.0);
    _mxarray2_ = mclInitializeDouble(0.0);
    _mxarray3_ = mclInitializeDouble(3.0);
    _mxarray4_ = mclInitializeDouble(2.7e-08);
    _mxarray5_ = mclInitializeDouble(3.3e-07);
    _mxarray6_ = mclInitializeDouble(.1);
    _mxarray7_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray8_ = mclInitializeCharVector(0, 0, (mxChar *)NULL);
    _mxarray9_ = mclInitializeString(42, _array10_);
    _mxarray11_ = mclInitializeString(35, _array12_);
    _mxarray13_ = mclInitializeString(42, _array14_);
    _mxarray15_ = mclInitializeString(42, _array16_);
    _mxarray17_ = mclInitializeString(46, _array18_);
    _mxarray19_ = mclInitializeString(48, _array20_);
}

void TerminateModule_normxcorr2(void) {
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfNormxcorr2_local_sum(mxArray * A, mxArray * m, mxArray * n);
static void mlxNormxcorr2_local_sum(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfNormxcorr2_xcorr2_fast(mxArray * T, mxArray * A);
static void mlxNormxcorr2_xcorr2_fast(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static mxArray * mlfNormxcorr2_freqxcorr(mxArray * a,
                                         mxArray * b,
                                         mxArray * outsize);
static void mlxNormxcorr2_freqxcorr(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfNormxcorr2_time_conv2(mxArray * obssize, mxArray * refsize);
static void mlxNormxcorr2_time_conv2(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * mlfNormxcorr2_time_fft2(mxArray * outsize);
static void mlxNormxcorr2_time_fft2(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]);
static mxArray * mlfNormxcorr2_time_fft(mxArray * M);
static void mlxNormxcorr2_time_fft(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]);
static mxArray * mlfNormxcorr2_ParseInputs(mxArray * * A, mxArray * * msg, ...);
static void mlxNormxcorr2_ParseInputs(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]);
static mxArray * Mnormxcorr2(int nargout_, mxArray * varargin);
static mxArray * Mnormxcorr2_local_sum(int nargout_,
                                       mxArray * A,
                                       mxArray * m,
                                       mxArray * n);
static mxArray * Mnormxcorr2_xcorr2_fast(int nargout_,
                                         mxArray * T,
                                         mxArray * A);
static mxArray * Mnormxcorr2_freqxcorr(int nargout_,
                                       mxArray * a,
                                       mxArray * b,
                                       mxArray * outsize);
static mxArray * Mnormxcorr2_time_conv2(int nargout_,
                                        mxArray * obssize,
                                        mxArray * refsize);
static mxArray * Mnormxcorr2_time_fft2(int nargout_, mxArray * outsize);
static mxArray * Mnormxcorr2_time_fft(int nargout_, mxArray * M);
static mxArray * Mnormxcorr2_ParseInputs(mxArray * * A,
                                         mxArray * * msg,
                                         int nargout_,
                                         mxArray * varargin);

static mexFunctionTableEntry local_function_table_[7]
  = { { "local_sum", mlxNormxcorr2_local_sum, 3, 1, NULL },
      { "xcorr2_fast", mlxNormxcorr2_xcorr2_fast, 2, 1, NULL },
      { "freqxcorr", mlxNormxcorr2_freqxcorr, 3, 1, NULL },
      { "time_conv2", mlxNormxcorr2_time_conv2, 2, 1, NULL },
      { "time_fft2", mlxNormxcorr2_time_fft2, 1, 1, NULL },
      { "time_fft", mlxNormxcorr2_time_fft, 1, 1, NULL },
      { "ParseInputs", mlxNormxcorr2_ParseInputs, -1, 3, NULL } };

_mexLocalFunctionTable _local_function_table_normxcorr2
  = { 7, local_function_table_ };

/*
 * The function "mlfNormxcorr2" contains the normal interface for the
 * "normxcorr2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 1-88). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfNormxcorr2(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * C = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    C = Mnormxcorr2(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfReturnValue(C);
}

/*
 * The function "mlxNormxcorr2" contains the feval interface for the
 * "normxcorr2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 1-88). The feval
 * function calls the implementation version of normxcorr2 through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxNormxcorr2(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2 Line: 1 Column:"
            " 1 The function \"normxcorr2\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mnormxcorr2(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfNormxcorr2_local_sum" contains the normal interface for the
 * "normxcorr2/local_sum" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 88-110). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_local_sum(mxArray * A,
                                         mxArray * m,
                                         mxArray * n) {
    int nargout = 1;
    mxArray * local_sum_A = NULL;
    mlfEnterNewContext(0, 3, A, m, n);
    local_sum_A = Mnormxcorr2_local_sum(nargout, A, m, n);
    mlfRestorePreviousContext(0, 3, A, m, n);
    return mlfReturnValue(local_sum_A);
}

/*
 * The function "mlxNormxcorr2_local_sum" contains the feval interface for the
 * "normxcorr2/local_sum" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 88-110). The feval
 * function calls the implementation version of normxcorr2/local_sum through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_local_sum(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/local_sum Line: 88 Col"
            "umn: 1 The function \"normxcorr2/local_sum\" was called"
            " with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/local_sum Line: 88 Co"
            "lumn: 1 The function \"normxcorr2/local_sum\" was call"
            "ed with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mnormxcorr2_local_sum(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_xcorr2_fast" contains the normal interface for
 * the "normxcorr2/xcorr2_fast" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 110-130). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_xcorr2_fast(mxArray * T, mxArray * A) {
    int nargout = 1;
    mxArray * cross_corr = NULL;
    mlfEnterNewContext(0, 2, T, A);
    cross_corr = Mnormxcorr2_xcorr2_fast(nargout, T, A);
    mlfRestorePreviousContext(0, 2, T, A);
    return mlfReturnValue(cross_corr);
}

/*
 * The function "mlxNormxcorr2_xcorr2_fast" contains the feval interface for
 * the "normxcorr2/xcorr2_fast" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 110-130). The feval
 * function calls the implementation version of normxcorr2/xcorr2_fast through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_xcorr2_fast(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/xcorr2_fast Line: 110 C"
            "olumn: 1 The function \"normxcorr2/xcorr2_fast\" was cal"
            "led with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/xcorr2_fast Line: 110 C"
            "olumn: 1 The function \"normxcorr2/xcorr2_fast\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mnormxcorr2_xcorr2_fast(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_freqxcorr" contains the normal interface for the
 * "normxcorr2/freqxcorr" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 130-141). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_freqxcorr(mxArray * a,
                                         mxArray * b,
                                         mxArray * outsize) {
    int nargout = 1;
    mxArray * xcorr_ab = NULL;
    mlfEnterNewContext(0, 3, a, b, outsize);
    xcorr_ab = Mnormxcorr2_freqxcorr(nargout, a, b, outsize);
    mlfRestorePreviousContext(0, 3, a, b, outsize);
    return mlfReturnValue(xcorr_ab);
}

/*
 * The function "mlxNormxcorr2_freqxcorr" contains the feval interface for the
 * "normxcorr2/freqxcorr" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 130-141). The feval
 * function calls the implementation version of normxcorr2/freqxcorr through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_freqxcorr(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/freqxcorr Line: 130 Co"
            "lumn: 1 The function \"normxcorr2/freqxcorr\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/freqxcorr Line: 130 Co"
            "lumn: 1 The function \"normxcorr2/freqxcorr\" was calle"
            "d with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mnormxcorr2_freqxcorr(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_time_conv2" contains the normal interface for
 * the "normxcorr2/time_conv2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 141-173). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_time_conv2(mxArray * obssize,
                                          mxArray * refsize) {
    int nargout = 1;
    mxArray * time = NULL;
    mlfEnterNewContext(0, 2, obssize, refsize);
    time = Mnormxcorr2_time_conv2(nargout, obssize, refsize);
    mlfRestorePreviousContext(0, 2, obssize, refsize);
    return mlfReturnValue(time);
}

/*
 * The function "mlxNormxcorr2_time_conv2" contains the feval interface for the
 * "normxcorr2/time_conv2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 141-173). The feval
 * function calls the implementation version of normxcorr2/time_conv2 through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_time_conv2(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_conv2 Line: 141 Co"
            "lumn: 1 The function \"normxcorr2/time_conv2\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_conv2 Line: 141 C"
            "olumn: 1 The function \"normxcorr2/time_conv2\" was cal"
            "led with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mnormxcorr2_time_conv2(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_time_fft2" contains the normal interface for the
 * "normxcorr2/time_fft2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 173-199). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_time_fft2(mxArray * outsize) {
    int nargout = 1;
    mxArray * time = NULL;
    mlfEnterNewContext(0, 1, outsize);
    time = Mnormxcorr2_time_fft2(nargout, outsize);
    mlfRestorePreviousContext(0, 1, outsize);
    return mlfReturnValue(time);
}

/*
 * The function "mlxNormxcorr2_time_fft2" contains the feval interface for the
 * "normxcorr2/time_fft2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 173-199). The feval
 * function calls the implementation version of normxcorr2/time_fft2 through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_time_fft2(int nlhs,
                                    mxArray * plhs[],
                                    int nrhs,
                                    mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_fft2 Line: 173 Co"
            "lumn: 1 The function \"normxcorr2/time_fft2\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_fft2 Line: 173 Co"
            "lumn: 1 The function \"normxcorr2/time_fft2\" was calle"
            "d with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mnormxcorr2_time_fft2(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_time_fft" contains the normal interface for the
 * "normxcorr2/time_fft" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 199-220). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_time_fft(mxArray * M) {
    int nargout = 1;
    mxArray * T = NULL;
    mlfEnterNewContext(0, 1, M);
    T = Mnormxcorr2_time_fft(nargout, M);
    mlfRestorePreviousContext(0, 1, M);
    return mlfReturnValue(T);
}

/*
 * The function "mlxNormxcorr2_time_fft" contains the feval interface for the
 * "normxcorr2/time_fft" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 199-220). The feval
 * function calls the implementation version of normxcorr2/time_fft through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_time_fft(int nlhs,
                                   mxArray * plhs[],
                                   int nrhs,
                                   mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_fft Line: 199 Co"
            "lumn: 1 The function \"normxcorr2/time_fft\" was calle"
            "d with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/time_fft Line: 199 Co"
            "lumn: 1 The function \"normxcorr2/time_fft\" was calle"
            "d with more than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mnormxcorr2_time_fft(nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfNormxcorr2_ParseInputs" contains the normal interface for
 * the "normxcorr2/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 220-267). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfNormxcorr2_ParseInputs(mxArray * * A,
                                           mxArray * * msg,
                                           ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * T = NULL;
    mxArray * A__ = NULL;
    mxArray * msg__ = NULL;
    mlfVarargin(&varargin, msg, 0);
    mlfEnterNewContext(2, -1, A, msg, varargin);
    if (A != NULL) {
        ++nargout;
    }
    if (msg != NULL) {
        ++nargout;
    }
    T = Mnormxcorr2_ParseInputs(&A__, &msg__, nargout, varargin);
    mlfRestorePreviousContext(2, 0, A, msg);
    mxDestroyArray(varargin);
    if (A != NULL) {
        mclCopyOutputArg(A, A__);
    } else {
        mxDestroyArray(A__);
    }
    if (msg != NULL) {
        mclCopyOutputArg(msg, msg__);
    } else {
        mxDestroyArray(msg__);
    }
    return mlfReturnValue(T);
}

/*
 * The function "mlxNormxcorr2_ParseInputs" contains the feval interface for
 * the "normxcorr2/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 220-267). The feval
 * function calls the implementation version of normxcorr2/ParseInputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxNormxcorr2_ParseInputs(int nlhs,
                                      mxArray * plhs[],
                                      int nrhs,
                                      mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[3];
    int i;
    if (nlhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: normxcorr2/ParseInputs Line: 220 C"
            "olumn: 1 The function \"normxcorr2/ParseInputs\" was cal"
            "led with more than the declared number of outputs (3)."),
          NULL);
    }
    for (i = 0; i < 3; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mnormxcorr2_ParseInputs(&mplhs[1], &mplhs[2], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 3 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 3; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mnormxcorr2" is the implementation version of the "normxcorr2"
 * M-function from file "k:\matlab6p5\toolbox\images\images\normxcorr2.m"
 * (lines 1-88). It contains the actual compiled code for that M-function. It
 * is a static function and must only be called from one of the interface
 * functions, appearing below.
 */
/*
 * function C = normxcorr2(varargin);
 */
static mxArray * Mnormxcorr2(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * C = NULL;
    mxArray * i_nonzero = NULL;
    mxArray * numerator = NULL;
    mxArray * denom = NULL;
    mxArray * denom_T = NULL;
    mxArray * denom_A = NULL;
    mxArray * local_sum_A2 = NULL;
    mxArray * local_sum_A = NULL;
    mxArray * mn = NULL;
    mxArray * n = NULL;
    mxArray * m = NULL;
    mxArray * xcorr_TA = NULL;
    mxArray * ans = NULL;
    mxArray * msg = NULL;
    mxArray * A = NULL;
    mxArray * T = NULL;
    mclCopyArray(&varargin);
    /*
     * %NORMXCORR2 Normalized two-dimensional cross-correlation.
     * %   C = NORMXCORR2(TEMPLATE,A) computes the normalized cross-correlation of
     * %   matrices TEMPLATE and A. The matrix A must be larger than the matrix
     * %   TEMPLATE for the normalization to be meaningful. The values of TEMPLATE
     * %   cannot all be the same. The resulting matrix C contains correlation
     * %   coefficients and its values may range from -1.0 to 1.0.
     * %
     * %   Class Support
     * %   -------------
     * %   The input matrices can be of class logical, uint8, uint16, or double.
     * %   The output matrix C is double.
     * %
     * %   Example
     * %   -------
     * %   T = .2*ones(11); % make light gray plus on dark gray background
     * %   T(6,3:9) = .6;   
     * %   T(3:9,6) = .6;
     * %   BW = T>0.5;      % make white plus on black background
     * %   imshow(BW), title('Binary')
     * %   figure, imshow(T), title('Template')
     * %   % make new image that offsets template T 
     * %   T_offset = .2*ones(21); 
     * %   offset = [3 5];  % shift by 3 rows, 5 columns
     * %   T_offset( (1:size(T,1))+offset(1), (1:size(T,2))+offset(2) ) = T;
     * %   figure, imshow(T_offset), title('Offset Template')
     * %   
     * %   % cross-correlate BW and T_offset to recover offset  
     * %   cc = normxcorr2(BW,T_offset); 
     * %   [max_cc, imax] = max(abs(cc(:)));
     * %   [ypeak, xpeak] = ind2sub(size(cc),imax(1));
     * %   corr_offset = [ (ypeak-size(T,1)) (xpeak-size(T,2)) ];
     * %   isequal(corr_offset,offset) % 1 means offset was recovered
     * %
     * %  See also CORRCOEF.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.
     * %   $Revision: 1.12 $  $Date: 2002/03/15 15:28:45 $
     * 
     * %   Input-output specs
     * %   ------------------
     * %   T:    2-D, real, full matrix
     * %         logical, uint8, uint16, or double
     * %         no NaNs, no Infs
     * %         prod(size(T)) >= 2
     * %         std(T(:))~=0
     * %
     * %   A:    2-D, real, full matrix
     * %         logical, uint8, uint16, or double
     * %         no NaNs, no Infs
     * %         size(A,1) >= size(T,1)
     * %         size(A,2) >= size(T,2)
     * %
     * %   C:    double
     * %
     * [T, A, msg] = ParseInputs(varargin{:});
     */
    mlfAssign(
      &T,
      mlfNormxcorr2_ParseInputs(
        &A,
        &msg,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * if ~isempty(msg)
     */
    if (mclNotBool(mlfIsempty(mclVv(msg, "msg")))) {
        /*
         * error(msg)
         */
        mlfError(mclVv(msg, "msg"), NULL);
    /*
     * end
     */
    }
    /*
     * 
     * %   We normalize the cross correlation to get correlation coefficients using
     * %   the definition of Haralick and Shapiro, Volume II (p. 317), generalized
     * %   to two-dimensions.
     * 
     * xcorr_TA = xcorr2_fast(T,A);
     */
    mlfAssign(
      &xcorr_TA, mlfNormxcorr2_xcorr2_fast(mclVv(T, "T"), mclVv(A, "A")));
    /*
     * 
     * [m n] = size(T);
     */
    mlfSize(mlfVarargout(&m, &n, NULL), mclVv(T, "T"), NULL);
    /*
     * mn = m*n;
     */
    mlfAssign(&mn, mclMtimes(mclVv(m, "m"), mclVv(n, "n")));
    /*
     * 
     * local_sum_A = local_sum(A,m,n);
     */
    mlfAssign(
      &local_sum_A,
      mlfNormxcorr2_local_sum(mclVv(A, "A"), mclVv(m, "m"), mclVv(n, "n")));
    /*
     * local_sum_A2 = local_sum(A.*A,m,n);
     */
    mlfAssign(
      &local_sum_A2,
      mlfNormxcorr2_local_sum(
        mclTimes(mclVv(A, "A"), mclVv(A, "A")), mclVv(m, "m"), mclVv(n, "n")));
    /*
     * 
     * denom_A = sqrt( ( local_sum_A2 - (local_sum_A.^2)/mn ) / (mn-1) );
     */
    mlfAssign(
      &denom_A,
      mlfSqrt(
        mclMrdivide(
          mclMinus(
            mclVv(local_sum_A2, "local_sum_A2"),
            mclMrdivide(
              mlfPower(mclVv(local_sum_A, "local_sum_A"), _mxarray0_),
              mclVv(mn, "mn"))),
          mclMinus(mclVv(mn, "mn"), _mxarray1_))));
    /*
     * denom_T = std(T(:));
     */
    mlfAssign(
      &denom_T,
      mlfStd(mclArrayRef1(mclVv(T, "T"), mlfCreateColonIndex()), NULL, NULL));
    /*
     * denom = denom_T*denom_A;
     */
    mlfAssign(
      &denom, mclMtimes(mclVv(denom_T, "denom_T"), mclVv(denom_A, "denom_A")));
    /*
     * numerator = (xcorr_TA - local_sum_A*sum(T(:))/mn ) / (mn-1);
     */
    mlfAssign(
      &numerator,
      mclMrdivide(
        mclMinus(
          mclVv(xcorr_TA, "xcorr_TA"),
          mclMrdivide(
            mclMtimes(
              mclVv(local_sum_A, "local_sum_A"),
              mlfSum(mclArrayRef1(mclVv(T, "T"), mlfCreateColonIndex()), NULL)),
            mclVv(mn, "mn"))),
        mclMinus(mclVv(mn, "mn"), _mxarray1_)));
    /*
     * 
     * % We know denom_T~=0 from input parsing;
     * % so denom is only zero where denom_A is zero, and in 
     * % these locations, C is also zero.
     * C = zeros(size(numerator));
     */
    mlfAssign(
      &C,
      mlfZeros(
        mlfSize(mclValueVarargout(), mclVv(numerator, "numerator"), NULL),
        NULL));
    /*
     * i_nonzero = find(denom_A~=0);
     */
    mlfAssign(
      &i_nonzero,
      mlfFind(NULL, NULL, mclNe(mclVv(denom_A, "denom_A"), _mxarray2_)));
    /*
     * C(i_nonzero) = numerator(i_nonzero) ./ denom(i_nonzero);
     */
    mclArrayAssign1(
      &C,
      mclRdivide(
        mclArrayRef1(
          mclVv(numerator, "numerator"), mclVv(i_nonzero, "i_nonzero")),
        mclArrayRef1(mclVv(denom, "denom"), mclVv(i_nonzero, "i_nonzero"))),
      mclVv(i_nonzero, "i_nonzero"));
    mclValidateOutput(C, 1, nargout_, "C", "normxcorr2");
    mxDestroyArray(T);
    mxDestroyArray(A);
    mxDestroyArray(msg);
    mxDestroyArray(ans);
    mxDestroyArray(xcorr_TA);
    mxDestroyArray(m);
    mxDestroyArray(n);
    mxDestroyArray(mn);
    mxDestroyArray(local_sum_A);
    mxDestroyArray(local_sum_A2);
    mxDestroyArray(denom_A);
    mxDestroyArray(denom_T);
    mxDestroyArray(denom);
    mxDestroyArray(numerator);
    mxDestroyArray(i_nonzero);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return C;
    /*
     * 
     * %-------------------------------
     * % Function  local_sum
     * %
     */
}

/*
 * The function "Mnormxcorr2_local_sum" is the implementation version of the
 * "normxcorr2/local_sum" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 88-110). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function local_sum_A = local_sum(A,m,n)
 */
static mxArray * Mnormxcorr2_local_sum(int nargout_,
                                       mxArray * A,
                                       mxArray * m,
                                       mxArray * n) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * local_sum_A = NULL;
    mxArray * c = NULL;
    mxArray * s = NULL;
    mxArray * B = NULL;
    mxArray * nA = NULL;
    mxArray * mA = NULL;
    mclCopyArray(&A);
    mclCopyArray(&m);
    mclCopyArray(&n);
    /*
     * 
     * % We thank Eli Horn for providing this code, used with his permission,
     * % to speed up the calculation of local sums. The algorithm depends on
     * % precomputing running sums as described in "Fast Normalized
     * % Cross-Correlation", by J. P. Lewis, Industrial Light & Magic.
     * % http://www.idiom.com/~zilla/Papers/nvisionInterface/nip.html
     * 
     * [mA,nA]=size(A);
     */
    mlfSize(mlfVarargout(&mA, &nA, NULL), mclVa(A, "A"), NULL);
    /*
     * 
     * B = [zeros(m,nA+2*n-1);
     */
    mlfAssign(
      &B,
      mlfVertcat(
        mlfZeros(
          mclVa(m, "m"),
          mclMinus(
            mclPlus(mclVv(nA, "nA"), mclMtimes(_mxarray0_, mclVa(n, "n"))),
            _mxarray1_),
          NULL),
        mlfHorzcat(
          mlfZeros(mclVv(mA, "mA"), mclVa(n, "n"), NULL),
          mclVa(A, "A"),
          mlfZeros(mclVv(mA, "mA"), mclMinus(mclVa(n, "n"), _mxarray1_), NULL),
          NULL),
        mlfZeros(
          mclMinus(mclVa(m, "m"), _mxarray1_),
          mclMinus(
            mclPlus(mclVv(nA, "nA"), mclMtimes(_mxarray0_, mclVa(n, "n"))),
            _mxarray1_),
          NULL),
        NULL));
    /*
     * zeros(mA,n) A zeros(mA,n-1);
     * zeros(m-1,nA+2*n-1)];
     * s = cumsum(B,1);
     */
    mlfAssign(&s, mlfCumsum(mclVv(B, "B"), _mxarray1_));
    /*
     * c = s(1+m:end,:)-s(1:end-m,:);
     */
    mlfAssign(
      &c,
      mclMinus(
        mclArrayRef2(
          mclVv(s, "s"),
          mlfColon(
            mclPlus(_mxarray1_, mclVa(m, "m")),
            mlfEnd(mclVv(s, "s"), _mxarray1_, _mxarray0_),
            NULL),
          mlfCreateColonIndex()),
        mclArrayRef2(
          mclVv(s, "s"),
          mlfColon(
            _mxarray1_,
            mclMinus(
              mlfEnd(mclVv(s, "s"), _mxarray1_, _mxarray0_), mclVa(m, "m")),
            NULL),
          mlfCreateColonIndex())));
    /*
     * s = cumsum(c,2);
     */
    mlfAssign(&s, mlfCumsum(mclVv(c, "c"), _mxarray0_));
    /*
     * local_sum_A = s(:,1+n:end)-s(:,1:end-n);
     */
    mlfAssign(
      &local_sum_A,
      mclMinus(
        mclArrayRef2(
          mclVv(s, "s"),
          mlfCreateColonIndex(),
          mlfColon(
            mclPlus(_mxarray1_, mclVa(n, "n")),
            mlfEnd(mclVv(s, "s"), _mxarray0_, _mxarray0_),
            NULL)),
        mclArrayRef2(
          mclVv(s, "s"),
          mlfCreateColonIndex(),
          mlfColon(
            _mxarray1_,
            mclMinus(
              mlfEnd(mclVv(s, "s"), _mxarray0_, _mxarray0_), mclVa(n, "n")),
            NULL))));
    mclValidateOutput(
      local_sum_A, 1, nargout_, "local_sum_A", "normxcorr2/local_sum");
    mxDestroyArray(mA);
    mxDestroyArray(nA);
    mxDestroyArray(B);
    mxDestroyArray(s);
    mxDestroyArray(c);
    mxDestroyArray(n);
    mxDestroyArray(m);
    mxDestroyArray(A);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return local_sum_A;
    /*
     * 
     * 
     * %-------------------------------
     * % Function  xcorr2_fast
     * %
     */
}

/*
 * The function "Mnormxcorr2_xcorr2_fast" is the implementation version of the
 * "normxcorr2/xcorr2_fast" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 110-130). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function cross_corr = xcorr2_fast(T,A)
 */
static mxArray * Mnormxcorr2_xcorr2_fast(int nargout_,
                                         mxArray * T,
                                         mxArray * A) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * cross_corr = NULL;
    mxArray * fft_time = NULL;
    mxArray * conv_time = NULL;
    mxArray * outsize = NULL;
    mxArray * A_size = NULL;
    mxArray * T_size = NULL;
    mclCopyArray(&T);
    mclCopyArray(&A);
    /*
     * 
     * T_size = size(T);
     */
    mlfAssign(&T_size, mlfSize(mclValueVarargout(), mclVa(T, "T"), NULL));
    /*
     * A_size = size(A);
     */
    mlfAssign(&A_size, mlfSize(mclValueVarargout(), mclVa(A, "A"), NULL));
    /*
     * outsize = A_size + T_size - 1;
     */
    mlfAssign(
      &outsize,
      mclMinus(
        mclPlus(mclVv(A_size, "A_size"), mclVv(T_size, "T_size")), _mxarray1_));
    /*
     * 
     * % figure out when to use spatial domain vs. freq domain
     * conv_time = time_conv2(T_size,A_size); % 1 conv2
     */
    mlfAssign(
      &conv_time,
      mlfNormxcorr2_time_conv2(
        mclVv(T_size, "T_size"), mclVv(A_size, "A_size")));
    /*
     * fft_time = 3*time_fft2(outsize); % 2 fft2 + 1 ifft2
     */
    mlfAssign(
      &fft_time,
      mclMtimes(
        _mxarray3_, mlfNormxcorr2_time_fft2(mclVv(outsize, "outsize"))));
    /*
     * 
     * if (conv_time < fft_time)
     */
    if (mclLtBool(mclVv(conv_time, "conv_time"), mclVv(fft_time, "fft_time"))) {
        /*
         * cross_corr = conv2(rot90(T,2),A);
         */
        mlfAssign(
          &cross_corr,
          mlfConv2(
            mlfRot90(mclVa(T, "T"), _mxarray0_), mclVa(A, "A"), NULL, NULL));
    /*
     * else
     */
    } else {
        /*
         * cross_corr = freqxcorr(T,A,outsize);
         */
        mlfAssign(
          &cross_corr,
          mlfNormxcorr2_freqxcorr(
            mclVa(T, "T"), mclVa(A, "A"), mclVv(outsize, "outsize")));
    /*
     * end
     */
    }
    mclValidateOutput(
      cross_corr, 1, nargout_, "cross_corr", "normxcorr2/xcorr2_fast");
    mxDestroyArray(T_size);
    mxDestroyArray(A_size);
    mxDestroyArray(outsize);
    mxDestroyArray(conv_time);
    mxDestroyArray(fft_time);
    mxDestroyArray(A);
    mxDestroyArray(T);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return cross_corr;
    /*
     * 
     * 
     * %-------------------------------
     * % Function  freqxcorr
     * %
     */
}

/*
 * The function "Mnormxcorr2_freqxcorr" is the implementation version of the
 * "normxcorr2/freqxcorr" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 130-141). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function xcorr_ab = freqxcorr(a,b,outsize);
 */
static mxArray * Mnormxcorr2_freqxcorr(int nargout_,
                                       mxArray * a,
                                       mxArray * b,
                                       mxArray * outsize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * xcorr_ab = NULL;
    mxArray * Fb = NULL;
    mxArray * Fa = NULL;
    mclCopyArray(&a);
    mclCopyArray(&b);
    mclCopyArray(&outsize);
    /*
     * 
     * % calculate correlation in frequency domain
     * Fa = fft2(rot90(a,2),outsize(1),outsize(2));
     */
    mlfAssign(
      &Fa,
      mlfFft2(
        mlfRot90(mclVa(a, "a"), _mxarray0_),
        mclIntArrayRef1(mclVa(outsize, "outsize"), 1),
        mclIntArrayRef1(mclVa(outsize, "outsize"), 2)));
    /*
     * Fb = fft2(b,outsize(1),outsize(2));
     */
    mlfAssign(
      &Fb,
      mlfFft2(
        mclVa(b, "b"),
        mclIntArrayRef1(mclVa(outsize, "outsize"), 1),
        mclIntArrayRef1(mclVa(outsize, "outsize"), 2)));
    /*
     * xcorr_ab = real(ifft2(Fa .* Fb));
     */
    mlfAssign(
      &xcorr_ab,
      mlfReal(
        mlfIfft2(mclTimes(mclVv(Fa, "Fa"), mclVv(Fb, "Fb")), NULL, NULL)));
    mclValidateOutput(
      xcorr_ab, 1, nargout_, "xcorr_ab", "normxcorr2/freqxcorr");
    mxDestroyArray(Fa);
    mxDestroyArray(Fb);
    mxDestroyArray(outsize);
    mxDestroyArray(b);
    mxDestroyArray(a);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return xcorr_ab;
    /*
     * 
     * 
     * %-------------------------------
     * % Function  time_conv2
     * %
     */
}

/*
 * The function "Mnormxcorr2_time_conv2" is the implementation version of the
 * "normxcorr2/time_conv2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 141-173). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function time = time_conv2(obssize,refsize)
 */
static mxArray * Mnormxcorr2_time_conv2(int nargout_,
                                        mxArray * obssize,
                                        mxArray * refsize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * time = NULL;
    mxArray * K = NULL;
    mclCopyArray(&obssize);
    mclCopyArray(&refsize);
    /*
     * 
     * % time a spatial domain convolution for 10-by-10 x 20-by-20 matrices
     * 
     * % a = ones(10);
     * % b = ones(20);
     * % mintime = 0.1;
     * 
     * % t1 = cputime;
     * % t2 = t1;
     * % k = 0;
     * % while (t2-t1)<mintime
     * %     c = conv2(a,b);
     * %     k = k + 1;
     * %     t2 = cputime;
     * % end
     * % t_total = (t2-t1)/k;
     * 
     * % % convolution time = K*prod(size(a))*prod(size(b))
     * % % t_total = K*10*10*20*20 = 40000*K
     * % K = t_total/40000;
     * 
     * % K was empirically calculated by the commented-out code above.
     * K = 2.7e-8; 
     */
    mlfAssign(&K, _mxarray4_);
    /*
     * 
     * % convolution time = K*prod(obssize)*prod(refsize)
     * time =  K*prod(obssize)*prod(refsize);
     */
    mlfAssign(
      &time,
      mclMtimes(
        mclMtimes(mclVv(K, "K"), mlfProd(mclVa(obssize, "obssize"), NULL)),
        mlfProd(mclVa(refsize, "refsize"), NULL)));
    mclValidateOutput(time, 1, nargout_, "time", "normxcorr2/time_conv2");
    mxDestroyArray(K);
    mxDestroyArray(refsize);
    mxDestroyArray(obssize);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return time;
    /*
     * 
     * 
     * %-------------------------------
     * % Function  time_fft2
     * %
     */
}

/*
 * The function "Mnormxcorr2_time_fft2" is the implementation version of the
 * "normxcorr2/time_fft2" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 173-199). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function time = time_fft2(outsize)
 */
static mxArray * Mnormxcorr2_time_fft2(int nargout_, mxArray * outsize) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * time = NULL;
    mxArray * Ts = NULL;
    mxArray * Tr = NULL;
    mxArray * K_fft = NULL;
    mxArray * S = NULL;
    mxArray * R = NULL;
    mclCopyArray(&outsize);
    /*
     * 
     * % time a frequency domain convolution by timing two one-dimensional ffts
     * 
     * R = outsize(1);
     */
    mlfAssign(&R, mclIntArrayRef1(mclVa(outsize, "outsize"), 1));
    /*
     * S = outsize(2);
     */
    mlfAssign(&S, mclIntArrayRef1(mclVa(outsize, "outsize"), 2));
    /*
     * 
     * % Tr = time_fft(R);
     * % K_fft = Tr/(R*log(R)); 
     * 
     * % K_fft was empirically calculated by the 2 commented-out lines above.
     * K_fft = 3.3e-7; 
     */
    mlfAssign(&K_fft, _mxarray5_);
    /*
     * Tr = K_fft*R*log(R);
     */
    mlfAssign(
      &Tr,
      mclMtimes(
        mclMtimes(mclVv(K_fft, "K_fft"), mclVv(R, "R")),
        mlfLog(mclVv(R, "R"))));
    /*
     * 
     * if S==R
     */
    if (mclEqBool(mclVv(S, "S"), mclVv(R, "R"))) {
        /*
         * Ts = Tr;
         */
        mlfAssign(&Ts, mclVv(Tr, "Tr"));
    /*
     * else
     */
    } else {
        /*
         * %    Ts = time_fft(S);  % uncomment to estimate explicitly
         * Ts = K_fft*S*log(S); 
         */
        mlfAssign(
          &Ts,
          mclMtimes(
            mclMtimes(mclVv(K_fft, "K_fft"), mclVv(S, "S")),
            mlfLog(mclVv(S, "S"))));
    /*
     * end
     */
    }
    /*
     * 
     * time = S*Tr + R*Ts;
     */
    mlfAssign(
      &time,
      mclPlus(
        mclMtimes(mclVv(S, "S"), mclVv(Tr, "Tr")),
        mclMtimes(mclVv(R, "R"), mclVv(Ts, "Ts"))));
    mclValidateOutput(time, 1, nargout_, "time", "normxcorr2/time_fft2");
    mxDestroyArray(R);
    mxDestroyArray(S);
    mxDestroyArray(K_fft);
    mxDestroyArray(Tr);
    mxDestroyArray(Ts);
    mxDestroyArray(outsize);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return time;
    /*
     * 
     * %-------------------------------
     * % Function time_fft
     * %
     */
}

/*
 * The function "Mnormxcorr2_time_fft" is the implementation version of the
 * "normxcorr2/time_fft" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 199-220). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function T = time_fft(M)
 */
static mxArray * Mnormxcorr2_time_fft(int nargout_, mxArray * M) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    mxArray * T = NULL;
    mxArray * dummy = NULL;
    mxArray * k = NULL;
    mxArray * t2 = NULL;
    mxArray * t1 = NULL;
    mxArray * mintime = NULL;
    mxArray * vec = NULL;
    mclCopyArray(&M);
    /*
     * 
     * % time a complex fft that is M elements long
     * 
     * vec = complex(ones(M,1),ones(M,1));
     */
    mlfAssign(
      &vec,
      mlfComplex(
        mlfOnes(mclVa(M, "M"), _mxarray1_, NULL),
        mlfOnes(mclVa(M, "M"), _mxarray1_, NULL)));
    /*
     * mintime = 0.1; 
     */
    mlfAssign(&mintime, _mxarray6_);
    /*
     * 
     * t1 = cputime;
     */
    mlfAssign(&t1, mlfCputime());
    /*
     * t2 = t1;
     */
    mlfAssign(&t2, mclVv(t1, "t1"));
    /*
     * k = 0;
     */
    mlfAssign(&k, _mxarray2_);
    /*
     * while (t2-t1) < mintime
     */
    while (mclLtBool(
             mclMinus(mclVv(t2, "t2"), mclVv(t1, "t1")),
             mclVv(mintime, "mintime"))) {
        /*
         * dummy = fft(vec);
         */
        mlfAssign(&dummy, mlfFft(mclVv(vec, "vec"), NULL, NULL));
        /*
         * k = k + 1;
         */
        mlfAssign(&k, mclPlus(mclVv(k, "k"), _mxarray1_));
        /*
         * t2 = cputime;
         */
        mlfAssign(&t2, mlfCputime());
    /*
     * end
     */
    }
    /*
     * T = (t2-t1)/k;
     */
    mlfAssign(
      &T,
      mclMrdivide(mclMinus(mclVv(t2, "t2"), mclVv(t1, "t1")), mclVv(k, "k")));
    mclValidateOutput(T, 1, nargout_, "T", "normxcorr2/time_fft");
    mxDestroyArray(vec);
    mxDestroyArray(mintime);
    mxDestroyArray(t1);
    mxDestroyArray(t2);
    mxDestroyArray(k);
    mxDestroyArray(dummy);
    mxDestroyArray(M);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return T;
    /*
     * 
     * 
     * %-------------------------------
     * % Function  ParseInputs
     * %
     */
}

/*
 * The function "Mnormxcorr2_ParseInputs" is the implementation version of the
 * "normxcorr2/ParseInputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\normxcorr2.m" (lines 220-267). It
 * contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function [T, A, msg] = ParseInputs(varargin)
 */
static mxArray * Mnormxcorr2_ParseInputs(mxArray * * A,
                                         mxArray * * msg,
                                         int nargout_,
                                         mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_normxcorr2);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * T = NULL;
    mclCopyArray(&varargin);
    /*
     * 
     * % defaults
     * T = [];
     */
    mlfAssign(&T, _mxarray7_);
    /*
     * A = [];
     */
    mlfAssign(A, _mxarray7_);
    /*
     * msg = '';
     */
    mlfAssign(msg, _mxarray8_);
    /*
     * 
     * msg = nargchk(2,2,nargin);
     */
    mlfAssign(msg, mlfNargchk(_mxarray0_, _mxarray0_, mlfScalar(nargin_)));
    /*
     * if ~isempty(msg);
     */
    if (mclNotBool(mlfIsempty(mclVv(*msg, "msg")))) {
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * T = varargin{1};
     */
    mlfAssign(&T, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
    /*
     * A = varargin{2};
     */
    mlfAssign(A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
    /*
     * 
     * if (~islogical(T) & ~isnumeric(T)) | ~isreal(T) | issparse(T) | ndims(T)~=2
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIslogical(mclVv(T, "T"))));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mclAnd(a_, mclNot(mlfIsnumeric(mclVv(T, "T")))));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVv(T, "T")))));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mlfIssparse(mclVv(T, "T"))));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(a_, mclNe(mlfNdims(mclVv(T, "T")), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * msg = 'TEMPLATE must be a 2-D, real, full matrix.';
             */
            mlfAssign(msg, _mxarray9_);
            /*
             * return;
             */
            goto return_;
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if (~islogical(A) & ~isnumeric(A)) | ~isreal(A) | issparse(A) | ndims(A)~=2  
     */
    {
        mxArray * a_ = mclInitialize(mclNot(mlfIslogical(mclVv(*A, "A"))));
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mclAnd(a_, mclNot(mlfIsnumeric(mclVv(*A, "A")))));
        } else {
            mlfAssign(&a_, mlfScalar(0));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mclNot(mlfIsreal(mclVv(*A, "A")))));
        }
        if (mlfTobool(a_)) {
            mlfAssign(&a_, mlfScalar(1));
        } else {
            mlfAssign(&a_, mclOr(a_, mlfIssparse(mclVv(*A, "A"))));
        }
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(a_, mclNe(mlfNdims(mclVv(*A, "A")), _mxarray0_)))) {
            mxDestroyArray(a_);
            /*
             * msg = 'A must be a 2-D, real, full matrix.';
             */
            mlfAssign(msg, _mxarray11_);
            /*
             * return;
             */
            goto return_;
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * T = double(T);
     */
    mlfAssign(&T, mlfDouble(mclVv(T, "T")));
    /*
     * A = double(A);
     */
    mlfAssign(A, mlfDouble(mclVv(*A, "A")));
    /*
     * 
     * if any(~isfinite(T(:))) | any(~isfinite(A(:)))
     */
    {
        mxArray * a_
          = mclInitialize(
              mlfAny(
                mclNot(
                  mlfIsfinite(
                    mclArrayRef1(mclVv(T, "T"), mlfCreateColonIndex()))),
                NULL));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mlfAny(
                     mclNot(
                       mlfIsfinite(
                         mclArrayRef1(mclVv(*A, "A"), mlfCreateColonIndex()))),
                     NULL)))) {
            mxDestroyArray(a_);
            /*
             * msg = 'TEMPLATE and A may not contain NaN or Inf.';
             */
            mlfAssign(msg, _mxarray13_);
            /*
             * return;
             */
            goto return_;
        } else {
            mxDestroyArray(a_);
        }
    /*
     * end
     */
    }
    /*
     * 
     * if prod(size(T)) < 2
     */
    if (mclLtBool(
          mlfProd(mlfSize(mclValueVarargout(), mclVv(T, "T"), NULL), NULL),
          _mxarray0_)) {
        /*
         * msg = 'TEMPLATE must contain at least 2 elements.';
         */
        mlfAssign(msg, _mxarray15_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if std(T(:)) == 0
     */
    if (mclEqBool(
          mlfStd(
            mclArrayRef1(mclVv(T, "T"), mlfCreateColonIndex()), NULL, NULL),
          _mxarray2_)) {
        /*
         * msg = 'The values of TEMPLATE cannot all be the same.';
         */
        mlfAssign(msg, _mxarray17_);
        /*
         * return;
         */
        goto return_;
    /*
     * end
     */
    }
    /*
     * 
     * if size(A,1)<size(T,1) | size(A,2)<size(T,2) 
     */
    {
        mxArray * a_
          = mclInitialize(
              mclLt(
                mlfSize(mclValueVarargout(), mclVv(*A, "A"), _mxarray1_),
                mlfSize(mclValueVarargout(), mclVv(T, "T"), _mxarray1_)));
        if (mlfTobool(a_)
            || mlfTobool(
                 mclOr(
                   a_,
                   mclLt(
                     mlfSize(mclValueVarargout(), mclVv(*A, "A"), _mxarray0_),
                     mlfSize(
                       mclValueVarargout(), mclVv(T, "T"), _mxarray0_))))) {
            mxDestroyArray(a_);
            /*
             * msg = 'A must be the same size or larger than TEMPLATE.';
             */
            mlfAssign(msg, _mxarray19_);
        } else {
            mxDestroyArray(a_);
        }
    /*
     * return;
     * end
     */
    }
    return_:
    mclValidateOutput(T, 1, nargout_, "T", "normxcorr2/ParseInputs");
    mclValidateOutput(*A, 2, nargout_, "A", "normxcorr2/ParseInputs");
    mclValidateOutput(*msg, 3, nargout_, "msg", "normxcorr2/ParseInputs");
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return T;
}
