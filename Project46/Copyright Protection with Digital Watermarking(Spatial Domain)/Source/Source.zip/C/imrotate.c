/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 15 00:54:06 2004
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-m" "-W" "main" "-L"
 * "C" "-t" "-T" "link:exe" "-h" "libmmfile.mlib" "-W" "mainhg"
 * "libmwsglm.mlib" "watermark005" 
 */
#include "imrotate.h"
#include "fliptform.h"
#include "imshow.h"
#include "libmatlbm.h"
#include "libmmfile.h"
#include "makeresampler.h"
#include "maketform.h"
#include "tformarray.h"
#include "tformfwd.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static double _array6_[4] = { 0.0, 1.0, 2.0, 3.0 };
static mxArray * _mxarray5_;

static mxChar _array10_[1] = { ':' };
static mxArray * _mxarray9_;

static mxArray * _array8_[3] = { NULL /*_mxarray9_*/, NULL /*_mxarray9_*/,
                                 NULL /*_mxarray9_*/ };
static mxArray * _mxarray7_;

static double _array12_[2] = { 2.0, 4.0 };
static mxArray * _mxarray11_;

static mxChar _array14_[1] = { 'c' };
static mxArray * _mxarray13_;
static mxArray * _mxarray15_;
static mxArray * _mxarray16_;
static mxArray * _mxarray17_;
static mxArray * _mxarray18_;
static mxArray * _mxarray19_;

static mxChar _array21_[6] = { 'a', 'f', 'f', 'i', 'n', 'e' };
static mxArray * _mxarray20_;

static double _array23_[3] = { 0.0, 0.0, 1.0 };
static mxArray * _mxarray22_;

static mxChar _array25_[1] = { 'l' };
static mxArray * _mxarray24_;

static mxChar _array27_[3] = { 'b', 'o', 'x' };
static mxArray * _mxarray26_;

static mxChar _array29_[9] = { 'c', 'o', 'm', 'p', 'o', 's', 'i', 't', 'e' };
static mxArray * _mxarray28_;

static mxChar _array31_[7] = { 'b', 'i', 'c', 'u', 'b', 'i', 'c' };
static mxArray * _mxarray30_;

static mxChar _array33_[5] = { 'c', 'u', 'b', 'i', 'c' };
static mxArray * _mxarray32_;

static mxChar _array35_[4] = { 'f', 'i', 'l', 'l' };
static mxArray * _mxarray34_;

static mxChar _array37_[8] = { 'b', 'i', 'l', 'i', 'n', 'e', 'a', 'r' };
static mxArray * _mxarray36_;

static mxChar _array39_[6] = { 'l', 'i', 'n', 'e', 'a', 'r' };
static mxArray * _mxarray38_;

static mxChar _array41_[7] = { 'n', 'e', 'a', 'r', 'e', 's', 't' };
static mxArray * _mxarray40_;

static double _array43_[2] = { 1.0, 2.0 };
static mxArray * _mxarray42_;

static mxChar _array45_[110] = { 'O', 'b', 's', 'o', 'l', 'e', 't', 'e', ' ',
                                 's', 'y', 'n', 't', 'a', 'x', '.', ' ', 'I',
                                 'n', ' ', 'f', 'u', 't', 'u', 'r', 'e', ' ',
                                 'v', 'e', 'r', 's', 'i', 'o', 'n', 's', ' ',
                                 'I', 'M', 'R', 'O', 'T', 'A', 'T', 'E', ' ',
                                 'w', 'i', 'l', 'l', ' ', 'r', 'e', 't', 'u',
                                 'r', 'n', ' ', 't', 'h', 'e', ' ', 'r', 'e',
                                 's', 'u', 'l', 't', ' ', 'i', 'n', ' ', 'a',
                                 'n', 's', ' ', 'i', 'n', 's', 't', 'e', 'a',
                                 'd', ' ', 'o', 'f', ' ', 'd', 'i', 's', 'p',
                                 'l', 'a', 'y', 'i', 'n', 'g', ' ', 'i', 't',
                                 ' ', 'i', 'n', ' ', 'f', 'i', 'g', 'u', 'r',
                                 'e', '.' };
static mxArray * _mxarray44_;

static mxChar _array47_[115] = { '[', 'R', ',', 'G', ',', 'B', ']', ' ', '=',
                                 ' ', 'I', 'M', 'R', 'O', 'T', 'A', 'T', 'E',
                                 '(', 'R', 'G', 'B', ')', ' ', 'i', 's', ' ',
                                 'a', 'n', ' ', 'o', 'b', 's', 'o', 'l', 'e',
                                 't', 'e', ' ', 'o', 'u', 't', 'p', 'u', 't',
                                 ' ', 's', 'y', 'n', 't', 'a', 'x', '.', ' ',
                                 'U', 's', 'e', ' ', 'o', 'n', 'e', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', ' ', 'a', 'r', 'g',
                                 'u', 'm', 'e', 'n', 't', ' ', 't', 'h', 'e',
                                 ' ', 'r', 'e', 'c', 'e', 'i', 'v', 'e', ' ',
                                 't', 'h', 'e', ' ', '3', '-', 'D', ' ', 'o',
                                 'u', 't', 'p', 'u', 't', ' ', 'R', 'G', 'B',
                                 ' ', 'i', 'm', 'a', 'g', 'e', '.' };
static mxArray * _mxarray46_;

static mxChar _array49_[35] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ', 'n',
                                'u', 'm', 'b', 'e', 'r', ' ', 'o', 'f', ' ',
                                'o', 'u', 't', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray48_;

static mxChar _array51_[1] = { 'n' };
static mxArray * _mxarray50_;
static mxArray * _mxarray52_;

static mxChar _array54_[24] = { 'I', 'n', 'v', 'a', 'l', 'i', 'd', ' ',
                                'i', 'n', 'p', 'u', 't', ' ', 'a', 'r',
                                'g', 'u', 'm', 'e', 'n', 't', 's', '.' };
static mxArray * _mxarray53_;

static mxChar _array58_[4] = { 'c', 'r', 'o', 'p' };
static mxArray * _mxarray57_;

static mxChar _array60_[5] = { 'l', 'o', 'o', 's', 'e' };
static mxArray * _mxarray59_;

static mxArray * _array56_[5] = { NULL /*_mxarray40_*/, NULL /*_mxarray36_*/,
                                  NULL /*_mxarray30_*/, NULL /*_mxarray57_*/,
                                  NULL /*_mxarray59_*/ };
static mxArray * _mxarray55_;

static mxChar _array62_[32] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ',
                                'i', 'n', 't', 'e', 'r', 'p', 'o', 'l',
                                'a', 't', 'i', 'o', 'n', ' ', 'm', 'e',
                                't', 'h', 'o', 'd', ':', ' ', '%', 's' };
static mxArray * _mxarray61_;

static mxChar _array64_[34] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                ' ', 'i', 'n', 't', 'e', 'r', 'p', 'o', 'l',
                                'a', 't', 'i', 'o', 'n', ' ', 'm', 'e', 't',
                                'h', 'o', 'd', ':', ' ', '%', 's' };
static mxArray * _mxarray63_;
static mxArray * _mxarray65_;

static mxChar _array67_[26] = { 'U', 'n', 'k', 'n', 'o', 'w', 'n', ' ', 'B',
                                'B', 'O', 'X', ' ', 'p', 'a', 'r', 'a', 'm',
                                'e', 't', 'e', 'r', ':', ' ', '%', 's' };
static mxArray * _mxarray66_;

static mxChar _array69_[25] = { 'A', 'm', 'b', 'i', 'g', 'u', 'o', 'u', 's',
                                ' ', 'B', 'B', 'O', 'X', ' ', 's', 't', 'r',
                                'i', 'n', 'g', ':', ' ', '%', 's' };
static mxArray * _mxarray68_;

static mxChar _array71_[50] = { 'I', 'n', 't', 'e', 'r', 'p', 'o', 'l', 'a',
                                't', 'i', 'o', 'n', ' ', 'm', 'e', 't', 'h',
                                'o', 'd', ' ', 'a', 'n', 'd', ' ', 'B', 'B',
                                'O', 'X', ' ', 'h', 'a', 'v', 'e', ' ', 't',
                                'o', ' ', 'b', 'e', ' ', 'a', ' ', 's', 't',
                                'r', 'i', 'n', 'g', '.' };
static mxArray * _mxarray70_;

void InitializeModule_imrotate(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeDouble(90.0);
    _mxarray3_ = mclInitializeDouble(0.0);
    _mxarray4_ = mclInitializeDouble(360.0);
    _mxarray5_ = mclInitializeDoubleVector(1, 4, _array6_);
    _mxarray9_ = mclInitializeString(1, _array10_);
    _array8_[0] = _mxarray9_;
    _array8_[1] = _mxarray9_;
    _array8_[2] = _mxarray9_;
    _mxarray7_ = mclInitializeCellVector(1, 3, _array8_);
    _mxarray11_ = mclInitializeDoubleVector(1, 2, _array12_);
    _mxarray13_ = mclInitializeString(1, _array14_);
    _mxarray15_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray16_ = mclInitializeDouble(3.0);
    _mxarray17_ = mclInitializeDouble(-1.0);
    _mxarray18_ = mclInitializeDouble(3.141592653589793);
    _mxarray19_ = mclInitializeDouble(180.0);
    _mxarray20_ = mclInitializeString(6, _array21_);
    _mxarray22_ = mclInitializeDoubleVector(1, 3, _array23_);
    _mxarray24_ = mclInitializeString(1, _array25_);
    _mxarray26_ = mclInitializeString(3, _array27_);
    _mxarray28_ = mclInitializeString(9, _array29_);
    _mxarray30_ = mclInitializeString(7, _array31_);
    _mxarray32_ = mclInitializeString(5, _array33_);
    _mxarray34_ = mclInitializeString(4, _array35_);
    _mxarray36_ = mclInitializeString(8, _array37_);
    _mxarray38_ = mclInitializeString(6, _array39_);
    _mxarray40_ = mclInitializeString(7, _array41_);
    _mxarray42_ = mclInitializeDoubleVector(1, 2, _array43_);
    _mxarray44_ = mclInitializeString(110, _array45_);
    _mxarray46_ = mclInitializeString(115, _array47_);
    _mxarray48_ = mclInitializeString(35, _array49_);
    _mxarray50_ = mclInitializeString(1, _array51_);
    _mxarray52_ = mclInitializeDouble(4.0);
    _mxarray53_ = mclInitializeString(24, _array54_);
    _array56_[0] = _mxarray40_;
    _array56_[1] = _mxarray36_;
    _array56_[2] = _mxarray30_;
    _mxarray57_ = mclInitializeString(4, _array58_);
    _array56_[3] = _mxarray57_;
    _mxarray59_ = mclInitializeString(5, _array60_);
    _array56_[4] = _mxarray59_;
    _mxarray55_ = mclInitializeCellVector(1, 5, _array56_);
    _mxarray61_ = mclInitializeString(32, _array62_);
    _mxarray63_ = mclInitializeString(34, _array64_);
    _mxarray65_ = mclInitializeDouble(5.0);
    _mxarray66_ = mclInitializeString(26, _array67_);
    _mxarray68_ = mclInitializeString(25, _array69_);
    _mxarray70_ = mclInitializeString(50, _array71_);
}

void TerminateModule_imrotate(void) {
    mxDestroyArray(_mxarray70_);
    mxDestroyArray(_mxarray68_);
    mxDestroyArray(_mxarray66_);
    mxDestroyArray(_mxarray65_);
    mxDestroyArray(_mxarray63_);
    mxDestroyArray(_mxarray61_);
    mxDestroyArray(_mxarray55_);
    mxDestroyArray(_mxarray59_);
    mxDestroyArray(_mxarray57_);
    mxDestroyArray(_mxarray53_);
    mxDestroyArray(_mxarray52_);
    mxDestroyArray(_mxarray50_);
    mxDestroyArray(_mxarray48_);
    mxDestroyArray(_mxarray46_);
    mxDestroyArray(_mxarray44_);
    mxDestroyArray(_mxarray42_);
    mxDestroyArray(_mxarray40_);
    mxDestroyArray(_mxarray38_);
    mxDestroyArray(_mxarray36_);
    mxDestroyArray(_mxarray34_);
    mxDestroyArray(_mxarray32_);
    mxDestroyArray(_mxarray30_);
    mxDestroyArray(_mxarray28_);
    mxDestroyArray(_mxarray26_);
    mxDestroyArray(_mxarray24_);
    mxDestroyArray(_mxarray22_);
    mxDestroyArray(_mxarray20_);
    mxDestroyArray(_mxarray19_);
    mxDestroyArray(_mxarray18_);
    mxDestroyArray(_mxarray17_);
    mxDestroyArray(_mxarray16_);
    mxDestroyArray(_mxarray15_);
    mxDestroyArray(_mxarray13_);
    mxDestroyArray(_mxarray11_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray9_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfImrotate_parse_inputs(mxArray * * ang,
                                          mxArray * * method,
                                          mxArray * * bbox,
                                          ...);
static void mlxImrotate_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]);
static mxArray * Mimrotate(int nargout_, mxArray * varargin);
static mxArray * Mimrotate_parse_inputs(mxArray * * ang,
                                        mxArray * * method,
                                        mxArray * * bbox,
                                        int nargout_,
                                        mxArray * varargin);

static mexFunctionTableEntry local_function_table_[1]
  = { { "parse_inputs", mlxImrotate_parse_inputs, -1, 4, NULL } };

_mexLocalFunctionTable _local_function_table_imrotate
  = { 1, local_function_table_ };

/*
 * The function "mlfNImrotate" contains the nargout interface for the
 * "imrotate" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines 1-137). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNImrotate(int nargout, mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimrotate(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfImrotate" contains the normal interface for the "imrotate"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines
 * 1-137). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfImrotate(mlfVarargoutList * varargout, ...) {
    mxArray * varargin = NULL;
    int nargout = 0;
    mlfVarargin(&varargin, varargout, 0);
    mlfEnterNewContext(0, -1, varargin);
    nargout += mclNargout(varargout);
    *mlfGetVarargoutCellPtr(varargout) = Mimrotate(nargout, varargin);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
    return mlfAssignOutputs(varargout);
}

/*
 * The function "mlfVImrotate" contains the void interface for the "imrotate"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines
 * 1-137). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVImrotate(mxArray * synthetic_varargin_argument, ...) {
    mxArray * varargin = NULL;
    mxArray * varargout = NULL;
    mlfVarargin(&varargin, synthetic_varargin_argument, 1);
    mlfEnterNewContext(0, -1, varargin);
    varargout = Mimrotate(0, synthetic_varargin_argument);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(varargin);
}

/*
 * The function "mlxImrotate" contains the feval interface for the "imrotate"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines
 * 1-137). The feval function calls the implementation version of imrotate
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxImrotate(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[1];
    int i;
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0] = Mimrotate(nlhs, mprhs[0]);
    mclAssignVarargoutCell(0, nlhs, plhs, mplhs[0]);
    mlfRestorePreviousContext(0, 0);
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "mlfImrotate_parse_inputs" contains the normal interface for
 * the "imrotate/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines 137-190). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
static mxArray * mlfImrotate_parse_inputs(mxArray * * ang,
                                          mxArray * * method,
                                          mxArray * * bbox,
                                          ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * A = NULL;
    mxArray * ang__ = NULL;
    mxArray * method__ = NULL;
    mxArray * bbox__ = NULL;
    mlfVarargin(&varargin, bbox, 0);
    mlfEnterNewContext(3, -1, ang, method, bbox, varargin);
    if (ang != NULL) {
        ++nargout;
    }
    if (method != NULL) {
        ++nargout;
    }
    if (bbox != NULL) {
        ++nargout;
    }
    A = Mimrotate_parse_inputs(&ang__, &method__, &bbox__, nargout, varargin);
    mlfRestorePreviousContext(3, 0, ang, method, bbox);
    mxDestroyArray(varargin);
    if (ang != NULL) {
        mclCopyOutputArg(ang, ang__);
    } else {
        mxDestroyArray(ang__);
    }
    if (method != NULL) {
        mclCopyOutputArg(method, method__);
    } else {
        mxDestroyArray(method__);
    }
    if (bbox != NULL) {
        mclCopyOutputArg(bbox, bbox__);
    } else {
        mxDestroyArray(bbox__);
    }
    return mlfReturnValue(A);
}

/*
 * The function "mlxImrotate_parse_inputs" contains the feval interface for the
 * "imrotate/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines 137-190). The feval
 * function calls the implementation version of imrotate/parse_inputs through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
static void mlxImrotate_parse_inputs(int nlhs,
                                     mxArray * plhs[],
                                     int nrhs,
                                     mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: imrotate/parse_inputs Line: 137 Co"
            "lumn: 1 The function \"imrotate/parse_inputs\" was calle"
            "d with more than the declared number of outputs (4)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    mlfEnterNewContext(0, 0);
    mprhs[0] = NULL;
    mlfAssign(&mprhs[0], mclCreateVararginCell(nrhs, prhs));
    mplhs[0]
      = Mimrotate_parse_inputs(
          &mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 0);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[0]);
}

/*
 * The function "Mimrotate" is the implementation version of the "imrotate"
 * M-function from file "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines
 * 1-137). It contains the actual compiled code for that M-function. It is a
 * static function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function varargout = imrotate(varargin)
 */
static mxArray * Mimrotate(int nargout_, mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imrotate);
    mxArray * varargout = NULL;
    mxArray * ans = NULL;
    mxArray * R = NULL;
    mxArray * T = NULL;
    mxArray * boxB = NULL;
    mxArray * boxA = NULL;
    mxArray * sn = NULL;
    mxArray * loB = NULL;
    mxArray * hiB = NULL;
    mxArray * loA = NULL;
    mxArray * hiA = NULL;
    mxArray * rotate = NULL;
    mxArray * k = NULL;
    mxArray * vec = NULL;
    mxArray * imbegin = NULL;
    mxArray * B = NULL;
    mxArray * v = NULL;
    mxArray * drec = NULL;
    mxArray * phi = NULL;
    mxArray * thirdD = NULL;
    mxArray * so = NULL;
    mxArray * bbox = NULL;
    mxArray * method = NULL;
    mxArray * ang = NULL;
    mxArray * A = NULL;
    mclCopyArray(&varargin);
    /*
     * %IMROTATE Rotate image.
     * %   B = IMROTATE(A,ANGLE,METHOD) rotates the image A by ANGLE
     * %   degrees in a counter-clockwise direction, using the specified
     * %   interpolation method. METHOD is a string that can have one of
     * %   these values:
     * %
     * %        'nearest'  (default) nearest neighbor interpolation
     * %
     * %        'bilinear' bilinear interpolation
     * %
     * %        'bicubic'  bicubic interpolation
     * %
     * %   If you omit the METHOD argument, IMROTATE uses the default
     * %   method of 'nearest'. To rotate the image clockwise, specify a
     * %   negative angle.
     * %
     * %   B = IMROTATE(A,ANGLE,METHOD,BBOX) rotates the image A through ANGLE
     * %   degrees. The bounding box of the image is set by the BBOX argument, a
     * %   string that can be 'loose' (default) or 'crop'. When BBOX is 'loose', B
     * %   includes the whole rotated image, which generally is larger than A. When
     * %   BBOX is 'crop' B is cropped to include only the central portion of the
     * %   rotated image and is the same size as A. If you omit the BBOX argument,
     * %   IMROTATE uses the default 'loose' bounding box.
     * %
     * %   IMROTATE sets invalid values on the periphery of B to 0. 
     * %
     * %   Class Support
     * %   -------------
     * %   The input image can be of class logical, uint8, uint16, or
     * %   double. The output image is of the same class as the input
     * %   image.
     * %
     * %   Example
     * %   -------
     * %        I = imread('ic.tif');
     * %        J = imrotate(I,-3,'bilinear','crop');
     * %        imshow(I), figure, imshow(J)
     * %
     * %   See also IMCROP, IMRESIZE, IMTRANSFORM, TFORMARRAY.
     * 
     * %   Copyright 1993-2002 The MathWorks, Inc.  
     * %   $Revision: 5.25 $  $Date: 2002/03/15 15:28:17 $
     * 
     * % Grandfathered:
     * %   Without output arguments, IMROTATE(...) displays the rotated
     * %   image in the current axis.  
     * 
     * [A,ang,method,bbox] = parse_inputs(varargin{:});
     */
    mlfAssign(
      &A,
      mlfImrotate_parse_inputs(
        &ang,
        &method,
        &bbox,
        mlfIndexRef(mclVa(varargin, "varargin"), "{?}", mlfCreateColonIndex()),
        NULL));
    /*
     * 
     * [so(1) so(2) thirdD] = size(A);
     */
    mlfSize(
      mlfIndexVarargout(
        &so, "(?)", _mxarray0_, &so, "(?)", _mxarray1_, &thirdD, "", NULL),
      mclVv(A, "A"),
      NULL);
    /*
     * 
     * if rem(ang,90)==0,% Catch and speed up 90 degree rotations
     */
    if (mclEqBool(mlfRem(mclVv(ang, "ang"), _mxarray2_), _mxarray3_)) {
        /*
         * phi = round(ang - 360*floor(ang/360));% remove 2pi rotations
         */
        mlfAssign(
          &phi,
          mlfRound(
            mclMinus(
              mclVv(ang, "ang"),
              mclMtimes(
                _mxarray4_,
                mlfFloor(mclMrdivide(mclVv(ang, "ang"), _mxarray4_))))));
        /*
         * drec = find(phi/90==[0:3]);
         */
        mlfAssign(
          &drec,
          mlfFind(
            NULL,
            NULL,
            mclEq(mclMrdivide(mclVv(phi, "phi"), _mxarray2_), _mxarray5_)));
        /*
         * v = {':',':',':'};
         */
        mlfAssign(&v, _mxarray7_);
        /*
         * if any(drec==[2 4]),% +- 90 deg rotation
         */
        if (mlfTobool(mlfAny(mclEq(mclVv(drec, "drec"), _mxarray11_), NULL))) {
            /*
             * if (bbox(1)=='c')&(so(1)~=so(2)),%crop non-square image
             */
            mxArray * a_
              = mclInitialize(
                  mclEq(mclIntArrayRef1(mclVv(bbox, "bbox"), 1), _mxarray13_));
            if (mlfTobool(a_)
                && mlfTobool(
                     mclAnd(
                       a_,
                       mclNe(
                         mclIntArrayRef1(mclVv(so, "so"), 1),
                         mclIntArrayRef1(mclVv(so, "so"), 2))))) {
                mxDestroyArray(a_);
                /*
                 * B(so(1),so(2),thirdD) = A(so(1),so(2),thirdD);  %this will make B the same class as A and
                 */
                mlfIndexAssign(
                  &B,
                  "(?,?,?)",
                  mclIntArrayRef1(mclVv(so, "so"), 1),
                  mclIntArrayRef1(mclVv(so, "so"), 2),
                  mclVv(thirdD, "thirdD"),
                  mlfIndexRef(
                    mclVv(A, "A"),
                    "(?,?,?)",
                    mclIntArrayRef1(mclVv(so, "so"), 1),
                    mclIntArrayRef1(mclVv(so, "so"), 2),
                    mclVv(thirdD, "thirdD")));
                /*
                 * %it will set the desired size for B
                 * B(so(1),so(2),thirdD) = 0;  %reset this value to 0, i.e. padding with 0
                 */
                mlfIndexAssign(
                  &B,
                  "(?,?,?)",
                  mclIntArrayRef1(mclVv(so, "so"), 1),
                  mclIntArrayRef1(mclVv(so, "so"), 2),
                  mclVv(thirdD, "thirdD"),
                  _mxarray3_);
                /*
                 * imbegin = (max(so)==so)*abs(diff(floor(so/2)));
                 */
                mlfAssign(
                  &imbegin,
                  mclMtimes(
                    mclEq(
                      mlfMax(NULL, mclVv(so, "so"), NULL, NULL),
                      mclVv(so, "so")),
                    mlfAbs(
                      mlfDiff(
                        mlfFloor(mclMrdivide(mclVv(so, "so"), _mxarray1_)),
                        NULL,
                        NULL))));
                /*
                 * vec = 1:min(so);
                 */
                mlfAssign(
                  &vec,
                  mlfColon(
                    _mxarray0_,
                    mlfMin(NULL, mclVv(so, "so"), NULL, NULL),
                    NULL));
                /*
                 * v(1) = {imbegin(1)+vec};
                 */
                mclIntArrayAssign1(
                  &v,
                  mlfCellhcat(
                    mclPlus(
                      mclIntArrayRef1(mclVv(imbegin, "imbegin"), 1),
                      mclVv(vec, "vec")),
                    NULL),
                  1);
                /*
                 * v(2) = {imbegin(2)+vec};
                 */
                mclIntArrayAssign1(
                  &v,
                  mlfCellhcat(
                    mclPlus(
                      mclIntArrayRef1(mclVv(imbegin, "imbegin"), 2),
                      mclVv(vec, "vec")),
                    NULL),
                  2);
            } else {
                mxDestroyArray(a_);
            }
            /*
             * end;% for square or nocrop non-square image v stays the same
             * for k = 1:thirdD,
             */
            {
                int v_ = mclForIntStart(1);
                int e_ = mclForIntEnd(mclVv(thirdD, "thirdD"));
                if (v_ > e_) {
                    mlfAssign(&k, _mxarray15_);
                } else {
                    /*
                     * B(v{1},v{2},k) = rot90(A(v{1},v{2},k),drec-1);
                     * end
                     */
                    for (; ; ) {
                        mlfIndexAssign(
                          &B,
                          "(?,?,?)",
                          mlfIndexRef(mclVv(v, "v"), "{?}", _mxarray0_),
                          mlfIndexRef(mclVv(v, "v"), "{?}", _mxarray1_),
                          mlfScalar(v_),
                          mlfRot90(
                            mlfIndexRef(
                              mclVv(A, "A"),
                              "(?,?,?)",
                              mlfIndexRef(mclVv(v, "v"), "{?}", _mxarray0_),
                              mlfIndexRef(mclVv(v, "v"), "{?}", _mxarray1_),
                              mlfScalar(v_)),
                            mclMinus(mclVv(drec, "drec"), _mxarray0_)));
                        if (v_ == e_) {
                            break;
                        }
                        ++v_;
                    }
                    mlfAssign(&k, mlfScalar(v_));
                }
            }
        /*
         * else % zero rotation or simple flipud
         */
        } else {
            /*
             * if drec==3,% simple flipud+fliplr
             */
            if (mclEqBool(mclVv(drec, "drec"), _mxarray16_)) {
                /*
                 * v(1) = {so(1):-1:1};
                 */
                mclIntArrayAssign1(
                  &v,
                  mlfCellhcat(
                    mlfColon(
                      mclIntArrayRef1(mclVv(so, "so"), 1),
                      _mxarray17_,
                      _mxarray0_),
                    NULL),
                  1);
                /*
                 * v(2) = {so(2):-1:1};
                 */
                mclIntArrayAssign1(
                  &v,
                  mlfCellhcat(
                    mlfColon(
                      mclIntArrayRef1(mclVv(so, "so"), 2),
                      _mxarray17_,
                      _mxarray0_),
                    NULL),
                  2);
            /*
             * end
             */
            }
            /*
             * B = A(v{:});
             */
            mlfAssign(
              &B,
              mclArrayRef1(
                mclVv(A, "A"),
                mlfIndexRef(mclVv(v, "v"), "{?}", mlfCreateColonIndex())));
        /*
         * end
         */
        }
    /*
     * else % use tformarray
     */
    } else {
        /*
         * phi = ang*pi/180; % Convert to radians
         */
        mlfAssign(
          &phi,
          mclMrdivide(mclMtimes(mclVv(ang, "ang"), _mxarray18_), _mxarray19_));
        /*
         * 
         * rotate = maketform('affine',[ cos(phi)  sin(phi)  0; ...
         */
        mlfAssign(
          &rotate,
          mlfMaketform(
            _mxarray20_,
            mlfVertcat(
              mlfHorzcat(
                mlfCos(mclVv(phi, "phi")),
                mlfSin(mclVv(phi, "phi")),
                _mxarray3_,
                NULL),
              mlfHorzcat(
                mclUminus(mlfSin(mclVv(phi, "phi"))),
                mlfCos(mclVv(phi, "phi")),
                _mxarray3_,
                NULL),
              _mxarray22_,
              NULL),
            NULL));
        /*
         * -sin(phi)  cos(phi)  0; ...
         * 0       0       1 ]);
         * 
         * % Coordinates from center of A
         * hiA = (so-1)/2;
         */
        mlfAssign(
          &hiA, mclMrdivide(mclMinus(mclVv(so, "so"), _mxarray0_), _mxarray1_));
        /*
         * loA = -hiA;
         */
        mlfAssign(&loA, mclUminus(mclVv(hiA, "hiA")));
        /*
         * if bbox(1)=='l'  % Determine limits for rotated image
         */
        if (mclEqBool(mclIntArrayRef1(mclVv(bbox, "bbox"), 1), _mxarray24_)) {
            /*
             * hiB = ceil(max(abs(tformfwd([loA(1) hiA(2); hiA(1) hiA(2)],rotate)))/2)*2;
             */
            mlfAssign(
              &hiB,
              mclMtimes(
                mlfCeil(
                  mclMrdivide(
                    mlfMax(
                      NULL,
                      mlfAbs(
                        mlfTformfwd(
                          mlfVertcat(
                            mlfHorzcat(
                              mclIntArrayRef1(mclVv(loA, "loA"), 1),
                              mclIntArrayRef1(mclVv(hiA, "hiA"), 2),
                              NULL),
                            mlfHorzcat(
                              mclIntArrayRef1(mclVv(hiA, "hiA"), 1),
                              mclIntArrayRef1(mclVv(hiA, "hiA"), 2),
                              NULL),
                            NULL),
                          mclVv(rotate, "rotate"))),
                      NULL,
                      NULL),
                    _mxarray1_)),
                _mxarray1_));
            /*
             * loB = -hiB;
             */
            mlfAssign(&loB, mclUminus(mclVv(hiB, "hiB")));
            /*
             * sn = hiB - loB + 1;
             */
            mlfAssign(
              &sn,
              mclPlus(
                mclMinus(mclVv(hiB, "hiB"), mclVv(loB, "loB")), _mxarray0_));
        /*
         * else % Cropped image
         */
        } else {
            /*
             * hiB = hiA;
             */
            mlfAssign(&hiB, mclVv(hiA, "hiA"));
            /*
             * loB = loA;
             */
            mlfAssign(&loB, mclVv(loA, "loA"));
            /*
             * sn = so;
             */
            mlfAssign(&sn, mclVv(so, "so"));
        /*
         * end
         */
        }
        /*
         * 
         * boxA = maketform('box',so,loA,hiA);
         */
        mlfAssign(
          &boxA,
          mlfMaketform(
            _mxarray26_,
            mclVv(so, "so"),
            mclVv(loA, "loA"),
            mclVv(hiA, "hiA"),
            NULL));
        /*
         * boxB = maketform('box',sn,loB,hiB);
         */
        mlfAssign(
          &boxB,
          mlfMaketform(
            _mxarray26_,
            mclVv(sn, "sn"),
            mclVv(loB, "loB"),
            mclVv(hiB, "hiB"),
            NULL));
        /*
         * T = maketform('composite',[fliptform(boxB),rotate,boxA]);
         */
        mlfAssign(
          &T,
          mlfMaketform(
            _mxarray28_,
            mlfHorzcat(
              mlfFliptform(mclVv(boxB, "boxB")),
              mclVv(rotate, "rotate"),
              mclVv(boxA, "boxA"),
              NULL),
            NULL));
        /*
         * 
         * if strcmp(method,'bicubic')
         */
        if (mlfTobool(mlfStrcmp(mclVv(method, "method"), _mxarray30_))) {
            /*
             * R = makeresampler('cubic','fill');
             */
            mlfAssign(&R, mlfMakeresampler(_mxarray32_, _mxarray34_, NULL));
        /*
         * elseif strcmp(method,'bilinear')
         */
        } else if (mlfTobool(mlfStrcmp(mclVv(method, "method"), _mxarray36_))) {
            /*
             * R = makeresampler('linear','fill');
             */
            mlfAssign(&R, mlfMakeresampler(_mxarray38_, _mxarray34_, NULL));
        /*
         * else
         */
        } else {
            /*
             * R = makeresampler('nearest','fill');
             */
            mlfAssign(&R, mlfMakeresampler(_mxarray40_, _mxarray34_, NULL));
        /*
         * end
         */
        }
        /*
         * 
         * B = tformarray(A, T, R, [1 2], [1 2], sn, [], 0);
         */
        mlfAssign(
          &B,
          mlfTformarray(
            mclVv(A, "A"),
            mclVv(T, "T"),
            mclVv(R, "R"),
            _mxarray42_,
            _mxarray42_,
            mclVv(sn, "sn"),
            _mxarray15_,
            _mxarray3_));
    /*
     * 
     * end
     */
    }
    /*
     * 
     * 
     * % Output
     * switch nargout,
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargout_));
        if (mclSwitchCompare(v_, _mxarray3_)) {
            /*
             * case 0,
             * warning(['Obsolete syntax. In future versions IMROTATE ',... 
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray44_, NULL));
            /*
             * 'will return the result in ans instead of displaying it in figure.']);
             * imshow(B);
             */
            mclAssignAns(&ans, mlfNImshow(0, mclVv(B, "B"), NULL));
        /*
         * case 1,
         */
        } else if (mclSwitchCompare(v_, _mxarray0_)) {
            /*
             * varargout{1} = B;
             */
            mlfIndexAssign(&varargout, "{?}", _mxarray0_, mclVv(B, "B"));
        /*
         * case 3,
         */
        } else if (mclSwitchCompare(v_, _mxarray16_)) {
            /*
             * warning(['[R,G,B] = IMROTATE(RGB) is an obsolete output syntax. ',...
             */
            mclAssignAns(&ans, mlfNWarning(0, NULL, _mxarray46_, NULL));
            /*
             * 'Use one output argument the receive the 3-D output RGB image.']);
             * for k=1:3,
             */
            {
                int v_0 = mclForIntStart(1);
                int e_ = 3;
                if (v_0 > e_) {
                    mlfAssign(&k, _mxarray15_);
                } else {
                    /*
                     * varargout{k} = B(:,:,k);
                     * end;
                     */
                    for (; ; ) {
                        mlfIndexAssign(
                          &varargout,
                          "{?}",
                          mlfScalar(v_0),
                          mlfIndexRef(
                            mclVv(B, "B"),
                            "(?,?,?)",
                            mlfCreateColonIndex(),
                            mlfCreateColonIndex(),
                            mlfScalar(v_0)));
                        if (v_0 == e_) {
                            break;
                        }
                        ++v_0;
                    }
                    mlfAssign(&k, mlfScalar(v_0));
                }
            }
        /*
         * otherwise,
         */
        } else {
            /*
             * error('Invalid number of output arguments.');
             */
            mlfError(_mxarray48_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    mxDestroyArray(A);
    mxDestroyArray(ang);
    mxDestroyArray(method);
    mxDestroyArray(bbox);
    mxDestroyArray(so);
    mxDestroyArray(thirdD);
    mxDestroyArray(phi);
    mxDestroyArray(drec);
    mxDestroyArray(v);
    mxDestroyArray(B);
    mxDestroyArray(imbegin);
    mxDestroyArray(vec);
    mxDestroyArray(k);
    mxDestroyArray(rotate);
    mxDestroyArray(hiA);
    mxDestroyArray(loA);
    mxDestroyArray(hiB);
    mxDestroyArray(loB);
    mxDestroyArray(sn);
    mxDestroyArray(boxA);
    mxDestroyArray(boxB);
    mxDestroyArray(T);
    mxDestroyArray(R);
    mxDestroyArray(ans);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return varargout;
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     * %
     * %  Function: parse_inputs
     * %
     * 
     */
}

/*
 * The function "Mimrotate_parse_inputs" is the implementation version of the
 * "imrotate/parse_inputs" M-function from file
 * "k:\matlab6p5\toolbox\images\images\imrotate.m" (lines 137-190). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * function [A,ang,method,bbox] = parse_inputs(varargin)
 */
static mxArray * Mimrotate_parse_inputs(mxArray * * ang,
                                        mxArray * * method,
                                        mxArray * * bbox,
                                        int nargout_,
                                        mxArray * varargin) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_imrotate);
    int nargin_ = mclNargin(-1, varargin, NULL);
    mxArray * A = NULL;
    mxArray * idx = NULL;
    mxArray * strings = NULL;
    mxArray * ans = NULL;
    mclCopyArray(&varargin);
    /*
     * % Outputs:  A       the input image
     * %           ang     the angle by which to rotate the input image
     * %           method  interpolation method (nearest,bilinear,bicubic)
     * %           bbox    bounding box option 'loose' or 'crop'
     * 
     * % Defaults:
     * method = 'n';
     */
    mlfAssign(method, _mxarray50_);
    /*
     * bbox = 'l';
     */
    mlfAssign(bbox, _mxarray24_);
    /*
     * 
     * error(nargchk(2,4,nargin));
     */
    mlfError(mlfNargchk(_mxarray1_, _mxarray52_, mlfScalar(nargin_)), NULL);
    /*
     * switch nargin
     */
    {
        mxArray * v_ = mclInitialize(mlfScalar(nargin_));
        if (mclSwitchCompare(v_, _mxarray1_)) {
            /*
             * case 2,             % imrotate(A,ang)        
             * A = varargin{1};
             */
            mlfAssign(
              &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * ang=varargin{2};
             */
            mlfAssign(
              ang, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
        /*
         * case 3,             % imrotate(A,ang,method) or
         */
        } else if (mclSwitchCompare(v_, _mxarray16_)) {
            /*
             * A = varargin{1};  % imrotate(A,ang,box)
             */
            mlfAssign(
              &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * ang=varargin{2};
             */
            mlfAssign(
              ang, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * method=varargin{3};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
        /*
         * case 4,             % imrotate(A,ang,method,box) 
         */
        } else if (mclSwitchCompare(v_, _mxarray52_)) {
            /*
             * A = varargin{1};
             */
            mlfAssign(
              &A, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray0_));
            /*
             * ang=varargin{2};
             */
            mlfAssign(
              ang, mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray1_));
            /*
             * method=varargin{3};
             */
            mlfAssign(
              method,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray16_));
            /*
             * bbox=varargin{4};
             */
            mlfAssign(
              bbox,
              mlfIndexRef(mclVa(varargin, "varargin"), "{?}", _mxarray52_));
        /*
         * otherwise,
         */
        } else {
            /*
             * error('Invalid input arguments.');
             */
            mlfError(_mxarray53_, NULL);
        /*
         * end
         */
        }
        mxDestroyArray(v_);
    }
    /*
     * 
     * % Check validity of the input parameters 
     * if ischar(method)&ischar(bbox),
     */
    {
        mxArray * a_ = mclInitialize(mlfIschar(mclVv(*method, "method")));
        if (mlfTobool(a_)
            && mlfTobool(mclAnd(a_, mlfIschar(mclVv(*bbox, "bbox"))))) {
            mxDestroyArray(a_);
            /*
             * strings = {'nearest','bilinear','bicubic','crop','loose'};
             */
            mlfAssign(&strings, _mxarray55_);
            /*
             * idx = strmatch(lower(method),strings);
             */
            mlfAssign(
              &idx,
              mlfStrmatch(
                mlfLower(mclVv(*method, "method")),
                mclVv(strings, "strings"),
                NULL));
            /*
             * if isempty(idx),
             */
            if (mlfTobool(mlfIsempty(mclVv(idx, "idx")))) {
                /*
                 * error(sprintf('Unknown interpolation method: %s',method));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray61_, mclVv(*method, "method"), NULL),
                  NULL);
            /*
             * elseif length(idx)>1,
             */
            } else if (mclLengthInt(mclVv(idx, "idx")) > 1) {
                /*
                 * error(sprintf('Ambiguous interpolation method: %s',method));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray63_, mclVv(*method, "method"), NULL),
                  NULL);
            /*
             * else
             */
            } else {
                /*
                 * if idx==4,bbox=strings{4};method=strings{1};
                 */
                if (mclEqBool(mclVv(idx, "idx"), _mxarray52_)) {
                    mlfAssign(
                      bbox,
                      mlfIndexRef(
                        mclVv(strings, "strings"), "{?}", _mxarray52_));
                    mlfAssign(
                      method,
                      mlfIndexRef(
                        mclVv(strings, "strings"), "{?}", _mxarray0_));
                /*
                 * elseif idx==5,bbox = strings{5};method=strings{1};
                 */
                } else if (mclEqBool(mclVv(idx, "idx"), _mxarray65_)) {
                    mlfAssign(
                      bbox,
                      mlfIndexRef(
                        mclVv(strings, "strings"), "{?}", _mxarray65_));
                    mlfAssign(
                      method,
                      mlfIndexRef(
                        mclVv(strings, "strings"), "{?}", _mxarray0_));
                /*
                 * else method = strings{idx};
                 */
                } else {
                    mlfAssign(
                      method,
                      mlfIndexRef(
                        mclVv(strings, "strings"), "{?}", mclVv(idx, "idx")));
                /*
                 * end
                 */
                }
            /*
             * end  
             */
            }
            /*
             * idx = strmatch(lower(bbox),strings(4:5));
             */
            mlfAssign(
              &idx,
              mlfStrmatch(
                mlfLower(mclVv(*bbox, "bbox")),
                mclArrayRef1(
                  mclVv(strings, "strings"),
                  mlfColon(_mxarray52_, _mxarray65_, NULL)),
                NULL));
            /*
             * if isempty(idx),
             */
            if (mlfTobool(mlfIsempty(mclVv(idx, "idx")))) {
                /*
                 * error(sprintf('Unknown BBOX parameter: %s',bbox));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray66_, mclVv(*bbox, "bbox"), NULL),
                  NULL);
            /*
             * elseif length(idx)>1,
             */
            } else if (mclLengthInt(mclVv(idx, "idx")) > 1) {
                /*
                 * error(sprintf('Ambiguous BBOX string: %s',bbox));
                 */
                mlfError(
                  mlfSprintf(NULL, _mxarray68_, mclVv(*bbox, "bbox"), NULL),
                  NULL);
            /*
             * else
             */
            } else {
                /*
                 * bbox = strings{3+idx};
                 */
                mlfAssign(
                  bbox,
                  mlfIndexRef(
                    mclVv(strings, "strings"),
                    "{?}",
                    mclPlus(_mxarray16_, mclVv(idx, "idx"))));
            /*
             * end 
             */
            }
        /*
         * else
         */
        } else {
            mxDestroyArray(a_);
            /*
             * error('Interpolation method and BBOX have to be a string.');  
             */
            mlfError(_mxarray70_, NULL);
        }
    /*
     * end
     */
    }
    mclValidateOutput(A, 1, nargout_, "A", "imrotate/parse_inputs");
    mclValidateOutput(*ang, 2, nargout_, "ang", "imrotate/parse_inputs");
    mclValidateOutput(*method, 3, nargout_, "method", "imrotate/parse_inputs");
    mclValidateOutput(*bbox, 4, nargout_, "bbox", "imrotate/parse_inputs");
    mxDestroyArray(ans);
    mxDestroyArray(strings);
    mxDestroyArray(idx);
    mxDestroyArray(varargin);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return A;
}
