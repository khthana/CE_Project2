function varargout = imageextractinfo(varargin)
% IMAGEEXTRACTINFO M-file for imageextractinfo.fig
%      IMAGEEXTRACTINFO, by itself, creates a new IMAGEEXTRACTINFO or raises the existing
%      singleton*.
%
%      H = IMAGEEXTRACTINFO returns the handle to a new IMAGEEXTRACTINFO or the handle to
%      the existing singleton*.
%
%      IMAGEEXTRACTINFO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGEEXTRACTINFO.M with the given input arguments.
%
%      IMAGEEXTRACTINFO('Property','Value',...) creates a new IMAGEEXTRACTINFO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before imageextractinfo_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to imageextractinfo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help imageextractinfo

% Last Modified by GUIDE v2.5 08-Mar-2004 02:00:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @imageextractinfo_OpeningFcn, ...
                   'gui_OutputFcn',  @imageextractinfo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before imageextractinfo is made visible.
function imageextractinfo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to imageextractinfo (see VARARGIN)

% Choose default command line output for imageextractinfo
handles.output = hObject;

%h_image=imfinfo('mark.bmp','bmp');
%set(handles.editFilename,'String',h_image.Filename);

% Update handles structure

guidata(hObject, handles);
%psnr_mse(hObject,eventdata,handles);

% UIWAIT makes imageextractinfo wait for user response (see UIRESUME)
% uiwait(handles.figure2);


% --- Outputs from this function are returned to the command line.
function varargout = imageextractinfo_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;




% --- Executes on button press in pushbuttonSimilarity_Ok.
function pushbuttonSimilarity_Ok_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSimilarity_Ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(gcf);



% --- Executes during object creation, after setting all properties.
function editSimilarity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSimilarity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editSimilarity_Callback(hObject, eventdata, handles)
% hObject    handle to editSimilarity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSimilarity as text
%        str2double(get(hObject,'String')) returns contents of editSimilarity as a double


