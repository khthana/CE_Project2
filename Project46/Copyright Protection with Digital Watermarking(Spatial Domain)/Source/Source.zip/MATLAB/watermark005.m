function varargout = watermark005(varargin)
% WATERMARK005 M-file for watermark005.fig
%      WATERMARK005, by itself, creates a new WATERMARK005 or raises the existing
%      singleton*.
%
%      H = WATERMARK005 returns the handle to a new WATERMARK005 or the handle to
%      the existing singleton*.
%
%      WATERMARK005('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WATERMARK005.M with the given input arguments.
%
%      WATERMARK005('Property','Value',...) creates a new WATERMARK005 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before watermark005_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to watermark005_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help watermark005

% Last Modified by GUIDE v2.5 23-Mar-2004 16:16:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @watermark005_OpeningFcn, ...
                   'gui_OutputFcn',  @watermark005_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before watermark005 is made visible.
function watermark005_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to watermark005 (see VARARGIN)

% Choose default command line output for watermark005
handles.output = hObject;
%handles.temp_popupblocksize=2;% we add

% Update handles structure
%define my data for initialize
handles.bool_openOriginal=0;
handles.bool_openWatermark=0;
handles.bool_openImageWithWatermark=0;
handles.bool_openExtractWatermark=0;

%check attack method
handles.bool_cropAlready=0;
handles.bool_rotateAlready=0;
handles.bool_filterAlready=0;
handles.bool_resizeAlready=0;
handles.bool_JPEGAlready=0;

%check save image
handles.bool_addWatermarkSave=0;
handles.bool_extractWatermarkSave=0;
handles.bool_AttackWatermarkSave=0;
handles.bool_cropAttackSave=0;
handles.bool_rotateAttackSave=0;
handles.bool_filterAttackSave=0;
handles.bool_resizeAttackSave=0;
handles.bool_JPEGAttackSave=0;
%handles.current_filename1='';
%handles.current_filename3='';


%block size add
handles.temp_popupblocksizeAdd=1;
guidata(hObject, handles);

%block size extracted
handles.temp_popupblocksizeExt=1;
guidata(hObject, handles);



%attack mode
handles.current_AttackMode='default';

%sizeblock
handles.temp_popupblocksize=1;% we add for initial blocksize by defualt is 1

guidata(hObject, handles);




% UIWAIT makes watermark005 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = watermark005_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbuttonOpenOriginal.
function pushbuttonOpenOriginal_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOpenOriginal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename1,pathname1]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
if isequal(filename1,0)|isequal(pathname1,0)
    disp('Status>>File not Open...Please try again.');
    handles.bool_openOriginal=0;%Not open origianl image 
    return;
        
else
    disp(['Status>>File ', pathname1, filename1, ' have already openned'])
    temp_path1=[pathname1 filename1];
    handles.current_filename1 = temp_path1;
end

image_x1=imread(handles.current_filename1);
%handles.h_subplotOriginal=subplot('Position',[0.03 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(temp_path1),title(filename1);
handles.h_subplotOriginal=subplot('Position',[0.03 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x1),title(filename1);
clc;

handles.bool_openOriginal=1;%set open origianl image already
guidata(hObject,handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%        set button active

%enable pushbuttonAddWatermark
if (handles.bool_openOriginal) &&(handles.bool_openWatermark)

    %Enaable pushbuttonAddWatermark
    set(findobj('tag','pushbuttonAddWatermark'),'Enable','on');
    
    %Enaable popupmenuBlockSizeAdd
    set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');
end


if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
   %enable pushbuttonExtract
    set(findobj('tag','pushbuttonExtract'),'Enable','on');
    
    %enable popupmenuAttackMethod
    set(findobj('tag','popupmenuAttackMethod'),'Enable','on');
    
    %Enaable popupmenuBlockSizeExt
    set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
end
if (handles.bool_openOriginal)
    %enable pushbuttonOriginal_info
    set(findobj('tag','pushbuttonOriginal_info'),'Enable','on');
    %enable pushbuttonShowRealOriginal
    set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','on');
end

% --- Executes on button press in pushbuttonOpenWatermark.
function pushbuttonOpenWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOpenWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%[filename2,pathname2]=uigetfile({'*.bmp','Bitmap(*.bmp)'},'Choose a file');
[filename2,pathname2]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
temp_path2=[pathname2 filename2];
if isequal(filename2,0)|isequal(pathname2,0)
    disp('Status>>File not Open');
    handles.bool_openWatermark=0;;%Not open watermark image
    return;
else
    disp(['Status>>File ', pathname2, filename2, ' have already openned'])
    temp_path2=[pathname2 filename2];
    handles.current_filename2 = temp_path2;
end


image_x2=imread(handles.current_filename2);
%handles.h_subplotWatermark=subplot('Position',[0.35 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(temp_path2),title(filename2);
handles.h_subplotWatermark=subplot('Position',[0.35 0.55  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x2),title(filename2);
clc;

handles.bool_openWatermark=1;%set open watermark image already
guidata(hObject,handles);

if (handles.bool_openOriginal) &&(handles.bool_openWatermark)
    %enable pushbuttonAddWatermark
    h_enablepushbuttonAddWatermark=findobj('tag','pushbuttonAddWatermark','Enable','off');
    set(h_enablepushbuttonAddWatermark,'Enable','on');
    
    %Enaable popupmenuBlockSizeAdd
    set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');
    
end
if (handles.bool_openWatermark)
    %enable pushbuttonWatermark_info
    h_enablepushbuttonWatermark_info=findobj('tag','pushbuttonWatermark_info','Enable','off');
    set(h_enablepushbuttonWatermark_info,'Enable','on');
    
    %enable pushbuttonShowRealWatermark
    h_enablepushbuttonShowRealWatermark=findobj('tag','pushbuttonShowRealWatermark','Enable','off');
    set(h_enablepushbuttonShowRealWatermark,'Enable','on');
end


% --- Executes during object creation, after setting all properties.
function popupmenuBlockSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
%set(hObject, 'String', {'plot(rand(5))', 'plot(sin(1:0.01:25))', 'comet(cos(1:.01:10))', 'bar(1:10)', 'plot(membrane)', 'surf(peaks)'});


% --- Executes on selection change in popupmenuBlockSize.
function popupmenuBlockSize_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuBlockSize contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSize

%all_choices = get(handles.my_menu, 'String')
%current_choice = all_choices{get(handles.my_menu, 'Value')};
%temp_popup_sel_index = get(handles.popupmenuBlockSize, 'Value');


popup_sel_index = get(handles.popupmenuBlockSize,'Value');
%popup_sel_index = get(hObject,'Value');
%msgbox(popup_sel_index);

switch popup_sel_index
    case 1
       block_size=1;
       set(handles.editBlockSize,'String','1');
    case 2
       block_size=2;
       set(handles.editBlockSize,'String','2');
   case 3
        block_size=4;
        set(handles.editBlockSize,'String','4');
    case 4
       block_size=8;
       set(handles.editBlockSize,'String','8');
   case 5
        block_size=16;
        set(handles.editBlockSize,'String','16');
    case 6
        block_size=32;
        set(handles.editBlockSize,'String','32');
    case 7
        block_size=64;
        set(handles.editBlockSize,'String','64');
    case 8
        block_size=128;
        set(handles.editBlockSize,'String','128');
    case 9
        block_size=256;
        set(handles.editBlockSize,'String','256');
    otherwise
        block_size=2;
        set(handles.editBlockSize,'String','2');
end 
%msgbox(block_size);     

handles.temp_popupblocksize=block_size;
guidata(hObject,handles);



% --- Executes on button press in pushbuttonAddWatermark.
function pushbuttonAddWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonAddWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%function add(infile,outfile,key,arg4,arg5);
%infile->name of input file to be added watermark
%outfile->name of output file after adding
%arg4=>watermark (file name) to be added in host image
%arg5=>percent of adding is valid from 1-100

%%%%%%%%%%Begin Add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%Manage input%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%Begin  Manage Key   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try
    defaultKey='12345678';
    %prompt = {'Enter matrix size:','Enter colormap name:'};
    %dlg_title = 'Input for peaks function';
    %num_lines= 1;
    %def     = {'20','hsv'};
    %answer  = inputdlg(prompt,dlg_title,num_lines,def);
    keyPrompt={'Please input password for adding watermark image(Recommand 8 Digits)'};
    dlgKey_title='Input password to protect watermark';
    keyNum_lines=1;

    temp_keyAnswer=inputdlg(keyPrompt,dlgKey_title,keyNum_lines);

    if isempty(temp_keyAnswer)
        msgbox('You cancel input password program will do nothing ','Cancel input Password ','warn','modal');
        return;
    end;    
    if isequal(temp_keyAnswer,{''})  
        key=defaultKey;
        h_passwdinvalid=msgbox('You don''t enter your password.Watermark image wouldn''t secure','Password invalid','warn','modal');
        uiwait(h_passwdinvalid);
    else 
        if isnan(str2double(temp_keyAnswer))
            key=defaultKey;
            %disp('nan');
        else
            key=temp_keyAnswer;
            %disp('not nan');
        end
    end    
    
    key=temp_keyAnswer;

   



    key=str2double(key);

%%%%%%%%%End  Manage Key   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%Begin percent to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    percentPrompt={'Please input percent for adding watermark image(defualt 95%)'};
    dlgPercent_title='Input percent to add watermark';
    defPercent     = {'95'};
    percentNum_lines=1;


    temp_percentAnswer=inputdlg(percentPrompt,dlgPercent_title,percentNum_lines,defPercent);

    if isempty(temp_percentAnswer)
        msgbox('You cancel input percent to add watermark. Program will do nothing','Cancel input percent adding ','warn','modal');
    return;
    end;    
    if isequal(temp_percentAnswer,{''})
         percent=defPercent;
         h_percentinvalid=msgbox('You don''t input percent to adding. Program will use defualt(100%)','Percent adding is invalid','warn','modal');
         uiwait(h_percentinvalid);
    else 
        if isnan(str2double(temp_percentAnswer))
            percent='100';
        else
        percent=temp_percentAnswer;
        end   
    end
%%%%%%%%%%End percent to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%Begin process to add watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% Begin check initial paramter for adding %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    try
        h_waitAdd = waitbar(0,'Please wait... Program is  processing. ');

        percent=str2double(percent);%change string to integer
        key = double(key);

    %%%%%%%%%%%Initial key %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        key_size = size(key);
        key_size = key_size(2);
        total_key = '';
        for i=1:key_size
            total_key = strcat(total_key,int2str(key(i)));
        end;
        %total_key = double(total_key);
        total_key = str2num(total_key);

    %%%%%%%%%%read  image%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        infile=handles.current_filename1;% original image
        im5_info = imfinfo(infile);
        im5 = imread(infile);
    
        im5 = im2double(im5);
            if strcmp(im5_info.ColorType,'truecolor')==1;
                im5_col = im5;
                im5 = im5_col(:,:,3);
            end;
        waitbar(0.1,h_waitAdd);

        %%%%define image type
        im_size_row = im5_info.Width;
        im_size_col = im5_info.Height;
        type = im5_info.Format;

        watermark=handles.current_filename2;%watermark image

        %%%%%%%%%% block size fix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
        block_size = handles.temp_popupblocksizeAdd;
    
    catch
        close(h_waitAdd);
        msgbox('Program Can''t initial some parameters.Process will be cancel...','Error initial parameters ','error','modal');
        return;
    end    
%%%%%%%%%%%End check initial paramters for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    %%%%%%%%%%%%%%%%%%%Begin block information%%%%%%%%%%%%%%%%%%
    if mod(im_size_row,block_size)==0 & mod(im_size_col,block_size)==0;
        block_per_row = im_size_row/block_size;
        block_per_col = im_size_col/block_size;
    else
        close(h_waitAdd); 
        msgbox('Miss Match between BLOCK and IMAGE size','ERROR','error','modal');
        return;
    end;
    %%%%%%%%%%%%%%%%%%%End block information%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%%%%%%%%%%%Begin check initial block for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    try
        if block_per_row>=block_per_col;
            max_block = block_per_row;
        else
            max_block = block_per_col;
        end;
        k=1;
        x(1:max_block,1:block_size)=0;
        for i = 1:max_block;
            for j = 1:block_size;
                x(i,j)=k;
                k = k+1;
            end;
        end;

    
        waitbar(0.3,h_waitAdd);

    %%%%%%%%%%%%Begin convert percent to number of block%%%%%%%%%%%%%%%%%%%%%%

        arg5=percent;%percent to add
        num_block = block_per_row*block_per_col;
        num_adding = arg5*num_block/100;
        num_adding = floor(num_adding);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        g_max(1:block_per_col,1:block_per_row) = 0;
        g_min(1:block_per_col,1:block_per_row) = 0;
        g_avg(1:block_per_col,1:block_per_row) = 0;
 
        for k = 1:block_per_col;
            for l = 1:block_per_row;
                tmp= max(im5(x(k,:),x(l,:)));
                g_max(k,l)= max(tmp);
        
                tmp= min(im5(x(k,:),x(l,:)));
                g_min(k,l)= min(tmp);
    
                tmp= sum(im5(x(k,:),x(l,:)));
                tmp= sum(tmp);
                g_avg(k,l)= tmp/(block_size*block_size);
            end;
        end;

        waitbar(0.5,h_waitAdd);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        wm_info = imfinfo(watermark);
        bin_mark = imread(watermark,wm_info.Format);
        %bin_mark=imread(watermark);
    catch
        close(h_waitAdd); 
        msgbox('Initial Block for adding has some errors...','ERROR Initial Blcok','error','modal');
    return;
    end    
%%%%%%%%%%%End check initial block for adding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%Begin check and convert watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% Begin check and convert watermark%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    try
        if strcmp(wm_info.ColorType,'truecolor')==1;
            bin_mark = rgb2gray(bin_mark);
            bin_mark = dither(bin_mark);
        else 
            bin_mark = dither(bin_mark);
    end;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        bin_mark = imresize(bin_mark,[block_per_col block_per_row]);
        imwrite(bin_mark,'real_mark.bmp','bmp');
        marked_im5 = im5;
    catch
        close(h_waitAdd); 
        msgbox('Check and convert watermark has some errors...','ERROR checking watermark','error','modal');
        return;
    end    
%%%%%%%%%%%Begin check and convert watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%Begin Check initial random    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%Begin initial random%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     try
        rand_size = 1;%mean 10,000 blocks,should not more than sqrt(n_block)
        seed = total_key;%key
        n_block = num_adding;
        s = randint(1,n_block,[1,num_block],seed);
        if arg5==100;
            s = randperm(num_block);
        end;


    %%%%%%%%End initial random%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        waitbar(0.7,h_waitAdd);


        for m = 1:1;      
            for n = 1:n_block;
                k = ceil(s(m,n)/block_per_row);
                l = mod(s(m,n),block_per_row);
                if l == 0; 
                    l = block_per_row; 
                end;
                for i = x(k,:);
                    for j = x(l,:);
            
                        if bin_mark(k,l) == 1;%white
                            if im5(i,j) > g_avg(k,l);
                                marked_im5(i,j) = g_max(k,l);
                            else    
                                marked_im5(i,j) = im5(i,j) + 0.0100;
                            end;
                        elseif bin_mark(k,l) == 0;%black
                                if im5(i,j) < g_avg(k,l);
                                    marked_im5(i,j) = g_min(k,l);%0.0005;
                                else
                                    marked_im5(i,j) = im5(i,j) - 0.0100;
                                 end;
                        end;
                
                    end;
                end;
            end;
        end;

    waitbar(0.9,h_waitAdd);
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if strcmp(im5_info.ColorType,'truecolor')==1;
            im5_col(:,:,3)=marked_im5;
            marked_im5 = im5_col;
        end;

   catch 
        close(h_waitAdd); 
        msgbox('Program can''t succeed this action ','Error some parameters','error','modal');
       return;
    end    

        waitbar(1,h_waitAdd,'Process is successful');
        delete(h_waitAdd);

%%%%%%%%%%%End Check initial random    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%show image with watermark 
    try
    handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title('Image with Watermark');
    %clc;
    catch 
    %    imshow(marked_im5);
        %delete(handles.h_subplotImageWithWatermark);
        handles.current_filename3='image_watermark_bak.bmp';
        imwrite(marked_im5,handles.current_filename3,'bmp')
        handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark');      
        %h_waitShowImageWithWatermark=msgbox('Program can''t show image in current windows..','Error Show image','error','modal');
%        uiwait(h_waitShowImageWithWatermark);
 %       pushbuttonClearAll_Callback;
    end    

%%%%%%%%Begin Set Active Button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        handles.bool_openImageWithWatermark=1;%already open Image with watermark
    
        handles.current_marked_im5=marked_im5;%image with watermark

        %enable pushbuttonSaveImageWithWatermark
        h_enableSaveImageWithWatermark=findobj('tag','pushbuttonSaveImageWithWatermark','Enable','off');
        set(h_enableSaveImageWithWatermark,'Enable','on');

        %enable pushbuttonImageWithWatermark_info
        h_enablepushbuttonImageWithWatermark_info=findobj('tag','pushbuttonImageWithWatermark_info','Enable','off');
        set(h_enablepushbuttonImageWithWatermark_info,'Enable','on');
    
        %enable pushbuttonShowRealImageWithWatermark
        h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
        set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');

    
        if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
        %enable pushbuttonExtract
        h_enableExtract=findobj('tag','pushbuttonExtract','Enable','off');
        set(h_enableExtract,'Enable','on');
        %enable popupmenuAttackMethod
        h_enablepopupmenuAttackMethod=findobj('tag','popupmenuAttackMethod','Enable','off');
        set(h_enablepopupmenuAttackMethod,'Enable','on');
        
        %Enaable popupmenuBlockSizeExt
        set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
        
        end

    %%%%%%%End Set Active Button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%%%%%%Begin Save image with watermark   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filename3,0)|isequal(pathname3,0)
        disp('Status>> File is not saving right now...Please try again');
        handles.bool_addWatermarkSave=0;%not save adding watermark
        handles.current_filename3='image_watermark_bak.bmp';
        imwrite(handles.current_marked_im5,handles.current_filename3,'bmp')
        guidata(hObject,handles);
        return;
    else
        disp(['Status>> File ', pathname3, filename3,'.bmp',' already saved'])
        filenameWrite=[pathname3 filename3 '.bmp'];
        imwrite(handles.current_marked_im5,filenameWrite,'bmp')
        title([filename3 '.bmp']);
        handles.bool_addWatermarkSave=1;%already save adding watermark
        handles.current_filename3 = filenameWrite;
        guidata(hObject,handles);
    end
catch
        try
            close(h_waitAdd);
        catch            
            msgbox('Program Can''t initial some parameters.Process will be cancel...','Error initial parameters ','error','modal');
            return;
        end
end        
%%%%%%%%%End Save image with watermark   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%End Add watermark  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in pushbuttonExtract.
function pushbuttonExtract_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonExtract (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%function ext(marked_im,org_im,outfile,attack_type);
%mark_im-> watermarked image that watermark will be extracted
%org_im-> original image that have no this watermark
%outfile-> file name that wanna save the extracted watermark
%attack type -> type of attack need to be identified
%   -'resize' if watermarked image is resized
%   -'crop' if watermarked image is cropped
%   -0-360 if watermarked image is rotated the angle need to be filled

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% Begin initial variable   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try
     attack_type=handles.current_AttackMode;%attack type
    try
        marked_im=handles.current_filename3;%image with watermark image
    
        org_im=handles.current_filename1;%original image
    catch
        msgbox('Can''t processing extracted watermark Program Error..Please close and open program again.','Process have an error','error','modal') 
        return;
    end    
    h_waitExt = waitbar(0,'Please wait... Program is  processing. ');
    
    waitbar(0.05,h_waitExt);

    im5_info = imfinfo(org_im);%im5 original image
    im6_info = imfinfo(marked_im);%im6 image with watermark

    attack = attack_type;%attack mode
    
    im6 = imread(marked_im,im6_info.Format);% read image with watermark
    im6 = im2double(im6);
    
    im5 = imread(org_im,im5_info.Format);%read original image
    im5 = im2double(im5);
    
 


%%%%%%%%%%%%%%%    color image  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if strcmp(im5_info.ColorType,'truecolor')==1;
        im5_col = im5;
        im5 = im5_col(:,:,3);
    end;
    if strcmp(im6_info.ColorType,'truecolor')==1;
        im6_col = im6;
        im6 = im6_col(:,:,3);
    end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    im_size_row = im5_info.Width;
    im_size_col = im5_info.Height;

    block_size = handles.temp_popupblocksizeExt;


%%%%%%%%%%%%%%%%%%%%%%% End initial variable   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Begin Check Attack mode   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%% detect attacked image and recover %%%%%%%
    try
    %%%%% detect resize %%%%%%%
    if strcmp(attack,'resize')==1;
        im6_back = im6;
        im6 = imresize(im6,[im_size_col,im_size_row]);
    end;

    %%%%% detect crop %%%%%%%
    if strcmp(attack,'crop')==1;
        im6_back = im6;

        tmp = im6;%image with watermark
        tmp2 = im5;%original image
        tmp = im2double(tmp);
        tmp2 = im2double(tmp2);
        tmp_size = size(tmp);
        tmp2_size = size(tmp2);
        rect_tmp = [3 3 (tmp_size(2)-3) (tmp_size(1)-3)];
        rect_tmp2 = [3 3 (tmp2_size(2)-3) (tmp2_size(1)-3)];
        sub_tmp = imcrop(tmp,rect_tmp);
        sub_tmp2 = imcrop(tmp2,rect_tmp2);


        c = normxcorr2(sub_tmp(:,:),sub_tmp2(:,:));
        [max_c,imax] = max(abs(c(:)));
        [ypeak,xpeak]=ind2sub(size(c),imax(1));
    
        corr_offset = [(xpeak-size(sub_tmp,2)) (ypeak-size(sub_tmp,1))];
        rect_offset = [(rect_tmp2(1)-rect_tmp(1)) (rect_tmp2(2)-rect_tmp(2))];

        offset = corr_offset+rect_offset;
        xoffset = offset(1);
        yoffset = offset(2);

        xbegin = xoffset + 1;
        xend = xoffset+size(tmp,2);
        ybegin = yoffset+1;
        yend = yoffset+size(tmp,1);

        tmp2(:,:) = 1;%original image
        tmp2(ybegin:yend,xbegin:xend) = tmp;
        im6 =tmp2;%image with watermark
    end;
    
    %%%%% detect rotate %%%%%%%
    if strcmp(attack,'rotate')==1;
            
        rotatePrompt={'Please input angle that picture had been rotate for extract watermark image(Angle in Degree)'};
        dlgRotate_title='Input angle to extract watermark';
        %defRotate     = {'90'};
        rotateNum_lines=1;

         %%%% input Rotate number %%%%%%%%%%%
        temp_rotateAnswer=inputdlg(rotatePrompt,dlgRotate_title,rotateNum_lines);
        
        if isempty(temp_rotateAnswer)
            msgbox('You cancel input angle program will do nothing ','Cancel input angle ','warn','modal');
            delete(h_waitExt);
            return;
        end;    

        if isequal(temp_rotateAnswer,{''})
            % rotate=defaultRotate;
             msgbox('You don''t input angle integer program will do nothing','Angle Rotate Error','error','modal');
             delete(h_waitExt);
            return;
        else 
            if isnan(str2double(temp_rotateAnswer))
               msgbox('You can input angle only 0-360...','Angle Rotate Input Error','error','modal');
               delete(h_waitExt);
               return;
            end;
        end;
    
        %str_rotateDegree=temp_rotateAnswer;
        doub_rotateDegree=str2double(temp_rotateAnswer);
  
        im6_back = im6;%image with watermark
        doub_rotateDegree = 360-doub_rotateDegree;
        im6 = imrotate(im6,doub_rotateDegree);
        if doub_rotateDegree~=0 && doub_rotateDegree~=90 && doub_rotateDegree~=180 && doub_rotateDegree~=270 && doub_rotateDegree~=360;
            im6_size = size(im6);
            im6_height = im6_size(1);
            im6_width = im6_size(2);
            im6_height = ceil((im6_height-im_size_col)/2);
            im6_width = ceil((im6_width-im_size_row)/2);
            im6 = imcrop(im6,[im6_width im6_height im_size_col-1 im_size_row-1]);
        end;
    end;
    catch
                msgbox('Program found attack mode error...','Attack mode Error','error','modal');
               delete(h_waitExt);
               return;
    end
    waitbar(0.3,h_waitExt);
    %%%%%%%%%%%%%%%%% End Check Attack mode   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %marked_im_size_row = im6_info.Width;
    %marked_im_size_col = im6_info.Height;
    %===========find g_max,g_min and g_avg of orginal image================
    if mod(im_size_row,block_size)==0 & mod(im_size_col,block_size)==0;
        block_per_row = im_size_row/block_size;
        block_per_col = im_size_col/block_size;
    else
        msgbox('Miss Match between BLOCK and IMAGE size','ERROR','error');
        return;
    end;
    if block_per_row>=block_per_col;
        max_block = block_per_row;
    else
        max_block = block_per_col;
    end;
    k=1;
    x(1:max_block,1:block_size)=0;
    for i = 1:max_block;
        for j = 1:block_size;
            x(i,j)=k;
            k = k+1;
        end;
    end;
    g_max(1:block_per_col,1:block_per_row) = 0;
    g_min(1:block_per_col,1:block_per_row) = 0;
    g_avg(1:block_per_col,1:block_per_row) = 0;
 
    waitbar(0.5,h_waitExt);
    for k = 1:block_per_col;
        for l = 1:block_per_row;
            tmp= max(im5(x(k,:),x(l,:)));
            g_max(k,l)= max(tmp);
    
            tmp= min(im5(x(k,:),x(l,:)));
            g_min(k,l)= min(tmp);
    
            tmp= sum(im5(x(k,:),x(l,:)));
            tmp= sum(tmp);
            g_avg(k,l)= tmp/(block_size*block_size);
        end;
    end;

    waitbar(0.7,h_waitExt);
    %%%%%%%%%%%%extract watermark by assummimg that size of w_im and o_im is equal%%%%%%%%%%%%%%%%%%%%%%%%%%
    extracted_mark(1:block_per_col,1:block_per_row) = 1;
    sum_gw = 0;
    sum_go = 0;
    %=======initial random===========================
    % rand_size = 60;%mean 10,000 blocks,should not more than sqrt(n_block)
    % seed = 18;
    % n_block = block_per_row*block_per_col;
    % s = randint(rand_size,rand_size,[1,n_block],seed);
    % %================================================
    for k = 1:block_per_col;
        for l = 1:block_per_row;
            for i = x(k,:);
                for j = x(l,:);
                    sum_gw = sum_gw + im6(i,j);%marked image
                    sum_go = sum_go + im5(i,j);%original image
                end;
            end;
            if sum_gw < sum_go;
                extracted_mark(k,l) = 0;%black
            elseif sum_gw >= sum_go;
                extracted_mark(k,l) = 1;%white
            end;
            sum_gw = 0;
            sum_go = 0;
        
        end;
    end;
    waitbar(0.9,h_waitExt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(im5_info.ColorType,'truecolor')==1;
        im5 = im5_col;
    end;
    if strcmp(im6_info.ColorType,'truecolor')==1;
        im6 = im6_col;
    end;
    waitbar(1,h_waitExt,'Process is successful');
    delete(h_waitExt);

    

    try
    handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(extracted_mark),title('Extracted Watermark');
    clc;

    catch 
 
        handles.current_filename4='image_watermark_extract_bak.bmp';
        imwrite(extracted_mark,handles.current_filename4,'bmp')
        handles.h_subplotExtractedWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename4),title('Extracted Watermark');      
    end    
    
    
    
    
    
    
    handles.bool_openExtractWatermark=1;%set open extracted watermark image already
    handles.current_extracted_mark=extracted_mark;



    %enable pushbuttonSaveExtracted
    h_enablepushbuttonSaveExtracted=findobj('tag','pushbuttonSaveExtracted','Enable','off');
    set(h_enablepushbuttonSaveExtracted,'Enable','on');

    %enable pushbuttonExtractedWatermark_info
    h_enablepushbuttonExtractedWatermark_info=findobj('tag','pushbuttonExtractedWatermark_info','Enable','off');
    set(h_enablepushbuttonExtractedWatermark_info,'Enable','on');
    
    %enable pushbuttonShowRealExtract
    h_enablepushbuttonShowRealExtract=findobj('tag','pushbuttonShowRealExtract','Enable','off');
    set(h_enablepushbuttonShowRealExtract,'Enable','on');

    [filename4,pathname4]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filename4,0)|isequal(pathname4,0)
        disp('Status>> File is not saving right now...Please try again');
        handles.bool_extractWatermarkSave=0;%not save extracted watermark
        handles.current_filename4='image_extracted_bak.bmp';
        imwrite(handles.current_extracted_mark,handles.current_filename4,'bmp')
        guidata(hObject,handles);
        return;
    else
        disp(['Status>> File ', pathname4, filename4,'.bmp',' already saved'])
        filenameWrite=[pathname4 filename4 '.bmp'];
        imwrite(handles.current_extracted_mark,filenameWrite,'bmp')
        title([filename4 '.bmp']);
        handles.bool_extractWatermarkSave=1;%already save extracted watermark
        handles.current_filename4 = filenameWrite;
        guidata(hObject,handles);
    end
catch            
        msgbox('Program have error...And can''t be processing.Close and Open again ','Program error','warn','modal');
        delete(h_waitExt);
       return;
end
%[0.03 0.55  0.3 0.3]1
%[0.35 0.55  0.3 0.3]2
%[0.03 0.075  0.3 0.3]3
%[0.35 0.075  0.3 0.3]4
%==============================================================================================================================

% --- Executes on button press in pushbuttonSaveImageWithWatermark.
function pushbuttonSaveImageWithWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveImageWithWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles=guidata(hObject);
    marked_im5=handles.current_marked_im5;
    [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filename3,0)|isequal(pathname3,0)
        disp('Status>> File is not saving right now...Please try again');
        handles.bool_addWatermarkSave=0;%not save adding watermark
        guidata(hObject,handles);
        return;
    else
        disp(['Status>> File ', pathname3, filename3, ' already saved'])
        filenameWrite=[pathname3 filename3 '.bmp'];
        imwrite(marked_im5,filenameWrite,'bmp')
        handles.current_filename3 = filenameWrite;
        try
            handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title('Image with Watermark');
            title([filename3 '.bmp']);
            clc;
        catch
            msgbox('Program can''t show image with watermark After Saving. ','Can''t show image with watermark after Saving','error','modal');
            return;
        end
        guidata(hObject,handles);

    end


% --- Executes on button press in pushbuttonSaveExtracted.
function pushbuttonSaveExtracted_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveExtracted (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles=guidata(hObject);
extracted_mark=handles.current_extracted_mark;
[filename4,pathname4]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
if isequal(filename4,0)|isequal(pathname4,0)
    disp('Status>> File is not saving right now...Please try again');
    handles.bool_extractWatermarkSave=0;%not save extracted watermark
    guidata(hObject,handles);
    return;
else
    disp(['Status>> File ', pathname4, filename4, ' already saved'])
    filenameWrite=[pathname4 filename4 '.bmp'];
    imwrite(extracted_mark,filenameWrite,'bmp')
     handles.current_filename4 = filenameWrite;
     try
          handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(extracted_mark),title('Extracted Watermark');
          title([filename4 '.bmp']);
           clc;
     catch
            msgbox('Program can''t show extracted watermark After Saving. ','Can''t show extracted watermark after Saving','error','modal');
            return;
     end
    guidata(hObject,handles);
   
end


% --- Executes during object creation, after setting all properties.






% --- Executes on button press in pushbuttonOpenImageWithWatermark.
function pushbuttonOpenImageWithWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOpenImageWithWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename3,pathname3]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
if isequal(filename3,0)|isequal(pathname3,0)
    disp('Status>>File not Open');
    handles.bool_openImageWithWatermark=0;%Not open Image with watermark image
    return;
else
    disp(['Status>>','File ', pathname3, filename3, ' already openned'])
    temp_path3=[pathname3 filename3];
    handles.current_filename3 = temp_path3;
    guidata(hObject,handles);
end

image_x3=imread(handles.current_filename3);
handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x3),title(filename3);
clc;

guidata(hObject,handles);
handles.bool_openImageWithWatermark=1;% open Image with watermark image already
guidata(hObject,handles);

if (handles.bool_openOriginal) &&(handles.bool_openImageWithWatermark)
    
    %enable pushbuttonExtract
    h_enableExtract=findobj('tag','pushbuttonExtract','Enable','off');
    set(h_enableExtract,'Enable','on');
    
    %enable popupmenuAttackMethod
    h_enablepopupmenuAttackMethod=findobj('tag','popupmenuAttackMethod','Enable','off');
    set(h_enablepopupmenuAttackMethod,'Enable','on');
    
    %Enaable popupmenuBlockSizeExt
    set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');
end

if (handles.bool_openImageWithWatermark)
    %enable pushbuttonImageWithWatermark_info
    h_enablepushbuttonImageWithWatermark_info=findobj('tag','pushbuttonImageWithWatermark_info','Enable','off');
    set(h_enablepushbuttonImageWithWatermark_info,'Enable','on');
    
    %enable pushbuttonShowRealImageWithWatermark
    h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
    set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');
end


%enable pushbuttonShowRealImageWithWatermark
h_enablepushbuttonShowRealImageWithWatermark=findobj('tag','pushbuttonShowRealImageWithWatermark','Enable','off');
set(h_enablepushbuttonShowRealImageWithWatermark,'Enable','on');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%          Enable Attack Watermark        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                           
%enable pushbuttonResize
h_enablepushbuttonResize=findobj('tag','pushbuttonResize','Enable','off');
set(h_enablepushbuttonResize,'Enable','on');

%enable pushbuttonRotate
h_enablepushbuttonRotate=findobj('tag','pushbuttonRotate','Enable','off');
set(h_enablepushbuttonRotate,'Enable','on');

%enable pushbuttonFilter
h_enablepushbuttonFilter=findobj('tag','pushbuttonFilter','Enable','off');
set(h_enablepushbuttonFilter,'Enable','on');

%enable h_enablepushbuttonCrop
h_enablepushbuttonCrop=findobj('tag','pushbuttonCrop','Enable','off');
set(h_enablepushbuttonCrop,'Enable','on');

%enable h_enablepushbuttonJPEGCompression
h_enablepushbuttonJPEGCompression=findobj('tag','pushbuttonJPEGCompression','Enable','off');
set(h_enablepushbuttonJPEGCompression,'Enable','on');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





% --- Executes on button press in pushbuttonCrop.
function pushbuttonCrop_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonCrop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%im_NameCrop=handles.current_filename3;

    try
       
        imageCrop=imread(handles.current_filename3);
   catch
         msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         return;
    end
    try
   
        handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(imageCrop),title('Crop Image with Watermark here');
        guidata(hObject,handles);
        %imageCropped=imcrop(handles.h_subplotImageWithWatermark )     ;
        
        %diable button;
        %disp('0k');
        disOpenImage;
        disAddWatermark;
        disExtWatermark;
        disUtilityAttackWatermark;
        disUtilityMainWatermark;
        disInfoOriginal;
        disInfoWatermark;
        disInfoImageWithWatermrk;
        disInfoExtractWatermark;
        
        
                
        imageCropped=imcrop(imageCrop);      
        
    catch
       %msgbox('Program can''t open image with watermark to crop.','Can''t open image with watermark to crop','error','modal');
        msgbox('This function Don''t support in Stand Alone Application ...Please run in MATLAB environment ','Application Support Error','error','modal');
       %pushbuttonClearAll_Callback;
       startAgain;
       return;
    end
try

        handles.bool_openImageWithWatermark=1;
        guidata(hObject,handles);
        
        %enable pushbuttonSaveAttackwatermark
        set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');

        [filenameCrop,pathnameCrop]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
        if isequal(filenameCrop,0)|isequal(filenameCrop,0)
            disp('Status>>File is not saving right now');
            handles.bool_cropAttackSave=0;;%not save crop attack watermark
            handles.bool_AttackWatermarkSave=0;%not save attack watermark
            handles.current_filename3='image_CropAttack_bak.bmp';
            guidata(hObject,handles);
            imwrite(imageCropped,handles.current_filename3,'bmp')
            %disable button
            disOpenImage;
            disAddWatermark;
            disExtWatermark;
            disUtilityAttackExceptSaveWatermark;
            disUtilityMainWatermark;
            disInfoOriginal;
            disInfoWatermark;
            disInfoExtractWatermark;

%            pushbuttonClearAll_Callback;
            
            try
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After cropping');
               clc;
            catch
                msgbox('Program can''t show image with watermark After cropping. ','Can''t show image with watermark after cropping','error','modal');
                return;
            end
            return;
        else
            temp_pathCrop=[pathnameCrop filenameCrop];
            filenameWriteCrop=[pathnameCrop filenameCrop '.bmp'];
            disp([filenameWriteCrop]);
            imwrite(imageCropped,filenameWriteCrop,'bmp')
            handles.current_filename3=filenameWriteCrop;
            guidata(hObject,handles);
            disp(['Status>>','File ', filenameWriteCrop, ' already saved'])
            handles.bool_cropAttackSave=1;% save crop attack watermark
            handles.bool_AttackWatermarkSave=1;%not save attack watermark
            %eanble button
            EnaOpenImage;
            EnaUtilityAttackWatermark;
            EnaUtilityMainWatermark;
            EnaInfoImageWithWatermrk;
           
            try 
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After cropping');
                clc;    
            catch
                msgbox('Program can''t show image with watermark After cropping. ','Can''t show image with watermark after cropping','error','modal');
                return;
            end
        end
 catch        
     msgbox('Program process error or Don''t support in Stand Alone Application ... ','Program error Or Support Error','warn','modal');
     return;
 end

% --- Executes on button press in pushbuttonResize.
function pushbuttonResize_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonResize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    try
        imageResize=imread(handles.current_filename3);
    catch
         msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         return;
    end


    resizePrompt={'Input Size Image...<Decreaes Size(0<Size<=1)>...<Increase Size(Size>1)>'};
    dlgResize_title='Input Size Image';
    defResize     = {'1'};
    resizeNum_lines=1;

    temp_resizeAnswer=inputdlg(resizePrompt,dlgResize_title,resizeNum_lines,defResize);
    
    
    if isempty(temp_resizeAnswer)
        msgbox('You cancel input resize number program will do nothing ','Cancel input resize ','error','modal');
        return;
    end;    

    resizeAnswer=str2num(temp_resizeAnswer{1});%first input array
    if isequal(temp_resizeAnswer,{''})
         resizeAnswer=1;
         h_resizeAnswerinvalid=msgbox('You don''t input resize number. Program will use defualt(1)','Resize number is invalid','warn','modal');
         uiwait(h_resizeAnswerinvalid);
     else   
         if isnan(str2double(temp_resizeAnswer))
                msgbox('You  input not a number for resizing  program will do nothing ','Cancel input Password ','error','modal');
                 return;
         end   
     end             

    


    if  resizeAnswer <= 0
        msgbox('You  input resize number not a positive integer program will do nothing ','Error resize number ','error','modal');
        return;
    else
          try  
              imageResized=imresize(imageResize,resizeAnswer);
          catch
                msgbox(' Maximum variable size allowed by the program is exceeded Or some parameters error. Program will do nothing ','Error resize number ','error','modal');
                return;
            end              
    end
        
        %enable pushbuttonSaveAttackwatermark
        set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
        
    [filenameResize,pathnameResize]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filenameResize,0)|isequal(pathnameResize,0)
            disp('Status>>File is not saving right now');
    
    
    
            handles.bool_resizeAttackSave=0;%not save crop attack watermark
            handles.bool_AttackWatermarkSave=0;%not save  attack watermark
            handles.current_filename3='image_CropAttack_bak.bmp';
            guidata(hObject,handles);
            imwrite(imageResized,handles.current_filename3,'bmp')
            %disable button
            disOpenImage;
            disAddWatermark;
            disExtWatermark;
            disUtilityAttackExceptSaveWatermark;
            disUtilityMainWatermark;
            disInfoOriginal;
            disInfoWatermark;
            disInfoExtractWatermark;
            try
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After resizing');
               clc;
               handles.bool_openImageWithWatermark=1;
               guidata(hObject,handles);
            catch
                msgbox('Program can''t show image with watermark After resizing. ','Can''t show image with watermark after resizing','error','modal');
                return;
            end
           return;
    else
        temp_pathResize=[pathnameResize filenameResize];
        filenameWriteResize=[pathnameResize filenameResize '.bmp'];
        disp([filenameWriteResize]);
        imwrite(imageResized,filenameWriteResize,'bmp')
        handles.current_filename3=filenameWriteResize;
        guidata(hObject,handles);
        disp(['Status>>','File ', filenameWriteResize, ' already saved'])
        handles.bool_resizeAttackSave=1;% save crop attack watermark
        handles.bool_AttackWatermarkSave=1;%save  attack watermark

          %eanble button
            EnaOpenImage;
            EnaUtilityAttackWatermark;
            EnaUtilityMainWatermark;
            try 
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After resizing');
                clc;    
            catch
                msgbox('Program can''t show image with watermark After resizing. ','Can''t show image with watermark after resizing','error','modal');
                return;
            end
     end
        




% --- Executes on button press in pushbuttonFilter.
function pushbuttonFilter_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonFilter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


    try
        imageFilter=imread(handles.current_filename3);
    catch
         msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         return;
    end

    h_filter=fspecial('average');
    
    %Enaable pushbuttonSaveAttackwatermark
     set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
    
    
    try
    imageFiltered=imfilter(imageFilter,h_filter);
    catch  
         %msgbox('Program have some parameter error ','Process error','error','modal');
         msgbox('This function Don''t support in Stand Alone Application ...Please run in MATLAB environment ','Application Support Error','error','modal');
         return;
     end        
     [filenameFiltered,pathnameFiltered]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
     if isequal(filenameFiltered,0)|isequal(pathnameFiltered,0)
            disp('Status>>File is not saving right now');
            handles.bool_filterAttackSave=0;%not save crop attack watermark
            handles.bool_AttackWatermarkSave=0;%not save  attack watermark
            handles.current_filename3='image_FilterAttack_bak.jpg';
            guidata(hObject,handles);
            imwrite(imageFiltered,handles.current_filename3,'bmp');
            %disable button
            disOpenImage;
            disAddWatermark;
            disExtWatermark;
            disUtilityAttackExceptSaveWatermark;
            disUtilityMainWatermark;
            disInfoOriginal;
            disInfoWatermark;
            disInfoExtractWatermark;

            try
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After filter');
               clc;
               handles.bool_openImageWithWatermark=1;
               guidata(hObject,handles);
            catch
                msgbox('Program can''t show image with watermark After filter.' ,'Can''t show image with watermark after filter.','error','modal');
                return;
            end
           return;
    else
        %temp_pathFiltered=[pathnameFiltered filenameFiltered];
        filenameWriteFiltered=[pathnameFiltered filenameFiltered '.bmp'];
        
        imwrite(imageFiltered,filenameWriteFiltered,'bmp');
        
        handles.current_filename3=filenameWriteFiltered;
        guidata(hObject,handles);
        disp(['Status>>','File ', filenameWriteFiltered, ' already saved'])
        handles.bool_JPEGAttackSave=1;% save crop attack watermark
        handles.bool_AttackWatermarkSave=1;%save  attack watermark

          %eanble button
            EnaOpenImage;
            EnaUtilityAttackWatermark;
            EnaUtilityMainWatermark;
            try 
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After Filtered ');
               clc;    
            catch
                msgbox('Program can''t show image with watermark After Filtered. ','Can''t show image with watermark after Filtered','error','modal');
                return;
            end
     end

 

% --- Executes on button press in pushbuttonFilter.
function pushbuttonRotate_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonRotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    try
        imageRotate=imread(handles.current_filename3);
    catch
        msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
        return;
    end
    %%%%%%%%%%%%%%%% rotate  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    try
        handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(imageRotate),title('Rotate Image with Watermark');
    catch
        msgbox('Program can''t open image with watermark to crop. ','Can''t open image with watermark to crop','error','modal');
        return;
    end

    %enable pushbuttonSaveImageWithWatermark
    set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');




    %imageRotate=imread(handles.current_filename3);
    rotatePrompt={'Input Angle degree in a counter-clockwise direction(0<=Angle<=360) '};
    dlgRotate_title='Input Angle Degree';
    defRotate     = {'0'};
    rotateNum_lines=1;

     %input rotate number
     temp_rotateAnswer=inputdlg(rotatePrompt,dlgRotate_title,rotateNum_lines,defRotate);

     if isempty(temp_rotateAnswer)
        msgbox('You cancel input rotate program will do nothing ','Cancel rotate input Password ','warn','modal');
        return;
    end;    
    if isnan(str2double(temp_rotateAnswer{1}))
            msgbox('You  input rotate angle not a integer.Program will do nothing ','Error rotate input','error','modal');
            return;
    end
       
    rotateAnswer=str2num(temp_rotateAnswer{1});%first input array

    if  (rotateAnswer > 360) || (rotateAnswer < 0)
        msgbox('Input must between 0 to 360 Degree','Input Angle Degree Out of Range','error','modal');
        return;
    else
        try
             imageRotated=imrotate(imageRotate,rotateAnswer);
             
              %enable pushbuttonSaveAttackwatermark
              set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');

        catch
             msgbox('Program can''t process rotate attacking . ','Some parameter error..','error','modal');
            return;
        end            
    end
  
            %enable pushbuttonSaveAttackwatermark
            set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
   
    [filenameRotate,pathnameRotate]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filenameRotate,0)|isequal(pathnameRotate,0)
        disp('Status>>File is not saving right now');
        handles.bool_AttackWatermarkSave=0;%not save  attack watermark
        handles.current_filename3='image_RotateAttack_bak.bmp';
        guidata(hObject,handles);
        imwrite(imageRotated,handles.current_filename3,'bmp')
            %disable button
            disOpenImage;
            disAddWatermark;
            disExtWatermark;
            disUtilityAttackExceptSaveWatermark;
            disUtilityMainWatermark;
            disInfoOriginal;
            disInfoWatermark;
            disInfoExtractWatermark;
        try
           handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After rotating');
           clc;
           handles.bool_openImageWithWatermark=1;
           guidata(hObject,handles);
        catch
            msgbox('Program can''t show image with watermark After rotating. ','Can''t show image with watermark after rotating','error','modal');
            return;
        end
        return;
            
    else
        temp_pathRotate=[pathnameRotate filenameRotate];
        filenameWriteRotate=[pathnameRotate filenameRotate '.bmp'];
        imwrite(imageRotated,filenameWriteRotate,'bmp')
        handles.current_filename3=filenameWriteRotate;
        guidata(hObject,handles);
        disp(['Status>>','File ', filenameWriteRotate, ' already saved'])
        handles.bool_AttackWatermarkSave=1;% save crop attack watermark
        try
           handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After rotating');
        catch
            msgbox('Program can''t show image with watermark After rotating. ','Can''t show image with watermark after rotating','error','modal');
            return;
        end
    end




     
        

% --- Executes on button press in pushbuttonShowRealOriginal.
function pushbuttonShowRealOriginal_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowRealOriginal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%figure('Name','Watermarked Image')
%h_realSizeOriginal=figure('Name','Show Real Original Iamge Size'),imshow(handles.current_filename1);
figure('Name','Show Real Original Iamge Size'),imshow(handles.current_filename1);
disp(['Status>>Show real original image have already shown'])

% --- Executes on button press in pushbuttonJPEGCompression.
function pushbuttonJPEGCompression_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonJPEGCompression (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%function jpeg(infile,percent,outfile)
%file to be compressed
%jpeg output file name
%output image quality 1-100
%q = 100-percent;
%in_info = imfinfo(infile);
%im = imread(infile,in_info.Format);
%imwrite(im,outfile,'Quality',q);

%jpeg_outfile='default.jpg';

    try
        imageJPEG=imread(handles.current_filename3);
    catch
         msgbox('You must open image with watermark first... ','Forgot to open image with watermark ','warn','modal');
         return;
    end



    jpegPrompt={'Input quality of compression JPEG (0-100)'};
    dlgJpeg_title='Input  Quality JPEG compression';
    defJpeg     = {'100'};
    jpegNum_lines=1;

    %input jpeg percent number
    temp_jpegAnswer=inputdlg(jpegPrompt,dlgJpeg_title,jpegNum_lines,defJpeg);

    if isempty(temp_jpegAnswer)
        msgbox('You cancel input JPEG Quality number program will do nothing ','Cancel input JPEG Quality ','error','modal');
        return;
    end;    

    jpegAnswer=str2num(temp_jpegAnswer{1});%first input array
    
    if isequal(temp_jpegAnswer,{''})
         jpegAnswer=100;
         h_jpegAnswerinvalid=msgbox('You don''t input JPEG Quality number. Program will use defualt(100)','PEG Quality number is invalid','warn','modal');
         uiwait(h_jpegAnswerinvalid);
     else  if  isnan(str2double(temp_jpegAnswer))
                   msgbox('You  input not a number for JPEG compression  program will do nothing ','Cancel input JPEG Quality','error','modal');
                   return;
             end   
     end        
    

        if  (jpegAnswer < 0) ||(jpegAnswer>100) 
            msgbox('You  input JPEG Quality number out of rang program will do nothing ','Error JPEG Quality number ','error','modal');
            return;
        end
       q = 100-jpegAnswer;

            %Enaable pushbuttonSaveAttackwatermark
            set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
    
    [filenameJPEG,pathnameJPEG]=uiputfile({'*.jpg','jpeg,jpg(*.jpg)'},'Save a file')
    if isequal(filenameJPEG,0)|isequal(pathnameJPEG,0)
            disp('Status>>File is not saving right now');
    
    
    
            handles.bool_JPEGAttackSave=0;%not save crop attack watermark
            handles.bool_AttackWatermarkSave=0;%not save  attack watermark
            handles.current_filename3='image_JPEGAttack_bak.jpg';
            guidata(hObject,handles);
            imwrite(imageJPEG,handles.current_filename3,'Quality',q);
            %disable button
            disOpenImage;
            disAddWatermark;
            disExtWatermark;
            disUtilityAttackExceptSaveWatermark;
            disUtilityMainWatermark;
            disInfoOriginal;
            disInfoWatermark;
            disInfoExtractWatermark;

            try
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark After JPEG compression');
               clc;
               handles.bool_openImageWithWatermark=1;
               guidata(hObject,handles);
            catch
                msgbox('Program can''t show image with watermark After JPEG compression.' ,'Can''t show image with watermark after JPEG compression.','error','modal');
                return;
            end
           return;
    else
        temp_pathJPEG=[pathnameJPEG filenameJPEG];
        filenameWriteJPEG=[pathnameJPEG filenameJPEG '.jpg'];
        
        imwrite(imageJPEG,filenameWriteJPEG,'Quality',q);
        
        handles.current_filename3=filenameWriteJPEG;
        guidata(hObject,handles);
        disp(['Status>>','File ', filenameWriteJPEG, ' already saved'])
        handles.bool_JPEGAttackSave=1;% save crop attack watermark
        handles.bool_AttackWatermarkSave=1;%save  attack watermark

          %eanble button
            EnaOpenImage;
            EnaUtilityAttackWatermark;
            EnaUtilityMainWatermark;
            try 
               handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(handles.current_filename3),title('Image with Watermark Saved After JPEG compression');
               clc;    
            catch
                msgbox('Program can''t show image with watermark After JPEG compression. ','Can''t show image with watermark after JPEG compression','error','modal');
                return;
            end
     end
               
% --- Executes on button press in pushbuttonShowRealWatermark.
function pushbuttonShowRealWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowRealWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%h_realSizeWatermark=figure('Name','Show Real Watermark Iamge Size'),imshow(handles.current_filename2);
figure('Name','Show Real Watermark Iamge Size'),imshow(handles.current_filename2);
disp(['Status>>Show real watermark image have already shown'])

% --- Executes on button press in pushbuttonShowRealImageWithWatermark.
function pushbuttonShowRealImageWithWatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowRealImageWithWatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h_realSizeImageWithWatermark=figure('Name','Show Real Image with Watermark Image Size'),imshow(handles.current_filename3);
disp(['Status>>Show real image with watermark have already shown'])

% --- Executes on button press in pushbuttonShowRealExtract.
function pushbuttonShowRealExtract_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowRealExtract (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h_realSizeExtract=figure('Name','Show Real Extracted Watermark Image Size'),imshow(handles.current_filename4);

% --- Executes on button press in pushbuttonExit.
function pushbuttonExit_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
exit_button=questdlg('Exit Now ?','Exit Watermark Program','Yes','No','No');
switch exit_button
    case 'Yes'
        delete(handles.figure1);
    case 'No'
        return
end




% --- Executes on button press in radiobuttonDefualt.
function radiobuttonDefualt_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonDefualt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonDefualt


% --- Executes during object creation, after setting all properties.
function popupmenuAttackMethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuAttackMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
   % handles.current_AttackMode='default';
    %guidata(hObject,handles);
   
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenuAttackMethod.
function popupmenuAttackMethod_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuAttackMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuAttackMethod contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuAttackMethod
popup_sel_index = get(handles.popupmenuAttackMethod,'Value');
%popup_sel_index = get(hObject,'Value');
%msgbox(popup_sel_index);

switch popup_sel_index
   case 1
      handles.current_AttackMode='default';
   case 2
      handles.current_AttackMode='resize';
   case 3
      handles.current_AttackMode='rotate';
      %set(handles.editrotateDegree,'Enable','on');
   case 4
      handles.current_AttackMode='crop';
   case 5
      handles.current_AttackMode='filter';
   case 6
      handles.current_AttackMode='jpeg_compression';
end 
guidata(hObject,handles);




% --- Executes on button press in pushbuttonOriginal_info.
function pushbuttonOriginal_info_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOriginal_info (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    handles.image_temp_info=handles.current_filename1;
    guidata(hObject,handles);
    imageInformation(hObject, eventdata, handles);
catch
    msgbox('You aren''t opening image now.','Forgot to open Image','error','modal') 
    return;
end
% --- Executes on button press in pushbuttonWatermark_info.
function pushbuttonWatermark_info_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonWatermark_info (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    handles.image_temp_info=handles.current_filename2;
    guidata(hObject,handles);
    imageInformation(hObject, eventdata, handles);
catch
    msgbox('You aren''t opening image now.','Forgot to open Image','error','modal') 
    return;
end

% --- Executes on button press in pushbuttonImageWithWatermark_info.
function pushbuttonImageWithWatermark_info_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImageWithWatermark_info (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    handles.image_temp_info=handles.current_filename3;
    guidata(hObject,handles);
    imageInformation(hObject, eventdata, handles);
catch
    msgbox('Image have an error','Can''display image information','error','modal') 
    return;
end


% --- Executes on button press in pushbuttonExtractedWatermark_info.
function pushbuttonExtractedWatermark_info_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonExtractedWatermark_info (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    handles.image_temp_info=handles.current_filename4;
    guidata(hObject,handles);
    imageInformation(hObject, eventdata, handles);
catch
    msgbox('Image have an error','Can''display image information','error','modal') 
    return;
end

% --- Executes on button press in pushbuttonPSNR_MSE.
function pushbuttonPSNR_MSE_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonPSNR_MSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
   % handles.image_psnr_original=handles.current_filename1;
    %handles.image_psnr_image_watermark=handles.current_filename3;
    %guidata(hObject,handles);
    disp(handles.current_filename1);
    disp(handles.current_filename3);
    clc;
    %find PSNR and MSE
    imageWatermarkInformation(hObject,eventdata, handles);
    catch
    msgbox('Can''t display PSNR and MSE...You must open Original Image and Image With watermark.','PSNR and MSE have an error','error','modal') 
    return;
end






% --- Executes on button press in pushbuttonSimilarity.
function pushbuttonSimilarity_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSimilarity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try  
    handles.image_similarity_original=handles.current_filename2;%watermark image
    handles.image_similarity_image_watermark=handles.current_filename4;%extracted watermark
    guidata(hObject,handles);
%    disp(handles.image_similarity_original);
 %   disp(handles.image_similarity_image_watermark);

catch
    msgbox('Can''t display Similarity...You must open Watermark Image and Extracted watermark image.','Similarity have an error','error','modal') 
    return;
end
    %call function find similarity
    imageExtractInformation(hObject,eventdata, handles);
    
% --- Executes on button press in pushbuttonClearAll.
function pushbuttonClearAll_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonClearAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%disp('%%% before     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
%disp(handles);
 try
       if (handles.bool_openOriginal)
            try
                if ishandle(handles.h_subplotOriginal)
                    delete(handles.h_subplotOriginal);
                end                    
                 handles.current_filename1='';
                guidata(hObject,handles);
                disInfoOriginal;
                if ishandle(handles.current_filename1)
                    delete(handles.current_filename1);
                end 
            catch
                disp('not delete handles 1' );    
            end    
       end
        
      if (handles.bool_openWatermark)
            try
                if ishandle(handles.h_subplotWatermark)
                    delete(handles.h_subplotWatermark);
                end
                handles.current_filename2=''
                guidata(hObject,handles);
                disInfoWatermark;
                if ishandle(handles.current_filename2)
                    delete(handles.current_filename2);
                end            
            catch                
            disp('not delete handles 2');
            end
       end             

            if (handles.bool_openImageWithWatermark)
                try
                    if ishandle(handles.h_subplotImageWithWatermark)
                        delete(handles.h_subplotImageWithWatermark);
                    end                        
                    handles.current_filename3=''
                    guidata(hObject,handles);
                    disInfoImageWithWatermrk;
                    if ishandle(handles.current_filename3)
                        delete(handles.current_filename3);
                    end                
                catch 
                  disp('not delete handles 3');
              end                    
            end    
            
            if(handles.bool_openExtractWatermark)

                try
                    if ishandle(handles.h_subplotExtractedWatermark)
                         delete(handles.h_subplotExtractedWatermark);
                     end
                        handles.current_filename4=''
                        guidata(hObject,handles);
                        disInfoExtractWatermark;
                     if ishandle(handles.current_filename4)
                        delete(handles.current_filename4);
                    end
                catch                            
                      disp('not delete handles 4');  
                end
          end
    
          %delete show of crop
          try
              delete(handles.h_subplotImageWithWatermark);
          catch
                disp('not delete crop');
          end
          
          
          
          
          
          
                    disp('not delete handles 5');
                    disp(handles);
                    handles.bool_openOriginal=0;
                    handles.bool_openWatermark=0;
                    handles.bool_openImageWithWatermark=0;
                    handles.bool_openExtractWatermark=0;
                    guidata(hObject,handles);
                    
               
                    %reset attack popup
                    set(findobj('tag','popupmenuAttackMethod'),'Value',1.0);
                    %attack mode
                    handles.current_AttackMode='default';
                    guidata(hObject,handles);

                     %block size add
                    handles.temp_popupblocksizeAdd=1;
                    guidata(hObject, handles);

                    %block size extracted
                    handles.temp_popupblocksizeExt=1;
                    guidata(hObject, handles);
                    
                    disAddWatermark;
                    disExtWatermark;
                    
                    set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','off'),
                    disp('After');
                    disp(handles);

                    clear;
                    clc;
         
                    
catch  
    msgbox('Program detect some errors and will terminate program.','Program Error','error','modal') 
    delete(handles.figure1);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%my Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%   Find Image information(Property) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function imageInformation(hObject, eventdata, handles)

    h_image=imfinfo(handles.image_temp_info);

    h_figImageInfo=imageinfo;%call function
    if gcf==h_figImageInfo
        set(findobj('tag','editFilename'),'String',h_image.Filename);
        set(findobj('tag','editFileModifyDate'),'String',h_image.FileModDate);
        set(findobj('tag','editFileSize'),'String',h_image.FileSize);
        set(findobj('tag','editImageFormat'),'String',h_image.Format);
        if h_image.Format =='bmp'
            set(findobj('tag','editImageFormatVersion'),'String',h_image.FormatVersion);
        else
            set(findobj('tag','editImageFormatVersion'),'String','It''s not bitmap image.So Can''t identify FormatVersion');
        end
        set(findobj('tag','editImageWidth'),'String',h_image.Width);
        set(findobj('tag','editImageHeight'),'String',h_image.Height);
        if h_image.Format =='bmp'
            set(findobj('tag','editImageCompressionType'),'String',h_image.CompressionType);
        else
        set(findobj('tag','editImageCompressionType'),'String','It''s not bitmap image.So Can''t identify CompressionType');
    end
end
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% FIND PSNR AND MSE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%im1  - Original image file name
% im2  - Watermarked image file name
% mse  � Mean Square Error
% psnr � Peak Signal to Noise Ratio
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function imageWatermarkInformation(hObject, eventdata, handles)

try    
%    im1= handles.image_psnr_original;
    im1= handles.current_filename1;
%    im2= handles.image_psnr_image_watermark;
    im2= handles.current_filename3;

    im1 = imread(im1);
    im1 = im2double(im1);

    im2 = imread(im2);
    im2 = im2double(im2);


    N = size(im1);

    iscolor = size(N);
        if iscolor(2) == 3;
            im1 = im1(:,:,3);
            im2 = im2(:,:,3);
        end;
    acc = 0;

    for k1=1:N(1)
          for k2=1:N(2)
             acc = acc+ ( im1(k1,k2) - im2(k1,k2) )^2;   
          end
    end

    mse  = acc/(N(1)*N(2));
    psnr = 10*log10((255^2)/mse);
%    disp(mse);
 %   disp(psnr);
    
    handles.mse_pass=mse;
    handles.psnr_pass=psnr;
    guidata(hObject,handles);

%      IMAGEWATERMARKINFO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGEWATERMARKINFO.M with the given input arguments.

% imagewatermarkinfo('CALLBACK',hObject,eventData,handles,...) calls the local   
%imagewatermarkinfo('imagewatermarkinfo_OpeningFcn',hObject,eventData,handles, varargin)   

%imagewatermarkinfo('editPSNR_CreateFcn',hObject,eventData,handles)
 %imagewatermarkinfo('editPSNR_CreateFcn',hObject,eventData,handles)

%function imagewatermarkinfo_OpeningFcn
%function editPSNR_CreateFcn
%function editMSE_CreateFcn
 
%    h_figWatermarkImageInfo=open('imagewatermarkinfo.fig');
   h_figWatermarkImageInfo=imagewatermarkinfo;

    
   if gcf==h_figWatermarkImageInfo
           set(findobj('tag','editPSNR'),'String',psnr);
          set(findobj('tag','editMSE'),'String',mse);
%           set(findobj(h_figWatermarkImageInfo,'tag','editPSNR'),'String',psnr);
%           set(findobj(h_figWatermarkImageInfo,'tag','editMSE'),'String',mse);
          % set(findobj(gcf,handles.editPSNR),'String',psnr);
         %  set(findobj(gcf,handles.editMSE),'String',mse);
     end    
         %end
 catch
    msgbox('Can''t display PSNR and MSE...Some parameters are missing Or program can''t read image.','PSNR MSE have an error','error','modal') 
    return;
end
 
 
 
 
 
 
 
 
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% FIND similarity  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
% function similarity(org,ext)
 function imageExtractInformation(hObject,eventdata,handles)
%org-> original watermark file name
%ext-> extracted image file name
%SIM Summary of this function goes here
%  Detailed explanation goes here
try
    org= handles.image_similarity_original;%original image
    ext=handles.image_similarity_image_watermark;%extracted image

if ischar(ext);
    ext = imread(ext);
end;
if ischar(org);
    org = imread(org);
end;
[m,n] = size(ext);
org=imresize(org,[m n]);
%m = row number
%n = column number
sim_im1(1:m*n)=1;
sim_im2(1:m*n)=1;

for i = 1:m ;
    sim_im1((n*(i-1)+1):(i*n)) = org(i,:);
    sim_im2((n*(i-1)+1):(i*n)) = ext(i,:);
end;

%sim_out = (sim_im1*sim_im2)/sqrt(sim_im2*sim_im2)
sim_out = ( dot(sim_im1,sim_im2)/sqrt( dot(sim_im2,sim_im2) ) )/( dot(sim_im1,sim_im1)/sqrt( dot(sim_im1,sim_im1) ) );

    handles.similarity_pass=sim_out;
  

    h_figImageExtractinfo=imageextractinfo;%handles function imageextractinfo

    
   if gcf==h_figImageExtractinfo
           set(findobj('tag','editSimilarity'),'String',handles.similarity_pass);
   end    
catch
    msgbox('Can''t display Similarity...Some parameters are missing Or program can''t read image.','PSNR MSE have an error','error','modal') 
    return;
end


% --- Executes on button press in pushbuttonOpenExtractedImage.
function pushbuttonOpenExtractedImage_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOpenExtractedImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename4,pathname4]=uigetfile({'*.bmp','Bitmap(*.bmp)';'*.jpg;*.jpeg','JPEG(*.jpg,*.jpeg)';},'Choose a file');
%msgbox(disp(filename4);
if isequal(filename4,0)|isequal(pathname4,0)
    disp('Status>>File not Open');
    handles.bool_openExtractWatermark=0;%not open extracted image
    return;
else
    disp(['Status>>','File  ', pathname4, filename4, ' already openned'])
    temp_path4=[pathname4 filename4];
    handles.current_filename4 = temp_path4;
end

image_x4=imread(handles.current_filename4);
%[0.35 0.075  0.3 0.3]4
handles.h_subplotExtractedWatermark=subplot('Position',[0.35 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(image_x4),title(filename4);
clc;

handles.bool_openExtractWatermark=1;%set open extracted image already
guidata(hObject,handles);
if(handles.bool_openExtractWatermark)
    %enable pushbuttonExtractedWatermark_info
    h_enablepushbuttonExtractedWatermark_info=findobj('tag','pushbuttonExtractedWatermark_info','Enable','off');
    set(h_enablepushbuttonExtractedWatermark_info,'Enable','on');

    %enable pushbuttonShowRealExtract
    h_enablepushbuttonShowRealExtract=findobj('tag','pushbuttonShowRealExtract','Enable','off');
    set(h_enablepushbuttonShowRealExtract,'Enable','on');
end


% --- Executes on button press in pushbuttonSaveAttackwatermark.
function pushbuttonSaveAttackwatermark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveAttackwatermark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


    handles=guidata(hObject);
    marked_im5=imread(handles.current_filename3);
    [filename3,pathname3]=uiputfile({'*.bmp','Bitmap(*.bmp)'},'Save a file')
    if isequal(filename3,0)|isequal(pathname3,0)
        disp('Status>> File is not saving right now...Please try again');
        handles.bool_AttackWatermarkSave=0;%not save attack watermark
        guidata(hObject,handles);
        return;
    else
        disp(['Status>> File ', pathname3, filename3, ' already saved'])
        filenameWrite=[pathname3 filename3 '.bmp'];
        imwrite(marked_im5,filenameWrite,'bmp')
        handles.current_filename3 = filenameWrite;
        handles.bool_AttackWatermarkSave=1;% save attack watermark
        EnaOpenImage;
        EnaUtilityAttackWatermark;
        EnaUtilityMainWatermark;
        EnaInfoImageWithWatermrk;
    
        try
            handles.h_subplotImageWithWatermark=subplot('Position',[0.03 0.075  0.3 0.3]),iptsetpref('ImshowBorder','tight'),imshow(marked_im5),title(['Save Attacking at ' filename3 '.bmp']);
            clc;
        catch
            msgbox('Program can''t show image with watermark After Saving. ','Can''t show image with watermark after Saving','error','modal');
            return;
        end

        guidata(hObject,handles);
       
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%%%%%%%%%%%%%%%%%%%%%%% Disable button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
function disOpenImage(hObject, eventdata, handles)
            %disable pushbuttonOpenOriginal
             set(findobj('tag','pushbuttonOpenOriginal'),'Enable','off');

             %disable pushbuttonOpenWatermark
             set(findobj('tag','pushbuttonOpenWatermark'),'Enable','off');

             %disable pushbuttonOpenImageWithWatermark
             set(findobj('tag','pushbuttonOpenImageWithWatermark'),'Enable','off');

             %disable pushbuttonOpenExtractedImage
             set(findobj('tag','pushbuttonOpenExtractedImage'),'Enable','off');

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function disAddWatermark(hObject, eventdata, handles)

            %Enaable popupmenuBlockSizeAdd
             set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','off');

             %Enaable popupmenuBlockSizeAdd
             set(findobj('tag','popupmenuBlockSizeAdd'),'Value',1.0);

             
            %disable pushbuttonAddWatermark
             set(findobj('tag','pushbuttonAddWatermark'),'Enable','off');
             
             %disable pushbuttonSaveImageWithWatermark
             set(findobj('tag','pushbuttonSaveImageWithWatermark'),'Enable','off');
            
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function disExtWatermark(hObject, eventdata, handles)


             
             %disable popupmenuBlockSizeExt
             set(findobj('tag','popupmenuBlockSizeExt'),'Enable','off');

             %disable popupmenuBlockSizeExt
             set(findobj('tag','popupmenuBlockSizeExt'),'Value',1.0);
             
            %disable popupmenuAttackMethod
             set(findobj('tag','popupmenuAttackMethod'),'Enable','off');

             %disable pushbuttonExtract
             set(findobj('tag','pushbuttonExtract'),'Enable','off');

             %disable pushbuttonSaveExtracted
             set(findobj('tag','pushbuttonSaveExtracted'),'Enable','off');
             
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function disUtilityAttackWatermark(hObject, eventdata, handles)
             %disable pushbuttonCrop
             set(findobj('tag','pushbuttonCrop'),'Enable','off');
             %disable pushbuttonRotate
            set(findobj('tag','pushbuttonRotate'),'Enable','off');
            
            %disable pushbuttonFilter
            set(findobj('tag','pushbuttonFilter'),'Enable','off');
            
            %disable pushbuttonResize
            set(findobj('tag','pushbuttonResize'),'Enable','off');
            
            %disable pushbuttonJPEGCompression
            set(findobj('tag','pushbuttonJPEGCompression'),'Enable','off');
            
            %disable pushbuttonSaveAttackwatermark
            set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','off');
            
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function disUtilityAttackExceptSaveWatermark(hObject, eventdata, handles)
             %disable pushbuttonCrop
             set(findobj('tag','pushbuttonCrop'),'Enable','off');
             %disable pushbuttonRotate
            set(findobj('tag','pushbuttonRotate'),'Enable','off');
            
            %disable pushbuttonFilter
            set(findobj('tag','pushbuttonFilter'),'Enable','off');
            
            %disable pushbuttonResize
            set(findobj('tag','pushbuttonResize'),'Enable','off');
            
            %disable pushbuttonJPEGCompression
            set(findobj('tag','pushbuttonJPEGCompression'),'Enable','off');
       
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
function disUtilityMainWatermark(hObject, eventdata, handles)
            
             %disable pushbuttonPSNR_MSE
             set(findobj('tag','pushbuttonPSNR_MSE'),'Enable','off');
             
             
             %disable pushbuttonSimilarity
             set(findobj('tag','pushbuttonSimilarity'),'Enable','off');
             
             
             %disable pushbuttonClearAll
             set(findobj('tag','pushbuttonClearAll'),'Enable','off');
             
             %disable pushbuttonExit
             set(findobj('tag','pushbuttonExit'),'Enable','off');
            
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
function disInfoOriginal(hObject, eventdata, handles)             
             
             %disable pushbuttonOriginal_info
             set(findobj('tag','pushbuttonOriginal_info'),'Enable','off');
             
             %disable pushbuttonShowRealOriginal
             set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','off');
function disInfoWatermark(hObject, eventdata, handles)                         
             
             %disable pushbuttonWatermark_info
             set(findobj('tag','pushbuttonWatermark_info'),'Enable','off');
             
             %disable pushbuttonShowRealWatermark
             set(findobj('tag','pushbuttonShowRealWatermark'),'Enable','off');
             
function disInfoImageWithWatermrk(hObject, eventdata, handles)                          
             
             %disable pushbuttonImageWithWatermark_info
             set(findobj('tag','pushbuttonImageWithWatermark_info'),'Enable','off');
             
             %disable pushbuttonShowRealImageWithWatermark
             set(findobj('tag','pushbuttonShowRealImageWithWatermark'),'Enable','off');
             
function disInfoExtractWatermark(hObject, eventdata, handles)                          
             
             %disable pushbuttonExtractedWatermark_info
             set(findobj('tag','pushbuttonExtractedWatermark_info'),'Enable','off');
             
             %disable pushbuttonShowRealExtract
             set(findobj('tag','pushbuttonShowRealExtract'),'Enable','off');
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%%%%%%%%%%%%%%%%%%%%%%% Enable button         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                            
             
function EnaOpenImage(hObject, eventdata, handles)
           
            %Enaable pushbuttonOpenOriginal
             set(findobj('tag','pushbuttonOpenOriginal'),'Enable','on');

             %Enaable pushbuttonOpenWatermark
             set(findobj('tag','pushbuttonOpenWatermark'),'Enable','on');

             %Enaable pushbuttonOpenImageWithWatermark
             set(findobj('tag','pushbuttonOpenImageWithWatermark'),'Enable','on');

             %Enaable pushbuttonOpenExtractedImage
             set(findobj('tag','pushbuttonOpenExtractedImage'),'Enable','on');

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function EnaAddWatermark(hObject, eventdata, handles)
     
             %Enaable popupmenuBlockSizeAdd
             set(findobj('tag','popupmenuBlockSizeAdd'),'Enable','on');

             %Enaable pushbuttonAddWatermark
             set(findobj('tag','pushbuttonAddWatermark'),'Enable','on');
             
             %Enaable pushbuttonSaveImageWithWatermark
             set(findobj('tag','pushbuttonSaveImageWithWatermark'),'Enable','on');
            
           

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function EnaExtWatermark(hObject, eventdata, handles)

            %Enaable popupmenuBlockSizeExt
             set(findobj('tag','popupmenuBlockSizeExt'),'Enable','on');

            %Enaable popupmenuAttackMethod
             set(findobj('tag','popupmenuAttackMethod'),'Enable','on');

             %Enaable pushbuttonExtract
             set(findobj('tag','pushbuttonExtract'),'Enable','on');

             %Enaable pushbuttonSaveExtracted
             set(findobj('tag','pushbuttonSaveExtracted'),'Enable','on');
             
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function EnaUtilityAttackWatermark(hObject, eventdata, handles)
             %Enaable pushbuttonCrop
             set(findobj('tag','pushbuttonCrop'),'Enable','on');
             %Enaable pushbuttonRotate
            set(findobj('tag','pushbuttonRotate'),'Enable','on');
            
            %Enaable pushbuttonFilter
            set(findobj('tag','pushbuttonFilter'),'Enable','on');
            
            %Enaable pushbuttonResize
            set(findobj('tag','pushbuttonResize'),'Enable','on');
            
            %Enaable pushbuttonJPEGCompression
            set(findobj('tag','pushbuttonJPEGCompression'),'Enable','on');
            
            %Enaable pushbuttonSaveAttackwatermark
            set(findobj('tag','pushbuttonSaveAttackwatermark'),'Enable','on');
            
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
function EnaUtilityAttackExceptSaveWatermark(hObject, eventdata, handles)
             %Enaable pushbuttonCrop
             set(findobj('tag','pushbuttonCrop'),'Enable','on');
             %Enaable pushbuttonRotate
            set(findobj('tag','pushbuttonRotate'),'Enable','on');
            
            %Enaable pushbuttonFilter
            set(findobj('tag','pushbuttonFilter'),'Enable','on');
            
            %Enaable pushbuttonResize
            set(findobj('tag','pushbuttonResize'),'Enable','on');
            
            %Enaable pushbuttonJPEGCompression
            set(findobj('tag','pushbuttonJPEGCompression'),'Enable','on');
       
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
function EnaUtilityMainWatermark(hObject, eventdata, handles)
            
             %Enaable pushbuttonPSNR_MSE
             set(findobj('tag','pushbuttonPSNR_MSE'),'Enable','on');
             
             
             %Enaable pushbuttonSimilarity
             set(findobj('tag','pushbuttonSimilarity'),'Enable','on');
             
             
             %Enaable pushbuttonClearAll
             set(findobj('tag','pushbuttonClearAll'),'Enable','on');
             
             %Enaable pushbuttonExit
             set(findobj('tag','pushbuttonExit'),'Enable','on');
            
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
function EnaInfoOriginal(hObject, eventdata, handles)             
             
             %Enaable pushbuttonOriginal_info
             set(findobj('tag','pushbuttonOriginal_info'),'Enable','on');
             
             %Enaable pushbuttonShowRealOriginal
             set(findobj('tag','pushbuttonShowRealOriginal'),'Enable','on');
function EnaInfoWatermark(hObject, eventdata, handles)                         
             
             %Enaable pushbuttonWatermark_info
             set(findobj('tag','pushbuttonWatermark_info'),'Enable','on');
             
             %Enaable pushbuttonShowRealWatermark
             set(findobj('tag','pushbuttonShowRealWatermark'),'Enable','on');
             
function EnaInfoImageWithWatermrk(hObject, eventdata, handles)                          
             
             %Enaable pushbuttonImageWithWatermark_info
             set(findobj('tag','pushbuttonImageWithWatermark_info'),'Enable','on');
             
             %Enaable pushbuttonShowRealImageWithWatermark
             set(findobj('tag','pushbuttonShowRealImageWithWatermark'),'Enable','on');
             
function EnaInfoExtractWatermark(hObject, eventdata, handles)                          
             
             %Enaable pushbuttonExtractedWatermark_info
             set(findobj('tag','pushbuttonExtractedWatermark_info'),'Enable','on');
             
             %Enaable pushbuttonShowRealExtract
             set(findobj('tag','pushbuttonShowRealExtract'),'Enable','on');
             
                         
function startAgain(hObject, eventdata, handles)    

pushbuttonClearAll_Callback;
EnaOpenImage;
             
             
             
             
                          
             
             
             
             


% --- Executes during object creation, after setting all properties.
function popupmenuBlockSizeAdd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSizeAdd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenuBlockSizeAdd.
function popupmenuBlockSizeAdd_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSizeAdd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuBlockSizeAdd contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSizeAdd

popup_sel_index_add = get(handles.popupmenuBlockSizeAdd,'Value');

switch popup_sel_index_add
    case 1
        block_size_add=1;
    case 2
        block_size_add=2;
    case 3
        block_size_add=4;
    case 4
        block_size_add=8;
    otherwise
        block_size_add=1;

end 


handles.temp_popupblocksizeAdd=block_size_add;
guidata(hObject,handles);

disp(handles.temp_popupblocksizeAdd);



% --- Executes during object creation, after setting all properties.
function popupmenuBlockSizeExt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSizeExt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenuBlockSizeExt.
function popupmenuBlockSizeExt_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuBlockSizeExt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuBlockSizeExt contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuBlockSizeExt

popup_sel_index_ext = get(handles.popupmenuBlockSizeExt,'Value');

switch popup_sel_index_ext
    case 1
        block_size_ext=1;
    case 2
        block_size_ext=2;
    case 3
        block_size_ext=4;
    case 4
        block_size_ext=8;
    otherwise
        block_size_ext=1;

end 


handles.temp_popupblocksizeExt=block_size_ext;
guidata(hObject,handles);
disp(handles.temp_popupblocksizeExt);
