function varargout = imageinfo(varargin)
% IMAGEINFO M-file for imageinfo.fig
%      IMAGEINFO, by itself, creates a new IMAGEINFO or raises the existing
%      singleton*.
%
%      H = IMAGEINFO returns the handle to a new IMAGEINFO or the handle to
%      the existing singleton*.
%
%      IMAGEINFO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGEINFO.M with the given input arguments.
%
%      IMAGEINFO('Property','Value',...) creates a new IMAGEINFO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before imageinfo_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to imageinfo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help imageinfo

% Last Modified by GUIDE v2.5 07-Mar-2004 00:58:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @imageinfo_OpeningFcn, ...
                   'gui_OutputFcn',  @imageinfo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before imageinfo is made visible.
function imageinfo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to imageinfo (see VARARGIN)

% Choose default command line output for imageinfo
handles.output = hObject;

%h_image=imfinfo('mark.bmp','bmp');
%set(handles.editFilename,'String',h_image.Filename);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes imageinfo wait for user response (see UIRESUME)
% uiwait(handles.figure2);



% --- Outputs from this function are returned to the command line.
function varargout = imageinfo_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function editFileModifyDate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFileModifyDate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editFileModifyDate_Callback(hObject, eventdata, handles)
% hObject    handle to editFileModifyDate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFileModifyDate as text
%        str2double(get(hObject,'String')) returns contents of editFileModifyDate as a double


% --- Executes during object creation, after setting all properties.
function editImageFormat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editImageFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editImageFormat_Callback(hObject, eventdata, handles)
% hObject    handle to editImageFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editImageFormat as text
%        str2double(get(hObject,'String')) returns contents of editImageFormat as a double


% --- Executes during object creation, after setting all properties.
function editFileSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFileSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editFileSize_Callback(hObject, eventdata, handles)
% hObject    handle to editFileSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFileSize as text
%        str2double(get(hObject,'String')) returns contents of editFileSize as a double


% --- Executes during object creation, after setting all properties.
function editImageHeight_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editImageHeight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editImageHeight_Callback(hObject, eventdata, handles)
% hObject    handle to editImageHeight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editImageHeight as text
%        str2double(get(hObject,'String')) returns contents of editImageHeight as a double


% --- Executes during object creation, after setting all properties.
function editImageWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editImageWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editImageWidth_Callback(hObject, eventdata, handles)
% hObject    handle to editImageWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editImageWidth as text
%        str2double(get(hObject,'String')) returns contents of editImageWidth as a double


% --- Executes during object creation, after setting all properties.
function editImageFormatVersion_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editImageFormatVersion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editImageFormatVersion_Callback(hObject, eventdata, handles)
% hObject    handle to editImageFormatVersion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editImageFormatVersion as text
%        str2double(get(hObject,'String')) returns contents of editImageFormatVersion as a double


% --- Executes during object creation, after setting all properties.
function editImageCompressionType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editImageCompressionType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editImageCompressionType_Callback(hObject, eventdata, handles)
% hObject    handle to editImageCompressionType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editImageCompressionType as text
%        str2double(get(hObject,'String')) returns contents of editImageCompressionType as a double




% --- Executes during object creation, after setting all properties.
function editPSNR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editPSNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editPSNR_Callback(hObject, eventdata, handles)
% hObject    handle to editPSNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editPSNR as text
%        str2double(get(hObject,'String')) returns contents of editPSNR as a double


% --- Executes during object creation, after setting all properties.
function editMSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function editMSE_Callback(hObject, eventdata, handles)
% hObject    handle to editMSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMSE as text
%        str2double(get(hObject,'String')) returns contents of editMSE as a double


% --- Executes on button press in pushbuttonInfoOK.
function pushbuttonInfoOK_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonInfoOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(gcf);