function varargout = imagewatermarkinfo(varargin)
% IMAGEWATERMARKINFO M-file for imagewatermarkinfo.fig
%      IMAGEWATERMARKINFO, by itself, creates a new IMAGEWATERMARKINFO or raises the existing
%      singleton*.
%
%      H = IMAGEWATERMARKINFO returns the handle to a new IMAGEWATERMARKINFO or the handle to
%      the existing singleton*.
%
%      IMAGEWATERMARKINFO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGEWATERMARKINFO.M with the given input arguments.
%
%      IMAGEWATERMARKINFO('Property','Value',...) creates a new IMAGEWATERMARKINFO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before imagewatermarkinfo_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to imagewatermarkinfo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help imagewatermarkinfo

% Last Modified by GUIDE v2.5 07-Mar-2004 02:00:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @imagewatermarkinfo_OpeningFcn, ...
                   'gui_OutputFcn',  @imagewatermarkinfo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before imagewatermarkinfo is made visible.
function imagewatermarkinfo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to imagewatermarkinfo (see VARARGIN)

% Choose default command line output for imagewatermarkinfo
handles.output = hObject;

%h_image=imfinfo('mark.bmp','bmp');
%set(handles.editFilename,'String',h_image.Filename);

% Update handles structure

guidata(hObject, handles);
%psnr_mse(hObject,eventdata,handles);

% UIWAIT makes imagewatermarkinfo wait for user response (see UIRESUME)
% uiwait(handles.figure2);


% --- Outputs from this function are returned to the command line.
function varargout = imagewatermarkinfo_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes during object creation, after setting all properties.
function editPSNR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editPSNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
% set(findobj('tag','editPSNR'),'String',psnr);
% set(findobj('tag','editPSNR'),'String',handles.psnr_pass);
% set(findobj('tag','editPSNR'),'String','PSNR');


function editPSNR_Callback(hObject, eventdata, handles)
% hObject    handle to editPSNR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editPSNR as text
%        str2double(get(hObject,'String')) returns contents of editPSNR as a double
% set(findobj('tag','editPSNR'),'String',handles.psnr_pass);          
           

% --- Executes during object creation, after setting all properties.
function editMSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end
% set(findobj('tag','editMSE'),'String',mse);
%set(findobj('tag','editMSE'),'String',handles.mse_pass );
% set(findobj('tag','editMSE'),'String','MSE');

function editMSE_Callback(hObject, eventdata,handles)
% hObject    handle to editMSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMSE as text
%        str2double(get(hObject,'String')) returns contents of editMSE as a double
%set(findobj('tag','editMSE'),'String',handles.mse_pass );

% --- Executes on button press in pushbuttonPSEN_Ok.
function pushbuttonPSEN_Ok_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonPSEN_Ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(gcf);

function psnr_mse(hObject,eventdata,handles)
    %im1 = imread(im1);
    im1=imread('lena.bmp');
    im1 = im2double(im1);

%   im2 = imread(im2);
    im2 = imread('lenawater.bmp');
    im2 = im2double(im2);


    N = size(im1);

    iscolor = size(N);
        if iscolor(2) == 3;
            im1 = im1(:,:,3);
            im2 = im2(:,:,3);
        end;
    acc = 0;

    for k1=1:N(1)
          for k2=1:N(2)
             acc = acc+ ( im1(k1,k2) - im2(k1,k2) )^2;   
          end
    end

    mse  = acc/(N(1)*N(2));
    psnr = 10*log10((255^2)/mse);
 %   disp(mse);
%    disp(psnr);
    
    handles.mse_pass=mse;
    handles.psnr_pass=psnr;
    guidata(hObject,handles);
set(findobj('tag','editMSE'),'String',handles.mse_pass );
 set(findobj('tag','editPSNR'),'String',handles.psnr_pass);