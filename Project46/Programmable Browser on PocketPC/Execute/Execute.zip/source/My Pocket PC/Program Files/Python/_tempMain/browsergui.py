from Tkinter import *
from config import *

class browser(Toplevel):
    def __init__( self,parent):
        Toplevel.__init__( self,parent )
        self.title( "Browser" )
        self.geometry( "235x270" )  # width x length
        #self.filepath = 'D:\\Project\\Example\\browser\\'
        self.filepath = picpath
        
        self.frame = Frame(self)
        self.menu = Menu(self)
        self.toolbar = Frame(self)
        self.textbox = Frame(self)
        self.addressbar = Frame(self)

        #menubar
        filemenu = Menu(self.menu)
        self.menu.add_cascade(label="File", menu=filemenu)
        filemenu.add_command(label="New")
        filemenu.add_command(label="Open..." )
        filemenu.add_command(label="Save")
        filemenu.add_command(label="Save as...")
        filemenu.add_separator()
        filemenu.add_command(label="Exit" )

        viewmenu = Menu(self.menu)
        self.menu.add_cascade(label="View", menu=viewmenu)
        viewmenu.add_command(label="Toolbar")

        favouritesmenu = Menu(self.menu)
        self.menu.add_cascade(label="Favourites",menu=favouritesmenu)
        favouritesmenu.add_command(label="Add favourites")
        favouritesmenu.add_command(label="Organize favourites")

        helpmenu = Menu(self.menu)
        self.menu.add_cascade(label="Help", menu=helpmenu)
        helpmenu.add_command(label="About...")


        #toolbar
        myImage0 = PhotoImage( file = self.filepath + "backbut.gif" )
        b = Button(self.toolbar, text="new", image = myImage0,relief = GROOVE,border="0")
        b.pack(side=LEFT)
        myImage1 = PhotoImage( file = self.filepath + "nextbut.gif" )
        b = Button(self.toolbar, text="open",image = myImage1,relief = GROOVE,border="0")
        b.pack(side=LEFT)
        myImage2 = PhotoImage( file = self.filepath + "stopbut.gif" )
        b = Button(self.toolbar, text="open",image = myImage2,relief = GROOVE,border="0")
        b.pack(side=LEFT)
        myImage3 = PhotoImage( file = self.filepath + "refreshbut.gif" )
        b = Button(self.toolbar, text="new", image = myImage3,relief = GROOVE,border="0")
        b.pack(side=LEFT)
        myImage4 = PhotoImage( file = self.filepath + "homebut.gif" )
#        b = Button(self.toolbar, text="new", image = myImage4,relief = GROOVE,border="0")
        Button(self.toolbar, text="new", image = myImage4,relief = GROOVE,border="0").pack(side=LEFT)
        myImage5 = PhotoImage( file = self.filepath + "favourbut.gif" )
#        b = Button(self.toolbar, text="new", image = myImage5,relief = GROOVE,border="0")
        Button(self.toolbar, text="new", image = myImage5,relief = GROOVE,border="0").pack(side=LEFT)
        self.toolbar.pack(side=TOP, fill=X)

        #Addressbar
        Label(self.addressbar,text="Address:").pack(side =LEFT)
        Entry(self.addressbar,width=27).pack(side=LEFT)
        myImage5 = PhotoImage( file = self.filepath + "gobut.gif" )
        Button(self.addressbar, image = myImage5,border="1").pack(side=LEFT)
        self.addressbar.pack()

        #Display
        self.scrollbar = Scrollbar(self)
        textboxa = Text(self.textbox,width=38,height=1,yscrollcommand=self.scrollbar.set)
        textboxa.pack(fill=BOTH,expand=2)
        self.scrollbar.config(command=textboxa.yview)

        textBox = Text(self.frame,width=35,height=18,yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=textBox.yview)
        self.scrollbar.pack(side=RIGHT, fill=Y)
        textBox.pack(fill=BOTH,expand=2)

        #frame
        self.frame.pack(expand = NO)
        self.frame.master.geometry("235x270")
        self.frame.master.title("Browser")

if __name__ == "__main__":
    app = Tk()
    shell = browser(app)
    app.mainloop()        