import sys
import traceback
import string
import os
import Pmw

from config import *

from ftplib import FTP  
from Tkinter import *
from tkMessageBox import *

class ftp( Toplevel):
   """Demonstrate Entrys and Event binding"""

   def __init__( self,parent):
      """Create, pack and bind events to four Entrys"""

      Toplevel.__init__( self,parent )
      self.title( "Pocket FTP" )
      self.geometry( "235x270" )  # width x length
      #self.filepath = 'C:\\PythonCE\\browser\\'
      #self.filepath = '\\Program Files\\Python\\pic\\'
      self.filepath = picpath
      #self.filepath = 'D:\\Project\\Example\\browser\\'

      #--- section ---------------
      self.tarname = 'text.txt'                      # remote/local file name
      #self.dir = 'D:\\Project\\Example\\browser\\'
      self.dir = '\\Program Files\\Python\\ftpFile\\'
      self.listfile = []
      self.ftppath = []

      #--  frame1  stor input uri of ftp
      self.frame2 = Frame( self )
      self.frame2.pack( side=TOP,pady = 2 )

      self.lbl_uri = Label(self.frame2,text='Host:')
      self.lbl_uri.pack(side = LEFT, pady = 3)

      self.txt_uri = Entry( self.frame2, name = "uri",width=15 )
      self.txt_uri.insert( INSERT,'161.246.5.87' )
      self.txt_uri.pack(side = LEFT,pady = 3,padx=3 )

      self.lbl_port = Label(self.frame2,text='Port:')
      self.lbl_port.pack(side = LEFT,pady = 3)

      self.txt_port = Entry( self.frame2, name = "port",width=3 )
      self.txt_port.insert( INSERT,'21' )
      self.txt_port.pack(side = LEFT,pady = 3 ,padx= 5)
      self.btn_login = Button( self.frame2, name = "login", text='Login', command=self.login)
      self.btn_login.pack(side = LEFT, pady = 3, padx = 2)      

      #--  frame1  stor input username and password
      self.frame1 = Frame( self )
      self.frame1.pack( side=TOP,pady = 5 )

      self.lbl_username= Label(self.frame1,text='User Name')
      self.lbl_username.pack(side = LEFT, pady = 3)
      self.txt_username = Entry( self.frame1, name = "username",width=5 )
      self.txt_username.insert( INSERT,'ck13' )
 #     self.txt_username.bind( "<Return>", self.showContents )
      self.txt_username.pack( side = LEFT, pady = 3 )

      self.lbl_password= Label(self.frame1,text='Password')
      self.lbl_password.pack(side = LEFT, pady = 3)      
      self.txt_password = Entry( self.frame1, name = "password" , show='*',width=5)
      self.txt_password.insert( INSERT,'ck13' )
      self.txt_password.pack( side = LEFT, pady = 3 )

      # frame 3 stor all other FTP command buttom
      self.frame3 = Frame( self )
      self.ftpim = PhotoImage( file = self.filepath + "up.gif" )
      
      self.btn_up = Button( self.frame3,image = self.ftpim,command=self.up)
      self.btn_up.pack(side = LEFT, pady = 3, padx = 2)
      
      self.btn_load = Button( self.frame3, name = "load", text='load', command=self.loadfile)
      self.btn_load.pack(side = LEFT, pady = 3, padx = 2)      
      self.frame3.pack( side=TOP, pady = 5 ) 

      # frame 4 stor  list box for show server file
      self.frame4 = Frame( self )
      self.frame4.pack(  side=TOP,pady = 5 )
      self.lib_showfile = Pmw.ScrolledListBox(self.frame4,items =self.listfile,vscrollmode='static',listbox_height = 4,dblclickcommand=self.loadfile,)#,selectioncommand = self.loadfile
      self.lib_showfile.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=2)

      # frame 5 stor a Entry that show FTP Message
      self.frame5 = Frame( self )
      self.frame5.pack( side=BOTTOM,pady = 0,fill=X )
      self.label = Label(self.frame5,text="",bd=1,relief=SUNKEN,anchor=W)
      self.label.pack(side = BOTTOM,fill = X)
      self.showsftptatus('')      

   def clear(self):
      self.label.config(text="")
      self.label.update_idletasks()

   def showsftptatus(self,message):
      print 'input:'+message
      self.label.config(text=message) 

   def set(self,format,*args):
      self.label.config(text=message %args)
      self.label.update_idletasks()

   def clear(self):
      self.label.config(text="")
      self.label.update_idletasks()
      status = StatusBar(root)
      status.pack(side=BOOTOM,fill =X)

   def up(self):
      if self.login==True:
         if len(self.ftppath)>=1:
            temp_dir=self.ftppath.pop()
            self.connection.cwd(temp_dir)
            self.showsftptatus('At dir:'+temp_dir)
            self.ref()

   def loadfile(self):
      if self.login==True :
         print 'Load file'
         chosen=self.lib_showfile.curselection()
         name=self.listfile[int(chosen[0])]
         if name.find('.')>=0:
            # select is a file
            try:	
               #print 'Downloading...'+name
               self.showsftptatus('Downloading...'+name)
               self.localfile  = open(self.dir+name, 'wb')
               self.connection.retrbinary('RETR ' + name, self.localfile.write, 1024)
               self.localfile.close()
               self.showsftptatus('Download OK '+name)
               #print 'Download OK '+name
            except Exception:
               print 'Can\'t Download '
         else:
            # select is a dir
            self.ftppath.append(self.connection.pwd()) # save the currentdir
            self.connection.cwd(name)               # chang dir
            self.showsftptatus('At dir:'+name)
            self.ref()
      else:
         self.notlogin = showinfo( "Message", "Not login" )

   def ref(self):
      self.listfile = self.connection.nlst()
      self.lib_showfile.setlist(self.listfile)

   def login(self):
      print 'FTP login:'+self.txt_uri.get()+":"+self.txt_username.get()+"@"+self.txt_password.get()
      try:
         self.connection = FTP()         # connect to ftp site self.txt_uri.get()
         self.connection.connect(self.txt_uri.get(),21)
         self.connection.login(self.txt_username.get(),self.txt_password.get())
         self.ftppath.append(self.connection.pwd())
         self.login = True
         self.showsftptatus(self.connection.getwelcome())
         self.ref()
         print 'Server Accept Login request'
      except Exception:
         self.login = False
         print "Can't login"
         self.cantlogin = showinfo("Message","Can't login")

#-----------------------------------------

   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(dict[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def showContents( self, event ):
      """Display the contents of the Entry"""
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      self.exedata = theContents

if __name__ == "__main__":
	app = Tk()
	shell = ftp( app)
	app.mainloop()