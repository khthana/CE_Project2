# 
# elog.py
# 
# Error Log function
#

elogh=None
elogw=None
elogf=None

def el_init(fn='elog.txt'):
	global elogh,elogw, elogf
	elogh=open(fn,'ab')
	elogw=elogh.write
	elogf=elogh.flush
	elogw("TEST")
	elogf()
	p("### elog initialized ###")
	return elogh

def p(s=None):
	global elogw, elogf
	if not s:
		elogw("\n")
		elogf()
		return
	elif s[-1] == ',':
		s = s[:-1]
		elogw(s)
		elogf()
		return
	elogw(s+"\n")
	elogf()
	return

##
