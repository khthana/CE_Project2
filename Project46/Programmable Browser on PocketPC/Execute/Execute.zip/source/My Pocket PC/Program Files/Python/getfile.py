from ftplib import FTP
from os.path import exists
from ftplib import FTP  

#----------------------------------------
import sys
import os

from ftplib import FTP  
from config import *
from getuserprofile import getuserprofile
from myftp import myftp


def getfile(c_filename,c_username='',c_password='',c_server='',c_port=''):

    self.upfd={}
    upf=getuserprofile()
    upf.getuserpf('ftp.profile',self.upfd)
    ##server :: 161.246.5.87
    ##username :: ck13
    ##password :: ck13
    ##port :: 21
    if c_filename == '':
        return
    
    if c_username == '' : c_username = self.upfd['username']
    if c_password == '' : c_password = self.upfd['password']
    if c_server == '' : c_server = self.upfd['server']
    if c_port == '' : c_port = self.upfd['port']


    self.ck_ftp = myftp(c_server,c_port,c_username,c_password)
    self.ck_ftp.login_ftp()
    self.ck_ftp.downloadfile_or_changdirto()
    self.ck_ftp.quit()

