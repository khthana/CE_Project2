# Fig. 10.7: fig10_07.py
# Button demonstration.

from Tkinter import *
from tkMessageBox import *

class PlainAndFancy( Frame ):
   """Create one plain and one fancy button"""
   
   def __init__( self ):
      """Create two buttons, pack them and bind events"""
      
      Frame.__init__( self )
      self.pack( expand = NO, fill = BOTH )
      self.master.title( "Buttons" )
      self.master.geometry("235x242")
      self.frame1 = Frame( self )
      self.frame1.pack( )
      
      # create button with text
      self.myImage0 = PhotoImage( file = filepath + "ftp2.gif" )
      self.plainButton = Button( self, image = self.myImage0, command = self.pressedPlain )
      self.plainButton.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton.config( relief = GROOVE )

      self.plainButton1 = Button( self.frame1, text = "Web Browser",command = self.pressedPlain )
      self.plainButton1.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton1.config( relief = GROOVE )      

      self.plainButton2 = Button( self.frame1, text = "File transfer",command = self.pressedPlain )
      self.plainButton2.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton2.config( relief = GROOVE )

      # plain 2
      self.frame2 = Frame( self )
      self.frame2.pack( )

      self.plainButton = Entry( self.frame2, name = "text3" )
      self.plainButton = Button( self, text = "button5",command = self.pressedPlain )
      self.plainButton.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton.config( relief = GROOVE )

      self.plainButton = Button( self, text = "button6",command = self.pressedPlain )
      self.plainButton.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton.config( relief = GROOVE )

      self.plainButton = Button( self, text = "button7",command = self.pressedPlain )
      self.plainButton.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton.config( relief = GROOVE )
      
      # create button with image
      self.myImage = PhotoImage( file = filepath + "logotiny.gif" )
      self.fancyButton = Button( self, image = self.myImage,
         command = self.pressedFancy )
      self.fancyButton.bind( "<Enter>", self.rolloverEnter )
      self.fancyButton.bind( "<Leave>", self.rolloverLeave )
      self.fancyButton.pack( side = LEFT, padx = 5, pady = 5 )

   def pressedPlain( self ):
      showinfo( "Message", "You pressed: Plain Button" )

   def pressedFancy( self ):
      showinfo( "Message", "You pressed: Fancy Button" )

   def rolloverEnter( self, event ):
      event.widget.config( relief = GROOVE )

   def rolloverLeave( self, event ):
      event.widget.config( relief = RAISED )

def main():
   PlainAndFancy().mainloop()

filepath = '\\Program Files\\Python\\'
#filepath= 'D:\\Project\\Example\\ch10\\'


main()

########################################################################## 
# (C) Copyright 2002 by Deitel & Associates, Inc. and Prentice Hall.     #
# All Rights Reserved.                                                   #
#                                                                        #
# DISCLAIMER: The authors and publisher of this book have used their     #
# best efforts in preparing the book. These efforts include the          #
# development, research, and testing of the theories and programs        #
# to determine their effectiveness. The authors and publisher make       #
# no warranty of any kind, expressed or implied, with regard to these    #
# programs or to the documentation contained in these books. The authors #
# and publisher shall not be liable in any event for incidental or       #
# consequential damages in connection with, or arising out of, the       #
# furnishing, performance, or use of these programs.                     #
##########################################################################
