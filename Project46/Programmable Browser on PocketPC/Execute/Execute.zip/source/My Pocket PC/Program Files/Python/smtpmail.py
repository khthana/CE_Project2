import smtplib, string, sys, time, mailconfig

mailserver = mailconfig.stmpservername
From = string.strip(raw_input('From? '))
To = string.strip(raw_input('To? '))
To = string.split(To, ';')
Subj = string.strip(raw_input('Subj?   '))

date = time.ctime(time.time())
text = ('From: %s\nTo: %s\nDate: %s\nSubject:%s\n' %(From, string.join(To,';'), date, Subj))

print 'Type message text, end with line=(ctrl + D or Z)'
while 1 :
	line = sys.stdin.readline()
	if not line:
		break
	text = text+line

if sys.platform[:3] == 'win' : print
print 'Connecting...'
server = smtplib.SMTP(mailserver)
failed = server.sendmail(From, To, text)
server.quit()
if failed:
	print 'Failed recipients: ',failed
else :
	print 'No errors.'

print 'Bye.'