# A "Python console" for Windows CE.
#
# Also works on NT/9x (with a few limitations!) - useful for debugging!
#
# Used 2 threads - one for UI (ie, the message loop) and another thread
# for executing Python code.  Uses very simple events to synchronise the 2!

from win32gui import *
from win32event import *
import sys
import string
import thread, threading
import traceback
import code # std module for compilation utilities.
import new
import os
import imp

#pypp IDOK=1
#define IDOK 1
#pypp IDCANCEL=2
#define IDCANCEL 2

#pypp GWL_WNDPROC=-4
#define GWL_WNDPROC -4
#pypp FIXED_PITCH=1
#define FIXED_PITCH 1
#pypp ANSI_FIXED_FONT=11
#define ANSI_FIXED_FONT 11

#pypp IDC_WAIT = 32514
#define IDC_WAIT 32514
#pypp HWND_TOP=0
#define HWND_TOP 0
#pypp CS_VREDRAW=1
#define CS_VREDRAW 1
#pypp CS_HREDRAW=2
#define CS_HREDRAW 2

#pypp CW_USEDEFAULT=0x80000000
#define CW_USEDEFAULT 0x80000000

#pypp WM_CHAR=258
#define WM_CHAR 258
#pypp WM_COMMAND=273
#define WM_COMMAND 273
#pypp WM_DESTROY=2
#define WM_DESTROY 2
#pypp WM_QUIT=18
#define WM_QUIT 18
#pypp WM_SETFOCUS=7
#define WM_SETFOCUS 7
#pypp WM_SETFONT=48
#define WM_SETFONT 48
#pypp WM_SETREDRAW=11
#define WM_SETREDRAW 11
#pypp WM_SIZE=5
#define WM_SIZE 5
#pypp WM_USER=1024
#define WM_USER 1024

#pypp WHITE_BRUSH=0
#define WHITE_BRUSH 0
#pypp SW_SHOW=5
#define SW_SHOW 5
#pypp SW_SHOWNORMAL=1
#define SW_SHOWNORMAL 1

#pypp WS_SYSMENU=524288
#define WS_SYSMENU 524288
#pypp WS_CLIPCHILDREN=33554432
#define WS_CLIPCHILDREN 33554432
#pypp WS_CHILD=1073741824
#define WS_CHILD 1073741824
#pypp WS_VISIBLE=268435456
#define WS_VISIBLE 268435456
#pypp WS_HSCROLL=1048576
#define WS_HSCROLL 1048576
#pypp WS_VSCROLL=2097152
#define WS_VSCROLL 2097152
if sys.platform=="wince":
	WS_OVERLAPPEDWINDOW=0
else:
	WS_OVERLAPPEDWINDOW=13565952

#pypp EM_GETLINECOUNT=186
#define EM_GETLINECOUNT 186
#pypp EM_GETSEL=176
#define EM_GETSEL 176
#pypp EM_LINEINDEX=187
#define EM_LINEINDEX 187
#pypp EM_LINEFROMCHAR=201
#define EM_LINEFROMCHAR 201
#pypp EM_LINELENGTH=193
#define EM_LINELENGTH 193
#pypp EM_SETSEL=177
#define EM_SETSEL 177
#pypp EM_REPLACESEL=194
#define EM_REPLACESEL 194

#pypp ES_LEFT=0
#define ES_LEFT 0
#pypp ES_MULTILINE=4
#define ES_MULTILINE 4
#pypp ES_WANTRETURN=4096
#define ES_WANTRETURN 4096
#pypp ES_AUTOVSCROLL=64
#define ES_AUTOVSCROLL 64
#pypp ES_AUTOHSCROLL=128
#define ES_AUTOHSCROLL 128

#pypp IDR_MENU=101
#define IDR_MENU 101
#pypp IDM_EXIT=40001
#define IDM_EXIT 40001
#pypp IDM_ABOUT=40002
#define IDM_ABOUT 40002
#pypp IDD_ABOUT=40002
#define IDD_ABOUT 40002

#pypp if UNICODE:
if UNICODE:
	TEXT = Unicode
else:
	TEXT = lambda x: x

if sys.platform=="wince":
	OutputDebugString = NKDbgPrintfW
else:
	from win32api import OutputDebugString
	
try:
	sys.ps1
except AttributeError:
	sys.ps1 = ">>> "
	sys.ps2 = "... "

class SimpleShell:
	editMessageMap = {}
	def __init__(self):
		self.bInteract = 0 # Am I interacting?
		self.hwnd = None
		self.hwndEdit = None
		self.outputQueue = []
		self.outputQueueLock = threading.Lock()

		# Allocate some events for thread sync
		self.currentBlockItems = None
		self.eventInteractiveInputAvailable = CreateEvent(None, 0, 0, None)
		self.eventClosed = CreateEvent(None, 0, 0, None)

	def __del__(self):
		print "InteractiveManager dieing"

	def write(self, text):
		text = string.replace(text, "\n", "\r\n")
		self.outputQueueLock.acquire()
		self.outputQueue.append(text)
		self.outputQueueLock.release()
		try:
#pypp 			PostMessage(self.hwnd, WM_USER, 0, 0)
			PostMessage(self.hwnd, 1024, 0, 0)
		except:
			pass
		
	def Run(self):
		PumpMessages()	

	def GetEditMessageMap(self):
#pypp 		return {WM_CHAR : self.OnEditChar}
		return {258 : self.OnEditChar}

	def GetParentMessageMap(self):
		map={}
#pypp 		map[WM_DESTROY] = self.OnParentDestroy
		map[2] = self.OnParentDestroy
#pypp 		map[WM_SIZE] = self.OnParentSize
		map[5] = self.OnParentSize
#pypp 		map[WM_SETFOCUS] = self.OnParentSetFocus
		map[7] = self.OnParentSetFocus
#pypp 		map[WM_USER] = self.OnParentUser
		map[1024] = self.OnParentUser
#pypp 		map[WM_COMMAND] = self.OnParentCommand
		map[273] = self.OnParentCommand
		return map
		
	def Init(self):
		try:
			self.hinst = GetModuleHandle(None)
		except NameError: # Not on CE??
			self.hinst = sys.hinst # But this is :-)

		InitCommonControls()

#pypp 		wc = WNDCLASS()
		wc = WNDCLASS()
		wc.hInstance = self.hinst
#pypp 		wc.style=CS_HREDRAW | CS_VREDRAW
		wc.style=2 | 1
#pypp 		wc.hbrBackground = GetStockObject(WHITE_BRUSH)
		wc.hbrBackground = GetStockObject(0)
#pypp 		wc.lpszClassName = TEXT("PYTHON_CE")
		wc.lpszClassName = TEXT("PYTHON_CE")
		# This code passes a dictionary as the "wndproc", rather than a function.
		wc.lpfnWndProc = self.GetParentMessageMap() #self.MainWndProc
		self.classAtom = RegisterClass(wc)
		
		if sys.platform=="wince":
#pypp 			style = WS_CLIPCHILDREN
			style = 33554432
		else:
#pypp 			style = WS_OVERLAPPEDWINDOW
			style = WS_OVERLAPPEDWINDOW
			
		self.hwnd = CreateWindow( self.classAtom, "Python CE", style, \
#pypp 	                      0, 0, CW_USEDEFAULT, CW_USEDEFAULT, \
	                      0, 0, 0x80000000, 0x80000000, \
	                      0, 0, self.hinst, None)

		left, top, right, bottom = GetClientRect(self.hwnd)

#		print sys.platform, type(sys.platform)
		if sys.platform=="wince":
			self.hCmdBar = CommandBar_Create(self.hinst, self.hwnd, 1)
#pypp 			CommandBar_InsertMenubar(self.hCmdBar, self.hinst, IDR_MENU, 0)
			CommandBar_InsertMenubar(self.hCmdBar, self.hinst, 101, 0)
			CommandBar_AddAdornments(self.hCmdBar, 0, 0)
			top = CommandBar_Height(self.hCmdBar)

#		style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL
#pypp 		style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN
		style = 1073741824|268435456|2097152|0|4|4096
		self.hwndEdit=CreateWindow("EDIT", None, style, \
				      left, top, (right-left), (bottom-top), \
		                      self.hwnd, 0, self.hinst, None)    
	
#pypp 		self.oldEditWndProc = SetWindowLong(self.hwndEdit, GWL_WNDPROC, self.GetEditMessageMap())# self.EditWndProc)
		self.oldEditWndProc = SetWindowLong(self.hwndEdit, -4, self.GetEditMessageMap())# self.EditWndProc)

		if sys.platform != "wince":
#pypp 			SendMessage(self.hwndEdit, WM_SETFONT, GetStockObject(ANSI_FIXED_FONT), 0)
			SendMessage(self.hwndEdit, 48, GetStockObject(11), 0)

#pypp 		ShowWindow(self.hwnd, SW_SHOW)
		ShowWindow(self.hwnd, 5)
		UpdateWindow(self.hwnd)

		EnableWindow(self.hwndEdit, 1)
	
		SetFocus(self.hwndEdit)
		SetCursor(LoadCursor(0,0))

	def Term(self):
		UnregisterClass(self.classAtom, self.hinst)
	
	def OnEditChar(self,hWnd, msg, wparam, lparam):
		if self.bInteract and wparam==0x0D: # return key
			HideCaret(hWnd);
#pypp 			cChar=SendMessage(hWnd, EM_LINEINDEX, -1)
			cChar=SendMessage(hWnd, 187, -1)
#pypp 			cLine=SendMessage(hWnd, EM_LINEFROMCHAR, cChar)
			cLine=SendMessage(hWnd, 201, cChar)
			# Find the start of the block
#pypp 			numLines = SendMessage(hWnd, EM_GETLINECOUNT, 0, 0)
			numLines = SendMessage(hWnd, 186, 0, 0)
			# GetLine fails as the size is wrong??
			maxLineSize=512
			blockStart = -1
			while cLine >= 0:
				line = str(Edit_GetLine(hWnd, cLine, maxLineSize))
				#line = repr(Edit_GetLine(hWnd, cLine, maxLineSize))
				if line[:4]==sys.ps1:
					blockStart = cLine
					break
				elif line[:4]!=sys.ps2:
					break
				cLine = cLine -1

			if blockStart>=0:
				# Find the end of the block.
				while 1:
					cLine = cLine + 1
					line = str(Edit_GetLine(hWnd, cLine, maxLineSize))
					if line is None or line[:4]!=sys.ps2:
						break
				blockEnd = cLine
				# blockStart is the first line
				# blockEnd is one past the block end.
				firstLine=str(Edit_GetLine(hWnd, blockStart, maxLineSize))[len(sys.ps1):]
				# Special case for an empty command - mimic Python better by writing another ">>>"
				if len(firstLine)==0 and blockStart+1==blockEnd:
					# Empty prompt - write a new one.
					self.write("\n"+sys.ps1)
				else:
					items = [firstLine]
					for cLine in range(blockStart+1, blockEnd):
						items.append( str(Edit_GetLine(hWnd, cLine, maxLineSize))[len(sys.ps2):] )

					# If the block is not at the end of the control, copy it there...
					if blockEnd != numLines:
						self.write("\n%s%s" % (sys.ps1, items[0]))
						for item in items[1:]:
							self.write("\n%s%s" % (sys.ps2, items[0]))
					else:
						# Ready to execute.
						self.currentBlockItems = items
						SetEvent(self.eventInteractiveInputAvailable)

			else:
				# Not in a block - write a new prompt.
				self.write("\n"+sys.ps1)

			ShowCaret(hWnd)
			return 0

		return CallWindowProc(self.oldEditWndProc, hWnd, msg, wparam, lparam)

	def OnParentSize(self, hwnd, msg, wparam, lparam):
		left, top, right, bottom = GetClientRect(hwnd)
		try:
			top=CommandBar_Height(self.hCmdBar);
		except NameError: # Only on CE
			pass
		if self.hwndEdit is not None:
#pypp 			SetWindowPos(self.hwndEdit, HWND_TOP, left, top, right-left, bottom-top, 0)
			SetWindowPos(self.hwndEdit, 0, left, top, right-left, bottom-top, 0)
#pypp 			ShowWindow(self.hwndEdit, SW_SHOWNORMAL)
			ShowWindow(self.hwndEdit, 1)

	def OnParentDestroy(self, hwnd, msg, wparam, lparam):
		PostQuitMessage(hwnd)
		# And tell the thread waiting for us we are done!
		SetEvent(self.eventClosed)

	def OnParentSetFocus(self, hwnd, msg, wparam, lparam):
		if self.hwndEdit is not None:
			SetFocus(self.hwndEdit)
	
	def OnParentUser(self, hwnd, msg, wparam, lparam):
		# Out write function post this message.
		# We dequeue the output, and write the text.
		while self.outputQueue:
			self.outputQueueLock.acquire()
			text = string.join(self.outputQueue, '')
			self.outputQueue = []
			self.outputQueueLock.release()
#pypp 			SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
			SendMessage(self.hwndEdit, 177, -2, -2)
			# Now check that we wont fill the control.
			# If so, remove the first lines until we are OK.
#pypp 			selInfo = SendMessage(self.hwndEdit, EM_GETSEL, 0, 0)
			selInfo = SendMessage(self.hwndEdit, 176, 0, 0)
#pypp 			endPos = HIWORD(selInfo)
			endPos = HIWORD(selInfo)
			lineLookIndex = 0
			lineLookLength = 0
			while endPos + len(text) - lineLookLength > 29000:
				lineLookIndex = lineLookIndex + 1
#pypp 				lineLookLength = SendMessage(self.hwndEdit, EM_LINEINDEX, lineLookIndex, 0)
				lineLookLength = SendMessage(self.hwndEdit, 187, lineLookIndex, 0)
			if lineLookIndex > 0:
				# The SETREDRAW has no effect on CE.  If we really want this
				# I think we must respond to WM_PAINT, and ignore it for the duration
				# the redraw is turned off.
#pypp 				SendMessage(self.hwndEdit, WM_SETREDRAW, 0, 0)
				SendMessage(self.hwndEdit, 11, 0, 0)
#pypp 				SendMessage(self.hwndEdit, EM_SETSEL, 0, lineLookLength)
				SendMessage(self.hwndEdit, 177, 0, lineLookLength)
#pypp 				SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(""))
				SendMessage(self.hwndEdit, 194, 0, TEXT(""))
				# And back to the end.
#pypp 				SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
				SendMessage(self.hwndEdit, 177, -2, -2)
#pypp 				SendMessage(self.hwndEdit, WM_SETREDRAW, 1, 0)
				SendMessage(self.hwndEdit, 11, 1, 0)
				
#pypp 			SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(text))
			#SendMessage(self.hwndEdit, 194, 0, TEXT(text))
			#SendMessage(self.hwndEdit, 194, 0, text) # send raw text...
			try:
				SendMessage(self.hwndEdit, 194, 0, TEXT(text))
			except TypeError:
				pass # ignore annoying string check...

	def OnParentCommand(self, hwnd, msg, wparam, lparam):
#pypp 		command = LOWORD(wparam)
		command = LOWORD(wparam)
#pypp 		if command == IDM_EXIT:
		if command == 40001:
			DestroyWindow(hwnd);
#pypp 		elif command == IDM_ABOUT:
		elif command == 40002:
#pypp 			DialogBox(self.hinst, IDD_ABOUT, hwnd, AboutBoxDlgProc)
			DialogBox(self.hinst, 40002, hwnd, AboutBoxDlgProc)
		return 0

def AboutBoxDlgProc(hwnd, msg, wparam, lparam):
#pypp 	if msg==WM_COMMAND:
	if msg==273:
#pypp 		p=LOWORD(wparam)
		p=LOWORD(wparam)
#pypp 		if p==IDOK or p==IDCANCEL:
		if p==1 or p==2:
			EndDialog(hwnd, 1)
		return 1
	return 0

def Interact(shell):
	shell.bInteract = 1
	locals = {}
	locals['shell']=shell
	sys.stdout.write("Python %s on %s\n%s\n%s" % (sys.version, sys.platform, sys.copyright, sys.ps1))
	
	while 1:
#pypp 		rc = WaitForMultipleObjects( (shell.eventInteractiveInputAvailable, shell.eventClosed), 0, INFINITE)
		rc = WaitForMultipleObjects( (shell.eventInteractiveInputAvailable, shell.eventClosed), 0, INFINITE)
#pypp 		if rc == WAIT_OBJECT_0:
		if rc == WAIT_OBJECT_0:
			codeText = string.join(shell.currentBlockItems, '\n')
			try:
				codeOb = code.compile_command(codeText)
			except SyntaxError:
				sys.stdout.write("\n")
				list = traceback.print_exc(0)
				sys.stdout.write(sys.ps1)
				continue
			except:
				traceback.print_exc()
				continue

			if codeOb is None:
				sys.stdout.write("\n%s" % sys.ps2)
				continue
			sys.stdout.write("\n")

#pypp 			SetCursor(LoadCursor(0, IDC_WAIT))
			SetCursor(LoadCursor(0, 32514))
			try:
				try:
					exec codeOb in locals
				except SystemExit:
					break
				except:
					exc_type, exc_value, exc_traceback = sys.exc_info()
					l = len(traceback.extract_tb(sys.exc_traceback))
					try: 1/0
					except:
						m = len(traceback.extract_tb(sys.exc_traceback))
					#traceback.print_exception(exc_type,
					#	exc_value, exc_traceback, l-m)
					traceback.print_exception(exc_type,
						exc_value, exc_traceback, 10)
					exc_traceback = None # Prevent a cycle
			finally:
				SetCursor(LoadCursor(0, 0))
				
			sys.stdout.write(sys.ps1)
		else:
			break

def RunCode(shell):
	try:
		# copy sys.argv before we stomp on it!
		sys.appargv = sys.argv[:]
		bKeepOpen = 0
		bInteract = 1
		cmdToExecute = None
		# Process sys.argv, removing args as we process them so any scripts
		# see _their_ argv!
		del sys.argv[0]
		# Remove some params the WCE debugger sometimes adds:
		sys.argv=filter(lambda arg: arg[:4]!="/WCE", sys.argv)
		i=0
		while i < len(sys.argv):
			if not sys.argv[i] or sys.argv[i][0]!='-':
				break
			if sys.argv[i]=='-i':
				bInteract = 1
				del sys.argv[i]
				continue
			elif sys.argv[i]=='-c':
				cmdToExecute = string.join(sys.argv[i+1:], ' ')
				sys.argv = sys.argv[:i-1]
				break
			i = i + 1
		
		if not sys.argv: sys.argv=['']

		if cmdToExecute is not None:
			try:
				exec cmdToExecute
			except:
				traceback.print_exc()
				bKeepOpen = 1
		elif len(sys.argv)>0 and sys.argv[0]:
			# Shift the args back to it sees itself as sys.argv[0]
			# Execute the named script
			fname = sys.argv[0]
			ext = os.path.splitext(fname)[1]
			if ext=='.pyc':
				mode="rb"
#pypp 				imp_params=("pyc", mode, imp.PY_COMPILED)
				imp_params=("pyc", mode, imp.PY_COMPILED)
			else:
				mode="r"
#pypp 				imp_params=("py", mode, imp.PY_SOURCE)
				imp_params=("py", mode, imp.PY_SOURCE)

			try:
				file = open(fname, mode)
			except IOError, (code, why):
				print "python: can't open %s: %s\n" % (fname, why)
				bKeepOpen = 1
				file = None
			if file:
				try:
					try:
						imp.load_module("__main__", file, fname, imp_params)
					except:
						traceback.print_exc()
						bKeepOpen = 1
				finally:
					file.close()
		else:
			bInteract = 1
		
		if bInteract:
			try:
				Interact(shell)
			except:
				traceback.print_exc()
				bKeepOpen = 1
	
		if not bKeepOpen:
#pypp 			PostThreadMessage(shellThreadId, WM_QUIT, 0, 0)
			PostThreadMessage(shellThreadId, 18, 0, 0)
	except:
		traceback.print_exc()
	
def main():
	# We run the shell in the main thread, so that when it terminates
	# (accidently or otherwise) the application terminates.
	# A seperate thread is used to execute the Python code.
	__name__ = sys.argv[0]

	# Make "shell" global just for debugging purposes
	# ie, so interactive code can see it via __main__.shell (or "ceshell.shell" on CE)
	global shell 
	shell = SimpleShell()
	global shellThreadId
	shellThreadId = thread.get_ident()
	# Create the windows, but dont start the message loop yet.
	shell.Init()

	# Can now write to the shell - assign the standard files.
	oldOut, oldErr = sys.stdout, sys.stderr
	sys.stderr = shell
	sys.stdout = shell

	# Create the new thread to execute the code.
	thread.start_new(RunCode, (shell,) )
	
	# Now run the shell.
	shell.Run()
	
	shell.Term()

	sys.stdout = oldOut
	sys.stderr = oldErr

# On Windows, run this as a script.
# On CE, this module is imported and main() executed by
# the startup C code.
if __name__=='__main__':
	main()
#pypp CONSTANTs not found:['UNICODE', 'WNDCLASS', 'TEXT', 'WS_OVERLAPPEDWINDOW', 'HIWORD', 'LOWORD', 'INFINITE', 'WAIT_OBJECT_0', 'PY_COMPILED', 'PY_SOURCE']
