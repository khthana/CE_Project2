from Tkinter import *

filepath = 'D:\\Project\\Example\\ch11\\Temp\\browser\\'
root = Tk()
frame = Frame(root)
menu = Menu(root)
toolbar = Frame(root)
root.config(menu=menu)
textbox = Frame(root)
server = Frame(root)
username=Frame(root)
password=Frame(root)
action=Frame(root)
#Addressbar
Label(server,text="Address:").pack(side =LEFT)
Entry(server,width=25).pack(side=LEFT)
server.pack()

Label(username,text="User Name:").pack(side =LEFT)
Entry(username,width=25).pack(side=LEFT)
username.pack()

Label(password,text="Password:").pack(side =LEFT)
Entry(password,width=25,show='*').pack(side=LEFT)
password.pack()


#Actionbar
Button(action,text="Retrive mail",border="1").pack(side=LEFT)
Button(action,text="Delete ",border="1").pack(side=LEFT)
Button(action,text="Forward ",border="1").pack(side=LEFT)
Button(action,text="Reply ",border="1").pack(side=LEFT)
Button(action,text="Save mail",border="1").pack(side=LEFT)
action.pack()
#Display
scrollbar = Scrollbar(frame)
textboxa = Text(textbox,width=38,height=1,yscrollcommand=scrollbar.set)
textboxa.pack(fill=BOTH,expand=2)
scrollbar.config(command=textboxa.yview)

textBox = Text(frame,width=35,height=18,yscrollcommand=scrollbar.set)
scrollbar.config(command=textBox.yview)
scrollbar.pack(side=RIGHT, fill=Y)
textBox.pack(fill=BOTH,expand=2)

#frame
frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("Mail")

mainloop()