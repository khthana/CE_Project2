# Module osce.py
# This file is read and integrated by os.py
# Call these funcs from os
#
# Telion

# CE patch for execv etc..
print "in osce"
def execv (path, args):
	import os
	p=os.path.abspath(path)
	#if os.path.exists(p):
	import win32process
	import string
	hPro,hThr,dwPro,dwThr=win32process.CreateProcess(p,string.join(args,' '),None,None,0,0,None,None,None)
	del string
	del win32process
	del os
#print "execv done"
def execve (path, args, env):
	import os
	p=os.path.abspath(path)
	import win32process
	import string
	hPro,hThr,dwPro,dwThr=win32process.CreateProcess(p,string.join(args,' '),None,None,0,0,env,None,None)
	del string
	del win32process
	del os

#print "execve done"

def system(cmd):
	#if os.path.exists(p):
	import win32process
	import string
	import os
	a = string.find(cmd, ' ')
	if a >0:
		p=cmd[:a]
	else:
		p=cmd
	p=os.path.abspath(p)
	hPro,hThr,dwPro,dwThr=win32process.CreateProcess(p,cmd[a+1:],None,None,0,0,None,None,None)
	del string
	del win32process
	del os

#print "system done"

def syscmd(icmd):
	#if os.path.exists(p):
	import win32process
	hPro,hThr,dwPro,dwThr=win32process.CreateProcess('\\windows\\cmd','/k '+icmd,None,None,0,0,None,None,None)
	del win32process

#print "syscmd done"

def syscmdc(icmd):
	#if os.path.exists(p):
	import win32process
	hPro,hThr,dwPro,dwThr=win32process.CreateProcess('\\windows\\cmd','/c '+icmd,None,None,0,0,None,None,None)
	del win32process

#print "syscmdc done"

import os
os.cwd='\\'
del os	

#print "os.cwd done"

def dirdir(top): # return only directory at the 'top' directory
	return filter(lambda n: os.path.isdir(n), os.listdir(top))
	# this could well be 
	#        return dirs(os.listdir(top))

def onlydir(d): # return only directory out of mixed file and directory list
	return filter(lambda n: os.path.isdir(n), d)

#print "onlydir done"

def normsort(dir): # sort list of directory and/or file normcased
	import os
	_dl=[]
	for d in dir: _dl.append(os.path.normcase(d),d)
	_dl.sort()
	return map(lambda d: d[1],_dl)
	del os

def msdir(p='.'):
	import os
	pp=os.path.abspath(p)
	if pp == '\\':
		pp=''
	if os.path.isdir(pp) or pp=='':
		return normsort(os.listdir(pp))
	elif os.path.exists(pp):
		return pp
	else:
		return None
	
#print "dir done"

def getcwd():
	import os
	return os.cwd
	del os

def chdir(p):
	import os
	pp=os.path.abspath(p)
	if os.path.isdir(pp):
		os.cwd=pp
		# print "os.cwd="+pp
		return 1
	
	# print "Error: Invalid directory;"+p
	# print "os.cwd="+os.cwd
	return 0
	del os

#print "chdir done"

# todo:
#
# def system(cmd):
# getcwd,chdir,putenv
# times
# fork, pipe, popen,


# End of ce patch
