import poplib, getpass, sys, mailconfig
from abstract import *

def newMail(mailserver, mailuser, mailpasswd, startMsgCount) :
	#print 'Connecting...'
	server = poplib.POP3(mailserver)
	server.user(mailuser)
	server.pass_(mailpasswd)

	try:
		#print server.getwelcome()
		msgCount, msgBytes = server.stat()
		if msgCount > startMsgCount : 
			newmailcount = msgCount - startMsgCount
			getnewmail = 1
		else : 
			newmailcount = 0
			getnewmail =0
		
	finally :
		server.quit()
	#print "getnewMail : ",getnewmail
	#print "newmailcount : ",newmailcount
	return [checkType(getnewmail),newmailcount]

def getStartMsgCount(mailserver, mailuser, mailpasswd) :
	print 'Connecting...'
	server = poplib.POP3(mailserver)
	server.user(mailuser)
	server.pass_(mailpasswd)

	try:
		print server.getwelcome()
		msgCount, msgBytes = server.stat()
		
	finally :
		server.quit()
	return msgCount