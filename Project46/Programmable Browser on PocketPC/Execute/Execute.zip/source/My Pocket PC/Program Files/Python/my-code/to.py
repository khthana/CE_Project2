# useing minidom   in page 104




#from xml.dom.ext.reader.Sax2 import FromXmlStream

import sys, string
from open_url import open_web

op = open_web()

#string = op.open(url="http://161.246.5.54:8080/123.html")
#string = op.open(url="http://127.0.0.1:8080/123.html")
#string = op.open(url="http://www.w3.org/TR/2003/WD-xhtml2-20030506/")
string = op.open(url="http://www.google.com")
print '<<BEGIN>>'
print string
print '<<END>>'




