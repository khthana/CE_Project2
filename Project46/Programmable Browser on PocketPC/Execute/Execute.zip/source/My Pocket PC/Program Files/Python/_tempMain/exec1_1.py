# Fig. 10.6: fig10_06.py
# Entry components and event binding demonstration.

import sys
import traceback
import string

import Pmw

from Tkinter import *
from tkMessageBox import *

class E( Frame ):
   """Demonstrate Entrys and Event binding"""

   
   #self.exedata = ""
   
   def __init__( self ):
      """Create, pack and bind events to four Entrys"""

      
      
      Frame.__init__( self )
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Testing exec function" )
      self.master.geometry( "235x242" )  # width x length

      self.frame1 = Frame( self )
      self.frame1.pack( pady = 5 )
      
      #self.in_txt = Text( self.frame1, name = "in_txt" ,row=6,size=20)
      #self.in_txt.bind( "<Return>", self.showContents )
      #self.in_txt.pack( side = LEFT, padx = 3 )

      self.in_txt = Pmw.ScrolledText( self.frame1,text_width = 25, text_height = 6, text_wrap = WORD,hscrollmode = "static", vscrollmode = "static" )
      self.in_txt.pack( side = LEFT, expand = YES, fill = BOTH, padx = 5, pady = 5 )      
      
      #self.in_txt = Pmw.ScrolledListBox(self.frame1,
      #   items =self.listfile,vscrollmode='static',listbox_height = 4,dblclickcommand=self.loadfile,)#,selectioncommand = self.loadfile
      #self.in_txt.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=2)


      self.frame2 = Frame( self )
      self.frame2.pack( pady = 5 )
      
      self.text3 = Entry( self.frame2, name = "text3" )
      self.text3.bind( "<Return>", self.showContents )
      self.text3.pack( side = LEFT, padx = 3 )

  
      self.frame3 = Frame( self )
      self.frame3.pack( pady = 5 )
      
      self.button2=Button( self.frame3, name = "exec", text='exec', command=self.myexec)
      self.button2.pack(side = LEFT, padx = 3)
      
      self.button1=Button( self.frame3, name = "read", text='read', command=self.settext)
      self.button1.pack(side = LEFT, padx = 3)

   def test(self,te):
      print te

   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(dict[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def myexec(self):
      self.exedata = self.in_txt.get()
      exec_(self,self.exedata)
      #exec theContents
      
   def showContents( self, event ):
      """Display the contents of the Entry"""
      
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      
      #self.text3.insert( INSERT, u )




tokens = (
    'NAME','NUMBER',
    'PLUS','MINUS','TIMES','DIVIDE','EQUALS',
    'LPAREN','RPAREN',
    )

# Tokens

t_PLUS    = r'\+'
t_MINUS   = r'-'
t_TIMES   = r'\*'
t_DIVIDE  = r'/'
t_EQUALS  = r'='
t_LPAREN  = r'\('
t_RPAREN  = r'\)'
t_NAME    = r'[a-zA-Z_][a-zA-Z0-9_]*'

def t_NUMBER(t):
    r'\d+'
    try:
        t.value = int(t.value)
    except ValueError:
        print "Integer value too large", t.value
        t.value = 0
    return t

t_ignore = " \t"

def t_newline(t):
    r'\n+'
    t.lineno += t.value.count("\n")
    
def t_error(t):
    print "Illegal character '%s'" % t.value[0]
    t.skip(1)




    
# Build the lexer
import lex
lex.lex()

# Parsing rules

precedence = (
    ('left','PLUS','MINUS'),
    ('left','TIMES','DIVIDE'),
    ('right','UMINUS'),
    )

# dictionary of names
names = { }

def p_statement_assign(t):
    'statement : NAME EQUALS expression'
    names[t[1]] = t[3]

def p_statement_expr(t):
    'statement : expression'
    print t[1]

def p_expression_binop(t):
    '''expression : expression PLUS expression
                  | expression MINUS expression
                  | expression TIMES expression
                  | expression DIVIDE expression'''
    if t[2] == '+'  : t[0] = t[1] + t[3]
    elif t[2] == '-': t[0] = t[1] - t[3]
    elif t[2] == '*': t[0] = t[1] * t[3]
    elif t[2] == '/': t[0] = t[1] / t[3]

def p_expression_uminus(t):
    'expression : MINUS expression %prec UMINUS'
    t[0] = -t[2]

def p_expression_group(t):
    'expression : LPAREN expression RPAREN'
    t[0] = t[2]

def p_expression_number(t):
    'expression : NUMBER'
    t[0] = t[1]

def p_expression_name(t):
    'expression : NAME'
    try:
        t[0] = names[t[1]]
    except LookupError:
        print "Undefined name '%s'" % t[1]
        t[0] = 0

def p_error(t):
    print "Syntax error at '%s'" % t.value





import yacc
yacc.yacc()

#while 1:
#    try:
#        s = raw_input('calc > ')
#    except EOFError:
#        break
#    yacc.parse(s)






def exec_(self,exedata):
   """ input a  exedata # stang format  and pass to exec()  function """
   try:
      try:
         #exedata = '''a=[10,20,30,40,50]
         #t=30'''
         #exec exedata in dict
         yacc.parse(exedata)

         #print 'Exec OK \n'
      except SystemExit:
         raise
      except:
         exc_type, exc_value, exc_traceback = sys.exc_info()
         l = len(traceback.extract_tb(sys.exc_traceback))
         print 'l :'+ str(l) +'\n'
         try:
            1/0
         except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
   finally:
      print 'End exec'





global tt
tt = 99
global dict
dict = {}

def main():
   E().mainloop()



main()
