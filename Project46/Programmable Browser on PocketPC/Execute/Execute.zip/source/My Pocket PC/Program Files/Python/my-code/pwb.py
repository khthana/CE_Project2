from Tkinter import *
#from MAIL import Mail
from temp import Dialog

def m():
    f = Dialog(root)

root = Tk()
filepath= 'D:\\Project\\Example\\ch11\\Temp\\'
menu = Menu(root)
toolbar = Frame(root)
root.config(menu=menu)
frame = Frame(root)

#frame

frame.pack(expand = NO)
frame.master.geometry("235x242")
frame.master.title("PWB")

#menubar
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New")
filemenu.add_command(label="Open..." )
filemenu.add_command(label="Save")
filemenu.add_command(label="Save as...")
filemenu.add_separator()
filemenu.add_command(label="Exit" )

editmenu = Menu(menu)
menu.add_cascade(label="Edit", menu=editmenu)
editmenu.add_command(label="Profile")

toolsmenu = Menu(menu)
menu.add_cascade(label="Tools",menu=toolsmenu)
toolsmenu.add_command(label="Web Browser")
toolsmenu.add_command(label="File Transfer")
toolsmenu.add_command(label="Mail Service")
helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About...")



#myImage0 = PhotoImage( file = filepath + "mail.gif" )
b = Button(toolbar, text="new", relief = GROOVE,command = m) #image = myImage0,
b.pack(side=LEFT)
#myImage1 = PhotoImage( file = filepath + "wb.gif" )
b = Button(toolbar, text="open",relief = GROOVE,command = m) #image = myImage1,
b.pack(side=LEFT)
#myImage2 = PhotoImage( file = filepath + "ftp.gif" )
b = Button(toolbar, text="close",relief = GROOVE,command = m) #image = myImage2,
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)
mainloop()