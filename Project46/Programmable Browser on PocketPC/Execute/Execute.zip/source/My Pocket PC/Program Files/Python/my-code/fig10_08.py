# Fig. 10.8: fig10_08.py
# Checkbuttons demonstration.

from Tkinter import *

class CheckFont( Frame ):
   """An area of text with Checkbutton controlled font"""
   
   def __init__( self ):
      """Create an Entry and two Checkbuttons"""
      
      Frame.__init__( self )
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Checkbutton Demo" )   
      
      self.frame1 = Frame( self )
      self.frame1.pack()
      
      self.text = Entry( self.frame1, width = 40,
         font = "Arial 10" )
      self.text.insert( INSERT, "Watch the font style change" )
      self.text.pack( padx = 3, pady = 3 )

      #self.frame2 = Frame( self )
     # self.frame2.pack()
      
      # create boolean variable
      self.boldOn = BooleanVar()

      # create "Bold" checkbutton
      self.checkBold = Checkbutton( self.frame1, text = "Bold", 
         variable = self.boldOn, command = self.changeFont )
      self.checkBold.pack(  padx = 3, pady = 3 )

      # create boolean variable
      self.italicOn = BooleanVar()

      # create "Italic" checkbutton
      self.checkItalic = Checkbutton( self.frame1, 
         text = "Italic", variable = self.italicOn, 
         command = self.changeFont )
      self.checkItalic.pack(  padx = 3, pady = 3 )

   def changeFont( self ):
      """Change the font based on selected Checkbuttons"""
      
      desiredFont = "Arial 10"

      if self.boldOn.get():
         desiredFont += " bold"
         self.master.title( "CK" )

      if self.italicOn.get():
         desiredFont += " italic"

      self.text.config( font = desiredFont )

def main():
   CheckFont().mainloop()


main()
