# Fig. 10.6: fig10_06.py
# Entry components and event binding demonstration.

import sys
import traceback
import string
import thread

import time
import threading
import Pmw

from Tkinter import *
from tkMessageBox import *

from Time3 import myTime
#from evenThread import CheckEvenThread

class CheckEvenThread( threading.Thread ):
   """Subclass of threading.Thread"""

   def __init__( self, threadName='defaulde' ,isleepTime=5,intk = None ):
      """Initialize thread, set sleep time, print data"""
      
      threading.Thread.__init__( self, name = threadName )
      self.sleepTime = isleepTime #5 #random.randrange( 1, 6 )
      print "Name: %s; sleep: %d" % \
            ( self.getName(), self.sleepTime )
      self.count = 0
      self.eventList=[]
      self.tk = intk
      self.checkEvent = TRUE
      self.eventitems=[]
      

   # overridden Thread run method
   def run( self ):
      """Sleep for 1 seconds"""  
      while self.count<500:         
         #mtime = myTime(self.li[3],self.li[4],self.li[5])  #hour=10,minute=11,second=12
         #if self.checkEvent:
         self.getCurrentTime()
         self.tk.setClock(self.__hour,self.__minute,self.__second)     
         self.count = self.count+1
         #time.sleep( self.sleepTime )
         time.sleep( 1 )
         
         #print "%s going to sleep for %s second(s) loop %s number" % \
         #   ( self.getName(), self.sleepTime ,self.count)
         #print self.getName(), "done sleeping"
   def getClock( self ):
      self.getCurrentTime()
      self.tk.setClock(self.__hour,self.__minute,self.__second)     

   def add( self,event ):
      self.eventList.append(event)

   def getCurrentTime(self):
      # setup my time to current
      self.li = time.localtime(time.time())
      self.__hour = self.li[3]
      self.__minute = self.li[4]
      self.__second = self.li[5]

   def testTime(self, h, m, s):
      ''' test ,  is in put time  valid '''
      if h > 24: return False
      if m > 60: return False
      if s > 60: return False
      return True
      
   def comPare( self, h, m, s):
      
      #print str(self.__hour)+' '+str(h)+' / '+str(self.__minute)+' '+str(m)+' / '+str(self.__second)+' '+str(s)
#if self.testTime(h,m,s)==True:
      if self.__hour > h:
         #print 'pass h'
         return False
      else:
         if self.__minute > m:
            #print 'pass m'
            return False
         else:         
            if self.__second > s:
               #print 'pass s'
               return False
      #print 'return true'
      return True

   def setCheckEvent( self, value):
      self.checkEvent = value
   
      

   def printEven( self ):
      self.getCurrentTime()
      #self.tk.textBox.delete('1.0', END)
      self.eventitems=[]
      for event  in self.eventList:
         if self.tk != None :
            hour1 = event.getHour()
            minute1 = event.getMinute()
            second1 = event.getSecond()
            thisEvent1 = event.getEvent()
            temp=':<'
            if self.comPare(hour1,minute1,second1):
               temp=':)'
            #print thisEvent + '-> '+':'+hour+':'+minute+':'+second
            
            temp = temp +' '+str(hour1)+':'+str(minute1)+':'+str(second1)+'  '+ thisEvent1 + '\n'
            
            #self.tk.textBox.insert( INSERT , temp)
            self.eventitems.append(temp)
         else:
            print ' OH NO MY GOD'

      return self.eventitems            

class E( Frame ):  #
   """Demonstrate Entrys and Event binding"""

   
   #self.exedata = ""
   
   def __init__(self):
      """Create, pack and bind events to four Entrys"""
      Frame.__init__(self)
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Event" )
      self.master.geometry( "235x242" )  # width x length

      self.listfile=[]      


     

      # frame2 store cloak  and gettime button
      self.frame2 = Frame( self )
      self.frame2.pack( pady = 5 )
      self.lbl_clock = Label(self.frame2,text='0')
      self.lbl_clock.pack(side = LEFT, padx = 3)
      self.btn_gettime=Button( self.frame2, name = "get", text='get', command=self.buildClock)
      self.btn_gettime.pack(side = LEFT, padx = 3)


     

      # frame4 store add time text box
      self.frame4 = Frame( self )
      self.frame4.pack( pady = 5 )
      
      self.lbl_hour = Label(self.frame4,text='Hour')
      self.lbl_hour.pack(side = LEFT)
      self.txt_hour = Entry(self.frame4,name = 'inputHour',width=3)
      self.txt_hour.insert(INSERT, '*')
      self.txt_hour.pack(side = LEFT)

      self.lbl_min = Label(self.frame4,text='Minute')
      self.lbl_min.pack(side = LEFT)      
      self.txt_min = Entry(self.frame4,name = 'inputMin', width=3)
      self.txt_min.insert( INSERT, '*')
      self.txt_min.pack(side = LEFT)

      self.lbl_sec = Label(self.frame4,text='Second')
      self.lbl_sec.pack(side = LEFT)        
      self.txt_sec = Entry(self.frame4,name = 'inputSecond',width=3)
      self.txt_sec.insert( INSERT, '*')
      self.txt_sec.pack(side = LEFT)



      # frame6 store input even name entry
      self.frame6 = Frame( self )
      self.frame6.pack( pady = 1 )
      self.lbl_evenname = Label(self.frame6,text='EvenName')
      self.lbl_evenname.pack(side = LEFT)
      self.txt_eventname= Entry(self.frame6,name = 'eventname',width=15)
      self.txt_eventname.pack(side = LEFT)

      # frame3 store add button  and check event button
      self.frame3 = Frame( self )
      self.frame3.pack( pady = 2 )
      self.btn_add=Button( self.frame3, name = "add", text='add', command=self.addEvent)
      self.btn_add.pack(side = LEFT, padx = 3)
      self.button3=Button( self.frame3, name = "check", text='check', command=self.readEvent)
      self.button3.pack(side = LEFT, padx = 3)      

   
      #lstB_h = Listbox(self.frame3)
      # fram5 store check output
      self.frame5 = Frame( self )
      self.frame5.pack( pady = 5 )
      
      #self.textBox = Text(self.frame5,width=15,height=5)
      #self.textBox.pack()
      self.lib_showevent = Pmw.ScrolledListBox(self.frame5,
         items =self.listfile,vscrollmode='static',listbox_height = 4,dblclickcommand=self.showeven,)#,selectioncommand = self.loadfile
      self.lib_showevent.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=2)
      

      ##########################################
      ## CheckEvenThread
      ##########################################
      self.checkEvenThread = CheckEvenThread( threadName='defaulde' , intk=self, isleepTime=1)
      #self.checkEvenThread = CheckEvenThread( threadName='defaulde' , intk=self, isleepTime=5)
      #self.checkEvenThread.start()

   def showeven(self):
      print 'show'

   def buildClock(self):
      self.li = time.localtime(time.time())   
      mtime = myTime(self.li[3],self.li[4],self.li[5])  #hour=10,minute=11,second=12
      #self.te = mtime.getHour()
      #self.text3.insert( INSERT, self.te ) #str(te)
      self.txt_hour.delete(0, END)
      self.txt_min.delete(0, END)
      self.txt_sec.delete(0, END)
      
      self.txt_hour.insert( INSERT, self.li[3])
      self.txt_min.insert( INSERT, self.li[4])
      self.txt_sec.insert( INSERT, self.li[5])
      
      self.buildThread()
      
   def buildThread( self ):
      
      self.checkEvenThread.getClock()
      #self.checkEvenThread.start()

      
      
   def setClock(self,hour,min,second):
      temp=str(hour)+':'+str(min)+':'+str(second)
      self.lbl_clock.config(text=temp)
   
   def addEvent( self ):
      ''' add Event to CheckEnevtList '''
      #self.txt_hour.insert( INSERT, self.li[3])
      #self.txt_min.insert( INSERT, self.li[4])
      #self.txt_sec.insert( INSERT, self.li[5])
      newEvent = myTime(int(self.txt_hour.get()),int(self.txt_min.get()),int(self.txt_sec.get()),self.txt_eventname.get())
      self.checkEvenThread.add(newEvent)

   def readEvent( self ):
      listitems = self.checkEvenThread.printEven()
      self.lib_showevent.setlist(listitems)
                          
   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(dict[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def myexec(self):
      self.exedata = self.text1.get()
      exec_(self,self.exedata)
      #exec theContents
      
   def showContents( self, event ):
      """Display the contents of the Entry"""
      
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      
      #self.text3.insert( INSERT, u )


def exec_(self,exedata):
   """ input a  exedata # stang format  and pass to exec()  function """
   try:
      try:
         #exedata = '''a=[10,20,30,40,50]
         #t=30'''
         exec exedata in dict
         print 'Exec OK \n'
      except SystemExit:
         raise
      except:
         exc_type, exc_value, exc_traceback = sys.exc_info()
         l = len(traceback.extract_tb(sys.exc_traceback))
         print 'l :'+ str(l) +'\n'
         try:
            1/0
         except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
   finally:
      print 'End exec'





global tt
tt = 99
global dict
dict = {}

def main():


   #checkEven = CheckEvenThread('text frist thread',10)
   #checkEven.start()
   #ch = CheckEvenThread( "thread1" ,5)
   #ch.start()
   #checkEven2 = CheckEvenThread('text frist thread',7)
   #checkEven2.start()
   
   E().mainloop()


main()














