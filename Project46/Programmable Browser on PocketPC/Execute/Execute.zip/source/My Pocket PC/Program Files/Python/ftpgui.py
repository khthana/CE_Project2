'''
ftpgui.py
Design GUI by Cherdkiat Saetae
Code Module by Chakrit Hengsirikul
* import class myftp in myftp.py (this is base class)
porblem:must make folder before use ( see detail in user profile or config.py)
---------------------------
2004/03/07
1.final test with myftp.py
2.chang to congif color by pwb.py
2004/03/15
print correctly
'''

import sys
import traceback
import string
import os
import Pmw

from config import *

from Tkinter import *
from tkMessageBox import *
from getuserprofile import getuserprofile
from myftp import myftp


class ftpgui(Toplevel):
   

   def __init__( self,parent,mycolor,select_color_number):
      Toplevel.__init__( self,parent )
      Pmw.initialise(parent)
      self.title( "PWB FTP" )
      self.geometry( "235x270" )  # width x length
      
      print 'Open FTP()'
      
      self.upfd={}
      upf=getuserprofile()
      upf.getuserpf('ftp.profile',self.upfd)
      ##server :: 161.246.5.87
      ##username :: ck13
      ##password :: ck13
      ##port :: 21
      #k=self.upfd.keys
      #for k in self.upfd:
      #   print k,' : ',self.upfd[k]

      self.SELECT_COLOR_NUMBER = select_color_number
      self.mycolor = mycolor
      #print mycolor
      

      #--- section ---------------
      self.filepath = picpath
      self.NEW_MYFTP = False  # indicate have myftp have create
      self.ftppath = ftppath.split('\\')
      self.ftppath = self.ftppath[:len(self.ftppath)-1]
      #self.local_current_dir = self.ftpdir
      self.localfilelist = [] # for store local  file in current view directory
      
      self.listfile = []  # for store server  file in current view directory



      #--  frame2  stor input uri of ftp
      self.frame2 = Frame( self )
      self.frame2.pack( side=TOP,expand = YES,fill=BOTH )
      
      self.lbl_uri = Label(self.frame2,text='Host:')
      self.lbl_uri.pack(side = LEFT)
      self.txt_uri = Entry( self.frame2, name = "uri",width=14)
      self.txt_uri.insert( INSERT,self.upfd['server'] )
      self.txt_uri.pack(side = LEFT,padx=2)

      self.lbl_port = Label(self.frame2,text='Port:')
      self.lbl_port.pack(side = LEFT)
      self.txt_port = Entry( self.frame2, name="port",width=3 )
      self.txt_port.insert( INSERT,self.upfd['port'])
      self.txt_port.pack(side = LEFT,padx= 5)

      self.btn_login = Button( self.frame2, name = "login", text='Login', command=self.login)
      self.btn_login.pack(side = RIGHT, padx = 2)

      #--  frame1  stor input username and password
      self.frame1 = Frame( self )
      self.frame1.pack( side=TOP,expand = YES,fill=BOTH)

      self.lbl_username= Label(self.frame1,text='User Name')
      self.lbl_username.pack(side = LEFT)
      self.txt_username = Entry( self.frame1, name ="username",width=10 )
      self.txt_username.insert( INSERT,self.upfd['username'] )
      self.txt_username.pack( side = LEFT)

      self.lbl_password= Label(self.frame1,text='Password')
      self.lbl_password.pack(side = LEFT)      
      self.txt_password = Entry( self.frame1, name ="password",show='*',width=8)
      self.txt_password.insert( INSERT,self.upfd['password'])
      self.txt_password.pack( side = LEFT)

      # frame 3 stor all other FTP command buttom
      self.frame3 = Frame( self )
      self.frame3.pack( side=TOP,fill = BOTH,expand =YES )
      self.ftpim = PhotoImage( file = self.filepath + "up.gif" )
      
      self.btn_loc_up = Button( self.frame3,image = self.ftpim,command=self.local_up)
      self.btn_loc_up.pack(side = LEFT, padx = 2)
      self.btn_upload = Button( self.frame3, name = "load", text='>>', command=self.upload_file)
      self.btn_upload.pack(side = LEFT, padx = 2)
      
      self.btn_ser_up = Button( self.frame3,image = self.ftpim,command=self.server_up)
      self.btn_ser_up.pack(side = RIGHT, padx = 2)
      self.btn_download = Button( self.frame3, name = "up", text='<<', command=self.download_file)
      self.btn_download.pack(side = RIGHT, padx = 2)


      # frame 4 stor  list box for show server file
      self.frame4 = Frame( self )
      self.frame4.pack(side=TOP,expand =YES,fill = BOTH)
      self.lib_localfile = Pmw.ScrolledListBox(self.frame4,
                                               items =self.listfile,
                                               vscrollmode='static',
                                               hscrollmode='static',
                                               listbox_width= '15',
                                               dblclickcommand=self.upload_file,    )
      self.lib_localfile.pack( side = LEFT)
      #n.component('page1-tab').configure(background = 'red')
      #['__call__', '__class__', '__cmp__', '__delattr__', '__doc__', '__get__', '__getattribute__', '__hash__', '__init__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__str__', 'im_class', 'im_func', 'im_self']

      #print "component",dir(self.lib_localfile.component('vertscrollbar')._configure())#background = 'red'

      #self.lib_localfile.component('vertscrollbar'))

      self.lib_serverfile = Pmw.ScrolledListBox(self.frame4,
                                                items =self.listfile,
                                                vscrollmode='static',
                                                hscrollmode='static',
                                                listbox_width= '15',
                                                dblclickcommand=self.download_file, )
      #self.lib_serverfile.configure(downarrow_background = 'green',uparrow_background = 'red')


      self.lib_serverfile.pack( side = RIGHT)

      # frame 5 stor a Entry that show FTP Message
      self.frame5 = Frame( self )
      self.frame5.pack( side=BOTTOM,fill=X,expand = YES )
      self.label = Label(self.frame5,text="",bd=1,relief=SUNKEN,anchor=W)
      self.label.pack(side=BOTTOM,fill = X,expand = YES)


      ## -- init config -- ^_^ --
      ## set local ScrolledListBox to show file
      self.showsftptatus_msg('')
      self.localfilelist = self.__get_local_filelist(self.__filepath_to_str())
      self.lib_localfile.setlist(self.localfilelist)
      ## set color   SELECT_COLOR_NUMBER
      self.setcolor(self.SELECT_COLOR_NUMBER)

##-----------------------------------------------------------------


   def showsftptatus_msg(self,message):
      #print 'input:'+message
      self.label.config(text=message)

   def showsftptatus(self):
      self.status = self.ftp.getftptatus()
      self.label.config(text=self.status)

   def clear(self):
      showsftptatus_msg('')


   def login(self):
      #print 'FTP login:'+self.txt_uri.get()+":"+self.txt_username.get()+"@"+self.txt_password.get()
      try:
         self.ftp=myftp(self.txt_uri.get(),self.txt_port.get(),self.txt_username.get(),self.txt_password.get())
         self.ftp.login_ftp()
         self.ftp.setlocaldir(self.__filepath_to_str())
         self.showsftptatus()
         self.__ref()
         self.NEW_MYFTP = True
         self.btn_login.config( state = DISABLED )
         self.txt_uri.config( state = DISABLED )
         self.txt_port.config( state = DISABLED )
         self.txt_username.config( state = DISABLED )
         self.txt_password.config( state = DISABLED )
         print 'FTP login'
      except Exception:
         self.showsftptatus_msg('Can not login')


      
   def local_up(self):
      #print 'local_up()',self.__filepath_to_str()
      if len(self.ftppath)>1:
         self.ftppath = self.ftppath[:len(self.ftppath)-1]
      self.__ref_lo()


   def server_up(self):
      if self.NEW_MYFTP:
         #print 'server_up()'
         self.ftp.uptotopdir()
         self.__ref()
         self.showsftptatus()

   def upload_file(self):
      chosen=self.lib_localfile.curselection()
      if chosen == ():
          t=1
      else:
         #print 'chosen:'+chosen[0]
         if ((int(chosen[0]) < 0) or (int(chosen[0]) > (len(self.localfilelist)-1))):
            self.showsftptatus_msg('Error to select file')
         else:
            name=self.localfilelist[int(chosen[0])]
            if name.find('.')>=0:
               try:
                  if self.NEW_MYFTP:
                     name=self.localfilelist[int(chosen[0])]
                     self.ftp.uploadfile(name)
                     self.__ref()
                     print 'upload_file()',name
                     self.showsftptatus_msg('file uploaded '+name)
               except Exception:
                  pass
                  #self.showsftptatus_msg('Can not upload '+name)
            else:
               name=name[1:len(name)-1]
               self.ftppath.append(name)
               self.ftppath.append(name)
               self.local_up()

   def download_file(self):
      if self.NEW_MYFTP:
          
         chosen=self.lib_serverfile.curselection()
         #print chosen
         if chosen == ():
            t=1
         else:
            if ((int(chosen[0]) < 0) or (int(chosen[0]) > (len(self.listfile)-1))):
               self.showsftptatus_msg('Error to select file')
            else:
               name=self.listfile[int(chosen[0])]
               if name.find('<')>=0:
                  #print 'sever chang dir:',name
                  name=name[1:len(name)-1]
               else:
                  print 'download_file()',name
               self.ftp.downloadfile_or_changdirto(name)
               self.showsftptatus()
               self.__ref_lo()  # line:1  |can not switch position line and line 2 
               self.__ref()     # line:2  |this can effect the log show in status bar (GUI)
               

#-----------------------------------------

   def __list_filter(sellf,inlist):
      dir=[]
      file=[]
      for item in inlist:
         if item.find('.')>=0:
            file.append(item)
         else:
            dir.append(item)
      dir.sort()
      for i in range(len(dir)):
         dir[i]='<'+dir[i]+'>'
      file.sort()
      for item in file:
         dir.append(item)
      return dir

        
   def __ref_lo(self):
      '''refashe local ScrolledListBox whit current directory'''
      self.localfilelist = self.__get_local_filelist(self.__filepath_to_str())
      self.localfilelist=self.__list_filter(self.localfilelist)
      self.lib_localfile.setlist(self.localfilelist)
      if self.NEW_MYFTP:
         self.ftp.setlocaldir(self.__filepath_to_str())
      self.showsftptatus_msg('LO-dir:'+self.__filepath_to_str())


   def __ref(self):
      '''refashe server ScrolledListBox whit current server directory'''
      self.listfile = self.ftp.nlst()
      self.listfile=self.__list_filter(self.listfile)
      self.lib_serverfile.setlist(self.listfile)
      self.showsftptatus()      

   def __filepath_to_str(self):
      ''' covert self.ftppath (in list from) to a string for show in status bar'''
      ftpdir = ''
      for t in self.ftppath:
         ftpdir+=t+'\\'
      return ftpdir

   def __get_local_filelist(self,currentpath):
      '''return the contain (filename and sub directory) of input path to a list'''
      #print 'currentpath:', currentpath
      if currentpath <>'':
         try:
            temp_101 = os.listdir(currentpath)
            #temp_101.insert(0,'.')
            return temp_101
         except Exception:
            return []
      else:
         return []

##---------------------------------------
   def setcolor(self,number):
      ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
      clr = self.mycolor.getcolor(number)
      Pmw.Color.changecolor(self,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       )

##   ** END


if __name__ == '__main__' :
   root = Tk()
   myapp = ftpgui(root)
   root.mainloop()
