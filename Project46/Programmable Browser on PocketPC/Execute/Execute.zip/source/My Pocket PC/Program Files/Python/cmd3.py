'''
by CHAKRIT HENGSIRIKUL
2004/03/12
-simple interpreter for exec function
-base class for class Console in pwb.py
can suport many ident
like   if x=3:
           if y=4:
               print x+y
this have many bug must be correct later
    like suport if x==3: but not support if(x==3):
    
## 2004/03/15
## print correctly
'''

import sys
import traceback
from config import *
from main import *
import mytestscript

class Cmd3:

    #prompt = ">>> "
    #identchars = "..."#IDENTCHARS
    #r_identchars = "   "

    def __init__(self, parent, namespaceDICT, stdin=None, stdout=None ):
        """Instantiate a line-oriented interpreter framework.
        """
        import sys
        if stdin is not None:
            self.stdin = stdin
        else:
            self.stdin = sys.stdin
        if stdout is not None:
            self.stdout = stdout
        else:
            self.stdout = sys.stdout

        self.cmdqueue = []
        self.parent = parent

        global SYS_PROMPT

        self.prompt = SYS_PROMPT
        self.identchars = "..."#IDENTCHARS
        self.r_identchars = "   "
        self.r_identchars = "\t"
        self.loop_command = ['if','while','for','def','elif','else','repeat']
        self.code = ''
        
        self.namespaceDICT= namespaceDICT
        

    def cmdloop(self,line):
        
        #self.stdout.flush()
        #line = self.stdin.readline()
        #print "#"+line
        result = self.lineprocess(line)
        if result[0]:
            self.stdout.write(result[1])
            self.myexec()
            self.stdout.write(self.prompt)
        else:
            self.stdout.write(result[1])
        


    def lineprocess(self,line):

        line=line.strip()           ## cut out '\n'
        
        #num = line.find(prompt)
        if line.find(self.prompt) == 0:      ## start loop
            if line == self.prompt: ## not input any thing
                return True,'\n'
            line=line.replace(self.prompt,'')     ## cut out '>>> '
            
            ## check  withch '(' infuther
            ## can run this if x==3
            ## but can't if(x==3)
            s = line.split()
            #print s
            if s[0] in self.loop_command:    
            #if self.inloopcommand(line): ## this line in begin loop command
                self.code = self.code+line+'\n'
                return False,'\n'+self.identchars  ## return False (not exec) and 1 identchars
            else:                       ## dose not loop command
                self.code = self.code+line+'\n'
                return True,'\n'
            
        elif line.find(self.identchars) == 0: ## this line is cone
            
            if self.testendindent(line): ## check in indent terminate
                return True,'\n'
            
            num_c = line.count(self.identchars)
            if self.inloopcommand(line): ## more identchars <second /t/t>
                num_c+=1

            line=line.replace(self.identchars,self.r_identchars) ##  replace identchars to space
            self.code = self.code+line+'\n'
            return False,'\n'+self.identchars*num_c
        else:
            return True,'\n'+self.prompt ## don't care input line that in ERROR from
        
    def testendindent(self,code):
            '''
                check input code <if code in only identchars return True><else return False>
            '''
            #if code == self.identchars: ## end code loop  and not apple to self.code
            #    return True
            test_l=code.replace(self.identchars,'') ##  replace identchars to space
            test_l=test_l.strip()
            if len(test_l)==0:
                return True
            else:
                return False
                
    def inloopcommand(self,code):
        '''
            input a line of code and check it is begin with loop_command character
            <if have return True ><else return False>
        '''
        code = code.replace(self.identchars,'')
        if code.find(' ')>0:
            code = code.split()
            temp_code = code[0]
        else:
            temp_code=code
        #print 'temp_code:'+temp_code
        for loop_c in self.loop_command:
            #print 'loop_c:',loop_c
            if temp_code==loop_c:
                return True
        return False


    def myexec(self):
        #print 'MYexec:'+self.code
        #self.code = 'print "AA"'
        #exec self.code in self.namespaceDICT
        try:
            
            #print '-----------------'
            #print self.code
            #print '-----------------'
            #if mytestscript.testscript(self.code.splitlines()):
            #    print 'SCRIPT ERROR'
            #else:
            #    print 'SCRIPT PASS TEST'
            self.code=self.code.strip()
            self.runscript2(self.code)
        finally:
            self.code = ''
            #print 'End exec'


    def runscript2(self,code):
        scriptList = filter(code.splitlines())
        #print "script : ",scriptList
        for script in scriptList :
            #script = script +';'
            #print "script:",script
            script = script.strip()
            if script <> '':
                try:
                    parseObj = Parse(script)
                    astList = parseObj.ast
                    #print "astList : ",astList
                    for i in astList :
                        #print "i : ",i
                        interprete(i)
                except Exception:
                    print 'SCRIPT ERROR ->',script

