

from Tkinter import *

root = Tk()


icon='''\
R0lGODlhIAAjAPcAAAAAAAAAQAAAgAAA/wAgAAAgQAAggAAg/wBAAABAQABAgABA/wBgAABgQABg
gABg/wCAAACAQACAgACA/wCgAACgQACggACg/wDAAADAQADAgADA/wD/AAD/QAD/gAD//yAAACAA
QCAAgCAA/yAgACAgQCAggCAg/yBAACBAQCBAgCBA/yBgACBgQCBggCBg/yCAACCAQCCAgCCA/yCg
ACCgQCCggCCg/yDAACDAQCDAgCDA/yD/ACD/QCD/gCD//0AAAEAAQEAAgEAA/0AgAEAgQEAggEAg
/0BAAEBAQEBAgEBA/0BgAEBgQEBggEBg/0CAAECAQECAgECA/0CgAECgQECggECg/0DAAEDAQEDA
gEDA/0D/AED/QED/gED//2AAAGAAQGAAgGAA/2AgAGAgQGAggGAg/2BAAGBAQGBAgGBA/2BgAGBg
QGBggGBg/2CAAGCAQGCAgGCA/2CgAGCgQGCggGCg/2DAAGDAQGDAgGDA/2D/AGD/QGD/gGD//4AA
AIAAQIAAgIAA/4AgAIAgQIAggIAg/4BAAIBAQIBAgIBA/4BgAIBgQIBggIBg/4CAAICAQICAgICA
/4CgAICgQICggICg/4DAAIDAQIDAgIDA/4D/AID/QID/gID//6AAAKAAQKAAgKAA/6AgAKAgQKAg
gKAg/6BAAKBAQKBAgKBA/6BgAKBgQKBggKBg/6CAAKCAQKCAgKCA/6CgAKCgQKCggKCg/6DAAKDA
QKDAgKDA/6D/AKD/QKD/gKD//8AAAMAAQMAAgMAA/8AgAMAgQMAggMAg/8BAAMBAQMBAgMBA/8Bg
AMBgQMBggMBg/8CAAMCAQMCAgMCA/8CgAMCgQMCggMCg/8DAAMDAQMDAgMDA/8D/AMD/QMD/gMD/
//8AAP8AQP8AgP8A//8gAP8gQP8ggP8g//9AAP9AQP9AgP9A//9gAP9gQP9ggP9g//+AAP+AQP+A
gP+A//+gAP+gQP+ggP+g///AAP/AQP/AgP/A////AP//QP//gP///ywAAAAAIAAjAAAI/wD/CRxI
sKDBgwgTKlzIsKHDhxD/AZjooKJFBxEFTgRga5vAbbZ2TBhp0eHEjglB7vjzreJCAB4PitwxcNu2
lS0VwoxJcNMEjARBSprwB+hBAP/atOGpcFsbBySP2kqaNAlThEMniDQ6cGcSW1PbfE3pYMeOHzu4
arSZ5M8fsFWnFtwG1ezZnwWR2pLh1i1csXIFihxp9gdegkjb7Onb9+/YmyMJn+XK8V9bxozB7pH0
z9bPz1oPr912GTNjGR2HQq0YGWlXkHxN95XUcZvqCQXq7nCtMeli2X3b/Nv2E2rukZt4SxRoS7Hs
zZw9r169G7GtTQNtJfnNeE9H6bh/7pFIbl0kQe3cJcmwefvzpm3KkZYN7BH9nzZTbX92UOC9co3m
mTWcXOhxRpxF/TkA31H4CUbTed99liB5CDmQRIP/CBiUZ7i9NwGFB0E1wYVy0WSefg5s8t5yClUk
EokCleXhhyv+l5CLI+InEkgq1hgRjiTyiJ0tNjoEJH7XTZRRQaztkIQDRS75T0lSVmnlQwEBADs=
'''


filepath = '\\Program Files\\Python\\pic\\'
#filepath = "C:\\Documents and Settings\\ck13\\Desktop\\Desktop\\"

iconImage0 = PhotoImage(master=root, data=icon)
bt0 = Button(image=iconImage0)#)#,text="bt1"
bt0.pack()


filename=filepath+"p242.gif"
iconImage = PhotoImage(master=root, file=filename)
bt = Button(image=iconImage)#)#,text="bt1"
bt.pack()

filename=filepath+"p252.gif"
iconImage2 = PhotoImage(master=root, file=filename)
bt2 = Button(image=iconImage2)#)#,text="bt1"
bt2.pack()

filename=filepath+"p162.gif"
iconImage3 = PhotoImage(master=root, file=filename)
bt3 = Button(image=iconImage3)#)#,text="bt1"
bt3.pack()

root.mainloop()
