''' -                          ^_^  '_'    
PWBCE  Version 0.1
By Chakrit Hengsirikul   &  Cherdkiat Saetae
: H_CK Email:ck1982@msn.com  Tel:063233481
: S_CH email:
Professor : Dr.Visit Hirankitti

######################################################
##  2004-03-05
## test integate with CL  // Ck
## change (script text box ) taxt to use Pmw.ScrolledText
##
## add inner class Console   to direct stdout to console
## add inner class openfile  to maintain open file dialog ( simple open file dialog can't use on winCE )

## 2004/03/06
## add setcolor class  make all windows can chang color
## 2003/03/10
## add def testscript()  by import mytestscrip.py used def testscript()
## LEK: new design
## 2003/03/12
## CK:implement Console 80%  can pare simple
##    add a clock  by used a callback function
## 2003/03/14
## complest clock
## load config <color>
## 2003/03/20
## chang carlendar to one year add show month label
######################################################
## note
## chang open script

 ** BUG in CL can not use with variable name that inclue '_' <under scroll>
'''

global namespaceDICT
namespaceDICT = {}

import sys
import os
import time

from Tkinter import *
import Pmw
import tkMessageBox


#import tkFileDialog
############################################################
##  congig varible


global myCONSOLE

global re_direct_stdout
re_direct_stdout = True  ## (True,False)

global save_stdout_to_file
save_stdout_to_file = False  ## (True,False)

global re_direct_stdout_to_console
re_direct_stdout_to_console = True ## (True,False) consolse in pwb.py  notebook.page1

global OPENTD_windows
OPENTD_windows = []

global ERROR_IN_FILTER ##ADD
ERROR_IN_FILTER = True ##ADD

global GEN_SCRIPT
GEN_SCRIPT = ''

global USER
USER = {}

from config import *
from cmd3 import Cmd3
#import basesetcolor ## base class for used function setcolor
import mytestscript  ##ADD
from getuserprofile import getuserprofile
from color import color
from ftpgui import ftpgui
from mailgui import mail
from browsergui import browser
from userprofile import user
from mycalendar import mycalendar

#from calendart import calendart

############################################################
##  varible
global scriptfilename
global SELECT_COLOR_number
SELECT_COLOR_number =1
global mycolor
mycolor = color()
global colorList
colorList = []
##  end varible
############################################################
global SELECTMONTH_CALENDAR
SELECTMONTH_CALENDAR = 1
############################################################  ***** ^_^ ***
##  note		
##  how to  stdoutfile.close()



#filepath= 'D:\\Project\\Example\\ch11\\Temp\\'
filepath = picpath


class setcolor:
    def __init__(self,number):
        #print "set number :",number
        self.number = number

    def __call__(self):
        #print "set number call:",self.number
        global SELECT_COLOR_number
        SELECT_COLOR_number = self.number
        self.setcolor2(SELECT_COLOR_number)
        
    def setcolor2(self,number):
        ''' temp this method to input a numbet of dict
            futrer must chang to inpup a dict from main program input
            a dict of color and set to main widget and some other color
            that to set to other special widget '''
        global mycolor
        #print "Set color:c",number
        clr = mycolor.getcolor(number)
        Pmw.Color.changecolor(mainframe,
                                background = clr['background'],
                                foreground = clr['foreground'],
                                activeForeground = clr['activeForeground'],
                                insertBackground = clr['insertBackground'],
                                selectForeground = clr['selectForeground'],
                                highlightColor = clr['highlightColor'],
                                disabledForeground = clr['disabledForeground'],
                                highlightBackground = clr['highlightBackground'],
                                activeBackground = clr['activeBackground'],
                                selectBackground = clr['selectBackground'],
                                troughColor = clr['troughColor'],
                                selectColor = clr['selectColor']       )

    '''def __createrandomcolor():
        # Create the list of colors to cycle through
        global colorList
        for color in Pmw.Color.spectrum(6, 1.5, 1.0, 1.0, 1):
            bg = Pmw.Color.changebrightness(color, 0.85)
            colorList.append((bg, 'black'))
            bg = Pmw.Color.changebrightness(color, 0.55)
            colorList.append((bg, 'white'))


    def randomcolor(index=0):
        Pmw.Color.changecolor(root,colorList[index][0] ,foreground = colorList[index][0])
        #Pmw.Color.setscheme(root, colorList[index][0] ,foreground = colorList[index][0]) 
'''
##############################################################################
##  class Console

class Console(Cmd3):#
    ''' to direct stdout to console (set with constant value for save in text file and show in  '''
    def __init__(self,parent,namespaceDICT):
        Cmd3.__init__(self,parent,namespaceDICT,self,self)
        #print 'Console.__init__()'
        self.P = parent
        self.stdoutfile = open(stdoutfilename,'w') # stdoutfilename from config.py

    def write(self, text):
        if save_stdout_to_file :
            self.stdoutfile.write(text)
        if re_direct_stdout_to_console :
            #text = text.strip()
            #if text <> '\n':
            tbx_out.appendtext(text)

    def __destroy__(self):
        print '__destroy__() '
        self.stdoutfile.close()

    def read(self):
        self.cmdloop(self.readline())
        #print '#'+self.readline()
        #code = tbx_script.get().splitlines()
        
    
    def readline(self):
        allcode = tbx_out.get()
        allcode.strip()
        allcode=allcode.splitlines()
        #print len(allcode)
        if len(allcode)>1:
            code=allcode[-1]
        else:
            return ''
        return code #"READLINE"


##############################################################################
##  class open file

class filedialog(Toplevel):
   """Demonstrate Entrys and Event binding"""

   def __init__( self,parent,MODE,mycolor,select_color_number):
        """Create, pack and bind events to four Entrys"""

        Toplevel.__init__( self,parent )
        self.title( "open file Script" )
        self.geometry( "200x180" )  # width x length
        self.transient()
        self.MODE = MODE
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        #print "scriptpath:",scriptpath
      
        self.listfile=[]
        self.temp = self.getfiletolist(scriptpath)
        #print self.temp
        for i in self.temp:
            self.listfile.append(i)


        btn_text = 'default'
        lbl_text = 'default'
        if self.MODE == 'OPEN':
            lbl_text = 'open file'
            btn_text = 'open'
        else:
            if self.MODE == 'SAVE':
                lbl_text = 'save file'
                btn_text = 'save'

        #--  frame1  stor input uri of ftp
        self.frame2 = Frame( self )
        self.lbl_port = Label(self.frame2,text=lbl_text)
        self.lbl_port.pack(side = LEFT,pady = 0)
        
        self.nty_savefile = Entry(self.frame2,width=18)
        self.nty_savefile.pack(side=LEFT)

        self.btn_open = Button( self.frame2,text=btn_text,command=self.action)
        self.btn_open.pack(side = LEFT, pady = 3, padx = 2)
        self.frame2.pack( side=TOP,pady = 1,padx=0)

        # frame 4 stor  list box for show server file
        self.frame4 = Frame( self )
        self.lib_showfile = Pmw.ScrolledListBox(
        self.frame4,
        items =self.listfile,
        vscrollmode='dynamic',
        listbox_height = 6,
        dblclickcommand=self.check,    )#,selectioncommand = self.loadfile
        self.lib_showfile.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=0)
        self.frame4.pack(  side=TOP,pady = 0 ,padx=0,expand = YES, fill = BOTH)
        
        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)


   def check(self):
        chosen=self.lib_showfile.curselection()
        self.nty_savefile.delete(0, END)
        self.nty_savefile.insert(INSERT,self.listfile[int(chosen[0])])

   def action(self):
        if self.nty_savefile.get() != '':
            if self.MODE == 'OPEN':
                global scriptfilename
                scriptfilename=self.nty_savefile.get()
            else:
                if self.MODE == 'SAVE':
                    savefilename = self.nty_savefile.get()
                    savefile = open(scriptpath+savefilename,'w')
                    savefile.write(tbx_script.get())
                    savefile.close()
                    print 'Save script->',savefilename
            self.destroy()
        else:
            #print 'Select file name'
            pass

   def getfiletolist(self,savepath):
        '''return the contain (filename) of input path in a list'''
        if savepath <>'':
            try:
                return os.listdir(savepath)
            except Exception:
                print 'Cant not read script to List'
        else:
            return []
        
   def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       ) 

##############################################################################
##  end class open file 
class AboutDialog:#(basesetcolor.Setcolor)
    
    def __init__(self, parent,mycolor,select_color_number):
        #basesetcolor.Setcolor.__init__(self,mycolor)
            
        #Create dialog.
        #Toplevel.__init__( self,parent )
        #self.title( "open file Script" )
        #self.geometry( "200x180" )  # width x length
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        self.parent=parent
        #Pmw.aboutversion('0.1')
        #Pmw.aboutcopyright('Copyright My Company 1999\nAll rights reserved')
        Pmw.aboutcontact(
        #    'For information about this application contact:\n' +
        #    '  My Help Desk\n' +
        #    '  Phone: +61 2 9876 5432\n' +
             #'  email: ck1982@msn.com'
            'Programmable Browser\n'+
            'Version 0.1\n'+
            'for WindowsCE On Pocket '
        )
        self.about = Pmw.AboutDialog(parent, applicationname = 'PWBCE')
        #self.about.withdraw()

        # Create button to launch the dialog.
        #w = Button(parent, text = 'Show about dialog',command = self.execute)
        #w.pack(padx = 8, pady = 8)
        
        ## set color   SELECT_COLOR_NUMBER
        #self.setcolor(self.SELECT_COLOR_NUMBER)

    def execute(self):
        self.about.show()
        self.setcolor(self.SELECT_COLOR_NUMBER)

    def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self.parent,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       )
        
##  end class AboutDialog 
##############################################################################
class calendart(Toplevel):
    
    def __init__(self,parent,datelist,mycolor,select_color_number):
        Toplevel.__init__( self,parent)
        ##['Thu', 29, 'Jan', 1, '2004']
        self.mytitle=str(str(datelist[0]))+' '+str(datelist[1])+' '+str(datelist[2])+' '+str(datelist[4])
        self.title( self.mytitle )
        self.geometry( "235x270" )
        self.filepath = picpath
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        
        self.datelist=datelist ## rweekday,n_day,t_mon,n_year,n_mon
        self.datelist.append(0)
        
        self.frm_datetime= Frame(self)
        self.frm_datetime.pack()
        Label(self.frm_datetime,text=self.mytitle).pack(pady='5',padx='2')
        
        self.frm_strt = Frame(self)
        self.frm_strt.pack()
        Label(self.frm_strt,text='StratTime').grid(row=1,column=1,ipadx='2')
        Label(self.frm_strt,text='EndTime').grid(row=1,column=3,ipadx='2')
        
        
        #self._strttime = Pmw.TimeCounter(self.frm_strt,
        #        labelpos = 'n',
        #        label_text = 'HH:MM:SS',
        #        min = '00:00:00',
        #        max = '23:59:59')
        #self._strttime.grid(row=2,column=1,ipadx='2')
#pack(padx=10, pady=5)

        #Label(self.frm_strt,text=' ').grid(row=2,column=2,ipadx='2')
        #setvalue(text)

        my_loct=time.localtime(time.time()) #(2004, 3, 16, 23, 41, 54, 1, 76, 0)
        #self._strttime.setvalue(str(my_loct[3])+':'+str(my_loct[4])+':'+str(my_loct[5]))
        #if my_loct[4]<59:my_loct[4]=my_loct[4]+1
        #elif my_loct[5]<30: my_loct[5]=my_loct[5]+20
        #self._strttime.setvalue(str(my_loct[3])+':'+str(my_loct[4]+1)+':'+str(my_loct[5]))
        
            
        self.frm_clock = Frame(self)
        self.frm_clock.pack()
        self.chb_star = False
        self.chb_str = Checkbutton(self.frm_clock,text='',command=self.chb_stpM)
        self.chb_str.grid(row=1,column=1)
        
        my_loct_3=my_loct[3]
        my_loct_4=my_loct[4]
        if my_loct_4 < 58:
            my_loct_4=my_loct_4+2
        elif my_loct_3<23:
            my_loct_3=my_loct_3+1
            
        self._strh = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'HH',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct_3,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 23}
                                 )
        self._strh.grid(row=1,column=2,ipadx='2')
        self._strm = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'MM',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct_4,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )
        self._strm.grid(row=1,column=3,ipadx='2')
        self._strs = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'SS',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct[5],
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )
        self._strs.grid(row=1,column=4,ipadx='2')
        Label(self.frm_clock,text=' ').grid(row=1,column=5,ipadx='2')
#--------------
        if my_loct_4 < 58:
            my_loct_4=my_loct_4+2
        elif my_loct_3<23:
            my_loct_3=my_loct_3+1
        self._stph = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'HH',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct_3,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 23}
                                 )
        self._stph.grid(row=1,column=6,ipadx='2')
        
        self._stpm = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'MM',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct_4,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )
        self._stpm.grid(row=1,column=7,ipadx='2')
        self._stps = Pmw.Counter(self.frm_clock,labelpos = 'n',
                                 label_text = 'SS',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = my_loct[5],
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )
        self._stps.grid(row=1,column=8,ipadx='2')
        self.chb_stop = False
        self.chb_stp = Checkbutton(self.frm_clock,text='',command=self.chb_strM)
        self.chb_stp.grid(row=1,column=9)
        
        #self._stoptime = Pmw.TimeCounter(self.frm_strt,
        #        labelpos = 'n',
        #        label_text = 'HH:MM:SS',
        #        min = '00:00:00',
        #        max = '23:59:59')
        #self._stoptime.grid(row=2,column=3,ipadx='2')

        
        
        self.frm_take = Frame(self)
        self.frm_take.pack()
        self.takedict={'remind()':'remind("NOTE_HEAR")',
                       'openurl()':'openurl("URL")',
                       'getBidsdata()':'getBidsdata("COMPANY")',
                       'download()':'download("FILENAME","DIR",ftp_username,ftp_password,ftp_server,ftp_port)',
                       'upload()':'upload("FILENAME","DIR",ftp_username,ftp_password,ftp_server,ftp_port)',
                       'sendmail()':'sendmail("TO","SUB","DATA",mailuser,mailserver)',
                       'checkmail()':'checkmail(mailserver,mailuser,mailpaswd)',
                       'readmail()':'readmail(mailserver,mailuser,mailpaswd)',
                       'savemail()':'savemail(mailserver,mailuser,mailpaswd)'
                      }
        self.takebox = Pmw.ComboBox(self.frm_take,
                                    labelpos='nw',
                                    scrolledlist_items=self.takedict.keys(),
                                    #label_text=self.mytitle,
                                    selectioncommand=self.selectionCommand
                                    )
        self.takebox.pack(fill = 'both', expand = 1,pady='0')
        
        #self.frm_take = Frame(self)
        #self.frm_take.pack()
        #self.etf_task = Pmw.EntryField(self.frm_take,labelpos = 'nw',label_text = 'Event',entry_width='32')
        #self.etf_task.pack(side= 'top',fill = 'both', expand = 1)

        #setentry(text)
        self.frm_action = Frame(self)
        self.frm_action.pack()
        self.etf_act = Pmw.EntryField(self.frm_action,labelpos = 'nw',label_text = 'Action',entry_width='32')
        self.etf_act.pack(side= 'top',fill = 'both', expand = 1)

        self.frm_gen = Frame(self)
        self.frm_gen.pack()
        self.btn = Button(self.frm_gen,text='generate',command=self.gencode)
        self.btn.pack(side='right',padx='5',pady='5')
        
        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)
        #atday=time.ctime(time.time())
        #self.daylist=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
        #self.box = Pmw.ScrolledListBox(self, listbox_selectmode='single', 
        #    listbox_width = 35,listbox_height = 10,
        #    labelpos='nw', 
        #    items=self.daylist,
        #    label_text=str(datelist[0])+' '+str(datelist[1])+' '+str(datelist[2])+' '+str(datelist[3]),
        #    selectioncommand=self.selectionCommand)
        #self.box.pack(fill = 'both', expand = 1)
        
    def chb_strM(self):
        print 'self.chb_star',self.chb_star
        if self.chb_star:
            self.chb_star = False
        else:
            self.chb_star = True

    def chb_stpM(self):
        print 'self.chb_stop',self.chb_stop
        if self.chb_stop:
            self.chb_stop = False
        else:
            self.chb_stop = True

    def selectionCommand(self,list):
        #print'list',list
        self.etf_act.setentry(self.takedict[list])

    def gencode(self):
        global GEN_SCRIPT
        #take = self.etf_task.getvalue()
        #take = take.strip()
        action = self.etf_act.getvalue()
        action = action.strip()
        my_atdate='|'+str(self.datelist[1])+'/'+str(self.datelist[3])+'/'+str(self.datelist[4])
        stop_time ='_'
        start_time='_'
        if self.chb_star:
            stop_time = str(self._stph.get())+':'+str(self._stpm.get())+':'+str(self._stps.get())+my_atdate  
        if self.chb_stop:
            start_time = str(self._strh.get())+':'+str(self._strm.get())+':'+str(self._strs.get())+my_atdate
            
        my_atdate = 'q<'+start_time+','+stop_time+'>'
        #self.datelist=datelist ## rweekday,n_day,t_mon,n_year,n_mon
        #print my_atdate+' : '+action
        GEN_SCRIPT = my_atdate+' : '+action
        self.destroy()

##---------------------------------------
    def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                            background = clr['background'],
                            foreground = clr['foreground'],
                            activeForeground = clr['activeForeground'],
                            insertBackground = clr['insertBackground'],
                            selectForeground = clr['selectForeground'],
                            highlightColor = clr['highlightColor'],
                            disabledForeground = clr['disabledForeground'],
                            highlightBackground = clr['highlightBackground'],
                            activeBackground = clr['activeBackground'],
                            selectBackground = clr['selectBackground'],
                            troughColor = clr['troughColor'],
                            selectColor = clr['selectColor']       )
        
##  end class  calendart
##############################################################################


dtl={}
dtlpf=getuserprofile()
dtlpf.getuserpf('detail.profile',dtl)
INIT_COLOR = dtl['color']
INIT_COLOR = int(INIT_COLOR[1]) ## reformat <cut out frist char and chang to int >
SELECT_COLOR_number = INIT_COLOR

mycal = mycalendar()
cliv=mycal.builtecalval(mycal.getcumonthNUM())
SELECTMONTH_CALENDAR = 1
SELECTMONTH_CALENDAR = mycal.getcumonthNUM()
btn=[]
btnt=[]
CUMONTHLABEL = mycal.getcumonthandyearTXT()
#print cliv 



def fp():
    #global OPENTD_windows
    my_ftp = ftpgui(root,mycolor,SELECT_COLOR_number)

def ml():
    #global OPENTD_windows
    #m = mail(root)
    my_mail = mail(root,mycolor,SELECT_COLOR_number)
 
def wb():
    #global OPENTD_windows
    my_web = browser(root,mycolor,SELECT_COLOR_number)

def editprofile():
    edpf = user(root,mycolor,SELECT_COLOR_number)    

def about():
    abd = AboutDialog(root,mycolor,SELECT_COLOR_number)
    abd.execute()




def quit():
    #shutdown()
    print 'root.destroy()'
    root.destroy()


def runscript():
    myCONSOLE.runscript2(tbx_script.get())


            

def testscript():##ADD
    if mytestscript.testscript(tbx_script.get().splitlines()): 
        print 'SCRIPT ERROR'
    else:
        print 'SCRIPT PASS TEST'
            
    
def fileopenbox2():
    global scriptfilename
    scriptfilename = 'NOFILE'
    dialogcript = filedialog(root,'OPEN',mycolor,SELECT_COLOR_number)
    root.wait_window(dialogcript)
    if scriptfilename != 'NOFILE':
        #print 'scriptfilename:',scriptfilename
        try:
            scriptfile = open(scriptpath+scriptfilename,'r') # stdoutfilename from config.py
            print 'Open script->',scriptfilename
            tbx_script.clear()
            lines = scriptfile.readlines()
            temp_sc = ''
            for line in lines:
                temp_sc += line
            temp_sc = temp_sc.strip()
            tbx_script.appendtext(temp_sc)
            scriptfile.close()
        except Exception:
            #pass
            print 'open script fail->',scriptfilename


def filesavebox2():
    #print 'filesavebox2'
    dialogcript = filedialog(root,'SAVE',mycolor,SELECT_COLOR_number)
    root.wait_window(dialogcript)


def clearscript2():
    tbx_script.clear()

def my_delete(self):
	pass

def my_exec(event):
    '''
        handle Consel <Return> press
    '''
    global myCONSOLE
    myCONSOLE.read()
    move_cursor_tbx_out()
    return "break" ## break event propogation up level widket


def move_cursor_tbx_out():
    '''
         move cursor to end of text anf delete last line <'\n'> in tbx_out widket
    '''
    code = tbx_out.get().rstrip()
    code = code.splitlines()
    tbx_out.clear()
    i=1
    for line in code:
        if line <> 'a\n':
            line = line.rstrip()
            if i==1:
                tbx_out.appendtext(line)
                i=2
            else:
                tbx_out.appendtext('\n'+line)

##-------------------------------------------------
                
def calrincre(btns=[],btnts=[]):
    if btns==[] or btnts==[]:return
    global SELECTMONTH_CALENDAR
    if SELECTMONTH_CALENDAR >=12: return
    SELECTMONTH_CALENDAR = SELECTMONTH_CALENDAR+1
    calrpack(SELECTMONTH_CALENDAR,btns,btnts)

def calrdecre(btns=[],btnts=[]):
    if btns==[] or btnts==[]:return
    global SELECTMONTH_CALENDAR
    if SELECTMONTH_CALENDAR <=1: return
    SELECTMONTH_CALENDAR = SELECTMONTH_CALENDAR-1
    calrpack(SELECTMONTH_CALENDAR,btns,btnts)

def calrpack(atmonth,btns=[],btnts=[]):
    if btns==[]or btnts==[]:return
    ##cliv=cal.builtecalval(atmonth)
    lbl_month.config(text=mycal.getmonthandyearTXT(atmonth))
    startday = mycal.getmonthstartdate(atmonth)
    
    atbtnts=0
    loop=False
    beforM=False
    beforM_star=mycal.calendar[SELECTMONTH_CALENDAR-1]-mycal.startdateofmounth[SELECTMONTH_CALENDAR]+1
    afterM_star=1
    
    for k in range(6):
        for v in range(7):
            #print k,v
            for i in range(mycal.calendar[atmonth]):            
                x=(i+startday)/7
                y=(i+startday)%7
                if k==x and v==y:
                    loop=True
                    beforM=True
                    ibt = btns[i]
                    ibt.grid(row=x,column=y,ipadx='2')
                    if y==0 :
                        ibt.config(background='#FFDD99')
                    elif y==6 :
                        ibt.config(background='#DDFF66')
                    else:
                        ibt.config(background='white')
                    if i==mycal.getcudayNUM()-1:
                        if atmonth == mycal.getcumonthNUM():
                            ibt.config(background='#33CCFF')
            if loop:
                loop=False
            else:
                if atbtnts<12:
                    ibt = btnts[atbtnts]
                    ibt.grid(row=k,column=v,ipadx='2')
                    ibt.config(background='#CCCCCC')
                    if beforM:
                        ibt.config(text=afterM_star)
                        afterM_star=afterM_star+1
                    else:
                        ibt.config(text=beforM_star)
                        beforM_star=beforM_star+1
                    atbtnts=atbtnts+1
            #       print atbtnts

            
def clickdate(day):
    
        if day==-1: return
        #print "def clickdate:",datelist
        #cliv[i]=(rweekday[abs(weekday[atday[0]]-(int(atday[2])%7))],i,ck_mou,ck_year)
    
        ##['Sun', 18, 'Jan', 1, '2004']
        datalist=mycal.getdate(day,SELECTMONTH_CALENDAR,2004)
        date = calendart(root,datalist,mycolor,SELECT_COLOR_number)
        root.wait_window(date)
        tbx_script.appendtext(GEN_SCRIPT+'\n')


def findstardofthemounth(day,atdate):
    ''' input a (19,'Thu')'''
    c_atday=weekday[atdate]-rweekday[(day%7)]+1
    c_atdate=rweekday[c_atday]
    return [c_atday,c_atdate]
    
#######################################################################################
#######################################################################################





root = Tk()
Pmw.initialise(root)
#Pmw.initialise()
mainframe = Frame(root)
toolbar = Frame(mainframe)

mainframe.pack(expand = NO)
mainframe.master.geometry("235x270")
mainframe.master.title("PWBCE Version 1.0")

menubar = Frame(mainframe)
menubar.pack(fill = X,expand=YES)


#myBalloon = Pmw.Balloon(mainframe)
choices = Pmw.MenuBar( menubar )
choices.pack(side = LEFT)

choices.addmenu( "File","File")
choices.addmenuitem( "File", "command", label = "New" ,command=clearscript2)
choices.addmenuitem( "File", "command", label = "Open" ,command =fileopenbox2)
choices.addmenuitem( "File", "command", label = "Save" ,command=filesavebox2)
choices.addmenuitem('File', 'separator')
choices.addmenuitem( "File", "command", label = "Edit Profiles" ,command=editprofile)
choices.addmenuitem('File', 'separator')
choices.addmenuitem( "File", "command", label = "Exit" ,command=quit)

choices.addmenu("Command","Command")
choices.addmenuitem( "Command", "command", label = "Test script" ,command=testscript)
choices.addmenuitem( "Command", "command", label = "Run script" ,command=runscript)

choices.addmenu("Tools","Tools")
choices.addmenuitem( "Tools", "command", label = "Web Browser" ,command = wb)
choices.addmenuitem( "Tools", "command", label = "File Transfe" ,command = fp)
choices.addmenuitem( "Tools", "command", label = "Mail Service" ,command = ml)
choices.addmenuitem('Tools', 'separator')
choices.addcascademenu( "Tools","Set Colors", "command", label = "Set Colors" )

choices.addmenuitem( "Set Colors", "radiobutton", label = "c1" ,command = setcolor(1))#randomcolor(1))#
choices.addmenuitem( "Set Colors", "radiobutton", label = "c2" ,command = setcolor(2))#randomcolor(2))
choices.addmenuitem( "Set Colors", "radiobutton", label = "c3" ,command = setcolor(3))#randomcolor(3)
choices.addmenuitem( "Set Colors", "radiobutton", label = "c4" ,command = setcolor(4))#randomcolor(1)

#choices.addcascademenu( "Tools", "Other" )
#choices.addmenuitem( "Other", "command", label = "Internet Explorer" )
#choices.addmenuitem( "Other", "command", label = "Calculator" )
#choices.addmenuitem( "Other", "command", label = "Note pad" )

choices.addmenu("About","About")
choices.addmenuitem( "About", "radiobutton", label = "About" ,command = about)
#choices.addmenuitem( "About", "radiobutton", label = "Help" ,command = setcolor(2))


clock = Frame(menubar)
clock.pack(side = RIGHT)
clocklabel = Label(clock,text="hh:mm:ss",bd=1,relief=SUNKEN,anchor=W,width='8')
clocklabel.pack()

myImage0 = PhotoImage( file = filepath + "mail.gif" )
b = Button(toolbar, image = myImage0,relief = RAISED,command = ml,border="0")
b.pack(side=LEFT)
myImage1 = PhotoImage( file = filepath + "wb.gif" )
b = Button(toolbar,image = myImage1,relief = GROOVE,command = wb,border="0")
b.pack(side=LEFT)
myImage2 = PhotoImage( file = filepath + "ftp.gif" )
b = Button(toolbar,image = myImage2,relief = GROOVE,command = fp,border="0")
b.pack(side=LEFT)

myImage3 = PhotoImage( file = filepath +  "run.gif" )
b = Button(toolbar,image = myImage3,relief = GROOVE,command = runscript,border="0")
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)



myImage5 = PhotoImage( file = filepath + "nextsmall.gif" )
b = Button(toolbar,image = myImage5,relief = GROOVE,command = lambda:calrincre(btn,btnt),border="0")
b.pack(side=RIGHT,padx=2)
toolbar.pack(side=TOP, fill=X)
myImage4 = PhotoImage( file = filepath + "backsmall.gif")
b = Button(toolbar,image = myImage4,relief = GROOVE,command = lambda:calrdecre(btn,btnt),border="0")
b.pack(side=RIGHT,padx=2)
toolbar.pack(side=TOP, fill=X)

lbl_month = Label(toolbar,text=CUMONTHLABEL)
lbl_month.pack(side=RIGHT,padx=2)

notebook = Pmw.NoteBook(mainframe)
notebook.pack(fill = 'both', expand = 1)





##PAGE2

page2 = notebook.add('Calendar')
#notebook.tab('Event List').focus_set()
frm_cald_weekname = Frame(page2)
frm_cald_weekname.pack()
frm_cald = Frame(page2)
frm_cald.pack()

btn1 = Button(frm_cald,text=1,borderwidth='1',command=lambda:clickdate(1),relief=SUNKEN,background='white',width='3',height='2')
btn2 = Button(frm_cald,text=2,borderwidth='1',command=lambda:clickdate(2),relief=SUNKEN,background='white',width='3',height='2')
btn3 = Button(frm_cald,text=3,borderwidth='1',command=lambda:clickdate(3),relief=SUNKEN,background='white',width='3',height='2')
btn4 = Button(frm_cald,text=4,borderwidth='1',command=lambda:clickdate(4),relief=SUNKEN,background='white',width='3',height='2')
btn5 = Button(frm_cald,text=5,borderwidth='1',command=lambda:clickdate(5),relief=SUNKEN,background='white',width='3',height='2')
btn6 = Button(frm_cald,text=6,borderwidth='1',command=lambda:clickdate(6),relief=SUNKEN,background='white',width='3',height='2')
btn7 = Button(frm_cald,text=7,borderwidth='1',command=lambda:clickdate(7),relief=SUNKEN,background='white',width='3',height='2')
btn8 = Button(frm_cald,text=8,borderwidth='1',command=lambda:clickdate(8),relief=SUNKEN,background='white',width='3',height='2')
btn9 = Button(frm_cald,text=9,borderwidth='1',command=lambda:clickdate(9),relief=SUNKEN,background='white',width='3',height='2')
btn10 = Button(frm_cald,text=10,borderwidth='1',command=lambda:clickdate(10),relief=SUNKEN,background='white',width='3',height='2')
btn11 = Button(frm_cald,text=11,borderwidth='1',command=lambda:clickdate(11),relief=SUNKEN,background='white',width='3',height='2')
btn12 = Button(frm_cald,text=12,borderwidth='1',command=lambda:clickdate(12),relief=SUNKEN,background='white',width='3',height='2')
btn13 = Button(frm_cald,text=13,borderwidth='1',command=lambda:clickdate(13),relief=SUNKEN,background='white',width='3',height='2')
btn14 = Button(frm_cald,text=14,borderwidth='1',command=lambda:clickdate(14),relief=SUNKEN,background='white',width='3',height='2')
btn15 = Button(frm_cald,text=15,borderwidth='1',command=lambda:clickdate(15),relief=SUNKEN,background='white',width='3',height='2')
btn16 = Button(frm_cald,text=16,borderwidth='1',command=lambda:clickdate(16),relief=SUNKEN,background='white',width='3',height='2')
btn17 = Button(frm_cald,text=17,borderwidth='1',command=lambda:clickdate(17),relief=SUNKEN,background='white',width='3',height='2')
btn18 = Button(frm_cald,text=18,borderwidth='1',command=lambda:clickdate(18),relief=SUNKEN,background='white',width='3',height='2')
btn19 = Button(frm_cald,text=19,borderwidth='1',command=lambda:clickdate(19),relief=SUNKEN,background='white',width='3',height='2')
btn20 = Button(frm_cald,text=20,borderwidth='1',command=lambda:clickdate(20),relief=SUNKEN,background='white',width='3',height='2')
btn21 = Button(frm_cald,text=21,borderwidth='1',command=lambda:clickdate(21),relief=SUNKEN,background='white',width='3',height='2')
btn22 = Button(frm_cald,text=22,borderwidth='1',command=lambda:clickdate(22),relief=SUNKEN,background='white',width='3',height='2')
btn23 = Button(frm_cald,text=23,borderwidth='1',command=lambda:clickdate(23),relief=SUNKEN,background='white',width='3',height='2')
btn24 = Button(frm_cald,text=24,borderwidth='1',command=lambda:clickdate(24),relief=SUNKEN,background='white',width='3',height='2')
btn25 = Button(frm_cald,text=25,borderwidth='1',command=lambda:clickdate(25),relief=SUNKEN,background='white',width='3',height='2')
btn26 = Button(frm_cald,text=26,borderwidth='1',command=lambda:clickdate(26),relief=SUNKEN,background='white',width='3',height='2')
btn27 = Button(frm_cald,text=27,borderwidth='1',command=lambda:clickdate(27),relief=SUNKEN,background='white',width='3',height='2')
btn28 = Button(frm_cald,text=28,borderwidth='1',command=lambda:clickdate(28),relief=SUNKEN,background='white',width='3',height='2')
btn29 = Button(frm_cald,text=29,borderwidth='1',command=lambda:clickdate(29),relief=SUNKEN,background='white',width='3',height='2')
btn30 = Button(frm_cald,text=30,borderwidth='1',command=lambda:clickdate(30),relief=SUNKEN,background='white',width='3',height='2')
btn31 = Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(31),relief=SUNKEN,background='white',width='3',height='2')

btntemp1= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp2= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp3= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp4= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp5= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp6= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp7= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp8= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp9= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp10= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp11= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp12= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp13= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')
btntemp14= Button(frm_cald,text=31,borderwidth='1',command=lambda:clickdate(-1),relief=SUNKEN,background='white',width='3',height='2')


#rweekday = {1:'Sun',2:'Mon',3:'Tue',4:'Wed',5:'Thu',6:'Fri',7:'Sat'}
Label(frm_cald_weekname,text=mycal.rweekday[0],borderwidth='1',background='white',width='4',height='2').grid(row=1,column=1,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[1],borderwidth='1',background='white',width='3',height='2').grid(row=1,column=2,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[2],borderwidth='1',background='white',width='4',height='2').grid(row=1,column=3,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[3],borderwidth='1',background='white',width='4',height='2').grid(row=1,column=4,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[4],borderwidth='1',background='white',width='4',height='2').grid(row=1,column=5,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[5],borderwidth='1',background='white',width='3',height='2').grid(row=1,column=6,ipadx='2')
Label(frm_cald_weekname,text=mycal.rweekday[6],borderwidth='1',background='white',width='4',height='2').grid(row=1,column=7,ipadx='2')

btn=[btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btn12,btn13,btn14,btn15,btn16,btn17,btn18,btn19,btn20,btn21,btn22,btn23,btn24,btn25,btn26,btn27,btn28,btn29,btn30,btn31]
btnt=[btntemp1, btntemp2, btntemp3, btntemp4, btntemp5, btntemp6, btntemp7, btntemp8, btntemp9, btntemp10, btntemp11, btntemp12, btntemp13, btntemp14 ]

#cliv=cal.builtecalval(cal.getcumonthNUM())
calrpack(mycal.getcumonthNUM(),btn,btnt)







#PAGE 1 
page1 = notebook.add('Script Editor')
notebook.tab('Script Editor').focus_set()


tbx_script = Pmw.ScrolledText(page1,
                #borderframe = 1,
                #labelpos = 'n',
                #label_text='ScrolledText with headers',
                #columnheader = 1,
                #rowheader = 1,
                #rowcolumnheader = 1,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none',
                #text_font = fixedFont,
                #Header_font = fixedFont,
                #Header_foreground = 'blue',
                #rowheader_width = 3,
                #rowcolumnheader_width = 3,
                #text_padx = 2,
                #text_pady = 2,
                #Header_padx = 4,
                #rowheader_pady = 4,
        )
tbx_script.tag_configure('yellow',background = 'yellow')
tbx_script.pack(padx = 1, pady = 1, fill = 'both', expand = 1)



##PAGE3
page3 = notebook.add('Console')
#page3..bind('<Return>',my_exec)
#notebook.tab('Event List').focus_set()
tbx_out = Pmw.ScrolledText(page3,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none',        )
#tbx_out.tag_configure('yellow',background = 'yellow')
tbx_out.component('text').bind('<Return>',my_exec)

#tbx_out.component('text').bind('<BackSpace>',my_exec)
#tbx_out.component('text').bind('<Delete>',my_delete)
tbx_out.pack(padx = 1, pady = 1, fill = 'both', expand = 1)

tbx_out.component('horizscrollbar').config(bg='red')
#temp_t =Entry(page3,name='t2')
#temp_t.bind('<Return>',my_exec)
#temp_t.pack()


##########################
## **  main section  ** ##

## *** add clock ***
def addnumber():
    #number = int(whrandom.random() * 1000)
    #print number
    #clocklabel.insert(END, str(number))
    li = time.localtime(time.time())
    l3=str(li[3])
    l4=str(li[4])
    l5=str(li[5])
    if len(l3)==1:l3='0'+l3
    if len(l4)==1:l4='0'+l4
    if len(l5)==1:l5='0'+l5
    t=l3+':'+l4+':'+l5
    clocklabel.config(text=t)
    #bell()
    #clocklabel.settext(str(number))
    #textBox.yview("moveto", 1.0)
    listenID = tbx_out.after(1000,addnumber)
    
listenID = tbx_out.after(1000, addnumber) ## *** add clock ***
 

#if re_direct_stdout:
    #global myCONSOLE
    #global namespaceDICT
myCONSOLE= Console(root,namespaceDICT)
    #save_stdout = sys.stdout

sys.stdout= myCONSOLE
sys.stdin= myCONSOLE
sys.stderr = myCONSOLE




mysetcolor = setcolor(INIT_COLOR)
mysetcolor.setcolor2(INIT_COLOR)

#__createrandomcolor()
#randomcolor(3)

def callback():
    if tkMessageBox.askokcancel("Quit", "Do you really wish to quit?"):
        root.destroy()

#root.protocol("WM_DELETE_WINDOW", callback) ## before close window

## ** BUG can not pare with variable name that inclue '_' <under scroll>
def buildeUSER(ind,prefix):
    cct=''
    for cck,ccv in ind.items():
        cct=cct+prefix+cck+' = "'+ccv+'"\n'
    myCONSOLE.runscript2(cct)

cc_filename = [['detail.profile','user_'],['contact.profile','cont_'],['web.profile','web_'],['mail.profile',''],['ftp.profile','ftp_']]
for nna in cc_filename:
    tckdata = {}
    #print '@@@@@@@',nna
    dtlpf.getuserpf(nna[0],tckdata)
    buildeUSER(tckdata,nna[1])




move_cursor_tbx_out()
#tbx_out.component('horizscrollbar').config(bg='red')
#tbx_out.component('Scrollbar').config(bg='red')



## ** START PROGRAM **
global HEADER        
print HEADER
global SYS_PROMPT
print SYS_PROMPT

root.mainloop()


