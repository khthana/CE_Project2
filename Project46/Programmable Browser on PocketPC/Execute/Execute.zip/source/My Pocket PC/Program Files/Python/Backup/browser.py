from Tkinter import *

filepath = 'D:\\Project\\Example\\browser\\'
root = Tk()
frame = Frame(root)
menu = Menu(root)
toolbar = Frame(root)
root.config(menu=menu)
textbox = Frame(root)
addressbar = Frame(root)

#menubar
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New")
filemenu.add_command(label="Open..." )
filemenu.add_command(label="Save")
filemenu.add_command(label="Save as...")
filemenu.add_separator()
filemenu.add_command(label="Exit" )

viewmenu = Menu(menu)
menu.add_cascade(label="View", menu=viewmenu)
viewmenu.add_command(label="Toolbar")

favouritesmenu = Menu(menu)
menu.add_cascade(label="Favourites",menu=favouritesmenu)
favouritesmenu.add_command(label="Add favourites")
favouritesmenu.add_command(label="Organize favourites")

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About...")


#toolbar
myImage0 = PhotoImage( file = filepath + "backbut.gif" )
b = Button(toolbar, text="new", image = myImage0,relief = GROOVE,border="0")
b.pack(side=LEFT)
myImage1 = PhotoImage( file = filepath + "nextbut.gif" )
b = Button(toolbar, text="open",image = myImage1,relief = GROOVE,border="0")
b.pack(side=LEFT)
myImage2 = PhotoImage( file = filepath + "stopbut.gif" )
b = Button(toolbar, text="open",image = myImage2,relief = GROOVE,border="0")
b.pack(side=LEFT)
myImage3 = PhotoImage( file = filepath + "refreshbut.gif" )
b = Button(toolbar, text="new", image = myImage3,relief = GROOVE,border="0")
b.pack(side=LEFT)
myImage4 = PhotoImage( file = filepath + "homebut.gif" )
b = Button(toolbar, text="new", image = myImage4,relief = GROOVE,border="0")
b.pack(side=LEFT)
myImage5 = PhotoImage( file = filepath + "favourbut.gif" )
b = Button(toolbar, text="new", image = myImage5,relief = GROOVE,border="0")
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)

#Addressbar
Label(addressbar,text="Address:").pack(side =LEFT)
Entry(addressbar,width=27).pack(side=LEFT)
myImage5 = PhotoImage( file = filepath + "gobut.gif" )
Button(addressbar, image = myImage5,border="1").pack(side=LEFT)
addressbar.pack()

#Display
scrollbar = Scrollbar(frame)
textboxa = Text(textbox,width=38,height=1,yscrollcommand=scrollbar.set)
textboxa.pack(fill=BOTH,expand=2)
scrollbar.config(command=textboxa.yview)

textBox = Text(frame,width=35,height=18,yscrollcommand=scrollbar.set)
scrollbar.config(command=textBox.yview)
scrollbar.pack(side=RIGHT, fill=Y)
textBox.pack(fill=BOTH,expand=2)

#frame
frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("Browser")

mainloop()