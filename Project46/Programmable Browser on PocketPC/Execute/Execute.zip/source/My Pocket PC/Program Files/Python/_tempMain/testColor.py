import sys
import os
from Tkinter import *
import Pmw


def def1(self):
    print 'def1()'


    
root = Tk()
Pmw.initialise(root)
fr = Frame(root)

tk_rgb1 = '#%02x%02x%02x' % (128,128,15)
btn_chk = Button(fr,text="Check mail",border="1",command=def1,bg=tk_rgb1)
btn_chk.pack(side=LEFT)




fr.pack()


root.mainloop()



