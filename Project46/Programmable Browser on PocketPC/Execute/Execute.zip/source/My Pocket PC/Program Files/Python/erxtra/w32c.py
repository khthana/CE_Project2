# A "Generic console Class" for Windows CE.
# 
# Copied almost entirely from Mark Hammond's ceshell.py - Thanks!
#
# Also works on NT/9x (with a few limitations!) - Not verified

# With this class, console and Python Interpreter can be 
# separated easily.
# Coding can be greatly cleaned. I don't have time for it.
# If you can, please clean it up and improve it.
#
# See pshg2.py for how to use it.
# You can make text editor with this, too.
# If you know a little about win32api calls, you can add
# menus, and other neet thing.
# It functions on my python CE 152+.
# But it may not run well on 22.
#
# Telion
#

from win32gui import *
from win32event import *

from sys import platform,hinst
import string
import threading
import thread
import sys

#el=sys.stderr.write

WINCE = (platform=='wince')

IDOK=1
IDCANCEL=2

GWL_WNDPROC=-4
FIXED_PITCH=1
ANSI_FIXED_FONT=11
SYSTEM_FONT=13 # Telion


IDC_WAIT = 32514
HWND_TOP=0
CS_VREDRAW=1
CS_HREDRAW=2

CW_USEDEFAULT=0x80000000

WM_CHAR=258 # with this we can send key code to any App
#WM_CUT=0x0300
#WM_COPY=0x0301
#WM_=0x0302
#WM_CLEAR=0x0303
#WM_UNDO=0x0304
#WM_RENDERFORMAT=0x0305
#WM_RENDERALLFORMATS=0x0306
#WM_DESTRPYCLIPBOARD=0x0307
WM_COMMAND=273
WM_DESTROY=2
WM_QUIT=18
WM_SETFOCUS=7
WM_SETFONT=48
WM_SETREDRAW=11
WM_SIZE=5
WM_USER=1024

WHITE_BRUSH=0
SW_SHOW=5
SW_SHOWNORMAL=1

WS_SYSMENU=524288
WS_CLIPCHILDREN=33554432
WS_CHILD=1073741824
WS_VISIBLE=268435456
WS_HSCROLL=1048576
WS_VSCROLL=2097152
if WINCE:
	WS_OVERLAPPEDWINDOW=0
else:
	WS_OVERLAPPEDWINDOW=13565952

EM_GETLINECOUNT=186
EM_GETSEL=176
EM_LINEINDEX=187
EM_LINEFROMCHAR=201
EM_LINELENGTH=193
EM_SETSEL=177
EM_REPLACESEL=194

ES_LEFT=0
ES_MULTILINE=4
ES_WANTRETURN=4096
ES_AUTOVSCROLL=64
ES_AUTOHSCROLL=128

ES_OEMCONVERT=0x0400

IDR_MENU=101
IDM_EXIT=40001
IDM_ABOUT=40002
IDD_ABOUT=40002

if UNICODE:
	TEXT = Unicode
else:
	TEXT = lambda x: x

if WINCE:
	OutputDebugString = NKDbgPrintfW
else:
	from win32api import OutputDebugString

#el("Header definition finished")


class W32console:
	editMessageMap = {}
	def __init__(self):
		#self.el=sys.stderr.write
		#self.el("W32console.__init__()")
		self.bInteract = 1 # Am I interacting?
		self.hwnd = None # <===== This can be very usefull.
		self.hwndEdit = None # <=== This one, too.
		self.outputQueue = []
		self.outputQueueLock = threading.Lock()

		# Allocate some events for thread sync
		self.currentBlockItems = None
		self.eventInteractiveInputAvailable = CreateEvent(None, 0, 0, None)
		self.eventClosed = CreateEvent(None, 0, 0, None)

		# Added by Telion for alias, history, input( ), etc..
		self.reading = 0 # readline flag
		self.read_dat= ''# readline data
		self.pChar = 0 # readline current line number
		self.pLine = 0 # readline current line length

		self.debug=0	# debug flag 0=no debug action for debugging this one only
		self.slocals={} # namespace for the Interactive interpreter
		self.cd=None
		self.w_title = 'PyTerminal'
		self._getc1_on = 1
		self._getc2_on = 1
		self.quitkey = 0x11 # Ctrl-Q

	def __del__(self):
		pass
		# no cleanup yet....
		#self.el( "W32console.__del__() InteractiveManager dieing")

	def write(self, text):
		##self.el("W<"+text+"<<<,")
		text = string.replace(text, "\n", "\r\n") # Internally, it's \n
		self.outputQueueLock.acquire()
		self.outputQueue.append(text)
		self.outputQueueLock.release()
		try:
			PostMessage(self.hwnd, WM_USER, 0, 0)
		except:
			pass

	def write2(self, text, hwnd2): # Telion <== Theorically, w32c.write2("Bla")
		# will send message to another program providing you know the hwnd.
		#self.el("W2<"+text+"<<<")
		text = string.replace(text, "\n", "\r\n")
		self.outputQueueLock.acquire()
		self.outputQueue.append(text)
		self.outputQueueLock.release()
		try:
			PostMessage(hwnd2, WM_USER, 0, 0)
		except:
			pass
		# to do: the rest
		
	def Run(self):
		#self.el("RUN")
		PumpMessages()	

	def GetEditMessageMap(self):
		#self.el("GetEditMM")
		return {WM_CHAR : self.OnEditChar}

	def GetParentMessageMap(self):
		#self.el("GetParentMM")
		map={}
		map[WM_DESTROY] = self.OnParentDestroy
		map[WM_SIZE] = self.OnParentSize
		map[WM_SETFOCUS] = self.OnParentSetFocus
		map[WM_USER] = self.OnParentUser
		map[WM_COMMAND] = self.OnParentCommand
		return map
		
	def Init(self):
		#self.el("W32c.init()")
		try:
			self.hinst = GetModuleHandle(None)
		except NameError: # Not on CE??
			self.hinst = sys.hinst # But this is :-)

		InitCommonControls()

		wc = WNDCLASS()
		wc.hInstance = self.hinst
		wc.style=CS_HREDRAW | CS_VREDRAW
		wc.hbrBackground = GetStockObject(WHITE_BRUSH)
		wc.lpszClassName = TEXT(self.w_title)
		# This code passes a dictionary as the "wndproc", rather than a function.
		wc.lpfnWndProc = self.GetParentMessageMap() #self.MainWndProc
		self.classAtom = RegisterClass(wc)
		
		if WINCE:
			style = WS_CLIPCHILDREN
		else:
			style = WS_OVERLAPPEDWINDOW
			
		self.hwnd = CreateWindow( self.classAtom, self.w_title, style, \
	                      0, 0, CW_USEDEFAULT, CW_USEDEFAULT, \
	                      0, 0, self.hinst, None)

		#self.el("Create Window done hwnd="+repr(self.hwnd))
		left, top, right, bottom = GetClientRect(self.hwnd)

#		print platform, type(platform)
		if WINCE:
			self.hCmdBar = CommandBar_Create(self.hinst, self.hwnd, 1)
			CommandBar_InsertMenubar(self.hCmdBar, self.hinst, IDR_MENU, 0)
			CommandBar_AddAdornments(self.hCmdBar, 0, 0)
			top = CommandBar_Height(self.hCmdBar)
			#self.el("Create CommandBar done hCmdBar="+repr(self.hCmdBar))
#		style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL # before mod
		style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN|ES_OEMCONVERT #|ES_AUTOHSCROLL # WS_HSCROLL removed. Will it wrap or not?
		# ES_OEMCONVERT added for unicode <->sjis conversion.ActivePython acts like that.
		self.hwndEdit=CreateWindow("EDIT", None, style, \
				      left, top, (right-left), (bottom-top), \
		                      self.hwnd, 0, self.hinst, None)    
		#self.el("Create EditWindow done hwndEdit="+repr(self.hwndEdit))
	
		self.oldEditWndProc = SetWindowLong(self.hwndEdit, GWL_WNDPROC, self.GetEditMessageMap())# self.EditWndProc)

		#if not WINCE: # <=== Modify this to change FONT
		#	SendMessage(self.hwndEdit, WM_SETFONT, GetStockObject(ANSI_FIXED_FONT), 0)
		# In CE GetStockObject(SYSTEM_FONT) can be used to get stock FONT.
		# SYSTEM_FONT = 13 ( defined in windows.h )
		# GetObjct(GetStockObject(SYSTEM_FONT)) will return PyLOGFONT.

		if WINCE: #
			#lf=GetObject(GetStockObject(13)) # 13 => SYSTEM_FONT
			#lf.lfCharSet=128 # Japanese ShiftJis. See wingdi.h of SDK for details.
			#lf.lfPitchAndFamily=1 # Fixed pitch. It could be 97
			#lfid = id(lf)
			#SendMessage(self.hwndEdit, WM_SETFONT, lfid, 0) # Well, let's try and see
			pass # It didn't work either.
		else:
			SendMessage(self.hwndEdit, WM_SETFONT, GetStockObject(ANSI_FIXED_FONT), 0)

		# If there is SelectObj(hdc,hgdiobj) or CreateFontIndirect(LOGFONT),
		# we can change font. But Mark didn't implemented them.
		#
		# maybe we can use WM_FONTCHANGE to hwind (not hwndEdit).
		# Anyway we have to find usable font object somehow.
		#
		#SendMessage(self.hwndEdit, WM_SETFONT, GetStockObject(13), 0) # 13=SYSTEM_FONT
		ShowWindow(self.hwnd, SW_SHOW) 
		UpdateWindow(self.hwnd)

		EnableWindow(self.hwndEdit, 1)
	
		SetFocus(self.hwndEdit)
		SetCursor(LoadCursor(0,0))
		#self.el("W32c.init() done")

	def Term(self):
		#self.el("W32c.Term")
		UnregisterClass(self.classAtom, self.hinst)

	# Mod by Telion for input( )
	def readline(self):
		##self.el("====W32c.readline()====")
		self.reading = 1
		rc = WaitForMultipleObjects( (self.eventInteractiveInputAvailable, self.eventClosed), 0, INFINITE)
		if rc == WAIT_OBJECT_0:
			s = self.read_dat
		else:
			s='Debug w32c.readline nothing'
		self.reading = 0
		#self.el("==="+repr(s)+"===\n")
		return repr(s)
	
	def _getc1(self,w,l): # hook for getchar, before showing the char
		# This func is called every time WM_CHAR sends message
		##self.el("#"+chr(w)+"<"+repr(w)+":"+repr(l)+">,")
		return 0

	def _getc2(self,w,l,r): # hook for getchar, after showing the char
		#print "*",
		##self.el("*,")
		return 0

	def SM(self,hw,msg,wp,lp): # Mod by Telion. Send arbitrary Message to w32c window 
		#self.el("SM:"+repr(hw)+", "+repr(msg)+", "+repr(wp)+", "+repr(lp)+"\n")
		return SendMessage(hw, msg, wp, lp) 
		
	def OnEditChar(self,hWnd, msg, wparam, lparam):# WindowProc for WM_CHAR call
		##self.el("OEC,"+chr(wparam)+"="+repr(wparam)+":"+repr(lparam)+",msg:"+repr(msg))
		if self._getc1_on:
			##self.el("_getc1 hook")
			if self._getc1(wparam, lparam): # getchar hook before showing char
			##self.el("_getc1 hook returnd")
				return # _getc1() can retrun 1 to stop
		if self.reading == 1: # first time after readline started
			##self.el("reading==1")
			self.reading = 2	# change it to avoid coming back
			self.pChar=SendMessage(hWnd, EM_LINEINDEX, -1) # get current line index
			self.pLine=SendMessage(hWnd, EM_LINELENGTH, self.pChar)# get the length
		if wparam!=0x0D: # if it is not return key, pass it to original procedure
			##self.el("A Key")
			# by inserting other code here,, you may capture and deal with other keys
			if wparam == self.quitkey: # If quit-key (Ctrl-Q), QUIT
				#self.el("wparam==0x11")
				DestroyWindow(self.hwnd);
				return
			# above function processes key for display and cut, copy, paste, undo
		else: # if it is return key
			##self.el("ReturnKey pressed")
			cChar=SendMessage(hWnd, EM_LINEINDEX, -1)
			cLine=SendMessage(hWnd, EM_LINEFROMCHAR, cChar)
			if self.reading: # readline in underway
				self.read_dat = str(Edit_GetLine(hWnd, cLine, 512)) # get current line
				if cChar != self.pChar: # if user moved away from input line
					pass # just return enitre line as a result
				else:
					if len(self.read_dat) < self.pLine: # if user erased prompt
						pass # just return enitre line as a result
					else:	
						self.read_dat = self.read_dat[self.pLine:] # remove prompt
				print ''
				SetEvent(self.eventInteractiveInputAvailable)
				#ShowCaret(hWnd)
				return 0
		r = CallWindowProc(self.oldEditWndProc, hWnd, msg, wparam, lparam)
		##self.el("CWP="+repr(r))
		if self._getc2_on:
			self._getc2(wparam, lparam,r) # getchar hook after
		return r

	def OnParentSize(self, hwnd, msg, wparam, lparam):
		left, top, right, bottom = GetClientRect(hwnd)
		try:
			top=CommandBar_Height(self.hCmdBar);
		except NameError: # Only on CE
			pass
		if self.hwndEdit is not None:
			SetWindowPos(self.hwndEdit, HWND_TOP, left, top, right-left, bottom-top, 0)
			ShowWindow(self.hwndEdit, SW_SHOWNORMAL)

	def OnParentDestroy(self, hwnd, msg, wparam, lparam):
		PostQuitMessage(hwnd)
		# And tell the thread waiting for us we are done!
		SetEvent(self.eventClosed)

	def OnParentSetFocus(self, hwnd, msg, wparam, lparam):
		if self.hwndEdit is not None:
			SetFocus(self.hwndEdit)
	
	def OnParentUser(self, hwnd, msg, wparam, lparam):
		# Out write function post this message.
		# We dequeue the output, and write the text.
		#    Writing by selecting text andreplacing it?
		#    Why? To limit the Edit buffer size!
		#    This way of doing slowsdown screen redraw.
		#    Maybe we can do it once in a while, say when showing sys.ps1,
		#    or when Enter is pressed. NOT EVERYTIME WRITEING.
		#
		##self.el("OnParentUser,"+repr(msg)+":"+repr(wparam)+":"+repr(lparam)+",hwnd="+repr(hwnd))
		while self.outputQueue:
			self.outputQueueLock.acquire()
			text = string.join(self.outputQueue, '')
			##self.el( "===OPU text===\n"+text+"\n===OPU text End===\n")
			#self.el(text)
			self.outputQueue = []
			self.outputQueueLock.release()
			##self.el("OPU QueueLock released")
			#   get text and empty queue done
			SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
			##self.el("OPU SETSEL sent")
			#   region selection starts
			
			# Now check that we wont fill the control.
			# If so, remove the first lines until we are OK.
			selInfo = SendMessage(self.hwndEdit, EM_GETSEL, 0, 0)
			##self.el("OPU GETSEL sent")
			endPos = HIWORD(selInfo)
			##self.el("selinfo="+repr(selInfo)+", endPos="+repr(endPos)+", len(Text)="+repr(len(text)))
			lineLookIndex = 0
			lineLookLength = 0
			while endPos + len(text) - lineLookLength > 29000:
				#self.el("OPU LLL loop",repr(lineLookIndex))
				lineLookIndex = lineLookIndex + 1
				lineLookLength = SendMessage(self.hwndEdit, EM_LINEINDEX, lineLookIndex, 0)
			if lineLookIndex > 0:
				# The SETREDRAW has no effect on CE.  If we really want this
				# I think we must respond to WM_PAINT, and ignore it for the duration
				# the redraw is turned off.
				SendMessage(self.hwndEdit, WM_SETREDRAW, 0, 0)
				SendMessage(self.hwndEdit, EM_SETSEL, 0, lineLookLength)
				SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(""))
				# And back to the end.
				SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
				SendMessage(self.hwndEdit, WM_SETREDRAW, 1, 0)

			##self.el("OPU before REPLACESEL sent")
			
			SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(text))
			##self.el("OPU REPLACESEL sent")

	def OnParentCommand(self, hwnd, msg, wparam, lparam):
		##self.el("OnParentCammnd"+repr(msg)+":"+repr(wparam)+":"+repr(lparam)+",hwnd="+repr(hwnd))
		command = LOWORD(wparam)
		
		if command == IDM_EXIT:
			#self.el("IDM_EXIT")
			DestroyWindow(hwnd);
		elif command == IDM_ABOUT:
			DialogBox(self.hinst, IDD_ABOUT, hwnd, AboutBoxDlgProc)
		return 0

def AboutBoxDlgProc(hwnd, msg, wparam, lparam):
	if msg==WM_COMMAND:
		p=LOWORD(wparam)
		if p==IDOK or p==IDCANCEL:
			EndDialog(hwnd, 1)
		return 1
	return 0

def startwin(Interact): # start an edit window with (func)Interact supplied.
	# We run the w32c in the main thread, so that when it terminates
	# (accidently or otherwise) the application terminates.
	# A seperate thread is used to execute the Python code.
	
	#import win32gui
	#win32gui.NKDbgPrintfW('Debugging message') #dosen't work??

	#Oname = __name__
	__name__ = sys.argv[0] # ??? Why this?

	# Make "w32c" global just for debugging purposes
	# ie, so interactive code can see it via __main__.w32c (or "ceshell.w32c" on CE)
	global w32c #
	w32c = W32console()
	global w32cThreadId
	w32cThreadId = thread.get_ident()
	# Create the windows, but dont start the message loop yet.
	w32c.Init()

	# Can now write to the w32c - assign the standard files.
	oldOut, oldErr, oldIn  = sys.stdout, sys.stderr, sys.stdin
	sys.stderr = w32c
	sys.stdout = w32c
	sys.stdin = w32c
	
	# Create the new thread to execute the code.
	thread.start_new(Interact, (w32c,) )
	
	# Now run the w32c.
	w32c.Run()
	w32c.Term()
	sys.stdout = oldOut
	sys.stderr = oldErr
	sys.stdin = oldIn

# On Windows, run this as a script.
# On CE, this module is imported and main() executed by
# the startup C code.

#if __name__=='__main__':
#	main()
