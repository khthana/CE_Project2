#
""" ----- obj.py ---
Utilities for object inspection and manipulation
	obj.info(anyPythonObject) will give lots of infomation about it.
"""
# I needed this to learn about python objects.
#
# Telion
#

def namedv(o_name,i=0,v=None):
	"""return the object with name (o_name) searching back recursively 
	all frames, and both locals() and globals().
	Usefull for accessing an object you know the name, but you can't
	access normally.
	
	Verbose version.(If set so)
	USE nameds() for faster operation if verbose output is not required
	
	It mimics name-space lookup of python, but in all frame levels
	i == 0 -> current frame (obj.named) DEFAULT
	i == 1 -> caller (code frame that called this function),
	i == 2 .. -> caller of caller and up
	i == -3 -> Interactive or Interpreter in CE, in most case.
	i == -1 -> Base level
	
	v == not None -> verbose operation
	"""
# For things easily found in sys.modules, sys.modules['module']['obj']
# may do the job.
# Also it is done this way for the speed.
# I tested cleaner nicer looking code, and it turned out
# This was was much faster.

	#if not i: i=0
	if i>=0: i=i+2
	if v: print "=== Searcing",o_name,"==="
	if "." in o_name: # preparation for dotted name
		#if v: print "object name with dot(s)"
		from string import find
		a=find(o_name,".")
		ono=o_name
		o_name2=o_name[a+1:]
		o_name=o_name[:a]
		#if v: print "-->",o_name, o_name2
		if "." in o_name2: # support uo to 2 dots for now
			#if v: print "object name with at least 2 dots"
			a2=find(o_name2,".")
			o_name3=o_name2[a2+1:]
			o_name2=o_name2[:a2]
			if "." in o_name3:
				raise "Error:","object name with more than 2 dots not supported"
		else:
			a2=0
	else:
		a=0
	from flist import f_list
	fl=f_list()[i:]
	if not fl: 
		if i>0: i = i-2
		raise IndexError, "frame list index out of range (i):="+repr(i)
	for fi in fl: # frame tracing back loop
		if v: print "Searcing in",repr(fi[1])
		try:
			o=(fi[0].f_locals)[o_name]
			if v: print "Found in locals of",repr(fi[1])
			if not a: return o # if the name doesn't have any dot
			#if v: print repr(len(dir(o)))
			#if v: print repr(len(o.__dict__.keys()))
			if v: print "Searching for 2nd part >",o_name2
			try:
				o2=o.__dict__[o_name2]
				if v: print o_name2,"Found in ",o_name, "__dict__ of",repr(fi[1])
				if not a2: return o2
				if v: print "Searching for 3rd part >",o_name3
				try:
					o3=o2.__dict__[o_name3]
					if v: print o_name3,"Found in ",o_name,o_name2, "__dict__ of",repr(fi[1])
					return o3
				except KeyError:
					pass
			except KeyError:
				pass
		except KeyError:
			pass
		try:
			o=(fi[0].f_globals)[o_name]
			if v: print "Found in globals of",repr(fi[1])
			if not a: return o # if the name doesn't have any dot
			#if v: print repr(len(dir(o)))
			#if v: print repr(len(o.__dict__.keys()))
			if v: print "Searching for 2nd part >",o_name2
			try:
				o2=o.__dict__[o_name2]
				if v: print o_name2,"Found in ",o_name, "__dict__ of",repr(fi[1])
				if not a2: return o2
				if v: print "Searching for 3rd part >",o_name3
				try:
					o3=o2.__dict__[o_name3]
					if v: print o_name3,"Found in ",o_name,o_name2, "__dict__ of",repr(fi[1])
					return o3
				except KeyError:
					pass
			except KeyError:
				pass
		except KeyError:
			pass

def named(o_name,i=0,v=None):
	"""stripped out version of named() for faster operation.
	arg (v) is kept for compatbility with named, but not used
	see named.__doc__ for more detail
	testing version with has_key()
	"""
	if not i: i=0
	if i>=0: i=i+2
	if "." in o_name: # preparation for dotted name
		from string import find
		a=find(o_name,".")
		o_name2=o_name[a+1:]
		o_name=o_name[:a]
		if "." in o_name2: # support uo to 2 dots for now
			a2=find(o_name2,".")
			o_name3=o_name2[a2+1:]
			o_name2=o_name2[:a2]
			if "." in o_name3:
				raise "Error:","object name with more than 2 dots not supported"
		else:
			a2=0
	else:
		a=0
	from flist import f_list
	fl=f_list()[i:]
	if not fl: 
		if i>0: i = i-2
		raise IndexError, "frame list index out of range (i):="+repr(i)

	for fi in fl: # frame tracing back loop
		ff=fi[0].f_locals
		if ff.has_key(o_name):
			o=ff[o_name]
			o=fi[0].f_locals[o_name]
			if not a: return o # if the name doesn't have any dot
			if o.__dict__.has_key(o_name2):
				o2=o.__dict__[o_name2]
				if not a2: return o2
				if o2.__dict__.has_key(o_name3):
					o3=o2.__dict__[o_name3]
					return o3
		ff=fi[0].f_globals
		if ff.has_key(o_name):
			o=ff[o_name]
			if not a: return o # if the name doesn't have any dot
			if o.__dict__.has_key(o_name2):
				o2=o.__dict__[o_name2]
				if not a2: return o2
				if o2.__dict__.has_key(o_name3):
					o3=o2.__dict__[o_name3]
					return o3


def tbn(s):
	""" traceback and find the frame and object with name (s) """
	import flist
	fl=flist.f_list()
	fi = 0
	import string
	a=string.find(s,".")
	if a>0:
		if s[:a] != "self":
			exec('import '+s[:a])
		else:
			ss = s[:a]
			s="self"
			fi = 1
	import sys
	sys.stdout.write("+ ps =>"+ s + ":= ")
	loc = 1
	o = None
	for ii in range(len(fl)):
		# in the caller's local namespace
		try: o = fl[ii][0].f_locals[s]
		except: pass
		else: break
		# in the caller's global namespace
		try: o = fl[ii][0].f_globals[s]
		except: pass
		else: loc = 0; break
	if not o:
		print "(Not Found)"
		return None
	return o

def ps(s): # search obj by name, then print name of obj, repr(obj), and id 
	o=named(s)
	print "+ ps =>", s,":=",repr(o),id(o)

def toname(o,i=2): # look for the name of given obj and return list of name(s).
	nn=["o"]
	if hasattr(o,'__name__'):
		#print "obj.__name__ exists :=",o.__name__
		nn.append(o.__name__)
	for k,v in locals().items(): # name in this locals
		if v == o:
			if not k in nn:
				nn.append(k)
	for k,v in globals().items():
		if v == o:
			if not k in nn:
				nn.append(k)
	from flu import locals_x,globals_x # name in specified frame
	for k,v in locals_x(i).items():
		if v == o:
			if not k in nn:
				nn.append(k)
	for k,v in globals_x(i).items():
		if v == o:
			if not k in nn:
				nn.append(k)
	import sys
	d = sys.modules # at last, check the sys.modules
	del sys
	for k,v in d.items():
		if k in nn:
			continue
		if v == o:
			nn.append(k)
		#if v.has_key(__dict__):
			#pass
	return nn[1:]
		

def po(o): # print name of obj , id , and repr(obj)
	print "po ->",objname(o),":=",repr(o),"<id:",id(o),">"

def atime():
	import time
	t = time.localtime(time.time())
	return '%02d/%02d/%02d  %02d:%02d:%02d' % t[:6]

def sysinfo():
	import sys
	import os
	print atime()
	ps("sys.argv")
	ps("__name__")
	ps("sys.version")
	ps("sys.platform")
	po(sys.copyright)
	po(sys.dllhandle)
	po(sys.prefix)
	po(sys.exec_prefix)
	po(sys.executable)
	po(os.name)

def pa(o,name):
	print repr(o),name
	if type(o) == type(''):
#		print "String"
		n=o
		exec('import '+n)
		oo=eval(n)
	else:
#		print "Not string"
		n=objname(o)
		oo=o
	if hasattr(oo,name):
		print n,".",name,":=",getattr(oo,name)

global oh
oh=[]
global fb
fb=None
global oo

def pof(f): # print the name of given function and the result of it
			# when it it applied to (global oo) object
	global oo
	try:
		r = f(oo)
	except:
		#import sys
		#r = "N/A error = "+repr(sys.exc_info()[2].tb_frame.f_exc_type)
		r=None
	if type(r) != type(''):
		r=repr(r)
	if r: print "+",f.__name__,"(obj) :=",r
	return r
	
def poa(a): # print the given attribute name string and the value of it
			# when it it applied to (global oo) object
	global oo
	if hasattr(oo,a):
		r = getattr(oo,a)
		if type(r) != type(''):
			rr=repr(r)
		else:
			rr=r
		try:
			l=len(r)
		except:
			l=0
		t=type(r)
		import types
		if t is types.DictType:
			if not ny("Print all Dict "+a):
				if ny("Print just Keys()"):
					rr=r.keys()
				else:
					rr=""
		if a == '__doc__':
			if l > 40:
				if not ny("Print Doc of length "+repr(l)):
					rr=""
		print "+obj.",a, ":=", repr(t), l, "->",rr
		#exec 'print "+",a, ":=", oo.'+a

def ny(s): # asks question with default answer of No
	r=input("# "+s+"?(Y or y = Yes / else = No)>")
	return r in ('y' ,'Y')

def yn(s): # asks question with default answer of Yes
	r=input("# "+s+"?(N or n = No / else = Yes)>")
	return not (r in ('n' ,'N'))

def nyiflong(s,o,n): # ask before print if len(o) > n
	if len(o) > n:
		r=input("# "+s+"?(Y or y = Yes / else = No)>")
		if not r in ('y' ,'Y'):
			return 0
	print repr(o)

def dig(s,o2):
	o2s=repr(o2)
	if ny("Dig the "+s+" := "+o2s+" "):
		print " - - - - - - "
		return info(o2)
	return(o2)

def asimp(s): 
	""" 	assert import and return module object 
	s <- module name string
	If it fails to import the module, it returns None.
	"""
	try:
		r=eval(s)
	except:
		try:
			exec "import "+s
		except:
			return None
		r=eval(s)
	return r
		

def info(o):
# after importing this module, try obj.info(anyobject)
# This will show most of info you may get out of it.
#
	global oo
	global oh
	global fb
	oh.append(o)
	oo=o
	print " Object information"
	oid=pof(id)
	otype=str(pof(type))
	orepr=pof(repr)
	olen=pof(len)
	ohash=pof(hash)
	ocall=pof(callable)
	odir=pof(dir)
	try:
		ovars=vars(o).keys().sort() # name,obj pairs in dictionary
	except:
		ovars=None
	print "+ vars(obj).keys() :=",repr(ovars)

	for i in ['__name__','__file__','__path__','__bases__','__class__','__module__'
		'__self__','__members__','__methods__','func_name','func_default',
		'im_class','im_self','im_func','co_name','co_argcount','co_nlocals',
		'co_varnames','co_filename','co_irstlineno','co_flags','co_stacksize',
		'f_back','f_code','f_lineno','f_trace','f_exc_type',
		'f_exc_value','f_exc_traceback','f_locals','f_globals','f_builtins',
		'tb_frame','tb_next','tb_lineno','start','stop','step','real','imag',
		'tolist','co_names',
		'__dict__','__doc__','func_doc','func_globals']:
		
		poa(i)
	
	if otype=="<type 'instance'>":
		r=dig("class",oo.__class__)

	elif otype=="<type 'class'>":
		if oo.__bases__:
			for c in oo.__bases__:
				if c: r=dig("baseclass",c)
		r=dig("module",asimp(oo.__module__))

	elif otype=="<type 'function'>":
		r=dig("module",asimp(oo.func_globals['__name__']))

	elif otype=="<type 'instance method'>":
		if oo.im_self:
			r=dig("instance",oo.im_self)
		else:
			r=dig("class",oo.im_class)

	elif otype=="<type 'builtin_function_or_method'>":
		if oo.__self__:
			r=dig("target object",oo.__self__)

	elif otype=="<type 'code'>":
		r=dig("function",oo.co_function)

	elif otype=="<type 'traceback'>":
		r=dig("frame",oo.tb_frame)

	elif otype=="<type 'frame'>":
		fb=oo.f_code
		r=dig("code object",oo.f_code)
	if fb:
		fb=None
		r=dig("previous frame",fb)
	
	return oh

