

def encode(s, binary=True, maxlinelen=76, eol='NL'):
    return s
    

