'''
' By Chakrit Hengsirikul
' Professor : Dr.Visit Hirankitti
'---------------------------------------
' 2004/03/05
' construct color map
'''

from config import *
from getuserprofile import getuserprofile

DEFAULT_COLOR = 1

class color:

    def __init__(self):

        scriptfilename = ''  ## for store form openfile when call openfile

        self.color = {1:{},2:{},3:{},4:{}}
        self.upf=getuserprofile()
        self.upf.getuserpf('colormap\\color1.profile',self.color[1])
        self.upf.getuserpf('colormap\\color2.profile',self.color[2])
        self.upf.getuserpf('colormap\\color3.profile',self.color[3])
        self.upf.getuserpf('colormap\\color4.profile',self.color[4])


    def getcolor(self,number):
        if number in self.color:
            return self.color[number]
        else:
            return self.color[DEFAULT_COLOR]