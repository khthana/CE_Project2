import poplib, getpass, sys, mailconfig
import smtplib, string, time
import urllib
from abstract import *
from ftplib import FTP
from os.path import exists

from tkMessageBox import *
################
import sys
import os
from Tkinter import *
import Pmw

from ftplib import FTP  
from config import *
from getuserprofile import getuserprofile
from myftp import myftp


global cx

def cttr(cx):
    cx=2
    print cx
    return checkType(0)

def remind(note):
    date = time.ctime(time.time())
    showinfo("Remind",note)
    print date+'>>'+note
    return checkType(1)

def openurl(c_url):
    from myweb import myweb
    
    root = Tk()
    brff=Frame(root)
    brff.pack()
    sslib_showfile = Pmw.ScrolledText(brff,
                usehullsize = 1,
                hull_width = 235,
                hull_height = 270,
                text_wrap='none',
    )
    sslib_showfile.pack(side = LEFT,expand =YES,fill=BOTH)
    ssmyweb=myweb()
    sstext=ssmyweb.open(c_url)
    sslib_showfile.appendtext(sstext)
    root.mainloop()
    return checkType(1)

def download(c_filename, c_dir='', c_username='', c_password='', c_server='', c_port='') :
    '''
        download a file from FTP Server
        by input all parameter OR only file name and other parameter by default < from user profile>
    '''
    #print c_filename
    #print c_dir
    #print c_username
    #print c_password
    #print c_server
    #print c_port
    
    global ftppath
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('ftp.profile',upfd)
    #for i in upfd.keys():
    #    print i,' ',upfd[i]
        
    if c_filename == '':
        return checkType(1)
    if c_username == '' : c_username = upfd['username']
    if c_password == '' : c_password = upfd['password']
    if c_server == '' : c_server = upfd['server']
    if c_port == '' : c_port = upfd['port']
    
    try :
        localfile  = open(ftppath+c_filename, 'wb')
        connection = FTP()       
        connection.connect(c_server,c_port)
        connection.login(c_username,c_password)
        if c_dir <> '':
            connection.cwd(c_dir)
        connection.retrbinary('RETR ' + c_filename, localfile.write, 1024)
        connection.quit()
        localfile.close()
        ck_boolean = 0
    except Exception:
        ck_boolean = 1
    #ck_ftp = myftp(c_server,c_port,c_username,c_password)
    #ck_ftp.login_ftp()
    #ck_ftp.setlocaldir(ftppath)
    #ck_boolean = ck_ftp.downloadfile_or_changdirto(c_filename)
    #ck_ftp.quit()
    #print 'Download done'
    return checkType(ck_boolean)


def upload(c_filename,c_dir='',c_username='',c_password='',c_server='',c_port='') :
    '''
        upload a file to FTP Server
        by input all parameter OR only file name and other parameter by default < from user profile>
    '''
    global ftppath
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('ftp.profile',upfd)
    #for i,v in upfd.items():
    #    print i+':'+v
    try :
        localfile  = open(ftppath+c_filename, 'r')
        connection = FTP()       
        connection.connect(c_server,c_port)
        connection.login(c_username,c_password)
        if c_dir <> '':
            connection.cwd(c_dir)
        connection.storbinary('STOR ' + c_filename, localfile, 1024)
        connection.quit()
        localfile.close()
        ck_boolean = 0
    except Exception:
        ck_boolean = 0
    return checkType(ck_boolean)


def sendmail(c_To, c_Subj,c_Data, c_From='', c_smtp='') :
    '''
        send out input mail
    '''
    import time
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('mail.profile',upfd)
    if c_From=='':c_From=upfd['mailuser']
    if c_smtp=='':c_smtp=upfd['smtpserver']
    
    addrdict={}
    upf.getuserpf('contact.profile',addrdict)
    if addrdict.has_key(c_To):
        c_To=addrdict[c_To]
    try:
        server = smtplib.SMTP(c_smtp)         ## connect, no login step
        c_From = string.strip(c_From)
        c_To   = string.strip(c_To)
        c_Subj = string.strip(c_Subj)
        c_Data = string.strip(c_Data)
        ## prepend standard headers
        date = time.ctime(time.time())
        mail = ('From: %s\nTo: %s\nDate: %s\nSubject: %s\n'
            % (c_From, string.join(c_To, ';'), date, c_Subj))
        mail = mail + c_Data
        failed = server.sendmail(c_From, c_To, mail)
    finally:
        server.quit()
        if failed:                                     ## smtplib may raise exceptions
            return checkType(0)
        else:
            return checkType(1)


def checkmail(c_pop='', c_mailuser='', c_mailpasswd=''):
    '''
        print out and return number of mail in server , print out number of byte
        BUG: a function must input a parameter and return
             < I dont know  what is this constrain for? >
             this make < can't only call checkmail() >
    '''
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('mail.profile',upfd)
    if c_pop=='':c_pop=upfd['mailserver']
    if c_mailuser=='':c_mailuser=upfd['mailuser']
    if c_mailpasswd=='':c_mailpasswd=upfd['mailpaswd']
    try:
        server = poplib.POP3(c_pop)
        server.user(c_mailuser)         # connect, login to mail server
        server.pass_(c_mailpasswd)       # pass is a reserved word
        msgCount, msgBytes = server.stat()
        print 'Have '+str(msgCount)+' mail Totle '+str(msgBytes)+' byte in Mail account'
        ##print 'There are', self.msgCount, 'mail messages in', self.msgBytes, 'bytes'
        ck_boolean = msgCount
    except Exception:
        ck_boolean = -1
    return checkType(ck_boolean)


def readmail(c_pop='', c_mailuser='', c_mailpasswd=''):
    '''
        retrive all mail and print out to CONSOLE by call def __myreadmail()
    '''
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('mail.profile',upfd)
    if c_pop=='':c_pop=upfd['mailserver']
    if c_mailuser=='':c_mailuser=upfd['mailuser']
    if c_mailpasswd=='':c_mailpasswd=upfd['mailpaswd']
    try:
        server = poplib.POP3(c_pop)
        server.user(c_mailuser)         # connect, login to mail server
        server.pass_(c_mailpasswd)       # pass is a reserved word
        msgCount, msgBytes = server.stat()
        print 'Have '+str(msgCount)+' mail Totle '+str(msgBytes)+' byte in Mail account'
        
        for mailat in range(msgCount):
            mail=[]
            try:
                end=0
                (hdr, message, octets) = server.retr(mailat)      # save text on list
                message = string.join(message, '\n')
                strfile = StringIO.StringIO(message)     # make string look like a file
                msghdrs = rfc822.Message(strfile)    # parse mail headers into a dict
                #print '%d:\t%d bytes' % (mailat, len(self.message))
                for hdr in ('From', 'Date', 'Subject'):
                    try:
                        mail[hdr] = msghdrs[hdr]
                        headermail[hdr] = msghdrs[hdr]
                        end = self.message.find(msghdrs[hdr])
                    except KeyError:
                        #print '\t%s=>(unknown)' % self.hdr
                        pass
                message = message[end+1:]
                #print '^'*70
                #print self.message
                mail['data'] = self.message
                __myreadmail(mail,mailat)
            finally:
                return self.mail,self.headermail
        ##print 'There are', self.msgCount, 'mail messages in', self.msgBytes, 'bytes'
        ck_boolean = msgCount
    except Exception:
        ck_boolean = -1
    return checkType(ck_boolean)
    pass

def __myreadmail(mail,mailat):
    '''
        inner function for def readmail()
        in put a mail and print out to CONSOLE
    '''
    print '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
    print 'Mail number:'+str(mailat)
    for hdr in ('From', 'Date', 'Subject'):
        if mail.has_key(hdr):
            print hdr+':'+mail[hdr]+'\n'


def savemail(c_pop='', c_mailuser='', c_mailpasswd=''):
    '''
        retrive all mail and save each mail in upfd['mailsavepath'] by call def __mysavemail()
    '''
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('mail.profile',upfd)
    if c_pop=='':c_pop=upfd['mailserver']
    if c_mailuser=='':c_mailuser=upfd['mailuser']
    if c_mailpasswd=='':c_mailpasswd=upfd['mailpaswd']
    try:
        server = poplib.POP3(c_pop)
        server.user(c_mailuser)         # connect, login to mail server
        server.pass_(c_mailpasswd)       # pass is a reserved word
        msgCount, msgBytes = server.stat()
        print 'Have '+str(msgCount)+' mail Totle '+str(msgBytes)+' byte in Mail account'
        
        for mailat in range(msgCount):
            mail=[]
            try:
                end=0
                (hdr, message, octets) = server.retr(mailat)      # save text on list
                message = string.join(message, '\n')
                strfile = StringIO.StringIO(message)     # make string look like a file
                msghdrs = rfc822.Message(strfile)    # parse mail headers into a dict
                #print '%d:\t%d bytes' % (mailat, len(self.message))
                for hdr in ('From', 'Date', 'Subject'):
                    try:
                        mail[hdr] = msghdrs[hdr]
                        headermail[hdr] = msghdrs[hdr]
                        end = self.message.find(msghdrs[hdr])
                    except KeyError:
                        pass
                message = message[end+1:]
                mail['data'] = self.message
                __mysavemail(mail,upfd['mailsavepath'])
            finally:
                return self.mail,self.headermail
        ck_boolean = msgCount
    except Exception:
        ck_boolean = -1
    return checkType(ck_boolean)


def __mysavemail(mail,mailsavepath):
    '''
        inner function for def savemail()
        in put a mail format file and where path to save
    '''
    for hdr in ('From', 'Date', ):
        if mail.has_key(hdr):
            print hdr+':'+mail[hdr]+'\n'
    filemail=''
    if mail.has_key('From'):filemail=filemail+'From:'+maol['From']
    if mail.has_key('Date'):filemail=filemail+'Date:'+maol['Date']
    if mail.has_key('Subject'):
        filemail=filemail+'Subject:'+maol['Subject']
        sub = mail['Subject']
    else:
        filemail=filemail+'Subject:'+maol['Subject']
        sub = 'unknow'
    if mail.has_key('data'):filemail=filemail+'data:'+maol['data']
    
    sub = __REMOVE_CHAR_LIST_FOR_FILENAME(sub)
    file = open(mailsavepath+sub+'.txt','w+')
    file.write(filemail)
    file.close()


def __REMOVE_CHAR_LIST_FOR_FILENAME(data):
    REMOVE_CHAR_LIST_FOR_FILENAME = ['\\','/',':','*','?','"','<','>','|']
    for t_i in REMOVE_CHAR_LIST_FOR_FILENAME:
        data = data.replace(t_i,'')
    return data




def getBidsdata(company) :
    remoteaddr = 'http://www.settrade.com/S13_FastQuote.jsp?txtBrokerId=IPO&txtSymbol=' + company
    print 'Downloading... ', remoteaddr
    remotefile = urllib.urlopen(remoteaddr)
    content = remotefile.read()
    remotefile.close() 
    keyword = ['Last Trade', 'Change', 'Open', 'Previous', 'Average', 'Day\'s Range', 'Bid', 'Volume', 'Market Capital']
    bidsdata = scanBids(keyword, content)
    date = time.ctime(time.time())
    allbidsdata = date + "\n"
    for i in range(len(keyword)) :
        allbidsdata = allbidsdata + keyword[i] + ' : ' + bidsdata[i] + "\n"
    return checkType(allbidsdata)

def scanBids(keyword, content) :
    eachdata = []
    for key in keyword :
        index = content.find(key)
        content = content[index+len(key):]
        intag = 0
        data = ''
        for char in content :
            if (char=='<') and (data == '') : intag = intag + 1
            elif (char=='<') and (data != '') : break
            elif (char=='>') and (data == '') : intag = intag-1
            elif (intag==0) and ((char!= "\t") and (char != " ")) : 
                data = data + char
        eachdata.append(data)
    return eachdata




if __name__ == '__main__' :
    cfn="Card.py"
    cdi="ch10"
    cun="ck13"
    cpw="ck13"
    csr="161.246.5.87"
    cpt="21"
    #a=download(cfn,cdi,cun,cpw,csr,cpt)
    #print 'download:',a.value
    cfn="Card.py"
    cdi="ch10"
    a=upload(cfn,cdi,cun,cpw,csr,cpt)
    print 'upload',a.value
    
    #sendmail('ck-163','testCommu','testdatatatdtatd\n\nkfkkf\n\nsfjksdfkfkkf')

    #a=checkmail();print a.value
    #a=readmail();print a.value
    #a=savemail();print a.value
    
    #a=openurl("http://dd")
    #a=remind('TEST REMIND');print a.value

    

