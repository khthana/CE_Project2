import os
from config import *

dirpath = picpath
a=os.listdir(dirpath)
print a