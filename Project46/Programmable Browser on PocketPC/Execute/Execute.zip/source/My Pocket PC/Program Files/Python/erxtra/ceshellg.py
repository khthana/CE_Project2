# A "Python console" for Windows CE.
#
# Also works on NT/9x (with a few limitations!) - useful for debugging!
#
# Used 2 threads - one for UI (ie, the message loop) and another thread
# for executing Python code.  Uses very simple events to synchronise the 2!


# Telion:
# Modified to act bit like unix shell (alias,history, etc)
# Type "help" on the command line for brief explanation.
# For more detail, read the code.
#
# input() works.

# It may require some modification for PythonCE22b1
# Also it has some garbage code
# I made it for me, not necessary for you.
# Don't cast a bad spell on me if you don't like it.
# Just change it as you wish, improve it.

print "starting ceshellg in pyce"
#import site
#print site.encoding
#site.encoding='mbcs' # Not working? 
Encoding = 'mbcs'

from win32gui import *
print "win32gui imported"
from win32event import *
print "win32event imported"

import sys
print sys.platform
print repr(sys.path)

import string
import thread
import threading
import traceback
import code # std module for compilation utilities.
import new
import os
import imp

from alias import Alias
#sys.platform="wince"  # for PythonCE22b1

#ignore  LOWORD
#ignore  HIWORD

#pypp IDOK=1
#define IDOK 1
#pypp IDCANCEL=2
#define IDCANCEL 2

#pypp GWL_WNDPROC=-4
#define GWL_WNDPROC -4
#pypp FIXED_PITCH=1
#define FIXED_PITCH 1
#pypp ANSI_FIXED_FONT=11
#define ANSI_FIXED_FONT 11

#pypp IDC_WAIT = 32514
#define IDC_WAIT 32514
#pypp HWND_TOP=0
#define HWND_TOP 0
#pypp CS_VREDRAW=1
#define CS_VREDRAW 1
#pypp CS_HREDRAW=2
#define CS_HREDRAW 2

#pypp CW_USEDEFAULT=0x80000000
#define CW_USEDEFAULT 0x80000000

#pypp WM_CHAR=258
#define WM_CHAR 258
#pypp WM_COMMAND=273
#define WM_COMMAND 273
#pypp WM_DESTROY=2
#define WM_DESTROY 2
#pypp WM_QUIT=18
#define WM_QUIT 18
#pypp WM_SETFOCUS=7
#define WM_SETFOCUS 7
#pypp WM_SETFONT=48
#define WM_SETFONT 48
#pypp WM_SETREDRAW=11
#define WM_SETREDRAW 11
#pypp WM_SIZE=5
#define WM_SIZE 5
#pypp WM_USER=1024
#define WM_USER 1024

#pypp WHITE_BRUSH=0
#define WHITE_BRUSH 0
#pypp SW_SHOW=5
#define SW_SHOW 5
#pypp SW_SHOWNORMAL=1
#define SW_SHOWNORMAL 1

#pypp WS_SYSMENU=524288
#define WS_SYSMENU 524288
#pypp WS_CLIPCHILDREN=33554432
#define WS_CLIPCHILDREN 33554432
#pypp WS_CHILD=1073741824
#define WS_CHILD 1073741824
#pypp WS_VISIBLE=268435456
#define WS_VISIBLE 268435456
#pypp WS_HSCROLL=1048576
#define WS_HSCROLL 1048576
#pypp WS_VSCROLL=2097152
#define WS_VSCROLL 2097152
if sys.platform=="wince":
	WS_OVERLAPPEDWINDOW=0
else:
	WS_OVERLAPPEDWINDOW=13565952

#pypp EM_GETLINECOUNT=186
#define EM_GETLINECOUNT 186
#pypp EM_GETSEL=176
#define EM_GETSEL 176
#pypp EM_LINEINDEX=187
#define EM_LINEINDEX 187
#pypp EM_LINEFROMCHAR=201
#define EM_LINEFROMCHAR 201
#pypp EM_LINELENGTH=193
#define EM_LINELENGTH 193
#pypp EM_SETSEL=177
#define EM_SETSEL 177
#pypp EM_REPLACESEL=194
#define EM_REPLACESEL 194

#pypp ES_LEFT=0
#define ES_LEFT 0
#pypp ES_MULTILINE=4
#define ES_MULTILINE 4
#pypp ES_WANTRETURN=4096
#define ES_WANTRETURN 4096
#pypp ES_AUTOVSCROLL=64
#define ES_AUTOVSCROLL 64
#pypp ES_AUTOHSCROLL=128
#define ES_AUTOHSCROLL 128

#pypp IDR_MENU=101
#define IDR_MENU 101
#pypp IDM_EXIT=40001
#define IDM_EXIT 40001
#pypp IDM_ABOUT=40002
#define IDM_ABOUT 40002
#pypp IDD_ABOUT=40002
#define IDD_ABOUT 40002

#ignore UNICODE
#ignore TEXT
if UNICODE:
	TEXT = Unicode
else:
	TEXT = lambda x: x

if sys.platform=="wince":
	OutputDebugString = NKDbgPrintfW
else:
	from win32api import OutputDebugString
	
try:
	sys.ps1
except AttributeError:
	sys.ps1 = ">>> "
	sys.ps2 = "... "

global slocals	# Telion
global dbg # Telion

#print "Before simpleshell class"
class SimpleShell:
	editMessageMap = {}
	def __init__(self,glo=None):
		#print "SimpleShell __init__()"
		if glo:
			self.init_glo=glo
		self.bInteract = 0 # Am I interacting?
		self.hwnd = None
		self.hwndEdit = None
		self.outputQueue = []
		self.outputQueueLock = threading.Lock()

		# Allocate some events for thread sync
		self.currentBlockItems = None
		self.eventInteractiveInputAvailable = CreateEvent(None, 0, 0, None)
		self.eventClosed = CreateEvent(None, 0, 0, None)

		# Added by Telion for alias, history, input( ), etc..
		self.reading = '' # readline flag and data
		self.pChar = 0 # readline current line number
		self.pLine = 0 # readline current line length

		self.cmdhist = []	# command history buffer
		self.cmdlst = 0 # last command number

		#self.alias = {'a':'alias','ua':'unalias'} # alias dictionary
		self.alias = Alias('pyalias') # load alias from '\\pyalias' in CE

		self.debug=0	# debug flag 0=no debug action

	def __del__(self):
		print "InteractiveManager dieing"

	def write(self, text):
		text = string.replace(text, "\n", "\r\n")
		#text = text[:-2], "\n", "\r\n")
		self.outputQueueLock.acquire()
		self.outputQueue.append(text)
		self.outputQueueLock.release()
		try:
#pypp 			PostMessage(self.hwnd, WM_USER, 0, 0)
			PostMessage(self.hwnd, 1024, 0, 0)
		except:
			pass
		
	def Run(self):
		PumpMessages()	

	def GetEditMessageMap(self):
#pypp 		return {WM_CHAR : self.OnEditChar}
		return {258 : self.OnEditChar}

	def GetParentMessageMap(self):
		map={}
#pypp 		map[WM_DESTROY] = self.OnParentDestroy
		map[2] = self.OnParentDestroy
#pypp 		map[WM_SIZE] = self.OnParentSize
		map[5] = self.OnParentSize
#pypp 		map[WM_SETFOCUS] = self.OnParentSetFocus
		map[7] = self.OnParentSetFocus
#pypp 		map[WM_USER] = self.OnParentUser
		map[1024] = self.OnParentUser
#pypp 		map[WM_COMMAND] = self.OnParentCommand
		map[273] = self.OnParentCommand
		return map
		
	def Init(self):
		#print "SimpleShell Init()"
		try:
			self.hinst = GetModuleHandle(None)
		except NameError: # Not on CE??
			self.hinst = sys.hinst # But this is :-)

		InitCommonControls()

#ignore WNDCLASS
		wc = WNDCLASS()
		wc.hInstance = self.hinst
#pypp 		wc.style=CS_HREDRAW | CS_VREDRAW
		wc.style=2 | 1
#pypp 		wc.hbrBackground = GetStockObject(WHITE_BRUSH)
		wc.hbrBackground = GetStockObject(0)
		wc.lpszClassName = TEXT("PYTHON_CE")
		# This code passes a dictionary as the "wndproc", rather than a function.
		wc.lpfnWndProc = self.GetParentMessageMap() #self.MainWndProc
		self.classAtom = RegisterClass(wc)
		
		if sys.platform=="wince":
#pypp 			style = WS_CLIPCHILDREN
			style = 33554432
		else:
#ignore WS_OVERLAPPEDWINDOW
			style = WS_OVERLAPPEDWINDOW
			
		self.hwnd = CreateWindow( self.classAtom, "Python CE", style, \
#pypp 	                      0, 0, CW_USEDEFAULT, CW_USEDEFAULT, \
	                      0, 0, 0x80000000, 0x80000000, \
	                      0, 0, self.hinst, None)

		left, top, right, bottom = GetClientRect(self.hwnd)

#		print sys.platform, type(sys.platform)
		if sys.platform=="wince":
			self.hCmdBar = CommandBar_Create(self.hinst, self.hwnd, 1)
#pypp 			CommandBar_InsertMenubar(self.hCmdBar, self.hinst, IDR_MENU, 0)
			CommandBar_InsertMenubar(self.hCmdBar, self.hinst, 101, 0)
			CommandBar_AddAdornments(self.hCmdBar, 0, 0)
			top = CommandBar_Height(self.hCmdBar)

		#style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL
#pypp 		style = WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN #|ES_AUTOHSCROLL|WS_HSCROLL
		style = 1073741824|268435456|2097152|0|4|4096 #|ES_AUTOHSCROLL|WS_HSCROLL
		self.hwndEdit=CreateWindow("EDIT", None, style, \
				      left, top, (right-left), (bottom-top), \
		                      self.hwnd, 0, self.hinst, None)    
	
#pypp 		self.oldEditWndProc = SetWindowLong(self.hwndEdit, GWL_WNDPROC, self.GetEditMessageMap())# self.EditWndProc)
		self.oldEditWndProc = SetWindowLong(self.hwndEdit, -4, self.GetEditMessageMap())# self.EditWndProc)

		if 0: #sys.platform != "wince":
#pypp 			SendMessage(self.hwndEdit, WM_SETFONT, GetStockObject(ANSI_FIXED_FONT), 0)
			SendMessage(self.hwndEdit, 48, GetStockObject(11), 0)

#pypp 		ShowWindow(self.hwnd, SW_SHOW)
		ShowWindow(self.hwnd, 5)
		#print "ShowWindow"
		UpdateWindow(self.hwnd)
		#print "UpdateWindow"

		EnableWindow(self.hwndEdit, 1)
		#print "EnableWindow"
	
		SetFocus(self.hwndEdit)
		#print "SetFocus"
		SetCursor(LoadCursor(0,0))
		#print "SetCursor"

	def Term(self):
		UnregisterClass(self.classAtom, self.hinst)

	# Mod by Telion for input( )
	def readline(self):
		#print "\nInside shell.readline"
		#pr = '-->'
		#lpr = len(pr)
		#sys.stdout.write( "\n"+pr)
		self.reading = 'on'
#pypp 		rc = WaitForMultipleObjects( (self.eventInteractiveInputAvailable, self.eventClosed), 0, INFINITE)
		rc = WaitForMultipleObjects( (self.eventInteractiveInputAvailable, self.eventClosed), 0, INFINITE)
#pypp 		if rc == WAIT_OBJECT_0:
		if rc == WAIT_OBJECT_0:
			s = self.reading
		else:
			s='Debug shell.readline nothing'
		#print "Going Out shell.readline with "+s
		self.reading = ''
		return repr(s)

	def SM(self,msg,wp,lp): # Mod by Telion. Send Message to shell window 
		return SendMessage(self.hWnd, msg, wp, lp) 
		
	def OnEditChar(self,hWnd, msg, wparam, lparam):# WindowProc for WM_CHAR call
		# readline patch for getting currnt cursor pos by Telion
		if self.reading != '':# readline going on
			if self.reading == 'on':# first time after readline started
				self.reading = 'on2'	# change it to avoid coming back
#pypp 				self.pChar=SendMessage(hWnd, EM_LINEINDEX, -1) # get current line index
				self.pChar=SendMessage(hWnd, 187, -1) # get current line index
#pypp 				self.pLine=SendMessage(hWnd, EM_LINELENGTH, self.pChar)# get the length
				self.pLine=SendMessage(hWnd, 193, self.pChar)# get the length
		if wparam!=0x0D: # if it is not return key, pass it to original procedure
			# by inserting other code here,, you may capture and deal with other keys
			return CallWindowProc(self.oldEditWndProc, hWnd, msg, wparam, lparam)
		else: # if it is return key
#pypp 			cChar=SendMessage(hWnd, EM_LINEINDEX, -1)
			cChar=SendMessage(hWnd, 187, -1)
#pypp 			cLine=SendMessage(hWnd, EM_LINEFROMCHAR, cChar)
			cLine=SendMessage(hWnd, 201, cChar)
			if self.reading != '': # readline in underway
				eline = Edit_GetLine(hWnd, cLine, 512)
#				if eline:
#					self.reading = eline.encode( Encoding) # get current line
#				else:
#					self.reading = ''
				if cChar != self.pChar: # if user moved away from input line
					pass # just return enitre line as the result
				else:
					if len(self.reading) < self.pLine: # if user erased prompt
						pass # just return enitre line as the result
					else:	
						# self.reading = self.reading[self.pLine:]+'X-X'+repr(cChar)+','+repr(self.pChar)+"x"+repr(cLine)+','+repr(self.pLine)+"<<Debug info"
						self.reading = self.reading[self.pLine:] # remove prompt
				print ''
				SetEvent(self.eventInteractiveInputAvailable)
				#ShowCaret(hWnd)
				return 0
			elif not self.bInteract: # if not in interact, pass it to original proc.
				return CallWindowProc(self.oldEditWndProc, hWnd, msg, wparam, lparam)
			# End of readline patch by Telion

			
			HideCaret(hWnd);
			# Find the start of the block
#pypp 			numLines = SendMessage(hWnd, EM_GETLINECOUNT, 0, 0)
			numLines = SendMessage(hWnd, 186, 0, 0)
			# GetLine fails as the size is wrong??
			maxLineSize=512
			blockStart = -1
			while cLine >= 0:
				eline = Edit_GetLine(hWnd, cLine, maxLineSize)
				if eline:
					line = eline.encode( Encoding)
				else:
					line = '';
				if line[:4]==sys.ps1:
					blockStart = cLine
					break
				elif line[:4]!=sys.ps2:
					break
				cLine = cLine -1

			if blockStart>=0:
				# Find the end of the block.
				while 1:
					cLine = cLine + 1
					eline = Edit_GetLine(hWnd, cLine, maxLineSize)
					if eline:
						line = eline.encode( Encoding)
					else:
						line = '';
					if line is None or line[:4]!=sys.ps2:
						break
				blockEnd = cLine
				# blockStart is the first line
				# blockEnd is one past the block end.
				eline = Edit_GetLine(hWnd, blockStart, maxLineSize)
				if eline:
					firstLine=(eline.encode( Encoding))[len(sys.ps1):]
				else:
					firstLine = '';
				# Special case for an empty command - mimic Python better by writing another ">>>"
				if len(firstLine)==0 and blockStart+1==blockEnd:
					# Empty prompt - write a new one.
					self.write("\n"+sys.ps1)
				else:
					items = [firstLine]
					for cLine in range(blockStart+1, blockEnd):
						eline = Edit_GetLine(hWnd, cLine, maxLineSize)
						if eline:
							items.append( (eline.encode( Encoding))[len(sys.ps2):] )
						else:
							items.append('')

					# If the block is not at the end of the control, copy it there...
					if blockEnd != numLines:
						self.write("\n%s%s" % (sys.ps1, items[0]))
						for item in items[1:]:
							self.write("\n%s%s" % (sys.ps2, items[0]))
					else:
						# Ready to execute.
						self.currentBlockItems = items
						
						# Alias Patch 1 by Telion
						# match against alias dict and replace it
						#
						# alias cmd=command :set cmd as alias of command
						# unalias cmd :remove alias cmd
						# %%commad :do not expand command
						#
						codeText = string.join(self.currentBlockItems, '\n')
						if codeText[0] == '%': # alias and history edit mode
							al = 0
							codeText=codeText[1:]
							if len(codeText)>0 and codeText[0] == '%': # No expansion mode
								codeText=codeText[1:]
								self.currentBlockItems=[codeText]
								#print "\n"+repr(self.currentBlockItems)+"="+repr(codeText)
								al=-1
							else:
								pass
						else:
							al = 1 # execution = 1
						#print "\n317expansion mode="+repr(al)+"CB"+repr(self.currentBlockItems)+"<CT>="+repr(codeText)
						#print "319"
						cmd=string.split(codeText,' ')
						#print "321"
						cmd1=list(cmd) # copy of command before alias expansion
						#print "323"
						#print cmd
						ct2=codeText
						if al >= 0: # expansion mode
							#print "326"
							ct2=self.alias.expand(codeText)
						#print codeText
						#print "326b"
						#print "\n326expansion mode="+repr(al)+"CB"+repr(self.currentBlockItems)+"<CT>="+codeText+"<ct2>="+ct2
						#print "327"
						#print "ct.type="+repr(type(codeText))+"<ct2.type>="+repr(type(ct2))
						#print "cmp="+repr(cmp(codeText,ct2))
						if cmp(codeText,ct2)!=0 and al >=0: # if expanded
							#print "329"
							codeText=ct2
							if al == 0: # edit mode
								#print "339"
								cmd=string.split(codeText,' ') 
								if cmd[0] == 'unalias' and len(cmd)>1: # alias unregister
									#print "335"
									cm=string.join(cmd,' ')
									cml=self.alias.value_keys(cm)
									if len(cml)>0:
										#print "339"
										codeText=cmd[0]+' '+cml[0]
								self.write("\n%s%s" % (sys.ps1, codeText))
								ShowCaret(hWnd)
								return 0
							else:
								#print "345"
								print "\n"+repr(codeText) # print expanded command to be done
								self.currentBlockItems=[codeText]
						
						# End of alias patch 1
						#print "350"

						#print "\n345expansion mode="+repr(al)+"CB"+repr(self.currentBlockItems)+"<CT>="+codeText



						# Simple command history patch by Telion
						# !   := show history
						# !!  := execute last command
						# !n  := execute n th command
						# %!! := edit last command
						# %!n := edit n th command
						# 
						#print "history patch here!"
						
						Maxcmdhist = 30  # this may be changed to any reasonable number
						cl = len(self.cmdhist)
						if codeText[0] == '!' and al >= 0: # if history request and expansion mode
							if cl==0: # check if history exist
								print "\nNo History in buffer"
								sys.stdout.write(sys.ps1)
								ShowCaret(hWnd)
								return 0
							elif codeText[1:] =='!': # Execute Last cmd with '!!'
								if al:
									self.currentBlockItems = [self.cmdhist[-1]]
								else:
									self.write("\n%s%s" % (sys.ps1, self.cmdhist[-1]))
									ShowCaret(hWnd)
									return 0
							elif codeText[1:] =='': # Show history with '!'
								print ""
								for n in range(cl):
									print ""+repr(self.cmdlst-cl+n+1)+":"+self.cmdhist[n]
								#sys.stdout.write("\n")
								sys.stdout.write(sys.ps1)
								ShowCaret(hWnd)
								return 0
							else: # do Nth cmd '!N'
								try:
									ch = int(codeText[1:])
								except:
									pass
								else:
									if ch >(self.cmdlst-cl) and ch <= self.cmdlst:
										self.currentBlockItems = [self.cmdhist[ch-self.cmdlst+cl-1]]
										#if codeText[1]!=' ': # Edit it
										if al == 0: # Edit it
											self.write("\n%s%s" % (sys.ps1, self.currentBlockItems[0]))
											ShowCaret(hWnd)
											return 0
										else: # Execute it
											pass
									else:
										print "\nHistory Number out of range"
										sys.stdout.write(sys.ps1)
										ShowCaret(hWnd)
										return 0
						elif (cl ==0 or codeText != self.cmdhist[-1]) and cmd1[0]!='unalias': # if not same as the last command, append it to the history buf
							#print "\n"+repr(codeText)
							self.cmdhist.append(codeText)
							self.cmdlst = self.cmdlst+1
							#print "lst="+repr(self.cmdlst)
							if cl >= Maxcmdhist:
								self.cmdhist = self.cmdhist[1:]
						# End of command history patch by Telion
						#print "\n405expansion mode="+repr(al)+"CB"+repr(self.currentBlockItems)+"<CT>="+codeText

						# Alias patch 2 by Telion
						cmd=string.split(codeText,' ')
						if cmd[0] == 'alias': # alias registration
							codeText=codeText[6:]
							if len(codeText)<3: # show  alias list
								print "\nAlias list"
								ak=self.alias.keys()
								ak.sort()
								for ali in ak:
									print ali+'='+repr(self.alias[ali])
							else: # register
								cmd=string.split(codeText,'=')
								cmd[0]=string.replace(cmd[0],' ','')
								if cmd[1][0]==' ':
									cmd[1]=cmd[1][1:]
								self.alias[cmd[0]]=cmd[1]
								print "\nAlias set:"+cmd[0]+"="+cmd[1]
							self.write(sys.ps1)
							ShowCaret(hWnd)
							return 0
						elif cmd[0] == 'unalias': # alias unregister
							try:
								print "\nRemoving alias:"+cmd1[1]
								del self.alias[cmd1[1]]
							except KeyError:
								print "No such alias"
							else:
								pass
							self.write(sys.ps1)
							ShowCaret(hWnd)
							return 0
						elif cmd[0] == 'help' or cmd[0]=='?': # shell help 
							hh="""
	'help' or '?' :=print this help 
	alias :=alias list
	alias xx=expanded :=set alias xx 
	unalias xx        :=unset alias xx
		note; initial alias list is loaded from '\pyalias'.
	!	:=history list
	!! :=last command
	!n :=nth command
	%command :=expand alias and/or history and let edit command line
		ex;	%!! :=edit last command line executed
		 	%!22 :=expanded 22th command for editing
	%%command :=No alias and/or history expansion\n
	"""
							self.write(hh+sys.ps1)
							ShowCaret(hWnd)
							return 0
						#elif cmd[0] == 'other': # put any other shell command
							#pass
						else:
							#print "\nexpansion mode="+repr(al)+"<CB>="+repr(self.currentBlockItems)
							if al < 0:
								#print "\nNoexpansion mode="+repr(self.currentBlockItems)
								pass
							else:
								pass
						# end of alias patch 2
						#print "\n460expansion mode="+repr(al)+"CB"+repr(self.currentBlockItems)+"<CT>="+codeText

						SetEvent(self.eventInteractiveInputAvailable)
			
			else:
				# Not in a block - write a new prompt.
				self.write("\n"+sys.ps1)

			ShowCaret(hWnd)
			return 0
			# end of return key processing
		#return CallWindowProc(self.oldEditWndProc, hWnd, msg, wparam, lparam)
		# ^this is not needed any more

	def OnParentSize(self, hwnd, msg, wparam, lparam):
		left, top, right, bottom = GetClientRect(hwnd)
		try:
			top=CommandBar_Height(self.hCmdBar);
		except NameError: # Only on CE
			pass
		if self.hwndEdit is not None:
#pypp 			SetWindowPos(self.hwndEdit, HWND_TOP, left, top, right-left, bottom-top, 0)
			SetWindowPos(self.hwndEdit, 0, left, top, right-left, bottom-top, 0)
#pypp 			ShowWindow(self.hwndEdit, SW_SHOWNORMAL)
			ShowWindow(self.hwndEdit, 1)

	def OnParentDestroy(self, hwnd, msg, wparam, lparam):
		PostQuitMessage(hwnd)
		# And tell the thread waiting for us we are done!
		SetEvent(self.eventClosed)

	def OnParentSetFocus(self, hwnd, msg, wparam, lparam):
		if self.hwndEdit is not None:
			SetFocus(self.hwndEdit)
	
	def OnParentUser(self, hwnd, msg, wparam, lparam):
		# Out write function post this message.
		# We dequeue the output, and write the text.
		while self.outputQueue:
			self.outputQueueLock.acquire()
#			text = string.join(self.outputQueue, '')
			try:
				text = string.join(self.outputQueue, '')
			except:
				for oQ in self.outputQueue:
					oQ = oQ.encode( Encoding)
				text = string.join(self.outputQueue, '')

			self.outputQueue = []
			self.outputQueueLock.release()
#pypp 			SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
			SendMessage(self.hwndEdit, 177, -2, -2)
			# Now check that we wont fill the control.
			# If so, remove the first lines until we are OK.
#pypp 			selInfo = SendMessage(self.hwndEdit, EM_GETSEL, 0, 0)
			selInfo = SendMessage(self.hwndEdit, 176, 0, 0)
#pypp 			endPos = HIWORD(selInfo)
			endPos = HIWORD(selInfo)
			lineLookIndex = 0
			lineLookLength = 0
			while endPos + len(text) - lineLookLength > 29000:
				lineLookIndex = lineLookIndex + 1
#pypp 				lineLookLength = SendMessage(self.hwndEdit, EM_LINEINDEX, lineLookIndex, 0)
				lineLookLength = SendMessage(self.hwndEdit, 187, lineLookIndex, 0)
			if lineLookIndex > 0:
				# The SETREDRAW has no effect on CE.  If we really want this
				# I think we must respond to WM_PAINT, and ignore it for the duration
				# the redraw is turned off.
#pypp 				SendMessage(self.hwndEdit, WM_SETREDRAW, 0, 0)
				SendMessage(self.hwndEdit, 11, 0, 0)
#pypp 				SendMessage(self.hwndEdit, EM_SETSEL, 0, lineLookLength)
				SendMessage(self.hwndEdit, 177, 0, lineLookLength)
#pypp 				SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(""))
				SendMessage(self.hwndEdit, 194, 0, TEXT(""))
				# And back to the end.
#pypp 				SendMessage(self.hwndEdit, EM_SETSEL, -2, -2)
				SendMessage(self.hwndEdit, 177, -2, -2)
#pypp 				SendMessage(self.hwndEdit, WM_SETREDRAW, 1, 0)
				SendMessage(self.hwndEdit, 11, 1, 0)
				
#pypp 			SendMessage(self.hwndEdit, EM_REPLACESEL, 0, TEXT(text))
			SendMessage(self.hwndEdit, 194, 0, TEXT(text))

	def OnParentCommand(self, hwnd, msg, wparam, lparam):
		command = LOWORD(wparam)
#pypp 		if command == IDM_EXIT:
		if command == 40001:
			DestroyWindow(hwnd);
#pypp 		elif command == IDM_ABOUT:
		elif command == 40002:
#pypp 			DialogBox(self.hinst, IDD_ABOUT, hwnd, AboutBoxDlgProc)
			DialogBox(self.hinst, 40002, hwnd, AboutBoxDlgProc)
		return 0

def AboutBoxDlgProc(hwnd, msg, wparam, lparam):
#pypp 	if msg==WM_COMMAND:
	if msg==273:
		p=LOWORD(wparam)
#pypp 		if p==IDOK or p==IDCANCEL:
		if p==1 or p==2:
			EndDialog(hwnd, 1)
		return 1
	return 0

def Interact(shell):
	global oldErr
	#oldErr.write("In Interact\n")
	#print "in Interact"
	shell.bInteract = 1
	# shell variable interface modification by Telion
	slocals = {} # modified from 'locals' to 'slocals'
	slocals['shell']=locals()['shell'] # This may be enough in most cases
	slocals['shell_locals']=locals().keys()
	slocals['shell_globals']=globals().keys()
	# slocals['shell_modules']=sys.modules # no need for this, since it's same
	# slocals['shell_vars']=vars()
	sys.stdout.write("Python %s on %s\n%s\n%s" % (sys.version, sys.platform, sys.copyright, sys.ps1))
	
	while 1:
#ignore INFINITE
		rc = WaitForMultipleObjects( (shell.eventInteractiveInputAvailable, shell.eventClosed), 0, INFINITE)
#ignore  WAIT_OBJECT_0
		if rc == WAIT_OBJECT_0:
			codeText = string.join(shell.currentBlockItems, '\n')
			# print "\nDebug="+repr(shell.currentBlockItems[0])
			try:
				codeOb = code.compile_command(codeText)
			except SyntaxError:
				sys.stdout.write("\n")
				list = traceback.print_exc(0)
				sys.stdout.write(sys.ps1)
				continue
			except:
				traceback.print_exc()
				continue

			if codeOb is None:
				sys.stdout.write("\n%s" % sys.ps2)
				continue
			sys.stdout.write("\n")

#pypp 			SetCursor(LoadCursor(0, IDC_WAIT))
			SetCursor(LoadCursor(0, 32514))
			try:
				try:
#					exec codeOb in slocals
					exec codeOb in slocals
				except SystemExit:
					break
				except:
					exc_type, exc_value, exc_traceback = sys.exc_info()
					l = len(traceback.extract_tb(sys.exc_traceback))
					try: 1/0
					except:
						m = len(traceback.extract_tb(sys.exc_traceback))
					traceback.print_exception(exc_type,
						exc_value, exc_traceback, l-m)
			finally:
				SetCursor(LoadCursor(0, 0))
				
			sys.stdout.write(sys.ps1)
		else:
			break

def RunCode(shell):
	#global oldErr
	#oldErr.write("In RunCode\n")

	try:
		# copy sys.argv before we stomp on it!
		sys.appargv = sys.argv[:]
		bKeepOpen = 0
		bInteract = 1
		cmdToExecute = None
		# Process sys.argv, removing args as we process them so any scripts
		# see _their_ argv!
		del sys.argv[0]
		# Remove some params the WCE debugger sometimes adds:
		sys.argv=filter(lambda arg: arg[:4]!="/WCE", sys.argv)
		i=0
		while i < len(sys.argv):
			if not sys.argv[i] or sys.argv[i][0]!='-':
				break
			if sys.argv[i]=='-i':
				bInteract = 1
				del sys.argv[i]
				continue
			elif sys.argv[i]=='-c':
				cmdToExecute = string.join(sys.argv[i+1:], ' ')
				sys.argv = sys.argv[:i-1]
				break
			i = i + 1
		
		if not sys.argv: sys.argv=['']

		if cmdToExecute is not None:
			try:
				exec cmdToExecute
			except:
				traceback.print_exc()
				bKeepOpen = 1
		elif len(sys.argv)>0 and sys.argv[0]:
			# Shift the args back to it sees itself as sys.argv[0]
			# Execute the named script
			fname = sys.argv[0]
			ext = os.path.splitext(fname)[1]
			if ext=='.pyc':
				mode="rb"
#ignore PY_COMPILED
				imp_params=("pyc", mode, imp.PY_COMPILED)
			else:
				mode="r"
#ignore PY_SOURCE
				imp_params=("py", mode, imp.PY_SOURCE)

			try:
				file = open(fname, mode)
			except IOError, (code, why):
				print "python: can't open %s: %s\n" % (fname, why)
				bKeepOpen = 1
				file = None
			if file:
				try:
					try:
						imp.load_module("__main__", file, fname, imp_params)
					except:
						traceback.print_exc()
						bKeepOpen = 1
				finally:
					file.close()
		else:
			bInteract = 1
		
		if bInteract:
			try:
				Interact(shell)
			except:
				traceback.print_exc()
				bKeepOpen = 1
	
		if not bKeepOpen:
#pypp 			PostThreadMessage(shellThreadId, WM_QUIT, 0, 0)
			PostThreadMessage(shellThreadId, 18, 0, 0)
	except:
		traceback.print_exc()
	
def main():
	# We run the shell in the main thread, so that when it terminates
	# (accidently or otherwise) the application terminates.
	# A seperate thread is used to execute the Python code.
	
	# Modification for cmd.exe of CE3.0
	# If first argv is '--' No ceshell
	import win32gui
	win32gui.NKDbgPrintfW('Debugging message') #dosen't work??
	
	if len(sys.argv) > 1 and sys.argv[1] == '--':
		f = open('\\python.log','wb')
		sys.stderr = f
		sys.stdout = f
		sys.stderr.write("Python %s on %s\n%s\n%s" % (sys.version, sys.platform, sys.copyright, sys.ps1))
		# print 'Python 1.5.2+ on CMD.EXE'
		print"\n"
		print sys.argv[0]+','+sys.argv[1]
		sys.argv = sys.argv[2:]
		print repr(sys.argv)
		if len(sys.argv) > 0:
			print sys.argv[0]
			if sys.argv[0] == '-c':
				cmdToExecute = string.join(sys.argv[1:], ' ')
				print 'CMD='+ cmdToExecute
				#sys.argv = sys.argv[:2]
				if cmdToExecute is not None:
					try:
						exec cmdToExecute
					except:
						traceback.print_exc()
						bKeepOpen = 1
			elif sys.argv[0] == '-h':
				print """usage python -- -c command :one liner
				-h :this help
				file args :python scripts"""
			else:
				fname = sys.argv[0]
				ext = os.path.splitext(fname)[1]
				if ext=='.pyc':
					mode="rb"
#ignore PY_COMPILED
					imp_params=("pyc", mode, imp.PY_COMPILED)
				else:
					mode="r"
#ignore PY_SOURCE
					imp_params=("py", mode, imp.PY_SOURCE)

				try:
					file = open(fname, mode)
				except IOError, (code, why):
					print "python: can't open %s: %s\n" % (fname, why)
					bKeepOpen = 1
					file = None
				if file:
					try:
						try:
							imp.load_module("__main__", file, fname, imp_params)
						except:
							traceback.print_exc()
							bKeepOpen = 1
					finally:
						file.close()

		f.close()
		return
	# End of Cmd.EXE mod
	
	#Oname = __name__
	__name__ = sys.argv[0] # ??? Why this?

	# Make "shell" global just for debugging purposes
	# ie, so interactive code can see it via __main__.shell (or "ceshell.shell" on CE)
	global shell #
	shell = SimpleShell()
	global shellThreadId
	shellThreadId = thread.get_ident()
	# Create the windows, but dont start the message loop yet.
	shell.Init()
	#print "shell.init() done"
	# Can now write to the shell - assign the standard files.
	global oldErr
	oldOut, oldErr, oldIn  = sys.stdout, sys.stderr, sys.stdin
	sys.stderr = shell
	#oldErr.write("stderr redirect done\n")
	sys.stdout = shell
	#oldErr.write("stdout redirect done\n")
	sys.stdin = shell
	#oldErr.write("stdin redirect done\n")
	#print "In the python window?"
	#oldErr.write("print test  done\n")
	if 0: # debug code
		#print "__name__ was :=",Oname
		#print "sys.argv :=",repr(sys,argv)
		#global dbg
		dbg=[]
		dbg.append("__name__","|",sys.argv)
	#oldErr.write("dbg\n")

	# Create the new thread to execute the code.
	thread.start_new(RunCode, (shell,) )
	#oldErr.write("thread Runcode\n")

	# Now run the shell.
	shell.Run()
	#oldErr.write("shell.Run() finished\n")

	shell.Term()

	sys.stdout = oldOut
	sys.stderr = oldErr
	sys.stdin = oldIn

# On Windows, run this as a script.
# On CE, this module is imported and main() executed by
# the startup C code.
if __name__=='__main__':
	main()
#pypp CONSTANTs not found:['UNICODE', 'WNDCLASS', 'TEXT', 'WS_OVERLAPPEDWINDOW', 'INFINITE', 'WAIT_OBJECT_0', 'HIWORD', 'LOWORD', 'PY_COMPILED', 'PY_SOURCE']
