#########################################################
##
## 2004/02/05
## test and begin import mypopmail and try to integrate
##
#########################################################



title = 'E-MAIL'

# Import Pmw from this directory tree.
import sys
from Tkinter import *
import Pmw

from mypopmail import mypopmail
from mysmtpmail import mysmtpmail
from config import *


class Demo(Toplevel):
    
    #def __init__( self,parent):
    def __init__( self,parent):
        print 'main__init__'
        withTabs = 1
        self.withTabs = withTabs
        print 'mail.__init()__'
        Toplevel.__init__( self,parent )
        self.title( "Mail" )
        self.geometry( "235x270" )  # width x length
        
        ##-------------------------------------------------------------
        
        self.filepath = picpath
        ## mailserver :: pop.163.com     
        ## mailuser   :: h_chakrit@163.com
        ## mailpaswd :: kritnum
        ## mailsavepath :: C:\PythonCE\userprofile\mail\
        ## mailfilename :: mail.txt
        ## 
        ##  setup mypopmail
        self.mypopmail = mypopmail()
        #print ' in mailgui '
        self.mailserver = self.mypopmail.getmailserver()
        self.mailuser   = self.mypopmail.getmailuser()
        self.mailpaswd = self.mypopmail.getmailpaswd()
        self.mailsavepath = self.mypopmail.getmailsavepath()
        self.mailfilename = self.mypopmail.getmailfilename()
        self.read = {}  # for store had read mail
        self.mail = {}  # for store current mail
        self.allmail = {} #for store all mail
        self.headermail = {} # stor  mail header ('From', 'Date', 'Subject')
        self.allheadermail = {} # stor all mail header ('From', 'Date', 'Subject')
        
        self.lst_mail = []#['Sydney', 'Melbourne', 'Brisbane','a12345678912345678912345679123456789123456789ppppppp','b','c','d','e','f','g','f','i'] # store list of mail in server  use for choose in list box
        
        ##-------------------------------------------------------------
        
        #self.mypopmail.connect()        # Default demo is to display a tabbed notebook.

        # Create a frame to put everything in
        self.mainframe = Frame(self)
        self.mainframe.pack(fill = 'both', expand = 1)
        
        # Create the notebook, but don't pack it yet.
        if self.withTabs:
            tabpos = 'n'
        else:
            tabpos = None
            
        self.notebook = Pmw.NoteBook(self.mainframe,tabpos = tabpos,
                #createcommand = PrintOne('Create'),
                #lowercommand = PrintOne('Lower'),
                #raisecommand = PrintOne('Raise'),
                hull_width = 300,
                hull_height = 200,
                )


        if not self.withTabs:
            # Create the selection widget to select the page in the notebook.
            self.optionmenu = Pmw.OptionMenu(self.mainframe,menubutton_width = 10,command = self.notebook.selectpage)
            self.optionmenu.pack(side = 'left', padx = 10)
        # Pack the notebook last so that the buttonbox does not disappear
        # when the window is made smaller.
        self.notebook.pack(fill = 'both', expand = 1, padx = 5, pady = 5)

        # Populate some pages of the notebook.
        #page1 = self.notebook.add('tmp')
        #self.notebook.delete('tmp')



# PAGR  1 CONECT SECTION

        self.page1 = self.notebook.add('Login')
        #if self.withTabs:
        self.notebook.tab('Login').focus_set()
        self.server = Frame(self.page1)
        self.username = Frame(self.page1)
        self.password = Frame(self.page1)
        #Addressbar
        self.lbl_srv = Label(self.server, name='address', text="Address:")
        self.nty_srv = Entry(self.server, name='server', width=25 )
        self.nty_srv.insert( INSERT,self.mypopmail.getmailserver())
        self.lbl_usn = Label(self.username,text="User Name:")
        self.nty_usn =Entry(self.username,width=25)
        self.nty_usn.insert( INSERT,self.mypopmail.getmailuser())
        self.lbl_pss = Label(self.password,text="Password:")
        self.nty_pss = Entry(self.password,width=25)#show='*'
        self.nty_pss.insert( INSERT, self.mypopmail.getmailpaswd())
        self.lbl_srv.pack(side =LEFT) #-----
        self.nty_srv.pack(side=LEFT)
        self.server.pack()
        self.lbl_usn.pack(side =LEFT) #-----
        self.nty_usn.pack(side=LEFT)
        self.username.pack()
        self.lbl_pss.pack(side =LEFT) #----
        self.nty_pss.pack(side=LEFT)
        self.password.pack()
        # retrive mail
        self.frm_retrive = Frame(self.page1)
        self.btn_chk = Button(self.frm_retrive,text="Check mail",border="1",command=self.checkemail)
        self.btn_chk.pack(side=LEFT)
        self.frm_retrive.pack(padx=2,pady=2)
        # show retrive mail
        self.frm_mail = Frame(self.page1)
        self.frm_mail.pack( side=TOP,pady = 2 )
        self.lib_showmail = Pmw.ScrolledListBox(self.frm_mail,items =self.lst_mail,vscrollmode='dynamic',dblclickcommand=self.viewmail, usehullsize = 1,hull_width = 200,hull_height = 200)#,selectioncommand = self.loadfile  static
        self.lib_showmail.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=2)#,listbox_height = 4


# PAGE 2 SEND

        self.page2 = self.notebook.add('Mail')
        #Addressbar
        self.to = Frame(self.page2)
        self.fromentry=Frame(self.page2)
        
        self.lbl_frm = Label(self.fromentry,text="From:")
        self.lbl_frm.pack(side =LEFT)
        self.nty_frm = Entry(self.fromentry,width=25)
        self.nty_frm.pack(side=LEFT)
        self.fromentry.pack()
        
        self.lbl_to_dte_TEXT = StringVar()
        self.lbl_to_dte = Label(self.to,textvariable=self.lbl_to_dte_TEXT)
        self.lbl_to_dte_TEXT.set("To:")
        self.lbl_to_dte.pack(side =LEFT)
        self.nty_to_dte = Entry(self.to,width=25)
        self.nty_to_dte.pack(side=LEFT)
        self.to.pack()

        self.subject=Frame(self.page2)
        self.lbl_suj = Label(self.subject,text="Subject:")
        self.lbl_suj.pack(side =LEFT)
        self.nty_suj = Entry(self.subject,width=25)#,show='*'
        self.nty_suj.pack(side=LEFT)
        self.subject.pack()
        
        #Actionbar
        self.action=Frame(self.page2)
        self.btn_frd = Button(self.action,text="Forward",border="1",command=self.forwardsendmail)
        self.btn_frd.pack(side=LEFT,padx=1)
        self.btn_sve = Button(self.action,text="Save",border="1",command=self.savemail)
        self.btn_sve.pack(side=LEFT,padx=1)
        self.btn_dlt = Button(self.action,text="Delete",border="1",command=self.deletemail)
        self.btn_dlt.pack(side=LEFT,padx=1)
        self.btn_clr = Button(self.action,text="Clear",border="1",command=self.clearmail)
        self.btn_clr.pack(side=LEFT,padx=1)
        self.action.pack(pady = "1")
        
        #Writearea
        self.writearea = Frame(self.page2)
        self.writearea.pack(fill=BOTH, expand=YES)
        
        
        fixedFont = Pmw.logicalfont('Fixed')
        self.tbx_write = Pmw.ScrolledText(self.writearea,
                #borderframe = 1,
                #labelpos = 'n',
                #label_text='ScrolledText with headers',
                #columnheader = 1,
                #rowheader = 1,
                #rowcolumnheader = 1,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none',
                #text_font = fixedFont,
                #Header_font = fixedFont,
                #Header_foreground = 'blue',
                #rowheader_width = 3,
                #rowcolumnheader_width = 3,
                #text_padx = 2,
                #text_pady = 2,
                #Header_padx = 4,
                #rowheader_pady = 4,
        )
        self.tbx_write.tag_configure('yellow', background = 'yellow')
        self.tbx_write.pack(padx = 1, pady = 1, fill = 'both', expand = 1)
        #appendtext(text)  clear()

        
        #self.tbx_write = Text(self.writearea)
        #self.tbx_write.config(foreground="blue")
        #self.tbx_write.config(background="yellow", foreground="red")
        #self.tbx_write.config(wrap="none")# none, char, word
        #self.rightScrollbar = Scrollbar(self.writearea, orient=VERTICAL, command=self.tbx_write.yview)
        #self.bottomScrollbar = Scrollbar(self.writearea, orient=HORIZONTAL, command=self.tbx_write.xview)
        #self.tbx_write.configure(yscrollcommand = self.rightScrollbar.set)
        #self.tbx_write.configure(xscrollcommand = self.bottomScrollbar.set)
        #self.bottomScrollbar.pack(side=BOTTOM, fill = X)
        #self.rightScrollbar.pack(side=RIGHT, fill = Y)
        #self.tbx_write.pack(side=LEFT, padx="1m", pady="1m", expand=YES, fill=BOTH)

        # frame 5 stor a Entry that show FTP Message
        self.frm_stu = Frame(self.page2)
        #self.frm_stu.pack(side=BOTTOM,pady = 0,fill=X)
        self.lbl_stu = Label(self.frm_stu,text="",bd=1,relief=SUNKEN,anchor=W)
        #self.lbl_stu.pack(side = BOTTOM,fill = X)

        
        self._messagebar2 = Pmw.MessageBar(self.frm_stu,
                entry_width = 35,
                entry_relief='groove',
                labelpos = 'w',
                label_text = 'Status:')
        self._messagebar2.pack(side = 'bottom', fill = 'x',expand = 1, padx = 1, pady = 1)
        self.frm_stu.pack(side = BOTTOM,fill = X)



        #self.page3 = self.notebook.insert('Applications', before = 'Send')#
        self.page3 = self.notebook.add('sa')
        self.button3 = Button(self.page3, text = 'This is the Applications page')
        self.button3.pack(expand = 1)



        # Initialise the first page and the initial colour.
        if not self.withTabs:
            self.optionmenu.setitems(self.notebook.pagenames())
        self.pageCounter = 0

    def showsmailtatus2(self,type,message):
        ##(priority, showtime, bells, logmessage)
        ##'systemerror'  : (5, 10, 2, 1),
        ##'usererror'    : (4, 5, 1, 0),
        ##'busy'         : (3, 0, 0, 0),
        ##'systemevent'  : (2, 5, 0, 0),
        ##'userevent'    : (2, 5, 0, 0),
        ##'help'         : (1, 5, 0, 0),
        ##'state'        : (0, 0, 0, 0),
        print 'input:'+message
        self._messagebar2.message(type,message)

    def changecolor(self):
        print 'changecolor()'

    def viewmail(self):
        print 'viewmail()'
        sels = self.lib_showmail.getcurselection()
        if len(sels) == 0:
            print 'No selection for double click'
        else:
            print 'Double click 0:', sels[0]
            self.mailindex = self.lst_mail.index(sels[0])
            print 'select mail index:',self.mailindex
            self.setmail(self.mailindex)

    def setmail(self,mailindex):
        print 'setmail()'
        self.mailindex = mailindex
        self.mail = self.mypopmail.allmail[self.mailindex]
        #print self.mail
        #('From', 'Date', 'Subject','data')
        self.clearmail()
        self.btn_frd.config(text='Forward') # set text of label and button 
        self.lbl_to_dte_TEXT.set("Date:")
        self.nty_to_dte.insert( INSERT,self.mail['Date']) # insert data to form
        self.nty_frm.insert( INSERT,self.mail['From'])
        self.nty_suj.insert( INSERT,self.mail['Subject'])
        self.tbx_write.appendtext(self.mail['data'])  #clear()
        self.notebook.tab('Mail').focus_set()

    def clearmail(self):
        '''delde text in date ,from,subject, write_text'''
        self.nty_to_dte.delete(0,END)
        self.nty_frm.delete(0,END)
        self.clear()
        
    def clear(self):
        '''delde text in date ,from'''
        self.nty_suj.delete(0,END)
        #self.tbx_write.delete(1.0,END) # for Tkinter Text
        self.tbx_write.clear()  # for Pmw.ScrolledText
        
    def checkemail(self):
        print 'checkmail()'
        self.mypopmail.setmailserver(self.nty_srv.get())
        self.mypopmail.setmailuser(self.nty_usn.get())
        self.mypopmail.setmailpaswd(self.nty_pss.get())
        self.mypopmail.connect()
        #print self.mypopmail.getstatus()
        self.mypopmail.loadallmail()
        #print '!'*80
        #print self.mypopmail.allheadermail
        #print '!'*80
        for key in self.mypopmail.allheadermail.keys():
            self.headermail[key]=self.mypopmail.allheadermail[key]['Subject']
            print self.headermail[key]
        self.lst_mail=self.headermail.values()
        self.lib_showmail.setlist(self.lst_mail)

 

    def forwardsendmail(self):
        print 'forwardmail'
        #self.lbl_to_dte_TEXT.set("To:")
        configvalue = self.btn_frd.config('text')
        print configvalue
        if 'Forward' in configvalue:
            print 'Forward'
            self.btn_frd.config(text='Send')
            self.lbl_to_dte_TEXT.set("To:")
            self.clearmail()
            self.tbx_write.appendtext('From:'+self.mail['From']+'\nDate:'+self.mail['Date']+'\nSubject:'+self.mail['Subject']+'\nData:\n'+'-----------------'+self.mail['data']+'------------------')  #clear()
            self.nty_frm.insert( INSERT,self.mypopmail.getmailuser())
        else:
            print 'Send'
            self.btn_frd.config(text='Forward')
            self.lbl_to_dte_TEXT.set("Date:")
            #mysmtpmail(From,To,Subj,Data)
            smtp=mysmtpmail(self.nty_frm.get(),self.nty_to_dte.get(),self.nty_suj.get(),self.tbx_write.get())
            c = smtp.send()
            if c==1:
                self.showsmailtatus2('help','Succeed to send mail')
            else:
                self.showsmailtatus2('busy','Failed to send mail')
        
    def savemail(self):
        print 'savemail'
        
    def deletemail(self):
        print 'deletemail'
        

######################################################################

#root = Tk()
#Pmw.initialise(root)
#root.title(title)

#widget = Demo(root)

#exitButton = Button(root, text = 'Exit', command = root.destroy)
#exitButton.pack()
#root.mainloop()
