from Tkinter import *
import os

class Dialog(Toplevel):

    def __init__(self, parent):

        Toplevel.__init__(self, parent)
        self.transient(parent)

        self.title("test")

        self.parent = parent

        self.result = None

        #self.body = Frame(self)
        
        #self.body.pack(padx=5, pady=5)


        #self.buttonbox()
        
        self.box = Frame(self)
        self.w = Button(self.box, text="OK", width=10, command=self.ok, default=ACTIVE)
        self.w.pack(side=LEFT, padx=5, pady=5)
        #self.initial_focus = self.box
        
        self.grab_set()

        if not self.initial_focus:
            self.initial_focus = self

        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.geometry("+%d+%d" % (parent.winfo_rootx()+235,parent.winfo_rooty()+242))

        self.initial_focus.focus_set()

        self.wait_window(self)


        

    def ok():
        print 'temp ok command'

    def cancel(self, event=None):
# put focus back to the parent window
        self.parent.focus_set()
        self.destroy()        


#
'''

# construction hooks

def body(self, master):
# create dialog body. return widget that should have
# initial focus. this method should be overridden
    pass

def buttonbox(self):
# add standard button box. override if you don't want the
# standard buttons
    box = Frame(self)
    w = Button(box, text="OK", width=10, command=self.ok, default=ACTIVE)
    w.pack(side=LEFT, padx=5, pady=5)
    w = Button(box, text="Cancel", width=10, command=self.cancel)
    w.pack(side=LEFT, padx=5, pady=5)

    self.bind("&lt;Return>", self.ok)
    self.bind("&lt;Escape>", self.cancel)

    box.pack()
#
# standard button semantics
def ok(self, event=None):
    if not self.validate():
        self.initial_focus.focus_set() # put focus back
        return

    self.withdraw()
    self.update_idletasks()

    self.apply()

    self.cancel()

def cancel(self, event=None):
# put focus back to the parent window
    self.parent.focus_set()
    self.destroy()
#
# command hooks
def validate(self):

    return 1 # override

def apply(self):
    pass # override  '''