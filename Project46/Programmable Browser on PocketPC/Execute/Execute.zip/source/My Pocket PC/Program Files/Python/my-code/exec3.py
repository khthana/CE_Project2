# test exec1 function
#
# modify from exec1.py
# modify on 2004-02-03 chang ( exec code in dict ) to ( exec code in mylocals )
# defind locals in a buildin dictionary from the interpreter ( the same variable domain
# with interpreter
# use this locals dictionary must to modify pcceshell.py <in python/lib>
# with this code in pcceshell.py
# add this line (locals["mylocals"]=locals) in (def Interact(shell):) after this line (locals = {})

import sys
import traceback
import string

import Pmw

from Tkinter import *
from tkMessageBox import *

class E( Frame ):
   """Demonstrate Entrys and Event binding"""

   
   #self.exedata = ""
   
   def __init__( self,mylocals ):
      """Create, pack and bind events to four Entrys"""
      self.mylocals =mylocals
      
      
      Frame.__init__( self )
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Testing exec function" )
      self.master.geometry( "235x242" )  # width x length

      self.frame1 = Frame( self )
      self.frame1.pack( pady = 5 )
      
      #self.in_txt = Text( self.frame1, name = "in_txt" ,row=6,size=20)
      #self.in_txt.bind( "<Return>", self.showContents )
      #self.in_txt.pack( side = LEFT, padx = 3 )

      self.in_txt = Pmw.ScrolledText( self.frame1,text_width = 25, text_height = 6, text_wrap = WORD,hscrollmode = "static", vscrollmode = "static" )
      self.in_txt.pack( side = LEFT, expand = YES, fill = BOTH, padx = 5, pady = 5 )      
      
      #self.in_txt = Pmw.ScrolledListBox(self.frame1,
      #   items =self.listfile,vscrollmode='static',listbox_height = 4,dblclickcommand=self.loadfile,)#,selectioncommand = self.loadfile
      #self.in_txt.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=2)


      self.frame2 = Frame( self )
      self.frame2.pack( pady = 5 )
      
      self.text3 = Entry( self.frame2, name = "text3" )
      self.text3.bind( "<Return>", self.showContents )
      self.text3.pack( side = LEFT, padx = 3 )

  
      self.frame3 = Frame( self )
      self.frame3.pack( pady = 5 )
      
      self.button2=Button( self.frame3, name = "exec", text='exec', command=self.myexec)
      self.button2.pack(side = LEFT, padx = 3)
      
      self.button1=Button( self.frame3, name = "read", text='read', command=self.settext)
      self.button1.pack(side = LEFT, padx = 3)

   def test(self,te):
      print te

   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(self.mylocals[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def myexec(self):
      self.exedata = self.in_txt.get()
      exec_(self,self.exedata)
      #exec theContents
      
   def showContents( self, event ):
      """Display the contents of the Entry"""
      
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      
      #self.text3.insert( INSERT, u )


def exec_(self,exedata):
   """ input a  exedata # stang format  and pass to exec()  function """
   try:
      try:
         #exedata = '''a=[10,20,30,40,50]
         #t=30'''
         exec exedata in self.mylocals
         print 'Exec OK \n'
      except SystemExit:
         raise
      except:
         exc_type, exc_value, exc_traceback = sys.exc_info()
         l = len(traceback.extract_tb(sys.exc_traceback))
         print 'l :'+ str(l) +'\n'
         try:
            1/0
         except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
   finally:
      print 'End exec'





global tt
tt = 99
global dict
dict = {}

#def main():
   #E().mainloop()



#main()
