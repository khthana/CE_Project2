def getContentFile(filename) :
	file = open(filename, 'r')
	content = file.read()
	file.close()
	keyword = ['Last Trade', 'Change', 'Open', 'Previous', 'Average', 'Day\'s Range', 'Bid', 'Volume', 'Market Capital']
	#scanBids(content)
	bidsdata = scanBids(keyword, content)
	allbidsdata = ''
	for i in range(len(keyword)) :
		allbidsdata = allbidsdata + keyword[i] + ' : ' + bidsdata[i] + "\n"
	return allbidsdata

def scanBids(keyword, content) :
	#keyword = ['Last Trade', 'Change', 'Open', 'Previous', 'Average', 'Day\'s Range', 'Bid', 'Volume', 'Market Capital']
	eachdata = []
	for key in keyword :
		index = content.find(key)
		content = content[index+len(key):]
		intag = 0
		data = ''
		for char in content :
			if (char=='<') and (data == '') : intag = intag + 1
			elif (char=='<') and (data != '') : break
			elif (char=='>') and (data == '') : intag = intag-1
			elif (intag==0) and ((char!= "\t") and (char != " ")) : 
				data = data + char
		eachdata.append(data)
	#print 'Eachdata : ',eachdata
	return eachdata

#file = 'test.html'
#text = getContentFile(file)
#print text
		
				
	
