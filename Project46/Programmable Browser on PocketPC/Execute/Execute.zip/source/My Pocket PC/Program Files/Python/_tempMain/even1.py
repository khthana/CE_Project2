# Fig. 10.6: fig10_06.py
# Entry components and event binding demonstration.

import sys
import traceback
import string
import thread

import time
import threading

from Tkinter import *
from tkMessageBox import *

from Time3 import myTime
#from evenThread import CheckEvenThread

class CheckEvenThread( threading.Thread ):
   """Subclass of threading.Thread"""

   def __init__( self, threadName='defaulde' ,isleepTime=5,intk = None ):
      """Initialize thread, set sleep time, print data"""
      
      threading.Thread.__init__( self, name = threadName )
      self.sleepTime = isleepTime #5 #random.randrange( 1, 6 )
      print "Name: %s; sleep: %d" % \
            ( self.getName(), self.sleepTime )
      self.count = 0
      self.eventList=[]
      self.tk = intk
      self.checkEvent = TRUE

   # overridden Thread run method
   def run( self ):
      """Sleep for 1 seconds"""
      
      while self.count<500:
           
         #mtime = myTime(self.li[3],self.li[4],self.li[5])  #hour=10,minute=11,second=12
         #if self.checkEvent:
         self.getCurrentTime()
         self.tk.setClock(self.__hour,self.__minute,self.__second)
            
         self.count = self.count+1
         #time.sleep( self.sleepTime )
         time.sleep( 1 )
         
         #print "%s going to sleep for %s second(s) loop %s number" % \
         #   ( self.getName(), self.sleepTime ,self.count)
         #print self.getName(), "done sleeping"


   def add( self,event ):
      self.eventList.append(event)

   def getCurrentTime(self):
      # setup my time to current
      self.li = time.localtime(time.time())
      self.__hour = self.li[3]
      self.__minute = self.li[4]
      self.__second = self.li[5]

   def testTime(self, h, m, s):
      ''' test ,  is in put time  valid '''
      if h > 24: return False
      if m > 60: return False
      if s > 60: return False
      return True
      
   def comPare( self, h, m, s):
      
      #print str(self.__hour)+' '+str(h)+' / '+str(self.__minute)+' '+str(m)+' / '+str(self.__second)+' '+str(s)
#if self.testTime(h,m,s)==True:
      if self.__hour > h:
         #print 'pass h'
         return False
      else:
         if self.__minute > m:
            #print 'pass m'
            return False
         else:         
            if self.__second > s:
               #print 'pass s'
               return False
      #print 'return true'
      return True

   def setCheckEvent( self, value):
      self.checkEvent = value
   
      

   def printEven( self ):
      self.getCurrentTime()
      self.tk.textBox.delete('1.0', END)
      for event  in self.eventList:
         if self.tk != None :
            hour1 = event.getHour()
            minute1 = event.getMinute()
            second1 = event.getSecond()
            thisEvent1 = event.getEvent()
            temp=':<'
            if self.comPare(hour1,minute1,second1):
               temp=':)'
            #print thisEvent + '-> '+':'+hour+':'+minute+':'+second
            
            temp = temp +' '+ thisEvent1 + '  '+str(hour1)+':'+str(minute1)+':'+str(second1)+'\n'
            
            self.tk.textBox.insert( INSERT , temp)
         else:
            print ' OH NO MY GOD'

class E( Frame ):  #
   """Demonstrate Entrys and Event binding"""

   
   #self.exedata = ""
   
   def __init__(self):
      """Create, pack and bind events to four Entrys"""
      Frame.__init__(self)
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Testing exec function" )
      self.master.geometry( "235x242" )  # width x length

      self.frame1 = Frame( self )
      self.frame1.pack( pady = 5 )
      
      self.text1 = Entry( self.frame1, name = "text1" )
      self.text1.bind( "<Return>", self.showContents )
      self.text1.pack( side = LEFT, padx = 3 )

      self.frame2 = Frame( self )
      self.frame2.pack( pady = 5 )

      self.lbl_clock = Label(self.frame2,text='0')
      self.lbl_clock.pack()
      
      self.text3 = Entry( self.frame2, name = "text3" )
      self.text3.bind( "<Return>", self.showContents )
      self.text3.pack( side = LEFT, padx = 3 )

  
      self.frame3 = Frame( self )
      self.frame3.pack( pady = 5 )
      
      self.button2=Button( self.frame3, name = "add", text='add', command=self.addEvent)
      self.button2.pack(side = LEFT, padx = 3)
      
      self.button1=Button( self.frame3, name = "build", text='build', command=self.buildClock)
      #self.button1=Button( self.frame3, name = "read", text='read', command=self.readEvent)
      self.button1.pack(side = LEFT, padx = 3)

      self.button3=Button( self.frame3, name = "print", text='print', command=self.readEvent)
      #self.button1=Button( self.frame3, name = "read", text='read', command=self.readEvent)
      self.button3.pack(side = LEFT, padx = 3)      


      #lstB_h = Listbox(self.frame3)
      self.frame4 = Frame( self )
      self.frame4.pack( pady = 5 )

      self.lbl_hour = Label(self.frame4,text='Hour')
      self.lbl_hour.pack(side = LEFT)
      self.txt_hour = Entry(self.frame4,name = 'inputHour',width=3)
      self.txt_hour.insert(INSERT, '*')
      self.txt_hour.pack(side = LEFT)

      self.lbl_min = Label(self.frame4,text='Minute')
      self.lbl_min.pack(side = LEFT)      
      self.txt_min = Entry(self.frame4,name = 'inputMin', width=3)
      self.txt_min.insert( INSERT, '*')
      self.txt_min.pack(side = LEFT)

      self.lbl_sec = Label(self.frame4,text='Second')
      self.lbl_sec.pack(side = LEFT)        
      self.txt_sec = Entry(self.frame4,name = 'inputSecond',width=3)
      self.txt_sec.insert( INSERT, '*')
      self.txt_sec.pack(side = LEFT)
      
      



      

      #lstB_h = Listbox(self.frame3)
      self.frame5 = Frame( self )
      self.frame5.pack( pady = 5 )
      
      self.textBox = Text(self.frame5,width=15,height=5)
      self.textBox.pack()
      

      ##########################################
      ## CheckEvenThread
      ##########################################
      #self.checkEvenThread = CheckEvenThread( threadName='defaulde' , intk=self, isleepTime=5)
      #self.checkEvenThread.start()

   def buildClock(self):
      self.li = time.localtime(time.time())   
      mtime = myTime(self.li[3],self.li[4],self.li[5])  #hour=10,minute=11,second=12
      #self.te = mtime.getHour()
      #self.text3.insert( INSERT, self.te ) #str(te)
      self.txt_hour.delete(0, END)
      self.txt_min.delete(0, END)
      self.txt_sec.delete(0, END)
      
      self.txt_hour.insert( INSERT, self.li[3])
      self.txt_min.insert( INSERT, self.li[4])
      self.txt_sec.insert( INSERT, self.li[5])
      
      self.buildThread()
      
   def buildThread( self ):
      self.checkEvenThread = CheckEvenThread( threadName='defaulde' , intk=self, isleepTime=15)
      self.checkEvenThread.start()

      
      
   def setClock(self,hour,min,second):
      temp=str(hour)+':'+str(min)+':'+str(second)
      self.lbl_clock.config(text=temp)
   
   def addEvent( self ):
      ''' add Event to CheckEnevtList '''
      #self.txt_hour.insert( INSERT, self.li[3])
      #self.txt_min.insert( INSERT, self.li[4])
      #self.txt_sec.insert( INSERT, self.li[5])
      newEvent = myTime(int(self.txt_hour.get()),int(self.txt_min.get()),int(self.txt_sec.get()),' ')
      self.checkEvenThread.add(newEvent)

   def readEvent( self ):
      self.checkEvenThread.printEven()
      
                          
   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(dict[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def myexec(self):
      self.exedata = self.text1.get()
      exec_(self,self.exedata)
      #exec theContents
      
   def showContents( self, event ):
      """Display the contents of the Entry"""
      
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      
      #self.text3.insert( INSERT, u )


def exec_(self,exedata):
   """ input a  exedata # stang format  and pass to exec()  function """
   try:
      try:
         #exedata = '''a=[10,20,30,40,50]
         #t=30'''
         exec exedata in dict
         print 'Exec OK \n'
      except SystemExit:
         raise
      except:
         exc_type, exc_value, exc_traceback = sys.exc_info()
         l = len(traceback.extract_tb(sys.exc_traceback))
         print 'l :'+ str(l) +'\n'
         try:
            1/0
         except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
   finally:
      print 'End exec'





global tt
tt = 99
global dict
dict = {}

def main():


   #checkEven = CheckEvenThread('text frist thread',10)
   #checkEven.start()
   #ch = CheckEvenThread( "thread1" ,5)
   #ch.start()
   #checkEven2 = CheckEvenThread('text frist thread',7)
   #checkEven2.start()
   
   E().mainloop()


main()














