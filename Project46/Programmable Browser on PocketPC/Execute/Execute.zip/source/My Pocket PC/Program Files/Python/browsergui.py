'''
browsergui.py
Design GUI by Cherdkiat Saetae
Code Module by Chakrit Hengsirikul
* import class myweb in myweb.py (this is base class)
2004/03/09
final test all work
2004/03/15
add DEFAULT_HOME at home()
print correctly
---------------------------

'''

from Tkinter import *
import Pmw
from tkMessageBox import *

from config import *
from getuserprofile import getuserprofile
from myweb import myweb


global SELECT_FAVOURIT_FROM_OPENFILE
SELECT_FAVOURIT_FROM_OPENFILE = ''
global FAVOURIT_MODE  ##this value  tell what user do in filedialog (Toplevel)
FAVOURIT_MODE = 'OPEN'  # OPEN , ADD

global FAVOURIT_URL
FAVOURIT_URL=''
global DEFAULT_HOME
DEFAULT_HOME = 'www.ce.kmitl.ac.th'
global favotites
favotites  = {}
global upf
upf=getuserprofile()
upf.getuserpf('web.profile',favotites)
if not favotites.has_key('home'):
    favotites['home'] = DEFAULT_HOME
    upf.getuserpf('web.profile',favotites)


##############################################################################
##  class open file

class filedialog(Toplevel):
   """Demonstrate Entrys and Event binding"""

   def __init__(self,parent,favourit_url,mycolor,select_color_number):
        """Create, pack and bind events to four Entrys"""
        Toplevel.__init__( self,parent )
        self.title( 'Favorites' )
        self.geometry( "200x180" )  # width x length
        
        self.transient()
        self.parent = parent
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        
        self.favourit_url = favourit_url
        global favotites
       
        #--  frame1  stor input uri of ftp
        self.frame2 = Frame( self )
        self.lbl_name = Label(self.frame2,text='name')
        self.lbl_name.pack(side = LEFT,pady = 0)
        self.nty_name = Entry(self.frame2,width=18)
        self.nty_name.pack(side=LEFT)
        self.frame2.pack( side=TOP,pady = 1,padx=0)
        
        self.frame3 = Frame( self )
        self.lbl_address = Label(self.frame3,text='address')
        self.lbl_address.pack(side = LEFT,pady = 0)
        self.nty_address = Entry(self.frame3,width=18)
        self.nty_address.pack(side=LEFT)
        self.nty_address.insert(INSERT,self.favourit_url)
        
        self.btn_add = Button(self.frame3,text='add',command=self.add)
        self.btn_add.pack(side = LEFT, pady = 3, padx = 2)
        self.frame3.pack( side=TOP,pady = 1,padx=0)


        # frame 4 stor  list box for show server file
        self.frame4 = Frame( self )
        self.lib_showfile = Pmw.ScrolledListBox(self.frame4,
                                                items = favotites.keys(),
                                                vscrollmode='dynamic',
                                                listbox_height = 6,
                                                dblclickcommand=self.action,    )#,selectioncommand = self.loadfile
        self.lib_showfile.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=0)
        self.frame4.pack(  side=TOP,pady = 0 ,padx=0,expand = YES, fill = BOTH)
        
        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)


   def add(self):
        #print 'add()'
        global favotites
        address = self.nty_address.get().strip()
        name = self.nty_name.get().strip()
        #print 'add',address,name
        if not(address=='' or name==''):
            if favotites.has_key(name):
                self.cantlogin = showinfo("Message","Can't Add same name")
            else:
                favotites[name]=address
                self.lib_showfile.setlist(favotites.keys())
                self.nty_name.delete(0,END)
                self.nty_address.delete(0,END)
                global upf
                #print favotites
                t_dict={}
                for key in favotites.keys():
                    t_dict[key]=favotites[key]
                upf.saveuserpf('web.profile',t_dict)
        else:
            self.cantlogin = showinfo("Message","Can't Add")


   def action(self):
        #print 'action()'
        global SELECT_FAVOURIT_FROM_OPENFILE
        global favotites
        if len(favotites)>0:
            chosen=self.lib_showfile.curselection()
            temp_list = favotites.keys()
            SELECT_FAVOURIT_FROM_OPENFILE = temp_list[int(chosen[0])]
            self.destroy()
        else:
            print 'Select file name'
            
##-------------------------------------------------------------
   def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                            background = clr['background'],
                            foreground = clr['foreground'],
                            activeForeground = clr['activeForeground'],
                            insertBackground = clr['insertBackground'],
                            selectForeground = clr['selectForeground'],
                            highlightColor = clr['highlightColor'],
                            disabledForeground = clr['disabledForeground'],
                            highlightBackground = clr['highlightBackground'],
                            activeBackground = clr['activeBackground'],
                            selectBackground = clr['selectBackground'],
                            troughColor = clr['troughColor'],
                            selectColor = clr['selectColor']       )
        

######################################################################333######################################################################333
####################################################################################################################################################
######################################################################333##########################################################################
        
        
class browser(Toplevel):
    def __init__( self,parent,mycolor,select_color_number):
        Toplevel.__init__( self,parent )
        self.title( "PWBCE Browser" )
        self.geometry( "235x270" )
        self.filepath = picpath
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        
        global favotites
        
        
        print 'Open Browser()'

        #home :: http://www.ce.kmitl.ac.th
        #google :: http://www.google.co.th
        #cknum :: http://cknum.hypermart.net/index4.html
        self.myweb = myweb()
        self.webcontent = []
        self.webaddress = []
        self.currentpage = 0
        


        self.MAX_TEMP_PAGE = 10  ## if NUMBER_CLEAR > MAX_TEMP_PAGE 
        self.NUMBER_CLEAR = 4    ## will clear all temp page in self.webcontent
       
#toolbar
        self.toolbar = Frame(self,relief=RIDGE,border='3')
        
        self.myImage0 = PhotoImage( file = self.filepath + "backbut.gif" )
        self.b_back = Button(self.toolbar, image = self.myImage0,border="0", command = self.back)
        self.b_back.pack(side=LEFT)
        
        self.myImage1 = PhotoImage( file = self.filepath + "nextbut.gif" )
        self.b_next = Button(self.toolbar,image = self.myImage1,border="0", command = self.next)
        self.b_next.pack(side=LEFT)
        
        self.myImage2 = PhotoImage( file = self.filepath + "stopbut.gif" )
        self.b_stop = Button(self.toolbar,image = self.myImage2,border="0")
        self.b_stop.pack(side=LEFT)
        
        self.myImage3 = PhotoImage( file = self.filepath + "refreshbut.gif" )
        self.b_refresh = Button(self.toolbar, image = self.myImage3,border="0", command = self.refresh)
        self.b_refresh.pack(side=LEFT)
        
        self.myImage4 = PhotoImage( file = self.filepath + "homebut.gif" )
        self.b_home = Button(self.toolbar, image = self.myImage4, border="0", command = self.home)
        self.b_home.pack(side=LEFT)
        
        self.myImage6 = PhotoImage( file = self.filepath + "favourbut.GIF" )
        self.b_favour = Button(self.toolbar, image = self.myImage6,border="0",command = self.favourit)
        self.b_favour.pack(side=LEFT)
        
        self.toolbar.pack(side=TOP, fill=X)

#Addressbar
        self.addressbar = Frame(self)
        Label(self.addressbar,text="Address").pack(side =LEFT)
        self.txt_add = Entry(self.addressbar,width=27)
        self.txt_add.pack(side=LEFT,expand=YES,fill=X)
        self.txt_add.insert( INSERT,favotites['home'])
        
        self.myImage5 = PhotoImage( file = self.filepath + "gobut.gif" )
        self.btn_go = Button(self.addressbar, image = self.myImage5,border="1", command = self.go)
        self.btn_go.pack(side=RIGHT)
        self.addressbar.pack()

#Display
        self.frame4 = Frame( self )
        self.frame4.pack(side=TOP,expand =YES,fill = BOTH)        
        #self.lib_showfile = Pmw.Pmw.ScrolledText(self.frame4,vscrollmode='static',hscrollmode='dynamic')
        self.lib_showfile = Pmw.ScrolledText(self.frame4,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none',
        )
        self.lib_showfile.pack( side = LEFT,expand =YES,fill=BOTH)

        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)


##-------------------------------------------------------------

    def favourit(self):
        #print 'favourbut()'
        global SELECT_FAVOURIT_FROM_OPENFILE
        global favotites
        dialogcript = filedialog(self,self.txt_add.get(),self.mycolor,self.SELECT_COLOR_NUMBER)
        self.wait_window(dialogcript)
        print 'SELECT_FAVOURIT_FROM_OPENFILE',SELECT_FAVOURIT_FROM_OPENFILE
        if favotites.has_key(SELECT_FAVOURIT_FROM_OPENFILE):
            self.txt_add.delete(0,END)
            self.txt_add.insert(INSERT,favotites[SELECT_FAVOURIT_FROM_OPENFILE])

        
    def home(self):
        global favotites
        global DEFAULT_HOME
        if not favotites.has_key('home'):
            favotites['home'] = DEFAULT_HOME
        self.gotoweb(favotites['home'])
        
    def go(self):
        uri = self.txt_add.get().strip()
        self.gotoweb(uri)


    def gotoweb(self,uri):
        text = self.__openweb(uri)
        self.webcontent.append(text)
        self.webaddress.append(uri)
        self.currentpage = len(self.webcontent) - 1
        self.__show(self.currentpage)
        
    def refresh(self):
        ''' check for if never open a web then go open it
            else open web (get address) add set webcontent at end of self.webcontent[-1] (*not append)
            and setcurrent page point to    '''
        uri = self.txt_add.get().strip()
        #print 'refresh()'
        if uri <> '':
            if len(self.webcontent)<=0:
                self.gotoweb(uri)
            else:
                ##  delect the current view page and retrive new page append at end <-  amke this worknext time
                #print 'self.currentpage',self.currentpage
                text = self.__openweb(uri)
                self.webcontent[-1] = text
                self.currentpage = len(self.webcontent) - 1
                self.__show(self.currentpage)
                #print 'next self.currentpage',self.currentpage
        else:
            #print 'NO input uri'
            pass

    def back(self):
        print 'back()'
        if self.currentpage > 0:
            self.currentpage-=1
            self.__show(self.currentpage)
        
    def next(self):
        ''' - chack can next ? '''
        #print 'nect()'
        if self.currentpage < len(self.webcontent)-1:
            self.currentpage+=1
            self.__show(self.currentpage) 

    
    def __show(self,currentpage):
        ''' show web contant '''
        self.lib_showfile.clear()
        self.lib_showfile.appendtext(self.webcontent[currentpage])
        
        self.txt_add.delete(0,END)
        self.txt_add.insert(INSERT,self.webaddress[currentpage])


    def __check_MAX_TEMP_PAGE(self):
        if len(self.webcontent)>self.MAX_TEMP_PAGE:
            self.webcontent = self.webcontent[self.NUMBER_CLEAR:]
            self.webadd = self.webadd[self.NUMBER_CLEAR:]

    def __openweb(self,uri):
        return self.myweb.open(uri)


##-------------------------------------------------------------
    def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                            background = clr['background'],
                            foreground = clr['foreground'],
                            activeForeground = clr['activeForeground'],
                            insertBackground = clr['insertBackground'],
                            selectForeground = clr['selectForeground'],
                            highlightColor = clr['highlightColor'],
                            disabledForeground = clr['disabledForeground'],
                            highlightBackground = clr['highlightBackground'],
                            activeBackground = clr['activeBackground'],
                            selectBackground = clr['selectBackground'],
                            troughColor = clr['troughColor'],
                            selectColor = clr['selectColor']       )




#if __name__ == "__main__":
#    root = Tk()
#    shell = browser(root)
#    root.mainloop()

