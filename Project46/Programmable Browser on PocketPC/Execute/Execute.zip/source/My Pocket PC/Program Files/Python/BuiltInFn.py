'''
BuiltInFn.py == Version1.4
This is a group of built-in function for CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 7 Dec. 2002, 18:52
================================================
Comment : pass
'''

from abstract import *
import sys

def printMethod(obj) :
	if obj.type == "list" :
		value = ForwardList(obj.value)
		print value
	elif obj.type == "dictionary" :
		value = ForwardDict(obj.value)
		print value
	elif obj.type == "ti" :
		v_0 = obj.value[0].value
		v_1 = obj.value[1].value
		v_2 = obj.value[2].value
		value = [v_0, v_1, v_2]
		print value
	else : print obj.value

## Built-in methods for Numeric Type

def absMethod(obj) :
	if obj.type in ["int","long","float","complex"] :
		result = abs(obj.value)
		return checkType(result)
	else : error()

def divmodMethod(obj1,obj2) :
	if ((obj1.type == "number") and (obj2.type == "number")) :
		pass
		#return Tuple(divmod(obj1.value,obj2.value))
	else : error()

def roundMethod(obj) :
	if obj.type in ["int","long","float","complex"] :
		result = round(obj.value)
		return checkType(result)
	else : error()

def powMethod(obj1,obj2) :
	if ((obj1.type in ["int","long","float","complex"]) and (obj2.type in ["int","long","float","complex"])) :
		result = pow(obj1.value,obj2.value)
		return checkType(result)
	else : error()

def realMethod(obj) :
	if obj.type == "complex" :
		result = obj.value.real
		return checkType(result)
	else : error()

def imagMethod(obj) :
	if obj.type == "complex" :
		result = obj.value.imag
		return checkType(result)
	else : error()

## Built-in methods for Sequence Type

def lenMethod(obj) :
	if obj.type in ["string","list","dictionary"] :
		result = len(obj.value)
		return checkType(result)
	else : error()

def minMethod(obj) :
	if obj.type == "string" :
		result = min(obj.value)
		return checkType(result)
	elif obj.type == "list" :
		value = ForwardList(obj.value)
		result = min(value)
		if isinstance(result,types.ListType) : result = BackwardList(result)
		return checkType(result)
	else : error()

def maxMethod(obj) :
	if obj.type == "string" :
		result = max(obj.value)
		return checkType(result)
	elif obj.type == "list" :
		value = ForwardList(obj.value)
		result = max(value)
		if isinstance(result,types.ListType) : result = BackwardList(result)
		return checkType(result)
	else : error()

## Built-in methods for List Type

def appendMethod(obj1,obj2) :
	if obj1.type == "list" :
		obj1.value.append(obj2)
		return obj1
	else : error()

def extendMethod(obj1,obj2) :
	if ((obj1.type == "list") and (obj2.type == "list")) :
		obj1.value.extend(obj2.value)
		return obj1
	else : error()

def countMethod(obj1,obj2) :
	if obj1.type == "list" :
		list = ForwardList(obj1.value)
		if obj2.type == "list" :
			value = ForwardList(obj2.value)
			result = list.count(value)
		else :
			result = list.count(obj2.value)
		return checkType(result)
	else : error()

def indexMethod(obj1,obj2) :
	if obj1.type == "list" :
		list = ForwardList(obj1.value)
		if obj2.type == "list" :
			value = ForwardList(obj2.value)
			result = list.index(value)
		else :
			result = list.index(obj2.value)
		return checkType(result)
	else : error()

def insertMethod(obj1,obj2,obj3):
	if ((obj1.type == "list") and (obj2.type == "int")) :
		obj1.value.insert(obj2.value,obj3)
		return obj1
	else : error()

def popMethod(obj1) :
	if obj1.type == "list" :
		result = obj1.value.pop()
		return [obj1,result]
	else : error()

def removeMethod(obj1,obj2) :
	if obj1.type == "list" :
		list = ForwardList(obj1.value)
		if obj2.type == "list" :
			removal = ForwardList(obj2.value)
			list.remove(removal)
		else : list.remove(obj2.value)
		list = BackwardList(list)
		return checkType(list)
	else : error()

def reverseMethod(obj1) :
	if obj1.type == "list" :
		value = ForwardList(obj1.value)
		value.reverse()
		result = BackwardList(value)
		return checkType(result)
	else : error()

def sortMethod(obj1) :
	if obj1.type == "list" :
		value = ForwardList(obj1.value)
		value.sort()
		result = BackwardList(value)
		return checkType(result)
	else : error()

##Built-in Method for Dictionary Type
def clearMethod(obj) :
	if obj.type == "dictionary" :
		obj.value.clear()
		return obj
	else : error()

def has_keyMethod(obj1,obj2) :
	if obj1.type == "dictionary" :
		dict = ForwardDict(obj1.value)
		fact = dict.has_key(obj2.value)
		return checkType(fact)
	else : error()

def keysMethod(obj) :
	if obj.type == "dictionary" :
		dict = ForwardDict(obj.value)
		keyList = dict.keys()
		return checkType(BackwardList(keyList))
	else : error()

def updateMethod(obj1,obj2) :
	if ((obj1.type == "dictionary") and (obj2.type == "dictionary")) :
		obj1.value.update(obj2.value)
		return obj1
	else : error()

def valuesMethod(obj) :
	if obj.type == "dictionary" :
		dict = ForwardDict(obj.value)
		keyList = dict.values()
		return checkType(BackwardList(keyList))
	else : error()


#Converting CL list to Python list
def ForwardList(obj) :
	value = []
	for i in range(len(obj)) :
		adder = obj[i]
		if adder.type == "list" : newObj = ForwardList(adder.value)
		elif adder.type == "dictionary" : newObj = ForwardDict(adder.value)
		else : newObj = adder.value
		value.append(newObj)
	return value

#Converting Python list to CL list
def BackwardList(obj) :
	value = []
	for i in range(len(obj)) :
		adder = obj[i]
		if isinstance(adder,types.ListType) : newObj = BackwardList(adder)
		elif isinstance(adder,types.DictType) : newObj = BackwardDict(adder)
		else : newObj = adder
		value.append(checkType(newObj))
	return value

#Converting CL dictionary to Python dictionary
def ForwardDict(obj) :
	value = {}
	key = obj.keys()
	for i in range(len(key)) :
		adderVal = obj[key[i]]
		if adderVal.type == "list" : newObj = ForwardList(adderVal.value)
		elif adderVal.type == "dictionary" : newObj = ForwardDict(adderVal.value)
		else : newObj = adderVal.value
		value[key[i].value] = newObj
	return value

#Converting Python dictionary to CL dictionary
def BackwardDict(obj) :
	value = {}
	key = obj.keys()
	for i in range(len(key)) :
		adderVal = obj[key[i]]
		if isinstance(adderVal,types.ListType) : newObj = BackwardList(adderVal)
		elif isinstance(adderVal,types.DictType) : newObj = BackwardDict(adderVal)
		else : newObj = adderVal
		value[checkType(key[i])] = checkType(adderVal)
	return value

def error() :
	print "Built-In Functions Error!"
	sys.exit(0)

