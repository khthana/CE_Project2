from Tkinter import *


def m():
    f = Mail(root)

root = Tk()
filepath= 'D:\\Project\\Example\\ch11\\Temp\\'
menu = Menu(root)
toolbar = Frame(root)
root.config(menu=menu)
frame = Frame(root)

#menubar
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New")
filemenu.add_command(label="Open..." )
filemenu.add_command(label="Save")
filemenu.add_command(label="Save as...")
filemenu.add_separator()
filemenu.add_command(label="Exit" )

editmenu = Menu(menu)
menu.add_cascade(label="Edit", menu=editmenu)
editmenu.add_command(label="Profile")

commandmenu = Menu(menu)
menu.add_cascade(label="Command",menu=commandmenu)
commandmenu.add_command(label="Test script")
commandmenu.add_command(label="Run script")
commandmenu.add_command(label="Clean up NameSpace")

toolsmenu = Menu(menu)
menu.add_cascade(label="Tools",menu=toolsmenu)
toolsmenu.add_command(label="Web Browser")
toolsmenu.add_command(label="File Transfer")
toolsmenu.add_command(label="Mail Service")
toolsmenu.add_command(label="Other")

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About...")



myImage0 = PhotoImage( file = filepath + "mail.gif" )
b = Button(toolbar, text="new", image = myImage0,relief = GROOVE,command = m,border="0")
b.pack(side=LEFT)
myImage1 = PhotoImage( file = filepath + "wb.gif" )
b = Button(toolbar, text="open",image = myImage1,relief = GROOVE,command = m,border="0")
b.pack(side=LEFT)
myImage2 = PhotoImage( file = filepath + "ftp.gif" )
b = Button(toolbar, text="open",image = myImage2,relief = GROOVE,command = m,border="0")
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)

#frame

frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("PWB")

scrollbar = Scrollbar(frame,command = textBox.yview)
scrollbar.pack(side=RIGHT, fill=Y)

scrollbar2 = Scrollbar(frame,command = textBox.xview)
scrollbar2.pack(fill=X)

textBox = Text(frame,width=35,height=18,xscrollcommand=scrollbar.set,yscrollcommand=scrollbar2.set)
textBox.pack(fill=BOTH)

mainloop()