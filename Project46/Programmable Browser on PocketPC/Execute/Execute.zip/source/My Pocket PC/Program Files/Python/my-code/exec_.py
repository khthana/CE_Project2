import sys
import traceback
import string

try:
    try:
        exec 'y=dew'
        print 'Error \n'
    except SystemExit:
        raise
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        l = len(traceback.extract_tb(sys.exc_traceback))
        print 'l :'+ str(l) +'\n'
        try: 1/0
        except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            #traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
finally:
    print 'End exec'