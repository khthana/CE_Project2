#######################################################
##   used to pare a file to dict and send
##   user to save a dict to a file with well structure
##   2004/01/23
##   2004/03/09
##   fix bug in saveuserpf()
##   ## 2004/03/15
##   print correctly
#######################################################

import sys
import string
import os

from config import *

class getuserprofile:

    def __init__(self):
        #print 'getUserProfile.__init__()'
        self.path = userprofilepath
        
    def setpath(self,PATH):
        self.path = PATH

## input 2 arg <1 filename > <2 dictionary for store data and return >
    def getuserpf(self,filename,UPdict):
        try :
            filename = self.path + filename
            f = open(filename,'r')
            lines = f.readlines()
            f.close()            
        except :
            print filename+" <- Profile not found"
        try :
            for line in lines :
                line = string.strip(line)
                if line[0] <>'/':
                    key, value = line.split('::')
                    key = string.strip(key)
                    value = string.strip(value)
                    #print key+":"+value
                    if not key :
                        continue
                    else:
                        UPdict[key] = value
                #else:
                    #print line
        except :
            print filename+" <- Profile file corrupt"
        return  UPdict


    
    def saveuserpf(self,filename,UPdict) :
        try :
            filename = self.path + filename
            f = open(filename,'w')              
            lines=""
            for k, v in UPdict.items():
                lines = lines+k+" :: "+v+"\n"
            f.write(lines)
            f.close()
        except :
            print filename+" <-  Error writing profile"
            #pass





#######################################################
##   test class section
#######################################################
#userurofiledict = {}
#t=getuserprofile()
#userprofiledict = t.getuserpf('mail.profile',userprofiledict) 
#t.setpath('C:\\PythonCE\\userprofile\\')
#for k, v in userprofiledict.items():
#    print k, v
#t.saveuserpf('mail2.profile',userprofiledict)
######################################################

            
   