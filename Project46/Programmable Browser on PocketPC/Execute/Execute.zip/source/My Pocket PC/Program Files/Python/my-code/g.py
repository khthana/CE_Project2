# Fig. 10.7: fig10_07.py
# Button demonstration.

from Tkinter import *
from tkMessageBox import *
#from fig10_09 import RadioFont

class PlainAndFancy( Frame ):
   """Create one plain and one fancy button"""
   
   def __init__( self ):
      """Create two buttons, pack them and bind events"""
      
      Frame.__init__( self )
      self.pack( expand = NO, fill = BOTH )
      self.master.title( "Buttons" )
      self.master.geometry("235x242")
      self.frame1 = Frame( self )
      self.frame1.pack( )
      
      # create button with text
      self.myImage0 = PhotoImage( file = filepath + "a13.gif" )
      self.plainButton = Button( self.frame1, image = self.myImage0, command = self.pressedPlain )
      self.plainButton.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton.config( relief = GROOVE )


      self.myImage1 = PhotoImage( file = filepath + "a2.gif" )
      self.plainButton1 = Button( self.frame1, image = self.myImage1, command = self.pressedPlain )
      self.plainButton1.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton1.config( relief = GROOVE )      

      self.myImage2 = PhotoImage( file = filepath + "a10.gif" )
      self.plainButton2 = Button( self.frame1, image = self.myImage2, command = self.pressedPlain )
      self.plainButton2.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton2.config( relief = GROOVE )

      # plain 2
      self.frame2 = Frame( self )
      self.frame2.pack( )

      self.plainButton3 = Entry( self.frame2, name = "text3" )
      self.plainButton3 = Button( self, text = "button5",command = self.pressedPlain )
      self.plainButton3.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton3.config( relief = GROOVE )

      self.plainButton4 = Button( self, text = "button6",command = self.pressedPlain )
      self.plainButton4.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton4.config( relief = GROOVE )

      self.plainButton5 = Button( self, text = "button7",command = self.pressedPlain )
      self.plainButton5.pack( side = LEFT, padx = 0, pady = 0 )
      self.plainButton5.config( relief = GROOVE )
      
      # create button with image
    
      self.myImage = PhotoImage( file = filepath + "a13.gif" )
      self.fancyButton = Button( self, image = self.myImage,
         command = self.pressedFancy )
      self.fancyButton.bind( "<Enter>", self.rolloverEnter )
      self.fancyButton.bind( "<Leave>", self.rolloverLeave )
      self.fancyButton.pack( side = LEFT, padx = 5, pady = 5 )

   def pressedPlain( self ):
      #showinfo( "Message", "You pressed: Plain Button" )
      t=RadioFont()
      t.pack()

   def pressedFancy( self ):
      showinfo( "Message", "You pressed: Fancy Button" )

   def rolloverEnter( self, event ):
      event.widget.config( relief = GROOVE )

   def rolloverLeave( self, event ):
      event.widget.config( relief = RAISED )

def main():
   #root=Tk()
   #t=RadioFont()
   PlainAndFancy().mainloop()
   #root

#filepath= 'D:\\Project\\Example\\ch10\\'
filepath = '\\Program Files\\Python\\pic\\'


main()


