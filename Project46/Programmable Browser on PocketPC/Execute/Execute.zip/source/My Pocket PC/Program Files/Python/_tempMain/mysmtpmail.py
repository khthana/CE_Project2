
######################################################

######################################################

import smtplib
import string
import sys
import time

from getuserprofile import getuserprofile


class mysmtpmail:

    def __init__(self,From,To,Subj,Data):
        ''' send mail module '''
        #From = string.strip("s3010096@kmitl.ac.th")       # ex: lutz@rmi.net s3010096@kmitl.ac.th
        #To   = string.strip("h_chakrit@163.com")       # ex: python-list@python.org
        #To   = string.split(To, ';')                   # allow a list of recipients
        #Subj = string.strip("test2004-02-05#2")

        print 'mysmtpmail.__init__()'
        self.upfd={}
        self.upf=getuserprofile()
        self.upf.getuserpf('mail.profile',self.upfd)
        self.smtpserver = self.upfd['smtpserver']

        self.From = string.strip(From)
        self.To   = string.strip(To)
        self.Subj = string.strip(Subj)
        self.Data = string.strip(Data)
        
        #mailconfig.smtpservername         # ex: starship.python.net

        # prepend standard headers
        date = time.ctime(time.time())
        self.mail = ('From: %s\nTo: %s\nDate: %s\nSubject: %s\n'
                % (self.From, string.join(self.To, ';'), date, self.Subj))
        self.mail = self.mail + self.Data
        print '@'*80
        print self.mail
        print '@'*80

    def send(self):
        print 'Connecting...'
        server = smtplib.SMTP(self.smtpserver)              # connect, no login step
        failed = server.sendmail(self.From, self.To, self.mail)
        server.quit() 
        if failed:                                     # smtplib may raise exceptions
            print 'Failed recipients:', failed         # too, but let them pass here
            return 0
        else:
            print 'No errors.'
            return 1


####################################################################
From = 'ck1982@msn.com'
To = 'h_chakrit@163.com'
Subj = 'pocket-by-SMTP#1'
Data = 'data-1a123456789\n2a123456789\n3a123456789'
a=mysmtpmail(From,To,Subj,Data)
b=a.send()
print b
