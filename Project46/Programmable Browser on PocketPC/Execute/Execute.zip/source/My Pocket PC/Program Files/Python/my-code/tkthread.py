# trivia_threading.py

from Tkinter import *

import threading
import time

AA = "begin \n"
HE = "1"

class Worker(threading.Thread):
    def __init__(self, text):
        threading.Thread.__init__(self)
        self.text = text
        self.running = 0
    def run(self):
        self.running = 1
        self.text.insert(END, AA)
        count = 0
        while self.running:
            time.sleep(0.2)
            self.text.insert(END, HE)
            count = count + 1
        self.text.insert(END, "\n%d%s!!\n\n" % (count, HE))
    def stop(self):
        self.running = 0
        self.join()

class Application:
    def __init__(self):
        self.root = Tk()
        self.root.geometry( "235x242" )  # width x length
        self.text = Text(self.root,width=20,height=10)
        self.text.pack()
        Button(self.root, text="Start", command=self.start_worker).pack(side=LEFT)
        Button(self.root, text="Stop", command=self.stop_worker).pack(side=LEFT)
        Button(self.root, text="Quit", command=self.quit).pack(side=RIGHT)
        self.worker = None
    def start_worker(self):
        if self.worker is None:
            self.worker = Worker(self.text)
            self.worker.start()
    def stop_worker(self):
        if self.worker is not None:
            self.worker.stop()
            self.worker = None
    def mainloop(self):
        self.root.mainloop()
    def quit(self):
        self.stop_worker()
        self.root.quit()

Application().mainloop()
