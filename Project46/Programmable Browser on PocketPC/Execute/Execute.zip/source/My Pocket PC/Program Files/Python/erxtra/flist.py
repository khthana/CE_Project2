#
#"""----- flist.py -----
# f_list(): returns the list of (frameobj, codeobj) paires from stack frame.
#	Useful for peeking the namespace of caller and up.
#
#	f_list()[0] is the frame of this function
#	f_list()[-1] is the base level of the stack frame (ceshell.py in CE)
#	f_list()[n][0] gives frame object for (n)th frame
#	f_list()[n][1] gives code object  (same as f_list()[n][0].f_code)
#	f_list()[n][0].f_locals gives locals() for (n)th frame
#	f_list()[n][0].f_globals gives globals() for (n)th frame
#
# Telion
#
#"""
#
	
def f_list():
	list=[]
	try:
		raise ZeroDivisionError
	except ZeroDivisionError:
		import sys
		f = sys.exc_info()[2].tb_frame
	while(f):
		list.append((f,f.f_code))
		f=f.f_back
	return list
