from Tkinter import *

filepath = 'D:\\Project\\Example\\ch11\\Temp\\browser\\'
root = Tk()
frame = Frame(root)
menu = Menu(root)
root.config(menu=menu)

#Addressbar
to = Frame(root)
Label(to,text="To:").pack(side =LEFT)
Entry(to,width=25).pack(side=LEFT)
to.pack()

fromentry=Frame(root)
Label(fromentry,text="From:").pack(side =LEFT)
Entry(fromentry,width=25).pack(side=LEFT)
fromentry.pack()

subject=Frame(root)
Label(subject,text="Subject:").pack(side =LEFT)
Entry(subject,width=25,show='*').pack(side=LEFT)
subject.pack()

#Actionbar
action=Frame(root)
Button(action,text="Send",border="1").pack(side=LEFT,padx=1)
Button(action,text="Clear",border="1").pack(side=LEFT,padx=1)
action.pack(pady = "1m")

#Writearea

writearea = Frame(root)
writearea.pack(side=BOTTOM, fill=BOTH, expand=YES)
textbox = Text(writearea)

rightScrollbar = Scrollbar(writearea, orient=VERTICAL, command=textbox.yview)
textbox.configure(yscrollcommand = rightScrollbar.set)
bottomScrollbar = Scrollbar(writearea, orient=HORIZONTAL, command=textbox.xview)
textbox.configure(xscrollcommand = bottomScrollbar.set)

bottomScrollbar.pack(side=BOTTOM, fill = X)
rightScrollbar.pack(side=RIGHT, fill = Y)

textbox.pack(side=LEFT, padx="1m", pady="1m", expand=YES, fill=BOTH)


#frame
frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("Editmail")

mainloop()