import string
import Pmw
from Tkinter import *
from config import *
from task import task
import time

class calendart(Toplevel):
    
    def __init__(self,parent,datelist,mycolor,select_color_number):
        Toplevel.__init__( self,parent)
        ##['Mon', 4, 'Mar', 3, '2004']
        self.mytitle=str(str(datelist[0]))+' '+str(datelist[1])+' '+str(datelist[2])+' '+str(datelist[4])
        self.title( self.mytitle )
        self.geometry( "235x270" )
        self.filepath = picpath
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        
        self.datelist=datelist ## rweekday,n_day,t_mon,n_year,n_mon
        self.datelist.append(0)
        
        self.frm_datetime= Frame(self)
        self.frm_datetime.pack()
        Label(self.frm_datetime,text=self.mytitle).pack(pady='5',padx='2')
        
        self.frm_strt = Frame(self)
        self.frm_strt.pack()
        Label(self.frm_strt,text='StratTime').grid(row=1,column=1,ipadx='2')
        Label(self.frm_strt,text='StopTime').grid(row=1,column=3,ipadx='2')
        
        self._strh = Pmw.Counter(parent,labelpos = 'w',
                                 label_text = 'Vertical integer:',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = 50,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 23}
                                 )
        self._strm = Pmw.Counter(parent,labelpos = 'w',
                                 label_text = 'Vertical integer:',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = 50,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )
        self._strs = Pmw.Counter(parent,labelpos = 'w',
                                 label_text = 'Vertical integer:',
                                 orient = 'vertical',
                                 entry_width = 2,
                                 entryfield_value = 50,
                                 entryfield_validate = {'validator' : 'integer','min' : 0, 'max' : 59}
                                 )

        #self._strttime = Pmw.TimeCounter(self.frm_strt,
        #        labelpos = 'n',
        #        label_text = 'HH:MM:SS',
        #        min = '00:00:00',
        #        max = '23:59:59')
        #self._strttime.grid(row=2,column=1,ipadx='2')
#pack(padx=10, pady=5)

        Label(self.frm_strt,text=' ').grid(row=2,column=2,ipadx='2')
        
        self._stoptime = Pmw.TimeCounter(self.frm_strt,
                labelpos = 'n',
                label_text = 'HH:MM:SS',
                min = '00:00:00',
                max = '23:59:59')
        self._stoptime.grid(row=2,column=3,ipadx='2')

        self.frm_take = Frame(self)
        self.frm_take.pack()
        self.takedict={'remind()':'remind("NOTE_HEAR")',
                  'sendmail()':'sendmail(used,pass,server'
                  }
        self.takebox = Pmw.ComboBox(self.frm_take,
                                    labelpos='nw',
                                    scrolledlist_items=self.takedict.keys(),
                                    #label_text=self.mytitle,
                                    selectioncommand=self.selectionCommand
                                    )
        self.takebox.pack(fill = 'both', expand = 1,pady='0')
        
        #self.frm_take = Frame(self)
        #self.frm_take.pack()
        #self.etf_task = Pmw.EntryField(self.frm_take,labelpos = 'nw',label_text = 'Event',entry_width='32')
        #self.etf_task.pack(side= 'top',fill = 'both', expand = 1)

        #setentry(text)
        self.frm_action = Frame(self)
        self.frm_action.pack()
        self.etf_act = Pmw.EntryField(self.frm_action,labelpos = 'nw',label_text = 'Action',entry_width='32')
        self.etf_act.pack(side= 'top',fill = 'both', expand = 1)

        self.frm_gen = Frame(self)
        self.frm_gen.pack()
        self.btn = Button(self.frm_gen,text='generate',command=self.gencode)
        self.btn.pack(side='right',padx='5',pady='5')
        
        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)
        #atday=time.ctime(time.time())
        #self.daylist=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
        #self.box = Pmw.ScrolledListBox(self, listbox_selectmode='single', 
        #    listbox_width = 35,listbox_height = 10,
        #    labelpos='nw', 
        #    items=self.daylist,
        #    label_text=str(datelist[0])+' '+str(datelist[1])+' '+str(datelist[2])+' '+str(datelist[3]),
        #    selectioncommand=self.selectionCommand)
        #self.box.pack(fill = 'both', expand = 1)

    def selectionCommand(self,list):
        #print'list',list
        self.etf_act.setentry(self.takedict[list])

    def gencode(self):
        #print 'gencode'
        #take = self.etf_task.getvalue()
        #take = take.strip()
        action = self.etf_act.getvalue()
        action = action.strip()
        my_atdate='|'+str(self.datelist[1])+'/'+str(self.datelist[3])+'/'+str(self.datelist[4])
        my_atdate = 't<'+self._strttime.getstring()+my_atdate+','+self._stoptime.getstring()+my_atdate+'>'
        #self.datelist=datelist ## rweekday,n_day,t_mon,n_year,n_mon
        #print my_atdate+' : '+action
        

##---------------------------------------
    def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                            background = clr['background'],
                            foreground = clr['foreground'],
                            activeForeground = clr['activeForeground'],
                            insertBackground = clr['insertBackground'],
                            selectForeground = clr['selectForeground'],
                            highlightColor = clr['highlightColor'],
                            disabledForeground = clr['disabledForeground'],
                            highlightBackground = clr['highlightBackground'],
                            activeBackground = clr['activeBackground'],
                            selectBackground = clr['selectBackground'],
                            troughColor = clr['troughColor'],
                            selectColor = clr['selectColor']       )

######################################################################

# Create demo in root window for testing.
if __name__ == "__main__":
    root = Tk()
    shell = calendart(root)
    root.mainloop()        