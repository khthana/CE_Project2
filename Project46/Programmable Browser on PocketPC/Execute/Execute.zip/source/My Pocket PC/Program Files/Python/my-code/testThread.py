from T import CheckEvenThread


thread1 = CheckEvenThread( threadName='T1' ,isleepTime=1 )
thread2 = CheckEvenThread( threadName='T2' ,isleepTime=2 )
thread3 = CheckEvenThread( threadName='T3' ,isleepTime=4 )

print "\nStarting threads"

thread1.start()
thread2.start()
thread3.start()

print "Threads started\n"