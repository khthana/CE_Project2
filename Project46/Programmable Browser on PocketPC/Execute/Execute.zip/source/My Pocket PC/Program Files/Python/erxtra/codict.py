#
#"""# codict:   code (or command) dictionary functions
#
##### It works, but still experimental. #####
#
# Useful for: switch...case emulation, command interpreter, reusable code database
#
# codict is similar to Python's local or global namespace dictionary.
# It consists of {name:(type,object)} dictionary, where the (object)
# must be one of followings;
#     executable object: source code, compiled code, module, file containing them.
#     list of above mentioned objects for sequencial execution.
# the (name) can be either (string), or (int) number
#
# By default, "codict._exec(name [,global [,local]])" will execute
# named object in the namespace frame of this module.
# To execute in caller's namespace, codict._exec(name, locals()) will do it.
# 
# codict.dict={} # name:command dictionary
# command=(type,executable object)
# type: 's'=source, 'c'=code, 'cs'=code with src, 'l'=command list
#
# codict.src={} # source only codict
#"""
# Telion
#

class Codict:
	def __init__(self,fn='pycodict' ):
		self.dict={}
		self.src={}
		self.filename=fn
		self.locals={}
		self._load() # load (src) file
		self._updateall() # compile and set in (self.dict)
		#print "__init__"
		self.__call__=self._exec_ne
		self.ce=self._exec
		self.depthc=0

	def _test(self):
		print "test"

	def _update(self, names): # compile the names keys in src and update dict
		if type(names) in (type(''),type(1)): # name can be string or number
			names=[names]
		#print repr(names)
		for name in names:
			#print name,
			#print self.src[name]
			if self.src[name][0] != 's':
				self.dict[name]=self.src[name]
				continue
			#code=compile(self.src[name], '<string>','exec') # code with source
			code=compile(self.src[name][1], '<codict.src['+str(name)+'][1]:cs>','exec') # code with source
			self.dict[name]=('cs',code)
	def _updateall(self ): # compile all keys in src and update dict
		self._update(self.src.keys())
	
	def _setlocals(self, fid=0): 
		from flu import globals_x
		self.locals=globals_x(1)
		print self.locals.keys()
		
	def _exec(self, name, argv=None, glo=None,loc=None):
		_cod=self.dict[name]
		if not glo:
			glo={}
		glo['argv']=argv
		if _cod[0] == 'l':
			for _c in _cod[1]:
				exec _c in glo,loc
		else:
			exec _cod[1] in glo,loc
#		if _cod[0] in ('c','cs','s'):
#			exec _cod[1] in glo,loc
#		elif _cod[0] == 'l':
#			for _c in _cod[1]:
#				exec _c in glo,loc
		return glo.get('return')

	def _exec_ne(self, name, argv=None, glo=None,loc=None):
		if self.depthc > 8:
			print "Codict ERROR: Nest depth exceeded"
			raise
			return 0
		#print name, type(name), repr(name), str(name)
		if type(name) != type(''):
			name=str(name)
		if not self.dict.has_key(name):
			#print name, type(name)
		#	print "Codict: Nokey <"+name+">"
			return -1
		_cod=self.dict[name]
		#print _cod
		if type(_cod[1])==type(''):
			_cname=_cod[1]
		#while (type(_cod)==type('')) and self.dict.has_key(_cod):
		#	_cod=self.dict[_cod]
		
		if not glo:
			glo={}
		glo['argv']=argv
		#if _cod[0] in ('c','cs','s'):
		#	exec _cod[1] in glo,loc
		#elif _cod[0] == 'l':
		if _cod[0] == 'l':
			for _c in _cod[1]:
				try:
					exec _c in glo,loc
				except NameError, _cname:
					self.depthc=self.depthc+1
					name=_cname
					#print _cname, repr(_cname),
					if type(_cname) != type(''):
						_cname=str(_cname)
					r=self._exec_ne(_cname, argv, glo,loc)
					#print "NameError", _cname
				except:
					#print "other error"
					raise
		else:
			try:
				exec _cod[1] in glo,loc
			except NameError, _cname:
				self.depthc=self.depthc+1
				name=_cname
				#print _cname, repr(_cname),
				if type(_cname) != type(''):
					_cname=str(_cname)
				r=self._exec_ne(_cname, argv, glo,loc)
				#print "NameError", _cname
			except:
				#print "other error"
				raise
		return glo.get('RV')

	#def __call__(self, name, argv=None):
	#	return self._call(name, argv)

	def _exec_local(self, name, argv=None):
		return self._exec(name, argv, self.locals)

	def _len(self):
		return len(self.dict)
	def codictkeys(self):
		return self.dict.keys()
	
	def _load(self, fn=None,src=1):
		if not fn: fn =self.filename
		import string
		#from os import linesep
		linesep="\n"
		f=open(fn,'r')
		if src: 	_c=self.src
		else: 	_c=self.dict
		ll=[]
		name=''
		ty=''
		for ln in f.readlines():
			#print ln,
			if ln and ln[0] == '#': # skip comments.
				#print "skiped"
				continue
			if ln and ln[0] == '=':
				#print "=name",
				if name:
					if ty =="s":
						_c[name]=('s',string.join(ll,linesep))
					else:
						_c[name]=('l',eval(string.join(ll,'')))
					#print repr(ll)
					#print repr(_c[name])
				name=ln[1:-1]
				if not name:
					raise "codictFileFormatError"
				while name[-1] in "\r\n": name=name[:-1]
				if ":" in name:
					ii=string.find(name,':')
					ty=name[ii+1:]
					name=name[:ii]
				else:
					ty='s'
				#print name+"-"+ty,
				if name[0] in string.digits: name=int(name)
				ll=[]
				continue
			if name: 
				#print "ln>",ln,
				while ln and ln[-1] in "\r\n": ln=ln[:-1]
				ll.append(ln)
				#print "ll=",ll
		if name and ll: 
			if ty =="s":
				_c[name]=('s',string.join(ll,linesep))
			else:
				_c[name]=('l',eval(string.join(ll,'')))
		f.close()
		
	def _save(self, fn=None,src=1):
		if not fn: fn =self.filename
		import string
		f=open(fn,'w')
		if src: 	_c=self.src
		else: 	_c=self.dict
		ck=_c.keys()
		ck.sort()
		#print repr(ck)
		fw=f.write
		fw("### codict\n")
		for k in ck:
			#print _c[k][0]
			ty=_c[k][0]
			if len(ty) > 1:
				continue
			#print k,
			if ty in 'sl':
				fw("="+str(k)+":"+ty+"\n")
				#print "="+str(k)
				if ty == 'l':
					fw(repr(_c[k][1]))
				else:
					fw(_c[k][1])
				#print _c[k][1]
				fw("\n")
		fw("### codict end\n")
		f.close()
