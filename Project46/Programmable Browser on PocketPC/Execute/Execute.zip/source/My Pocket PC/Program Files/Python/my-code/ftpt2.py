import os
from ftplib import FTP                   # socket-based ftp tools
Version = '1.5'                          # version to download
tarname = 'text.txt'                     #% Version    # remote/local file name
 
print 'Connecting...'
localfile  = open(tarname, 'wb')         # where to store download
connection = FTP('161.246.5.87')         # connect to ftp site
connection.login('ck13','ck13')      # default is anonymous login
#connection.cwd('pub/python/src')        # xfer 1k at a time to localfile

print 'Downloading...'
connection.retrbinary('RETR ' + tarname, localfile.write, 1024)
print connection.pwd()
connection.cwd("tt")

#fileList = []
#connection.retrlines('LIST', fileList.append)
#for i in fileList:
#	print i
print connection.dir()
print connection.getwelcome()
print connection.pwd()
connection.quit()
localfile.close()

print 'finsh download...'
print 'Open and printfile...'
try:
	file = open(tarname, 'r')
	while 1:
		line = file.readline()
		print line
		if line =='':
			break	
	#line = file.readline()
	#print "line 1:",line
except IOError, (code, why):
	print "python: can't open %s: %s\n" % (fname, why)
	bKeepOpen = 1
	file = None


