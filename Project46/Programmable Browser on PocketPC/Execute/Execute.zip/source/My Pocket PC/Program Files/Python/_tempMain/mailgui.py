#########################################################
##
## 2004/02/04
## test and begin import mypopmail and try to integrate
##
#########################################################


from Tkinter import *
from mypopmail import mypopmail
from config import *


class mail(Toplevel):

    
    def __init__( self,parent,upfd):
        print 'mail.__init()__'
        self.upfd = upfd
        Toplevel.__init__( self,parent )
        self.title( "Mail" )
        self.geometry( "235x270" )  # width x length

        self.filepath = picpath
        
        ## mailserver :: pop.163.com     
        ## mailuser   :: h_chakrit@163.com
        ## mailpaswd :: kritnum
        ## mailsavepath :: C:\PythonCE\userprofile\mail\
        ## mailfilename :: mail.txt
        
        self.mailserver = self.upfd['mailserver']
        self.mailuser   = self.upfd['mailuser']
        self.mailpaswd = self.upfd['mailpaswd']
        self.mailfile = self.upfd['mailsavepath']
        self.mailfilename = self.upfd['mailfilename']
        
        self.read = {}  # for store had read mail
        self.mail = {}  # for store current mail
        
        self.menu = Frame(self)
        self.toolbar = Frame(self)
        self.textbox = Frame(self)
        self.server = Frame(self)
        self.username = Frame(self)
        self.password = Frame(self)
        self.action = Frame(self)

        #Addressbar
        self.lbl_srv = Label(self.server, name='address', text="Address:")
        self.lbl_srv.pack(side =LEFT)
        self.nty_srv = Entry(self.server, name='server', width=25 )
        self.nty_srv.insert( INSERT,self.mailserver )
        self.nty_srv.pack(side=LEFT)
        self.server.pack()

        self.lbl_usn = Label(self.username,text="User Name:")
        self.lbl_usn.pack(side =LEFT)
        self.nty_usn =Entry(self.username,width=25)
        self.nty_usn.insert( INSERT,self.mailuser)
        self.nty_usn.pack(side=LEFT)
        self.username.pack()

        self.lbl_pss = Label(self.password,text="Password:")
        self.lbl_pss.pack(side =LEFT)
        self.nty_pss = Entry(self.password,width=25)#show='*'
        self.nty_pss.insert( INSERT, self.password )
        self.nty_pss.pack(side=LEFT)
        self.password.pack()

        #Actionbar
        self.btn_rtr = Button(self.action,text="Retrive mail",border="1",command=self.retrivemail)
        self.btn_rtr.pack(side=LEFT)
        
        self.btn_dlt = Button(self.action,text="Delete ",border="1",command=self.d)
        self.btn_dlt.pack(side=LEFT)
        self.btn_frw = Button(self.action,text="Forward ",border="1")
        self.btn_frw.pack(side=LEFT)
        self.btn_rpy = Button(self.action,text="Reply ",border="1")
        self.btn_rpy.pack(side=LEFT)
        self.btn_sml = Button(self.action,text="Save mail",border="1")
        self.btn_sml.pack(side=LEFT)
        self.action.pack()

        ## -----------------------------------------------------
        ##  setup mypopmail
        self.mypopmail = mypopmail(upfd)
        #self.mypopmail.connect()

        #print ' in mailgui '
        #for self.k,self.v in self.upfd.items():
        #    print str(self.k)+" : "+str(self.v)

        
        #Display
        self.scrollbar = Scrollbar(self)
        self.textBox = Text(self,width=35,height=8,yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.textBox.yview)
        #scrollbar2.config(command=textBox.xview)
        self.scrollbar.pack(side=RIGHT, fill=Y)
        self.textBox.pack(fill=BOTH,expand=2)



    def retrivemail(self):
        self.mypopmail.connect()
        self.c=self.mypopmail.loadmail(1)
        print '*'*50
        print self.c
        print '-'*50
        for self.i,self.j in self.c.items():
            print self.i + " -> " + self.j

	def deletemail(self):
		print 'delete'
		#self.btn_sml.unpack()

    def d(self):
        print 'deletemail122222'
        self.btn_sml.pack_forget()
        

        
"""     self.scrollbar = Frame(self)
        textboxa = Text(self.scrollbar,width=38,height=1,yscrollcommand=self.scrollbar.set)
        textboxa.pack(fill=BOTH,expand=2)
        scrollbar.config(command=textboxa.yview)

        textBox = Text(self.frame,width=35,height=18,yscrollcommand=scrollbar.set)
        scrollbar.config(command=textBox.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.textBox.pack(fill=BOTH,expand=2)

        #frame
        self.frame.pack(expand = NO)
        self.frame.master.geometry("235x270")
        self.frame.master.title("Mail")
"""



#if __name__ == "__main__":
#    app = Tk()
#    shell = mail(app)
#    app.mainloop()