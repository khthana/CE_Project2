username :: ck13
stardir :: C:\PythonCE\browser\userprofile\
password :: ck13
port :: 21
server :: 161.246.5.87
