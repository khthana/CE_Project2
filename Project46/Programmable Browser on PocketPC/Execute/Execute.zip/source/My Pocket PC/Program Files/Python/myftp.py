'''
| Base Module for ftpgui.py
|----------------------------------------------
| 2004/03/15
| print correctly
'''

import sys
import os

from ftplib import FTP  

from config import *
from getuserprofile import getuserprofile

class myftp:

    def __init__(self,server='161.246.5.87',port='21',username='Anonymous',password='PWBCE@'):
        ''' this is my ftp lib '''
        #print 'myftp.__init__()'
        self.server = server
        self.port = port
        self.username = username
        self.password = password

        self.ftppath = ['.']
        self.login = False
        self.ftptatus = 'FTP init state'
        self.dir = ''
        self.welcomemsg = 'PWBCE_FTP'

    def login_ftp(self):
        #print 'myftp.login()'
        try:
            self.connection = FTP()       
            self.connection.connect(self.server,self.port)
            self.connection.login(self.username,self.password)
            self.ftppath.append(self.connection.pwd())
            self.login = True
            self.welcomemsg = self.connection.getwelcome()
            #self.ref()
            self.ftptatus = 'Server Accept Login request'
            #print self.ftptatus
        except Exception:
            self.login = False
            self.ftptatus = "Can't login"
            #print self.ftptatus


    def nlst(self):
          return self.connection.nlst()

    def uptotopdir(self):
        if self.login:
            if len(self.ftppath)>1: # check > 1 because have init put a '\' in self.ftppath
                self.ftptatus = 'SE-dir:'+self.__filepath_to_str()
                temp_dir=self.ftppath.pop()
                self.connection.cwd(temp_dir)
                #print self.ftptatus
                return True
            else:
                self.ftptatus = 'SE-dir:'+self.__filepath_to_str()
                #print self.ftptatus
                return False
        else:
            self.ftptatus = 'Can not chang to top level Directory '
            #print self.ftptatus
            return False

    def uploadfile(self,filename):
        if self.login:
            localfile = open(self.dir+filename, 'rb')
            #remote.cwd(dir)
            self.connection.storbinary('STOR ' + filename, localfile, 1024)
            localfile.close()
            self.ftptatus = 'Upload OK '+filename
            #print self.ftptatus
        return True
        ## on pocket else statement make error. I think ??? 
        #else:
        #    self.ftptatus = 'Can not Upload '+filename
            #print self.ftptatus
        #    return False


    def downloadfile_or_changdirto(self,filename):
        '''
            input an argv (filename to download or directory to chang to)
            but this is not complse to check input argv to divide file or directory
        '''
        if self.login:
            if filename.find('.')>=0:
                try:
                    self.ftptatus ='Downloading...'+ filename
                    #print self.ftptatus
                    localfile  = open(self.dir+filename, 'wb')
                    self.connection.retrbinary('RETR ' + filename, localfile.write, 1024)
                    localfile.close()
                    self.ftptatus = 'Download OK '+filename
                    #print self.ftptatus

                except Exception:
                    self.ftptatus = 'Can not Download '+filename
                    #print self.ftptatus

            else: # name.find('.')>=0:
                try:
                    self.ftppath.append(self.connection.pwd())      # save the currentdir
                    self.connection.cwd(filename)                   # chang dir
                    self.ftptatus = 'SE-dir:'+self.__filepath_to_str()+filename
                    #print self.ftptatus
                    return True
                except:
                    self.ftptatus = 'Can not chang to Directory '+filename
                    #print self.ftptatus
                    return False
        else: # self.login==True:
            self.ftptatus = 'Plase login befor loadfile '+filename
            #print self.ftptatus
            return False

    def __filepath_to_str(self):
        t1 = self.ftppath[-1].split('/')
        t3=''
        for t2 in t1:
            t3+=t2+'\\'
        return t3
    
    def quit(self):
        self.connection.quit()
    def cwd(self,dir):
        remote.cwd(dir)

    def setlocaldir(self,dir):
        self.dir = dir

    def getftptatus(self):
        return self.ftptatus

    def getwelcomemsg(self):
        return self.welcomemsg




if __name__ == '__main__' :
    from getuserprofile import getuserprofile             
    upfd={}
    upf=getuserprofile()
    upf.getuserpf('ftp.profile',upfd)
    #server :: 161.246.5.87
    #username :: ck13
    #password :: ck13
    #port :: 21
    k=upfd.keys
    for k in upfd:
        print k,' : ',upfd[k]
    

    a = myftp(upfd['server'],upfd['port'],upfd['username'],upfd['password'])
    a.login_ftp()
    a.uptotopdir()
    a.downloadfile_or_changdirto('browser')
    a.uptotopdir()
    a.downloadfile_or_changdirto('cache.txt')

    a.uploadfile('a.txt')

