## syandard Lib
from Tkinter import *
import Pmw
## config import before other python file
## import CONSTANT VALUES
from config import *

from getuserprofile import getuserprofile

#from ttt import *

from ftpgui import ftp
from mailgui import mail
from browsergui import browser

from Script7 import Demo

#from temp import Dialog

	## data section  
	## this include all user need data 

	## upfd == user profile dictionary  for store all user config data
global upfd
upfd={}
global upf
upf=getuserprofile()




def __init__():
	''' this is call for input user command use data'''



## get uesr data to upfd befor call this  must call __init__()
def getuserdata(filename):
	
	upf.getuserpf(filename,upfd)
	#for k,v in upfd.items():
	#	print str(k)+" : "+str(v)
	

def fp():
	getuserdata('ftp.profile')
	fp = ftp(root)

def ml():
	#getuserdata('mail.profile')
	widget = Demo(root)
	#m = mail(root)

def wb():
    wb = browser(root)

root = Tk()
filepath = picpath
#filepath= 'D:\\Project\\Example\\ch11\\Temp\\'

menu = Menu(root)
toolbar = Frame(root)
toolbar2 = Frame(root)
root.config(menu=menu)
frame = Frame(root)

##menubar
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="New")
filemenu.add_command(label="Open..." )
filemenu.add_command(label="Save")
filemenu.add_command(label="Save as...")
filemenu.add_separator()
filemenu.add_command(label="Exit" )


editmenu = Menu(menu)
menu.add_cascade(label="Edit", menu=editmenu)
editmenu.add_command(label="Profile")

commandmenu = Menu(menu)
menu.add_cascade(label="Command",menu=commandmenu)
commandmenu.add_command(label="Test script")
commandmenu.add_command(label="Run script")
commandmenu.add_command(label="Clean up NameSpace")

toolsmenu = Menu(menu)
menu.add_cascade(label="Tools",menu=toolsmenu)
toolsmenu.add_command(label="Web Browser")
toolsmenu.add_command(label="File Transfer")
toolsmenu.add_command(label="Mail Service")
toolsmenu.add_command(label="Other")

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="About...")

myImage0 = PhotoImage( file = filepath + "mail.gif" )
b = Button(toolbar, image = myImage0,relief = RAISED,command = ml,border="0")
b.pack(side=LEFT)
myImage1 = PhotoImage( file = filepath + "wb.gif" )
b = Button(toolbar,image = myImage1,relief = GROOVE,command = wb,border="0")
b.pack(side=LEFT)
myImage2 = PhotoImage( file = filepath + "ftp.gif" )
b = Button(toolbar,image = myImage2,relief = GROOVE,command = fp,border="0")
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)

se = Button(toolbar2, text="Script Editor",relief = GROOVE,command = fp,border="0")
se.pack(side=LEFT)

el = Button(toolbar2, text="Event List",relief = RAISED,command = fp,border="0")
el.pack(side=LEFT)
toolbar2.pack(side=TOP, fill=X)

##frame
frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("PWB")

## build text box with scrollbar
scrollbar = Scrollbar(frame)
#scrollbar2 = Scrollbar(frame)
textBox = Text(frame,width=35,height=18,yscrollcommand=scrollbar.set)
scrollbar.config(command=textBox.yview)
#scrollbar2.config(command=textBox.xview)
scrollbar.pack(side=RIGHT, fill=Y)
#scrollbar2.pack(fill=X)
textBox.pack(fill=BOTH,expand=2)

#############################################################
#############################################################
#############################################################
## Version 0.01 code 2004-02-04
#############################################################
#############################################################
## begin program

__init__() 			## buile data
root.mainloop()


