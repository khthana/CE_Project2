import ftplib

file = 'sousa.au'
site = '161.246.10.21'
dir = 'Photo'

def putfile(file=file, site=site, dir=dir, user=(), verbose=1) :
	if verbose : print 'Uploading ',file
	local = open(file, 'rb')
	remote = ftplib.FTP(site)
	apply(remote.login, user)
	remote.cwd(dir)
	remote.storbinary('STOR ' + file, local, 1024)
	remote.quit()
	local.close()
	if verbose : print 'Upload done.'

if __name__ == '__main__' :
	import sys, getpass
	#pswd = getpass.getpass(site + 'pswd?')
	pswd = '58deAB74'
	#putfile(file=sys.argv[1], user=('s4061624', pswd))
	putfile(user=('s4061624', pswd))