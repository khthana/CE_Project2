# 
# Pshg2.py
# 
# Not finished yet.
# Experimental shell like code.
# It can be modified to make standard python Interpreter.
#
# It uses w32c.py for console.
# elog.py is for error logging. You can take them out.
#
# Telion
#

from codict import Codict
import string
import sys
import elog
el=elog.p

from w32c import *

import psh

def Interact(console):
	el("'#### Interact ####'")
	console.bInteract = 1

	sps1="+sps1>"
	sps2="+sps2>"
	
	pp=psh.Psh()
	pp._load()
	prompt=sps1

	pp.pglo['PyT']=locals()['console']
	sys.stdout.write("Python %s on %s\n%s\n" % (sys.version, sys.platform, sys.copyright))
	while 1:
		#el("Interact loop")
		cmd=input(prompt)
		if not cmd: continue
		if cmd[:len(prompt)] == prompt:
			cmd=cmd[len(prompt):]
		if cmd=="quit":
			if input("Quit? (yY=yes/Else=no)")[0] in "yY":
				return
		try:
			cl=pp.pcmd(cmd)
			pp.pcm(cl)
		except:
			pp.pf=0
			import traceback
			exc_type, exc_value, exc_traceback = sys.exc_info()
			l = len(traceback.extract_tb(sys.exc_traceback))
			#print "l=",l,
			try: 1/0
			except:
				m = len(traceback.extract_tb(sys.exc_traceback))
			#print ", m=",m
			traceback.print_exception(exc_type,
				exc_value, exc_traceback, l-m)

	DestroyWindow(console.hwnd);

	if 0:
		#try:
		#	exec codeText
		#except:
		#	print "ERROR %%"
		#	traceback.print_exc()

		#if not codeText: continue
		
			# print "\nDebug="+repr(w32c.currentBlockItems[0])
			try:
				codeOb = code.compile_command(codeText)
			except SyntaxError:
				sys.stdout.write("\n")
				list = traceback.print_exc(0)
				sys.stdout.write(sps1)
				continue
			except:
				traceback.print_exc()
				continue

			if codeOb is None:
				sys.stdout.write("\n%s" % sps2)
				continue
			sys.stdout.write("\n")

			#SetCursor(LoadCursor(0, IDC_WAIT))
			try:
				try:
					exec codeOb in pp.pglo
				except SystemExit:
					break
				except:
					exc_type, exc_value, exc_traceback = sys.exc_info()
					l = len(traceback.extract_tb(sys.exc_traceback))
					try: 1/0
					except:
						m = len(traceback.extract_tb(sys.exc_traceback))
					traceback.print_exception(exc_type,
						exc_value, exc_traceback, l-m)
			finally:
				SetCursor(LoadCursor(0, 0))
				
			sys.stdout.write(sps1)

def main():
	startwin(Interact)
