'''
    2004/03/10
    modify from main.py->filter()
    used by menu->testScript
    to run test SCript( check only not compile )
    
'''


def testscript(allLines) :
	global ERROR_IN_FILTER
	ERROR_IN_FILTER = False
	#print "filter..."
	tab = [0]
	loop = [""]
	state = 1
	loop_command = ['if','while','for','def','elif','else','repeat']
	script = ""
	scriptList=[]
	brace_stack = []
	for line in allLines :
		#print "line : ",line
		tab_count = 0
		for char in line :
			if char == "\t" :
				tab_count = tab_count + 1
			elif char == " " :
				ERROR_IN_FILTER = True
				break
			else : break
		if "\n" in line :
			line = line.replace("\n",";\n")
		else : line = line + ";"
		line = line.replace("\t","")
		token = line.split(" ")
		if state == 1 :
			if tab_count > tab[len(tab)-1] :
				ERROR_IN_FILTER = True
				break
			elif tab_count < tab[len(tab)-1] :
				if (line[0] == "}") :
					if (tab_count != tab[len(tab)-2]) :
						ERROR_IN_FILTER = True
						break
					else : script = script + "}"
					brace_stack.pop()
					tab.pop()
				else :
					tab.pop()
					while tab_count < tab[len(tab)-1] :
						script = script + "}"
						tab.pop()
						loop.pop()
					if tab_count == tab[len(tab)-1] :
						script = script + "}"
					else :
						ERROR_IN_FILTER = True
						break
			if tab_count == tab[len(tab)-1] :
				if token[0] in loop_command :
					state = 2
					if (loop[len(loop)-1] == "if") and (token[0] in ["else","elif"]):
						script = script + line
					elif tab_count != 0 :
						loop.pop()
						loop.append(token[0])
						script = script + line
					elif tab_count == 0 :
						if script != "" : scriptList.append(script)
						loop.pop()
						loop.append(token[0])
						script = line
				elif line[0] == "{" :
					state = 3
					if tab_count == 0 :
						if script != "" : 
							scriptList.append(script)
							script = ""
					script = script + "{"
				elif tab_count == 0 :
					if token[0] == "until" :
						script = script + line
						scriptList.append(script)
						script = ""
					elif script != "" :
						scriptList.append(script)
						script = ""
						if line[0] != "}" : scriptList.append(line)
					else : scriptList.append(line)
				elif line[0] == "}" : pass
				else : script = script + line
			else :
				ERROR_IN_FILTER = True
				break
		elif state == 2 :
			if tab_count <= tab[len(tab)-1] :
				ERROR_IN_FILTER = True
				break
			else :
				tab.append(tab_count)
				if token[0] not in loop_command :
					if line[0] == "{" :
						state = 3
						line = ""
					else : state = 1
				else : loop.append(token[0])
			script = script + "{" + line
		elif state == 3 :
			if tab_count <= tab[len(tab)-1] :
				ERROR_IN_FILTER = True
				break
			else :
				tab.append(tab_count)
				brace_stack.append("{")
				if token[0] in loop_command : 
					state = 2
					loop.append(token[0])
				elif line[0] != "{" : state = 1
				else : line = "{"
			script = script + line
			
	if (len(tab)>1) :
		brace_num = len(tab)-1
		brace = ""
		for count in range(brace_num) :
			brace = brace + "}"
		script = script + brace
		scriptList.append(script)
		
	return ERROR_IN_FILTER





#filter("print('aa')\n\tprint('as')")
