color :: c2
address :: 3 Lamblatiw rd. Ladkrabang Bangkok
email :: aaa@kmitl.ac.th
name :: KMITL
telephone :: 00
