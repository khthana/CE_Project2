import Tkinter 

class Table(Tkinter.Frame): 
    "creation dans une frame d un tableau " 
    def __init__(self, root=None, rowheader_width=1, rowheader_color='blue',  columnheader_width=3, columnheader_color='red', **kw ): 
        apply(Tkinter.Frame.__init__, (self,root), kw) 
        self['background']='white' 


        self.frame_left=Tkinter.Frame(self) 
        self.frame_center=Tkinter.Frame(self) 
        self.frame_right=Tkinter.Frame(self) 
        
        self.rowheader=Tkinter.Text(self.frame_center, wrap="none", height=rowheader_width, foreground=rowheader_color, font=('Terminal')) 
        self.corner=Tkinter.Text(self.frame_left, width=columnheader_width, height=rowheader_width, foreground=columnheader_color,font=('Terminal')) 
        self.corner2=Tkinter.Label(self.frame_left, height=1) 
        
        self.text=Tkinter.Text(self.frame_center, wrap="none",font=('Terminal')) 
        self.columnheader=Tkinter.Text(self.frame_left, wrap="none", width=columnheader_width, foreground=columnheader_color,font=('Terminal')) 
        
        self.scrollY=Tkinter.Scrollbar(self.frame_right, orient='vertical', command=self.text.yview) 
        self.scrollX=Tkinter.Scrollbar(self.frame_center, orient='horizontal', command=self.text.xview) 

        self.text["xscrollcommand"]=self.scrollX.set 
        self.text["yscrollcommand"]=self.scrollY.set 

        self.rowheader["xscrollcommand"]=self.scrollX.set 
        self.rowheader["yscrollcommand"]=self.scrollY.set 

        self.columnheader["xscrollcommand"]=self.scrollX.set 
        self.columnheader["yscrollcommand"]=self.scrollY.set 



        self.frame_left.pack(side='left',fill='both', expand=0) 
        self.corner.pack(side='top',fill='both', expand=0) 
        self.columnheader.pack(side='top',fill='both', expand=1) 
        self.corner2.pack(side='top',fill='both', expand=0) 
        
        self.frame_center.pack(side='left', fill='both', expand=1) 
        self.rowheader.pack(side='top', fill='both', expand=0) 
        self.text.pack(side='top', fill='both', expand=1) 
        self.scrollX.pack(side='top',fill='both', expand=0) 
        
        self.frame_right.pack(side='left', fill='both',expand=0) 
        self.scrollY.pack(side='top', fill='both', expand=1) 

root=Tkinter.Tk() 
c=Table(root) 
c.pack(fill='both', expand=1) 
root.mainloop() 
