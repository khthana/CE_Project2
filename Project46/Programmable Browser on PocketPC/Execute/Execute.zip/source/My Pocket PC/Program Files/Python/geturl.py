import os
import urllib
Version = '1.5'
tarname = 'test.html'

remoteaddr = 'http://www.settrade.com/S13_FastQuote.jsp?txtBrokerId=IPO&txtSymbol=AA'
print 'Downloading... ', remoteaddr

remotefile = urllib.urlopen(remoteaddr)
localfile = open(tarname, 'wb')
localfile.write(remotefile.read())
localfile.close()
remotefile.close() 