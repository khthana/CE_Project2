

import sys, string
from open_url import open_web


print "OPEN WWW.GOOGLE.COM /n"

op = open_web()
string = op.open(url="http://www.google.com/index.html")

print string
