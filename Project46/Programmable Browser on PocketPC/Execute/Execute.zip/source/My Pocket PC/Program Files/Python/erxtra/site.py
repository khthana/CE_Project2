# dummy site.py

import sys
if 1:
	sys.stderr = open('py-stderr.txt','ab')
	sys.stdout = open('py-stdout.txt','ab')

#from win32gui import *

TEXT = Unicode

print "starting dummy site.py in memcard2-python22"

#import sys
#sys.path=['','\\memcard2\\Pyce-Files', '\\Memcard2\\Python22\\Lib', '\\Memcard2\\Python22\\dynwin', '\\My documents']

print "site.py END"
