import sys
fname = '\Program Files\Python\my.txt'
try:
	file = open(fname, 'r')
	while 1:
		line = file.readline()
		print line
		if line =='':
			break
		
	#line = file.readline()
	#print "line 1:",line
except IOError, (code, why):
	print "python: can't open %s: %s\n" % (fname, why)
	bKeepOpen = 1
	file = None





