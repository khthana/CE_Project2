'''   
## 2004/01/23
## 2004/02/04
## chang implement for project
## chang __init function to recive userprofile from main program
## and add,change many
## 2004/02/05
## add function loadallmaill() and  self.loadallmaill
## fixbug
## 2004/03/15
## print correctly
## 2004/03/17
## fixbug : change used mailsavepath from mail.profile to used from config.py <global mailsavepath>
##          but have the same problem in used in CL lanfuage  dose not chang.
            Still used mailsavepath from mail.profile 
'''

import poplib, rfc822, string, StringIO
import sys, getpass
from config import *
from getuserprofile import getuserprofile


class mypopmail:

    def __init__(self):
        
        #print 'mypopmail.__init__()'
        self.upfd={}
        self.upf=getuserprofile()
        self.upf.getuserpf('mail.profile',self.upfd)

        self.addrdict={}
        self.upf.getuserpf('contact.profile',self.addrdict)
        
        #print ' show upfd from mypopmail'
        #for k,v in self.upfd.items():
        #    print str(k)+" : "+str(v)
            
        #for k,v in self.addrdict.items():
        #    print str(k)+" : "+str(v)            
        #print 'self.addrdict=',self.addrdict
        
        global mailsavepath
        self.mailserver = self.upfd['mailserver']
        self.mailuser   = self.upfd['mailuser']
        self.mailpaswd = self.upfd['mailpaswd']
        self.mailsavepath = mailsavepath #self.upfd['mailsavepath']
        self.mailfilename = self.upfd['mailfilename']
        
        self.read = {}  # for store had read mail
        self.mail = {}  # for store current mail
        self.allmail = {} #for store all mail
        self.headermail = {} # stor  mail header ('From', 'Date', 'Subject')
        self.allheadermail = {} # stor all mail header ('From', 'Date', 'Subject')
        self.toDelete = []
        #self.welcomemsg='NOT CONNECTED'
        self.status = {'welcomemsg':'NOT CONNECTED','msgCount':0,'bytes':0}

        ## mailserver :: pop.163.com     
        ## mailuser   :: h_chakrit@163.com
        ## mailpaswd :: kritnum
        ## mailsavepath :: C:\PythonCE\userprofile\mail\
        ## mailfilename :: mail.txt

    def getmailserver(self):
        return self.mailserver

    def setmailserver(self,mailserver):
        self.mailserver=mailserver

    def getmailuser(self):
        return self.mailuser

    def setmailuser(self,mailuser):
        self.mailuser=mailuser

    def getmailpaswd (self):
        return self.mailpaswd

    def setmailpaswd(self,mailpaswd):
        self.mailpaswd=mailpaswd

    def getmailsavepath(self):
        return self.mailsavepath

    def setmailsavepath(self,mailsavepath):
        self.mailsavepath=mailsavepath

    def getmailfilename(self):
        return self.mailfilename

    def setmailfilename(self,mailfilename):
        self.mailfilename=mailfilename

    def getallmail(self):
        return self.allmail
        
    def setallmail(self,dict):
        self.allmail = dict

    def getallheadermail(self):
        return self.allheadermail
        
    def setallheadermail(self,dict):
        self.allheadermail = dict

    def getstatus(self):
        return self.status
    
    def getaddrdict(self):
        #for k,v in self.addrdict.items():
        #    print str(k)+" : "+str(v) 
        return self.addrdict

    def connect(self):
        print 'Connecting...',self.mailserver
        self.server = poplib.POP3(self.mailserver)
        self.server.user(self.mailuser)         # connect, login to mail server
        self.server.pass_(self.mailpaswd)       # pass is a reserved word
        self.status['welcomemsg'] = self.server.getwelcome()   # save returned greeting message
        (self.status['msgCount'], self.status['msgBytes']) = self.server.stat()
        ##print 'There are', self.msgCount, 'mail messages in', self.msgBytes, 'bytes'
        return self.server

    def loadmail(self,mailat):
        if mailat>0 & mailat<=self.status['msgCount']:
            try:
                self.end=0
                #print self.server.list()
                #print 'Retrieving:',
                (self.hdr, self.message, self.octets) = self.server.retr(mailat)      # save text on list
                #print 'RRR--->',self.hdr
                self.message = string.join(self.message, '\n')
                self.strfile = StringIO.StringIO(self.message)     # make string look like a file
                self.msghdrs = rfc822.Message(self.strfile)    # parse mail headers into a dict
                #print '%d:\t%d bytes' % (mailat, len(self.message))
                for self.hdr in ('From', 'Date', 'Subject'):
                    try:
                        self.mail[self.hdr] = self.msghdrs[self.hdr]
                        self.headermail[self.hdr] = self.msghdrs[self.hdr]
                        #print '\t%s=>%s' % (self.hdr, self.msghdrs[self.hdr])
                        self.end = self.message.find(self.msghdrs[self.hdr])
                    except KeyError:
                        #print '\t%s=>(unknown)' % self.hdr
                        pass
                self.read[mailat] = self.message  # store all data for save and pare again
                self.message = self.message[self.end+1:]
                #print '^'*70
                #print self.message
                self.mail['data'] = self.message
            finally:
                return self.mail,self.headermail
        else:
            temp={'From':'NO', 'Date':'NO', 'Subject':'NO', 'data':'No'}
            temp2={'From':'NO', 'Date':'NO', 'Subject':'NO'}
            return temp,temp2

    def pfiletomail(self,file):
        #print 'parfiletomail()->',file
        msghdrs = rfc822.Message(file)    # parse mail headers into a dict
        #print '%d:\t%d bytes' % (mailat, len(self.message))
        message = file.read()
        mail= {}
        end = 0
        for hdr in ('From', 'Date', 'Subject'):
            try:
                mail[hdr] = msghdrs[hdr]
                end = message.find(msghdrs[hdr])
                #print '\t%s=>%s' % (self.hdr, self.msghdrs[self.hdr])
            except KeyError:
                mail[hdr] = 'unknown'
                #print '\t%s=>(unknown)' % hdr
        mail['data'] = message[end+1:]
        return mail
        


    def loadallmail(self):
        ''' get all mail in server to self.allmail{}'''
        self.connect()
        for mailat in range(self.status['msgCount']):
            self.mail={}
            self.headermail={}
            self.allmail[mailat],self.allheadermail[mailat] =self.loadmail(mailat+1)
            #print '%'*80
            #print self.allmail[mailat]
            #print '%'*80
            #print self.allheadermail[mailat]
        self.server.quit()
        #print '/'*80
        #print self.allheadermail
        #return self.allmail,self.allheadermail

    def savemessage(self,mailat,filename=''):
        if filename=='':
            filename = self.mailfilename
        if mailat in (self.read.keys()):
            #print 'save message ...'
            self.file = open(self.mailfile+filename,'a')
            self.file.write('\n\n'+'#'*80+'\n'+'-'*80+'\n'+self.read[mailat]+'\n')
            self.file.close()
        else:
            #print 'Retrieving message ...'
            self.loadmail(mailat)
            self.savemessage(mailat)
            
    def deletemail(self,mailat):
        if (1 <= mailat <= self.status['msgCount']) and (mailat not in self.toDelete):
            #print 'Detete message number ',mailat
            self.toDelete.append(mailat)
        else:
            #print 'Bad message number'
            t=1
        #try:
        #    print 'Deleting messages from server.'
        #    self.server.dele(mailat)                 # mbox locked until quit()
        #finally:
        #     print 'Deleted'
        
    def deleteallmail(self):
        #print 'To be deleted:', self.toDelete
        self.connect()
        try:
            #print 'Deleting messages from server.'
            for msgnum in self.toDelete:                 # reconnect to delete mail
                self.server.dele(msgnum)                 # mbox locked until quit()
        finally:
            self.clearparameter()
            self.server.quit()

    def clearparameter(self):
        #print 'mypopmail.clearparameter()'
        self.read = {}  # for store had read mail
        self.mail = {}  # for store current mail
        self.allmail = {} #for store all mail
        self.headermail = {} # stor  mail header ('From', 'Date', 'Subject')
        self.allheadermail = {} # stor all mail header ('From', 'Date', 'Subject')
        self.toDelete = []
        #self.welcomemsg='NOT CONNECTED'
        self.status = {'welcomemsg':'NOT CONNECTED','msgCount':0,'bytes':0}
        self.toDelete = []
        
    def quit(self):
        self.server.quit()
        #print 'server.quit()'
            


#######################################################
##   test class section
#######################################################
'''from getuserprofile import getuserprofile
upfd={}
upf=getuserprofile()
upf.getuserpf('mail.profile',upfd)
a=mypopmail(upfd)
a.connect()
c=a.loadmail(1)
print '*'*50
print c
print '-'*50
for i,j in c.items():
    print i + " -> " + j
'''
#######################################################