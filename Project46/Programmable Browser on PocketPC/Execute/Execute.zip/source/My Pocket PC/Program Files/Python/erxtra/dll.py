#
# Wrapper classes for calldll module
#
#  ####   Dll class is undergoing modification, and it does not work.
#  ####   Please use Dllfunc class in the middle of this file.
#
# Usage:
# 	from dll import Dll
# 	yourdll = Dll('dllname','funcname','FORMAT_STRING', 'RESULT_F_STRING', args)
#
# 	FORMAT_STRING and RESULT_F_STRING will be feeded to PyArgParseTuple.
# 	So, use the format accepted in PyArgParseTuple.
#
# Example (There are many others);
# 	s:string or unicode object -> string
# 	u:unicode object -> unicode string (Wide Char)
# 	i:int
# 	es:doesn't work in CE?
#
# At the moment of creation, you can skip all arguments.
# This will create empty vanila Dll object.
# Later, you can load Dll by; 
# yourdll.load('dllname')
#
# Or, you can specify just dllname at start up.
#
# Then, you can call object for functions;
# yourdll('funcname','FORMAT_STRING', 'RESULT_F_STRING', args)
#
#
# Or you can specify dllHandle of already loaded dll in dllname.
# This provision is mostly for Dllfunc class
#
# Typical example in CE
#
# from dll import Dll
# core = Dll('coredll') # equivalent of stdlib, or kernel32 in other win32 ?
# print core('strlen','s','i','I wanna know my length')
#
#
# Optional features
#
# You can turn on debug print by;
# 	yourdll.setdebug()
# Turn it off by;
# 	yourdll.setdebug(0)
#
# You can turn on error raising by;
# 	yourdll.setraise() # it is set by default at initialization
# Turn it off by;
# 	yourdll.setraise(0)
#
# Use this module and calldll with caution.
# If you supply calldll.call_foreign_function() with wrong proc_address,
# Python will crash and disappear (It wouldn't crash CE itself in most cases).
# I put safegurd against this by always calling get_proc_address
# before to call function for normal use.
# This way,you cannot call bogus proc_address from this module.
# But this slows down things when you want to call same function
# successicely.
# If you want call same function again and again, use again() method
#
# Example:
#
# from dll import Dll
# core = Dll('coredll') # equivalent of stdlib, or kernel32 in other win32?
# print core('strlen','s','i','I wanna know my length')
# print core.again('How about this one?')
#
# Or, use Dllfunc class derived from Dll class (at the end of this file).
#
#
# At this moment, to call win32api with pointers for output buffer,
# I think you can use array module.
# I will check membuf related functions in calldll later, and
# invent a system to make life easier for calling win32api.
#
# 01/11/18 12:05 by Telion
#
# By the way, as the result of debuging stupid mistakes, I put many debug prints.
# Remove them to make it lean if you wish.
# I don't remove them by myself because last time I cleaned code for
# other people, I didn't do good job.(A few people's Python was stack as result)
#

#######
#
# 02/09/02 19:41
#
# __call()__ function of Dll class is under reconstruction,
# and it does not work right now.
#
# Please use Dllfunc class instead.
# 

import calldll
if hasattr(calldll,'strptr'):
	havestrptr=1
else:
	havestrptr=0

#try:
#	import reflect
#except:
#	havereflect=0
#else:
#	havereflect=1
havereflect=0

dllcache={}

class TDebug:
	def __init__(self):
		self.dbg = None # no initial debugging print
		self.er = 1 # raise errors
	def setdebug(self, onoff=1): # debug() for ON, debug(0) or debug(None) for OFF
		self.dbg = onoff
		if self.dbg:
			print "Dll debug ON"
		else:
			print "Dll debug OFF"
	def setraise(self, onoff=1): # debug() for ON, debug(0) or debug(None) for OFF
		self.er = onoff
		if self.er and self.dbg:
			print "Dll debug ON"
		elif (not self.er) and self.dbg:
			print "Dll debug OFF"
	
class Dll (TDebug):
	def __init__(self,dll):
		TDebug.__init__(self)
		self.dll = dll
		self.hdll = None
		self.func = self.gpa
		if type(dll)==type('') and dll:
			if self.dbg:
				print "__init__(): str dll =", dll
			if self._load(dll):
				if not dllcache.has_key(dll):
					dllcache[dll]=self.hdll
		else:
			raise TypeError, dll+" __init__()"

	def _load(self, dll):
		if self.dbg:
			print "dll =",dll
		if dll:
			self.dll = dll
			self.hdll = calldll.ll(dll)
			if self.dbg:
				print "load(): self.hdll =",self.hdll
			if (not self.hdll) and self.er:
				raise "calldll.load_library Error", dll
			return self.hdll

	def gpa(self, func):
		if self.dbg:
			print "Dll.gpa(): hdll=",self.hdll,", func=",func
		if (not self.hdll) and self.er:
			raise "Dll.No_dll_loaded Error", func
		if func:
			self.func = func
			self.pa = calldll.get_proc_address(self.hdll,func)
			if self.dbg:
				print "Dll.gpa(): calldll returned self.pa=",self.pa
			if (not self.pa) and self.er:
				raise "calldll.get_proc_address Error", func
			return self.pa

	def __del__(self):
		calldll.free_library(self.hdll)

	def __call__(self,*args):
		if self.dbg:
			print "__call__()"
		if not args:
			return self.hdll
		



############
#
# Dllfun CLass
#
# Usage:
#
# from dll import Dllfunc
# yourfunc = Dllfunc('dllname','funcname','FORMAT_STRING','RESULT_F_STRING')
# yourfunc(argtuple)
#
# 	FORMAT_STRING and RESULT_F_STRING will be feeded to PyArgParseTuple.
# 	So, use the format accepted in PyArgParseTuple.
# Example (There are many others);
# 	s:string or unicode object -> string
# 	u:unicode object -> unicode string (Wide Char)
# 	i:int
# 	es:doesn't work in CE?
#
#
#
# Or you can specify dllHandle of already loaded dll in dllname.
#
# Example:
#
# from dll import Dllfunc
# strlen_clone = Dllfunc('coredll','strlen','s','i')
# print strlen_clone('How long is this?')
#
# atoi_clone = Dllfunc(strlen_clone.hdll,'atoi','s','i')
# xx = atoi_clone('234')+atoi_clone('635')
# 
# printf_clone = Dllfunc('coredll'),'printf','s','i')
#
# ### NOTE ###
# Use it with caution. Many functions (especially win32api) take
# pointer for the output buffer.
# You can  do this by array module, but you have to make sure
# that there is enough length to store the value.
# Becareful with the strings. 
# Unicode strings can be double the length of ascii.
# utf-7,8 and other may be even longer
#
# This class is for the ease of the use. Not for the speed.
# Use calldll directly for the speed, or make extension module.
#

import struct
import string,sys

class Dllfunc(Dll):
	def __init__(self, dll, func, fsl, rs):
		#print "Dllfunc.__init__(): dll=",dll,", func=",func,", fsl=",fsl,", rs=",rs
		self.dbg = None # no initial debugging print
		#self.dbg = 1 # 
		self.er = 1 # raise errors
		if self.dbg:
			print "Dll.__init__(): dll=",dll,", func=",func,", fsl=",fsl,", rs=",rs,", args=",args
		if type(dll)==type(0):
			self.hdll=dll
		else:
			Dll.__init__(self,dll)

		self.func = func
		self.pa = None
		self.fsl = fsl
		self.rs = rs
		self.args = None
		self.result = None
		self.outarg={} # the list of args returned
		self.ptrarg=[] # the list of args that will be modified to pointer
		if func and fsl and rs and self.gpa(func):
			self.setfsl(fsl,rs)

	def setfsl(self,fsl,rs):
		if not self.pa:
			return
		else:
			fsl2=[]
			# fsl format is same as sungle item in format string for PyArg_ParseTuple,
			# plus  "& (s|z|u|i) [ > [nnnn] ]" which gives pointer to the string, (or
			# object converted into string in case of "i") as an arg.
			# If optional ">" is present, readwrite buffer will be created,
			# then arg value is copied on it to pass for the function.
			# After the function call, values will be taken from the buffer
			# and retruned as a result tuple.
			i=0
			for fsi in fsl:
				if fsi[0] =="&": # support for arg by pointer  
					fsl2.append('i') 
					if len(fsi) > 2 and fsi[2]==">": 
						# this arg is for output ==> create buffer fot it
						if len(fsi)>3:
							self.outarg[i]=int(fsi[3:])
						else:
							try:
								self.outarg[i]=struct.calcsize(fs1[1]) # unspecified
							except:
								self.outarg[i]=0 # need to be specified later
					else:
						self.ptrarg.append(i) # this arg is for input.
				else:
					fsl2.append(fsi)
				i=i+1
			self.fs = string.join(fsl2,'') # space is not permitted in format string?


	def __call__(self, *args):
#		if havereflect:
		if 0:
			self.anames = reflect.argsetl()
		else:
			self.anames=[]
		self.exargs=args
		self.args=list(args)
		if self.dbg:
			print "pa=",self.pa, ", fsl=",self.fsl,", rs=",self.rs,", args=",args
			print self.anames
		for i in self.ptrarg:
			if havestrptr:
				self.args[i]=calldll.strptr(args[i])
			else:
				self.args[i]=id(args[i])+28 # It also works in PythonCE22
		i=0
		for a in args:
			if hasattr(a,'address'): # membuf object, cstruct object
				self.arg[i]=a.address
			elif hasattr(a,'buffer_info'): # array
				self.arg[i],r=a.buffer_info()
#			elif 
			i = i +1
		self.mbd={}
		#print self.args
		for k,v in self.outarg.items():
			a=args[k]
			 # determin the required length of buffer
			l=v
			if type(a)==type(''): # if it's string, use the length of it
				l=len(a)
			else:
				if self.er:
					raise "Dllfunc.Wrong arg type, __call__():", args
				return None
			if not l:
				if self.er:
					raise "Dllfunc.Output arg length not set, __call__():", args
				return None
			self.mbd[k]=calldll.membuf(l) # create temporary memory buffer
			self.mbd[k].write(struct.pack(self.fsl[k][1],args[k])) 
			self.args[k]=self.mbd[k].address() # give it by address
			#print "self.mbd:",self.mbd
			#print "args:",self.args
			
		r = calldll.call_foreign_function(self.pa,self.fs,self.rs,tuple(self.args))
		self.result = [r]
		#print "result:",r
		for k in self.outarg.keys():
			#print self.fsl[k], 
			#print self.fsl[k][1], 
			#print self.mbd[k].read()
			if self.fsl[k][1] in "sz":
				s=str(self.mbd[k].size())+self.fsl[k][1]
			else:
				s=self.fsl[k][1]
			r,=struct.unpack(s,self.mbd[k].read())
			#print k, r
			self.result.append(r)
		
		if len(self.result)==1:
			return self.result[0]
		return self.result

	def format(self, fs, rs=None):
		self.fs=fs
		if rs:
			self.rs=rs
	
	def dump(self):
		print "self.dbg =", self.dbg
		print "self.er =", self.er
		print "self.dll =", self.dll
		print "self.hdll =", self.hdll
		print "self.func =", self.func
		print "self.pa =", self.pa
		print "self.fs =", self.fs
		print "self.fsl =", self.fsl
		print "self.rs =", self.rs
		print "self.exargs =", self.args
		print "self.args =", self.args
		print "self.ptrarg =", self.ptrarg
		print "self.outarg =", self.outarg
		print "self.result =", self.result

def makefs(o):
	if type(o)==type(''): fs='s'
	elif type(o)==type(0): fs='i'
	elif type(o)==type(0.1): fs='f'
#
# Convert string or int into membuf object.
# It can be referenced by address (pointer) and modified by C functions
#
class Byref: 
	def __init__(self,a):
		#print "Byref init"
		if not a:
			raise "Byref: Error arg not valid",a
		r=[]
		if type(a)==type(''):
			l=len(a)
			v=a
		elif type(a)==type(0):
			l=4
			v=struct.pack('i',a)
		m=calldll.membuf(l)
		m.write(v)
		for attr in dir(m): # inherit membuf it...
			if attr[:1]=="__": continue # skip __init__, etc
			self.__dict__[attr]=eval("m."+attr)
		self.address = self.address() # use this as a variable, not function
		self.size=l # this one too
		self.type=type(a)
		self.data=a

	def __call__(self):
		if self.type ==type(''):
			return self.read()
		
import array
class xArray: # array object with 
	def __init__(self,fs,a):
		o=array.array(fs,a)
		self.address,r=o.buffer_info()
		alist=dir(o)
		for attr in alist: # inherit array it...
			self.__dict__[attr]=eval("o."+attr)


