
import time

class mycalendar:
    
    def __init__(self):
        ATTODAY=''
        ## 'Tue Mar 16 20:55:11 2004'
        #if ATTODAY == '':
        #ATTODAY=time.ctime(time.time())
        #print 'Today:'+str(ATTODAY)
        ATTODAY='Tue Mar 16 20:55:11 2004'
        self.ATTODAY=ATTODAY.split()
        
        #print self.ATTODAY

        ## (2004, 3, 16, 20, 55, 41, 1, 76, 0)
        #self.YMD=time.localtime(time.time())
        self.YMD = (2004, 3, 16, 20, 55, 41, 1, 76, 0)

        self.weekday = {'Sun':0,'Mon':1,'Tue':2,'Wed':3,'Thu':4,'Fri':5,'Sat':6}
        self.rweekday = {0:'Sun',1:'Mon',2:'Tue',3:'Wed',4:'Thu',5:'Fri',6:'Sat'}
        self.month = {1:'Jan',2:'Feb',3:'Mar',4:'Apr',5:'May',6:'Jun',7:'Jul',8:'Aug',9:'Sep',10:'Oct',11:'Nov',12:'Dec'}
        self.rmonth = {'Jan':1,'Feb':2,'Mar':3,'Apr':4,'May':5,'Jun':6,'Jul':7,'Aug':8,'Sep':9,'Oct':10,'Nov':11,'Dec':12}
        self.startdateofmounth ={0:0,1:0,2:0,3:0,4:0,5:0,6:0,7:0,8:0,9:0,10:0,11:0,12:0,13:31}
        #this year [4,0,1,4,6,2,4,0,3,5,1,3]
        self.calendar={0:31,1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31,13:31}
        if(self.YMD[0]%4==0 and (self.YMD[0]%100!=0 or self.YMD[0]%400==0)):
            self.calendar[2]=29
        
        self.cliv=[]
        
        # make calendar of one year        
        self.weekday[self.ATTODAY[0]]
        startday = abs(self.weekday[self.ATTODAY[0]]-(int(self.ATTODAY[2])%7))
        thisMstart = abs(self.weekday[self.ATTODAY[0]]-(self.YMD[2]%7))+ 1
        tempstart=thisMstart
        self.startdateofmounth[self.YMD[1]]= thisMstart
        for i in range(self.YMD[1],13):
            start=(tempstart+self.calendar[i])%7
            #print str(i)+' -> '+str(tempstart)+'+'+str(self.calendar[i])+'  cal'+str(i)+':'+str(start)
            tempstart=start
            self.startdateofmounth[i+1]=start
            
        for i in range(self.YMD[1]-1,0,-1):  #  i  =  2, 1
            strd=abs((self.startdateofmounth[i+1]-self.calendar[i])%7)
            self.startdateofmounth[i]=strd
            #print str(i)+' -> '+str(strd),'   ',self.startdateofmounth[i+1],self.calendar[i]

        #print '@'*70
        #for kk in self.startdateofmounth.keys():
            #print str(kk)+':'+str(self.startdateofmounth[kk])

        ## (2004, 3, 21, 3, 30, 1, 6, 81, 0)
        self.REALTODAYNUM =time.localtime(time.time())
        print self.REALTODAYNUM
        T_CU_DATE=self.rweekday[((self.REALTODAYNUM[2]%7)-1+self.startdateofmounth[self.REALTODAYNUM[1]])%7]
        print 'CU_DATE :'+T_CU_DATE
        
        ## 'Tue Mar 16 20:55:11 2004'
        self.REALTODAYTEXT =T_CU_DATE+' '+self.month[self.REALTODAYNUM[1]]+' '+str(self.REALTODAYNUM[2])+' '+str(self.REALTODAYNUM[3])+':'+str(self.REALTODAYNUM[4])+':'+str(self.REALTODAYNUM[5])+' '+str(self.REALTODAYNUM[0])
        self.REALTODAYTEXT=self.REALTODAYTEXT.split()
        print self.REALTODAYTEXT

        
    def getctime(self,list):
        print  'getctime()'
        ## (2004, 3, 21, 3, 30, 1, 6, 81, 0)
        L_REALTODAYNUM =list #time.localtime(time.time())
        #print L_REALTODAYNUM
        L_T_CU_DATE=self.rweekday[((L_REALTODAYNUM[2]%7)-1+self.startdateofmounth[L_REALTODAYNUM[1]])%7]
        #print 'CU_DATE :'+L_T_CU_DATE
        ## 'Tue Mar 16 20:55:11 2004'
        L_REALTODAYTEXT =L_T_CU_DATE+' '+self.month[L_REALTODAYNUM[1]]+' '+str(L_REALTODAYNUM[2])+' '+str(L_REALTODAYNUM[3])+':'+str(L_REALTODAYNUM[4])+':'+str(L_REALTODAYNUM[5])+' '+str(L_REALTODAYNUM[0])
        L_REALTODAYTEXT = L_REALTODAYTEXT.split()
        return L_REALTODAYTEXT
        

    def builtecalval(self,atmonth):
        cliv=[]#['Mon', 4, 'Mar', '2004', 3]
        for i in range(self.calendar[atmonth]):
            temp=self.rweekday[(i+self.startdateofmounth[atmonth])%7]
            cliv.append([temp,i+1,self.month[atmonth],atmonth,self.ATTODAY[4]])
        self.cliv=cliv
        return self.cliv
        
    def printcliv(self):
        for temp in self.cliv:
            print temp
        

    def getcudate(self):
        ## 'Tue Mar 16 20:55:11 2004'
        return  self.REALTODAYTEXT

    def getcumonthNUM(self):
        ## (2004, 3, 21, 3, 30, 1, 6, 81, 0)
        return self.REALTODAYNUM[1]
    
    def getcudayNUM(self):
        ## (2004, 3, 21, 3, 30, 1, 6, 81, 0)
        return self.REALTODAYNUM[2]
    
    def getcummonthTXT(self):
        return self.REALTODAYTEXT[1]

    
    def getmonthstartdate(self,atmonth):
        return self.startdateofmounth[atmonth]

    def getcumonthandyearTXT(self):
        ## self.ATTODAY = 'Tue Mar 16 20:55:11 2004'
        return  self.REALTODAYTEXT[1]+' '+self.REALTODAYTEXT[4]
    
    def getmonthandyearTXT(self,atmonth):
        ## self.ATTODAY = 'Tue Mar 16 20:55:11 2004'
        return  self.month[atmonth]+' '+self.REALTODAYTEXT[4]
  
    def getdate(self,day,month,year):
        ##['Sun', 18, 'Jan', 1, '2004']
        return [self.rweekday[(day+self.startdateofmounth[month])%7],day,self.month[month],month,self.REALTODAYTEXT[4]]

        
    def findstardofthemounth(day,atdate):
        ''' input a (19,'Thu')'''
        c_atday=weekday[atdate]-rweekday[(day%7)]+1
        c_atdate=rweekday[c_atday]
        return [c_atday,c_atdate]




#cal=mycalendar()

#cal.builtecalval(1)
#cal.printcliv()
#print '&'*50
#print cal.getctime((2004, 3, 31, 3, 30, 1, 6, 81, 0))
#print cal.getctime((2004, 4, 5, 3, 30, 1, 6, 81, 0))
#cal.builtecalval(2)
#cal.printcliv()
#print '&'*50
#cal.builtecalval(3)
#cal.printcliv()