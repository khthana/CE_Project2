# TCP Cli

import httplib
import urllib

class open_web:
    """ return a html file with a input url """

    
    
    def __init__( self ):
        self.name = "open web name"
        print " openWeb  __init__"

    def __name__( self ):
        return " open_web file "

    def open( self, url="" ):
        """ openU """
        print " call openU"

        if url=="":
            #url="http://www.google.com/"
            #url="http://161.246.5.54:8080/index.html"
            url = "http://www.w3.org/MarkUp/"
            
        self.inurl = url
        page =  urllib.urlopen(url)
        
        for key, value in page.headers.items() :
            print key, " = ", value

        tempPage = ""
        while 1:
            line = page.readline()
            tempPage=tempPage + line + "\n"
            if not line:
		break

	return tempPage

    def aa( self ):
        print "aa called"
        
	
"""
 outputfile = open("ounputfile.html","wb")


print page.url,"\n"
#print len(page.read()),"\n"



print " begin input data  \n ---------------------------------------------------------------------------------"	
while 1:
	line = page.readline()

	if line.find("src")!=-1:
		
		listimg = line.split("src");
		for list2 in listimg:
			list3 = list2.split(" ",1) 
			print "\n\n",list3[0]
			

		print line
		print "\n\n"

	outputfile.write(line)
	if not line:
		break


outputfile.close()










#	num = stri.find(key)
#	if num!=-1:
		
		

		
	
	













#url='www.google.com'
#urlpath='/index.html'

#host = httplib.HTTP(url)
#host.putrequest("GET",urlpath)
#host.putheader("Accept","text/html")
#host.endheaders()

#headers host.getreply()
#errcode = 300 
#if errcode != 200:
#	raise RuntimeError
#htmlfile = host.getfile()
#htmlpage = htmlfile.read()

#for line in htmlpage:
#	print line
	
#htmlfile.close()
#return htmlpage


"""
