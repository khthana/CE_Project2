# 
# Psh.py
# 
# I found something called ipython.
# It seems that ipython offers mostly everything I wanted and more.
# 

from codict import Codict
import string
import sys


def start():

	dbg=open('pydbg','w')
	pd=dbg.write
	pp=Psh()
	pp._load()
	prompt="#>"
	while(1):
		cmd=input(prompt)
		if not cmd: continue
		if cmd[:len(prompt)] == prompt:
			cmd=cmd[len(prompt):]
		if cmd=="quit":
			return
		try:
			cl=pp.pcmd(cmd)
			pp.pcm(cl)
		except:
			pp.pf=0
			import traceback
			exc_type, exc_value, exc_traceback = sys.exc_info()
			l = len(traceback.extract_tb(sys.exc_traceback))
			print "l=",l,
			try: 1/0
			except:
				m = len(traceback.extract_tb(sys.exc_traceback))
			print ", m=",m
			traceback.print_exception(exc_type,
				exc_value, exc_traceback, l-m)
			#print "Error"

class Psh (Codict):
	# to do; need better parsing of commandline.
	def __init__(self,fn=None):

		self.pglo={}
		self.multi =1 # enable multiline command support ";"
		self.redirect =1 # enable redirecting stdio ">" ">>" "<"
		self.pipe =1 # enable pipe "|"
		self.ex =1 # enable codict (command, statement extension) support
		self.result=None
		self.has_result=None
		self.had_result=None
		self.si=None
		self.so=None
		self.cw=sys.stdout.write
		self.pf=0
		Codict.__init__(self)
		self.pglo['codict']=self.dict
		self.pglo['pshell']=self
		#print "init done"

	def pcmd(self, cmd): # parse command line
		cm=list(cmd)
		dqf=0 # double quote flag
		sqf=0 # single quite flag
		escf=0
		cl=[]
		ii=0
		i=-1
		end=len(cm)
		while(1):
			i=i+1
			if i >= end: break
			#print i, cm[i],":",sqf,dqf,escf
			cc=cm[i]
			if cc == "\\" and (not (escf or sqf or dqf)):
				#print "ESC \\ "
				if (not dqf) and (not sqf):
					cm.pop(i)
					end=end-1
					i=i-1
				escf=1
				continue
			elif cc == '"' and (not escf):
				#print "DQ",
				if (not dqf) and (not sqf): dqf=1
				else: dqf=0
				escf=0
				continue
			elif cc == "'" and (not escf):
				#print "SQ ",
				if (not sqf) and (not dqf): sqf=1
				else: sqf=0
				escf=0
				continue
			elif sqf or dqf or escf:
				#print " sde, ESCF OFF"
				escf=0
				continue
			elif cc in " ;<>|":
				#print "[ ;<>|]",
				if i>ii:
					cl.append(string.join(cm[ii:i],''))
					#print "cl =",cl[-1],
				if cc != " ":
					cl.append(cm[i])
					#print "clns =",cl[-1],
				ii=i+1
				#print ""
				continue
		cl.append(string.join(cm[ii:i],''))
		return cl

	def pcms(self, cmd):
		cl=self.pcmd(cmd)
		return pcm(cl)

	def pcm(self, cl,glo=None,loc=None): # execute parsed command list
		#print "cmd:=",cmd
		#print cl
		#self.cw(repr(cl)+"\n")
		cml=[]
		if self.multi: # multi enabled?
			while ";" in cl: # multi commands. It works on the commandline.
							# problems in codict codes.
				ci=cl.index(";")
				cml.append(cl[:ci])
				del cl[:ci+1]
			if cml:
				cml.append(cl[:ci])
				self.cw(repr(cml)+"\n")
				for ccl in cml:
					if not ccl:
						coninue
					r=self.pcm(ccl,glo)
				return r
		if self.pipe:
			while "|" in cl: # pipe. Not tested at all
				ci=cl.index("|")
				cml.append(cl[:ci])
				del cl[:ci+1]
			if cml:
				cml.append(cl[:ci])
				self.so=sys.stdout
				self.si=sys.stdin
				pfa=0
				self.pf=1
				for ccl in cml:
					if not ccl:
						coninue
					if not ">" in ccl:
						fn='pshpipe'+repr(pfa)
						sys.stdout=open(fn,'w')
					r=self.pcs(ccl,glo)
					sys.stdout.close()
					si=sys.stdin
					sys.stdin=open(sys.stdout.name,'r')
					si.close()
					pfa = not pfa
				self.pf=0
				r=sys.stdin.read()
				sys.stdout.close()
				sys.stdin.close()
				sys.stdout=self.so
				sys.stdin=self.si
				return r
		return self.pcs(cl,glo) # other


	def pcs(self,cl,glo=None):
		#print "cmdline=",cl,", pf",self.pf
		self.cw("cmdlist="+repr(cl)+"\n")
		if not glo:
			glo=self.pglo
		if not self.pf:
			if self.si:
				sys.stdin=self.si
			if self.so:
				sys.stdout=self.so
			self.so = None
			self.si = None

		if ">" in cl:
			if not self.pf: self.so=sys.stdout
			ci=cl.index(">")
			cl.pop(ci)
			if cl[ci]==">": # append mode
				cl.pop(ci)
				sys.stdout=open(string.strip(cl[ci]),'a')
				try: sys.stdout.seek(0,2)
				except: pass
				self.cw("Redirect stdout,appending to:"+repr(cl[ci])+"\n")
			else: # overwrite
				sys.stdout=open(string.strip(cl[ci]),'w')
				self.cw("Redirect stdout to:"+repr(cl[ci])+"\n")
			cl.pop(ci)
		if "<" in cl:
			if not self.pf: self.si=sys.stdin
			ci=cl.index("<")
			cl.pop(ci)
			sys.stdin=open(string.strip(cl[ci]),'w')
			self.cw("Redirect stdin from:"+repr(cl[ci])+"\n")
			cl.pop(ci)

		self.had_result=self.has_result
		self.has_result=0
		cmd = cl.pop(0)
		argv=cl
		#print "cmd=",cmd,", argv=",argv
		#self.cw( "cmd="+repr(cmd)+", argv="+repr(argv)+"\n")
		#print self.had_result, "Result was", self.result
		if glo.has_key('RV'):
			glo['PRV']=glo['RV']
			glo['RV']=None
		rr = self._exec_ne(cmd,argv,glo)
		if rr > 0:
			self.cw("Codict mode:"+cmd+", "+repr(argv)+"\n")
			if rr:
				self.has_result=1
				self.result=rr
		#self.cw( "return="+repr(rr)+"\n")
		while type(rr)==type(1) and rr < 0: # codict execution
			self.cw( "No Entry in Codict \n")
			#print "Here"
			if not "(" in cmd:
				try: ci=string.find(repr(eval(cmd,glo)),"function")
				except: ci=0
			else:
				ci=0
			if (ci > 0) and argv: # functions can be used like a statement.
							# much easier to type in.
				cmd=cmd+"("+string.join(argv,',')+")"
				self.cw("Function Auto Eval mode:"+cmd+"\n")
				self.result=eval(cmd ,glo)
				if self.result:
					self.has_result=1
				#print "R:",repr(self.result)
				#cm="cmdreturn="+cmd #+";print cmdreturn"
				break
			elif argv:
				#print "Here?"
				cm=cmd+" "+string.join(argv,' ')
				#self.cw("dbg, cm:"+cm+"\n")
			else:
				#print "Or here"
				ci = string.find(cmd,'=')
				if (cmd[:5]=="print") or \
						((ci >= 0 ) and (not cmd[ci+1] in '!=<>')):
					cm=cmd
					#self.cw("dbg, cm:"+cm+"\n")
					self.has_result=0
				else:
					#print "Eval>",
					self.cw("Eval mode:"+cmd+"\n")
					self.result=eval(cmd ,glo)
					self.has_result=1
					#print "R:",repr(self.result)
					#cm="cmdreturn="+cmd #+";print cmdreturn"
					break
			#print "cm=",cm
			#print "out here"
			self.cw("Exec mode:"+cm+"\n")
			exec cm in glo
			break
			#print eval(cm,self.pglo)
		if self.si and (not self.pf):
			sys.stdin=self.si
		if self.so:
			if self.has_result: print self.result
			if not self.pf: sys.stdout=self.so
		#print "HS:",self.has_result
		#print "HD:",self.had_result
		#if 1:
		if self.has_result:
			#print "Result=",
			self.cw(repr(self.result)+"\n")
		return
