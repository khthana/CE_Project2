# tset file on winCE  12/92003
# CK


import sys
fname = '\Program Files\Python\my.py'
try:
	file = open(fname, 'r')
	while 1:
		line = file.readline()
		print line
		if line =='':
			break
		
	#line = file.readline()
	#print "line 1:",line
except IOError, (code, why):
	print "python: can't open %s: %s\n" % (fname, why)
	bKeepOpen = 1
	file = None

# testopen.txt

'''if file:
	try:
		try:
			imp.load_module("__main__", file, fname, imp_params)
		except:
			traceback.print_exc()
			bKeepOpen = 1
	finally:
		file.close()
'''




'''try:
    file = open("Program Files\Python\testopen.txt","r")
    line = file.readline()
    print "line 1:",line
    line = file.readline()
    print "line 2:",line
    line = file.readline()
    print "line 3:",line
        
    print  "object->:" ,file
    
except IOError, message:
    print >> sys.stderr,"File could not open",message
    sys.exit(1)
'''
'''while 1:
    try:
        tinput =raw_input("?")
    except EOFError:
        break
    else:
        print >> file, tinput
        

file.close()
'''
