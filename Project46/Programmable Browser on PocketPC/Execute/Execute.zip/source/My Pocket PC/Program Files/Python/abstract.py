'''
This is a abstract program for CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 24 Nov. 2002, 18:37
================================================
Comment : adding new types,TIME and INTERVAL.
'''

import types
import sys
calendar = {1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}

class AssignStmt:
	def __init__(self,lvalue,assign,value) :
		self.type = "assignstmt"
		self.lvalue = lvalue
		self.assign = assign
		self.value = value

	def fork(self,obj):
		if obj.type == "int":
			result = IntNum(obj.value)
		elif obj.type == "long":
			result = LongNum(obj.value)
		elif obj.type == "float":
			result = FloatNum(obj.value)
		elif obj.type == "complex":
			result = ComplexNum(obj.value)
		elif obj.type == "list":
			temp = []
			for i in range(len(obj.value)) :
				x = self.fork(obj.value[i])
				temp.append(x)
			result = List(temp)
		elif obj.type == "string":
			result = String(obj.value)
		elif obj.type == "tp":
			result = Point(obj.value)
		elif obj.type == "td" :
			result = Duration(obj.value)
		elif obj.type == "ti" :
			result = Interval(obj.value[0], obj.value[1])
		return result

class EventAction :
	def __init__(self,event,action) :
		self.type = "event_action"
		self.event = event
		self.action = action

class Event :
	def __init__(self,time_handle,event_type) :
		self.type = "event"
		self.time_handle = time_handle
		self.event_type = event_type

class Expr :
	pass

class BinOp(Expr) :
	def __init__(self,left,op,right):
		self.type = "binop"
		self.left = left
		self.right = right
		self.op = op

class UnaryOp(Expr) :
	def __init__(self,op,right) :
		self.type = "unaryop"
		self.op = op
		self.right = right

class BitwiseOp(Expr) :
	def __init__(self,left,op,right):
		self.type = "bitwiseop"
		self.left = left
		self.right = right
		self.op = op

class ShiftOp(Expr) :
	def __init__(self,left,op,right):
		self.type = "shiftop"
		self.left = left
		self.right = right
		self.op = op

class ExtendOp(Expr) :
	def __init__(self,left,op,right):
		self.type = "extendop"
		self.left = left
		self.right = right
		self.op = op

class ShrinkOp(Expr) :
	def __init__(self,left,op,right):
		self.type = "shrinkop"
		self.left = left
		self.right = right
		self.op = op

class Boolean(Expr) :
	def __init__(self,left,op,right):
		self.type = "boolean"
		self.left = left
		self.right = right
		self.op = op

class Logic(Expr) :
	def __init__(self,left,op,right):
		self.type = "logic"
		self.left = left
		self.right = right
		self.op = op

class Group(Expr) :
	def __init__(self,group):
		self.type = "group"
		self.value = group

class Number(Expr) :
	
	def add(self,rvalue) :
		value = self.value + rvalue.value
		return checkType(value)
		
	def sub(self,rvalue) :
		value = self.value - rvalue.value
		return checkType(value)
	
	def mul(self,rvalue) :
		value = self.value * rvalue.value
		return checkType(value)
	
	def div(self,rvalue) :
		value = self.value / rvalue.value
		return checkType(value)
	
	def power(self,rvalue) :
		value = self.value ** rvalue.value
		return checkType(value)
	
	def mod(self,rvalue) :
		value = self.value % rvalue.value
		return checkType(value)

	def less(self,rvalue) :
		value = self.value < rvalue.value
		return checkType(value)
	
	def more(self,rvalue) :
		value = self.value > rvalue.value
		return checkType(value)
	
	def lesseq(self,rvalue) :
		value = self.value <= rvalue.value
		return checkType(value)
	
	def moreeq(self,rvalue) :
		value = self.value >= rvalue.value
		return checkType(value)
	
	def eq(self,rvalue) :
		value = self.value == rvalue.value
		return checkType(value)
	
	def noteq(self,rvalue) :
		value = self.value != rvalue.value
		return checkType(value)
	
	def shiftl(self,rvalue) :
		value = self.value << rvalue.value
		return checkType(value)
	
	def shiftr(self,rvalue) :
		value = self.value >> rvalue.value
		return checkType(value)
	
	def andfn(self,rvalue) :
		value = self.value & rvalue.value
		return checkType(value)
	
	def orfn(self,rvalue) :
		value = self.value | rvalue.value
		return checkType(value)
	
	def xorfn(self,rvalue) :
		value = self.value ^ rvalue.value
		return checkType(value)
	
	def minus(self) :
		value = -self.value
		return checkType(value)
	
	def inverse(self) :
		value = ~self.value
		return checkType(value)
	
	def andLogic(self,rvalue) :
		value = self.value and rvalue.value
		return checkType(value)
	
	def orLogic(self,rvalue) :
		value = self.value or rvalue.value
		return checkType(value)
	
	def notLogic(self) :
		value = not self.value
		return checkType(value)

class IntNum(Number) :
	def __init__(self,value) :
		self.type = "int"
		self.value = value 

class LongNum(Number) :
	def __init__(self,value) :
		self.type = "long"
		self.value = value

class FloatNum(Number) :
	def __init__(self,value) :
		self.type = "float"
		self.value = value

class ComplexNum(Number) :
	def __init__(self,value) :
		self.type = "complex"
		self.value = value 

class Id(Expr) :
	def __init__(self,id) :
		self.type = "id"
		self.id = id

class Sequence(Expr) :
	def add(self,rvalue) :
		if rvalue.type in ["list","string"] :
			value = self.value + rvalue.value
		else : error()
		return checkType(value)
	def mul(self,rvalue) :
		if rvalue.type == "int" :
			value = self.value * rvalue.value
		else : error()
		return checkType(value)

class String(Sequence) :
	def __init__(self,string) :
		self.type = "string"
		string = string.replace("\\n","\n")
		string = string.replace("\\t","\t")
		self.value = string

class List(Sequence) :
	def __init__(self,value) :
		self.type = "list"
		self.value = value

class Dictionary(Expr) :
	def __init__(self,value) :
		self.type = "dictionary"
		self.value = value

class Access(Expr) :
	def __init__(self,id,index) :
		self.type = "access"
		self.id = id
		self.index = index

class AccessScope(Expr) :
	def __init__(self,id,start,stop) :
		self.type = "access_scope"
		self.id = id
		self.start = start
		self.stop = stop

class Point(Expr) :
	def __init__(self,time) :
		self.type = "tp"
		self.value = time
	
	def add(self,rvalue) :
		if rvalue.type != "td" : error()
		else :
			result = Point(self.value + rvalue.value)
			return result
	
	def sub(self,rvalue) :
		if rvalue.type == "td" : 
			result = Point(self.value - rvalue.value)
			return result

		elif rvalue.type == "tp" :
			result = Duration(self.value - rvalue.value)
			return result
	
	def less(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value < rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = self.value < rvalue.value[0].value
			return checkType(value)
		else : error()
	
	def more(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value > rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = self.value > rvalue.value[1].value
			return checkType(value)
		else : error()
	
	def lesseq(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value <= rvalue.value
			return checkType(value)
		else : error()

	def moreeq(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value >= rvalue.value
			return checkType(value)
		else : error()
	
	def eq(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value == rvalue.value
			return checkType(value)
		else : error()
	
	def noteq(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value != rvalue.value
			return checkType(value)
		else : error()
	
	def during(self,rvalue):
		if rvalue.type == "ti" :
			value = (self.value >= rvalue.value[0].value) and \
			(self.value <= rvalue.value[1].value)
			return checkType(value)
		else : error()
	
	def start(self,rvalue):
		if rvalue.type == "ti" :
			value = self.value == rvalue.value[0].value
			return checkType(value)
		else : error()
	
	def finish(self,rvalue):
		if rvalue.type == "ti" :
			value = self.value == rvalue.value[1].value
			return checkType(value)
		else : error()
	
class Duration(Expr) :
# Given day,month and year are number of theirs such as 2.3.4d is the number of 
# 2 days 3 months and 4 years,not at 2th March 0004 ,so I can't use function likes 
# addDate() in time_stmt class.I don't know about meaning of month,Jan,Feb etc..
	def __init__(self,duration) :
		self.type = "td"
		self.value = duration
	
	def add(self,rvalue) :
		if rvalue.type == "td" :
			return Duration(self.value+rvalue.value)
		elif rvalue.type == "tp" :
			result = Point(rvalue.value+self.value)
			return result
		else : error()
		
	def sub(self,rvalue) :
		if rvalue.type == "td" :
			return Duration(self.value-rvalue.value)
		else : error()
	
	def mul(self,rvalue) :
		if rvalue.type in ["int","float","long"] :
			return Duration(self.value*rvalue.value)
		else : error()
	
	def div(self,rvalue) :
		if rvalue.type in ["int","float","long"] :
			number = float(rvalue.value)
			return Duration(self.value/number)
		elif rvalue.type == "td" :
			return Number(self.value/rvalue.value)
		else : error()
		
	def less(self,rvalue):
		if rvalue.type == "td" :
			value = self.value < rvalue.value
			return checkType(value)
		else : error()
	
	def more(self,rvalue):
		if rvalue.type == "td" :
			value = self.value > rvalue.value
			return checkType(value)
		else : error()
	
	def lesseq(self,rvalue):
		if rvalue.type == "td" :
			value = self.value <= rvalue.value
			return checkType(value)
		else : error()
	
	def moreeq(self,rvalue):
		if rvalue.type == "td" :
			value = self.value >= rvalue.value
			return checkType(value)
		else : error()
	
	def eq(self,rvalue):
		if rvalue.type == "td" :
			value = self.value == rvalue.value
			return checkType(value)
		else : error()
	
	def noteq(self,rvalue):
		if rvalue.type == "td" :
			value = self.value != rvalue.value
			return checkType(value)
		else : error()

class Interval(Expr) :
	def __init__(self,start,end) :
		self.type = "ti"
		#if ((start.value != []) and (end.value != [])) : distance = Duration(end.value - start.value)
		#else : distance = []
		#self.value = [start,end,distance]
		self.value = [start,end]
	
	def shiftr(self,rvalue) :
		if rvalue.type == "td" :
			start = Point(self.value[0].value+rvalue.value)
			end = Point(self.value[1].value+rvalue.value)
			return Interval(start,end)
		else : error()
	
	def shiftl(self,rvalue) :
		if rvalue.type == "td" :
			start = Point(self.value[0].value-rvalue.value)
			end = Point(self.value[1].value-rvalue.value)
			return Interval(start,end)
		else : error()
	
	def extendr(self,rvalue) :
		if rvalue.type == "td" :
			start = self.value[0]
			end = Point(self.value[1].value+rvalue.value)
			return Interval(start,end)
		else : error()
	
	def extendl(self,rvalue) :
		if rvalue.type == "td" :
			start = Point(self.value[0].value-rvalue.value)
			end = self.value[1]
			return Interval(start,end)
		else : error()
	
	def shrinkr(self,rvalue) :
		if rvalue.type == "td" :
			start = self.value[0]
			end = Point(self.value[1].value-rvalue.value)
			return Interval(start,end)
		else : error()
	
	def shrinkl(self,rvalue) :
		if rvalue.type == "td" :
			start = Point(self.value[0].value+rvalue.value)
			end = self.value[1]
			return Interval(start,end)
		else : error()
	
	def concat(self,rvalue) :
		if rvalue.type == "ti" :
			if self.value[1].value == rvalue.value[0].value :
				return Interval(self.value[0], rvalue.value[1])
			else : error()
		else : error()

	def union(self,rvalue) :
		if rvalue.type == "ti" :
			if ((self.value[0].value <= rvalue.value[0].value) and \
			(self.value[1].value >= rvalue.value[1].value)) :
				return Interval(self.value[0], self.value[1])
			elif ((self.value[0].value <= rvalue.value[0].value) and\
			(self.value[1].value >= rvalue.value[0].value) and \
			(self.value[1].value < rvalue.value[1].value)) :
				return Interval(self.value[0],rvalue.value[1])
		else : error()

	def difference(self,rvalue) :
		if rvalue.type == "ti" :
			if ((self.value[0].value < rvalue.value[0].value) and \
			(self.value[1].value >= rvalue.value[0].value) and \
			(self.value[1].value <= rvalue.value[1].value)) :
				return Interval(self.value[0],rvalue.value[0])
			elif ((self.value[0].value >= rvalue.value[0].value) and \
			(self.value[0].value <= rvalue.value[1].value) and \
			(self.value[1].value > rvalue.value[1].value)) :
				return Interval(rvalue.value[1],self.value[1])
			elif ((self.value[0].value >= rvalue.value[0].value) and \
			(self.value[1].value <= rvalue.value[1].value)) :
				pass #empty set
			elif (self.value[1].value < rvalue.value[0].value) :
				return Interval(self.value[0], self.value[1])
			elif (self.value[0].value > rvalue.value[1].value) :
				return Interval(self.value[0], self.value[1])
		else : error()
	
	def intersect(self,rvalue):
		if rvalue.type == "ti" :
			if ((self.value[0].value <= rvalue.value[0].value) and\
			(self.value[1].value >= rvalue.value[1].value)) :
				return Interval(rvalue.value[0], rvalue.value[1])
			elif ((self.value[0].value <= rvalue.value[0].value) and\
			(self.value[1].value > rvalue.value[0].value) and \
			(self.value[1].value <= rvalue.value[1].value)) :
				return Interval(rvalue.value[0],self.value[1])
			elif (self.value[1].value < rvalue.value[0].value) :
				pass # empty set
			elif (self.value[0].value > rvalue.value[1].value) :
				pass #empty set
			elif ((self.value[0].value > rvalue.value[0].value) and \
			(self.value[0].value < rvalue.value[1].value) and \
			(self.value[1].value >= rvalue.value[1].value) ) :
				return Interval(self.value[0], rvalue.value[1])
			elif ((self.value[0].value > rvalue.value[0].value) and\
			(self.value[1].value < rvalue.value[1].value) ) :
				return Interval(self.value[0],self.value[1])
		else : error()
	
	def less(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value[1].value < rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = self.value[1].value < rvalue.value[0].value
			return checkType(value)
		else : error()
	
	def more(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value[0].value > rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = self.value[0].value > rvalue.value[1].value
			return checkType(value)
		else : error()
	
	def eq(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[0].value == rvalue.value[0].value) \
			and (self.value[1].value == rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def noteq(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[0].value != rvalue.value[0].value) \
			or (self.value[1].value != rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def meet(self,rvalue):
		if rvalue.type == "ti" :
			value = self.value[1].value == rvalue.value[0].value
			return checkType(value)
		else : error()
	
	def metBy(self,rvalue):
		if rvalue.type == "ti" :
			value = self.value[0].value == rvalue.value[1].value
			return checkType(value)
		else : error()
	
	def overlap(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[1].value > rvalue.value[0].value) \
			and (self.value[1].value < rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def overlapBy(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[0].value < rvalue.value[1].value)\
			and (self.value[1].value > rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def during(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[0].value > rvalue.value[0].value) \
			and (self.value[1].value < rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def contain(self,rvalue):
		if rvalue.type == "tp" :
			value = ((self.value[0].value < rvalue.value) and \
			(self.value[1].value > rvalue.value))
			return checkType(value)
		elif rvalue.type == "ti" :
			value = ((self.value[0].value < rvalue.value[0].value)\
			and (self.value[1].value > rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def start(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[0].value == rvalue.value[0].value)\
			and (self.value[1].value < rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def startBy(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value[0].value == rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = ((self.value[0].value == rvalue.value[0].value)\
			and (self.value[1].value > rvalue.value[1].value))
			return checkType(value)
		else : error()
	
	def finish(self,rvalue):
		if rvalue.type == "ti" :
			value = ((self.value[1].value == rvalue.value[1].value)\
			and (self.value[0].value > rvalue.value[0].value))
			return checkType(value)
		else : error()
	
	def finishBy(self,rvalue):
		if rvalue.type == "tp" :
			value = self.value[1].value == rvalue.value
			return checkType(value)
		elif rvalue.type == "ti" :
			value = ((self.value[1].value == rvalue.value[1].value) \
			and (self.value[0].value < rvalue.value[0].value))
			return checkType(value)
		else : error()

class SequenceGrp :
	def __init__(self,sequence_list) :
		self.type = "sequence"
		self.value = sequence_list

class UnorderedGrp :
	def __init__(self,unordered_list) :
		self.type = "unordered"
		self.value = unordered_list

class ParallelGrp :
	def __init__(self,parallel_list) :
		self.type = "parallel"
		self.value = parallel_list

class IntervalStatement :
	def __init__(self,interval,statement) :
		self.type = "interval_statement"
		self.interval = interval
		self.stmts = statement

class Module(Expr) :
	def __init__(self,name) :
		self.type = "module"
		self.name = name

class function(Expr) :
	def __init__(self,function_name,parameter) :
		self.type = "function"
		self.name = function_name
		self.parameter = parameter
	
	def fork(self,obj):
		if obj.type == "int":
			result = IntNum(obj.value)
		elif obj.type == "long":
			result = LongNum(obj.value)
		elif obj.type == "float":
			result = FloatNum(obj.value)
		elif obj.type == "complex":
			result = ComplexNum(obj.value)
		elif obj.type == "list":
			temp = []
			for i in range(len(obj.value)) :
				x = self.fork(obj.value[i])
				temp.append(x)
			result = List(temp)
		elif obj.type == "string":
			result = String(obj.value)
		elif obj.type == "tp":
			result = Point(obj.value)
		elif obj.type == "td" :
			result = Duration(obj.value)
		elif obj.type == "ti" :
			result = Interval(obj.value[0], obj.value[1])
		return result

class Elif_program :
	def __init__(self,expr,elif_stmts) :
		self.type = "elif"
		self.expression = expr
		self.statements = elif_stmts

class If_else :
	def __init__(self,expr,if_stmts,elif_list,else_stmts) :
		self.type = "if"
		self.expression = expr
		self.ifStmt= if_stmts
		self.elifList = elif_list
		self.elseStmt = else_stmts

class while_stmt :
	def __init__(self,expr,stmts) :
		self.type = "while"
		self.expression = expr
		self.statements = stmts
	
class for_stmt :
	def __init__(self,start,stop,stmts) :
		self.type = "for"
		self.start = start
		self.stop = stop
		self.statements = stmts

class repeat_stmt :
	def __init__(self,expr,stmts) :
		self.type = "repeat"
		self.expression = expr
		self.statements = stmts

class SubProgram :
	def __init__(self) :
		self.type = "subprogram"
		self.stmts = []
	
	def addStmt(self,stmt) :
		self.stmts.append(stmt)
	
	def clear(self) :
		self.stmts = []

class SubClass :
	def __init__(self) :
		self.type = "subclass"
		self.stmts = []
	
	def addStmt(self,stmt) :
		self.stmts.append(stmt)
	
	def clear(self) :
		self.stmts = []

class ret_stmt :
	def __init__(self,expression) :
		self.type = "return"
		self.expression = expression
	
class defineFunction :
	def __init__(self,name,argument,code) :
		self.type = "defineFunction"
		self.name = name
		self.argument = argument
		self.body = code

class Comment :
	def __init__(self,comment) :
		self.type = "comment"
		self.value = comment
	
def checkType(value) :
	if isinstance(value,types.IntType) :
		return IntNum(value)
	elif isinstance(value,types.LongType) :
		return LongNum(value)
	elif isinstance(value,types.FloatType) :
		return FloatNum(value)
	elif isinstance(value,types.ComplexType) :
		return ComplexNum(value)
	elif isinstance(value,types.StringType) :
		return String(value)
	elif isinstance(value,types.ListType) :
		return List(value)

def error() :
	print "Type mismatch!"
	sys.exit(0)