##  another version of  T.py   have  CheckEvenThread that 
##  dose not use sleep()  function  but use loop for



import threading
import time

class CheckEvenThread( threading.Thread ):
   
   def __init__( self, threadName='def',isleepTime=5):
      threading.Thread.__init__( self, name = threadName )
      if isleepTime<1:
          isleepTime=1
      self.sleepTime = isleepTime
      self.count=0
      print "Name: %s; sleep: %d" % \
            ( self.getName(), self.sleepTime )
      self.d=[1,2,3,4,5,6,7,8]
     
   def run( self ):
      
      #while self.count<5:
      for i in range(int(5)):   #
         self.count =self.count+1
         self.li = time.localtime(time.time())
         self.k=0
         o=self.sleepTime
         time.sleep( self.sleepTime )
         #for j in range(int(o)):
         #   self.k=self.k+1
            
         #print "%s|t=%s|c=%s@%s:%s:%s  %s" % \
            ( self.getName(), self.sleepTime ,self.count,self.li[3],self.li[4],self.li[5],self.k)
         s= self.getName()+ '
         #
       






