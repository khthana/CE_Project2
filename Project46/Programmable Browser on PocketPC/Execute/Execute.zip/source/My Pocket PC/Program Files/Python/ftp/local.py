import string
import Pmw
from Tkinter import *
from config import *
from task import task
class calendart(Toplevel):
    def __init__(self,parent):
        Toplevel.__init__( self,parent)
        self.title( "Calendar(time)" )
        self.geometry( "235x270" )
        self.filepath = picpath
        
        a=24
        #for items in range(a):
        list=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
        self.box = Pmw.ScrolledListBox(self, listbox_selectmode='single', 
            listbox_width = 35,listbox_height = 10,
            labelpos='nw', 
            items=list,
            label_text='dd::mm::yy', 
            selectioncommand=self.selectionCommand)
    
        self.box.pack(fill = 'both', expand = 1)

    def selectionCommand(self):
        ttask = task(self)

######################################################################

# Create demo in root window for testing.
if __name__ == "__main__":
    root = Tk()
    shell = calendart(root)
    root.mainloop()        