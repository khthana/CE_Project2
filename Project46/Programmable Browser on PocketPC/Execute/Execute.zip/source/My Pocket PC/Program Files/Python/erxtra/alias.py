#print "alias.py in Python\lib"

import UserDict # in 2.2 import is case sensitive even in DOS ?

class Alias (UserDict.UserDict): # alias class
	"""	Alias hanndling class Super ( UserDict )
	If you give alias file name for the alias, __init__ will open it,
	and return the alias in it.
	if Dictionary or Alias object is given as init argument, 
	instance with that dictionary is created.
	If no alias file name is given, or anything goes wrong, __init__ returns
	empty alias dicctionary.
	
	load(fn) loads alias from Alias file
	pload(fn) loads from pickle file
	save(fn)  saves to Alias file
	psave(fn) saves to pickle file
	* any of above operation sets self.fn, and fn can be omitted for
	further operation on the same file.
	
	expand(cmd) expand
"""

	def __init__(self,fn=None): 
		"This will take either Alias file name or Dictionary or Alis as an arg"
		self.data={}
		self.fn=''
		t=type(fn)
		if t == type(' '):
			self.load(fn)
		elif t==type(self.data):
			userdict.UserDict.__init__(self,fn)
		elif t(fn.data)==type(self.data):
			userdict.UserDict.__init__(self,fn)

	def load(self,fn=None):
		#print "alias.py load(fn) fn=",fn
		if fn is None and self.fn != '':
			fn = self.fn
		try:
			f=open(fn)
		except:
			#print fn,"not in the root"
			import sys,os
			for pt in sys.path:
				#print "pt=",pt,"  fn=",fn
				fnx=os.path.join(pt,fn)
				try:
					f=open(fnx)
				except:
					continue
				else:
					#print fn,"in ",pt
					fn=fnx
					break
			else:
				raise
				return {}
			del sys
		try:
			import string
			a=[]
			alias={}
			s=f.read()
			#print "len(s)",len(s)
			f.close()
			s1=string.find(s,'### Alias definitions')
			#print "\ns1="+repr(s1)
			s2=string.find(s,'\n',s1+12)
			#print "s2="+repr(s2)
			s=s[s2+1:]
			#print s
			s1=string.find(s,'### Alias definitions END')
			#print "s1="+repr(s1)
			s=s[:s1]
			#print s
			ss=string.split(s,'\n')
			#print ss
			#print "Goning for loop"
			for _l in ss:
				if len(_l) < 3:
					continue 
				if _l[0]=='#':
					#print "comment detected>"+_l
					continue
				if _l[-1] =="\15":
					_l=_l[:-1]
				a=string.split(_l,'=')
				if len(a) < 2:
					continue
				#print a
				k=string.strip(a[0])
				if k =='' or k is None:
					continue
				v=string.strip(string.join(a[1:],'='))
				if v is None:
					v=''
				alias[k]=v
				#print alias
			if alias != {}:
				self.fn = fn
			self.data=alias
			return alias
		except:
			raise

	def save(self,fn=None):
		if fn is None and self.fn != '':
			fn = self.fn
		try:
			f=open(fn,'w')
		except:
			return -1
		try:
			dk=self.data.keys()
			dk.sort()
			f.write("### Alias definitions\n")
			for k in dk:
				f.write(k+"="+self.data[k]+"\n")
			f.write("### Alias definitions END\n")
			f.close()
		except:
			return -2
		else:
			self.fn = fn
			return 0
	

	def pload(self,fn=None):
		if fn is None and self.fn != '':
			fn = self.fn
		try:
			f=open(fn)
		except:
			f=None
		try:
			import pickle
			self.data=pickle.load(f)
			f.close()
		except:
			return {}
		else:
			self.fn = fn
			return self.data
	
	def psave(self,fn):
		if fn is None and self.fn != '':
			fn = self.fn
		try:
			f=open(fn,'w')
		except:
			f=None
		try:
			import pickle
			pickle.dump(self.data,f)
			f.close()
		except:
			return -2
		else:
			self.fn = fn
			return 0

	def expand(self,cmd,deli="\W"):
		"""Expand alias in the commandline.
		string:cmd, string:deli <- command delimiter 
		Anything non alphanumeric is the default delimiter.
		It returns expanded command line on success.
		"""
		d=self.data
		if type(cmd) != type(' ') or cmd == '' or cmd is None:
			return ''
		c=cmd
		import re
		for k in d.keys():
			c=re.sub('(^|'+deli+')'+k+'('+deli+'|$)','\g<1>'+d[k]+'\g<2>',c)
		return c
		
	#def __del__():
	#	pass
	#


#print "alias end"
