'''
This is a parse program (Yacc) for CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 24 Nov. 2002, 18:36
================================================
Comment : Duty is Parsing. This have many CFG
Input is scripts(string). Output is list of abstract syntax tree(AST).
Called by main.py
'''

import yacc
import langlex
import sys
from abstract import *
tokens = langlex.tokens

#Precedence of operators 
precedence = (
	('left','OR'),
	('left','AND'),
	('right','NOT'),
	('left','LESS','LESSEQ','GREATER','GREATEREQ','EQ','NOTEQ','MI','M','OI','O','DI','D','SI','S','FI','F'),
	('left','OROP'),
	('left','XOROP'),
	('left','ANDOP'),
	('left','SHIFTL','SHIFTR','EXTENDL','EXTENDR','SHRINKL','SHRINKR'),
	('left','PLUS','MINUS'),
	('left','MUL','DIVIDE','MOD'),
	('left','POWER'),
	('right','UMINUS','UPLUS'),
	('right','UINVERSE'),
)




def p_cl(t) :
	'''cl : event_action
	      | program'''
	t[0] = t[1]

def p_event_action(t) :
	'event_action : event OCC action'
	#print "Hi!! event-action-3"
	#print "start time : ",t[1].time_handle.value[0].value
	#print "end time : ",t[1].time_handle.value[1].value
	print "event : ",t[1]#.event_type.value
	#print "action : ",t[3].stmts
	#print "DIR t[3].stmts:"+dir(t[3].stmts)
	## t[2] -->
	#print 'len',len(t)
	t[0] = [EventAction(t[1],t[3])]

def p_event1(t) :
	'event : Q COLON event_type'
	t[0] = Event(t[2],t[4])

def p_event2(t) :
	'event : event_type'
	t[0] = Event(Interval(Point([]),Point([])), t[1])

def p_interval_time(t) :
	'''interval_time : interval
			 | id '''
	t[0] = t[1]

def p_event_type(t) :
	'event_type : expression'
	t[0] = t[1]

def p_action(t) :
	'action : statement'
	t[0] = t[1]

def p_program1(t) :
	'program : program element'
	t[1].append(t[2])
	t[0] = t[1]

def p_program2(t) :
	'program : element'
	t[0] = [t[1]]

def p_element(t) :
	''' element : module_stmt SEMI
		    | statement'''
		    #| comment'''
	t[0] = t[1]

def p_statement1(t) :
	'statement : Q interval_time COLON statement_type'
	#print 'p_statement1(t)'
	print t[2],t[4]
	t[0] = IntervalStatement(t[2],t[4])

def p_statement2(t) :
	'statement : statement_type'
	#print t[1].value
	t[0] = IntervalStatement(Interval(Point([]),Point([])),t[1])

def p_statement_type(t) :
	''' statement_type : expression SEMI
			   | assign_stmt SEMI
			   | control_stmt
			   | define_function
			   | group_stmt'''
	t[0] = t[1]
	
#Dictionary of ID
ids = {}
def p_statement_assign(t) :
	'''assign_stmt : left_value EQUALS expression
		       | left_value PLUSEQ expression
		       | left_value MINUSEQ expression
		       | left_value MULEQ expression
		       | left_value DIVEQ expression
		       | left_value MODEQ expression
		       | left_value POWEREQ expression
		       | left_value SHIFTLEQ expression
		       | left_value SHIFTREQ expression
		       | left_value ANDEQ expression
		       | left_value OREQ expression
		       | left_value XOREQ expression'''
	t[0] = AssignStmt(t[1],t[2],t[3])

def p_left_value(t) :
	'''left_value : id
	              | access'''
	t[0] = t[1]

def p_statement_control(t):
	'''control_stmt : if_sentence
	                | while_sentence
			| for_sentence
			| repeat_sentence'''
	t[0] = t[1]

def p_sentence_if1(t) :
	'''if_sentence : IF expression COLON SEMI if_statement elif_sentence else_sentence'''
	sub_if = SubProgram()
	sub_else = SubProgram()
	sub_if.stmts = t[5]
	sub_else.stmts = t[7]
	t[0] = If_else(t[2],sub_if,t[6],sub_else)
	#print "if sentence 1"

def p_sentence_if2(t) :
	'''if_sentence : IF expression COLON SEMI if_statement elif_sentence'''
	sub_if = SubProgram()
	sub_else = SubProgram()
	sub_if.stmts = t[5]
	sub_else.stmts = []
	t[0] = If_else(t[2],sub_if,t[6],sub_else)
	#print "if sentence2"

def p_sentence_if3(t) :
	'''if_sentence : IF expression COLON SEMI if_statement else_sentence'''
	sub_if = SubProgram()
	sub_else = SubProgram()
	sub_if.stmts = t[5]
	sub_else.stmts = t[6]
	t[0] = If_else(t[2],sub_if,[],sub_else)
	#print "if sentence3"

def p_sentence_if4(t) :
	'''if_sentence : IF expression COLON SEMI if_statement'''
	sub_if = SubProgram()
	sub_else = SubProgram()
	sub_if.stmts = t[5]
	sub_else.stmts = []
	t[0] = If_else(t[2],sub_if,[],sub_else)
	#print "if sentence4"

def p_sentence_elif_1(t) :
	'''elif_sentence : elif_sentence ELIF expression COLON SEMI elif_statement'''
	sub_elif = SubProgram()
	sub_elif.stmts = t[6]
	elif_pg = Elif_program(t[3],sub_elif)
	t[1].append(elif_pg)
	t[0] = t[1]

def p_sentence_elif_2(t) :
	'''elif_sentence : ELIF expression COLON SEMI elif_statement'''
	sub_elif = SubProgram()
	sub_elif.stmts = t[5]
	elif_pg = Elif_program(t[2],sub_elif)
	t[0] = [elif_pg]

def p_sentence_else(t) :
	'''else_sentence : ELSE COLON SEMI else_statement'''
	t[0] = t[4]

def p_statement_if(t):
	'if_statement : LBRACE subprogram RBRACE'
	t[0] = t[2]

def p_statement_elif(t):
	'elif_statement : LBRACE subprogram RBRACE'
	t[0] = t[2]

def p_statement_else(t):
	'else_statement : LBRACE subprogram RBRACE'
	t[0] = t[2]

def p_sentence_while(t) :
	'''while_sentence : WHILE expression COLON SEMI while_statement'''
	sub_while = SubProgram()
	sub_while.stmts = t[5]
	t[0] = while_stmt(t[2],sub_while)

def p_while_statement(t):
	''' while_statement : LBRACE subprogram RBRACE'''
	t[0] = t[2]
	
def p_sentence_for(t) :
	'''for_sentence : FOR id TO expression COLON SEMI for_statement'''
	sub_for = SubProgram()
	sub_for.stmts = t[7]
	t[0] = for_stmt(t[2],t[4],sub_for)

def p_for_statement(t):
	''' for_statement : LBRACE subprogram RBRACE'''
	t[0] = t[2]

def p_sentence_repeat(t) :
	'''repeat_sentence : REPEAT COLON SEMI repeat_statement UNTIL expression SEMI'''
	sub_repeat = SubProgram()
	sub_repeat.stmts = t[4]
	t[0] = repeat_stmt(t[6],sub_repeat)

def p_repeat_statement(t):
	''' repeat_statement : LBRACE subprogram RBRACE'''
	t[0] = t[2]

def p_subprogram1(t) :
	'''subprogram : subprogram statement'''
	t[1].append(t[2])
	t[0] = t[1]

def p_subprogram2(t) :
	'''subprogram : statement'''
	program = []
	program.append(t[1])
	t[0] = program

def p_statement_group(t) :
	'''group_stmt : sequence_grp
				  | unordered_grp
				  | parallel_grp '''
	t[0] = t[1]

def p_statement_grp_sequence(t) :
	'sequence_grp : LBRACE sequence RBRACE'
	t[0] = SequenceGrp(t[2])

def p_sub_sequence1(t) :
	' sequence : sequence element '
	t[1].append(t[2])
	t[0] = t[1]

def p_sub_sequence2(t) :
	' sequence : element '
	t[0] = [t[1]]

def p_statement_grp_unordered(t) :
	'unordered_grp : LBRACE unordered RBRACE'
	print "unorder group"
	t[0] = UnorderedGrp(t[2])

def p_sub_unordered1(t) :
	' unordered : unordered UNORDERED element '
	t[1].append(t[3])
	t[0] = t[1]

def p_sub_unordered2(t) :
	' unordered : UNORDERED element '
	t[0] = [t[2]]

def p_statement_grp_parallel(t) :
	'parallel_grp : LBRACE parallel RBRACE'
	t[0] = ParallelGrp(t[2])

def p_sub_parallel1(t) :
	' parallel : parallel PARALLEL element '
	t[1].append(t[3])
	t[0] = t[1]

def p_sub_parallel2(t) :
	' parallel : PARALLEL element '
	t[0] = [t[2]]

def p_module_script(t) :
	'module_stmt : IMPORT ID'
	t[0] = Module(t[2])

def p_statement_expression(t) :
	''' expression : unary_expr
		       | binary_expr
		       | bitwise_expr
		       | shift_expr
		       | extend_expr
		       | shrink_expr
		       | boolean_expr
		       | logic_expr
		       | group_expr
		       | term '''
	t[0] = t[1]

def p_term(t) :
	''' term : number
		 | function
		 | id
		 | string
		 | time
		 | list
		 | dictionary
		 | access_scope
		 | access '''
	t[0] = t[1]

def p_expression_binop(t):
	'''binary_expr : expression PLUS expression
		       | expression MINUS expression
		       | expression MUL expression
		       | expression DIVIDE expression
		       | expression POWER expression
		       | expression MOD expression'''
	t[0] = BinOp(t[1],t[2],t[3])

def p_expression_unaryop(t) :
	'''unary_expr : MINUS expression %prec UMINUS
	              | PLUS expression %prec UPLUS
		      | UINVERSE expression'''
	print "expression unaryop"
	t[0] = UnaryOp(t[1],t[2])

def p_expression_bitwiseop(t):
	'''bitwise_expr : expression ANDOP expression
			| expression OROP expression
			| expression XOROP expression'''
	t[0] = BitwiseOp(t[1],t[2],t[3])

def p_expression_shiftop(t):
	'''shift_expr : expression SHIFTL expression
	              | expression SHIFTR expression'''
	t[0] = ShiftOp(t[1],t[2],t[3])

def p_expression_extendop(t):
	'''extend_expr : expression EXTENDL expression
		       | expression EXTENDR expression'''
	t[0] = ExtendOp(t[1],t[2],t[3])

def p_expression_shrinkop(t):
	'''shrink_expr : expression SHRINKL expression
		       | expression SHRINKR expression'''
	t[0] = ShrinkOp(t[1],t[2],t[3])

def p_expression_boolean(t) :
	'''boolean_expr : expression LESS expression
	                | expression GREATER expression
			| expression LESSEQ expression
			| expression GREATEREQ expression
			| expression EQ expression
			| expression NOTEQ expression
			| expression MI expression
	                | expression M expression
			| expression OI expression
			| expression O expression
			| expression DI expression
			| expression D expression
			| expression SI expression
			| expression S expression
			| expression FI expression
			| expression F expression'''
	t[0] = Boolean(t[1],t[2],t[3])

def p_expression_logical1(t) :
	'''logic_expr : number AND number
	              | number OR number'''
	t[0] = Logic(t[1],t[2],t[3])

def p_expression_logical2(t) :
	'logic_expr : NOT expression '
	t[0] = Logic(t[2],t[1],None)

def p_term_time(t):
	'''time : point
	        | duration
		| interval '''
	print t[1]
	t[0] = t[1]

def p_term_time_point(t):
	'point : TP'
	
	t[0] = Point(t[1])

def p_term_time_duration(t):
	'duration : TD'
	t[0] = Duration(t[1])

def p_term_time_interval1(t):
	'interval : LESS point_time COMMA point_time GREATER'
	#print 'interval1'
	t[0] = Interval(t[2],t[4])

def p_term_time_interval2(t):
	'interval : LESS UNDER COMMA point_time GREATER'
	#print 'interval2'
	t[0] = Interval(Point([]),t[4])
	

def p_term_time_interval3(t):
	'interval : LESS point_time COMMA UNDER GREATER'
	#print 'interval3'
	t[0] = Interval(t[2],Point([]))

def p_term_time_interval4(t):
	'interval : LESS UNDER COMMA UNDER GREATER'
	#print 'interval4'
	t[0] = Interval(Point([]),Point([]))

def p_point_time(t) :
	'''point_time : point
		      | id '''
	t[0] = t[1]

def p_term_list(t) :
	'list : LBRACKET components RBRACKET'
	t[0] = List(t[2])

def p_list_components1(t) :
	'components : components COMMA expression'
	t[1].append(t[3])
	t[0] = t[1]

def p_list_components2(t) :
	'components : expression'
	t[0] = [t[1]]

def p_term_dictionary(t) :
	'dictionary : LBRACE dict_components RBRACE'
	t[0] = Dictionary(t[2])

def p_dictionary_components1(t) :
	'dict_components : dict_components COMMA expression COLON expression' 
	t[1][t[3]] = t[5]
	t[0] = t[1]

def p_dictionary_components2(t) :
	'dict_components : expression COLON expression' 
	t[0] = {t[1]:t[3]}

#def p_key_component(t) :
#	'''key_component : number
#		         | id
#		         | string'''
#	t[0] = t[1]

def p_term_access(t) :
	'access : ID LBRACKET index_number RBRACKET'
	t[0] = Access(t[1],t[3])

def p_term_access_scope1(t) :
	'access_scope : ID LBRACKET index_number COLON index_number RBRACKET'
	t[0] = AccessScope(t[1],t[3],t[5])

def p_term_access_scope2(t) :
	'access_scope : ID LBRACKET index_number COLON RBRACKET'
	t[0] = AccessScope(t[1],t[3],None)

def p_term_access_scope3(t) :
	'access_scope : ID LBRACKET COLON index_number RBRACKET'
	t[0] = AccessScope(t[1],None,t[4])

def p_sequence_index(t) :
	'''index_number : int_number
		        | id'''
	t[0] = t[1]

def p_expression_group(t):
	'group_expr : LPAREN expression RPAREN'
	t[0] = t[2]

def p_term_number(t) :
	'''number : int_number
		  | float_number 
		  | long_number 
		  | complex_number'''   
	t[0] = t[1]

def p_term_int(t) :
	'int_number : INTNUM'
	t[0] = IntNum(t[1])

def p_term_long(t) :
	'long_number : LONGNUM'
	t[0] = LongNum(t[1])

def p_term_float(t) :
	'float_number : FLOATNUM'
	t[0] = FloatNum(t[1])

def p_term_complex(t) :
	'complex_number : COMPLEXNUM'
	t[0] = ComplexNum(t[1])

def p_term_id(t) :
	'id : ID'
	t[0] = Id(t[1])

def p_term_function(t) :
	'function : ID LPAREN parameters RPAREN'
	t[0] = function(t[1],t[3])

def p_param_list1(t):
	'parameters : parameters COMMA expression'
	t[1].append(t[3])
	t[0] = t[1]

def p_param_list2(t):
	'parameters : expression'
	parameter = []
	parameter.append(t[1])
	t[0] = parameter

def p_term_string(t) :
	'''string : STRING'''
	t[0] = String(t[1][1:len(t[1])-1])

def p_define_function(t):
	'''define_function : DEF ID LPAREN arguments RPAREN COLON SEMI stmt_list'''
	body = SubProgram()
	body.stmts = t[8]
	t[0] = defineFunction(t[2],t[4],body)

def p_list_of_stmt1(t):
	'''stmt_list : LBRACE subprogram return_stmt RBRACE'''
	t[2].append(t[3])
	t[0] = t[2]

def p_list_of_stmt2(t):
	'''stmt_list : LBRACE subprogram RBRACE'''
	t[2].append(ret_stmt(Number(1)))
	t[0] = t[2]

def p_argument_list1(t):
	'arguments : arguments COMMA ID'
	t[1].append(t[3])
	t[0] = t[1]

def p_argument_list2(t):
	'arguments : ID'
	argument = []
	argument.append(t[1])
	t[0] = argument

def p_return_stmt(t) :
	'return_stmt : RETURN expression SEMI'
	t[0] = IntervalStatement(Interval(Point([]),Point([])),ret_stmt(t[2]))
	#t[0] = ret_stmt(t[2])

def p_comment(t) :
	'comment : COMMENT'
	t[0] = Comment(t[1])

#def p_empty(t) :
#	'empty :'
#	pass

def p_error(t) :
	print "Syntax error at '%s'" %t.value


class Parse:
	def __init__(self,scripts) :
		yacc.yacc()
		self.ast = yacc.parse(scripts)