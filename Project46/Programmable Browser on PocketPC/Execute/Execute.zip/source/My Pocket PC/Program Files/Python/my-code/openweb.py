# Fig. 11.2: fig11_02.py
# Copying selected text from one text area to another.


import Pmw
import sys, string

from Tkinter import *
from open_url import open_web


class CopyTextWindow( Frame ):
   """Demonstrate ScrolledTexts"""
   
   def __init__( self ):
      """Create two ScrolledTexts and a Button"""
      
      Frame.__init__( self )
      Pmw.initialise()
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Open-Web" )
      self.master.geometry("235x242")

      self.frame1 = Frame(self)
      self.frame1.pack( pady=2)
      # create scrolled text box with word wrap enabled
      self.text1 = Entry( self.frame1, name = 'text1')
      self.text1.insert(INSERT,'http://google.com/')
      self.text1.pack(side=LEFT)

      self.copyButton = Button( self.frame1, text = "Go", command = self.copyText )
      self.copyButton.pack(side=LEFT)

      self.frame2 = Frame(self)
      self.frame2.pack(pady=2)
      # create uneditable scrolled text box
      self.text2 = Pmw.ScrolledText( self.frame2, text_state = DISABLED,text_wrap = WORD,
         hscrollmode = "static", vscrollmode = "static" )#text_width = 25, text_height = 12,
      self.text2.pack( side = LEFT) #expand = YES, fill = BOTH

   def copyText( self ):
      """Set the text in the second ScrolledText"""
      url = self.text1.get()  #="http://www.google.com/index.html"
      web_con = op.open(url)
      self.text2.settext( web_con )





def main():

   CopyTextWindow().mainloop()


op = open_web()
main()










