'''
##  mysmtpmail.py
##  2004-02-12
##  modifly input data from def __init__(self,From,To,Subj,Data): -> def __init__():
##  and move the input data to def send(self,From,To,Subj,Data):
##  2004/03/15
##  print correctly
'''

import smtplib
import string
import sys
import time

from getuserprofile import getuserprofile

class mysmtpmail:

    def __init__(self):
        ''' send mail module '''
        #print 'mysmtpmail.__init__()'
        self.upfd={}
        self.upf=getuserprofile()
        self.upf.getuserpf('mail.profile',self.upfd)
        self.smtpserver = self.upfd['smtpserver']

    def getsmtpserver(self):
        return self.smtpserver
    
    def send(self,From,To,Subj,Data):
        #print 'Connecting...'
        try:
            #self.From = string.strip("s3010096@kmitl.ac.th")    # ex: lutz@rmi.net s3010096@kmitl.ac.th
            #self.To   = string.strip("h_chakrit@163.com")       # ex: python-list@python.org
            #self.To   = string.split(To, ';')                   # allow a list of recipients
            #self.Subj = string.strip("test2004-02-05#2")
            server = smtplib.SMTP(self.smtpserver)         ## connect, no login step
            
            self.From = string.strip(From)
            self.To   = string.strip(To)
            self.Subj = string.strip(Subj)
            self.Data = string.strip(Data)

            ## prepend standard headers
            date = time.ctime(time.time())
            self.mail = ('From: %s\nTo: %s\nDate: %s\nSubject: %s\n'
                % (self.From, string.join(self.To, ';'), date, self.Subj))
            self.mail = self.mail + self.Data
            #print '@'*80
            #print self.mail
            #print '@'*80

            
            #server.connect();
            failed = server.sendmail(self.From, self.To, self.mail)
            
            
        finally:
            server.quit()
            if failed:                                     ## smtplib may raise exceptions
                #print 'Failed recipients:', failed         ## too, but let them pass here
                return 0
            else:
                #print 'No errors.'
                return 1


####################################################################
#From = 'ck1982@msn.com'
#To = 'h_chakrit@163.com'
#Subj = 'pocket-by-SMTP#1'
#Data = 'data-1a123456789\n2a123456789\n3a123456789'
#a=mysmtpmail()
#b=a.send(From,To,Subj,Data)
#print b
