'''
    design and code by : Cherdkiat Saetae
    chang some by : Chakrit Hengsirikul 
    2004/03/15
    print correctly
'''


from Tkinter import *
import Pmw
from config import *
from getuserprofile import getuserprofile
from color import color


class user(Toplevel):
    def __init__( self,parent,mycolor,select_color_number):
        Toplevel.__init__( self,parent)
        self.title( "User Profile" )
        self.geometry( "235x270" )

        print 'Edit Profile()'
        
        self.filepath = picpath

        self.upf=getuserprofile()        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor

#notebook
        self.notebook = Pmw.NoteBook(self,hull_height = 235)
        self.notebook.pack(expand = YES,fill=BOTH)
        self.mailaddselected = ''

        self.frmBttn = Frame(self)
        self.frmBttn.pack(pady ='4')

        self.okFav = Button(self.frmBttn,text ='OK',width='6',command=self.ok)
        self.okFav.pack(side='left',pady = '0',expand =YES)
        self.canclFav = Button(self.frmBttn,text ='Cancel',width='6',command=self.cancel)
        self.canclFav.pack(side='left',pady = '0',expand =YES)

#Detail page
        self.genpage = self.notebook.add('General')
        self.notebook.tab('General').focus_set()

        self.dtl={}
        self.upf.getuserpf('detail.profile',self.dtl)        

        self.gengroup = Pmw.Group(self.genpage, tag_text='Details')
        self.gengroup.pack(fill = 'both', padx = 6, pady = 6)

        self._name = Pmw.EntryField(self.gengroup.interior(),labelpos = 'w',label_text = '   Name:')
        self._name.insert( INSERT,self.dtl['name'] )
        self._address = Pmw.EntryField(self.gengroup.interior(),labelpos = 'w',label_text = 'Address:')
        self._address.insert( INSERT,self.dtl['address'] )
        self._tel = Pmw.EntryField(self.gengroup.interior(),labelpos = 'w',label_text = '    Tel:')
        self._tel.insert( INSERT,self.dtl['telephone'] )
        self._email = Pmw.EntryField(self.gengroup.interior(),labelpos = 'w',label_text = '  Email')
        self._email.insert( INSERT,self.dtl['email'] )
        entries = (self._name, self._address, self._tel, self._email)
        for entry in entries:
            entry.pack(fill='x',pady='5',padx='2')
        Pmw.alignlabels(entries)
        colorlist = ['c1','c2','c3','c4']
        self.colordropdown = Pmw.ComboBox(self.genpage,
                                          label_text = 'Colour Styles:',
                                          labelpos = 'nw',
                                          selectioncommand = self.changeColour,
                                          scrolledlist_items = colorlist
                                          )
        self.colordropdown.pack(side = 'left', anchor = 'n',fill = 'x',padx='15')
        self.savedtlbut = Button(self.genpage,text = 'Apply',command=self.savedetail)
        self.savedtlbut.pack(side=RIGHT,padx='8')
        
#FTP page
        self.ftppage = self.notebook.add('FTP Server')
        #self.notebook.tab('FTP Server').focus_set()

        self.ftp={}
        self.upf.getuserpf('ftp.profile',self.ftp)
        
        self.ftpgroup = Pmw.Group(self.ftppage, tag_text='config FTP')
        self.ftpgroup.pack(fill = 'both', padx = 2, pady = 6)
        #Host
        self.txt_ftphost = Pmw.EntryField(self.ftpgroup.interior(),labelpos = 'w',label_text = '           Host:')
        self.txt_ftphost.insert(INSERT,self.ftp['server'])
        #Port
        self.txt_ftpport = Pmw.EntryField(self.ftpgroup.interior(),labelpos = 'w',label_text = '            Port:')
        self.txt_ftpport.insert( INSERT,self.ftp['port'] )
        #username
        self.txt_ftpusername =Pmw.EntryField(self.ftpgroup.interior(),labelpos = 'w',label_text = 'User Name:')
        self.txt_ftpusername.insert( INSERT,self.ftp['username'] )
        #password
        self.txt_ftppassword =Pmw.EntryField(self.ftpgroup.interior(),labelpos = 'w',label_text = '   Password:')
        self.txt_ftppassword.component('entry').config(show='*')##,show='*'
        self.txt_ftppassword.insert( INSERT,self.ftp['password'] )
        for entry in (self.txt_ftphost,self.txt_ftpport,self.txt_ftpusername,self.txt_ftppassword):
            entry.pack(fill='x',pady='4',padx='1')
        #Pmw.alignlabels(entries)
        #button
        self.Savftp = Button(self.ftppage,text ='Apply',command=self.saveftp)
        self.Savftp.pack(side=RIGHT,padx='10')


#Mail Page
        self.page2 = self.notebook.add('Mail')
        self.notebook.tab('Mail').focus_set()

        self.mailnotebook = Pmw.NoteBook(self.page2,hull_height = 235)
        self.mailnotebook.pack(expand = YES,fill=BOTH)

        
        self.mail={}
        self.upf.getuserpf('mail.profile',self.mail)
        
        self.mailserverpg = self.mailnotebook.add('Server')
        self.mailgroup = Pmw.Group(self.mailserverpg, tag_text='config mail')
        self.mailgroup.pack(fill = 'both', padx = 2, pady = 4)
        #mail server
        self.txt_mail_srvr = Pmw.EntryField(self.mailgroup.interior(),labelpos = 'w',label_text = 'Mail Server:')
        self.txt_mail_srvr.insert(INSERT,self.mail['mailserver'])
        #smtp server
        self.txt_smtp_srvr = Pmw.EntryField(self.mailgroup.interior(),labelpos = 'w',label_text = 'SMTP Server:')
        self.txt_smtp_srvr.insert( INSERT,self.mail['smtpserver'] )
        #username
        self.txt_username_mail =Pmw.EntryField(self.mailgroup.interior(),labelpos = 'w',label_text = 'User:')
        self.txt_username_mail.insert( INSERT,self.mail['mailuser'] )
        #password
        self.txt_password_mail =Pmw.EntryField(self.mailgroup.interior(),labelpos = 'w',label_text = 'Password:')
        self.txt_password_mail.component('entry').config(show='*')
        #self.cbb_svr.component('entry').config(state =DISABLED)
        #,show='*'
        self.txt_password_mail.insert( INSERT,self.mail['mailpaswd'] )
        for entry in (self.txt_mail_srvr,self.txt_smtp_srvr,self.txt_username_mail,self.txt_password_mail):
            entry.pack(fill='x',pady='4',padx='1')
        Pmw.alignlabels(entries)
        #button
        self.Savmail = Button(self.mailserverpg,text ='Apply',command=self.savemail)
        self.Savmail.pack(side=RIGHT,padx='10')


        self.add={}
        self.upf.getuserpf('contact.profile',self.add)
        self.addbookpg = self.mailnotebook.add('Contact List')

        #self.FavName = self.web.keys()
        self.CURRENT_SELECTED_MAIL_CONTACT = ''
        self.ContactList = Pmw.ComboBox(self.addbookpg,
                                    listbox_height='4',
                                    label_text = 'Contact Name:',
                                    labelpos = 'nw',
                                    scrolledlist_items = self.add.keys(),
                                    dropdown = 0,
                                    selectioncommand=self.selectionAddressContactList
                                    )
        self.ContactList.pack(fill='x')
        self.ContactAddr = Pmw.EntryField(self.addbookpg,labelpos = 'nw',label_text = 'Email:',validate = None)
        self.ContactAddr.pack(fill='x')

        self.frmBttnmailcont = Frame(self.addbookpg)
        self.frmBttnmailcont.pack(side='bottom',pady ='2')
        self.addCont = Button(self.frmBttnmailcont,text ='Add',width='5',command=self.addcont)
        self.addCont.pack(side='left',pady='1')
        self.SavCont = Button(self.frmBttnmailcont,text ='Apply',width='5',command=self.savecont)
        self.SavCont.pack(side='left',pady='1')
        self.DelCont = Button(self.frmBttnmailcont,text ='Delete',width='5',command=self.deletecont)
        self.DelCont.pack(side='left',pady='1')




#Favourite Page
        self.page3 = self.notebook.add('Favourite')
        self.notebook.tab('Favourite').focus_set()                

        self.web={}
        self.upf.getuserpf('web.profile',self.web)

        #self.FavName = self.web.keys()
        self.CURRENT_SELECTED_FAVOURITE = ''
        self.FavList = Pmw.ComboBox(self.page3,
                                    listbox_height='6',
                                    label_text = 'Favourite Name:',
                                    labelpos = 'nw',
                                    scrolledlist_items = self.web.keys(),
                                    dropdown = 0,
                                    selectioncommand=self.selectionAddress
                                    )
        self.FavList.pack(fill='x')
        self.FavAddr = Pmw.EntryField(self.page3,
                                      labelpos = 'nw',
                                      label_text = 'URL:',
                                      validate = None)
        self.FavAddr.pack(fill='x')

        self.frmBttnFav = Frame(self.page3)
        self.frmBttnFav.pack(side='bottom',pady ='2')
        self.addFav = Button(self.frmBttnFav,text ='Add',width='5',command=self.addfav)
        self.addFav.pack(side='left',pady='3')
        self.SavFav = Button(self.frmBttnFav,text ='Save',width='5',command=self.savefav)
        self.SavFav.pack(side='left',pady='3')
        self.DelFav = Button(self.frmBttnFav,text ='Delete',width='5',command=self.deletefav)
        self.DelFav.pack(side='left',pady='3')

        self.setcolor(self.SELECT_COLOR_NUMBER)





## ** Detail  ** ########################################################################
        
    def savedetail(self):
        print 'Personal detail Saved'
        self.dtl['name']=self._name.get()
        self.dtl['address']=self._address.get()
        self.dtl['telephone']=self._tel.get()
        self.dtl['email']=self._email.get()
        self.upf.saveuserpf('detail.profile',self.dtl) 

#    def savemailadd(self):
            #self.mailpf.saveuserpf('contact.profile',self.Addbook)



## **  FTP  ** ########################################################################

    def saveftp(self):
        print 'FTP Config Saved'
        self.ftp['server']=self.txt_ftphost.get()
        self.ftp['port']=self.txt_ftpport.get()
        self.ftp['username']=self.txt_ftpusername.get()
        self.ftp['password']=self.txt_ftppassword.get()
        self.upf.saveuserpf('ftp.profile',self.ftp)


## **  Mail  ** ########################################################################

    def savemail(self):
        print 'Mail Config Saved'
        '''select = self.AddList.getcurselection()
        if select <> ():
            key,value = select[0].split('::')
            print key+' === '+ value
            self.add[key]=value
            self.Addbook=[]
            for i,v in self.add.items():
                self.Addbook.append(i+'::'+v)
            self.AddList.setlist(self.Addbook)
        '''
        self.mail['mailserver']=self.txt_mail_srvr.get()
        self.mail['smtpserver']=self.txt_smtp_srvr.get()
        self.mail['mailuser']=self.txt_username_mail.get()
        self.mail['mailpaswd']=self.txt_password_mail.get()
        self.upf.saveuserpf('mail.profile',self.mail)
        
        
    def selectionAddressContactList(self,list):
        print 'selectionAddressContactList'
        self.CURRENT_SELECTED_MAIL_CONTACT = list
        if self.add.has_key(list):
            self.ContactAddr.setvalue(self.add[list])

    def addcont(self):
        newname = self.ContactList.component('entry').get()
        value = self.ContactAddr.get()
        if newname<>'' and value <>'':
            self.add[newname]=value
            self.__updatecont()
        #self.ContactAddr.clear()
        #self.CURRENT_SELECTED_MAIL_CONTACT =''
        
    def savecont(self):
        #print 'save contact'
        select = self.ContactList.getcurselection()
        newname = self.ContactList.component('entry').get()
        if select<>() and select[0]<>newname:
            del self.add[select[0]]
            self.add[newname]=self.ContactAddr.get()
        else:
            self.add[newname]=self.ContactAddr.get() #self.web[]
        self.__updatecont()
        
    def deletecont(self):
        #print 'delete contact()'
        select = self.ContactList.getcurselection()
        newname = self.ContactList.component('entry').get()
        if select<>() and select[0]==newname:
            self.ContactList.component('entry').delete(0,END)
            self.ContactAddr.delete(0,END)
            del self.add[select[0]]
        self.__updatecont()

    def __updatecont(self):
        self.ContactList.setlist(self.add.keys())
        self.upf.saveuserpf('contact.profile',self.add)


## ** Favourite  ** ########################################################################
        
    def selectionAddress(self,list):
        self.CURRENT_SELECTED_FAVOURITE = list
        if self.web.has_key(list):
            self.FavAddr.setvalue(self.web[list])

    def addfav(self):
        newname = self.FavList.component('entry').get()
        value = self.FavAddr.get()
        if newname<>''and value <>'':
            self.web[newname]=value
            self.__updatefar()
        #self.FavAddr.clear()
        #self.CURRENT_SELECTED_FAVOURITE =''
        
    def savefav(self):
        #print 'save favourite'
        select = self.FavList.getcurselection()
        newname = self.FavList.component('entry').get()
        if select<>() and select[0]<>newname:
            del self.web[select[0]]
            self.web[newname]=self.FavAddr.get()
        else:
            self.web[newname]=self.FavAddr.get() #self.web[]
        self.__updatefar()
        
    def deletefav(self):
        #print 'delete favourite()'
        select = self.FavList.getcurselection()
        newname = self.FavList.component('entry').get()
        if select<>() and select[0]==newname:
            self.FavList.component('entry').delete(0,END)
            self.FavAddr.delete(0,END)
            del self.web[select[0]]
        self.__updatefar()
        
    def __updatefar(self):
        self.FavList.setlist(self.web.keys())
        self.upf.saveuserpf('web.profile',self.web)


########################################################################



    def ok(self):
        self.savedetail()
        self.saveftp()
        self.savemail()
        self.destroy()

    def cancel(self):
        self.destroy()


########################################################################

    def changeColour(self,list):
        if list=='c1':
            self.setcolor(1)
        elif list=='c2':
            self.setcolor(2)
        elif list=='c3':
            self.setcolor(3)
        if list=='c4':
            self.setcolor(4)
        self.dtl['color']=list
        

    def setcolor(self,number):
      ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
      clr = self.mycolor.getcolor(number)
      Pmw.Color.changecolor(self,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       )
      
#if __name__ == "__main__":
 #   root = Tk()
  #  shell = user(root)
   # root.mainloop()