#
#"""----- flu.py -----
# Utilities for handling python name space (frame, globals, locals, etc)
# 
# """
# Telion
#

from flist import f_list	

def f_list_filter(item,value):
	"""get list of (frame, codeobj) paires which match
	(item == value) criteria.
	See fru.__doc__ for more"""
	
	l=f_list()
	result=[]
	if item[:3]=='co_':
		i=1
	elif item[:2]=='f_':
		i=0
	else:
		return None
	for ll in l:
		if eval( 'll[i].'+item+"=="+repr(value)):
			result.append(ll)
	return result

def globals_b():
	"""returns globals() of python base level.
	In WindowsCE, that is the globals() of ceshell.py level."""
	return f_list()[-1][0].f_globals
def globals_i():
	"""returns globals() of python interactive level.
	In WindowsCE, that is the globals() of interpreter level."""
	#return f_list_filter("co_name","?")[0][0].f_globals
	return f_list()[-3][0].f_globals # quicker this way (for CE)
def globals_x(i):
	"""returns globals of any frame level.
	i == 0 -> current frame, i == 1 -->caller, 
	i == -3 Interactive or Interpreter(in CE), i == -1 Base level"""
	if i >= 0:
		i=i+2
	return f_list()[i][0].f_globals

def glokeys_b():
	"""reterns locals_b().keys(). python base level"""
	return f_list()[-1][0].f_globals.keys()
def glokeys_i():
	"""reterns locals_b().keys(). python Interpreter level"""
	return f_list_filter("co_name","?")[0][0].f_globals.keys()
def glokeys():
	"""reterns locals_b().keys(). """
	return globals().keys()

def locals_b():
	"""returns locals() of python base level.
	In WindowsCE, that is the locals() of ceshell.py level."""
	return f_list()[-1][0].f_locals
def locals_i():
	"""returns locals() of python interactive level.
	In WindowsCE, that is the locals() of interpreter level."""
	#return f_list_filter("co_name","?")[0][0].f_locals
	return f_list()[-3][0].f_locals
def locals_x(i):
	"""returns locals() of any frame level.
	i == 0 -> current frame,  i == 1 -->caller, 
	i == -3 Interactive or Interpreter,  i == -1 Base level"""
	if i >= 0:
		i=i+2
	return f_list()[i][0].f_locals

def lokeys_b():
	"""reterns locals_b().keys(). python base level"""
	return f_list()[-1][0].f_locals.keys()
def lokeys_i():
	"""reterns locals_i().keys(). interpreter level"""
	return f_list_filter("co_name","?")[0][0].f_locals.keys()
def lokeys():
	"""returns locals.keys()."""
	return locals().keys()

def f_list_dic():
	"""return the dictionary of (function_name, (frame_obj,code_obj)) pair"""
	l=f_list()
	ld={}
	for i in l:
		ld[i[1].co_name]=i
	return ld

def lp(l):
	"""print out the list vertically"""
	for ll in l: print repr(ll)
def dp(d):
	"""print out the dictionary vertically"""
	for k,v in d.items(): print k, repr(v)

def flevel():
	return len(f_list())-1
	

def setlocal(keys,fid=None): # import the name and object from differnt frame
	# copy the (k) entry in Interpreter level locals() to this locals()
	if type(keys)==type(''):
		k=keys
		keys=[k]
	if not fid:
		fid=1
	else:
		fid = -1-fid
	gx=globals_x(fid)
	exec "from flu import globals_i" in gx
	for k in keys:
		#if globals_i().has_key(k):
		exec k+"=globals_i()['"+k+"']" in gx
			 # if the key is not in the Ineterpreter locals, create the key
	
def exec_i(cmd):
	exec cmd in globals_i()

def eval_i(cmd):
	return eval(cmd,globals_i())
