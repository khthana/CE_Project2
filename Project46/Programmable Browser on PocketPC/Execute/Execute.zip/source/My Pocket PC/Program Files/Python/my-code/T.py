
import threading
import time

class CheckEvenThread( threading.Thread ):
   
   def __init__( self, threadName='def',isleepTime=5):
      threading.Thread.__init__( self, name = threadName )
      if isleepTime<1:
          isleepTime=1
      self.sleepTime = isleepTime
      self.count=0
      print "Name: %s; sleep: %d" % \
            ( self.getName(), self.sleepTime )
     
   def run( self ):
      while self.count<5:
         self.count =self.count+1
         self.li = time.localtime(time.time())
         print "%s|t=%s|c=%s@%s:%s:%s  " % \
            ( self.getName(), self.sleepTime ,self.count,self.li[3],self.li[4],self.li[5])
         time.sleep( self.sleepTime )
       






