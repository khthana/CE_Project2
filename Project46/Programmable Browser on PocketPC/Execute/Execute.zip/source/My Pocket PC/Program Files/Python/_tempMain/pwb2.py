from Tkinter import *
#from ttt import *
from ftpgui import ftp
from mailgui import mail
from browsergui import browser
from Script7 import Demo
#from temp import Dialog
import Pmw
from config import *
import tkFileDialog

def fp():
    fp = ftp(root)

def ml():
    #m = mail(root)
    widget = Demo(root)

def wb():
    wb = browser(root)

def diropenbox(msg=None, title=None, argInitialDir=None):
	"""A dialog to get a directory name.
	Note that the msg argument, if specified, is ignored.

	Returns the name of a directory, or None if user chose to cancel.

	If an initial directory is specified in argument 3,
	and that directory exists, then the
	dialog box will start with that directory.
	"""
	root = Tk()
	root.withdraw()
	if argInitialDir == None:
		f = tkFileDialog.askdirectory(
			parent=root, title=title)
	else:
		f = tkFileDialog.askdirectory(
			parent=root, title=title, initialdir=argInitialDir)
	if f == "": return None
	return f

def fileopenbox(msg=None, title=None, argInitialFile=None):
	"""A dialog to get a file name.
	Returns the name of a file, or None if user chose to cancel.

	if argInitialFile contains a valid filename, the dialog will
	be positioned at that file when it appears.
	"""
	root = Tk()
	root.withdraw()
	f = tkFileDialog.askopenfilename(
		parent=root,title=title, initialfile=argInitialFile)
	if f == "": return None
	return f


#-------------------------------------------------------------------
# filesavebox
#-------------------------------------------------------------------
def filesavebox(msg=None, title=None, argInitialFile=None):
	"""A file to get the name of a file to save.
	Returns the name of a file, or None if user chose to cancel.

	if argInitialFile contains a valid filename, the dialog will
	be positioned at that file when it appears.
	"""
	root = Tk()
	root.withdraw()
	f = tkFileDialog.asksaveasfilename(
		parent=root, title=title, initialfile=argInitialFile)
	if f == "": return None
	return f

#filepath= 'D:\\Project\\Example\\ch11\\Temp\\'
filepath = picpath

root = Tk()
toolbar = Frame(root)
toolbar2 = Frame(root)
frame = Frame(root)

Pmw.initialise()
myBalloon = Pmw.Balloon(root)
choices = Pmw.MenuBar( root )
choices.pack( fill = X )

choices.addmenu( "File","File")
choices.addmenuitem( "File", "command", label = "New" ,command=filesavebox)
choices.addmenuitem( "File", "command", label = "Open..." ,command =fileopenbox)
choices.addmenuitem( "File", "command", label = "Save" ,command=fileopenbox)
choices.addmenuitem( "File", "command", label = "Exit" ,command=root.destroy)

choices.addmenu("Edit","Edit")
choices.addmenuitem( "Edit", "command", label = "Undo" )

choices.addmenu("Command","Command")
choices.addmenuitem( "Command", "command", label = "Test script" )
choices.addmenuitem( "Command", "command", label = "Run script" )

choices.addmenu("Tools","Tools")
choices.addmenuitem( "Tools", "command", label = "Web Browser" )
choices.addmenuitem( "Tools", "command", label = "File Transfe" )
choices.addmenuitem( "Tools", "command", label = "Mail Service" )
choices.addcascademenu( "Tools", "Other" )
choices.addmenuitem( "Other", "command", label = "Internet Explorer" )
choices.addmenuitem( "Other", "command", label = "Calculator" )
choices.addmenuitem( "Other", "command", label = "Note pad" )

myImage0 = PhotoImage( file = filepath + "mail.gif" )
b = Button(toolbar, image = myImage0,relief = RAISED,command = ml,border="0")
b.pack(side=LEFT)
myImage1 = PhotoImage( file = filepath + "wb.gif" )
b = Button(toolbar,image = myImage1,relief = GROOVE,command = wb,border="0")
b.pack(side=LEFT)
myImage2 = PhotoImage( file = filepath + "ftp.gif" )
b = Button(toolbar,image = myImage2,relief = GROOVE,command = fp,border="0")
b.pack(side=LEFT)
toolbar.pack(side=TOP, fill=X)


notebook = Pmw.NoteBook(root)
notebook.pack(fill = 'both', expand = 1)

page = notebook.add('Script Editor')
notebook.tab('Script Editor').focus_set()

scrollbar = Scrollbar(page)
#scrollbar2 = Scrollbar(frame)
textBox = Text(page,yscrollcommand=scrollbar.set)
scrollbar.config(command=textBox.yview)
#scrollbar2.config(command=textBox.xview)
scrollbar.pack(side=RIGHT, fill=Y)
#scrollbar2.pack(fill=X)
textBox.pack(fill=BOTH,expand=2)

page2 = notebook.add('Event List')
notebook.tab('Event List').focus_set()

scrollbar = Scrollbar(page2)
#scrollbar2 = Scrollbar(frame)
textBox = Text(page2,yscrollcommand=scrollbar.set)
scrollbar.config(command=textBox.yview)
#scrollbar2.config(command=textBox.xview)
scrollbar.pack(side=RIGHT, fill=Y)
#scrollbar2.pack(fill=X)
textBox.pack(fill=BOTH,expand=2)

#frame
frame.pack(expand = NO)
frame.master.geometry("235x270")
frame.master.title("PWB")

root.mainloop()