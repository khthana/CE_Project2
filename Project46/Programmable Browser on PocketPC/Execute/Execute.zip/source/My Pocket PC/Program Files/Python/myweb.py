'''
| change <myweb.py> change form <open_url.py>
| and change class name form <open_web> to <myweb>
| Base Module for browsergui.py
| return a html file with a input url 
|----------------------------------------------
| 2004/03/08
| change from origenal file open_url.py
| 2004/03/08
| add exception hendle and def getheader(self)
| 2004/03/15
| print correctly
'''

import httplib
import urllib



class myweb:
    
    def __init__( self ):
        #print " openWeb  __init__"
        self.header = {}
        self.GET_PAGE = False


    def open( self, url='' ):
        """ open input url  and  set all header to dictionary  <def getheader(self):> """
        if url=="":
            #url="http://www.google.com/"
            #url="http://161.246.5.54:8080/index.html"
            #url = "http://www.w3.org/MarkUp/"
            url = "http://www.ce.kmitl.ac.th"
            
        self.GET_PAGE = False    
        print 'open Web->'+url
        self.page = ''
        self.tempPage = '\n ERROR ON REQUEST \n +    '+url
        
        try:    
            self.inurl = url
            
            self.page =  urllib.urlopen(url)
            self.tempPage = ''
            for key, value in self.page.headers.items() :
                self.header[key] = value
            while 1:
                line = self.page.readline()
                self.tempPage=self.tempPage + line +"\n"
                if not line:
                    break
            self.GET_PAGE = True
        except Exception:
            self.inurl = ''
            self.GET_PAGE = False
            #print self.tempPage
            
        return self.tempPage


    def getheader(self):
        #print "myweb.getheader()"
        if self.GET_PAGE:
            return self.header
        else:
            return {}


"""
 outputfile = open("ounputfile.html","wb")


print page.url,"\n"
#print len(page.read()),"\n"



print " begin input data  \n ---------------------------------------------------------------------------------"	
while 1:
	line = page.readline()

	if line.find("src")!=-1:
		
		listimg = line.split("src");
		for list2 in listimg:
			list3 = list2.split(" ",1) 
			print "\n\n",list3[0]
			

		print line
		print "\n\n"

	outputfile.write(line)
	if not line:
		break


outputfile.close()










#	num = stri.find(key)
#	if num!=-1:











#url='www.google.com'
#urlpath='/index.html'

#host = httplib.HTTP(url)
#host.putrequest("GET",urlpath)
#host.putheader("Accept","text/html")
#host.endheaders()

#headers host.getreply()
#errcode = 300 
#if errcode != 200:
#	raise RuntimeError
#htmlfile = host.getfile()
#htmlpage = htmlfile.read()

#for line in htmlpage:
#	print line
	
#htmlfile.close()
#return htmlpage


"""
