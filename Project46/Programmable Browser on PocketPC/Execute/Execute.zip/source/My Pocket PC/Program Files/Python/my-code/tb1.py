from Tkinter import *
root=Tk()

frame = Frame()
frame.pack( padx=2,pady=2)

text1 = Entry(frame, name = 'text1')
text1.insert( INSERT,"bbb")
text1.bind( "<Return>",changtext)

text1.pack( pady=5,side=LEFT)


root.mainloop()

#checkbutton1=Checkbutton(frame,text='Cbutton1',variable = boldOn,command = changtext)
#checkbutton1.pack( side=LEFT, padx=2, pady=2)

def changtext(self, event):
    #theName = event.widget.winfo_name()
    #theContents = event.widget.get()
    # text1.insert( INSERT,theName+" : "+theContents)
     text1.insert( INSERT,"aaa")
    
    
