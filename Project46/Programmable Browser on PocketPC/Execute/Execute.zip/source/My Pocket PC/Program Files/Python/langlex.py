'''
This is a lexical program for CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 24 Nov. 2002, 18:37
================================================
Comment : adding new tokens,TIME and INTERVAL.

-------------------------------------
Chckrit Hengsirikul

 2004-02-27
 add def mktime(-) to support PythonCE
 pythonCE time.mktime() don't work
 
'''



import lex
import time

# add mktime to support PythonCE
# pythonCE time.mktime() don't work
# 2004-02-27
def mktime(mytime):
    #print "\n",mytime
    yr = mytime[0]
    #yr=yr-1970
    mo = mytime[1]
    dy = mytime[2]
    hr = mytime[3]
    mn = mytime[4]
    sc = mytime[5]
    # Determine machine epoch
    tm=((0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334),(0, 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335))
    #yr,mo,dy,hr,mn,sc=gmtime(second)[:6]
    i=int(yr-1)
    to_year =int(i*365+i/4-i/100+i/400-693960.0)
    to_month=tm[yr%4==0 and (yr%100!=0 or yr%400==0)][mo]
    EPOCH  =(to_year+to_month+dy)*86400+hr*3600+mn*60+sc - 2177564400.0
    #EPOCH = EPOCH - 2177564400.0 #2180242800.0 + 2678400.0#2174886000.0 #  #2177539200.0 - 25200.0
    return EPOCH


# Reserved words
reserved = (
	'DEF','ELIF', 'ELSE','FOR','IF', 'RETURN','WHILE','TO',
	'REPEAT','UNTIL','IMPORT','AND','OR','NOT',
	'MI','M','OI','O','DI','D','SI','S','FI','F',
	'Q'
	) #change T to Q

#tokens ' name
tokens = reserved + (
	'ID',
	'INTNUM','FLOATNUM','LONGNUM','COMPLEXNUM',
	'PLUS','MINUS','MUL','DIVIDE','POWER','MOD','UINVERSE',
	'ANDOP','OROP','XOROP','ANDEQ','OREQ','XOREQ',
	'SHIFTL','SHIFTR','SHIFTLEQ','SHIFTREQ',
	'LPAREN','RPAREN',
	'LESS','GREATER','LESSEQ','GREATEREQ','EQ','NOTEQ',
	'PLUSEQ','MINUSEQ','MULEQ','DIVEQ','MODEQ','POWEREQ','EQUALS',
	'TP','TD','COLON','SEMI','LBRACE','RBRACE',
	'STRING','LBRACKET','RBRACKET','COMMENT','COMMA', 'UNDER',
	'EXTENDL','EXTENDR','SHRINKL','SHRINKR','OCC',
	'UNORDERED','PARALLEL')

#########
##Token##
#########
#t_UNDER = r'\_ '

t_ANDOP = r'&'
t_OROP = r'\|'
t_XOROP = r'\^'

t_OCC = r'-->'
t_SHIFTLEQ = r'<<='
t_SHIFTREQ = r'>>='
t_SHIFTL = r'<<'
t_SHIFTR = r'>>'
t_EXTENDL = r'<-'
t_EXTENDR = r'->'
t_SHRINKL = r'>-'
t_SHRINKR = r'-<'

t_UNORDERED = r'\#'
t_PARALLEL = r'\\\\'

#t_PARALLEL = r'\#'
#t_UNORDERED = r'\\\\'

t_UINVERSE = r'~'

t_PLUSEQ = r'\+='
t_MINUSEQ = r'-='
t_MULEQ = r'\*='
t_DIVEQ = r'/='
t_MODEQ = r'%='
t_POWEREQ = r'\*\*='

#Operators
t_PLUS = r'\+'
t_MINUS = r'-'
t_MUL = r'\*'
t_DIVIDE = r'/'
t_POWER = r'\*\*'
t_MOD = r'%'

t_ANDEQ = r'&='
t_OREQ = r'\|='
t_XOREQ = r'\^='

#Parentesis
t_LPAREN = r'\('
t_RPAREN = r'\)'

#Comparison
t_LESSEQ = r'<='
t_GREATEREQ = r'>='
t_LESS = r'<'
t_GREATER = r'>'
t_EQ = r'=='
t_NOTEQ = r'!='

t_SEMI = r';'
t_COMMA = r','
#t_DCOLON = r'::'
t_COLON = r':'
t_LBRACE = r'\{'
t_RBRACE = r'\}'

t_LBRACKET = r'\['
t_RBRACKET = r'\]'

#Assign
t_EQUALS = r'='


#t_ID = r'[a-zA-Z_][a-zA-Z0-9_]*'

# Identifiers and reserved words

symbol_table = { }
for r in reserved:
    symbol_table[r.lower()] = r

#Name of variable

def t_ID(t):
    r'[a-zA-Z][a-zA-Z0-9_]*'
    t.type = symbol_table.get(t.value,"ID")
    return t

#t_COMMENT = r'![\w~\#\"\$%&\^\*\(\)-\+=\[\]\{\}<>,\./\';:\|\?\\ ]*'

t_STRING = r'\"[\w~!#\$%&@\^\*\(\)-\+=\[\]\{\}<>,\./\';:\|\?\\ ]*\"'

t_UNDER = r'_'

#Number

#TIME Token
def t_TP(t):
	r'(([1-9]|[0-1][0-9])|2[0-3]):[0-5][0-9]:[0-5][0-9]\|(([0-2][0-9])|3[0-1])/(([1-9])|1[0-2])/[0-9][0-9][0-9][0-9]'
	temp = t.value.split("|")
	temp_clock = temp[0].split(":")
	temp_date = temp[1].split("/")
	t.value = [0,0,0]
	index = 2
	for s in temp_date:
		t.value[index]=(eval(s))
		index -= 1
	for s in temp_clock:
		t.value.append(eval(s))
	t.value.extend([0,0,0])
	#(2004, 2, 10, 9, 0, 0, 0, 0, 0)
	#print "t.value : ",t.value
	#t.value = time.mktime((2004, 2, 10, 9, 0, 0, 0, 0, 0))
	t.value = mktime(t.value)
	print "t.value kim: ",t.value
	return t

def t_TD(t) : 
# Such as 5.5d,2m,8y or 50h
	r'((\d+|(\d+)\.\d+)(min|[dhs]))(,(\d+|(\d+)\.\d+)(min|[dhmsy]))*'
	temp = t.value[0:len(t.value)].split(",")
	value = [0,0,0,0]
	for element in temp :
		if element[len(element)-1] == "d" :
			value[0] += eval(element[0:len(element)-1])
		elif element[len(element)-1] == "h" :
			value[1] += eval(element[0:len(element)-1])
		elif (element[len(element)-3] == "m") and (element[len(element)-2] \
		== "i") and (element[len(element)-1] == "n") :
			value[2] += eval(element[0:len(element)-3])
		elif element[len(element)-1] == "s" :
			value[3] += eval(element[0:len(element)-1])
	t.value = value[0]*86400 + value[1]*3600 + value[2]*60 + value[3]
	return t

def t_COMPLEXNUM(t) :
	r'((\d+|(\d+)\.\d+))[\+-](\d+|(\d+)\.\d+)[jJ]'
	try :
		t.value = complex(t.value)
	except ValueError :
		print "Long value too large : ",t.value
		t.value = complex(0)
	return t

def t_FLOATNUM(t) :
	r'(\d+)\.\d+'
	try :
		t.value = float(t.value)
	except ValueError :
		print "Float value too large : ",t.value
		t.value = float(0)
	return t

def t_LONGNUM(t) :
	r'(\d+)[lL]'
	try :
		t.value = long(t.value)
	except ValueError :
		print "Long value too large : ",t.value
		t.value = long(0)
	return t


def t_INTNUM(t) :
	r'\d+'
	try :
		t.value = int(t.value)
	except ValueError :
		print "Integer value too large : ",t.value
		t.value = 0
	return t

t_ignore = " \t"

def t_NEWLINE(t) :
	r"\n+"
	t.lineno += t.value.count("\n")

def t_error(t) :
	print "Illegal character '%s'" %t.value[0]
	t.skip(1)

lex.lex()