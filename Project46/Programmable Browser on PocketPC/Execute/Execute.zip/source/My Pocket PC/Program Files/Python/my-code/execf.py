import sys
dir = 'C:\\PythonCE\\'
dir = '\\Program Files\\Python\\'

execfile(dir+'ftpgui.py',{})