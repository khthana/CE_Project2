mailpaswd :: kritnum
mailuser :: h_chakrit@163.com
mailsavepath :: \Program Files\Python\userprofile\mail\
mailfilename :: mail.txt
smtpserver :: diamond.ce.kmitl.ac.th
mailserver :: pop.163.com
