'''
semantic.py == Version1.3.1
This is a semantic for parsing CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 24 Nov. 2002, 18:36
================================================
Comment : correcting process of assignment.
If assign symbol is "=",it must fork new type for the value from definite AST.
'''

#import Built_ins
from BuiltInFn import *
from parsing import *
from communication import *
from eventmodule import *
import time
import sys
import thread
import whrandom
import abstract
import threading

ids = {}
functions = {}
activeFunctions = []
retValue = 0
calendar = {1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
process_stack = []
process_id = 0
startMsgCount = 0
return_value = abstract.IntNum(1)


def interprete(ast) :
	if (ast.type == "defineFunction") : function[ast.name] = ast
	elif (ast.type == "event_action") : thread.start_new_thread(eventListener,(ast,))
	elif (ast.type == "interval_statement") : execute_interval_statement(ast)
	else : execute_statement(ast)
	#print "final process stack : ",process_stack

def eventListener(ast) :
	#ps = ast.event.time_handle.value[0].value
	#pe = ast.event.time_handle.value[1].value
	start = ast.event.time_handle.value[0]
	end = ast.event.time_handle.value[1]
	if (start.type == "id") : ps = execute_statement(start)
	else : ps = start.value
	if (end.type == "id") : pe = execute_statement(end)
	else : pe = end.value
	if (ps != []) : time.sleep(ps - time.time())
	event_happen = 0
	if (pe != []) :
		while ((time.time()<=pe) and (event_happen==0)) :
			if execute_statement(ast.event.event_type).value :
				execute_interval_statement(ast.action)
				event_happen = 1
	else :
		while (event_happen == 0) :
			if execute_statement(ast.event.event_type).value :
				execute_interval_statement(ast.action)
				event_happen =1

def execute_interval_statement(ast) :
	#ps = ast.interval.value[0].value
	#pe = ast.interval.value[1].value
	start = ast.interval.value[0]
	end = ast.interval.value[1]
	if (start.type == "id") : ps = execute_statement(start).value
	else : ps = start.value
	if (end.type == "id") : pe = execute_statement(end).value
	else : pe = end.value
	
	if (pe != []) :
		if (ps != []) : time.sleep(ps - time.time())
		thread.start_new_thread(execute_statement,(ast.stmts,))
		time.sleep(pe - time.time())
		if (process_stack != []) : sys.exit(0)
	else :
		if (ps != []) : time.sleep(ps - time.time())
		execute_statement(ast.stmts)

def execute_statement(stm) :
	global retValue
	global process_id
	global return_value
	global startMsgCount
	process_id += 1
	id = process_id
	#print "begin id : ",id
	#print "begin process stack : ",process_stack
	process_stack.append(id)
	if stm.type == "id" :
		if activeFunctions != [] :
			activeRecord = activeFunctions[len(activeFunctions)-1]
			try :
				value = activeRecord[1][stm.id]
			except LookupError :
				print "Undefined name '%s'" %stm.id
				value = 0
		else :
			try :
				value = ids[stm.id]
				#print "value : ",value.value
			except LookupError :
				print "Undefined name '%s'" %stm.id
				value = 0
		return_value = value

	elif stm.type == "int" :
		return_value = stm
	
	elif stm.type == "float" :
		return_value = stm
	
	elif stm.type == "long" :
		return_value = stm
	
	elif stm.type == "complex" :
		return_value = stm
	
	elif stm.type == "list" :
		#print "List : ",stm.value
		return_value = stm
	
	elif stm.type == "dictionary" :
		return_value = stm
	
	elif stm.type == "string" :
		#print "test : ",stm.value
		return_value = stm
	
	elif stm.type == "tp" :
		return_value = stm
	
	elif stm.type == "td" :
		return_value = stm
	
	elif stm.type == "ti" :
		return_value = stm
	
	elif stm.type == "sequence" :
		for stmt in stm.value :
			execute_interval_statement(stmt)
	
	elif stm.type == "unordered" :
		stmt_list = stm.value
		while (stmt_list != []) :
			index = whrandom.randint(0,len(stmt_list)-1)
			execute_interval_statement(stmt_list[index])
			stmt_list.remove(stmt_list[index])
	
	elif stm.type == "parallel" :
		threads = []
		for stmt in stm.value :
			t = threading.Thread(target=execute_interval_statement,args=(stmt,))
			threads.append(t)
		for i in range(len(stm.value)) :
			threads[i].start()
		while (process_stack[len(process_stack)-1] != id) : pass
	
	elif stm.type == "defineFunction" :
		functions[stm.name] = stm
		#print "functions : ",functions
	
	elif stm.type == "module" :
		filename = ".\\scripts\\" + stm.name + ".txt"
		print "FileName = ",filename
		file = open(filename,'r')
		moduleScripts = file.readlines()
		file.close()
		moduleList = filter(moduleScripts)
		print "moduleList : ",moduleList
		for script in moduleList :
			parseObj = Parse(script)
			stmList = parseObj.stm
			for stm in stmList :
				if stm.type in ["defineFunction","assignstmt"] : execute_statement(stm)

	elif stm.type == "boolean" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '<' : value = left_value.less(right_value)
		elif stm.op == '>' : value = left_value.more(right_value)
		elif stm.op == '<=' : value = left_value.lesseq(right_value)
		elif stm.op == '>=' : value = left_value.moreeq(right_value)
		elif stm.op == '==' : value = left_value.eq(right_value)
		elif stm.op == '!=' : value = left_value.noteq(right_value)
		elif stm.op == 'mi' : value = left_value.metBy(right_value)
		elif stm.op == 'm' : value = left_value.meet(right_value)
		elif stm.op == 'oi' : value = left_value.overlapBy(right_value)
		elif stm.op == 'o' : value = left_value.overlap(right_value)
		elif stm.op == 'di' : value = left_value.contain(right_value)
		elif stm.op == 'd' : value = left_value.during(right_value)
		elif stm.op == 'si' : value = left_value.startBy(right_value)
		elif stm.op == 's' : value = left_value.start(right_value)
		elif stm.op == 'fi' : value = left_value.finishBy(right_value)
		elif stm.op == 'f' : value = left_value.finish(right_value)
		#print "boolean value : ",value.value
		return_value = value
	
	elif stm.type == "logic" :
		left_value = execute_statement(stm.left)
		if stm.right != None : right_value = execute_statement(stm.right)
		if stm.op == "and" : value = left_value.andLogic(right_value)
		elif stm.op == "or" : value = left_value.orLogic(right_value)
		elif stm.op == "not" : value = left_value.notLogic()
		return_value = value

	elif stm.type == "shiftop" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '<<' : value = left_value.shiftl(right_value)
		elif stm.op == '>>' : value = left_value.shiftr(right_value)
		return_value = value
	
	elif stm.type == "extendop" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '<-' : value = left_value.extendl(right_value)
		elif stm.op == '->' : value = left_value.extendr(right_value)
		return_value = value
	
	elif stm.type == "shrinkop" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '>-' : value = left_value.shrinkl(right_value)
		elif stm.op == '-<' : value = left_value.shrinkr(right_value)
		return_value = value

	elif stm.type == "bitwiseop" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '&' : value = left_value.andfn(right_value)
		elif stm.op == '|' : value = left_value.orfn(right_value)
		elif stm.op == '^' : value = left_value.xorfn(right_value)
		return_value = value

	elif stm.type == "unaryop" :
		right_value = execute_statement(stm.right)
		if stm.op == '+' : value = right_value
		elif stm.op == '-' : value = right_value.minus()
		elif stm.op == '~' : value = right_value.inverse()
		#print "unary"
		return_value = value

	elif stm.type == "binop" :
		left_value = execute_statement(stm.left)
		right_value = execute_statement(stm.right)
		if stm.op == '+' : value = left_value.add(right_value)
		elif stm.op == '-' : value = left_value.sub(right_value)
		elif stm.op == '*' : value = left_value.mul(right_value)
		elif stm.op == '/' : value = left_value.div(right_value)
		elif stm.op == '**' : value = left_value.power(right_value)
		elif stm.op == '%' : value = left_value.mod(right_value)
		#print value
		return_value = value
	
	elif stm.type == "function" :
		localsVar = {}
		if (stm.name == "print") and (len(stm.parameter)==1) : printMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "abs") and (len(stm.parameter)==1) : retValue = absMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "divmod") and (len(stm.parameter)==2) : retValue = divmodMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
		elif (stm.name == "round") and (len(stm.parameter)==1) : retValue = roundMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "pow") and (len(stm.parameter)==2) : retValue = powMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
		elif (stm.name == "real") and (len(stm.parameter)==1) : retValue = realMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "imag") and (len(stm.parameter)==1) : retValue = imagMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "len") and (len(stm.parameter)==1) : retValue = lenMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "min") and (len(stm.parameter)==1) : retValue = minMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "max") and (len(stm.parameter)==1) : retValue = maxMethod(execute_statement(stm.parameter[0]))
		elif (stm.name == "append") and (len(stm.parameter)==2) : 
			if stm.parameter[0].type != "id" : error()
			result = appendMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "extend") and (len(stm.parameter)==2) : 
			if stm.parameter[0].type != "id" : error()
			result = extendMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "count") and (len(stm.parameter)==2) : 
			retValue = countMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
		elif (stm.name == "index") and (len(stm.parameter)==2) : 
			retValue = indexMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
		elif (stm.name == "insert") and (len(stm.parameter)==3) : 
			if stm.parameter[0].type != "id" : error()
			result = insertMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]),execute_statement(stm.parameter[2]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "pop") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = popMethod(execute_statement(stm.parameter[0]))
			ids[stm.parameter[0].id] = result[0]
			retValue = result[1]
		elif (stm.name == "remove") and (len(stm.parameter)==2) :
			if stm.parameter[0].type != "id" : error()
			result = removeMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "reverse") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = reverseMethod(execute_statement(stm.parameter[0]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "sort") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = sortMethod(execute_statement(stm.parameter[0]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "clear") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = clearMethod(execute_statement(stm.parameter[0]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "has_key") and (len(stm.parameter)==2) : 
			if stm.parameter[0].type != "id" : error()
			result = has_keyMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
			retValue = result
		elif (stm.name == "keys") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = keysMethod(execute_statement(stm.parameter[0]))
			retValue = result
		elif (stm.name == "update") and (len(stm.parameter)==2) : 
			if stm.parameter[0].type != "id" : error()
			result = updateMethod(execute_statement(stm.parameter[0]),execute_statement(stm.parameter[1]))
			ids[stm.parameter[0].id] = result
		elif (stm.name == "values") and (len(stm.parameter)==1) : 
			if stm.parameter[0].type != "id" : error()
			result = valuesMethod(execute_statement(stm.parameter[0]))
			retValue = result
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@			
########################################################################################################################333
##########################################################################################################################
########################################################################################################################333
##########################################################################################################################
		elif (stm.name == "download") and (len(stm.parameter)==6) : 
			retValue = download(execute_statement(stm.parameter[0]).value,
								execute_statement(stm.parameter[1]).value,
								execute_statement(stm.parameter[2]).value,
								execute_statement(stm.parameter[3]).value,
								execute_statement(stm.parameter[4]).value,
								execute_statement(stm.parameter[5]).value)
		elif (stm.name == "download") and (len(stm.parameter)==1) :
			retValue = download(execute_statement(stm.parameter[0]).value)

		elif (stm.name == "cttr") and (len(stm.parameter)==1) : retValue = cttr(execute_statement(stm.parameter[0]).value)
		elif (stm.name == "openurl") and (len(stm.parameter)==1) : retValue = openurl(execute_statement(stm.parameter[0]).value)
		elif (stm.name == "remind") and (len(stm.parameter)==1) : retValue = remind(execute_statement(stm.parameter[0]).value)

		elif (stm.name == "upload") and (len(stm.parameter)==6) :
			retValue = upload(execute_statement(stm.parameter[0]).value,
							execute_statement(stm.parameter[1]).value,
							execute_statement(stm.parameter[2]).value,
							execute_statement(stm.parameter[3]).value,
							execute_statement(stm.parameter[4]).value,
							execute_statement(stm.parameter[5]).value)
		elif (stm.name == "upload") and (len(stm.parameter)==1) :
			retValue = upload(execute_statement(stm.parameter[0]).value,)

		elif (stm.name == "sendmail") and (len(stm.parameter)==5) :         # send mail 5
			retValue = sendmail(execute_statement(stm.parameter[0]).value,
								execute_statement(stm.parameter[1]).value,
								execute_statement(stm.parameter[2]).value,
								execute_statement(stm.parameter[3]).value,
								execute_statement(stm.parameter[4]).value)
		elif (stm.name == "sendmail") and (len(stm.parameter)==3) :         # send mail 3
			retValue = sendmail(execute_statement(stm.parameter[0]).value,
								execute_statement(stm.parameter[1]).value,
								execute_statement(stm.parameter[2]).value)
			
		elif (stm.name == "readmail") and (len(stm.parameter)==0) :retValue = readmail()
		elif (stm.name == "readmail") and (len(stm.parameter)==1) :retValue = readmail(execute_statement(stm.parameter[0]).value)
		elif (stm.name == "readmail") and (len(stm.parameter)==3) :
			retValue = readmail(execute_statement(stm.parameter[0]).value,
								execute_statement(stm.parameter[1]).value,
								execute_statement(stm.parameter[2]).value)

		elif (stm.name == "checkmail") and (len(stm.parameter)==0) :retValue = checkmail()
		elif (stm.name == "checkmail") and (len(stm.parameter)==1) :retValue = checkmail(execute_statement(stm.parameter[0]).value)
		elif (stm.name == "checkmail") and (len(stm.parameter)==3) :
			retValue = checkmail(execute_statement(stm.parameter[0]).value,
								execute_statement(stm.parameter[1]).value,
								execute_statement(stm.parameter[2]).value)

		elif (stm.name == "getBidsdata") and (len(stm.parameter)==1) : retValue = getBidsdata(execute_statement(stm.parameter[0]).value)

		elif (stm.name == "newMail") and (len(stm.parameter)==3) :
			if startMsgCount == 0 : 
				startMsgCount = getStartMsgCount(execute_statement(stm.parameter[0]).value, execute_statement(stm.parameter[1]).value, execute_statement(stm.parameter[2]).value)
				#print "startMsgCount : ",startMsgCount
			result = newMail(execute_statement(stm.parameter[0]).value, execute_statement(stm.parameter[1]).value, execute_statement(stm.parameter[2]).value, startMsgCount)
			if result[1] != 0 : startMsgCount = 0
			#print "result[0] : ",result[0].value
			if result[0].value == 1 : print "Check new mail complete"
			retValue = result[0]
		elif functions.has_key(stm.name) :
			if len(functions[stm.name].argument) == len(stm.parameter) :
				#print "length : ",len(stm.parameter)
				for index in range(len(stm.parameter)) :
					result = execute_statement(stm.parameter[index])
					if stm.parameter[index].type not in ["int","long","float","complex"] :
						result = stm.fork(result)
					localsVar[functions[stm.name].argument[index]] = result
			else : 
				print "Argument not match!!"
				error()
			activeRecord = [functions[stm.name].name,localsVar,functions[stm.name].body]
			activeFunctions.append(activeRecord)
			execute_statement(functions[stm.name].body)
			activeFunctions.pop()
		else : print "Undefined Function"
		return_value = retValue
		retValue = 0

	elif stm.type == "if" :
		all_expr = []
		all_expr.append(stm.expression)
		#print stm.expression.type
		if execute_statement(stm.expression).value :
			#print "Come to if statement...."
			execute_statement(stm.ifStmt)
		if (stm.elifList != []) :
			#print "Come to Elif..."
			elif_count = len(stm.elifList) # number of elif_loop
			for count in range(elif_count) :
			# create new expression
				elif_expr = stm.elifList[count].expression
				#print "elif_expr : ",elif_expr
				expr = execute_statement(elif_expr).value
				for index in all_expr : 
					inverse_expr = not execute_statement(index).value
					expr = expr and inverse_expr
				all_expr.append(elif_expr)
				if expr :
					execute_statement(stm.elifList[count].statements)
		
		if (stm.elseStmt.stmts != []) :
			#print "Come to else...."
			expr = 1
			for index in all_expr : 
				inverse_expr = not execute_statement(index).value
				expr = expr and inverse_expr
			if expr :
				#print "run else statement..."
				execute_statement(stm.elseStmt)

	elif stm.type == "while" :
		while execute_statement(stm.expression).value :
			execute_statement(stm.statements)
	
	elif stm.type == "for" :
		start = execute_statement(stm.start).value
		stop = execute_statement(stm.stop).value
		while start <= stop :
			execute_statement(stm.statements)
			ids[stm.start.id].value += 1
			start += 1
	
	elif stm.type == "repeat" :
		execute_statement(stm.statements)
		#print "repeat : ",stm.expression
		while (not execute_statement(stm.expression).value) :
			execute_statement(stm.statements)

	elif stm.type == "subprogram" :
		#print "Welcome to SubProgram"
		for stmt in stm.stmts :
			execute_interval_statement(stmt)
	
	elif stm.type == "return" :
	#	if stm.expression == "" :
	#		retValue = 1
	#	else :
		retValue = execute_statement(stm.expression)
	
	elif stm.type == "interval_statement" :
		execute_interval_statement(stm)
	
	elif stm.type == "access" :
		value = ids[stm.id]
		if value.type in ["list","tuple"] :
			result = value.value[execute_statement(stm.index).value]
		elif value.type == "string" :
			result = checkType(value.value[execute_statement(stm.index).value])
		elif value.type == "dictionary" :
			dict = ForwardDict(value.value)
			result = checkType(dict[execute_statement(stm.index).value])
		else : error()
		return_value = result
	
	elif stm.type == "access_scope" :
		value = ids[stm.id]
		if value.type in ["list","tuple"] :
			if stm.start == None :
				result = checkType(value.value[:execute_statement(stm.stop).value])
			elif stm.stop == None :
				result = checkType(value.value[execute_statement(stm.start).value:])
			else : result = checkType(value.value[execute_statement(stm.start).value:execute_statement(stm.stop).value])
		elif value.type == "string" :
			if stm.start == None :
				result = checkType(value.value[:execute_statement(stm.stop).value])
			elif stm.stop == None :
				result = checkType(value.value[execute_statement(stm.start).value:])
			else : result = checkType(value.value[execute_statement(stm.start).value:execute_statement(stm.stop).value])
		else : error()
		return_value = result
	
	elif stm.type == "comment" :
		#print "Comment : ",stm.value
		pass


	elif stm.type == "assignstmt" :
		if stm.value.type not in ["int","long","float","complex","list","string","interval","dictionary"] :
			flag = 1
		else : flag = 0
		value = execute_statement(stm.value)
		if stm.lvalue.type == "id" :
			if activeFunctions != [] :
				activeRecord = activeFunctions[len(activeFunctions)-1]
				if stm.assign == '=' : 
					if flag == 1 : value = stm.fork(value)
					activeRecord[1][stm.lvalue.id] = value
				elif stm.assign == '+=' : activeRecord[1][stm.lvalue.id].value += value.value
				elif stm.assign == '-=' : activeRecord[1][stm.lvalue.id].value -= value.value
				elif stm.assign == '*=' : activeRecord[1][stm.lvalue.id].value *= value.value
				elif stm.assign == '/=' : activeRecord[1][stm.lvalue.id].value /= value.value
				elif stm.assign == '%=' : activeRecord[1][stm.lvalue.id].value %= value.value
				elif stm.assign == '**=' : activeRecord[1][stm.lvalue.id].value **= value.value
				elif stm.assign == '>>=' : activeRecord[1][stm.lvalue.id].value >>= value.value
				elif stm.assign == '<<=' : activeRecord[1][stm.lvalue.id].value <<= value.value
				elif stm.assign == '&=' : activeRecord[1][stm.lvalue.id].value &= value.value
				elif stm.assign == '|=' : activeRecord[1][stm.lvalue.id].value |= value.value
				elif stm.assign == '^=' : activeRecord[1][stm.lvalue.id].value ^= value.value
				#print "localsID : ",activeRecord[1]
			else :
				if stm.assign == '=' : 
					if flag == 1 : value = stm.fork(value)
					ids[stm.lvalue.id] = value
				elif stm.assign == '+=' : ids[stm.lvalue.id].value += value.value
				elif stm.assign == '-=' : ids[stm.lvalue.id].value -= value.value
				elif stm.assign == '*=' : ids[stm.lvalue.id].value *= value.value
				elif stm.assign == '/=' : ids[stm.lvalue.id].value /= value.value
				elif stm.assign == '%=' : ids[stm.lvalue.id].value %= value.value
				elif stm.assign == '**=' : ids[stm.lvalue.id].value **= value.value
				elif stm.assign == '>>=' : ids[stm.lvalue.id].value >>= value.value
				elif stm.assign == '<<=' : ids[stm.lvalue.id].value <<= value.value
				elif stm.assign == '&=' : ids[stm.lvalue.id].value &= value.value
				elif stm.assign == '|=' : ids[stm.lvalue.id].value |= value.value
				elif stm.assign == '^=' : ids[stm.lvalue.id].value ^= value.value
				#print "ids-id : ",ids

		elif stm.lvalue.type == "access" :
			if activeFunctions != [] :
				activeRecord = activeFunctions[len(activeFunctions)-1]
				if activeRecord[1][stm.lvalue.id].type in ["list","dictionary"] :
					if activeRecord[1][stm.lvalue.id].type == "dictionary" : index = checkType(execute_statement(stm.lvalue.index).value)
					else : index = execute_statement(stm.lvalue.index).value
					if stm.assign == '=' : 
						if flag == 1 : value = stm.fork(value)
						activeRecord[1][stm.lvalue.id].value[index] = value
					elif stm.assign == '+=' : activeRecord[1][stm.lvalue.id].value[index].value += value.value
					elif stm.assign == '-=' : activeRecord[1][stm.lvalue.id].value[index].value -= value.value
					elif stm.assign == '*=' : activeRecord[1][stm.lvalue.id].value[index].value *= value.value
					elif stm.assign == '/=' : activeRecord[1][stm.lvalue.id].value[index].value /= value.value
					elif stm.assign == '%=' : activeRecord[1][stm.lvalue.id].value[index].value %= value.value
					elif stm.assign == '**=' : activeRecord[1][stm.lvalue.id].value[index].value **= value.value
					elif stm.assign == '>>=' : activeRecord[1][stm.lvalue.id].value[index].value >>= value.value
					elif stm.assign == '<<=' : activeRecord[1][stm.lvalue.id].value[index].value <<= value.value
					elif stm.assign == '&=' : activeRecord[1][stm.lvalue.id].value[index].value &= value.value
					elif stm.assign == '|=' : activeRecord[1][stm.lvalue.id].value[index].value |= value.value
					elif stm.assign == '^=' : activeRecord[1][stm.lvalue.id].value[index].value ^= value.value
					#print "localsID : ",activeRecord[1]
				else : 
					print "You can't modify values because it's an immuable data type!!"
					sys.exit(0)
			else :
				if ids[stm.lvalue.id].type in ["list","dictionary"] :
					if ids[stm.lvalue.id].type == "dictionary" : index = checkType(execute_statement(stm.lvalue.index).value)
					else : index = execute_statement(stm.lvalue.index).value

					if stm.assign == '=' : 
						if flag == 1 : value = stm.fork(value)
						ids[stm.lvalue.id].value[index] = value
					elif stm.assign == '+=' : ids[stm.lvalue.id].value[index].value += value.value
					elif stm.assign == '-=' : ids[stm.lvalue.id].value[index].value -= value.value
					elif stm.assign == '*=' : ids[stm.lvalue.id].value[index].value *= value.value
					elif stm.assign == '/=' : ids[stm.lvalue.id].value[index].value /= value.value
					elif stm.assign == '%=' : ids[stm.lvalue.id].value[index].value %= value.value
					elif stm.assign == '**=' : ids[stm.lvalue.id].value[index].value **= value.value
					elif stm.assign == '>>=' : ids[stm.lvalue.id].value[index].value >>= value.value
					elif stm.assign == '<<=' : ids[stm.lvalue.id].value[index].value <<= value.value
					elif stm.assign == '&=' : ids[stm.lvalue.id].value[index].value &= value.value
					elif stm.assign == '|=' : ids[stm.lvalue.id].value[index].value |= value.value
					elif stm.assign == '^=' : ids[stm.lvalue.id].value[index].value ^= value.value
					#print "ids-access : ",ids
				else : 
					print "You can't modify values because it's an immuable data type!!"
					sys.exit(0)
	
	#print "test......."
	#print "<before pop> id : ",id
	#print "<before pop> process stack : ",process_stack
	index = process_stack.index(id)
	process_stack.pop(index)
	#print "<after pop> process stack : ",process_stack
	tmp_return = return_value
	return_value = abstract.IntNum(1)
	return tmp_return

def add(a,b) :
	#print "adding function..."
	return a+b

def filter(allLines) :
	print "filter..."
	tab = [0]
	loop = [""]
	state = 1
	loop_command = ['if','while','for','def','elif','else','repeat']
	script = ""
	scriptList=[]
	for line in allLines :
		tab_count = 0
		for char in line :
			if char == "\t" :
				tab_count = tab_count + 1
			elif char == " " :
				error()
			else : break
		if "\n" in line :
			line = line.replace("\n",";\n")
		else : line = line + ";"
		line = line.replace("\t","")
		token = line.split(" ")
		if state == 1 :
			if tab_count > tab[len(tab)-1] :
				error()
			elif tab_count < tab[len(tab)-1] :
				tab.pop()
				while tab_count < tab[len(tab)-1] :
					script = script + "}"
					tab.pop()
					loop.pop()
				if tab_count == tab[len(tab)-1] :
					script = script + "}"
				else : error()
			if tab_count == tab[len(tab)-1] :
				if token[0] in loop_command :
					state = 2
					if (loop[len(loop)-1] == "if") and (token[0] in ["else","elif"]):
						script = script + line
					elif tab_count != 0 :
						loop.pop()
						loop.append(token[0])
						script = script + line
					elif tab_count == 0 :
						if script != "" : scriptList.append(script)
						loop.pop()
						loop.append(token[0])
						script = line
				elif tab_count == 0 :
					if token[0] == "until" :
						script = script + line
						scriptList.append(script)
						script = ""
					elif script != "" :
						scriptList.append(script)
						scriptList.append(line)
						script = ""
					else : scriptList.append(line)
				else : script = script + line
			else : error()
		elif state == 2 :
			if tab_count < tab[len(tab)-1]+1 : error()
			else :
				tab.append(tab_count)
				if token[0] not in loop_command :
					state = 1
				else : loop.append(line)
			script = script + "{" + line	
	if (len(tab)>1) :
		brace_num = len(tab)-1
		brace = ""
		for count in range(brace_num) :
			brace = brace + "}"
		script = script + brace
		scriptList.append(script)
	return scriptList

def error() :
	print "Syntax Error!"
	sys.exit(0)
