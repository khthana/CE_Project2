''' -                          ^_^  '_'    
PWBCE  Version 0.1
By Chakrit Hengsirikul  &  Cherdkiat Saetae
: H_CK Email:ck1982@msn.com
: S_CH email:
Professor : Dr.Visit Hirankitti

#########################################################
##
## 2004/02/05
## test and begin import mypopmail and try to integrate
## 2004-02-12
## test all and add stmpserver at PAGE1
## add color concept
## 2004-03-05
## change this file name form Script9 to this name (maingui.py)
## 2004/03/06
## change set color from pwb.py (by input mycolor,select_color_number when construct)
## 2004/03/14
## last test all error remove ( if I know at this time )
## ^_^
## 2004/03/15
## print correctly
#########################################################

'''



import sys
import os
from Tkinter import *
import Pmw

from mypopmail import mypopmail
from mysmtpmail import mysmtpmail
from config import *
from getuserprofile import getuserprofile


global SELECTED_ADDRESS
SELECTED_ADDRESS = ''
######################################################################################
##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
######################################################################################

class Addrdialog(Toplevel):
   """Demonstrate Entrys and Event binding"""

   def __init__( self,parent,addrdict,mycolor,select_color_number):
        """Create, pack and bind events to four Entrys"""

        Toplevel.__init__( self,parent )
        self.title( "Select mail address Script" )
        self.geometry( "200x180" )  # width x length
        self.transient()
        
        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        #print "scriptpath:",scriptpath
        #print ' show upfd from mypopmail'

        self.addrdict = addrdict
        self.addrlist = self.addrdict.keys()
        #for k,v in self.addrdict.items():
        #   print str(k)+" : "+str(v)
        #self.listfile=[]

        #--  frame1  stor input uri of ftp
        self.frame2 = Frame( self )
        self.lbl_email = Label(self.frame2,text='Email:')
        self.lbl_email.pack(side = LEFT,pady = 0)
        
        self.nty_getaddr = Entry(self.frame2,width=18)
        self.nty_getaddr.pack(side=LEFT)

        self.btn_getaddr = Button( self.frame2,text='OK',command=self.action)
        self.btn_getaddr.pack(side = LEFT, pady = 3, padx = 2)
        self.frame2.pack( side=TOP,pady = 1,padx=0)

        # frame 4 stor  list box for show server file
        self.frame4 = Frame( self )
        self.lib_showaddr = Pmw.ScrolledListBox(self.frame4,
                                                items =self.addrlist,
                                                vscrollmode='dynamic',
                                                listbox_height = 6,
                                                dblclickcommand=self.check_action,
                                                selectioncommand = self.check
                                                )#,
        
        self.lib_showaddr.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=0)
        self.frame4.pack(  side=TOP,pady = 0 ,padx=0,expand = YES, fill = BOTH)
        
        ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)


   def check(self):
        chosen=self.lib_showaddr.curselection()  ##self.addrdict = addrdict #self.addrlist = self.addrdict.keys()
        self.nty_getaddr.delete(0, END)
        key = self.addrlist[int(chosen[0])]
        self.nty_getaddr.insert(INSERT,self.addrdict[key])

   def action(self):
        global SELECTED_ADDRESS
        temp_add = self.nty_getaddr.get()
        if temp_add <>'':
            SELECTED_ADDRESS=temp_add
            #print 'SELECTED_ADDRESS:',SELECTED_ADDRESS
            self.destroy()
        else:
            SELECTED_ADDRESS = ''

   def check_action(self):
        self.check()
        self.action()


   def setcolor(self,number):
        ''' temp this method to input a numbet of dict  future must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       )

######################################################################################
##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
######################################################################################

class mail(Toplevel):
    
    #def __init__( self,parent):
    def __init__( self,parent,mycolor,select_color_number):
     
        Toplevel.__init__( self,parent )
        self.title( "PWB Mail" )
        self.geometry( "235x270" )  # width x length
        
        print 'Open Mail()'

        self.SELECT_COLOR_NUMBER = select_color_number
        self.mycolor = mycolor
        
        ##-------------------------------------------------------------
        
        self.filepath = picpath
        ## mailserver :: pop.163.com     
        ## mailuser   :: h_chakrit@163.com
        ## mailpaswd :: kritnum
        ## mailsavepath :: C:\PythonCE\userprofile\mail\
        ## mailfilename :: mail.txt
        ## 
        ##  setup mypopmail
        self.MAIL_MODE = True
        self.CAN_FORWARD = True


        #self.mailmode = 'POP' # 'POP' or 'SAVE'
        self.mailindex = None
        self.mysmtpmail = mysmtpmail()
        self.mypopmail = mypopmail()

        self.REMOVE_CHAR_LIST_FOR_FILENAME = ['\\','/',':','*','?','"','<','>','|']
        
        self.read = {}          # for store had read mail
        self.mail = {}          # for store current mail
        self.allmail = {}       #for store all mail
        self.headermail = {}    # stor  mail header ('From', 'Date', 'Subject')
        self.allheadermail = {} # stor all mail header ('From', 'Date', 'Subject')


        self.lst_mail = []

        #self.mypopmail.connect()

        # Create a frame to put everything in
        self.mainframe = Frame(self)
        self.mainframe.pack(fill = 'both', expand = 1)

        self.notebook = Pmw.NoteBook(self.mainframe,tabpos = 'n',
                #createcommand = PrintOne('Create'),
                #lowercommand = PrintOne('Lower'),
                #raisecommand = PrintOne('Raise'),
                hull_width = 300,
                hull_height = 200,
                )

        self.notebook.pack(fill = 'both', expand = 1, padx = 1, pady = 1)

        # Populate some pages of the notebook.
        # page1 = self.notebook.add('tmp')
        # self.notebook.delete('tmp')


## PAGR  1 CONECT SECTION

        self.page1 = self.notebook.add('Login')
        self.notebook.tab('Login').focus_set()
        ## retrive mail
        self.CONT_SERVER=['User:', self.mypopmail.getmailuser(),'',
                          'Password:',self.mypopmail.getmailpaswd(),'',
                          'POPServer:',self.mypopmail.getmailserver(),'',
                          'SMTPServer:',self.mysmtpmail.getsmtpserver()]
        self.server = Frame(self.page1)
        self.cbb_svr = Pmw.ComboBox(self.server,
                                    scrolledlist_items = self.CONT_SERVER,
                                    selectioncommand = self.setCONT_SERVER)
        self.cbb_svr.pack(side = 'left', anchor = 'n',fill = 'x', expand = 1, padx = 1, pady = 1)
        self.cbb_svr.selectitem(1, setentry = 1)
        self.cbb_svr.component('entry').config(state =DISABLED)
        self.server.pack()
        self.btn_chk = Button(self.server,text="Check mail",border="1",command=self.checkemail)#self.s2
        self.btn_chk.pack(side=LEFT)
        
        ## show retrive mail
        self.frm_mail = Frame(self.page1)
        self.frm_mail.pack( side=TOP,pady = 0 )
        self.lib_showmail = Pmw.ScrolledListBox(self.frm_mail,
                                                items =self.lst_mail,
                                                vscrollmode='dynamic',
                                                dblclickcommand=self.viewmail,
                                                selectioncommand = self.viewmail ,
                                                usehullsize = 1,
                                                hull_width = 215,
                                                hull_height = 215
                                                )#, static
        self.lib_showmail.pack( side = LEFT, expand = YES, fill = BOTH ,padx=0,pady=0)#,listbox_height = 4
        

## PAGE 2 ViewMail

        self.page2 = self.notebook.add('ViewMail')
        ##Addressbar
        self.to = Frame(self.page2)
        self.fromentry=Frame(self.page2)
        self.lbl_frm = Label(self.fromentry,text="From:")
        self.lbl_frm.pack(side =LEFT)
        self.nty_frm = Entry(self.fromentry,width=25)
        self.nty_frm.pack(side=LEFT)
        self.fromentry.pack()

        self.lbl_to_dte_TEXT = StringVar()
        self.lbl_to_dte = Label(self.to,text='Date:')
        self.lbl_to_dte.pack(side =LEFT)
        self.nty_to_dte = Entry(self.to,width=25)
        self.nty_to_dte.pack(side=LEFT)
        self.to.pack()

        self.subject=Frame(self.page2)
        self.lbl_suj = Label(self.subject,text="Subject:")
        self.lbl_suj.pack(side =LEFT)
        self.nty_suj = Entry(self.subject,width=25)
        self.nty_suj.pack(side=LEFT)
        self.subject.pack()
        
        ##Actionbar
        self.action=Frame(self.page2)
        self.btn_frd = Button(self.action,text="Forward",border="1",command=self.forwardmail)
        self.btn_frd.pack(side=LEFT,padx=0)
        self.btn_sve = Button(self.action,text="Save",border="1",command=self.savemail)
        self.btn_sve.pack(side=LEFT,padx=0)
        self.btn_dlt = Button(self.action,text="Delete",border="1",command=self.deletemail)
        self.btn_dlt.pack(side=LEFT,padx=0)

        self.action.pack(pady = "1")
        
        ##Writearea
        self.writearea = Frame(self.page2)
        self.writearea.pack(fill=BOTH, expand=YES)
        
        fixedFont = Pmw.logicalfont('Fixed')
        self.tbx_write = Pmw.ScrolledText(self.writearea,
                #borderframe = 1,
                #labelpos = 'n',
                #label_text='ScrolledText with headers',
                #columnheader = 1,
                #rowheader = 1,
                #rowcolumnheader = 1,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none',
                #text_font = fixedFont,
                #Header_font = fixedFont,
                #Header_foreground = 'blue',
                #rowheader_width = 3,
                #rowcolumnheader_width = 3,
                #text_padx = 2,
                #text_pady = 2,
                #Header_padx = 4,
                #rowheader_pady = 4,
        )
        self.tbx_write.tag_configure('yellow', background = 'yellow')
        self.tbx_write.pack(padx = 1, pady = 1, fill = 'both', expand = 1)

        # frame 5 stor a Entry that show FTP Message
        self.frm_stu = Frame(self.page2)
        self._messagebar2 = Pmw.MessageBar(self.frm_stu,
                entry_width = 35,
                entry_relief='groove',
                labelpos = 'w',
                label_text = 'Status:',
                entry_bg = 'red')
        self._messagebar2.pack(side = 'bottom', fill = 'x',expand = 1, padx = 1, pady = 1)        
        self.frm_stu.pack(side = BOTTOM,fill = X)

        
## PAGE 4 SENDMAIL

        self.page4 = self.notebook.add('SendMail')
        
        self.p4_to = Frame(self.page4)
        self.p4_fromentry=Frame(self.page4)
        self.p4_subject=Frame(self.page4)
        self.p4_action=Frame(self.page4)
        self.p4_writearea = Frame(self.page4)
        self.p4_frm_stu = Frame(self.page4)

        ##Addressbar
        self.p4_lbl_frm = Label(self.p4_fromentry,text="From:")
        self.p4_lbl_frm.pack(side =LEFT)
        self.p4_nty_frm = Entry(self.p4_fromentry,width=25)
        self.p4_nty_frm.pack(side=LEFT)
        self.p4_fromentry.pack()


        self.p4_lbl_to = Label(self.p4_to,text='To:')
        self.p4_lbl_to.pack(side =LEFT)
        self.p4_nty_to = Entry(self.p4_to,width=25)
        self.p4_nty_to.pack(side=LEFT)
        self.p4_to.pack()
        self.p4_btn_addr= Button(self.p4_to,text="Addr",border="1",command=self.openaddressbook)
        self.p4_btn_addr.pack(side=LEFT,padx=0)

        
        self.p4_lbl_suj = Label(self.p4_subject,text="Subject:")
        self.p4_lbl_suj.pack(side =LEFT)
        self.p4_nty_suj = Entry(self.p4_subject,width=25)
        self.p4_nty_suj.pack(side=LEFT)
        self.p4_subject.pack()
        
        ##Actionbar
        self.p4_btn_snd = Button(self.p4_action,text="Send",border="1",command=self.sendmail)
        self.p4_btn_snd.pack(side=LEFT,padx=0)
        #self.btn_frd = Button(self.action,text="Forward",border="1",command=self.forwardmail)
        #self.btn_frd.pack(side=LEFT,padx=0)
        #self.btn_dlt = Button(self.action,text="Delete",border="1",command=self.deletemail)
        #self.btn_dlt.pack(side=LEFT,padx=0)
        self.p4_btn_clr = Button(self.p4_action,text="Clear",border="1",command=self.p4_clearmail)
        self.p4_btn_clr.pack(side=LEFT,padx=0)
        self.p4_btn_sve = Button(self.p4_action,text="Save",border="1",command=self.p4_savemail)
        self.p4_btn_sve.pack(side=LEFT,padx=0)
        #self.btn_qut = Button(self.action,text="Quit",border="1",command=self.quitmail)
        #self.btn_qut.pack(side=LEFT,padx=0)
        self.p4_action.pack(pady = "1")
        
        ##Writearea
        fixedFont = Pmw.logicalfont('Fixed')
        self.p4_tbx_write = Pmw.ScrolledText(self.p4_writearea,
                usehullsize = 1,
                hull_width = 200,
                hull_height = 110,
                text_wrap='none'
        )
        #self.tbx_write.tag_configure('yellow', background = 'yellow')
        self.p4_tbx_write.pack(padx = 0, pady = 0, fill = 'both', expand = 1)
        self.p4_writearea.pack(fill=BOTH, expand=YES)

        ##STATUS Message
        self.p4_messagebar2 = Pmw.MessageBar(self.p4_frm_stu,
                entry_width = 35,
                entry_relief='groove',
                labelpos = 'w',
                label_text = 'Status:',
                entry_bg = 'red')
        self.p4_messagebar2.pack(side = 'bottom', fill = 'x',expand = 1, padx = 0, pady =1)
        self.p4_frm_stu.pack(side = BOTTOM,fill = X)


## PAGE 3 SAVE
        
        self.savemaillist = []
        self.savemaillist=self.getsavemailfilenametolist(self.mypopmail.getmailsavepath())
        if(self.savemaillist == []):
            self.savemaillist=['2','3']
        #self.page3 = self.notebook.insert('Applications', before = 'Send')#
        self.page3 = self.notebook.add('saved')
        self.frm_sav = Frame(self.page3)#lambda:
        self.cbb_svl = Pmw.ComboBox(self.frm_sav,
                                    scrolledlist_items = self.savemaillist,
                                    selectioncommand = self.selectsavemailtoread
                                    )
        self.cbb_svl.pack(side = 'left', anchor = 'n',fill = 'x', expand = 1, padx = 0, pady = 0)

        #self.cbb_svl.horizscrollbar.config(bg='#000000')
        #self.cbb_svl.config(highlightthickness='#000000')
        self.btn_frw3 = Button(self.frm_sav, text = 'Send',command=self.forwardsavemail)
        self.btn_frw3.pack(side=LEFT,padx=0)
        self.btn_dlt3 = Button(self.frm_sav, text = 'Del',command=self.deletesavemail)
        self.btn_dlt3.pack(side=LEFT,padx=0)
        self.frm_sav.pack(side = TOP,pady=1)
        self.frm_savshmal = Frame(self.page3)
        self.tbx_svwt = Pmw.ScrolledText(self.frm_savshmal,
                                          usehullsize = 1,
                                          #hull_background='red3',
                                          hull_width = 215,
                                          #text_background = 'gray70',
                                          #vertscrollbar_background = 'red',
                                          #vertscrollbar_highlightcolor='#667878',
                                          #vertscrollbar_highlightbackground='#112233',
                                          #vertscrollbar_troughcolor='#998877',
                                          hull_height = 205,
                                          text_wrap='none',)
        #self.tbx_svwt.component('vertscrollbar').configure(bg='#000000',highlightcolor='#000000',highlightbackground='#000000')
        #self.tbx_svwt.tag_configure('yellow', background = 'yellow')
        #self.tbx_svwt._horizScrollbar.config(bg='#000000',activebackground='#000000',highlightcolor='#000000',highlightbackground='#000000')

        self.tbx_svwt.pack(padx = 1, pady = 1, fill = 'both', expand = 1)
        self.frm_savshmal.pack(expand = 1)


        #self.hr=self.tbx_svwt.horizscrollbar
        #self.tbx_svwt.getcomponent('horizscrollbar')
     

      ## set color   SELECT_COLOR_NUMBER
        self.setcolor(self.SELECT_COLOR_NUMBER)
      ## set disable forward 
        self.set_CAN_FORWARD(False)
        

        
    def setcolor(self,number):
        ''' temp this method to input a numbet of dict  futrer must chang to inpup a dict from main program input a dict of color and set to main widget and some other color that to set to other special widget'''
        clr = self.mycolor.getcolor(number)
        Pmw.Color.changecolor(self,
                              background = clr['background'],
                              foreground = clr['foreground'],
                              activeForeground = clr['activeForeground'],
                              insertBackground = clr['insertBackground'],
                              selectForeground = clr['selectForeground'],
                              highlightColor = clr['highlightColor'],
                              disabledForeground = clr['disabledForeground'],
                              highlightBackground = clr['highlightBackground'],
                              activeBackground = clr['activeBackground'],
                              selectBackground = clr['selectBackground'],
                              troughColor = clr['troughColor'],
                              selectColor = clr['selectColor']       )
        self.tbx_svwt.config(background = clr['background'])

##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
##  HELP FUNCTION
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        ##(priority, showtime, bells, logmessage)
        ##'systemerror'  : (5, 10, 2, 1),
        ##'usererror'    : (4, 5, 1, 0),
        ##'busy'         : (3, 0, 0, 0),
        ##'systemevent'  : (2, 5, 0, 0),
        ##'userevent'    : (2, 5, 0, 0),
        ##'help'         : (1, 5, 0, 0),
        ##'state'        : (0, 0, 0, 0),
        
    def showsmailtatus2(self,type,message):
        '''  set input message to statusbar '''
        #print 'input:'+message
        self._messagebar2.resetmessages('busy')
        self._messagebar2.message(type,message)
        
    def p4_showsmailtatus2(self,type,message):
        '''  set input message to statusbar '''
        #print 'input:'+message
        self.p4_messagebar2.resetmessages('busy')
        self.p4_messagebar2.message(type,message)

    def clear(self):
        '''delde text in date from'''
        self.p4_nty_suj.delete(0,END)
        self.p4_tbx_write.clear()  # for Pmw.ScrolledText
        
    def clearmail(self):
        '''
            delde text in date ,from,subject, write_text in PAGE 2 < ReadMail >
        '''
        self.nty_to_dte.delete(0,END)
        self.nty_frm.delete(0,END)
        self.nty_suj.delete(0,END)
        self.tbx_write.clear()  # for Pmw.ScrolledText
        
    def p4_clearmail(self):
        '''
            delde text in date ,from,subject, write_text in PAGE 4 < ReadMail >
        '''
        self.p4_nty_to.delete(0,END)
        self.p4_nty_frm.delete(0,END)
        self.p4_nty_suj.delete(0,END)
        self.p4_tbx_write.clear()  # for Pmw.ScrolledText


##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
##  WORK GUI FUNCTION
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
    def viewmail(self):
        '''selete mail to view from ListBox and then call setmail()'''
        print 'viewmail()'
        self.set_CAN_FORWARD(True) ## enable to farward mail 
        #chosen=self.lib_showfile.curselection()
        #name=self.listfile[int(chosen[0])]
        sels = self.lib_showmail.curselection() 
        if len(sels) == 0:
            #print 'No selection for double click'
            t=1
        else:
            self.mailindex = int(sels[0])
            #print 'select mail index:', self.mailindex
            self.mailmode = 'POP'
            self.setmail(self.mailindex)
            
    def setmail(self,mailindex):
        '''
           get mail to Display by input a parameter "mailindex"
        '''
        #print 'setmail()'
        #self.showsmailtatus2('busy','Sendding mail ...')
        self.mail = self.mypopmail.allmail[mailindex]
        self.setmail2(self.mail)

    def setmail2(self,mail):
        '''
            read in mail dictionary and set to ViewMail <PAGE2>
            ## data in mail dictionary ('From', 'Date', 'Subject','data')
        '''
        self.clearmail()
        temp_sub =''
        for k,v in mail.items():
            if k=='Date':
                self.nty_to_dte.insert(INSERT,mail['Date'])
            elif k=='From':
                self.nty_frm.insert(INSERT,mail['From'])
            elif k=='Subject':
                temp_sub = mail['Subject']
                self.nty_suj.insert(INSERT,mail['Subject'])
            elif k=='data':
                #self.tbx_write.clear() not want to clear 
                self.tbx_write.appendtext(mail['data'])
                
        self.showsmailtatus2('busy',temp_sub)      
        self.notebook.tab('ViewMail').focus_set()

    def p4_setmail2(self,mail):
        '''
            read in mail dictionary and set to SendMail <PAGE4>
            ## data in mail dictionary ('From', 'Date', 'Subject','data')
        '''
        self.p4_clearmail() 
        self.p4_showsmailtatus2('busy','Send Mail')

        for k,v in mail.items(): ## insert data by using for loop to prevwnt error in read key in dictionary
            #if k=='Date':
            #    self.p4_nty_to.insert( INSERT,mail['Date']) 
            #elif k=='From':
            #    self.p4_nty_frm.insert( INSERT,mail['From'])
            if k=='Subject':
                self.p4_nty_suj.insert( INSERT,mail['Subject'])
            elif k=='data':
                #self.p4_tbx_write.clear() not want to clear 
                self.p4_tbx_write.appendtext(mail['data'])
                
        self.p4_nty_frm.insert( INSERT,self.mypopmail.getmailuser())        
        self.notebook.tab('SendMail').focus_set()

    def forwardmail(self):
        '''
            copy text from VIEW MAIL to SEND MAIL
        '''
        #print 'forwardmail()'
        if self.CAN_FORWARD:
            self.set_CAN_FORWARD(False)
            if self.nty_frm.get()<>'':
                self.p4_nty_frm.delete(0,END) ## delete  all data in SendMail
                self.p4_nty_to.delete(0,END)
                self.p4_nty_suj.delete(0,END)
                self.p4_tbx_write.clear()
            
                self.p4_nty_frm.insert( INSERT,self.mypopmail.getmailuser()) ## set data to SendMail
                self.p4_nty_suj.insert(INSERT,'FW-'+ self.nty_suj.get())
                self.p4_tbx_write.appendtext('From:'+self.nty_frm.get()+'\nDate:'+self.nty_to_dte.get()+'\nSubject:'+self.nty_suj.get()+'\nData:\n'+'---------------\n'+self.tbx_write.get()+'------------------')  #clear()
                self.nty_frm.delete(0,END) ## delete  all data in ViewMail
                self.nty_to_dte.delete(0,END)
                self.nty_suj.delete(0,END)
                self.tbx_write.clear()
            
                self.p4_showsmailtatus2('busy','Edit mail') ## show status
                self.showsmailtatus2('busy','Edit mail')
                self.notebook.tab('SendMail').focus_set()
                return
            self.showsmailtatus2('busy','Create new mail')
        else:
            self.showsmailtatus2('busy',"Can't forward")

            
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
##  WORK LIB FUNCTION
##++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
    def checkemail(self):
        '''
           connetc to server and download all mail to local
           or delete all marked mail and destroy this GUI
        '''
        if self.MAIL_MODE:
            self.MAIL_MODE = False
            self.btn_chk.config(text='Sign out')
            print 'checkmail()'
            self.mypopmail.setmailserver(self.mypopmail.getmailserver())
            self.mypopmail.setmailuser(self.mypopmail.getmailuser())
            self.mypopmail.setmailpaswd(self.mypopmail.getmailpaswd())
            #print self.mypopmail.getstatus()
            self.mypopmail.loadallmail()
            #print '!'*80
            #print self.mypopmail.allheadermail
            #print '!'*80
            for key in self.mypopmail.allheadermail.keys():
                self.headermail[key]=self.mypopmail.allheadermail[key]['Subject']
                #print self.headermail[key]
            self.lst_mail=self.headermail.values()
            self.lib_showmail.setlist(self.lst_mail)
        else:
            self.quitmail()
            self.destroy()


    def sendmail(self):
        '''
            send the mail as new or forward mail
        '''
        #self.lbl_to_dte_TEXT.set("To:")
        #mysmtpmail(From,To,Subj,Data)
        _From = self.p4_nty_frm.get()
        _To = self.p4_nty_to.get()
        _Subj = self.p4_nty_suj.get()
        _Data = self.p4_tbx_write.get()
        if (not(_From=='' or _To=='' or _Subj=='' or _Data=='')):
            c = self.mysmtpmail.send(_From,_To,_Subj,_Data)
            #print 'c:',c
            if c==1:
                print 'SendMail()->',_To
                self.p4_showsmailtatus2('busy','Succeed to send mail')
                self.p4_nty_frm.delete(0,END)
                self.p4_nty_to.delete(0,END)
                self.p4_nty_suj.delete(0,END)
                self.p4_tbx_write.clear()
            else:
                self.p4_showsmailtatus2('busy','Failed to send mail')
        else:
            self.p4_showsmailtatus2('busy','Mail not complete')


    def savemail(self):
        '''
           save reading email in VIEW MAIL to text file( subject name ) for read next time each mail save to one file
        '''
        #print 'savemail to mail'
        _From = self.nty_frm.get()
        _Date = self.nty_to_dte.get()
        _Subj = self.nty_suj.get()
        _Data = self.tbx_write.get()
        if _Data=='':
           self.showsmailtatus2('help','Mail not save, Data not complete')
           return
         
        if _From=='': _From='unknow'
        if _Date=='': _Date='unknow'
        if _Subj=='': _Subj='unknow'
        if _Data=='': _Data='unknow'
        self.showsmailtatus2('busy','Saving mail ...')
        try:
            filemail='From:'+_From+'\nDate:'+_Date+'\nSubject:'+_Subj+'\nData:\n'+_Data
            sub = self.__REMOVE_CHAR_LIST_FOR_FILENAME(self.nty_suj.get())
            file = open(self.mypopmail.mailsavepath+sub+'.txt','w+')
            file.write(filemail)
            file.close()
            print 'SaveMail:',sub
            self.refresh_savemaillist();
            self.showsmailtatus2('busy','Mail saveed')
        except Exception:
            self.showsmailtatus2('busy',"Mail can't Save because data is binary")
        
    def p4_savemail(self):
        '''save reading email in SEND MAIL to text file for read next time each mail save to one file'''
        #print 'savemail to mail'
        _From = self.p4_nty_frm.get()
        _To = self.p4_nty_to.get()
        _Subj = self.p4_nty_suj.get()
        _Data = self.p4_tbx_write.get()
        if _Data=='':
           self.showsmailtatus2('help','Mail not save, Data not complete')
           return
         
        if _From=='': _From='unknow'
        if _To=='': _To='unknow'
        if _Subj=='': _Subj='unknow'
        if _Data=='': _Data='unknow'
        self.p4_showsmailtatus2('busy','Saving mail ...')
        try:
            filemail='From:'+_From+'\nTo:'+_To+'\nSubject:'+_Subj+'\nData:\n'+_Data
            # if have time must correct to show file save dialog
            sub = self.__REMOVE_CHAR_LIST_FOR_FILENAME(self.p4_nty_suj.get())
            file = open(self.mypopmail.mailsavepath+sub+'.txt','w+')
            file.write(filemail)
            file.close()
            print 'SaveMail:',sub
            self.refresh_savemaillist();
            self.p4_showsmailtatus2('busy','Mail saveed')
        except Exception:
            self.p4_showsmailtatus2('busy',"Mail can't Save because data is binary")
            

        
    def deletemail(self):
        ''' add want to delete mail to local varibel and delete later '''
        
        if self.mailindex <> None:
            #print 'deleteMail:',sub
            #print 'deletemail at ',self.mailindex
            self.mypopmail.deletemail(self.mailindex+1)
            self.clearmail()
            #self.notebook.tab('Login').focus_set()
            self.showsmailtatus2('busy','Delete mail at '+str(self.mailindex+1))
            #self.mypopmail.deletemessages()
        else:
            self.showsmailtatus2('help','No selected mail')


    def quitmail(self):
        ''' delete all mark to delete mail'''
        self.showsmailtatus2('busy','Deleting mails ...')
        if self.mypopmail.toDelete!=[]:
            self.mypopmail.deleteallmail()
        #self.showsmailtatus2('busy','All select mails deleted')
        self.lst_mail=[]
        self.lib_showmail.setlist(self.lst_mail)



# SAVE MAIL PAGE FUNCTION -----------------------------------------------------------------

    def deletesavemail(self):
        '''
            delect sve mail -> delect text file that select by ComboBox (cbb_svl)
        '''
        select = self.cbb_svl.getcurselection()
        #print 'select ',select
        if select <> ():
            if select[0] in self.savemaillist:
                os.remove(self.mypopmail.mailsavepath+select[0])
                self.tbx_svwt.clear()
                self.refresh_savemaillist();
                self.clearmail()
            else:
                self.showsmailtatus2('help','No selected mail')
        else:
            self.showsmailtatus2('help','No selected mail')

    def refresh_savemaillist(self):
        '''Set cbb_svl by Get file name from mailsavepath'''
        self.savemaillist=self.getsavemailfilenametolist(self.mypopmail.mailsavepath)
        self.cbb_svl.clear()
        self.cbb_svl.setlist(self.savemaillist)
        #self.cbb_svl.selectitem(0, setentry = 1)
        
    def getsavemailfilenametolist(self,savepath):
        '''
           return the contain (filename) of input path in a list
        '''
        print 'savepath:',savepath
        if savepath <>'':
            try:
                return os.listdir(savepath)
            except Exception:
                print 'Cant not read save mail to List'
        else:
            return []


    def selectsavemailtoread(self,list):
        '''
            Click on the ComboListBox select the file mail to  show in PAGE3
        '''
        print 'selectsavemailtoread()',list
        #if list
        try:
            self.tbx_svwt.clear()
            file = open(self.mypopmail.getmailsavepath()+list,'r')
            self.tbx_svwt.appendtext(file.read())
        except Exception:
            print 'Cant not read ',list,' mail'
            

    def forwardsavemail(self):
        '''
            from PAGE3 when want to forwards the show mail
            read the file and pass to mypopmail to find subject to...< pare text file to mail object >
        '''
        #print 'forwardsavemail()'
        if self.tbx_svwt.get()<>'':
            select = self.cbb_svl.getcurselection()
            if select <> ():
                file = open(self.mypopmail.getmailsavepath()+select[0],'r')
                dict=self.mypopmail.pfiletomail(file)
                self.p4_setmail2(dict)
                #print dict
                #print self.tbx_svwt.getvalue()



    def openaddressbook(self):
        #print 'openaddressbook()'
        #dict = self.mypopmail.getaddrdict()
        dict = self.mypopmail.addrdict
        #print 'dict',dict
        #for k,v in dict.items():
        #   print str(k)+" : "+str(v)
        addrdialor = Addrdialog(self,dict,self.mycolor,self.SELECT_COLOR_NUMBER)
        self.wait_window(addrdialor)
        self.p4_nty_to.delete(0, END)
        #print 'SELECTED_ADDRESS2:',SELECTED_ADDRESS
        self.p4_nty_to.insert(INSERT,SELECTED_ADDRESS)

##------------------------------------------------------------------
        
    def setCONT_SERVER(self,list):
        self.cbb_svr.selectitem(1, setentry = 1)

 
    def set_CAN_FORWARD(self,boolean):
        if boolean:
            self.CAN_FORWARD = True
            self.btn_frd.config(state = NORMAL)
        else:
            self.CAN_FORWARD = False
            self.btn_frd.config(state = DISABLED)

    def __REMOVE_CHAR_LIST_FOR_FILENAME(self,data):
        for t_i in self.REMOVE_CHAR_LIST_FOR_FILENAME:
            data = data.replace(t_i,'')
        return data




######################################################################
#title = 'E-MAIL'
#root = Tk()
#Pmw.initialise(root)
#root.title(title)
#widget = mail(root)
#root.mainloop()
