# Fig. 10.6: fig10_06.py
# Entry components and event binding demonstration.

import sys
import traceback
import string



from Tkinter import *
from tkMessageBox import *

class E( Frame ):
   """Demonstrate Entrys and Event binding"""

   
   #self.exedata = ""
   
   def __init__( self ):
      """Create, pack and bind events to four Entrys"""

      
      
      Frame.__init__( self )
      self.pack( expand = YES, fill = BOTH )
      self.master.title( "Testing exec function" )
      self.master.geometry( "235x242" )  # width x length

      self.frame1 = Frame( self )
      self.frame1.pack( pady = 5 )
      
      self.text1 = Entry( self.frame1, name = "text1" )
      self.text1.bind( "<Return>", self.showContents )
      self.text1.pack( side = LEFT, padx = 3 )

      self.frame2 = Frame( self )
      self.frame2.pack( pady = 5 )
      
      self.text3 = Entry( self.frame2, name = "text3" )
      self.text3.bind( "<Return>", self.showContents )
      self.text3.pack( side = LEFT, padx = 3 )

  
      self.frame3 = Frame( self )
      self.frame3.pack( pady = 5 )
      
      self.button2=Button( self.frame3, name = "exec", text='exec', command=self.myexec)
      self.button2.pack(side = LEFT, padx = 3)
      
      self.button1=Button( self.frame3, name = "read", text='read', command=self.settext)
      self.button1.pack(side = LEFT, padx = 3)



   def settext(self):
      try:
         variablename = self.text3.get()
         temp = " = " + str(dict[variablename])
         self.text3.insert( INSERT, temp )
      except:
         self.text3.insert( INSERT, 'Can\'t find tt' )

   def myexec(self):
      self.exedata = self.text1.get()
      exec_(self,self.exedata)
      #exec theContents
      
   def showContents( self, event ):
      """Display the contents of the Entry"""
      
      # acquire name of Entry component that generated event
      theName = event.widget.winfo_name()
      # acquire contents of Entry component that generated event
      theContents = event.widget.get()
      showinfo( "Message", theName + ": " + theContents )
      
      #self.text3.insert( INSERT, u )


def exec_(self,exedata):
   """ input a  exedata # stang format  and pass to exec()  function """
   try:
      try:
         exec exedata in dict
         print 'Exec OK \n'
      except SystemExit:
         raise
      except:
         exc_type, exc_value, exc_traceback = sys.exc_info()
         l = len(traceback.extract_tb(sys.exc_traceback))
         print 'l :'+ str(l) +'\n'
         try:
            1/0
         except:
            m = len(traceback.extract_tb(sys.exc_traceback))
            print 'm :'+ str(m) +'\n'
            traceback.print_exception(exc_type,exc_value, exc_traceback, l-m)
            exc_traceback = None # Prevent a cycle
   finally:
      print 'End exec'





global tt
tt = 99
global dict
dict = {}

def main():
   E().mainloop()



main()
