#
# pypp.py
#
# Python PreProcessor
#
# Usage:
#
# Put constant definitions, and/or include files
# exactly like C header file, in your script 
#
#     #include "stdlib.h"
#     #define CONST_A 3.14
#     #ignore TEXT
#     #ignore UNICODE
#
# Use the CONSTANT in the script without defining them.
#
# callfunc(CONST_A)
# if UNICODE:
#    TEXT = CONST_XXX
#
# After that:
# 1. At Python interpreter prompt,
#      >>> import pypp; pypp.pp("yourmodule")
# 2. Or, Instead of import yourmodule, you put; # I have not tested this yet.
#        import pypp; pypp.p_import("yourmodule")
#
#
# pypp will parse the source file,
# register include filename,
# accumlate CONSTANT definitions,
# and accumlate "ignore" list.
#
# When it encounter CONTANT:(all CAPITAL, more than 4 characters,
# not quoted, it can include underscore and other signes),
# it will look in the ignore list and skip if found,
# then it will search in the "const" dict, and then header file, 
# to replace CONSTANTs with the value.
#
# If the constant definition is taken from header file,
# that definition line will be added to the source file
# so that pypp could avoid time consuming header file
# scanning next time.
#
# The original souce line will be preserved as a comment.
# This will keep readability of the cource, while
# reducing speed and memory overhead.
#
# Also, original source file is kept with .pyp extension.
# Any unfound CONSTANT will be kept AS IS to be safe.
#
# Check this module with ceshell.py, and you will see
# what it does.
# To be sure, keep original ceshell.py somewhere
# just in case.
#
# 
# Limitations:
#
# 1. At this moment, include file must be in the same directory 
#   as the source file. This can be improved easily.
# 2. Only simple CONSTANT can be used. No macros. CONSTANT must be
#   all capital (and underscore) of FOUR char or more of length.
# 3. When CONSTANT is searched in the include file, pypp does not
#   care about #if #endif nor comment block. It will take first definition.
#   I may improve this. #if #else parsing is relatively simple.
#   But this may slow down the search as well...
# 4. Any word that is longer than 4 char and all capital will be
#   considered as a CONSTANT, and searched. If you use a lot of
#   all capital word, pypp will be slower. 
#   Use #ignore to improve the speed.
#
# Header file search is handy, but it is relatively slow.
# 
# Use #ignore statements to speed up.
# If all CONSTANTs are found within the source file #define,
# pypp will not search in header file.
#
# Please modify and improve the speed and/or feature,
# and tell me.
#
# This module requires: flu.py  If you don't have it,
# pypp cannot import the module for you. No big deal, though.
#
# 01/11/21 14:25  by  Telion
#

#print "in pypp"
import string
import os, sys
import flu
if sys.version[0]=="1":
	py1=1
else:
	py1=0

_pypp_tmp_='_PYPP_TMP_' # prefix for marking temporal replacement
ptlen=len(_pypp_tmp_)


kwd={ # add any keyword and the code.
'#include':
"""if not impf: print '#include found', # for later
hfn=string.strip(s[8:])
if not impf: print hfn,
while(hfn[0] in '<\\'\"\>'): hfn = hfn[1:]
while(hfn[-1] in '<\\'\"\>'): hfn = hfn[:-1]
if not impf: print ":",hfn
include.append(hfn)
#print include
""",

'#ignore':
"""if not impf: print 'Adding to ignore list'
ig=string.split(s[7:])
ignore.append(ig[0])
#print ignore
""",

'#define':
"""if dbg: print "#define found"
lst=string.split(s[p+7:])
if dbg: print lst
if len(lst[1]) <= ptlen or lst[1][:ptlen] != _pypp_tmp_:
	const[lst[0]]=lst[1]
""",
}

def pp(mn,dbg=0):
	p_import(mn,0,dbg)

def p_import(mn, impf=1,dbg=0):
	if not impf: print "in pypp",
	
	# CONSTANT dict. It may contain predfined list.
	const={'PYPP':1,'PythonCE':22} # just an example
	#const[_pypp_tmp_]=[]
	include=[]
	ignore=[]

	# include file list and their search path
	includepath=sys.path # this feature is not implemented yet.
	if os.environ.has_key('INCLUDEPATH'):
		i=os.environ['INCLUDEPATH']
		if type(i)==type(''):
			i=string.split(i,';')
		if type(i)==type([]):
			includepath=i+includepath

	if 1:
		# find the fullpath of the module
		fn=mn+'.py'
		for fpath in sys.path:
			if fn in os.listdir(fpath):
				break
		fn=os.path.join(fpath,fn)
	f=open(fn,'r')
	fls=f.readlines()
	f.close()
	if not impf: print fn, "opened. Start parsing"

	#i=line
	line = 0
	i=0
	imax=len(fls)
	if not impf: print fn, "has", imax, "lines"
	incf=0 # flag for #include.
	lconst=[] # list for unfound constant
	ci=20

	while(1): # scan each line for keyword, and CONSTANT
		i=i+1
		lig=[]
		if i >= imax:
			break
		if not i%100:
			if not impf: print i,"lines done"
		s=fls[i]
		#if dbg: print i,":",s,
		# keyword scanning
		for k in kwd.keys(): # check match with keyword dict and act.
			p = string.find(s,k)
			if p >= 0:
				if not line:
					line = i
				exec kwd[k]

		# CONSTANT replacement. Skip if the line is comment or too short
		s2=string.strip(s)
		if len(s2) <2:
			continue
		if s2[0]=="#": # ignore comment line
			continue
		#if dbg: print "+"
		#sl=re.split("[^0-9a-zA-Z_]", s)
		# or better with \W ? but I don't know how to specify "C" Local yet.
		# I botherd to write the clone thinking it may be faster than RE.
		# But maybe not....
		sl=resplit(""" \t()*+:;/-=^\"'$%&!?<>,.|@`[{]}""", s) # try the clone
		if not sl:
			continue

		#if dbg: print i,"sl:",sl

		rf=0
		ss="#pypp "+s # keep the original
		wi=-1
		for w in sl: # check each word
			wi=wi+1
			#if dbg: print "checking word:", w,
			if not w or w[0]=="#": # ignore after the comment
				break

			if len(w) <4: # CONSTANT should be longer than 4 chars
				continue
			#if dbg: print w,
			cf=1
			cf2=0
			if py1: # for python 152
				for c in w:
					if c in string.lowercase:
						#if dbg: print w,"  it wasn't CONSTANT", c
						cf=0
						break
					elif cf2:
						pass
					elif c in string.uppercase: # need at least one alphabet
						cf2=1
			elif w.isupper(): # it's simple in python22
				cf2=1
			#if dbg: print "cf,cf2:",cf,cf2,
			if cf and cf2: # No lowercase found == CONSTANT
				#if dbg: print w,
				#if dbg: print "wi=",wi,len(sl),sl[1]
				if (w in ignore) or (w in lig) :
					if dbg: print w,"ignored"
					continue
				if wi>0 and len(sl) >2 and sl[wi-1][-1] in '"\'' and sl[wi+1][0] in '\'"':
					if dbg: print w,"quoted"
					continue
				if wi==0 and len(sl) >2 and sl[1]=="=": 
					if s[:len(w)]==w:
						cssi=string.find(s,'#')
						if cssi <0: cssi=999
						css=string.strip(s[string.find(s,'=')+1:cssi])
						const[w]=css
						s= "#define "+ w + " "+css+"\n"
						rf=1
						if dbg: print w,"const from source",css
						del css
					#if dbg: print "<"
					break
				leftover=0
				if not const.has_key(w): # well, get it in the include file.
					if dbg: print w,"const not in dict",
					incf=incf+1
					if len(w) > ptlen and w[:ptlen] == _pypp_tmp_: # left over from errors
						lconst.append(w[ptlen:])
						leftover=1
					else:
						lconst.append(w) # find it later.
						const[w]=_pypp_tmp_+w+" " # temporal entry
				if not leftover:
					#if dbg: print "CONSTANT found :", w, ", replacing with :",const[w]  
					s=string.replace(s,w,const[w])
					rf=1
					if dbg: print w,"const in dict:",const[w]
					lig.append(w)
				#if dbg: print "<"
		if rf: # If CONSTANT was replaced, keep original line as a comment
			#if dbg: print "CONSTANT replaced"
			s=ss+s
			#if dbg: print "Line :",i," done>",s,
		else:
			pass
			#if dbg: print "No CONSTANT in this line"
		fls[i]=s
		#if dbg: print "Line :",i," done>",fls[i],
		# one line scanned

	deflf=0
	lc2=lconst[:]
	if incf and include: # find and replace those CONSTANT not found in the const dict
		defline=["\n#---- definition added by pypp ---\n" ]
		if not impf: print "Checking undefined CONSTANTs",len(lconst)
		if not impf: print include
		for hfn in include:
			if not lc2:
				break

			#fpath=findfile(hfn,includepath) # not done yet
			i=string.rfind(fn,'\\')
			if i >= 0:
				fpath=fn[:i+1]+hfn # assume include file are in the same directory
			else:
				fpath=hfn
			if not impf: print "    in",fpath

			f=open(fpath,'r')
			for hfl in f.readlines():
				if not hfl[0]=="#":
					continue
				hfi=string.find(hfl,"define")
				if hfi < 0:
					continue
				hfll=string.split(hfl[1:])
				if not hfll[1] in lc2:
					continue
				if len(hfll) >1 :
					const[hfll[1]] = hfll[2]
				else:
					const[hfll[1]] = ''
				popi= lc2.index(hfll[1])
				lc2.pop(popi)
				defline.append(hfl)
				deflf=1
				if not lc2:
					break
		if lc2:
			if not impf: print "Following CONSTANTs were not found\n",
			if len(lc2) > 10:
				if not impf: print lc2[:10]
			else:
				if not impf: print lc2
		if deflf:
			defline.append("#----- pypp -------\n\n")
			fls[line]=fls[line]+string.join(defline,'') # copy definitions from header
	s=string.join(fls,'')+("#pypp CONSTANTs not found:"+repr(lc2)+"\n")
	if lc2: # Unfound constants will be back in original form
		for ll in lc2:
			const[ll]=ll
	for w in lconst: # replace all temporally marked CONSTANTs
		s=string.replace(s,_pypp_tmp_ + w + " ", const[w])
	
	if not impf: print "### All Line processed ###"
	os.rename(fn,fn+'p') # yourmodule.py will be saved as yourmodule.pyp
	f=open(fn,'w')
	f.write(s)
	f.close()
	if not impf: print "###",fn,"updated ###"
	#print const
	if not lc2:
		try:
			go=flu.globals_x(2) # get the global dictionary of caller
		except:
			if not impf: print "flu.py module not found?"
			return
		exec "import "+mn in go # and put the module in it
		go=flu.globals_x(2)
		#if dbg: print go.keys()
		reload(go[mn]) # make sure that it is recompiled
		#go=flu.globals_x(4)
		#if dbg: print const
	else:
		if dbg: print lc2

# helper functions

sjoin=string.join
sfind=string.find
def resplit(dlpat,s,max=None): # same as string.split, repeated with delimiter list string
	# this can be done re.split(pat,s,max).....
	#sjoin=string.join
	#sfind=string.find
	global sjoin
	global sfind
	sl=list(string.strip(s))
	#while( sl[-1]  in  '\r\n'): 
	#	sl.pop() # remove \n \r and combination od them
	#	if not sl:
	#		break
	rtl=[]
	tmp=[]
	count=0
	for c in sl:
		if c in dlpat: # if the char is a delimiter 
			if tmp:
				rtl.append(sjoin(tmp,''))
				tmp=[]
			if not (c in " \t"):
				rtl.append(c)
			#if max and count >= max:
			#	break
			#else:
			#	count=count+1
		else:
			tmp.append(c)
	if tmp:
		rtl.append(sjoin(tmp,''))
	return rtl
	
#print "end import pypp"
