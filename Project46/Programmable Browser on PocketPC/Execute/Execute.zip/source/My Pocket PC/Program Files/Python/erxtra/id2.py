#
# ======= id2.py =======
#
#  id2.obj(id,i=0):
#
# get (obj) and one of it's name from given (id),
# start searching from (i)th frame  from the caller of this function.
#
# Default value of 0 ( caller of id2.obj() )
#
# This function will climb up the stack frame checking both
# f_locals and f_globals, as well as modules and dictionaries
# contained in them, semi-recursively (up to 2 dots)
#
# If id is in the current local dictionary, it's quick.
# After searching local and then global dictionary,
# It will dig into moodule's dictionary and other dictionary
# before to go to parent frame for searching.
#
# WARNING: If the id is that of common thing such as None,
#          it will find  ONLY ONE of many possible results.
#
# It has dirty redundant code. But it's for the speed's sake.
# This code beated cleaner recursive version and looping version.
# (I was disapointed to find the nice looking codes I worked for
#  a hour was TWICE SLOWER than this one. Oh, well.
#  Also, on the Windows CE, recursive version failed most probably
#  due to lack of stack space, and it took a hour or so to find out....)
# No __doc__ string is provided. Again for the speed and bit of memory
#
# All verbose print out puts are commented out.
# - 01/10/19 02:17
#

def obj(oi, i=0):
	#print " Serching the name and object of id:",repr(oi)
	if i>=0: i=i+2
	from types import DictType
	from flist import f_list
	fl=f_list()[i:]
	sl=[] # skip list to avoid searching twice or more
	if not fl: 
		if i>0: i = i-2
		raise IndexError, "frame list index out of range (i):="+repr(i)
	for fi in fl: # frame tracing back loop
		#print repr(fi)
		rr=2
		while(rr):
			rr=rr-1
			if rr:
				d = fi[0].f_locals
			else:
				d = fi[0].f_globals
			for k,v in d.items(): # f_locals loop
				if id(v) == oi:
					#print "found in locals of", repr(fi)
					return k,v
				if hasattr(v,'__dict__') and not (k in sl):
					#print "m-->",k
					for k2,v2 in v.__dict__.items(): # module loop
						if id(v2) == oi:
							#print "found in", k2, "of", repr(fi)
							return k+"."+k2,v2 
						if not (k2 in sl) and hasattr(v2,'__dict__'):
							#print "m-+->",k,k2
							for k3,v3 in v2.__dict__.items(): # secondary module loop
								if id(v3) == oi:
									#print "found in", k3, "of", repr(fi)
									return k+"."+k2+"."+k3,v3 
							sl.append(k2)
						if not (k2 in sl) and type(v2) is DictType:
							#print "d-+-->",k,k2
							for k3,v3 in v2.items(): # secondary dict loop
								if id(v3) == oi:
									#print "found in", k3, "of", repr(fi)
									return k3,v3 
							sl.append(k2)
					sl.append(k)
				if not (k in sl) and type(v) is DictType: # Dictionary loop
					#print "d-->",k
					for k2,v2 in v.items():
						if id(v2) == oi:
							#print "found in", k2, "of", repr(fi)
							return k2,v2 
						if not (k2 in sl) and hasattr(v2,'__dict__'):
							#print "m-+->",k,k2
							for k3,v3 in v2.__dict__.items(): # secondary module loop
								if id(v3) == oi:
									#print "found in", k3, "of", repr(fi)
									return k+"."+k2+"."+k3,v3 
							sl.append(k2)
						if not (k2 in sl) and type(v2) is DictType:
							#print "d-+-->",k,k2
							for k3,v3 in v2.items(): # secondary dict loop
								if id(v3) == oi:
									#print "found in", k3, "of", repr(fi)
									return k3,v3 
							sl.append(k2)
					sl.append(k)
	return None
