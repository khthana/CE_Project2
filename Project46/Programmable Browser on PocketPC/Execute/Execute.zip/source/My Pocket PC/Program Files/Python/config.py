'''--------------------------------------------------------------
| Chakrit Hengsirikul
| congig file for config all dirctories for PWB
| simple by config only varible ( mainpath )
|--------------------------------------------
| 2004/03/05  add check sys.platform
|             scriptpath , 
|			  stdoutfilepath , stdoutfilename 
|			  stderrfilepath , stderrfilename
---------------------------------------------------------------'''


import sys

## main progarm path
global mainpath

# winCE path
mainpath = '\\Program Files\\Python\\'
# win32 path
if sys.platform == 'win32':
    mainpath = 'C:\\PythonCE\\browser\\'


################################################################33
################################################################44

## main picture file path 
global picpath
#picpath = '\\Program Files\\Python\\pic\\'
picpath = mainpath+'pic\\'

global ftppath
#picpath = '\\Program Files\\Python\\pic\\'
ftppath = mainpath+'ftp\\'

## used by pwb2.py  stor file script
global scriptpath
scriptpath = mainpath+'scripts\\'


## used by getuserprofile.py
global userprofilepath
userprofilepath = mainpath+'userprofile\\'

global mailsavepath
mailsavepath = userprofilepath+'mail\\'
#\userprofile\mail

## used by pwb2.py  form save standard output mesage to file
global stdoutfilepath
stdoutfilepath = mainpath
global stdoutfilename
stdoutfilename = stdoutfilepath + 'stdout.txt'

## used by pwb2.py  form save error mesage to file
global stderrfilepath
stderrfilepath = mainpath
global stderrfilepname
stderrfilename = stderrfilepath + 'stderr.txt'

###################################################################
###################################################################
## Constant

global SYS_PROMPT
SYS_PROMPT = 'CL>'

global HEADER
HEADER = 'PWBCE  Version 1.0\n'+'By Chakrit Hengsirikul & Cherdkiat Saetae\n'+'include CL Language\n'+'By Visit Hirankitti & Supannada Chotipant\n'
         
         #'Last update : 26 Oct. 2002, 16:00'+
         #'================================='+
         #'Port To PythonCE ON WinCE'+

