/  this is comment line
/
/
Buttom_bg :: #6666FF
Buttom_activebackground :: #66FFFF
Buttom_disabledforeground :: #99CCCC
Buttom_highlightbackground :: #33FFCC
Entry_bg :: #6699FF
Entry_fg :: #333333
Entry_highlightbackground :: #33FFCC
Entry_selectbackground :: #33FFCC
Entry_selectforeground :: #333333
Text_background :: #6699FF
Text_foreground :: #333333
Frame_bg :: #66CCFF
Frame_highlightbackground :: #33FF66
Label_bg :: #66CCFF
Listbox_bg :: #6699FF
Listbox_selectbackground :: #33FFCC
Menu_bg :: #6699FF
Menu_fg :: #33FFCC
Menu_selectcolor :: #009900
Menu_disabledforeground :: #99CCCC
Menu_activebackground :: #FF3399
Menu_activeforeground :: #330066
tt :: #CC00FF
pp :: #99FF00
/
/ background:            (must be specified)
/ foreground:            black
/ activeForeground:      same as foreground
/ insertBackground:      same as foreground
/ selectForeground:      same as foreground
/ highlightColor:        same as foreground
/ disabledForeground:    between fg and bg but closer to bg
/ highlightBackground:   same as background
/ activeBackground:      a little lighter that bg
/ selectBackground:      a little darker that bg
/ troughColor:           a little darker that bg
/ selectColor:           yellow
/
background :: #33CCFF
foreground :: #000000
activeForeground :: #000000
insertBackground  :: #000000
selectForeground :: #000000
highlightColor :: #000000
disabledForeground :: #3366CC
highlightBackground :: #33CCFF
activeBackground :: #33FFFF
selectBackground :: #3366CC
troughColor :: #3366CC
selectColor :: #FFFF66