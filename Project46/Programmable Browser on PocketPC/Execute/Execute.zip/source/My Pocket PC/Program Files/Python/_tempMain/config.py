

## main progarm path
global mainpath
#mainpath = 'C:\\PythonCE\\browser\\'
mainpath = '\\Program Files\\Python\\'


## main picture file path 
global picpath
#picpath = '\\Program Files\\Python\\pic\\'
picpath = mainpath+'pic\\'




## used by getuserprofile.py
global userprofilepath
userprofilepath = mainpath+'userprofile\\'
