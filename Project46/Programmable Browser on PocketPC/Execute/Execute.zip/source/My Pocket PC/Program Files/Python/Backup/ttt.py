from Tkinter import *

class Mail(Toplevel):

    
    def __init__(self, parent):

        Toplevel.__init__(self, parent)
        

#        self.transient(parent)
#        self.parent = parent
        self.geometry("300x20")
        Button(self,text="Test",relief = GROOVE).pack(side=LEFT, fill = X)
        
'''        
        frame = Frame()
        frame.pack(expand = NO)
        frame.master.geometry("235x242")
        frame.master.title("PWB")        

        root = Tk()
        self = Frame(root)
        self.pack(expand = NO)
        #self.result = None
        self.master.title("mail")
        self.master.geometry("235x242")
        filepath= 'D:\\Project\\Example\\ch11\\Temp\\'       
#        self.Im = PhotoImage( file = filepath + "wb.gif" )
#        wb = Button( self, image = self.Im )
#        wb.pack( side = LEFT, padx = 0, pady = 0)
#        wb.config(relief = GROOVE)

filepath= 'D:\\Project\\Example\\ch11\\Temp\\'

'''