#smtpservername = 'smtp.rmi.net'

#popservername = 'pop.rmi.net'
#popusername = 'lutz'

#savemailfile = r'c:\stuff\etc\savemail.txt'

#poppasswdfile = r'c:\stuff\etc\pymailgui.txt'

#myaddress = 'lutz@rmi.net'
#mysignature = '--Mark Lutz  (http://rmi.net/~lutz)  [PyMailGui 1.0]'

#smtpservername = 'www.maildozy.com'
smtpservername = '161.246.10.21'

popservername = '161.246.10.21'
popusername = 's4061624'

savemailfile = r'c:\stuff\etc\savemail.txt'

poppasswdfile = r'c:\stuff\etc\pymailgui.txt'

myaddress = 'lutz@rmi.net'
mysignature = '--Mark Lutz  (http://rmi.net/~lutz)  [PyMailGui 1.0]'