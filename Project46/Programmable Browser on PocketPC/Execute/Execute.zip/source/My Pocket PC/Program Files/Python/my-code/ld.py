from Tkinter import *
root = Tk()
Label(root, text='Hello GUI world!').pack(side=TOP)


Button(root, text='press', command=sys.exit()).pack(side=LEFT)
root.mainloop()

