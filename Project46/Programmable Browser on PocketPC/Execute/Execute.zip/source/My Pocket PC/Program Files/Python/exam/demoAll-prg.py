from Tkinter import *
demoModules = ['demoDlg', 'demoRadio', 'demoCheck', 'demoScale']
from PP2E.launchmodes import PortableLauncher

for demo in demoModules:                        # see Parallel System Tools
    PortableLauncher(demo, demo+'.py')()        # start as top-level programs

Label(text='Multiple program demo', bg='white').pack()
mainloop()