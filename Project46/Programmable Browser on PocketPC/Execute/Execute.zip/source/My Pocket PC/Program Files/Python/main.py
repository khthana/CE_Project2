'''
main.py == Version1.3.1
This is a main program for CL.
By Supannada Chotipant
Professor : Dr.Visit Hirankitti
Last update : 26 Oct. 2002, 16:00
================================================
Comment : Running by this program.
Recieved scripts from file.
Call parsing.py for parse script.
Then call semantic.py for translate AST,output of parsing.py.
This version have changing many step for filtering program file
into a line instruction ,so it can filter some statements version1.3 can't 
;if-else statement and repeat-until statement.

## 2004/03/15
## print correctly
'''


from parsing import *
from semantic import *
import sys

def filter(allLines) :
	#print "filter..."
	tab = [0]
	loop = [""]
	state = 1
	loop_command = ['if','while','for','def','elif','else','repeat']
	script = ""
	scriptList=[]
	brace_stack = []
	for line in allLines :
		#print "line : ",line
		tab_count = 0
		for char in line :
			if char == "\t" :
				tab_count = tab_count + 1
			elif char == " " :
				error_in_main()
			else : break
		if "\n" in line :
			line = line.replace("\n",";\n")
		else : line = line + ";"
		line = line.replace("\t","")
		token = line.split(" ")
		if state == 1 :
			if tab_count > tab[len(tab)-1] : error_in_main()
			elif tab_count < tab[len(tab)-1] :
				if (line[0] == "}") :
					if (tab_count != tab[len(tab)-2]) : error_in_main()
					else : script = script + "}"
					brace_stack.pop()
					tab.pop()
				else :
					tab.pop()
					while tab_count < tab[len(tab)-1] :
						script = script + "}"
						tab.pop()
						loop.pop()
					if tab_count == tab[len(tab)-1] :
						script = script + "}"
					else : error_in_main()
			if tab_count == tab[len(tab)-1] :
				if token[0] in loop_command :
					state = 2
					if (loop[len(loop)-1] == "if") and (token[0] in ["else","elif"]):
						script = script + line
					elif tab_count != 0 :
						loop.pop()
						loop.append(token[0])
						script = script + line
					elif tab_count == 0 :
						if script != "" : scriptList.append(script)
						loop.pop()
						loop.append(token[0])
						script = line
				elif line[0] == "{" :
					state = 3
					if tab_count == 0 :
						if script != "" : 
							scriptList.append(script)
							script = ""
					script = script + "{"
				elif tab_count == 0 :
					if token[0] == "until" :
						script = script + line
						scriptList.append(script)
						script = ""
					elif script != "" :
						scriptList.append(script)
						script = ""
						if line[0] != "}" : scriptList.append(line)
					else : scriptList.append(line)
				elif line[0] == "}" : pass
				else : script = script + line
			else : error_in_main()
		elif state == 2 :
			if tab_count <= tab[len(tab)-1] : error_in_main()
			else :
				tab.append(tab_count)
				if token[0] not in loop_command :
					if line[0] == "{" :
						state = 3
						line = ""
					else : state = 1
				else : loop.append(token[0])
			script = script + "{" + line	
		elif state == 3 :
			if tab_count <= tab[len(tab)-1] : error_in_main()
			else :
				tab.append(tab_count)
				brace_stack.append("{")
				if token[0] in loop_command : 
					state = 2
					loop.append(token[0])
				elif line[0] != "{" : state = 1
				else : line = "{"
			script = script + line
			
	if (len(tab)>1) :
		brace_num = len(tab)-1
		brace = ""
		for count in range(brace_num) :
			brace = brace + "}"
		script = script + brace
		scriptList.append(script)
	return scriptList

def error_in_main() :
	print "Error in Filter Syntax"
	sys.exit(0)

def execute(scripts) :
	scriptList = filter(scripts)
	#print "script : ",scriptList
	for script in scriptList :
		parseObj = Parse(script)
		astList = parseObj.ast
		#print "astList : ",astList
		for i in astList :
			#print "i : ",i
			interprete(i)



if __name__ == '__main__' :

	#filename = raw_input('Enter file name : ')
	filename = 'C:\\PythonCE\\browser\\scripts\\time.txt'
	#filename = 'E:\\project\\codekim\\scripts\\'+ filename
	#filename = '\\Program Files\\Python\\scripts\\me.txt'

	file = open(filename,'r')
	allLines = file.readlines()
	file.close()
	print "allLines : ",allLines
	scriptList = filter(allLines)
	print "script : ",scriptList
	for script in scriptList :
		parseObj = Parse(script)
		astList = parseObj.ast
		#print "astList : ",astList
		for i in astList :
			#print "i : ",i
			interprete(i)

