#######################################################
##   used to pare a file to dict and send
##   user to save a dict to a file with well structure
##   2004/01/23
#######################################################

import sys
import string
import os

from config import *

class getuserprofile:

    def __init__(self):
        print 'getUserProfile.__init__()'
        self.path = userprofilepath
        
    def setpath(self,PATH):
        self.path = PATH

## input 2 arg <1 filename > <2 dictionary for store data and return >
    def getuserpf(self,filename,UPdict):
        try :
            filename = self.path + filename
            f = open(filename,'r')
            lines = f.readlines()
            f.close()            
        except :
            print filename+" <- Profile not found"
        try :
            for line in lines :
                line = string.strip(line)
                key, value = line.split('::')
                key = string.strip(key)
                value = string.strip(value)
                #print key+":"+value
                if not key :
                    continue
                else:
                    UPdict[key] = value
        except :
            print filename+" <- Profile file corrupt"
        return  UPdict


    
    def saveuserpf(self,filename,UPdict) :
        try :
            filename = self.path + filename
            f = open(filename,'w')              
        except :
            print filename+" <- Profile not found"
        lines=""
        for k, v in UserProfileDict.items():
            lines = lines+k+" :: "+v+"\n"
        try :
            f.write(lines)
            f.close()
        except :
            print filename+" <-  Error writing profile"





#######################################################
##   test class section
#######################################################
#userurofiledict = {}
#t=getuserprofile()
#userprofiledict = t.getuserpf('mail.profile',userprofiledict) 
#t.setpath('C:\\PythonCE\\userprofile\\')
#for k, v in userprofiledict.items():
#    print k, v
#t.saveuserpf('mail2.profile',userprofiledict)
######################################################

            
   