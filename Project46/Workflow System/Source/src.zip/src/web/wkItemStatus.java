/*
 * Created on 13 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package web;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class wkItemStatus {

  static String status = "";

  public wkItemStatus() {
  }
	//  Action Status
  public static String getStatus(String st){
	if(st.equals("1")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='RED'>ACTIVE</FONT>";
	}else if(st.equals("2")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='GREEN'>APPROVE</FONT>";
	}else if(st.equals("3")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='RED'>ABORT</FONT>";
	}else if(st.equals("4")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='GRAY'>NO RECIPIENT</FONT>";
	}else if(st.equals("5")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='BLUE'>RETURN</FONT>";
	}else if(st.equals("6")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='VIOLET'>ASSIGN</FONT>";
	}else if(st.equals("7")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='1' COLOR='ORANGE'>DISAPPROVE<FONT>";
	}else{
	  status = "";
	}
	return status;
  }

  public static String getNumstatus(String st){
	if(st.equalsIgnoreCase("active")){
	  status = "1";//@ 1 = active
	}else if(st.equalsIgnoreCase("approve")){
	  status = "2";
	}else if(st.equalsIgnoreCase("abort")){
	  status = "3";
	}else if(st.equalsIgnoreCase("no_recipient")){
	  status = "4";
	}else if(st.equalsIgnoreCase("return")){
	  status = "5";
	}else if(st.equalsIgnoreCase("assign")){
	  status = "6";
	}else if(st.equalsIgnoreCase("disapprove")){
	  status = "7";
	}else if(st.equalsIgnoreCase("save")){
	  status = "8";
	}else if(st.equalsIgnoreCase("send")){
	  status = "9";//@ 1 = active
	}else{
	  status = "";
	}
	return status;
  }
}
