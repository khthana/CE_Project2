/*
 * Created on 8 ��.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package web;

import java.util.StringTokenizer;

import util.WorkflowControlData;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListBox implements WorkflowControlData{
	private String element="";
	private String input_name="";
	private String input_value="";
	private String  disabled="";
	private String init_value="";
	
	public ListBox(){
		
	}
	public ListBox(String input_name,String input_value,String value,String disabled,String nullable){
		this.input_name=input_name;
		this.input_value=input_value;
		this.init_value=value;
		if( disabled.equals(READ_ONLY));
				setDisable();
		if( nullable.equals(NULLABLE))
				setNull();
	}
	public void setNull(){
		this.init_value=NULLABLE;// add null
		this.input_value=NULLABLE+"##"+this.input_value;
	}
	public ListBox(String webElement){
		this.element=webElement;
	}
	public void setName(String name){
		this.input_name=name;
	}
	public String getName(){
		return this.input_name;
	}
	public void setValue(String value){
		this.input_value=value;
	}
	public String getValue(){
		return this.input_value;
	}
	public void setDisable(){
		this.disabled="disabled";
	}
	public void setEnalble(){
		this.disabled="";
	}
	public void setInitValue(String init){
		this.init_value=init;
	}
	public String getInitValue(){
		return this.init_value;
	}
	public String getWebElement(){
		String head="<select name=\""+input_name+"\" "+disabled+">";
		StringTokenizer st=new StringTokenizer(input_value,"##");
		String value="";
		while( st.hasMoreTokens() ){
			value=st.nextToken();
			if( value.equals(this.init_value) )
				element+="<option value=\""+value+"\" selected >"+value+"</option>";
			else
				element+="<option value=\""+value+"\" >"+value+"</option>";
		}
		//System.out.println(element);
		String tail="</select>";
		this.element=head+this.element+tail;
		return this.element;
	}
}