/*
 * Created on 8 ��.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package web;

import util.WorkflowControlData;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TextFields implements WorkflowControlData{
		private String element="";
		private String input_name="";
		private String  disabled="";
		private String init_value="";
		
		public TextFields(){
		
		}
		public TextFields(String input_name,String value,String disabled,String nullable){
			this.input_name=input_name;
			this.init_value=value;
			if( disabled.equals(READ_ONLY) )
				setDisable();
			if( nullable.equals(NULLABLE))
				setNull();
		}
		public void setNull(){
			this.init_value="";
		}
		public TextFields(String webElement){
			this.element=webElement;
		}
		public void setName(String name){
			this.input_name=name;
		}
		public String getName(){
			return this.input_name;
		}
		public void setDisable(){
			this.disabled="disabled";
		}
		public void setEnalble(){
			this.disabled="";
		}
		public void setInitValue(String init){
			this.init_value=init;
		}
		public String getInitValue(){
			return this.init_value;
		}
		public String getWebElement(){
			this.element="<input type=\"text\" name=\""+input_name+"\" value=\""+init_value+"\" "+disabled+">";
			return this.element;
		}
}