/*
 * Created on 14 ��.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package web;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Status {

  static String status = "";

  public Status() {
  }
	//  Action Status
  public static String getAiStatus(String st){
	if(st.equals("1")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>ACTIVE</FONT>";
	}else if(st.equals("2")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='GREEN'>APPROVE</FONT>";
	}else if(st.equals("3")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>IGNORE</FONT>";
	}else if(st.equals("4")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='GRAY'>ABORT</FONT>";
	}else if(st.equals("5")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='BLUE'>DISAPPROVE</FONT>";
	}else if(st.equals("6")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='VIOLET'>RETURN</FONT>";
	}else if(st.equals("7")){
	  status = "<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='ORANGE'>ASSIGN<FONT>";
	}else{
	  status = "";
	}
	return status;
  }
  public static String getPriority(String prio){
  	if( prio.equals("0")){
  		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>���</FONT>";
  	}else if(prio.equals("1")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>����</FONT>";
  	}else if(prio.equals("2")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>�ҹ��ҧ</FONT>";
  	}else if(prio.equals("3")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>�ҡ</FONT>";
  	}else if(prio.equals("4")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>�Ӥѭ�ҡ</FONT>";
  	}else{
  		status="";
  	}
  	return status;
  }
  public static String getStepStatus(String st){
  	if( st.equals("1") ){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>ACTIVE</FONT>";
  	}else if( st.equals("2")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>COMPLETE</FONT>";
  	}else if( st.equals("3")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>ABORT</FONT>";
  	}else if( st.equals("4")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>NO RECIEPIENT</FONT>";
  	}else if( st.equals("5")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>NOT COMPLETE</FONT>";
  	}else if( st.equals("6")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>RETURN</FONT>";
  	}else if( st.equals("7")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>IGNORE</FONT>";
  	}else {
  		status="";
  	}
  	return status;
  }
  public static String getWfStatus(String st){
  	if( st.equals("1") ){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>ACTIVE</FONT>";
  	}else if( st.equals("2") ){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>COMPLETE</FONT>";
  	}else if( st.equals("3")){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>ABORT</FONT>";
  	}else if( st.equals("4") ){
		status="<FONT FACE='MS Sans Serif, DB ThaiText' SIZE='2' COLOR='RED'>No Recipient</FONT>";
  	}
  	return status;
  }
}
