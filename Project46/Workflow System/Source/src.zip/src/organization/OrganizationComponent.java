/*
 * Created on 11 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization;
/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.util.*;
public interface OrganizationComponent{
		//	search resource
	// if not found it will be return null;
	User findUserById( String user_code );
	//	if not found it will be return null;
	Team findTeamById( String team_code );
	//	if not found it will be return null;
	Position findPositionById(String position_id);
	//	if not found it will be return null;
	Queue findQueueById( String queue_code);
	// if not found it will be return null;
	Role findRoleById(String role_id);
		// list all resource
	Collection findAllUsers();
	Collection findAllTeams();
	Collection findAllPositions();
	Collection findAllQueues();
	Collection findAllRoles();
	
		// add resource
	void addUser(User u);
	void addTeam(Team t);
	void addPosition(Position p);
	void addQueue(Queue q);
	void addRole(Role r);
	
		// delete resource
	void delUser(String u_code);
	void delTeam(String t_code);
	void delPosition(String p_id);
	void delQueue(String q_code);
	void delRole(String r_id);
	
		//  update
	void updateUser(User u);
	void updateTeam(Team t);
	void updatePosition(Position p);
	void updateQueue(Queue q);
	void updateRole(Role r);
}