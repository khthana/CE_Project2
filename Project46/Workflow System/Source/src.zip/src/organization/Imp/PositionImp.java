/*
 * Created on 21 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

import java.sql.ResultSet;

import organization.Position;

import util.Database;
import util.DatabaseField;
/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PositionImp implements Position,DatabaseField{
	private String position_id;
	private String position_name;
	private String reportPosition;
	private String role_id;
	public PositionImp(String post_id){
		Database mydb=new Database("workflow");
		String sql="select * from position where position_id='"+position_id+"'";
		sql+="";
		ResultSet rs=mydb.executeQuery(sql);
		if ( mydb.nextRecord(rs) ){
			this.position_id=post_id;
			this.position_name=mydb.getColumn(rs,FLD_POSITION_NAME);
			this.reportPosition=mydb.getColumn(rs,FLD_REPORT_POSITION);
			this.role_id=mydb.getColumn(rs,FLD_ROLE);
		}
	}
	public void setPorstId(String post_id){
		this.position_id=post_id;
	}
	public String getPostId(){
		return this.position_id;
	}
	public void setPostName(String pname){
		this.position_name=pname;
	}
	public String getPostName(){
		return this.position_name;
	}
	public void steReportPost(String reportP){
		this.reportPosition=reportP;
	}
	public String getReportPost(){
		return this.reportPosition;
	}
	public String getRoleId(){
		return this.role_id;
	}
	public void setRoleId(String role_id){
		this.role_id=role_id;
	}
}