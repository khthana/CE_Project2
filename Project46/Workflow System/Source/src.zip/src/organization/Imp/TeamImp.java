/*
 * Created on 14 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

import java.sql.ResultSet;
import java.util.*;
import organization.Team;
import util.Database;
import util.DatabaseField;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TeamImp implements Team,DatabaseField{
	private String team_code;
	private String SQL;
	private ResultSet rs;
	private Database mydb;
	public TeamImp(String team_code){
		this.team_code=team_code;
		mydb=new Database("workflow");
		String sql="select * from Team where team_code='"+this.team_code+"'";
		rs=mydb.executeQuery(sql);
		mydb.nextRecord(rs);
	}
	public String getTeamCode(){
		/*
		* * put your code here
		*/
		return this.team_code;
	}
	public String getTeamName(){
		/*
		* * put your code here
		*/
		return mydb.getColumn(rs,FLD_TEAM_NAME);
	}
	public Collection getMembers(){
		Vector us=new Vector();
		/*
		* * put your code here
		*/
			SQL="select "+FLD_USER_CODE+" from team_user where "+FLD_TEAM_CODE+"='"+team_code+"'";
			rs=mydb.executeQuery(SQL);
			while(mydb.nextRecord(rs))
				us.addElement(new UserImp( mydb.getColumn(rs,FLD_USER_CODE) ) );
			return us;
	}
	public String getTeamDesc(){
		return mydb.getColumn(rs,FLD_TEAM_DESC);
	}
}
