/*
 * Created on 14 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

import java.sql.ResultSet;

import organization.User;
import util.Database;
import util.DatabaseField;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class UserImp implements User,DatabaseField{
	private String user_code;
	private String user_name;
	private String pri_post;
	private String job_grade;
	private String email;
	private String utype;
	private String passwd;
	private String begin_date;
	private String end_date;
	// u must make sure user is valid before creat userImp("MD-001")
	public UserImp() {
	}
	public UserImp(String user_code){
		Database mydb=new Database("workflow");
		String sql="select * from user where user_code='"+user_code+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if( mydb.nextRecord(rs) ){
			this.user_code=user_code;
			this.user_code=user_code;
			this.user_name=mydb.getColumn(rs,FLD_USER_NAME);
			this.pri_post=mydb.getColumn(rs,FLD_PRIMARY_POSITION);
			this.job_grade=mydb.getColumn(rs,FLD_JOB_GRADE);
			this.email=mydb.getColumn(rs,FLD_EMAIL);
			this.utype=mydb.getColumn(rs,FLD_UTYPE);
			this.passwd=mydb.getColumn(rs,FLD_PASSWORD);
			this.begin_date=mydb.getColumn(rs,FLD_BEGIN_DATE);
			this.end_date=mydb.getColumn(rs,FLD_END_DATE);
		}
	}
	public String getUserCode(){
		/*
		* * put your code here
		*/
		return  this.user_code;
	}
	public void setUserCode(String user_code){
		/*
		* * put your code here
		*/
		this.user_code=user_code;
	}
	public String getUserName(){
		/*
		* * put your code here
		*/
		return this.user_name;
	}
	public void setUserName(String user_name){
		/*
		* * put your code here
		*/
		this.user_name=user_name;
	}
	public String getPrimaryPost(){
		/*
		* * put your code here
		*/
		return this.pri_post;
	}
	public void setPrimaryPost(String pri_post){
		/*
		* * put your code here
		*/
		this.pri_post=pri_post;
	}
	public String getJobGrade(){
		/*
		* * put your code here
		*/
		return this.job_grade;
	}
	public void setJobGrade(String job_grade){
		/*
		* * put your code here
		*/
		this.job_grade=job_grade;
	}
	public String getEmail(){
		/*
		* * put your code here
		*/
		return this.email;
	}
	public void setEmail(String email){
		/*
		* * put your code here
		*/
		this.email=email;
	}
	public String getUType(){
		/*
		* * put your code here
		*/
		return this.utype;
	}
	public void setUType(String utype){
		/*
		* * put your code here
		*/
		this.utype=utype;
	}
	public String getPasswd(){
		/*
		* * put your code here
		*/
		return this.passwd;
	}
	public void setPasswd(String passwd){
		/*
		* * put your code here
		*/
		this.passwd=passwd;
	}
	public String getBeginDate(){
		/*
		* * put your code here
		*/
		return this.begin_date;
	}
	public void setBeginDate(String begin_date){
		/*
		* * put your code here
		*/
		this.begin_date=begin_date;
	}
	public String getEndDate(){
		return this.end_date;
	}
	public void setEndDate(String end_date){
		/*
		* * put your code here
		*/
		this.end_date=end_date;
	}
}