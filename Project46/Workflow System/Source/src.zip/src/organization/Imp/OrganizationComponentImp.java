/*
 * Created on 14 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.util.*;

import organization.OrganizationComponent;
import organization.Queue;
import organization.*;
import util.Database;
import util.DatabaseField;

public class OrganizationComponentImp implements OrganizationComponent,DatabaseField{
	private ResultSet rs;
	private String result;
	private Database mydb;
	public OrganizationComponentImp(){
		mydb=new Database("workflow");
	}
		//////////////////  search  resource
	public User findUserById( String user_code ){
		String SQL="select "+FLD_USER_CODE+" from User where "+FLD_USER_CODE+"='"+user_code+"'";
		rs=mydb.executeQuery(SQL);
		if( mydb.nextRecord(rs) ){
			return new UserImp(user_code);
		}else
			return null;
	}
  
	public Team findTeamById( String team_code ){
		String SQL="select "+FLD_TEAM_CODE+" from Team where "+FLD_TEAM_CODE+" ='"+team_code+"'";
		rs=mydb.executeQuery(SQL);
		if( mydb.nextRecord(rs) )
			return new TeamImp(team_code);
		else
			return null;
	}
	
	public Position findPositionById(String position_id){
		String SQL="select "+FLD_POSITION_ID+" from Position where "+FLD_POSITION_ID+" ='"+position_id+"'";
		rs=mydb.executeQuery(SQL);
		if( mydb.nextRecord(rs) )
			return new PositionImp(position_id);
		else
			return null;
	}
	
	public Queue findQueueById(String queue_code){
		String SQL="select "+FLD_QUEUE_CODE+" from Queue where "+FLD_QUEUE_CODE+" ='"+queue_code+"'";
		rs=mydb.executeQuery(SQL);
		if( mydb.nextRecord(rs) )
			return new QueueImp(queue_code);
		else
			return null;
	}
	
	public Role findRoleById( String role_id){
		String SQL="selecrt "+FLD_ROLE_ID+" from Role where "+FLD_ROLE_ID+" ='"+role_id+"'";
		rs=mydb.executeQuery(SQL);
		if( mydb.nextRecord(rs) )
			return new RoleImp(role_id);
		else
			return null;
	}
	/////////////////////////////////////////
		// get all resource
	public Collection findAllUsers(){
		Vector us=new Vector();
		String SQL="select "+FLD_USER_CODE+" from User";
		rs=mydb.executeQuery(SQL);
			while(mydb.nextRecord(rs))
				us.addElement(new UserImp(mydb.getColumn(rs,FLD_USER_CODE)));
		return us;
	}
	
	public Collection findAllTeams(){
		Vector us=new Vector();
		String SQL="select "+FLD_TEAM_CODE+" from Team";
		rs=mydb.executeQuery(SQL);
			while(mydb.nextRecord(rs))
				us.addElement(new TeamImp(mydb.getColumn(rs,FLD_TEAM_CODE)));
		return us;
	}
	public Collection findAllPositions(){
		Vector us=new Vector();
		String SQL="select "+FLD_POSITION_ID+" from position";
		rs=mydb.executeQuery(SQL);
			while(mydb.nextRecord(rs))
				us.addElement(new PositionImp(mydb.getColumn(rs,FLD_POSITION_ID)));
		return us;
	}
	public Collection findAllQueues(){
		Vector us=new Vector();
		String SQL="select "+FLD_QUEUE_CODE+" from queue";
		rs=mydb.executeQuery(SQL);
			while(mydb.nextRecord(rs))
				us.addElement(new QueueImp(mydb.getColumn(rs,FLD_QUEUE_CODE)));
		return us;
	}
	public Collection findAllRoles(){
		Vector pos=new Vector();
		String sql="select "+FLD_ROLE_ID+" from organization_role";
		ResultSet rs=mydb.executeQuery(sql);
			while(mydb.nextRecord(rs))
				pos.addElement(new RoleImp(mydb.getColumn(rs,FLD_ROLE_ID)));
		return pos;
	}
	//////////////////////////////////////////////////////
		// add resource
	public void addUser(User u){
		mydb.initMyTable("USER");
		mydb.set(FLD_USER_CODE,u.getUserCode());
		mydb.set(FLD_USER_NAME,u.getUserName());
		mydb.set(FLD_PRIMARY_POSITION,u.getPrimaryPost());
		mydb.set(FLD_JOB_GRADE,Integer.parseInt(u.getJobGrade()));
		mydb.set(FLD_EMAIL,u.getEmail());
		mydb.set(FLD_PASSWORD,u.getPasswd());
		mydb.set(FLD_UTYPE,Integer.parseInt(u.getUType()));
		mydb.set(FLD_BEGIN_DATE,u.getBeginDate());
		mydb.set(FLD_END_DATE,u.getEndDate());
		mydb.insert();
	}
	public void addTeam(Team t){
		mydb.initMyTable(TBL_TEAM);
		mydb.set(FLD_TEAM_CODE,t.getTeamCode());
		mydb.set(FLD_TEAM_NAME,t.getTeamName());
		mydb.set(FLD_TEAM_DESC,t.getTeamDesc());
		mydb.insert();
	}
	public void addPosition(Position p){
		
	}
	public void addQueue(Queue q){
		
	}
	public void addRole(Role r){
		
	}
	
	public Collection findUsersByTeamAndRole( String team, String role ){
		Vector us=new Vector();
		try{
			String SQL="select user_code from team , role";
				  SQL=" where team.team_id='"+team+"' and ";
			rs=mydb.executeQuery(SQL);
			while( rs.next() )
				us.addElement(rs.getString("user_code"));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return us;
	}
  		// del team
	public void delUser(String u_code){
		Database db = new Database("workflow");
		db.initMyTable(TBL_USER);
		db.setFilter(FLD_USER_CODE,u_code);
		db.delete();
	}
	public void delTeam(String t_code){
		
	}
	public void delPosition(String p_id){
		
	}
	public void delQueue(String q_code){
		
	}
	public void delRole(String r_id){
		
	}
	
		//  update
	public void updateUser(User u){
		Database db = new Database("workflow");
		db.initMyTable(TBL_USER);
		db.set(FLD_USER_NAME,u.getUserName());
		db.set(FLD_PRIMARY_POSITION,u.getPrimaryPost());
		db.set(FLD_JOB_GRADE,u.getJobGrade());
		db.set(FLD_EMAIL,u.getEmail());
		db.set(FLD_PASSWORD,u.getPasswd());
		db.set(FLD_UTYPE,u.getUType());
		db.set(FLD_BEGIN_DATE,u.getBeginDate());
		db.set(FLD_END_DATE,u.getEndDate());
		db.setFilter(FLD_USER_CODE,u.getUserCode());
		db.update();
	}
	public void updateTeam(Team t){
		
	}
	public void updatePosition(Position p){
		
	}
	public void updateQueue(Queue q){
		
	}
	public void updateRole(Role r){
		
	}
	
	// add member in to resource
		// add user in team
	public void addMemberInTeam(){
		
	}
		// add user in queue
	public void addMemberInQueue(){
		
	}
		// add position in role
	public void addMemberInRole(){
		
	}
}
