/*
 * Created on 19 ��.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Vector;

import organization.Role;
import util.Database;
import util.DatabaseField;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RoleImp implements Role,DatabaseField{
	private String role_id;
	private String role;
	private String role_desciption;
	public RoleImp(String role_id){
		Database mydb=new Database("workflow");
		String sql="select * from user where user_code='"+this.role_id+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if( mydb.nextRecord(rs) ){
			this.role_id=role_id;
			this.role=mydb.getColumn(rs,FLD_ROLE);
			this.role_desciption=mydb.getColumn(rs,FLD_ROLE_DESC);
		}
	}
	public String getRoleId(){
		return this.role_id;
	}
	public void setRoleId(String role_id){
		this.role_id=role_id;
	}
	public String getRole(){
		return this.role;
	}
	public String getRoleDesc(){
		return this.role_desciption;
	}
	public void setRoleDesc(String role_desc){
		this.role_desciption=role_desc;
	}
	public Collection getPositionInRole(){
		Database mydb=new Database("workflow");
		Vector v=new Vector();
		String sql="select * from "+TBL_ORGANIZATION_ROLE+" where user_code='"+this.role_id+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if( mydb.nextRecord(rs) ){
			v.addElement(new PositionImp(mydb.getColumn(rs,FLD_POSITION_ID)));
		}
		return v;
	}
}