/*
 * Created on 22 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization.Imp;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Vector;

import organization.Queue;
import util.Database;
import util.DatabaseField;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class QueueImp implements Queue,DatabaseField {
	private String q_code;
	private String q_name;
	private String q_desc;
	private String q_type;
	public QueueImp(String q_code){
		Database mydb=new Database("workflow");
		String sql="select * from Queue where queue_code='"+q_code+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if( mydb.nextRecord(rs) ){
			this.q_code=q_code;
			this.q_name=mydb.getColumn(rs,FLD_QUEUE_NAME);
			this.q_type=mydb.getColumn(rs,FLD_QUEUE_TYPE);
			this.q_desc=mydb.getColumn(rs,FLD_QUEUE_DESC);
		}
	}
	public String getQueueCode(){
		return this.q_code;
	}
	public void setQueueCode(String q_code){
		this.q_code=q_code;
	}
	public String getQueueName(){
		return this.q_name;
	}
	public void setQueueName(String q_name){
		this.q_name=q_name;
	}
	public String getQueueType(){
		return this.q_type;
	}
	public void setQueueType(String q_type){
		this.q_type=q_type;
	}
	public String getQueueDesc(){
		return this.q_desc;
	}
	public void setQueueDesc(String q_desc){
		this.q_desc=q_desc;
	}
	public Collection getMemberQueue(){
		Database mydb=new Database("workflow");
		Vector v=new Vector();
		String sql="select * from "+TBL_QUEUE_USER+" where q_code='"+this.q_code+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if( mydb.nextRecord(rs) )
			v.addElement(new UserImp(mydb.getColumn(rs,FLD_QUEUE_CODE)));
		return v;
	}
}
