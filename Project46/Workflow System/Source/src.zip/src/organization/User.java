/*
 * Created on 11 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface User{
	String getUserCode();
	String getUserName();
	String getPrimaryPost();
	String getJobGrade();
	String getEmail();
	String getUType();
	String getPasswd();// retrive md5 message from database
	String getBeginDate();
	String getEndDate();
}