/*
 * Created on 15 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization;

import java.util.Collection;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface Role {
	// such as GMR ��� manager
	String getRoleId();
	String getRole();
	String getRoleDesc();
	Collection getPositionInRole();
}
