/*
 * Created on 14 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package organization;

import java.util.Collection;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public interface Team {
	String getTeamCode();
	String getTeamName();
	String getTeamDesc();
	Collection getMembers();
}
