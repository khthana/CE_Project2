/*
 * Created on 2 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
import util.MyCalendar;
import util.WorkflowControlData;
import workflow.engine.definition.StepDefinition;
import workflow.engine.definition.Transition;
import workflow.engine.definition.WorkflowDefinition;

public class StepIncident extends Database implements DatabaseField, WorkflowControlData{

	//private Properties stepProp = new Properties();
	//private ResultSet rs;
	//private ActorIncident actinc = null;
	//private WorkflowVariable wv = null;
	//private StepStatus sts = null;
	//private ActorIncStatus acts = null;
	//private MyInterpreter myi = null;
	
	public StepIncident() {
		super("workflow");
	}
	public StepIncident(Properties scrData) {
		super("workflow");
		//stepProp = scrData;
		super.initMyTable(TBL_STEP_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		ResultSet rs = super.search();
		if (!super.nextRecord(rs)) {
			this.createStepIncident(scrData);
		} else {
			this.updateStepIncident(scrData);
		}
	}
	
	private void createStepIncident(Properties scrData) {
		super.initMyTable(TBL_STEP_INCIDENT);
				
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		//super.set(FLD_STEP_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_STEP_SEQ_NO)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		//super.set(FLD_EXP_COMPLETION_TIME,scrData.getProperty(FLD_EXP_COMPLETION_TIME));
		//super.set(FLD_EXP_EXTENTION_TIME,scrData.getProperty(FLD_EXP_EXTENTION_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		
		super.insert();
	}
	private void updateStepIncident(Properties scrData) {
		super.initMyTable(TBL_STEP_INCIDENT);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		//super.set(FLD_STEP_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_STEP_SEQ_NO)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		//super.set(FLD_EXP_COMPLETION_TIME,scrData.getProperty(FLD_EXP_COMPLETION_TIME));
		//super.set(FLD_EXP_EXTENTION_TIME,scrData.getProperty(FLD_EXP_EXTENTION_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.update();
	}
	
	public ResultSet getStepIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String status){
		super.initMyTable(TBL_STEP_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_STATUS,Integer.parseInt(status));
		return super.search();
	}
	public ResultSet getStepIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		super.initMyTable(TBL_STEP_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		return super.search();
	}
	public ResultSet getStepIncident(String wf_id,String wf_ver,String wf_seq_no){
		super.initMyTable(TBL_STEP_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setOrder(FLD_START_TIME);
		return super.search();
	}
	// return StepDefinition of StepIncident
	public ResultSet getDefinition(String wf_id,String wf_ver,String step_id) {
		StepDefinition std = new StepDefinition();
		return std.getStepDef(wf_id,wf_ver,step_id);
	}
	/*
	// get Status of Step
	public String getStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		String res = "";
		return res;
	}
	*/
	// set Status of Step by StepStatus
	public void setStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String status) {
		//Calendar ca = Calendar.getInstance();
		String datetime = MyCalendar.getDataTime();//ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543)+" "+ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		super.initMyTable(TBL_STEP_INCIDENT);
		
		super.set(FLD_STATUS,Integer.parseInt(status));
		super.set(FLD_COMPLETION_TIME,datetime);
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.update();
	}
	/*
	// Create Actor Incident in Step
	public void createActorIncident(Properties scrData) {
		actinc = new ActorIncident(scrData);
	}
	// set Status of actor incident
	public void setStatusActorInc(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String status) {
		actinc = new ActorIncident();
		actinc.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,status);
	}
	*/
	/*
	// get group of actorincident
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {		
		actinc = new ActorIncident();
		rs = actinc.getActorInc(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		return rs;
	}
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id) {		
		actinc = new ActorIncident();
		rs = actinc.getActorInc(wf_id,wf_ver,wf_seq_no,step_id);
		return rs;
	}
	*/
	
	// move to next
	public void next(String wf_id,String wf_ver,String wf_seq_no,String step_id,String event,String user_code,String position_code) {
		MyInterpreter myi = new MyInterpreter(wf_id,wf_ver,wf_seq_no,step_id);
		StepIncident si = new StepIncident();
		ResultSet rs = si.getDefinition(wf_id,wf_ver,step_id);
		si.nextRecord(rs);
		String datetime = MyCalendar.getDataTime();
		String comp = si.getColumn(rs,FLD_COMPLETE_SCRIPT);
		//String user_code = "";
		//String pos_code = "";
		boolean bu2 = true;
		if (!(comp == null || comp.equals("") || comp.equals(" "))) {
			bu2 = ((Boolean)myi.executeScript(comp)).booleanValue();
		} else {
			ActorIncident ai = new ActorIncident();
			rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
			while (ai.nextRecord(rs)) {
				String eve = super.getColumn(rs,FLD_STATUS);
				if (eve.equals(STATUS_AI_ACTIVE)) {
					bu2 = false;
					break;
				}
			}
		}
		if (bu2) {
			Transition tt = new Transition();
			rs = tt.getTo(wf_id,wf_ver,step_id);
			boolean flow = false;
			StepDefinition sd = new StepDefinition();
			StepIncident stepinc = new StepIncident();
			ActorIncident ai1 = new ActorIncident();
			ActorIncident ai2 = new ActorIncident();
			QueueTransfer qt = new QueueTransfer();
			while (tt.nextRecord(rs)) {
				String onevent = super.getColumn(rs,FLD_ON_EVENT);
				String onev = EVENT_APPROVE;			
				String amount = "1";
				String next_step_id = super.getColumn(rs,FLD_NEXT_STEP_ID);
				//StepDefinition sd = new StepDefinition();
				ResultSet rs8 = sd.getStepDef(wf_id,wf_ver,next_step_id);
				sd.nextRecord(rs8);
				String type = sd.getColumn(rs8,FLD_STEP_TYPE);
				String precond = sd.getColumn(rs8,FLD_PRE_CONDITION).trim();
				if (onevent != null && !onevent.equals("") && !onevent.equals(" ") && !onevent.equals("-")) {
					if (onevent.length()>2) {
						amount = onevent.substring(0,onevent.indexOf("-"));
						onev = onevent.substring(onevent.indexOf("-")+1);
					}
				} else {
					amount = "1";
					onev = event;
				}
				if (precond==null||precond.equals("")||precond.equals(" ")||precond.equals("1")) {
					precond = "1";
				}
				if (onev.equals(event)){ //&& !type.equals(END_STEP)) {
					comp = super.getColumn(rs,FLD_CONDITION);
					if (onev.equals(EVENT_APPROVE)) {
						if (comp == null || comp.equals(" ") || comp.equals("")) {
							comp = "INC.APPROVE >= "+amount+" || INC.DISAPPROVE >= "+amount;
						} else {
							comp += " && INC.APPROVE >= "+amount;
						}
					} else if (onev.equals(EVENT_DISAPPROVE)) {
						if (comp == null || comp.equals(" ") || comp.equals("")) {
							comp = "INC.APPROVE >= "+amount+" || INC.DISAPPROVE >= "+amount;
						} else {
							comp += " && INC.DISAPPROVE >= "+amount;
						}
					}
					System.out.println(comp);
					//String nstid = super.getColumn(rs,FLD_NEXT_STEP_ID);
					//StepDefinition sd = new StepDefinition();
					WorkflowDefinition wf = new WorkflowDefinition();
					boolean bu3 = ((Boolean)myi.executeScript(comp)).booleanValue();
					if (bu3) {
						//StepIncident stepinc = new StepIncident();
						stepinc.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_COMPLETE);
						stepinc.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,datetime);
						flow = true;
						// complete
						ResultSet rs6 = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,step_id,QCOMMENT);
						while (qt.nextRecord(rs6)) {
							String tfr = qt.getColumn(rs6,FLD_TFR_ACTOR_ID);
							String own = qt.getColumn(rs6,FLD_OWNER_ACTOR_ID);
							String sta = qt.getColumn(rs6,FLD_STATUS);
							if (sta.equals(STATUS_QT_ACTIVE)) {
								qt.setStatus(wf_id,wf_ver,wf_seq_no,step_id,QCOMMENT,tfr,own,STATUS_QT_COMMENT_NOTCOMPLETE);
							}
						}
						ResultSet rsai1 = ai1.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);		
						while (ai1.nextRecord(rsai1)) {
							String ucode = ai1.getColumn(rsai1,FLD_ACTOR_ID);
							String pcode = ai1.getColumn(rsai1,FLD_POSITION_CODE);
							String sta = ai1.getColumn(rsai1,FLD_STATUS);
							if (sta.equals(STATUS_AI_ACTIVE)) {
								//ActorIncident ai2 = new ActorIncident();
								ai2.setStatus(wf_id,wf_ver,wf_seq_no,step_id,ucode,pcode,STATUS_AI_IGNORE);
							}
						}
						
						Properties p = new Properties();
						p.setProperty(FLD_WF_ID,wf_id);
						p.setProperty(FLD_WF_VER,wf_ver);
						p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
						p.setProperty(FLD_STEP_ID,next_step_id);	
						p.setProperty(FLD_START_TIME,datetime);
						p.setProperty(FLD_COMPLETION_TIME,"1/1/2000 00:00:00");
						p.setProperty(FLD_STATUS,STATUS_AI_ACTIVE);
						p.setProperty(FLD_COMMENT,"");
						p.setProperty(FLD_USER_CODE,user_code);
						p.setProperty(FLD_POSITION_CODE,position_code);
						//sd.createStepIncident(p);
						// next complete and set after next to ignore
						boolean newstep = true;
						if (Integer.parseInt(precond) > 1) {
							Transition ttt = new Transition();
							ResultSet rsttt = ttt.getFrom(wf_id,wf_ver,next_step_id);
							int possible = 0;
							int active = 0;
							int complete = 0;
							while (ttt.nextRecord(rsttt)) {
								String sid = ttt.getColumn(rsttt,FLD_STEP_ID);
								StepIncident si1 = new StepIncident();
								ResultSet rs1 = si1.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
								si1.nextRecord(rs1);
								if (si1.getColumn(rs1,FLD_STATUS).equals(STATUS_ST_ACTIVE)) {
									active++;
								} else if (si1.getColumn(rs1,FLD_STATUS).equals(STATUS_ST_COMPLETE)) {
									complete++;
								}
							}
							possible = active+complete;
							int pc = Integer.parseInt(precond);
							WorkflowIncident wfinc = new WorkflowIncident();
							wfinc.setStepStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_COMPLETE);
							if (pc > complete) {
								newstep = false;
							} else if (pc > possible) {
								newstep = false;
								//wfinc = new WorkflowIncident();
								wfinc.abort(wf_id,wf_ver,wf_seq_no,step_id);
								break;
							}
						}
						if (newstep) {
							// set ignore other step incident that active and connect the next step
							if (!type.equals(END_STEP)) {
								StepIncident si0 = new StepIncident();
								si0.ignoreStep(wf_id,wf_ver,wf_seq_no,step_id);
							/*
							Transition t5 = new Transition();
							ResultSet rst5 = t5.getFrom(wf_id,wf_ver,next_step_id);
							while (t5.nextRecord(rst5)) {
								String sid = t5.getColumn(rst5,FLD_STEP_ID);
								if (!sid.equals(step_id)) {
									StepIncident si5 = new StepIncident();
									ResultSet rssi5 = si5.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
									if (si5.nextRecord(rssi5)) {
										String sta5 = si5.getColumn(rssi5,FLD_STATUS);
										if (sta5.equals(STATUS_ST_ACTIVE)) {
											ActorIncident siai51 = new ActorIncident();
											ResultSet rssiai51 = siai51.getActorIncident(wf_id,wf_ver,wf_seq_no,sid);
											while (siai51.nextRecord(rssiai51)) {
												String sta51 = siai51.getColumn(rssiai51,FLD_STATUS);
												if (sta51.equals(STATUS_AI_ACTIVE)) {
													String paiact = siai51.getColumn(rssiai51,FLD_ACTOR_ID);
													String paipos = siai51.getColumn(rssiai51,FLD_POSITION_CODE);
													ActorIncident ai51 = new ActorIncident();
													ai51.setStatus(wf_id,wf_ver,wf_seq_no,sid,paiact,paipos,STATUS_AI_IGNORE);
												}
											}
											StepIncident si51 = new StepIncident();
											si51.setStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
										}
									} else {
										Transition t6 = new Transition();
										ResultSet rst6 = t6.getFrom(wf_id,wf_ver,sid);
										while (t6.nextRecord(rst6)) {
											xxx
										}
									}
								}
							}
							*/
							// create stepincident
							StepDefinition stdef = new StepDefinition();
							stdef.createStepIncident(p);
							/*
							WorkflowDefinition wfdef = new WorkflowDefinition();
							ResultSet rs5 = wfdef.getStepDefinition(wf_id,wf_ver,next_step_id);
							wfdef.nextRecord(rs5);
							String actdef = wfdef.getColumn(rs5,FLD_RECIPIENT_DEF);
							ResolveActor ra = new ResolveActor();
							// get all in type U,P,PC,T
							Vector actor = (Vector)ra.getRefActor(actdef);
							for (int i=0;i<actor.size();i++) {
								String pos = (String) actor.get(i);
								String uc = pos.substring(0,pos.indexOf(" "));
								pos = pos.substring(pos.indexOf(" ")+1);
								p.setProperty(FLD_ACTOR_ID,uc);
								p.setProperty(FLD_USER_CODE,uc);
								p.setProperty(FLD_POSITION_CODE,pos);
								ActorIncident aii = new ActorIncident(p);
							}
							actor = (Vector) ra.getAllQueue(actdef);
							p.setProperty(FLD_USER_CODE,user_code);
							p.setProperty(FLD_OWNER_ACTOR_ID,user_code);
							p.setProperty(FLD_STATUS,STATUS_QT_ACTIVE);
							for (int i=0;i<actor.size();i++) {
								String qc = (String) actor.get(i);
								p.setProperty(FLD_QUEUE_CODE,qc);
								QueueTransfer qtt = new QueueTransfer(p);
							}
							actor = (Vector) ra.getAllRole(actdef);
							for (int i=0;i<actor.size();i++) {
								String role = (String) actor.get(i);
								String fr = "";
								if (role.substring(0,1).equals("I")) {
									ActorIncident ai = new ActorIncident();
									ResultSet rsai = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,"1");
									ai.nextRecord(rsai);
									String uc = ai.getColumn(rsai,FLD_ACTOR_ID);
									String pc = ai.getColumn(rsai,FLD_POSITION_CODE);
									fr = ra.getUserRole(role,uc,pc);
								} else {
									fr = ra.getUserRole(role,user_code,position_code);
								}
								String uc = fr.substring(0,fr.indexOf(" "));
								String pc = fr.substring(fr.indexOf(" ")+1);
								p.setProperty(FLD_ACTOR_ID,uc);
								p.setProperty(FLD_USER_CODE,uc);
								p.setProperty(FLD_POSITION_CODE,pc);
								ActorIncident aii = new ActorIncident(p);
							}
							*/
							// check no recipient
							//ai2 = new ActorIncident();
							ResultSet rsai2 = ai2.getActorIncident(wf_id,wf_ver,wf_seq_no,next_step_id);
							int incident = 0;
							while (ai2.nextRecord(rsai2)) {
								incident++;
							}
							rsai2 = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,next_step_id);
							while (qt.nextRecord(rsai2)) {
								incident++;
							}
							if (incident == 0) {
								//StepIncident si1 = new StepIncident();
								//si1.setStatus(wf_id,wf_ver,wf_seq_no,next_step_id,STATUS_ST_NO_RECIPIENT);
								WfIncMgmt wimg = new WfIncMgmt();
								wimg.setStepStatus(wf_id,wf_ver,wf_seq_no,next_step_id,STATUS_ST_NO_RECIPIENT);
								wimg.setWfStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_NO_RECIPIENT);
							}
							StepIncident si1 = new StepIncident();
							si1.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_COMPLETE);
							} else if (newstep && type.equals(END_STEP)) {
								WorkflowIncident wi = new WorkflowIncident();
								wi.setStepStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_COMPLETE);
								wi.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_COMPLETE);
								StepDefinition sd11 = new StepDefinition();
								ResultSet rssd11 = sd11.getStepDef(wf_id,wf_ver,next_step_id);
								sd11.nextRecord(rssd11);
								String recip = sd11.getColumn(rssd11,FLD_RECIPIENT_DEF);
								//p = new Properties();
								p.setProperty(FLD_WF_ID,wf_id);
								p.setProperty(FLD_WF_VER,wf_ver);
								p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
								p.setProperty(FLD_STEP_ID,next_step_id);	
								p.setProperty(FLD_START_TIME,datetime);
								p.setProperty(FLD_COMPLETION_TIME,datetime);
								p.setProperty(FLD_COMMENT,"");
								p.setProperty(FLD_STATUS,STATUS_ST_COMPLETE);
								StepDefinition stdef = new StepDefinition();
								stdef.createStepIncident(p);
								if (!(recip==null||recip.equals("")||recip.equals(" "))) {
									if (recip.substring(1,2).equals("M")) {
										//send mail to user that was specify in the Definition
										wi = new WorkflowIncident();
										ResultSet rswi = wi.getWfInc(wf_id,wf_ver,wf_seq_no);
										wi.nextRecord(rswi);
										String init = wi.getColumn(rswi,FLD_INITIATOR);
										String wfname = wi.getColumn(rswi,FLD_WF_NAME);
										Database dbuser = new Database("workflow");
										dbuser.initMyTable(TBL_USER);
										dbuser.setFilter(FLD_USER_CODE,init);
										ResultSet rsuser = dbuser.search();
										dbuser.nextRecord(rsuser);
										String email = dbuser.getColumn(rsuser,FLD_EMAIL);
										String message = "Your workflow "+wfname+" No="+wf_seq_no+" was complete.";
										//WfMail wfm = new WfMail();
										//wfm.sendMail(email,message);
									}
								}
							}
					}/* else {
						ActorIncident actinc = new ActorIncident();
						ResultSet rsactinc = actinc.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
						int a = 0;
						while (actinc.nextRecord(rsactinc)) {
							if (actinc.getColumn(rsactinc,FLD_STATUS).equals(STATUS_AI_ACTIVE)) {
								a++;
								break;
							}
						}
						if (a == 0) {
							WorkflowIncident wfinc = new WorkflowIncident();
							wfinc.abort(wf_id,wf_ver,wf_seq_no,step_id);
						}
					}*/
				} /*else if (type.equals(END_STEP)){
					WorkflowIncident wi = new WorkflowIncident();
					wi.setStepStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_COMPLETE);
					wi.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_COMPLETE);
					StepDefinition sd11 = new StepDefinition();
					ResultSet rssd11 = sd11.getStepDef(wf_id,wf_ver,next_step_id);
					sd11.nextRecord(rssd11);
					String recip = sd11.getColumn(rssd11,FLD_RECIPIENT_DEF);
					Properties p = new Properties();
					p.setProperty(FLD_WF_ID,wf_id);
					p.setProperty(FLD_WF_VER,wf_ver);
					p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
					p.setProperty(FLD_STEP_ID,next_step_id);	
					p.setProperty(FLD_START_TIME,datetime);
					p.setProperty(FLD_COMPLETION_TIME,datetime);
					p.setProperty(FLD_COMMENT,"");
					p.setProperty(FLD_STATUS,STATUS_ST_COMPLETE);
					StepDefinition stdef = new StepDefinition();
					stdef.createStepIncident(p);
					if (!(recip==null||recip.equals("")||recip.equals(" "))) {
						if (recip.substring(1,2).equals("M")) {
							//send mail to user that was specify in the Definition
							wi = new WorkflowIncident();
							ResultSet rswi = wi.getWfInc(wf_id,wf_ver,wf_seq_no);
							wi.nextRecord(rswi);
							String init = wi.getColumn(rswi,FLD_INITIATOR);
							String wfname = wi.getColumn(rswi,FLD_WF_NAME);
							Database dbuser = new Database("workflow");
							dbuser.initMyTable(TBL_USER);
							dbuser.setFilter(FLD_USER_CODE,init);
							ResultSet rsuser = dbuser.search();
							dbuser.nextRecord(rsuser);
							String email = dbuser.getColumn(rsuser,FLD_EMAIL);
							String message = "Your workflow "+wfname+" No="+wf_seq_no+" was complete.";
							WfMail wfm = new WfMail();
							wfm.sendMail(email,message);
						}
					}
				}*/
			}
		}
	}
	}
	private void ignoreStep(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		Transition t = new Transition();
		ActorIncident ai = new ActorIncident();
		StepIncident si = new StepIncident();
		StepIncident sii = new StepIncident();
		ResultSet rst = t.getFrom(wf_id,wf_ver,step_id);
		while (t.nextRecord(rst)) {
			String sid = t.getColumn(rst,FLD_STEP_ID);
			//StepIncident si = new StepIncident();
			ResultSet rssi = si.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
			if (si.nextRecord(rssi)) {
				String sta = si.getColumn(rssi,FLD_STATUS);
				if (sta.equals(STATUS_ST_ACTIVE)) {
					si.setStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
					//ActorIncident ai = new ActorIncident();
					ResultSet rsai = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,sid);
					while (ai.nextRecord(rsai)) {
						String staai = ai.getColumn(rsai,FLD_STATUS);
						if (staai.equals(STATUS_AI_ACTIVE)) {
							String act = ai.getColumn(rsai,FLD_ACTOR_ID);
							String pos = ai.getColumn(rsai,FLD_POSITION_CODE);
							ActorIncident aii = new ActorIncident();
							aii.setStatus(wf_id,wf_ver,wf_seq_no,sid,act,pos,STATUS_AI_IGNORE);
						}
					}
				}
			} else if (!sid.equals("1")) {
				//StepIncident sii = new StepIncident();
				sii.ignoreStep(wf_id,wf_ver,wf_seq_no,sid);
			}
		}
	}
	// return to previous step
	public void returns(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code) {
		ResultSet rs = this.getDefinition(wf_id,wf_ver,step_id);
		super.nextRecord(rs);
		String bu1 = super.getColumn(rs,FLD_RETURN_SCRIPT);
		MyInterpreter myi = new MyInterpreter(wf_id,wf_ver,wf_seq_no,step_id);
		boolean bu2 = true;
		if (!(bu1.equals(null) || bu1.equals("") || bu1.equals(" "))) {
			bu2 = ((Boolean)myi.executeScript(bu1)).booleanValue();
		}
		if (bu2) {
			Transition t = new Transition();
			StepIncident sii = new StepIncident();
			ResultSet rst = t.getFrom(wf_id,wf_ver,step_id);
			int n = 0;
			while (t.nextRecord(rst)) {
				//StepIncident sii = new StepIncident();
				String ssid = t.getColumn(rst,FLD_STEP_ID);
				ResultSet rssii = sii.getStepIncident(wf_id,wf_ver,wf_seq_no,ssid);
				if (sii.nextRecord(rssii)) {
					n++;
				}
			}
			if (n == 1) {
				Transition tt = new Transition();
				ResultSet rstt = tt.getFrom(wf_id,wf_ver,step_id);
				tt.nextRecord(rstt);
				String psid = tt.getColumn(rstt,FLD_STEP_ID);
				tt = new Transition();
				rstt = tt.getTo(wf_id,wf_ver,psid);
				int a = 0;
				//sii = new StepIncident();
				while (tt.nextRecord(rstt)) {
					String sid = tt.getColumn(rstt,FLD_NEXT_STEP_ID);
					//StepIncident sii = new StepIncident();
					ResultSet rssii = sii.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
					if (sii.nextRecord(rssii)) {
						a++;
					}
				}
				if (a<2) {
					// one -- one
					//StepIncident sii = new StepIncident();
					sii.setStatus(wf_id,wf_ver,wf_seq_no,psid,STATUS_ST_ACTIVE);
					ActorIncident aii = new ActorIncident();
					ResultSet rsaii = aii.getActorIncident(wf_id,wf_ver,wf_seq_no,psid);
					ActorIncident aiii = new ActorIncident();
					while(aii.nextRecord(rsaii)) {
						String pact = aii.getColumn(rsaii,FLD_ACTOR_ID);
						String ppos = aii.getColumn(rsaii,FLD_POSITION_CODE);
						//ActorIncident aiii = new ActorIncident();
						aiii.setStatus(wf_id,wf_ver,wf_seq_no,psid,pact,ppos,STATUS_AI_ACTIVE);
					}
					//StepIncident siii = new StepIncident();
					sii.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_RETURN);
					//ActorIncident aiii = new ActorIncident();
					ResultSet rsaiii = aiii.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
					while (aiii.nextRecord(rsaiii)) {
						String pact = aiii.getColumn(rsaiii,FLD_ACTOR_ID);
						String ppos = aiii.getColumn(rsaiii,FLD_POSITION_CODE);
						//ActorIncident ai1 = new ActorIncident();
						ResultSet rsai1 = aii.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,pact);
						aii.nextRecord(rsai1);
						if (aii.getColumn(rsai1,FLD_STATUS).equals(STATUS_AI_ACTIVE)) {
							aii.setStatus(wf_id,wf_ver,wf_seq_no,step_id,pact,ppos,STATUS_AI_IGNORE);
						}
					}
				} else {
					//suport one -- many -- one
					Transition t3 = new Transition();
					ResultSet rst3 = t3.getTo(wf_id,wf_ver,step_id);
					t3.nextRecord(rst3);
					String nsid = t3.getColumn(rst3,FLD_NEXT_STEP_ID);
					StepDefinition stdef = new StepDefinition();
					ResultSet rsstdef = stdef.getStepDef(wf_id,wf_ver,nsid);
					stdef.nextRecord(rsstdef);
					String pre = stdef.getColumn(rsstdef,FLD_PRE_CONDITION);
					int b = 0;
					if (!(pre == null||pre.equals("")||pre.equals(" "))) {
						//Transition t1 = new Transition();
						ResultSet rst1 = t3.getTo(wf_id,wf_ver,psid);
						StepIncident si1 = new StepIncident();
						while (t3.nextRecord(rst1)) {
							String sid = t3.getColumn(rst1,FLD_STEP_ID);
							//StepIncident si1 = new StepIncident();
							ResultSet rssi1 = si1.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
							if (si1.nextRecord(rssi1)) {
								String sta = si1.getColumn(rssi1,FLD_STATUS);
								if (sta.equals(STATUS_ST_COMPLETE)||sta.equals(STATUS_ST_ACTIVE)) {
									b++;
								}
							}
						}
						int p = Integer.parseInt(pre);
						if (b < p) {
							//StepIncident sii = new StepIncident();
							sii.setStatus(wf_id,wf_ver,wf_seq_no,psid,STATUS_ST_ACTIVE);
							ActorIncident aii = new ActorIncident();
							ResultSet rsaii = aii.getActorIncident(wf_id,wf_ver,wf_seq_no,psid);
							ActorIncident aiii = new ActorIncident();
							while(aii.nextRecord(rsaii)) {
								String pact = aii.getColumn(rsaii,FLD_ACTOR_ID);
								String ppos = aii.getColumn(rsaii,FLD_POSITION_CODE);
								//ActorIncident aiii = new ActorIncident();
								aiii.setStatus(wf_id,wf_ver,wf_seq_no,psid,pact,ppos,STATUS_AI_ACTIVE);
							}
							Transition t2 = new Transition();
							ResultSet rst2 = t2.getTo(wf_id,wf_ver,psid);
							// should change to set status to return 
							// and to forward change all step that 
							// connect this step and initiate next step incident 
							StepIncident siii = new StepIncident();
							ActorIncident aiiii = new ActorIncident();
							while (t2.nextRecord(rst2)) {
								String sid = t2.getColumn(rst2,FLD_NEXT_STEP_ID);
								//StepIncident siii = new StepIncident();
								siii.setStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
								//ActorIncident aiii = new ActorIncident();
								ResultSet rsaiii = aiii.getActorIncident(wf_id,wf_ver,wf_seq_no,sid);
								while (aii.nextRecord(rsaiii)) {
									String pact = aiii.getColumn(rsaiii,FLD_ACTOR_ID);
									String ppos = aiii.getColumn(rsaiii,FLD_POSITION_CODE);
									//ActorIncident aiiii = new ActorIncident();
									ResultSet rsaiiii = aiiii.getActorIncident(wf_id,wf_ver,wf_seq_no,sid,pact);
									aiiii.nextRecord(rsaiiii);
									if (aiiii.getColumn(rsaiiii,FLD_STATUS).equals(STATUS_AI_ACTIVE)) {
										aiiii.setStatus(wf_id,wf_ver,wf_seq_no,sid,pact,ppos,STATUS_AI_IGNORE);
									}
								}
							}
						}
					} else {
						//StepIncident sii = new StepIncident();
						sii.setStatus(wf_id,wf_ver,wf_seq_no,psid,STATUS_ST_ACTIVE);
						ActorIncident aii = new ActorIncident();
						ResultSet rsaii = aii.getActorIncident(wf_id,wf_ver,wf_seq_no,psid);
						ActorIncident aiii = new ActorIncident();
						while(aii.nextRecord(rsaii)) {
							String pact = aii.getColumn(rsaii,FLD_ACTOR_ID);
							String ppos = aii.getColumn(rsaii,FLD_POSITION_CODE);
							//ActorIncident aiii = new ActorIncident();
							aiii.setStatus(wf_id,wf_ver,wf_seq_no,psid,pact,ppos,STATUS_AI_ACTIVE);
						}
						Transition tttt = new Transition();
						ResultSet rstttt = tttt.getTo(wf_id,wf_ver,psid);
						// should change to set status to return 
						// and to forward change all step that 
						// connect this step and initiate next step incident 
						StepIncident siii = new StepIncident();
						ActorIncident ai11 = new ActorIncident();
						while(tttt.nextRecord(rstttt)) {
							String sid = tttt.getColumn(rstttt,FLD_NEXT_STEP_ID);
							//StepIncident siii = new StepIncident();
							siii.setStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
							ActorIncident ai1 = new ActorIncident();
							ResultSet rsai1 = ai1.getActorIncident(wf_id,wf_ver,wf_seq_no,sid);
							while (ai1.nextRecord(rsai1)) {
								String pact = ai1.getColumn(rsai1,FLD_ACTOR_ID);
								String ppos = ai1.getColumn(rsai1,FLD_POSITION_CODE);
								//ActorIncident ai11 = new ActorIncident();
								ResultSet rsai11 = ai11.getActorIncident(wf_id,wf_ver,wf_seq_no,sid,pact);
								ai11.nextRecord(rsai11);
								if (ai11.getColumn(rsai11,FLD_STATUS).equals(STATUS_AI_ACTIVE)) {
									ai11.setStatus(wf_id,wf_ver,wf_seq_no,sid,pact,ppos,STATUS_AI_IGNORE);
								}
							}
						}
					}
				}
			} else if (n > 1){
				// support many -- one
				Transition tt = new Transition();
				ResultSet rstt = tt.getFrom(wf_id,wf_ver,step_id);
				ActorIncident ai = new ActorIncident();
				StepIncident si = new StepIncident();
				ActorIncident aii = new ActorIncident();
				while (tt.nextRecord(rstt)) {
					String poststep = tt.getColumn(rstt,FLD_STEP_ID);
					//StepIncident si = new StepIncident();
					si.setStatus(wf_id,wf_ver,wf_seq_no,poststep,STATUS_ST_ACTIVE);
					//ActorIncident ai = new ActorIncident();
					ResultSet rsai = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,poststep);
					while (ai.nextRecord(rsai)) {
						String act = ai.getColumn(rsai,FLD_ACTOR_ID);
						String pos = ai.getColumn(rsai,FLD_POSITION_CODE);
						//ActorIncident aii = new ActorIncident();
						aii.setStatus(wf_id,wf_ver,wf_seq_no,poststep,act,pos,STATUS_AI_ACTIVE);
					}
				}
				StepIncident siii = new StepIncident();
				siii.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_IGNORE);
				ActorIncident aiii = new ActorIncident();
				ActorIncident ai1 = new ActorIncident();
				ResultSet rsaiii = aiii.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
				while (aiii.nextRecord(rsaiii)) {
					String pact = aiii.getColumn(rsaiii,FLD_ACTOR_ID);
					String ppos = aiii.getColumn(rsaiii,FLD_POSITION_CODE);
					//ActorIncident ai1 = new ActorIncident();
					ResultSet rsai1 = ai1.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,pact);
					ai1.nextRecord(rsai1);
					if (ai1.getColumn(rsai1,FLD_STATUS).equals(STATUS_AI_ACTIVE)) {
						ai1.setStatus(wf_id,wf_ver,wf_seq_no,step_id,pact,ppos,STATUS_AI_IGNORE);
					}
				}
			} else {
				// in situation no step incident from
			}
			this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_RETURN);
		} 
		else {
			StepIncident si = new StepIncident();
			si.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_IGNORE);
		}
	}
	/*
	// abort
	public void abort(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		//WorkflowDefinition wf = new WorkflowDefinition();
		//rs = wf.getWorkflowDef(wf_id,wf_ver);
		//super.nextRecord(rs);
		//String bu1 = super.getColumn(rs,FLD_ABORT_SCRIPT);
		//boolean bu2 = true;
		//if (!(bu1.equals(null) || bu1.equals("") || bu1.equals(" "))) {
		//	bu2 = Boolean.getBoolean((String)myi.executeScript(bu1));
		//}
		//if (bu2) {
		//	WorkflowIncident wi = new WorkflowIncident();
		//	wi.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_ABORT);
			this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_ABORT);
		//	this.setStatusActorInc(wf_id,wf_ver,wf_seq_no,step_id,actor_id,STATUS_ACT_ABORT);
		//} else {
		//	this.setStatusActorInc(wf_id,wf_ver,wf_seq_no,step_id,actor_id,STATUS_ACT_IGNORE);
		//}
	}
	*/
	/*
	public void ignore(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		//set complete time too
		this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_IGNORE);
	}	
	
	// assign
	public void assign(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		ActorIncident ai = new ActorIncident();
		ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,STATUS_UI_COMPLETE);
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);												
		//p.setProperty(FLD_STEP_SEQ_NO,"0");
		//String element = (String) i.next();
		//
		//QASSIGN
		p.setProperty(FLD_QUEUE_CODE,"QAssign");//.substring(1));
		//p.setProperty(FLD_PRIMARY_POSITION,)
		p.setProperty(FLD_TFR_ACTOR_ID,"");
		p.setProperty(FLD_OWNER_ACTOR_ID,tfr_actor_id);
		p.setProperty(FLD_STATUS,STATUS_UI_ACTIVE);
		p.setProperty(FLD_LAST_UPDATE,datetime);
		p.setProperty(FLD_COMPLETION_TIME,datetime);
		p.setProperty(FLD_COMMENT,"");
		this.createActorIncident(p);
	}		
	// comment incident
	public void comment(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,Properties scrData) {
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		scrData.setProperty(FLD_STATUS,STATUS_UI_COMPLETE);
		scrData.setProperty(FLD_LAST_UPDATE,datetime);
		scrData.setProperty(FLD_COMPLETION_TIME,datetime);
		this.createActorIncident(scrData);
	}
	// tfr_actor_id is group of user that want they to comment your work
	public void commentReq(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		ChartManager cm = new ChartManager("0");
		Collection c = cm.getRefActor(tfr_actor_id);
		Iterator i = c.iterator();
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);	
		p.setProperty(FLD_LAST_UPDATE,datetime);
		p.setProperty(FLD_COMPLETION_TIME,datetime);
		// QCOMMENT	
		p.setProperty(FLD_ACTOR_ID,"QComment");//.substring(1));
		// actor_id = QComment , tfr_actor_id = Commenter , owner_actor_id = Requester
		while (i.hasNext()) {											
			//p.setProperty(FLD_STEP_SEQ_NO,"0");
			String element = (String) i.next();
			//					
			//p.setProperty(FLD_PRIMARY_POSITION,)
			p.setProperty(FLD_TFR_ACTOR_ID,element);
			p.setProperty(FLD_OWNER_ACTOR_ID,actor_id);
			p.setProperty(FLD_STATUS,STATUS_);
			p.setProperty(FLD_COMMENT,"");
			this.createActorIncident(p);
		}
	}
	/*
	// takeover incident
	public void takeover(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
	}
	*/
	/*
	// take incident from system queue or define queue
	public void take(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String owner_actor_id,String tfr_actor_id) {
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);												
		//p.setProperty(FLD_STEP_SEQ_NO,"0");
		//String element = (String) i.next();
		//
		//QASSIGN
		p.setProperty(FLD_ACTOR_ID,actor_id);//.substring(1));
		//p.setProperty(FLD_PRIMARY_POSITION,)
		p.setProperty(FLD_TFR_ACTOR_ID,tfr_actor_id);
		p.setProperty(FLD_OWNER_ACTOR_ID,owner_actor_id);
		p.setProperty(FLD_STATUS,STATUS_UI_COMPLETE);
		p.setProperty(FLD_LAST_UPDATE,datetime);
		p.setProperty(FLD_COMPLETION_TIME,datetime);
		//p.setProperty(FLD_COMMENT,"");
		this.createActorIncident(p);
		p.setProperty(FLD_ACTOR_ID,tfr_actor_id);
		p.setProperty(FLD_TFR_ACTOR_ID,"");
		p.setProperty(FLD_OWNER_ACTOR_ID,"");
		p.setProperty(FLD_STATUS,STATUS_UI_ACTIVE);
		p.setProperty(FLD_COMMENT,"");
		p.setProperty(FLD_LAST_UPDATE,"");
		p.setProperty(FLD_COMPLETION_TIME,"");
		this.createActorIncident(p);
	}
	*/
	
	//return all Workflow Variable that can see in this step
	/*
	public ResultSet getStepVariable(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		wv = new WorkflowVariable();
		wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no);
		return rs;
	}
	*/
	// return specified workflow variable
	/*
	public ResultSet getStepVariable(String wf_id,String wf_ver,String wf_seq_no,String step_id,String var_name) {
		wv = new WorkflowVariable();
		rs = wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no,var_name);
		return rs;
	}
	*/
	public void updateCompleteTime(String wf_id,String wf_ver,String wf_seq_no,String step_id,String dt) {
		super.initMyTable(TBL_STEP_INCIDENT);
		super.set(FLD_COMPLETION_TIME,dt);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.update();
	}

}
