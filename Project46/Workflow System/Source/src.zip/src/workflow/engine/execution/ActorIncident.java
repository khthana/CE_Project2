/*
 * Created on 14 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import util.*;
import workflow.orgchart.ResolveActor;


import java.sql.*;
public class ActorIncident extends Database implements DatabaseField, WorkflowControlData {
	//private StepIncident =new StepIncident();
	//private Properties prop=new Properties();
	//private ResultSet rs;
	//private String SQL="";
	//private ActorIncStatus acts = null;
	
	public ActorIncident() {
		super("workflow");
	}
	public ActorIncident(Properties scrData){
		super("workflow");
		//this.prop=scrData;
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_ACTOR_ID,scrData.getProperty(FLD_ACTOR_ID));
		//super.setFilter(FLD_POSITION_CODE,scrData.getProperty(FLD_POSITION_CODE));
		ResultSet rs = super.search();
		try {
			if (!rs.next()) {
				this.createActorIncident(scrData);
			} else {
				this.updateActorIncident(scrData);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createActorIncident(Properties scrData) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		//super.set(FLD_STEP_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_STEP_SEQ_NO)));
		super.set(FLD_ACTOR_ID,scrData.getProperty(FLD_ACTOR_ID));
		//super.set(FLD_POSITION_CODE,scrData.getProperty(FLD_POSITION_CODE));
		//super.set(FLD_ACTOR_PRIMARY_POSITION,Long.parseLong(FLD_ACTOR_PRIMARY_POSITION));
		//super.set(FLD_TFR_ACTOR_ID,Integer.parseInt(scrData.getProperty(FLD_TFR_ACTOR_ID)));
		//super.set(FLD_OWNER_ACTOR_ID,Integer.parseInt(scrData.getProperty(FLD_OWNER_ACTOR_ID)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		
		super.insert();
	}
	private void updateActorIncident(Properties scrData) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		//super.set(FLD_STEP_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_STEP_SEQ_NO)));
		super.set(FLD_ACTOR_ID,scrData.getProperty(FLD_ACTOR_ID));
		//super.set(FLD_POSITION_CODE,scrData.getProperty(FLD_POSITION_CODE));
		//super.set(FLD_ACTOR_PRIMARY_POSITION,Long.parseLong(FLD_ACTOR_PRIMARY_POSITION));
		//super.set(FLD_TFR_ACTOR_ID,Integer.parseInt(scrData.getProperty(FLD_TFR_ACTOR_ID)));
		//super.set(FLD_OWNER_ACTOR_ID,Integer.parseInt(scrData.getProperty(FLD_OWNER_ACTOR_ID)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_ACTOR_ID,scrData.getProperty(FLD_ACTOR_ID));
		//super.setFilter(FLD_POSITION_CODE,scrData.getProperty(FLD_POSITION_CODE));
		
		super.update();
	}
	
	// get in status of
	public int getActorIncStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String status) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_STATUS,Integer.parseInt(status));
		super.setColumn("count(*)");
		ResultSet rs = super.search();
		super.nextRecord(rs);
		int res = Integer.parseInt(super.getColumn(rs,1));
		return res;
	}
	
	// DbInquiry return multiple row of result
	public ResultSet getActorIncident(String actor_id){
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_ACTOR_ID,actor_id);
		return super.search();
		//SQL="select * from "+TBL_ACTOR_INCIDENT+" where actor_id="+actor_id+" and "+FLD_STATUS+"=1";
		//rs=super.executeQuery(SQL);
	}
	public ResultSet getActorIncident(String actor_id,String position_code) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_ACTOR_ID,actor_id);
		super.setFilter(FLD_POSITION_CODE,position_code);
		return super.search();
		//SQL="select * from "+TBL_ACTOR_INCIDENT+" where actor_id="+actor_id+" and "+FLD_STATUS+"=1";
		//rs=super.executeQuery(SQL);
	}
	/*
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,actor_id);
		super.setFilter(FLD_POSITION_CODE,position_code);
		rs = super.search();
		return rs;
	}
	*/
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,actor_id);
		return super.search();
	}
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setOrder(FLD_START_TIME);
		return super.search();
	}
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setOrder(FLD_STEP_ID);
		return super.search();
	}
	/*
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String user_code,String status) {
		super.initMyTable(TBL_USER_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_STATUS,Integer.parseInt(status));
		rs = super.search();
		return rs;
	}
	*/
	
	public void setStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String status) {
		String datetime = MyCalendar.getDataTime();

		super.initMyTable(TBL_ACTOR_INCIDENT);
		
		super.set(FLD_STATUS,Integer.parseInt(status));
		super.set(FLD_COMPLETION_TIME,datetime);
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,actor_id);
		//super.setFilter(FLD_POSITION_CODE,position_code);
		super.update();
	}
	//public void abort(String wf_id,String wf_ver,String wf_seq_no,String step_id,String user_code) {
	//	this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,user_code,STATUS_UI_ABORT);
	//}
	/*
	// move to next
	public void next(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String event) {
	}
	// return to previous step
	public void previous(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {
	}
	// abort
	public void abort(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {
	}
	*/
	// assign
	public void assign(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String tfr_actor_id) {
		//Calendar ca = Calendar.getInstance();
		String datetime = MyCalendar.getDataTime();//ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543);
		//datetime += " ";
		//datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
		
		//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,actor_id,datetime);
		this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,STATUS_AI_ASSIGN);
		
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);	
		p.setProperty(FLD_QUEUE_CODE,QASSIGN);
		p.setProperty(FLD_TFR_ACTOR_ID,tfr_actor_id);
		p.setProperty(FLD_OWNER_ACTOR_ID,actor_id);
		p.setProperty(FLD_STATUS,STATUS_QT_ACTIVE);
		p.setProperty(FLD_START_TIME,datetime);
		p.setProperty(FLD_COMPLETION_TIME,"01/01/2000");
		QueueTransfer qt = new QueueTransfer(p);
	}
	
	// comment incident
	public void comment(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String comment) {
		//Calendar ca = Calendar.getInstance();
		String datetime = MyCalendar.getDataTime();//ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543);
		//datetime += " ";
		//datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
		
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.set(FLD_COMMENT,comment);
		super.set(FLD_STATUS,STATUS_AI_APPROVE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,actor_id);
		super.setFilter(FLD_POSITION_CODE,position_code);
		super.update();
		
		QueueTransfer qt = new QueueTransfer();
		ResultSet rs = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,step_id,QCOMMENT);
		while(super.nextRecord(rs)) {
			String status = super.getColumn(rs,FLD_STATUS);
			if (status.equals(STATUS_QT_ACTIVE)) {
				boolean a = false;
				String chktfr = super.getColumn(rs,FLD_TFR_ACTOR_ID);
				String chkown = super.getColumn(rs,FLD_OWNER_ACTOR_ID);
				if (chktfr.equals(actor_id) || chkown.equals(actor_id)) {
					qt.setStatus(wf_id,wf_ver,wf_seq_no,step_id,QCOMMENT,actor_id,chkown,STATUS_QT_COMMENT_COMPLETE);
					a = true;
				}
				if (a) {
					break;
				}
			}
		}		
	}
	
	// tfr_actor_id is group of user that want they to comment your work
	public void commentReq(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String tfr_actor_id) {
		//Calendar ca = Calendar.getInstance();
		String datetime = MyCalendar.getDataTime();//ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543);
		//datetime += " ";
		//datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);

		ResolveActor ra = new ResolveActor();
		QueueTransfer qt = null;
		Vector vt = (Vector) ra.getRefActor(tfr_actor_id);
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);
		p.setProperty(FLD_QUEUE_CODE,QCOMMENT);
		p.setProperty(FLD_OWNER_ACTOR_ID,actor_id);
		p.setProperty(FLD_START_TIME,datetime);
		p.setProperty(FLD_COMPLETION_TIME,"");
		p.setProperty(FLD_STATUS,STATUS_QT_ACTIVE);
		Iterator i = vt.iterator();
		String tfr = "";
		while (i.hasNext()) {
			tfr = (String) i.next();
			p.setProperty(FLD_TFR_ACTOR_ID,tfr);
			qt = new QueueTransfer(p);
			qt.take(wf_id,wf_ver,wf_seq_no,step_id,QCOMMENT,tfr,position_code);
		}
	}
	/*
	// takeover incident
	public void takeover(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
	}
	// take incident from system queue or define queue
	public void take(String wf_id,String wf_ver,String wf_seq_no,String step_id,String owner_actor_id,String tfr_actor_id) {
	}
	*/
	public void updateCompleteTime(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String dt) {
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.set(FLD_COMPLETION_TIME,dt);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,actor_id);
		//super.setFilter(FLD_POSITION_CODE,position_code);
		super.update();
	}
	public void setOpinion(String wf_id,String wf_ver,String wf_seq_no,String step_id,String user_code,String position_code,String comment) {
		String datetime = MyCalendar.getDataTime();
		super.initMyTable(TBL_ACTOR_INCIDENT);
		super.set(FLD_COMPLETION_TIME,datetime);
		super.set(FLD_COMMENT,comment);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_ACTOR_ID,user_code);
		//super.setFilter(FLD_POSITION_CODE,position_code);
		super.update();
	}
}