/*
 * Created on 15 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

//import java.sql.ResultSet;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
import workflow.engine.definition.WfVarDef;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WorkflowVariable extends Database implements DatabaseField {
	//private ResultSet rs = null;
	//private Properties wvprop = null;
	
	public WorkflowVariable() {
		super("workflow");
	}
	public WorkflowVariable(Properties scrData) {
		super("workflow");
		//this.wvprop = scrData;
		super.initMyTable(TBL_WORKFLOW_VARIABLE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		ResultSet rs = super.search();
		try {
			if (!rs.next()) {
				this.createWorkflowVariable(scrData);
			} else {
				this.updateWorkflowVariable(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createWorkflowVariable(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_VARIABLE);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_VAR_VALUE,scrData.getProperty(FLD_VAR_VALUE));
		//super.set(FLD_CHG_HISTORY,scrData.getProperty(FLD_CHG_HISTORY));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		
		super.insert();
	}
	private void updateWorkflowVariable(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_VARIABLE);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_VAR_VALUE,scrData.getProperty(FLD_VAR_VALUE));
		//super.set(FLD_CHG_HISTORY,scrData.getProperty(FLD_CHG_HISTORY));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		
		super.update();
	}
	
	public ResultSet getWorkflowVariable(String wf_id,String wf_ver,String wf_seq_no) {
		super.initMyTable(TBL_WORKFLOW_VARIABLE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		return super.search();
	}
	public ResultSet getWorkflowVariable(String wf_id,String wf_ver,String wf_seq_no,String var_name) {
		super.initMyTable(TBL_WORKFLOW_VARIABLE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_VAR_NAME,var_name);
		return super.search();
	}
	
	//DbRecord
	// Check type of Value
	public String getValue(String wf_id,String wf_ver,String wf_seq_no,String var_name){
		ResultSet rs = this.getWorkflowVariable(wf_id,wf_ver,wf_seq_no,var_name);
		String res = "";
		try {
			rs.next();
			res = rs.getString(FLD_VAR_VALUE);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public void setValue(String wf_id,String wf_ver,String wf_seq_no,String var_name,String var_value) {
		/*
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
		*/
		super.initMyTable(TBL_WORKFLOW_VARIABLE);

		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_VAR_NAME,var_name);
		//rs = super.search();
		//super.set(FLD_LAST_UPDATE,datetime);
		super.set(FLD_VAR_VALUE,var_value);
		super.update();
	}
	
	public ResultSet getDefinition(String wf_id,String wf_ver,String var_name) {
		WfVarDef wvd = new WfVarDef();
		return wvd.getWfVarDef(wf_id,wf_ver,var_name);
	}
}