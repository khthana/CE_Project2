/*
 * Created on 2 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

import java.sql.*;

import java.util.Properties;

import util.Database;
import util.DatabaseField;
import util.MyCalendar;
import util.WorkflowControlData;
import workflow.engine.definition.WorkflowDefinition;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class WfIncMgmt implements WorkflowControlData, DatabaseField{
	//WorkflowIncident wi = null;
	//ActorIncident ai = null;
	//QueueTransfer qt = null;
	//private ResultSet rs;
	
	public WfIncMgmt(){
	}	
	public ResultSet getWfInc() {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getWfInc();
	}
	public ResultSet getWfInc(String wf_id,String wf_ver) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getWfInc(wf_id,wf_ver);
	}
	public ResultSet getWfInc(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getWfInc(wf_id,wf_ver,wf_seq_no);
	}
	public ResultSet getStepInc(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getStepIncident(wf_id,wf_ver,wf_seq_no);
	}
	public ResultSet getStepInc(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getStepIncident(wf_id,wf_ver,wf_seq_no,step_id);
	}
	public ResultSet getWfVariable(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getWorkflowVariables(wf_id,wf_ver,wf_seq_no); 
	}
	public ResultSet getWfVariable(String wf_id,String wf_ver,String wf_seq_no,String var_name) {
		WorkflowIncident wi = new WorkflowIncident();
		return wi.getWorkflowVariables(wf_id,wf_ver,wf_seq_no,var_name); 
	}
	public void createWfInc(String wf_id,String wf_ver) {
		//String wf_id = scrData.getProperty(FLD_WF_ID);
		//String wf_ver = scrData.getProperty(FLD_WF_VER);
		String datetime = MyCalendar.getDataTime();
		String wf_seq_no = "";//scrData.getProperty(FLD_WF_SEQ_NO);
		WorkflowDefinition wd = new WorkflowDefinition();
		ResultSet rs = wd.getWorkflowDef(wf_id,wf_ver);
		long seq = 0;
		wd.nextRecord(rs);
		seq = Long.parseLong(wd.getColumn(rs,FLD_LAST_SEQ));
		seq++;
		String prio = wd.getColumn(rs,FLD_PRIORITY);
		String diff = wd.getColumn(rs,FLD_DIFFICULT_LEVEL);
		wd.initMyTable(TBL_WORKFLOW_DEFINITION);
		wd.set(FLD_LAST_SEQ,seq);
		wd.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		wd.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		wd.update();
		wf_seq_no = String.valueOf(seq);
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_SUBJECT,"");
		p.setProperty(FLD_PRIORITY,prio);
		p.setProperty(FLD_START_TIME,datetime);
		System.out.println(p.getProperty(FLD_START_TIME));
		p.setProperty(FLD_COMPLETION_TIME,"2004-01-01");
		p.setProperty(FLD_EXTENSION_TIME,"2004-01-01");
		p.setProperty(FLD_STATUS,STATUS_WF_CREATED_NOT_COMPLETE);
		p.setProperty(FLD_COMMENT,"");
		p.setProperty(FLD_DIFFICULT_LEVEL,diff);
		p.setProperty(FLD_INITIATOR,"");
		WorkflowIncident wi = new WorkflowIncident(p);
		//wd.createWorkflowIncident(scrData);
	}
	public void startwfInc(Properties scrData) {
		String datetime = MyCalendar.getDataTime();
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		scrData.setProperty(FLD_STATUS,STATUS_WF_ACTIVE);
		scrData.setProperty(FLD_START_TIME,datetime);
		WorkflowIncident wi = new WorkflowIncident(scrData);
		//wi.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_ACTIVE);
		scrData.setProperty(FLD_STEP_ID,"1");
		scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_ST_COMPLETE);
		wi.createStepIncident(scrData);
		
		WorkflowDefinition wd = new WorkflowDefinition();
		ResultSet rs = wd.getWfVarDef(wf_id,wf_ver);
		while(wd.nextRecord(rs)) {
			String var_name = wd.getColumn(rs,FLD_VAR_NAME);
			if (scrData.getProperty(var_name) != null) {
				scrData.setProperty(FLD_VAR_VALUE,scrData.getProperty(var_name));
				scrData.setProperty(FLD_VAR_NAME,var_name);
				wi.createWorkflowVariable(scrData);
			}
		}
		
		scrData.setProperty(FLD_STEP_ID,"1");
		String actor_id = scrData.getProperty(FLD_INITIATOR);
		
		Database db = new Database("workflow");
		db.initMyTable(TBL_POSITION_USER);
		db.setFilter(FLD_USER_CODE,actor_id);
		rs = db.search();
		db.nextRecord(rs);
		String position_code = db.getColumn(rs,FLD_POSITION_CODE);
		
		scrData.setProperty(FLD_ACTOR_ID,actor_id);
		scrData.setProperty(FLD_STATUS,STATUS_AI_ACTIVE);
		scrData.setProperty(FLD_START_TIME,MyCalendar.getDataTime());
		scrData.setProperty(FLD_COMPLETION_TIME,MyCalendar.getDataTime());
		scrData.setProperty(FLD_COMMENT,"");
		ActorIncident ai = new ActorIncident(scrData);
		scrData.setProperty(FLD_STEP_ID,"1");
		scrData.setProperty(FLD_USER_CODE,scrData.getProperty(FLD_INITIATOR));
		scrData.setProperty(FLD_POSITION_CODE,position_code);
		this.approveAction(scrData);
	}
	public void createStepInc(Properties scrData) {
		WorkflowDefinition wd = new WorkflowDefinition();
		wd.createStepIncident(scrData);
	}
	public void setWfStatus(String wf_id,String wf_ver,String wf_seq_no,String status) {
		WorkflowIncident wi = new WorkflowIncident();
		wi.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,status);
	}
	public void setStepStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String status) {
		WorkflowIncident wi = new WorkflowIncident();
		wi.setStepStatus(wf_id,wf_ver,wf_seq_no,step_id,status);
	}
	
	
	public void approveAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		String comment = scrData.getProperty(FLD_COMMENT);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,STATUS_AI_APPROVE);
			ai.setOpinion(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,comment);
			this.next(wf_id,wf_ver,wf_seq_no,step_id,EVENT_APPROVE,actor_id,position_code,scrData);
		}
	}
	public void disapproveAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		String comment = scrData.getProperty(FLD_COMMENT);		
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,STATUS_AI_DISAPPROVE);
			ai.setOpinion(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,comment);
			this.next(wf_id,wf_ver,wf_seq_no,step_id,EVENT_DISAPPROVE,actor_id,position_code,scrData);
		}
	}
	private void next(String wf_id,String wf_ver,String wf_seq_no,String step_id,String event,String user_code,String position_code,Properties scrData) {
		WorkflowIncident wi = new WorkflowIncident();
		wi.updateVariable(scrData);
		wi.next(wf_id,wf_ver,wf_seq_no,step_id,event,user_code,position_code);
	}
	
	
	public void returnAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		ActorIncident ai = new ActorIncident();
		WorkflowIncident wi = new WorkflowIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,STATUS_AI_RETURN);
			//wi = new WorkflowIncident();
			wi.returns(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code);
		}
	}
	public void abortAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		ActorIncident ai = new ActorIncident();
		WorkflowIncident wi = new WorkflowIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,STATUS_AI_ABORT);
			wi = new WorkflowIncident();
			wi.abort(wf_id,wf_ver,wf_seq_no,step_id);
		}
	}
	public void assignAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		String tfr_actor_id = scrData.getProperty(FLD_TFR_ACTOR_ID);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.assign(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,tfr_actor_id);
		}
		//wi = new WorkflowIncident();
		//wi.assign(wf_id,wf_ver,wf_seq_no,step_id,user_code,tfr_user_code);
	}
	public void commentAction(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String comment) {
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.comment(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,comment);
		}
		//wi = new WorkflowIncident();
		//wi.comment(wf_id,wf_ver,wf_seq_no,step_id,actor_id,scrData);
	}
	public void commentReqAction(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code,String tfr_actor_id) {
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		ai.nextRecord(rs);
		String sta = ai.getColumn(rs,"status");
		if (sta.equals(STATUS_AI_ACTIVE)) {
			ai.commentReq(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code,tfr_actor_id);
		}
		//wi = new WorkflowIncident();
		//wi.commentReq(wf_id,wf_ver,wf_seq_no,step_id,actor_id,tfr_actor_id);
	}
	public void takeAction(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String queue_code = scrData.getProperty(FLD_QUEUE_CODE);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		String tfr_actor_id = scrData.getProperty(FLD_USER_CODE);
		QueueTransfer qt = new QueueTransfer();
		ResultSet rs = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,step_id,queue_code);
		if (queue_code.equals(QASSIGN)) {
			while (qt.nextRecord(rs)) {
				String sta = qt.getColumn(rs,"status");
				if (sta.equals(STATUS_QT_ACTIVE)) {
					qt.take(wf_id,wf_ver,wf_seq_no,step_id,queue_code,tfr_actor_id,position_code);
				}
			}
		} else {
			if (qt.nextRecord(rs)) {
				String sta = qt.getColumn(rs,"status");
				if (sta.equals(STATUS_QT_ACTIVE)) {
					qt.take(wf_id,wf_ver,wf_seq_no,step_id,queue_code,tfr_actor_id,position_code);
				}
			}
		}
		//wi = new WorkflowIncident();
		//wi.take(wf_id,wf_ver,wf_seq_no,step_id,actor_id,owner_actor_id,tfr_actor_id);
	}
	
	/*
	// takeover incident
	public void takeoverAction(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
	}
	*/
	
	/*
	public void returnAction(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {
	}
	public void assignAction() {
	}
	public void abortAction() {
	}
	public void commentAction() {
	}
	public void commentReqAction() {
	}
	*/
}
