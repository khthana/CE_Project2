/*
 * Created on 17 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

import java.sql.ResultSet;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
import util.MyCalendar;
import util.WorkflowControlData;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class QueueTransfer extends Database implements DatabaseField, WorkflowControlData{
	//private Properties qiProp = null;
	//private ResultSet rs = null;
	
	public QueueTransfer() {
		super("workflow");
	}
	public QueueTransfer(Properties scrData) {
		super("workflow");
		//qiProp = scrData;
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_QUEUE_CODE,scrData.getProperty(FLD_QUEUE_CODE));
		super.setFilter(FLD_TFR_ACTOR_ID,scrData.getProperty(FLD_TFR_ACTOR_ID));
		super.setFilter(FLD_OWNER_ACTOR_ID,scrData.getProperty(FLD_OWNER_ACTOR_ID));
		ResultSet rs = super.search();
		if (!super.nextRecord(rs)) {
			this.createQueueTransfer(scrData);
		} else {
			this.updateQueueTransfer(scrData);
			//System.out.println(this.getColumn(rs,FLD_WF_ID));
			//System.out.println(this.getColumn(rs,FLD_WF_VER));
			//System.out.println(this.getColumn(rs,FLD_WF_SEQ_NO));
			//System.out.println(this.getColumn(rs,FLD_STEP_ID));
			//System.out.println(this.getColumn(rs,FLD_QUEUE_CODE));
		}
	}
	
	private void createQueueTransfer(Properties scrData) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_QUEUE_CODE,scrData.getProperty(FLD_QUEUE_CODE));
		super.set(FLD_TFR_ACTOR_ID,scrData.getProperty(FLD_TFR_ACTOR_ID));
		super.set(FLD_OWNER_ACTOR_ID,scrData.getProperty(FLD_OWNER_ACTOR_ID));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.insert();
	}
	private void updateQueueTransfer(Properties scrData) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_QUEUE_CODE,scrData.getProperty(FLD_QUEUE_CODE));
		super.set(FLD_TFR_ACTOR_ID,scrData.getProperty(FLD_TFR_ACTOR_ID));
		super.set(FLD_OWNER_ACTOR_ID,scrData.getProperty(FLD_OWNER_ACTOR_ID));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_QUEUE_CODE,scrData.getProperty(FLD_QUEUE_CODE));
		super.update();
	}
	
	// rest   add a method of tfr_actor_id too
	public ResultSet getQueueTransfer(String wf_id,String wf_ver,String wf_seq_no,String step_id,String queue_code,String actor_id) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,queue_code);
		super.setFilter(FLD_OWNER_ACTOR_ID,actor_id);
		return super.search();
	}
	public ResultSet getQueueTransfer(String wf_id,String wf_ver,String wf_seq_no,String step_id,String queue_code) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,queue_code);
		return super.search();
	}
	public ResultSet getQueueTransfer(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		return super.search();
	}
	public ResultSet getQueueTransfer(String wf_id,String wf_ver,String wf_seq_no) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		return super.search();
	}
	
	public void setStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String queue_code,String tfr_actor_id,String owner_actor_id,String status) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		
		super.set(FLD_STATUS,Integer.parseInt(status));
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,queue_code);	
		super.setFilter(FLD_TFR_ACTOR_ID,tfr_actor_id);
		super.setFilter(FLD_OWNER_ACTOR_ID,owner_actor_id);
		super.update();
	}
	public void updateCompleteTime(String wf_id,String wf_ver,String wf_seq_no,String step_id,String queue_code,String tfr_actor_id,String owner_actor_id,String dt) {
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.set(FLD_COMPLETION_TIME,dt);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,queue_code);
		super.setFilter(FLD_TFR_ACTOR_ID,tfr_actor_id);
		super.setFilter(FLD_OWNER_ACTOR_ID,owner_actor_id);
		super.update();
	}

	public void take(String wf_id,String wf_ver,String wf_seq_no,String step_id,String queue_code,String tfr_actor_id,String position_code) {
		//Calendar ca = Calendar.getInstance();
		String datetime = MyCalendar.getDataTime();//ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543);
		//datetime += " ";
		//datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
		
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,queue_code);
		//super.setFilter(FLD_TFR_ACTOR_ID,tfr_actor_id);
		super.setFilter(FLD_STATUS,STATUS_QT_ACTIVE);
		ResultSet rs = super.search();
	
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		p.setProperty(FLD_STEP_ID,step_id);
		p.setProperty(FLD_START_TIME,datetime);
		p.setProperty(FLD_COMPLETION_TIME,"");
		p.setProperty(FLD_STATUS,STATUS_AI_ACTIVE);
		p.setProperty(FLD_COMMENT,"");
		p.setProperty(FLD_ACTOR_ID,tfr_actor_id);
		p.setProperty(FLD_POSITION_CODE,position_code);
		ActorIncident ai = new ActorIncident();
		
		Database db = new Database("workflow");
		while(super.nextRecord(rs)) {
			db.initMyTable(TBL_QUEUE_TRANSFER);
			db.setFilter(FLD_WF_ID,wf_id);
			db.setFilter(FLD_WF_VER,wf_ver);
			db.setFilter(FLD_WF_SEQ_NO,wf_seq_no);
			db.setFilter(FLD_STEP_ID,step_id);
			db.setFilter(FLD_QUEUE_CODE,queue_code);
			
			String chktfr = super.getColumn(rs,FLD_TFR_ACTOR_ID);
			String chkown = super.getColumn(rs,FLD_OWNER_ACTOR_ID);
			String status = "";
			
			if (queue_code.equals(QASSIGN)) {
				if (chktfr.equals(tfr_actor_id)) {
					status = STATUS_QT_ASSIGN_COMPLETE;
					ai = new ActorIncident(p);
					db.setFilter(FLD_OWNER_ACTOR_ID,chkown);
					db.setFilter(FLD_TFR_ACTOR_ID,tfr_actor_id);
					db.set(FLD_STATUS,STATUS_QT_COMPLETE);
					db.set(FLD_COMPLETION_TIME,datetime);
					db.update();
					//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,datetime);
					//this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,status);
				} else if (chkown.equals(tfr_actor_id)) {
					status = STATUS_QT_ASSIGN_NOTCOMPLETE;
					ai = new ActorIncident();
					ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,tfr_actor_id,position_code,STATUS_AI_ACTIVE);
					db.setFilter(FLD_OWNER_ACTOR_ID,tfr_actor_id);
					db.setFilter(FLD_TFR_ACTOR_ID,chktfr);
					db.set(FLD_STATUS,STATUS_QT_NOTCOMPLETE);
					db.set(FLD_COMPLETION_TIME,datetime);
					db.update();
					//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,datetime);
					//this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,status);
				}
				//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,datetime);
				//this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,status);
			} else if (queue_code.equals(QCOMMENT)) {
				if (chktfr.equals(tfr_actor_id) || chkown.equals(tfr_actor_id)) {
					ai = new ActorIncident(p);
				}
			} else {
				//if (chktfr.equals(tfr_actor_id) || chkown.equals(tfr_actor_id)) {
					ai = new ActorIncident(p);
					db.setFilter(FLD_OWNER_ACTOR_ID,ACTOR_ENGINE);
					db.set(FLD_TFR_ACTOR_ID,tfr_actor_id);
					db.set(FLD_STATUS,STATUS_QT_COMPLETE);
					db.set(FLD_COMPLETION_TIME,datetime);
					db.update();
					//this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,queue_code,tfr_actor_id,chkown,STATUS_QT_COMPLETE);
					//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,queue_code,chktfr,chkown,datetime);
				//}
			}
		}
				
		//this.setStatus(wf_id,wf_ver,wf_seq_no,step_id,qc,status);
		//this.updateCompleteTime(wf_id,wf_ver,wf_seq_no,step_id,queue_code,datetime);
		//ActorIncident ai = new ActorIncident();
		//ai.setStatus(wf_id,wf_ver,wf_seq_no,step_id,tfr_actor_id,position_code,STATUS_AI_ACTIVE);
	}
	/*
	public void comment(String wf_id,String wf_ver,String wf_seq_no,String step_id,String user_code,String comment) {
		Calendar ca = Calendar.getInstance();
		String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+ca.get(1);
		datetime += " ";
		datetime += ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
		
		super.initMyTable(TBL_QUEUE_TRANSFER);
		super.set(FLD_COMMENT,comment);
		super.set(FLD_COMPLETION_TIME,datetime);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_QUEUE_CODE,QUEUE_COMMENT);
		super.setFilter(FLD_TFR_USER_CODE,user_code);
		super.update();
	}
	*/
}
