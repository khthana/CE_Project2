/*
 * Created on 24 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

import java.sql.ResultSet;
import java.util.Properties;

import util.Database;
import util.DatabaseField;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AttachFile extends Database implements DatabaseField{
	private String file_name="";
	public AttachFile(){
		super("workflow");
	}
	public AttachFile(Properties scrData){
		super("workflow");
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_FILE_SEQ_NO,Integer.parseInt(scrData.getProperty(FLD_FILE_SEQ_NO)));
		ResultSet rs=super.search();
		try{
			if( rs.next() ){
				updateFile(scrData);
			}else{
				addFile(scrData);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public ResultSet getFileList(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		super.initMyTable(TBL_ATTATCHED_FILE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Integer.parseInt(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setOrder(FLD_FILE_SEQ_NO);
		return super.search();	
	}// passed
	public void addFile(Properties scrData){
		super.initMyTable(TBL_ATTATCHED_FILE);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Integer.parseInt(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_FILE_NAME,scrData.getProperty(FLD_FILE_NAME));
		super.set(FLD_FILE_TYPE,scrData.getProperty(FLD_FILE_TYPE));
		super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.set(FLD_LAST_UPDATE,"1981-12-17 08:08:08");
		super.insert();
	}// passs
	public void delFile(String wf_id,String wf_ver,String wf_seq_no,String step_id,String file_seq_no){
		super.initMyTable(TBL_ATTATCHED_FILE);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Integer.parseInt(wf_seq_no));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_FILE_SEQ_NO,Integer.parseInt(file_seq_no));
		super.delete();
	}// pass
	public void updateFile(Properties scrData){
		super.initMyTable(TBL_ATTATCHED_FILE);
		super.set(FLD_FILE_NAME,scrData.getProperty(FLD_FILE_NAME));
		super.set(FLD_FILE_TYPE,scrData.getProperty(FLD_FILE_TYPE));
		super.set(FLD_LAST_UPDATE,"1981-12-17 08:08:08");
		super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Integer.parseInt(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_FILE_SEQ_NO,scrData.getProperty(FLD_FILE_SEQ_NO));
		super.update();
	}// passsed
	public void updateBySeqNo(Properties scrData){
		super.initMyTable(TBL_ATTATCHED_FILE);
		super.setFilter(FLD_FILE_SEQ_NO,scrData.getProperty(FLD_FILE_SEQ_NO));
		System.out.println(scrData.getProperty(FLD_FILE_SEQ_NO));
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		System.out.println(scrData.getProperty(FLD_WF_ID));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		System.out.println(scrData.getProperty(FLD_WF_VER));
		super.set(FLD_WF_SEQ_NO,Integer.parseInt(scrData.getProperty(FLD_WF_SEQ_NO)));
		System.out.println(scrData.getProperty(FLD_WF_SEQ_NO));System.out.println(scrData.getProperty(FLD_FILE_SEQ_NO));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		System.out.println(scrData.getProperty(FLD_STEP_ID));
		super.set(FLD_FILE_DESC,scrData.getProperty(FLD_FILE_DESC));
		System.out.println(scrData.getProperty(FLD_FILE_DESC));
		super.set(FLD_LAST_UPDATE,"1981-10-17 08:08:08");
		super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.update();
	}
}