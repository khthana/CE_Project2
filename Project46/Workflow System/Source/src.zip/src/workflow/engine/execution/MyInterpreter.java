/*
 * Created on 30 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;

import util.DatabaseField;
import util.WorkflowControlData;
import workflow.engine.definition.StepDefinition;
import workflow.engine.definition.WfVarDef;
import workflow.engine.definition.WorkflowDefinition;
import bsh.EvalError;
import bsh.Interpreter;


public class MyInterpreter extends Interpreter implements DatabaseField, WorkflowControlData {
	
	//ResultSet rs = null;
	//WorkflowDefinition wf = null;
	//WfVarDef wfvardef = null;
	//StepDefinition st = null;
	//WorkflowIncident wi = null;
	//WorkflowVariable wv = null;
	//StepIncident si = null;
	
	public MyInterpreter(String wf_id,String wf_ver,String step_id) {
		//this.setEnvironmentWorkflowDefinition(wf_id,wf_ver);
		//this.setEnvironmentStepDefinition(wf_id,wf_ver,step_id);
	}

	public MyInterpreter(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		//this.setEnvironmentWorkflowDefinition(wf_id,wf_ver);
		//this.setEnvironmentStepDefinition(wf_id,wf_ver,step_id);
		//this.setEnvironmentWorkflowIncident(wf_id,wf_ver,wf_seq_no);
		this.setEnvironmentVariable(wf_id,wf_ver,wf_seq_no);
		//this.setEnvironmentStepIncident(wf_id,wf_ver,wf_seq_no,step_id);
		this.setEnvironmentEvent(wf_id,wf_ver,wf_seq_no,step_id);
	}

	private void setEnvironmentVariable(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		ResultSet rs = wi.getWorkflowVariables(wf_id,wf_ver,wf_seq_no);
		WfVarDef wfvardef = new WfVarDef();
		while (wi.nextRecord(rs)) {
			String var_name = wi.getColumn(rs,FLD_VAR_NAME);
			String var_value = wi.getColumn(rs,FLD_VAR_VALUE);
			ResultSet rs2 = wfvardef.getWfVarDef(wf_id,wf_ver,var_name);
			wfvardef.nextRecord(rs2);
			String var_type = wfvardef.getColumn(rs2,FLD_VAR_TYPE);
			if (var_type.equals(NUMBER)) {
				this.set(var_name,Double.parseDouble(var_value));
			} else if (var_type.equals(TEXT)) {
				this.set(var_name,var_value);
			} else if (var_type.equals(DATE_TIME)) {
				this.set(var_name,var_value);
			}
		}
	}
	private void setEnvironmentWorkflowDefinition(String wf_id,String wf_ver) {
		WorkflowDefinition wf = new WorkflowDefinition();
		ResultSet rs = wf.getWorkflowDef(wf_id,wf_ver);
		wf.nextRecord(rs);
		this.set("wf_id",Integer.parseInt(wf_id));
		this.set("wf_ver",Integer.parseInt(wf_ver));
		this.set("wf.start_time",wf.getColumn(rs,FLD_START_TIME));
		this.set("wf.end_time",wf.getColumn(rs,FLD_END_TIME));
		this.set("wf.priority",Integer.parseInt(wf.getColumn(rs,FLD_PRIORITY)));
		this.set("wf.completion_duration",Long.parseLong(wf.getColumn(rs,FLD_COMPLETION_DURATION)));
		this.set("wf.extension_duration",Long.parseLong(wf.getColumn(rs,FLD_EXTENSION_DURATION)));
		boolean a = false;
		if (wf.getColumn(rs,FLD_TAKEOVER_RIGHT).equals("1")) {
			a = true;
		}
		this.set("wf.takeover_right",a);
		this.set("wf.difficult_level",Integer.parseInt(wf.getColumn(rs,FLD_DIFFICULT_LEVEL)));
		this.set("wf.last_seq",Long.parseLong(wf.getColumn(rs,FLD_LAST_SEQ)));
		a = false;
		if (wf.getColumn(rs,FLD_CURRENT_USE).equals("1")) {
			a = true;
		}
		this.set("wf.current_use",a);
	}
	public void setEnvironmentStepDefinition(String wf_id,String wf_ver,String step_id) {
		StepDefinition st = new StepDefinition();
		ResultSet rs = st.getStepDef(wf_id,wf_ver,step_id);
		st.nextRecord(rs);
		this.set("step_id",Integer.parseInt(step_id));
		this.set("st.task_rate",Double.parseDouble(st.getColumn(rs,FLD_TASK_RATE)));
		boolean a = false;
		if (st.getColumn(rs,FLD_ATTACHED_STATUS).equals("1")) {
			a = true;
		}
		this.set("st.attached_status",a);
		this.set("st.completion_duration",Long.parseLong(st.getColumn(rs,FLD_COMPLETION_DURATION)));
		this.set("st.extension_duration",Long.parseLong(st.getColumn(rs,FLD_EXTENSION_DURATION)));
		this.set("st.delay_duration",Long.parseLong(st.getColumn(rs,FLD_DELAY_DURATION)));
	}
	public void setEnvironmentWorkflowIncident(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		ResultSet rs = wi.getWfInc(wf_id,wf_ver,wf_seq_no);
		wi.nextRecord(rs);
		this.set("wf_seq_no",Long.parseLong(wf_seq_no));
		this.set("wi.priority",Integer.parseInt(wi.getColumn(rs,FLD_PRIORITY)));
		this.set("wi.start_time",wi.getColumn(rs,FLD_START_TIME));
		this.set("wi.completion_time",wi.getColumn(rs,FLD_COMPLETION_TIME));
		this.set("wi.extension_time",wi.getColumn(rs,FLD_EXTENSION_TIME));
		this.set("wi.difficult_level",Integer.parseInt(wi.getColumn(rs,FLD_DIFFICULT_LEVEL)));
	}
	public void setEnvironmentStepIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		StepIncident si = new StepIncident();
		ResultSet rs = si.getStepIncident(wf_id,wf_ver,wf_seq_no,step_id);
		si.nextRecord(rs);
		this.set("si.start_time",si.getColumn(rs,FLD_START_TIME));
		this.set("si.completion_time",si.getColumn(rs,FLD_COMPLETION_TIME));
	}
	private void setEnvironmentEvent(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
		int approve = 0;
		int disapprove = 0;
		int active = 0;
		int total = 0;
		while (ai.nextRecord(rs)) {
			total++;
			String status = ai.getColumn(rs,FLD_STATUS);
			if (status.equals(STATUS_AI_APPROVE)) {
				approve++;
			} else if (status.equals(STATUS_AI_DISAPPROVE)) {
				disapprove++;
			} else if (status.equals(STATUS_AI_ACTIVE)) {
				active++;
			}
		}
		this.set("INC.TOTAL",total);
		this.set("INC.APPROVE",approve);
		this.set("INC.DISAPPROVE",disapprove);
		this.set("INC.ACTIVE",active);
	}

	public Object executeScript(String script) {
		Object res = new Object();
		try {
			res = super.eval(script);
		} catch (EvalError e) {
			e.printStackTrace();
		}
		return res;
	}
	public void set(String key,Object value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
	public void set(String key,int value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
	public void set(String key,double value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
	public void set(String key,float value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
	public void set(String key,boolean value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
	public void set(String key,long value) {
		try {
			super.set(key,value);
		} catch (EvalError e) {
			e.printStackTrace();
		}
	}
}