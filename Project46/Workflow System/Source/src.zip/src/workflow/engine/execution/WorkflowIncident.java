/*
 * Created on 1 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.execution;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
import util.MyCalendar;
import util.WorkflowControlData;
import workflow.engine.definition.Transition;
import workflow.engine.definition.WorkflowDefinition;

public class WorkflowIncident extends Database implements DatabaseField, WorkflowControlData {
	//private ResultSet rs;
	//private Properties wiprop = null;
	//private WorkflowVariable wv = null;
	//private StepIncident si = null;
	//private ActorIncident actinc = null;
	//private WorkflowDefinition wfdef = null;
	//private MyInterpreter myi = null;
	
	//Calendar ca = Calendar.getInstance();
	//private String datetime = ca.get(5)+"/"+(ca.get(2)+1)+"/"+(ca.get(1)-543)+" "+ca.get(11)+":"+ca.get(12)+":"+ca.get(13);
	
	public WorkflowIncident() {
		super("workflow");
	}
	// creat new workflow incident
	public WorkflowIncident(Properties scrData) {
		super("workflow");
		//this.wiprop = scrData;
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		ResultSet rs = super.search();
		
		if (!super.nextRecord(rs)) {
			this.createWorkflowInc(scrData);
		}else {
			this.updateWorkflowInc(scrData);
		}
	}
	private void createWorkflowInc(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_SUBJECT,scrData.getProperty(FLD_SUBJECT));
		super.set(FLD_INITIATOR,scrData.getProperty(FLD_INITIATOR));
		super.set(FLD_PRIORITY,Integer.parseInt(scrData.getProperty(FLD_PRIORITY)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_EXTENSION_TIME,scrData.getProperty(FLD_EXTENSION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));		
		super.set(FLD_DIFFICULT_LEVEL,Integer.parseInt(scrData.getProperty(FLD_DIFFICULT_LEVEL)));
		
		super.insert();
	}
	private void updateWorkflowInc(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.set(FLD_SUBJECT,scrData.getProperty(FLD_SUBJECT));
		super.set(FLD_PRIORITY,Integer.parseInt(scrData.getProperty(FLD_PRIORITY)));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_COMPLETION_TIME,scrData.getProperty(FLD_COMPLETION_TIME));
		super.set(FLD_EXTENSION_TIME,scrData.getProperty(FLD_EXTENSION_TIME));
		super.set(FLD_STATUS,Integer.parseInt(scrData.getProperty(FLD_STATUS)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		super.set(FLD_INITIATOR,scrData.getProperty(FLD_INITIATOR));
		super.set(FLD_DIFFICULT_LEVEL,Integer.parseInt(scrData.getProperty(FLD_DIFFICULT_LEVEL)));
		//super.set(FLD_INITIATOR,Integer.parseInt(scrData.getProperty(FLD_INITIATOR)));
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(scrData.getProperty(FLD_WF_SEQ_NO)));
		super.update();
	}
	
	public ResultSet getWfInc() {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		return super.search();
	}
	public ResultSet getWfInc(String wf_id,String wf_ver) {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		return super.search();
	}
	public ResultSet getWfInc(String wf_id,String wf_ver,String wf_seq_no){
		//SQL="select * from "+TBL_WORKFLOW_INCIDENT+"where "+FLD_WF_ID+"="+wf_id+" and "+FLD_WF_VER+"="+wf_ver;
		//SQL+=" and "+FLD_WF_SEQ_NO+"="+seq_no;
		//super.executeQuery(SQL);
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		return super.search();
	}
	public String getInitiator(String wf_id,String wf_ver,String wf_seq_no) {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		ResultSet rs = super.search();
		String res = super.getColumn(rs,FLD_INITIATOR);
		return res;
	}
	/*
	// return actor incident
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		actinc = new ActorIncident();
		rs = actinc.getActorInc(wf_id,wf_ver,wf_seq_no,step_id);
		return rs;		
	}
	public ResultSet getActorIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id) {
		actinc = new ActorIncident();
		rs = actinc.getActorInc(wf_id,wf_ver,wf_seq_no,step_id,actor_id);
		return rs;
	}
	*/
	// return group of stepincident
	public ResultSet getStepIncident(String wf_id,String wf_ver,String wf_seq_no) {	
		StepIncident si = new StepIncident();
		return si.getStepIncident(wf_id,wf_ver,wf_seq_no);
	}
	// return a stepincident
	public ResultSet getStepIncident(String wf_id,String wf_ver,String wf_seq_no,String step_id) {		
		StepIncident si = new StepIncident();
		return si.getStepIncident(wf_id,wf_ver,wf_seq_no,step_id);
	}
	// return group of workflow variable
	public ResultSet getWorkflowVariables(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowVariable wv = new WorkflowVariable();
		return wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no);
	}
	// return a workflowvariable
	public ResultSet getWorkflowVariables(String wf_id,String wf_ver,String wf_seq_no,String var_name) {
		WorkflowVariable wv = new WorkflowVariable();
		return wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no,var_name);
	}
	public void setWorkflowVariable(String wf_id,String wf_ver,String wf_seq_no,String var_name,String var_value) {
		WorkflowVariable wv = new WorkflowVariable();
		wv.setValue(wf_id,wf_ver,wf_seq_no,var_name,var_value);
	}
	
	// wf_id,wf_ver,wf_seq_no,step_id,[var_name+var_value] in the scrData
	public void updateVariable(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		WorkflowDefinition wd = new WorkflowDefinition();
		ResultSet rs = wd.getStepVarAccess(wf_id,wf_ver,step_id);
		Properties p = new Properties();
		p.setProperty(FLD_WF_ID,wf_id);
		p.setProperty(FLD_WF_VER,wf_ver);
		p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		while (wd.nextRecord(rs)) {
			String access = wd.getColumn(rs,FLD_ACCESS_RIGHT);
			if (access.equals(READ_WRITE)) {
				String vname = wd.getColumn(rs,FLD_VAR_NAME);
				p.setProperty(FLD_VAR_VALUE,scrData.getProperty(vname));
				p.setProperty(FLD_VAR_NAME,vname);
				this.createWorkflowVariable(p);
			} else {
				continue;
			}
		}
	}
	// move to next
	public void next(String wf_id,String wf_ver,String wf_seq_no,String step_id,String event,String user_code,String position_code) {
		StepIncident si = new StepIncident();
		si.next(wf_id,wf_ver,wf_seq_no,step_id,event,user_code,position_code);
	}
	// return to previous step
	public void returns(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String position_code) {
		StepIncident si = new StepIncident();
		si.returns(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code);
	}
	// abort
	public void abort(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		MyInterpreter myi = new MyInterpreter(wf_id,wf_ver,wf_seq_no,step_id);
		ResultSet rs = this.getDefinition(wf_id,wf_ver);
		super.nextRecord(rs);
		String cond = super.getColumn(rs,FLD_ABORT_SCRIPT);
		StepIncident si = new StepIncident();
		boolean bu2 = true;
		if (!(cond.equals(null) || cond.equals("") || cond.equals(" "))) {
			bu2 = ((Boolean)myi.executeScript(cond)).booleanValue();
		}
		if (bu2) {
			this.setStepStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_ABORT);
			Transition t = new Transition();
			ResultSet rst = t.getTo(wf_id,wf_ver,step_id);
			String precond = "";
			int n=0;
			while (t.nextRecord(rst)) {
				si = new StepIncident();
				String sid = t.getColumn(rst,FLD_NEXT_STEP_ID);
				ResultSet rssi = si.getDefinition(wf_id,wf_ver,sid);
				si.nextRecord(rssi);
				precond = si.getColumn(rssi,FLD_PRE_CONDITION);
				n++;
			}
			boolean abort = true;
			if (n==1) {
				if (!(precond==null||precond.equals("")||precond.equals(" "))) {
					//Transition tt = new Transition();
					ResultSet rstt = t.getTo(wf_id,wf_ver,step_id);
					t.nextRecord(rstt);
					String prestep = t.getColumn(rstt,FLD_NEXT_STEP_ID);
					//tt = new Transition();
					rstt = t.getFrom(wf_id,wf_ver,prestep);
					int m = 0;
					while (t.nextRecord(rstt)) {
						String sid = t.getColumn(rstt,FLD_STEP_ID);
						//StepIncident sii = new StepIncident();
						ResultSet rssii = si.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
						si.nextRecord(rssii);
						String sta = si.getColumn(rssii,FLD_STATUS);
						if (sta.equals(STATUS_ST_ACTIVE)||sta.equals(STATUS_ST_COMPLETE)) {
							m++;
						}
					}
					if (m >= Integer.parseInt(precond)) {
						abort = false;
					}
				}
			}
 			if (abort) {
 				// should abort all step incident hava the best way but not this code
 				// abort another step
 				WorkflowIncident wi = new WorkflowIncident();
 				rs = wi.getStepIncident(wf_id,wf_ver,wf_seq_no);
 				while (wi.nextRecord(rs)) {
 					String sid = wi.getColumn(rs,FLD_STEP_ID);
 					WorkflowIncident wist = new WorkflowIncident();
 					ResultSet rsst = wist.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
 					wist.nextRecord(rsst);
 					if (wist.getColumn(rsst,FLD_STATUS).equals(STATUS_ST_ACTIVE)) {
 						wist.setStepStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
 					}
 				}
 				/*
				Transition tt = new Transition();
				ResultSet rstt = tt.getFrom(wf_id,wf_ver,step_id);
				tt.nextRecord(rstt);
				String pstep = tt.getColumn(rstt,FLD_STEP_ID);
				tt = new Transition();
				rstt = tt.getTo(wf_id,wf_ver,pstep);
				while (tt.nextRecord(rstt)) {
					String sid = tt.getColumn(rstt,FLD_NEXT_STEP_ID);
					StepIncident sii = new StepIncident();
					ResultSet rssii = sii.getStepIncident(wf_id,wf_ver,wf_seq_no,sid);
					if (sii.nextRecord(rssii)) {
						String sta = sii.getColumn(rssii,FLD_STATUS);
						if (sta.equals(STATUS_ST_ACTIVE)) {
							ActorIncident aii = new ActorIncident();
							ResultSet rsaii = aii.getActorIncident(wf_id,wf_ver,wf_seq_no,sid);
							while (aii.nextRecord(rsaii)) {
								String staaii = aii.getColumn(rsaii,FLD_STATUS);
								if (staaii.equals(STATUS_AI_ACTIVE)) {
									String pact = aii.getColumn(rsaii,FLD_ACTOR_ID);
									String ppos = aii.getColumn(rsaii,FLD_POSITION_CODE);
									ActorIncident ai1 = new ActorIncident();
									ai1.setStatus(wf_id,wf_ver,wf_seq_no,sid,pact,ppos,STATUS_AI_IGNORE);
								}
							}
							StepIncident si1 = new StepIncident();
						si1.setStatus(wf_id,wf_ver,wf_seq_no,sid,STATUS_ST_IGNORE);
						}
					}
				}
				*/
 				// abort actor incident and queue transfer
				ActorIncident ai = new ActorIncident();
				ActorIncident aii = new ActorIncident();
				ResultSet rsai = ai.getActorIncident(wf_id,wf_ver,wf_seq_no);
				while(ai.nextRecord(rsai)) {
					String act = ai.getColumn(rsai,FLD_ACTOR_ID);
					String pos = ai.getColumn(rsai,FLD_POSITION_CODE);
					String sid = ai.getColumn(rsai,FLD_STEP_ID);
					String sta = si.getColumn(rsai,FLD_STATUS);
					//ActorIncident aii = new ActorIncident();
					if (sta.equals(STATUS_AI_ACTIVE)) {
						if (sid.equals(step_id)) {
							aii.setStatus(wf_id,wf_ver,wf_seq_no,step_id,act,pos,STATUS_AI_ABORT);
						} else {
							aii.setStatus(wf_id,wf_ver,wf_seq_no,step_id,act,pos,STATUS_AI_IGNORE);
						}
					} 
				}
				QueueTransfer qt = new QueueTransfer();
				QueueTransfer qtt = new QueueTransfer();
				ResultSet rsqt = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no);
				while (qt.nextRecord(rsqt)) {
					String qc = qt.getColumn(rsqt,FLD_QUEUE_CODE);
					String tfr = qt.getColumn(rsqt,FLD_TFR_ACTOR_ID);
					String own = qt.getColumn(rsqt,FLD_OWNER_ACTOR_ID);
					String sid = qt.getColumn(rsqt,FLD_STEP_ID);
					String sta = qt.getColumn(rsqt,FLD_STATUS);
					//QueueTransfer qtt = new QueueTransfer();
					if (sta.equals(STATUS_QT_ACTIVE)) {
						if (sid.equals(step_id)) {
							qtt.setStatus(wf_id,wf_ver,wf_seq_no,step_id,qc,tfr,own,STATUS_QT_NOTCOMPLETE);
						} else {
							qtt.setStatus(wf_id,wf_ver,wf_seq_no,sid,qc,tfr,own,STATUS_QT_NOTCOMPLETE);
						}
					}					
				}
				this.setWorkflowStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_ABORT);
 			} else {
				si.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_IGNORE); 			
 			}
		} else {
			si.setStatus(wf_id,wf_ver,wf_seq_no,step_id,STATUS_ST_IGNORE);
		}
	}	
	/*
	// assign
	public void assign(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
		si = new StepIncident();
		si.assign(wf_id,wf_ver,wf_seq_no,step_id,actor_id,tfr_actor_id);
	}	
	// comment incident
	public void comment(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,Properties scrData) {
		si = new StepIncident();
		si.comment(wf_id,wf_ver,wf_seq_no,step_id,actor_id,scrData);
	}
	// tfr_actor_id is group of user that want they to comment your work
	public void commentReq(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
		si = new StepIncident();
		si.commentReq(wf_id,wf_ver,wf_seq_no,step_id,actor_id,tfr_actor_id);
	}
	/*
	// takeover incident
	public void takeover(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String tfr_actor_id) {
	}
	*/
	/*
	// take incident from system queue or define queue
	public void take(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String owner_actor_id,String tfr_actor_id) {
		si = new StepIncident();
		si.take(wf_id,wf_ver,wf_seq_no,step_id,actor_id,owner_actor_id,tfr_actor_id);
	}
	*/
	/*
	public void save(String wf_id,String wf_ver,String wf_seq_no,String step_id,Properties scrData) {
		
	}
	*/
	
	// set status of workflow
	public void setWorkflowStatus(String wf_id,String wf_ver,String wf_seq_no,String status) {
		String datetime = MyCalendar.getDataTime();
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		
		super.set(FLD_STATUS,Integer.parseInt(status));
		super.set(FLD_COMPLETION_TIME,datetime);
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.update();
	}
	// set status of step
	public void setStepStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String status) {
		StepIncident si = new StepIncident();
		si.setStatus(wf_id,wf_ver,wf_seq_no,step_id,status);
	}
	/*
	// set status of actor incident
	public void setActorIncStatus(String wf_id,String wf_ver,String wf_seq_no,String step_id,String actor_id,String status) {
		actinc = new ActorIncident();
		actinc.setStatus(wf_id,wf_ver,wf_seq_no,step_id,actor_id,status);
	}
	*/	

	// return resultset of workflowdefinition
	public ResultSet getDefinition(String wf_id,String wf_ver) {
		WorkflowDefinition wfdef = new WorkflowDefinition();
		return wfdef.getWorkflowDef(wf_id,wf_ver);
	}
	/*
	public ResultSet getStepDefinition(String wf_id,String wf_ver,String step_id) {
		si = new StepIncident();
		rs = si.getDefinition(wf_id,wf_ver,step_id);
		return rs;
	}
	public ResultSet getWfVarDef(String wf_id,String wf_ver,String var_name) {
		WorkflowVariable wv = new WorkflowVariable();
		rs = wv.getDefinition(wf_id,wf_ver,var_name);
		return rs;
	}
	*/
	// create step_Incident
	public void createStepIncident(Properties scrData) {
		WorkflowDefinition wfdef = new WorkflowDefinition();
		wfdef.createStepIncident(scrData);
	}
	public void createWorkflowVariable(Properties scrData) {
		WorkflowDefinition wfdef = new WorkflowDefinition();
		wfdef.createWorkflowVariable(scrData);
	}
	public void updateCompleteTime(String wf_id,String wf_ver,String wf_seq_no,String dt) {
		super.initMyTable(TBL_WORKFLOW_INCIDENT);
		super.set(FLD_COMPLETION_TIME,dt);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_WF_SEQ_NO,Long.parseLong(wf_seq_no));
		super.update();
	}
}
