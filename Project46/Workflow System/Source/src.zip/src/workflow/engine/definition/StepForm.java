/*
 * Created on 3 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;
/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;


import util.*;
import web.ListBox;
import web.TextFields;
import workflow.engine.execution.WorkflowVariable;

public class StepForm extends Database implements DatabaseField,WorkflowControlData {
	private ResultSet rs = null;
	private WorkflowVariable wv;
	private WfVarDef wfvardef;
	private StepVarAccess sva;
	public StepForm() {
		super("workflow");
		wfvardef=new WfVarDef();
		sva=new StepVarAccess();
	}
	// get web form to display
	public String getStepForm(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		wv=new WorkflowVariable();
		String form = "";
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		rs = super.search();
		String begin="<!--";
		String end="-->";
		String field="";
		String element="";
		boolean con=true;
		int pre=0;
		int pos=0;
		ResultSet var_def=wfvardef.getWfVarDef(wf_id,wf_ver);
		ResultSet var=null;
		try {
			String var_name="";
			String var_desc_thai="";
			String var_desc_eng="";
			String hint="";
			String var_type="";
			String init_value="";
			String nullable="";
			String input_type="";
			String token="";
			String input_value="";
			form =(rs.next())?rs.getString(FLD_WEB_PAGE):"";// get form orginal
			ResultSet r=null;
			String accessR="";
			String current_value="";
			ResultSet rs=null;
			// set wfvariable
			while( var_def.next() ){  // next variable
				///////// prepare property of wfvar
				var_name=ThaiUtilities.ASCII2Unicode(var_def.getString(FLD_VAR_NAME));
				var_desc_thai=ThaiUtilities.ASCII2Unicode(var_def.getString(FLD_VAR_DESC_THAI));
				var_desc_eng=var_def.getString(FLD_VAR_DESC_ENG);
				hint=var_def.getString(FLD_HINT);
				var_type=var_def.getString(FLD_VAR_TYPE);
				init_value=var_def.getString(FLD_INIT_VALUE);
				nullable=var_def.getString(FLD_NULLABLE);
				nullable=(nullable.equals("0"))?"NOT NULL":"NULLABLE";
				input_type=var_def.getString(FLD_INPUT_TYPE);
				input_value=var_def.getString(FLD_INPUT_VALUE);
					// under the same wf_id,wf_ver have unique var_name
				var=wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no,var_name);
				current_value=var.next()?var.getString(FLD_VAR_VALUE):"";  //default equal ""
				//////// end prepare variable
				//get Step variable Acess
				r=sva.getStepVarAccess(wf_id,wf_ver,step_id,var_def.getString(FLD_VAR_NAME));
				accessR= r.next()?r.getString(FLD_ACCESS_RIGHT):"";
				token="<!--";
				token+=var_name+":";// build token
				con=true;
				pre=0;
				pos=0;
				//  scan in form for replace element into token( <!-- --> )
				while( con ){
					element="";
					pre=form.indexOf(token,pre);  // search  not match pre = -1
					if( pre > 0 ){
						pos=form.indexOf(end,pre+token.length()); // pre is pos of "<--"
						field=form.substring(pre+token.length(),pos);
							///  what field ?
						if( !accessR.equals(NOT_ACCESSIBLE) ){  // found variable Not Access
							if( field.equals(FLD_VAR_NAME)){
								element=var_name;
							}else if( field.equals(FLD_VAR_TYPE)){
								element=var_type;					
							}else if( field.equals(VALUE) ){  // value=( init_value +input_type+ input_value)
								if( accessR.equals(READ_ONLY) ){
									if( !current_value.equals("") ){ // have current
										//display input value
										element=current_value;
										//element=buildComp(input_type,var_name,"","",current_value,"",READ_ONLY);
									}else{
										// display init value
										element=init_value;
										//element=buildComp(input_type,var_name,init_value,input_value,"","",READ_ONLY);
									}
										/*
										}else if( accessR.equals(WRITE_ONLY) ){
											if( !current_value.equals("") ){ // have current
												element=buildComp(input_type,var_name,var_type,init_value,"","");
											}
										*/
								}else if( accessR.equals(READ_WRITE) ){
									if( !current_value.equals("") ){ // have current
										element=buildComp(input_type,var_name,"","",current_value,"","");
									}else{
										// display init value
										element=buildComp(input_type,var_name,init_value,input_value,"","","");
									}
								}
							}else if( field.equals(FLD_VAR_DESC_THAI)){
								element=var_desc_thai;
							}else if( field.equals(FLD_VAR_DESC_ENG)){
								element=var_desc_eng;
							}else if( field.equals(FLD_HINT)){
								element=hint;
							}else if( field.equals(FLD_ACCESS_RIGHT)){
								element=nullable;
							}
						}else  // loop variable Not Access
							element="Not Accessible";
						form=form.replaceFirst(token+field+end,element);
						pre=pre+element.length();        //update pre to current index
					}else
						con=false;//false indicate the string not match occurence
				}
			}
			// scan set system var  
			// will build in next release
			/*while( sys_var.next() ){
				token="<!--SYSTEM_VAR:";
				form.replaceFirst();
			}*/
			
			/* scan set variable for formula
			// will build in next release
			 */
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return form;
	}	// passed
	
	// build from with input value
	private String buildComp(String input_type,String var_name,String init_value,String input_value,String current_value,String nullable,String read_only){
		String com="";
		String value="";
		// ��Ҩзӡ�� ���¡�� ���ҧ������ Web component ᷹��Ҩдա���
			if( init_value.equals("") ) // not have init value
				value=current_value;
			else 
				value=init_value;
			if( input_type.equals(TEXT_FIELDS)){
				// not require input value
				TextFields tf=new TextFields(var_name,value,read_only,nullable);
				com=tf.getWebElement();
			}else if( input_type.equals(LIST_BOX)){
				ListBox lb=new ListBox(var_name,input_value,value,read_only,nullable);
				com=lb.getWebElement();
			}
		return com;
	}
	
	//  generate init step use for generate default page
	public String genInitStepForm(String wf_id,String wf_ver,String step_id){
		String	initForm ="<table width=\"761\" border=\"1\" cellpadding=\"1\" cellspacing=\"0\" bgcolor=\"#FFFFCC\">";
				initForm+="<tr>";
				initForm+="<td width=\"123\"><div align=\"center\"><strong>variable</strong></div></td>";
				initForm+="<td width=\"228\"><div align=\"center\"><strong>value</strong></div></td>";
				initForm+="<td width=\"63\"><div align=\"center\"><strong>require</strong></div></td>";
				initForm+="<td width=\"329\"><div align=\"center\"><strong>Description</strong></div></td>";
				initForm+="</tr>";
		ResultSet var_def=wfvardef.getWfVarDef(wf_id,wf_ver);
		try{
			String accessR="";// acess right
			ResultSet r=null;
			String var="";
			/// list all workflow variable
			while( var_def.next() ){
				//get Step variable Acess
				r=sva.getStepVarAccess(wf_id,wf_ver,step_id,var_def.getString(FLD_VAR_NAME));
				accessR= r.next()?r.getString(FLD_ACCESS_RIGHT):"";
				// Not process NOT ACCESS
				if( !accessR.equalsIgnoreCase(NOT_ACCESSIBLE) ){
					var="<!--"+var_def.getString(FLD_VAR_NAME)+":"+FLD_VAR_NAME+"-->";
					initForm+="<tr bgcolor=\"#FFFFFF\"><td><strong>"+var+"</strong></td>";
					var="<!--"+var_def.getString(FLD_VAR_NAME)+":"+VALUE+"-->";
					initForm+="<td>"+var+"</td>";
					var="<!--"+var_def.getString(FLD_VAR_NAME)+":"+FLD_ACCESS_RIGHT+"-->";
					initForm+="<td>"+var+"</td>";
					var="<!--"+var_def.getString(FLD_VAR_NAME)+":"+FLD_VAR_DESC_THAI+"-->";
					initForm+="<td>"+var+"</td>";
					initForm+="</tr>";
				}
			}
			initForm+="</table>";
		}catch (SQLException ex) {
			ex.printStackTrace();
		}
		return initForm;
	}// pass
	
	public String getExecutedForm(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		wv=new WorkflowVariable();
		String form = "";
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		rs = super.search();
		String begin="<!--";
		String end="-->";
		String field="";
		String element="";
		boolean con=true;
		int pre=0;
		int pos=0;
		ResultSet var_def=wfvardef.getWfVarDef(wf_id,wf_ver);
		ResultSet var=null;
		try {
			String var_name="";
			String var_desc_thai="";
			String var_desc_eng="";
			String hint="";
			String var_type="";
			String init_value="";
			String nullable="";
			String input_type="";
			String token="";
			String input_value="";
			form =(rs.next())?rs.getString(FLD_WEB_PAGE):"";// get form orginal
			ResultSet r=null;
			String accessR="";
			String current_value="";
			ResultSet rs=null;
			// set wfvariable
			while( var_def.next() ){  // next variable
				///////// prepare property of wfvar
				var_name=var_def.getString(FLD_VAR_NAME);
				var_desc_thai=ThaiUtilities.ASCII2Unicode(var_def.getString(FLD_VAR_DESC_THAI));
				var_desc_eng=ThaiUtilities.ASCII2Unicode(var_def.getString(FLD_VAR_DESC_ENG));
				hint=var_def.getString(FLD_HINT);
				var_type=var_def.getString(FLD_VAR_TYPE);
				init_value=var_def.getString(FLD_INIT_VALUE);
				nullable=var_def.getString(FLD_NULLABLE);
				nullable=(nullable.equals("0"))?"NOT NULL":"NULLABLE";
				input_type=var_def.getString(FLD_INPUT_TYPE);
				input_value=var_def.getString(FLD_INPUT_VALUE);
					// under the same wf_id,wf_ver have unique var_name
				var=wv.getWorkflowVariable(wf_id,wf_ver,wf_seq_no,var_name);
				current_value=var.next()?var.getString(FLD_VAR_VALUE):"";  //default equal ""
				//////// end prepare variable
				//get Step variable Acess
				r=sva.getStepVarAccess(wf_id,wf_ver,step_id,var_def.getString(FLD_VAR_NAME));
				accessR= r.next()?r.getString(FLD_ACCESS_RIGHT):"";
				token="<!--";
				token+=var_name+":";// build token
				con=true;
				pre=0;
				pos=0;
				//  scan in form for replace element into token( <!-- --> )
				while( con ){
					element="";
					pre=form.indexOf(token,pre);  // search  not match pre = -1
					if( pre > 0 ){
						pos=form.indexOf(end,pre+token.length()); // pre is pos of "<--"
						field=form.substring(pre+token.length(),pos);
							///  what field ?
						if( !accessR.equals(NOT_ACCESSIBLE) ){  // found variable Not Access
							if( field.equals(FLD_VAR_NAME)){
								element=var_name;
							}else if( field.equals(FLD_VAR_TYPE)){
								element=var_type;					
							}else if( field.equals(VALUE) ){  // value=( init_value +input_type+ input_value)
								if( accessR.equals(READ_ONLY) ){
									if( !current_value.equals("") ){ // have current
										//display input value
										element=current_value;
										//element=buildComp(input_type,var_name,"","",current_value,"",READ_ONLY);
									}
										/*
										}else if( accessR.equals(WRITE_ONLY) ){
											if( !current_value.equals("") ){ // have current
												element=buildComp(input_type,var_name,var_type,init_value,"","");
											}
										*/
								}else if( accessR.equals(READ_WRITE) ){
									if( !current_value.equals("") ) // have current
										element=current_value;
								}
							}else if( field.equals(FLD_VAR_DESC_THAI)){
								element=var_desc_thai;
							}else if( field.equals(FLD_VAR_DESC_ENG)){
								element=var_desc_eng;
							}else if( field.equals(FLD_HINT)){
								element=hint;
							}else if( field.equals(FLD_ACCESS_RIGHT)){
								element=nullable;
							}
						}else  // loop variable Not Access
							element="Not Accessible";
						form=form.replaceFirst(token+field+end,element);
						pre=pre+element.length();        //update pre to current index
					}else
						con=false;//false indicate the string not match occurence
				}
			}
			// scan set system var  
			// will build in next release
			/*while( sys_var.next() ){
				token="<!--SYSTEM_VAR:";
				form.replaceFirst();
			}*/
			
			/* scan set variable for formula
			// will build in next release
			 */
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return form;
	}
	
}
/*
	// use at create step incident
	public String generateForm(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		WorkflowDefinition wd = new WorkflowDefinition();
		rs = wd.getWfVarDef(wf_id,wf_ver,step_id);
		String s = "<table width=\"400\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"2\" bgcolor=\"#CCCCCC\"> "+
  					"<tr bgcolor=\"#FFFFFF\">"+
					"<td align=\"center\"><font size=\"2\">Variable Name</font></td>"+
					"<td align=\"center\"><font size=\"2\">Variable Value</font></td>"+
					"<td align=\"center\"><font size=\"2\">Description</font></td>"+
					"<td align=\"center\"><font size=\"2\">Require</font></td>"+
  					"</tr>";// head
		try {
			String d = "";
			while (rs.next()) {
				String a = rs.getString(FLD_VAR_NAME);
				int b = rs.getInt(FLD_INPUT_TYPE);
				//String c = rs.getString(FLD_INPUT_VALUE);
				String c="";
				if (c == null) {
					c = rs.getString(FLD_INIT_VALUE);
				}
				d += "<tr bgcolor=\"#FFFFFF\">";
				StringTokenizer st = new StringTokenizer(c,"::");
				String nullable = "";
				
				if (rs.getBoolean(FLD_NULLABLE)) {
					nullable += "NO";
				} else {
					nullable += "YES";
				}
				if (Integer.valueOf(step_id).intValue() != 1) {
					if (rs.getInt(FLD_ACCESS_RIGHT) == 1) {
						b += 10; 
						nullable = "NO";
					} else if (rs.getInt(FLD_ACCESS_RIGHT) == 2) {
						b += 20;
					} else if (rs.getInt(FLD_ACCESS_RIGHT) == 3) {
						b += 20;
						nullable = "YES";
					}
					c = wv.getValue(wf_id,wf_ver,wf_seq_no,rs.getString(FLD_VAR_NAME));
				}
				switch (b) {
					// TEXTBOX
					case 1 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><input type=\"text\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\"></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					// TEXTAREA
					case 2 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><textarea name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\"></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					// DROPDOWN
					case 3 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\"> ";
										while (st.hasMoreTokens()) {
											d+= "<option>"+st.nextToken()+"</option>";										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					// LISTBOX
					case 4 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\" size=\"5\" multiple> ";
										while (st.hasMoreTokens()) {
											d+= "<option>"+st.nextToken()+"</option>";
										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					// CHECKBOX
					case 5 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											d += "<input type=\"checkbox\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\">"+st.nextToken()+"</br>";
										}
										d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					// RADIOBUTTON
					case 6 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											d += "<input type=\"radio\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\">"+st.nextToken()+"</br>";
										}
										d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 11 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\"><input type=\"text\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+c+"\" disabled >/font></td>"+
									"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 12 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><textarea name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+c+"\" disabled ></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 13 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\" disabled> ";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d+= "<option selected>"+st.nextToken()+"</option>";
											} else {
												d+= "<option>"+st.nextToken()+"</option>";
											}						
										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 14 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\" size=\"5\" multiple disabled> ";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d+= "<option selected>"+st.nextToken()+"</option>";
											} else {
												d+= "<option>"+st.nextToken()+"</option>";
											}
										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 15 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d += "<input type=\"checkbox\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" disabled checked>"+st.nextToken()+"</br>";
											} else {
												d += "<input type=\"checkbox\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" disabled >"+st.nextToken()+"</br>";
											}
										}
								d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 16 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d += "<input type=\"radio\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" disabled checked>"+st.nextToken()+"</br>";
											} else {
												d += "<input type=\"radio\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" disabled >"+st.nextToken()+"</br>";
											}
										}
								d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 21 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\"><input type=\"text\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+c+"\" >/font></td>"+
									"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 22 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\"><textarea name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+c+"\" ></font></td>"+
									"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
									"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 23 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\"> ";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d+= "<option selected>"+st.nextToken()+"</option>";
											} else {
												d+= "<option>"+st.nextToken()+"</option>";
											}						
										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 24 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\"><select name=\""+rs.getString(FLD_VAR_NAME)+"\" size=\"5\" multiple> ";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d+= "<option selected>"+st.nextToken()+"</option>";
											} else {
												d+= "<option>"+st.nextToken()+"</option>";
											}
										}
								d += "</select></font></td>"+
										"<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 25 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d += "<input type=\"checkbox\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" checked>"+st.nextToken()+"</br>";
											} else {
												d += "<input type=\"checkbox\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" >"+st.nextToken()+"</br>";
											}
										}
								d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;
					case 26 : 	d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_NAME)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">";
										while (st.hasMoreTokens()) {
											String buff = st.nextToken();
											if (c.equals(buff)) {
												d += "<input type=\"radio\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" checked>"+st.nextToken()+"</br>";
											} else {
												d += "<input type=\"radio\" name=\""+rs.getString(FLD_VAR_NAME)+"\" value=\""+st.nextToken()+"\" >"+st.nextToken()+"</br>";
											}
										}			
								d += "</font></td>";
								d += "<td align=\"center\"><font size=\"2\">"+rs.getString(FLD_VAR_DESC_THAI)+"</font></td>"+
										"<td align=\"center\"><font size=\"2\">"+nullable+"</font></td>";
								break;		
				}
				d += "</tr>";
			}
			s += d;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		s += "</table>";
		return s;
	}
	*/