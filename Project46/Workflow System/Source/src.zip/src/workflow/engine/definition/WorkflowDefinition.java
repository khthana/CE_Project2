/*
 * Created on 25 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import util.Database;
import util.DatabaseField;
import workflow.engine.execution.WfIncMgmt;

public class WorkflowDefinition extends Database implements DatabaseField {

	//private ResultSet rs = null;
	//private String SQL;
	
	//private StepDefinition sd = null;
	//private WfVarDef wvd = null;
	//private Transition tt = null;
	//private WorkflowIncident wi = null;
	// properties of WorkflowDefinition
	//private Properties workflow = new Properties();
	//Calendar ca = Calendar.getInstance();
	//private String datetime = String.valueOf(ca.get(5))+"/"+String.valueOf(ca.get(2)+1)+"/"
	//					+String.valueOf(ca.get(1))+" "
	//					+String.valueOf(ca.get(11)+":"+String.valueOf(ca.get(12))+":"
	//					+String.valueOf(ca.get(13)));

	public WorkflowDefinition(){
		super("workflow");
	}
	// build new workflow Definition
	public WorkflowDefinition(Properties scrData){
		super("workflow");
		//this.workflow=scrData;
		ResultSet rs = this.getWorkflowDef(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER));
		try {
			//rs.next();
			if (!rs.next()) {
				this.createWorkflowDefinition(scrData);
			} else {
				this.updateWorkflowDefinition(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createWorkflowDefinition(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_WF_NAME,scrData.getProperty(FLD_WF_NAME));
		super.set(FLD_WF_SHORT_CODE,scrData.getProperty(FLD_WF_SHORT_CODE));
		super.set(FLD_WF_OBJECTIVE,scrData.getProperty(FLD_WF_OBJECTIVE));
		super.set(FLD_WF_RULE,scrData.getProperty(FLD_WF_RULE));
		super.set(FLD_COMPLETION_DURATION,Long.valueOf(scrData.getProperty(FLD_COMPLETION_DURATION)).intValue());
		super.set(FLD_EXTENSION_DURATION,Long.valueOf(scrData.getProperty(FLD_EXTENSION_DURATION)).intValue());
		//initiator
		super.set(FLD_INITIATOR_DEF,scrData.getProperty(FLD_INITIATOR_DEF));
		super.set(FLD_INITIATE_TIME,scrData.getProperty(FLD_INITIATE_TIME));
		super.set(FLD_SCHEDULE,scrData.getProperty(FLD_SCHEDULE));
		super.set(FLD_WF_DESC,scrData.getProperty(FLD_WF_DESC));
		//super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_END_TIME,scrData.getProperty(FLD_END_TIME));
		super.set(FLD_PRIORITY,Integer.parseInt(scrData.getProperty(FLD_PRIORITY)));
		//super.set(FLD_SECURITY,Integer.parseInt(scrData.getProperty(FLD_SECURITY)));
		super.set(FLD_ABORT_SCRIPT,scrData.getProperty(FLD_ABORT_SCRIPT));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.set(FLD_TAKEOVER_RIGHT,Integer.valueOf(scrData.getProperty(FLD_TAKEOVER_RIGHT)).intValue());
		//super.set(FLD_WEB_PAGE,scrData.getProperty(FLD_WEB_PAGE));
		super.set(FLD_DIFFICULT_LEVEL,Integer.valueOf(scrData.getProperty(FLD_DIFFICULT_LEVEL)).intValue());
		super.set(FLD_LAST_SEQ,Long.parseLong(scrData.getProperty(FLD_LAST_SEQ)));
		super.set(FLD_CURRENT_USE,Integer.parseInt(scrData.getProperty(FLD_CURRENT_USE)));
		super.insert();
	}
	private void updateWorkflowDefinition(Properties scrData) {
		
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_WF_NAME,scrData.getProperty(FLD_WF_NAME));
		super.set(FLD_WF_SHORT_CODE,scrData.getProperty(FLD_WF_SHORT_CODE));
		super.set(FLD_WF_OBJECTIVE,scrData.getProperty(FLD_WF_OBJECTIVE));
		super.set(FLD_WF_RULE,scrData.getProperty(FLD_WF_RULE));
		super.set(FLD_COMPLETION_DURATION,Long.valueOf(scrData.getProperty(FLD_COMPLETION_DURATION)).intValue());
		super.set(FLD_EXTENSION_DURATION,Long.valueOf(scrData.getProperty(FLD_EXTENSION_DURATION)).intValue());
		// initiator
		super.set(FLD_INITIATOR_DEF,scrData.getProperty(FLD_INITIATOR_DEF));
		super.set(FLD_INITIATE_TIME,scrData.getProperty(FLD_INITIATE_TIME));
		super.set(FLD_SCHEDULE,scrData.getProperty(FLD_SCHEDULE));
		super.set(FLD_LAST_SEQ,Long.parseLong(scrData.getProperty(FLD_LAST_SEQ)));
		//super.set(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		super.set(FLD_START_TIME,scrData.getProperty(FLD_START_TIME));
		super.set(FLD_END_TIME,scrData.getProperty(FLD_END_TIME));
		super.set(FLD_PRIORITY,Integer.parseInt(scrData.getProperty(FLD_PRIORITY)));
		//super.set(FLD_SECURITY,Integer.parseInt(scrData.getProperty(FLD_SECURITY)));
		super.set(FLD_ABORT_SCRIPT,scrData.getProperty(FLD_ABORT_SCRIPT));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.set(FLD_TAKEOVER_RIGHT,Integer.valueOf(scrData.getProperty(FLD_TAKEOVER_RIGHT)).intValue());
		//super.set(FLD_WEB_PAGE,scrData.getProperty(FLD_WEB_PAGE));
		super.set(FLD_DIFFICULT_LEVEL,Integer.valueOf(scrData.getProperty(FLD_DIFFICULT_LEVEL)).intValue());
		super.set(FLD_WF_DESC,scrData.getProperty(FLD_WF_DESC));
		super.set(FLD_CURRENT_USE,Integer.parseInt(scrData.getProperty(FLD_CURRENT_USE)));
		
		super.setFilter(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		
		super.update();
	}
	
	// return all workflow from database
	public ResultSet getWorkflowDef() {
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.setOrder(FLD_WF_ID);
		ResultSet rs = super.search();
		return rs;
	}
	// return about workflow from database
	// DbRecord
	public ResultSet getWorkflowDef(String wf_id,String wf_ver){
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		//System.out.println(SQL);
		ResultSet rs = super.search();
		return rs;
	}
	//delete a WorkflowDefinition from WorkflowDefinition
	public void delWorkflowDefinition(String wf_id,String wf_ver) {
		StepDefinition sd = new StepDefinition();
		sd.delStepDef(wf_id,wf_ver);
		WfVarDef wvd = new WfVarDef();
		wvd.delWfVarDef(wf_id,wf_ver);
		Transition tt = new Transition();
		tt.delTransition(wf_id,wf_ver);
		this.delStepVarAccessByWF(wf_id,wf_ver);
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.delete();
	}
	/*
	// Check user that have privilege(�Է���) to create
	public boolean checkInitiatorRight(String wf_id,String wf_ver,String user_id) {
		boolean result = false;
		ResolveActor ra = new ResolveActor();
		try {
			Collection c = ra.getRefActor(this.getWorkflowDef(wf_id,wf_ver).getString(FLD_INITIATOR_DEF));
			String bu = c.toString();
			if (bu.indexOf(user_id) > -1) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	*/
	//copy WorkflowDefinition but change version of workflow
	public void copyWorkflowDefinition(String wf_id,String wf_ver) {
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		ResultSet rs = this.getWorkflowDef(wf_id,wf_ver);
		//SQL = "select * from "+TBL_WORKFLOW_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+
		//		" and "+FLD_WF_VER+"="+wf_ver;
		//rs = super.executeQuery(SQL);
		Properties result = new Properties();
		try {
			rs.next();
			result.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
			String a = String.valueOf(Integer.valueOf(wf_ver).intValue()+1);
			Database db = new Database("workflow");
			db.initMyTable(TBL_WORKFLOW_DEFINITION);
			db.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
			ResultSet rsdb = db.search();
			int b = 0;
			while (db.nextRecord(rsdb)) {
				String aa = db.getColumn(rsdb,FLD_WF_VER);
				int c = Integer.parseInt(aa);
				if (c > b) {
					b = c;
				}
			}
			b++;
			a = String.valueOf(b); 
			result.setProperty(FLD_WF_VER,a);
			result.setProperty(FLD_WF_NAME,rs.getString(FLD_WF_NAME));
			result.setProperty(FLD_WF_SHORT_CODE,rs.getString(FLD_WF_SHORT_CODE));
			result.setProperty(FLD_WF_OBJECTIVE,rs.getString(FLD_WF_OBJECTIVE));
			result.setProperty(FLD_WF_RULE,rs.getString(FLD_WF_RULE));
			result.setProperty(FLD_WF_DESC,rs.getString(FLD_WF_DESC));
			result.setProperty(FLD_COMPLETION_DURATION,rs.getString(FLD_COMPLETION_DURATION));
			result.setProperty(FLD_EXTENSION_DURATION,rs.getString(FLD_EXTENSION_DURATION));
			result.setProperty(FLD_INITIATOR_DEF,rs.getString(FLD_INITIATOR_DEF));
			result.setProperty(FLD_INITIATE_TIME,rs.getString(FLD_INITIATE_TIME));
			result.setProperty(FLD_SCHEDULE,rs.getString(FLD_SCHEDULE));
			result.setProperty(FLD_LAST_SEQ,"0");
			//result.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
			result.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
			result.setProperty(FLD_END_TIME,rs.getString(FLD_END_TIME));
			result.setProperty(FLD_PRIORITY,rs.getString(FLD_PRIORITY));
			//result.setProperty(FLD_SECURITY,rs.getString(FLD_SECURITY));
			result.setProperty(FLD_ABORT_SCRIPT,rs.getString(FLD_ABORT_SCRIPT));
			//Date d = new Date();
			//String date = "";
			//date = String.valueOf(d.get)
			//result.setProperty(FLD_LAST_UPDATE,datetime);
			//
			//result.setProperty(FLD_UPDATE_BY,rs.getString(FLD_UPDATE_BY));
			result.setProperty(FLD_TAKEOVER_RIGHT,rs.getString(FLD_TAKEOVER_RIGHT));
			//result.setProperty(FLD_WEB_PAGE,rs.getString(FLD_WEB_PAGE));
			result.setProperty(FLD_DIFFICULT_LEVEL,rs.getString(FLD_DIFFICULT_LEVEL));
			result.setProperty(FLD_CURRENT_USE,super.getColumn(rs,FLD_CURRENT_USE));

			WorkflowDefinition wd = new WorkflowDefinition(result);
			// copy workflow variable
			rs = this.getWfVarDef(wf_id,wf_ver);
			while (super.nextRecord(rs)) {
				result.setProperty(FLD_VAR_NAME,super.getColumn(rs,FLD_VAR_NAME));
				result.setProperty(FLD_VAR_DESC_THAI,super.getColumn(rs,FLD_VAR_DESC_THAI));
				result.setProperty(FLD_VAR_DESC_ENG,super.getColumn(rs,FLD_VAR_DESC_ENG));
				result.setProperty(FLD_VAR_TYPE,super.getColumn(rs,FLD_VAR_TYPE));
				result.setProperty(FLD_HINT,super.getColumn(rs,FLD_HINT));
				result.setProperty(FLD_INIT_VALUE,super.getColumn(rs,FLD_INIT_VALUE));
				result.setProperty(FLD_VALIDATE_CLASS,super.getColumn(rs,FLD_VALIDATE_CLASS));
				result.setProperty(FLD_NULLABLE,super.getColumn(rs,FLD_NULLABLE));
				result.setProperty(FLD_ENCRYPT,super.getColumn(rs,FLD_ENCRYPT));
				result.setProperty(FLD_ACCESS_RIGHT,super.getColumn(rs,FLD_ACCESS_RIGHT));
				result.setProperty(FLD_INPUT_TYPE,super.getColumn(rs,FLD_INPUT_TYPE));
				result.setProperty(FLD_INPUT_VALUE,super.getColumn(rs,FLD_INPUT_VALUE));
				WfVarDef vardef = new WfVarDef(result);
			}
			//copy step definition
			rs = this.getStepDefinition(wf_id,wf_ver);
			while (super.nextRecord(rs)) {
				result.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				result.setProperty(FLD_STEP_NAME,rs.getString(FLD_STEP_NAME));
				result.setProperty(FLD_STEP_DESC,rs.getString(FLD_STEP_DESC));
				result.setProperty(FLD_STEP_TYPE,rs.getString(FLD_STEP_TYPE));
				result.setProperty(FLD_RECIPIENT_DEF,rs.getString(FLD_RECIPIENT_DEF));
				result.setProperty(FLD_TASK_RATE,rs.getString(FLD_TASK_RATE));
				result.setProperty(FLD_WEB_PAGE,rs.getString(FLD_WEB_PAGE));
				result.setProperty(FLD_AUTO_APPROVE,rs.getString(FLD_AUTO_APPROVE));
				result.setProperty(FLD_COMPLETE_SCRIPT,rs.getString(FLD_COMPLETE_SCRIPT));
				result.setProperty(FLD_RETURN_SCRIPT,rs.getString(FLD_RETURN_SCRIPT));
				result.setProperty(FLD_ATTACHED_STATUS,rs.getString(FLD_ATTACHED_STATUS));
				result.setProperty(FLD_COMPLETION_DURATION,rs.getString(FLD_COMPLETION_DURATION));
				result.setProperty(FLD_EXTENSION_DURATION,rs.getString(FLD_EXTENSION_DURATION));
				result.setProperty(FLD_DELAY_DURATION,rs.getString(FLD_DELAY_DURATION));
				result.setProperty(FLD_ONLATE_NOTIFY,rs.getString(FLD_ONLATE_NOTIFY));
				result.setProperty(FLD_PRE_CONDITION,rs.getString(FLD_PRE_CONDITION));
				StepDefinition stdef = new StepDefinition(result);
			}
			// copy transition
			rs = this.getTransition(wf_id,wf_ver);
			while (super.nextRecord(rs)) {
				result.setProperty(FLD_STEP_ID,super.getColumn(rs,FLD_STEP_ID));
				result.setProperty(FLD_NEXT_STEP_ID,super.getColumn(rs,FLD_NEXT_STEP_ID));
				result.setProperty(FLD_CONDITION,super.getColumn(rs,FLD_CONDITION));
				result.setProperty(FLD_ON_EVENT,super.getColumn(rs,FLD_ON_EVENT));
				result.setProperty(FLD_TRAN_DESC,super.getColumn(rs,FLD_TRAN_DESC));
				Transition tt = new Transition(result);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/*
	 * step definition section
	 */
	
	// return a StepDefinition in the WorkflowDefinition
	//DbRecord
	public ResultSet getStepDefinition(String wf_id,String wf_ver,String step_id) {
		StepDefinition sd = new StepDefinition();
		return sd.getStepDef(wf_id,wf_ver,step_id);
	}
	// return all StepDefinition in the WorkflowDefinition
	//DbInquiry
	public ResultSet getStepDefinition(String wf_id,String wf_ver){
		StepDefinition sd = new StepDefinition();
		return sd.getStepDef(wf_id,wf_ver);	
	}
	// return all WorkflowVariable in the WorkflowDefinition
	// delete StepDefinition from WorkflowDefinition
	public void delStepDefinition(String wf_id,String wf_ver,String step_id){
		this.delStepVarAccessByStep(wf_id,wf_ver,step_id);
		Transition tt = new Transition();
		tt.delTransition(wf_id,wf_ver,step_id);
		ResultSet rs = tt.getFrom(wf_id,wf_ver,step_id);
		Transition ttt = new Transition();
		while (tt.nextRecord(rs)) {
			String pstep = tt.getColumn(rs,FLD_STEP_ID);
			ttt.delTransition(wf_id,wf_ver,pstep,step_id);
		}
		StepDefinition sd = new StepDefinition();
		sd.delStepDef(wf_id,wf_ver,step_id);
		StepVarAccess sva = new StepVarAccess();
		sva.delStepVarAccessByStep(wf_id,wf_ver,step_id);
	}
	// add StepDefinition to WorkflowDefinition by StepDefiniton Data
	public void addStepDefinition(Properties scrData){
		//Database
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		if (step_id.equals("1"))
			scrData.setProperty(FLD_ACCESS_RIGHT,"3");
		else
			scrData.setProperty(FLD_ACCESS_RIGHT,"1");
		WfVarDef vardef = new WfVarDef();
		ResultSet rs = vardef.getWfVarDef(wf_id,wf_ver);
		while (vardef.nextRecord(rs)) {
			String vname = vardef.getColumn(rs,FLD_VAR_NAME);
			if (!step_id.equals("1") || !step_id.equals("2"))
				scrData.setProperty(FLD_ACCESS_RIGHT,scrData.getProperty(vname)); 
			scrData.setProperty(FLD_VAR_NAME,vname);
			this.addStepVarAccess(scrData);
		}
		String form = this.genInitStepForm(wf_id,wf_ver,step_id);
		scrData.setProperty(FLD_WEB_PAGE,form);
		StepDefinition sd = new StepDefinition(scrData);
	}
	public void updateStepDefinition(Properties scrData) {
		//Date d = new Date();
		//scrData.setProperty(FLD_UPDATE_BY," ");
		//scrData.setProperty(FLD_LAST_UPDATE,datetime);
		WfVarDef vardef = new WfVarDef();
		ResultSet rs = vardef.getWfVarDef(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER));
		while (vardef.nextRecord(rs)) {
			String vname = vardef.getColumn(rs,FLD_VAR_NAME);
			scrData.setProperty(FLD_VAR_NAME,vname);
			scrData.setProperty(FLD_ACCESS_RIGHT,scrData.getProperty(vname));
			System.out.println(scrData.getProperty(vname));
			//scrData.setProperty(FLD_VAR_NAME,vardef.getColumn(rs,FLD_VAR_NAME));
			this.addStepVarAccess(scrData);
		}
		StepDefinition sd = new StepDefinition(scrData);
		//sd.updateStepDefinition(scrData);
	}
	
	/*
	 * Workflow variable definition section
	 */

	public void addWfVarDef(Properties scrData) {
		WfVarDef wvd = new WfVarDef(scrData);
	}
	// delete workflow variable definition
	public void delWfVarDef(String wf_id,String wf_ver,String var_name) {
		this.delStepVarAccessByVar(wf_id,wf_ver,var_name);
		WfVarDef wvd = new WfVarDef();
		wvd.delWfVarDefinition(wf_id,wf_ver,var_name);
	}
	//DbRecord
	public ResultSet getWfVarDef(String wf_id,String wf_ver,String var_name) {
		WfVarDef wvd = new WfVarDef();
		return wvd.getWfVarDef(wf_id,wf_ver,var_name);
	}
	//DbInquiry
	public ResultSet getWfVarDef(String wf_id,String wf_ver) {
		WfVarDef wvd = new WfVarDef();
		return wvd.getWfVarDef(wf_id,wf_ver);
	}
	public void updateWfVarDef(Properties scrData){
		Date d = new Date();
		//scrData.setProperty(FLD_UPDATE_BY," ");
		//scrData.setProperty(FLD_LAST_UPDATE,d.toLocaleString());
		WfVarDef wvd = new WfVarDef(scrData);
		//wvd.updateWfVarDef(scrData);
	}

	/*
	 * Transition Section
	 */
	public void addTransition(Properties scrData) {
		Transition tt = new Transition(scrData);
	}
	public ResultSet getTransition(String wf_id,String wf_ver) {
		Transition tt = new Transition();
		return tt.getTransition(wf_id,wf_ver);
	}
	public ResultSet getTo(String wf_id,String wf_ver,String step_id) {
		Transition tt = new Transition();
		return tt.getTo(wf_id,wf_ver,step_id);
	}
	public ResultSet getFrom(String wf_id,String wf_ver,String next_step_id) {
		Transition tt = new Transition();
		return tt.getFrom(wf_id,wf_ver,next_step_id);
	}
	public ResultSet getTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		Transition tt = new Transition();
		return tt.getTransition(wf_id,wf_ver,step_id,next_step_id);
	}
	public void delTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		Transition tt = new Transition();
		tt.delTransition(wf_id,wf_ver,step_id,next_step_id);
	}
	
	/*
	 * Incident section
	 */
	
	// Create New Incident
	public void createWorkflowIncident(Properties scrData) {
		WfIncMgmt wimg = new WfIncMgmt();
		wimg.createWfInc(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER));
		/*
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = "";//scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = "1";//scrData.getProperty(FLD_STEP_ID);
		// Database
		rs = this.getWorkflowDef(wf_id,wf_ver);
		long seq = 0;
		try {
			rs.next();
			seq = rs.getLong(FLD_LAST_SEQ);
			//Long.valueOf(rs.getString(FLD_LAST_SEQ)).longValue();
			seq++;
			super.initMyTable(TBL_WORKFLOW_DEFINITION);
			super.set(FLD_LAST_SEQ,seq);
			super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
			super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
			super.update();
			//SQL = "update workflow_definition set last_seq ="+seq+" where wf_id="+scrData.getProperty("wf_id")+"and wf_ver="+scrData.getProperty("wf_ver");
			//super.executeUpdate(SQL);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		wf_seq_no = String.valueOf(seq);
		scrData.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
		WorkflowIncident wi = new WorkflowIncident(scrData);
		// set Status of WorkflowIncident	
		scrData.setProperty("step_id","1");
		scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_ST_COMPLETE);
		//StepIncident si = new StepIncident(scrData);
		this.createStepIncident(scrData);
		
		rs = this.getWfVarDef(wf_id,wf_ver);
		//Properties p = new Properties();
		//scrData.setProperty(FLD_WF_ID,wf_id);
		//p.setProperty(FLD_WF_VER,wf_ver);
		scrData.setProperty(FLD_WF_SEQ_NO,String.valueOf(seq));
		//p.setProperty(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//p.setProperty(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		try {
			while (rs.next()) {
				String a = rs.getString(FLD_VAR_NAME);
				scrData.setProperty(FLD_VAR_NAME,a);
				scrData.setProperty(FLD_VAR_VALUE,scrData.getProperty(a));
				//p.setProperty(FLD_CHG_HISTORY,"0");
				this.createWorkflowVariable(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//p = new Properties();
		//p.setProperty(FLD_WF_ID,wf_id);
		//p.setProperty(FLD_WF_VER,wf_ver);
		//p.setProperty(FLD_WF_SEQ_NO,String.valueOf(seq));
		scrData.setProperty(FLD_STEP_ID,step_id);
		//scrData.setProperty(FLD_USER_CODE,scrData.getProperty(FLD_USER_CODE));
		//scrData.setProperty(FLD_POSITION_CODE,scrData.getProperty(FLD_POSITION_CODE));
		scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_AI_ACTIVE);
		scrData.setProperty(FLD_START_TIME,datetime);
		scrData.setProperty(FLD_COMPLETION_TIME,"1/1/2000 00:00:00");
		scrData.setProperty(FLD_COMMENT,scrData.getProperty(FLD_COMMENT));
		String actor_id = scrData.getProperty(FLD_USER_CODE);
		scrData.setProperty(FLD_ACTOR_ID,actor_id);
		String position_code = scrData.getProperty(FLD_POSITION_CODE);
		//ActorIncident ai = new ActorIncident(scrData);
		//wi = new WorkflowIncident();
		WfIncMgmt wim = new WfIncMgmt();
		//WfIncMgmt wimg = new WfIncMgmt();
		wim.approveAction(wf_id,wf_ver,wf_seq_no,step_id,actor_id,position_code," ");
		*/
	}
	public void createStepIncident(Properties scrData) {
		StepDefinition sd = new StepDefinition();
		sd.createStepIncident(scrData);
	}
	public void createWorkflowVariable(Properties scrData) {
		WfVarDef wvd = new WfVarDef();
		wvd.createWfVariable(scrData);
	}
	
	public ResultSet getStepVarAccess(String wf_id,String wf_ver,String step_id) {
		StepVarAccess stacc = new StepVarAccess();
		ResultSet rs = stacc.getStepVarAccess(wf_id,wf_ver,step_id);
		return rs;
	}
	public ResultSet getStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name) {
		StepVarAccess stacc = new StepVarAccess();
		ResultSet rs = stacc.getStepVarAccess(wf_id,wf_ver,step_id,var_name);
		return rs;
	}
	public void delStepVarAccessByWF(String wf_id,String wf_ver) {
		StepVarAccess stacc = new StepVarAccess();
		stacc.delStepVarAccessByWF(wf_id,wf_ver);
	}
	public void delStepVarAccessByVar(String wf_id,String wf_ver,String var_name) {
		StepVarAccess stacc = new StepVarAccess();
		stacc.delStepVarAccessByVar(wf_id,wf_ver,var_name);
	}
	public void delStepVarAccessByStep(String wf_id,String wf_ver,String step_id) {
		StepVarAccess stacc = new StepVarAccess();
		stacc.delStepVarAccessByVar(wf_id,wf_ver,step_id);
	}
	public void delStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name) {
		StepVarAccess stacc = new StepVarAccess();
		stacc.delStepVarAccess(wf_id,wf_ver,step_id,var_name);
	}
	public void addStepVarAccess(Properties scrData) {		
		StepVarAccess stacc = new StepVarAccess(scrData);
	}
	public void updateStepVarAccess(Properties scrData) {
		StepVarAccess stacc = new StepVarAccess(scrData);
	}
	public int getMaxStep(String wf_id,String wf_ver) {
		StepDefinition sd = new StepDefinition();
		int out = sd.getMaxStep(wf_id,wf_ver);
		return out;
	}
	public int getMaxWfID() {
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.setColumn("max(wf_id)");
		ResultSet rs = super.search();
		super.nextRecord(rs);
		int out = Integer.parseInt(super.getColumn(rs,"max(wf_id)"));
		return out;
	}
	public int getMaxWfVer(String wf_id) {
		super.initMyTable(TBL_WORKFLOW_DEFINITION);
		super.setColumn("max(wf_ver)");
		super.setFilter(FLD_WF_ID,wf_id);
		ResultSet rs = super.search();
		super.nextRecord(rs);
		int out = Integer.parseInt(super.getColumn(rs,"max(wf_ver)"));
		return out;
	}
	public String getStepForm(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		StepDefinition sd=new StepDefinition();
		return sd.getStepForm(wf_id,wf_ver,wf_seq_no,step_id);
	}
	public String genInitStepForm(String wf_id,String wf_ver,String step_id) {
		StepForm sf = new StepForm();
		return sf.genInitStepForm(wf_id,wf_ver,step_id);
	}
}