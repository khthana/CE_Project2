/*
 * Created on 11 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;

import java.sql.ResultSet;
import java.util.Properties;

import util.Database;
import util.DatabaseField;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class StepVarAccess extends Database implements DatabaseField{
	
	public StepVarAccess() {
		super("workflow");
	}
	public StepVarAccess(Properties scrData) {
		super("workflow");
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String var_name = scrData.getProperty(FLD_VAR_NAME);
		ResultSet rs = this.getStepVarAccess(wf_id,wf_ver,step_id,var_name);
		if (this.nextRecord(rs)) {
			this.updateStepVarAccess(scrData);
		} else {
			this.createStepVarAccess(scrData);
		}
	}
	private void createStepVarAccess(Properties scrData) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_ACCESS_RIGHT,Integer.parseInt(scrData.getProperty(FLD_ACCESS_RIGHT)));
		super.insert();
	}
	private void updateStepVarAccess(Properties scrData) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_ACCESS_RIGHT,Integer.parseInt(scrData.getProperty(FLD_ACCESS_RIGHT)));
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.setFilter(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.update();
	}
	public ResultSet getStepVarAccess(String wf_id,String wf_ver,String step_id) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		ResultSet rs = super.search();
		return rs;
	}
	public ResultSet getStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_VAR_NAME,var_name);
		ResultSet rs = super.search();
		return rs;
	}
	public void delStepVarAccessByStep(String wf_id,String wf_ver,String step_id) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.delete();
	}
	public void delStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(step_id));
		super.setFilter(FLD_VAR_NAME,var_name);
		super.delete();
	}
	public void delStepVarAccessByWF(String wf_id,String wf_ver) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.delete();
	}
	public void delStepVarAccessByVar(String wf_id,String wf_ver,String var_name) {
		super.initMyTable(TBL_STEP_VAR_ACCESS);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_VAR_NAME,var_name);
		super.delete();
	}
}
