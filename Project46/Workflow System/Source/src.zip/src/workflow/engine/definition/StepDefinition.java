/*
 * Created on 27 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
import util.MyCalendar;
import util.WorkflowControlData;
import workflow.engine.execution.ActorIncident;
import workflow.engine.execution.QueueTransfer;
import workflow.engine.execution.StepIncident;
import workflow.orgchart.ResolveActor;

public class StepDefinition extends Database implements DatabaseField, WorkflowControlData{
	//private ResultSet rs;
	//private String SQL;
	//private Transition t = null;
	//Properties step=new Properties();

	public StepDefinition(){	
		super("workflow");
	}
	public StepDefinition(Properties scrData){
		super("workflow");
		//this.step = scrData;
		ResultSet rs = this.getStepDef(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER),scrData.getProperty(FLD_STEP_ID));	
		try {
			if (!rs.next()) {
				this.createStepDefinition(scrData);
			} else {
				this.updateStepDefinition(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private void createStepDefinition(Properties scrData) {
		super.initMyTable(TBL_STEP_DEFINITION);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_STEP_NAME,scrData.getProperty(FLD_STEP_NAME));
		super.set(FLD_STEP_DESC,scrData.getProperty(FLD_STEP_DESC));
		super.set(FLD_STEP_TYPE,Integer.parseInt(scrData.getProperty(FLD_STEP_TYPE)));
		super.set(FLD_RECIPIENT_DEF,scrData.getProperty(FLD_RECIPIENT_DEF).trim());
		super.set(FLD_TASK_RATE,Long.parseLong(scrData.getProperty(FLD_TASK_RATE)));
		super.set(FLD_WEB_PAGE,scrData.getProperty(FLD_WEB_PAGE));
		super.set(FLD_AUTO_APPROVE,scrData.getProperty(FLD_AUTO_APPROVE));
		super.set(FLD_COMPLETE_SCRIPT,scrData.getProperty(FLD_COMPLETE_SCRIPT));
		super.set(FLD_RETURN_SCRIPT,scrData.getProperty(FLD_RETURN_SCRIPT));
		super.set(FLD_ATTACHED_STATUS,Integer.parseInt(scrData.getProperty(FLD_ATTACHED_STATUS)));
		super.set(FLD_COMPLETION_DURATION,Long.parseLong(scrData.getProperty(FLD_COMPLETION_DURATION)));
		super.set(FLD_EXTENSION_DURATION,Long.parseLong(scrData.getProperty(FLD_EXTENSION_DURATION)));
		super.set(FLD_DELAY_DURATION,Long.parseLong(scrData.getProperty(FLD_DELAY_DURATION)));
		super.set(FLD_ONLATE_NOTIFY,Long.parseLong(scrData.getProperty(FLD_ONLATE_NOTIFY)));//Long.parseLong(scrData.getProperty(FLD_ONLATE_NOTIFY)));
		//super.set(FLD_LAST_SEQ,Long.parseLong(scrData.getProperty(FLD_LAST_SEQ)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));		
		super.set(FLD_PRE_CONDITION,scrData.getProperty(FLD_PRE_CONDITION).trim());
		
		super.insert();
	}
	private void updateStepDefinition(Properties scrData) {
		super.initMyTable(TBL_STEP_DEFINITION);
		
		super.initMyTable(TBL_STEP_DEFINITION);
		super.set(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.set(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.set(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		super.set(FLD_STEP_NAME,scrData.getProperty(FLD_STEP_NAME));
		super.set(FLD_STEP_DESC,scrData.getProperty(FLD_STEP_DESC));
		super.set(FLD_STEP_TYPE,Integer.parseInt(scrData.getProperty(FLD_STEP_TYPE)));
		super.set(FLD_RECIPIENT_DEF,scrData.getProperty(FLD_RECIPIENT_DEF).trim());
		super.set(FLD_TASK_RATE,Long.parseLong(scrData.getProperty(FLD_TASK_RATE)));
		super.set(FLD_WEB_PAGE,scrData.getProperty(FLD_WEB_PAGE));
		super.set(FLD_AUTO_APPROVE,scrData.getProperty(FLD_AUTO_APPROVE));
		super.set(FLD_COMPLETE_SCRIPT,scrData.getProperty(FLD_COMPLETE_SCRIPT));
		super.set(FLD_RETURN_SCRIPT,scrData.getProperty(FLD_RETURN_SCRIPT));
		super.set(FLD_ATTACHED_STATUS,Integer.parseInt(scrData.getProperty(FLD_ATTACHED_STATUS)));
		super.set(FLD_COMPLETION_DURATION,Long.parseLong(scrData.getProperty(FLD_COMPLETION_DURATION)));
		super.set(FLD_EXTENSION_DURATION,Long.parseLong(scrData.getProperty(FLD_EXTENSION_DURATION)));
		super.set(FLD_DELAY_DURATION,Long.parseLong(scrData.getProperty(FLD_DELAY_DURATION)));
		super.set(FLD_ONLATE_NOTIFY,Long.parseLong(scrData.getProperty(FLD_ONLATE_NOTIFY)));//Long.parseLong(scrData.getProperty(FLD_ONLATE_NOTIFY)));
		//super.set(FLD_LAST_SEQ,Long.parseLong(scrData.getProperty(FLD_LAST_SEQ)));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));		
		super.set(FLD_PRE_CONDITION,scrData.getProperty(FLD_PRE_CONDITION).trim());
		
		super.setFilter(FLD_WF_ID,Integer.parseInt(scrData.getProperty(FLD_WF_ID)));
		super.setFilter(FLD_WF_VER,Integer.parseInt(scrData.getProperty(FLD_WF_VER)));
		super.setFilter(FLD_STEP_ID,Integer.parseInt(scrData.getProperty(FLD_STEP_ID)));
		
		super.update();
	}
	
	//DbInquiry
	public ResultSet getStepDef(String wf_id,String wf_ver) {
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setOrder(FLD_STEP_ID);
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_STEP_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver;
		//rs = super.executeQuery(SQL);
		return rs;
	}
	// return properties of stepdefinition in database
	//DbRecord
	public ResultSet getStepDef(String wf_id,String wf_ver,String step_id){
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_STEP_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id;
		//rs = super.executeQuery(SQL);	
		return rs;
	}
	/*
	// return all transition of step that have
	// DbInquiry
	public void addTransition(Properties scrData) {
		t = new Transition(scrData);
	}
	public void delTransition(String wf_id,String wf_ver,String step_id) {
		t = new Transition();
		t.delTransition(wf_id,wf_ver,step_id);
	}
	public void delTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		t = new Transition();
		t.delTransition(wf_id,wf_ver,step_id,next_step_id);
	}
	public ResultSet getTransition(String wf_id,String wf_ver,String step_id) {
		t = new Transition();
		rs = t.getTransition(wf_id,wf_ver,step_id);
		return rs;
	}
	public ResultSet getTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		t = new Transition();
		rs = t.getTransition(wf_id,wf_ver,step_id,next_step_id);
		return rs;
	}
	*/
	// return Form Html(JSP File) in the StepDefinition
	public String getStepForm(String wf_id,String wf_ver,String wf_seq_no,String step_id) {
		StepForm sf = new StepForm();
		return sf.getStepForm(wf_id,wf_ver,wf_seq_no,step_id);
	}
	// return Variable in each step
	// DbInquiry
	/*
	public ResultSet getVarDef(String wf_id,String wf_ver,String step_id) {
		WfVarDef wvd = new WfVarDef();
		rs = wvd.getWfVarDef(wf_id,wf_ver);
		MyInterpreter myi = new MyInterpreter(wf_id,wf_ver,step_id);
		try {
			while(rs.next()) {
				String a = rs.getString(FLD_CONDITION);
				a = (String)myi.executeScript(a);
				boolean res = Boolean.valueOf(a).booleanValue();
				if (res) {
					//rs.deleteRow();
				} else {
					rs.deleteRow();
				}
				// wrong command
				rs.refreshRow();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	public ResultSet getVarDef(String wf_id,String wf_ver,String step_id,String var_name) {
		WfVarDef wvd = new WfVarDef();
		rs = wvd.getWfVarDef(wf_id,wf_ver,var_name);
		MyInterpreter myi = new MyInterpreter(wf_id,wf_ver,step_id);
		try {
			String a = rs.getString(FLD_CONDITION);
			a = (String)myi.executeScript(a);
			boolean res = Boolean.valueOf(a).booleanValue();
			if (!res) {
				rs.deleteRow();
			}
			rs.refreshRow();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	*/
	// delete specific stepDefinition 
	public void delStepDef(String wf_id,String wf_ver) {
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.delete();
		//SQL = "delete from "+TBL_STEP_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver;
		//super.executeUpdate(SQL);
	}
	public void delStepDef(String wf_id,String wf_ver,String step_id) {
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.delete();
		//SQL = "delete from "+TBL_STEP_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id;
		//super.executeUpdate(SQL);
	}
	
	// Create New Incident
	public void createStepIncident(Properties scrData) {
		String datetime = MyCalendar.getDataTime();
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		//scrData.setProperty(FLD_START_TIME,d.toString()+" "+t.toString());
		//scrData.setProperty(FLD_LAST_UPDATE,d.toString()+" "+t.toString());
		StepIncident si = new StepIncident(scrData);
		//si = new StepIncident();
		ResolveActor ra = new ResolveActor();
		StepDefinition stdef = new StepDefinition();
		ActorIncident ai = new ActorIncident();
		ResultSet rs = si.getDefinition(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER),scrData.getProperty(FLD_STEP_ID));		
		try {
			rs.next();
			String recipient = si.getColumn(rs,FLD_RECIPIENT_DEF).trim();//rs.getString(FLD_RECIPIENT_DEF);
			Collection c = ra.getRefActor(recipient);
			Iterator i = c.iterator();
			while (i.hasNext()) {
				//Properties p = new Properties();
				//p.setProperty(FLD_WF_ID,wf_id);
				//p.setProperty(FLD_WF_VER,wf_ver);
				//p.setProperty(FLD_WF_SEQ_NO,scrData.getProperty(FLD_WF_SEQ_NO));
				//p.setProperty(FLD_STEP_ID,step_id);												
				//p.setProperty(FLD_STEP_SEQ_NO,"0");
				String element = (String) i.next();
				String act = element;//.substring(0,element.indexOf(" "));
				//String pos = element.substring(element.indexOf(" ")+1);
				scrData.setProperty(FLD_ACTOR_ID,act);//.substring(1));
				scrData.setProperty(FLD_POSITION_CODE,"");
				//p.setProperty(FLD_TFR_USER_CODE,"");
				//p.setProperty(FLD_OWNER_ACTOR_ID,"");
				scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_AI_ACTIVE);
				scrData.setProperty(FLD_START_TIME,datetime);
				scrData.setProperty(FLD_COMPLETION_TIME,"2000-01-01 00:00:00");
				//p.setProperty(FLD_LAST_UPDATE,datetime);
				scrData.setProperty(FLD_COMMENT,"");
				//StepDefinition stdef = new StepDefinition();
				stdef.createActorIncident(scrData);
			}
			ra = new ResolveActor();
			c = ra.getAllQueue(recipient);
			Iterator ii = c.iterator();
			while (ii.hasNext()) {
				//Properties p = new Properties();
				//p.setProperty(FLD_WF_ID,wf_id);
				//p./setProperty(FLD_WF_VER,wf_ver);
				//p.setProperty(FLD_WF_SEQ_NO,scrData.getProperty(FLD_WF_SEQ_NO));
				//p.setProperty(FLD_STEP_ID,step_id);												
				//p.setProperty(FLD_STEP_SEQ_NO,"0");
				String element = (String) ii.next();
				scrData.setProperty(FLD_QUEUE_CODE,element.substring(1));//.substring(1));
				//p.setProperty(FLD_PRIMARY_POSITION,)
				scrData.setProperty(FLD_TFR_ACTOR_ID,"");
				scrData.setProperty(FLD_OWNER_ACTOR_ID,ACTOR_ENGINE);//scrData.getProperty(FLD_USER_CODE));
				scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_QT_ACTIVE);
				scrData.setProperty(FLD_START_TIME,datetime);
				scrData.setProperty(FLD_COMPLETION_TIME,"1/1/2000 00:00:00");
				//p.setProperty(FLD_LAST_UPDATE,datetime);
				//p.setProperty(FLD_COMMENT,"");
				//StepDefinition stdef = new StepDefinition();
				QueueTransfer qt = new QueueTransfer(scrData);
				//stdef.createActorIncident(scrData);
			}
			ra = new ResolveActor();
			c = ra.getAllRole(recipient);
			Iterator iii = c.iterator();
			Database db = new Database("workflow");
			db.initMyTable(TBL_POSITION_USER);
			while (iii.hasNext()) {
				String element = (String) iii.next();
				//String actor_id = ra.getUserRole(element,scrData.getProperty(FLD_USER_CODE),scrData.getProperty(FLD_POSITION_CODE));
				String actor_id = "";
				String pos_code = "";//actor_id.substring(actor_id.indexOf(" ")+1);
				//actor_id = actor_id.substring(0,actor_id.indexOf(" "));
				if (element.substring(0,1).equals("I")) {
					ResultSet rs5 = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,"1");
					ai.nextRecord(rs5);
					String initiator = ai.getColumn(rs5,FLD_ACTOR_ID);
					db.setFilter(FLD_USER_CODE,initiator);
					ResultSet rs99 = db.search();
					db.nextRecord(rs99);
					pos_code = db.getColumn(rs99,FLD_POSITION_CODE);//ai.getColumn(rs5,FLD_POSITION_CODE);
					actor_id = ra.getUserRole(element,initiator,pos_code);
					pos_code = actor_id.substring(actor_id.indexOf(" ")+1);
					actor_id = actor_id.substring(0,actor_id.indexOf(" "));
				} else {
					actor_id = ra.getUserRole(element,scrData.getProperty(FLD_USER_CODE),scrData.getProperty(FLD_POSITION_CODE));
					pos_code = actor_id.substring(actor_id.indexOf(" ")+1);
					actor_id = actor_id.substring(0,actor_id.indexOf(" "));
				}
				scrData.setProperty(FLD_ACTOR_ID,actor_id);
				scrData.setProperty(FLD_POSITION_CODE,pos_code);
				scrData.setProperty(FLD_STATUS,WorkflowControlData.STATUS_AI_ACTIVE);
				scrData.setProperty(FLD_START_TIME,datetime);
				scrData.setProperty(FLD_COMPLETION_TIME,"1/1/2000 00:00:00");
				scrData.setProperty(FLD_COMMENT,"");
				//StepDefinition stdef = new StepDefinition();
				stdef.createActorIncident(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private void createActorIncident(Properties scrData) {
		ActorIncident ainc = new ActorIncident(scrData);
	}
	public int getMaxStep(String wf_id,String wf_ver) {
		int out = 0;
		super.initMyTable(TBL_STEP_DEFINITION);
		super.setColumn("max(step_id)");
		super.setFilter(FLD_WF_ID,wf_id);
		super.setFilter(FLD_WF_VER,wf_ver);
		ResultSet rs = super.search();
		super.nextRecord(rs);
		out = Integer.parseInt(super.getColumn(rs,"max(step_id)"));
		return out;
	}
}
