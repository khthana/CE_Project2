// change stepTo and stepFrom to null in the initialize state

/*
 * Created on 27 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import util.Database;
import util.DatabaseField;
public class Transition extends Database implements DatabaseField{
	//private ResultSet rs;
	//private String SQL;
	
	//Collection stepTo=null;
	//Collection stepFrom = null;
	//Condition cond;
	
	//Properties t_prop = new Properties();
	
	public Transition() {
		super("workflow");
	}
	public Transition(Properties scrData) {
		super("workflow");
		//this.t_prop = scrData;
		ResultSet rs = this.getTransition(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER),scrData.getProperty(FLD_STEP_ID),scrData.getProperty(FLD_NEXT_STEP_ID));	
		try {
			if (!rs.next()) {
				this.createTransition(scrData);
			} else {
				this.updateTransition(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}   
	
	private void createTransition(Properties scrData) {
		super.initMyTable(TBL_TRANSITION);
		
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_STEP_ID)).intValue());
		super.set(FLD_NEXT_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_NEXT_STEP_ID)).intValue());
		super.set(FLD_CONDITION,scrData.getProperty(FLD_CONDITION));
		super.set(FLD_ON_EVENT,scrData.getProperty(FLD_ON_EVENT));
		super.set(FLD_TRAN_DESC,scrData.getProperty(FLD_TRAN_DESC));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		
		super.insert();
	}
	private void updateTransition(Properties scrData) {
		super.initMyTable(TBL_TRANSITION);
		
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_STEP_ID)).intValue());
		super.set(FLD_NEXT_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_NEXT_STEP_ID)).intValue());
		super.set(FLD_CONDITION,scrData.getProperty(FLD_CONDITION));
		super.set(FLD_ON_EVENT,scrData.getProperty(FLD_ON_EVENT));
		super.set(FLD_TRAN_DESC,scrData.getProperty(FLD_TRAN_DESC));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		
		super.setFilter(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_STEP_ID)).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(scrData.getProperty(FLD_NEXT_STEP_ID)).intValue());
		
		super.update();
	}
	
	// return group of step_id
	// DbInquiry
	public ResultSet getTo(String wf_id,String wf_ver,String step_id){
		// get to step from stepId
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		ResultSet rs = super.search();
		return rs;
	}
	public ResultSet getTo(String wf_id,String wf_ver,String step_id,String event){
		// get to step from stepId
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.setFilter(FLD_ON_EVENT,Integer.parseInt(event));
		ResultSet rs = super.search();
		return rs;
	}
	// return group of step_id
	// DbInquiry
	public ResultSet getFrom(String wf_id,String wf_ver,String next_step_id){
		// get to from
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(next_step_id).intValue());
		ResultSet rs = super.search();
		return rs;
	}
	public ResultSet getFrom(String wf_id,String wf_ver,String next_step_id,String event){
		// get to from
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(next_step_id).intValue());
		super.setFilter(FLD_ON_EVENT,Integer.parseInt(event));
		ResultSet rs = super.search();
		return rs;
	}
	// return Condition in String
	public String getCondition(String wf_id,String wf_ver,String step_id,String next_step_id){
		// do get script
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(next_step_id).intValue());
		ResultSet rs = super.search();
		//SQL = "SELECT * FROM "+TBL_NEXT_STEP+" WHERE "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_NEXT_STEP_ID+"="+next_step_id+
		//		" and "+FLD_STEP_ID+"="+step_id;
		//rs = super.executeQuery(SQL);
		String result = super.getColumn(rs,FLD_CONDITION);
		return result;
	}
	// return transition of workflow
	public ResultSet getTransition(String wf_id,String wf_ver) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setOrder(FLD_STEP_ID);
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver;
		//rs = super.executeQuery(SQL);
		return rs;
	}
	public ResultSet getTransition(String wf_id,String wf_ver,String step_id) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id;
		//rs = super.executeQuery(SQL);
		return rs;
	}
	public ResultSet getTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(next_step_id).intValue());
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id+" and "+
		//		FLD_NEXT_STEP_ID+"="+next_step_id;
		//rs = super.executeQuery(SQL);
		return rs;
	}
	// delete Transition
	public void delTransition(String wf_id,String wf_ver) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.delete();
		//SQL = "delete from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver;
		//super.executeUpdate(SQL);
	}
	public void delTransition(String wf_id,String wf_ver,String step_id) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.delete();
		//SQL = "delete from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id;
		//super.executeUpdate(SQL);
	}
	public void delTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		super.initMyTable(TBL_TRANSITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_STEP_ID,Integer.valueOf(step_id).intValue());
		super.setFilter(FLD_NEXT_STEP_ID,Integer.valueOf(next_step_id).intValue());
		super.delete();
		//SQL = "delete from "+TBL_NEXT_STEP+" where "+FLD_WF_ID+"="+wf_id+" and "+
		//		FLD_WF_VER+"="+wf_ver+" and "+FLD_STEP_ID+"="+step_id+
		//		" and "+FLD_NEXT_STEP_ID+"="+next_step_id;
		//super.executeUpdate(SQL);
	}
}