/*
 * Created on 27 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.engine.definition;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.Date;
import java.util.Properties;
//import java.util.Timer;

import util.Database;
import util.DatabaseField;
import workflow.engine.execution.WorkflowVariable;


public class WfVarDef extends Database implements DatabaseField {
	//private ResultSet rs;
	//private String SQL;
	
	//private Properties wfVariable = new Properties();
	
	public WfVarDef() {
		super("workflow");
	}
	public WfVarDef(Properties scrData) {
		super("workflow");
		//this.wfVariable = scrData;
		ResultSet rs = this.getWfVarDef(scrData.getProperty(FLD_WF_ID),scrData.getProperty(FLD_WF_VER),scrData.getProperty(FLD_VAR_NAME));
		try {
			if (!rs.next()) {
				this.createWfVarDef(scrData);
			} else {
				this.updateWfVarDef(scrData);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createWfVarDef(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_VAR_DESC_THAI,scrData.getProperty(FLD_VAR_DESC_THAI));
		super.set(FLD_VAR_DESC_ENG,scrData.getProperty(FLD_VAR_DESC_ENG));
		super.set(FLD_HINT,scrData.getProperty(FLD_HINT));
		//super.set(FLD_CONDITION,scrData.getProperty(FLD_CONDITION));
		super.set(FLD_VAR_TYPE,Integer.parseInt(scrData.getProperty(FLD_VAR_TYPE)));
		super.set(FLD_INIT_VALUE,scrData.getProperty(FLD_INIT_VALUE));
		super.set(FLD_VALIDATE_CLASS,scrData.getProperty(FLD_VALIDATE_CLASS));
		super.set(FLD_NULLABLE,Integer.parseInt(scrData.getProperty(FLD_NULLABLE)));//Boolean.valueOf(scrData.getProperty(FLD_NULLABLE)).booleanValue());
		//super.set(FLD_TAG_TYPE,scrData.getProperty(FLD_TAG_TYPE));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.set(FLD_ENCRYPT,Integer.parseInt(scrData.getProperty(FLD_ENCRYPT)));//Boolean.valueOf(scrData.getProperty(FLD_ENCRYPT)).booleanValue());
		//super.set(FLD_ACCESS_RIGHT,Integer.valueOf(scrData.getProperty(FLD_ACCESS_RIGHT)).intValue());
		super.set(FLD_INPUT_TYPE,Integer.parseInt(scrData.getProperty(FLD_INPUT_TYPE)));
		super.set(FLD_INPUT_VALUE,scrData.getProperty(FLD_INPUT_VALUE));
		
		super.insert();
	}
	private void updateWfVarDef(Properties scrData) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		
		super.set(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.set(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.set(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		super.set(FLD_VAR_DESC_THAI,scrData.getProperty(FLD_VAR_DESC_THAI));
		super.set(FLD_VAR_DESC_ENG,scrData.getProperty(FLD_VAR_DESC_ENG));
		super.set(FLD_HINT,scrData.getProperty(FLD_HINT));
		//super.set(FLD_CONDITION,scrData.getProperty(FLD_CONDITION));
		super.set(FLD_VAR_TYPE,Integer.parseInt(scrData.getProperty(FLD_VAR_TYPE)));
		super.set(FLD_INIT_VALUE,scrData.getProperty(FLD_INIT_VALUE));
		super.set(FLD_VALIDATE_CLASS,scrData.getProperty(FLD_VALIDATE_CLASS));
		super.set(FLD_NULLABLE,Integer.parseInt(scrData.getProperty(FLD_NULLABLE)));//Boolean.valueOf(scrData.getProperty(FLD_NULLABLE)).booleanValue());
		//super.set(FLD_TAG_TYPE,scrData.getProperty(FLD_TAG_TYPE));
		//super.set(FLD_LAST_UPDATE,scrData.getProperty(FLD_LAST_UPDATE));
		//super.set(FLD_UPDATE_BY,scrData.getProperty(FLD_UPDATE_BY));
		super.set(FLD_ENCRYPT,Integer.parseInt(scrData.getProperty(FLD_ENCRYPT)));//Boolean.valueOf(scrData.getProperty(FLD_ENCRYPT)).booleanValue());
		//super.set(FLD_ACCESS_RIGHT,Integer.valueOf(scrData.getProperty(FLD_ACCESS_RIGHT)).intValue());
		super.set(FLD_INPUT_TYPE,Integer.parseInt(scrData.getProperty(FLD_INPUT_TYPE)));
		super.set(FLD_INPUT_VALUE,scrData.getProperty(FLD_INPUT_VALUE));
		
		super.setFilter(FLD_WF_ID,Integer.valueOf(scrData.getProperty(FLD_WF_ID)).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(scrData.getProperty(FLD_WF_VER)).intValue());
		super.setFilter(FLD_VAR_NAME,scrData.getProperty(FLD_VAR_NAME));
		
		super.update();
	}
	/*
	// return Name of Variable
	public String getName(String wf_id,String wf_ver,String var_name) {
		return new String();
	}
	// return Value of Variable by identifier
	public String getVarValue(String wf_id,String wf_var,String wf_seq_no,String var_name) {
		return new String();
	}
	*/
	// return properties of Variable
	// DbInquiry of properties of workflow variable definition
	public ResultSet getWfVarDef(String wf_id,String wf_ver) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setOrder(FLD_VAR_NAME);
		ResultSet rs = super.search();
		//SQL = "select * from "+TBL_WORKFLOW_VAR_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+
		//		" and "+FLD_WF_VER+"="+wf_ver;
		//rs = super.executeQuery(SQL);
		return rs;
	}
	// DbRecord
	public ResultSet getWfVarDef(String wf_id,String wf_ver,String var_name) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.parseInt(wf_id));
		super.setFilter(FLD_WF_VER,Integer.parseInt(wf_ver));
		super.setFilter(FLD_VAR_NAME,var_name);
		ResultSet rs = super.search();
		//SQL = "SELECT * FROM "+TBL_WORKFLOW_VAR_DEFINITION+" WHERE "+FLD_WF_ID+"="+
		//		wf_id+" and "+FLD_WF_VER+"="+wf_ver+" and "+FLD_VAR_NAME+"='"+
		//		var_name+"'";
		//rs = super.executeQuery(SQL);
		return rs;
	}
	//delete WfVarDef
	public void delWfVarDefinition(String wf_id,String wf_ver,String var_name) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.setFilter(FLD_VAR_NAME,var_name);
		super.delete();
		//SQL = "delete from "+TBL_WORKFLOW_VAR_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+
		//			" and "+FLD_WF_VER+"="+wf_ver+" and "+FLD_VAR_NAME+"="+var_name;
		//super.executeUpdate(SQL);
	}
	public void delWfVarDef(String wf_id,String wf_ver) {
		super.initMyTable(TBL_WORKFLOW_VAR_DEFINITION);
		super.setFilter(FLD_WF_ID,Integer.valueOf(wf_id).intValue());
		super.setFilter(FLD_WF_VER,Integer.valueOf(wf_ver).intValue());
		super.delete();
		//SQL = "delete from "+TBL_WORKFLOW_VAR_DEFINITION+" where "+FLD_WF_ID+"="+wf_id+
		//		" and "+FLD_WF_VER+"="+wf_ver;
		//super.executeUpdate(SQL);
	}
	public void createWfVariable(Properties scrData) {
		//Date d = new Date();
		//Timer t = new Timer();
		//scrData.setProperty(FLD_UPDATE_BY,"");
		//scrData.setProperty(FLD_LAST_UPDATE,d.toString()+" "+t.toString());
		//scrData.setProperty(FLD_CHG_HISTORY,"");
		WorkflowVariable wv = new WorkflowVariable(scrData);
	}
}
