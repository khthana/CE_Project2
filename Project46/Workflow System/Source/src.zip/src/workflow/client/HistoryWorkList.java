/*
 * Created on 6 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.client;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Vector;

import util.Database;
import util.DatabaseField;
import util.WorkflowControlData;
import workflow.client.Wk;
/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HistoryWorkList implements DatabaseField,WorkflowControlData{
	private Wk wk;
	private WfIncOperation wfinc;
	public HistoryWorkList(){
		wk=new Wk();
		wfinc=new WfIncOperation();
	}
	public Collection getIncomingWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		Database db=new Database("workflow");		
		db.initMyTable(TBL_ACTOR_INCIDENT); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		//  get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_POSITION_CODE);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMPLETION_TIME);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STATUS);
			// condition join
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_SEQ_NO);
			// set filter
		String set1="("+STATUS_WF_COMPLETE+","+STATUS_WF_ABORT+","+STATUS_WF_ACTIVE+")";
		db.setFilterIn(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,set1);// active incident
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_ACTOR_ID,user_code);   // by user_code
			// set order by
		db.setOrder(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		rs=db.search();  // execute
		while ( db.nextRecord(rs) ){
			if( !db.getColumn(rs,FLD_STEP_ID).equals("1")){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_START_TIME));
			wk.setComment(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_COMMENT));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID)); 
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setCompleteDate(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_COMPLETION_TIME));
			wk.setStatus(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_STATUS));
			v.addElement(wk);
			}
		}
		return v;
	}
	public Collection getInitWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		Database db=new Database("workflow");		
		db.initMyTable(TBL_ACTOR_INCIDENT); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		//  get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_COMPLETION_TIME);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STATUS);
		//db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_POSITION_CODE);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMPLETION_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS);
		
			// condition join
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_SEQ_NO);
			// set filter
		String set1="("+STATUS_WF_COMPLETE+","+STATUS_WF_ABORT+","+STATUS_WF_ACTIVE+")";
		db.setFilterIn(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,set1);// active incident
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR,user_code);   // by user_code
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID,"1");   // by user_code
			// set order by
		db.setOrder(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		rs=db.search();  // execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_START_TIME));
			wk.setComment(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_COMMENT));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID)); 
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setCompleteDate(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_COMPLETION_TIME));
			wk.setStatus(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS));
			v.addElement(wk);
		}
		return v;
	}
	public Collection getHistAssigningWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		Database db=new Database("workflow");		
		db.initMyTable(TBL_ACTOR_INCIDENT); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		//  get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_POSITION_CODE);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMPLETION_TIME);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STATUS);
			// condition join
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_SEQ_NO);
			// set filter
		String set1="("+STATUS_WF_COMPLETE+","+STATUS_WF_ABORT+","+STATUS_WF_ACTIVE+")";
		db.setFilterIn(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,set1);// active incident
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_ACTOR_ID,user_code);   // by user_code
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_STATUS,STATUS_AI_ASSIGN);   // by user_code
			// set order by
		db.setOrder(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		rs=db.search();  // execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_START_TIME));
			wk.setComment(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_COMMENT));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID)); 
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setCompleteDate(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_COMPLETION_TIME));
			wk.setStatus(db.getColumn(rs,TBL_ACTOR_INCIDENT+"."+FLD_STATUS));
			v.addElement(wk);
		}
		return v;
	}

	public Collection getTrack(String wf_id,String wf_ver,String wf_seq_no){
		return wfinc.getStepInc(wf_id,wf_ver,wf_seq_no);
	}
	
	public Collection searchHist(String fields,String col){
		return new Vector();
	}
	public Collection SortBy(String field){
		return new Vector();
	}
}