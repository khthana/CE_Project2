/*
 * Created on 4 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.client;
/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.util.*;

import util.*;
import workflow.orgchart.Membership;

public class WHandle implements DatabaseField,WorkflowControlData{
	private Wk wk;
	private WfIncOperation wfinc; 
	public WHandle(){
		wfinc=new WfIncOperation();
		wk=new Wk();
	}
	public Collection getMyWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		Database db=new Database("workflow");
		db.initMyTable(TBL_ACTOR_INCIDENT); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		//  get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		//db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_POSITION_CODE);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		// condition join
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_SEQ_NO);
		// set filter
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_AI_ACTIVE));// active incident
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_WF_ACTIVE));
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_ACTOR_ID,user_code);

		db.setOrder(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		rs=db.search();  // execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,FLD_START_TIME));
			wk.setComment(db.getColumn(rs,FLD_COMMENT));
			//wk.setPosition(db.getColumn(rs,FLD_POSITION_CODE));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,FLD_STEP_ID)); 
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			v.addElement(wk);
		}
		return v;
	}
	public Collection getQueueWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		String set="";
		Membership ms=new Membership();
		Database db=new Database("workflow");
		Collection q=ms.getAllQMember(user_code);
		Iterator i = q.iterator();
		Properties prop=new Properties();
		Properties key_pair=new Properties();
		set+="(";
		int count=0;
		while (i.hasNext()){
			count++;
			prop=(Properties)i.next();
			set+="'"+prop.getProperty(FLD_QUEUE_CODE)+"',";
			//key_pair.setProperty(prop.getProperty(FLD_QUEUE_CODE),prop.getProperty(FLD_POSITION_CODE));
		}
		if( count>0 )
			set=set.substring(0,set.lastIndexOf(','))+')';// delete last ',' and terminate with ')'
		db.initMyTable(TBL_QUEUE_TRANSFER); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		// get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_STEP_ID);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE);
		// set join condition
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_SEQ_NO);
		// set filter
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_STATUS,Integer.parseInt(STATUS_QT_ACTIVE));
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_WF_ACTIVE));
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_OWNER_ACTOR_ID,ACTOR_ENGINE);
		if( count > 0) // have queue
			db.setFilterIn(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE,set);
		System.out.println(set);
		db.setOrder(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);

		rs=db.search();// execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,FLD_START_TIME));
			//wk.setComment(db.getColumn(rs,FLD_COMMENT));
			wk.setComment("");
			//wk.setPosition(key_pair.getProperty(db.getColumn(rs,FLD_QUEUE_CODE)));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,FLD_STEP_ID));
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setQueue(db.getColumn(rs,FLD_QUEUE_CODE));
			v.addElement(wk);
		}
		return v;
	}
	public Collection getAssigningWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		String set="";
		Database db=new Database("workflow");
		
		db.initMyTable(TBL_QUEUE_TRANSFER); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		// get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_STEP_ID);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE);
		// set join condition
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_SEQ_NO);
		// set filter
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_STATUS,Integer.parseInt(STATUS_QT_ACTIVE));
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_WF_ACTIVE));
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE,QASSIGN);
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_OWNER_ACTOR_ID,user_code);
		
		db.setOrder(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);

		rs=db.search();// execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,FLD_START_TIME));
			//wk.setComment(db.getColumn(rs,FLD_COMMENT));
			wk.setComment("NO COMMENT");
			//wk.setPosition(key_pair.getProperty(db.getColumn(rs,FLD_QUEUE_CODE)));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,FLD_STEP_ID));
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setQueue(db.getColumn(rs,FLD_QUEUE_CODE));
			v.addElement(wk);
		}
		return v;
	}
	public Collection getAssignedWork(String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		String set="";
		Database db=new Database("workflow");
		
		db.initMyTable(TBL_QUEUE_TRANSFER); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		// get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_STEP_ID);
		db.setColumn(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE);
		
		// set join condition
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_QUEUE_TRANSFER+"."+FLD_WF_SEQ_NO);
		// set filter
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_STATUS,Integer.parseInt(STATUS_QT_ACTIVE));
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_WF_ACTIVE));
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_QUEUE_CODE,QASSIGN);
		db.setFilter(TBL_QUEUE_TRANSFER+"."+FLD_TFR_ACTOR_ID,user_code);
		
		
		db.setOrder(TBL_QUEUE_TRANSFER+"."+FLD_START_TIME);

		rs=db.search();// execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,FLD_START_TIME));
			//wk.setComment(db.getColumn(rs,FLD_COMMENT));
			wk.setComment("");
			//wk.setPosition(key_pair.getProperty(db.getColumn(rs,FLD_QUEUE_CODE)));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,FLD_STEP_ID));
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			wk.setQueue(db.getColumn(rs,FLD_QUEUE_CODE));
			v.addElement(wk);
		}
		return v;
	}
	public Collection search(String keyword,String field,String user_code){
		ResultSet rs=null;
		Vector v=new Vector();
		Database db=new Database("workflow");
		db.initMyTable(TBL_ACTOR_INCIDENT); // init my table
		db.joinTable(TBL_WORKFLOW_INCIDENT);
		db.joinTable(TBL_WORKFLOW_DEFINITION);
		//  get specific column
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SHORT_CODE);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO);
		db.setColumn(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		db.setColumn(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		db.setColumn(TBL_ACTOR_INCIDENT+"."+FLD_COMMENT);
		// condition join
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_ID+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_ID);
		db.setJoinCondition(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_VER+"="+TBL_WORKFLOW_INCIDENT+"."+FLD_WF_VER);
		db.setJoinCondition(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO+"="+TBL_ACTOR_INCIDENT+"."+FLD_WF_SEQ_NO);
		// set filter
		/*
		 * all
ref_no
wf_name
subject
initiate
commingDate
priority
step
	  if(!columnname.equalsIgnoreCase("ALL"))
	  {
		 sql = "select * ";
		 sql+=" from subj where Upper(" + columnname + ") LIKE '%" +keyword+ "%'";		 
	  }else{
		 sql = "select * ";
		 sql +=" from subj where ((Upper(subj_code) LIKE '%" +keyword + "%')OR";
		 sql += "(Upper(subj_thai) LIKE '%" +keyword + "%')OR";
		 sql += "(Upper(subj_eng) LIKE '%" +keyword + "%')OR";
		 sql += "(Upper(credit) LIKE '%" +keyword + "%')OR";
		 sql += "(Upper(description) LIKE '%" +keyword + "%'))";		 
	  }

		*/
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_AI_ACTIVE));// active incident
		db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_STATUS,Integer.parseInt(STATUS_WF_ACTIVE));
		db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_ACTOR_ID,user_code);
		if( !field.equalsIgnoreCase("ALL") ){
			if( field.equals("ref_no") ){
				//db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_Short_code,keyword);
				//db.setOrFilterLike(TBL_WORKFLOW_INCIDENT+"."+FLD_WF_SEQ_NO,keyword);
			}else if( field.equals(FLD_WF_NAME) )
				db.setFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME,keyword);
			else if( field.equals(FLD_SUBJECT) )
				db.setFilterLike(TBL_WORKFLOW_INCIDENT+"."+FLD_SUBJECT,keyword);
			else if( field.equals(FLD_INITIATOR) )
				db.setFilterLike(TBL_WORKFLOW_INCIDENT+"."+FLD_INITIATOR,keyword);
			else if( field.equals(FLD_START_TIME) )
				db.setFilterLike(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME,keyword);
			else if( field.equals(FLD_PRIORITY) )
				db.setFilter(TBL_WORKFLOW_INCIDENT+"."+FLD_PRIORITY,Integer.parseInt(keyword));
			else if( field.equals(FLD_STEP_ID) )
				db.setFilter(TBL_ACTOR_INCIDENT+"."+FLD_STEP_ID,Integer.parseInt(keyword));
		}else{
			/*
			 * request 2 method 
			 *    1) setOrFilterLike
			 * 	  2) setOrFilter
			 * 
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_Short_code,keyword);
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_SEQ_NO,keyword);
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_WF_NAME,keyword);
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_SUBJECT,keyword);
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_INITIATOR,keyword);
			 * db.setOrFilterLike(TBL_WORKFLOW_DEFINITION+"."+FLD_START_TIME,keyword);
			 * db.setOrFilter(TBL_WORKFLOW_DEFINITION+"."+FLD_PRIORITY,Integer.parseInt(keyword));
			 * db.setOrFilter(TBL_WORKFLOW_DEFINITION+"."+FLD_STEP_ID,Integer.parseInt(keyword));
			*/
		}
		// set order by
		db.setOrder(TBL_ACTOR_INCIDENT+"."+FLD_START_TIME);
		rs=db.search();  // execute
		while ( db.nextRecord(rs) ){
			wk=new Wk();
			wk.setWfId(db.getColumn(rs,FLD_WF_ID));
			wk.setWfVer(db.getColumn(rs,FLD_WF_VER));
			wk.setWfSeqNo(db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setRefNo(db.getColumn(rs,FLD_WF_SHORT_CODE)+db.getColumn(rs,FLD_WF_SEQ_NO));
			wk.setCommingDate(db.getColumn(rs,FLD_START_TIME));
			wk.setComment(db.getColumn(rs,FLD_COMMENT));
			//wk.setPosition(db.getColumn(rs,FLD_POSITION_CODE));
			wk.setInitiate(db.getColumn(rs,FLD_INITIATOR));
			wk.setPriority(db.getColumn(rs,FLD_PRIORITY));
			wk.setStepId(db.getColumn(rs,FLD_STEP_ID)); 
			wk.setWDName(db.getColumn(rs,FLD_WF_NAME));
			wk.setSubject(db.getColumn(rs,FLD_SUBJECT));
			v.addElement(wk);
		}
		return v;
	}
	public Collection SortBy(String field){
		return new Vector();
	}
}