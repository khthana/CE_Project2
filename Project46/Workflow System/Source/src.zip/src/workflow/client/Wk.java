/*
 * Created on 5 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.client;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Wk {
	private String wf_id;
	private String wf_ver;
	private String wf_seq_no;
	private String ref_no;
	private String wf_name;
	private String subject;
	private String initiate;
	private String commingDate;
	private String completeDate;
	private String stepId;
	private String priority;
	private String comment;
	private String position;
	private String status;
	private String queue_code;
	public Wk(){
	}
	public void setWfId(String wf_id){
		this.wf_id=wf_id;
	}
	public String getWfId(){
		return this.wf_id;
	}
	public void setWfVer(String wf_ver){
		this.wf_ver=wf_ver;
	}
	public String getWfVer(){
		return this.wf_ver;
	}
	public void setWfSeqNo(String wf_seq_no){
		this.wf_seq_no=wf_seq_no;
	}
	public String getWfSeqNo(){
		return this.wf_seq_no;
	}
	public void setRefNo(String ref_no){
		this.ref_no=ref_no;
	}
	public String getWkRefNo(){
		return this.ref_no;
	}
	public void setWDName(String wf_name){
		this.wf_name=wf_name;
	}
	public String getWDName(){
		return this.wf_name;
	}
	public void setSubject(String subject){
		this.subject=subject;
	}
	public String getSubject(){
		return this.subject;
	}
	public void setInitiate(String initiate){
		this.initiate=initiate;
	}
	public String getInitiate(){
		return this.initiate;
	}
	public void setCommingDate(String comming){
		this.commingDate=comming;
	}
	public String getCommingDate(){
		return this.commingDate;
	}
	public void setPriority(String priority){
		this.priority = priority;
	}
	public String getPriority(){
		return this.priority;
	}
	public void setStepId(String id){
		this.stepId=id;
	}
	public String getStepId(){
		return this.stepId;
	}
	public void setComment(String com){
		this.comment=com;
	}
	public String getComment(){
		return this.comment;
	}
	public String getCompleteDate(){
		return this.completeDate;
	}
	public void setCompleteDate(String completeDate){
		this.completeDate=completeDate;
	}
	public String getStatus(){
		return this.status;
	}
	public void setStatus(String status){
		this.status=status;
	}
	
	public void setQueue(String q){
		this.queue_code=q;
	}
	
	
	public String getQueue(){
		return this.queue_code;
	}
}