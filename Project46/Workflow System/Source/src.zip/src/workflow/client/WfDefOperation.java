/*
 * Created on 23 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.client;

import java.sql.ResultSet;
import java.util.*;
import util.DatabaseField;
import util.WorkflowControlData;
import workflow.engine.definition.WorkflowDefinition;
import workflow.orgchart.ResolveActor;
/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WfDefOperation implements WorkflowControlData,DatabaseField{
	private WorkflowDefinition wd;
	private ResolveActor ra;
	public WfDefOperation(){
		wd=new WorkflowDefinition();
		ra=new ResolveActor();
	}
	public Collection getAllWfDefList(String user_code){
		String actor_def="",curent_use="";
		Vector wf=new Vector();
		Properties p=new Properties();
		ResultSet rs=wd.getWorkflowDef();
		try{
		while( rs.next() ){
			actor_def=rs.getString(FLD_INITIATOR_DEF);
			curent_use=rs.getString(FLD_CURRENT_USE);
			if(  ra.isMemberActorDef(user_code,actor_def) && curent_use.equals("1") ){// avaliable
				p=new Properties();
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_WF_NAME,rs.getString(FLD_WF_NAME));
				p.setProperty(FLD_WF_SHORT_CODE,rs.getString(FLD_WF_SHORT_CODE));
				p.setProperty(FLD_WF_OBJECTIVE,rs.getString(FLD_WF_OBJECTIVE));
				p.setProperty(FLD_WF_RULE,rs.getString(FLD_WF_RULE));
				p.setProperty(FLD_COMPLETION_DURATION,rs.getString(FLD_COMPLETION_DURATION));
				p.setProperty(FLD_EXTENSION_DURATION,rs.getString(FLD_EXTENSION_DURATION));
				p.setProperty(FLD_INITIATOR_DEF,actor_def);
				p.setProperty(FLD_INITIATE_TIME,rs.getString(FLD_INITIATE_TIME));
				p.setProperty(FLD_SCHEDULE,rs.getString(FLD_SCHEDULE));
				p.setProperty(FLD_LAST_SEQ,rs.getString(FLD_LAST_SEQ));
				p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
				p.setProperty(FLD_END_TIME,rs.getString(FLD_END_TIME));
				p.setProperty(FLD_PRIORITY,rs.getString(FLD_PRIORITY));
				p.setProperty(FLD_ABORT_SCRIPT,rs.getString(FLD_ABORT_SCRIPT));
				p.setProperty(FLD_TAKEOVER_RIGHT,rs.getString(FLD_TAKEOVER_RIGHT));
				p.setProperty(FLD_DIFFICULT_LEVEL,rs.getString(FLD_DIFFICULT_LEVEL));
				p.setProperty(FLD_WF_DESC,rs.getString(FLD_WF_DESC));
				p.setProperty(FLD_CURRENT_USE,curent_use);
				wf.addElement(p);
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return wf;
	}
	public Properties getWfDefDetail(String wf_id,String wf_ver){
		Properties p=new Properties();
		ResultSet rs=wd.getWorkflowDef(wf_id,wf_ver);
		try{
		if( rs.next() ){
			p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
			p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
			p.setProperty(FLD_WF_NAME,rs.getString(FLD_WF_NAME));
			p.setProperty(FLD_WF_SHORT_CODE,rs.getString(FLD_WF_SHORT_CODE));
			p.setProperty(FLD_WF_OBJECTIVE,rs.getString(FLD_WF_OBJECTIVE));
			p.setProperty(FLD_WF_RULE,rs.getString(FLD_WF_RULE));
			p.setProperty(FLD_COMPLETION_DURATION,rs.getString(FLD_COMPLETION_DURATION));
			p.setProperty(FLD_EXTENSION_DURATION,rs.getString(FLD_EXTENSION_DURATION));
			p.setProperty(FLD_INITIATOR_DEF,rs.getString(FLD_INITIATOR_DEF));
			p.setProperty(FLD_INITIATE_TIME,rs.getString(FLD_INITIATE_TIME));
			p.setProperty(FLD_SCHEDULE,rs.getString(FLD_SCHEDULE));
			p.setProperty(FLD_LAST_SEQ,rs.getString(FLD_LAST_SEQ));
			p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
			p.setProperty(FLD_END_TIME,rs.getString(FLD_END_TIME));
			p.setProperty(FLD_PRIORITY,rs.getString(FLD_PRIORITY));
			p.setProperty(FLD_ABORT_SCRIPT,rs.getString(FLD_ABORT_SCRIPT));
			p.setProperty(FLD_TAKEOVER_RIGHT,rs.getString(FLD_TAKEOVER_RIGHT));
			p.setProperty(FLD_DIFFICULT_LEVEL,rs.getString(FLD_DIFFICULT_LEVEL));
			p.setProperty(FLD_WF_DESC,rs.getString(FLD_WF_DESC));
			p.setProperty(FLD_CURRENT_USE,rs.getString(FLD_CURRENT_USE));
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return p;
	}
	public String getStepForm(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		String form=wd.getStepForm(wf_id,wf_ver,wf_seq_no,step_id);
		return form;
	}
	public Properties getStepDef(String wf_id,String wf_ver,String step_id){
		Properties p=new Properties();
		ResultSet rs=wd.getStepDefinition(wf_id,wf_ver,step_id);
		try{
			while(rs.next()){
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				p.setProperty(FLD_STEP_NAME,rs.getString(FLD_STEP_NAME));
				p.setProperty(FLD_STEP_DESC,rs.getString(FLD_STEP_DESC));
				p.setProperty(FLD_STEP_TYPE,rs.getString(FLD_STEP_TYPE));
				p.setProperty(FLD_RECIPIENT_DEF,rs.getString(FLD_RECIPIENT_DEF));
				p.setProperty(FLD_TASK_RATE,rs.getString(FLD_TASK_RATE));
				p.setProperty(FLD_WEB_PAGE,rs.getString(FLD_WEB_PAGE));
				p.setProperty(FLD_AUTO_APPROVE,rs.getString(FLD_AUTO_APPROVE));
				p.setProperty(FLD_COMPLETE_SCRIPT,rs.getString(FLD_COMPLETE_SCRIPT));
				p.setProperty(FLD_RETURN_SCRIPT,rs.getString(FLD_RETURN_SCRIPT));
				p.setProperty(FLD_ATTACHED_STATUS,rs.getString(FLD_ATTACHED_STATUS));
				p.setProperty(FLD_COMPLETION_DURATION,rs.getString(FLD_COMPLETION_DURATION));
				p.setProperty(FLD_EXTENSION_DURATION,rs.getString(FLD_EXTENSION_DURATION));
				p.setProperty(FLD_DELAY_DURATION,rs.getString(FLD_DELAY_DURATION));
				p.setProperty(FLD_ONLATE_NOTIFY,rs.getString(FLD_ONLATE_NOTIFY));
				p.setProperty(FLD_PRE_CONDITION,rs.getString(FLD_PRE_CONDITION));
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			return p;
		}
		public Collection getStepVariable(String wf_id,String wf_ver,String step_id){
			Vector v=new Vector();
			Properties p=null;
			String var_acc="";
			Collection c=getWorkflowVarDef(wf_id,wf_ver);
			Iterator i=c.iterator();
			while( i.hasNext() ){
				p=(Properties)i.next();
				var_acc=getStepVarAccess(wf_id,wf_ver,step_id,p.getProperty(FLD_VAR_NAME));
				// get read write
				if( var_acc.equals(READ_WRITE) ){
					v.addElement(p.getProperty(FLD_VAR_NAME));
				}
			}
			return v;
		}
	private Collection getWorkflowVarDef(String wf_id,String wf_ver){
		Vector v=new Vector();
		Properties p=null;
		ResultSet rs=wd.getWfVarDef(wf_id,wf_ver);
		try{
		while( rs.next() ){
				p=new Properties();
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_VAR_NAME,rs.getString(FLD_VAR_NAME));
				p.setProperty(FLD_VAR_DESC_THAI,rs.getString(FLD_VAR_DESC_THAI));
				p.setProperty(FLD_VAR_DESC_ENG,rs.getString(FLD_VAR_DESC_ENG));
				p.setProperty(FLD_HINT,rs.getString(FLD_HINT));
				p.setProperty(FLD_VAR_TYPE,rs.getString(FLD_VAR_TYPE));
				p.setProperty(FLD_INIT_VALUE,rs.getString(FLD_INIT_VALUE));
				p.setProperty(FLD_VALIDATE_CLASS,rs.getString(FLD_VALIDATE_CLASS));
				p.setProperty(FLD_NULLABLE,rs.getString(FLD_NULLABLE));
				p.setProperty(FLD_ENCRYPT,rs.getString(FLD_ENCRYPT));
				p.setProperty(FLD_INPUT_TYPE,rs.getString(FLD_INPUT_TYPE));
				v.addElement(p);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return v;
	}
	private String getStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name){
		ResultSet rs=wd.getStepVarAccess(wf_id,wf_ver,step_id,var_name);
		String acc="";
		try{
			if ( rs.next() ){
				acc=rs.getString(FLD_ACCESS_RIGHT);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return acc;
	}
}