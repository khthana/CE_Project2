/*
 * Created on 23 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.client;

import java.sql.ResultSet;
import java.util.*;
import util.DatabaseField;
import util.WorkflowControlData;
import workflow.orgchart.*;
import workflow.engine.definition.StepForm;
import workflow.engine.execution.WfIncMgmt;
import workflow.engine.execution.*;
/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WfIncOperation implements WorkflowControlData,DatabaseField{// ��Ҩ� extend wfSupervisoryOperation
	private WfIncMgmt wimgt;
	private ResolveActor ra;
	private ActorIncident ai;
	public WfIncOperation(){
		ra=new ResolveActor();
		wimgt= new WfIncMgmt();
		ai=new ActorIncident();
	}
	public Properties getWfInc(String wf_id,String wf_ver,String wf_seq_no){
		ResultSet rs=wimgt.getWfInc(wf_id,wf_ver,wf_seq_no);
		Properties p=new Properties();
		try{
			if ( rs.next() ){
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_WF_SEQ_NO,rs.getString(FLD_WF_SEQ_NO));
				p.setProperty(FLD_SUBJECT,rs.getString(FLD_SUBJECT));
				p.setProperty(FLD_INITIATOR,rs.getString(FLD_INITIATOR));
				p.setProperty(FLD_PRIORITY,rs.getString(FLD_PRIORITY));
				p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
				p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
				p.setProperty(FLD_EXTENSION_TIME,rs.getString(FLD_EXTENSION_TIME));
				p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
				p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));		
				p.setProperty(FLD_DIFFICULT_LEVEL,rs.getString(FLD_DIFFICULT_LEVEL));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return p;
	}
	public Collection getAttachFile(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		Vector files=new Vector();
		AttachFile att=new AttachFile();
		Properties p=new Properties();
		ResultSet rs=att.getFileList(wf_id,wf_ver,wf_seq_no,step_id);
		try{
			while( rs.next() ){
				p=new Properties();
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_WF_SEQ_NO,rs.getString(FLD_WF_SEQ_NO));
				p.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				p.setProperty(FLD_FILE_SEQ_NO,rs.getString(FLD_FILE_SEQ_NO));
				p.setProperty(FLD_FILE_NAME,rs.getString(FLD_FILE_NAME));
				p.setProperty(FLD_FILE_DESC,rs.getString(FLD_FILE_DESC));
				p.setProperty(FLD_LAST_UPDATE,rs.getString(FLD_LAST_UPDATE));
				p.setProperty(FLD_UPDATE_BY,rs.getString(FLD_UPDATE_BY));
				files.addElement(p);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return files;
	}
	// fecth all stepIncident specific wf_id wf_ver wf_seq_no
	public Collection getOpinion(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		Vector op=new Vector();
		Properties p=null;
		ResultSet rs=ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
		try{
			while( rs.next() ){
				p=new Properties();
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_WF_SEQ_NO,rs.getString(FLD_WF_SEQ_NO));
				p.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				p.setProperty(FLD_POSITION_CODE,rs.getString(FLD_POSITION_CODE));
				p.setProperty(FLD_ACTOR_ID,rs.getString(FLD_ACTOR_ID));
				p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
				p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
				p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
				p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
				op.addElement(p);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return op;
	}
	
	public Collection getStepInc(String wf_id,String wf_ver,String wf_seq_no){
		Vector op=new Vector();
		Properties p=null;
		ResultSet rs=wimgt.getStepInc(wf_id,wf_ver,wf_seq_no);
		try{
			while( rs.next() ){
				p=new Properties();
				p.setProperty(FLD_WF_ID,rs.getString(FLD_WF_ID));
				p.setProperty(FLD_WF_VER,rs.getString(FLD_WF_VER));
				p.setProperty(FLD_WF_SEQ_NO,rs.getString(FLD_WF_SEQ_NO));
				p.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
				p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
				p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
				p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
				op.addElement(p);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return op;
	}
	public void updateFileBySeqNO(Properties scrData){
		AttachFile att=new AttachFile();
		att.updateBySeqNo(scrData);
	}// passwd
	public void initateWork(String wf_id,String wf_ver){
		wimgt.createWfInc(wf_id,wf_ver);
	}
	public void startWork(Properties scrData){
		wimgt.startwfInc(scrData);
	}
	// view form for incident history
	public String getExecutedForm(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		StepForm  sf=new StepForm();
		return sf.getExecutedForm(wf_id,wf_ver,wf_seq_no,step_id);
	}
	/*
	public Collection getTrackInc(String wf_id,String wf_ver,String wf_seq_no){
		Vector inc=new Vector();
		Properties p=null;
		ResultSet rs=wimgt.getStepInc(wf_id,wf_ver,wf_seq_no);
		try{
			while( rs.next() ){
				p=new Properties();
				p.setProperty(FLD_STEP_ID,rs.getString(FLD_STEP_ID));
				p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
				p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
				p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
				p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
				inc.addElement(p);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return inc;
	}*/
		// get var value specific variable
	public void autoAssignWork(){
		
	}
	public void takeOver(){
		
	}
	// get comment request in specific work
	public Collection  getComment(String wf_id,String wf_ver,String wf_seq_no){
		return new Vector();
	}


	public void abortWork(String wf_id,String wf_ver,String wf_seq_no,String step_id){
		// abort step Incident
	}
	
	////////////////           History Operation
	public Collection getHistory(String wf_id,String wf_ver,String wf_seq_no){
		
		return new Vector();
	}
	public void action(Properties scrData){
		String command=scrData.getProperty("command");
		if( command.equals(EVENT_ABORT) ){
			  wimgt.abortAction(scrData);
		}else if( command.equals(EVENT_APPROVE) ){
				wimgt.approveAction(scrData);
		}else if( command.equals(EVENT_ASSIGN) ){
				wimgt.assignAction(scrData);
		}else if( command.equals(EVENT_DISAPPROVE) ){
				wimgt.disapproveAction(scrData);
		}else if( command.equals(EVENT_RETURN)){
				wimgt.returnAction(scrData);
		}else if( command.equals("take")){
				wimgt.takeAction(scrData);	
		}
	}
	public void getJob(String wf_id,String wf_ver,String wf_seq_no,String step_id,String byUser){
		
	}
}