/*
 * Created on 28 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.admin;

import java.util.Collection;
import java.util.Properties;
import java.util.Vector;

import organization.OrganizationComponent;
import organization.User;
import organization.Imp.OrganizationComponentImp;
import organization.Imp.UserImp;
import util.DatabaseField;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class OrganisationMgmt implements DatabaseField {
	
	public OrganisationMgmt() {
	}
	
	public void createUser(Properties scrData) {
		UserImp u = new UserImp();
		u.setUserCode(scrData.getProperty(FLD_USER_CODE));
		u.setUserName(scrData.getProperty(FLD_USER_NAME));
		u.setPrimaryPost(scrData.getProperty(FLD_PRIMARY_POSITION));
		u.setJobGrade(scrData.getProperty(FLD_JOB_GRADE));
		u.setEmail(scrData.getProperty(FLD_EMAIL));
		u.setPasswd(scrData.getProperty(FLD_PASSWORD));
		u.setUType(scrData.getProperty(FLD_UTYPE));
		u.setBeginDate(scrData.getProperty(FLD_BEGIN_DATE));
		u.setEndDate(scrData.getProperty(FLD_END_DATE));
		OrganizationComponent oc = new OrganizationComponentImp();
		oc.addUser(u);
	}
	public void createPosition() {
	}
	public void createTeam() {
	}
	public void createQueue() {
	}
	
	public void updateUser(Properties scrData) {
		UserImp u = new UserImp();
		u.setUserCode(scrData.getProperty(FLD_USER_CODE));
		u.setUserName(scrData.getProperty(FLD_USER_NAME));
		u.setPrimaryPost(scrData.getProperty(FLD_PRIMARY_POSITION));
		u.setJobGrade(scrData.getProperty(FLD_JOB_GRADE));
		u.setEmail(scrData.getProperty(FLD_EMAIL));
		u.setPasswd(scrData.getProperty(FLD_PASSWORD));
		u.setUType(scrData.getProperty(FLD_UTYPE));
		u.setBeginDate(scrData.getProperty(FLD_BEGIN_DATE));
		u.setEndDate(scrData.getProperty(FLD_END_DATE));
		OrganizationComponent oc = new OrganizationComponentImp();
		oc.updateUser(u);
	}
	public void updatePosition() {
	}
	public void updateTeam() {
	}
	public void updateQueue() {
	}
	
	public void deleteUser(String user_code) {
		OrganizationComponent oc = new OrganizationComponentImp();
		oc.delUser(user_code);
	}
	public void deletePosition() {
	}
	public void deleteTeam() {
	}
	public void deleteQueue() {
	}
	
	public Collection getListUser() {
		OrganizationComponent oc = new OrganizationComponentImp();
		Vector v = (Vector) oc.findAllUsers();
		Vector res = new Vector();
		Properties p = new Properties();
		for (int i=0;i<v.size();i++) {
			User user = (User) v.get(i);
			p = this.getPropUser(user.getUserCode());
			res.addElement(p);
		}
		return res;
	}
	public Collection getListTeam() {
		Vector res = new Vector();
		return res;
	}
	public Collection getListPosition() {
		Vector res = new Vector();
		return res;
	}
	public Collection getListQueue() {
		Vector res = new Vector();
		return res;
	}
	
	public Properties getPropUser(String user_code) {
		OrganizationComponent oc = new OrganizationComponentImp();
		User user = oc.findUserById(user_code);
		Properties p = new Properties();
		p.setProperty(FLD_USER_CODE,user.getUserCode());
		p.setProperty(FLD_USER_NAME,user.getUserName());
		p.setProperty(FLD_PRIMARY_POSITION,user.getPrimaryPost());
		p.setProperty(FLD_JOB_GRADE,user.getJobGrade());
		p.setProperty(FLD_EMAIL,user.getEmail());
		p.setProperty(FLD_PASSWORD,user.getPasswd());
		p.setProperty(FLD_UTYPE,user.getUType());
		p.setProperty(FLD_BEGIN_DATE,user.getBeginDate());
		p.setProperty(FLD_END_DATE,user.getEndDate());
		return p;
	}
	//have member in properties [u002][u003]
	public Properties getPropPosition() {
		Properties p = new Properties();
		return p;
	}
	// have member in properties [u002][u003]
	public Properties getPropTeam() {
		Properties p = new Properties();
		return p;
	}
	//have member in properties [u002][u003]
	public Properties getPropQueue() {
		Properties p = new Properties();
		return p;
	}
}
