/*
 * Created on 30 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.admin;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Properties;
import java.util.Vector;

import workflow.engine.definition.WorkflowDefinition;


public class WorkflowDefinitionMgmt {
	
	private WorkflowDefinition wfdef=null;
	
	// copy workflow definition
	public void copyWorkflowDefinition(String wf_id,String wf_ver){
		wfdef = new WorkflowDefinition();
		wfdef.copyWorkflowDefinition(wf_id,wf_ver);
	}
	
	// delete workflow definition
	public void deleteWorkflowDefinition(String wf_id,String wf_ver){
		wfdef = new WorkflowDefinition();
		wfdef.delWorkflowDefinition(wf_id,wf_ver);
	}
	public void deleteStepDefinition(String wf_id,String wf_ver,String step_id) {
		wfdef = new WorkflowDefinition();
		wfdef.delStepDefinition(wf_id,wf_ver,step_id);
	}
	public void deleteWorkflowVarDefinition(String wf_id,String wf_ver,String var_name) {
		wfdef = new WorkflowDefinition();
		wfdef.delWfVarDef(wf_id,wf_ver,var_name);
	}
	public void deleteTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		wfdef = new WorkflowDefinition();
		wfdef.delTransition(wf_id,wf_ver,step_id,next_step_id);
	}
	
	// get all list workflow definition permiss each userid
	public Collection getListWorkflowDef(){
		wfdef = new WorkflowDefinition();
		Vector res = new Vector();
		ResultSet rs = wfdef.getWorkflowDef();
		try {
			while(rs.next()) {
				//String datetime = rs.getString("end_time");
				//Calendar ca = Calendar.getInstance();
				//Calendar wfca = Calendar.getInstance();
				//int day = Integer.parseInt(datetime.substring(0,2));
				//int month = Integer.parseInt(datetime.substring(3,5));
				//month--;
				//int year = Integer.parseInt(datetime.substring(6,10));
				//int hour = Integer.parseInt(datetime.substring(11,13));
				//int minute = Integer.parseInt(datetime.substring(14,16));
				//int second = Integer.parseInt(datetime.substring(17,19));
				//wfca.set(year,month,day,hour,minute,second);
				//Vector sub = null;
				//if (ca.after(wfca)) {
					res.addElement(this.getPropWfDef(rs.getString("wf_id"),rs.getString("wf_ver")));
					/*
					sub = new Vector();
					sub.addElement(rs.getString("wf_id"));
					sub.addElement(rs.getString("wf_ver"));
					sub.addElement(rs.getString("wf_name"));
					sub.addElement(rs.getString("wf_short_code"));
					sub.addElement(rs.getString("wf_objective"));
					sub.addElement(rs.getString("wf_rule"));
					sub.addElement(rs.getString("completion_duration"));
					sub.addElement(rs.getString("extension_duration"));
					sub.addElement(rs.getString("initiator_def"));
					sub.addElement(rs.getString("initiate_time"));
					sub.addElement(rs.getString("schedule"));
					sub.addElement(rs.getString("last_seq"));
					sub.addElement(rs.getString("comment"));
					sub.addElement(rs.getString("start_time"));
					sub.addElement(rs.getString("end_time"));
					sub.addElement(rs.getString("priority"));
					sub.addElement(rs.getString("security"));
					sub.addElement(rs.getString("abort_script"));
					sub.addElement(rs.getString("last_update"));
					sub.addElement(rs.getString("update_by"));
					sub.addElement(rs.getString("takeover_right"));
					sub.addElement(rs.getString("web_page"));
					sub.addElement(rs.getString("difficult_level"));
					*/
				//}
				//res.addElement(sub);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public Collection getAllListWorkflowDef() {
		wfdef = new WorkflowDefinition();
		WorkflowDefinitionMgmt wfdm = new WorkflowDefinitionMgmt();
		Vector res = new Vector();
		ResultSet rs = wfdef.getWorkflowDef();
		try {
			while(rs.next()) {
				res.addElement(wfdm.getPropWfDef(rs.getString("wf_id"),rs.getString("wf_ver")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public Collection getListWfVarDef(String wf_id,String wf_ver){
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getWfVarDef(wf_id,wf_ver);
		Vector res = new Vector();
		try {
			//Vector sub = null;
			while(rs.next()) {
				res.addElement(this.getPropWfVarDef(wf_id,wf_ver,rs.getString("var_name")));
				/*
				sub = new Vector();
				sub.addElement(rs.getString("wf_id"));
				sub.addElement(rs.getString("wf_ver"));
				sub.addElement(rs.getString("var_name"));
				sub.addElement(rs.getString("var_desc_thai"));
				sub.addElement(rs.getString("var_desc_eng"));
				sub.addElement(rs.getString("hint"));
				sub.addElement(rs.getString("var_type"));
				sub.addElement(rs.getString("init_value"));
				sub.addElement(rs.getString("validate_class"));
				sub.addElement(rs.getString("nullable"));
				sub.addElement(rs.getString("last_update"));
				sub.addElement(rs.getString("update_by"));
				sub.addElement(rs.getString("encrypt"));
				sub.addElement(rs.getString("access_right"));
				sub.addElement(rs.getString("button_type"));
				sub.addElement(rs.getString("button_value"));
				*/
			}
			//res.addElement(sub);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public Collection getListStepDefinition(String wf_id,String wf_ver) {
		Vector res = new Vector();
		
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getStepDefinition(wf_id,wf_ver);
		try {
			//Vector sub = null;
			while(rs.next()) {
				res.addElement(this.getPropStepDef(wf_id,wf_ver,rs.getString("step_id")));
				/*
				sub = new Vector();
				sub.addElement(rs.getString("wf_id"));
				sub.addElement(rs.getString("wf_ver"));
				sub.addElement(rs.getString("step_id"));
				sub.addElement(rs.getString("step_name"));
				sub.addElement(rs.getString("step_desc"));
				sub.addElement(rs.getString("step_type"));
				sub.addElement(rs.getString("recipient_def"));
				sub.addElement(rs.getString("task_rate"));
				sub.addElement(rs.getString("web_page"));
				sub.addElement(rs.getString("auto_approve"));
				sub.addElement(rs.getString("complete_script"));
				sub.addElement(rs.getString("return_script"));
				sub.addElement(rs.getString("attached_status"));
				sub.addElement(rs.getString("completion_duration"));
				sub.addElement(rs.getString("extension_duration"));
				sub.addElement(rs.getString("delay_duration"));
				sub.addElement(rs.getString("onlate_notify"));
				sub.addElement(rs.getString("last_seq"));
				sub.addElement(rs.getString("last_update"));
				sub.addElement(rs.getString("update_by"));
				sub.addElement(rs.getString("pre_condition"));
				*/
			}
			//res.addElement(sub);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	public Collection getListTransition(String wf_id,String wf_ver) {
		Vector res = new Vector();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getTransition(wf_id,wf_ver);
		try {
			//Vector sub = null;
			while(rs.next()) {
				res.addElement(this.getPropTransition(wf_id,wf_ver,rs.getString("step_id"),rs.getString("next_step_id")));
				/*
				sub = new Vector();
				sub.addElement(rs.getString("wf_id"));
				sub.addElement(rs.getString("wf_ver"));
				sub.addElement(rs.getString("step_id"));
				sub.addElement(rs.getString("next_step_id"));
				sub.addElement(rs.getString("condition"));
				sub.addElement(rs.getString("on_event"));
				sub.addElement(rs.getString("last_update"));
				sub.addElement(rs.getString("update_by"));
				*/
			}
			//res.addElement(sub);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}
	
	public Properties getPropWfDef(String wf_id,String wf_ver) {
		Properties result = new Properties();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getWorkflowDef(wf_id,wf_ver);
		try {
			if (rs.next()) {
				result.setProperty("wf_id",rs.getString("wf_id"));
				result.setProperty("wf_ver",rs.getString("wf_ver"));
				result.setProperty("wf_name",rs.getString("wf_name"));
				result.setProperty("wf_short_code",rs.getString("wf_short_code"));
				result.setProperty("wf_objective",rs.getString("wf_objective"));
				result.setProperty("wf_rule",rs.getString("wf_rule"));
				result.setProperty("completion_duration",rs.getString("completion_duration"));
				result.setProperty("extension_duration",rs.getString("extension_duration"));
				result.setProperty("initiator_def",rs.getString("initiator_def"));
				result.setProperty("initiate_time",rs.getString("initiate_time"));
				result.setProperty("schedule",rs.getString("schedule"));
				result.setProperty("last_seq",rs.getString("last_seq"));
				//result.setProperty("comment",rs.getString("comment"));
				result.setProperty("start_time",rs.getString("start_time"));
				result.setProperty("end_time",rs.getString("end_time"));
				result.setProperty("priority",rs.getString("priority"));
				//result.setProperty("security",rs.getString("security"));
				result.setProperty("abort_script",rs.getString("abort_script"));
				//result.setProperty("last_update",rs.getString("last_update"));
				//result.setProperty("update_by",rs.getString("update_by"));
				result.setProperty("takeover_right",rs.getString("takeover_right"));
				//result.setProperty("web_page",rs.getString("web_page"));
				result.setProperty("difficult_level",rs.getString("difficult_level"));	
				result.setProperty("current_use",rs.getString("current_use"));		
				result.setProperty("wf_desc",rs.getString("wf_desc"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	public Properties getPropStepDef(String wf_id,String wf_ver,String step_id) {
		Properties sp = new Properties();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getStepDefinition(wf_id,wf_ver,step_id);
		try {
			if (rs.next()) {
				sp.setProperty("wf_id",rs.getString("wf_id"));
				sp.setProperty("wf_ver",rs.getString("wf_ver"));
				sp.setProperty("step_id",rs.getString("step_id"));
				sp.setProperty("step_name",rs.getString("step_name"));
				sp.setProperty("step_desc",rs.getString("step_desc"));
				sp.setProperty("step_type",rs.getString("step_type"));
				sp.setProperty("recipient_def",rs.getString("recipient_def"));
				sp.setProperty("task_rate",rs.getString("task_rate"));
				sp.setProperty("web_page",rs.getString("web_page"));
				sp.setProperty("auto_approve",rs.getString("auto_approve"));
				sp.setProperty("complete_script",rs.getString("complete_script"));
				sp.setProperty("return_script",rs.getString("return_script"));
				sp.setProperty("attached_status",rs.getString("attached_status"));
				sp.setProperty("completion_duration",rs.getString("completion_duration"));
				sp.setProperty("extension_duration",rs.getString("extension_duration"));
				sp.setProperty("delay_duration",rs.getString("delay_duration"));
				sp.setProperty("onlate_notify",rs.getString("onlate_notify"));
				//sp.setProperty("last_seq",rs.getString("last_seq"));
				//sp.setProperty("last_update",rs.getString("last_update"));
				//sp.setProperty("update_by",rs.getString("update_by"));
				sp.setProperty("pre_condition",rs.getString("pre_condition"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sp;
	}
	public Properties getPropWfVarDef(String wf_id,String wf_ver,String var_name) {
		Properties var_prop = new Properties();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getWfVarDef(wf_id,wf_ver,var_name);
		try {
			if (rs.next()) {
				String stemp = "";
				var_prop.setProperty("wf_id",rs.getString("wf_id"));
				var_prop.setProperty("wf_ver",rs.getString("wf_ver"));
				var_prop.setProperty("var_name",rs.getString("var_name"));
				var_prop.setProperty("var_desc_thai",rs.getString("var_desc_thai"));
				var_prop.setProperty("var_desc_eng",rs.getString("var_desc_eng"));
				var_prop.setProperty("hint",rs.getString("hint"));
				//var_prop.setProperty("condition",rs.getString("condition"));
				var_prop.setProperty("var_type",rs.getString("var_type"));
				stemp = rs.getString("init_value");
				if(stemp != null)
					var_prop.setProperty("init_value",stemp);
				else
					var_prop.setProperty("init_value","");
				stemp = rs.getString("validate_class");
				if (stemp != null)
					var_prop.setProperty("validate_class",stemp);
				else
					var_prop.setProperty("validate_class","");
				var_prop.setProperty("nullable",rs.getString("nullable"));
				//var_prop.setProperty(FLD_TAG_TYPE,rs.getString(FLD_TAG_TYPE));
				//var_prop.setProperty("last_update",rs.getString("last_update"));
				//var_prop.setProperty("update_by",rs.getString("update_by"));
				var_prop.setProperty("encrypt",rs.getString("encrypt"));
				//var_prop.setProperty("access_right",rs.getString("access_right"));	
				var_prop.setProperty("input_type",rs.getString("input_type"));	
				stemp = rs.getString("input_value");
				if (stemp != null) 
					var_prop.setProperty("input_value",stemp);
				else
					var_prop.setProperty("input_value","");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return var_prop;
	}
	public Properties getPropTransition(String wf_id,String wf_ver,String step_id,String next_step_id) {
		Properties tp = new Properties();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getTransition(wf_id,wf_ver,step_id,next_step_id);
		try {
			if (rs.next()) {
				tp.setProperty("wf_id",rs.getString("wf_id"));
				tp.setProperty("wf_ver",rs.getString("wf_ver"));
				tp.setProperty("step_id",rs.getString("step_id"));
				tp.setProperty("next_step_id",rs.getString("next_step_id"));
				String stemp = rs.getString("condition");
				if (stemp != null)
					tp.setProperty("condition",stemp);
				else
					tp.setProperty("condition","");
				stemp = rs.getString("on_event");
				if (stemp != null)
					tp.setProperty("on_event",stemp);
				else 
					tp.setProperty("on_event","");
				stemp = rs.getString("tran_desc");
				if (stemp != null)
					tp.setProperty("tran_desc",stemp);
				else
					tp.setProperty("tran_desc","");
				//tp.setProperty("last_update",rs.getString("last_update"));
				//tp.setProperty("update_by",rs.getString("update_by"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tp;
	}
	
	public void createWorkflowDefinition(Properties scrData) {
		wfdef = new WorkflowDefinition(scrData);
		//create start step
		//sp.setProperty("wf_id",rs.getString("wf_id"));
		//sp.setProperty("wf_ver",rs.getString("wf_ver"));
		scrData.setProperty("step_id","1");
		scrData.setProperty("step_name","Start");
		scrData.setProperty("step_desc","Start Step");
		scrData.setProperty("step_type","1");
		scrData.setProperty("recipient_def","");
		scrData.setProperty("task_rate","0");
		scrData.setProperty("web_page","");
		scrData.setProperty("auto_approve","");
		scrData.setProperty("complete_script","");
		scrData.setProperty("return_script","");
		scrData.setProperty("attached_status","1");
		scrData.setProperty("completion_duration","0");
		scrData.setProperty("extension_duration","0");
		scrData.setProperty("delay_duration","0");
		scrData.setProperty("onlate_notify","0");
		scrData.setProperty("pre_condition","");
		this.createStepDefinition(scrData);
		//create end step
		scrData.setProperty("step_id","2");
		scrData.setProperty("step_name","End");
		scrData.setProperty("step_desc","End Step");
		scrData.setProperty("step_type","3");
		this.createStepDefinition(scrData);
	}
	public void updateWorkflowDefinition(Properties scrData) {
		wfdef = new WorkflowDefinition(scrData);
	}
	public void createStepDefinition(Properties scrData) {
		wfdef = new WorkflowDefinition();
		wfdef.addStepDefinition(scrData);
	}
	public void updateStepDefinition(Properties scrData) {
		wfdef.updateStepDefinition(scrData);
	}
	public void createTransition(Properties scrData) {
		wfdef = new WorkflowDefinition();
		wfdef.addTransition(scrData);
	}
	public void createWorkflowVarDefinition(Properties scrData) {
		wfdef = new WorkflowDefinition();
		wfdef.addWfVarDef(scrData);
	}
	public int getMaxStep(String wf_id,String wf_ver) {
		wfdef = new WorkflowDefinition();
		return wfdef.getMaxStep(wf_id,wf_ver);
	}
	public int getMaxWfID() {
		wfdef = new WorkflowDefinition();
		return wfdef.getMaxWfID();
	}
	public int getMaxWfVer(String wf_id) {
		wfdef = new WorkflowDefinition();
		return wfdef.getMaxWfVer(wf_id);
	}
	public Properties getPropStepVarAccess(String wf_id,String wf_ver,String step_id,String var_name) {
		Properties prop = new Properties();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getStepVarAccess(wf_id,wf_ver,step_id,var_name);
		wfdef.nextRecord(rs);
		prop.setProperty("wf_id",wfdef.getColumn(rs,"wf_id"));
		prop.setProperty("wf_ver",wfdef.getColumn(rs,"wf_ver"));
		prop.setProperty("step_id",wfdef.getColumn(rs,"step_id"));
		prop.setProperty("var_name",wfdef.getColumn(rs,"var_name"));
		prop.setProperty("access_right",wfdef.getColumn(rs,"access_right"));
		return prop;
	}
	public Collection getListAccessVarStep(String wf_id,String wf_ver,String step_id) {
		Vector v = new Vector();
		wfdef = new WorkflowDefinition();
		ResultSet rs = wfdef.getWfVarDef(wf_id,wf_ver);
		while (wfdef.nextRecord(rs)) {
			String vname = wfdef.getColumn(rs,"var_name");
			v.addElement(this.getPropStepVarAccess(wf_id,wf_ver,step_id,vname));
		}
		return v;
	}
	public void createAccessVarStep(Properties scrData) {
		wfdef = new WorkflowDefinition();
		wfdef.addStepVarAccess(scrData);
	}
	public String genInitStepForm(Properties scrData) {
		wfdef = new WorkflowDefinition();
		String wf_id = scrData.getProperty("wf_id");
		String wf_ver = scrData.getProperty("wf_ver");
		String step_id = scrData.getProperty("step_id");
		return wfdef.genInitStepForm(wf_id,wf_ver,step_id);
	}
}