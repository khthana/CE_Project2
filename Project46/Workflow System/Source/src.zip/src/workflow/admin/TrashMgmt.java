/*
 * Created on 28 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.admin;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Properties;
import java.util.Vector;

import util.DatabaseField;
import util.WorkflowControlData;
import workflow.engine.definition.WorkflowDefinition;
import workflow.engine.execution.ActorIncident;
import workflow.engine.execution.WfIncMgmt;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TrashMgmt implements DatabaseField, WorkflowControlData {
	
	public TrashMgmt() {
	}
	public void abortInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		WfIncMgmt wimg = new WfIncMgmt();
		wimg.setWfStatus(wf_id,wf_ver,wf_seq_no,STATUS_WF_ABORT);
	}
	public void assignInc(Properties scrData) {
		WfIncMgmt wimg = new WfIncMgmt();
		wimg.assignAction(scrData);
	}
	public Collection getAllWfInc() {
		Vector res = new Vector();
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getWfInc();
		Properties p = new Properties();
		Properties pp = new Properties();
		try {
			while(rs.next()) {
				String wf_id = rs.getString(FLD_WF_ID);
				String wf_ver = rs.getString(FLD_WF_VER);
				String wf_seq_no = rs.getString(FLD_WF_SEQ_NO);
				String status = rs.getString(FLD_STATUS);
				if (status.equals(STATUS_WF_NO_RECIPIENT)) {
					p.setProperty(FLD_WF_ID,wf_id);
					p.setProperty(FLD_WF_VER,wf_ver);
					p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
					pp = this.getPropWfInc(p);
					res.addElement(pp);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	public Collection getAllStepInc(Properties scrData) {
		Vector res = new Vector();
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		Properties p = new Properties();
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getStepInc(wf_id,wf_ver,wf_seq_no);
		try {
			while (rs.next()) {
				String step_id = rs.getString(FLD_STEP_ID);
				scrData.setProperty(FLD_STEP_ID,step_id);
				p = this.getPropStepInc(scrData);
				res.addElement(p);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	public Properties getPropWfDef(String wf_id,String wf_ver) {
		WorkflowDefinitionMgmt wfmg = new WorkflowDefinitionMgmt();
		Properties p = wfmg.getPropWfDef(wf_id,wf_ver);
		return p;
	}
	public Properties getPropStepDef(String wf_id,String wf_ver,String step_id) {
		WorkflowDefinitionMgmt wfmg = new WorkflowDefinitionMgmt();
		Properties p = wfmg.getPropStepDef(wf_id,wf_ver,step_id);
		return p;
	}
	public Collection getActorInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
		Vector v = new Vector();
		Properties p = new Properties();
		while (ai.nextRecord(rs)) {
			String user_code = ai.getColumn(rs,FLD_ACTOR_ID);
			scrData.setProperty(FLD_USER_CODE,user_code);
			p = this.getPropActorInc(scrData);
			v.addElement(p);
		}
		return v;
	}
	public Properties getPropActorInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String user_code = scrData.getProperty(FLD_USER_CODE);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,user_code);
		Properties p = new Properties();
		if (ai.nextRecord(rs)) {
			p.setProperty("wf_id",wf_id);
			p.setProperty("wf_ver",wf_ver);
			p.setProperty("wf_seq_no",wf_seq_no);
			p.setProperty("step_id",step_id);
			p.setProperty("user_code",ai.getColumn(rs,"actor_id"));
			p.setProperty("position_code",ai.getColumn(rs,"position_code"));
			p.setProperty("status",ai.getColumn(rs,"status"));
			p.setProperty("start_time",ai.getColumn(rs,"start_time"));
			p.setProperty("completion_time",ai.getColumn(rs,"completion_time"));
			p.setProperty("comment",ai.getColumn(rs,"comment"));
		}
		return p;
	}
	public Properties getPropStepInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getStepInc(wf_id,wf_ver,wf_seq_no,step_id);
		Properties p = new Properties();
		try {
			rs.next();
			p.setProperty(FLD_WF_ID,wf_id);
			p.setProperty(FLD_WF_VER,wf_ver);
			p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
			p.setProperty(FLD_STEP_ID,step_id);
			p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
			p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
			p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
			p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}
	public Properties getPropWfInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getWfInc(wf_id,wf_ver,wf_seq_no);
		WorkflowDefinition wf = new WorkflowDefinition();
		Properties p = new Properties(); 
		try {
			rs.next();
			p.setProperty("wf_id",rs.getString("wf_id"));
			p.setProperty("wf_ver",rs.getString("wf_ver"));
			p.setProperty("wf_seq_no",rs.getString("wf_seq_no"));
			p.setProperty("subject",rs.getString("subject"));
			p.setProperty("priority",rs.getString("priority"));
			p.setProperty("start_time",rs.getString("start_time"));
			p.setProperty("completion_time",rs.getString("completion_time"));
			p.setProperty("extension_time",rs.getString("extension_time"));
			p.setProperty("status",rs.getString("status"));
			String stemp = rs.getString("comment");
			if (stemp != null)
				p.setProperty("comment",stemp);
			else
				p.setProperty("comment","");
			p.setProperty("difficult_level",rs.getString("difficult_level"));
			p.setProperty("initiator",rs.getString("initiator"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}
}
