/*
 * Created on 28 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.admin;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import util.*;
import workflow.engine.definition.WorkflowDefinition;
import workflow.engine.execution.ActorIncident;
import workflow.engine.execution.QueueTransfer;
import workflow.engine.execution.WfIncMgmt;
import workflow.engine.execution.WorkflowIncident;


/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MonitorMgmt implements DatabaseField {
	
	public MonitorMgmt() {
	}
	public Collection getInc() {
		Vector res = new Vector();
		return res;
	}
	public Collection getListWorkflowDef() {
		WorkflowDefinitionMgmt wfmg = new WorkflowDefinitionMgmt();
		return wfmg.getListWorkflowDef();
	}
	// not use
	public Collection getLastStepActive(String wf_id,String wf_ver,String wf_seq_no) {
		WorkflowIncident wi = new WorkflowIncident();
		wi.initMyTable("step_incident");
		wi.setFilter("wf_id",wf_id);
		wi.setFilter("wf_ver",wf_ver);
		wi.setFilter("wf_seq_no",wf_seq_no);
		//wi.setFilter("status","1");
		ResultSet rs = wi.search();
		Vector v = new Vector();
		while (wi.nextRecord(rs)) {
			Properties p = new Properties();
			p.setProperty("wf_id",wf_id);
			p.setProperty("wf_ver",wf_ver);
			p.setProperty("wf_seq_no",wf_seq_no);
			String status = wi.getColumn(rs,"status");
			if (status.equals("1")){ 
				p.setProperty("step_id",wi.getColumn(rs,"step_id"));
			} else {
				p.setProperty("step_id","1");
			}
			v.addElement(p);
		}
		return v;
	}
	public Collection getAllWfInc(Properties search) {//UserProfile up,Properties scrFilter) {
		Enumeration es = search.keys();
		WorkflowIncident wi = new WorkflowIncident();
		wi.initMyTable("workflow_incident");
		boolean hassearch = false;
		while(es.hasMoreElements()) {
			String estemp = (String) es.nextElement();
			String stemp = search.getProperty(estemp);
			//boolean setstart = false;
			if (estemp.equals("category")) {
				//pattern wf_id:wf_ver
				hassearch = true;
				wi.setFilter("workflow_definition.wf_id",Integer.parseInt(stemp.substring(0,stemp.indexOf(":"))));
				wi.setFilter("workflow_definition.wf_ver",Integer.parseInt(stemp.substring(stemp.indexOf(":")+1)));
			} else if (estemp.equals("initiator")) {
				hassearch = true;
				wi.setFilter("initiator",stemp);
			} else if (estemp.equals("startdate")) {
				if (search.getProperty("enddate") != null && !search.getProperty("enddate").equals("") && !search.getProperty("enddate").equals(" ")) {
					hassearch = true;
					wi.setFilterBetween("workflow_incident.start_time",MyCalendar.convertPattern(stemp),MyCalendar.convertPattern(search.getProperty("workflow_incident.enddate")));
				}
			//} else if (estemp.equals("end_date")) {
			} else if (estemp.equals("status")) {
				hassearch = true;
				wi.setFilter("workflow_incident.status",stemp);
			}
		}
		wi.joinTable(TBL_WORKFLOW_DEFINITION);
		wi.setJoinCondition("workflow_definition.wf_id=workflow_incident.wf_id and workflow_definition.wf_ver = workflow_incident.wf_ver");
		wi.setOrder("workflow_definition.wf_id");
		wi.setOrder("workflow_definition.wf_id");
		wi.setOrder("wf_seq_no");
		ResultSet rs = wi.search();
		Vector res = new Vector();
		Properties p = new Properties();
		while (wi.nextRecord(rs)) {
			p = new Properties();
			p.setProperty(FLD_WF_ID,wi.getColumn(rs,"workflow_definition.wf_id"));
			p.setProperty(FLD_WF_VER,wi.getColumn(rs,"workflow_definition.wf_ver"));
			p.setProperty(FLD_WF_SEQ_NO,wi.getColumn(rs,FLD_WF_SEQ_NO));
			//System.out.println(p.getProperty(FLD_WF_SEQ_NO));
			p.setProperty(FLD_WF_NAME,wi.getColumn(rs,FLD_WF_NAME));
			p.setProperty(FLD_WF_SHORT_CODE,wi.getColumn(rs,FLD_WF_SHORT_CODE));
			p.setProperty(FLD_SUBJECT,wi.getColumn(rs,FLD_SUBJECT));
			//System.out.println(p.getProperty(FLD_SUBJECT));
			p.setProperty(FLD_INITIATOR,wi.getColumn(rs,FLD_INITIATOR));
			p.setProperty(FLD_STATUS,wi.getColumn(rs,FLD_STATUS));
			//p = this.getPropWfInc(p);
			res.addElement(p);
		}
		return res;
	}
	public Collection getAllStepInc(Properties scrData) {
		Vector res = new Vector();
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		Properties p = new Properties();
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getStepInc(wf_id,wf_ver,wf_seq_no);
		try {
			while (rs.next()) {
				String step_id = rs.getString(FLD_STEP_ID);
				scrData.setProperty(FLD_STEP_ID,step_id);
				p = this.getPropStepInc(scrData);
				res.addElement(p);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	public Properties getPropWfDef(String wf_id,String wf_ver) {
		WorkflowDefinitionMgmt wfmg = new WorkflowDefinitionMgmt();
		Properties p = wfmg.getPropWfDef(wf_id,wf_ver);
		return p;
	}
	public Properties getPropStepDef(String wf_id,String wf_ver,String step_id) {
		WorkflowDefinitionMgmt wfmg = new WorkflowDefinitionMgmt();
		Properties p = wfmg.getPropStepDef(wf_id,wf_ver,step_id);
		return p;
	}

	public Collection getActorInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id);
		Vector v = new Vector();
		Properties p = new Properties();
		while (ai.nextRecord(rs)) {
			String user_code = ai.getColumn(rs,FLD_ACTOR_ID);
			scrData.setProperty(FLD_USER_CODE,user_code);
			p = this.getPropActorInc(scrData);
			v.addElement(p);
		}
		return v;
	}
	public Properties getPropActorInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String user_code = scrData.getProperty(FLD_USER_CODE);
		ActorIncident ai = new ActorIncident();
		ResultSet rs = ai.getActorIncident(wf_id,wf_ver,wf_seq_no,step_id,user_code);
		Properties p = new Properties();
		if (ai.nextRecord(rs)) {
			p.setProperty("wf_id",wf_id);
			p.setProperty("wf_ver",wf_ver);
			p.setProperty("wf_seq_no",wf_seq_no);
			p.setProperty("step_id",step_id);
			p.setProperty("user_code",ai.getColumn(rs,"actor_id"));
			p.setProperty("position_code",ai.getColumn(rs,"position_code"));
			p.setProperty("status",ai.getColumn(rs,"status"));
			p.setProperty("start_time",ai.getColumn(rs,"start_time"));
			p.setProperty("completion_time",ai.getColumn(rs,"completion_time"));
			p.setProperty("comment",ai.getColumn(rs,"comment"));
		}
		return p;
	}
	public Properties getPropStepInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getStepInc(wf_id,wf_ver,wf_seq_no,step_id);
		Properties p = new Properties();
		try {
			rs.next();
			p.setProperty(FLD_WF_ID,wf_id);
			p.setProperty(FLD_WF_VER,wf_ver);
			p.setProperty(FLD_WF_SEQ_NO,wf_seq_no);
			p.setProperty(FLD_STEP_ID,step_id);
			p.setProperty(FLD_START_TIME,rs.getString(FLD_START_TIME));
			p.setProperty(FLD_COMPLETION_TIME,rs.getString(FLD_COMPLETION_TIME));
			p.setProperty(FLD_STATUS,rs.getString(FLD_STATUS));
			p.setProperty(FLD_COMMENT,rs.getString(FLD_COMMENT));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}
	public Properties getPropWfInc(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getWfInc(wf_id,wf_ver,wf_seq_no);
		WorkflowDefinition wf = new WorkflowDefinition();
		Properties p = new Properties(); 
		try {
			rs.next();
			p.setProperty("wf_id",rs.getString("wf_id"));
			p.setProperty("wf_ver",rs.getString("wf_ver"));
			p.setProperty("wf_seq_no",rs.getString("wf_seq_no"));
			p.setProperty("subject",rs.getString("subject"));
			p.setProperty("priority",rs.getString("priority"));
			p.setProperty("start_time",rs.getString("start_time"));
			p.setProperty("completion_time",rs.getString("completion_time"));
			p.setProperty("extension_time",rs.getString("extension_time"));
			p.setProperty("status",rs.getString("status"));
			String stemp = rs.getString("comment");
			if (stemp != null)
				p.setProperty("comment",stemp);
			else
				p.setProperty("comment","");
			p.setProperty("difficult_level",rs.getString("difficult_level"));
			p.setProperty("initiator",rs.getString("initiator"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}
	public Collection getAllWfVarDef(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		WorkflowDefinitionMgmt wfdm = new WorkflowDefinitionMgmt();
		Collection c = wfdm.getListWfVarDef(wf_id,wf_ver);
		return c;
	}
	public Properties getPropWfVarDef(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String var_name = scrData.getProperty(FLD_VAR_NAME);
		WorkflowDefinitionMgmt wfdm = new WorkflowDefinitionMgmt();
		Properties p = wfdm.getPropWfVarDef(wf_id,wf_ver,var_name);
		return p;
	}
	public String getStepVarForm(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		Properties p = this.getPropStepDef(wf_id,wf_ver,step_id);
		WfIncMgmt wimg = new WfIncMgmt();
		String form = "";
		return form;
	}
	public Collection getAllQueueTransfer(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		QueueTransfer qt = new QueueTransfer();
		ResultSet rs = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,step_id);
		Vector v = new Vector();
		while (qt.nextRecord(rs)) {
			String queue_code = qt.getColumn(rs,FLD_QUEUE_CODE);
			scrData.setProperty(FLD_QUEUE_CODE,queue_code);
			Properties p = this.getPropQueueTransfer(scrData);
			v.addElement(p);
		}
		return v;
	}
	public Properties getPropQueueTransfer(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String step_id = scrData.getProperty(FLD_STEP_ID);
		String queue_code = scrData.getProperty(FLD_QUEUE_CODE);
		QueueTransfer qt = new QueueTransfer();
		ResultSet rs = qt.getQueueTransfer(wf_id,wf_ver,wf_seq_no,step_id,queue_code);
		Properties p = new Properties(scrData);
		if (qt.nextRecord(rs)) {
			p.setProperty(FLD_TFR_ACTOR_ID,qt.getColumn(rs,FLD_TFR_ACTOR_ID));
			p.setProperty(FLD_OWNER_ACTOR_ID,qt.getColumn(rs,FLD_OWNER_ACTOR_ID));
			p.setProperty(FLD_STATUS,qt.getColumn(rs,FLD_STATUS));
			p.setProperty(FLD_START_TIME,qt.getColumn(rs,FLD_START_TIME));
			p.setProperty(FLD_END_TIME,qt.getColumn(rs,FLD_END_TIME));
		}
		return p;
	}
	public Collection getAllWfVar(Properties scrData) {
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		WorkflowDefinition wd = new WorkflowDefinition();
		ResultSet rs = wd.getWfVarDef(wf_id,wf_ver);
		Vector v = new Vector();
		while (wd.nextRecord(rs)) {
			String var_name = wd.getColumn(rs,FLD_VAR_NAME);
			scrData.setProperty(FLD_VAR_NAME,var_name);
			Properties p = new Properties();
			p = this.getPropWfvar(scrData);
			v.addElement(p);
		}
		return v;
	}
	public Properties getPropWfvar(Properties scrData) {
		Properties p = this.getPropWfVarDef(scrData);
		String wf_id = scrData.getProperty(FLD_WF_ID);
		String wf_ver = scrData.getProperty(FLD_WF_VER);
		String wf_seq_no = scrData.getProperty(FLD_WF_SEQ_NO);
		String var_name = scrData.getProperty(FLD_VAR_NAME);
		WfIncMgmt wimg = new WfIncMgmt();
		ResultSet rs = wimg.getWfVariable(wf_id,wf_ver,wf_seq_no,var_name);
		try {
			rs.next();
			p.setProperty(FLD_VAR_VALUE,rs.getString(FLD_VAR_VALUE));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return p;
	}
/*
	// resume
	public void startWfInc(){
	}
	// ������ա������¹ role �ͧ��ѡ�ҹ ���� ������ ��������´ stepDef
	// ��������� wfInc �ӧҹ malfunctioning 
	public void stopWfInc(){
	}
	public void changeStateWfInc(){
		
	}
	public void TermicateWfInc(){
	}
	public void AbortWfInc(){
	}
	public void Puring(){
		
	}
	public void BackUp(){
		
	}
	public void DownloadWfInc(){
	}
	public void UploadWfInc(){
	}
	public void Audit(){
	}
*/
}
