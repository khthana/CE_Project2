/*
 * Created on 6 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.orgchart;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import util.Database;
import util.DatabaseField;
public class ResolveActor extends Database implements DatabaseField {
	String SQL;
	//ResultSet rs;
	
	//paturn of actor_Def is [(U,T,Q,P,R)identify]
	//example [U100000] etc.
	
	public ResolveActor() {
		super("workflow");
	}
	//	return collection of all user_id have been member (user team position role)
	public Collection getRefActor(String actor_Def) {
		Collection result = new Vector();
		String a = new String(actor_Def);
		
		Collection ucol = this.getAllUsers(actor_Def);
		//Collection qcol = this.getAllQueue(actor_Def);
		Collection tcol = this.getAllTeam(actor_Def);
		Collection pcol = this.getAllPosition(actor_Def);
		Collection xcol = this.getAllRole(actor_Def);
		
		result.addAll(ucol);
		Database db = new Database("workflow");
		db.initMyTable(TBL_POSITION);
		Iterator buff = xcol.iterator();
		ResultSet rs = null;
		while (buff.hasNext()) {
			String element = (String) buff.next();
			if (element.substring(0,1).equals("X")) {
				db.setFilter(FLD_ROLE,element.substring(1));
				rs = db.search();
				while (db.nextRecord(rs)) {
					String rtemp = db.getColumn(rs,FLD_POSITION_ID);
					result.addAll(this.getUser("@"+rtemp));
				}
			}
		}
		//result.addAll(qcol);
		/*
		Iterator buff = qcol.iterator();
		while (buff.hasNext()) {
			String element = (String) buff.next();
			result.addAll(ra.getAllUser(element));
		}
		*/
		Iterator buff1 = tcol.iterator();
		while (buff1.hasNext()) {
			String element = (String) buff1.next();
			result.addAll(this.getUser(element));
		}
		
		Iterator buff2 = pcol.iterator();
		while (buff2.hasNext()) {
			String element = (String) buff2.next();
			result.addAll(this.getUser(element));
		}
		
		Iterator resbuff = result.iterator();
		Collection cc = new Vector();
		//System.out.println("clear");
		while (resbuff.hasNext()) {
			String element = (String) resbuff.next();
			//System.out.println(cc.contains(element));
			if (!cc.contains(element)) {
				cc.add(element);
			}
		}
		result = cc;
		return result;
	}
	//	resolve all user_id in tyep of actor_def
	// actor_Def = Q1000
	public Collection getUser(String actor_Def){
		// detect Queue , user ,
		if (actor_Def.substring(0,1).equals("Q")) {
			//System.out.println(actor_Def);
			super.initMyTable(TBL_QUEUE_USER);
			super.setFilter(FLD_QUEUE_CODE,actor_Def.substring(1,actor_Def.length()));
			//this.SQL = "select * from "+TBL_QUEUE_USER+" where "+
			//	  	FLD_QUEUE_CODE+" = "+actor_Def.substring(1,actor_Def.length());
		} else if (actor_Def.substring(0,1).equals("T")){
			//System.out.println(actor_Def);
			super.initMyTable(TBL_TEAM_USER);
			super.setFilter(FLD_TEAM_CODE,actor_Def.substring(1,actor_Def.length()));
			//this.SQL = "select * from "+TBL_TEAM_USER+" where "+
			//		FLD_TEAM_CODE+" = "+actor_Def.substring(1,actor_Def.length());
		} else if (actor_Def.substring(0,1).equals("P")) {
			//System.out.println(actor_Def);
			super.initMyTable(TBL_POSITION_USER);
			super.setFilter(FLD_POSITION_CODE,actor_Def.substring(1,actor_Def.length()));
			//this.SQL = "select * from "+TBL_POSITION_USER+" where "+
			//		FLD_POSITION_ID+" = "+actor_Def.substring(1,actor_Def.length());
		} else if (actor_Def.substring(0,1).equals("@")) {
			super.initMyTable(TBL_POSITION_USER);
			super.setFilter(FLD_POSITION_ID,actor_Def.substring(1));
		}
		//System.out.println(SQL);
		//System.out.println(actor_Def.substring(1,2));
		//this.rs = super.executeQuery(this.SQL);
		ResultSet rs = super.search();
		Collection res_col = new Vector();
		try {
			while(rs.next()) {
				res_col.add(rs.getString(FLD_USER_CODE));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return res_col;
	}
	
	//resolve all user in the actor_def of Initiator_Def or Recipient_Def
	public Collection getAllUsers(String actor_Def) {
		String a = new String(actor_Def);
		Collection res_col = new Vector();
		//System.out.println(a.indexOf("]")+1);
		while (a.length() > 1) {
			//System.out.println(a+a.length());
			//System.out.println(a.substring(1,2));
			if (a.substring(1,2).equals("U")) {
				res_col.add(a.substring(2,a.indexOf("]")));
				//System.out.println(a.substring(1));
			}
			try {
				a = a.substring(a.indexOf("]")+1);
			} catch (Exception e) {
				a = "";
			}
		}
		return res_col;
	}
	//resolve all team in tyep of actor_def
	public Collection getAllTeam(String actor_Def){
		String a = new String(actor_Def);
		Collection res_col = new Vector();
		while (a.length() > 1) {
			if (a.substring(1,2).equals("T")) {
				res_col.add(a.substring(1,a.indexOf("]")));
			}
			try {
				a = a.substring(a.indexOf("]")+1);
			} catch (Exception e) {
				a = "";
			}
		}
		return res_col;
	}
	//resolve all Queue in tyep of actor_def
	public Collection getAllQueue(String actor_Def){
		String a = new String(actor_Def);
		Collection res_col = new Vector();
		while (a.length() > 1) {
			if (a.substring(1,2).equals("Q")) {
				res_col.add(a.substring(1,a.indexOf("]")));
			}
			try {
				a = a.substring(a.indexOf("]")+1);
			} catch (Exception e) {
				a = "";
			}
		}
		return res_col;
	}
	public Collection getAllPosition(String actor_Def){
		String a = new String(actor_Def);
		Collection res_col = new Vector();
		while (a.length() > 1) {
			if (a.substring(1,2).equals("P")) {
				res_col.add(a.substring(1,a.indexOf("]")));
			}
			try {
				a = a.substring(a.indexOf("]")+1);
			} catch (Exception e) {
				a = "";
			}
		}
		return res_col;
	}
	
	//	resolve user in role
	public String getUserRole(String role,String user_code,String position_code) {
		String code = " ";
		
		if (role.equals("XALL")) {
			code = user_code+" "+position_code;
		} else if (role.equals("FSUP") || role.equals("ISUP")) {
			code = this.getTraceup(user_code,position_code);
			/*
			// user_code that input into this method is step before
			Database db1 = new Database("workflow");
			// get position id form user_code and position_code
			db1.initMyTable(TBL_POSITION_USER);
			db1.setFilter(FLD_POSITION_CODE,position_code);
			db1.setFilter(FLD_USER_CODE,user_code);
			ResultSet rs1 = db1.search();			
			db1.nextRecord(rs1);
			String position_id = db1.getColumn(rs1,FLD_POSITION_ID);
			// get Report position of upper position_id 
			Database db2 = new Database("workflow");
			db2.initMyTable(TBL_POSITION);
			db2.setFilter(FLD_POSITION_ID,position_id);
			ResultSet rs2 = db2.search();
			db2.nextRecord(rs2);
			String report_position = db2.getColumn(rs2,FLD_REPORT_POSITION);
			Database db3 = new Database("workflow");
			db3.initMyTable(TBL_POSITION_USER);
			db3.setFilter(FLD_POSITION_ID,report_position);
			ResultSet rs3 = db3.search();
			//db3.nextRecord(rs3);
			Database db4 = new Database("workflow");
			db4.initMyTable(TBL_USER);
			db4.setFilter(FLD_USER_CODE,user_code);
			ResultSet rs4 = db4.search();
			db4.nextRecord(rs4);
			String command_line = db4.getColumn(rs4,FLD_COMMAND_LINE);
			while (db3.nextRecord(rs3)) {
				String user = db3.getColumn(rs3,FLD_USER_CODE);
				user += " "+db3.getColumn(rs3,FLD_POSITION_CODE);
				if (command_line.indexOf(user) != -1) {
					code = user;
					break;
				}
			}
			*/
		} else if (role.substring(0,1).equals("F") || role.substring(0,1).equals("I")) {
			boolean fin = true;
			String utemp = user_code;
			String ptemp = position_code;
			Database db = new Database("workflow");
			ResultSet rs = null;
			while (fin) {
				String temp = this.getTraceup(utemp,ptemp);
				if (!temp.equals(" ")) {
					utemp = temp.substring(0,temp.indexOf(" "));
					ptemp = temp.substring(temp.indexOf(" ")+1);
					db.initMyTable(TBL_POSITION_USER);
					db.setFilter(FLD_USER_CODE,utemp);
					db.setFilter(FLD_POSITION_CODE,ptemp);
					rs = db.search();
					db.nextRecord(rs);
					String pid = db.getColumn(rs,FLD_POSITION_ID);
					db.initMyTable(TBL_POSITION);
					db.setFilter(FLD_POSITION_ID,pid);
					rs = db.search();
					db.nextRecord(rs);
					String rtemp = db.getColumn(rs,FLD_ROLE);
					if (rtemp.length() > role.substring(1).length()) {
						if (rtemp.substring(0,role.substring(1).length()).toUpperCase().equals(role.substring(1))) {
							fin = false;
							code = temp;
						}
					} else if (rtemp.toUpperCase().equals(role.substring(1))) {
						fin = false;
						code = temp;
					} else if (temp.substring(temp.indexOf(" ")+1).equals("1")) {
						fin = false;
					}
				} else {
					fin = false;
				}
				
			}
		} else if (role.equals("XINIT")) {
			//initiator recieve from outside
			code = user_code;
		}
		return code;
	}
	private String getTraceup(String user_code,String position_code) {
		Database db1 = new Database("workflow");
		db1.initMyTable(TBL_POSITION_USER);
		db1.setFilter(FLD_USER_CODE,user_code);
		db1.setFilter(FLD_POSITION_CODE,position_code);
		ResultSet rs = db1.search();
		db1.nextRecord(rs);
		//get position of user and position code that input this method
		String pid = db1.getColumn(rs,FLD_POSITION_ID);
		String coml = db1.getColumn(rs,FLD_COMMAND_LINE);
		//get report position
		//db1 = new Database("workflow");
		db1.initMyTable(TBL_POSITION);
		db1.setFilter(FLD_POSITION_ID,pid);
		rs = db1.search();
		db1.nextRecord(rs);
		String reppos = db1.getColumn(rs,FLD_REPORT_POSITION);
		// get about position id
		db1.initMyTable(TBL_POSITION_USER);
		db1.setFilter(FLD_POSITION_ID,reppos);
		rs = db1.search();
		String repuser = "";
		String reppsc = "";
		boolean found = false;
		if (db1.nextRecord(rs)) {
			found = true;
			repuser = db1.getColumn(rs,FLD_USER_CODE);
			reppsc = db1.getColumn(rs,FLD_POSITION_CODE);
			/*
			if (reppsc.length() < coml.length()) {
				if (coml.substring(0,reppsc.length()).equals(reppsc)) {
					found = true;
					break;
				}
			} else if (coml.equals(reppsc)) {
				found = true;
				break;
			}
			*/
		} else if (reppos.equals("0")) {
			repuser = user_code;
			reppsc = position_code;
			found = true;
		}
		String out = " ";
		if (found) {
			out = repuser+" "+reppsc;
		}
		return out;
	}
	// get all role in actor definition
	public Collection getAllRole(String actor_Def) {
		String a = new String(actor_Def);
		Vector v = new Vector();
		while (a.length() > 1) {
			String b = a.substring(1,2);
			if (b.equals("X") || b.equals("I") || b.equals("F")) {
				v.addElement(a.substring(1,a.indexOf("]")));
			}
			a = a.substring(a.indexOf("]")+1);
		}
		return v;
	}
	public boolean isMemberActorDef(String user_code,String actor_def){
		int member=0;
		String u="";
		if (actor_def.indexOf("XALL") > -1) {
			member = 1;
		} else {
			Collection c=getRefActor(actor_def);
			Collection c1 = this.getAllQueue(actor_def);
			Iterator i1 = c1.iterator();
			while (i1.hasNext()) {
				c.addAll(this.getUser((String)i1.next()));
			}
			Iterator i=c.iterator();
			while( i.hasNext() && member == 0 ){
				u=(String)i.next();
				//System.out.println(u+"sss");
				if( u.equals(user_code) ){
					member++;
				}
			}
		}
		return (member==1)?true:false;
	}
}