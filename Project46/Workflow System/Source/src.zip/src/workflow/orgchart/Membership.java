/*
 * Created on 21 �.�. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package workflow.orgchart;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Properties;
import java.util.Vector;

import util.Database;
import util.DatabaseField;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Membership implements DatabaseField{
	public Membership(){
	}
	// get properties all Q and position_code
	public Collection getAllQMember(String user_code){
		Database db=new Database("workflow");
		Vector q=new Vector();
		Properties p;
		ResultSet rs;
		db.initMyTable(TBL_QUEUE_USER);
		db.setColumn(FLD_QUEUE_CODE);
		//db.setColumn(FLD_POSITION_CODE);
		db.setFilter(FLD_USER_CODE,user_code);
		rs=db.search();
		while( db.nextRecord(rs)){
			p=new Properties();
			p.setProperty(FLD_QUEUE_CODE,db.getColumn(rs,FLD_QUEUE_CODE));
			//p.setProperty(FLD_POSITION_CODE,db.getColumn(rs,FLD_POSITION_CODE));
			q.addElement(p);
		}
		return q;
	}
	// get all team and position_code
	public Collection getAllTMember(String user_code){
		Database db=new Database("workflow");
		Vector t=new Vector();
		db.initMyTable(TBL_TEAM_USER);
		db.setColumn(FLD_TEAM_CODE);
		db.setColumn(FLD_POSITION_CODE);
		db.setFilter(FLD_USER_CODE,user_code);
		ResultSet rs=db.search();
		Properties team;
		while( db.nextRecord(rs)){
			team=new Properties();
			team.setProperty(FLD_TEAM_CODE,db.getColumn(rs,FLD_TEAM_CODE));
			//team.setProperty(FLD_POSITION_CODE,db.getColumn(rs,FLD_POSITION_CODE));
			t.addElement(team);
		}
		return t;
	}
	public Collection getAllPMember(String user_code){
		Database db=new Database("workflow");
		Vector p=new Vector();
		ResultSet rs;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn(FLD_POSITION_CODE);
		db.setFilter(FLD_USER_CODE,user_code);
		rs=db.search();
		Properties post_code=null;
		while( db.nextRecord(rs) ){
			post_code=new Properties();
			post_code.setProperty(FLD_POSITION_CODE,db.getColumn(rs,FLD_POSITION_CODE));
			p.addElement(post_code);
		}
		return p;
	}
	public Collection getAllPidMember(String user_code){
		Database db=new Database("workflow");
		Vector r=new Vector();
		ResultSet rs;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn(FLD_POSITION_ID);
	    db.setColumn(FLD_POSITION_CODE);
		db.setFilter(FLD_USER_CODE,user_code);
		rs=db.search();
		Properties rl;
		while( db.nextRecord(rs) ){
			rl=new Properties();
			rl.setProperty(FLD_POSITION_ID,db.getColumn(rs,FLD_POSITION_ID));
			rl.setProperty(FLD_POSITION_CODE,db.getColumn(rs,FLD_POSITION_CODE));
			r.addElement(rl);
		}
		return r;
	}
	public Collection getAllRMember(String user_code){
		Database db=new Database("workflow");
		Collection pid=getAllPidMember(user_code);
		Vector r=new Vector();
		ResultSet rs;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn("DISTINCT("+FLD_ROLE+")");
		db.setFilter(FLD_USER_CODE,user_code);
		rs=db.search();
		Properties rl;
		while( db.nextRecord(rs) ){
			rl=new Properties();
			rl.setProperty(FLD_ROLE,db.getColumn(rs,FLD_ROLE));
			r.addElement(rl);
		}
		return r;
	}
	/////////////////   IS Member Ship
	public boolean isPostIdInR(String post_id){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn(FLD_ROLE);
		db.setFilter(FLD_POSITION_ID,post_id);
		ResultSet rs=db.search();
		if( db.nextRecord(rs) )// has resultSet
			result=true;
		else
			result=false;
		return result;
	}
	public void getAllPostCodeInRole(){
		
	}
	public void getAllPostCodeInPostId(){
		
	}
	public Vector getAllPostIdInRole(String role){
		return new Vector();
	}
	public String getRoleByPostId(String post_id){
		return "";
	}
	public String getRoleByPostCode(String post_code){
		return "";
	}
	public boolean isQMember(String user_code,String queue_code){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_QUEUE_USER);
		db.setColumn(FLD_USER_CODE);
		db.setFilter(FLD_QUEUE_CODE,queue_code);
		ResultSet rs=db.search();
		if( db.nextRecord(rs) )// has resultSet
			result=true;
		else
			result=false;
		return result;
	}
	public boolean isTMember(String user_code,String team_code){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_TEAM_USER);
		db.setColumn(FLD_USER_CODE);
		db.setFilter(FLD_TEAM_CODE,team_code);
		ResultSet rs=db.search();
		if( db.nextRecord(rs) )// has resultSet
			result=true;
		else
			result=false;
		return result;
	}
	public boolean isPMemeber(String user_code,String post_code){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn(FLD_USER_CODE);
		db.setFilter(FLD_POSITION_CODE,post_code);
		ResultSet rs=db.search();
		if( db.nextRecord(rs) )// has resultSet
			result=true;
		else
			result=false;
		return result;
	}
	// user_code is existing in position_id ?
	public boolean isPidMember(String user_code,String post_id){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_POSITION_USER);
		db.setColumn(FLD_USER_CODE);
		db.setFilter(FLD_POSITION_ID,post_id);
		ResultSet rs=db.search();
		if( db.nextRecord(rs) )// has resultSet
			result=true;
		else
			result=false;
		return result;
	}
	public boolean isRMember(String user_code,String role){
		Database db=new Database("workflow");
		boolean result=false;
		db.initMyTable(TBL_POSITION);
		db.setColumn(FLD_POSITION_ID);
		db.setFilter(FLD_ROLE,role);
		ResultSet rs=db.search();
		int exist=0;
		while( db.nextRecord(rs) ){
			result=this.isPidMember(user_code,db.getColumn(rs,FLD_POSITION_ID));
			exist++;
		}
		result= (exist > 0)?true:false;
		return result;
	}
	public boolean isMemberInitiator(String initator){
		ResolveActor ra=new ResolveActor();
			
		return false;
	}
}