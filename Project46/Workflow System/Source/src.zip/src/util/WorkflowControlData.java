/*
 * Created on 30 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;
/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface WorkflowControlData {
		   //	Actor of workflow System
		 static final String ACTOR_ADMIN = "0";
		 static final String ACTOR_ANONYMOUS = "-1";
		 static final String ACTOR_ENGINE = "-2";
		 static final String ACTOR_AUTOMATIC = "-3";
		 static final String ACTOR_NO_RECIPIENT = "-4";
		   
		    //  Actor incident status
		 static final String STATUS_AI_ACTIVE = "1"; // when which incident occur
	 	 static final String STATUS_AI_APPROVE = "2";// when user dicisiion approve
		 static final String STATUS_AI_IGNORE = "3";// this actor_incident is ignored by engine
		 static final String STATUS_AI_ABORT = "4";//when user dicisiion abort
		 static final String STATUS_AI_DISAPPROVE = "5";//when user dicisiion disapprove
		 static final String STATUS_AI_RETURN = "6";//when user dicisiion return
		 static final String STATUS_AI_ASSIGN = "7";//when user dicisiion assign
		 static final String STATUS_AI_COMMNET = "8";// when comment in incident
	     static final String STATUS_AI_TAKEN = "9"; // when actor incident taken by supervisor
	     static final String STATUS_AI_TAKE = "10"; // take by me
		 static final String STATUS_AI_ASSIGN_COMPLETE = "10";
	     
	     // step status will force status of actor incident to be same  
			//	stepIncident status
		 static final String STATUS_ST_ACTIVE = "1";
		 static final String STATUS_ST_COMPLETE = "2"; // workflowIncident is end.
	 	 static final String STATUS_ST_ABORT = "3";
		 static final String STATUS_ST_NO_RECIPIENT = "4";
		 static final String STATUS_ST_NOTCOMPLETE = "5"; // fail or aborted
	 	 static final String STATUS_ST_RETURN = "6";
		 static final String STATUS_ST_IGNORE = "7";
		 static final String STATUS_ST_MAIL_SEND = "8";

			// queue Incident status
		 static final String STATUS_QT_ACTIVE = "1";
		 static final String STATUS_QT_COMPLETE = "2";
		 static final String STATUS_QT_NOTCOMPLETE = "3";
		 static final String STATUS_QT_ASSIGN_COMPLETE = "4";
		 static final String STATUS_QT_ASSIGN_NOTCOMPLETE = "5";
		 static final String STATUS_QT_COMMENT_COMPLETE = "6";
		 static final String STATUS_QT_COMMENT_NOTCOMPLETE = "7";
		 
		 	// workflowIncident status
		 static final String STATUS_WF_CREATED_NOT_COMPLETE="0";	
		 static final String STATUS_WF_ACTIVE = "1";
		 static final String STATUS_WF_COMPLETE = "2";
		 static final String STATUS_WF_ABORT = "3";// abort workfowIncident abort
		 static final String STATUS_WF_NO_RECIPIENT = "4"; // when workflowIncident abort with no recipient
		 	
		 	// step Time Status
		 static final String STATUS_T_IDLE = "1"; // idel time
		 static final String STATUS_T_NORMAL = "2"; // on time
		 static final String STATUS_T_EXTENSION = "3";// on time extension
		 static final String STATUS_T_LATE = "4"; // on time late

			// Event Type
		 static final String EVENT_APPROVE = "1";
		 static final String EVENT_DISAPPROVE = "2";
		 static final String EVENT_ABORT = "3";
		 static final String EVENT_ASSIGN = "4";
		 static final String EVENT_RETURN = "5";
			
			// command
		/*
		 static final String CMD_APPROVE = "approve" ;
		 static final String CMD_DISAPPROVE = "disapprove" ;
		 static final String CMD_ABORT = "abort" ;
		 static final String CMD_RETURN = "return" ;
		 static final String CMD_ASSIGN = "assign" ;
		// static final String CMD_SEND = "send" ;// for initiate work
		 static final String CMD_SAVE = "save" ;
		 */
		 
			// step type
		 static final String START_STEP="1";
		 static final String NORMAL_STEP="2";
		 static final String END_STEP="3";// can be several steps
		 static final String AUTOMATIC_STEP="4";// automatic step
		
			// var type
		 static final String TEXT ="0";
		 static final String NUMBER ="1";
		 static final String DATE_TIME ="2";
		 static final String INITATOR="3";
		 static final String RECIPIENT="4";
		 static final String BOOLEAN="5";
		 static final String FORMULA="6";
		 
			// web component
		 static final String TEXT_FIELDS="0";
		 //static final String CHECK_BOX="1";
		 //static final String RADIO_BUTTON="2";
		 static final String LIST_BOX="3";
		 //static final String FILE_FIELDS="4";

			// Priority of work
		 static final String NONE="0";
		 static final String LOW="1";
		 static final String MEDIUM="2";// default
		 static final String HIGH="3";
		 static final String VERY_HIGH="4";
		
			// step variable access
		 static final String NOT_ACCESSIBLE="0";
		 static final String READ_ONLY="1";
		 static final String WRITE_ONLY="2";
		 static final String READ_WRITE="3";
		 
		 	// Attached status
		 static final String MUST_ATTACHED="0";
		 static final String ATTACHABLE="1";
		 static final String NON_ATTACHED="2";
		 
			// special field
		 static final String QASSIGN = "qassign";
		 static final String QCOMMENT = "qcomment";
		 static final String QSUB = "qsub";
		 static final String NULLABLE="1";// about form
		 static final String VALUE="value";// about form
}