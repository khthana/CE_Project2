/*
 * Created on 10 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
/*
Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
//DriverManager.registerDriver(new com.microsoft.jdbc.sqlserver.SQLServerDriver());
Connection connection = DriverManager.getConnection(
"jdbc:microsoft qlserver://161.246.6.82:1433","sa","123456");
*/
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
public class Database{
	//private  String driver="com.microsoft.jdbc.sqlserver.SQLServerDriver";
	//private  String url= "jdbc:microsoft:sqlserver://161.246.6.82:1433";
	//private  String user="ssa";
	//private  String passwd="123456";
		// ascess
	//private  String driver="sun.jdbc.odbc.JdbcOdbcDriver";
	//private  String url= "jdbc:odbc:";
	//private  String user="root";
	//private  String passwd="";
	
	private  String driver="org.gjt.mm.mysql.Driver";
	private  String url= "jdbc:mysql://161.246.6.82:3306/";
	private  String user="root";
	private  String passwd="";
	private  Connection con=null;
	private  Statement stm=null;
	private  ResultSet rs=null;
	protected String SQL="";
    
	public Database(String db) {
		try{
			Class.forName(driver);
			con=DriverManager.getConnection(url+db,user,passwd);//url+db
			stm=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	/*public  void createStm(){
		try{
			stm=con.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}*/
	/*
	public static Database getInitialDB(ResultSet re,String dbname) {
		Database db = new Database(dbname);
		db.setResultSet(re);
		return db;
	}
	private void setResultSet(ResultSet re) {
		this.rs = re;
	}
	*/
	public String getColumn(ResultSet re,String  col){
		//ResultSet re = this.rs;
		ResultSet ree = re;
		String result = "";
		try{
			result=ThaiUtilities.ASCII2Unicode(ree.getString(col));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return result;
	}
	public String getColumn(ResultSet re,int i) {
		ResultSet ree = re;
		String result = "";
		try {
			result = ThaiUtilities.ASCII2Unicode(ree.getString(i));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}
	public void executeUpdate(String SQL){
		try{
			//System.out.println(stm.executeUpdate(SQL));
			stm.executeUpdate(SQL);
			this.clearCommand();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public ResultSet executeQuery(String SQL){
		try{
			rs=stm.executeQuery(SQL);
			this.clearCommand();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return rs;
	}
	public boolean nextRecord(ResultSet re){
		boolean next=false;
		try{
			next=re.next();//this.rs.next();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return next;
	}
	/*
	public void finalize(){
		try{
			stm.close();
			con.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}*/
	protected void finalize() throws Throwable {
		try {
			stm.close();
			con.close();
		} finally {
			super.finalize();
		}
	}
 	private void clearCommand(){
 		data.clear();
 		keyd.clear();
 		fd.clear();
 		fk.clear();
 		table=null;
 		order.clear();
 		group.clear();
 		column.clear();
 		desc=false;
 		jcond = null;
 		databet.clear();
 		keybet.clear();
 		datain.clear();
 		keyin.clear();
 		datalike.clear();
 		keylike.clear();
 	}
	//private Properties data = new Properties();
	//private Properties keyd = new Properties();
	private ArrayList data = new ArrayList();
	private ArrayList keyd = new ArrayList();
	private ArrayList fd= new ArrayList();
	private ArrayList fk = new ArrayList();
	private ArrayList order = new ArrayList();
	private ArrayList group = new ArrayList();
	private ArrayList column = new ArrayList();
	private ArrayList keyin = new ArrayList();
	private ArrayList datain = new ArrayList();
	private ArrayList keylike = new ArrayList();
	private ArrayList datalike = new ArrayList();
	private boolean desc = false;
	private String table = null;
	private String jcond = "";
	private ArrayList databet = new ArrayList();
	private ArrayList keybet = new ArrayList();
	
	public void initMyTable(String inittable) {
		table = inittable;
	}
	public void joinTable(String jtable) {
		table = table+", "+jtable;
	}
	public void setJoinCondition(String condition) {
		if (jcond.equals("")||jcond==null||jcond.equals(" ")) {
			jcond = condition;
		} else {
			jcond += " and "+condition;
		}
	}
	public void enableDesc() {
		this.desc = true;
	}
	public void disableDesc() {
		this.desc = false;
	}
	public ResultSet search() { 
		String a = "";
		if (!(jcond == null||jcond.equals("")||jcond.equals(" "))) {
			a += jcond+" and ";
		}
		if (!fk.isEmpty()) {
			for (int i = 0;i < fk.size()-1;i++) {
				a += fk.get(i);
				a += "=";
				a += fd.get(i);
				a += " and ";
			}
			a += fk.get(fk.size()-1);
			a += "=";
			a += fd.get(fk.size()-1);
			a = " where "+a;
		}
		if (!keyin.isEmpty()) {
			if (!(a.equals("")||a.equals(" "))) {
				a += " and ";
			} else {
				a += " where ";
			}
			for (int i=0;i<keyin.size()-1;i++) {
				a += keyin.get(i);
				a += " in ";
				a += datain.get(i);
				a += " and ";
			}
			a += keyin.get(keyin.size()-1);
			a += " in ";
			a += datain.get(datain.size()-1);
		}
		if (!keylike.isEmpty()) {
			if (!(a.equals("")||a.equals(" "))) {
				a += " and ";
			} else {
				a += " where ";
			}
			for (int i=0;i<keylike.size()-1;i++) {
				a += keylike.get(i);
				a += " like ";
				a += datalike.get(i);
				a += " and ";
			}
			a += keylike.get(keylike.size()-1);
			a += " like ";
			a += datalike.get(datalike.size()-1);
		}
		if (!keybet.isEmpty()) {
			if (!(a.equals("")||a.equals(" "))) {
				a += " and ";
			} else {
				a += " where ";
			}
			for (int i=0;i<keybet.size()-1;i++) {
				a += keybet.get(i);
				a += " between ";
				a += databet.get(i);
				a += " and ";
			}
			a += keybet.get(keybet.size()-1);
			a += " between ";
			a += databet.get(databet.size()-1);
		}
		String b = "";
		if (!column.isEmpty()) {
			for (int i = 0;i<column.size()-1;i++) {
				b += column.get(i);
				b += ", ";
			}
			b += column.get(column.size()-1);
		} else {
			b += " * " ;
		}
		String c = "";
		if (!order.isEmpty()) {
			c += " order by ";
			for (int i = 0;i<order.size()-1;i++) {
				c += order.get(i);
				c += ", ";
			}
			c += order.get(order.size()-1);
			if (desc) {
				c += " desc";
			}
		}
		String d = "";
		if (!group.isEmpty()) {
			d += " group by ";
			for (int i = 0;i<group.size()-1;i++) {
				d += group.get(i);
				d += ", ";
			}
			d += group.get(group.size()-1);
		}
		SQL = "select "+b+" from "+table+a+c+d;
		//System.out.println(SQL);
		this.rs = this.executeQuery(SQL);
		return this.rs;
	}
	public void update() {
		String a = "";
		for (int i = 0;i<keyd.size()-1;i++) {
			a += keyd.get(i);
			a += "=";
			a += data.get(i);
			a += ",";
		}
		a += keyd.get(keyd.size()-1);
		a += "=";
		a += data.get(keyd.size()-1);
		
		String b = "";
		if (!fk.isEmpty()) {
			for (int i = 0;i<fk.size()-1;i++) {
				b += fk.get(i);
				b += "=";
				b += fd.get(i);
				b += " and ";
			}
			b += fk.get(fk.size()-1);
			b += "=";
			b += fd.get(fk.size()-1);
			b = " where "+b;
		}
		SQL = "update "+table+" set "+a+b;
		//System.out.println(SQL);
		//this.executeUpdate(SQL);
		this.executeUpdate(SQL);
	}
	public void insert() {
		String a = "(";
		String b = "(";
		for (int i = 0;i < keyd.size()-1;i++) {
			a += keyd.get(i);
			a += ",";
			b += data.get(i);
			b += ",";
		}
		a+= keyd.get(keyd.size()-1);
		b+= data.get(data.size()-1);
		a += ")";
		b += ")";
		SQL = "insert into "+table+" "+a+" values "+b;
		//System.out.println(SQL);
		//this.executeUpdate(SQL);
		this.executeUpdate(SQL);
	}
	public void delete() {
		String a = "";
		if (!fk.isEmpty()) {
			for (int i = 0;i < fk.size()-1;i++) {
				a += fk.get(i);
				a += "=";
				a += fd.get(i);
				a += " and ";
			}
			a += fk.get(fk.size()-1);
			a += "=";
			a += fd.get(fk.size()-1);
			a = " where "+a;
		}
		SQL = "delete from "+table+a;
		//System.out.println(SQL);
		this.executeUpdate(SQL);
	}
	
	public void setColumn(String key) {
		boolean b = column.contains(key);
		if (!b) {
			column.add(key);
		}
	}
	// set order
	public void setOrder(String key) {
		boolean b = order.contains(key);
		if (!b) {
			order.add(key);
		}
	}
	// set group by
	public void setGroupBy(String key) {
		boolean b = group.contains(key);
		if (!b) {
			group.add(key);
		}
	}
	// set Whers Condition
	public void setFilter(String key,boolean val) {
		fk.add(key);
		String a = "";
		if (val) {
			a = "1";
		} else {
			a = "0";
		}
		fd.add(String.valueOf(a));
	}
	public void setFilter(String key,int val) {
		fk.add(key);
		fd.add(String.valueOf(val));
	}
	public void setFilter(String key,long val) {
		fk.add(key);
		fd.add(String.valueOf(val));
	}
	public void setFilter(String key,double val) {
		fk.add(key);
		fd.add(String.valueOf(val));
	}
	public void setFilter(String key,float val) {
		fk.add(key);
		fd.add(String.valueOf(val));
	}
	public void setFilter(String key,String val) {
		String s = "'"+val+"'";
		//if (keyd.contains(key)) {
			//String a = (String)data.get(keyd.indexOf(key));
			//s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
			//fd.set(fk.indexOf(key),s);
		//} else {
			fk.add(key);
			fd.add(s);
		//}
	}
	public void setFilter(String key,Date val) {
		String s = "'"+val.toString()+"'";
		if (keyd.contains(key)) {
			String a = (String)data.get(keyd.indexOf(key));
			s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
		}
		fk.add(key);
		fd.add(s);
	}
	public void setFilter(String key,Timer val) {
		String s = "'"+val.toString()+"'";
		if (keyd.contains(key)) {
			String a = (String)data.get(keyd.indexOf(key));
			s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
		}
		fk.add(key);
		fd.add(s);
	}
	public void setFilterIn(String key,String val) {
		//String s = "'"+val+"'";
		keyin.add(key);
		datain.add(val);
	}
	public void setFilterLike(String key,String val) {
		String s = "'"+val+"'";
		keylike.add(key);
		datalike.add(s);
	}
	public void setFilterBetween(String field,String val1,String val2) {
		String s = "'"+val1+"' and '"+val2+"'";
		keybet.add(field);
		databet.add(s);
	}
	
	// set DATA
	public void set(String key,boolean val) {
		keyd.add(key);
		String a = "";
		if (val) {
			a = "1";
		} else {
			a = "0";
		}
		data.add(String.valueOf(a));
	}
	public void set(String key,int val) {
		keyd.add(key);
		data.add(String.valueOf(val));
	}
	public void set(String key,long val) {
		keyd.add(key);
		data.add(String.valueOf(val));
	}
	public void set(String key,double val) {
		keyd.add(key);
		data.add(String.valueOf(val));
	}
	public void set(String key,float val) {
		keyd.add(key);
		data.add(String.valueOf(val));
	}
	public void set(String key,String val) {
		String s = "'"+val+"'";
		//if (keyd.contains(key)) {
		//	String a = (String)data.get(keyd.indexOf(key));
		//	s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
		//	data.set(keyd.indexOf(key),s);
		//} else {
			keyd.add(key);
			data.add(s);
		//}
	}
	public void set(String key,Date val) {
		String s = "'"+val.toString()+"'";
		if (keyd.contains(key)) {
			String a = (String)data.get(keyd.indexOf(key));
			s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
			data.set(keyd.indexOf(key),s);
		} else {
			keyd.add(key);
			data.add(s);
		}
	}
	public void set(String key,Timer val) {
		String s = "'"+val.toString()+"'";
		if (keyd.contains(key)) {
			String a = (String)data.get(keyd.indexOf(key));
			s = a.substring(0,a.length()-1)+" "+s.substring(1,s.length());
			data.set(keyd.indexOf(key),s);
		} else {
			keyd.add(key);
			data.add(s);
		}
	}
}