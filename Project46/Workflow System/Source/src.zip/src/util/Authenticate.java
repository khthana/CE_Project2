/*
 * Created on 29 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;

import java.sql.ResultSet;

import organization.OrganizationComponent;
import organization.User;
import organization.Imp.OrganizationComponentImp;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Authenticate implements WorkflowControlData,DatabaseField{
	public Authenticate(){
		
	}
	public UserProfile verifyPassword(String user_code,String passwd){
		boolean ok=false;
		UserProfile up=null;
			// prove user
		OrganizationComponent oc=new OrganizationComponentImp();
		User u=oc.findUserById(user_code);
		if( u != null ){  // not user in system ?	
			if( u.getPasswd().equals(passwd) )
				ok=true;
			else
				ok=false;
		}else
			ok=false; // not found user_code or password is in correct
		return (ok)?getUserProfile(u):null;
	}
	private UserProfile getUserProfile(User u){
			// set user profile prepared to send out to UI
		UserProfile up=new UserProfile(u.getUserCode());
		up.setUName(u.getUserName());
		up.setEmail(u.getEmail());
		up.setUType(u.getUType());
		Database mydb =new Database("workflow");
		String sql="select * from "+TBL_POSITION_USER+" where "+FLD_USER_CODE+"='"+u.getUserCode()+"'";
		ResultSet rs=mydb.executeQuery(sql);
		if ( mydb.nextRecord(rs) )
			up.setPosition(mydb.getColumn(rs,FLD_POSITION_CODE));
		return up;
	}
}