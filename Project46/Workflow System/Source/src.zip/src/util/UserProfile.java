/*
 * Created on 22 ?.?. 2547
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;


/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class UserProfile {
	private String user_code;
	private String user_name;
	private String email;
	private String utype;
	private String position_code;
	public UserProfile(String user_code){
		this.user_code=user_code;
	}
	public void setUcode(String pcode){
		this.position_code=pcode;
	}
	public String getUcode(){
		return this.user_code;
	}
	public void setUName(String name){
		this.user_name=name;
	}
	public String getUName(){
		return this.user_name;
	}
	public void setEmail(String email){
		this.email=email;
	}
	public String getEmail(){
		return this.email;
	}
	public void setUType(String utype){
		this.utype=utype;
	}
	public String getUType(){
		return this.utype;
	}
	public void setPosition(String pcode){
		this.position_code=pcode;
	}
	public String getPosition(){
		return this.position_code;
	}
}
