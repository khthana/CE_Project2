/*
 * Created on 24 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;

import java.util.Calendar;

/**
 * @author KIM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MyCalendar{
	
	public MyCalendar () {
	}
	public static String getDate() {
		Calendar ca = Calendar.getInstance();
		String date = String.valueOf(ca.get(1))+"-"+String.valueOf(ca.get(2))+"-"+String.valueOf(ca.get(5));
		return date;
	}
	public static String getTime() {
		Calendar ca = Calendar.getInstance();
		String time = String.valueOf(ca.get(11)+":"+String.valueOf(ca.get(12))+":"+String.valueOf(ca.get(13)));
		return time;
	}
	public static String getDataTime() {
		return getDate()+" "+getTime();
	}
	public static String convertPattern(String datetime) {
		String dttemp = datetime.substring(0,datetime.indexOf(" "));
		String year = dttemp.substring(dttemp.lastIndexOf("-")+1);
		String month = dttemp.substring(dttemp.indexOf("-")+1,dttemp.lastIndexOf("-"));
		String day = dttemp.substring(0,dttemp.indexOf("-"));
		dttemp = year+"-"+month+"-"+day+" "+datetime.substring(datetime.indexOf(" ")+1);
		return dttemp;
	}
	public static int calcDateDifference(float  calendarItem, java.util.Date d1, java.util.Date d2) {
		 int x = 1000;
		 if (calendarItem == Calendar.DAY_OF_MONTH)   { // �Ԩ�ó�������ҧ�����ҧ�ѹ
			x = x * 60 * 60 * 24;
		 } else
			 if (calendarItem == Calendar.HOUR_OF_DAY)   { // �Ԩ�ó�������ҧ�����ҧ��.
				 x = x * 60 * 60;
		} else
			if (calendarItem == Calendar.MINUTE) { // �Ԩ�ó�������ҧ�����ҧ�ҷ�
				x = x * 60;
		} else
			return 1;
		 return (int) ((d2.getTime() - d1.getTime())   / (x));
	}
	/*
	 how to use
	  int datediff =
	  calcDateDifference(Calendar.DAY_OF_MONTH,FirstDate.getTime(),SecondDate.getTime());                          
	*/
	public static String getTimeStamp(){
		Calendar rightNow = Calendar.getInstance();
		return Long.toString(rightNow.getTimeInMillis());
	}
}
