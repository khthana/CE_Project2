/*
 * Created on 27 �.�. 2546
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package util;

/**
 * @author Administrator
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface DatabaseField {
		/**
	   	* TableName
	   	*/
		static final String TBL_ACTOR_INCIDENT = "actor_incident" ;
		static final String TBL_ATTATCHED_FILE = "attached_file";
		static final String TBL_AUTO_ASSIGN = "auto_assign";
		static final String TBL_LOG = "log" ;
		static final String TBL_LOG_VAR = "log_var" ;
		static final String TBL_POSITION = "position" ;
		static final String TBL_POSITION_USER = "position_user" ;
		static final String TBL_QUEUE = "queue" ;
		static final String TBL_QUEUE_TRANSFER = "queue_transfer";
		static final String TBL_QUEUE_USER = "queue_user" ;
		static final String TBL_ORGANIZATION_ROLE = "organization_role" ;
		static final String TBL_STEP_DEFINITION = "step_definition" ;
		static final String TBL_STEP_INCIDENT = "step_incident" ;
		static final String TBL_STEP_VAR_ACCESS= "step_var_access";
		static final String TBL_TEAM = "team" ;
		static final String TBL_TEAM_USER = "team_user" ;
		static final String TBL_TRANSITION= "transition";
		static final String TBL_USER = "user" ;
		static final String TBL_UTYPE_PRIVILEGE = "utype_privilege" ;
		static final String TBL_WORKFLOW_VAR_DEFINITION = "wfvar_definition" ;
	  	static final String TBL_WORKFLOW_DEFINITION = "workflow_definition" ;
	  	static final String TBL_WORKFLOW_INCIDENT = "workflow_incident" ;
	  	static final String TBL_WORKFLOW_VARIABLE = "workflow_variable" ;

		/**
		* Field variable in table actor_incident
		*/
		static final String FLD_ACTOR_ID ="actor_id";
		
		/**
		* Field variable in table attach_file
		*/
		static final String FLD_FILE_SEQ_NO ="file_seq_no";
		static final String FLD_FILE_NAME ="file_name";
		static final String FLD_FILE_DESC ="file_desc";
		static final String FLD_FILE_TYPE ="file_type";
		static final String FLD_FILE_DATA ="file_data";
	
		/*
		 * Field variable in table auto_assign
		 */
		static final String FLD_ASSIGN_USER_CODE ="assign_user_code";
		static final String FLD_USE ="use";
		 
		/*
		 * Field variable in table log_var
		 */
		static final String FLD_LOG_ID ="log_id";
		
		/*
		 * Field variable in table position
		 */
		static final String FLD_POSITION_ID = "position_id" ;
		static final String FLD_POSITION_CODE = "position_code" ;
		static final String FLD_POSITION_NAME = "position_name" ;
		static final String FLD_REPORT_POSITION = "report_position" ;
		static final String FLD_ROLE = "role";
		
		/*
		 * Field variable in table queue
		 */
		static final String FLD_QUEUE_CODE = "queue_code" ;
		static final String FLD_QUEUE_NAME = "queue_name" ;
		static final String FLD_QUEUE_TYPE = "queue_type" ;
		static final String FLD_QUEUE_DESC = "queue_desc" ;
		
		/*
		 * Field variable in table queue
		 */
		static final String FLD_TFR_ACTOR_ID = "tfr_actor_id";
		static final String FLD_OWNER_ACTOR_ID = "owner_actor_id";
		
		/*
		 * Field variable in table queue_user
		 */
		static final String FLD_LIST_SEQ = "list_seq" ;
		static final String FLD_WEIGHT = "weight" ;
		
		/*
		 * role 
		 */
		static final String FLD_ROLE_ID = "role_id" ;
		static final String FLD_ROLE_DESC = "role_description" ;
		/**
		 * Field variable in table step_definition
		 */
		static final String FLD_STEP_ID = "step_id";
		static final String FLD_STEP_NAME = "step_name";
		static final String FLD_STEP_DESC = "step_desc";
		static final String FLD_STEP_TYPE = "step_type";
		static final String FLD_RECIPIENT_DEF = "recipient_def";
		static final String FLD_TASK_RATE = "task_rate";
		static final String FLD_WEB_PAGE = "web_page";
		static final String FLD_AUTO_APPROVE = "auto_approve";
		static final String FLD_COMPLETE_SCRIPT = "complete_script";
		static final String FLD_RETURN_SCRIPT = "return_script";
		static final String FLD_ATTACHED_STATUS = "attached_status";
		static final String FLD_COMPLETION_DURATION = "completion_duration";
		static final String FLD_EXTENSION_DURATION = "extension_duration";
		static final String FLD_DELAY_DURATION = "delay_duration";
		static final String FLD_ONLATE_NOTIFY = "onlate_notify";
		static final String FLD_PRE_CONDITION = "pre_condition";
	
		/*
		 * Field variable in table team
		 */
		static final String FLD_TEAM_NAME = "team_name" ;
		static final String FLD_TEAM_CODE = "team_code" ;
		static final String FLD_TEAM_DESC = "team_desc" ;
		
		/*
		 * Field variable in table transition
		 */
		static final String FLD_NEXT_STEP_ID = "next_step_id";
		static final String FLD_CONDITION = "condition";
		static final String FLD_ON_EVENT = "on_event";
		static final String FLD_TRAN_DESC = "tran_desc";
		/*
		 * Field of Table User
		 */	
		static final String FLD_USER_CODE = "user_code";
		static final String FLD_USER_NAME = "user_name";
		static final String FLD_PRIMARY_POSITION = "primary_position";
		static final String FLD_JOB_GRADE = "job_grade";
		static final String FLD_EMAIL = "email";
		static final String FLD_PASSWORD = "password";
		static final String FLD_UTYPE = "utype";
		static final String FLD_BEGIN_DATE = "begin_date";
		static final String FLD_COMMAND_LINE = "command_line";
		static final String FLD_END_DATE = "end_date";
		
		/*
		 * Field of Table UTYPE_PRIVILEGE
		 */
		
		/**
		* Field variable in table wfvar_definition
		*/
		static final String FLD_VAR_NAME = "var_name";
		static final String FLD_VAR_DESC_THAI = "var_desc_thai";
		static final String FLD_VAR_DESC_ENG = "var_desc_eng";
		static final String FLD_HINT = "hint";
		static final String FLD_VAR_TYPE = "var_type";
		static final String FLD_INIT_VALUE = "init_value";
		static final String FLD_VALIDATE_CLASS = "validate_class";
		static final String FLD_NULLABLE = "nullable";
		static final String FLD_TAG_TYPE = "tag_type";
		static final String FLD_ENCRYPT = "encrypt";
		static final String FLD_ACCESS_RIGHT = "access_right";
		static final String FLD_INPUT_TYPE	= "input_type";
		static final String FLD_INPUT_VALUE = "input_value";
		
		/**
		* Field variable in table workflow_definition
		*/
		static final String FLD_WF_ID = "wf_id";
		static final String FLD_WF_VER = "wf_ver";
		static final String FLD_WF_NAME = "wf_name";
		static final String FLD_WF_SHORT_CODE = "wf_short_code";
		static final String FLD_WF_OBJECTIVE = "wf_objective";
		static final String FLD_WF_RULE = "wf_rule";
		static final String FLD_INITIATOR_DEF = "initiator_def";
		static final String FLD_INITIATE_TIME = "initiate_time";
		static final String FLD_SCHEDULE = "schedule";
		static final String FLD_WF_DESC = "wf_desc";
		static final String FLD_START_TIME = "start_time";
		static final String FLD_END_TIME = "end_time";
		static final String FLD_PRIORITY = "priority";
		static final String FLD_SECURITY = "security";
		static final String FLD_ABORT_SCRIPT = "abort_script";
		static final String FLD_TAKEOVER_RIGHT = "takeover_right";
		static final String FLD_DIFFICULT_LEVEL = "difficult_level";
		static final String FLD_LAST_SEQ = "last_seq";
		static final String FLD_CURRENT_USE = "current_use";
		/**
		 * 
		* Field variable in table wordflow_incident
		*/
		static final String FLD_WF_SEQ_NO = "wf_seq_no";
		static final String FLD_SUBJECT = "subject";
		static final String FLD_INITIATOR = "initiator";
		static final String FLD_WF_START_TIME = "start_time";
		static final String FLD_EXTENSION_TIME = "extension_time";

	 	/**
	   	* Field variable in table workflow_variable
	   	*/
	  	static final String FLD_VAR_VALUE = "var_value";
	  	//static final String FLD_CHG_HISTORY = "chg_history";		
		/*
		 * share filed
		 */
		static final String FLD_COMMENT = "comment";
		static final String FLD_LAST_UPDATE = "last_update";
		static final String FLD_UPDATE_BY = "update_by";
		static final String FLD_STATUS = "status";
		static final String FLD_COMPLETION_TIME = "completion_time";
}