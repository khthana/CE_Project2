/**
 *================================================================================
 * THIS SOFTWARE IS PROVIDED BY JAVAZOOM "AS IS".
 * JAVAZOOM DISCLAIMS ANY OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT
 * LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT.
 *================================================================================
 */

package util;
import java.io.*;
import java.util.zip.*;
import java.sql.*;
import javazoom.download.util.*;
import javazoom.download.DownloadSource;

/**
 * This class implements a DownloadSource for database.
 * All files are downloaded from a table.
 */
public class DownloadMyDBSource extends DownloadSource
{
  /** Buffer size to read file from database inputstream and write to user's outputstream. Default is 4096 **/
  public static int BUFFERSIZE = 4096;

  /**
   * Contructs DownloadDatabaseSource and loads JDBC driver.
   * @param conf DatabaseConfig
   */
  public DownloadMyDBSource(Config conf)
  {
    super(conf);
    try
    {
      Class.forName(((DatabaseConfig)conf).getDriver());
    }
    catch (ClassNotFoundException ex)
    {
      trace(0,"Class not found : "+ex.getMessage());
    }
  }

  /**
   * Returns file length or -1 if file is not found or not readable.
   * <br>
   * Step 1 : Connects to database<br>
   * Step 2 : Runs SQL query to get file's length<br>
   * Step 3 : Close database connection<br>
   * @param fi FileInfo to download
   * @return size of file to download.
   */
  public int getDataLength(FileInfo fi)
  {
    DatabaseConfig conf = (DatabaseConfig)super.getConfig();
    String downloadtable = conf.getSchema().getProperty("TABLE");
    String filenamecolumn = conf.getSchema().getProperty("FILENAMECOLUMN");
    String datacolumn = conf.getSchema().getProperty("DATACOLUMN");
    String customcolumn = conf.getSchema().getProperty("CUSTOM");
    try
    {
      // Connect to database.
      Connection c = DriverManager.getConnection(conf.getUrl(),conf.getCredentials());
      String count = "SELECT "+datacolumn+" FROM "+downloadtable+" WHERE "+filenamecolumn+"='"+fi.getFilename()+"' AND "+customcolumn +" = '"+fi.getCustomField()+"';";
      Statement s = c.createStatement();
      ResultSet r = s.executeQuery(count);
      int size = -1;
      while (r.next())
      {
        Blob b = r.getBlob(datacolumn);
        if (b != null) size = (int) b.length();
      }
      r.close();
      s.close();
      c.close();
      return size;
    }
    catch (SQLException ex)
    {
      trace(0,ex.getMessage());
      return -1;
    }
  }

  /**
   * Sends file to download (binary) to end-user.
   * <br>
   * Step 1 : Connects to database<br>
   * Step 2 : Runs SQL query to get file's content<br>
   * Step 3 : Sends file's content to end-user outpustream<br>
   * Step 4 : Close database connection<br>
   * @param fi FileInfo to download
   * @param outdata OutputStream for current user.
   * @throws IOException
   */
  public void download(FileInfo fi, OutputStream outdata) throws IOException
  {
    DatabaseConfig conf = (DatabaseConfig)super.getConfig();
    String downloadtable = conf.getSchema().getProperty("TABLE");
    String filenamecolumn = conf.getSchema().getProperty("FILENAMECOLUMN");
    String datacolumn = conf.getSchema().getProperty("DATACOLUMN");
    InputStream in = null;
    Connection c = null;
    Statement s = null;
    ResultSet r = null;
    try
    {
      // Connect to database.
      c = DriverManager.getConnection(conf.getUrl(),conf.getCredentials());
      String extractfile = "SELECT "+datacolumn+" FROM "+downloadtable+" WHERE "+filenamecolumn+"='"+fi.getFilename()+"' AND FILE_SEQ_NO = '"+fi.getCustomField()+"';";

      s = c.createStatement();
      r = s.executeQuery(extractfile);
      int size = 0;
      while (r.next())
      {
        Blob b = r.getBlob(datacolumn);
        in = b.getBinaryStream();
      }
    }
    catch (SQLException ex)
    {
      throw new IOException(ex.getMessage());
    }
    if (in != null)
    {
      if (fi.isZipEnabled() == false)
      {
        BufferedInputStream bis = new BufferedInputStream(in);
        int bytesRead = 0;
        byte[] obuffer = new byte[BUFFERSIZE];
        while ( (bytesRead = bis.read(obuffer)) != -1) outdata.write(obuffer,0,bytesRead);
        outdata.flush();
        outdata.close();
        bis.close();
      }
      else
      {
        BufferedInputStream bis = new BufferedInputStream(in);
        int bytesRead = 0;
        byte[] obuffer = new byte[BUFFERSIZE];
        ZipOutputStream zos = new ZipOutputStream(outdata);
        ZipEntry ze = new ZipEntry(fi.getFilename());
        zos.putNextEntry(ze);
        while ( (bytesRead = bis.read(obuffer)) != -1) zos.write(obuffer,0,bytesRead);
        zos.closeEntry();
        zos.flush();
        zos.close();
        bis.close();
      }
    }
    try
    {
      r.close();
      s.close();
      c.close();
    }
    catch (SQLException ex)
    {
      throw new IOException(ex.getMessage());
    }
  }

  /**
   * Sends messages to trace object.
   * @param level of trace
   * @param message to send
   */
  private void trace(int level, String message)
  {
    Debug.getInstance().trace(level,getClass().getName()+": "+message);
  }
}