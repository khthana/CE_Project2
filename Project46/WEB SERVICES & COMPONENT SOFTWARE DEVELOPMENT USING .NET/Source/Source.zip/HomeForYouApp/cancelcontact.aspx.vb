Imports HomeForYouApp.WebReference1
Public Class cancelcontact
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim conid, chk, called As String
        Dim serv As Service1 = New Service1()

        conid = Request.QueryString("id")
        called = Session.Contents("called")
        chk = serv.CancelContact(conid)
        If (chk = "OK") Then
            Session.Add("Pageload", 0)
            Session.Add("login", "false")
            MsgBox("¡��ԡ��¡�����º��������")

        End If
    End Sub
    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub
End Class
