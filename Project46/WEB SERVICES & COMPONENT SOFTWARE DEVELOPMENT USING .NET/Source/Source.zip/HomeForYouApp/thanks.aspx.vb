Public Class thanks
    Inherits System.Web.UI.Page
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents Form2 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents l1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim type As String
        type = Session.Contents("order")
        If type = "home" Then
            Label1.Text = "�ҧ��ҨеԴ�����йѴ�ѹ���ѭ�ҡѺ��ҹ�����Ƿ���ش"
            Label1.Visible = True
        Else
            Label3.Text = "�ҧ��Ҩзӡ����Ẻ��ҹ���Ѻ��ҹ�����赡ŧ�����Ƿ���ش"
            Label3.Visible = True
        End If
        Session.Add("Pageload", 0)
        Session.Add("login", "false")
    End Sub

End Class
