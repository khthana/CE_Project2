Imports System.Data
Imports System.Data.SqlClient
Imports HomeForYouApp.WebReference1
Imports System.Reflection

Public Class orderBuildhome
    Inherits System.Web.UI.Page
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Image2 As System.Web.UI.WebControls.Image
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton5 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton6 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton9 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton8 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton7 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton4 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents RadioButtonList1 As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents c1 As System.Web.UI.WebControls.Button
    Protected WithEvents c2 As System.Web.UI.WebControls.Button
    Protected WithEvents c3 As System.Web.UI.WebControls.Button
    Protected WithEvents c4 As System.Web.UI.WebControls.Button
    Protected WithEvents c5 As System.Web.UI.WebControls.Button
    Protected WithEvents c6 As System.Web.UI.WebControls.Button
    Protected WithEvents c7 As System.Web.UI.WebControls.Button
    Protected WithEvents c8 As System.Web.UI.WebControls.Button
    Protected WithEvents c9 As System.Web.UI.WebControls.Button
    Protected WithEvents c10 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button4 As System.Web.UI.WebControls.Button
    Protected WithEvents r2 As System.Web.UI.WebControls.Button
    Protected WithEvents r1 As System.Web.UI.WebControls.Button
    Protected WithEvents r3 As System.Web.UI.WebControls.Button
    Protected WithEvents r4 As System.Web.UI.WebControls.Button



    Dim serv As Service1 = New Service1()
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        ImageButton5.Enabled = False
        Dim p As Integer
        p = Session.Contents("Pageload")
        If p <> 1 Then
            Dim oSQLConn As SqlConnection = New SqlConnection()
            oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                        "Data Source=161.246.6.113,1433;" & _
                                        "Initial Catalog=HomeForYou;" & _
                                        "User ID=sa;" & _
                                        "Password=wx5k,x6hp"
            Dim ds As DataSet = New DataSet()
            Dim sql As String
            sql = "select homeid from Homeplan"
            Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
            myAdapter.Fill(ds, "order")
            oSQLConn.Close()
            Dim c, i1 As Integer
            c = CInt(ds.Tables("order").Rows.Count)
            i1 = 0
            While (i1 <> c)
                DropDownList1.Items.Add(New ListItem(ds.Tables("order").Rows(i1).Item(0), ds.Tables("order").Rows(i1).Item(0)))
                i1 += 1
            End While
            DropDownList1.DataBind()
            
        End If

        
        Session.Add("Pageload", 1)
       
    End Sub

    Private Sub ImageButton3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Session.Add("Pageload", 0)
        Response.Redirect("signup.aspx")
    End Sub

    Private Sub ImageButton8_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton8.Click
        Session.Add("Pageload", 0)
        Response.Redirect("search.aspx")
    End Sub


    Private Sub ImageButton4_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton4.Click
        Session.Add("Pageload", 0)
        Response.Redirect("allplan.aspx")
    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Session.Add("Pageload", 0)
        Response.Redirect("index.aspx")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim chk, id, detail As String
        Dim totalprice As Integer
        If ((TextBox1.Text = "") Or (TextBox2.Text = "") Or (TextBox3.Text = "") Or (TextBox4.Text = "")) Then
            MsgBox("��سҡ�͡���������ú�ء��ͧ")
        End If
        id = Session.Contents("ContactID")
        If id = "" Then
            MsgBox("��س���͡�Թ��͹����¡��")

        Else

            chk = serv.preOrder(id)

            If (chk = "OK") Then

                Dim totalprice1 As Integer = cal()
                Try
                    chk = serv.submitOrderHomeBuild(id, DropDownList1.SelectedItem.Value, "Credit", RadioButtonList1.SelectedItem.Value, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, totalprice1)

                Catch
                    chk = serv.submitOrderHomeBuild(id, DropDownList1.SelectedItem.Value, "Credit", RadioButtonList1.SelectedItem.Value, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, totalprice1)
                End Try
            End If
            If chk = "Complete" Then
                Session.Add("order", "home")
                Session.Add("called", "orderBuildhome.aspx")
                Session.Add("Pageload", 0)
                Response.Redirect("showcontact.aspx")
            Else
                MsgBox(chk)
            End If
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        RadioButtonList1.ClearSelection()
        TextBox1.Text = ""
        TextBox1.BackColor = TextBox1.BackColor.White()
        TextBox2.Text = ""
        TextBox2.BackColor = TextBox2.BackColor.White()
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub

    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim totalprice As Integer = cal()
        TextBox5.Text = cal() + " ��ҹ�ҷ"
    End Sub

    Public Function cal() As String

        Dim totalprice = CInt(serv.objPrice(DropDownList1.SelectedItem.Value, RadioButtonList1.SelectedItem.Value))
        Return totalprice
    End Function


    Private Sub c1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c1.Click
        TextBox1.BackColor = c1.BackColor
        TextBox1.Text = c1.ID
    End Sub
    Private Sub c2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c2.Click
        TextBox1.BackColor = c2.BackColor
        TextBox1.Text = c2.ID
    End Sub
    Private Sub c3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c3.Click
        TextBox1.BackColor = c3.BackColor
        TextBox1.Text = c3.ID
    End Sub
    Private Sub c4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c4.Click
        TextBox1.BackColor = c4.BackColor
        TextBox1.Text = c4.ID
    End Sub
    Private Sub c5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c5.Click
        TextBox1.BackColor = c5.BackColor
        TextBox1.Text = c5.ID
    End Sub
    Private Sub c6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c6.Click
        TextBox1.BackColor = c6.BackColor
        TextBox1.Text = c6.ID
    End Sub
    Private Sub c7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c7.Click
        TextBox1.BackColor = c7.BackColor
        TextBox1.Text = c7.ID
    End Sub
    Private Sub c8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c8.Click
        TextBox1.BackColor = c8.BackColor
        TextBox1.Text = c8.ID
    End Sub
    Private Sub c9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c9.Click
        TextBox1.BackColor = c9.BackColor
        TextBox1.Text = c9.ID
    End Sub
    Private Sub c10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles c10.Click
        TextBox1.BackColor = c10.BackColor
        TextBox1.Text = c10.ID
    End Sub


    Private Sub r1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles r1.Click
        TextBox2.BackColor = r1.BackColor
        TextBox2.Text = r1.ID
    End Sub

    Private Sub r2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles r2.Click
        TextBox2.BackColor = r2.BackColor
        TextBox2.Text = r2.ID
    End Sub

    Private Sub r3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles r3.Click
        TextBox2.BackColor = r3.BackColor
        TextBox2.Text = r3.ID
    End Sub

    Private Sub r4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles r4.Click
        TextBox2.BackColor = r4.BackColor
        TextBox2.Text = r4.ID
    End Sub

    Private Sub ImageButton6_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton6.Click
        Session.Add("Pageload", 0)
        Response.Redirect("orderPlan.aspx")
    End Sub

    Private Sub Imagebutton9_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton7.Click
        Session.Add("Pageload", 0)
        Response.Redirect("tip.aspx")
    End Sub

End Class
