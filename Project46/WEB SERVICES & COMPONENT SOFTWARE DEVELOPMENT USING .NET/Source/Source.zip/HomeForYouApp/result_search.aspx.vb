Imports HomeForYouApp.WebReference1
Public Class result_search
    Inherits System.Web.UI.Page
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton5 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton6 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton9 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton8 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton4 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim Area1, Style1, Floors1, Width1, Depth1, Detail1, Bathroom1, Bedrooms1 As String
        
        Area1 = Request.QueryString("Area")
        Style1 = Request.QueryString("Style")
        Floors1 = Request.QueryString("Floors")
        Width1 = Request.QueryString("Width")
        Depth1 = Request.QueryString("Depth")
        Detail1 = Request.QueryString("Detail")
        Bathroom1 = Request.QueryString("Bathroom")
        Bedrooms1 = Request.QueryString("Bedrooms")
        If Area1 = "0" Then Area1 = ""
        If Style1 = "0" Then Style1 = ""
        If Width1 = "0" Then Width1 = ""
        If Depth1 = "0" Then Depth1 = ""


        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow
        Dim serv As Service1 = New Service1()
        mySet = serv.searchHomePlan(Area1, Style1, Floors1, Width1, Depth1, Detail1, Bathroom1, Bedrooms1)

        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Home ID</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Picture</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Home Style</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Home Area</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Detail</b></center></font>", GetType(String)))

        Dim i As Decimal = 0
        Dim row As Decimal = 0
        Dim id As String


        For Each myRow In mySet.Tables("Homeplan").Rows

            myRow = myTable.NewRow()
            myRow(0) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(0) & "</center>"
            myRow(1) = "<center><a href='showplan.aspx?id=" & mySet.Tables("Homeplan").Rows(i).Item(0) & "' target='_blank'><img src=" & mySet.Tables("Homeplan").Rows(i).Item(9) & " border='0'></a></center>"
            myRow(2) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(1) & "</center>"
            myRow(3) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(2) & "</center>"
            myRow(4) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(8) & "</center>"

            myTable.Rows.Add(myRow)
            i += 1
            row += 1
        Next
        Label1.Text = row
        DataGrid1.DataSource = myTable


        DataGrid1.DataBind()



    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("index.aspx")
    End Sub

    Private Sub ImageButton3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Response.Redirect("signup.aspx")
    End Sub

    Private Sub ImageButton8_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton8.Click
        Response.Redirect("search.aspx")
    End Sub
    Private Sub ImageButton6_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton6.Click
        Response.Redirect("orderPlan.aspx")
    End Sub
    Private Sub ImageButton5_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton5.Click
        Response.Redirect("orderBuildhome.aspx")
    End Sub

    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged

    End Sub

    Private Sub ImageButton4_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton4.Click
        Response.Redirect("allplan.aspx")
    End Sub
    Private Sub Imagebutton9_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton9.Click
        Session.Add("Pageload", 0)
        Response.Redirect("tip.aspx")
    End Sub
End Class
