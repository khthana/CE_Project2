<%@ Page Language="vb" AutoEventWireup="false" Codebehind="tip.aspx.vb" Inherits="HomeForYouApp.tip" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>tip</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#fcecdd">
		<form id="Form1" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 107; LEFT: 222px; POSITION: absolute; TOP: 647px" runat="server" Height="20px" Width="42px"></asp:Label>
			<asp:HyperLink id="HyperLink6" style="Z-INDEX: 131; LEFT: 297px; POSITION: absolute; TOP: 581px" runat="server" Width="104px" Height="20px" BackColor="#C0C0FF" Target="_blank" NavigateUrl="plandetail.htm">��Դ�ͧẺ</asp:HyperLink>
			<asp:label id="Label12" style="Z-INDEX: 130; LEFT: 482px; POSITION: absolute; TOP: 139px" runat="server" Width="53px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">˹���á</asp:label>
			<asp:label id="Label13" style="Z-INDEX: 109; LEFT: 546px; POSITION: absolute; TOP: 139px" runat="server" Width="70px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">ŧ����¹</asp:label>
			<asp:label id="Label16" style="Z-INDEX: 129; LEFT: 630px; POSITION: absolute; TOP: 139px" runat="server" Width="70px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">Ẻ��ҹ</asp:label>
			<asp:label id="Label14" style="Z-INDEX: 121; LEFT: 708px; POSITION: absolute; TOP: 138px" runat="server" Width="70px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">����</asp:label>
			<asp:label id="Label3" style="Z-INDEX: 128; LEFT: 769px; POSITION: absolute; TOP: 137px" runat="server" Width="70px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">���й�����</asp:label>
			<asp:label id="Label10" style="Z-INDEX: 127; LEFT: 838px; POSITION: absolute; TOP: 136px" runat="server" Width="70px" Height="29px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">��觫����Ź</asp:label>
			<asp:label id="Label15" style="Z-INDEX: 126; LEFT: 915px; POSITION: absolute; TOP: 137px" runat="server" Width="70px" Height="25px" Font-Bold="True" Font-Size="Smaller" ForeColor="MediumBlue">���ҧ��ҹ</asp:label><IMG style="Z-INDEX: 124; LEFT: 8px; WIDTH: 476px; POSITION: absolute; TOP: 26px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 119; LEFT: 483px; WIDTH: 121px; POSITION: absolute; TOP: 27px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 120; LEFT: 604px; WIDTH: 365px; POSITION: absolute; TOP: 26px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365">
			<asp:imagebutton id="Imagebutton6" style="Z-INDEX: 103; LEFT: 900px; POSITION: absolute; TOP: 92px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a4.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton8" style="Z-INDEX: 104; LEFT: 829px; POSITION: absolute; TOP: 92px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a5.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton7" style="Z-INDEX: 106; LEFT: 758px; POSITION: absolute; TOP: 93px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a17.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton4" style="Z-INDEX: 105; LEFT: 687px; POSITION: absolute; TOP: 93px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a3.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton3" style="Z-INDEX: 102; LEFT: 616px; POSITION: absolute; TOP: 93px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a2.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton2" style="Z-INDEX: 101; LEFT: 545px; POSITION: absolute; TOP: 93px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a8.gif" BackColor="Silver"></asp:imagebutton>
			<asp:imagebutton id="Imagebutton1" style="Z-INDEX: 100; LEFT: 474px; POSITION: absolute; TOP: 93px" runat="server" Width="70px" Height="40px" ImageUrl="..\HomeForYouApp\Pictures\a1.gif" BackColor="Silver"></asp:imagebutton><IMG style="Z-INDEX: 114; LEFT: 8px; WIDTH: 408px; POSITION: absolute; TOP: 88px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif" width="408">
			<asp:Label id="Label2" style="Z-INDEX: 108; LEFT: 192px; POSITION: absolute; TOP: 274px" runat="server" Height="25px" Width="70px" BackColor="#00C0C0" Font-Bold="True">���й�����</asp:Label>
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 110; LEFT: 296px; POSITION: absolute; TOP: 335px" runat="server" Width="145px" Height="20px" BackColor="#C0C0FF" NavigateUrl="tip1_color.aspx" Target="_blank">�������ѹ���Ѻ��ͧ���</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 111; LEFT: 297px; POSITION: absolute; TOP: 383px" runat="server" Width="100px" Height="20px" BackColor="#C0C0FF" NavigateUrl="tip2_doorknob.aspx" Target="_blank">��ѭ���١�Դ</asp:HyperLink>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 112; LEFT: 297px; POSITION: absolute; TOP: 432px" runat="server" Width="220px" Height="20px" BackColor="#C0C0FF" NavigateUrl="tip3_area.aspx" Target="_blank">�红ͧ���ҧ�� �������Ѵ���ͷ��</asp:HyperLink>
			<asp:HyperLink id="HyperLink4" style="Z-INDEX: 113; LEFT: 296px; POSITION: absolute; TOP: 479px" runat="server" Width="170px" Height="20px" BackColor="#C0C0FF" NavigateUrl="tip4_garden.aspx" Target="_blank">�Ѵ�ǹ��´��µ�Ǥس�ͧ</asp:HyperLink>
			<asp:HyperLink id="HyperLink5" style="Z-INDEX: 116; LEFT: 297px; POSITION: absolute; TOP: 529px" runat="server" Width="104px" Height="20px" BackColor="#C0C0FF" NavigateUrl="tip5.aspx" Target="_blank">�Ը����͡��е�����</asp:HyperLink>
			<asp:Image id="Image3" style="Z-INDEX: 117; LEFT: 232px; POSITION: absolute; TOP: 335px" runat="server" Width="40px" Height="20px" ImageUrl="..\HomeForYouApp\Pictures\new.gif"></asp:Image>
			<asp:Image id="Image4" style="Z-INDEX: 118; LEFT: 231px; POSITION: absolute; TOP: 384px" runat="server" Width="40px" Height="20px" ImageUrl="..\HomeForYouApp\Pictures\new.gif"></asp:Image>
			<asp:Image id="Image5" style="Z-INDEX: 122; LEFT: 593px; POSITION: absolute; TOP: 319px" runat="server" Width="310px" Height="226px" ImageUrl="..\HomeForYouApp\Pictures\map04.gif"></asp:Image>
			<asp:Image id="Image6" style="Z-INDEX: 123; LEFT: 283px; POSITION: absolute; TOP: 274px" runat="server" Width="59px" Height="29px" ImageUrl="..\HomeForYouApp\Pictures\icon_h.gif"></asp:Image>
		</form>
	</body>
</HTML>
