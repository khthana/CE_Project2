Imports HomeForYouApp.WebReference1
Public Class showcontact
    Inherits System.Web.UI.Page
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim conid As String
        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow
        Dim serv As Service1 = New Service1()


        conid = Session.Contents("ContactID")

        mySet = serv.ShowContact(conid)

        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>���ʻ�Шӵ���١���</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>�ѹ���</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>����Ẻ��ҹ</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>��������´</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>¡��ԡ��¡��</b></center></font>", GetType(String)))

        Dim i As Decimal = 0
        Dim row As Decimal = 0
        Dim id As String

        conid = Session.Contents("ContactID")
        For Each myRow In mySet.Tables("cd").Rows

            myRow = myTable.NewRow()
            myRow(0) = mySet.Tables("cd").Rows(i).Item(0)
            myRow(1) = mySet.Tables("cd").Rows(i).Item(1)
            myRow(2) = mySet.Tables("cd").Rows(i).Item(2)
            myRow(3) = mySet.Tables("cd").Rows(i).Item(3)

            myRow(4) = "<center><a href='cancelcontact.aspx?id=" + conid + "'>¡��ԡ</a></center>"

            myTable.Rows.Add(myRow)
            i += 1
            row += 1
        Next
        DataGrid1.DataSource = myTable
        DataGrid1.DataBind()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Session.Add("login", "false")
        Response.Redirect("thanks.aspx")
    End Sub
End Class
