<%@ Page Language="vb" AutoEventWireup="false" Codebehind="allplan.aspx.vb" Inherits="HomeForYouApp.allplan" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>allplan</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<script language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</script>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<FONT face="Tahoma">
			<DIV style="Z-INDEX: 100; LEFT: 8px; WIDTH: 10px; POSITION: absolute; TOP: 8px; HEIGHT: 10px" ms_positioning="text2D">
				<FORM id="Form1" method="post" runat="server">
					<FONT face="Tahoma">
						<asp:label id="Label16" style="Z-INDEX: 116; LEFT: 639px; POSITION: absolute; TOP: 165px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">Ẻ��ҹ</asp:label><IMG style="Z-INDEX: 118; LEFT: 31px; WIDTH: 476px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><FONT face="Tahoma"><IMG style="Z-INDEX: 103; LEFT: 32px; WIDTH: 416px; POSITION: absolute; TOP: 110px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif" width="416"></FONT>
						<asp:label id="Label15" style="Z-INDEX: 117; LEFT: 928px; POSITION: absolute; TOP: 163px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">���ҧ��ҹ</asp:label>
						<asp:imagebutton id="ImageButton2" style="Z-INDEX: 104; LEFT: 486px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a1.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton3" style="Z-INDEX: 105; LEFT: 558px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a8.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton4" style="Z-INDEX: 108; LEFT: 630px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a2.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton8" style="Z-INDEX: 111; LEFT: 702px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a3.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton9" style="Z-INDEX: 112; LEFT: 774px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a17.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton6" style="Z-INDEX: 110; LEFT: 845px; POSITION: absolute; TOP: 120px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a5.gif"></asp:imagebutton>
						<asp:imagebutton id="ImageButton5" style="Z-INDEX: 109; LEFT: 917px; POSITION: absolute; TOP: 119px" runat="server" Width="70px" Height="40px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a4.gif"></asp:imagebutton>
						<asp:label id="Label10" style="Z-INDEX: 114; LEFT: 851px; POSITION: absolute; TOP: 162px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="29px" Font-Size="Smaller">��觫����Ź</asp:label>
						<asp:label id="Label11" style="Z-INDEX: 115; LEFT: 782px; POSITION: absolute; TOP: 163px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">���й�����</asp:label>
						<asp:label id="Label14" style="Z-INDEX: 113; LEFT: 721px; POSITION: absolute; TOP: 164px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">����</asp:label>
						<asp:label id="Label13" style="Z-INDEX: 107; LEFT: 559px; POSITION: absolute; TOP: 165px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">ŧ����¹</asp:label>
						<asp:label id="Label12" style="Z-INDEX: 106; LEFT: 495px; POSITION: absolute; TOP: 166px" runat="server" Font-Bold="True" ForeColor="MediumBlue" Width="70px" Height="25px" Font-Size="Smaller">˹���á</asp:label><IMG style="Z-INDEX: 102; LEFT: 507px; WIDTH: 121px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 101; LEFT: 622px; WIDTH: 365px; POSITION: absolute; TOP: 52px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"></FONT>
					<asp:datagrid id="DataGrid1" style="Z-INDEX: 119; LEFT: 183px; POSITION: absolute; TOP: 304px" runat="server" ForeColor="DarkGreen" Width="740px" Height="191px" CellSpacing="5" BorderWidth="4px" BorderStyle="Ridge" BorderColor="Red"></asp:datagrid></FORM>
			</DIV>
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 436px; POSITION: absolute; TOP: 660px" runat="server" Width="33px" Height="211px"></asp:Label>
		</FONT>
	</body>
</HTML>
