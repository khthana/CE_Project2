<%@ Page Language="vb" AutoEventWireup="false" Codebehind="index.aspx.vb" Inherits="HomeForYouApp.index"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>HomeForYou</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<script language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</script>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<FONT face="Tahoma">
			<DIV style="Z-INDEX: 101; LEFT: 8px; WIDTH: 10px; POSITION: absolute; TOP: 8px; HEIGHT: 10px" ms_positioning="FlowLayout">
				<FORM id="Form1" method="post" runat="server">
					<FONT face="Tahoma">
						<asp:panel id="Panel1" style="Z-INDEX: 113; LEFT: 24px; POSITION: absolute; TOP: 286px" runat="server" Height="210px" Width="312px">
<P>&nbsp;</P>
<P>&nbsp;&nbsp;&nbsp;
								<asp:label id="Label13" runat="server" Height="25px" Width="43px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">���ͼ����</asp:label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<asp:textbox id="TextBox1" runat="server" Height="27px" Width="176px" BorderColor="Transparent" BackColor="HighlightText"></asp:textbox>&nbsp;&nbsp;&nbsp;
							</P>
<P>&nbsp;&nbsp;&nbsp;
								<asp:label id="Label14" runat="server" Height="19px" Width="49px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">���ʼ�ҹ</asp:label>&nbsp;&nbsp;&nbsp;&nbsp;
								<INPUT id="Password1" style="WIDTH: 176px; HEIGHT: 26px" type="password" size="24" name="Password1" runat="server"></P>
<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
								<asp:button id="Enter" runat="server" Height="30px" Width="82px" ForeColor="MidnightBlue" Font-Bold="True" BackColor="#FFE0C0" Text="��ŧ"></asp:button>&nbsp;&nbsp;
								<asp:button id="Cancel" runat="server" Height="30px" Width="80px" ForeColor="MidnightBlue" Font-Bold="True" BackColor="#FFE0C0" Text="¡��ԡ"></asp:button></P><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 

<P></P></FONT><FONT face="Tahoma"></asp:panel>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<P>&nbsp;</P>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						<P><asp:imagebutton id="ImageButton2" style="Z-INDEX: 105; LEFT: 477px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a1.gif"></asp:imagebutton><asp:imagebutton id="ImageButton3" style="Z-INDEX: 106; LEFT: 549px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a8.gif"></asp:imagebutton><asp:label id="Label4" style="Z-INDEX: 107; LEFT: 486px; POSITION: absolute; TOP: 181px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">˹���á</asp:label><asp:label id="Label5" style="Z-INDEX: 108; LEFT: 550px; POSITION: absolute; TOP: 180px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">ŧ����¹</asp:label><asp:imagebutton id="ImageButton4" style="Z-INDEX: 109; LEFT: 621px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a2.gif"></asp:imagebutton><asp:imagebutton id="ImageButton5" style="Z-INDEX: 110; LEFT: 908px; POSITION: absolute; TOP: 134px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a4.gif"></asp:imagebutton><asp:imagebutton id="ImageButton6" style="Z-INDEX: 111; LEFT: 836px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a5.gif"></asp:imagebutton><asp:imagebutton id="ImageButton8" style="Z-INDEX: 113; LEFT: 693px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a3.gif"></asp:imagebutton><asp:imagebutton id="ImageButton9" style="Z-INDEX: 114; LEFT: 765px; POSITION: absolute; TOP: 135px" runat="server" Height="40px" Width="70px" BackColor="Silver" ImageUrl="..\HomeForYouApp\Pictures\a17.gif"></asp:imagebutton><asp:label id="Label8" style="Z-INDEX: 117; LEFT: 712px; POSITION: absolute; TOP: 179px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">����</asp:label><asp:label id="Label9" style="Z-INDEX: 118; LEFT: 919px; POSITION: absolute; TOP: 178px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">���ҧ��ҹ</asp:label><asp:label id="Label10" style="Z-INDEX: 119; LEFT: 842px; POSITION: absolute; TOP: 177px" runat="server" Height="29px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">��觫����Ź</asp:label><asp:label id="Label11" style="Z-INDEX: 120; LEFT: 773px; POSITION: absolute; TOP: 178px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">���й�����</asp:label></P>
						<asp:imagebutton id="ImageButton1" style="Z-INDEX: 111; LEFT: 786px; POSITION: absolute; TOP: 247px" runat="server" ImageUrl="..\HomeForYouApp\Pictures\H101.jpg"></asp:imagebutton><asp:imagebutton id="ImageButton10" style="Z-INDEX: 112; LEFT: 784px; POSITION: absolute; TOP: 419px" runat="server" ImageUrl="..\HomeForYouApp\Pictures\H201.jpg"></asp:imagebutton><asp:imagebutton id="ImageButton11" style="Z-INDEX: 113; LEFT: 784px; POSITION: absolute; TOP: 592px" runat="server" Height="138px" Width="181px" ImageUrl="..\HomeForYouApp\Pictures\H301.jpg"></asp:imagebutton></FONT>
					<P>&nbsp;</P>
					<P></P>
					<P>&nbsp;</P>
					<P>&nbsp;</P>
					<br>
					<br>
					<asp:button id="Button1" style="Z-INDEX: 109; LEFT: 148px; POSITION: absolute; TOP: 567px" tabIndex="3" runat="server" ForeColor="Navy" Font-Bold="True" BackColor="#FFE0C0" Text="�͡�ҡ�к�"></asp:button>
					<P></P>
					<IMG style="Z-INDEX: 103; LEFT: 614px; WIDTH: 365px; POSITION: absolute; TOP: 68px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"><IMG style="Z-INDEX: 104; LEFT: 18px; WIDTH: 476px; POSITION: absolute; TOP: 68px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 105; LEFT: 493px; WIDTH: 121px; POSITION: absolute; TOP: 68px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"></FORM>
				<P></P>
			</DIV>
			<asp:label id="Label12" style="Z-INDEX: 107; LEFT: 828px; POSITION: absolute; TOP: 568px" runat="server" Height="22px" Width="101px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">Ẻ��ҹ�ͧ���</asp:label><asp:label id="Label3" style="Z-INDEX: 106; LEFT: 829px; POSITION: absolute; TOP: 396px" runat="server" Height="25px" Width="111px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">Ẻ��ҹ�������</asp:label><asp:label id="Label2" style="Z-INDEX: 104; LEFT: 830px; POSITION: absolute; TOP: 736px" runat="server" Height="19px" Width="106px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">Ẻ��ҹ������</asp:label><IMG style="Z-INDEX: 102; LEFT: 26px; WIDTH: 373px; POSITION: absolute; TOP: 134px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl.gif" width="373">
		</FONT>
		<DIV id="DIV1" style="Z-INDEX: 103; LEFT: 378px; WIDTH: 100px; POSITION: absolute; TOP: 272px; HEIGHT: 100px" ms_positioning="FlowLayout" runat="server"></DIV>
		<asp:label id="Label6" style="Z-INDEX: 105; LEFT: 638px; POSITION: absolute; TOP: 188px" runat="server" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Size="Smaller" Font-Bold="True">Ẻ��ҹ</asp:label><asp:panel id="Panel2" style="Z-INDEX: 108; LEFT: 108px; POSITION: absolute; TOP: 265px" runat="server" Height="248px" Width="223px">
			<P><FONT face="Tahoma">&nbsp; </FONT>
				<asp:label id="greet" runat="server" Width="128px" Font-Bold="True" Font-Size="Medium" ForeColor="MidnightBlue" Visible="False">�Թ�յ�͹�Ѻ �س</asp:label>
				<asp:label id="cusname" runat="server" Width="50px" Height="11px" Font-Bold="True" ForeColor="#C00000" Font-Names="Microsoft Sans Serif"></asp:label></P>
			<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
					<asp:image id="Image1" runat="server" Width="150px" Height="143px"></asp:image></FONT></P>
			<P><FONT face="Tahoma">&nbsp;&nbsp;</FONT><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT><FONT face="Tahoma">&nbsp;&nbsp;</FONT></P>
			<P><FONT face="Tahoma">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </FONT>
		</asp:panel></P>
	</body>
</HTML>
