<%@ Page Language="vb" AutoEventWireup="false" Codebehind="thanks.aspx.vb" Inherits="HomeForYouApp.thanks"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<TITLE>thanks</TITLE>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<META http-equiv="refresh" content="5; url=index.aspx">
		<SCRIPT language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</SCRIPT>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
		</form>
		<asp:label id="Label2" style="Z-INDEX: 101; LEFT: 407px; POSITION: absolute; TOP: 320px" runat="server" Font-Size="Large" Height="16px" Width="219px" ForeColor="Green" Font-Bold="True">�ͺ�س������ԡ��</asp:label><asp:label id="Label1" style="Z-INDEX: 109; LEFT: 300px; POSITION: absolute; TOP: 396px" runat="server" Font-Size="Large" Height="16px" Width="391px" ForeColor="Green" Font-Bold="True" Visible="False"></asp:label><asp:label id="Label3" style="Z-INDEX: 108; LEFT: 304px; POSITION: absolute; TOP: 382px" runat="server" Font-Size="Large" Height="16px" Width="386px" ForeColor="Green" Font-Bold="True" Visible="False"></asp:label><IMG style="Z-INDEX: 105; LEFT: 31px; WIDTH: 476px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 103; LEFT: 507px; WIDTH: 121px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 100; LEFT: 622px; WIDTH: 365px; POSITION: absolute; TOP: 52px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"><FONT face="Tahoma"><IMG style="Z-INDEX: 104; LEFT: 32px; WIDTH: 416px; POSITION: absolute; TOP: 116px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif" width="416"></FONT></FONT></FORM>
		<asp:Label id="l1" style="Z-INDEX: 106; LEFT: 476px; POSITION: absolute; TOP: 506px" runat="server" Height="5px"></asp:Label>
	</body>
</HTML>
