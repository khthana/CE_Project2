<%@ Page Language="vb" AutoEventWireup="false" Codebehind="showcontact.aspx.vb" Inherits="HomeForYouApp.showcontact"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>showcontact</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<SCRIPT language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</SCRIPT>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:datagrid id="DataGrid1" style="Z-INDEX: 101; LEFT: 79px; POSITION: absolute; TOP: 226px" runat="server" BackColor="#FFE0C0" BorderColor="#0000C0">
					<HeaderStyle BackColor="#C0FFC0"></HeaderStyle>
				</asp:datagrid><IMG style="Z-INDEX: 105; LEFT: 32px; WIDTH: 476px; POSITION: absolute; TOP: 49px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 103; LEFT: 508px; WIDTH: 121px; POSITION: absolute; TOP: 49px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 100; LEFT: 629px; WIDTH: 365px; POSITION: absolute; TOP: 49px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"><FONT face="Tahoma"><IMG style="Z-INDEX: 104; LEFT: 33px; WIDTH: 416px; POSITION: absolute; TOP: 112px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif" width="416"></FONT>
				<asp:Button id="Button1" style="Z-INDEX: 102; LEFT: 427px; POSITION: absolute; TOP: 392px" runat="server" Text="��ŧ" BackColor="#FFE0C0" ForeColor="#0000C0" Font-Bold="True" Width="96px"></asp:Button></FONT></form>
	</body>
</HTML>
