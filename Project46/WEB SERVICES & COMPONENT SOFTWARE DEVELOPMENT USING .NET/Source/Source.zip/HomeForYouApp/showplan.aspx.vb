Imports HomeForYouApp.WebReference1
Public Class showplan
    Inherits System.Web.UI.Page
    Protected WithEvents DIV1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Image2 As System.Web.UI.WebControls.Image

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim serv As Service1 = New Service1()
        Dim hid As String
        Dim myset As DataSet = New DataSet()
        hid = Request.QueryString("id")
        myset = serv.getPicUrl(hid)
        DIV1.InnerHtml = serv.ShowModel(hid, 400, 300)
        Image2.ImageUrl = myset.Tables("pic").Rows(0).Item(1)
        Image2.ImageAlign = ImageAlign.AbsMiddle

       

        Dim mySet2 As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow
        mySet2 = serv.orderPlan(hid)

        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>HomeID</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>�ҤҤ�ҡ�����ҧClassA(��ҹ�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>�ҤҤ�ҡ�����ҧClassB(��ҹ�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>�ҤҤ�ҡ�����ҧClassC(��ҹ�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Ẻ��д��� (�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>��������� 1 �ش (�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>��������� 5 �ش (�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>�������� (�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Ẻ��ҧ (�ҷ)</b></center></font>", GetType(String)))
        myTable.Columns.Add(New DataColumn("<font color=blue><center><b>Ẻ��Ѻ��ҹ����-��� (�ҷ)</b></center></font>", GetType(String)))

        Dim i As Decimal = 0
        Dim row As Decimal = 0
        Dim id As String



        myRow = myTable.NewRow()
        myRow(0) = "<center>" & mySet2.Tables("order").Rows(0).Item(0) & "</center>"
        myRow(1) = "<center>" & CInt(mySet2.Tables("order").Rows(0).Item(2)) & "</center>"
        myRow(2) = "<center>" & CInt(mySet2.Tables("order").Rows(1).Item(2)) & "</center>"
        myRow(3) = "<center>" & CInt(mySet2.Tables("order").Rows(2).Item(2)) & "</center>"
        myRow(4) = "<center>" & CInt(mySet2.Tables("order").Rows(3).Item(2)) & "</center>"
        myRow(5) = "<center>" & CInt(mySet2.Tables("order").Rows(4).Item(2)) & "</center>"
        myRow(6) = "<center>" & CInt(mySet2.Tables("order").Rows(5).Item(2)) & "</center>"
        myRow(7) = "<center>" & CInt(mySet2.Tables("order").Rows(6).Item(2)) & "</center>"
        myRow(8) = "<center>" & CInt(mySet2.Tables("order").Rows(7).Item(2)) & "</center>"
        myRow(9) = "<center>" & CInt(mySet2.Tables("order").Rows(8).Item(2)) & "</center>"

        myTable.Rows.Add(myRow)
        
        DataGrid1.DataSource = myTable


        DataGrid1.DataBind()



    End Sub
End Class
