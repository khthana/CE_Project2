<%@ Page Language="vb" AutoEventWireup="false" Codebehind="showplan.aspx.vb" Inherits="HomeForYouApp.showplan"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>showplan</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<script language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</script>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 325px; POSITION: absolute; TOP: 990px" runat="server" Height="78px" Width="33px"></asp:Label>
			<asp:datagrid id="DataGrid1" style="Z-INDEX: 119; LEFT: 43px; POSITION: absolute; TOP: 794px" runat="server" Height="191px" Width="914px" BorderColor="Red" BorderStyle="Ridge" BorderWidth="4px" CellSpacing="5" ForeColor="DarkGreen"></asp:datagrid>
			&nbsp;
			<asp:Panel id="Panel1" style="Z-INDEX: 101; LEFT: 171px; POSITION: absolute; TOP: 360px" runat="server" Width="79px" Height="89px">
<P><FONT face="Tahoma"></P>
<P>
					<asp:Image id="Image2" runat="server" ImageAlign="Middle"></asp:Image></P></FONT><FONT face="Tahoma">
					<P>&nbsp;</P>
					<P>&nbsp;</P>
				</FONT></asp:Panel>
			<DIV id="DIV1" style="Z-INDEX: 102; LEFT: 313px; WIDTH: 30px; POSITION: absolute; TOP: 40px; HEIGHT: 31px" runat="server" ms_positioning="FlowLayout"></DIV>
		</form>
	</body>
</HTML>
