<%@ Page Language="vb" AutoEventWireup="false" Codebehind="search.aspx.vb" Inherits="HomeForYouApp.search"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>search</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<script language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</script>
	</HEAD>
	<body bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"><IMG style="Z-INDEX: 103; LEFT: 33px; WIDTH: 416px; POSITION: absolute; TOP: 110px; HEIGHT: 104px" height="104" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif" width="416">
				<asp:label id="Label16" style="Z-INDEX: 136; LEFT: 643px; POSITION: absolute; TOP: 165px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">Ẻ��ҹ</asp:label><asp:imagebutton id="ImageButton2" style="Z-INDEX: 105; LEFT: 486px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a1.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton3" style="Z-INDEX: 108; LEFT: 558px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a8.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton4" style="Z-INDEX: 114; LEFT: 630px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a2.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton8" style="Z-INDEX: 121; LEFT: 702px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a3.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton9" style="Z-INDEX: 122; LEFT: 774px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a17.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton6" style="Z-INDEX: 117; LEFT: 845px; POSITION: absolute; TOP: 120px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a5.gif" BackColor="Silver"></asp:imagebutton><asp:imagebutton id="ImageButton5" style="Z-INDEX: 115; LEFT: 917px; POSITION: absolute; TOP: 119px" runat="server" Height="40px" Width="70px" ImageUrl="..\HomeForYouApp\Pictures\a4.gif" BackColor="Silver"></asp:imagebutton><asp:label id="Label15" style="Z-INDEX: 129; LEFT: 928px; POSITION: absolute; TOP: 163px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">���ҧ��ҹ</asp:label><asp:label id="Label10" style="Z-INDEX: 130; LEFT: 851px; POSITION: absolute; TOP: 162px" runat="server" Font-Size="Smaller" Height="29px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">��觫����Ź</asp:label><asp:label id="Label11" style="Z-INDEX: 133; LEFT: 782px; POSITION: absolute; TOP: 163px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">���й�����</asp:label><asp:label id="Label14" style="Z-INDEX: 126; LEFT: 721px; POSITION: absolute; TOP: 164px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">����</asp:label><asp:label id="Label13" style="Z-INDEX: 112; LEFT: 559px; POSITION: absolute; TOP: 165px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">ŧ����¹</asp:label><asp:label id="Label12" style="Z-INDEX: 110; LEFT: 495px; POSITION: absolute; TOP: 166px" runat="server" Font-Size="Smaller" Height="25px" Width="70px" ForeColor="MediumBlue" Font-Bold="True">˹���á</asp:label><asp:dropdownlist id="DropDownList4" style="Z-INDEX: 132; LEFT: 235px; POSITION: absolute; TOP: 554px" runat="server" Font-Size="X-Small" Height="14px" Width="98px" Font-Bold="True">
					<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
					<asp:ListItem Value="5-10">5-10 m</asp:ListItem>
					<asp:ListItem Value="10-15">10-15 m</asp:ListItem>
					<asp:ListItem Value="15-20">15-20 m</asp:ListItem>
					<asp:ListItem Value="20-25">20-25 m</asp:ListItem>
					<asp:ListItem Value="30-35">30-35 m</asp:ListItem>
					<asp:ListItem Value="40-50">40-50 m</asp:ListItem>
					<asp:ListItem Value="50-60">50-60 m</asp:ListItem>
					<asp:ListItem Value="60-500">more 60 m</asp:ListItem>
				</asp:dropdownlist><IMG style="Z-INDEX: 104; LEFT: 33px; WIDTH: 476px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 102; LEFT: 507px; WIDTH: 121px; POSITION: absolute; TOP: 52px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 101; LEFT: 622px; WIDTH: 365px; POSITION: absolute; TOP: 52px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"></FONT>&nbsp;
			<asp:label id="Label1" style="Z-INDEX: 106; LEFT: 235px; POSITION: absolute; TOP: 269px" runat="server" ForeColor="DarkBlue" Font-Bold="True">HOME STYLE</asp:label><asp:label id="Label2" style="Z-INDEX: 107; LEFT: 237px; POSITION: absolute; TOP: 329px" runat="server" Width="101px" ForeColor="DarkBlue" Font-Bold="True">HOME AREA</asp:label><asp:label id="Label3" style="Z-INDEX: 109; LEFT: 234px; POSITION: absolute; TOP: 475px" runat="server" Width="112px" ForeColor="DarkBlue" Font-Bold="True">HOME WIDTH</asp:label><asp:label id="Label4" style="Z-INDEX: 111; LEFT: 233px; POSITION: absolute; TOP: 533px" runat="server" Height="17px" Width="121px" ForeColor="DarkBlue" Font-Bold="True">HOME DEPTH</asp:label><asp:label id="Label5" style="Z-INDEX: 113; LEFT: 233px; POSITION: absolute; TOP: 597px" runat="server" Width="63px" ForeColor="DarkBlue" Font-Bold="True">LEVELS</asp:label><asp:label id="Label7" style="Z-INDEX: 116; LEFT: 236px; POSITION: absolute; TOP: 395px" runat="server" Width="97px" ForeColor="DarkBlue" Font-Bold="True">BEDROOMS</asp:label><asp:label id="Label8" style="Z-INDEX: 118; LEFT: 236px; POSITION: absolute; TOP: 438px" runat="server" Width="108px" ForeColor="DarkBlue" Font-Bold="True">BATHROOMS</asp:label><asp:checkbox id="CheckBox1" style="Z-INDEX: 119; LEFT: 228px; POSITION: absolute; TOP: 640px" runat="server" Width="150px" ForeColor="DarkBlue" Font-Bold="True" Text="GARAGE STALL"></asp:checkbox><asp:checkbox id="CheckBox2" style="Z-INDEX: 120; LEFT: 406px; POSITION: absolute; TOP: 640px" runat="server" Width="132px" ForeColor="DarkBlue" Font-Bold="True" Text="LIVINGROOM"></asp:checkbox><asp:checkbox id="CheckBox3" style="Z-INDEX: 123; LEFT: 565px; POSITION: absolute; TOP: 640px" runat="server" Width="147px" ForeColor="DarkBlue" Font-Bold="True" Text="DINNINGROOM"></asp:checkbox><asp:label id="Label6" style="Z-INDEX: 124; LEFT: 231px; POSITION: absolute; TOP: 693px" runat="server" Width="119px" ForeColor="DarkBlue" Font-Bold="True">OTHER DETAIL</asp:label><asp:textbox id="TextBox1" style="Z-INDEX: 125; LEFT: 366px; POSITION: absolute; TOP: 690px" runat="server" Width="327px" MaxLength="200"></asp:textbox><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 127; LEFT: 235px; POSITION: absolute; TOP: 288px" runat="server" Font-Size="X-Small" Width="103px" Font-Bold="True">
				<asp:ListItem Value="0">All</asp:ListItem>
				<asp:ListItem Value="Standard">Standard</asp:ListItem>
				<asp:ListItem Value="Exclusive">Exclusive</asp:ListItem>
				<asp:ListItem Value="Modern">Modern</asp:ListItem>
			</asp:dropdownlist><asp:dropdownlist id="DropDownList2" style="Z-INDEX: 128; LEFT: 237px; POSITION: absolute; TOP: 349px" runat="server" Font-Size="X-Small" Width="99px" Font-Bold="True">
				<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
				<asp:ListItem Value="20-30 ">20-30 ��.��</asp:ListItem>
				<asp:ListItem Value="30-40 ">30-40 ��.��</asp:ListItem>
				<asp:ListItem Value="40-50 ">40-50 ��.��</asp:ListItem>
				<asp:ListItem Value="50-60">50-60 ��.��</asp:ListItem>
				<asp:ListItem Value="60-70">60-70 ��.��</asp:ListItem>
				<asp:ListItem Value="70-80">70-80 ��.��</asp:ListItem>
				<asp:ListItem Value="80-100">80-100 ��.��</asp:ListItem>
				<asp:ListItem Value="100-150">100-150 ��.��</asp:ListItem>
				<asp:ListItem Value="150-1000">�ҡ���� 150 ��.��</asp:ListItem>
			</asp:dropdownlist><asp:dropdownlist id="DropDownList3" style="Z-INDEX: 131; LEFT: 235px; POSITION: absolute; TOP: 495px" runat="server" Font-Size="X-Small" Width="100px" Font-Bold="True">
				<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
				<asp:ListItem Value="5-10">5-10 m</asp:ListItem>
				<asp:ListItem Value="10-15">10-15 m</asp:ListItem>
				<asp:ListItem Value="15-20">15-20 m</asp:ListItem>
				<asp:ListItem Value="20-25">20-25 m</asp:ListItem>
				<asp:ListItem Value="30-35">30-35 m</asp:ListItem>
				<asp:ListItem Value="40-50">40-50 m</asp:ListItem>
				<asp:ListItem Value="50-60">50-60 m</asp:ListItem>
				<asp:ListItem Value="60-500">more 60 m</asp:ListItem>
			</asp:dropdownlist><asp:button id="Button1" style="Z-INDEX: 134; LEFT: 447px; POSITION: absolute; TOP: 748px" runat="server" Width="108px" ForeColor="DarkBlue" Font-Bold="True" BackColor="#FFE0C0" Text="SEARCH"></asp:button><asp:label id="Label9" style="Z-INDEX: 135; LEFT: 623px; POSITION: absolute; TOP: 843px" runat="server"></asp:label><asp:radiobuttonlist id="RadioButtonList1" style="Z-INDEX: 137; LEFT: 366px; POSITION: absolute; TOP: 393px" runat="server" ForeColor="DarkBlue" Font-Bold="True" RepeatDirection="Horizontal">
				<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
				<asp:ListItem Value="1">1</asp:ListItem>
				<asp:ListItem Value="2">2</asp:ListItem>
				<asp:ListItem Value="3">3</asp:ListItem>
				<asp:ListItem Value="4">4</asp:ListItem>
				<asp:ListItem Value="5">5</asp:ListItem>
			</asp:radiobuttonlist><asp:radiobuttonlist id="RadioButtonList2" style="Z-INDEX: 138; LEFT: 366px; POSITION: absolute; TOP: 435px" runat="server" ForeColor="DarkBlue" Font-Bold="True" RepeatDirection="Horizontal">
				<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
				<asp:ListItem Value="1">1</asp:ListItem>
				<asp:ListItem Value="2">2</asp:ListItem>
				<asp:ListItem Value="3">3</asp:ListItem>
			</asp:radiobuttonlist><asp:radiobuttonlist id="RadioButtonList3" style="Z-INDEX: 139; LEFT: 367px; POSITION: absolute; TOP: 593px" runat="server" ForeColor="DarkBlue" Font-Bold="True" RepeatDirection="Horizontal">
				<asp:ListItem Value="0" Selected="True">All</asp:ListItem>
				<asp:ListItem Value="1">1</asp:ListItem>
				<asp:ListItem Value="2">2</asp:ListItem>
				<asp:ListItem Value="3">3</asp:ListItem>
			</asp:radiobuttonlist></form>
	</body>
</HTML>
