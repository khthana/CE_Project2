<%@ Page Language="vb" AutoEventWireup="false" Codebehind="HomeRequire.aspx.vb" Inherits="HomeForYouApp.orderHome"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>HomeRequire</title>
		<META content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<META content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<META content="JavaScript" name="vs_defaultClientScript">
		<META content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<BODY bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<FORM id="Form1" method="post" runat="server">
			<FONT face="Tahoma"><FONT face="Tahoma">
					<asp:image id="Image1" style="Z-INDEX: 101; LEFT: 23px; POSITION: absolute; TOP: 18px" runat="server" ImageUrl="file:///C:\Documents and Settings\Jatupon\My Documents\Visual Studio Projects\HomeForYouApp\house-plans-logo1.jpg" Height="100px" Width="980px"></asp:image>
					<asp:Image id="Image2" style="Z-INDEX: 102; LEFT: 25px; POSITION: absolute; TOP: 135px" runat="server" ImageUrl="file:///C:\Documents and Settings\Jatupon\My Documents\Visual Studio Projects\HomeForYouApp\Untitled-1 copy.jpg" Height="109px" Width="383px"></asp:Image></FONT></FONT>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 103; LEFT: 427px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a1.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton3" style="Z-INDEX: 104; LEFT: 499px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a8.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton4" style="Z-INDEX: 105; LEFT: 571px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a2.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton7" style="Z-INDEX: 106; LEFT: 643px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a9.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton8" style="Z-INDEX: 107; LEFT: 715px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a3.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton9" style="Z-INDEX: 108; LEFT: 787px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a17.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton6" style="Z-INDEX: 109; LEFT: 858px; POSITION: absolute; TOP: 137px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a5.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:ImageButton id="ImageButton5" style="Z-INDEX: 110; LEFT: 930px; POSITION: absolute; TOP: 136px" runat="server" ImageUrl="file:///C:\Inetpub\wwwroot\HomeForYouApp\Pictures\a4.gif" Height="40px" Width="70px" BackColor="Silver"></asp:ImageButton>
			<asp:Label id="Label4" style="Z-INDEX: 111; LEFT: 436px; POSITION: absolute; TOP: 183px" runat="server" Height="25px" Width="70px">˹���á</asp:Label>
			<asp:Label id="Label5" style="Z-INDEX: 112; LEFT: 500px; POSITION: absolute; TOP: 182px" runat="server" Height="25px" Width="70px">ŧ����¹</asp:Label>
			<asp:Label id="Label6" style="Z-INDEX: 113; LEFT: 580px; POSITION: absolute; TOP: 182px" runat="server" Height="25px" Width="70px">Ẻ��ҹ</asp:Label>
			<asp:Label id="Label7" style="Z-INDEX: 114; LEFT: 646px; POSITION: absolute; TOP: 181px" runat="server" Height="25px" Width="70px">�Ź��ҹ</asp:Label>
			<asp:Label id="Label8" style="Z-INDEX: 115; LEFT: 734px; POSITION: absolute; TOP: 180px" runat="server" Height="25px" Width="70px">����</asp:Label>
			<asp:Label id="Label11" style="Z-INDEX: 116; LEFT: 795px; POSITION: absolute; TOP: 180px" runat="server" Height="25px" Width="70px">���й�����</asp:Label>
			<asp:Label id="Label10" style="Z-INDEX: 117; LEFT: 864px; POSITION: absolute; TOP: 179px" runat="server" Height="50px" Width="70px">��觫����Ź��ҹ</asp:Label>
			<asp:Label id="Label9" style="Z-INDEX: 118; LEFT: 941px; POSITION: absolute; TOP: 180px" runat="server" Height="25px" Width="70px">���ҧ��ҹ</asp:Label>
			<HR style="Z-INDEX: 119; LEFT: 426px; WIDTH: 578px; POSITION: absolute; TOP: 220px; HEIGHT: 24px" width="578" color="#ff6633" SIZE="24">
			<asp:Label id="Label1" style="Z-INDEX: 120; LEFT: 203px; POSITION: absolute; TOP: 764px" runat="server" Height="12px" Width="30px"></asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 121; LEFT: 44px; POSITION: absolute; TOP: 282px" runat="server" Height="25px" Width="250px" BackColor="#C0C0FF" Font-Bold="True" ForeColor="Blue">��������´����ǡѺ������ҧ��ҹ</asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 122; LEFT: 135px; POSITION: absolute; TOP: 336px" runat="server" Height="25px" Width="200px" BackColor="#00C0C0">��ʴط���������ҧ</asp:Label>
			<asp:Label id="Label12" style="Z-INDEX: 123; LEFT: 137px; POSITION: absolute; TOP: 384px" runat="server" Height="25px" Width="200px" BackColor="#00C0C0">�պ�ҹ</asp:Label>
			<asp:Label id="Label13" style="Z-INDEX: 124; LEFT: 136px; POSITION: absolute; TOP: 432px" runat="server" Height="25px" Width="200px" BackColor="#00C0C0">����ѧ��</asp:Label>
			<asp:Label id="Label14" style="Z-INDEX: 125; LEFT: 136px; POSITION: absolute; TOP: 479px" runat="server" Height="25px" Width="200px" BackColor="#00C0C0">ʶҹ��������ҧ</asp:Label>
			<asp:Label id="Label15" style="Z-INDEX: 126; LEFT: 137px; POSITION: absolute; TOP: 600px" runat="server" Height="25px" Width="200px" BackColor="#00C0C0">��������´�������</asp:Label>
			<asp:Button id="Button1" style="Z-INDEX: 127; LEFT: 366px; POSITION: absolute; TOP: 728px" runat="server" Height="30px" Width="100px" Text="�׹�ѹ" Font-Bold="True"></asp:Button>
			<asp:Button id="Button2" style="Z-INDEX: 128; LEFT: 509px; POSITION: absolute; TOP: 728px" runat="server" Height="30px" Width="100px" Text="¡��ԡ" Font-Bold="True"></asp:Button>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 129; LEFT: 413px; POSITION: absolute; TOP: 384px" runat="server" Height="25px" Width="100px"></asp:TextBox>
			<asp:TextBox id="TextBox2" style="Z-INDEX: 130; LEFT: 413px; POSITION: absolute; TOP: 432px" runat="server" Height="25px" Width="100px"></asp:TextBox>
			<asp:TextBox id="TextBox3" style="Z-INDEX: 131; LEFT: 412px; POSITION: absolute; TOP: 478px" runat="server" Height="100px" Width="300px" TextMode="MultiLine"></asp:TextBox>
			<asp:TextBox id="TextBox4" style="Z-INDEX: 132; LEFT: 413px; POSITION: absolute; TOP: 599px" runat="server" Height="100px" Width="300px" TextMode="MultiLine"></asp:TextBox>
			<asp:RadioButtonList id="RadioButtonList1" style="Z-INDEX: 133; LEFT: 413px; POSITION: absolute; TOP: 333px" runat="server" Height="30px" Width="300px" RepeatDirection="Horizontal">
				<asp:ListItem Value="0">���ҧ��</asp:ListItem>
				<asp:ListItem Value="1">�ҹ��ҧ</asp:ListItem>
				<asp:ListItem Value="2">������</asp:ListItem>
			</asp:RadioButtonList></FORM>
	</BODY>
</HTML>
