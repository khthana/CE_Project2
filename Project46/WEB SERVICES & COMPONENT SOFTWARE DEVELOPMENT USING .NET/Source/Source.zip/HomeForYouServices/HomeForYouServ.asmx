<%@ WebService Language="vb" Codebehind="HomeForYouServ.asmx.vb" Class="HomeForYouServices.Service1" %>
