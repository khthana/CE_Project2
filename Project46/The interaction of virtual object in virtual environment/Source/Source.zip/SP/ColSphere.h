// ColSphere.h: interface for the CColSphere class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COLSPHERE_H__32C5C8C0_C5F1_11D4_BCED_00104B10589D__INCLUDED_)
#define AFX_COLSPHERE_H__32C5C8C0_C5F1_11D4_BCED_00104B10589D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Finger.h"

class CColSphere  
{
public:
	bool bAllowRotate;
	bool bAllowTranslate;

	CD3DVec3 colPos[8];
	bool bGrasp;

	CRMFrame frame;
	CD3DAffine afSph;
	
	REAL radius;
	REAL mass;
	CMatrix3 inertia;

	CD3DVec3 force;
	CD3DVec3 torque;

	CD3DVec3 linearMom;
	CD3DVec3 angMom;
	CD3DVec3 vel;
	CD3DVec3 angVel;

	void Init();
	void CheckCollision(CFinger* finger);
	void AddForce(CD3DVec3 d, CD3DVec3 f);
	void ResolveCollision(REAL dt);
	void ClearForce();
	void UpdateMotion(REAL dt);

	CColSphere();
	virtual ~CColSphere();
};

#endif // !defined(AFX_COLSPHERE_H__32C5C8C0_C5F1_11D4_BCED_00104B10589D__INCLUDED_)
