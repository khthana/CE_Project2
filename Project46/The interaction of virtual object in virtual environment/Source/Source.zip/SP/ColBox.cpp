// ColBox.cpp: implementation of the CColBox class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SP.h"
#include "ColBox.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define FRICTION REAL(0.8)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CColBox::CColBox()
{
	bAllowRotate = true;
	bAllowTranslate = true;
}

CColBox::~CColBox()
{
}

void CColBox::Init()
{
	REAL xx = size.x * size.x;
	REAL yy = size.y * size.y;
	REAL zz = size.z * size.z;
	REAL mulConst = 1.0f;
	CD3DVec3 ex = mass / 12.0f * CD3DVec3(yy+zz, 0, 0) * mulConst;
	CD3DVec3 ey = mass / 12.0f * CD3DVec3(0, xx+zz, 0) * mulConst;
	CD3DVec3 ez = mass / 12.0f * CD3DVec3(0, 0, xx+yy) * mulConst;
	inertia = CMatrix3(ex, ey, ez);

	force = CD3DVec3();
	torque = CD3DVec3();
	vel = CD3DVec3();
	linearMom = CD3DVec3();
	angVel = CD3DVec3();
	angMom = CD3DVec3();
	bGrasp = false;
}

void CColBox::CheckCollision(CFinger* finger)
{
	bool bCollisionNow = false;

	for (int i=0; i<NFINGER; i++) 
	{
		CD3DVec3 rPos = afBox.Inv() * finger[i].realPos;
		struct Face {
			CD3DVec3 pos;
			CD3DVec3 normal;
		};
		Face face[7];
		CD3DVec3 halfBoxSize = size * 0.5f; 
		CD3DVec3 lower = halfBoxSize * -1.0f;
		CD3DVec3 upper = halfBoxSize;
		face[1].pos = upper;
		face[1].normal = CD3DVec3(1, 0, 0);
		face[2].pos = upper;
		face[2].normal = CD3DVec3(0, 1, 0);
		face[3].pos = upper;
		face[3].normal = CD3DVec3(0, 0, 1);

		face[4].pos = lower;
		face[4].normal = CD3DVec3(-1, 0, 0);
		face[5].pos = lower;
		face[5].normal = CD3DVec3(0, -1, 0);
		face[6].pos = lower;
		face[6].normal = CD3DVec3(0, 0, -1);

		// find distance from finger to every faces of box
		REAL dist[7];
		for (int j=1; j<=6; j++)
		{
			dist[j] = (rPos - face[j].pos) * face[j].normal;
		}

		// finger is inside box when all dists are negative
		int inside = 1;
		for (int m=1; m<=6; m++)
		{
			inside &= (dist[m] <= 0);
		}
		int minID = 0;
		REAL minDist = -999.99f;
		if (inside == 1)
		{
			// find colliding face of box
			for (int n=1; n<=6; n++)
			{
				if (dist[n] >= minDist)
				{
					minID = n;
					minDist = dist[minID];
				}
			}
			bCollisionNow = true;
		}
		else
		{
			bCollisionNow = false;
		}
//		if (i==0) TRACE("%d dist 1=%2.2f 2=%2.2f 3=%2.2f 4=%2.2f 5=%2.2f 6=%2.2f min=%2.2f face=%d ",
//			bCollideNow, dist[1],dist[2],dist[3],dist[4],dist[5],dist[6],minDist,minID);

		CD3DVec3 colPosNow;
		switch (minID)
		{
		case 1:
			colPosNow = CD3DVec3(halfBoxSize.x, rPos.y, rPos.z);
			break;
		case 2:
			colPosNow = CD3DVec3(rPos.x, halfBoxSize.y, rPos.z);
			break;
		case 3:
			colPosNow = CD3DVec3(rPos.x, rPos.y, halfBoxSize.z);
			break;
		case 4:
			colPosNow = CD3DVec3(-halfBoxSize.x, rPos.y, rPos.z);
			break;
		case 5:
			colPosNow = CD3DVec3(rPos.x, -halfBoxSize.y, rPos.z);
			break;
		case 6:
			colPosNow = CD3DVec3(rPos.x, rPos.y, -halfBoxSize.z);
			break;
		}
		
		if (colPos[i] == CD3DVec3()) // no previous collision
		{
			if (bCollisionNow) // no previous collision but now colliding
			{
				// preserve collision position and face 
				colPos[i] = colPosNow;
				colFace[i] = minID;
				strcpy(finger[i].collideTo, frame.Name());
			}
			else // no previous collision and no collidision now
			{
				// reset collision position and face 
				colPos[i] = CD3DVec3();
				colFace[i] = 0;
				if (strcmp(finger[i].collideTo, frame.Name()) == 0)
				{
					strcpy(finger[i].collideTo, "NONE");
				}
			}
		}
		else // has previous collision
		{
			if (bCollisionNow) // has previous collision and now colliding
			{
				// consider friction
				CD3DVec3 move = rPos - colPos[i];
				REAL depth = (rPos - face[minID].pos) * -face[minID].normal;
				CD3DVec3 newColPos = rPos + (depth * face[minID].normal);
				CD3DVec3 tangent = newColPos - colPos[i];
				CD3DVec3 slip;
				if ((minID == colFace[i]) && (tangent.Size() > FRICTION * depth)) // with friction
				{
					slip = (tangent.Size() - (FRICTION * depth)) * tangent.Unit();
				}
				else // without friction
				{
					slip = CD3DVec3();
				}
				colPos[i] = colPos[i] + slip;
				colFace[i] = minID;
			}
			else // has previous collision but no collision now
			{
				colPos[i] = CD3DVec3();
				colFace[i] = 0;
				if (strcmp(finger[i].collideTo, frame.Name()) == 0)
				{
					strcpy(finger[i].collideTo, "NONE");
				}
			}
		}
	}
}

void CColBox::AddForce(CD3DVec3 d, CD3DVec3 f)
{
	force += f;
	torque += d ^ f;
}

void CColBox::ClearForce()
{
	// clear force and torque
	force = CD3DVec3();
	torque = CD3DVec3();
	// clear moment
	linearMom = CD3DVec3();
	angMom = CD3DVec3();
	// clear velocity
//	vel = CD3DVec3();
//	angVel = CD3DVec3();
}


void CColBox::ResolveCollision(REAL dt)
{
	// linear momentum; d/dt P(t) = F(t)
	CD3DVec3 P = force * dt;
	linearMom += P;

	// velocity; d/dt v(t) = d/dt P(t) / mass
	CD3DVec3 v = linearMom / mass;	
	vel += v;

	// angular moment; d/dt L(t) = torque(t)
	CD3DVec3 L = torque * dt;
	angMom += L;

	// rotation matrix = affine of object
	CMatrix3 R = afBox;
	// inertia tensor; I(t) = R(t) * I_obj * R(t)_transpose
	// since, R(t)_transpose = R(t)_inv
	CMatrix3 I = R * inertia * R.Inv();
		
	// angular velocity; w(t) = I(t)_inv * L(t)
	angVel = I.Inv() * angMom;
}

void CColBox::UpdateMotion(REAL dt)
{
	// translation
	if (bAllowTranslate) afBox.Pos(afBox.Pos() + vel * dt);

	// rotation
	CD3DAffine afRot;
	if (bAllowRotate)
		afRot.InitRot(angVel.Size() * dt, angVel.Unit());
	afBox = afRot.Rot(afBox);

	frame.AfWorld(afBox);
}