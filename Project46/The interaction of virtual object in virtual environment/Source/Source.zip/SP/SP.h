// SP.h : main header file for the SP application
//

#if !defined(AFX_SP_H__222977A6_0E28_11D3_930A_00104B10589D__INCLUDED_)
#define AFX_SP_H__222977A6_0E28_11D3_930A_00104B10589D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSPApp:
// See SP.cpp for the implementation of this class
//
class CSPView;
class CSPApp : public CWinApp
{
public:
	CSPApp();
	CSPView* view;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG LCount);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSPApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SP_H__222977A6_0E28_11D3_930A_00104B10589D__INCLUDED_)
