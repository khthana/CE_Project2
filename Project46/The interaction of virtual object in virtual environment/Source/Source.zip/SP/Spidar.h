#include "HapticDevice.h"
#include "SpidarDriver.h"

using namespace Hase;

//
//----------------------------------------------------------------------------
//	CSpidar
//
class CSpidar : public CHapticDevice
{
private:
	void UseTwoStrings(Vec3 ph1, Vec3 ph2, Vec3 f, REAL &tens1, REAL &tens2);
	void UseThreeStrings(Vec3 *ph, Vec3 f, REAL *tens);
	REAL MinThreeValues(REAL a, REAL b, REAL c);
	void SortThreeValues(REAL val1, REAL val2, REAL val3, int &a, int &b, int &c);

public:
	bool bInitialized;
	int channel;
	Vec3 posSqrConst;
	CMatrix3 matPos;


	CSpidarEncoder encoder[4];
	CSpidarMotor motor[4];
	static Vec3 motorPosDef[][4];
	static int ctAddrDef[];	
	static int daAddrDef[];
	static REAL voltPerNewton;
	static REAL lenPerPulse;
	static REAL minForce;
	static REAL maxForce;
	static REAL MAXTENSION;

	Vec3 SetForce(const Vec3& f);
	Vec3 GetPos();
	void MinForceSet();
	virtual bool Init(int ch=0);
	virtual bool BeforeCalibrate();
	virtual bool Calibrate();
	virtual bool AfterCalibrate();
	void InitMat();
	REAL AvailableForce(int disable, Vec3& f, Vec3* v3Str);
	CSpidar();
	virtual ~CSpidar();
};
