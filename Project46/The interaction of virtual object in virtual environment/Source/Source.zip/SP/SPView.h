// SPView.h : interface of the CSPView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPVIEW_H__222977AE_0E28_11D3_930A_00104B10589D__INCLUDED_)
#define AFX_SPVIEW_H__222977AE_0E28_11D3_930A_00104B10589D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <Hase/D3D/HD3DRM.h>
#include <Hase/Misc/MMTimer.h>
#include <Hase/Stream/WinStream.h>
#include <Hase/Stream/SockStr.h>
#include <Hase/DSound/HDSound.h>
#include "Finger.h"
#include "ColBox.h"
#include "ColSphere.h"

using namespace Hase;

class CSPView : public CView
{
protected: // create from serialization only
	CSPView();
	DECLARE_DYNCREATE(CSPView)

// Attributes
public:
	CSPDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:

	int GRAVITY_ACTIVE;
	bool bDisplayForce;
	bool bRotate;
	bool bTranslate;

	REAL startTime;
	REAL stopTime;
	REAL lapTime;
	bool running;
	REAL tick;
	int start;
	void ToggleStartStop();
	int objID;
	bool bCheck;

	int swap;
	void SwapPosition();
	void HitIndicator();
	CRMMesh meshIndicator[6];
	CRMFrame frIndicator[6];
	int hitface;
	void UpdateIndicator();
	void ResetIndicator();

	CFinger finger[NFINGER];

	void MotionSphere(int n);
	void MotionBox(int n);
	void CollisionSphereToWall();
	void CollisionSphereToSphere();
	void CollisionSphereToBox();
	void ResetObjects();
	void CollisionBoxToBox(int src, int trg);
	void CollisionBoxToWall();
	void GetRotationAngle();
	static CD3DAffine afBox[2];
	static CD3DAffine afSph[2];


	// communication
	CSockStream sock;
	void SendPos();
	BOOL Connect();
	BOOL Is_Connect;
	std::ofstream file;

	// text pane
	CWinStreamWin wsw;

	// mesh objects
	CRMMesh meshOpenSave;
	CRMFrame frOpenSave;

	CRMFrame frRPos[8];
	int numObject;

	CColBox box[2];
//	CRMFrame frBox[2];
	void BuildBox();
	void RedrawBox();
	bool bBox0, bBox1;
	bool bRcube;
	char state;

	CColSphere sphere[2];
//	CRMFrame frSphere[2];
	void BuildSphere();
	void RedrawSphere();
	bool bSphere0, bSphere1;

	void BuildCylinder();
	void BuildGrid();
	void BuildFloor();
	static CD3DVec3 floorPos;
	static CD3DVec3 floorNormal;

	// multimedia timer
	CMMTimer mmtimer;
	static void OnMMTimer(void* arg);
	void HapticStep();
	int timerType;
	REAL lastTime;

	// directx
	CD3DRM rm;
	CD3DDevice surf;
	CDDraws	ddraws;
	CDDSurface surfString;
	CRMLight pointLight;
//	CDSound dsound;
//	int hWav[3];
	int dataType;

	int calibID;
	bool bOffset;
	bool bCalibrate;
	void RecalibrateFinger(int num);
	void Calibrate();
	void OnIdle();
	void StartTask();
	int firstrun;

public:
	virtual ~CSPView();

private:
	void CloseFile();
	void ClearBuffer();
	void Save1FingerToBuffer(int index);
	void Save8FingersToFile();
	void Test();
	void Step();
	void InitScene();
	void UpdateScene();
	CRMFrame BuildAxes();
	REAL dtoffset;
	REAL deltaTime;
	int fingerID;

	struct EXPDATA {
		CD3DVec3 pos;
		REAL length0, length1, length2;
		REAL counter0, counter1, counter2;
	};
	EXPDATA data[8];

	void SaveOneSetDataToFile();
	void GetDataAtOnePosition(int i);
	void ClearAllData();
	void Trigger();
	void GetExpData();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSPView)
	afx_msg void OnOpenMesh();
	afx_msg void OnOpenLogPane();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnConnect();
	afx_msg void OnButtonConnect();
	afx_msg void OnBox();
	afx_msg void OnSphere();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnFileSave();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnUpdateForce(CCmdUI* pCmdUI);
	afx_msg void OnForce();
	afx_msg void OnButtonGravity();
	afx_msg void OnButtonMmtimer();
	afx_msg void OnButtonThread();
	afx_msg void OnFloor();
	afx_msg void OnUpdateRotate(CCmdUI* pCmdUI);
	afx_msg void OnRotate();
	afx_msg void OnUpdateTranslate(CCmdUI* pCmdUI);
	afx_msg void OnTranslate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SPView.cpp
inline CSPDoc* CSPView::GetDocument()
   { return (CSPDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPVIEW_H__222977AE_0E28_11D3_930A_00104B10589D__INCLUDED_)
