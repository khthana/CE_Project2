// Finger.h: interface for the CFinger class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FINGER_H__D6F301E3_3241_11D4_BCED_00104B10589D__INCLUDED_)
#define AFX_FINGER_H__D6F301E3_3241_11D4_BCED_00104B10589D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <Hase/D3D/HD3DRM.h>
#include "Spidar.h"

using namespace Hase;

#define NFINGER 2

class CFinger  
{
public:
	CSpidar dev;

	CRMFrame frame;

	CD3DVec3 realPos;
	CD3DVec3 virtualPos;
	bool bCollide;
	
	CD3DVec3 force;
	CD3DVec3 torque;
	CD3DVec3 diff;
	CD3DVec3 prop;

	char collideTo[8];

	CD3DVec3 tempPos;
	REAL L0, L1, L2;

	void Init(int i);

	CFinger();
	virtual ~CFinger();
};

#endif // !defined(AFX_FINGER_H__D6F301E3_3241_11D4_BCED_00104B10589D__INCLUDED_)
