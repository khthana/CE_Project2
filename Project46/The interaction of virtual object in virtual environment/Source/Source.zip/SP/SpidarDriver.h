#include <Hase/Misc/Inc.h>
#include <Hase/D3D/HD3DAffine.h>
using namespace Hase;

#define	CLOCK		1 //	counter�̉�]����(���v����𐳂ɂ���ꍇ)
#define CONTRCLK	0 //	counter�̉�]����(���v����𕉂ɂ���ꍇ)
#define DAvaluePerVolt 409.6
#define Vec3 CD3DVec3

//----------------------------------------------------------------------------
//	CSpidarMotor
//
class CSpidarMotor 
{
protected:
	int daChannel;
	REAL maxForce;
	REAL minForce;
	REAL voltPerNewton;
	int daAddress;
	REAL daValuePerNewton;

public:
	Vec3 pos;
	CSpidarMotor();
	~CSpidarMotor();
	void Set(int daAdr, int daCh, REAL VoltPerNewton, REAL min, REAL max);
	int Init();
	int DaAddr(){return daAddress;}
	int Force(REAL f);
	void DaChannel(int daChannel);
	int DaChannel(){return daChannel;}
 	REAL MinForce(){return minForce;}
	void MinForce(REAL mf);
	REAL MaxForce(){return maxForce;}
	void MaxForce(REAL mf);
	void VoltPerNewton(REAL vpn);
	REAL VoltPerNewton();
	int Volt(REAL);
	int DaOut(int);
};

//----------------------------------------------------------------------------
//	CSpidarEncoder
//
class CSpidarEncoder 
{
protected:
	REAL lengthPerPulse;
	int ctChannel;
	int ctAddress;
	int direction;

public:
	CSpidarEncoder();
	void Set(int ctAdr, int ctCh, int dir, REAL lpp);
	int Init();
	int CtAddr(){return ctAddress;}
	void CtChannel(int ctChannel);
	int CtChannel(){return ctChannel;}
	void LenPerPulse(REAL lpp);
	REAL LenPerPulse();
	int Length(REAL);
	REAL Length();
	int Count(long);
	long Count();
	bool Exist();
};

