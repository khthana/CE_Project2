#include "stdafx.h"
#include "Spidar.h"
//----------------------------------------------------------------------------
//	SPIDAR�̒萔�̐ݒ�
//int CSpidar::ctAddrDef[] = {0x230, 0x240, 0x250, 0x260, 0x270, 0x280};
//int CSpidar::daAddrDef[] = {0x340, 0x350, 0x360};
//yo edit
int CSpidar::ctAddrDef[] = {0x304, 0x308};
int CSpidar::daAddrDef[] = {0x300};


//	�P�j���[�g���o�����߂�DA�̏o�͓d��[V/N]	{0����,1����,...}
//	maxon �̏ꍇ
//	0.008[m]    / 0.0438[Nm/A] / 0.5[A/V] =  0.365296803653
//	��t���@�̏ꍇ
//	0.008[m]    / 0.0277[Nm/A] / 0.5[A/V] =  0.577617328520
//REAL CSpidar::voltPerNewtonDef[] = {0.5776f, 0.5776f};
REAL CSpidar::voltPerNewton = 0.577617328520f;

//	�P�J�E���g�̒��� [m/pulse]
//	2*PI*0.008[m] / 500[pulse]*4 = 2.513274122872e-5
//REAL CSpidar::lenPerPulseDef[] = {2.513274122872e-5f, -2.513274122872e-5f};
REAL CSpidar::lenPerPulse = 2.513274122872e-5f;

//	�ŏ����� [N]
//REAL CSpidar::minForceDef[] = {0.5f, 0.5f};
//REAL CSpidar::minForce = 0.35f;
REAL CSpidar::minForce = 0.5f;

//	�ő咣�� [N]
//REAL CSpidar::maxForceDef[] = {20.0f, 20.0f};
REAL CSpidar::maxForce = 20.0f;
#if 0
Vec3 CSpidar::motorPosDef[][3] =	//	���[�^�̎��t���ʒu(���S�����_�Ƃ���)
{
	// left hand side
	/* 0*/{Vec3(-0.0250f, +0.2280f, -0.2815f), /* 1*/Vec3(-0.3170f, +0.0800f, -0.2825f), /* 2*/Vec3(-0.3680f, +0.2300f, -0.0250f)},
	/* 3*/{Vec3(-0.0250f, +0.2300f, +0.2815f), /* 4*/Vec3(-0.3175f, +0.0250f, +0.2825f), /* 5*/Vec3(-0.3680f, +0.2300f, +0.0250f)},
	/* 6*/{Vec3(-0.0250f, -0.2300f, +0.2815f), /* 7*/Vec3(-0.3175f, -0.0250f, +0.2825f), /* 8*/Vec3(-0.3680f, -0.2300f, +0.0250f)},
	/* 9*/{Vec3(-0.0250f, -0.2280f, -0.2815f), /*10*/Vec3(-0.3170f, -0.0800f, -0.2825f), /*11*/Vec3(-0.3680f, -0.2300f, -0.0250f)},
	// right hand side
	/*12*/{Vec3(+0.0250f, +0.2280f, -0.2815f), /*13*/Vec3(+0.3170f, +0.0800f, -0.2825f), /*14*/Vec3(+0.3680f, +0.2300f, -0.0250f)},
	/*15*/{Vec3(+0.0250f, +0.2300f, +0.2815f), /*16*/Vec3(+0.3175f, +0.0250f, +0.2825f), /*17*/Vec3(+0.3680f, +0.2300f, +0.0250f)},
	/*18*/{Vec3(+0.0250f, -0.2300f, +0.2815f), /*19*/Vec3(+0.3175f, -0.0250f, +0.2825f), /*20*/Vec3(+0.3680f, -0.2300f, +0.0250f)},
	/*21*/{Vec3(+0.0250f, -0.2280f, -0.2815f), /*22*/Vec3(+0.3170f, -0.0800f, -0.2825f), /*23*/Vec3(+0.3680f, -0.2300f, -0.0250f)}
};
#endif

#if 1
//yo edit
#define PX	0.265f	//	x�����̕ӂ̒���/2
#define PY	0.265f	//	y�����̕ӂ̒���/2
#define PZ	0.265f	//	z�����̕ӂ̒���/2
Vec3 CSpidar::motorPosDef[][4] =	//	���[�^�̎��t���ʒu(���S�����_�Ƃ���)
	{
		{Vec3( PX, PY,-PZ), Vec3(-PX, PY, PZ), Vec3(-PX,-PY,-PZ), Vec3( PX,-PY, PZ)},
		{Vec3(-PX, PY,-PZ),	Vec3( PX, PY, PZ), Vec3(-PX,-PY, PZ), Vec3( PX,-PY,-PZ)}
		
	};
#endif

REAL CSpidar::MAXTENSION = REAL(CSpidar::maxForce - CSpidar::minForce);

//----------------------------------------------------------------------------

CSpidar::CSpidar()
{
	bInitialized = false;
	channel = 0;
}

CSpidar::~CSpidar()
{
	MinForceSet();
}

bool CSpidar::Init(int ch) //ch=0,1,2,...,7
{
	if (bInitialized) return true;
	int i;
	channel = ch;
	//Initialize motors
	switch(channel)
	{
	case 0:
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
	case 1:
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i+4, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
/*	case 2:
		for(i=0; i<2; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i+6, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		motor[2].pos = motorPosDef[channel][2];
		motor[2].Set(daAddrDef[1], 0, voltPerNewton, minForce, maxForce);
		motor[2].Init();
		break;
	case 3:
		for(i=0; i<3; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[1], i+1, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
	case 4:
		for(i=0; i<3; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[1], i+4, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
	case 5:
		motor[0].pos = motorPosDef[channel][0];
		motor[0].Set(daAddrDef[1], 7, voltPerNewton, minForce, maxForce);
		motor[0].Init();
		for(i=1; i<3; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[2], i-1, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
	case 6:
		for(i=0; i<3; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[2], i+2, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
	case 7:
		for(i=0; i<3; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[2], i+5, voltPerNewton, minForce, maxForce);
			motor[i].Init();
		}
		break;
*/	}
	// Initialize encoders
	switch(channel)
	{
	case 0:
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[0], i, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
	case 1:
		//encoder[0].Set(ctAddrDef[0], 3, 0, lenPerPulse);
		//encoder[0].Init();
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[1], i, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
/*	case 2:
		for(i=0; i<2; i++)
		{
			encoder[i].Set(ctAddrDef[1], i+2, 0, lenPerPulse);
			encoder[i].Init();
		}
		encoder[2].Set(ctAddrDef[2], 0, 0, lenPerPulse);
		encoder[2].Init();
		break;
	case 3:
		for(i=0; i<3; i++)
		{
			encoder[i].Set(ctAddrDef[2], i+1, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
	case 4:
		for(i=0; i<3; i++)
		{
			encoder[i].Set(ctAddrDef[3], i, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
	case 5:
		encoder[0].Set(ctAddrDef[3], 3, 0, lenPerPulse);
		encoder[0].Init();
		for(i=1; i<3; i++)
		{
			encoder[i].Set(ctAddrDef[4], i-1, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
	case 6:
		for(i=0; i<2; i++)
		{
			encoder[i].Set(ctAddrDef[4], i+2, 0, lenPerPulse);
			encoder[i].Init();
		}
		encoder[2].Set(ctAddrDef[5], 0, 0, lenPerPulse);
		encoder[2].Init();
		break;
	case 7:
		for(i=0; i<3; i++)
		{
			encoder[i].Set(ctAddrDef[5], i+1, 0, lenPerPulse);
			encoder[i].Init();
		}
		break;
*/	}
	InitMat();
	bInitialized = Calibrate();
	return bInitialized;
}
/*
//yo edit
bool CSpidar::Init(int ch) 
{
	int i;
	channel = ch;
/*S*************************************************
	//	�h���C�o�̎擾
	if (!drivers.bInitalized) drivers.Init();
	if (driver)
		{
		drivers.Return(driver);
		driver = NULL;
		}
	driver = drivers.Rent();
**S**************************************************/
/*
	switch(channel)
	{
	case 0:
		//	���[�^�̏�����
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i, voltPerNewton, minForce, maxForce);
			//S motor[i].Set(driver, i, voltPerNewtonDef[channel], minForceDef[channel], maxForceDef[channel]);
			motor[i].Init();
		}
		break;
	case 1:
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i+4, voltPerNewton, minForce, maxForce);
			//S motor[i].Set(driver, i, voltPerNewtonDef[channel], minForceDef[channel], maxForceDef[channel]);
			motor[i].Init();
		}
		break;
	}
	switch(channel)
	{
	case 0:
		//	�G���R�[�_�̏�����
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[0], i, 0, lenPerPulse);
			//S encoder[i].Set(driver, i, lenPerPlusDef[channel]);
			encoder[i].Init();
		}
		break;
	case 1:
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[1], i, 0, lenPerPulse);
			//S encoder[i].Set(driver, i, lenPerPlusDef[channel]);
			encoder[i].Init();
		}
		break;
	}

	InitMat();
	bInitialized = Calibrate();
	return true;
}
*/



bool CSpidar::BeforeCalibrate()
{
	MinForceSet();
	return true;
}

bool CSpidar::Calibrate()
{
	emuPos = Vec3(0,0,0);
	Clear();
	MinForceSet();
	for(int i=0; i<4; i++)
		encoder[i].Length(motor[i].pos.Size());
	return encoder[0].Exist();
//	return true;
}

bool CSpidar::AfterCalibrate()
{
	MinForceSet();
	return true;
}

void CSpidar::MinForceSet()
{
	force = Vec3(0,0,0);
	for(int i=0; i<4; i++) 
		motor[i].Force(motor[i].MinForce());
}
/*
#if 0
Vec3 CSpidar::GetPos()
{
	if (bInitialized)
	{
		int ch = channel;

		// motor positions
		Vec3 A0 = motor[0].pos; //x
		Vec3 A1 = motor[1].pos; //y
		Vec3 A2 = motor[2].pos; //z
		if (ch==0) 
			TRACE("mot=%2.3f,%2.3f,%2.3f %2.3f,%2.3f,%2.3f %2.3f,%2.3f,%2.3f ",
			A0.x, A0.y, A0.z, A1.x, A1.y, A1.z, A2.x, A2.y, A2.z);

		// Length of strings
		REAL len0 = encoder[0].Length();
		REAL len1 = encoder[1].Length();
		REAL len2 = encoder[2].Length();
		REAL len0Sqr = pow(len0, 2);
		REAL len1Sqr = pow(len1, 2);
		REAL len2Sqr = pow(len2, 2);
		if (ch==0) TRACE("len=%2.3f %2.3f %2.3f ", len0, len1, len2); 

		// Normal vectors
		Vec3 n1, n2, n3;
		n1 = (A1 - A0).Unit();
		n2 = (A2 - A0).Unit();
		if ((ch == 0) || (ch == 2) || (ch == 5) || (ch == 7))
			n3 = n2 ^ n1;
		else
			n3 = n1 ^ n2;
		if (ch==0) TRACE("n3=%2.2f,%2.2f,%2.2f ", n3.x, n3.y, n3.z);

		REAL cosTheta = n1 * n2;
		REAL sinSqrTheta = 1.0f - pow(cosTheta, 2);
		REAL oneOverSinSqrTheta = 1.0f / sinSqrTheta;
		
		// distance between motors
		REAL d1 = (A1 - A0).Size();
		REAL d2 = (A2 - A0).Size();
		REAL d1Sqr = pow(d1, 2);
		REAL d2Sqr = pow(d2, 2);
		//if (ch==0) TRACE("d=%f %f ", d1, d2);
#if 0
		REAL m10 = d1 / (2 * sinSqrTheta);
		REAL m20 = d2 / (2 * sinSqrTheta);
		REAL m11 = -1 / (2 * d1 * sinSqrTheta);
		REAL m21 = -1 / (2 * d2 * sinSqrTheta);

		REAL alpha1 = (m10 + (m11 * (len1Sqr - len0Sqr))) - 
			(cosTheta * (m20 + (m21 * (len2Sqr - len0Sqr))));
		REAL alpha2 = -(cosTheta * (m10 + (m11 * (len1Sqr - len0Sqr)))) +
			(m20 + (m21 * (len2Sqr - len0Sqr)));
#endif
		REAL K1 = 0.5f * (d1Sqr - len1Sqr + len0Sqr);
		REAL K2 = 0.5f * (d2Sqr - len2Sqr + len0Sqr);
		
		REAL alpha1 = oneOverSinSqrTheta * ((K1 / d1) - (cosTheta * (K2 / d2))); 
		REAL alpha2 = oneOverSinSqrTheta * ((K2 / d2) - (cosTheta * (K1 / d1)));

		//if (ch==0) TRACE("alpha=%f %f %f %f ", alpha1, alpha2, alpha11, alpha22);

		Vec3 A3minusA0 = (alpha1 * n1) + (alpha2 * n2);
		REAL alpha3 = sqrt(len0Sqr - pow(A3minusA0.Size(), 2));
		Vec3 P;
		if (alpha3 > 0) P = A0 + A3minusA0 + (alpha3 * n3);
		else P = Vec3();
		if (ch==0) TRACE("P=%2.2f,%2.2f,%2.2f \n", P.x, P.y, P.z);
		return P;
	}
	else
	{
		return CHapticDevice::GetPos();
	}
}
#endif
*/
#if 1
Vec3 CSpidar::GetPos()
{
	//BOOL traceEnable = 0;
	if (bInitialized)
	{/*
		if (traceEnable) TRACE("ch=%d ", channel);
		REAL x0,y0,z0, x1,y1,z1, x2,y2,z2;
		x0 = motor[0].pos.x;
		y0 = motor[0].pos.y;
		z0 = motor[0].pos.z;
	
		x1 = motor[1].pos.x;
		y1 = motor[1].pos.y;
		z1 = motor[1].pos.z;
		
		x2 = motor[2].pos.x;
		y2 = motor[2].pos.y;
		z2 = motor[2].pos.z;

		Vec3 plnCenter = (motor[0].pos + motor[1].pos + motor[2].pos) / 3.0f;
		
		REAL A0, A1, A2;
		A0 = pow(x0,2) + pow(y0,2) + pow(z0,2);
		A1 = pow(x1,2) + pow(y1,2) + pow(z1,2);
		A2 = pow(x2,2) + pow(y2,2) + pow(z2,2);
				
		// Length of strings
		REAL L0, L1, L2, L0Sqr, L1Sqr, L2Sqr;
		L0 = encoder[0].Length();
		L1 = encoder[1].Length();
		L2 = encoder[2].Length();
		
		L0Sqr = pow(L0,2);
		L1Sqr = pow(L1,2);
		L2Sqr = pow(L2,2);
	
		REAL B0, B1;
		B0 = (L0Sqr - L1Sqr - A0 + A1) / 2.0f;
		B1 = (L0Sqr - L2Sqr - A0 + A2) / 2.0f;
				
		REAL denom1, C0, C1;
		denom1 = ((z2 - z0) * (y1 - y0)) - ((z1 - z0) * (y2-y0));
		C0 = ((B0 * (z2 - z0)) - (B1 * (z1 - z0))) / denom1;
		C1 = (((x2 - x0) * (z1 - z0)) - ((x1 - x0) * (z2 - z0))) / denom1;
			
		REAL denom2, D0, D1;
		denom2 = ((y2 - y0) * (z1 - z0)) - ((y1 - y0) * (z2 - z0));
		D0 = ((B0 * (y2 - y0)) - (B1 * (y1 - y0))) / denom2;
		D1 = (((y1 - y0) * (x2 - x0)) - ((y2 - y0) * (x1 - x0))) / denom2;
			
		REAL a, b, c;
		a = 1.0f + pow(C1,2) + pow(D1,2);
		b = 2.0f * ((C0*C1) - (C1*y0) + (D0*D1) - (D1*z0) - x0);
		c = A0 - L0Sqr + pow(C0,2) + pow(D0,2) - (2.0f*C0*y0) - (2.0f*D0*z0);
		//if (traceEnable) TRACE("Eq.= %fx^2 + %fx + %f = 0 ", a, b, c);

		REAL criticalTerm = pow(b,2) - (4.0f*a*c);
		if (criticalTerm <= 0)
		{
			if (traceEnable) TRACE("center= %f,%f,%f \n", plnCenter.x, plnCenter.y, plnCenter.z);
			return plnCenter;
		}

		// Solve polynomial eq. ax^2 + bx^1 + c = 0
		// solution x = (-b+-sqrt(b^2-4ac))/2a
		//
		// for finger0 to finger3 (Left hand)  use	x = (-b+sqrt(b^2-4ac))/2a
		//     ^^^^^^^^^^^^^^^^^^	                      ^^^	
		// for finger4 to finger7 (Right hand) use	x = (-b-sqrt(b^2-4ac))/2a
		//     ^^^^^^^^^^^^^^^^^^		                  ^^^	
		REAL x, y, z;
		if (channel < 4) 
			x = (-b + sqrt(pow(b,2) - (4.0f*a*c))) / (2.0f*a);
		else
			x = (-b - sqrt(pow(b,2) - (4.0f*a*c))) / (2.0f*a);

		y = C0 + (C1 * x);
		z = D0 + (D1 * x);
		if (traceEnable) TRACE("P= %f,%f,%f \n", x, y, z);
		return Vec3(x,y,z);
	*/
	//yo edit
		REAL len[4];
		for(int i=0; i<4; i++) len[i]=encoder[i].Length();
		Vec3 rtv = matPos * (
			Vec3(	Square(len[0])-Square(len[1]),
				Square(len[1])-Square(len[2]),
				Square(len[2])-Square(len[3])	) + posSqrConst);
		return rtv;

	}
	else
	{
		return CHapticDevice::GetPos();
	}
}
#endif

REAL CSpidar::AvailableForce(int disable, Vec3& f, Vec3* v3Str)
	{
	Vec3 fOrg = f;
	Vec3 e[3];
	REAL l[3];
	int i,j=0;
	for(i=0; i<4; i++)
		{
		if (i==disable) continue;
		e[j] = v3Str[i];
		l[j] = motor[i].MaxForce();
		j++;
		}
	REAL det = CMatrix3(e[0], e[1], e[2]).Det();
	for(i=0; i<3; i++)
		{
		Vec3 n1 = (e[(i+1)%3] ^ e[(i+2)%3]).Unit();
		REAL inp1 = n1*e[i];
		if (inp1 < 0)
			{
			n1 = -n1;
			inp1 = -inp1;
			}
		//	�͂ݏo��������؂藎�Ƃ�
		REAL dist1 = f*n1;
		REAL move1;
		if (dist1 > inp1 * l[i]) move1 = dist1 - inp1*l[i];
		else if (dist1 >= 0) continue;	//	�͂ݏo���ĂȂ���Ύ��̎���
		else move1 = dist1;
		f = f - move1*n1;
		dist1 -= move1;
		for(int j=0; j<3; j++)
			{
			if (j==i) continue;
			Vec3 n2 = (e[(j+1)%3] ^ e[(j+2)%3]).Unit();
			REAL inp2 = n2*e[j];
			if (inp2 < 0)
				{
				n2 = -n2;
				inp2 = -inp2;
				}
			REAL dist2 = f*n2;
			REAL move2;
			if (dist2 > inp2*l[j]) move2 =dist2 - inp2*l[j];
			else if (dist2 >= 0) continue;
			else move2 = dist2;
			f = f - move2 * (n2-(n2*n1)*n1) / (1-Square(n1*n2));
			for(int k=0; k<3; k++)
				{
				if (i==k) continue;
				if (j==k) continue;
				Vec3 n3 = (e[(k+1)%3] ^ e[(k+2)%3]).Unit();
				REAL inp3 = n3*e[k];
				if (inp3 < 0)
					{
					n3 = -n3;
					inp3 = -inp3;
					}
				REAL dist3 = f*n3;
				if (0<=dist3 && dist3<=inp3*l[k]) break;
				//	���ׂĂ͂ݏo���Ă���
				f = (dist1>0 ? e[i]*l[i] : Vec3()) + 
					(dist2>0 ? e[j]*l[j] : Vec3()) + 
					(dist3>0 ? e[k]*l[k] : Vec3());
				break;
				}
			break;
			}
		break;
		}
//11.20	REAL eval = ((fOrg - f).Square() / fOrg.Square()) - det*det*0.1;
	REAL eval = ((fOrg - f).Square() / fOrg.Square()) + 0.2/ABS(det);	//11.20
	//	eval=�]���l:�ڕW�̗͂ɋ߂��Adet���傫�������ǂ�
	return eval;
	}

//----------------------------------------------------------------------
// Force generation for SPIDAR-8 
//
Vec3 CSpidar::SetForce(const Vec3& f)
{
/*	REAL omega[3];
	Vec3 phi[3];
	REAL tension[3];
	Vec3 colForce = f;
	int i;
	// initialize variables
	for (i=0; i<3; i++)
	{
		omega[i] = REAL(0.0);
		phi[i] = Vec3(0,0,0);
		tension[i] = REAL(0.0);
	}
	// calculate 3 position unit-vectors and their projection of force vector
	//
	//           phi[i]					                    
	//      o------>------------o
	//  realPos[0]			 motor[i].pos
	//
	// Step 1. projection of force vector on each string
	//	omega_i = proj(phi_i, colForce)	i=0,1,2	
	//	where omega_i = real value of projection
	//		  phi_i = position vector, direction from pointer to motor	  				
	//		  colForce = force vector 		

	for (i=0; i<3; i++)
	{
		phi[i] = (motor[i].pos - realPos[0]).Unit();
		omega[i] = (phi[i] * colForce);
	}
	
	// Step 1.0 sort omega descending
	int one, two, three;
	one = 0; two = 1; three = 2;
	SortThreeValues(omega[0], omega[1], omega[2], one, two, three);
	//TRACE("omega=%f %f %f %d,%d,%d \n", omega[0], omega[1], omega[2], one, two, three);

	// Step 1.1 consider omega1 <= 0
	if (omega[one] <= REAL(0.0))
	{
		for (i=0; i<3; i++)
		{
			tension[i] = REAL(0.0);
		}
		// goto Step 3. assigning tension values to 3 motors
	}
	// Step 1.2 in case that omega1 > 0 >= omega2
	//if ( (omega[one] > REAL(0.0)) && (omega[one] >= omega[two]) )
	if ( (omega[one] > REAL(0.0)) && (REAL(0.0) >= omega[two]) )
	{
		tension[one] = omega[one];
		tension[one] = (tension[one] < MAXTENSION) ? (tension[one]) : (MAXTENSION);
		tension[two] = REAL(0.0);
		tension[three] = REAL(0.0);
		// goto Step 3 assigning tension values to 3 motors
	}
	// Step 1.3 in case that omega2 > 0 >= omega3
	//if ( (omega[two] > REAL(0.0)) && (omega[two] >= omega[three]) )
	if ( (omega[two] > REAL(0.0)) && (REAL(0.0) >= omega[three]) )
	{
		tension[three] = REAL(0.0);
		// goto Step 2.1 using only 2 strings
		UseTwoStrings(phi[one], phi[two], colForce, tension[one], tension[two]);
		// goto Step 3 assigning tension values to 3 motors
	}
	// Step 1.4 in case that omega3 > 0
	if (omega[three] > REAL(0.0))
	{
		REAL t[3] = {0,0,0};
		// goto Step 2.2 using all 3 strings
		UseThreeStrings(phi, colForce, t);
		for (i=0; i<3; i++) tension[i] = t[i];
		// goto Step 3 assigning tension values to 3 motors
	}

	// Step 3. assigning tension values to 3 motors
	// initialize tension values, negative value is set to zero
	for(i=0; i<3; i++) 
		if (tension[i] < REAL(0.0)) tension[i] = REAL(0.0);

#if 0
	TRACE("%d %d %d tension=%3.3f %3.3f %3.3f ", one, two, three, tension[0], tension[1], tension[2]);
#endif

	Vec3 tense, u[3];
	for(i=0; i<3; i++)
	{
		if (i==one)
		{
			u[i] = phi[one];
			if (i==0) tense.x = tension[one];
			if (i==1) tense.y = tension[one];
			if (i==2) tense.z = tension[one];
		}
		if (i==two)
		{
			u[i] = phi[two];
			if (i==0) tense.x = tension[two];
			if (i==1) tense.y = tension[two];
			if (i==2) tense.z = tension[two];
		}
		if (i==three)
		{
			u[i] = phi[three];
			if (i==0) tense.x = tension[three];
			if (i==1) tense.y = tension[three];
			if (i==2) tense.z = tension[three];
		}
	}
	REAL minF = tense.Size() * 0.2;
	motor[0].Force(tense.x + MAX(motor[0].MinForce(), minF));
	motor[1].Force(tense.y + MAX(motor[1].MinForce(), minF));
	motor[2].Force(tense.z + MAX(motor[2].MinForce(), minF));

#if 0
	// without force projection, incorrect tensions are resulted
	CMatrix3 mpos = CMatrix3(phi[0], phi[1], phi[2]);
	Vec3 xt = mpos.Inv() * colForce;
	Vec3 xf = mpos * xt; 
#endif
	// spidar display forces using force projection
	CMatrix3 mat3Pos = CMatrix3(u[0], u[1], u[2]);
	spForce = mat3Pos * tense;
#if 0
	if (channel == 0) TRACE("col=%2.3f %2.3f %2.3f sp= %2.3f %2.3f %2.3f t=%2.3f %2.3f %2.3f xt=%2.3f %2.3f %2.3f xf=%2.3f %2.3f %2.3f \n", 
		colForce.x, colForce.y, colForce.z,	spForce.x, spForce.y, spForce.z, tense.x, tense.y, tense.z, xt.x, xt.y, xt.z, xf.x, xf.y, xf.z);
#endif
#if 0
	if (channel == 0) TRACE("mx=%2.3f %2.3f %2.3f my= %2.3f %2.3f %2.3f mz=%2.3f %2.3f %2.3f ux=%2.3f %2.3f %2.3f uy=%2.3f %2.3f %2.3f uz=%2.3f %2.3f %2.3f ", 
		phi[0].x, phi[0].y, phi[0].z, phi[1].x, phi[1].y, phi[1].z, phi[2].x, phi[2].y, phi[2].z, 
		u[0].x, u[0].y, u[0].z, u[1].x, u[1].y, u[1].z, u[2].x, u[2].y, u[2].z);		
#endif	
*/
//yo edit
	int i;
	Vec3 v3Str[4];							//	�|�C���^���猩�����̌����̒P�ʃx�N�g��
	for (i=0; i<4; i++) v3Str[i] = (motor[i].pos-realPos[0]).Unit();
	REAL minErr = 1E20f;
	int minDisable = 0;
	static int lastDisable;
	Vec3 avf[4];
	for (i=0; i<4; i++)
		{
		avf[i] = f;
		REAL err = AvailableForce(i, avf[i], v3Str);
//		if (i==lastDisable)	err -= 0.4f;
		if (err < minErr)
			{
			minErr = err;
			minDisable = i;
			}
		}
	lastDisable = minDisable;
	int sel[3];
	for(i=0; i<3; i++) sel[i] = (minDisable+1+i)%4;
	Vec3 force = avf[minDisable];
	CMatrix3 matF = CMatrix3(v3Str[sel[0]], v3Str[sel[1]], v3Str[sel[2]]);
	Vec3 v3Tension = matF.Inv() * force;
	REAL tension[4];
	tension[sel[0]] = v3Tension.x;
	tension[sel[1]] = v3Tension.y;
	tension[sel[2]] = v3Tension.z;
	tension[minDisable] = 0;
	//	���[�^�ɏo�̓g���N��ݒ肷��
	for(i=0; i<4; i++)
		motor[i].Force(tension[i]+motor[i].MinForce());

	return spForce;
}

// Step 2.1 using 2 strings
void CSpidar::UseTwoStrings(Vec3 ph1, Vec3 ph2, Vec3 f, REAL &tens1, REAL &tens2)
{

	REAL v2_x = ph1 * f;
	REAL v2_y = ph2 * f;
	CD3DVec2 v2omega = CD3DVec2(v2_x, v2_y);
	
	REAL ex_x = 1;
	REAL ey_x = ph1 * ph2;
	REAL ex_y = ey_x;
	REAL ey_y = 1;

	CMatrix2 mat2A = CMatrix2(ex_x, ey_x, ex_y, ey_y);
	CD3DVec2 t = mat2A.Inv() * v2omega;

	REAL tout1[2];
	tout1[0] = t.x;
	tout1[1] = t.y;

	// sort descendingly values of tout1[0] and tout1[1]
	int one, two;
	one = 0; two = 1;
	if (tout1[0] > tout1[1])
	{
		one = 0;
		two = 1;
	}
	else
	{
		one = 1;
		two = 0;
	}

	// Step 2.1.1 in case that tout1_1 > 0 >= tout1_2
	if ( (tout1[one] > REAL(0.0)) && (REAL(0.0) >= tout1[two]) )
	//if ( (tout1[one] > REAL(0.0)) && (tout1[one] >= tout1[two]) )
	{
		if (one == 0) tens1 = ph1 * f;
		else tens1 = ph2 * f;
		tens1 = (tens1 < MAXTENSION) ? (tens1) : (MAXTENSION);
		tens2 = REAL(0.0);
		// return to SetForce
		return;
	}
	// Step 2.1.2 in case that tout1_1 > tout1_2 > 0
	if ( (tout1[one] > tout1[two]) && (tout1[two] > REAL(0.0)) )
	{
		if (one == 0) 
		{
			tens1 = ph1 * f;
			tens2 = ph2 * f;
		}
		else 
		{
			tens1 = ph2 * f;
			tens2 = ph1 * f;
		}
		tens1 = MinThreeValues(tout1[one], tens1, MAXTENSION);
		tens2 = MinThreeValues(tout1[two], tens2, MAXTENSION);
		// return to SetForce
		return;
	}
	// return to SetForce
	return;
}

// Step 2.2 using 3 strings
void CSpidar::UseThreeStrings(Vec3 *ph, Vec3 f, REAL *tens)
{
	// tout = (A_trans*A)Inv * (A_trans*f)
	CMatrix3 mat3A = CMatrix3(ph[0], ph[1], ph[2]);
	CMatrix3 ATAInv = (mat3A.Trans() * mat3A).Inv();
	Vec3 t1 = ATAInv * (mat3A.Trans() * f);
	
	REAL tout1[3];
	tout1[0] = t1.x;
	tout1[1] = t1.y;
	tout1[2] = t1.z;
	
	// sort descendingly values of tout1[0], tout1[1], and tout1[2]
	int one, two, three;
	one = 0; two = 1; three = 2;
	SortThreeValues(tout1[0], tout1[1], tout1[2], one, two, three);

	// Step 2.2.1 in case that tout1_1 > 0 >= tout1_2
	if ( (tout1[one] > REAL(0.0)) && (REAL(0.0) >= tout1[two]) )
	//if ( (tout1[one] > REAL(0.0)) && (tout1[one] >= tout1[two]) )
	{
		REAL t = ph[one] * f;
		tens[one] = (t < MAXTENSION) ? (t) : (MAXTENSION);
		tens[two] = REAL(0.0);
		tens[three] = REAL(0.0);
		// return to SetForce
		return;
	}
	// Step 2.2.2 in case that tout1_2 > 0 >= tout1_3
	if ( (tout1[two] > REAL(0.0)) && (REAL(0.0) >= tout1[three]) )
	//if ( (tout1[two] > REAL(0.0)) && (tout1[two] >= tout1[three]) )
	{
		tens[three] = REAL(0.0);
		UseTwoStrings(ph[one], ph[two], f, tens[one], tens[two]);
		// return to SetForce
		return;
	}
	// Step 2.2.3 in case that tout1_3 > 0
	if (tout1[three] > REAL(0.0))
	{
		tens[one] = ph[one] * f;
		tens[one] = MinThreeValues(tens[one], tout1[one], MAXTENSION);
		tens[two] = ph[two] * f;
		tens[two] = MinThreeValues(tens[two], tout1[two], MAXTENSION);
		tens[three] = ph[three] * f;
		tens[three] = MinThreeValues(tens[three], tout1[three], MAXTENSION);
		// return to SetForce;
		return;	
	}
	// return to SetForce
	return;
}

REAL CSpidar::MinThreeValues(REAL a, REAL b, REAL c)
{
	REAL temp = (a < b) ? (a) : (b);
	return ((temp < c) ? (temp) : (c));
}

// Sort descending three values while keeping initial order (a b c)
// for example: 5 8 4 initial order 0 1 2, after sorted 8 5 4 order 1 0 2 
void CSpidar::SortThreeValues(REAL val1, REAL val2, REAL val3, int &a, int &b, int &c)
{
	REAL num[3], max;
	num[0] = val1; 
	num[1] = val2;
	num[2] = val3;
	int temp;
	for (int i=0; i<3; i++)
	{
		max = num[i];
		
		for (int j=i+1; j<3; j++)
		{
			if (max < num[j])
			{
				max = num[j];
				num[j] = num[i];
				num[i] = max;
				if (i==0 && j==1) { temp=a; a=b; b=temp;}
				if (i==0 && j==2) { temp=a; a=c; c=temp;}
				if (i==1 && j==2) { temp=b; b=c; c=temp;}
			}
		}
	}
	return;
}

void CSpidar::InitMat()
	{
	matPos = 2*CMatrix3(
					motor[1].pos-motor[0].pos,
					motor[2].pos-motor[1].pos,
					motor[3].pos-motor[2].pos).Trans();
	matPos = matPos.Inv();

	posSqrConst = Vec3(	motor[1].pos.Square()-motor[0].pos.Square(),
						motor[2].pos.Square()-motor[1].pos.Square(),
						motor[3].pos.Square()-motor[2].pos.Square());
	}

//
// End of force generation
//----------------------------------------------------------------------
