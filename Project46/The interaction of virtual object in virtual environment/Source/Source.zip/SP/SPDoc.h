// SPDoc.h : interface of the CSPDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPDOC_H__29AE3ECB_76AB_11D8_9580_00B0D01A56F6__INCLUDED_)
#define AFX_SPDOC_H__29AE3ECB_76AB_11D8_9580_00B0D01A56F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSPDoc : public CDocument
{
protected: // create from serialization only
	CSPDoc();
	DECLARE_DYNCREATE(CSPDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSPDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSPDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPDOC_H__29AE3ECB_76AB_11D8_9580_00B0D01A56F6__INCLUDED_)
