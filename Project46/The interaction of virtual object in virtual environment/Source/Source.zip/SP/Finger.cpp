// Finger.cpp: implementation of the CFinger class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SP.h"
#include "Finger.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFinger::CFinger()
{
	tempPos = CD3DVec3();
	L0 = REAL(0);
	L1 = REAL(0);
	L2 = REAL(0);
}

CFinger::~CFinger()
{
}

void CFinger::Init(int i)
{
	force = CD3DVec3();
	torque = CD3DVec3();
	diff = CD3DVec3();
	prop = CD3DVec3();
	realPos = CD3DVec3();
	virtualPos = CD3DVec3();

	strcpy(collideTo, "NONE");
	
	dev.Init(i);
}
