// ColSphere.cpp: implementation of the CColSphere class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SP.h"
#include "ColSphere.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define FRICTION REAL(0.98)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CColSphere::CColSphere()
{
	bAllowRotate = true;
	bAllowTranslate = true;
}

CColSphere::~CColSphere()
{
}

void CColSphere::Init()
{
	REAL rr = radius * radius;
	REAL mulConst = 1.0f;
	CD3DVec3 ex = 0.4f * mass * CD3DVec3(rr, 0, 0) * mulConst;
	CD3DVec3 ey = 0.4f * mass * CD3DVec3(0, rr, 0) * mulConst;
	CD3DVec3 ez = 0.4f * mass * CD3DVec3(0, 0, rr) * mulConst;
	inertia = CMatrix3(ex, ey, ez);

	force = CD3DVec3();
	torque = CD3DVec3();
	vel = CD3DVec3();
	linearMom = CD3DVec3();
	angVel = CD3DVec3();
	angMom = CD3DVec3();
	bGrasp = false;
}

void CColSphere::CheckCollision(CFinger* finger)
{
	bool bCollisionNow = false;

	for (int i=0; i<NFINGER; i++)
	{
		// finger position in sphere's coordinate system
		CD3DVec3 rPos = afSph.Inv() * finger[i].realPos;

		if (rPos.Size() <= radius)
		{
			bCollisionNow = true;
		}
		else
		{
			bCollisionNow = false;
		}

		CD3DVec3 colPosNow;
		colPosNow = radius * rPos.Unit();
		 
		if (colPos[i] == CD3DVec3()) // no previous collision
		{
			if (bCollisionNow) // no previous collision but now colliding
			{
				// preserve collision position and face 
				colPos[i] = colPosNow;
				strcpy(finger[i].collideTo, frame.Name());
			}
			else // no previous collision and no collidision now
			{
				// reset collision position and face 
				colPos[i] = CD3DVec3();
				if (strcmp(finger[i].collideTo, frame.Name()) == 0)
				{
					strcpy(finger[i].collideTo, "NONE");
				}
			}
		}
		else // has previous collision
		{
			if (bCollisionNow) // has previous collision and now colliding
			{
				// consider friction
				REAL depth = radius - rPos.Size();
				CD3DVec3 newColPos = radius * rPos.Unit();
				CD3DVec3 tangent = newColPos - colPos[i];
				CD3DVec3 slip;
				if (tangent.Size() > FRICTION * depth) // with friction
				{
					slip = (tangent.Size() - (FRICTION * depth)) * tangent.Unit();
				}
				else // without friction
				{
					slip = CD3DVec3();
				}
				colPos[i] = colPos[i] + slip;
			}
			else // has previous collision but no collision now
			{
				colPos[i] = CD3DVec3();
				if (strcmp(finger[i].collideTo, frame.Name()) == 0)
				{
					strcpy(finger[i].collideTo, "NONE");
				}
			}
		}
	}
}

void CColSphere::AddForce(CD3DVec3 d, CD3DVec3 f)
{
	force += f;
	torque += d ^ f;
}

void CColSphere::ClearForce()
{
	// clear force and torque
	force = CD3DVec3();
	torque = CD3DVec3();
	// clear momentum
	linearMom = CD3DVec3();
	angMom = CD3DVec3();
	// clear velocity
//	vel = CD3DVec3();
//	angVel = CD3DVec3();
}

void CColSphere::ResolveCollision(REAL dt)
{
	// linear momentum; d/dt P(t) = F(t)
	CD3DVec3 P = force * dt;
	linearMom += P;

	// velocity; d/dt v(t) = d/dt P(t) / mass
	CD3DVec3 v = linearMom / mass;
	vel += v;

	// angular moment; d/dt L(t) = torque(t)
	CD3DVec3 L = torque * dt;
	angMom += L;

	// rotation matrix = affine of object
	CMatrix3 R = afSph;
	// inertia tensor; I(t) = R(t) * I_obj * R(t)_transpose
	// since, R(t)_transpose = R(t)_inv
	CMatrix3 I = R * inertia * R.Inv();
		
	// angular velocity; w(t) = I(t)_inv * L(t)
	angVel = I.Inv() * angMom;
}

void CColSphere::UpdateMotion(REAL dt)
{
	// translation
	if (bAllowTranslate) afSph.Pos(afSph.Pos() + vel * dt);

	// rotation
	CD3DAffine afRot;
	if (bAllowRotate) afRot.InitRot(angVel.Size() * dt, angVel.Unit());
	afSph = afRot.Rot(afSph);

	frame.AfWorld(afSph);
}