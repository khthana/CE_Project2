// SPDoc.cpp : implementation of the CSPDoc class
//

#include "stdafx.h"
#include "SP.h"

#include "SPDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSPDoc

IMPLEMENT_DYNCREATE(CSPDoc, CDocument)

BEGIN_MESSAGE_MAP(CSPDoc, CDocument)
	//{{AFX_MSG_MAP(CSPDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPDoc construction/destruction

CSPDoc::CSPDoc()
{
	// TODO: add one-time construction code here

}

CSPDoc::~CSPDoc()
{
}

BOOL CSPDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSPDoc serialization

void CSPDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSPDoc diagnostics

#ifdef _DEBUG
void CSPDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSPDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSPDoc commands
