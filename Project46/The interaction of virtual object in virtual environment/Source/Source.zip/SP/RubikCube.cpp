// RubikCube.cpp: implementation of the CRubikCube class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SP.h"
#include "RubikCube.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRubikCube::CRubikCube()
{
}

CRubikCube::~CRubikCube()
{
}

void CRubikCube::Init(int n)
{
	afBoxDyna = CD3DAffine();
	afBoxVisInit = CD3DAffine();

	afBoxVisInit *= 0.06f;
	afBoxVisInit.Ex(afBoxVisInit.Ex().Unit() * (0.03f + 0.001f));
	if (n == 0) afBoxVisInit.Pos(-0.03f + 0.001f);
	else afBoxVisInit.Pos(0.03f - 0.001f);

	mass = 1.0f;
	REAL xx = 0.06f * 0.06f;
	REAL yy = 0.12f * 0.12f;
	REAL zz = 0.12f * 0.12f;
	REAL mulConst = 1.0f;
	CD3DVec3 ex = mass / 12.0f * CD3DVec3(yy+zz, 0, 0) * mulConst;
	CD3DVec3 ey = mass / 12.0f * CD3DVec3(0, xx+zz, 0) * mulConst;
	CD3DVec3 ez = mass / 12.0f * CD3DVec3(0, 0, xx+yy) * mulConst;
	inertia = CMatrix3(ex, ey, ez);

	torque = CD3DVec3(0,0,0);
	vel = CD3DVec3(0,0,0);
	angVel = CD3DVec3(0,0,0);
	angMom = CD3DVec3(0,0,0);
}

void CRubikCube::Collision(CFinger* finger)
{
	afBoxVis = afBoxDyna * afBoxVisInit;
	torque = CD3DVec3(0,0,0);
	int i;
	for (i=0; i<NFINGER; i++) {
		int colBoxSide = 0;
		CD3DVec3 bP = afBoxVis.Inv() * finger[i].dev.RPos();
		if ((bP.x > 0) && (bP.x < 1) && (bP.x > ABS(bP.y)) && (bP.x > ABS(bP.z))) {
			colBoxSide = 1;
		}
		else if ((bP.y > 0) && (bP.y < 1) && (bP.y > ABS(bP.x)) && (bP.y > ABS(bP.z))) {
			colBoxSide = 2;
		}
		else if ((bP.z > 0) && (bP.z < 1) && (bP.z > ABS(bP.x)) && (bP.z > ABS(bP.y))) {
			colBoxSide = 3;
		}
		else if ((bP.x < 0) && (bP.x > -1) && (-bP.x > ABS(bP.y)) && (-bP.x > ABS(bP.z))) {
			colBoxSide = 4;
		}
		else if ((bP.y < 0) && (bP.y > -1) && (-bP.y > ABS(bP.x)) && (-bP.y > ABS(bP.z))) {
			colBoxSide = 5;
		}
		else if ((bP.z < 0) && (bP.z > -1) && (-bP.z > ABS(bP.x)) && (-bP.z > ABS(bP.y))) {
			colBoxSide = 6;
		}
		else {
			colBoxSide = 0;
		}
		bool bContactNow = false;
		if (lastColBoxSide[i] == 0) {
			lastColBoxSide[i] = colBoxSide;
			bContactNow = true;
		}
		if (colBoxSide == 0) {
			lastColBoxSide[i] = 0;
		}
		CD3DVec3 colPos;
		switch (lastColBoxSide[i]) {
		case 1: // +X
			colPos = CD3DVec3(1, bP.y, bP.z);
			n = CD3DVec3(1,0,0);
			break;
		case 2: // +Y
			colPos = CD3DVec3(bP.x, 1, bP.z);
			n = CD3DVec3(0,1,0);
			break;
		case 3: // +Z
			colPos = CD3DVec3(bP.x, bP.y, 1);
			n = CD3DVec3(0,0,1);
			break;
		case 4: // -X
			colPos = CD3DVec3(-1, bP.y, bP.z);
			n = CD3DVec3(-1,0,0);
			break;
		case 5: // -Y
			colPos = CD3DVec3(bP.x, -1, bP.z);
			n = CD3DVec3(0,-1,0);
			break;
		case 6: // -Z
			colPos = CD3DVec3(bP.x, bP.y, -1);
			n = CD3DVec3(0,0,-1);
			break;
		default: // no collision
			colPos = CD3DVec3(0,0,0);
			break;
		}
		if (bContactNow) {
			lastColPos[i] = colPos;
		}
		CD3DVec3 dist = bP - lastColPos[i];
		CD3DVec3 R = dist - (dist * n) * n;
		if (colPos != CD3DVec3(0,0,0) &&  R.Size() >= - MOVE_FRICTION * (dist * n)) {
			lastColPos[i] = lastColPos[i] + (R - R.Unit() * MOVE_FRICTION * (-dist * n));
		}

		CD3DVec3 wRealPos, wProxyPos, wForce;
		if (lastColBoxSide[i] == 0) {
			wProxyPos = CD3DVec3(0,0,0);
			wForce = CD3DVec3(0,0,0);
			finger[i].virtualPos = afBoxVis * bP;
		}
		else {
			wRealPos = afBoxVis * bP;
			wProxyPos = afBoxVis * lastColPos[i];
			wForce = (wProxyPos - wRealPos) * 400.0f;
			finger[i].virtualPos = wProxyPos;
		}
		torque += wProxyPos ^ (-wForce);
		finger[i].force += wForce;
	}
}
