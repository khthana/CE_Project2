xof 0302txt 0064
// LWS2X generated file 
// (LWS2X (C)1996,1997 A.Koizuka/Bio_100%  mail:koizuka@ss.iij4u.or.jp )
// http://www.ss.iij4u.or.jp/~koizuka/

template Header {
 <3D82AB43-62DA-11cf-AB39-0020AF71E433>
 WORD major;
 WORD minor;
 DWORD flags;
}

template Vector {
 <3D82AB5E-62DA-11cf-AB39-0020AF71E433>
 FLOAT x;
 FLOAT y;
 FLOAT z;
}

template Coords2d {
 <F6F23F44-7686-11cf-8F52-0040333594A3>
 FLOAT u;
 FLOAT v;
}

template Matrix4x4 {
 <F6F23F45-7686-11cf-8F52-0040333594A3>
 array FLOAT matrix[16];
}

template ColorRGBA {
 <35FF44E0-6C7C-11cf-8F52-0040333594A3>
 FLOAT red;
 FLOAT green;
 FLOAT blue;
 FLOAT alpha;
}

template ColorRGB {
 <D3E16E81-7835-11cf-8F52-0040333594A3>
 FLOAT red;
 FLOAT green;
 FLOAT blue;
}

template IndexedColor {
 <1630B820-7842-11cf-8F52-0040333594A3>
 DWORD index;
 ColorRGBA indexColor;
}

template Boolean {
 <4885AE61-78E8-11cf-8F52-0040333594A3>
 WORD truefalse;
}

template Boolean2d {
 <4885AE63-78E8-11cf-8F52-0040333594A3>
 Boolean u;
 Boolean v;
}

template MaterialWrap {
 <4885AE60-78E8-11cf-8F52-0040333594A3>
 Boolean u;
 Boolean v;
}

template TextureFilename {
 <A42790E1-7810-11cf-8F52-0040333594A3>
 STRING filename;
}

template Material {
 <3D82AB4D-62DA-11cf-AB39-0020AF71E433>
 ColorRGBA faceColor;
 FLOAT power;
 ColorRGB specularColor;
 ColorRGB emissiveColor;
 [...]
}

template MeshFace {
 <3D82AB5F-62DA-11cf-AB39-0020AF71E433>
 DWORD nFaceVertexIndices;
 array DWORD faceVertexIndices[nFaceVertexIndices];
}

template MeshFaceWraps {
 <4885AE62-78E8-11cf-8F52-0040333594A3>
 DWORD nFaceWrapValues;
 Boolean2d faceWrapValues;
}

template MeshTextureCoords {
 <F6F23F40-7686-11cf-8F52-0040333594A3>
 DWORD nTextureCoords;
 array Coords2d textureCoords[nTextureCoords];
}

template MeshMaterialList {
 <F6F23F42-7686-11cf-8F52-0040333594A3>
 DWORD nMaterials;
 DWORD nFaceIndexes;
 array DWORD faceIndexes[nFaceIndexes];
 [Material]
}

template MeshNormals {
 <F6F23F43-7686-11cf-8F52-0040333594A3>
 DWORD nNormals;
 array Vector normals[nNormals];
 DWORD nFaceNormals;
 array MeshFace faceNormals[nFaceNormals];
}

template MeshVertexColors {
 <1630B821-7842-11cf-8F52-0040333594A3>
 DWORD nVertexColors;
 array IndexedColor vertexColors[nVertexColors];
}

template Mesh {
 <3D82AB44-62DA-11cf-AB39-0020AF71E433>
 DWORD nVertices;
 array Vector vertices[nVertices];
 DWORD nFaces;
 array MeshFace faces[nFaces];
 [...]
}

template FrameTransformMatrix {
 <F6F23F41-7686-11cf-8F52-0040333594A3>
 Matrix4x4 frameMatrix;
}

template Frame {
 <3D82AB46-62DA-11cf-AB39-0020AF71E433>
 [...]
}

Header {
 1;
 0;
 1;
}

Material MatDefault {
 0.784314;0.784314;0.784314;1.000000;;
 21.333333;
 0.000000;0.000000;0.000000;;
 0.000000;0.000000;0.000000;;
}

Mesh {
  42;
  0.000000;1.000000;0.000000;,
  0.000000;-1.000000;0.000000;,
  0.000000;0.447214;0.894427;,
  0.525731;-0.447214;0.723607;,
  0.850651;0.447214;0.276393;,
  0.850651;-0.447214;-0.276393;,
  0.525731;0.447214;-0.723607;,
  0.000000;-0.447214;-0.894427;,
  -0.525731;0.447214;-0.723607;,
  -0.850651;-0.447214;-0.276393;,
  -0.850651;0.447214;0.276393;,
  -0.525731;-0.447214;0.723607;,
  0.500000;0.850651;0.162460;,
  0.309017;0.850651;-0.425325;,
  -0.309017;0.850651;-0.425325;,
  0.000000;0.850651;0.525731;,
  -0.500000;0.850651;0.162460;,
  0.500000;-0.850651;-0.162460;,
  0.000000;-0.850651;-0.525731;,
  -0.500000;-0.850651;-0.162460;,
  -0.309017;-0.850651;0.425325;,
  0.309017;-0.850651;0.425325;,
  0.500000;0.525731;0.688191;,
  0.809017;0.525731;-0.262866;,
  0.000000;0.525731;-0.850651;,
  -0.809017;0.525731;-0.262866;,
  -0.500000;0.525731;0.688191;,
  0.809017;-0.525731;0.262866;,
  0.809017;0.000000;0.587785;,
  1.000000;0.000000;0.000000;,
  0.500000;-0.525731;-0.688191;,
  0.809017;0.000000;-0.587785;,
  0.309017;0.000000;-0.951057;,
  -0.500000;-0.525731;-0.688191;,
  -0.309017;0.000000;-0.951057;,
  -0.809017;0.000000;-0.587785;,
  -0.809017;-0.525731;0.262866;,
  -1.000000;0.000000;0.000000;,
  -0.809017;0.000000;0.587785;,
  0.000000;-0.525731;0.850651;,
  -0.309017;0.000000;0.951057;,
  0.309017;0.000000;0.951057;;

  80;
  3;15,22,12;,
  3;12,23,13;,
  3;13,24,14;,
  3;14,25,16;,
  3;16,26,15;,
  3;17,27,21;,
  3;18,30,17;,
  3;19,33,18;,
  3;20,36,19;,
  3;21,39,20;,
  3;41,28,22;,
  3;29,31,23;,
  3;32,34,24;,
  3;35,37,25;,
  3;38,40,26;,
  3;29,28,27;,
  3;32,31,30;,
  3;35,34,33;,
  3;38,37,36;,
  3;41,40,39;,
  3;3,41,39;,
  3;2,40,41;,
  3;11,39,40;,
  3;11,38,36;,
  3;10,37,38;,
  3;9,36,37;,
  3;9,35,33;,
  3;8,34,35;,
  3;7,33,34;,
  3;7,32,30;,
  3;6,31,32;,
  3;5,30,31;,
  3;5,29,27;,
  3;4,28,29;,
  3;3,27,28;,
  3;10,38,26;,
  3;11,40,38;,
  3;2,26,40;,
  3;8,35,25;,
  3;9,37,35;,
  3;10,25,37;,
  3;6,32,24;,
  3;7,34,32;,
  3;8,24,34;,
  3;4,29,23;,
  3;5,31,29;,
  3;6,23,31;,
  3;2,41,22;,
  3;3,28,41;,
  3;4,22,28;,
  3;1,21,20;,
  3;3,39,21;,
  3;11,20,39;,
  3;1,20,19;,
  3;11,36,20;,
  3;9,19,36;,
  3;1,19,18;,
  3;9,33,19;,
  3;7,18,33;,
  3;1,18,17;,
  3;7,30,18;,
  3;5,17,30;,
  3;1,17,21;,
  3;5,27,17;,
  3;3,21,27;,
  3;0,16,15;,
  3;10,26,16;,
  3;2,15,26;,
  3;0,14,16;,
  3;8,25,14;,
  3;10,16,25;,
  3;0,13,14;,
  3;6,24,13;,
  3;8,14,24;,
  3;0,12,13;,
  3;4,23,12;,
  3;6,13,23;,
  3;0,15,12;,
  3;2,22,15;,
  3;4,12,22;;

  MeshMaterialList {
   1;
   1;
   0;;
   {MatDefault}
  }
}
