// ColBox.h: interface for the CColBox class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COLBOX_H__9FBF5700_BB03_11D4_9288_C8A5EB533306__INCLUDED_)
#define AFX_COLBOX_H__9FBF5700_BB03_11D4_9288_C8A5EB533306__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "finger.h"

class CColBox  
{
public:
	int colFace[8];
	CD3DVec3 colPos[8];
	bool bGrasp;
	bool bAllowRotate;
	bool bAllowTranslate;

	CRMFrame frame;
	CD3DAffine afBox;

	// status
	CD3DVec3 linearMom;
	CD3DVec3 angMom;
	CD3DVec3 vel;
	CD3DVec3 angVel;

	// property
	REAL mass;
	CMatrix3 inertia;
	CD3DVec3 size;

	// work
	CD3DVec3 force;
	CD3DVec3 torque;

	void Init();
	void CheckCollision(CFinger* finger);
	void AddForce(CD3DVec3 d, CD3DVec3 f);
	void ResolveCollision(REAL dt);
	void ClearForce();
	void UpdateMotion(REAL dt);

	CColBox();
	virtual ~CColBox();
};

#endif // !defined(AFX_COLBOX_H__9FBF5700_BB03_11D4_9288_C8A5EB533306__INCLUDED_)
