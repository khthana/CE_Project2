#include "stdafx.h"
#include <conio.h>
#include "SpidarDriver.h"

CSpidarEncoder::CSpidarEncoder() 
{
	ctAddress=0;
	ctChannel=0;
	direction=0;
	lengthPerPulse=0;
}

void CSpidarEncoder::Set(int ctAdr, int ctCh, int dir, REAL lpp) 
{
	ctAddress=ctAdr;
	ctChannel=ctCh;
	direction=dir;
	lengthPerPulse=lpp;
}

//	�����_�ł̎��̒����� n �Ƃ��ď���������֐�
int CSpidarEncoder::Length(REAL n) 
{
//	return Count((long)(n/lengthPerPulse));
	return Count((long)((n - 0.0041617f) / 2.6218E-5f));
}

REAL CSpidarEncoder::Length() 
{
	long cnt=Count();
	if (cnt > 8388608L)
		cnt -= 16777216L;
//	return cnt*lengthPerPulse;
	return (0.0041617f + (2.6218E-5f * cnt));
}

//	counter�ɒl��������֐�
int CSpidarEncoder::Count(long n) 
{
	unsigned char low,middle,high;

	high   = (unsigned char)(n >>16);
	middle = (unsigned char)(n >>8 );
	low    = (unsigned char)n;

	_outp(ctAddress    , ctChannel*5 );						/* ���ۂɒl�������镔�� */
	_outp(ctAddress+0x1, low);								/* low    */
	_outp(ctAddress+0x1, middle);							/* middle */
	_outp(ctAddress+0x1, high);								/* high   */
	return 0;
}

//	�J�E���g�l��ǂފ֐�
//  Read counter value
long CSpidarEncoder::Count() 
{
	unsigned char low,middle,high;
	_outp(ctAddress    , 0x14  );							/* data latch */
	_outp(ctAddress+0x1, 0xf   );
	_outp(ctAddress    , ctChannel*5 );						/* read data */

	low    = (char)(_inp(ctAddress+0x1) & 0xff);			/* low    */
  	middle = (char)(_inp(ctAddress+0x1) & 0xff);			/* middle */
	high   = (char)(_inp(ctAddress+0x1) & 0xff);			/* high   */

	return ((long)(low+(middle<<8)+(high<<16)));
}

int CSpidarEncoder::Init() 
{
	/* operation command �͉����P.3-4�Q�� */
	_outp(ctAddress    , ctChannel*5+1);					/* mode set */
	_outp(ctAddress+0x1, 0x86+direction * 8);
	_outp(ctAddress    , ctChannel*5+2);					/* z-pulse invalidity */
	_outp(ctAddress+0x1, 0x2);								/* z-pulse ��p���Ȃ� */
	_outp(ctAddress    , 0x16);								/* sense reset */
	_outp(ctAddress+0x1, 0xff);
	return 0;
}

bool CSpidarEncoder::Exist()
{
	_outp(ctAddress, 0x15);
	int data = _inp(ctAddress+0x1);
	if (data == 0xFF) return false;
	else return true;
}

CSpidarMotor::CSpidarMotor()
{
	daAddress=0;
	daChannel=0;
	daValuePerNewton=0;
	minForce=0;
	maxForce=0;
}

CSpidarMotor::~CSpidarMotor()
{
	Force(minForce);
}

void CSpidarMotor::Set(int daAdr, int daCh, REAL voltPerNewton, REAL min, REAL max)
{
	daAddress=daAdr;
	daChannel=daCh;
	daValuePerNewton = voltPerNewton * DAvaluePerVolt;
	minForce=min;
	maxForce=max;
}

int CSpidarMotor::Force(REAL f)
{
	int retval;
	if (f>maxForce) 
	{
		f=maxForce;retval=0x100;
	} 
	else 
	{
		if (f<minForce) f=minForce;retval=0x200;
	}
	return DaOut((int)(f*daValuePerNewton))+retval;
}

int CSpidarMotor::Volt(REAL v)
{
	return DaOut((int)(v*DAvaluePerVolt));
}

int CSpidarMotor::DaOut(int value)
{
	// �ő�l�ŏ��l�͈̔͂𒴂��Ȃ��悤�ɂ���
	if ((unsigned short)0xfff < value) value = (unsigned short)0xfff;

	_outp(daAddress+0x0,(unsigned char)(daChannel + ((value << 4) & 0x0f0) ));
														// OUTPUT DATA (LOW)
	_outp(daAddress+0x1,(unsigned char)(value >> 4));		//	           (HIGH)
//	_outp(daAddress+0x2, 0x80);							// �����X�V�X�^�[�g
	return 0;
}

int CSpidarMotor::Init() 
{
	static BOOL IsInitialized=FALSE;
	if (IsInitialized==TRUE) return 1;
	IsInitialized=TRUE;
	_outp(daAddress+0x2,0x01);							/* range set mode �ɂ���*/
	_outp(daAddress+0x0,0x00);							/* channel 0 to 3 */
	_outp(daAddress+0x1,0x00);							/* range data set 0�`10[V]*/
	_outp(daAddress+0x0,0x04);							/* channel 4 to 7 */
	_outp(daAddress+0x1,0x00);							/* range data set 0�`10[V]*/
//	_outp(daAddress+0x2,0x02);							/* �����X�V���[�h*/
	_outp(daAddress+0x2,0x00);							/* �ʏ탂�[�h*/
	return 0;
}
