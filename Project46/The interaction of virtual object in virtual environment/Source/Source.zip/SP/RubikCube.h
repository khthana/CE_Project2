// RubikCube.h: interface for the CRubikCube class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RUBIKCUBE_H__A46F9380_14A6_11D5_A21C_00104B10589D__INCLUDED_)
#define AFX_RUBIKCUBE_H__A46F9380_14A6_11D5_A21C_00104B10589D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Finger.h"

//#define MOVE_FRICTION	0.8f
#define MOVE_FRICTION	2.0f

class CRubikCube  
{
public:
	CRMFrame frame;
	CD3DAffine afBoxVisInit;
	CD3DAffine afBoxVis;
	CD3DAffine afBoxDyna;
	CD3DVec3 torque;
	CD3DVec3 angMom;
	CD3DVec3 angVel;
	CMatrix3 inertia;
	REAL mass;
	CD3DVec3 vel;
	int lastColBoxSide[NFINGER];
	CD3DVec3 n;
	CD3DVec3 lastColPos[NFINGER];

	void Init(int n);
	void Collision(CFinger* finger);
	
	CRubikCube();
	virtual ~CRubikCube();
};

#endif // !defined(AFX_RUBIKCUBE_H__A46F9380_14A6_11D5_A21C_00104B10589D__INCLUDED_)
