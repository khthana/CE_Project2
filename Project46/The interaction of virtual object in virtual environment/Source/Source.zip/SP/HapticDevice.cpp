// HapticDevice.cpp: implementation of the CHapticDevice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SP.h"
#include "HapticDevice.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//--------------------------------------------------------------------
//	CHapticDevice
//
CHapticDevice::CHapticDevice():realPos(2, Vec3(0,0,0))
{
	Clear();
}

CHapticDevice::~CHapticDevice()
{
}

void CHapticDevice::Clear()
{
	realPos.Clear();
	emuPos = 0;
//	mode = FORCE;
	spForce = Vec3();
}

Vec3 CHapticDevice::GetPos()
{
	return emuPos;
}
/*
Vec3 CHapticDevice::VPos()
{
	return dest;
}
*/
Vec3 CHapticDevice::RPos()
{
	return realPos[0];
}
/*
void CHapticDevice::Pos(const Vec3& p)
{
	dest = p;
	mode = POS;
}
*/
Vec3 CHapticDevice::Force()
{
	return force;
}

void CHapticDevice::Force(const Vec3& f)
{
	force = f;
//	mode = FORCE;
	SetForce(force);
}

void CHapticDevice::Step()
{
	realPos.Add();
	realPos[0] = GetPos();
/*
	realPos[0] = afCalib * GetPos();
	Vec3& rPos = realPos[0];
	if (mode == FORCE) dest = realPos[0];
	else force = Vec3();
*/
}

