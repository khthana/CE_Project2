//
// SPView.cpp : implementation of the CSPView class
//
#include "stdafx.h"
#include "SP.h"

#include "SPDoc.h"
#include "SPView.h"

#include <string.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define HAPTIC_PERIOD	(1.0f/500.0f)
#define WORLD_PERIOD	(1.0f/30.0f)

#define PI	REAL(3.141592653589793)

//#define POINTER_RADIUS	REAL(0.01)
//#define SPHERE_RADIUS	REAL(0.05)
//#define BOX_SIZE		REAL(0.05)
//#define CYLINDER_RADIUS REAL(0.05)

#define NSPHERE 2
#define NBOX	1

#define K	REAL(450)
#define B	REAL(300)
#define KSTIFFNESS	REAL(1500)

#define SHOW_SURFSTRING			1
#define HI_RESOLUTION_MESH		0
#define LOW_RESOLUTION_MESH		1
#define WIREFRAME_MESH			0
#define CAST_SHADOW				1
//#define GRAVITY_ACTIVE		1
#define SHOW_AXIS				0
#define SHOW_ROTATION_ANGLE		1
#define SHOW_HIT_INDICATOR		1

CD3DVec3 CSPView::floorPos = CD3DVec3(0, -0.12f, 0);
CD3DVec3 CSPView::floorNormal = CD3DVec3(0, 1, 0);

CD3DAffine CSPView::afBox[] = {CD3DAffine(0.00f, 0, -0.10f), CD3DAffine(-0.12f, 0, 0)};
CD3DAffine CSPView::afSph[] = 
{ CD3DAffine(CD3DVec3( 1,0,0), CD3DVec3(0,1,0), CD3DVec3(-0.12f, 0, 0)), 
  CD3DAffine(CD3DVec3(-1,0,0), CD3DVec3(0,-1,0), CD3DVec3( 0.12f, 0, 0)) };

/////////////////////////////////////////////////////////////////////////////
// CSPView

IMPLEMENT_DYNCREATE(CSPView, CView)

BEGIN_MESSAGE_MAP(CSPView, CView)
	//{{AFX_MSG_MAP(CSPView)
//	ON_COMMAND(ID_OpenMesh, OnOpenMesh)
//	ON_COMMAND(ID_OpenLogPane, OnOpenLogPane)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
//	ON_COMMAND(ID_Connect, OnConnect)
//	ON_COMMAND(ID_ButtonConnect, OnButtonConnect)
	ON_COMMAND(ID_Box, OnBox)
	ON_COMMAND(ID_Sphere, OnSphere)
	ON_WM_KEYDOWN()
	ON_WM_SIZE()
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_WM_TIMER()
//	ON_UPDATE_COMMAND_UI(ID_FORCE, OnUpdateForce)
//	ON_COMMAND(ID_FORCE, OnForce)
//	ON_COMMAND(ID_BUTTON_GRAVITY, OnButtonGravity)
//	ON_COMMAND(ID_BUTTON_MMTIMER, OnButtonMmtimer)
//	ON_COMMAND(ID_BUTTON_THREAD, OnButtonThread)
//	ON_COMMAND(ID_Floor, OnFloor)
//	ON_UPDATE_COMMAND_UI(ID_Rotate, OnUpdateRotate)
//	ON_COMMAND(ID_Rotate, OnRotate)
//	ON_UPDATE_COMMAND_UI(ID_Translate, OnUpdateTranslate)
//	ON_COMMAND(ID_Translate, OnTranslate)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPView construction/destruction

CSPView::CSPView()
{
	// TODO: add construction code here
	Is_Connect = FALSE;
	bCalibrate = false;
//	calibID = 0;
//	bOffset = false;
	state = 'X';
	bRcube = false;
	bBox0 = false;
	bBox1 = false;
	bSphere0 = false;
	bSphere1 = false;
	fingerID = 0;
	dtoffset = 0;
	deltaTime = 0;
	start = 0;
	objID = 1;
	numObject = 0;
	hitface = 0;
	bDisplayForce = true;
	running = false;
	lapTime = 0;
	tick = 0;
	swap = 0;
	GRAVITY_ACTIVE = 0;
	bRotate = true;
	bTranslate = true;
	dataType = 4;
	bCheck = true;
}

CSPView::~CSPView()
{
	mmtimer.Release();
	if (file.is_open()) file.close();
}

BOOL CSPView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSPView drawing

void CSPView::OnDraw(CDC* pDC)
{
	CSPDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CSPView printing

BOOL CSPView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSPView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSPView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSPView diagnostics

#ifdef _DEBUG
void CSPView::AssertValid() const
{
	CView::AssertValid();
}

void CSPView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSPDoc* CSPView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSPDoc)));
	return (CSPDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSPView message handlers
void CSPView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	
	((CSPApp*)AfxGetApp())->view = this;

	// initialize SPIDAR
	for(int i=0; i<NFINGER; i++) 
	{
		finger[i].Init(i);
	}

	// Direct3D
	ddraws.HWnd(m_hWnd);
	surf.drivers.Set(2);
	surf.HWnd(m_hWnd);
	surf.Create();
	rm.Surf(surf);
	rm.Create();
	InitScene();	

/*
	//--------------------------------------------------
	// DirectSound
	dsound.HWnd(m_hWnd);
	dsound.Create();
//	int hWav[3];
	hWav[0] = dsound.waves.Load("sboom.wav");	// wave#1
	hWav[1] = dsound.waves.Load("sstop.wav");	// wave#2
	hWav[2] = dsound.waves.Load("sbounce.wav");	// wave#3 

	for (i=0; i<3; i++) {
		dsound.waves[hWav[i]]->MaxDist(20);
		dsound.waves[hWav[i]]->MinDist(1);
	}
	//dsound.waves[hWav[0]]->Play();
	//--------------------------------------------------
*/
	// multimedia timer
	mmtimer.Set(OnMMTimer, this);
	mmtimer.Resolution(HAPTIC_PERIOD*1000);
	mmtimer.Interval(HAPTIC_PERIOD*1000);
//	mmtimer.Thread();
	timerType = 0;

	ClearBuffer();
	ClearAllData();
//	SetTimer(1, 250, NULL);

	firstrun = true;

}

void CSPView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	surf.Release();
}

//----------------------------------------------------------------------
// Multimedia Timer
//
void CSPView::OnMMTimer(void* arg)
{
	CSPView* view = (CSPView*) arg;
	view->HapticStep();
}

void CSPView::HapticStep()
{
//	static int counter=0;
//	TRACE("\n%d ", counter++);

	int i;
	// get real positions of fingers
	for (i=0; i<NFINGER; i++) 
	{
		// SPIDAR measures fingertip positons
		finger[i].dev.Step();
		finger[i].realPos = finger[i].dev.RPos();

		if (strcmp(finger[i].collideTo, "NONE") == 0)
		{
			finger[i].virtualPos = finger[i].realPos;
		}
		finger[i].force = CD3DVec3();
		finger[i].torque = CD3DVec3();
	}
#if 1
	if (bBox0 || bBox1)
	{
//		CollisionBoxToBox(0, 1);
//		CollisionBoxToBox(1, 0);
		CollisionBoxToWall();

		for (i=0; i<NBOX; i++)
		{
			box[i].CheckCollision(finger);
		}
		// get virtual position of fingers
		for (i=0; i<NFINGER; i++)
		{
//			TRACE("%s ", finger[i].collideTo); 
			if (strcmp(finger[i].collideTo, "BOX0") == 0) 
			{
				finger[i].virtualPos = box[0].afBox * box[0].colPos[i];
			}
			if (strcmp(finger[i].collideTo, "BOX1") == 0) 
			{
				finger[i].virtualPos = box[1].afBox * box[1].colPos[i];
			}
		}
//		TRACE("\n");
	}
#endif

	if (bSphere0 || bSphere1)
	{
		CollisionSphereToSphere();
		CollisionSphereToWall();

		for (i=0; i<NSPHERE; i++)
		{
			sphere[i].CheckCollision(finger);
		}

		// get virtual position of fingers
		for (i=0; i<NFINGER; i++)
		{
//			TRACE("%s ", finger[i].collideTo);
			if (strcmp(finger[i].collideTo, "SPH0") == 0) 
			{
				finger[i].virtualPos = sphere[0].afSph * sphere[0].colPos[i];
			}
			if (strcmp(finger[i].collideTo, "SPH1") == 0) 
			{
				finger[i].virtualPos = sphere[1].afSph * sphere[1].colPos[i];
			}
		}
//		TRACE("\n");
	}

	// compute force 
	for (i=0; i<NFINGER; i++) 
	{
		if (!strcmp(finger[i].collideTo, "NONE") == 0)
		{
			CD3DVec3 d = finger[i].virtualPos - finger[i].realPos;
			finger[i].diff = d - finger[i].prop;
			finger[i].prop = d;
			CD3DVec3 forceNow = K * finger[i].prop + B * finger[i].diff;
			finger[i].force = forceNow;
		}
//		else 
//		{
//			finger[i].force = CD3DVec3();
//		}
		// set force to SPIDAR
		if (bDisplayForce) finger[i].dev.SetForce(finger[i].force);
	}

	if (bBox0 || bBox1)
	{
		for (i=0; i<NBOX; i++)
		{
			MotionBox(i);
		}
	}

	if (bSphere0 || bSphere1)
	{
		for (i=0; i<NSPHERE; i++)
		{
			MotionSphere(i);
		}
	}

	if ((bBox0 || bBox1) && (bSphere0 || bSphere1))
	{
		CollisionSphereToBox();
	}

#if 0
	TRACE("finger#%d force=%2.3f %2.3f %2.3f size=%f \n", fingerID,
		finger[fingerID].force.x, 
		finger[fingerID].force.y, 
		finger[fingerID].force.z, 
		finger[fingerID].force.Size());
#endif

//	if (bRcube) TwoBoxesMotion();
}

void CSPView::MotionSphere(int n)
{
	char sphName[8];
	if (n == 0) strcpy(sphName, "SPH0");
	if (n == 1) strcpy(sphName, "SPH1");
	int i;
	
	int numFingerGrasp = 0;
	for (i=0; i<NFINGER; i++)
	{
		if (strcmp(finger[i].collideTo, sphName) == 0)
		{
			numFingerGrasp += 1;
		}
	}
	// add forces to sphere
	for (i=0; i<NFINGER; i++)
	{
		if (strcmp(finger[i].collideTo, sphName) == 0)
		{
			sphere[n].AddForce(finger[i].virtualPos - sphere[n].afSph.Pos(),  -finger[i].force);
			finger[i].torque = (finger[i].virtualPos - sphere[n].afSph.Pos()) ^  -finger[i].force;
		}
//		else
//		{
//			finger[i].torque = CD3DVec3();
//		}
	}
	if (GRAVITY_ACTIVE)	
	{
		CD3DVec3 mg = sphere[n].mass * CD3DVec3(0, -9.8f, 0);
		sphere[n].AddForce(CD3DVec3(), mg);
	}
	sphere[n].ResolveCollision(deltaTime);
	sphere[n].UpdateMotion(deltaTime);

	// reduce speed and spin
	if (sphere[n].vel.Square() > 0) sphere[n].vel *= REAL(0.96); //REAL(0.97);
	if (sphere[n].angVel.Square() > 0) sphere[n].angVel *= REAL(0.97);

	// clear forces
	sphere[n].ClearForce();
}

void CSPView::MotionBox(int n)
{
	int i;
	char boxName[8];
	if (n == 0) strcpy(boxName, "BOX0");
	if (n == 1) strcpy(boxName, "BOX1");

#if 0 // to grasp, one finger is on one side and at least another on the opposite side  
	int numFingerGrasp = 0;
	for (i=0; i<NFINGER; i++)
	{
		if (strcmp(finger[i].collideTo, boxName) == 0)
		{
			numFingerGrasp += 1;
			CD3DVec3 f1 = (box[n].afBox.Inv() * finger[i].virtualPos).Unit();
			for (int j=i+1; j<NFINGER; j++)
			{
				if (strcmp(finger[j].collideTo, boxName) == 0)
				{
					CD3DVec3 f2 = box[n].afBox.Inv() * finger[j].virtualPos;
					if ((f2 * f1) < 0)
					{
						numFingerGrasp += 1;
					}
				}
			}
			break;
		}
	}
	// check whether is grasped
	if (numFingerGrasp >= 2) box[n].bGrasp = true;
	else box[n].bGrasp = false;
#endif

	// add forces that collided with fingers
	for (i=0; i<NFINGER; i++)
	{
		if (strcmp(finger[i].collideTo, boxName) == 0)
		{
			box[n].AddForce(finger[i].virtualPos - box[n].afBox.Pos(), -finger[i].force);
			finger[i].torque = (finger[i].virtualPos - box[n].afBox.Pos()) ^ -finger[i].force;
		}
//		else
//			finger[i].torque = CD3DVec3();
	}

	if (GRAVITY_ACTIVE)
	{
		CD3DVec3 mg = box[n].mass * CD3DVec3(0, -9.8f, 0);
		box[n].AddForce(CD3DVec3(), mg);
	}
//	if (box[n].bGrasp == true)
//	{
//		box[n].ResolveCollision(deltaTime);
//	}
	box[n].ResolveCollision(deltaTime);
	box[n].UpdateMotion(deltaTime);

	// reduce speed and spin
	if (box[n].vel.Square() > 0) box[n].vel *= REAL(0.95);
	if (box[n].angVel.Square() > 0) box[n].angVel *= REAL(0.97);

	// clear forces
	box[n].ClearForce();
}	


//-------------------------------------------------------------
// F = K * delta_x + B * dx/dt, dx/dt < 0, moving into the wall 
// F = K * delta_x,  dx/dt >= 0, moving away the wall

void CSPView::CollisionSphereToWall()
{
	struct WALL {
		CD3DVec3 pos;
		CD3DVec3 normal;
	}; 
	WALL wall[5];
	wall[0].pos = floorPos; // floor 
	wall[0].normal = floorNormal;
	wall[1].pos = CD3DVec3(-0.30f, 0, 0); // Left wall 
	wall[1].normal = CD3DVec3(1, 0, 0);
	wall[2].pos = CD3DVec3(0, 0, 0.30f); // Back wall 
	wall[2].normal = CD3DVec3(0, 0, -1);
	wall[3].pos = CD3DVec3(0.30f, 0, 0); // Right wall 
	wall[3].normal = CD3DVec3(-1, 0, 0);
	wall[4].pos = CD3DVec3(0, 0, -25.0f); // front wall 
	wall[4].normal = CD3DVec3(0, 0, 1);

	for (int i=0; i<NSPHERE; i++)
	{
		CD3DVec3 sphPos = sphere[i].afSph.Pos();
		for (int j=0; j<5; j++) // wall
		{
			REAL sphDist = (wall[j].pos.Size() - sphere[i].radius) - (sphPos * -wall[j].normal);
//			if (i==1 && j==0 ) wsw << sphDist << "\n";
			if (sphDist <= 0) 
			{
				// sphere is colliding with a wall
				CD3DVec3 force =  -sphDist * wall[j].normal * KSTIFFNESS;
				CD3DVec3 newSphPos = sphPos + (-sphDist * wall[j].normal);
				if (j == 0 && sphDist == 0)
				{
					force = sphere[i].mass * CD3DVec3(0, 9.8f, 0);
				}
				sphere[i].AddForce(newSphPos - sphPos, force);
				//dsound.waves[hWav[2]]->Play();
			}
		}
	}
}

void CSPView::CollisionSphereToSphere()
{
	CD3DVec3 pos0 = sphere[0].afSph.Pos();
	CD3DVec3 pos1 = sphere[1].afSph.Pos();

	REAL r0 = sphere[0].radius;
	REAL r1 = sphere[1].radius;

	CD3DVec3 dist = pos1 - pos0;
	REAL rr = r0 + r1;
	
	if (dist.Size() <= rr) 
	{
		// compute collision forces
		REAL overlap = rr - dist.Size();
		CD3DVec3 normal = dist.Unit();
		CD3DVec3 colForce = overlap * normal *  KSTIFFNESS;
	
		sphere[0].AddForce(CD3DVec3(), -colForce);
		sphere[1].AddForce(CD3DVec3(), colForce);
		//dsound.waves[hWav[0]]->Play();
		
#if 1 // check hitface
		CD3DVec3 cp0 = pos0 + r0 * normal;
		CD3DVec3 cp1 = pos1 + r1 * -normal;

		CD3DVec3 red0 = pos0 + r0 * sphere[0].afSph.Ex(); // center of red circle sph0
		CD3DVec3 red1 = pos1 + r1 * sphere[1].afSph.Ex(); // center of red circle sph1
		
		CD3DAffine aftemp01 = sphere[0].afSph * CD3DAffine(Rad(90), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 green0 = pos0 + r0 * aftemp01.Ey(); // center of green circle sph0
		CD3DAffine aftemp11 = sphere[1].afSph * CD3DAffine(Rad(90), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 green1 = pos1 + r1 * aftemp11.Ey(); // center of green circle sph1
		
		CD3DAffine aftemp02 = sphere[0].afSph * CD3DAffine(Rad(-30), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 blue0 = pos0 + r0 * aftemp02.Ey(); // center of blue circle sph0
		CD3DAffine aftemp12 = sphere[1].afSph * CD3DAffine(Rad(-30), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 blue1 = pos1 + r1 * aftemp12.Ey(); // center of blue circle sph1
		
		CD3DAffine aftemp03 = sphere[0].afSph * CD3DAffine(Rad(-150), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 yellow0 = pos0 + r0 * aftemp03.Ey(); // center of yellow circle sph0
		CD3DAffine aftemp13 = sphere[1].afSph * CD3DAffine(Rad(-150), 'x') * CD3DAffine(Rad(15), 'z');
		CD3DVec3 yellow1 = pos1 + r1 * aftemp13.Ey(); // center of yellow circle sph1

		REAL inp01 = (cp0 - red0) * -sphere[0].afSph.Ex();
		REAL inp02 = (cp0 - green0) * -aftemp01.Ey();
		REAL inp03 = (cp0 - blue0) * -aftemp02.Ey();
		REAL inp04 = (cp0 - yellow0) * -aftemp03.Ey();

		REAL inp11 = (cp1 - red1) * -sphere[1].afSph.Ex();
		REAL inp12 = (cp1 - green1) * -aftemp11.Ey();
		REAL inp13 = (cp1 - blue1) * -aftemp12.Ey();
		REAL inp14 = (cp1 - yellow1) * -aftemp13.Ey();

		REAL limit = 0.25f * rr * 0.342f; // 1/4 * diameter * cos(70)

		int hit0;
		if ((inp01 >= 0) && (inp01 <= limit))
			hit0 = 1;
		else 
			if ((inp02 >= 0) && (inp02 <= limit))
				hit0 = 2;
			else 
				if ((inp03 >= 0) && (inp03 <= limit))
					hit0 = 3;
				else 
					if ((inp04 >= 0) && (inp04 <= limit))
						hit0 = 4;
					else
						hit0 = 0;
		int hit1;
		if ((inp11 >= 0) && (inp11 <= limit))
			hit1 = 1;
		else 
			if ((inp12 >= 0) && (inp12 <= limit))
				hit1 = 2;
			else 
				if ((inp13 >= 0) && (inp13 <= limit))
					hit1 = 3;
				else 
					if ((inp14 >= 0) && (inp14 <= limit))
						hit1 = 4;
					else
						hit1 = 0;

		if ((hit0 == 1) && (hit1 == 1))
			hitface = 1;
		else
			if ((hit0 == 2) && (hit1 == 2))
				hitface = 2;
			else
				if ((hit0 == 3) && (hit1 == 3))
					hitface = 3;
				else
					if ((hit0 == 4) && (hit1 == 4))
						hitface = 4;
					else
						hitface = 0;
#endif // check hitface
	}

}

void CSPView::CollisionSphereToBox()
{
	for (int i=0; i<NBOX; i++) 
	{
		for (int j=0; j<NSPHERE; j++)
		{
			// position of sphere in box coordinate
			CD3DVec3 sphPos = box[i].afBox.Inv() * sphere[j].afSph.Pos();
			
			struct Face 
			{
				CD3DVec3 pos;
				CD3DVec3 normal;
			};
			Face face[7];

			REAL r = sphere[j].radius;
			CD3DVec3 halfBoxSize = box[i].size * 0.5f;
			CD3DVec3 lower = CD3DVec3(-halfBoxSize.x - r, -halfBoxSize.y - r, -halfBoxSize.x - r);
			CD3DVec3 upper = CD3DVec3( halfBoxSize.x + r,  halfBoxSize.y + r,  halfBoxSize.x + r);

			face[1].pos = upper;
			face[1].normal = CD3DVec3(1, 0, 0);
			face[2].pos = upper;
			face[2].normal = CD3DVec3(0, 1, 0);
			face[3].pos = upper;
			face[3].normal = CD3DVec3(0, 0, 1);
	
			face[4].pos = lower;
			face[4].normal = CD3DVec3(-1, 0, 0);
			face[5].pos = lower;
			face[5].normal = CD3DVec3(0, -1, 0);
			face[6].pos = lower;
			face[6].normal = CD3DVec3(0, 0, -1);

			REAL dist[7];
			for (int k=1; k<=6; k++)
			{
				// find distance from sphere to every faces of box
				dist[k] = (sphPos - face[k].pos) * face[k].normal;
			}
			int inside = 1;
			for (int m=1; m<=6; m++)
			{
				// if sphere is inside box, all dists must be negative
				int flag;
				if (dist[m] < 0) flag = 1;
				else flag = 0;
				inside &= flag;
			}
			int minID = 0;
			REAL minDist = -999.99f;

			if (inside == 1) // has collision
			{
				for (int n=1; n<=6; n++)
				{
					// find colliding face of box
					if (dist[n] > minDist)
					{
						minID = n;
						minDist = dist[minID];
					}
				}
				CD3DVec3 colPosOnBox;
				switch (minID)
				{
				case 1:
					colPosOnBox = CD3DVec3(halfBoxSize.x + r, sphPos.y, sphPos.z);
					break;
				case 2:
					colPosOnBox = CD3DVec3(sphPos.x, halfBoxSize.y + r, sphPos.z);
					break;
				case 3:
					colPosOnBox = CD3DVec3(sphPos.x, sphPos.y, halfBoxSize.z + r);
					break;
				case 4:
					colPosOnBox = CD3DVec3(-halfBoxSize.x - r, sphPos.y, sphPos.z);
					break;
				case 5:
					colPosOnBox = CD3DVec3(sphPos.x, -halfBoxSize.y - r, sphPos.z);
					break;
				case 6:
					colPosOnBox = CD3DVec3(sphPos.x, sphPos.y, -halfBoxSize.z - r);
					break;
				}

				CD3DVec3 colPos = box[i].afBox * colPosOnBox;
				CD3DVec3 colForce = (colPos - sphere[j].afSph.Pos()) *  KSTIFFNESS;
				
				box[i].AddForce((colPos - box[i].afBox.Pos()), -colForce);
				sphere[j].AddForce((colPos - sphere[j].afSph.Pos()), colForce);
			}
			switch (minID)
			{
			case 1:
				hitface = 0;
				break;
			case 2:
				hitface = 3;
				break;
			case 3:
				hitface = 4;
				break;
			case 4:
				hitface = 2;
				break;
			case 5:
				hitface = 0;
				break;
			case 6:
				hitface = 1;
				break;
			}
			//hitface = minID;
			hitface = 0; // now disable hit indicator
		}
	}
}

#define BOX_INDICATORS 0
void CSPView::HitIndicator()
{

	for (int i=0; i<6; i++)
	{
		meshIndicator[i].Load("sphere.x");
		meshIndicator[i].Scale(CD3DVec3(0.018f, 0.018f, 0.018f));

#if BOX_INDICATORS
		if (i == 0) meshIndicator[i].Set(D3DRGB(0, 0.2, 0)); // green
		if (i == 1) meshIndicator[i].Set(D3DRGB(0.2, 0, 0)); // red
		if (i == 2) meshIndicator[i].Set(D3DRGB(0, 0, 0.2)); // blue
		if (i == 3) meshIndicator[i].Set(D3DRGB(0.2, 0.2, 0)); // yellow
		if (i == 4) meshIndicator[i].Set(D3DRGB(0.2, 0, 0.2)); // violet
		if (i == 5) meshIndicator[i].Set(D3DRGB(0, 0.2, 0.2)); // sky 
#else // indicator for collision sphere
		if (i == 0) meshIndicator[i].Set(D3DRGB(0.2, 0, 0)); // red
		if (i == 1) meshIndicator[i].Set(D3DRGB(0, 0.2, 0)); // green
		if (i == 2) meshIndicator[i].Set(D3DRGB(0, 0.2, 0.2)); // blue
		if (i == 3) meshIndicator[i].Set(D3DRGB(0.2, 0.2, 0)); // yellow
		if (i == 4) meshIndicator[i].Set(D3DRGB(0, 0, 0)); // black
		if (i == 5) meshIndicator[i].Set(D3DRGB(0, 0, 0)); // black 
#endif	
		frIndicator[i].DelThis();
		frIndicator[i].AfParent(CD3DAffine(0.10f+i*0.05f, 0.10f, 0.30f));
		frIndicator[i].Add(meshIndicator[i]);
		rm.Scene().Add(frIndicator[i]);
	}
}

void CSPView::UpdateIndicator()
{

#if BOX_INDICATORS
	if (hitface == 0) return;
	switch (hitface)
	{
	case 1:
		meshIndicator[5].Set(D3DRGB(0, 1, 1));
		break;
	case 2:
		meshIndicator[2].Set(D3DRGB(0, 0, 1));
		break;
	case 3:
		meshIndicator[3].Set(D3DRGB(1, 1, 0));
		break;
	case 4:
		meshIndicator[0].Set(D3DRGB(0, 1, 0));
		break;
	case 5:
		meshIndicator[4].Set(D3DRGB(1, 0, 1));
		break;
	case 6:
		meshIndicator[1].Set(D3DRGB(1, 0, 0));
		break;
	}
#else 
	if (hitface == 0) return;
	switch (hitface)
	{
	case 1:
		meshIndicator[0].Set(D3DRGB(1, 0, 0));
		break;
	case 2:
		meshIndicator[1].Set(D3DRGB(0, 1, 0));
		break;
	case 3:
		meshIndicator[2].Set(D3DRGB(0, 0.4, 1));
		break;
	case 4:
		meshIndicator[3].Set(D3DRGB(1, 1, 0));
		break;
	case 5:
		meshIndicator[4].Set(D3DRGB(0, 0, 0));
		break;
	case 6:
		meshIndicator[5].Set(D3DRGB(0, 0, 0));
		break;
	}
#endif
}

void CSPView::ResetIndicator()
{
	for (int i=0; i<6; i++)
	{
#if BOX_INDICATORS
		if (i == 0) meshIndicator[i].Set(D3DRGB(0, 0.2, 0));
		if (i == 1) meshIndicator[i].Set(D3DRGB(0.2, 0, 0));
		if (i == 2) meshIndicator[i].Set(D3DRGB(0, 0, 0.2));
		if (i == 3) meshIndicator[i].Set(D3DRGB(0.2, 0.2, 0));
		if (i == 4) meshIndicator[i].Set(D3DRGB(0.2, 0, 0.2));
		if (i == 5) meshIndicator[i].Set(D3DRGB(0, 0.2, 0.2));
#else
		if (i == 0) meshIndicator[i].Set(D3DRGB(0.2, 0, 0)); // red
		if (i == 1) meshIndicator[i].Set(D3DRGB(0, 0.2, 0)); // green
		if (i == 2) meshIndicator[i].Set(D3DRGB(0, 0.2, 0.2)); // blue
		if (i == 3) meshIndicator[i].Set(D3DRGB(0.2, 0.2, 0)); // yellow
		if (i == 4) meshIndicator[i].Set(D3DRGB(0, 0, 0)); // not use
		if (i == 5) meshIndicator[i].Set(D3DRGB(0, 0, 0)); // not use 
#endif
	}
	hitface = 0;
}

void CSPView::CollisionBoxToWall()
{
	REAL EPSILON = 10E-5f;
	int i, j;
	for (i=0; i<NBOX; i++)
	{
		CD3DVec3 halfBox = box[i].size * 0.5f;
		CD3DVec3 vertex[9];
		vertex[0] = CD3DVec3(); // not use
		vertex[1] = CD3DVec3(-halfBox.x, -halfBox.y, -halfBox.z);
		vertex[2] = CD3DVec3(-halfBox.x, -halfBox.y,  halfBox.z);
		vertex[3] = CD3DVec3(-halfBox.x,  halfBox.y,  halfBox.z);
		vertex[4] = CD3DVec3(-halfBox.x,  halfBox.y, -halfBox.z);
		vertex[5] = CD3DVec3( halfBox.x, -halfBox.y, -halfBox.z);
		vertex[6] = CD3DVec3( halfBox.x, -halfBox.y,  halfBox.z);
		vertex[7] = CD3DVec3( halfBox.x,  halfBox.y,  halfBox.z);
		vertex[8] = CD3DVec3( halfBox.x,  halfBox.y, -halfBox.z);
		REAL dist[9];
		int numCol = 0;
		REAL sumDist = 0;
		CD3DVec3 sumVertex;
		// for each vertex
		for (j=1; j<=8; j++)
		{
			vertex[j] = box[i].afBox * vertex[j];
			dist[j] = (vertex[j] - floorPos) * -floorNormal;
			if (dist[j] >= 0)
			{
				numCol += 1;
				sumDist = sumDist + dist[j];
				sumVertex = sumVertex + vertex[j] * dist[j];
			}

		}
		CD3DVec3 avgVertex;
		if (numCol > 0)
		{
			if (sumDist > EPSILON)
			{
				avgVertex = sumVertex / sumDist;
			}
			else
			{
				sumVertex = CD3DVec3();
				for (j=1; j<=8; j++)
					if (dist[j] >= 0) sumVertex = sumVertex + vertex[j];
				avgVertex = sumVertex / numCol;
			}
			REAL overlap = (floorPos - avgVertex) * floorNormal;
			CD3DVec3 newPos = avgVertex + (overlap * floorNormal);
			CD3DVec3 colForce = overlap * floorNormal *  KSTIFFNESS;
			box[i].AddForce(newPos - box[i].afBox.Pos(), colForce);
		}
	}
}

void CSPView::CollisionBoxToBox(int src, int trg)
{
	int i, j, k;

	CD3DVec3 halfSource = box[src].size * 0.5f;

	CD3DVec3 vertex[9];
	vertex[0] = CD3DVec3(); // not use
	vertex[1] = CD3DVec3(-halfSource.x, -halfSource.y, -halfSource.z);
	vertex[2] = CD3DVec3(-halfSource.x, -halfSource.y,  halfSource.z);
	vertex[3] = CD3DVec3(-halfSource.x,  halfSource.y,  halfSource.z);
	vertex[4] = CD3DVec3(-halfSource.x,  halfSource.y, -halfSource.z);
	vertex[5] = CD3DVec3( halfSource.x, -halfSource.y, -halfSource.z);
	vertex[6] = CD3DVec3( halfSource.x, -halfSource.y,  halfSource.z);
	vertex[7] = CD3DVec3( halfSource.x,  halfSource.y,  halfSource.z);
	vertex[8] = CD3DVec3( halfSource.x,  halfSource.y, -halfSource.z);

	CD3DAffine afBoxSource, afBoxTarget;
	afBoxSource = box[src].afBox;
	afBoxTarget = box[trg].afBox;

	// information of target box
	CD3DVec3 halfTarget = box[trg].size * 0.5f;

	CD3DVec3 lower = CD3DVec3(-halfTarget.x, -halfTarget.y, -halfTarget.z);
	CD3DVec3 upper = CD3DVec3( halfTarget.x,  halfTarget.y,  halfTarget.z);
	struct Face {
		CD3DVec3 pos;
		CD3DVec3 normal;
	};
	Face face[7];
	face[0].pos = CD3DVec3(); // not use
	face[0].normal = CD3DVec3(); // not use
	face[1].pos = upper;
	face[1].normal = CD3DVec3(1, 0, 0);
	face[2].pos = upper;
	face[2].normal = CD3DVec3(0, 1, 0);
	face[3].pos = upper;
	face[3].normal = CD3DVec3(0, 0, 1);
	face[4].pos = lower;
	face[4].normal = CD3DVec3(-1, 0, 0);
	face[5].pos = lower;
	face[5].normal = CD3DVec3(0, -1, 0);
	face[6].pos = lower;
	face[6].normal = CD3DVec3(0, 0, -1);

	REAL dist[7]; dist[0] = 0;
	int faceID[9]; faceID[0] = 0;
	int vertexID[9]; vertexID[0] = 0;
	int numCol = 0;

	int flag;
	int inside, minID;
	REAL minDist;

	// for each vertex
	for (i=1; i<=8; i++)
	{
		vertexID[i] = 0;
		// vertices of source box in target box coordinate
		vertex[i] = afBoxSource * vertex[i];
		vertex[i] = afBoxTarget.Inv() * vertex[i];   

		faceID[i] = 0;
		// for each face
		for (j=1; j<=6; j++)
		{
			dist[j] = 0;
			dist[j] = (vertex[i] - face[j].pos) * face[j].normal;
		}
		inside = 1;
		for (j=1; j<=6; j++)
		{
			if (dist[j] <= 0) flag = 1;
			else flag = 0;

			inside = inside & flag;
		}
		//TRACE("%d ", inside);

		minDist = -10E5f;
		minID = 0;
		if (inside == 1)
		{
			// find colliding face of box
			for (k=1; k<=6; k++)
			{
				if (dist[k] > minDist)
				{
					minDist = dist[k];
					minID = k;
				}
			}
			numCol += 1;
			vertexID[numCol] = i;
			faceID[numCol] = minID;
		}
	}

	if (numCol == 0) return;
	
	CD3DVec3 sumVertex; 
	CD3DVec3 midVertex;
	for (i=1; i<=numCol; i++)
	{
		int n = vertexID[i];
		sumVertex = sumVertex + vertex[n];
		midVertex = sumVertex / numCol;
	}
	//TRACE("mid=%f,%f,%f size=%f ", midVertex.x, midVertex.y, midVertex.z, midVertex.Size());

	CD3DVec3 colPos;
	REAL depth = REAL(0.0);

	if (numCol == 1) // 1 vertex collide
	{
		int p = faceID[1];
		int q = vertexID[1];
		depth = ABS((vertex[q] - face[p].pos) * face[p].normal);
		colPos = vertex[q] + (depth * face[p].normal);
		//TRACE("collision=1 vertex=%d face=%d depth=%f ", q, p, depth);
	}
	else // 2, 3, or 4 vertices collided 
	{
		minDist = -10E5f;
		minID = 0;
		REAL mdist[6]; 
		// find collision face
		for (j=1; j<=6; j++)
		{
			mdist[j] = 0;
			mdist[j] = (midVertex - face[j].pos) * face[j].normal;
			if (mdist[k] > minDist)
			{
				minDist = mdist[k];
				minID = k;
			}
		}
		depth = ABS((midVertex - face[minID].pos) * face[minID].normal);
		colPos = midVertex + (depth * face[minID].normal);
		//TRACE("collision=2 face=%d depth=%f ", minID, depth);
	}
	//TRACE("col=%f,%f,%f \n", colPos.x, colPos.y, colPos.z);

	if ((numCol >= 1) && (numCol <= 4))
	{
		CD3DVec3 vertexPos = afBoxTarget * midVertex;
		colPos = afBoxTarget * colPos;

		CD3DVec3 colForce = (colPos - vertexPos) * KSTIFFNESS;

		box[trg].AddForce((colPos - box[trg].afBox.Pos()), -colForce);
		box[src].AddForce((colPos - box[src].afBox.Pos()),  colForce);
	}
}

#define ROTATE_BOX 0
#define ROTATE_SPH 1
void CSPView::GetRotationAngle()
{
	REAL pitch, yaw, roll;

#if ROTATE_BOX
	CD3DVec3 ezi = box[0].afBox.Ez();
	CD3DVec3 exi = box[0].afBox.Ex();
	pitch = Deg(atan2(ezi.y, ezi.x));
	yaw = Deg(atan2(exi.z, exi.x));
	roll = Deg(atan2(exi.y, exi.x));
#endif

#if ROTATE_SPH
	CD3DVec3 eyi = sphere[objID].afSph.Ey();
	CD3DVec3 exi = sphere[objID].afSph.Ex();
	pitch = Deg(atan2(eyi.z, eyi.y));
	yaw = Deg(atan2(exi.z, exi.x));
	roll = Deg(atan2(exi.y, exi.x));
	if (objID == 1) 
	{
		pitch = pitch + 180;
		yaw = yaw + 180;
		roll = roll + 180;
	}

	static int counter = 0;
	if (!file.is_open()) return;

	file << counter << " Sphere# " << objID << " Pitch= " << pitch << " Yaw= " << yaw << " Roll= " << roll;   
//	wsw  << counter << " Sphere# " << objID << " Pitch= " << pitch << " Yaw= " << yaw << " Roll= " << roll;   
	for (int i=0; i<NFINGER; i++)
	{
		CD3DVec3 p = finger[i].realPos;
		CD3DVec3 f = finger[i].force;
		CD3DVec3 t = finger[i].torque;
		CD3DVec3 sf = finger[i].dev.spForce;

		file << " [" << i << "]" 
			<< " P= " << p.x << " " << p.y << " " << p.z 
			<< " F= " << f.x << " " << f.y << " " << f.z 
			<< " T= " << t.x << " " << t.y << " " << t.z 
			<< " SF= " << sf.x << " " << sf.y << " " << sf.z; 
/*
		wsw  << " [" << i << "]" 
			<< " P= " << p.x << " " << p.y << " " << p.z 
			<< " F= " << f.x << " " << f.y << " " << f.z 
			<< " T= " << t.x << " " << t.y << " " << t.z  
			<< " SF= " << sf.x << " " << sf.y << " " << sf.z; 
*/
	}
	file << "\n";
//	wsw << "\n";
	counter++;
#endif
}

void CSPView::InitScene()
{
	rm.Scene(CRMFrame());
	rm.ViewFrustum(CRMViewFrustum(REAL(0.05), 0));
	CD3DAffine afCam(REAL(0.0), REAL(0.12), REAL(-0.5));	//(0, 0.5,-0.5)
	afCam = afCam.LookAt(CD3DVec3(0,0,0));
	rm.Camera().AfParent(afCam);
	CRMFrame frLight;
	frLight.AfParent(CD3DAffine(0.6f,2.5f,-2).LookAt(CD3DVec3(0,0,0)));
//	frLight.Add(CRMLight(D3DRMLIGHT_POINT, D3DRGB(1,1,1)));
	pointLight.Set(D3DRMLIGHT_POINT, D3DRGB(1,1,1));
	frLight.Add(pointLight);
	frLight.Add(CRMLight(D3DRMLIGHT_AMBIENT, D3DRGB(0.3,0.3,0.3)));
	rm.Scene().Add(frLight);
//	rm.Scene()->SetSceneBackgroundRGB(D3DVALUE(0.2), D3DVALUE(0.6), D3DVALUE(0.4));

	int i;
	for( i=0; i<NFINGER; i++)
	{
		CRMMesh meshPointer("sphere.x");
		REAL r = REAL(0.01);
		REAL rr = REAL(0.0125);
		if (i == 0) // right thumb
		{
			//meshPointer.Load("sphere.x");
			meshPointer.Scale(CD3DVec3(rr,rr,rr));
			CRMTexture tex("checker.ppm");
			meshPointer.Set(tex, D3DRMWRAP_SPHERE, 'y');
			//meshPointer.Set(D3DRGB(0.8,0.4,0));
			meshPointer.Set(D3DRGB(1,0.7,1));
		}
		else // right fingers
		{
			//meshPointer.Load("sphere.x");
			meshPointer.Scale(CD3DVec3(r,r,r));
			//meshPointer.Set(D3DRGB(0.8,0.4,0));
			meshPointer.Set(D3DRGB(1,0.7,1));
		}
/*
    int i;
	for(i=0; i<NFINGER; i++) 
	{
		CRMMesh meshPointer("sphere.x");
//		CRMMesh meshPointer;
		REAL r = REAL(0.01);
		REAL rr = REAL(0.0125);
//		meshPointer.Scale(CD3DVec3(r,r,r));
		if (i < NFINGER/2) 
		{
			if (i == 0) // left thumb
			{
				//meshPointer.Load("sphere.x");
				meshPointer.Scale(CD3DVec3(rr,rr,rr));
				CRMTexture tex("checker.ppm");
				meshPointer.Set(tex, D3DRMWRAP_SPHERE, 'y');
				//meshPointer.Set(D3DRGB(0.8,0.4,0));
				meshPointer.Set(D3DRGB(1,0.7,1));
			}
			else // left fingers
			{
				//meshPointer.Load("sphere.x");
				meshPointer.Scale(CD3DVec3(r,r,r));
				//meshPointer.Set(D3DRGB(0.8,0.4,0));
				meshPointer.Set(D3DRGB(1,0.7,1));
			}
		}
		else 
		{
			if (i == 4) // right thumb
			{
				//meshPointer.Load("box.x");
				meshPointer.Scale(CD3DVec3(rr,rr,rr));
				CRMTexture tex("checker.ppm");
				meshPointer.Set(tex, D3DRMWRAP_SPHERE, 'y');
				//meshPointer.Set(D3DRGB(0,0.4,0.8));
				meshPointer.Set(D3DRGB(1,1,0.7));
			}
			else // left fingers
			{
				//meshPointer.Load("sphere.x");
				meshPointer.Scale(CD3DVec3(r,r,r));
				//meshPointer.Set(D3DRGB(0,0.4,0.8));
				meshPointer.Set(D3DRGB(1,1,0.7));
			}
		}
*/		
		
		finger[i].frame.DelThis();		
		finger[i].frame.Add(meshPointer);
		rm.Scene().Add(finger[i].frame);
	
		if (CAST_SHADOW)
		{
			LPDIRECT3DRMVISUAL shadow;
			CD3DVec3 pln = floorPos;
			rm->CreateShadow(meshPointer, pointLight, pln.x, pln.y, pln.z, 0,1,0, &shadow);
			finger[i].frame.Add(shadow);
			shadow->Release();
		}
	}//end for

	

#if 0
//	CRMFrame frPtr[8];
	for (i=0; i<8; i++) 
	{
		CRMMesh meshPtr("sphere.x");
		meshPtr.Scale(CD3DVec3(0.0025f,0.0025f,0.0025f));
		meshPtr.Set(D3DRGB(1,1,1));
		frRPos[i].Add(meshPtr);
//		if (i==0) frPtr[i].AfParent(CD3DAffine(-0.40f,-0.20f,-0.20f));
//		if (i==1) frPtr[i].AfParent(CD3DAffine(-0.40f,-0.20f,+0.20f));
//		if (i==2) frPtr[i].AfParent(CD3DAffine(-0.40f,+0.20f,+0.20f));
//		if (i==3) frPtr[i].AfParent(CD3DAffine(-0.40f,+0.20f,-0.20f));
//		if (i==4) frPtr[i].AfParent(CD3DAffine(+0.40f,-0.20f,-0.20f));
//		if (i==5) frPtr[i].AfParent(CD3DAffine(+0.40f,-0.20f,+0.20f));
//		if (i==6) frPtr[i].AfParent(CD3DAffine(+0.40f,+0.20f,+0.20f));
//		if (i==7) frPtr[i].AfParent(CD3DAffine(+0.40f,+0.20f,-0.20f));
		rm.Scene().Add(frRPos[i]);
	}
#endif

#if SHOW_HIT_INDICATOR
	HitIndicator();
#endif
	
}

void CSPView::OnIdle()
{
	UpdateScene();
	Step();
	if (firstrun)
	{
		if (AfxMessageBox(" SPIDAR-8 needs CALIBRATION \n      click  [OK]  to start ", MB_OKCANCEL) == IDOK)
		{
			Calibrate();
		}
		firstrun = false;
	}
}

//----------------------------------------------------------------------
// Update scene
//
void CSPView::UpdateScene()
{

#define USE_AVERAGE_TIME 0
#if USE_AVERAGE_TIME
	REAL time = GetTickCount();
	REAL dt = (int)time - (int)lastTime;
	dt /= 1000;
	if (dt > 0.1f) dt = REAL(0.1);
	if (dt < 0.015f) return;
	static REAL dtAve = REAL(0.01);
	dtAve *= REAL(0.3);
	dtAve += dt * REAL(0.1);

	if (bSphere0 || bSphere1) 
	{
		for (int n = 0; n < NSPHERE; n ++)
			sphere[n].UpdateMotion(dtAve);
	}
#endif

	deltaTime = 1.0f/(300.0f + dtoffset);

	// update finger pointers
	for (int i=0; i<NFINGER; i++) 
	{
		CD3DAffine af = finger[i].frame.AfWorld();
		af.Pos(finger[i].virtualPos);
//		af.Pos(finger[i].realPos);
		finger[i].frame.AfWorld(af);

//		CD3DAffine afPtr = CD3DAffine();
//		afPtr.Pos(finger[i].realPos);
//		frRPos[i].AfWorld(afPtr);
	}

#if SHOW_ROTATION_ANGLE
	CD3DVec3 ezi = sphere[objID].afSph.Ez();
	CD3DVec3 eyi = sphere[objID].afSph.Ey();
	CD3DVec3 exi = sphere[objID].afSph.Ex();

	REAL pitch = Deg(atan2(-eyi.z, eyi.y));
	REAL yaw = Deg(atan2(exi.z, exi.x));
	REAL roll = Deg(atan2(eyi.x, eyi.y));
	if (objID == 1) 
	{
		pitch = Deg(atan2(eyi.z, -eyi.y));
		yaw = Deg(atan2(-exi.z, -exi.x));
		roll = Deg(atan2(-eyi.x, -eyi.y));
	}
#endif

#if SHOW_SURFSTRING
	char df;
	if (bDisplayForce == 1) df = 'F';
	else df = 'N';
	int tt;
	if (timerType == 1) tt = 1000;
	else tt = 500;

	char str[64];
	surfString.Size(CSize(540, 20));
	surfString.Create();
	surfString.Clear();
	HDC hdc = surfString.GetDC();
	if (hdc) {
		CDC* pDC = CDC::FromHandle(hdc);
		switch (dataType)
		{
		case 1:
			sprintf(str, "[%d] SPH=%d X-Pitch= %3.2f Y-Yaw= %3.2f Z-Roll= %3.2f TRN=%d ROT=%d", 
				timerType, objID, pitch, yaw, roll, bTranslate, bRotate);
			break;
		case 2:
			sprintf(str, "%dHz [%c] 1/%3.0f Time= %.2f LapTime= %.2f", 
				tt, df, 1.0f/deltaTime, tick, lapTime/1000.0f);
			break;
		case 3:
			sprintf(str, "[%d] SPH=%d POS %2.2f %2.2f %2.2f ROT X= %3.2f Y= %3.2f Z= %3.2f", 
				timerType, objID, sphere[objID].afSph.Pos().x, 
				sphere[objID].afSph.Pos().y, sphere[objID].afSph.Pos().z, pitch, yaw, roll);
			break;
		case 4:
			sprintf(str, " Press [A] to reset the task"); 
			break;
		}
		pDC->TextOut(0, 0, str);
		surfString.ReleaseDC();
	}
	surf.Blt(surfString);
#endif

#if USE_AVERAGE_TIME
	lastTime = time;
#endif

#if SHOW_HIT_INDICATOR
	UpdateIndicator();
#endif

	// stop watch
	if (start && !running) 
	{
		lapTime = 0;
		startTime = GetTickCount();
		running = true;
	}
	if (running) 
		tick = (GetTickCount() - startTime) / 1000.0f;

	if (running && !start)
	{
		stopTime = GetTickCount();
		running = false;
		lapTime = stopTime - startTime;
		tick = 0;
	}

	rm.Scene()->Move(D3DVALUE(1.0));
	rm.FitSurface();
	rm.Clear();
	rm.Render();
	rm.Update();
	rm.Flip();
}

void CSPView::ResetObjects()
{
	if (bBox0 || bBox1) RedrawBox();
	if (bSphere0 || bSphere1) RedrawSphere();
	for (int i=0; i<NFINGER; i++)
		finger[i].virtualPos = finger[i].realPos;
	ResetIndicator();
}

//----------------------------------------------------------------------
// Send fingers' positions
//
void CSPView::Step()
{
	//	SendPos();
#if 0
	TRACE("finer#%d realPos=%2.3f %2.3f %2.3f virtualPos=%2.3f %2.3f %2.3f \n", fingerID+1,
		finger[fingerID].realPos.x, finger[fingerID].realPos.y, finger[fingerID].realPos.z, 
		finger[fingerID].virtualPos.x, finger[fingerID].virtualPos.y, finger[fingerID].virtualPos.z);
#endif
#if 0
	TRACE("finer#%d realPos=%2.3f %2.3f %2.3f Length=%2.3f %2.3f %2.3f \n", fingerID+1,
		finger[fingerID].realPos.x, finger[fingerID].realPos.y, finger[fingerID].realPos.z, 
		finger[fingerID].dev.encoder[0].Length(), finger[fingerID].dev.encoder[1].Length(), finger[fingerID].dev.encoder[2].Length());
#endif
#if 0
	TRACE("finer#%d collision force=%2.3f %2.3f %2.3f display force=%2.3f %2.3f %2.3f \n", fingerID+1,
		finger[fingerID].force.x, finger[fingerID].force.y, finger[fingerID].force.z, 
		finger[fingerID].dev.spForce.x, finger[fingerID].dev.spForce.y, finger[fingerID].dev.spForce.z);
#endif
}

//----------------------------------------------------------------------
// Calibrate SPIDAR
//
void CSPView::Calibrate()
{
	int i;
	char buff[64];
	for(i=0; i<NFINGER; i++) 
	{
		switch (i)
		{
		case 0:
			sprintf( buff, " %d. Move LEFT THUMB to the center ", i+1);
			break;
		case 1:
			sprintf( buff, " %d. Move LEFT INDEX to the center ", i+1);
			break;
		case 2:
			sprintf( buff, " %d. Move LEFT MIDDLE to the center ", i+1);
			break;
		case 3:
			sprintf( buff, " %d. Move LEFT RING to the center ", i+1);
			break;
		case 4:
			sprintf( buff, " %d. Move RIGHT THUMB to the center ", i+1);
			break;
		case 5:
			sprintf( buff, " %d. Move RIGHT INDEX to the center ", i+1);
			break;
		case 6:
			sprintf( buff, " %d. Move RIGHT MIDDLE to the center ", i+1);
			break;
		case 7:
			sprintf( buff, " %d. Move RIGHT RING to the center ", i+1);
			break;
		}

//		sprintf( buff, " [%d] Move finger # %d to the center ", i+1);
		if (AfxMessageBox(buff, MB_OKCANCEL) == IDOK) 
		{
			finger[i].dev.Calibrate();
		}
	}
	for (i=0; i<NFINGER; i++)
		finger[i].dev.AfterCalibrate();

	if (AfxMessageBox("All fingers are calibrated", MB_OKCANCEL) == IDOK)
		bCalibrate = true;
	else
		bCalibrate = false;

	if(bCalibrate) StartTask();
}

void CSPView::StartTask()
{
	// build objects on scene
	BuildFloor();
	BuildSphere();
	BuildBox();

	// add gravity to objects
	GRAVITY_ACTIVE = 1;

	// activate mmtimer
	mmtimer.Create();
	timerType = 1;

}

void CSPView::OnOpenMesh() 
{
	// TODO: Add your command handler code here
	CFileDialog dlg(true, NULL, "*.x");
	if (dlg.DoModal() == IDOK) 
	{
		meshOpenSave.Release();
		frOpenSave.Release();
		meshOpenSave.Load( (const char*)dlg.GetPathName() );
		meshOpenSave.Scale(CD3DVec3(0.5f,0.5f,0.5f));
		meshOpenSave.Set(D3DRGB(0.2,0.4,0.6));
		frOpenSave.Add(meshOpenSave);
		frOpenSave.AfParent(CD3DAffine(CD3DVec3(0,0,-1),CD3DVec3(0,1,0),CD3DVec3(-0.10f,0.0f,0.1f)));
		//frOpenSave.Rot(CD3DVec3(0,1,0), D3DVALUE(0.02));
		rm.Scene().Add(frOpenSave);
	}	
}

//----------------------------------------------------------------------
// Open pane text window
//
void CSPView::OnOpenLogPane() 
{
	// TODO: Add your command handler code here
	wsw.Create();
}

void CSPView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (nChar == 'A')		ResetObjects();
	if (nChar == 'B')		BuildBox();
	if (nChar == 'C')		Calibrate();
	if (nChar == 'D')		objID = objID ? 0 : 1;
	if (nChar == 'E')
	{
		dataType = dataType++;
		if (dataType > 3) dataType = 1;
	}
	if (nChar == 'F') 
	{
		if (ddraws.Primary().IsFullscreen()) ddraws.Primary().Window();
		else ddraws.Primary().Fullscreen(640,480,16);
		surf.DDraw(ddraws.Primary());
	}						
	if (nChar == 'G')		GRAVITY_ACTIVE = GRAVITY_ACTIVE ? 0 : 1;
	if (nChar == 'H')		OnForce();
//	if (nChar == 'J')		;
//	if (nChar == 'K')		;
//	if (nChar == 'L')		;
	if (nChar == 'M') 
	{
		mmtimer.Create();
		timerType = 1;
	}
	if (nChar == 'N') 
	{		
		mmtimer.Thread();
		timerType = 0;
	}
//	if (nChar == 'I')		;
//	if (nChar == 'O')		;
//	if (nChar == 'U')		;

	if (nChar == 'P')		BuildFloor();
	if (nChar == 'Q')		ToggleStartStop();
//	if (nChar == 'R')		BuildRubikCube();
	if (nChar == 'S')		BuildSphere();
//	if (nChar == 'T')		Test();
//	if (nChar == 'U')		;
//	if (nChar == 'V')		;
	if (nChar == 'W')		CloseFile();
	if (nChar == 'X')		OnTranslate(); //BuildAxes();
//	if (nChar == 'Y')		SwapPosition();
	if (nChar == 'Z')		OnRotate(); //GetRotationAngle();

#if 0 
	if (nChar == VK_SPACE)	
	{
		static index = 0;
		if (index == 8)
		{
			Save8FingersToFile();
			index = 0;
		}
		else
		{
			Save1FingerToBuffer(index);
			index++;
		}
	}
#endif

#if 0 
	if (nChar == VK_SPACE)	
	{
		static index = 0;
		if (index == 8)
		{
			SaveOneSetDataToFile();
			index = 0;
		}
		else
		{
			GetDataAtOnePosition(index);
			index++;
		}
	}
#endif


	if (nChar == VK_NUMPAD1) fingerID = 0;
	if (nChar == VK_NUMPAD2) fingerID = 1;
	if (nChar == VK_NUMPAD3) fingerID = 2;
	if (nChar == VK_NUMPAD4) fingerID = 3;
	if (nChar == VK_NUMPAD5) fingerID = 4;
	if (nChar == VK_NUMPAD6) fingerID = 5;
	if (nChar == VK_NUMPAD7) fingerID = 6;
	if (nChar == VK_NUMPAD8) fingerID = 7;

	if (nChar == VK_LEFT)
	{
		finger[fingerID].dev.emuPos.x -= 0.001f;
	}
	if (nChar == VK_RIGHT)
	{
		finger[fingerID].dev.emuPos.x += 0.001f;
	}
	if (nChar == VK_UP)
	{
		finger[fingerID].dev.emuPos.y += 0.001f;
	}
	if (nChar == VK_DOWN)
	{
		finger[fingerID].dev.emuPos.y -= 0.001f;
	}

	if (nChar == VK_SUBTRACT)	dtoffset -= 10.0f;
	if (nChar == VK_ADD)		dtoffset += 10.0f;

//	if (nChar == VK_MULTIPLY)	;
//	if (nChar == VK_DIVIDE)		;

//-----------------------------------------------------
#if 0
	if (nChar == VK_NUMPAD9){
		bOffset = !bOffset;
	}
	if (nChar == VK_NUMPAD1){
		calibID --;
		if (calibID <0) calibID = 7;
		TRACE("ID:%d mode:%s\n", calibID, bOffset ? "offset" : "scale");
	}else if (nChar == VK_NUMPAD3){
		calibID ++;
		if (calibID >7) calibID = 0;
		TRACE("ID:%d mode:%s\n", calibID, bOffset ? "offset" : "scale");
	}
	CD3DVec3 delta;
	if (nChar == VK_NUMPAD4) delta.x = -1;
	else if (nChar == VK_NUMPAD6) delta.x = 1;
	else if (nChar == VK_NUMPAD2) delta.y = -1;
	else if (nChar == VK_NUMPAD8) delta.y = 1;
	else if (nChar == VK_NUMPAD0) delta.z = -1;
	else if (nChar == VK_NUMPAD5) delta.z = 1;
	
	if (bOffset){
		finger[calibID].dev.afCalib.Pos(finger[calibID].dev.afCalib.Pos() + delta * 0.01f);
	}else{
		CD3DVec3 sc = delta * 0.001f + CD3DVec3(1,1,1);
		finger[calibID].dev.afCalib.ExX() *= sc.x;
		finger[calibID].dev.afCalib.EyY() *= sc.y;
		finger[calibID].dev.afCalib.EzZ() *= sc.z;
	}
#endif
#if 0
	TRACE("id :%d scale(%f %f %f) offset(%f %f %f)\n", calibID,
		finger[calibID].dev.afCalib.ExX(),
		finger[calibID].dev.afCalib.EyY(),
		finger[calibID].dev.afCalib.EzZ(),
		finger[calibID].dev.afCalib.PosX(),
		finger[calibID].dev.afCalib.PosY(),
		finger[calibID].dev.afCalib.PosZ());
#endif	
//-----------------------------------------------------
	
    CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CSPView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rc;
	GetClientRect(rc);
	CSize sz = rc.Size();
	sz.cx /= 2;
	sz.cy /= 2;
	CPoint pos = point - sz;

	if (nFlags & MK_LBUTTON) 
	{
		finger[fingerID].dev.emuPos.x = pos.x / 500.0f;
		finger[fingerID].dev.emuPos.y = -(pos.y / 500.0f);
	}
	else if (nFlags & MK_RBUTTON) 
	{
		finger[fingerID].dev.emuPos.x = pos.x / 500.0f;
		finger[fingerID].dev.emuPos.z = -(pos.y / 500.0f);
	}

	CView::OnMouseMove(nFlags, point);
}

void CSPView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rc;
	CSize sz = rc.Size();
	sz.cx /= 2;
	sz.cy /= 2;
	CPoint pos = point - sz;

	finger[fingerID].dev.emuPos.x = pos.x / 500.0f;
	finger[fingerID].dev.emuPos.y = -(pos.y / 500.0f);

//	SetCapture();

	CView::OnLButtonDown(nFlags, point);
}

void CSPView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	CRect rc;
 	CSize sz = rc.Size();
	sz.cx /= 2;
	sz.cy /= 2;
	CPoint pos = point - sz;

	finger[fingerID].dev.emuPos.x = pos.x / 500.0f;
	finger[fingerID].dev.emuPos.z = -(pos.y / 500.0f);

//	SetCapture();

//	Trigger();

	CView::OnRButtonDown(nFlags, point);
}

void CSPView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	//ReleaseCapture();
	
	CView::OnLButtonUp(nFlags, point);
}

void CSPView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	//ReleaseCapture();

	CView::OnRButtonUp(nFlags, point);
}

CRMFrame CSPView::BuildAxes()
{
	CRMFrame Xaxis, Yaxis, Zaxis;
	for (int i=0; i<3; i++)
	{
		REAL length = 0.2f;
		REAL thick = length/120.0f;
		REAL hatLength = length/15.0f;
		REAL lift = 0.5f * (hatLength/2.0f) + thick/2.0f;
		REAL back = 0.866f * (hatLength/2.0f) - thick/2.0f;
		REAL px = 0;
		REAL py = 0;
		REAL pz = 0;
		CRMMesh meshAxis("box.x");
		meshAxis.Scale(CD3DVec3(length, thick, thick));
		if (i == 0) { // x-axis
			meshAxis.Set(D3DRGB(1,0,0));
			Xaxis.Add(meshAxis);
			Xaxis.AfParent(CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0,1,0), CD3DVec3(px,0,0)));
			CRMMesh meshHat("box.x");
			meshHat.Scale(CD3DVec3(hatLength, thick, thick));
			meshHat.Set(D3DRGB(1,0,0));
			CRMFrame LHat, RHat;
			LHat.Add(meshHat);
			RHat.Add(meshHat);
			LHat.AfParent(CD3DAffine(CD3DVec3(1,-1,0), CD3DVec3(0,1,0), CD3DVec3(px+length/2.0f-back,lift,0)));
			RHat.AfParent(CD3DAffine(CD3DVec3(1,1,0), CD3DVec3(0,1,0), CD3DVec3(px+length/2.0f-back,-lift,0)));
			LHat.Add(RHat);
			Xaxis.Add(LHat);
		}
		if (i == 1) { // y-axis
			meshAxis.Set(D3DRGB(0,1,0));
			Yaxis.Add(meshAxis);
			Yaxis.AfParent(CD3DAffine(CD3DVec3(0,1,0), CD3DVec3(0,0,1), CD3DVec3(0,py,0)));
			CRMMesh meshHat("box.x");
			meshHat.Scale(CD3DVec3(hatLength, thick, thick));
			meshHat.Set(D3DRGB(0,1,0));
			CRMFrame LHat, RHat;
			LHat.Add(meshHat);
			RHat.Add(meshHat);
			LHat.AfParent(CD3DAffine(CD3DVec3(1,-1,0), CD3DVec3(0,1,0), CD3DVec3(lift,py+length/2.0f-back,0)));
			RHat.AfParent(CD3DAffine(CD3DVec3(1,1,0), CD3DVec3(0,1,0), CD3DVec3(-lift,py+length/2.0f-back,0)));
			LHat.Add(RHat);
			Yaxis.Add(LHat);
		}
		if (i == 2) { // z-axis
			meshAxis.Set(D3DRGB(0,1,1));
			Zaxis.Add(meshAxis);
			Zaxis.AfParent(CD3DAffine(CD3DVec3(0,0,1), CD3DVec3(0,1,0), CD3DVec3(0,0,pz)));
			CRMMesh meshHat("box.x");
			meshHat.Scale(CD3DVec3(hatLength, thick, thick));
			meshHat.Set(D3DRGB(0,1,1));
			CRMFrame LHat, RHat;
			LHat.Add(meshHat);
			RHat.Add(meshHat);
			LHat.AfParent(CD3DAffine(CD3DVec3(1,0,-1), CD3DVec3(0,1,0), CD3DVec3(lift,0,pz+length/2.0f-back)));
			RHat.AfParent(CD3DAffine(CD3DVec3(1,0,1), CD3DVec3(0,1,0), CD3DVec3(-lift,0,pz+length/2.0f-back)));
			LHat.Add(RHat);
			Zaxis.Add(LHat);
		}
	}
	Yaxis.Add(Zaxis);
	Xaxis.Add(Yaxis);
	return Xaxis;
}

//----------------------------------------------------------------------
// Build floor 
//
void CSPView::BuildFloor()
{
	int i;
	REAL x, y, z;

	CRMMesh meshFloor("box.x");
//	CRMTexture tex("texture2.bmp");
//	meshFloor.Set(tex, D3DRMWRAP_FLAT, 'x');
	meshFloor.Set(D3DRGB(0.2, 0.8, 1));
	x = REAL(0.80);
	y = REAL(0.05);
	z = REAL(0.60);
	CD3DVec3 floorSize = CD3DVec3(x, y, z);
	meshFloor.Scale(floorSize);
	CRMFrame frFloor;
	frFloor.Add(meshFloor);
	frFloor.AfParent(CD3DAffine(0, floorPos.y - y, 0));
	rm.Scene().Add(frFloor);

	for (i=0; i<2; i++)
	{
		CRMMesh meshWallX("box.x");
		meshWallX.Set(D3DRGB(0.2, 0.8, 1));
		x = REAL(0.04);
		y = REAL(0.25);
		z = REAL(0.60);
		CD3DVec3 wallX = CD3DVec3(x, y, z);
		meshWallX.Scale(wallX);
		CRMFrame frWallX;
		frWallX.Add(meshWallX);
//		if (i == 0) frWallX.AfParent(CD3DAffine(CD3DVec3(-1,0,0), CD3DVec3(0,1,0), CD3DVec3(0.40f + x/2, floorPos.y, 0))); 
//		if (i == 1) frWallX.AfParent(CD3DAffine(CD3DVec3(-1,0,0), CD3DVec3(0,1,0), CD3DVec3(-0.40f - x/2, floorPos.y, 0))); 
		if (i == 0) frWallX.AfParent(CD3DAffine( 0.40f + x/2, floorPos.y, 0)); 
		if (i == 1) frWallX.AfParent(CD3DAffine(-0.40f - x/2, floorPos.y, 0)); 
		rm.Scene().Add(frWallX);
	}

	CRMMesh meshWallZ("box.x");
	meshWallZ.Set(D3DRGB(0, 0.55, 0.7));
	x = REAL(0.80);
	y = REAL(0.25);
	z = REAL(0.04);
	CD3DVec3 wallZ = CD3DVec3(x, y, z);
	meshWallZ.Scale(wallZ);
	CRMFrame frWallZ;
	frWallZ.Add(meshWallZ);
	frWallZ.AfParent(CD3DAffine(0, floorPos.y, 0.30f + z/2));
//	frWallZ.AfParent(CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0,-1,0), CD3DVec3(0, floorPos.y, 0.30f + z/2)));
	rm.Scene().Add(frWallZ);


#if 0 // 1 square marker
	CRMMesh meshBoxMarker("box.x");
	meshBoxMarker.Set(D3DRGB(0.6, 0.6, 0.6));
	meshBoxMarker.Scale(CD3DVec3(0.12f, 0.02f, 0.12f));
	CRMFrame frBoxMarker;
	frBoxMarker.Add(meshBoxMarker);
	frBoxMarker.AfParent(CD3DAffine(-0.20f, (floorPos.y-0.0325f), 0)); 
	rm.Scene().Add(frBoxMarker);
#endif
#if 1 // 2 circle markers
	for (i=0; i<2; i++)
	{
		CRMMesh meshSphMarker("disc.x");
		meshSphMarker.Set(D3DRGB(0.6, 0.6, 0.6));
		meshSphMarker.Scale(CD3DVec3(0.06f, 0.06f, 0.06f));
		CRMFrame frSphMarker;
		frSphMarker.Add(meshSphMarker);
		CD3DAffine af;
		if (i == 0) af = CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0,0,1), CD3DVec3(0.12f, floorPos.y-0.002f, 0));
		if (i == 1) af = CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0,0,1), CD3DVec3(-0.12f, floorPos.y-0.002f, 0));
		frSphMarker.AfParent(af); 
		rm.Scene().Add(frSphMarker);
	}
#endif
}

//----------------------------------------------------------------------
// Build grid plane
//
void CSPView::BuildGrid()
{
	CRMMesh meshGrid("grid.x");
	meshGrid.Scale(CD3DVec3(0.1f, 0.1f, 0.1f));
	meshGrid.operator IDirect3DRMMeshBuilder*()->SetQuality(D3DRMRENDER_WIREFRAME);
	CRMFrame frGrid;
	frGrid.Add(meshGrid);
	frGrid.AfParent(CD3DAffine(0, 0, 0));
	rm.Scene().Add(frGrid);
}

void CSPView::BuildCylinder()
{
	CRMMesh meshCylinder("cylinder.x");
	REAL r = 0.05f;
	meshCylinder.Scale(CD3DVec3(r, r*3, r));
	meshCylinder.Set(D3DRGB(0, 0.6, 0.8));
	CRMFrame frCylinder;
	frCylinder.Add(meshCylinder);
	CD3DAffine af = CD3DAffine(CD3DVec3(1,0,0),CD3DVec3(0,1,0), CD3DVec3(0,-(r*3)/2,0));
	frCylinder.AfParent(af);
	rm.Scene().Add(frCylinder);
}

void CSPView::BuildBox()
{
	int i;
	static bool bCreated = false;

	if (bCreated == true)
	{
		for(i=0; i<NBOX; i++)
		{
			box[i].frame.DelThis();
			if (i == 0) bBox0 = false;
			if (i == 1) bBox1 = false;
		}
		bCreated = false;
		return;
	}

	for(i=0; i<NBOX; i++) 
	{
		CRMMesh meshBox;
		if (HI_RESOLUTION_MESH) meshBox.Load("box1.x");
		if (LOW_RESOLUTION_MESH) meshBox.Load("box.x");
		REAL lenght = REAL(0.08);
		CD3DVec3 boxSize = CD3DVec3(lenght, lenght, lenght);
		meshBox.Scale(boxSize);
		
		if (LOW_RESOLUTION_MESH) 
		{
			// paint color on each face of box                         +------+
			meshBox.faces[0].Set(D3DRGB(0, 1, 0)); // Green            | Blue | 
			meshBox.faces[1].Set(D3DRGB(1, 0, 0)); // Red       +------|------|------+------+
			meshBox.faces[2].Set(D3DRGB(0, 0, 1)); // Blue      |Green | Red  | Sky  |Yellow|
			meshBox.faces[3].Set(D3DRGB(1, 1, 0)); // Yellow    +------|------|------+------+
			meshBox.faces[4].Set(D3DRGB(1, 0, 1)); // Violet           |Violet|
			meshBox.faces[5].Set(D3DRGB(0, 1, 1)); // Sky              +------+
		}
		if (HI_RESOLUTION_MESH) 
		{
			int j;
			for (j=0; j<25; j++) meshBox.faces[j].Set(D3DRGB(0, 1, 0));

			for (j=25; j<30; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 0));
			for (j=30; j<35; j++) meshBox.faces[j].Set(D3DRGB(0, 0, 1));
			for (j=35; j<40; j++) meshBox.faces[j].Set(D3DRGB(1, 1, 0));
			for (j=40; j<45; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 1));

			for (j=45; j<50; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 0));
			for (j=50; j<55; j++) meshBox.faces[j].Set(D3DRGB(0, 0, 1));
			for (j=55; j<60; j++) meshBox.faces[j].Set(D3DRGB(1, 1, 0));
			for (j=60; j<65; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 1));

			for (j=65; j<70; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 0));
			for (j=70; j<75; j++) meshBox.faces[j].Set(D3DRGB(0, 0, 1));
			for (j=75; j<80; j++) meshBox.faces[j].Set(D3DRGB(1, 1, 0));
			for (j=80; j<85; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 1));

			for (j=85; j<90; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 0));
			for (j=90; j<95; j++) meshBox.faces[j].Set(D3DRGB(0, 0, 1));
			for (j=95; j<100; j++) meshBox.faces[j].Set(D3DRGB(1, 1, 0));
			for (j=100; j<105; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 1));
		
			for (j=105; j<110; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 0));
			for (j=110; j<115; j++) meshBox.faces[j].Set(D3DRGB(0, 0, 1));
			for (j=115; j<120; j++) meshBox.faces[j].Set(D3DRGB(1, 1, 0));
			for (j=120; j<125; j++) meshBox.faces[j].Set(D3DRGB(1, 0, 1));

			for (j=125; j<150; j++) meshBox.faces[j].Set(D3DRGB(0, 1, 1));
		}
		if (WIREFRAME_MESH)
			// render wireframe
			meshBox.operator IDirect3DRMMeshBuilder*()->SetQuality(D3DRMRENDER_WIREFRAME);

		box[i].frame.DelThis();
		box[i].frame.Add(meshBox);
		box[i].frame.AfParent(afBox[i]);
		
		if (SHOW_AXIS)
		{
			CRMFrame axis = BuildAxes();
			axis.AfParent(afBox[i]);
			box[i].frame.Add(axis);
		}

		if (CAST_SHADOW)
		{
			LPDIRECT3DRMVISUAL shadow;
			CD3DVec3 pln = floorPos;
			rm->CreateShadow(meshBox, pointLight, pln.x, pln.y, pln.z, 0,1,0, &shadow);
			box[i].frame.Add(shadow);
			shadow->Release();
		}

		box[i].mass = REAL(0.5);
//		box[i].mass = REAL(0.3);
		box[i].size = boxSize;
		box[i].afBox = CD3DAffine() * afBox[i];
		if (i == 0) 
		{
			box[i].frame.Name("BOX0");
			bBox0 = true;
			numObject += 1;
		}
		if (i == 1) 
		{
			box[i].frame.Name("BOX1");
			bBox1 = true;
			numObject += 1;
		}
		box[i].Init();
		rm.Scene().Add(box[i].frame);
	}
	bCreated = true;
}

void CSPView::RedrawBox()
{
	for (int i=0; i<NBOX; i++)
	{
		box[i].afBox = CD3DAffine() * afBox[i];
		box[i].Init();
		box[i].frame.AfWorld(box[i].afBox);
	}
}

void CSPView::BuildSphere()
{
	int i;
	static bool bCreated = false;
	if (bCreated == true) 
	{
		for(i=0; i<NSPHERE; i++)
		{
			sphere[i].frame.DelThis();
			if (i == 0) bSphere0 = false;
			if (i == 1) bSphere1 = false;
		}
		bCreated = false;
		return;
	}

	for(i=0; i<NSPHERE; i++) 
	{
		CRMMesh meshSphere("sphere1.x");
		REAL r = REAL(0.05);
		meshSphere.Scale(CD3DVec3(r, r, r));
		if (i == 0) {
//			meshSphere.Set(D3DRGB(1, 0.9, 1));
//			CRMTexture tex("texture6.bmp"); // 6 makers
			CRMTexture tex("texture4.bmp"); // 4 makers
//			CRMTexture tex("image1.bmp");
			meshSphere.Set(tex, D3DRMWRAP_SPHERE, 'x');
		}
		if (i == 1) {
//			meshSphere.Set(D3DRGB(1, 0.9, 1));
			CRMTexture tex("texture4.bmp"); // 4 makers
			meshSphere.Set(tex, D3DRMWRAP_SPHERE, 'x');
		}
		if (WIREFRAME_MESH)
			meshSphere.operator IDirect3DRMMeshBuilder*()->SetQuality(D3DRMRENDER_WIREFRAME);

		sphere[i].frame.DelThis();
		sphere[i].frame.Add(meshSphere);
		sphere[i].frame.AfParent(afSph[i]);
//		sphere[i].frame.Rot(CD3DVec3(0,1,0), D3DVALUE(0.005));

		if (SHOW_AXIS)
		{
			CRMFrame axis = BuildAxes();
			axis.AfParent(afSph[i]);
			sphere[i].frame.Add(axis);
		}

		if (CAST_SHADOW)
		{
			LPDIRECT3DRMVISUAL shadow;
			CD3DVec3 pln = floorPos;
			rm->CreateShadow(meshSphere, pointLight, pln.x, pln.y, pln.z, 0,1,0, &shadow);
			sphere[i].frame.Add(shadow);
			shadow->Release();
		}

//		sphere[i].mass = REAL(0.5);
		sphere[i].mass = REAL(0.25);
		sphere[i].radius = r;
		sphere[i].afSph = CD3DAffine() * afSph[i];
		if (i == 0) 
		{
			sphere[i].frame.Name("SPH0");
			bSphere0 = true;
			numObject += 1;
		}
		if (i == 1) 
		{
			sphere[i].frame.Name("SPH1");
			bSphere1 = true;
			numObject += 1;
		}

		if (0) // show center of each color marker
		{
			CD3DVec3 pos = sphere[i].afSph.Pos(); 
			CD3DVec3 red = pos + r * sphere[i].afSph.Ex(); // center of red circle
			CD3DAffine aftemp1 = sphere[i].afSph * CD3DAffine(Rad(90), 'x') * CD3DAffine(Rad(15), 'z');
			CD3DVec3 green = pos + r * aftemp1.Ey(); // center of green circle
			CD3DAffine aftemp2 = sphere[i].afSph * CD3DAffine(Rad(-30), 'x') * CD3DAffine(Rad(15), 'z');
			CD3DVec3 blue = pos + r * aftemp2.Ey(); // center of blue circle
			CD3DAffine aftemp3 = sphere[i].afSph * CD3DAffine(Rad(-150), 'x') * CD3DAffine(Rad(15), 'z');
			CD3DVec3 yellow = pos + r * aftemp3.Ey(); // center of yellow circle
			for (int j=0; j<4; j++)
			{
				CRMMesh meshPtr("sphere.x");
				meshPtr.Scale(CD3DVec3(0.003f, 0.003f, 0.003f));
				meshPtr.Set(D3DRGB(1, 1, 1));
				CRMFrame frPtr;
				frPtr.Add(meshPtr);
				if (j == 0) frPtr.AfParent(CD3DAffine(red.x, red.y, red.z));
				if (j == 1) frPtr.AfParent(CD3DAffine(green.x, green.y, green.z));
				if (j == 2) frPtr.AfParent(CD3DAffine(blue.x, blue.y, blue.z));
				if (j == 3) frPtr.AfParent(CD3DAffine(yellow.x, yellow.y, yellow.z));
				sphere[i].frame.Add(frPtr);
			}
		}

		sphere[i].Init();
		rm.Scene().Add(sphere[i].frame);
	}
	bCreated = true;
}

void CSPView::RedrawSphere()
{
	for (int i=0; i<NSPHERE; i++)
	{
		sphere[i].afSph = CD3DAffine() * afSph[i];
		sphere[i].Init();
		sphere[i].frame.AfWorld(sphere[i].afSph);
	}
}

void CSPView::CloseFile()
{
	if (file.is_open()) file.close();
}

void CSPView::OnFileSave() 
{
	// TODO: Add your command handler code here

	if (file.is_open()) file.close();
	CFileDialog dlg(false, NULL, "*.txt");
	if (dlg.DoModal() == IDOK) 
	{
		file.open((const char*)dlg.GetPathName());
	}
	//file.open("sendData.txt");
}

void CSPView::ClearBuffer()
{
	for (int i=0; i<NFINGER; i++)
	{
		finger[i].tempPos = CD3DVec3();
		finger[i].L0 = REAL(0);
		finger[i].L1 = REAL(0);
		finger[i].L2 = REAL(0);
	}
}

void CSPView::Trigger()
{
	static int index = 0;
	if (index == 8)
	{
		SaveOneSetDataToFile();
		index = 0;
	}
	else
	{
		GetDataAtOnePosition(index);
		index++;
	}
}

void CSPView::ClearAllData()
{
	for (int i=0; i<8; i++)
	{
		data[i].pos = CD3DVec3();
		data[i].length0 = 0;
		data[i].length1 = 0;
		data[i].length2 = 0;
		data[i].counter0 = 0;
		data[i].counter1 = 0;
		data[i].counter2 = 0;
	}
}

void CSPView::GetDataAtOnePosition(int i)
{
	int ID = i; 

	data[i].pos = finger[ID].dev.RPos();
	data[i].length0 = finger[ID].dev.encoder[0].Length();
	data[i].length1 = finger[ID].dev.encoder[1].Length();
	data[i].length2 = finger[ID].dev.encoder[2].Length();
	data[i].counter0 = finger[ID].dev.encoder[0].Count();
	data[i].counter1 = finger[ID].dev.encoder[1].Count();
	data[i].counter2 = finger[ID].dev.encoder[2].Count();
	
	wsw << i+1 << " POS= " << data[i].pos.x << " " << data[i].pos.y << " " << data[i].pos.z
			<< " LENGTH= " << data[i].length0 << " " << data[i].length1 << " " << data[i].length2
			<< " COUNTER= " << data[i].counter0 << " " << data[i].counter1 << " " << data[i].counter2
			<< "\n\n";
}

void CSPView::SaveOneSetDataToFile()
{
	static int counter = 0;
	if (!file.is_open()) 
	{
		AfxMessageBox("Error: file is not opened, no data save", MB_OK);
		ClearAllData();
		return;
	}

	counter++;
	file << "Record #" << counter << "\n";
	for (int i=0; i<8; i++)
	{
		file << " [" << i <<  "] POS= " << data[i].pos.x << " " << data[i].pos.y << " " << data[i].pos.z 
			<< " LENGTH= " << data[i].length0 << " " << data[i].length1 << " " << data[i].length2
			<< " COUNTER= " << data[i].counter0 << " " << data[i].counter1 << " " << data[i].counter2
			<< "\n";
	}
	file.flush();
	AfxMessageBox("Data Saved", MB_OK);
	ClearAllData();
}

void CSPView::Save1FingerToBuffer(int i)
{
	static int counter = 0;
	
	i = 0;

	finger[i].tempPos = finger[i].dev.RPos();
	finger[i].L0 = finger[i].dev.encoder[0].Length();
	finger[i].L1 = finger[i].dev.encoder[1].Length();
	finger[i].L2 = finger[i].dev.encoder[2].Length();
	Beep(0,0);
	char f; 
	if (i == 0 || i == 4) f = 'T';
	if (i == 1 || i == 5) f = 'I';
	if (i == 2 || i == 6) f = 'M';
	if (i == 3 || i == 7) f = 'R';
	char h;
	if (i < 4) h = 'L';
	else h = 'R';

	wsw << ++counter << " [" << h << f << "]" 
		<< " pos=(" << finger[i].tempPos.x << " " << finger[i].tempPos.y << " " << finger[i].tempPos.z << ")"
		<< " L0=" << finger[i].L0 << " L1=" << finger[i].L1 << " L2=" << finger[i].L2 << "\n\n";
}

//----------------------------------------------------------------------
// 
//
void CSPView::Save8FingersToFile()
{
	static int counter = 0;
	if (!file.is_open()) 
	{
		AfxMessageBox("Error: no file open, data not save", MB_OK);
		ClearBuffer();
		return;
	}

	counter++;
	for (int i=0; i<NFINGER; i++) 
	{
		CD3DVec3 pos = finger[i].tempPos;
		REAL L0 = finger[i].L0;
		REAL L1 = finger[i].L1;
		REAL L2 = finger[i].L2;
		char f; 
		if (i == 0 || i == 4) f = 'T';
		if (i == 1 || i == 5) f = 'I';
		if (i == 2 || i == 6) f = 'M';
		if (i == 3 || i == 7) f = 'R';
		char h;
		if (i < 4) h = 'L';
		else h = 'R';
		file << counter << " " << h << f << " pos= " << pos.x << " " << pos.y << " " << pos.z 
			<< " L0= " << L0 << " L1= " << L1 << " L2= " << L2 ;
	}
	file << "\n";
	file.flush();
	AfxMessageBox("Data Saved", MB_OK);
	ClearBuffer();
}


void CSPView::SendPos()
{
/*
	if (Is_Connect) 
	{
		CD3DAffine afBox1 = box1.afBoxDyna * box1.afBoxVis;
		CD3DAffine afBox2 = box2.afBoxDyna * box2.afBoxVis;
		for (int i=0; i<NFINGER; i++) {
			CD3DVec3 p = finger[i].realPos;
			sock << i << " " << p.x << " " << p.y << " " << p.z << "\n";
			file << i << " " << p.x << " " << p.y << " " << p.z << "\n";
		}
		sock << "L" << " " << afBox1 << "\n";
		file << "L" << " " << afBox1 << "\n";
		sock << "R" << " " << afBox2 << "\n";
		file << "R" << " " << afBox2 << "\n";
		sock << "D" << state << "\n";
		file << "D" << state << "\n";
		sock.flush();
		file.flush();
	}
*/
	return;
}

//----------------------------------------------------------------------
// Connect to graphics server
//
BOOL CSPView::Connect()
{
	BOOL rtn;
	rtn = sock.connect("GULL", 10000);
	Sleep(100);
	return rtn;
}

void CSPView::OnConnect() 
{
	// TODO: Add your command handler code here
	if(AfxMessageBox("Connecting Graphics Server\n   GULL port:10000") == IDOK)
		Is_Connect = Connect();
	if(Is_Connect) {
		Beep(0,0);
		AfxMessageBox("Connection established");
	}
	else {
		AfxMessageBox("Connection error!");
	}
}

void CSPView::OnButtonConnect() 
{
	// TODO: Add your command handler code here
	OnConnect();
}

void CSPView::OnBox() 
{
	// TODO: Add your command handler code here
	BuildBox();
}

void CSPView::OnSphere() 
{
	// TODO: Add your command handler code here
	BuildSphere();
}

void CSPView::OnFloor() 
{
	// TODO: Add your command handler code here
	BuildFloor();	
}

void CSPView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
//	if (start) GetRotationAngle();
	if (start) GetExpData();
	else 
		if (file.is_open() && bCheck == false) 
		{
			file << "LapTime= " << lapTime/1000.0f <<" sec.\n";
			bCheck = true;
		}
	

	CView::OnTimer(nIDEvent);
}

void CSPView::GetExpData()
{
#if 1
	static int counter = 0;
	if (!file.is_open()) return;

	CD3DVec3 ey_0 = sphere[0].afSph.Ey();
	CD3DVec3 ex_0 = sphere[0].afSph.Ex();
	REAL pit_0 = Deg(atan2(-ey_0.z, ey_0.y));
	REAL yaw_0 = Deg(atan2( ex_0.z, ex_0.x));
	REAL rol_0 = Deg(atan2( ey_0.x, ey_0.y));
	CD3DVec3 pos_0 = sphere[0].afSph.Pos();

	CD3DVec3 ey_1 = sphere[1].afSph.Ey();
	CD3DVec3 ex_1 = sphere[1].afSph.Ex();
	REAL pit_1 = Deg(atan2( ey_1.z, -ey_1.y));
	REAL yaw_1 = Deg(atan2(-ex_1.z, -ex_1.x));
	REAL rol_1 = Deg(atan2(-ey_1.x, -ey_1.y));
	CD3DVec3 pos_1 = sphere[1].afSph.Pos();

	file << counter 
		<< " SPH0:ROT= " << pit_0 << " " << yaw_0 << " " << rol_0 << " POS= " << pos_0.x << " " << pos_0.y << " " << pos_0.z  
		<< " SPH1:ROT= " << pit_1 << " " << yaw_1 << " " << rol_1 << " POS= " << pos_1.x << " " << pos_1.y << " " << pos_1.z ;
	
	for (int i=0; i<NFINGER; i++)
	{
		CD3DVec3 p = finger[i].realPos;
		CD3DVec3 f = finger[i].force;
		CD3DVec3 t = finger[i].torque;
		CD3DVec3 sf = finger[i].dev.spForce;

		file << " [" << i << "]" 
			<< " P= " << p.x << " " << p.y << " " << p.z 
			<< " F= " << f.x << " " << f.y << " " << f.z 
			<< " T= " << t.x << " " << t.y << " " << t.z 
			<< " SF= " << sf.x << " " << sf.y << " " << sf.z; 
	}
	file << "\n";
	counter++;
#endif

}

void CSPView::ToggleStartStop()
{
	start = start ? 0 : 1;
	if (start == 0) bCheck = false;
}

void CSPView::OnForce() 
{
	// TODO: Add your command handler code here
	bDisplayForce = !bDisplayForce;	
}

void CSPView::OnUpdateForce(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(bDisplayForce ? 1 : 0);
}

void CSPView::SwapPosition()
{
	if (bSphere0 && bBox0)
	{
		swap = swap ? 0 : 1;
		if (swap == 0) 
		{
			if (bSphere0) sphere[0].afSph = CD3DAffine() * afSph[0];
			if (bBox0) box[0].afBox = CD3DAffine() * afBox[0];
		}
		if (swap == 1) 
		{
			sphere[0].afSph = CD3DAffine() * afSph[1];
			box[0].afBox = CD3DAffine() * afBox[1];
		}
		sphere[0].Init();
		sphere[0].frame.AfWorld(sphere[0].afSph);
		box[0].Init();
		box[0].frame.AfWorld(box[0].afBox);
	}
}

void CSPView::OnButtonGravity() 
{
	// TODO: Add your command handler code here
	GRAVITY_ACTIVE = GRAVITY_ACTIVE ? 0 : 1;
}

void CSPView::OnButtonMmtimer() 
{
	// TODO: Add your command handler code here
	mmtimer.Create();
	timerType = 1;	
}

void CSPView::OnButtonThread() 
{
	// TODO: Add your command handler code here
	mmtimer.Thread();
	timerType = 0;
}

void CSPView::OnUpdateRotate(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(bRotate ? 1 : 0);	
}

void CSPView::OnRotate() 
{
	// TODO: Add your command handler code here
	bRotate = !bRotate;
	if (bSphere0 || bSphere1)
	{
		for (int i=0; i<NSPHERE; i++)
			sphere[i].bAllowRotate = bRotate;
	}

	if (bBox0 || bBox1)
	{
		for (int i=0; i<NSPHERE; i++)
			box[i].bAllowRotate = bRotate;
	}
}

void CSPView::OnUpdateTranslate(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(bTranslate ? 1 : 0);	
}

void CSPView::OnTranslate() 
{
	// TODO: Add your command handler code here
	bTranslate = !bTranslate;
	if (bSphere0 || bSphere1)
	{
		for (int i=0; i<NSPHERE; i++)
			sphere[i].bAllowTranslate = bTranslate;
	}

	if (bBox0 || bBox1)
	{
		for (int i=0; i<NSPHERE; i++)
			box[i].bAllowTranslate = bTranslate;
	}
}
