//---------------------------------------------------------------------------
#pragma warn -csu
#pragma warn -pch
#pragma warn -hid
#include <vcl\vcl.h>
#pragma hdrstop
#include "HaseBCBP.hpp"
#define INITGUID
#include "Hase/CBuilder/D3DBox.h"
#pragma warn -csu
#pragma warn -pch
#pragma warn -hid
#ifndef LOWWORD
#define LOWWORD(x) WORD(x&0xFFFF)
#endif
#ifndef HIWORD
#define HIWORD(l) ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#endif

//---------------------------------------------------------------------------
static inline TD3DBox *ValidCtrCheck()
	{
	return new TD3DBox(NULL);
	}
//---------------------------------------------------------------------------
NAMESPACE_HASE::CDDraws* TD3DBox::pDDraw;
int TD3DBox::instanceCount;
__fastcall TD3DBox::TD3DBox(TComponent* Owner)
	: TWinControl(Owner)
	{
	buildSceneEvent = NULL;
	beforeRenderEvent = NULL;
	afterRenderEvent = NULL;
	fullWidth = 640;
	fullHeight = 480;
	fullBPP = 16;
	fullscreen = false;
	Width = 200;
	Height = 200;
    pSurf = NULL;
    pRM = NULL;
	if (!pDDraw)
		{
		pDDraw = new NAMESPACE_HASE::CDDraws;
		}
	instanceCount ++;
	pRM = new NAMESPACE_HASE::CD3DRMEx;
	pSurf = new NAMESPACE_HASE::CD3DDevice;
	}
__fastcall TD3DBox::~TD3DBox()
	{
	delete pRM;
    pRM = NULL;
	delete pSurf;
    pSurf = NULL;
	instanceCount --;
	if (instanceCount == 0)
		{
		delete pDDraw;
		pDDraw = NULL;
		}
	}

void __fastcall TD3DBox::CreateWindowHandle(const TCreateParams &Params)
	{
	TWinControl::CreateWindowHandle(Params);
    if (!pDDraw) return;
	pDDraw->Set(Handle);
	pDDraw->Primary().Create();
	pSurf->Set(Handle);
	pSurf->Create();
	pRM->Set(*pSurf);
	pRM->Create();
    FPUReset();
	if (buildSceneEvent) buildSceneEvent(*pRM);
	}
void __fastcall TD3DBox::DestroyWindowHandle(void)
	{
    if (!pRM)
    	{
		TWinControl::DestroyWindowHandle();
        return;
        }
	pRM->Release();
	pSurf->Release();
	TWinControl::DestroyWindowHandle();
	}
void __fastcall TD3DBox::SetFullscreen(bool f)
	{
    if (!pSurf || !pDDraw) return;
	if (f)
		{
		pSurf->SaveWindowPlace();
		pDDraw->Primary().Fullscreen(fullWidth, fullHeight, fullBPP);
		pSurf->FitWindowToSurface();
		}
	else
		{
		pDDraw->Primary().Window();
		pSurf->RestoreWindowPlace();
		}
	}
bool __fastcall TD3DBox::IsFullscreen()
	{
    if (!pDDraw) return false;
	return pDDraw->Primary().IsFullscreen();
	}

bool __fastcall TD3DBox::Render()
	{
    if (!pRM) return false;
	bool rtv = true;
	rtv &= pRM->Clear();
	if (beforeRenderEvent) beforeRenderEvent(*pRM, *pSurf);
    FPUReset();
	rtv &= pRM->Render();
	if (afterRenderEvent) afterRenderEvent(*pRM, *pSurf);
	rtv &= pRM->Update();
	return rtv;
	}
void __fastcall TD3DBox::WMSize(TWMSize& msg)
	{
    if (!pSurf) return;
	pSurf->Release();
	}
void __fastcall TD3DBox::WMPaint(TWMPaint& msg)
	{
	PAINTSTRUCT ps;
	BeginPaint(Handle, &ps);
	ps.fErase = true;
	PatBlt(ps.hdc, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right-ps.rcPaint.left, ps.rcPaint.bottom-ps.rcPaint.top, BLACKNESS);
	EndPaint(Handle, &ps);
	}
void __fastcall TD3DBox::SetDriver(int drv)
	{
    if (!pSurf) return;
	pSurf->drivers.Set(drv);
	}
int __fastcall TD3DBox::GetDriver()
	{
    if (!pSurf) return 2;
	return pSurf->drivers.prefer;
	}

//---------------------------------------------------------------------------
#include <Hase/DX/HDXError.cpp>
#include <Hase/DX/HDXObj.cpp>
#include <Hase/DDraw/HDDraw.cpp>
#include <Hase/DDraw/HDDMode.cpp>
#include <Hase/DDraw/HDDSurf.cpp>
#include <Hase/D3D/HD3DAffine.cpp>
#include <Hase/D3D/HD3DDev.cpp>
#include <Hase/D3D/HD3DRM.cpp>
#include <Hase/D3D/HRMFrame.cpp>
#include <Hase/D3D/HRMFrameEx.cpp>
#include <Hase/D3D/HRMVisual.cpp>
#include <Hase/D3D/HRMVisualEx.cpp>
#include <Hase/D3D/HD3DRMEx.cpp>
//---------------------------------------------------------------------------
