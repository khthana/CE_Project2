#include "Haptic/Spidar.h"
//----------------------------------------------------------------------------
//	SPIDAR�̒萔�̐ݒ�

 int CSpidar::ctAddrDef[] = {0x304, 0x308};
 int CSpidar::daAddrDef[] = {0x300};

//	�P�j���[�g���o�����߂�DA�̏o�͓d��[V/N]	{0����,1����,...}
//	maxon �̏ꍇ
//	0.008[m]    / 0.0438[Nm/A] / 0.5[A/V] =  0.365296803653
//	��t���@�̏ꍇ
//	0.008[m]    / 0.0277[Nm/A] / 0.5[A/V] =  0.5776
// REAL CSpidar::voltPerNewtonDef[] = {0.5776f, 0.3653f};
 REAL CSpidar::voltPerNewton = 0.577617328520f;

//	�P�J�E���g�̒��� [m/plus]
//	2*PI*0.008[m] / 500[plus]*4 = 2.513274122872e-5
// REAL CSpidar::lenPerPlusDef[] = {2.924062107079e-5f, -2.924062107079e-5f};
 REAL CSpidar::lenPerPlus = 2.513274122872e-5f;

//	�ŏ����� [N]
// REAL CSpidar::minForceDef[] = {0.5f, 0.5f};
 REAL CSpidar::minForce = 0.5f;

//	�ő咣�� [N]
// REAL CSpidar::maxForceDef[] = {20.0f, 20.0f};
 REAL CSpidar::maxForce = 20.0f;

//	���[�^�̎��t���ʒu
//	���[�^�������̂Ɏ��t�����Ă���ꍇ
#define PX	0.265f	//	x�����̕ӂ̒���/2
#define PY	0.265f	//	y�����̕ӂ̒���/2
#define PZ	0.265f	//	z�����̕ӂ̒���/2
 Vec3 CSpidar::motorPosDef[][4] =	//	���[�^�̎��t���ʒu(���S�����_�Ƃ���)
	{
		{Vec3( PX, PY,-PZ), Vec3(-PX, PY, PZ), Vec3(-PX,-PY,-PZ), Vec3( PX,-PY, PZ)},
		{Vec3(-PX, PY,-PZ),	Vec3( PX, PY, PZ), Vec3(-PX,-PY, PZ), Vec3( PX,-PY,-PZ)}
	};
//----------------------------------------------------------------------------
//S	CSpidarDrivers CSpidar::drivers;

CSpidar::CSpidar()
	{
	bInitialized = false;
	channel = 0;
//S	driver = NULL;
	}
CSpidar::~CSpidar()
	{
	MinForceSet();
	}
bool CSpidar::Init(int ch)
	{
	int i;
	channel = ch;
/*S*************************************************
	//	�h���C�o�̎擾
	if (!drivers.bInitalized) drivers.Init();
	if (driver)
		{
		drivers.Return(driver);
		driver = NULL;
		}
	driver = drivers.Rent();
**S**************************************************/

	switch(channel)
	{
	case 0:
		//	���[�^�̏�����
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i, voltPerNewton, minForce, maxForce);
			//S motor[i].Set(driver, i, voltPerNewtonDef[channel], minForceDef[channel], maxForceDef[channel]);
		}
		break;
	case 1:
		for(i=0; i<4; i++)
		{
			motor[i].pos = motorPosDef[channel][i];
			motor[i].Set(daAddrDef[0], i+4, voltPerNewton, minForce, maxForce);
			//S motor[i].Set(driver, i, voltPerNewtonDef[channel], minForceDef[channel], maxForceDef[channel]);
		}
		break;
	}
	switch(channel)
	{
	case 0:
		//	�G���R�[�_�̏�����
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[0], i, 0, lenPerPlus);
			//S encoder[i].Set(driver, i, lenPerPlusDef[channel]);
		}
		break;
	case 1:
		for(i=0; i<4; i++)
		{
			encoder[i].Set(ctAddrDef[1], i, 0, lenPerPlus);
			//S encoder[i].Set(driver, i, lenPerPlusDef[channel]);
		}
		break;
	}

	InitMat();
	bInitialized = Calib();
	return true;
	}
/*S
void CSpidar::VoltPerNewton(REAL vpn)
	{
	for(int i=0; i<4; i++) motor[i].VoltPerNewton(vpn);
	}
void CSpidar::LenPerPulse(REAL lpp)
	{
	for(int i=0; i<4; i++) encoder[i].LenPerPulse(lpp);
	}

void CSpidar::MinForce(REAL mf)
	{
	for(int i=0; i<4; i++) motor[i].MinForce(mf);
	}
void CSpidar::MaxForce(REAL mf)
	{
	for(int i=0; i<4; i++) motor[i].MaxForce(mf);
	}	
*/

bool CSpidar::BeforeCalib()
	{
	MinForceSet();
	return true;
	}
bool CSpidar::AfterCalib()
	{
	return true;
	}
bool CSpidar::Calib()
	{
	//	�|�C���^�����_(���S)�ɒu���āA�L�����u���[�V�������s��
	v3Emu = Vec3();
	Clear();
	MinForceSet();
	int i;
	for(i=0; i<4; i++)
		encoder[i].Length(motor[i].pos.Size());
	Pos(Vec3());
	MinForceSet();
//	if (AfxMessageBox("SPIDAR���g���܂���?", MB_YESNO) == IDNO) return false;
//S	return driver != NULL;
	return true;
	}
Vec3 CSpidar::GetPos()
	{
	if (bInitialized)
		{
		REAL len[4];
		for(int i=0; i<4; i++) len[i]=encoder[i].Length();
//		TRACE("len = %1.3f, %1.3f, %1.3f, %1.3f\n", len[0], len[1], len[2], len[3]);
		Vec3 rtv = matPos * (
			Vec3(	Square(len[0])-Square(len[1]),
				Square(len[1])-Square(len[2]),
				Square(len[2])-Square(len[3])	) + posSqrConst);
		return rtv;
		}
	else
		{
		return CForceDev3::GetPos();
		}
	}
REAL CSpidar::AvailableForce(int disable, Vec3& f, Vec3* v3Str)
	{
	Vec3 fOrg = f;
	Vec3 e[3];
	REAL l[3];
	int i,j=0;
	for(i=0; i<4; i++)
		{
		if (i==disable) continue;
		e[j] = v3Str[i];
		l[j] = motor[i].MaxForce();
		j++;
		}
	REAL det = CMatrix3(e[0], e[1], e[2]).Det();
	for(i=0; i<3; i++)
		{
		Vec3 n1 = (e[(i+1)%3] ^ e[(i+2)%3]).Unit();
		REAL inp1 = n1*e[i];
		if (inp1 < 0)
			{
			n1 = -n1;
			inp1 = -inp1;
			}
		//	�͂ݏo��������؂藎�Ƃ�
		REAL dist1 = f*n1;
		REAL move1;
		if (dist1 > inp1 * l[i]) move1 = dist1 - inp1*l[i];
		else if (dist1 >= 0) continue;	//	�͂ݏo���ĂȂ���Ύ��̎���
		else move1 = dist1;
		f = f - move1*n1;
		dist1 -= move1;
		for(int j=0; j<3; j++)
			{
			if (j==i) continue;
			Vec3 n2 = (e[(j+1)%3] ^ e[(j+2)%3]).Unit();
			REAL inp2 = n2*e[j];
			if (inp2 < 0)
				{
				n2 = -n2;
				inp2 = -inp2;
				}
			REAL dist2 = f*n2;
			REAL move2;
			if (dist2 > inp2*l[j]) move2 =dist2 - inp2*l[j];
			else if (dist2 >= 0) continue;
			else move2 = dist2;
			f = f - move2 * (n2-(n2*n1)*n1) / (1-Square(n1*n2));
			for(int k=0; k<3; k++)
				{
				if (i==k) continue;
				if (j==k) continue;
				Vec3 n3 = (e[(k+1)%3] ^ e[(k+2)%3]).Unit();
				REAL inp3 = n3*e[k];
				if (inp3 < 0)
					{
					n3 = -n3;
					inp3 = -inp3;
					}
				REAL dist3 = f*n3;
				if (0<=dist3 && dist3<=inp3*l[k]) break;
				//	���ׂĂ͂ݏo���Ă���
				f = (dist1>0 ? e[i]*l[i] : Vec3()) + 
					(dist2>0 ? e[j]*l[j] : Vec3()) + 
					(dist3>0 ? e[k]*l[k] : Vec3());
				break;
				}
			break;
			}
		break;
		}
//11.20	REAL eval = ((fOrg - f).Square() / fOrg.Square()) - det*det*0.1;
	REAL eval = ((fOrg - f).Square() / fOrg.Square()) + 0.2/ABS(det);	//11.20
	//	eval=�]���l:�ڕW�̗͂ɋ߂��Adet���傫�������ǂ�
	return eval;
	}
Vec3 CSpidar::SetForce(const Vec3& f)
	{
	int i;
	Vec3 v3Str[4];							//	�|�C���^���猩�����̌����̒P�ʃx�N�g��
	for (i=0; i<4; i++) v3Str[i] = (motor[i].pos-realPos[0]).Unit();
	REAL minErr = 1E20f;
	int minDisable = 0;
	static int lastDisable;
	Vec3 avf[4];
	for (i=0; i<4; i++)
		{
		avf[i] = f;
		REAL err = AvailableForce(i, avf[i], v3Str);
//		if (i==lastDisable)	err -= 0.4f;
		if (err < minErr)
			{
			minErr = err;
			minDisable = i;
			}
		}
	lastDisable = minDisable;
	int sel[3];
	for(i=0; i<3; i++) sel[i] = (minDisable+1+i)%4;
	Vec3 force = avf[minDisable];
	CMatrix3 matF = CMatrix3(v3Str[sel[0]], v3Str[sel[1]], v3Str[sel[2]]);
	Vec3 v3Tension = matF.Inv() * force;
	REAL tension[4];
	tension[sel[0]] = v3Tension.x;
	tension[sel[1]] = v3Tension.y;
	tension[sel[2]] = v3Tension.z;
	tension[minDisable] = 0;
	//	���[�^�ɏo�̓g���N��ݒ肷��
	for(i=0; i<4; i++)
		motor[i].Force(tension[i]+motor[i].MinForce());
#if 0
	TRACE("f=(%3.3f,%3.3f,%3.3f) t1=%3.3f t2=%3.3f t3=%3.3f t4=%3.3f\n",
		force.x, force.y, force.z,
		tension[0]+motor[0].MinForce(),
		tension[1]+motor[1].MinForce(),
		tension[2]+motor[2].MinForce(),
		tension[3]+motor[3].MinForce());
#endif
	//	���ۂɏo�͂����͂�Ԃ�
	return force;
	}
void CSpidar::MinForceSet()
	{
	mode = FORCE;
	force = Vec3(0,0,0);
	for(int i=0; i<4; i++) motor[i].Force(motor[i].MinForce());
	}
void CSpidar::WaitMoving()
	{
	while(1)
		{
		Vec3 pos1 = GetPos();
		Sleep(100);
		Vec3 pos2 = GetPos();
		if (pos1 == pos2) break;
		}
	}
void CSpidar::GoHomePos()
	{
	MinForceSet();
	motor[0].Force(motor[0].MinForce()*20);
	WaitMoving();
	motor[0].Force(motor[0].MinForce()*3);
	}

void CSpidar::InitMat()
	{
	matPos = 2*CMatrix3(
					motor[1].pos-motor[0].pos,
					motor[2].pos-motor[1].pos,
					motor[3].pos-motor[2].pos).Trans();
	matPos = matPos.Inv();

	posSqrConst = Vec3(	motor[1].pos.Square()-motor[0].pos.Square(),
						motor[2].pos.Square()-motor[1].pos.Square(),
						motor[3].pos.Square()-motor[2].pos.Square());
	}
