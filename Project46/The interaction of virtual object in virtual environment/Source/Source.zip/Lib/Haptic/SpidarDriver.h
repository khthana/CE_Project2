#ifndef HAPTIC_SPIDARDRIVER_H
#define HAPTIC_SPIDARDRIVER_H
//	SPIDAR�̃h���C�o�̊�{�N���X
//	���ۂɓ��o�͂��s�Ȃ��Ă���̂� XXXXDriver.cpp

#include <Haptic/Haptic.h>

#define	CLOCK		1 //	counter�̉�]����(���v����𐳂ɂ���ꍇ)
#define CONTRCLK	0 //	counter�̉�]����(���v����𕉂ɂ���ꍇ)
#define DAvaluePerVolt 409.6

/*
//----------------------------------------------------------------------------
//	CDriverBase
//
struct CSpidarDrivers;
struct DLLCLASS CDriverBase
	{
	bool bInitalized;
	bool bUse;
	CSpidarDrivers* drivers;
	CDriverBase();
	virtual ~CDriverBase();
	virtual bool Init();
	virtual void Da(int ch, REAL volt)=0;
	virtual long Count(int ch)=0;
	virtual void Count(int ch, long n)=0;
	virtual const char* Name()=0;
	};
struct DLLCLASS CSpidarDrivers: public NAMESPACE_HASE__ PArray<CDriverBase>
	{
	bool bInitalized;
	CSpidarDrivers();
	void Init();
	CDriverBase* Rent();
	void Return(CDriverBase* drv);
	void Add(CDriverBase* drv);
	};
*/

//----------------------------------------------------------------------------
//	CSpidarMotor
//
class DLLCLASS CSpidarMotor 
	{
	protected:
	int daChannel;
	REAL maxForce;
	REAL minForce;
	REAL voltPerNewton;
	//CDriverBase* driver;
	int daAddress;
	REAL daValuePerNewton;

	public:
	Vec3 pos;
	CSpidarMotor();
	~CSpidarMotor();
	//void Set(CDriverBase* drv, int ch, REAL VoltPerNewton, REAL min, REAL max);
	void Set(int daAdr, int daCh, REAL VoltPerNewton, REAL min, REAL max);
	int Init();
	int DaAddr(){return daAddress;}
	int Force(REAL f);
	void DaChannel(int daChannel);
	int DaChannel(){return daChannel;}
 	REAL MinForce(){return minForce;}
	void MinForce(REAL mf);
	REAL MaxForce(){return maxForce;}
	void MaxForce(REAL mf);
	void VoltPerNewton(REAL vpn);
	REAL VoltPerNewton();
	int Volt(REAL);
	int DaOut(int);
	};
//----------------------------------------------------------------------------
//	CSpidarEncoder
//
class DLLCLASS CSpidarEncoder 
	{
	protected:
	REAL lengthPerPulse;
	int ctChannel;
	//CDriverBase* driver;
	int ctAddress;
	int direction;

	public:
	CSpidarEncoder();
	//void Set(CDriverBase* drv, int ch, REAL lpp);
	void Set(int ctAdr, int ctCh, int dir, REAL lpp);
	int Init();
	int CtAddr(){return ctAddress;}
	void CtChannel(int ctChannel);
	int CtChannel(){return ctChannel;}
	void LenPerPulse(REAL lpp);
	REAL LenPerPulse();
	int Length(REAL);
	REAL Length();
	int Count(long);
	long Count();
	bool Exist();
	};

#endif
