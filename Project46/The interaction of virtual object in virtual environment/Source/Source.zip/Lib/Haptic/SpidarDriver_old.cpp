#include <conio.h>
#include "Haptic/SpidarDriver.h"
//----------------------------------------------------------------------------
//	CDriverBase
//
CDriverBase::CDriverBase()
	{
	bInitalized = false;
	bUse = false;
	}
CDriverBase::~CDriverBase()
	{
	}
bool CDriverBase::Init()
	{
	bInitalized = true;
	return true;
	}
//----------------------------------------------------------------------------
//	CSpidarDrivers
//
CSpidarDrivers::CSpidarDrivers()
	{
	bInitalized = false;
	}
extern void InitPCCardDriver(CSpidarDrivers& sd);
extern void InitContecIsaDriver(CSpidarDrivers& sd);
void CSpidarDrivers::Init()
	{
	Clear();	
	InitPCCardDriver(*this);
	InitContecIsaDriver(*this);
	//	�J�[�h�̌����Ə�����
	for(int i=0; i<Size(); i++) Bgn()[i]->Init();
	bInitalized = true;
	}
CDriverBase* CSpidarDrivers::Rent()
	{
	for(int i=0; i<Size(); i++)
		{
		if (Bgn()[i]->bInitalized && !Bgn()[i]->bUse)
			{
			Bgn()[i]->bUse = true;
			return Bgn()[i];
			}
		}
	return NULL;
	}
void CSpidarDrivers::Add(CDriverBase* drv)
	{
	PArray<CDriverBase>::Add(drv);
	drv->drivers = this;
	}
void CSpidarDrivers::Return(CDriverBase* drv)
	{
	It it = Find(drv);
	if (it) (*it)->bUse = false;
	}
//----------------------------------------------------------------------------
//	CSpidarEncoder
//
CSpidarEncoder::CSpidarEncoder() 
	{
	driver = NULL;
	}
void CSpidarEncoder::Set(CDriverBase* drv, int ch, REAL lpp) 
	{
	driver=drv;
	channel=ch;
	lengthPerPulse=lpp;
	}
void CSpidarEncoder::Channel(int ch)
	{
	channel = ch;
	}
void CSpidarEncoder::LenPerPulse(REAL lpp)
	{
	lengthPerPulse=lpp;
	}
REAL CSpidarEncoder::LenPerPulse()
	{
	return lengthPerPulse;
	}
//	���݂̎��̒�����n�Ƃ���
void CSpidarEncoder::Length(REAL n)
	{
	if (driver) driver->Count(channel, (long)(n/lengthPerPulse));
	}
REAL CSpidarEncoder::Length()
	{
	if (!driver) return 0;
	return driver->Count(channel)*lengthPerPulse;
	}

//----------------------------------------------------------------------------
//	CSpidarMotor
//
CSpidarMotor::CSpidarMotor()
	{
	channel=0;
	voltPerNewton = 1.0f;
	minForce=0.1f;
	maxForce=10;
	driver = NULL;
	}
CSpidarMotor::~CSpidarMotor()
	{
	Force(minForce);
	}
void CSpidarMotor::Set(CDriverBase* drv, int ch, REAL vpn, REAL min, REAL max)
	{
	driver = drv;
	channel=ch;
	voltPerNewton = vpn;
	minForce=min;
	maxForce=max;
	}
void CSpidarMotor::VoltPerNewton(REAL vpn)
	{
	voltPerNewton = vpn;
	}
REAL CSpidarMotor::VoltPerNewton()
	{
	return voltPerNewton;
	}
void CSpidarMotor::MinForce(REAL mf)
	{
	minForce = mf;
	}
void CSpidarMotor::MaxForce(REAL mf)
	{
	maxForce = mf;
	}
void CSpidarMotor::Channel(int ch)
	{
	channel = ch;
	}
void CSpidarMotor::Force(REAL f)
	{
	if (f>maxForce) f=maxForce;
	else if (f<minForce) f=minForce;
	if (!driver) return;
	driver->Da(channel, f*voltPerNewton);
	}
