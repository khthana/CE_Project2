//	PCCard��p�����X�p�C�_�[�V�X�e���̃h���C�o
#include "Hase/Misc/Inc.h"
#include <conio.h>
#include "Haptic/SpidarDriver.h"
#include "Haptic/Upp.h"

#define DA_ZERO 2048	//	0V���o�����߂�D/A�ɏ������ޒl
#define DA_VPV	409.6f	//	D/A�ɏ������ޒl / �o�͓d��

//	#define USE_DRIVER_IMPORT_LIB
//	�C���|�[�g���C�u�������������ALoadLibrary�Ń��[�h���邩�̑I��
//	�C���|�[�g���C�u�������g�p�����DLL���Ȃ��ꍇ�ɓ��삵�Ȃ��v���O����
//	�ɂȂ�̂Œʏ��LoadLibrary���g�p����B
#ifdef USE_DRIVER_IMPORT_LIB
#include <Haptic/RatocUpp/UppLib32/UppLib32.h>
#include <C:/CB32/cwin/cbw.h>
#else
#define BOARDNAMELEN	50
extern	"C"	{
	//	Ratoc UPP driver
	BOOL (APIENTRY *UppGetCardResource) (HWND, WORD, LPWORD, LPWORD) = NULL;
	void (APIENTRY *OutUpp)(WORD, WORD, BYTE) = NULL;
	WORD (APIENTRY *InUpp)(WORD, WORD) = NULL;
	//	ComputerBoards D/A driver
    int (__stdcall *cbAOut)(int BoardNum, int Chan, int Gain, USHORT DataValue) = NULL;
    int (__stdcall *cbDIn)(int BoardNum, int port, int* DataValue) = NULL;
    int (__stdcall *cbGetBoardName)(int BoardNum, char *BoardName) = NULL;
	}
static bool bLoaded = false;
static bool bFirstLoad = true;
static bool LoadDll()
	{
	if (bLoaded) return true;
	if (!UppGetCardResource || !OutUpp || !InUpp)
		{
		char* libName = "UPPLib32.DLL";
		HINSTANCE hi = LoadLibrary(libName);
		if (hi)
			{
			TRACE("\'%s\' is loaded.\n", libName);
			*(void**)&UppGetCardResource = GetProcAddress(hi, "UppGetCardResource");
			*(void**)&OutUpp = GetProcAddress(hi, "OutUpp");
			*(void**)&InUpp = GetProcAddress(hi, "InUpp");
			}
		else if (bFirstLoad) TRACE("Could not load \'%s\'.\n", libName);
		}
	if (!cbAOut || !cbGetBoardName || !cbDIn)
		{
		char* libName = "CBW32.DLL";
		HINSTANCE hi = LoadLibrary(libName);
		if (hi)
			{
			TRACE("\'%s\' is loaded.\n", libName);
			*(void**)&cbAOut = GetProcAddress(hi, "cbAOut");
			*(void**)&cbDIn = GetProcAddress(hi, "cbDIn");
			*(void**)&cbGetBoardName = GetProcAddress(hi, "cbGetBoardName");
			}
		else if (bFirstLoad) TRACE("Could not load \'%s\'.\n", libName);
		}
	bFirstLoad = false;
	if (UppGetCardResource && OutUpp && InUpp && cbAOut && cbDIn && cbGetBoardName)
		{
		bLoaded = true;
		return true;
		}
	return false;
	}
#endif
//----------------------------------------------------------------------------
//	CRatocUppCard
//
class CRatocUppCard:public CUpp, public NAMESPACE_HASE__ CRefCount
	{
	protected:
	enum {SLOTMAX=8};
	int slot;		//	�J�[�h���h�����Ă���X���b�g�̔ԍ�
	int cardNum;	//	�J�[�h�������Ɍ��������J�[�h�̂���
					//	cardNum���ڂ��g���B
	WORD address;
	WORD irq;
	public:
	CRatocUppCard(int cdnum);
	~CRatocUppCard();
	bool Init();
	void Out(unsigned a, unsigned v);
	int	 In(unsigned a);
	};
CRatocUppCard::CRatocUppCard(int cn)
	{
	cardNum = cn;
	slot = -1;
	}
CRatocUppCard::~CRatocUppCard()
	{
	}
bool CRatocUppCard::Init()
	{
#ifndef USE_DRIVER_IMPORT_LIB
	if (!LoadDll()) return false;
#endif
	//	�J�[�h�̌���
	int find = -1;
	for(slot=0; slot<SLOTMAX; slot++)
		{
		if (UppGetCardResource(AfxGetMainWnd()->m_hWnd, slot, &address, &irq) == 0)
			{
			find ++;
			if (find == cardNum) break;
			}
		}
	if (find <cardNum)
		{
		slot = -1;
		TRACE("Could not find #%d Ratoc UPP card\n", cardNum);
		return false;
		}
	TRACE("#%d Ratoc UPP card was found at slot%d address0x%x\n", cardNum, slot, address);
	//	�@�\�̐ݒ�
	CUpp::Init();
	for(int i=0; i<8; i++)
		{
		int p = i*2;	//	A���̓��͒[�q�ԍ�
		int q = i*2+1;	//	B���̓��͒[�q�ԍ�
		//	UPP�̋@�\�̐ݒ�
		//	CUppFunc(�G���R�[�_�t�J�E���g, ���W�X�^i�ɃJ�E���g�l���i�[, �s�g�p, �����オ��+������+�[�qp, �����オ��+������+�[�qq, �[�qp, �[�qq)
		Add(CUppFunc(CUppFunc::TPC+0x4, i, 0xFF, 0x60+p, 0x60+q, p, q));
		}
	//	UPP�����s��Ԃɂ���
	Run(1);
	return true;
	}
void CRatocUppCard::Out(unsigned a, unsigned v)
	{
	OutUpp(address, a, v);
	}
int	 CRatocUppCard::In(unsigned a)
	{
	return InUpp(address, a);
	}
//----------------------------------------------------------------------------
//	CComputerBoardsDa
//
class DLLCLASS CComputerBoardsDa: public NAMESPACE_HASE__ CRefCount
	{
	protected:
	int cardNum;	//	�J�[�h�������Ɍ��������J�[�h�̂���
					//	cardNum���ڂ��g���B
	int board;		//	ComputerBoards�̃{�[�h�ԍ�
	public:
	CComputerBoardsDa(int cdNum);
	~CComputerBoardsDa();
	bool Init();
	void Out(int ch, REAL volt);
	int DIn(int port);
	};
CComputerBoardsDa::CComputerBoardsDa(int cdNum)
	{
	cardNum = cdNum;
	board = -1;
	}
CComputerBoardsDa::~CComputerBoardsDa()
	{
	}
bool CComputerBoardsDa::Init()
	{
#ifndef USE_DRIVER_IMPORT_LIB
	if (!LoadDll()) return false;
#endif
	//	�J�[�h�̌���
	int find = -1;
	char name[BOARDNAMELEN];
	ZeroMemory(name, sizeof(name));
	for(board=0; board<10; board++)
		{
		cbGetBoardName(board, name);
		if (strcmp(name, "PCM-DAC08") == 0)
			{
			int err = cbAOut(board, 0, 0, DA_ZERO);
			if (err == 0)
				{
				for(int k=0; k<8; k++) cbAOut(board, k, 0, DA_ZERO);
				find ++;
				if (find == cardNum) break;
				}
			}
		}
	if (find <cardNum)
		{
		board = -1;
		TRACE("Could not find #%d ComputerBoards PCM-DAC08 card\n", cardNum);
		return false;
		}
	TRACE("#%d ComputerBoards PCM-DAC08 was found at board%d\n", cardNum, board);
	for(int i=0; i<8; i++) Out(i, 0);
	return true;
	}
void CComputerBoardsDa::Out(int ch, REAL volt)
	{
	DWORD val = volt * DA_VPV + DA_ZERO;
	if (val > 4096) val = 4096;
	cbAOut(board, ch, 0, val);
	}
int CComputerBoardsDa::DIn(int port)
	{
	if (port > 7) port = 7;
	if (port < 0) port = 0;
	int val=-1;
	int err = cbDIn(board, port<4 ? 10 : 11, &val);
	if (err) TRACE("err=%d port=%d\n", err, port);
	return (val & (0x00000001 << (port%4))) != 0;
	}
//----------------------------------------------------------------------------
//	CPCCardDriver
//
class DLLCLASS CPCCardDriver: public CDriverBase
	{
	CRatocUppCard* upp;
	CComputerBoardsDa* da;
	int cardNum;
	int portBase;
	int channelBase;
	int count[8];
	public:
	CPCCardDriver(int cardNo, int chBase, int portBase);
	~CPCCardDriver();
	//	cardNo:�����ڂ̃J�[�h���g����, chBase: 0�Ԗڂ̃��[�^���g��DA,Encoder�̃`�����l��
	//	PCCard�́A�ړI�̃J�[�h���X���b�g�Ɏh�����Ă��邩�ǂ����m�F�ł���B
	//	�X���b�g0���猟�����čŏ��Ɍ��������J�[�h��0���ځA����1����...�ƂȂ�B
	bool Init();
	void InitUpp();
	void InitDa();
	void Da(int ch, REAL volt);
	int DIn(int port);
	long Count(int ch);
	void Count(int ch, long n);
	const char* Name();
	};
CPCCardDriver::CPCCardDriver(int cn, int cb, int pb)
	{
	cardNum = cn;
	channelBase = cb;
	portBase = pb;
	upp = NULL;
	da = NULL;
	for(int i=0; i<8; i++) count[i] = 0;
	}
CPCCardDriver::~CPCCardDriver()
	{
	if (upp) upp->Release();
	upp = NULL;
	if (da) da->Release();
	da = NULL;
	}
const char* CPCCardDriver::Name()
	{
	return "PCCard";
	}
void CPCCardDriver::InitUpp()
	{
	if (upp) return;
	for(int i=0;i<drivers->Size(); i++)
		{
		if ((*drivers)[i] == this) continue;
		if ((*drivers)[i]->Name() != Name()) continue;
		CPCCardDriver& ref = *(CPCCardDriver*)((*drivers)[i]);
		if (ref.cardNum != cardNum) continue;
		ASSERT(ref.channelBase != channelBase);
		if (ref.upp)
			{
			upp = ref.upp;
			upp->AddRef();
			}
		}
	if (!upp)
		{
		upp = new CRatocUppCard(cardNum);
		if (!upp->Init())
			{
			upp->Release();
			upp = NULL;
			}
		}
	}
void CPCCardDriver::InitDa()
	{
	if (da) return;
	for(int i=0;i<drivers->Size(); i++)
		{
		if ((*drivers)[i] == this) continue;
		if ((*drivers)[i]->Name() != Name()) continue;
		CPCCardDriver& ref = *(CPCCardDriver*)((*drivers)[i]);
		if (ref.cardNum != cardNum) continue;
		ASSERT(ref.channelBase != channelBase);
		if (ref.da)
			{
			da = ref.da;
			da->AddRef();
			}
		}
	if (!da)
		{
		da = new CComputerBoardsDa(cardNum);
		if (!da->Init())
			{
			da->Release();
			da = NULL;
			}
		}
	}
bool CPCCardDriver::Init()
	{
	InitUpp();
	InitDa();
	if (!upp || !da) return false;
	CDriverBase::Init();
	return true;
	}
void CPCCardDriver::Da(int ch, REAL volt)
	{
	ch += channelBase;
	if(da) da->Out(ch, volt);
	}
int CPCCardDriver::DIn(int port)
	{
	port += portBase;
	if(da) return da->DIn(port);
	return 0;
	}
long CPCCardDriver::Count(int ch)
	{
	ch += channelBase;
	if (upp)
		{
		long delta = ((long)(upp->UdrRead(ch))-count[ch])&0x0000FFFF;
		if (delta < 0x00008000) count[ch] += delta;
		else count[ch] += (delta-0x00010000);
		}
	return count[ch];
	}
void CPCCardDriver::Count(int ch, long n)
	{
	ch += channelBase;
	count[ch] = n;
	if (upp) upp->UdrWrite(ch, (DWORD)n & 0x0000FFFF);
	}
void InitPCCardDriver(CSpidarDrivers& sd)
	{
	//	PC�J�[�h4��
	sd.Add(new CPCCardDriver(0, 0, 0));
	sd.Add(new CPCCardDriver(0, 4, 2));
//	sd.Add(new CPCCardDriver(1, 0, 0));
//	sd.Add(new CPCCardDriver(1, 4, 2));
	}
