#ifndef HAPTIC_SPIDARDRIVER_H
#define HAPTIC_SPIDARDRIVER_H
//	SPIDAR�̃h���C�o�̊�{�N���X
//	���ۂɓ��o�͂��s�Ȃ��Ă���̂� XXXXDriver.cpp

#include <Haptic/Haptic.h>

#define	CLOCK		1 //	counter�̉�]����(���v����𐳂ɂ���ꍇ)
#define CONTRCLK	0 //	counter�̉�]����(���v����𕉂ɂ���ꍇ)
#define DAvaluePerVolt 409.6

//----------------------------------------------------------------------------
//	CDriverBase
//
struct CSpidarDrivers;
struct DLLCLASS CDriverBase
	{
	bool bInitalized;
	bool bUse;
	CSpidarDrivers* drivers;
	CDriverBase();
	virtual ~CDriverBase();
	virtual bool Init();
	virtual void Da(int ch, REAL volt)=0;
	virtual int DIn(int port)=0;
	virtual long Count(int ch)=0;
	virtual void Count(int ch, long n)=0;
	virtual const char* Name()=0;
	};
struct DLLCLASS CSpidarDrivers: public NAMESPACE_HASE__ PArray<CDriverBase>
	{
	bool bInitalized;
	CSpidarDrivers();
	void Init();
	CDriverBase* Rent();
	void Return(CDriverBase* drv);
	void Add(CDriverBase* drv);
	};
//----------------------------------------------------------------------------
//	CSpidarMotor
//
class DLLCLASS CSpidarMotor 
	{
	protected:
	int channel;
	REAL maxForce;
	REAL minForce;
	REAL voltPerNewton;
	CDriverBase* driver;

	public:
	Vec3 pos;
	CSpidarMotor();
	~CSpidarMotor();
	void Set(CDriverBase* drv, int ch, REAL VoltPerNewton, REAL min, REAL max);
	void Force(REAL f);
	
	void Channel(int ch);
	int Channel(){return channel;}
 	REAL MinForce(){return minForce;}
	void MinForce(REAL mf);
	REAL MaxForce(){return maxForce;}
	void MaxForce(REAL mf);
	void VoltPerNewton(REAL vpn);
	REAL VoltPerNewton();
	};
//----------------------------------------------------------------------------
//	CSpidarEncoder
//
class DLLCLASS CSpidarEncoder 
	{
	protected:
	REAL lengthPerPulse;
	int channel;
	CDriverBase* driver;

	public:
	CSpidarEncoder();
	void Set(CDriverBase* drv, int ch, REAL lpp);
	void Channel(int ch);
	int Channel(){return channel;}
	void LenPerPulse(REAL lpp);
	REAL LenPerPulse();
	void Length(REAL);
	REAL Length();
	};

#endif
