#include "Hase/DDraw/HDDSurf.h"
#include "Hase/DDraw/HDDraw.h"
#pragma hdrstop
BEGIN_NAMESPACE_HASE
//----------------------------------------------------------------------------
//	CDDSurfaceBase
//
void CDDSurfaceBase::DDraw(CDDraw& dd)
	{
	if (pCDD==&dd) return;
	Release();
	pCDD=&dd;
	}
//----------------------------------------------------------------------------
//	CDDSurfaceDesc
//
void CDDSurfaceDesc::Calc()
	{
	bitPerPixel=0;
	bytePerPixel=0;
	pixelPerByte=0;
	if (ddpfPixelFormat.dwFlags & DDPF_RGB)
		{
		bitPerPixel = ddpfPixelFormat.dwRGBBitCount;
		bytePerPixel = (ddpfPixelFormat.dwRGBBitCount+7) / 8;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_YUV)
		{
		bitPerPixel = ddpfPixelFormat.dwYUVBitCount;
		bytePerPixel = (ddpfPixelFormat.dwYUVBitCount+7) / 8;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED1)
		{
		bitPerPixel = 1;
		pixelPerByte = 8;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED2)
		{
		bitPerPixel = 2;
		pixelPerByte = 4;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED4)
		{
		bitPerPixel = 4;
		pixelPerByte = 2;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXED8)
		{
		bitPerPixel = 8;
		pixelPerByte = 1;
		bytePerPixel = 1;
		}
	else if (ddpfPixelFormat.dwFlags & DDPF_PALETTEINDEXEDTO8)
		{
		bitPerPixel = 8;
		pixelPerByte = 1;
		bytePerPixel = 1;
		}
	szLock.cx = rcLock.right - rcLock.left;
	szLock.cy = rcLock.bottom - rcLock.top;
	lineLen = szLock.cx * bytePerPixel;
	if (lineLen == 0 && pixelPerByte) lineLen = (szLock.cx+pixelPerByte-1) / pixelPerByte;
	}

CDDSurfaceDesc::CDDSurfaceDesc()
	{
	Clear();
	}
CDDSurfaceDesc::CDDSurfaceDesc(const DDSURFACEDESC& desc)
	{
	Clear();
	DDSURFACEDESC* pDesc = this;
	memcpy(pDesc, &desc, sizeof(DDSURFACEDESC));
	Calc();
	}
void CDDSurfaceDesc::Clear()
	{
	DDSURFACEDESC* pDesc = this;
	memset(pDesc, 0, sizeof(DDSURFACEDESC));
	dwSize = sizeof(DDSURFACEDESC);
	bLock = false;
	bytePerPixel = 0;
	pixelPerByte = 0;
	bitPerPixel = 0;
	lineLen = 0;
	memset(&rcLock, 0, sizeof(rcLock));
	memset(&szLock, 0, sizeof(szLock));
	}
SIZE CDDSurfaceDesc::Size() const
	{
	SIZE sz;
	sz.cx = dwWidth;
	sz.cy = dwHeight;
	return sz;
	}
void CDDSurfaceDesc::Size(const SIZE& sz)
	{
	dwWidth = sz.cx;
	dwHeight = sz.cy;
	dwFlags |= DDSD_WIDTH | DDSD_HEIGHT;
	}
void CDDSurfaceDesc::Caps(DWORD caps)
	{
	ddsCaps.dwCaps = caps;
	dwFlags |= DDSD_CAPS;
	}
DWORD CDDSurfaceDesc::Caps()
	{
	if (dwFlags & DDSD_CAPS) return ddsCaps.dwCaps;
	return 0;
	}
//----------------------------------------------------------------------------
//	CDDSInterface
//
CDDSInterface::CDDSInterface()
	{
	pDDS = NULL;
	pDDS2 = NULL;
#if DIRECTDRAW_VERSION >= 0x0500
	pDDS3 = NULL;
#endif
	}
CDDSInterface::CDDSInterface(const CDDSInterface& cidds)
	{
	pDDS=cidds.pDDS;
	if (pDDS) pDDS->AddRef();
	pDDS2=cidds.pDDS2;
	if (pDDS2) pDDS2->AddRef();
#if DIRECTDRAW_VERSION >= 0x0500
	pDDS3=cidds.pDDS3;
	if (pDDS3) pDDS3->AddRef();
#endif
	}
CDDSInterface CDDSInterface::operator =(const CDDSInterface& cidds)
	{
	Release();
	pDDS=cidds.pDDS;
	if (pDDS) pDDS->AddRef();
	pDDS2=cidds.pDDS2;
	if (pDDS2) pDDS2->AddRef();
#if DIRECTDRAW_VERSION >= 0x0500
	pDDS3=cidds.pDDS3;
	if (pDDS3) pDDS3->AddRef();
#endif
	return *this;
	}
void CDDSInterface::Release()
	{
	RELEASE(pDDS);
	RELEASE(pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	RELEASE(pDDS3);
#endif
	}
CDDSInterface::~CDDSInterface()
	{
	Release();
	}
//----------------------------------------------------------------------------
//	CDDSurface
//
CDDSurface::CDDSurface()
	{
	pCDD = NULL;
	hDC = NULL;
	bCallDeleteCallbacks = true;
	}
CDDSurface::~CDDSurface()
	{
	Release();
	if (bCallDeleteCallbacks)
		{
		bCallDeleteCallbacks = false;
		deleteCallbacks.Call(*this);
		}
	}
bool CDDSurface::Create(bool bCallCallback)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	//	Backup original surface desc.
	descOld = desc;
	//	check ddraw
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (!pCDD->pDDraw && !pCDD->Create()) goto leave;
	//	Create surface
	if (pCDD->CKDDERR(pCDD->pDDraw->CreateSurface(&desc, &pDDS, NULL)))goto leave;
	pDDS->QueryInterface(IID_IDirectDrawSurface2, (void**)&pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	pDDS->QueryInterface(IID_IDirectDrawSurface3, (void**)&pDDS3);
#endif
	//	get surface description
	pDDS->GetSurfaceDesc(&desc);
	desc.Calc();
	//	set palette
	if (desc.ddpfPixelFormat.dwFlags&DDPF_PALETTEINDEXED8) 
		{
		if (!pCDD->CreatePalette()) goto leave;
		if (pCDD->CKDDERR(pDDS->SetPalette(pCDD->pPalette))) goto leave;
		}
	//	call create callbacks
	if (bCallCallback) createCallbacks.Call(*this);
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	desc = descOld;
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CDDSurface::Release(bool bCallCallback)
	{
	if (!pDDS) return;
	CDD_ENTER_CRITICAL;
	ReleaseDC();
	Unlock();
	if (bCallCallback) releaseCallbacks.Call(*this);
	desc = descOld;
	CDDSInterface::Release();
	CDD_LEAVE_CRITICAL;
	}

bool CDDSurface::Blt(CDDSurface& surf, DWORD flags)
	{
	POINT pt={0,0};
	SIZE sz={0xFFFFFFFF, 0xFFFFFFFF};
	return Blt(surf, pt, sz, flags);
	}
bool CDDSurface::Blt(CDDSurface& surf, POINT dest, SIZE sz, DWORD flags)
	{
	POINT pt={0,0};
	return Blt(surf, dest, sz, pt, flags);
	}
bool CDDSurface::Blt(CDDSurface& surf, POINT dest, SIZE sz, POINT src, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (sz.cx == -1)
		{
		sz = Size();
		SIZE szSrc = surf.Size();
		sz.cx = std::min(sz.cx, szSrc.cx);
		sz.cy = std::min(sz.cy, szSrc.cy);
		}
	RECT rcDest;
	rcDest.left = dest.x;
	rcDest.top = dest.y;
	rcDest.right = dest.x + sz.cx;
	rcDest.bottom = dest.y + sz.cy;
	RECT rcSrc;
	rcSrc.left = src.x;
	rcSrc.top = src.y;
	rcSrc.right = src.x + sz.cx;
	rcSrc.bottom = src.y + sz.cy;
	if (IsLost()) Restore();
	bool rtv = !pCDD->CKDDERR(pDDS->Blt(&rcDest, surf.pDDS, &rcSrc, flags, NULL));
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CDDSurface::Clear(DWORD color,DWORD flags)
	{
	POINT pt={0,0};
	SIZE sz={0xFFFFFFFF,0xFFFFFFFF};
	return Clear(pt, sz, color, flags);
	}
bool CDDSurface::Clear(POINT dest, SIZE sz, DWORD color, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	bool rtv = false;
	if (IsLost() && !Restore()) goto leave;
	if (sz.cx == -1) sz = Size();
	RECT rcDest;
	rcDest.left = dest.x;
	rcDest.top = dest.y;
	rcDest.right = dest.x + sz.cx;
	rcDest.bottom = dest.y + sz.cy;
	DDBLTFX bltFx;
	memset(&bltFx, 0, sizeof(bltFx));
	bltFx.dwSize = sizeof(bltFx);
	bltFx.dwFillColor = color;
	rtv = !pCDD->CKDDERR(pDDS->Blt(&rcDest, NULL, NULL, DDBLT_COLORFILL|flags, &bltFx));
leave:
	CDD_LEAVE_CRITICAL;
	return rtv;
	}

bool CDDSurface::Lock(POINT pt, SIZE sz)
	{
	CDD_ENTER_CRITICAL;
	if (desc.bLock) goto leave;
	if (IsLost() && !Restore()) goto leave;
	//	rect to lock
	if (pt.x > (int)desc.dwWidth) desc.rcLock.left = desc.dwWidth;
	else desc.rcLock.left = pt.x;
	if (pt.y > (int)desc.dwHeight) desc.rcLock.top = desc.dwHeight;
	else desc.rcLock.top = pt.y;
	if (sz.cx<0 || pt.x+sz.cx>(int)desc.dwWidth) desc.rcLock.right = desc.dwWidth;
	else desc.rcLock.right = pt.x + sz.cx;
	if (sz.cy<0 || pt.y+sz.cy>(int)desc.dwHeight) desc.rcLock.bottom = desc.dwHeight;
	else desc.rcLock.bottom = pt.y + sz.cy;
	if (!pCDD->CKDDERR(pDDS->Lock(&desc.rcLock, &desc, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT, NULL)))
		{
		desc.Calc();
		desc.bLock = true;
		}
leave:
	CDD_LEAVE_CRITICAL;
	return desc.bLock;
	}
void CDDSurface::Unlock()
	{
	if (!pDDS) return;
	if (!desc.bLock) return;
	pDDS->Unlock(desc.lpSurface);
	desc.bLock = false;
	memset(&desc.rcLock, 0, sizeof(desc.rcLock));
	memset(&desc.szLock, 0, sizeof(desc.szLock));
	desc.Calc();
	CDD_LEAVE_CRITICAL;
	}
HDC CDDSurface::GetDC()
	{
	if (hDC) return hDC;
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return hDC;
	pCDD->CKDDERR(pDDS->GetDC(&hDC));
	return hDC;
	}
void CDDSurface::ReleaseDC()
	{
	if (!hDC) return;
	pCDD->CKDDERR(pDDS->ReleaseDC(hDC));
	hDC = NULL;
	CDD_LEAVE_CRITICAL;
	}
bool CDDSurface::Restore()
	{
	bool rtv = false;
	if (!pDDS) return Create();
	CDD_ENTER_CRITICAL;
  	if (pDDS->IsLost() == DDERR_SURFACELOST)
		{
		HRESULT hr = pDDS->Restore();
		if (hr!=DDERR_OUTOFMEMORY && hr!=DDERR_OUTOFVIDEOMEMORY)
			{
			Release();
			rtv = Create();
			goto leave;
			}
		if (pCDD->CKDDERRMSG(hr, "restore surface failed.")) goto leave;
		}
	rtv = true;
leave:
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CDDSurface::IsLost()
	{
	CDD_ENTER_CRITICAL;
	if (!pDDS || pDDS->IsLost() != DD_OK) return true;
	CDD_LEAVE_CRITICAL;
	return false;
	}
SIZE CDDSurface::Size()
	{
	return desc.Size();
	}
inline int GetMaskLeft(DWORD m)
	{
    int i;
	for(i=0; i<32; i++)
		{
		if (m & 0x80000000) break;
		m <<= 1;
		}
	return 32-i;
	}
inline DWORD MoveToMask(BYTE bCol, DWORD mask)
	{
	DWORD col = bCol;
	int shift = GetMaskLeft(mask)-8;
	if (shift > 0) col <<= shift;
	else col >>= -shift;
	col &= mask;
	return col;
	}
DWORD CDDSurface::ColorToPixel(COLORREF col)
	{
	DDPIXELFORMAT& fmt = desc.ddpfPixelFormat;
	DWORD rtv = 0;
	if (fmt.dwFlags & DDPF_RGB)
		{
		rtv |= MoveToMask(GetRValue(col), fmt.dwRBitMask);
		rtv	|= MoveToMask(GetGValue(col), fmt.dwGBitMask);
		rtv	|= MoveToMask(GetBValue(col), fmt.dwBBitMask);
		}
	else rtv = col;
	return rtv;
	}


//----------------------------------------------------------------------------
//	CWindowManage
//
CWindowManage::CWindowManage()
	{
	pWndPlaceOld = NULL;
	pMainWndPlaceOld = NULL;
	}
CWindowManage::~CWindowManage()
	{
	delete pWndPlaceOld;
	delete pMainWndPlaceOld;
	}
	
static WNDPROC wprocOld;
static LRESULT CALLBACK WpcMinMaxInfo( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
	if (uMsg == WM_GETMINMAXINFO)
		{
		LPMINMAXINFO pmmi = (LPMINMAXINFO) lParam;
		pmmi->ptMaxTrackSize.x = pmmi->ptMaxSize.x * 2;
		pmmi->ptMaxTrackSize.y = pmmi->ptMaxSize.y * 2;
		return 0;
		}
	if (wprocOld) return wprocOld(hwnd, uMsg, wParam, lParam);
	return NULL;
	} 
bool CWindowManage::FitWindow(POINT ptTo, SIZE szTo)
	{
	if (!hWnd)
		{
		CDDraws::GetLastCreate()->Primary().DDERRMSG(2, "This operation needs hWnd.");
		return false;
		}
	CDD_ENTER_CRITICAL;
	HWND hWndParent = hWnd;
	HWND hWndMain;
	while(hWndParent)
		{
		hWndMain = hWndParent;
		hWndParent = GetParent(hWndMain);
		}

	//	set minmaxinfo handler
	if (wprocOld) 
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	wprocOld = (WNDPROC)GetWindowLong(hWndMain, GWL_WNDPROC);
	SetWindowLong(hWndMain, GWL_WNDPROC, (LONG)WpcMinMaxInfo);

	bool rtv = true;
	int i;
	for(i=0; i<4; i++)
		{
		RECT rcClient, rcMain;
		GetWindowRect(hWndMain, &rcMain);
		GetClientRect(hWnd, &rcClient);

		RECT rcScCl;
		POINT pt;
		pt.x = rcClient.left;
		pt.y = rcClient.top;
		::ClientToScreen(hWnd, &pt);
		rcScCl.left		= pt.x;
		rcScCl.top		= pt.y;
		pt.x = rcClient.right;
		pt.y = rcClient.bottom;
		::ClientToScreen(hWnd, &pt);
		rcScCl.right	= pt.x;
		rcScCl.bottom	= pt.y;
		TRACEALL("rcMain (%d,%d) (%d,%d)\n", rcMain.left, rcMain.top, rcMain.right, rcMain.bottom);
		TRACEALL("rcScCl (%d,%d) (%d,%d)\n", rcScCl.left, rcScCl.top, rcScCl.right, rcScCl.bottom);
		
		rcMain.left += ptTo.x - rcScCl.left;
		rcMain.top += ptTo.y - rcScCl.top;
		rcMain.right += szTo.cx - (rcScCl.right - rcScCl.left);
		rcMain.bottom += szTo.cy - (rcScCl.bottom - rcScCl.top);
		MoveWindow(hWndMain, rcMain.left, rcMain.top, rcMain.right-rcMain.left, rcMain.bottom-rcMain.top, false);
		if (rcScCl.left == ptTo.x &&
			rcScCl.top == ptTo.y &&
			rcScCl.right == ptTo.x+szTo.cx &&
			rcScCl.bottom == ptTo.y+szTo.cy) break;
		}	
	if (i==4) rtv = false;
	//	restore handler
	SetWindowLong(hWndMain, GWL_WNDPROC, (LONG)wprocOld);
	wprocOld = NULL;
	CDD_LEAVE_CRITICAL;
	InvalidateRect(hWndMain, NULL, false);
	return rtv;
	}
bool CWindowManage::RestoreWindowPlace()
	{
	if (!hWnd || !pWndPlaceOld || !pMainWndPlaceOld) return false;
	HWND hWndParent = hWnd;
	HWND hWndMain;
	while(hWndParent)
		{
		hWndMain = hWndParent;
		hWndParent = GetParent(hWndMain);
		}
	SetWindowPlacement(hWnd, pWndPlaceOld);
	SetWindowPlacement(hWndMain, pMainWndPlaceOld);
	delete pWndPlaceOld;
	pWndPlaceOld = NULL;
	delete pMainWndPlaceOld;
	pMainWndPlaceOld = NULL;
	return true;
	}
void CWindowManage::SaveWindowPlace()
	{
	if (!hWnd) return;
	HWND hWndParent = hWnd;
	HWND hWndMain;
	while(hWndParent)
		{
		hWndMain = hWndParent;
		hWndParent = GetParent(hWndMain);
		}
	if (!pWndPlaceOld) pWndPlaceOld = new WINDOWPLACEMENT;
	pWndPlaceOld->length = sizeof(WINDOWPLACEMENT);
	GetWindowPlacement(hWnd, pWndPlaceOld);
	if (!pMainWndPlaceOld) pMainWndPlaceOld = new WINDOWPLACEMENT;
	pMainWndPlaceOld->length = sizeof(WINDOWPLACEMENT);
	GetWindowPlacement(hWndMain, pMainWndPlaceOld);
	}
void CWindowManage::ClientToScreen(POINT* pt, SIZE* sz)
	{
	POINT ptClient = *pt;
	::ClientToScreen(hWnd, pt);
	RECT rc;
	::GetClientRect(hWnd, &rc);
	SIZE szMax;
	szMax.cx = rc.right - rc.left - ptClient.x;
	szMax.cy = rc.bottom - rc.top - ptClient.y;
	if (szMax.cx < 0) szMax.cx = 0;
	if (szMax.cy < 0) szMax.cy = 0;
	if (sz->cx < 0 || sz->cx > szMax.cx) sz->cx = szMax.cx;
	if (sz->cy < 0 || sz->cy > szMax.cy) sz->cy = szMax.cy;
	}
SIZE CWindowManage::Size()
	{
	SIZE sz;
	RECT rc;
	::GetClientRect(hWnd, &rc);
	sz.cx = rc.right - rc.left;
	sz.cy = rc.bottom - rc.top;
	return sz;
	}
//----------------------------------------------------------------------------
//	CFrontSurface
//
CFrontSurface::CFrontSurface()
	{
	pCDD = NULL;
	pClipper = NULL;
	}
CFrontSurface::~CFrontSurface()
	{
	Release();
	}
void CFrontSurface::ClientToScreen(POINT* pt, SIZE* sz)
	{
	if (pCDD->IsFullscreen()) return;
	CWindowManage::ClientToScreen(pt, sz);
	}

bool CFrontSurface::Create()
	{
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	pCDD->surfPrimary.Create();
	if (!pClipper && pCDD->CKDDERR(pCDD->pDDraw->CreateClipper(0, &pClipper, NULL)))
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	if (hWnd) pClipper->SetHWnd(0, hWnd);
	CDD_LEAVE_CRITICAL;
	return true;
	}
void CFrontSurface::Release()
	{
	if (!pClipper) return;
	RELEASE(pClipper);
	if (pCDD->IsFullscreen()) pCDD->surfPrimary.Release();
	}
bool CFrontSurface::IsLost()
	{
	return !pClipper || !pCDD || pCDD->surfPrimary.IsLost();
	}
bool CFrontSurface::Restore()
	{
	CDD_ENTER_CRITICAL;
	if (!pClipper) return Create();
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	bool rtv = pCDD->surfPrimary.Restore();
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::SetClipper()
	{
	bool rtv = false;
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (!pCDD->surfPrimary.Restore()) goto leave;
	if (!pCDD->IsFullscreen())
		{
		if (!pClipper) goto leave;
		rtv = !pCDD->CKDDERR(pCDD->surfPrimary.pDDS->SetClipper(pClipper));
		}
	else
		{
		if (!pCDD->pClipper) goto leave;
		rtv = !pCDD->CKDDERR(pCDD->surfPrimary.pDDS->SetClipper(pCDD->pClipper));
		}
leave:
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Blt(CDDSurface& surf, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	POINT dest={0,0};
	SIZE sz={-1,-1};
	POINT src={0,0};
	ClientToScreen(&dest, &sz);
	bool rtv = pCDD->surfPrimary.Blt(surf, dest, sz, src, flags);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Blt(CDDSurface& surf, POINT dest, SIZE sz, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	POINT src={0,0};
	ClientToScreen(&dest, &sz);
	bool rtv = pCDD->surfPrimary.Blt(surf, dest, sz, src, flags);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Blt(CDDSurface& surf, POINT dest, SIZE sz, POINT src, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	ClientToScreen(&dest, &sz);
	bool rtv = pCDD->surfPrimary.Blt(surf, dest, sz, src, flags);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Clear(DWORD color, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	bool rtv = pCDD->surfPrimary.Clear(color, flags);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Clear(POINT pt, SIZE sz, DWORD color, DWORD flags)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	ClientToScreen(&pt, &sz);
	bool rtv = pCDD->surfPrimary.Clear(pt, sz, color, flags);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CFrontSurface::Lock(POINT pt, SIZE sz)
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return false;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	ClientToScreen(&pt, &sz);
	bool rtv = pCDD->surfPrimary.Lock(pt, sz);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
void CFrontSurface::Unlock()
	{
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	pCDD->surfPrimary.Unlock();
	CDD_LEAVE_CRITICAL;
	}
HDC CFrontSurface::GetDC()
	{
	CDD_ENTER_CRITICAL;
	if (IsLost() && !Restore()) return NULL;
	if (!SetClipper())
		{
		CDD_LEAVE_CRITICAL;	
		return NULL;
		}
	HDC hdc = pCDD->surfPrimary.GetDC();
	CDD_LEAVE_CRITICAL;
	return hdc;
	}
void CFrontSurface::ReleaseDC()
	{
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	pCDD->surfPrimary.ReleaseDC();
	CDD_LEAVE_CRITICAL;
	}
bool CFrontSurface::FitWindowToSurface()
	{
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	POINT pt={0,0};
	SIZE sz={pCDD->surfPrimary.desc.dwWidth, pCDD->surfPrimary.desc.dwHeight};
	bool rtv = FitWindow(pt, sz);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
DWORD CFrontSurface::ColorToPixel(COLORREF col)
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.ColorToPixel(col);
	}
DWORD CFrontSurface::PixelPerByte()
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.PixelPerByte();
	}
DWORD CFrontSurface::BytePerPixel()
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.BytePerPixel();
	}
DWORD CFrontSurface::LineLen()
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.LineLen();
	}
BYTE* CFrontSurface::Line(DWORD y)
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.Line(y);
	}
DWORD CFrontSurface::NLine()
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	return pCDD->surfPrimary.NLine();
	}
//----------------------------------------------------------------------------
//	CDDSInterfaces
//
CDDSInterfaces::CDDSInterfaces()
	{
	cur = 0;
	}
void CDDSInterfaces::Cur(int c)
	{
	if (c>=Size()) c = 0;
	cur = c;
	}
END_NAMESPACE_HASE
