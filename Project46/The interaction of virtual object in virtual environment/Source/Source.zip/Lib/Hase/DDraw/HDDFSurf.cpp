#include "Hase/DDraw/HDDSurf.h"
#include "Hase/DDraw/HDDFSurf.h"
#include "Hase/DDraw/HDDraw.h"
#pragma hdrstop

BEGIN_NAMESPACE_HASE
using namespace std;
//----------------------------------------------------------------------------
//	CFlipSurface
//
HRESULT WINAPI CFlipSurface::EnumBackBufferCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext)
	{
	if (!(pDesc->ddsCaps.dwCaps & DDSCAPS_BACKBUFFER))
		return DDENUMRET_OK;
	CFlipSurface& surf = *(CFlipSurface*)pContext;
	surf.pDDS = pDDS;
	surf.pDDS->QueryInterface(IID_IDirectDrawSurface2, (void**)&surf.pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	surf.pDDS->QueryInterface(IID_IDirectDrawSurface3, (void**)&surf.pDDS3);
#endif
	return DDENUMRET_OK;
	}
static const int timeout = 100;

CFlipSurface::CFlipSurface()
	{
	bFlippable = false;
	}
CFlipSurface::~CFlipSurface()
	{
	Release();
	if (bCallDeleteCallbacks)
		{
		bCallDeleteCallbacks = false;
		deleteCallbacks.Call(*this);
		}
	}
bool CFlipSurface::Flip()
	{
	if (!pDDS) return false;
	CDD_ENTER_CRITICAL;
	bool rtv;
	if (bFlippable)
		{
		rtv = !pCDD->CKDDERR(pCDD->surfPrimary.pDDS->Flip(NULL, DDFLIP_WAIT));
		}
	else rtv = front.Blt(*this);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}

bool CFlipSurface::Create(bool bCallCallback, int nBack)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (!pCDD->Create()) goto leave;
	if (pCDD->IsFullscreen())
		{
		CDDSurface& surfPri = pCDD->surfPrimary;
		if (surfPri.pDDS)
			{
			pCDD->DDERRMSG(1, "Another surface already uses the primary surface.");
			goto leave;
			}
		//	create complex surface
		surfPri.Caps(DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX |
			(desc.ddsCaps.dwCaps & 	~(DDSCAPS_OFFSCREENPLAIN | DDSCAPS_BACKBUFFER)  ));
		surfPri.desc.dwFlags |= DDSD_BACKBUFFERCOUNT;
		surfPri.desc.dwBackBufferCount = nBack;
		if (!surfPri.Create()) goto leave;
		surfPri.pDDS->EnumAttachedSurfaces(this, EnumBackBufferCallback);
		//	get desc
		descOld = desc;
		pDDS->GetSurfaceDesc(&desc);
		desc.Calc();
		//	set palette
		if (desc.ddpfPixelFormat.dwFlags&DDPF_PALETTEINDEXED8) 
			{
			if (!pCDD->CreatePalette()) goto leave;
			if (pCDD->CKDDERR(pDDS->SetPalette(pCDD->pPalette))) goto leave;
			}
		bFlippable = true;
		if (bCallCallback) createCallbacks.Call(*this);
		}
	else	//	we are not in the fullscreen mode.
		{
		bFlippable = false;
		if (!pCDD->surfPrimary.pDDS)
			{
			pCDD->surfPrimary.desc.dwFlags = 0;
			pCDD->surfPrimary.Caps(DDSCAPS_PRIMARYSURFACE);
			if (!pCDD->surfPrimary.Create()) goto leave;
			}
		if (!front.Create()) goto leave;
		Caps(DDSCAPS_OFFSCREENPLAIN | (desc.ddsCaps.dwCaps & 
			~(DDSCAPS_PRIMARYSURFACE | DDSCAPS_BACKBUFFER)  ));
		SIZE sz = front.Size();
		if (sz.cx < 8) sz.cx = 8;
		if (sz.cy < 8) sz.cy = 8;
		CDDSurface::Size(sz);
		if (!CDDSurface::Create(bCallCallback)) goto leave;
		}
	pCDD->surfPrimary.releaseCallbacks.Add(ReleaseCallBack, this);
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	Release();
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CFlipSurface::Release(bool bCallCallback)
	{
	if (!pDDS) return;
	CDD_ENTER_CRITICAL;
	if (!pCDD)
		{
		CDD_LEAVE_CRITICAL;
		return;
		}
	pCDD->surfPrimary.releaseCallbacks.Del(ReleaseCallBack, this);
	if (desc.ddsCaps.dwCaps & DDSCAPS_BACKBUFFER)
		{
		CDDSurface::Release(bCallCallback);
		pCDD->surfPrimary.Release();
		}
	else CDDSurface::Release(bCallCallback);
	front.Release();
	CDD_LEAVE_CRITICAL;
	}
bool CFlipSurface::FitSurface()
	{
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (pCDD->IsFullscreen()) return true;
	SIZE sz = Size();
	SIZE fsz = front.Size();
	if ((fsz.cx<8 || fsz.cy<8) && (sz.cx>=fsz.cx && sz.cy>=fsz.cy)) return true;
	if (sz.cx == fsz.cx && sz.cy == fsz.cy) return true;
	Release();
	return Create();
	}
bool CFlipSurface::Restore()
	{
	TRACEALL("CFlipSurface::Restore\n");
	CDD_ENTER_CRITICAL;
	bool rtv = false;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (pCDD->surfPrimary.pDDS)
		{
		if (desc.ddsCaps.dwCaps & DDSCAPS_BACKBUFFER)
			rtv = front.Restore();
		else
			{
			rtv = front.Restore();
			if (rtv) rtv = CDDSurface::Restore();
			}
		}
	if (!rtv)
		{
		Release();
		rtv=Create();
		}
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
void CFlipSurface::ReleaseCallBack(CDDSurface& pri, void* pContext)
	{
	CFlipSurface* thisSurf = (CFlipSurface*)pContext;
	thisSurf->Release();
	}
//----------------------------------------------------------------------------
//	CAutoFlip
//
//#define USE_THREAD			//	thread���g�p
CAutoFlip::CAutoFlip()
	{
	hComFile = INVALID_HANDLE_VALUE;
	comPort = 0;
	nBackBuffer = 1;
	purposeTable = NULL;
	freeSurf = NOSURFACE;
	nPurpose = 1;
	bRunFlipThread = false;
	bExitFlipThread = false;
	frontPurpose = 0;
	lastFlipTime = 0;
	refPeriod = 0;
	hThread = NULL;
	}
CAutoFlip::~CAutoFlip()
	{
	ReleasePurposeTable();
	}
int CAutoFlip::Cur()
	{
	if (!purposeTable) return 0;
	return purposeTable[nBackBuffer][0];
	}
void CAutoFlip::TimerFunc(void* pContext)
	{
	CAutoFlip& af = *(CAutoFlip*)pContext;
	af.AutoFlipStep();
	}
DWORD WINAPI CAutoFlip::FlipThreadFunc(void* pContext)
	{
	CAutoFlip& surf = *(CAutoFlip*)pContext;
	while(!surf.bExitFlipThread)
		{
		surf.AutoFlipStep();
		Sleep(15);
		}
	surf.bRunFlipThread = false;
	return 0;
	}
void CAutoFlip::SearchVacantPurpose()
	{
	if (freeSurf >= 0)
		{
		for(int i = nPurpose; i<nBackBuffer+1; i++)
			if (purposeTable[i][0] == NOSURFACE)
				{
				purposeTable[i][0] = freeSurf;
				freeSurf = NOSURFACE;
				break;
				}
		}
	}
void CAutoFlip::AutoFlipStep()
	{
	int time = GetTickCount() - lastFlipTime;
	if (time < (int)(refPeriod-2)) return;
	CDDSInterface& front = FrontBuffer();
	if (!front.pDDS || front.pDDS->IsLost()!=DD_OK) return;
	int nextPurpose = frontPurpose + 1;
	if (nextPurpose >= nPurpose) nextPurpose=0;
	//	�f�o�b�O�p�Ƀe�[�u����\��
#ifdef USE_THREAD
	int i;
	TRACE("FP: %d   NP: %d\n",frontPurpose, nextPurpose);
	TRACE("PT0:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][0]);
		}
	TRACE("\n");
	TRACE("PT1:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][1]);
		}
	TRACE("\n");
#endif
//	DWORD flipStartTime = GetTickCount();
	if (freeSurf >= 0 || purposeTable[nextPurpose][1] == NOSURFACE)
		{	//	�X�V�����t���b�v
		if (Surf().PCDD()->CKDDERR(front.pDDS->Flip(BackBuffer(nextPurpose,0).pDDS, DDFLIP_WAIT)))
			TRACE("CAutoFlip::FlipThead(): Fliping surface %d without update failed.\n", purposeTable[nextPurpose][0]);
		else
			{
			std::swap(purposeTable[nextPurpose][0], purposeTable[frontPurpose][0]);
			frontPurpose = nextPurpose;
			}
		}
	else	//	�X�V
		{
		if (Surf().PCDD()->CKDDERR(front.pDDS->Flip(BackBuffer(nextPurpose,1).pDDS, DDFLIP_WAIT)))
			TRACE("CAutoFlip::FlipThead(): Fliping surface %d with update failed.\n", purposeTable[nextPurpose][1]);
		else
			{
			freeSurf = purposeTable[nextPurpose][0];						//	�g�p�ς݃o�b�t�@���󂫃o�b�t�@�ɂ��ă��T�C�N��
			purposeTable[nextPurpose][0] = purposeTable[nextPurpose][1];	//	���Ɏg�p����o�b�t�@�����ݎg�p���Ă���o�b�t�@��
			purposeTable[nextPurpose][1] = NOSURFACE;						//	���Ɏg�p����o�b�t�@�͂Ȃ�
			std::swap(purposeTable[nextPurpose][0], purposeTable[frontPurpose][0]);
			frontPurpose = nextPurpose;
			}
		}
	lastFlipTime = GetTickCount();
	SetCom(frontPurpose ? 1 : 2);
//	TRACE("fliptime=%d\n", lastFlipTime - flipStartTime);
	}
void CAutoFlip::ComPort(int cp)
	{
	comPort = cp;
	if (hComFile != INVALID_HANDLE_VALUE)
		{
		ReleaseCom();
		CreateCom();
		}
	}
void CAutoFlip::ReleaseCom()
	{
	if (hComFile != INVALID_HANDLE_VALUE) 
		{
		CloseHandle((HANDLE)hComFile);
		hComFile = INVALID_HANDLE_VALUE;
		}
	}
bool CAutoFlip::CreateCom()
	{
	if (hComFile!= INVALID_HANDLE_VALUE) return true;
	// load the COM prefix string and append port number
	char szPort[256]="COM1";
	szPort[3] += (char)comPort;

	// open COMM device
	hComFile = CreateFile( szPort, GENERIC_READ | GENERIC_WRITE,
			0,                    // exclusive access
			NULL,                 // no security attrs
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,//|FILE_FLAG_OVERLAPPED,
			NULL );
	if (hComFile == INVALID_HANDLE_VALUE)
		{
		TRACE("CAutoFlip::CreateCom: CreateFile() create \"%s\" failed.\n", szPort);
		return false;
		}
	//	set DCB
	dcb.DCBlength = sizeof( DCB ) ;
	if (!GetCommState(hComFile, &dcb))
		{
		int error = GetLastError();
		TRACE("CAutoFlip::CreateCom: GetCommState() failed code %d.\n", error);
		ReleaseCom();
		return false;
		}
	// setup hardware flow control
	dcb.fOutxDsrFlow = false;
	dcb.fDtrControl = DTR_CONTROL_DISABLE ;
	dcb.fOutxCtsFlow = false ;
	dcb.fRtsControl = RTS_CONTROL_DISABLE ;
	if (!SetCommState(hComFile, &dcb))
		{
		int error = GetLastError();
		TRACE("CAutoFlip::CreateCom: SetCommState() failed code %d.\n", error);
		return false;
		};
	return true;
	}
void CAutoFlip::SetCom(int v)
	{
	if (!hComFile) return;
	if (v&0x1) dcb.fRtsControl = RTS_CONTROL_ENABLE;
	else dcb.fRtsControl = RTS_CONTROL_DISABLE;
	if (v&0x2) dcb.fDtrControl = DTR_CONTROL_ENABLE;
	else dcb.fDtrControl = DTR_CONTROL_DISABLE;
	if (SetCommState(hComFile, &dcb) == 0)
		{
		int error = GetLastError();
		TRACE("CAutoFlip::SetCom: SetCommState() failed. code %d\n", error);
		};
	}
void CAutoFlip::NBuffer(int nb)
	{
	ReleasePurposeTable();
	if (nb<2) nb = 2;
	if (nBackBuffer != nb-1)
		{
		nBackBuffer = nb-1;
		Surf().Release();
		}
	if (nPurpose>nBackBuffer) nPurpose=nBackBuffer;
	}
void CAutoFlip::ReleasePurposeTable()
	{
	ReleaseCom();
	if (!purposeTable) return;
	StopAutoFlip();
	for(int i=0; i<nBackBuffer+1; i++) delete (int*)purposeTable[i];
	delete purposeTable;
	purposeTable = NULL;
	}
bool CAutoFlip::CreatePurposeTable()
	{
	/*	purposeTable �ɂ���
	purposeTable[i][0]	:	����i�����݉ʂ����Ă���o�b�t�@�̔ԍ�
	purposeTable[i][1]	:	����i�����ɉʂ����o�b�t�@�̔ԍ�
	purposeTable[i][2]	:	����i���X�V���ɉʂ����\��̃o�b�t�@�̔ԍ�
	purposeTable[nPurpose..nBackBuffer-1][0]
					:	���������̂Ȃ��o�b�t�@
	purposeTable[nBackBuffer]
					:	���݂̕`��p�o�b�t�@
	NOSURFACE		:	�o�b�t�@���Ȃ����Ƃ�\���ԍ�
	FRONTSURFACE	:	�\����ʂ�\���ԍ�
	*/
	if (purposeTable) return true;
	if (!CreateCom()) return false;
	if (!Surf().Restore()) return false;
	if (nBackBuffer < 2)
		{
		TRACE("Surfaces must have three or more back buffers to call CAutoFlip::CreatePurposeTable().\n");
		return false;
		}
	if (nPurpose < 2)
		{
		TRACE("Surfaces must have two or more purpose to call CAutoFlip::CreatePurposeTable().\n");
		return false;
		}
	purposeTable = (volatile int**)new int*[nBackBuffer+1];
	int i;
	for(i=0; i<nBackBuffer+1; i++) purposeTable[i] = new int[3];
	for(i=0; i<nBackBuffer+1; i++)
		{
		purposeTable[i][1] = NOSURFACE;
		purposeTable[i][2] = NOSURFACE;
		}
	for(i=0; i<nBackBuffer-1; i++) purposeTable[i][0] = i;
	purposeTable[nBackBuffer-1][0] = FRONTSURFACE;
	purposeTable[nBackBuffer][0] = nBackBuffer-1;
	frontPurpose = nBackBuffer-1;
	freeSurf = NOSURFACE;
	return true;
	}
void CAutoFlip::NPurpose(int n)
	{
    if (n < 2) ReleasePurposeTable();
    if (nPurpose == n) return;
    ReleasePurposeTable();
	if (n<0) n=0;
	if (n>nBackBuffer)
        {
        n=nBackBuffer;
        Surf().Release();
        }
	nPurpose = n;
	}
bool CAutoFlip::SetPurpose(int purpose, bool bDelay)
	{
	if (!CreatePurposeTable()) return false;
	if (purpose<0 || purpose >= nPurpose)
		{
		TRACE("CAutoFlip::SetPurpose() : Bad purpose.\n");
		return false;
		}
	//	�󂢂Ă���o�b�t�@��T��
	SearchVacantPurpose();
	int freeBuf;
	for(freeBuf=nPurpose; freeBuf<nBackBuffer; freeBuf++)
		if (0<=purposeTable[freeBuf][0]) break;
	if (freeBuf==nBackBuffer && !bRunFlipThread)
		{
		TRACE("CAutoFlip::SetPurpose() : No freeBuf back buffer.\n");
		return false;//	�󂫃o�b�t�@���Ȃ��Ƃ�
		}
	
	if (bDelay)
		{
		if (purposeTable[purpose][2] != NOSURFACE)
			{
			TRACE("CAutoFlip::SetPurpose() : Another surface is waiting for update.\n");
			return false;
			}
		purposeTable[purpose][2] = purposeTable[nBackBuffer][0];
		TRACEALL("Set buffer %d to purpose %d with delay.\n", purposeTable[nBackBuffer][0], purpose);
		purposeTable[nBackBuffer][0] = NOSURFACE;
		}
	else
		{
		if (purposeTable[purpose][1] != NOSURFACE)
			{
			TRACE("CAutoFlip::SetPurpose() : Another surface is waiting for update.\n");
			return false;
			}
		purposeTable[purpose][1] = purposeTable[nBackBuffer][0];
		TRACEALL("Set buffer %d to purpose %d.\n", purposeTable[nBackBuffer][0], purpose);
		purposeTable[nBackBuffer][0] = NOSURFACE;
		}
	for (int t=0; t<timeout; t++)
		{
		SearchVacantPurpose();
		for(freeBuf=nPurpose; freeBuf<nBackBuffer+1; freeBuf++)
			if (0<=purposeTable[freeBuf][0]) goto next;
		Sleep(20);
		}
	
	TRACE("CAutoFlip::SetPurpose() : Timeouted wating for free surface.\n");
	int i;
	TRACE("FP: %d\n",frontPurpose);
	TRACE("PT0:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][0]);
		}
	TRACE("\n");
	TRACE("PT1:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][1]);
		}
	TRACE("\n");
	Surf().Release();
	return false;
next:
	//	�󂫃o�b�t�@�𔭌�
	if (freeBuf != nBackBuffer)
		{
		purposeTable[nBackBuffer][0] = purposeTable[freeBuf][0];
		purposeTable[freeBuf][0] = NOSURFACE;
		}
	CurBuffer(BackBuffer(nBackBuffer, 0));
	return true;
	}
bool CAutoFlip::UpdatePurpose()
	{
	if (!CreatePurposeTable()) return false;
	bool rtv = true;
	for(int i=0; i<nPurpose; i++)
		{
		if (purposeTable[i][2] != NOSURFACE)
			{
			if (purposeTable[i][1] == NOSURFACE)
				{
				std::swap(purposeTable[i][1], purposeTable[i][2]);
				}
			else rtv = false;
			}
		}
	return rtv;
	}
bool CAutoFlip::StartAutoFlip()
	{
	if (bRunFlipThread) return true;
	if (!CreatePurposeTable()) return false;
	//	measure the length of refresh period.
	refPeriod = 0;
	Surf().PCDD()->surfPrimary.pDDS->Flip(BackBuffer(0,0).pDDS, DDFLIP_WAIT);
	const int measureTime = 3;
	int startTime = GetTickCount();
	for(int i=0; i<measureTime+1; i++)
		{
		int refPeriodTmp = 0;
		while(refPeriodTmp < 5)
			{
			Surf().PCDD()->surfPrimary.pDDS->Flip(BackBuffer(0,0).pDDS, DDFLIP_WAIT);
			DWORD endTime = GetTickCount();
			refPeriodTmp = endTime - startTime;
			startTime = endTime;
			}
		if (i>0) refPeriod += refPeriodTmp;
		}
	refPeriod /= measureTime;
	TRACE("CAutoFlip: The virtical sync frequency of the display is %dHz\n", 1000/refPeriod);
#ifdef USE_THREAD
	DWORD flipThreadID = 0;
	hThread = CreateThread(NULL, 0x1000, FlipThreadFunc, this, 0, &flipThreadID);
	if (hThread)
		{
		bRunFlipThread = true;
		SetThreadPriority(hThread, THREAD_PRIORITY_ABOVE_NORMAL);
		}
#else
	mmtimer.Set(TimerFunc, this);
	mmtimer.Resolution(1);
	mmtimer.Interval(1);
	mmtimer.Create();
	bRunFlipThread = true;
#endif
	return bRunFlipThread;
	}
void CAutoFlip::StopAutoFlip()
	{
	if (!bRunFlipThread) return;
	bExitFlipThread = true;
#ifdef USE_THREAD
	for(int t=0; t<timeout && bRunFlipThread; t++) Sleep(20);
	CloseHandle(hThread);
	hThread = NULL;
#else
	mmtimer.Release();
#endif
	bRunFlipThread = false;
	bExitFlipThread = false;
	}

//----------------------------------------------------------------------------
//	CAutoFlipSurface
//
HRESULT WINAPI CAutoFlipSurface::EnumSurfacesCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext)
	{
	CAutoFlipSurface& surf = *(CAutoFlipSurface*)pContext;
	CDDSInterface newSurf;
	newSurf.pDDS = pDDS;
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface2, (void**)&newSurf.pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface3, (void**)&newSurf.pDDS3);
#endif
	surf.backs.Add(newSurf);
	return DDENUMRET_OK;
	}

CAutoFlipSurface::CAutoFlipSurface()
	{
	}
CAutoFlipSurface::~CAutoFlipSurface()
	{
	Release();
	}
CDDSInterface& CAutoFlipSurface::BackBuffer(int p, int t)
	{
	ASSERT(0<=p&&p<nBackBuffer+1 && 0<=t&&t<3);
	ASSERT(purposeTable[p][t] >= 0);
	return backs[purposeTable[p][t]];
	}
void CAutoFlipSurface::CurBuffer(CDDSInterface& nb)
	{
	(CDDSInterface&)*this = nb;
	}
CDDSInterface& CAutoFlipSurface::FrontBuffer()
	{
	return pCDD->surfPrimary;
	}
bool CAutoFlipSurface::Flip()
	{
	return CFlipSurface::Flip();
	}
bool CAutoFlipSurface::Flip(int n)
	{
	if (!Restore()) return false;
	if (bRunFlipThread) return false;
	if (n<0 || n>=backs.Size()) return false;
	(CDDSInterface&)*this = backs[n];
	Flip();
	return true;
	}
bool CAutoFlipSurface::Restore()
	{
	return CFlipSurface::Restore();
	}
bool CAutoFlipSurface::CreatePurposeTable()
	{
	if (!Create()) return false;
	if (backs.Size() < nBackBuffer) return false;
	return CAutoFlip::CreatePurposeTable();
	}
bool CAutoFlipSurface::Create(bool bCallCallback)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	if (!CFlipSurface::Create(bCallCallback, nBackBuffer)) return false;
	if (pCDD->IsFullscreen())
		{
		backs.Add(*this);
		for(int i=0; i<nBackBuffer-1; i++)
			backs.End()[-1].pDDS->EnumAttachedSurfaces(this, EnumSurfacesCallback);
		if (backs.Size() != nBackBuffer) goto leave;
		//	set palette
		if (desc.ddpfPixelFormat.dwFlags&DDPF_PALETTEINDEXED8) 
			{
			if (!pCDD->CreatePalette()) goto leave;
			for(int i=1; i<nBackBuffer; i++)
				if (pCDD->CKDDERR(backs[i].pDDS->SetPalette(pCDD->pPalette))) goto leave;
			}
		bFlippable = true;
		}
	else
		{
		backs.Add(*this);
		}
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	Release();
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CAutoFlipSurface::Release(bool bCallCallback)
	{
	if (!pDDS && backs.Size() == 0) return;
	CDD_ENTER_CRITICAL;
	ReleasePurposeTable();
	if (!pCDD) goto leave;
	backs.Clear();
	CFlipSurface::Release(bCallCallback);
leave:
	CDD_LEAVE_CRITICAL;
	}

END_NAMESPACE_HASE
