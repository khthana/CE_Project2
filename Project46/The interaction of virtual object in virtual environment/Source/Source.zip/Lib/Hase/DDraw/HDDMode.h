#ifndef HASE_DDRAW_HDDMODE_H
#define HASE_DDRAW_HDDMODE_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Hase/DDraw/HDDSurf.h"

BEGIN_NAMESPACE_HASE
class DLLCLASS CDisplayMode
	{
	public:
	CDDSurfaceDesc desc;
	bool operator < (const CDisplayMode&) const;
	bool operator == (const CDisplayMode&) const;
	};

class DLLCLASS CDisplayModes :public Array<CDisplayMode>
	{
	public:
	CDisplayModes();
	int Find(int w, int h, UINT bpp);
    It Find(const CDisplayMode& key)
        {
        return Array<CDisplayMode>::Find(key);
        }
	};
END_NAMESPACE_HASE

#endif