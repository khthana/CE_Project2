#include "Hase/DDraw/HDDMode.h"
BEGIN_NAMESPACE_HASE
bool CDisplayMode::operator < (const CDisplayMode& m) const
	{
    if (desc.bitPerPixel < m.desc.bitPerPixel) return true;
    if (desc.Size().cx < m.desc.Size().cx) return true;
    if (desc.Size().cy < m.desc.Size().cy) return true;
	return false;
	}
bool CDisplayMode::operator == (const CDisplayMode& m) const
	{
	return !(m < *this) && !(*this < m);
	}


CDisplayModes::CDisplayModes()
	{
	Clear();
	}
int CDisplayModes::Find(int w, int h, UINT bpp)
	{
	CDisplayModes& modes = *this;
	for(int i=0; i<modes.Size(); i++)
		{
		if (modes[i].desc.Size().cx == w 
			&& modes[i].desc.Size().cy == h 
			&& modes[i].desc.bitPerPixel == bpp) return i;
		}
	return -1;
	}	
END_NAMESPACE_HASE
