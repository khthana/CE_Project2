# Microsoft Developer Studio Project File - Name="hase" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=hase - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "hase.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "hase.mak" CFG="hase - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "hase - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "hase - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""$/hase", NEAAAAAA"
# PROP Scc_LocalPath "."
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "hase - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "CREATE_DLL" /D "_WINDLL" /D "_AFXDLL" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /o /win32 "NUL"
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /o /win32 "NUL"
# ADD BASE RSC /l 0x411 /d "NDEBUG"
# ADD RSC /l 0x411 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 winmm.lib d3drm.lib ddraw.lib dsound.lib ole32.lib /nologo /subsystem:windows /dll /machine:I386
# SUBTRACT LINK32 /incremental:yes /debug /nodefaultlib
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=copy release\hase.dll c:\windows	copy release\hase.lib ..
# End Special Build Tool

!ELSEIF  "$(CFG)" == "hase - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MDd /W3 /GX /ZI /Od /I ".." /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "CREATE_DLL" /D "_WINDLL" /D "_AFXDLL" /D "_AFXEXT" /YX"stdafx.h" /FD /c
# SUBTRACT CPP /Fr
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o /win32 "NUL"
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o /win32 "NUL"
# ADD BASE RSC /l 0x411 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 winmm.lib d3drm.lib ddraw.lib dsound.lib ole32.lib /nologo /subsystem:windows /dll /profile /debug /machine:I386 /out:"Debug/haseD.dll"
# SUBTRACT LINK32 /map /nodefaultlib
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Desc=copy
PostBuild_Cmds=copy debug\haseD.dll c:\windows	copy debug\haseD.lib ..
# End Special Build Tool

!ENDIF 

# Begin Target

# Name "hase - Win32 Release"
# Name "hase - Win32 Debug"
# Begin Group "Misc"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Misc\Callback.h
# End Source File
# Begin Source File

SOURCE=.\Misc\Defs.h
# End Source File
# Begin Source File

SOURCE=.\Misc\Handle.h
# End Source File
# Begin Source File

SOURCE=.\Misc\HString.h
# End Source File
# Begin Source File

SOURCE=.\Misc\Inc.h
# End Source File
# Begin Source File

SOURCE=.\Misc\Matrix.cpp
# End Source File
# Begin Source File

SOURCE=.\Misc\Matrix.h
# End Source File
# Begin Source File

SOURCE=.\Misc\MMTimer.cpp
# End Source File
# Begin Source File

SOURCE=.\Misc\MMTimer.h
# End Source File
# Begin Source File

SOURCE=.\Misc\RingBuf.h
# End Source File
# Begin Source File

SOURCE=.\Misc\Types.h
# End Source File
# End Group
# Begin Group "D3D"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\D3d\HD3DAffine.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DAffine.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DAffineDef.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DDev.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DDev.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DIM.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DIM.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DRM.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DRM.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DRMEx.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DRMEx.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HD3DRMExDef.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMFrame.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMFrame.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMFrameEx.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMFrameEx.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMVisual.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMVisual.h
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMVisualEx.cpp
# End Source File
# Begin Source File

SOURCE=.\D3d\HRMVisualEx.h
# End Source File
# End Group
# Begin Group "DDraw"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\DDraw\HDDFSurf.cpp
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDFSurf.h
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDMode.cpp
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDMode.h
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDraw.cpp
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDraw.h
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDSurf.cpp
# End Source File
# Begin Source File

SOURCE=.\DDraw\HDDSurf.h
# End Source File
# End Group
# Begin Group "DX"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Dx\HDXError.cpp
# End Source File
# Begin Source File

SOURCE=.\Dx\HDXError.h
# End Source File
# Begin Source File

SOURCE=.\Dx\HDXObj.cpp
# End Source File
# Begin Source File

SOURCE=.\Dx\HDXObj.h
# End Source File
# End Group
# Begin Group "Stream"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Stream\comStream.cpp
# End Source File
# Begin Source File

SOURCE=.\Stream\comStream.h
# End Source File
# Begin Source File

SOURCE=.\Stream\sockStr.cpp
# End Source File
# Begin Source File

SOURCE=.\Stream\sockStr.h
# End Source File
# Begin Source File

SOURCE=.\Stream\strbufBase.cpp
# End Source File
# Begin Source File

SOURCE=.\Stream\strbufBase.h
# End Source File
# Begin Source File

SOURCE=.\Stream\WinStream.cpp
# End Source File
# Begin Source File

SOURCE=.\Stream\WinStream.h
# End Source File
# End Group
# Begin Group "DSound"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\DSound\HDS3DBuf.cpp
# End Source File
# Begin Source File

SOURCE=.\DSound\HDS3DBuf.h
# End Source File
# Begin Source File

SOURCE=.\DSound\HDSBuf.cpp
# End Source File
# Begin Source File

SOURCE=.\DSound\HDsBuf.h
# End Source File
# Begin Source File

SOURCE=.\DSound\HDSBufBase.cpp
# End Source File
# Begin Source File

SOURCE=.\DSound\HDSBufBase.h
# End Source File
# Begin Source File

SOURCE=.\DSound\HDSound.cpp
# End Source File
# Begin Source File

SOURCE=.\DSound\HDSound.h
# End Source File
# Begin Source File

SOURCE=.\DSound\waveFile.cpp
# End Source File
# Begin Source File

SOURCE=.\DSound\WaveFile.h
# End Source File
# End Group
# End Target
# End Project
