#include <Hase/DSound/HDSound.h>
#include <windowsx.h>
#pragma hdrstop
#include "wavefile.h"

BEGIN_NAMESPACE_HASE
/*----------------------*/
/*		CDSBufBase		*/
/*----------------------*/
CDSBufBase::CDSBufBase(CDSound& cds)
	{
	pCDS = &cds;
	bPlaying = false;
	bPlaying = false;
	bLoop = false;
	bGlobal = false;
	bHardware = false;
	}
CDSBufBase::CDSBufBase()
	{
	pCDS = NULL;
	bPlaying = false;
	bPlaying = false;
	bLoop = false;
	bGlobal = false;
	bHardware = false;
	}

CDSBufBase::~CDSBufBase()
	{
	}
void CDSBufBase::CDS(CDSound& cds)
	{
	pCDS = & cds;
	}
END_NAMESPACE_HASE