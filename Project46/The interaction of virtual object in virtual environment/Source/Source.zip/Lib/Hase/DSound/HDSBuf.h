#ifndef HaseDS_DSBUF_H
#define HaseDS_DSBUF_H

#include <Hase/DSound/HDSBufBase.h>
#include <Hase/DSound/WaveFile.h>
BEGIN_NAMESPACE_HASE
class DLLCLASS CDSBuf:public CDSBufBase
	{
	protected:
	DSBUFFERDESC descDSB;
	LPDIRECTSOUNDBUFFER pDSB;
	CWaveFile waveFile;
	public:
	CDSBuf(CDSound& cds);
	CDSBuf();
	virtual	~CDSBuf();
	void			Cleanup();
    virtual bool	AllocDSB();
    virtual bool	WriteDSB();
	public:
	virtual void	BufferPos(double msec);
	virtual double	BufferPos();
	virtual void	Volume(double db);
	virtual double	Volume();
	virtual void	Pan(double db);
	virtual double	Pan();
    virtual bool	Playing();
    virtual bool	Load(const char* fname=NULL);
    virtual void	Play();
    virtual void	Stop();
	};
END_NAMESPACE_HASE
#endif  // __FILEINFO_H__
