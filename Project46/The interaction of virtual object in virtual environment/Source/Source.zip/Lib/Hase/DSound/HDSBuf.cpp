#include <Hase/DSound/HDSound.h>
#include <Hase/DSound/HDSBuf.h>
#pragma hdrstop
USING_NAMESPACE_HASE;
using namespace std;

CDSBuf::CDSBuf(CDSound& cds):
	CDSBufBase(cds)
	{
	ZeroMemory(&descDSB, sizeof(descDSB));
	descDSB.dwSize = sizeof(descDSB);
	pDSB = NULL;
	}
CDSBuf::CDSBuf():
	CDSBufBase()
	{
	ZeroMemory(&descDSB, sizeof(descDSB));
	descDSB.dwSize = sizeof(descDSB);
	pDSB = NULL;
	}
CDSBuf::~CDSBuf()
	{
	RELEASE(pDSB);
	}
void CDSBuf::Cleanup()
	{
	RELEASE(pDSB);
	}
bool CDSBuf::AllocDSB()
	{
    descDSB.dwFlags |= DSBCAPS_STATIC;
//    descDSB.dwFlags |= DSBCAPS_CTRLDEFAULT;
    descDSB.dwFlags |= DSBCAPS_CTRLFX;  // edit by Somsak

    // The derived class will pick its 3D flags
#ifdef DSBCAPS_GLOBALFOCUS
    if(Global()) descDSB.dwFlags |= DSBCAPS_GLOBALFOCUS;
	else descDSB.dwFlags |= DSBCAPS_STICKYFOCUS;
#else
	descDSB.dwFlags |= DSBCAPS_STICKYFOCUS;
#endif

	descDSB.dwFlags |= DSBCAPS_GETCURRENTPOSITION2;
    descDSB.dwBufferBytes = waveFile.dataSize;
    descDSB.lpwfxFormat = waveFile.pWfx;

	RELEASE(pDSB);
    if (!pCDS->pDS && !pCDS->Create()) return false;
	if( pCDS->CKDSERR(pCDS->pDS->CreateSoundBuffer(&descDSB, &pDSB, NULL)) )
		return false;
	return true;
	}
bool CDSBuf::WriteDSB()
	{
    /* Ok, lock the sucker down, and copy the memory to it. */
	void * pWrite1, * pWrite2;
	DWORD len1, len2;
    if( pCDS->CKDSERR(pDSB->Lock(0, waveFile.dataSize, &pWrite1, &len1, &pWrite2, &len2, 0L)) )
		{
		RELEASE(pDSB);
		return false;
		}
    ASSERT( pWrite1 != NULL );
    ASSERT( len1 == waveFile.dataSize );
    ASSERT( 0 == len2 );
    ASSERT( NULL == pWrite2 );

    memcpy(pWrite1, waveFile.pData, waveFile.dataSize);

    /* Ok, now unlock the buffer, we don't need it anymore. */
    if( pCDS->CKDSERR(pDSB->Unlock( pWrite1, len1, pWrite2, len2)) )
		{
		RELEASE(pDSB);
		return false;
		}
	return true;
	}

bool CDSBuf::Load(const char* fname)
	{
	if (!waveFile.Load(fname))
		{
		char buf[1024];
		ostrstream(buf, sizeof(buf)) << "Fail to load wave file \'" << fname << "\'.\n";
		pCDS->DSERRMSG(2, buf);
		return false;
		}
	AllocDSB();
	WriteDSB();
	waveFile.Release();
	return true;
	}
void CDSBuf::Play()
	{
	if(pDSB)
		{
		if(Looped()) pDSB->Play( 0, 0, DSBPLAY_LOOPING );
		else pDSB->Play(0, 0, 0);
		bPlaying = true;
		}
	}

void CDSBuf::Stop()
	{
    if(pDSB)
		{
		pDSB->Stop();
		pDSB->SetCurrentPosition(0);
		bPlaying = false;
		}
	}

void CDSBuf::BufferPos(double msec)
	{
	DWORD samplePerSec = waveFile.pWfx->nSamplesPerSec;
	DWORD bpos = samplePerSec * msec / 1000.0;
	pDSB->SetCurrentPosition(bpos);
	}
double CDSBuf::BufferPos()
	{
	DWORD samplePerSec = waveFile.pWfx->nSamplesPerSec;
	DWORD bpos, wbpos;
	pDSB->GetCurrentPosition(&bpos, &wbpos);
	double ms = (double)bpos / (double)samplePerSec * 1000.0;
	return ms;
	}
void CDSBuf::Pan(double db)
	{
	pDSB->SetPan(db*100);
	}
double CDSBuf::Pan()
	{
	long lpan;
	pDSB->GetPan(&lpan);
	return (double)lpan / 100.0;
	}
void CDSBuf::Volume(double db)
	{
	pDSB->SetVolume(db*100);
	}
double CDSBuf::Volume()
	{
	long vol = 0;
	pDSB->GetVolume(&vol);
	return (double)vol/100;
	}
bool CDSBuf::Playing()
	{
	if (bPlaying)
		{
		DWORD stat=0;
		pDSB->GetStatus(&stat);
		if (stat & DSBSTATUS_PLAYING) return true;
		}
	return false;
	}
