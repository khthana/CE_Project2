#include <Hase/DSound/HDSound.h>
#include <Hase/DSound/HDS3DBuf.h>
#pragma hdrstop
USING_NAMESPACE_HASE;

#ifdef DSBCAPS_CTRL3D
CDS3DBuf::CDS3DBuf(CDSound& cds):
	CDSBuf(cds)
	{
	pDSB3D = NULL;
	}
CDS3DBuf::CDS3DBuf():
	CDSBuf()
	{
	pDSB3D = NULL;
	}
CDS3DBuf::~CDS3DBuf()
	{
	RELEASE(pDSB3D);
	}
bool CDS3DBuf::AllocDSB()
	{
	RELEASE(pDSB3D);
    descDSB.dwFlags |= DSBCAPS_CTRL3D;
	if (!CDSBuf::AllocDSB()) return false;
    if ( pCDS->CKDSERR(pDSB->QueryInterface(IID_IDirectSound3DBuffer, (void **)&pDSB3D)) ) return false;
    return true;
	}

void CDS3DBuf::Pos(const CD3DVec3& v)
	{
	pDSB3D->SetPosition(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDS3DBuf::Pos()
	{
	CD3DVec3 v;
	pDSB3D->GetPosition(&v);
	return v;
	}
void CDS3DBuf::Vel(const CD3DVec3& v)
	{
	pDSB3D->SetVelocity(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDS3DBuf::Vel()
	{
	CD3DVec3 v;
	pDSB3D->GetVelocity(&v);
	return v;
	}
void CDS3DBuf::MaxDist(REAL d)
	{
	HRESULT hr = pDSB3D->SetMaxDistance(d, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	if (hr!= DS_OK) TRACE("faild.");
	}
REAL CDS3DBuf::MaxDist()
	{
	REAL d;
	pDSB3D->GetMaxDistance(&d);
	return d;
	}
void CDS3DBuf::MinDist(REAL d)
	{
	pDSB3D->SetMinDistance(d, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
REAL CDS3DBuf::MinDist()
	{
	REAL d;
	pDSB3D->GetMinDistance(&d);
	return d;
	}
void CDS3DBuf::Cone(CD3DVec2 v)
	{
	pDSB3D->SetConeAngles(v.x, v.y, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec2 CDS3DBuf::Cone()
	{
	DWORD x,y;
	pDSB3D->GetConeAngles(&x, &y);
	return CD3DVec2(x,y);
	}
void CDS3DBuf::ConeOri(CD3DVec3 v)
	{
	pDSB3D->SetConeOrientation(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDS3DBuf::ConeOri()
	{
	CD3DVec3 v;
	pDSB3D->GetConeOrientation(&v);
	return v;
	}
void CDS3DBuf::OutVolume(REAL db)
	{
	pDSB3D->SetConeOutsideVolume(db*100, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
REAL CDS3DBuf::OutVolume()
	{
	long l;
	pDSB3D->GetConeOutsideVolume(&l);
	return REAL(l)/REAL(100);
	}
#endif