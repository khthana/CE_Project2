#ifndef HaseDS_DSWAVBUFBASE_H
#define HaseDS_DSWAVBUFBASE_H

#include <Hase/Misc/Inc.h>
#include <mmsystem.h>
#include <dsound.h>
#include <Hase/D3D/HD3DAffine.h>

BEGIN_NAMESPACE_HASE
class CDSound;
class DLLCLASS CDSBufBase
	{
	protected:
	CDSound*		pCDS;			//	Pointer to CDSound class.
	bool			bPlaying;
	bool			bLoop;
	bool			bGlobal;
	bool			bHardware;
	public:
	//	non 3d buffer operations
	virtual void		Pan(double db){}
	virtual double		Pan(){return 0;}
	//	3d buffer operations
	virtual void		Pos(const CD3DVec3&){}
	virtual CD3DVec3	Pos(){return CD3DVec3();}
	virtual void		Vel(const CD3DVec3&){}
	virtual CD3DVec3	Vel(){return CD3DVec3();}
	virtual void		MaxDist(REAL max){}
	virtual REAL		MaxDist(){return 0;}
	virtual void		MinDist(REAL min){}
	virtual REAL		MinDist(){return 0;}
	virtual void		Cone(CD3DVec2 v){}
	virtual CD3DVec2	Cone(){return CD3DVec2();}
	virtual void		ConeOri(CD3DVec3 v){}
	virtual CD3DVec3	ConeOri(){return CD3DVec3();}
	virtual void		OutVolume(REAL v){}
	virtual REAL		OutVolume(){return 0;}

	//	common
	virtual void	Volume(double db){}
	virtual double	Volume(){return 0;}
	virtual void	BufferPos(double msec){}
	virtual double	BufferPos(){return 0;}
	virtual bool	Playing(){return bPlaying;}
    virtual bool	Looped(){return bLoop;}
    virtual void	Looped(bool b){bLoop = b;}
    virtual bool	Global(){return bGlobal;}
    virtual bool	Hardware(){return bHardware;}
    virtual bool	Load(const char* fname = NULL) = 0;
	virtual void	Play() = 0;
	virtual void	Stop() = 0;
    CDSBufBase(CDSound&);
    CDSBufBase();
    CDSound* PCDS(){return pCDS;}
	void CDS(CDSound& s);
	virtual ~CDSBufBase();
	};
END_NAMESPACE_HASE
#endif