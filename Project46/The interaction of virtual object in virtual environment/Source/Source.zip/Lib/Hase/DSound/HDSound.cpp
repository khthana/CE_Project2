#include <Hase/DSound/HDSound.h>
#include <Hase/DSound/HDSBuf.h>
#include <Hase/DSound/HDS3DBuf.h>
#pragma hdrstop

#define NUM_FORMATENTRIES	(sizeof(fdFormats)/sizeof(fdFormats[0]))
#define FC_GETFREQCODE(fc)  ((fc) / 1000)
#define FC_GETBITS(fc)      ((fc) % 100)
#define FC_GETCHANNELS(fc)  (((fc) % 1000) / 100)
USING_NAMESPACE_HASE;
using namespace std;

struct FORMATDATA
	{
    DWORD   dwCode;
    bool    fEnable;
	};
FORMATDATA   fdFormats[] = { { 8108, TRUE },
                { 8116,  TRUE },
                { 8208,  TRUE },
                { 8216,  TRUE },
                { 11108, TRUE },
                { 11116, TRUE },
                { 11208, TRUE },
                { 11216, TRUE },
                { 22108, TRUE },
                { 22116, TRUE },
                { 22208, TRUE },
                { 22216, TRUE },
                { 44108, TRUE },
                { 44116, TRUE },
                { 44208, TRUE },
                { 44216, TRUE } };


DWORD aFormatOrder[] = { 44216, 44116, 44208, 44108, 22216, 22116, 22208, 22108,
                11216, 11116, 11208, 11108, 8216, 8116, 8208, 8108 };

CDSDevice::CDSDevice(const CDSDevice& src)
	{
	name = src.name;
	description = src.description;
	pGuid = NULL;
	if (src.pGuid)
		{
		pGuid = new GUID;
		memcpy(pGuid, src.pGuid, sizeof(GUID));
		}
	}
CDSDevice::CDSDevice(const GUID* lpg, const char* desc, const char* aName)
	{
	description = desc;
	name = aName;
	pGuid = NULL;
	if (lpg)
		{
		pGuid = new GUID;
		memcpy(pGuid, lpg, sizeof(GUID));
		}
	}

//----------------------------------------------------------------------------
//	CDSListener
//
#ifdef DSBCAPS_CTRL3D
CDSListener::CDSListener()
	{
	pListener = NULL;
	pCDS = NULL;
	}
CDSListener::~CDSListener()
	{
	Release();
	}
void CDSListener::Release()
	{
	RELEASE(pListener);
	}
bool CDSListener::Create(CDSound* aPCDS)
	{
	pCDS = aPCDS;
	if (pCDS->CKDSERR(pCDS->pDSBPrimary->QueryInterface( IID_IDirectSound3DListener, (void**)&pListener))) return false;
	return true;
	}
void CDSListener::Af(const CD3DAffine& af)
	{
	CD3DVec3 front = af.Ez();
	CD3DVec3 top = af.Ey();
	pListener->SetOrientation(
		front.x, front.y, front.z,
		top.x, top.y, top.z,
		pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	Pos(af.Pos());
	}
CD3DAffine CDSListener::Af()
	{
	D3DVECTOR f,t,p;
	pListener->GetOrientation(&f, &t);
	pListener->GetPosition(&p);
	CD3DAffine af(CD3DVec3(t.x, t.y, t.z), CD3DVec3(f.x, f.y, f.z), 'y', CD3DVec3(p.x, p.y, p.z));
	return af;
	}
void CDSListener::Pos(const CD3DVec3& v)
	{
	pListener->SetPosition(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDSListener::Pos()
	{
	D3DVECTOR p;
	pListener->GetPosition(&p);
	return CD3DVec3(p.x, p.y, p.z);
	}
void CDSListener::Vel(const CD3DVec3& v)
	{
	pListener->SetVelocity(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDSListener::Vel()
	{
	D3DVECTOR p;
	pListener->GetVelocity(&p);
	return CD3DVec3(p.x, p.y, p.z);
	}
#endif

//----------------------------------------------------------------------------
//	CDSWaves
//
int CDSWaves::Load(const char* path, bool b3D)
	{
	CDSBufBase* buf = NULL;
#ifdef DSBCAPS_CTRL3D
	if (b3D) buf = new CDS3DBuf;
#else
	pCDS->DSERRMSG(1, "Can't use 3d buffer on this version of direct sound. Conventional buffer is used insted.");
#endif
	if (!buf) buf = new CDSBuf;
	buf->CDS(*pCDS);
	if (!buf->Load(path)) return 0;
	return Add(buf);
	}
//----------------------------------------------------------------------------
//	CDSound
//
CDSound::CDSound()
	{
	curDevPos = 0;
	bExclusive = TRUE;
	pDS = NULL;
	pDSBPrimary = NULL;
	pWfx = NULL;
	dwOutFormat = 44216;
	hWnd = NULL;
	EnumDevice();
	waves.pCDS = this;
	}
CDSound::~CDSound()
	{
	Release();
	}
bool CDSound::Create(DWORD outFmt, int devPos, bool bExclusiveMode)
	{
	curDevPos = devPos;
	bExclusive = bExclusiveMode;
	dwOutFormat = outFmt;

	int i;
	LPGUID pGuDevice = NULL;

	if (FAILED(CoInitialize(NULL))) // suikyo
		{
		DSERRMSG(2, "CoInitialize(NULL) failed.");
		goto ID_ExitError;
		}

	if (devices.Size()>0) pGuDevice = devices[curDevPos].pGuid;
	if (!pDS)
		{
		if (CKDSERR(CoCreateInstance( CLSID_DirectSound, NULL, CLSCTX_INPROC_SERVER,
			IID_IDirectSound, (void**)&pDS )))
			goto ID_ExitError;
		}
	if( CKDSERR(pDS->Initialize(pGuDevice)) )
		{
		if(pGuDevice!=NULL)
			{
			TRACE( "Using default device\n" );
			if (CKDSERR(pDS->Initialize(NULL))) goto ID_ExitReleaseDS;
			}
		else goto ID_ExitReleaseDS;
		}
    if (hWnd)
		{
		if (CKDSERR(pDS->SetCooperativeLevel(hWnd, bExclusiveMode ? DSSCL_EXCLUSIVE : DSSCL_PRIORITY)))
			goto ID_ExitReleaseDS;
		}
	else
		{
		TRACE("To call SetCooperativeLevel() we need hWnd.\n");
		goto ID_ExitReleaseDS;
		}
    if(!InitPrimaryDSB()) goto ID_ExitReleaseDS;
	for(i=1; i<waves.Size(); i++) if (waves[i]) waves[i]->Load();
    return true;

ID_ExitReleaseDS:
    // The InitPrimaryDSB() call should have cleaned up
    // after itself if it failed

    ASSERT( NULL == pDSBPrimary );

    if( NULL != pDS )
	    {
    	pDS->Release();
    	pDS = NULL;
    	}

ID_ExitError:
    return FALSE;
    }

void CDSound::Release()
    {
#ifdef DSBCAPS_CTRL3D
	listener.Release();
#endif
	waves.Clear();
	if (pDSBPrimary)
	    {
    	pDSBPrimary->Stop();
    	pDSBPrimary->Release();
    	pDSBPrimary = NULL;
    	}
    if(pDS)
    	{
    	pDS->Release();
    	pDS = NULL;
    	}
	delete pWfx;
    }
void CDSound::HWnd(HWND hw)
	{
	HWND hWndParent = hw;
	//	get mainframe window
	while(hWndParent)
		{
		hWnd = hWndParent;
		hWndParent = GetParent(hWnd);
		}
	}
HWND CDSound::HWnd()
	{
	return hWnd;
	}

int _stdcall CDSDevices::DSEnumCallBack(GUID FAR * lpGuid, const char* desc, const char* name, void* arg)
	{
	CDSound* pCDS = (CDSound*) arg;
	pCDS->devices.Add(CDSDevice(lpGuid, desc, name));
	return TRUE;
	}
int _stdcall CDSDevices::DSEnumCallBack(GUID FAR * lpGuid, char* desc, char* name, void* arg)
	{
	CDSound* pCDS = (CDSound*) arg;
	pCDS->devices.Add(CDSDevice(lpGuid, desc, name));
	return TRUE;
	}
void CDSound::EnumDevice()
	{
	DirectSoundEnumerate(CDSDevices::DSEnumCallBack, this);
	}

bool CDSound::InitPrimaryDSB()
    {
    DSBUFFERDESC dsbd;
    ZeroMemory( &dsbd, sizeof(DSBUFFERDESC));
    pWfx = new WAVEFORMATEX;
    if( NULL == pWfx )
    return FALSE;
    ZeroMemory( pWfx, sizeof(WAVEFORMATEX));
    pWfx->wFormatTag = WAVE_FORMAT_PCM;
    FormatCodeToWfx( dwOutFormat, pWfx );
    dsbd.dwSize = sizeof(DSBUFFERDESC);
#ifdef DSBCAPS_CTRL3D
    dsbd.dwFlags = DSBCAPS_CTRL3D | DSBCAPS_PRIMARYBUFFER;
#else
    dsbd.dwFlags = DSBCAPS_PRIMARYBUFFER;
#endif

    if ( CKDSERR(pDS->CreateSoundBuffer(&dsbd, &pDSBPrimary, NULL)) ) goto IPSB_ExitError;
	HRESULT hr;
	if( FAILED(hr = pDSBPrimary->SetFormat(pWfx)) )
		{
		DisableFormatCode(dwOutFormat);
		// If we couldn't load the desired format, then try everything starting
		// at really high quality, and degrading to 8M8 (yuck)
		char buf[1024];
		ostrstream(buf, sizeof(buf)) << "Unable to SetFormat() preferred format to " << dwOutFormat << ".\n" << '\0';
		DSERRMSG(1, buf);
		int nCurFormat;
		for (nCurFormat=0; nCurFormat < NUM_FORMATENTRIES; nCurFormat++)
			{
			dwOutFormat = aFormatOrder[nCurFormat];
			FormatCodeToWfx( dwOutFormat, pWfx );
			ostrstream(buf, sizeof(buf)) << "Trying format code: " << dwOutFormat << ".\n" << '\0';
			DSERRMSG(0, buf);
			if( CKDSERR(pDSBPrimary->SetFormat(pWfx)) )
				DisableFormatCode(dwOutFormat);
			else 
				{
				EnableFormatCode(dwOutFormat);
				break;
				}
			nCurFormat++;
			}
		if(nCurFormat == NUM_FORMATENTRIES) goto IPSB_ExitError;
		}
#ifdef DSBCAPS_CTRL3D
	if (!listener.Create(this)) goto IPSB_ExitError;
#endif
	if( CKDSERR(pDSBPrimary->Play(0, 0, DSBPLAY_LOOPING)) )	goto IPSB_ExitRelease;
	return true;
	
IPSB_ExitRelease:
	if(	pDSBPrimary )
		{	
		pDSBPrimary->Stop();
		pDSBPrimary->Release();
		pDSBPrimary = NULL;
		}
IPSB_ExitError:
	return FALSE;
    }
/* FormatCodeToWfx()
 *
 *    This function reads format codes and fills most of the fields of a
 * WAVEFORMATEX structure based on the values read.  It does not fill the
 * wFormatTag or cbSize members.
 *
 */
 bool CDSound::FormatCodeToWfx( DWORD dwFormat, PWAVEFORMATEX pWfx )
    {
    DWORD   dwFreq;

    if( NULL == pWfx )
    return FALSE;

    // Extract the sample rate
    dwFreq = FC_GETFREQCODE(dwFormat);
    pWfx->nSamplesPerSec = ( dwFreq == 8 ? 8000 : (dwFreq / 11) * 11025);

    pWfx->wBitsPerSample = (WORD)FC_GETBITS(dwFormat);
    pWfx->nChannels = (WORD)FC_GETCHANNELS(dwFormat);

    // The nBlockAlign calculation below only works for whole-byte samples
    ASSERT( pWfx->wBitsPerSample % 8 == 0 );

    pWfx->nBlockAlign = pWfx->nChannels * (pWfx->wBitsPerSample / 8);
    pWfx->nAvgBytesPerSec = pWfx->nBlockAlign * pWfx->nSamplesPerSec;

    return TRUE;
    }

void CDSound::DisableFormatCode( DWORD dwCode )
    {
    int i;

    for( i = 0; i < NUM_FORMATENTRIES; i++ )
    {
    if( fdFormats[i].dwCode == dwCode )
        {
        fdFormats[i].fEnable = FALSE;
        break;
        }
    }
    }


void CDSound::EnableFormatCode( DWORD dwCode )
    {
    int i;
    for( i = 0; i < NUM_FORMATENTRIES; i++ )
	    {
		if( fdFormats[i].dwCode == dwCode )
			{
			fdFormats[i].fEnable = TRUE;
			break;
			}
		}
    }
void CDSound::ChangeDevice(int devPos)
	{
	if (devPos == curDevPos) return;
	Release();
	Create(dwOutFormat, devPos, bExclusive);
	}
//----------------------------------------------------------------------------
//	CDSError
//
bool CDSError::Check(DWORD n, const char* msg, const char* fn, int ln)
	{
	if (n==DS_OK) return false;
	if (n==0) return false;
	DSErrorToString(err, desc, n);
	return CDXError::Check(n, msg, fn, ln);
	}
bool CDSError::DSErrorToString(char*& err, char*& desc, HRESULT hr)
	{
	err = "";
	desc = "Unknown direct sound error.";
	switch(hr)
		{
		case DSERR_ALLOCATED:
			err = "DSERR_ALLOCATED";
			desc = "The request failed because resources, such as a priority level, were already in use by another caller.";
			return true;
		case DSERR_ALREADYINITIALIZED:
			err = "DSERR_ALREADYINITIALIZED";
			desc = "The object is already initialized.";
			return true;
		case DSERR_BADFORMAT:
			err = "DSERR_BADFORMAT";
			desc = "The specified wave format is not supported.";
				return true;
		case DSERR_BUFFERLOST:
			err = "DSERR_BUFFERLOST";
				desc = "The buffer memory has been lost and must be restored.";
			return true;
		case DSERR_CONTROLUNAVAIL:
			err =  "DSERR_CONTROLUNAVAIL";
			desc = "The control (volume, pan, and so forth) requested by the caller is not available.";
			return true;
		case DSERR_GENERIC:
			err = "DSERR_GENERIC";
			desc = "An undetermined error occurred inside the DirectSound subsystem.";
			return true;
		case DSERR_INVALIDCALL:
			err = "DSERR_INVALIDCALL";
			desc = "This function is not valid for the current state of this object.";
			return true;
		case DSERR_INVALIDPARAM:
		 	err = "DSERR_INVALIDPARAM";
			desc = "An invalid parameter was passed to the returning function.";
			return true;
		case DSERR_NOAGGREGATION:
		 	err = "DSERR_NOAGGREGATION";
			desc = "The object does not support aggregation.";
			return true;
		case DSERR_NODRIVER:
		 	err = "DSERR_NODRIVER";
			desc = "No sound driver is available for use.";
			return true;
#ifdef DSERR_NOINTERFACE
		case DSERR_NOINTERFACE:
			err = "DSERR_NOINTERFACE";
			desc = "The requested COM interface is not available.";
			return true;
#endif
		case DSERR_OTHERAPPHASPRIO:
			err = "DSERR_OTHERAPPHASPRIO";
			desc = "Another application has a higher priority level, preventing this call from succeeding";
			return true;
		case DSERR_OUTOFMEMORY:
			err = "DSERR_OUTOFMEMORY";
			desc = "The DirectSound subsystem could not allocate sufficient memory to complete the caller's request.";
			return true;
		case DSERR_PRIOLEVELNEEDED:
			err = "DSERR_PRIOLEVELNEEDED";
			desc = "The caller does not have the priority level required for the function to succeed.";
			return true;
		case DSERR_UNINITIALIZED:
			err = "DSERR_UNINITIALIZED";
			desc = "The IDirectSound::Initialize method has not been called or has not been called successfully before other methods were called.";
			return true;
		case DSERR_UNSUPPORTED:
			err = "DSERR_UNSUPPORTED";
			desc = "The function called is not supported at this time.";
			return true;
		}
	return false;
	}
