#include <Hase/DSound/waveFile.h>
#pragma hdrstop
USING_NAMESPACE_HASE;

#ifndef ER_MEM
#define ER_MEM              0xe000
#endif

#ifndef ER_CANNOTOPEN
#define ER_CANNOTOPEN       0xe100
#endif

#ifndef ER_NOTWAVEFILE
#define ER_NOTWAVEFILE      0xe101
#endif

#ifndef ER_CANNOTREAD
#define ER_CANNOTREAD       0xe102
#endif

#ifndef ER_CORRUPTWAVEFILE
#define ER_CORRUPTWAVEFILE  0xe103
#endif

#ifndef ER_CANNOTWRITE
#define ER_CANNOTWRITE      0xe104
#endif

#define DELETE_CLEAR(x)	{if(x) delete (x); (x)=NULL;}


CWaveFile::CWaveFile()
	{
	pData = NULL;
	pWfx = NULL;
	dataSize = 0;
	}
CWaveFile::~CWaveFile()
	{
	delete pWfx;
	delete pData;
	}

bool CWaveFile::loadWfx(HMMIO hMmio, MMCKINFO& ckInfoRiff, MMCKINFO& ckInfo)
	{
	if ((lastError = (int)mmioDescend(hMmio, &ckInfoRiff, NULL, 0)) != 0)
		return false;
	if ((ckInfoRiff.ckid != FOURCC_RIFF) || (ckInfoRiff.fccType != mmioFOURCC('W', 'A', 'V', 'E')))
		{
		lastError = ER_NOTWAVEFILE;
		return false;
		}
			
	/* Search the input file for for the 'fmt ' chunk.     */
	ckInfo.ckid = mmioFOURCC('f', 'm', 't', ' ');
	if ((lastError = (int)mmioDescend(hMmio, &ckInfo, &ckInfoRiff, MMIO_FINDCHUNK)) != 0)
		return false;                
					
	/* Expect the 'fmt' chunk to be at least as large as <PCMWAVEFORMAT>;
	* if there are extra parameters at the end, we'll ignore them */
	
	if (ckInfo.cksize < (long) sizeof(PCMWAVEFORMAT))
		{
		lastError = ER_NOTWAVEFILE;
		return false;
		}
															
	/* Read the 'fmt ' chunk into <pcmWaveFormat>.*/     
	PCMWAVEFORMAT pcmWaveFormat;  // Temp PCM structure to load in.
	if (mmioRead(hMmio, (HPSTR) &pcmWaveFormat, (long) sizeof(pcmWaveFormat)) != (long) sizeof(pcmWaveFormat))
		{
		lastError = ER_CANNOTREAD;
		return false;
		}

	// Ok, allocate the waveformatex, but if its not pcm
	// format, read the next word, and thats how many extra
	// bytes to allocate.
	WORD cbExtraAlloc;	// Extra bytes for waveformatex 
	if (pcmWaveFormat.wf.wFormatTag == WAVE_FORMAT_PCM) cbExtraAlloc = 0;
	else
		{
		// Read in length of extra bytes.
		if ( mmioRead(hMmio, (char*)&cbExtraAlloc, sizeof(cbExtraAlloc)) != sizeof(cbExtraAlloc) )
			{
			lastError = ER_CANNOTREAD;
			return false;
			}
		}
							
	// Ok, now allocate that waveformatex structure.
	if ((pWfx = (WAVEFORMATEX*) new BYTE[sizeof(WAVEFORMATEX)+cbExtraAlloc]) == NULL)
		{
		lastError = ER_MEM;
		return false;
		}

	// Copy the bytes from the pcm structure to the waveformatex structure
	memcpy(pWfx, &pcmWaveFormat, sizeof(pcmWaveFormat));
	pWfx->cbSize = cbExtraAlloc;

	// Now, read those extra bytes into the structure, if cbExtraAlloc != 0.
	if (cbExtraAlloc != 0)
		{
		char* ptr = (char*)pWfx + sizeof(WAVEFORMATEX);
		if (mmioRead(hMmio, ptr, cbExtraAlloc) != cbExtraAlloc)
			{
			lastError = ER_NOTWAVEFILE;
			DELETE_CLEAR(pWfx);
			return false;
			}
		}

	/* Ascend the input file out of the 'fmt ' chunk. */
	if ((lastError = mmioAscend(hMmio, &ckInfo, 0)) != 0) return false;
	return true;
	}
bool CWaveFile::loadData(HMMIO hMmio, MMCKINFO& ckInfoRiff, MMCKINFO& ckInfo)
	{
	int error;
	error = mmioSeek(hMmio, ckInfoRiff.dwDataOffset + sizeof(FOURCC), SEEK_SET);
	ASSERT(error!=-1);
	//      Search the input file for for the 'data' chunk.
	ckInfo.ckid = mmioFOURCC('d', 'a', 't', 'a');
	if ((lastError = mmioDescend(hMmio, &ckInfo, &ckInfoRiff, MMIO_FINDCHUNK)) != 0)
		{
		return false;
		}
	dataSize = ckInfo.cksize;
	if ((pData = new BYTE[dataSize]) == NULL)
		{
		lastError = ER_MEM;
		return false;
		}
	MMIOINFO mmioInfo;
	if (lastError = mmioGetInfo(hMmio, &mmioInfo, 0) != 0)
		{
		DELETE_CLEAR(pData);
		return false;
		}
	for(int cT = 0; cT < dataSize;)
		{
		/* Copy the bytes from the io to the buffer. */
		if (mmioInfo.pchNext == mmioInfo.pchEndRead)
			{
			if ((lastError = mmioAdvance(hMmio, &mmioInfo, MMIO_READ)) != 0)
				{
				DELETE_CLEAR(pData);
				return false;
				} 
			if (mmioInfo.pchNext == mmioInfo.pchEndRead)
				{
				lastError = ER_CORRUPTWAVEFILE;
				DELETE_CLEAR(pData);
				return false;
				}
			}
		// Actual copy.
		int len = mmioInfo.pchEndRead - mmioInfo.pchNext;
		memcpy(pData+cT, mmioInfo.pchNext, len < dataSize-cT ? len : dataSize-cT);
		mmioInfo.pchNext += len;
		cT += len;
		}

	if ((lastError = mmioSetInfo(hMmio, &mmioInfo, 0)) != 0)
		{
		DELETE_CLEAR(pData);
		return false;
		}
	return true;
	}

bool CWaveFile::Load(const char* fn)
	{
	HMMIO           hMmio;
	MMCKINFO        ckInfoRiff;     // chunk info. for Riff.
	MMCKINFO		ckInfo;
	if (fn) fname = fn;
	// Initialization
	lastError = 0;
	hMmio = NULL;
	char fnameBuf[1024];
	strcpy(fnameBuf, fname.c_str());
	//	load wave file
	if ((hMmio = mmioOpen(fnameBuf, NULL, MMIO_ALLOCBUF | MMIO_READ)) == NULL)
		{
		lastError = ER_CANNOTOPEN;
		return false;
		}
	if (!loadWfx(hMmio, ckInfoRiff, ckInfo))
		{
		mmioClose(hMmio, 0);
		return false;
		}
	if (!loadData(hMmio, ckInfoRiff, ckInfo))
		{
		mmioClose(hMmio, 0);
		return false;
		}
	mmioClose(hMmio, 0);
	return true;
	}
bool CWaveFile::Save(const char* fn)
	{
	return false;
	}
void CWaveFile::Release()
	{
	DELETE_CLEAR(pData);
	dataSize = 0;
	}
