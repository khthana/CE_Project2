#include <Hase/DSound/HDSound.h>
#include <Hase/DSound/HDSBuf3D.h>
#pragma hdrstop
USING_NAMESPACE_HASE;
#define TOVEC3(v) CD3DVec3((v).x, (v).y, (v).z)
CDSBuf3D::CDSBuf3D(CDSound& cds):
	CDSBuf(cds)
	{
	pDSB3D = NULL;
	}
CDSBuf3D::CDSBuf3D():
	CDSBuf()
	{
	pDSB3D = NULL;
	}
CDSBuf3D::~CDSBuf3D()
	{
	RELEASE(pDSB3D);
	}
bool CDSBuf3D::AllocDSB()
	{
	RELEASE(pDSB3D);
    descDSB.dwFlags |= DSBCAPS_CTRL3D;
	if (!CDSBuf::AllocDSB()) return false;
    HRESULT hr = pDSB->QueryInterface(IID_IDirectSound3DBuffer, (void **)&pDSB3D);
	if( FAILED(hr) )
        {
        TRACE("QI for DS3DBuffer interface: %s", pCDS->HrToString(hr));
        return false;
        }
    return true;
	}

void CDSBuf3D::Pos(const CD3DVec3& v)
	{
	pDSB3D->SetPosition(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDSBuf3D::Pos()
	{
	D3DVECTOR v;
	pDSB3D->GetPosition(&v);
	return TOVEC3(v);
	}
void CDSBuf3D::Vel(const CD3DVec3& v)
	{
	pDSB3D->SetVelocity(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDSBuf3D::Vel()
	{
	D3DVECTOR v;
	pDSB3D->GetVelocity(&v);
	return TOVEC3(v);
	}
void CDSBuf3D::MaxDist(REAL d)
	{
	HRESULT hr = pDSB3D->SetMaxDistance(d, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	if (hr!= DS_OK) TRACE("faild.");
	}
REAL CDSBuf3D::MaxDist()
	{
	REAL d;
	pDSB3D->GetMaxDistance(&d);
	return d;
	}
void CDSBuf3D::MinDist(REAL d)
	{
	pDSB3D->SetMinDistance(d, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
REAL CDSBuf3D::MinDist()
	{
	REAL d;
	pDSB3D->GetMinDistance(&d);
	return d;
	}
void CDSBuf3D::Cone(CD3DVec2 v)
	{
	pDSB3D->SetConeAngles(v.x, v.y, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec2 CDSBuf3D::Cone()
	{
	DWORD x,y;
	pDSB3D->GetConeAngles(&x, &y);
	return CD3DVec2(x,y);
	}
void CDSBuf3D::ConeOri(CD3DVec3 v)
	{
	pDSB3D->SetConeOrientation(v.x, v.y, v.z, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
CD3DVec3 CDSBuf3D::ConeOri()
	{
	D3DVECTOR v;
	pDSB3D->GetConeOrientation(&v);
	return TOVEC3(v);
	}
void CDSBuf3D::OutVolume(REAL db)
	{
	pDSB3D->SetConeOutsideVolume(db*100, pCDS->bImmidiate ? DS3D_IMMEDIATE : DS3D_DEFERRED);
	}
REAL CDSBuf3D::OutVolume()
	{
	long l;
	pDSB3D->GetConeOutsideVolume(&l);
	return REAL(l)/REAL(100);
	}
