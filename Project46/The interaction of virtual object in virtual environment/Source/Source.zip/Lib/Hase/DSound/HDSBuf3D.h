#ifndef HaseDS_CDSBUF3D_H
#define HaseDS_CDSBUF3D_H
#include <Hase/DSound/HDSBuf.h>
BEGIN_NAMESPACE_HASE
class DLLCLASS CDSBuf3D:public CDSBuf
	{
	protected:
	public:
	LPDIRECTSOUND3DBUFFER pDSB3D;
	public:
	CDSBuf3D(CDSound& pCDS);
	CDSBuf3D();
	virtual	~CDSBuf3D();
	virtual bool	AllocDSB();
	//	don't use these non 3d oparations
	virtual void	Pan(double db){}
	virtual double	Pan(){return 0;}

	//	3d oparations
	virtual void	Pos(const CD3DVec3&);
	virtual CD3DVec3	Pos();
	virtual void	Vel(const CD3DVec3&);
	virtual CD3DVec3	Vel();
	virtual void	MaxDist(REAL max);
	virtual REAL	MaxDist();
	virtual void	MinDist(REAL min);
	virtual REAL	MinDist();
	virtual void	Cone(CD3DVec2 v);
	virtual CD3DVec2	Cone();
	virtual void	ConeOri(CD3DVec3 v);
	virtual CD3DVec3	ConeOri();
	virtual void	OutVolume(REAL v);
	virtual REAL	OutVolume();
	};

END_NAMESPACE_HASE
#endif
