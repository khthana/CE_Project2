#ifndef HaseDS_CDS3DBUF_H
#define HaseDS_CDS3DBUF_H
#include <Hase/DSound/HDSBuf.h>
BEGIN_NAMESPACE_HASE
#ifdef DSBCAPS_CTRL3D
class DLLCLASS CDS3DBuf:public CDSBuf
	{
	protected:
	public:
	LPDIRECTSOUND3DBUFFER pDSB3D;
	public:
	CDS3DBuf(CDSound& pCDS);
	CDS3DBuf();
	virtual	~CDS3DBuf();
	virtual bool	AllocDSB();
	//	don't use these non 3d oparations
	virtual void	Pan(double db){}
	virtual double	Pan(){return 0;}

	//	3d oparations
	virtual void	Pos(const CD3DVec3&);
	virtual CD3DVec3	Pos();
	virtual void	Vel(const CD3DVec3&);
	virtual CD3DVec3	Vel();
	virtual void	MaxDist(REAL max);
	virtual REAL	MaxDist();
	virtual void	MinDist(REAL min);
	virtual REAL	MinDist();
	virtual void	Cone(CD3DVec2 v);
	virtual CD3DVec2	Cone();
	virtual void	ConeOri(CD3DVec3 v);
	virtual CD3DVec3	ConeOri();
	virtual void	OutVolume(REAL v);
	virtual REAL	OutVolume();
	};
#endif
END_NAMESPACE_HASE
#endif
