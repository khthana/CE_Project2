#ifndef HASE_DSOUND_H
#define HASE_DSOUND_H
#include <Hase/Misc/Inc.h>
#include <mmsystem.h>
#include <dsound.h>
#include <Hase/DSound/HDS3DBuf.h>
#include <Hase/Dx/HDxError.h>
#include <Hase/Dx/HDxObj.h>
#include <Hase/Misc/Handle.h>
#define DSERRMSG(n, msg)	error.DXERRMSG((n), (msg))
#define CKDSERR(hr)			error.CKDXERR(hr)
#define CKDSERRMSG(hr, msg)	error.CKDXERRMSG((hr), (msg))
BEGIN_NAMESPACE_HASE

class DLLCLASS CDSError:public CDXError
	{
	public:
	virtual bool Check(DWORD n, const char* msg, const char* fn=NULL, int ln=0);
	static bool DSErrorToString(char*& err, char*& desc, HRESULT error);
	};
struct DLLCLASS CDSDevice
	{
	std::string description;
	std::string name;
	GUID* pGuid;
	CDSDevice(){pGuid=NULL;}
	CDSDevice(const CDSDevice& src);
	CDSDevice(const GUID* pGuid, const char* desc, const char* name);
	~CDSDevice(){delete pGuid;}
	bool operator ==(const CDSDevice&d) const {return name == d.name;}
	bool operator <(const CDSDevice&d) const {return name < d.name;}
	};
class CDSound;
class DLLCLASS CDSDevices: protected Array<CDSDevice>
	{
	static int _stdcall DSEnumCallBack(GUID FAR * lpGuid, const char* desc, const char* name, void* arg);
	static int _stdcall DSEnumCallBack(GUID FAR * lpGuid, char* desc, char* name, void* arg);
	friend CDSound;
	public:
	void Set(int i);
	const CDSDevice& operator [] (int i) const
		{
		return Bgn()[i];
		}
	int Size() const {return Array<CDSDevice>::Size();}
	};
#ifdef DSBCAPS_CTRL3D
class DLLCLASS CDSListener
	{
	protected:
	IDirectSound3DListener* pListener;
	CDSound* pCDS;
	public:
	CDSListener();
	~CDSListener();
	void Release();
	bool Create(CDSound* pCDS);
	void Af(const CD3DAffine& af);
	CD3DAffine Af();
	void Pos(const CD3DVec3& v);
	CD3DVec3 Pos();
	void Vel(const CD3DVec3& v);
	CD3DVec3 Vel();
	};
#endif
class DLLCLASS CDSWaves:public Handle<CDSBufBase>
	{
	friend CDSound;
	protected:
	CDSound* pCDS;
	public:
	int Load(const char* path, bool b3D = false);
	};
class CDSBuf;
class CDS3DBuf;
class CDSListener;
//	DirectSound�N���X�A�����1���΂悢
class DLLCLASS CDSound
	{
	friend CDSListener;
	friend CDSBuf;
	friend CDS3DBuf;
	protected:
	static int count;
	int curDevPos;
	IDirectSound* pDS;
	IDirectSoundBuffer*	pDSBPrimary;
	WAVEFORMATEX* pWfx;
	DWORD dwOutFormat;
	bool bExclusive;
	bool bImmidiate;
	HWND hWnd;
	void ChangeDevice(int devPos);
	bool InitPrimaryDSB();
	bool FormatCodeToWfx(DWORD dwFormat, PWAVEFORMATEX pwfx );
	void DisableFormatCode(DWORD dwCode);
	void EnableFormatCode(DWORD dwCode);
	void EnumDevice();

	public:
	enum{MAXVOL_VAL = 0, MIDPAN_VAL = 0};
	enum DSBufType {DSBUF, DSBUF3D};
	CDSWaves waves;
	CDSDevices devices;
#ifdef DSBCAPS_CTRL3D
	CDSListener listener;
#endif
	CDSError error;
	CDSound();
	~CDSound();
	//			44kHz 2 channel  16 bit
	bool Create(DWORD outFmt=44216, int devPos=0, bool bExclusiveMode=false);
	void Release();
	HWND HWnd();
	void HWnd(HWND hw);
	virtual void Immidiate(bool b){bImmidiate = b;}
	virtual bool Immidiate(){return bImmidiate;}
	};

END_NAMESPACE_HASE
#endif
