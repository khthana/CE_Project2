#ifndef HaseDS_WAVE_H
#define HaseDS_WAVE_H
#include <Hase/Misc/Inc.h>
#include <mmsystem.h>
#include <dsound.h>
#include <mmreg.h>

BEGIN_NAMESPACE_HASE
class CWaveFile
	{
	public:
	CWaveFile();
	~CWaveFile();
	bool Load(const char* fn=NULL);
	bool Save(const char* fn=NULL);
	void Release();
	std::string fname;
	WAVEFORMATEX* pWfx;
	BYTE* pData;
	size_t dataSize;
	int lastError;
	protected:
	bool loadWfx(HMMIO hMmio, MMCKINFO& ckInfoRiff, MMCKINFO& ckInfo);
	bool loadData(HMMIO hMmio, MMCKINFO& ckInfoRiff, MMCKINFO& ckInfo);
	};
END_NAMESPACE_HASE

#endif
