copy *.htm u:\public_html\*.html
copy *.html u:\public_html\*.html
