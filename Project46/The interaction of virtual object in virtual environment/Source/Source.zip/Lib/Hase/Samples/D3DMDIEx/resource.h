//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D3DMDIEx.rc
//
#define IDUPDATE                        3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_D3DMDIEXTYPE                129
#define IDD_D3DMODE                     131
#define IDC_DRIVER                      1003
#define IDC_WINDRIVER                   1003
#define IDC_SCREEN                      1004
#define IDC_FULLDRIVER                  1005
#define ID_BTN_D3DDLG                   32771
#define ID_SETCLIP                      32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
