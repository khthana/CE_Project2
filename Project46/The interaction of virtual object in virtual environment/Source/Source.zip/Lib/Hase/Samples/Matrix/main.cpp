#include <hase/misc/matrix.h>
#include <iostream>
using namespace std;
USING_NAMESPACE_HASE;
void main()
	{
	Matrix mat(30,10);
	mat[1][1] = 1;
	mat[2][2] = 2;
	mat[3][3] = 3;
	mat[1][4] = 1;
	mat[2][5] = 1;
	mat[3][6] = 1;
	mat *= 3;
	cout << mat << "\n";
	cout << mat.PInv();
	char ch;
	cin >> ch;
	}