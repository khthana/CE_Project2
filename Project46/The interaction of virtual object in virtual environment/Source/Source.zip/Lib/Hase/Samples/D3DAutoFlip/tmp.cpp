
//----------------------------------------------------------------------------
//	CAutoFlip
//
CAutoFlip::CAutoFlip()
	{
	nBackBuffer = 1;
	purposeTable = NULL;
	nPurpose = 0;
	bRunFlipThread = false;
	bExitFlipThread = false;
	frontPurpose = 0;
	}
CAutoFlip::~CAutoFlip()
	{
	ReleasePurposeTable();
	Release();
	}
DWORD WINAPI CAutoFlip::FlipThreadFunc(void* pContext)
	{
	CAutoFlip& surf = *(CAutoFlip*)pContext;
	surf.FlipThead();
	return 0;
	}
void CAutoFlip::FlipThread()
	{
	while(!bExitFlipThread)
		{
		int nextPurpose = frontPurpose;
		nextPurpose ++;
		if (nextPurpose >= nPurpose) nextPurpose=0;
/*		//	�f�o�b�O�p�Ƀe�[�u����\��
		int i;
		TRACE("FP: %d   NP: %d\n",frontPurpose, nextPurpose);
		TRACE("PT0:");
		for(i=0; i<nBackBuffer+1; i++)
			{
			TRACE("%3d", purposeTable[i][0]);
			}
		TRACE("\n");
		TRACE("PT1:");
		for(i=0; i<nBackBuffer+1; i++)
			{
			TRACE("%3d", purposeTable[i][1]);
			}
		TRACE("\n");
*/
		if (purposeTable[nextPurpose][1] == NOSURFACE)
			{	//	�X�V�����t���b�v
			if (pCDD->surfPrimary.pDDS->Flip(Back(nextPurpose,0).pDDS, DDFLIP_WAIT) != DD_OK)
				{
				TRACE("CAutoFlip::FlipThead(): Fliping surface %d without update failed.\n", purposeTable[nextPurpose][0]);
				}
			else
				{
				std::swap(purposeTable[nextPurpose][0], purposeTable[frontPurpose][0]);
				frontPurpose = nextPurpose;
				}
			}
		else	//	�X�V
			{
			//	�󂫖ړI�̌���
			int vacant;
			for(int t=0; t<timeout; t++)
				{
				for(vacant=nPurpose; vacant<nBackBuffer+1; vacant++)
					if (purposeTable[vacant][0] == NOSURFACE) goto next;
				Sleep(5);
				}
next:
			if (t == timeout)
				{
				TRACE("FlipSurface::FlipThead(): No vacant surface. cannot update.\n");
				}
			else
				{
				if (pCDD->surfPrimary.pDDS->Flip(Back(nextPurpose,1).pDDS, DDFLIP_WAIT) != DD_OK)
					{
					TRACE("CAutoFlip::FlipThead(): Fliping surface %d with update failed.\n", purposeTable[nextPurpose][1]);
					}
				else
					{
					purposeTable[vacant][0] = purposeTable[nextPurpose][0];			//	�g�p�ς݃o�b�t�@���󂫃o�b�t�@�ɂ��ă��T�C�N��
					purposeTable[nextPurpose][0] = purposeTable[nextPurpose][1];	//	���Ɏg�p����o�b�t�@�����ݎg�p���Ă���o�b�t�@��
					purposeTable[nextPurpose][1] = NOSURFACE;						//	���Ɏg�p����o�b�t�@�͂Ȃ�
					std::swap(purposeTable[nextPurpose][0], purposeTable[frontPurpose][0]);
					frontPurpose = nextPurpose;
					}
				}
			}
		}
	bExitFlipThread = false;
	bRunFlipThread = false;
	}
void CAutoFlip::NBuffer(int nb)
	{
	ReleasePurposeTable();
	if (nb<2) nb = 2;
	if (nBackBuffer != nb-1) 
		{
		nBackBuffer = nb-1;
		Release();
		}
	if (nPurpose>nBackBuffer) nPurpose=nBackBuffer;
	}
void CAutoFlip::ReleasePurposeTable()
	{
	if (!purposeTable) return;
	StopAutoFlip();
	for(int i=0; i<nBackBuffer+1; i++) delete (int*)purposeTable[i];
	delete purposeTable;
	purposeTable = NULL;
	}
bool CAutoFlip::CreatePurposeTable()
	{
	/*	purposeTable �ɂ���
	purposeTable[i][0]	:	����i�����݉ʂ����Ă���o�b�t�@�̔ԍ�
	purposeTable[i][1]	:	����i�����ɉʂ����o�b�t�@�̔ԍ�
	purposeTable[i][2]	:	����i���X�V���ɉʂ����\��̃o�b�t�@�̔ԍ�
	purposeTable[nPurpose..nBackBuffer-1][0]
					:	���������̂Ȃ��o�b�t�@
	purposeTable[nBackBuffer]
					:	���݂̕`��p�o�b�t�@
	NOSURFACE		:	�o�b�t�@���Ȃ����Ƃ�\���ԍ�
	FRONTSURFACE	:	�\����ʂ�\���ԍ�
	*/
	if (purposeTable) return true;
	if (!Create()) return false;
	if (backs.Size() == 0)
		{
		TRACE("Surfaces must have two or more back buffers to call CAutoFlip::CreatePurposeTable().\n");
		return false;
		}
	purposeTable = (volatile int**)new int*[nBackBuffer+1];
	int i;
	for(i=0; i<nBackBuffer+1; i++) purposeTable[i] = new int[3];
	for(i=0; i<nBackBuffer+1; i++)
		{
		purposeTable[i][1] = NOSURFACE;
		purposeTable[i][2] = NOSURFACE;
		}
	for(i=0; i<nBackBuffer-1; i++) purposeTable[i][0] = i;
	purposeTable[nBackBuffer-1][0] = FRONTSURFACE;
	purposeTable[nBackBuffer][0] = nBackBuffer-1;
	*(CDDSInterface*)this = backs[purposeTable[nBackBuffer][0]];
	frontPurpose = nBackBuffer-1;
	return true;
	}
void CAutoFlip::NPurpose(int n)
	{
	if (n<0) n=0;
	if (n>nBackBuffer) n=nBackBuffer;
	nPurpose = n;
	}
bool CAutoFlip::SetPurpose(int purpose, bool bDelay)
	{
	if (!CreatePurposeTable()) return false;
	if (purpose<0 || purpose >= nPurpose)
		{
		pCDD->DDERRMSG("Bad purpose.\n");
		return false;
		}
	//	�󂢂Ă���o�b�t�@��T��
	int freeBuf;
	for(freeBuf=nPurpose; freeBuf<nBackBuffer; freeBuf++)
		if (0<=purposeTable[freeBuf][0]) break;
	if (freeBuf==nBackBuffer && !bRunFlipThread)
		{
		pCDD->DDERRMSG("No freeBuf back buffer.\n");
		return false;//	�󂫃o�b�t�@���Ȃ��Ƃ�
		}
	
	if (bDelay)
		{
		if (purposeTable[purpose][2] != NOSURFACE)
			{
			pCDD->DDERRMSG("Another surface is waiting for update.\n");
			return false;
			}
		purposeTable[purpose][2] = purposeTable[nBackBuffer][0];
		purposeTable[nBackBuffer][0] = NOSURFACE;
		}
	else
		{
		if (purposeTable[purpose][1] != NOSURFACE)
			{
			pCDD->DDERRMSG("Another surface is waiting for update.\n");
			return false;
			}
		purposeTable[purpose][1] = purposeTable[nBackBuffer][0];
		purposeTable[nBackBuffer][0] = NOSURFACE;
		}
	for (int t=0; t<timeout; t++)
		{
		for(freeBuf=nPurpose; freeBuf<nBackBuffer+1; freeBuf++)
			if (0<=purposeTable[freeBuf][0]) goto next;
		Sleep(5);
		}
	
	pCDD->DDERRMSG("Timeouted wating for free surface.\n");
	int i;
	TRACE("FP: %d\n",frontPurpose);
	TRACE("PT0:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][0]);
		}
	TRACE("\n");
	TRACE("PT1:");
	for(i=0; i<nBackBuffer+1; i++)
		{
		TRACE("%3d", purposeTable[i][1]);
		}
	TRACE("\n");
	Release();
	return false;
next:
	//	�󂫃o�b�t�@�𔭌�
	if (freeBuf != nBackBuffer)
		{
		purposeTable[nBackBuffer][0] = purposeTable[freeBuf][0];
		purposeTable[freeBuf][0] = NOSURFACE;
		}
	return true;
	}
bool CAutoFlip::UpdatePurpose()
	{
	if (!CreatePurposeTable()) return false;
	bool rtv = true;
	for(int i=0; i<nPurpose; i++)
		{
		if (purposeTable[i][2] != NOSURFACE)
			{
			if (purposeTable[i][1] == NOSURFACE)
				{
				std::swap(purposeTable[i][1], purposeTable[i][2]);
				}
			}
		else rtv = false;
		}
	return rtv;
	}
bool CAutoFlip::StartAutoFlip()
	{
	if (bRunFlipThread) return true;
	if (!CreatePurposeTable()) return false;
	DWORD flipThreadID = 0;
	HANDLE hThread = CreateThread(NULL, 0x1000, FlipThreadFunc, this, 0, &flipThreadID);
	if (hThread)
		{
		bRunFlipThread = true;
		SetThreadPriority(hThread, THREAD_PRIORITY_ABOVE_NORMAL);
		}
	return bRunFlipThread;
	}
void CAutoFlip::StopAutoFlip()
	{
	if (!bRunFlipThread) return;
	bExitFlipThread = true;
	for(int t=0; t<timeout*3 && bRunFlipThread; t++) Sleep(5);
	}

//----------------------------------------------------------------------------
//	CAutoFlipSurface
//
HRESULT WINAPI CAutoFlipSurface::EnumBackBufferCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext)
	{
	if (!(pDesc->ddsCaps.dwCaps & DDSCAPS_BACKBUFFER)) return DDENUMRET_OK;
	return EnumSurfacesCallback(pDDS, pDesc, pContext);
	}
HRESULT WINAPI CAutoFlipSurface::EnumSurfacesCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext)
	{
	CAutoFlipSurface& surf = *(CAutoFlipSurface*)pContext;
	CDDSInterface newSurf;
	newSurf.pDDS = pDDS;
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface2, (void**)&newSurf.pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface3, (void**)&newSurf.pDDS3);
#endif
	surf.backs.Add(newSurf);
	return DDENUMRET_OK;
	}

CAutoFlipSurface::CAutoFlipSurface()
	{
	}
CAutoFlipSurface::~CAutoFlipSurface()
	{
	Release();
	}
bool CAutoFlipSurface::Flip()
	{
	return CFlipSurface::Flip();
	}
bool CAutoFlipSurface::Flip(int n)
	{
	CAutoFlip::Flip(n);
	*(CDDSInterface*)this = backs[purposeTable[nBackBuffer][0]];
	return true;
	}
bool CAutoFlipSurface::Create(bool bCallCallback)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	if (!Create(bCallCallback, nBackBuffer)) return false;
	if (pCDD->IsFullscreen())
		{
		CDDSurface& surfPri = pCDD->surfPrimary;
		backs.Add(*this);
		for(int i=0; i<nBackBuffer-1; i++)
			backs.End()[-1].pDDS->EnumAttachedSurfaces(this, EnumSurfacesCallback);
		if (backs.Size() != nBackBuffer) goto leave;
		//	set palette
		if (desc.ddpfPixelFormat.dwFlags&DDPF_PALETTEINDEXED8) 
			{
			if (!pCDD->CreatePalette()) goto leave;
			for(int i=1; i<nBackBuffer; i++)
				if (pCDD->CKDDERR(backs[i].pDDS->SetPalette(pCDD->pPalette))) goto leave;
			}
		bFlippable = true;
		}
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	Release();
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CAutoFlipSurface::Release(bool bCallCallback)
	{
	if (!pDDS && backs.Size() == 0) return;
	CDD_ENTER_CRITICAL;
	ReleasePurposeTable();
	if (!pCDD) goto leave;
	backs.Clear();
	CFlipSurface::Release();
leave:
	CDD_LEAVE_CRITICAL;
	}
