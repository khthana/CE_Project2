// D3DSDIExView.cpp : CD3DSDIExView �N���X�̓���̒�`���s���܂��B
//
#include "stdafx.h"
#pragma hdrstop
#include "D3DSDIEx.h"
#include "D3DSDIExView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CD3DSDIExView
CDDraws CD3DSDIExView::ddraw;

IMPLEMENT_DYNCREATE(CD3DSDIExView, CView)

BEGIN_MESSAGE_MAP(CD3DSDIExView, CView)
	//{{AFX_MSG_MAP(CD3DSDIExView)
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CD3DSDIExView �N���X�̍\�z/����

CD3DSDIExView::CD3DSDIExView()
	{
	// TODO: ���̏ꏊ�ɍ\�z�p�̃R�[�h��ǉ����Ă��������B
	}

CD3DSDIExView::~CD3DSDIExView()
	{
	d3drm.Release();
	surf.Release();
	}

BOOL CD3DSDIExView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: ���̈ʒu�� CREATESTRUCT cs ���C������ Window �N���X�܂��̓X�^�C����
	//  �C�����Ă��������B
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CD3DSDIExView �N���X�̕`��

void CD3DSDIExView::OnDraw(CDC* pDC)
{
	CD3DSDIExDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: ���̏ꏊ�Ƀl�C�e�B�u �f�[�^�p�̕`��R�[�h��ǉ����܂��B
}

/////////////////////////////////////////////////////////////////////////////
// CD3DSDIExView �N���X�̐f�f

#ifdef _DEBUG
void CD3DSDIExView::AssertValid() const
{
	CView::AssertValid();
}

void CD3DSDIExView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CD3DSDIExDoc* CD3DSDIExView::GetDocument() // ��f�o�b�O �o�[�W�����̓C�����C���ł��B
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CD3DSDIExDoc)));
	return (CD3DSDIExDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CD3DSDIExView �N���X�̃��b�Z�[�W �n���h��

void CD3DSDIExView::OnInitialUpdate() 
	{
	CView::OnInitialUpdate();
	
	// TODO: ���̈ʒu�ɌŗL�̏�����ǉ����邩�A�܂��͊�{�N���X���Ăяo���Ă�������
	((CD3DSDIExApp*)AfxGetApp())->view = this;
#if 1
	ddraw.Primary().HWnd(m_hWnd);
//	ddraw.ddraws[1].HWnd(m_hWnd);
	surf.EnumDrivers();
	surf.drivers.Set(2);
	surf.HWnd(m_hWnd);
	surf.NBuffer(4);
	surf.Create();
	d3drm.Surf(surf);
#else
	d3drm.Set(m_hWnd);
#endif
	if (d3drm.Create())
		{
		BuildScene();
		d3drm.Scene()->SetSceneBackground(D3DRGB(0.4,0.6,0.9));
		//	�ϐ��̏�����
		now=CD3DAffine(0,500,0);
		}
	}

void CD3DSDIExView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	static UINT lastFlags;
	static CPoint pLStart, pRStart;
	if (!(lastFlags&MK_LBUTTON) && (nFlags&MK_LBUTTON))
		{
		pLStart = point;
		SetCapture();
		}
	else if (nFlags&MK_LBUTTON)
		{
		CSize delta = point - pLStart;
		mouseLDrag.x = delta.cx;
		mouseLDrag.y = delta.cy;
		}
	else
		{
		mouseLDrag = CD3DVec2();
		}

	if (!(lastFlags&MK_RBUTTON) && (nFlags&MK_RBUTTON))
		{
		pRStart = point;
		SetCapture();
		}
	else if (nFlags&MK_RBUTTON)
		{
		CSize delta = point - pRStart;
		mouseRDrag.x = delta.cx;
		mouseRDrag.y = delta.cy;
		}
	else
		{
		mouseRDrag = CD3DVec2();
		}
	if (nFlags == 0) ReleaseCapture();
	lastFlags = nFlags;

	CView::OnMouseMove(nFlags, point);
}

#define groundHeight	REAL(15)
#define rebound			REAL(0.7)
#define gravity			REAL(0.2)			//	�d�͉����x(���̒l)
#define delta			REAL(0.2)
#define airResist		CD3DVec3(REAL(0.02), REAL(0.02), REAL(0.02))
void CD3DSDIExView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	if (nChar == VK_NUMPAD8) accel = now.Rot(CD3DVec3(0,0,delta));
	if (nChar == VK_NUMPAD2) accel = now.Rot(CD3DVec3(0,0,-delta));
	if (nChar == VK_NUMPAD1) now*=CD3DAffine(-1,0,0);
	if (nChar == VK_NUMPAD3) now*=CD3DAffine(1,0,0);
	if (nChar == VK_NUMPAD4) now*=CD3DAffine(Rad(-5), 'y');
	if (nChar == VK_NUMPAD6) now*=CD3DAffine(Rad(5), 'y');
	if (nChar == VK_NUMPAD5) head*=CD3DAffine(Rad(-5), 'x');
	if (nChar == VK_NUMPAD0) head*=CD3DAffine(Rad(5), 'x');
	if (nChar == VK_NUMPAD7) head*=CD3DAffine(Rad(-5), 'z');
	if (nChar == VK_NUMPAD9) head*=CD3DAffine(Rad(5), 'z');
	if (nChar == VK_DECIMAL) vel = CD3DVec3();
	if (nChar == VK_SPACE) accel = CD3DVec3(0, 2, 0);
	if (nChar == 'R')
		{
		ddraw.Primary().surfPrimary.Release();
		}
	if (nChar == 'F')
		{
		if (ddraw.Primary().IsFullscreen())
			{
			ddraw.Primary().Window();
			surf.RestoreWindowPlace();
			}
		else
			{
			surf.SaveWindowPlace();
			ddraw.Primary().Fullscreen(640, 480, 16);
			surf.FitWindow(CPoint(0,0), CSize(50,100));
			surf.NPurpose(2);
			surf.NBuffer(4);
			surf.StartAutoFlip();
			}
		}
	if (nChar == '1' && ddraw.ddraws.Size()>1)
		{
		if (ddraw.Primary().IsFullscreen()) 
			{
			ddraw.Primary().Window();
			surf.DDraw(ddraw.Primary());
			}
		else if (ddraw.ddraws[1].IsFullscreen()) 
			{
			ddraw.Primary().Window();
			ddraw.ddraws[1].Window();
			surf.DDraw(ddraw.Primary());
			}
		else 
			{
			ddraw.ddraws[1].Fullscreen(1024,768,16);
			surf.FitWindow(CPoint(0,0), CSize(100,100));
			surf.DDraw(ddraw.ddraws[1]);
			}
		}
	
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CD3DSDIExView::Step()
	{
	//---------------------------------------------------------------
	//	���͏���
	//
	now *= CD3DAffine(Rad(mouseLDrag.x * 0.1) ,'y');
	now *= CD3DAffine(0, 0, -mouseLDrag.y * 0.01);
	now	*= CD3DAffine(Rad(mouseRDrag.x * 0.1) ,'z');
	now	*= CD3DAffine(Rad(mouseRDrag.y * 0.1) ,'x');
	//---------------------------------------------------------------
	//	���_�̈ړ�����
	//
#if 1
	//	�ʒu���X�V
	vel += accel;
	accel = CD3DVec3();
	now.Pos(now.Pos() + vel);
	player.AfParent(now);
	//	�̂̓����蔻��
	static CD3DVec3 lastColPos;
	CRMIsects crsPlayer;
	CRMIsects crsScene;
	player.FindSceneIsect(crsPlayer, crsScene);
	CD3DVec3 normal, pos;
	int count=0;
	for(int i=0; i<crsPlayer.Size(); i++)
		{
		if (crsPlayer[i]->pFrame == &player.Ext())
			{
			normal += crsPlayer[i]->pair->normal;
			pos += crsPlayer[i]->pair->pos + playerRadius*crsPlayer[i]->pair->normal;
			count ++;
			}
		}
	crsPlayer.Effect();
	if (count > 0)
		{
		normal = normal.Unit();
		pos = pos / count;
		lastColPos = pos;
		TRACE("Col: num=%d n(%f,%f,%f) p(%f,%f,%f)\n", crsPlayer.Size(), normal.x, normal.y, normal.z, pos.x, pos.y, pos.z);
		now.Pos(pos);
		REAL ip = vel * normal;
		if (ip < -gravity*4)
			{
			vel = vel - (1+rebound) * ip * normal;	//	����
			}
		else if (ABS(ip) < gravity*4)				//	���ꂪ�Ȃ��Ǝ��_���U������
			{
			vel = vel - ip * normal;				//	���˒�~
			now.Pos( now.Pos() + vel);				//	���ꂪ�Ȃ��ƍ��o��Ȃ�
			}
		}
	if (now.Pos().y < groundHeight + playerRadius)
		{
		now.PosY() = groundHeight + playerRadius;
		if (-vel.y > 4*gravity) vel.y = - rebound * vel.y;
		else if (ABS(vel.y) < 4*gravity) vel.y = REAL(0);
		}
	//	�d�͉���
	vel += CD3DVec3(REAL(0), -gravity, REAL(0));
	//	��C��R
	vel.x -= vel.x * airResist.x;
	vel.y -= vel.y * airResist.y;
	vel.z -= vel.z * airResist.z;
	//	�ʒu�̕ۑ�
	last = now;
	//	�v���C���[�̈ʒu��ݒ�
	CD3DAffine afCam = CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0, 200, now.Pos().y - lastColPos.y));
	player.AfParent(now);
	d3drm.Camera().AfParent(afCam * head * CD3DAffine(0, playerRadius/1.5, -5));
#else
	player.Motion().vel += accel;
	accel = CD3DVec3(0,0,0);
	d3drm.Scene().Step(0.2f);
	CD3DAffine afW;
	afW.Pos(player.AfWorld().Pos());
	player.AfWorld(afW);
	CD3DAffine afCam = CD3DAffine(CD3DVec3(1,0,0), CD3DVec3(0, 200, afW.Pos().y));
	d3drm.Camera().AfParent(afCam * head * CD3DAffine(0, playerRadius/1.5, -5));
#endif
	Sleep(10);
	if (ddraw.Primary().IsFullscreen())
		{
		d3drm.Camera().AfParent(afCam * head * CD3DAffine(-0.03, playerRadius/1.5, -5));
		d3drm.FitSurface();
		d3drm.Clear();
		d3drm.Render();
		d3drm.Update();
		d3drm.SetPurpose(1, true);
		d3drm.Camera().AfParent(afCam * head * CD3DAffine(0.03, playerRadius/1.5, -5));
		d3drm.FitSurface();
		d3drm.Clear();
		d3drm.Render();
		d3drm.Update();
		d3drm.UpdatePurpose();
		d3drm.SetPurpose(0);
		}
	else
		{
		d3drm.Camera().AfParent(afCam * head * CD3DAffine(0, playerRadius/1.5, -5));
		d3drm.Step();
		}
	}

void CD3DSDIExView::BuildScene()
	{
	//	����
	CRMFrameEx lights;
	lights.Add(CRMLight(D3DRMLIGHT_AMBIENT, D3DRGB(0.6, 0.6, 0.6)));
	lights.Add(CRMLight(D3DRMLIGHT_DIRECTIONAL, D3DRGB(0.5, 0.5, 0.5)));
	d3drm.Scene().Add(lights);

	//	�n�`
	CRMFrameEx fFrontier;
	fFrontier.Load("frontier.x");
	fFrontier.AfParent(CD3DAffine() * 30);
	fFrontier.Ext().PMotion(new CAbsMotion);
	d3drm.Scene().Add(fFrontier);

	//	�v���C���[�̎p
	d3drm.Scene().Add(player);
	player.Add(d3drm.Camera());
	player.Name("player");
	player.Ext().MoveThis();
	CRMMeshEx mPriest("Priest.x");
	mPriest.Pos(CD3DVec3(0, -1, 0));
	mPriest.Ext().colPrec = CColVisual::GLOBE;
	mPriest.Ext().UpdateGlobe();
	playerRadius = mPriest.Ext().radius;
	player.Add(mPriest);
	player.Ext().MoveThis();
	player.Ext().PMotion(new CSolidMotion);
	player.AfWorld(CD3DAffine(0,500,0));

	//	�V�[��
	d3drm.ViewFrustum(CRMViewFrustum(3, 5000.0));
	d3drm.Scene().ExtAll();
	d3drm.Scene().Ext().AddForce(CGravity(CD3DVec3(0,-gravity,0)));
	}

BOOL CD3DSDIExView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	
	// CView::OnEraseBkgnd(pDC);
	return true;
}

void CD3DSDIExView::OnActive()
	{
	if (ddraw.Primary().pPalette)
		{
		ddraw.Primary().surfPrimary.pDDS->SetPalette(ddraw.Primary().pPalette);
		surf.pDDS->SetPalette(ddraw.Primary().pPalette);
		}
	}
