@echo off
zcopy /s /del *.bak *.~?? *.exe *.obj *.pch *.tds *.dcu
