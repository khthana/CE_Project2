//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SAMPLE.RC
//
#define IDR_MAINFRAME				128
#define IDR_SAMPLETYPE				129
#define IDD_ABOUTBOX				100

// ���̃f�t�H���g�l�͐V�K�I�u�W�F�N�g�p�̒l�ł�
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS			1
#define _APS_NEXT_RESOURCE_VALUE	130
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
