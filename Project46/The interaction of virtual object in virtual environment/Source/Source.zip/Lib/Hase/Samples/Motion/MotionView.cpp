// MotionView.cpp : CMotionView �N���X�̓���̒�`���s���܂��B
//

#include "stdafx.h"
#include "Motion.h"

#include "MotionDoc.h"
#include "MotionView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMotionView

IMPLEMENT_DYNCREATE(CMotionView, CView)

BEGIN_MESSAGE_MAP(CMotionView, CView)
	//{{AFX_MSG_MAP(CMotionView)
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMotionView �N���X�̍\�z/����

CMotionView::CMotionView()
	{	
	}

CMotionView::~CMotionView()
	{
	}

BOOL CMotionView::PreCreateWindow(CREATESTRUCT& cs)
	{
	return CView::PreCreateWindow(cs);
	}

/////////////////////////////////////////////////////////////////////////////
// CMotionView �N���X�̕`��

void CMotionView::OnDraw(CDC* pDC)
	{
	CMotionDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	}

/////////////////////////////////////////////////////////////////////////////
// CMotionView �N���X�̐f�f

#ifdef _DEBUG
void CMotionView::AssertValid() const
	{
	CView::AssertValid();
	}

void CMotionView::Dump(CDumpContext& dc) const
	{
	CView::Dump(dc);
	}

CMotionDoc* CMotionView::GetDocument() // ��f�o�b�O �o�[�W�����̓C�����C���ł��B
	{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMotionDoc)));
	return (CMotionDoc*)m_pDocument;
	}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMotionView �N���X�̃��b�Z�[�W �n���h��

void CMotionView::OnInitialUpdate() 
	{
	CView::OnInitialUpdate();
	((CMotionApp*)AfxGetApp())->view = this;
	ddraw.HWnd(m_hWnd);
	surf.drivers.Set(2);
	surf.HWnd(m_hWnd);
	surf.Create();
	rm.Surf(surf);
	rm.Create();
	BuildScene();
	}
CRMFrameEx frWall[6];
CRMFrameEx frBall[6];
void CMotionView::Step()
	{
	//	���̕ǂ𓮂���
	static int actCount;
	if (actCount < 3)
		{
		((CAbsMotion&)frWall[2].Motion()).vel = CD3DVec3(-2, 0, 0);
		actCount ++;
		}
	else if (actCount < 5)
		{
		((CAbsMotion&)frWall[2].Motion()).vel = CD3DVec3(2, 0, 0);
		actCount ++;
		}
	else actCount = 0;
	rm.Step();						//	�`��
	rm.Scene().Step(REAL(0.02));	//	�^���V�~�����[�^
	}
void CMotionView::BuildScene()
	{
	int i;
	//	����
	CRMFrameEx frLight;
	frLight.AfParent(CD3DAffine(0,3,0));
	frLight.Add(CRMLight(D3DRMLIGHT_POINT, D3DRGB(1, 1, 1)));
	frLight.Add(CRMLight(D3DRMLIGHT_AMBIENT, D3DRGB(0.3, 0.3, 0.3)));
	rm.Scene().Add(frLight);
	CD3DAffine afCam(0.5, 2, 0);
	afCam = afCam.LookAt(CD3DVec3(0,0,0));
	rm.Camera().AfParent(afCam);

	//	�����萔
	REAL bound = REAL(0.9);
	CMotionMaterial::Def().Bound(bound);
	CMotionMaterial::Def().MoveFriction(REAL(0.1));
	rm.Scene().Add(CGravity(CD3DVec3(0, REAL(-9.8), 0)));
	//	��
	CRMMeshEx meshWall("disc.x");
	meshWall.Scale(CD3DVec3(1,1,1));
	meshWall.Ext(new CRMColPlane);
	for(i=0; i<4; i++)
		{
		frWall[i].Add(meshWall);
		frWall[i].Motion(CAbsMotion());
		rm.Scene().Add(frWall[i]);
		}
	frWall[0].AfParent( CD3DAffine(CD3DVec3(0,0, 1), CD3DVec3(1,0,0), 'z', CD3DVec3( 0, 0,-0.5f)) );
	frWall[1].AfParent( CD3DAffine(CD3DVec3(0,0,-1), CD3DVec3(1,0,0), 'z', CD3DVec3( 0, 0, 0.5f)) );
	frWall[2].AfParent( CD3DAffine(CD3DVec3( 1,0.3f,0), CD3DVec3(0,1,0), 'z', CD3DVec3(-0.5f, 0, 0)) );
	frWall[3].AfParent( CD3DAffine(CD3DVec3(-1,3,0), CD3DVec3(0,1,0), 'z', CD3DVec3( 0, 0, 0)) );
	CRMTexture tex("sphere.bmp");
	CRMMeshEx mesh2("sphere.x");
	mesh2.ColPrec() = CColVisual::GLOBE;
	mesh2.Set(tex, D3DRMWRAP_CYLINDER, 'y');
	mesh2.Scale(CD3DVec3(0.1f,0.1f,0.1f));	//	���a20cm
	for(i=0; i<4; i++)
		{
		CRMFrameEx fr2;
		fr2.Add(mesh2);
		rm.Scene().Add(fr2);
		REAL sc = sqrt(i+1);				//	���a��sc�{
		fr2.AfParent(CD3DAffine((i%4)*0.2, i/4*0.2 + 0.5, REAL(i) / 100.0) * sc);
		CSolidMotion m;
		m.mass = 5*(i+1);					//	����
		REAL in = REAL(0.4*m.mass*sc*0.2*sc*0.2);
		m.inertia = CD3DVec3(in,in,in);		//	���̊������[�����g�� 0.4*m*r^2
		fr2.Motion(m);
		}
	rm.Scene().ExtAll();
	}

void CMotionView::OnSize(UINT nType, int cx, int cy) 
	{
	CView::OnSize(nType, cx, cy);
	
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����Ă�������
	surf.Release();
	}

void CMotionView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
	{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	if (nChar == 'F')
		{
		if (ddraw.Primary().IsFullscreen()) ddraw.Primary().Window();
		else ddraw.Primary().Fullscreen(640,480,16);
		}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
	}
