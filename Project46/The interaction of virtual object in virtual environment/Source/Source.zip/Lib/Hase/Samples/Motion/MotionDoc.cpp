// MotionDoc.cpp : CMotionDoc �N���X�̓���̒�`���s���܂��B
//

#include "stdafx.h"
#include "Motion.h"

#include "MotionDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMotionDoc

IMPLEMENT_DYNCREATE(CMotionDoc, CDocument)

BEGIN_MESSAGE_MAP(CMotionDoc, CDocument)
	//{{AFX_MSG_MAP(CMotionDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMotionDoc �N���X�̍\�z/����

CMotionDoc::CMotionDoc()
{
}

CMotionDoc::~CMotionDoc()
{
}

BOOL CMotionDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMotionDoc �V���A���C�[�[�V����

void CMotionDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMotionDoc �N���X�̐f�f

#ifdef _DEBUG
void CMotionDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMotionDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMotionDoc �R�}���h
