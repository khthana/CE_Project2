//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SockStrEx.rc
//
#define ID_SERVER                       3
#define IDD_ABOUTBOX                    100
#define IDD_SOCKADDR                    102
#define IDR_MAINFRAME                   128
#define IDR_SOCKCLTYPE                  129
#define IDC_ADDR1                       1000
#define IDC_ADDR2                       1001
#define IDC_ADDR3                       1002
#define IDC_ADDR4                       1003
#define IDC_ADDR                        1004
#define IDC_PORT                        1006
#define ID_CLIENT                       1008
#define ID_CONNECT                      32771
#define ID_TEST                         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
