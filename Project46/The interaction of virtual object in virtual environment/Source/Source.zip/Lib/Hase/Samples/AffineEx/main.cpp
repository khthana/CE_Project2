#include <hase/3D/Affine.h>
#include <iostream>
using namespace std;
USING_NAMESPACE_HASE;
void main()
	{
	Affine af;
	cout << af;
	char ch;
	cin >> ch;
	}