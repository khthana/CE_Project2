#include "Hase/D3D/HD3DRM.h"
#include "hase/D3D/HD3DAffine.h"
#include "Hase/D3D/HRMVisual.h"
#pragma hdrstop
using namespace std;

BEGIN_NAMESPACE_HASE
//-----------------------------------------------------------------------------
//	CRMVisual
//
/*
bool CRMVisual::IsExtend()
	{
	if (!PVisual()) return false;
	CRMColMesh* pExt = (CRMColMesh*)(CRMObjExt::GetExt(PVisual()));
	return pExt != NULL;
	}
CColVisual& CRMVisual::Ext()
	{
	CColVisual* pExt = (CColVisual*)(CRMObjExt::GetExt(PVisual()));
	if (!pExt)
		{
		if (InterfaceID() == IID_IDirect3DRMMeshBuilder)
			pExt = new CRMColMesh;
		else pExt = new CRMColSphere;
		pExt->Set(PVisual());
		}
	return *pExt;
	}
void CRMVisual::Ext(CColVisual* v)
	{
	v->Set(PVisual());
	}
*/
//-----------------------------------------------------------------------------
//	CRMLight
//
CRMLight::CRMLight()
	{
	}
CRMLight::CRMLight(IDirect3DRMLight* l):
	CRMObject(l)
	{
	}
CRMLight::CRMLight(const CRMLight& l):
	CRMObject(l)
	{
	}
CRMLight::CRMLight(D3DRMLIGHTTYPE lt, D3DCOLOR col)
	{
	Set(lt, col);
	}
void CRMLight::Set(D3DRMLIGHTTYPE lt, D3DCOLOR col)
	{
	BeforeCreate();
	RELEASE(PLight());
	CKRMERR(CD3DRM::pD3DRM->CreateLight(lt, col, &PLight()));
	AfterCreate();
	}

//-----------------------------------------------------------------------------
//	CRMTexture
//
CRMTexture::CRMTexture(const std::string fname, bool bTransp, D3DCOLOR colTransp, CD3DVec2 decaleSize, CD3DVec2 decaleOrigin)
	{
	Load(fname, bTransp, colTransp, decaleSize, decaleOrigin);
	}
bool CRMTexture::Load(std::string fname, bool bTransp, D3DCOLOR colTransp, CD3DVec2 decaleSize, CD3DVec2 decaleOrigin)
	{
	Release();
	BeforeCreate();
	HRESULT hr = CD3DRM::pD3DRM->LoadTexture(fname.c_str(), &PTex());
	AfterCreate();
	if (hr != D3DRM_OK)
		{
		char buf[1024];
		ostrstream(buf, sizeof(buf)) << "Failed to load \'" << fname.c_str() << "\'.\n" << '\0';
		CKRMERRMSG(hr, buf);
		goto generic_error;
		}
	if (CKRMERR(PTex()->SetColors(16))) goto generic_error;
	if (CKRMERR(PTex()->SetShades(8))) goto generic_error;
	if (CKRMERR(PTex()->SetDecalTransparency(bTransp))) goto generic_error;
	if (CKRMERR(PTex()->SetDecalTransparentColor(colTransp))) goto generic_error;
	if (CKRMERR(PTex()->SetDecalSize(decaleSize.x, decaleSize.y))) goto generic_error;
	if (CKRMERR(PTex()->SetDecalOrigin(decaleSize.x, decaleSize.y))) goto generic_error;
	return true;
generic_error:
	Release();
	return false;
	}
//-----------------------------------------------------------------------------
//	CRMMaterial
//
CRMMaterial::CRMMaterial(const CD3DVec3& em, const CD3DVec3& sp, REAL pw)
	{
	Set(em, sp, pw);
	}
void CRMMaterial::Set(const CD3DVec3& em, const CD3DVec3& sp, REAL pw)
	{
	Release();
	BeforeCreate();
	CKRMERR(CD3DRM::pD3DRM->CreateMaterial(pw, &PMaterial()));
	AfterCreate();
	CKRMERR(PMaterial()->SetEmissive(em.x, em.y, em.z));
	CKRMERR(PMaterial()->SetSpecular(sp.x, sp.y, sp.z));
	}
const IID& CRMMaterial::InterfaceID() const
	{
	return IID_IDirect3DRMMaterial;
	}
const CLSID& CRMMaterial::ClassID() const
	{
	return CLSID_CDirect3DRMMaterial;
	}

//-----------------------------------------------------------------------------
//	CRMMesh
//
CRMMesh::CRMMesh(const CRMMesh& m):
	CRMVisual(m)
	{
	vertices.pCMesh = this;
	faces.pCMesh = this;
	}
CRMMesh::CRMMesh(IDirect3DRMMeshBuilder* m):
	CRMVisual(m)
	{
	vertices.pCMesh = this;
	faces.pCMesh = this;
	}
CRMMesh::CRMMesh()
	{
	vertices.pCMesh = this;
	faces.pCMesh = this;
	}
CRMMesh::CRMMesh(const std::string fname):
	CRMVisual()
	{
	vertices.pCMesh = this;
	faces.pCMesh = this;
	Load(fname);
	}
CRMMesh::~CRMMesh()
	{
	}
bool CRMMesh::CheckCreate()
	{
	if (!PMeshB())
		{
		BeforeCreate();
		if (CKRMERR(CD3DRM::pD3DRM->CreateMeshBuilder(&PMeshB()))) return false;
		AfterCreate();
		}
	return true;
	}
bool CRMMesh::Load(const std::string fname)
	{
	if (!CheckCreate()) return false;
	HRESULT hr = PMeshB()->Load((void*)fname.c_str(), NULL, D3DRMLOAD_FROMFILE, NULL, NULL);
	if (hr != D3DRM_OK)
		{
		char buf[1024];
		ostrstream(buf, sizeof(buf)) << "Failed to load \'" << fname.c_str() << "\'.\n" << '\0';
		CKRMERRMSG(hr, buf);
		return false;
		}
	return true;
	}
bool CRMMesh::Save(const std::string fname, D3DRMXOFFORMAT fmt, D3DRMSAVEOPTIONS opt)
	{
	if (!CheckCreate()) return false;
	HRESULT hr = PMeshB()->Save(fname.c_str(), fmt, opt);
	if (hr != D3DRM_OK)
		{
		char buf[1024];
		ostrstream(buf, sizeof(buf)) << "Failed to save \'" << fname.c_str() << "\'.\n" << '\0';
		CKRMERRMSG(hr, buf);
		return false;
		}
	return true;
	}
bool CRMMesh::Set(const CRMTexture& tex, D3DRMWRAPTYPE wt, const CD3DAffine& af, CD3DVec2 texO, CD3DVec2 texS)
	{
	if (!CheckCreate()) return false;
	IDirect3DRMWrap* pWrap = NULL;
    CD3DVec3 pos = af.Rot(af.Pos());
	if (CKRMERR(CD3DRM::pD3DRM->CreateWrap(wt, NULL,
		pos.x, pos.y, pos.z,
		af.Ez().x, af.Ez().y, af.Ez().z,
		af.Ey().x, af.Ey().y, af.Ey().z,
		texO.x, texO.y,
		texS.x, texS.y, &pWrap)))
		{
		goto generic_error;
		}
	if (CKRMERR(pWrap->Apply((IDirect3DRMObject*)PMeshB())))
		goto generic_error;
	if (CKRMERR(PMeshB()->SetTexture(tex)))
		goto generic_error;
	RELEASE(pWrap);
	return true;
generic_error:
	RELEASE(pWrap);
	return false;
	}
#define TEXGAPMAG REAL(1.005)
bool CRMMesh::CalcWrap(CD3DAffine& af, CD3DVec2& texS, D3DRMWRAPTYPE wt, char axis1, char axis2)
	{
	if (!CheckCreate()) return false;
	D3DRMBOX box;
	if (CKRMERR(PMeshB()->GetBox(&box)))
		return false;
	CD3DVec3 ex(box.max.x - box.min.x, 0, 0);
	CD3DVec3 ey(0, box.max.y - box.min.y, 0);
	CD3DVec3 ez(0, 0, box.max.z - box.min.z);
	CD3DVec3 pos;
	pos.x = box.min.x;
	pos.y = box.min.y;
	pos.z = box.min.z;
	CD3DVec3 a, b, c;
	axis1 = (char)toupper(axis1);
	axis2 = (char)toupper(axis2);
	int a1 = axis1-'X';
	int a2;
	if ('X' <= axis2 && axis2 <= 'Z' && axis1 != axis2) a2 = axis2-'X';
	else if (axis2 == '-') a2 = (a1-1+3)%3;
	else a2 = (a1+1)%3;
	int a3 = (a1+1)%3;
	if (a3==a2) a3=(a2+1)%3;
	a = a1==0 ? ex : (a1==1 ? ey : ez);
	b = a2==0 ? ex : (a2==1 ? ey : ez);
	c = a3==0 ? ex : (a3==1 ? ey : ez);
	if (wt == D3DRMWRAP_FLAT)
		{
		af.Ex(c.Unit());
		af.Ey(b.Unit());
		af.Ez(a.Unit());
        if (c.Size()>0) texS.x = 1/c.Size()*TEXGAPMAG;
		if (b.Size()>0) texS.y = 1/b.Size()*TEXGAPMAG;
		}
	else if (wt == D3DRMWRAP_CYLINDER)
		{
		af.Ex(b.Unit());
		af.Ey(c.Unit());
		af.Ez(a.Unit());
		texS.x = 1;
		if (a.Size()>0) texS.y = 1/(a.Size()*TEXGAPMAG);
		pos += b/2 + c/2;
		}
	else if (wt == D3DRMWRAP_SPHERE)
		{
		af.Ex(b.Unit());
		af.Ey(c.Unit());
		af.Ez(a.Unit());
		texS=CD3DVec2(1,1);
		pos += a/2 + b/2 + c*TEXGAPMAG/2; 
		}
    if (af.Det() == 0) af = CD3DAffine();
    af.Pos(af.Inv().Rot(pos));
	return true;
	}
bool CRMMesh::Set(const CRMTexture& tex, D3DRMWRAPTYPE wt, char axis1, char axis2, CD3DVec2 texO)
	{
	CD3DAffine af;
	CD3DVec2 texS;
	if (!CalcWrap(af, texS, wt, axis1, axis2)) return false;
	return Set(tex, wt, af, texO, texS);
	}
bool CRMMesh::Set(D3DCOLOR col)
	{
	if (!CheckCreate()) return false;
	if (CKRMERR(PMeshB()->SetColor(col))) return false;
	return true;
	}
bool CRMMesh::Set(D3DRMCOLORSOURCE colSrc)
	{
	if (!CheckCreate()) return false;
	if (CKRMERR(PMeshB()->SetColorSource(colSrc))) return false;
	return true;
	}
bool CRMMesh::Set(IDirect3DRMMaterial* m)
	{
	if (!CheckCreate()) return false;
	if (CKRMERR(PMeshB()->SetMaterial(m))) return false;
	return true;
	}
bool CRMMesh::Scale(const CD3DVec3& s)
	{
	if (!CheckCreate()) return false;
	bool rtv = CKRMERR(PMeshB()->Scale(s.x, s.y, s.z));
	vertices.Release();
	UpdateMesh();
	return rtv;
	}
bool CRMMesh::Pos(const CD3DVec3& s)
	{
	if (!CheckCreate()) return false;
	bool rtv = CKRMERR(PMeshB()->Translate(s.x, s.y, s.z));
	vertices.Release();
	UpdateMesh();
	return rtv;
	}
bool CRMMesh::GetBox(CD3DVec3& min, CD3DVec3& max)
	{
	if (!CheckCreate()) return false;
	D3DRMBOX box;
	bool rtv = CKRMERR(PMeshB()->GetBox(&box));
	min.x = box.min.x;
	min.y = box.min.y;
	min.z = box.min.z;
	max.x = box.max.x;
	max.y = box.max.y;
	max.z = box.max.z;
	return rtv;
	}
bool CRMMesh::Add(const CRMFace& face)
	{
	if (!CheckCreate()) return false;
	ASSERT(face.pFace);
	bool rv;
	if (face.pCMesh)
		{
		IDirect3DRMFace* f=NULL;
		GUID guid;
		face.pFace->Clone(NULL, guid, (void**)&f);
		rv = !CKRMERR(PMeshB()->AddFace(f));
		if (!rv) RELEASE(f);
		}
	rv = !CKRMERR(PMeshB()->AddFace(face.pFace));
	return rv;
	}
int CRMMesh::Add(const CRMVertex& vtx)
	{
	if (!CheckCreate()) return false;
	int idP = PMeshB()->AddVertex(vtx.Pos().x, vtx.Pos().y, vtx.Pos().z);
	int idN = PMeshB()->AddNormal(vtx.Normal().x, vtx.Normal().y, vtx.Normal().z);
	vertices.Release();
	UpdateMesh();
	ASSERT(idP == idN);
	return idP;
	}
const IID& CRMMesh::InterfaceID() const
	{
	return IID_IDirect3DRMMeshBuilder;
	}
const IID& CRMMesh::ClassID() const
	{
	return CLSID_CDirect3DRMMeshBuilder;
	}
//
//	CRMFace
//
CRMVertex CRMFace::Vertices::operator[](UINT id)
	{
	ASSERT(id < Size());
	ASSERT(face->pCMesh);
	face->pCMesh->CheckCreate();
	int idMesh = face->pFace->GetVertexIndex(id);
	return face->pCMesh->vertices[idMesh];
	}
UINT CRMFace::Vertices::Size()
	{
	return face->pFace->GetVertexCount();
	}

CRMFace::CRMFace(CRMFace& f)
	{
	pFace = f.pFace;
	f.pFace = NULL;
	vertices.face = this;
	}
CRMFace::CRMFace()
	{
	pCMesh = NULL;
	pFace = NULL;
	CD3DRM::pD3DRM->CreateFace(&pFace);
	vertices.face = this;
	}

CRMFace::CRMFace(CRMMesh& m, IDirect3DRMFace* pf)
	{
	pCMesh = &m;
	pFace = pf;
	vertices.face = this;
	}
CRMFace::~CRMFace()
	{
	RELEASE(pFace);
	}
bool CRMFace::Set(D3DCOLOR col)
	{
	return CKRMERR(pFace->SetColor(col));
	}
bool CRMFace::Set(IDirect3DRMMaterial* m)
	{
	return CKRMERR(pFace->SetMaterial(m));
	}
bool CRMFace::Set(IDirect3DRMTexture* t)
	{
	return CKRMERR(pFace->SetTexture(t));
	}
bool CRMFace::Add(const CRMVertex& vtx)
	{
	ASSERT(pCMesh);		//	��� CRMMesh::Add(CRMFace& f) �Ń��b�V���ɉ����Ă��������B
	int id = pCMesh->Add(vtx);
	return Add(id);
	}
bool CRMFace::Add(int id)
	{
	return CKRMERR(pFace->AddVertexAndNormalIndexed(id, id));
	}
//
//	CRMFaces
//
CRMFaces::CRMFaces()
	{
	pFaces = NULL;
	}
CRMFaces::~CRMFaces()
	{
	RELEASE(pFaces);
	}
void CRMFaces::Create()
	{
	if (pFaces && pFaces->GetSize() < Size()) RELEASE(pFaces);
	pCMesh->CheckCreate();
	if (!pFaces) pCMesh->PMeshB()->GetFaces(&pFaces);
	ASSERT(pFaces);
	}
CRMFace CRMFaces::operator [](UINT id)
	{
	Create();
	ASSERT(id <pFaces->GetSize());
	IDirect3DRMFace* pFace=NULL;
	pFaces->GetElement(id, &pFace);
	return CRMFace(*pCMesh, pFace);
	}
UINT CRMFaces::Size()
	{
	pCMesh->CheckCreate();
	return pCMesh->PMeshB()->GetFaceCount();
	}
void CRMFaces::Size(UINT s)
	{
	while(Size() < s) Add();
	}
bool CRMFaces::Add(const CRMFace& face)
	{
	return pCMesh->Add(face);
	}
//-----------------------------------------------------------------------------
//	CRMVertex
//
CRMVertex::CRMVertex(const CD3DVec3& p, const CD3DVec3& n)
	{
	id = -1;
	vertices = NULL;
	pos = p;
	normal = n;
	}
CRMVertex::CRMVertex(const CRMVertex& v)
	{
	id = v.id;
	vertices = v.vertices;
	pos = v.pos;
	normal = v.normal;
	}
const CRMVertex CRMVertex::operator = (const CRMVertex& v)
	{
	pos = v.pos;
	normal = v.normal;
	if (vertices)
		{
		vertices->SetNormal(id, normal);
		vertices->SetPos(id, pos);
		}
	return *this;
	}
void CRMVertex::Pos(const CD3DVec3& p)
	{
	pos = p;
	if (vertices) vertices->SetPos(id, pos);
	}
void CRMVertex::Normal(const CD3DVec3& n)
	{
	normal = n;
	if (vertices) vertices->SetNormal(id, normal);
	}
bool CRMVertex::Set(D3DCOLOR col)
	{
	if (!vertices) return false;
	vertices->pCMesh->CheckCreate();
	return CKRMERR(vertices->pCMesh->PMeshB()->SetVertexColor(id, col));
	}
//
//	CRMVertices
//
CRMVertices::CRMVertices()
	{
	pPos = NULL;
	pNor = NULL;
	nPos = 0;
	nNor = 0;
	};
CRMVertices::~CRMVertices()
	{
	Release();
	}
void CRMVertices::Create()
	{
	DWORD fc=0;
	if (!pPos)
		{
		pCMesh->CheckCreate();
		pCMesh->PMeshB()->GetVertices(&nPos, NULL, &nNor, NULL, &fc, NULL);
		pPos = new D3DVECTOR [nPos];
		pNor = new D3DVECTOR [nNor];
		pCMesh->PMeshB()->GetVertices(&nPos, pPos, &nNor, pNor, &fc, NULL);
		}
	}
void CRMVertices::Release()
	{
	delete [] pPos;
	pPos = NULL;
	nPos = 0;
	delete [] pNor;
	pNor = NULL;
	nNor = 0;
	}
void CRMVertices::SetPos(int id, const D3DVECTOR& pos)
	{
	Create();
	ASSERT(0<=id && id<(int)nPos);
	pPos[id] = pos;
	pCMesh->PMeshB()->SetVertex(id, pos.x, pos.y, pos.z);
	pCMesh->UpdateMesh();
	}
void CRMVertices::SetNormal(int id, const D3DVECTOR& nor)
	{
	Create();
	ASSERT(0<=id && id<(int)nNor);
	pNor[id] = nor;
	pCMesh->PMeshB()->SetNormal(id, nor.x, nor.y, nor.z);
	}

CRMVertex CRMVertices::operator[](UINT id)
	{
	Create();
	CRMVertex vtx;
	vtx.vertices = this;
	vtx.id = id;
	vtx.pos = pPos[id];
	vtx.normal = pNor[id];
	return vtx;
	}
UINT CRMVertices::Size()
	{
	Create();
	return nPos;
	}
void CRMVertices::Size(UINT s)
	{
	while (Size() < s) Add();
	}
int CRMVertices::Add(const CRMVertex& vtx)
	{
	return pCMesh->Add(vtx);
	}

END_NAMESPACE_HASE
