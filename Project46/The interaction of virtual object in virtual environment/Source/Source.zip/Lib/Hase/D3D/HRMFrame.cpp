#include "Hase/D3D/HD3DRM.h"
#pragma hdrstop
#define CKERR CKRMERR
#define CKERRFILE CKRMERRFILE
#define ERRMSG RMERRMSG
BEGIN_NAMESPACE_HASE
//-----------------------------------------------------------------------------
//	CRMObject
//
CRMObject::CRMObject(const CRMObject& o):
	CDXObject(o)
	{
	name = NULL;
	if (bRelease)
		{
		BeforeCreate();
		AfterCreate();
		}
	}
CRMObject::CRMObject(IDirect3DRMObject* o):
	CDXObject(o)
	{
	name = NULL;
	if (bRelease) 
		{
		BeforeCreate();
		AfterCreate();
		}
	}
CRMObject::~CRMObject()
	{
	Release();
	}
IDirect3DRMObject* CRMObject::Clone() const
	{
	IDirect3DRMObject* rtv = NULL;
	if (pObject) CKERR(PRMObj()->Clone(NULL, InterfaceID(), (void**)&rtv));
	return rtv;
	}
void CRMObject::DestroyCallback(IDirect3DRMObject* , void* pArg)
	{
	CRMObject* pObj = (CRMObject*)pArg;
	pObj->PRMObj() = NULL;
	pObj->bRelease = false;
	}
bool CRMObject::Create()
	{
	if (PRMObj()) return true;
	BeforeCreate();
	if (ClassID() != CDXObject::ClassID())
		CKRMERR( CD3DRM::pD3DRM->CreateObject(ClassID(), NULL, InterfaceID(), (void**)&PRMObj()) );
	return AfterCreate();
	}
void CRMObject::BeforeCreate()
	{
	CD3DRM::CreateD3DRM();
	}
bool CRMObject::AfterCreate()
	{
	if (!PRMObj())
		{
		ERRMSG(2, "Create RM object before call CRMObject::AfterCreate.");
		return false;
		}
	bRelease = true;
	if (name) CKERR(PRMObj()->SetName(name));
	return !CKERR(PRMObj()->AddDestroyCallback(DestroyCallback, this));
	}
void CRMObject::Release()
	{
	delete name;
	name = NULL;
	if (bRelease)
		{
		if (PRMObj()) CKERR(PRMObj()->DeleteDestroyCallback(DestroyCallback, this));
		CDXObject::Release();
		CD3DRM::ReleaseD3DRM();
		}
	}
const char* CRMObject::Name()
	{
	if (name) return name;
	if (!PRMObj())
		{
		ERRMSG(2, "NULL object used.");
		return NULL;
		}
	DWORD size;
	CKERR(PRMObj()->GetName(&size, NULL));
    if (size == 0)
        {
        name = new char[1];
        name[0] = '\0';
        return name;
        }
	name = new char[size];
	CKERR(PRMObj()->GetName(&size, name));
	return name;
	}
void CRMObject::Name(const char* n)
	{
	delete name;
	name = NULL;
	if (n && strlen(n))
		{
		name = new char[strlen(n) + 1];
		strcpy(name, n);
		}
	if (!PRMObj()) return;
	CKERR(PRMObj()->SetName(name));
	}
const CRMObject& CRMObject::operator = (const CRMObject& o)
	{
	Release();
	ASSERT(!o.pObject || Check(o.pObject));
	pObject = o.pObject;
	if (pObject)
		{
		BeforeCreate();
		pObject->AddRef();
		AfterCreate();
		}
	return *this;
	}
const IID& CRMObject::InterfaceID() const
	{
	return IID_IDirect3DRMObject;
	}
bool CRMObject::Check(IUnknown* pUk) const
	{
	if (!pUk) return false;
	IUnknown* newIf=NULL;
	pUk->QueryInterface(InterfaceID(), (void**)&newIf);
	if (newIf)
		{
		newIf->Release();
		return true;
		}
	return false;
	}
//-----------------------------------------------------------------------------
//	CRMFrame
//
CRMFrame::CRMFrame(const char* fname)
	{
	Load(fname);
	}
CRMFrame& CRMFrame::FromI(IDirect3DRMFrame* pFr)
	{
	static CRMFrame fr;
	delete fr.name;
	fr.name = NULL;
	fr.pObject = pFr;
	return fr;
	}
void CRMFrame::CreateFrame()
	{
	BeforeCreate();
	bool err = CKERR( CD3DRM::pD3DRM->CreateFrame(NULL, &PFrame()) );
	ASSERT(!err);
	AfterCreate();
	}
bool CRMFrame::Load(const char* fname)
	{
	Create();
	return !CKERR(PFrame()->Load((void*)fname, NULL, D3DRMLOAD_INSTANCEBYREFERENCE, NULL, NULL));
	}
bool CRMFrame::Find(const CRMFrame& frOrg)
	{
	if (!PFrame()) return false;
	CRMFrame fr(frOrg);
	while(fr)
		{
		if (fr == *this) break;
		fr = fr.Parent();
		}
	if (fr) return true;
	return false;
	}
CRMFrame CRMFrame::Find(const char* n)
	{
	if (!PFrame()) return CRMFrame();
	if (strcmp(Name(), n) == 0) return *this;
	int nCh = NChild();
	CRMFrame fr;
	for(int i=0; i<nCh; i++)
		{
		fr = Child(i).Find(n);
		if (fr) return fr;
		};
	return fr;
	}
CRMFrame CRMFrame::Parent()
	{
	IDirect3DRMFrame* f = NULL;
	if (PFrame()) CKERR(PFrame()->GetParent(&f));
	if (f)
		{
		int ref = f->Release();
		TRACEALL("CRMFrame::Parent ref = %d\n", ref);
		}
	return f;
	}
void CRMFrame::Parent(IDirect3DRMFrame* pf)
	{
	IDirect3DRMFrame* parent = Parent();
	if (  parent && CKERR( parent->DeleteChild(PFrame()) )  ) return;
	if (pf) CKERR(pf->AddChild(PFrame()));
	}
void CRMFrame::Add(CRMFrame& f)
	{
	Create();
	f.Create();
	CKERR(PFrame()->AddChild(f));
	}
void CRMFrame::Del(const CRMFrame& f)
	{
	if (PFrame()) CKERR(PFrame()->DeleteChild(f));
	}
void CRMFrame::DelThis()
	{
	if (Parent()) Parent().Del(*this);
	}
CRMFrame CRMFrame::Child(int id)
	{
	IDirect3DRMFrameArray* fa=NULL;
	if (CKERR(PFrame()->GetChildren(&fa))) return CRMFrame();
	IDirect3DRMFrame* f=NULL;
	if (!CKERR(fa->GetElement(id, &f)) && f)
		{
		int ref = f->Release();
		TRACEALL("CRMFrame::Parent ref = %d\n", ref);
		}
	RELEASE(fa);
	return f;
	}
int CRMFrame::NChild()
	{
	if (!PFrame()) return 0;
	IDirect3DRMFrameArray* fa=NULL;
	if (CKERR(PFrame()->GetChildren(&fa))) return 0;
	int rtv = fa->GetSize();
	RELEASE(fa);
	return rtv;
	}

void CRMFrame::Add(const CRMLight& light)
	{
	Create();
	CKERR(PFrame()->AddLight(light));
	}
void CRMFrame::Del(const CRMLight& light)
	{
	Create();
	CKERR(PFrame()->DeleteLight(light));
	}
CRMLight CRMFrame::Light(int id)
	{
	IDirect3DRMLightArray* la=NULL;
	if (CKERR(PFrame()->GetLights(&la))) return CRMLight();
	IDirect3DRMLight* l=NULL;
	if (!CKERR(la->GetElement(id, &l)) && l)
		{
		int ref = l->Release();
		TRACEALL("CRMFrame::Light ref = %d\n", ref);
		}
	RELEASE(la);
	return l;
	}
CRMLight CRMFrame::Light(const char* name)
	{
	IDirect3DRMLightArray* la=NULL;
	if (CKERR(PFrame()->GetLights(&la))) return CRMLight();
	for(int i=0; i<la->GetSize(); i++)
		{
		IDirect3DRMLight* l=NULL;
		if (!CKERR(la->GetElement(i, &l)) && l)
			{
			int ref = l->Release();
			TRACEALL("CRMFrame::Light ref = %d\n", ref);
			DWORD nlen=0;
			l->GetName(&nlen, NULL);
			char* n = new char [nlen];
			l->GetName(&nlen, n);
			if (strcmp(n, name) == 0)
				{
				delete n;
				RELEASE(la);
				return l;
				}
			delete n;
			}
		}
	RELEASE(la);
	return CRMLight();
	}
int CRMFrame::NLight()
	{
	if (!PFrame()) return 0;
	IDirect3DRMLightArray* la=NULL;
	if (CKERR(PFrame()->GetLights(&la))) return 0;
	int rtv = la->GetSize();
	RELEASE(la);
	return rtv;
	}

void CRMFrame::Add(CRMVisual& vis)
	{
	Create();
	vis.Create();
	CKERR(PFrame()->AddVisual(vis.PVisual()));
	}
void CRMFrame::Add(const CRMVisual& vis)
	{
	CRMVisual v = vis;
	Add(v);
	}
void CRMFrame::Del(const CRMVisual& vis)
	{
	if (!vis.PVisual()) return;
	if (!PFrame()) return;
	CKERR(PFrame()->DeleteVisual(vis.PVisual()));
	}
CRMVisual CRMFrame::Visual(int id)
	{
	IDirect3DRMVisualArray* va=NULL;
	if (CKERR(PFrame()->GetVisuals(&va))) return CRMVisual();
	IDirect3DRMVisual* v=NULL;
	if (!CKERR(va->GetElement(id, &v)) && v)
		{
		int ref = v->Release();
		TRACEALL("CRMFrame::Visual ref = %d\n", ref);
		}
	RELEASE(va);
	return v;
	}
CRMVisual CRMFrame::Visual(const char* name)
	{
	IDirect3DRMVisualArray* va=NULL;
	if (CKERR(PFrame()->GetVisuals(&va))) return CRMVisual();
	for(int i=0; i<va->GetSize(); i++)
		{
		IDirect3DRMVisual* v=NULL;
		if (!CKERR(va->GetElement(i, &v)) && v)
			{
			int ref = v->Release();
			TRACEALL("CRMFrame::Visual ref = %d\n", ref);
			DWORD nlen=0;
			v->GetName(&nlen, NULL);
			char* n = new char [nlen];
			v->GetName(&nlen, n);
			if (strcmp(n, name) == 0)
				{
				delete n;
				RELEASE(va);
				return v;
				}
			delete n;
			}
		}
	RELEASE(va);
	return CRMVisual();
	}
int CRMFrame::NVisual()
	{
	if (!PFrame()) return 0;
	IDirect3DRMVisualArray* va=NULL;
	if (CKERR(PFrame()->GetVisuals(&va))) return 0;
	int rtv = va->GetSize();
	RELEASE(va);
	return rtv;
	}
void CRMFrame::Clear()
	{
	Create();
	int i;
	for(i=NChild()-1; i>=0; i--) Del(Child(i));
	for(i=NVisual()-1; i>=0; i--) Del(Visual(i));
	for(i=NLight()-1; i>=0; i--) Del((IDirect3DRMLight*)Light(i));
	}
REAL CRMFrame::RotAngle()
	{
	Create();
	D3DVECTOR v;
	REAL r;
	CKERR(PFrame()->GetRotation(Parent(), &v, &r));
	return r;
	}
CD3DVec3 CRMFrame::RotAxis()
	{
	Create();
	D3DVECTOR v;
	REAL r;
	CKERR(PFrame()->GetRotation(Parent(), &v, &r));
	return v;
	}
void CRMFrame::Rot(const CD3DVec3& axis, D3DVALUE rVel)
	{
	Create();
	CKERR(PFrame()->SetRotation(Parent(), axis.x, axis.y, axis.z, rVel));
	}
CD3DVec3 CRMFrame::Vel()
	{
	Create();
	D3DVECTOR v;
	BOOL b=false;
	CKERR(PFrame()->GetVelocity(Parent(), &v, b));
	return v;
	}
void CRMFrame::Vel(const CD3DVec3& vel)
	{
	Create();
	CKERR(PFrame()->SetVelocity(Parent(), vel.x, vel.y, vel.z, false));
	}
void CRMFrame::Ori(const CD3DVec3& ez, const CD3DVec3& ey, const CRMFrame& frRef)
	{
	Create();
	CKERR(PFrame()->SetOrientation(frRef, ez.x, ez.y, ez.z, ey.x, ey.y, ey.z));
	}
void CRMFrame::Pos(const CD3DVec3& v, const CRMFrame& frRef)
	{
	Create();
	CKERR(PFrame()->SetPosition(frRef, v.x, v.y, v.z));
	}
CD3DAffine CRMFrame::AfParent()
	{
	Create();
    CD3DAffine af;
	D3DRMMATRIX4D& m = af;
	CKERR(PFrame()->GetTransform(m));
	return af;
	}
CD3DAffine CRMFrame::AfWorld()
	{
	Create();
	if (Parent()) return Parent().AfWorld() * AfParent();
	return AfParent();
	}
void CRMFrame::AfWorld(const CD3DAffine& afW)
	{
	Create();
	AfParent(CRMFrame::FromI(Parent()).AfWorld().Inv() * afW);
	}
void CRMFrame::AfParent(const CD3DAffine& af)
	{
	Create();
    D3DRMMATRIX4D& m = af;
	CKERR(PFrame()->AddTransform(D3DRMCOMBINE_REPLACE, m));
	}
const IID& CRMFrame::InterfaceID() const
	{
	return IID_IDirect3DRMFrame;
	}
const CLSID& CRMFrame::ClassID() const
	{
	return CLSID_CDirect3DRMFrame;
	}
END_NAMESPACE_HASE
