#ifndef HASE_D3D_HD3DRM_H
#define HASE_D3D_HD3DRM_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"
#include "Hase/D3D/HD3DDev.h"
#include "Hase/D3D/HRMFrame.h"
#include "Hase/D3D/HRMVisual.h"
#include <d3drm.h>
#define RMERRMSG(n, msg)		CD3DRM::Error().DXERRMSG((n), (msg))
#define CKRMERR(n)				CD3DRM::Error().CKDXERR(n)
#define CKRMERRMSG(n,msg)		CD3DRM::Error().CKDXERRMSG((n), (msg))

BEGIN_NAMESPACE_HASE
//----------------------------------------------------------------------------
//	CRMError
//
class DLLCLASS CRMError:public CDDError
	{
	public:
	virtual bool Check(DWORD n, const char* msg, const char* fn=NULL, int ln=0);
	static bool RMErrorToString(char*& err, char*& desc, HRESULT error);
	};
//----------------------------------------------------------------------------
//	CRMViewFrustum	������(�����ϊ��̃p�����[�^)��\��
//
struct DLLCLASS CRMViewFrustum
	{			
	CRMViewFrustum(REAL f=0, REAL b=0, CD3DVec2 size=CD3DVec2(), CD3DVec2 pos = CD3DVec2());
	CRMViewFrustum(REAL f, REAL b, REAL w, REAL asp=1);
	REAL front, back;
	CD3DVec2 bgn, end;
	REAL aspect;
	};
//----------------------------------------------------------------------------
//	CRMViewport
//
struct DLLCLASS CRMViewport
	{
	IDirect3DRMDevice* pRMDev;
	IDirect3DRMViewport* pRMView;
	CRMViewport(const CRMViewport& v);
	CRMViewport(IDirect3DRMDevice* d, IDirect3DRMViewport* v);
	CRMViewport();
	~CRMViewport();
	void Release();
	bool operator ==(const CRMViewport&i) const{return pRMDev == i.pRMDev;}
	bool operator <(const CRMViewport&i) const{return pRMDev < i.pRMDev;}
	bool SetViewFrustum(const CRMViewFrustum& vf);
	bool SetRenderQuality(D3DRMRENDERQUALITY rq);
	bool SetTextureQuality(D3DRMTEXTUREQUALITY tq);
	bool SetViewport(CD3DVec2 bgn, CD3DVec2 end);
	bool SetCamera(IDirect3DRMFrame*);
	bool ForceUpdate();
	};
//----------------------------------------------------------------------------
//	CRMViewports
//
class DLLCLASS CRMViewports:public CRMViewport
	{
	protected:
	Array<CRMViewport> views;
	bool SetViewport(CD3DVec2 viewPos, CD3DVec2 viewSize);
	bool SetViewFrustum(const CRMViewFrustum & vf);
	bool SetCamera(IDirect3DRMFrame*);
	void Release();
	
	public:
	static CRMError& Error();
	CRMViewports();
	bool SetRenderQuality(D3DRMRENDERQUALITY rq);
	bool SetTextureQuality(D3DRMTEXTUREQUALITY tq);
	bool ForceUpdate();
	};
//----------------------------------------------------------------------------
//	CD3DRM	Direct3DRM�̈�̎��_�ɑΉ�����
//
class DLLCLASS CD3DRM:public CRMViewports
	{
	bool bD3DRMCreated;
	protected:
	static CD3DRM* last;				// pointer to CD3DRM instance which selected last.
	//	the rendering destination. chose one of following.
	CAutoFlipD3DDevice* pCAfD3DDev;		// the surface to be rendered (autoflip)
	CD3DDevice* pCD3DDev;				// the surface to be rendered
	CD3DRM* pCD3DRMBase;				// for getting rendering destination surface from other CD3DRM object.
	HWND hWnd;							// the window for geting rendering destination surface.
	IDirectDrawClipper* pClipper;		// if hWnd is selected use this clipper
	
	//	rendering setup
	CD3DVec2 viewPos;					// the position of lefttop of the viewport in surface
	CD3DVec2 viewSize;					// the size of the viewport in surface
    CRMFrame scene;						// Master (route) frame in which other frames are placed
    CRMFrame camera;					// The frame which is describing the user's point of view
	CRMViewFrustum viewFrustum;			// viewing frustum set by user
	CRMViewFrustum curViewFrustum;		// current view frustum
	D3DRMRENDERQUALITY renderQuality;	// current shade mode, fill mode and lighting state
	D3DRMTEXTUREQUALITY textureQuality; // current texture interpolation
	bool SetViewFrustum();
    bool SetClip();
	bool Create(bool bAddCallback);
	void Release(bool bDelCallback);
	static void CreateCallback(CDDSurface& surf, void*);
	static void ReleaseCallback(CDDSurface& surf, void*);
	static void DeleteCallback(CDDSurface& surf, void*);
	//	constructor and destructor
	bool CreateRM();
	void ReleaseRM();

	public://-----------------------------------------------------------------
	static IDirect3DRM* pD3DRM;
	
	//	constructor and destructor
	CD3DRM();
	~CD3DRM();
	bool Create(){return Create(true);}		//	�ŏ��̃����_�����O���͂��߂�O�ɌĂ�
	void Release(){Release(true);}
	static ULONG CreateD3DRM();				//	pD3DRM�̎Q�ƃJ�E���g�𑝂₷
	static ULONG ReleaseD3DRM();			//	pD3DRM�̎Q�ƃJ�E���g�����炷

	//	rendering destination. call one of following.
	void Surf(CD3DDevice& surf);			//	render to directdraw surface.
	void Surf(CAutoFlipD3DDevice& dev);		//	render to autoflip directdraw surface (for multi eyes).
	CD3DDevice* PSurf(){return pCD3DDev;}	//	pointer to the redering destination surface.
	void RMBase(CD3DRM& rm);				//	get rendering destination surface from other CD3DRM object.
	CD3DRM* PRMBase(){return pCD3DRMBase;}	//	pointer to the other CD3DRM object from which get destination surface.
	void HWnd(HWND wnd);					//	set the handle of the rendering destination window.
	HWND HWnd(){return hWnd;}				//	get the handle of the rendering destination window.

	//	setup rendering scene
	CRMFrame Scene(){return scene;}			//	the root frame
	CRMFrame Camera(){return camera;}		//	rendering view point
	void Scene(CRMFrame& s);				//	set scene frame
	void Scene(const CRMFrame& s);
	void Camera(CRMFrame& c);				//	set camera frame
	void Camera(const CRMFrame& c);
	void SceneCamera(CRMFrame&s, CRMFrame& c);

	//	rendering setup
	bool ViewFrustum(const CRMViewFrustum& v);	//	set the viwing frustum.
	CRMViewFrustum ViewFrustum(){return viewFrustum;}	//	get the viwing frustum.
	void Viewport(CD3DVec2 vPos, CD3DVec2 vSize);//	set the position and the size of the viewport (set rate 0to1).
	CD3DVec2 ViewportPos(){return viewPos;}		//	get the viewport position.
	CD3DVec2 ViewportSize(){return viewSize;}	//	get the viewport size.
	void RenderQuality(D3DRMRENDERQUALITY rq);	//	set the render quality (IDirect3DRMDevice::SetQuality).
	D3DRMRENDERQUALITY RenderQuality(){return renderQuality;}
												//	get the render quality.
	void TextureQuality(D3DRMTEXTUREQUALITY tq);//	set the texture qualtiy. (IDirect3DRMDevice::SetTextureQuality)
	D3DRMTEXTUREQUALITY TextureQuality(){return textureQuality;}
												//	get the texture qualtiy.
	
	//	rendering
	bool Step();						//	one step of rendering
	//	rendering detail
	bool FitSurface();					//	Fit the surface to the window
	bool Clear();						//	Clear viewport
	bool Render();						//	Render scene
	bool Update();						//	Update back buffer
	bool Flip();						//	Flip or copy back buffer to flont buffer.
	
	//	utility
	CRMObject Find(const char* name);	//	find CRMObject whose name is name.
	IDirect3DRM* operator ->() const;
	IDirect3DRM* operator *() const;
	CD3DVec3 WorldToView(const CD3DVec3& w);
	CD3DVec3 ViewToWorld(const CD3DVec3& v);
	//	auto flip for multi eyes.
	bool SetPurpose(int i, bool bDelay=false);
	bool UpdatePurpose();
	int NPurpose();
	void NPurpose(int n);
	//	Other classes who need this class's instance can use this.
	static CD3DRM& GetLastCreate();
	};
END_NAMESPACE_HASE
#endif