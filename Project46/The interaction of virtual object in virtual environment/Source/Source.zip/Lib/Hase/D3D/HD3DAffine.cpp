#include "Hase/D3D/HD3DAffine.h"
#include "Hase/D3D/HD3DAffineDef.h"
#include "Hase/3D/AffineB.cpp"
#define UNDEF_ALL_AFFINEB
#include "Hase/3D/AffineB.h"
