#include "Hase/Misc/Inc.h"
#define INITGUID
#include <d3drm.h>
#include <mmsystem.h>
#include <dsound.h>
#include "Hase/D3D/HD3DRM.h"

BEGIN_NAMESPACE_HASE
CD3DRM* CD3DRM::last;
IDirect3DRM* CD3DRM::pD3DRM;
//----------------------------------------------------------------------------
//	CRMViewFrustum
//
CRMViewFrustum::CRMViewFrustum(REAL f, REAL b, CD3DVec2 sz, CD3DVec2 p)
	{
	front = f;
	back = b;
	bgn = p - sz/2;
	end = p + sz/2;
	aspect = 1;
	}
CRMViewFrustum::CRMViewFrustum(REAL f, REAL b, REAL w, REAL asp)
	{
	front = f;
	back = b;
	bgn.x = -w/2;
	end.x = w/2;
	aspect = asp;
	}
//----------------------------------------------------------------------------
//	CRMViewport
//
CRMViewport::CRMViewport(const CRMViewport& v)
	{
	pRMDev = v.pRMDev;
	if (pRMDev) pRMDev->AddRef();
	pRMView = v.pRMView;
	if (pRMView) pRMView->AddRef();
	}
CRMViewport::CRMViewport(IDirect3DRMDevice* d, IDirect3DRMViewport* v)
	{
	pRMDev = d;
	if (pRMDev) pRMDev->AddRef();
	pRMView = v;
	if (pRMView) pRMView->AddRef();
	}
CRMViewport::CRMViewport()
	{
	pRMDev = NULL;
	pRMView = NULL;
	}
void CRMViewport::Release()
	{
	RELEASE(pRMView);
	RELEASE(pRMDev);
	}
CRMViewport::~CRMViewport()
	{
	Release();
	}
bool CRMViewport::SetRenderQuality(D3DRMRENDERQUALITY rq)
	{
	if (pRMDev)
		return CKRMERR(pRMDev->SetQuality(rq));
	return false;
	}
bool CRMViewport::SetTextureQuality(D3DRMTEXTUREQUALITY tq)
	{
	if (pRMDev)
		return CKRMERR(pRMDev->SetTextureQuality(tq));
	return false;
	}

bool CRMViewport::SetViewport(CD3DVec2 viewPos, CD3DVec2 viewSize)
	{
	if (pRMView)
		{
		SIZE szView;
		szView.cx = pRMDev->GetWidth();
		szView.cy = pRMDev->GetHeight();
		POINT bgnView;
		bgnView.x = szView.cx * viewPos.x + 0.5f;
		bgnView.y = szView.cy * viewPos.y + 0.5f;
		POINT endView;
		endView.x = szView.cx * (viewPos.x+viewSize.x) + 0.5f;
		endView.y = szView.cy * (viewPos.y+viewSize.y) + 0.5f;
		return CKRMERR(pRMView->Configure(bgnView.x, bgnView.y, endView.x - bgnView.x, endView.y - bgnView.y));
		}
	return false;
	}
bool CRMViewport::SetViewFrustum(const CRMViewFrustum & vf)
	{
	bool err = true;
    if (pRMView)
        {
    	err = CKRMERR(pRMView->SetUniformScaling(false));
    	err |= CKRMERR(pRMView->SetFront(vf.front));
    	err |= CKRMERR(pRMView->SetBack(vf.back));
    	err |= CKRMERR(pRMView->SetPlane(vf.bgn.x, vf.end.x, vf.bgn.y, vf.end.y));
        }
	return !err;
	}
bool CRMViewport::SetCamera(IDirect3DRMFrame* cam)
	{
	if (pRMView) 
		return !CKRMERR(pRMView->SetCamera(cam));
	return false;
	}
bool CRMViewport::ForceUpdate()
	{
	if (pRMView) 
		{
		int x = pRMView->GetX();
		int y = pRMView->GetY();
		return CKRMERR(pRMView->ForceUpdate( x, y, x+pRMView->GetWidth(), y+pRMView->GetHeight() ));
		}
	return false;
	}
//----------------------------------------------------------------------------
//	CRMViewports
//
CRMViewports::CRMViewports()
	{
	}
void CRMViewports::Release()
	{
	views.Clear();
	CRMViewport::Release();
	}
bool CRMViewports::SetRenderQuality(D3DRMRENDERQUALITY rq)
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].SetRenderQuality(rq);
	if (views.Size() == 0) rtv &= CRMViewport::SetRenderQuality(rq);
	return rtv;
	}
bool CRMViewports::SetTextureQuality(D3DRMTEXTUREQUALITY tq)
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].SetTextureQuality(tq);
	if (views.Size() == 0) rtv &= CRMViewport::SetTextureQuality(tq);
	return rtv;
	}
bool CRMViewports::SetViewport(CD3DVec2 viewPos, CD3DVec2 viewSize)
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].SetViewport(viewPos, viewSize);
	if (views.Size() == 0) rtv &= CRMViewport::SetViewport(viewPos, viewSize);
	return rtv;
	}
bool CRMViewports::SetViewFrustum(const CRMViewFrustum & vf)
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].SetViewFrustum(vf);
	if (views.Size() == 0) rtv &= CRMViewport::SetViewFrustum(vf);
	return rtv;
	}
bool CRMViewports::SetCamera(IDirect3DRMFrame* cam)
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].SetCamera(cam);
	if (views.Size() == 0) rtv &= CRMViewport::SetCamera(cam);
	return rtv;
	}
bool CRMViewports::ForceUpdate()
	{
	bool rtv = true;
	for(int i=0; i<views.Size(); i++)
		rtv &= views[i].ForceUpdate();
	if (views.Size() == 0) rtv &= CRMViewport::ForceUpdate();
	return rtv;
	}
static CRMError* CRMViewports_error;
CRMError& CRMViewports::Error()
	{
	if (!CRMViewports_error) CRMViewports_error = new CRMError;
	return *CRMViewports_error;
	}
//----------------------------------------------------------------------------
//	CRMError
//
bool CRMError::Check(DWORD n, const char* msg, const char* fn, int ln)
	{
	if (n==DD_OK) return false;
	if (n==D3D_OK) return false;
	if (n==D3DRM_OK) return false;
	if (n==0) return false;
	if (RMErrorToString(err, desc, n)
		|| DDErrorToString(err, desc, n)
		|| D3DErrorToString(err, desc, n));
	return CDXError::Check(n, msg, fn, ln);
	}
bool CRMError::RMErrorToString(char*& err, char*& desc, HRESULT error)
	{
	err = "";
	desc = "";
    switch(error) 
    	{
        case D3DRMERR_BADOBJECT:
			err = "D3DRMERR_BADOBJECT\0";
			return true;
        case D3DRMERR_BADTYPE:
			err = "D3DRMERR_BADTYPE\0";
			return true;
        case D3DRMERR_BADALLOC:
			err = "D3DRMERR_BADALLOC\0";
			return true;
        case D3DRMERR_FACEUSED:
			err = "D3DRMERR_FACEUSED\0";
			return true;
        case D3DRMERR_NOTFOUND:
			err = "D3DRMERR_NOTFOUND\0";
			return true;
        case D3DRMERR_NOTDONEYET:
			err = "D3DRMERR_NOTDONEYET\0";
			return true;
        case D3DRMERR_FILENOTFOUND:
			err = "D3DRMERR_FILENOTFOUND\0";
			desc = "The file was not found.";
			return true;
        case D3DRMERR_BADFILE:
			err = "D3DRMERR_BADFILE\0";
			return true;
        case D3DRMERR_BADDEVICE:
			err = "D3DRMERR_BADDEVICE\0";
			return true;
        case D3DRMERR_BADVALUE:
			err = "D3DRMERR_BADVALUE\0";
			return true;
        case D3DRMERR_BADMAJORVERSION:
			err = "D3DRMERR_BADMAJORVERSION\0";
			return true;
        case D3DRMERR_BADMINORVERSION:
			err = "D3DRMERR_BADMINORVERSION\0";
			return true;
        case D3DRMERR_UNABLETOEXECUTE:
			err = "D3DRMERR_UNABLETOEXECUTE\0";
			return true;
        default:
			desc = "d3drm unknown.";
            return false;
		}
	}
//----------------------------------------------------------------------------
//	CD3DRM
//
CD3DRM::CD3DRM()
	{
	bD3DRMCreated = false;
	pCD3DRMBase = NULL;
	pCD3DDev = NULL;
	pCAfD3DDev = NULL;
	pRMDev = NULL;
	pRMView = NULL;
	renderQuality = D3DRMLIGHT_ON | D3DRMFILL_SOLID | D3DRMSHADE_GOURAUD;
	textureQuality = D3DRMTEXTURE_NEAREST;
	hWnd = NULL;
	pClipper = NULL;
	viewPos = CD3DVec2(0,0);
	viewSize = CD3DVec2(1,1);
	CreateRM();
	}
CD3DRM::~CD3DRM()
	{
 	Release();
	ReleaseRM();
	}
void CD3DRM::CreateCallback(CDDSurface& surf, void* p)
	{
	TRACEALL("CD3DRM::CreateCallback\n");
	CD3DRM* pRM = (CD3DRM*)p;
	pRM->Create(false);
	}
void CD3DRM::ReleaseCallback(CDDSurface& surf, void* p)
	{
	TRACEALL("CD3DRM::ReleaseCallback\n");
	CD3DRM* pRM = (CD3DRM*)p;
	pRM->Release(false);
	}
void CD3DRM::DeleteCallback(CDDSurface& surf, void* p)
	{
	TRACEALL("CD3DRM::DeleteCallback\n");
	CD3DRM* pRM = (CD3DRM*)p;
	pRM->Release(true);
	pRM->pCD3DDev = NULL;
	}

ULONG CD3DRM::CreateD3DRM()
	{
	ULONG rtv=1;
	if (!pD3DRM)
		{
		Direct3DRMCreate(&pD3DRM);
		if (!pD3DRM)
			{
			TRACE("%d:%d   Direct3DRMCreate() failed.\n", __FILE__, __LINE__);
			abort();
			}
		}
	else rtv = pD3DRM->AddRef();
	TRACEALL("pD3DRM's refcount ^%d\n", rtv);
	return rtv;
	}
ULONG CD3DRM::ReleaseD3DRM()
	{
	if (!pD3DRM)
		{
		TRACE("%s:%d   Can't release Direct3DRM.\n", __FILE__, __LINE__);
		return 0;
		}
	ULONG rtv = pD3DRM->Release();
	if (rtv == 0)
		{
		pD3DRM = NULL;
		delete CRMViewports_error;
		CRMViewports_error = NULL;
		}
	TRACEALL("pD3DRM's refcount _%d\n", rtv);
	return rtv;
	}
bool CD3DRM::CreateRM()
	{
	if (!bD3DRMCreated) CreateD3DRM();
	bD3DRMCreated = true;
	last = this;

	//	�J�������V�[���̎q���łȂ��ꍇ�́A�J�������V�[���̎q�ɂ���
	if (!scene.Find(camera)) scene.Add(camera);
	SetCamera(camera);
	return true;
	}
bool CD3DRM::Create(bool bAddCallback)
	{
	int devWidth, devHeight;
	TRACEALL("CD3DRM::Create()\n");
	if (!CreateRM()) goto leaveReturn;
	if (!pRMDev)
		{
		//	create device from D3DDevice
		if (pCD3DDev)
			{
			//	Check surface
			if (!pCD3DDev->Restore()) goto leaveReturn;
			//	Set callbacks to the surface
			if (bAddCallback)
				{
				pCD3DDev->createCallbacks.Add(CreateCallback, this);
				pCD3DDev->releaseCallbacks.Add(ReleaseCallback, this);
				pCD3DDev->deleteCallbacks.Add(DeleteCallback, this);
				}
			//	create RM device
			if (pCAfD3DDev && pCD3DDev->pCDD->IsFullscreen())
				{
				for(int i=0; i<pCAfD3DDev->backs.Size(); i++)
					{
					views.Add(CRMViewport());
					if (CKRMERR(pD3DRM->CreateDeviceFromD3D(pCD3DDev->pCDD->pD3D, pCAfD3DDev->backs[i].pD3DDev, &views.End()[-1].pRMDev))) goto leaveReturn;
					if (CKRMERR(views.End()[-1].pRMDev->SetBufferCount(pCD3DDev->IsRealFlip() ? pCAfD3DDev->NBuffer() : 1))) goto leaveReturn;
					}
				if (!views.Size()) goto leaveReturn;
				pRMDev = views.End()[-1].pRMDev;
				pRMDev->AddRef();
				}
			else
				{
				if (CKRMERR(pD3DRM->CreateDeviceFromD3D(pCD3DDev->pCDD->pD3D, pCD3DDev->pD3DDev, &pRMDev))) goto leaveReturn;
				if (CKRMERR(pRMDev->SetBufferCount(pCD3DDev->IsRealFlip() ? 2 : 1))) goto leaveReturn;
				}
			}
		//	get device from pCD3DRMBase(other CD3DRM)
		else if (pCD3DRMBase)
			{
			if (!pCD3DRMBase->pRMDev) pCD3DRMBase->Create();
			pRMDev = pCD3DRMBase->pRMDev;
			if (!pRMDev) goto leaveReturn;
			pRMDev->AddRef();
			views = pCD3DRMBase->views;
			pCD3DDev = pCD3DRMBase->pCD3DDev;
			hWnd = pCD3DRMBase->hWnd;
			if (bAddCallback && pCD3DDev)
				{
				pCD3DDev->createCallbacks.Add(CreateCallback, this);
				pCD3DDev->releaseCallbacks.Add(ReleaseCallback, this);
				pCD3DDev->deleteCallbacks.Add(DeleteCallback, this);
				}
			}
		//	create device from hWnd and Clipper
		else if (hWnd)
			{
			if (!pClipper)
				{
				if (CKRMERR(DirectDrawCreateClipper(0, &pClipper, NULL)))
					goto leaveReturn;
				}
			pClipper->SetHWnd(0, hWnd);
			RECT rc;
			GetClientRect(hWnd, &rc);
			if (CKRMERR(pD3DRM->CreateDeviceFromClipper(pClipper, NULL, rc.right, rc.bottom, &pRMDev)))
				goto leaveReturn;
			}
		}
	if (!pRMDev) goto leaveReturn;
	devWidth = pRMDev->GetWidth();
	devHeight = pRMDev->GetHeight();
	if (views.Size())
		{
		for(int i=0; i<views.Size(); i++)
			if (!views[i].pRMView && CKRMERR(pD3DRM->CreateViewport(views[i].pRMDev, camera, 0,0,devWidth,devHeight, &views[i].pRMView))) goto leaveReturn;
		pRMView = views.End()[-1].pRMView;
		pRMView->AddRef();
		}
	else
		{
		if (!pRMView && CKRMERR(pD3DRM->CreateViewport(pRMDev, camera, 0, 0, devWidth, devHeight ,&pRMView)))
			{
			RELEASE(pRMDev);
			goto leaveReturn;
			}
		}
	SetViewport(viewPos, viewSize);
	ForceUpdate();
	SetRenderQuality(renderQuality);
	SetTextureQuality(textureQuality);
	SetViewFrustum();
	return true;
leaveReturn:
	return false;
	}
void CD3DRM::ReleaseRM()
	{
	Release(true);
	RELEASE(pClipper);
	if (bD3DRMCreated) ReleaseD3DRM();
	bD3DRMCreated = false;
	}
void CD3DRM::Release(bool bDelCallback)
	{
	TRACEALL("CD3DRM::Release\n");
	if (bDelCallback && pCD3DDev)
		{
		pCD3DDev->createCallbacks.Del(CreateCallback, this);
		pCD3DDev->releaseCallbacks.Del(ReleaseCallback, this);
		pCD3DDev->deleteCallbacks.Del(DeleteCallback, this);
		}
	CRMViewports::Release();
	}
bool CD3DRM::FitSurface()
	{
	if (pCD3DDev)
		return pCD3DDev->FitSurface();
	if (hWnd)
		{
		RECT rc;
		GetClientRect(hWnd, &rc);
		if (pRMDev->GetWidth() != rc.right-rc.left || pRMDev->GetHeight() != rc.bottom-rc.top)
			{
			Release();
			Create();
			return true;
			}
		}
	return true;
	}
bool CD3DRM::Clear()
	{
	if (pCD3DDev && pCD3DDev->IsLost()) pCD3DDev->Restore();
	if (!pRMView)
		{
		RMERRMSG(2, "There is no D3DRMViewport.");
		return false;
		}
	bool rtv = !CKRMERR(pRMView->Clear());
	return rtv;
	}
bool CD3DRM::Render()
	{
	bool rtv = false;
	if (pCD3DDev && pCD3DDev->IsLost()) pCD3DDev->Restore();
	if (!pRMView)
		{
		RMERRMSG(2, "There is no D3DRMViewport.");
		goto leaveReturn;
		}
	if (!scene)
		{
		RMERRMSG(2, "There is no scene to render.");
		goto leaveReturn;
		}
	rtv = !CKRMERR(pRMView->Render(scene));
leaveReturn:
	return rtv;
	}
bool CD3DRM::Update()
	{
	bool rtv = false;
	if (pCD3DDev && pCD3DDev->IsLost())
    	if (!pCD3DDev->Restore()) goto leave;
		
	if (pRMDev) rtv = !CKRMERR(pRMDev->Update());
leave:
	return rtv;
	}
bool CD3DRM::Flip()
	{
	if (!pCD3DRMBase && pCD3DDev) return pCD3DDev->Flip();
	return false;
	}
bool CD3DRM::Step()
	{
	bool rtv = true;
	FitSurface();
	rtv &= Clear();
	rtv &= Render();
	rtv &= Update();
	rtv &= Flip();
	return rtv;
	}
void CD3DRM::RMBase(CD3DRM& rm)
	{
	pCD3DRMBase = &rm;
	}
void CD3DRM::Surf(CD3DDevice& dev)
	{
	Release();
	hWnd = NULL;
	pCD3DDev = &dev;
	if (!pCD3DDev->pCDD) pCD3DDev->pCDD = &CDDraws::GetLastCreate()->Primary();
	}
void CD3DRM::Surf(CAutoFlipD3DDevice& dev)
	{
	Release();
	hWnd = NULL;
	pCD3DDev = &dev;
	pCAfD3DDev = &dev;
	if (!pCD3DDev->pCDD) pCD3DDev->pCDD = &CDDraws::GetLastCreate()->Primary();
	}
void CD3DRM::HWnd(HWND wnd)
	{
	Release();
	hWnd = wnd;
	pCD3DDev = NULL;
	}
bool CD3DRM::ViewFrustum(const CRMViewFrustum& v)
	{
	viewFrustum = v;
	return SetViewFrustum();
	}
bool CD3DRM::SetViewFrustum()
	{
	if (viewFrustum.front == 0) viewFrustum.front = REAL(1);
	if (viewFrustum.end == 0) viewFrustum.back = REAL(1000);
	if (viewFrustum.bgn.x == 0) viewFrustum.bgn.x = -viewFrustum.front / 2;
	if (viewFrustum.end.x == 0) viewFrustum.end.x = viewFrustum.front / 2;
	REAL w = 1, h = 1;
    if (pRMView)
        {
        w=pRMView->GetWidth();
        h=pRMView->GetHeight();
        }
	REAL asp = h/w * viewFrustum.aspect;
	REAL top = viewFrustum.bgn.y;
	REAL bottom = viewFrustum.end.y;
	if (viewFrustum.bgn.y == 0) top = viewFrustum.bgn.x * asp;
	if (viewFrustum.end.y == 0) bottom = viewFrustum.end.x * asp;
	curViewFrustum.front = viewFrustum.front;
	curViewFrustum.back = viewFrustum.back;
	curViewFrustum.bgn.x = viewFrustum.bgn.x;
	curViewFrustum.end.x = viewFrustum.end.x;
	curViewFrustum.bgn.y = top;
	curViewFrustum.end.y = bottom;
	return CRMViewports::SetViewFrustum(curViewFrustum);
	}

void CD3DRM::Viewport(CD3DVec2 vPos, CD3DVec2 vSize)
	{
	viewPos = vPos;
	viewSize = vSize;
	SetViewport(viewPos, viewSize);
	}
void CD3DRM::Scene(const CRMFrame& s)
	{
	CRMFrame fr;
	fr = s;
	Scene(fr);
	}
void CD3DRM::Scene(CRMFrame& s)
	{
	//	�V�[���t���[�����쐬���ݒ�
	s.Create();
	scene = s;
	//	�J�������V�[���̎q���łȂ��ꍇ�́A�J�������V�[���̎q�ɂ���
	if (!scene.Find(camera)) scene.Add(camera);
	}
void CD3DRM::Camera(const CRMFrame& c)
	{
	CRMFrame fr;
	fr = c;
	Camera(fr);
	}
void CD3DRM::Camera(CRMFrame& c)
	{
	c.Create();
	camera = c;
	//	�J�������V�[���̎q���łȂ��ꍇ�́A�J�������V�[���̎q�ɂ���
	if (!scene.Find(camera)) scene.Add(camera);
	SetCamera(camera);
	}
void CD3DRM::SceneCamera(CRMFrame&s, CRMFrame& c)
	{
	if (!s.Find(c)) s.Add(c);
	scene = s;
	camera = c;
	SetCamera(camera);
	}
void CD3DRM::RenderQuality(D3DRMRENDERQUALITY rq)
	{
	renderQuality = rq;
	SetRenderQuality(rq);
	}
void CD3DRM::TextureQuality(D3DRMTEXTUREQUALITY tq)
	{
	textureQuality = tq;
	SetTextureQuality(tq);
	}

CD3DRM& CD3DRM::GetLastCreate()
	{
	ASSERT(last);
	return *last;
	}
bool CD3DRM::SetPurpose(int i, bool bDelay)
	{
	if (!pCAfD3DDev) return false;
	bool rtv = pCAfD3DDev->SetPurpose(i, bDelay);
	if (!rtv) return false;
	RELEASE(pRMView);
	RELEASE(pRMDev);
	int draw = pCAfD3DDev->Cur();
	pRMView = views[draw].pRMView;
	pRMDev = views[draw].pRMDev;
	pRMView->AddRef();
	pRMDev->AddRef();
	int x = pRMView->GetX();
	int y = pRMView->GetY();
	pRMView->ForceUpdate(x, y, x+pRMView->GetWidth(), y+pRMView->GetHeight());
	return true;
	}
bool CD3DRM::UpdatePurpose()
	{
	if (!pCAfD3DDev) return false;
	return pCAfD3DDev->UpdatePurpose();
	}
int CD3DRM::NPurpose()
	{
	if (!pCAfD3DDev) return 1;
	return pCAfD3DDev->NPurpose();
	}
void CD3DRM::NPurpose(int n)
	{
	if (!pCAfD3DDev) return;
	pCAfD3DDev->NPurpose(n);
	}

CRMObject CD3DRM::Find(const char* name)
	{
	IDirect3DRMObject* pObj=NULL;
	CKRMERR(pD3DRM->GetNamedObject(name, &pObj));
	return pObj;
	}
IDirect3DRM* CD3DRM::operator ->() const
	{
	return pD3DRM;
	}
IDirect3DRM* CD3DRM::operator *() const
	{
	return pD3DRM;
	}
static CD3DVec3 ConvVec3(D3DRMVECTOR4D sch)
	{
	CD3DVec3 sco;
	if (sch.w)
		{
		REAL rhw = 1/sch.w;
		sco.x = sch.x * rhw;
		sco.y = sch.x * rhw;
		sco.y = sch.z * rhw;
		}
	return sco;
	}
CD3DVec3 CD3DRM::WorldToView(const CD3DVec3& w)
	{
	D3DRMVECTOR4D sch;
	ASSERT(pRMView);
    D3DVECTOR v3w = w;
	CKRMERR(pRMView->Transform(&sch, &v3w));
	CD3DVec3 sc;
	if (sch.w)
		{
		REAL rhw = 1/sch.w;
		sc.x = sch.x * rhw;
		sc.y = sch.y * rhw;
		sc.z = sch.z * rhw;
		}
	return sc;
	}
CD3DVec3 CD3DRM::ViewToWorld(const CD3DVec3& v)
	{
	D3DRMVECTOR4D sch;
	sch.x = v.x;
	sch.y = v.y;
	sch.z = v.z;
	sch.w = 1;
	D3DVECTOR w;
	ASSERT(pRMView);
	CKRMERR(pRMView->InverseTransform(&w, &sch));
	return w;
	}

//////////////////////////////////////////////////////////////

/*
#include <Hase/D3D/D3DMacs.h>
bool CD3DRM::SetClip()
	{
	D3DEXECUTEBUFFERDESC debDesc;
	D3DEXECUTEDATA d3dExData;
	LPDIRECT3DEXECUTEBUFFER pD3DExCmdBuf = NULL;
	LPVOID lpBuffer, lpInsStart;
	size_t size;
	if (!pCD3DDev) return true;
	//	there is no D3D Viewport, we must return true because it is not required.
    IDirect3DViewport* pD3DView = NULL;
    pRMView->GetDirect3DViewport(&pD3DView);
	if (!pD3DView) return true;
	//	Create an execute buffer of the required size
	size = 0;
	size += sizeof(D3DINSTRUCTION) * 2;
	size += sizeof(D3DSTATUS) * 1;
	memset(&debDesc, 0, sizeof(D3DEXECUTEBUFFERDESC));
	debDesc.dwSize = sizeof(D3DEXECUTEBUFFERDESC);
	debDesc.dwFlags = D3DDEB_BUFSIZE;
	debDesc.dwBufferSize = size;
	if (CKRMERR(pCD3DDev->pD3DDev->CreateExecuteBuffer(&debDesc, &pD3DExCmdBuf, NULL))) goto exit_with_error;
	//	Lock the execute buffer so it can be filled
	if (CKRMERR(pD3DExCmdBuf->Lock(&debDesc))) goto exit_with_error;
	memset(debDesc.lpData, 0, size);
	lpInsStart = debDesc.lpData;
	lpBuffer = lpInsStart;
	//	Set render state
	OP_SET_STATUS(
		D3DSETSTATUS_ALL,
		D3DSTATUS_DEFAULT | D3DCLIP_BACK | D3DCLIP_BOTTOM | D3DCLIP_FRONT | D3DCLIP_LEFT | D3DCLIP_RIGHT | D3DCLIP_TOP,
		0,0,0,0, lpBuffer);
	OP_EXIT(lpBuffer);
	if (CKRMERR(pD3DExCmdBuf->Unlock())) goto exit_with_error;
	//	Set the execute data and exectue the buffer
	memset(&d3dExData, 0, sizeof(D3DEXECUTEDATA));
	d3dExData.dwSize = sizeof(D3DEXECUTEDATA);
	d3dExData.dwInstructionOffset = (ULONG) 0;
	d3dExData.dwInstructionLength = (ULONG) ((char*)lpBuffer - (char*)lpInsStart);
	pD3DExCmdBuf->SetExecuteData(&d3dExData);
	if (CKRMERR(pCD3DDev->pD3DDev->BeginScene())) goto exit_with_error;
	if (CKRMERR(pCD3DDev->pD3DDev->Execute(pD3DExCmdBuf,pD3DView,D3DEXECUTE_UNCLIPPED))) goto exit_with_error;
	if (CKRMERR(pCD3DDev->pD3DDev->EndScene())) goto exit_with_error;
	//	We are done with the execute buffer, so release it.
	pD3DExCmdBuf->Release();
	return true;

exit_with_error:
	RELEASE(pD3DExCmdBuf);
	return false;
	}
*/
END_NAMESPACE_HASE
