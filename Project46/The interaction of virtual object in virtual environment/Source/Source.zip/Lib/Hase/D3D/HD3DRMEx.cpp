#ifdef USEMFC
#include "Hase/Stream/WinStream.h"
#define DEBUG_STREAM CWinStream::First()
#endif
#include "Hase/D3D/HD3DRMEx.h"
#include "Hase/D3D/HD3DRMExDef.h"			//	�}�N����`
#include "Hase/3D/FrameB.cpp"
#include "Hase/3D/MotionB.cpp"
#include "Hase/3D/VisualB.cpp"
#include "Hase/D3D/HD3DRM.h"
#define UNDEF_ALL_FRAMEB
#include "Hase/3D/FrameB.h"				//	�}�N������
#pragma hdrstop

BEGIN_NAMESPACE_HASE
FindFrameExt::FindFrameExt()
	{
	nFrame = 0;
	curr = 0;
	}
FindFrameExt::~FindFrameExt()
	{
	}
FindVisualExt::FindVisualExt()
	{
	nVisual = 0;
	curr = 0;
	}
FindVisualExt::~FindVisualExt()
	{
	}

//-----------------------------------------------------------------------------
//	CD3DRMEx
//
void CD3DRMEx::Scene(CRMFrameEx& s)
	{
	CD3DRM::Scene(s);
	}
void CD3DRMEx::Camera(CRMFrameEx& c)
	{
	CD3DRM::Camera(c);
	}
void CD3DRMEx::Scene(const CRMFrameEx& s)
	{
	CD3DRM::Scene(s);
	}
void CD3DRMEx::Camera(const CRMFrameEx& c)
	{
	CD3DRM::Camera(c);
	}
//-----------------------------------------------------------------------------
//	CRMObjExt
//
CRMObjExt* CRMObjExt::GetExt(IDirect3DRMObject* p)
	{
	ASSERT(p);
	return (CRMObjExt*)(p->GetAppData());
	}
void CRMObjExt::SetExt(IDirect3DRMObject* p, CRMObjExt* ext)
	{
	ASSERT(p);
	CKRMERR( p->SetAppData((DWORD)ext) );
	}

CRMObjExt::CRMObjExt(IDirect3DRMObject* p)
	{
	userDeleteCallback = NULL;
	userData = NULL;
	pRMObj = p;
	if (pRMObj)
		{
		CRMObjExt* res = CRMObjExt::GetExt(pRMObj);
		ASSERT(res==0);
		CRMObjExt::SetExt(pRMObj, this);
		pRMObj->AddDestroyCallback(DestroyCallback, this);
		}
	}
void CRMObjExt::Set(IDirect3DRMObject* p)
	{
	if (pRMObj)
		{
		CRMObjExt::SetExt(pRMObj, NULL);
		pRMObj->DeleteDestroyCallback(DestroyCallback, this);
		}
	pRMObj = p;
	CRMObjExt* old = CRMObjExt::GetExt(pRMObj);
	delete old;
	CRMObjExt::SetExt(pRMObj, this);
	pRMObj->AddDestroyCallback(DestroyCallback, this);
	}
CRMObjExt::~CRMObjExt()
	{
	if (userDeleteCallback) userDeleteCallback(this);
	if (pRMObj)
		{
		CRMObjExt::SetExt(pRMObj, NULL);
		pRMObj->DeleteDestroyCallback(DestroyCallback, this);
		pRMObj = NULL;
		}
	}
void CRMObjExt::DestroyCallback(IDirect3DRMObject* , void* pArg)
	{
	CRMObjExt* pExt = (CRMObjExt*)pArg;
	pExt->pRMObj = NULL;
	delete pExt;
	}
END_NAMESPACE_HASE
