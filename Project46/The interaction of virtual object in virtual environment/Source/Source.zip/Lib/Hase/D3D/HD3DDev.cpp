#include "Hase/DDraw/HDDMode.h"
#include "Hase/D3D/HD3DDev.h"
BEGIN_NAMESPACE_HASE
using namespace std;
bool CD3DDriver::CheckRendDepth(int bpp)
	{
	return (CDDraw::BPPToDDBD(bpp) & desc.dwDeviceRenderBitDepth) != 0;
	}

CD3DDrivers::CD3DDrivers()
	{
	cur = -1;
	prefer = 0;
	}
CD3DDriver& CD3DDrivers::CurDriver()
	{
	if (cur < 0) cur = 0;
	if (cur > (int)Size()-1) cur = Size()-1;
	return *(Bgn()+cur);
	}
bool CD3DDrivers::Select(int rendDepth, bool bHALOK)
	{
	int i = prefer;
	if (i < 0) i = 0;
	if (i > (int)Size()-1) i = Size() - 1;
	for(UINT j=0; j<Size(); j++,i++)
		{
		if (i >= (int)Size()) i = 0;
		if ((bHALOK || !Bgn()[i].bHAL)
			&& Bgn()[i].CheckRendDepth(rendDepth))
			{
			cur = i;
			return true;
			}
		}
	return false;
	}
void CD3DDrivers::Set(int id)
	{
	prefer = id;
	}
//----------------------------------------------------------------------------
//	CD3DDevice
//
static HRESULT PASCAL EnumDevicesCallback(GUID* pGuid, char* a, char* n, D3DDEVICEDESC* pHAL, D3DDEVICEDESC* pHEL, void* pContext)
	{
	CD3DDevice* pDev = (CD3DDevice*)pContext;
	CD3DDriver newDrv;
	newDrv.guid = *pGuid;
	newDrv.about = a;
	newDrv.name = n;
    if (pHAL->dcmColorModel)
		{
        newDrv.bHAL = true;
        newDrv.desc = *pHAL;
		}
	else
		{
        newDrv.bHAL = false;
        newDrv.desc = *pHEL;
		}
	newDrv.zBufferDepth = CDDraw::FindBPP(newDrv.desc.dwDeviceZBufferBitDepth, 16);
	pDev->drivers.Add(newDrv);
	return D3DENUMRET_OK;
	}
bool CD3DDevice::EnumDrivers()
	{
	CDD_ENTER_CRITICAL;
	if (!pCDD) pCDD = &(CDDraws::GetLastCreate()->Primary());
	if (!pCDD->Create3D())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	drivers.Clear();
	bool rtv = pCDD->CKDDERR(pCDD->pD3D->EnumDevices(EnumDevicesCallback, this));
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
bool CD3DDevice::CZSurface::Create(DWORD depth, bool bHAL, bool bCallCallback)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	Caps(DDSCAPS_ZBUFFER);
	desc.dwFlags |= DDSD_ZBUFFERBITDEPTH;
	desc.dwZBufferBitDepth = depth;
    if (bHAL) 
		{
		desc.ddsCaps.dwCaps |= DDSCAPS_VIDEOMEMORY;
		desc.ddsCaps.dwCaps &= ~DDSCAPS_SYSTEMMEMORY;
		if (CDDSurface::Create(bCallCallback)) 
			{
			CDD_LEAVE_CRITICAL;
			return true;
			}
		}
	desc.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;
	desc.ddsCaps.dwCaps &= ~DDSCAPS_VIDEOMEMORY;
	bool rtv = CDDSurface::Create(bCallCallback);
	CDD_LEAVE_CRITICAL;
	return rtv;
	}
CD3DDevice::CD3DDevice()
	{
	pD3DDev = NULL;
#if DIRECTDRAW_VERSION >= 0x0500
	pD3DDev2 = NULL;
#endif
	}
CD3DDevice::~CD3DDevice()
	{
	Release();
	if (bCallDeleteCallbacks)
		{
		bCallDeleteCallbacks = false;
		deleteCallbacks.Call(*this);
		}
	}
void CD3DDevice::DDraw(CDDraw& dd)
	{
	Release();
	CFlipSurface::DDraw(dd);
	zBuffer.DDraw(dd);
	EnumDrivers();
	}
bool CD3DDevice::Create(bool bCallCallback, int nBackBuffer)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	if (!pCDD)
    	{
        pCDD = &(CDDraws::GetLastCreate()->Primary());
        }
	if (!pCDD->Create())
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	if (!zBuffer.pCDD) zBuffer.pCDD = pCDD;
	TRACEALL("CD3DDevice::Create\n");
	if (drivers.Size() == 0) EnumDrivers();
	if (drivers.Size() == 0)
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	//	create flip 3D surface
	desc.ddsCaps.dwCaps |= DDSCAPS_3DDEVICE;
	if (!CFlipSurface::Create(false, nBackBuffer))
		{
		CDD_LEAVE_CRITICAL;
		return false;
		}
	//	init d3d
	if (!pCDD->Create3D()) goto releaseReturn;
	//	select d3d driver that is good for this surface
	if (!drivers.Select(desc.bitPerPixel, (desc.ddsCaps.dwCaps&DDSCAPS_VIDEOMEMORY)!=0))
		{
		pCDD->DDERRMSG(2, "Cannot find d3d driver that is good for this surface.");
		goto releaseReturn;
		}
	//	create zbuffer if it was requested.
	if (drivers.CurDriver().zBufferDepth)
		{
		zBuffer.Release(bCallCallback);
		zBuffer.Size(Size());
		if (!zBuffer.Create(drivers.CurDriver().zBufferDepth, drivers.CurDriver().bHAL, bCallCallback)) goto releaseReturn;
		//	If z buffer is in system memory, we can't use HAL.
		if (drivers.CurDriver().bHAL && zBuffer.desc.ddsCaps.dwCaps&DDSCAPS_SYSTEMMEMORY)
			{
			if (!drivers.Select(desc.bitPerPixel, false))
				{
				pCDD->DDERRMSG(2, "Cannot find d3d driver that is good for this surface.");
				goto releaseReturn;
				}
			zBuffer.Release(bCallCallback);
			if (!zBuffer.Create(drivers.CurDriver().zBufferDepth, false, bCallCallback)) goto releaseReturn;
			}
		TRACEALL("CD3DDevice::Create zBuf%d: (%d,%d) %d\n", zBuffer.Size().cx, zBuffer.Size().cy, zBuffer.desc.ddsCaps.dwCaps & DDSCAPS_VIDEOMEMORY);
		}
#if 0
	//	If d3ddriver is HEL, backbuffer should be in system memory.
	if (!drivers.CurDriver().bHAL && desc.ddsCaps.dwCaps&DDSCAPS_VIDEOMEMORY)
		{
		CFlipSurface::Release(false);
		desc.ddsCaps.dwCaps &= ~DDSCAPS_VIDEOMEMORY;
		desc.ddsCaps.dwCaps |= DDSCAPS_SYSTEMMEMORY;
		CFlipSurface::Create(false);
        if (!pDDS) goto releaseReturn();
		descOld.ddsCaps.dwCaps &= ~DDSCAPS_SYSTEMMEMORY;
		}
#endif
	//	Attach z buffer to the back buffer
	if (zBuffer.pDDS && pCDD->CKDDERR(pDDS->AddAttachedSurface(zBuffer.pDDS))) goto releaseReturn;
	//	create d3ddevice
	if (pCDD->CKDDERR(pDDS2->QueryInterface(drivers.CurDriver().guid, (void**)&pD3DDev))) goto releaseReturn;
	if (bCallCallback)
		{
		createCallbacks.Call(*this);
		}
	CDD_LEAVE_CRITICAL;
	return true;
releaseReturn:
	Release(false);
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CD3DDevice::Release(bool bCallCallback)
	{
	if (!pDDS) return;
	CDD_ENTER_CRITICAL;
	TRACEALL("CD3DDevice::Release\n");
	if (bCallCallback)
		{
		releaseCallbacks.Call(*this);
		}
	RELEASE(pD3DDev);
	zBuffer.Release(bCallCallback);
	CFlipSurface::Release(false);
	CDD_LEAVE_CRITICAL;
	}
bool CD3DDevice::Restore()
	{
	CDD_ENTER_CRITICAL;
	bool rtv = CFlipSurface::Restore();
  	if (rtv && zBuffer.pDDS && zBuffer.pDDS->IsLost() == DDERR_SURFACELOST)
		{
		HRESULT hr = zBuffer.pDDS->Restore();
		if (hr!=DDERR_OUTOFMEMORY && hr!=DDERR_OUTOFVIDEOMEMORY)
			{
			Release();
			rtv = Create();
			goto leave;
			}
		if (pCDD->CKDDERRMSG(hr, "restore surface failed."))
			{
			rtv = false;
			goto leave;
			}
		}
leave:
	CDD_LEAVE_CRITICAL;
	return rtv;
	}

//----------------------------------------------------------------------------
//	CD3DDevInterface
//
CD3DDevInterface::CD3DDevInterface()
	{
	pD3DDev = NULL;
	}
CD3DDevInterface::CD3DDevInterface(const CD3DDevInterface& i):
	CDDSInterface(i)
	{
	pD3DDev = i.pD3DDev;
	if (pD3DDev) pD3DDev->AddRef();
	}
CD3DDevInterface::~CD3DDevInterface()
	{
	RELEASE(pD3DDev);
	}
//----------------------------------------------------------------------------
//	CAutoFlipD3DDevice
//
HRESULT WINAPI CAutoFlipD3DDevice::EnumSurfacesCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext)
	{
	if ((pDesc->ddsCaps.dwCaps & DDSCAPS_ZBUFFER)) return DDENUMRET_OK;
	CAutoFlipD3DDevice& surf = *(CAutoFlipD3DDevice*)pContext;
	CD3DDevInterface newSurf;
	newSurf.pDDS = pDDS;
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface2, (void**)&newSurf.pDDS2);
#if DIRECTDRAW_VERSION >= 0x0500
	newSurf.pDDS->QueryInterface(IID_IDirectDrawSurface3, (void**)&newSurf.pDDS3);
#endif
	surf.backs.Add(newSurf);
	return DDENUMRET_OK;
	}

CAutoFlipD3DDevice::CAutoFlipD3DDevice()
	{
	}
CAutoFlipD3DDevice::~CAutoFlipD3DDevice()
	{
	Release();
	}
CDDSInterface& CAutoFlipD3DDevice::BackBuffer(int p, int t)
	{
	ASSERT(0<=p&&p<nBackBuffer+1 && 0<=t&&t<3);
	ASSERT(purposeTable[p][t] >= 0);
	return backs[purposeTable[p][t]];
	}
void CAutoFlipD3DDevice::CurBuffer(CDDSInterface& nb)
	{
	(CDDSInterface&)*this = nb;
	pD3DDev->Release();
	pD3DDev = ((CD3DDevInterface&)nb).pD3DDev;
	pD3DDev->AddRef();
	}
CDDSInterface& CAutoFlipD3DDevice::FrontBuffer()
	{
	return pCDD->surfPrimary;
	}
bool CAutoFlipD3DDevice::Flip()
	{
	return CD3DDevice::Flip();
	}
bool CAutoFlipD3DDevice::Flip(int n)
	{
	if (!Restore()) return false;
	if (bRunFlipThread) return false;
	if (n<0 || n>=backs.Size()) return false;
	(CD3DDevInterface&)*this = backs[n];
	Flip();
	return true;
	}
bool CAutoFlipD3DDevice::Restore()
	{
	return CD3DDevice::Restore();
	}
bool CAutoFlipD3DDevice::CreatePurposeTable()
	{
	if (!Create()) return false;
	if (backs.Size() < nBackBuffer) return false;
	return CAutoFlip::CreatePurposeTable();
	}
bool CAutoFlipD3DDevice::Create(bool bCallCallback)
	{
	if (pDDS) return true;
	CDD_ENTER_CRITICAL;
	if (!CD3DDevice::Create(false, nBackBuffer)) return false;
	if (pCDD->IsFullscreen())
		{
		CD3DDevInterface devi;
		(CDDSInterface&)devi = *this;
		devi.pD3DDev = pD3DDev;
		devi.pD3DDev->AddRef();
		backs.Add(devi);
		int i;
		for(i=1; i<nBackBuffer; i++)
			{
			//	get next surface.
			int sizeOld = backs.Size();
			backs.End()[-1].pDDS->EnumAttachedSurfaces(this, EnumSurfacesCallback);
			if (backs.Size() <= sizeOld) goto leave;
			//	attach Z buffer.
			if (zBuffer.pDDS && pCDD->CKDDERR(backs.End()[-1].pDDS->AddAttachedSurface(zBuffer.pDDS))) goto leave;
			//	create d3ddevice
			if (pCDD->CKDDERR(backs.End()[-1].pDDS2->QueryInterface(drivers.CurDriver().guid, (void**)&backs.End()[-1].pD3DDev))) goto leave;
			}
		//	set palette
		if (desc.ddpfPixelFormat.dwFlags&DDPF_PALETTEINDEXED8)
			{
			if (!pCDD->CreatePalette()) goto leave;
			for(int i=1; i<nBackBuffer; i++)
				if (pCDD->CKDDERR(backs[i].pDDS->SetPalette(pCDD->pPalette))) goto leave;
			}
		bFlippable = true;
		}
	if (bCallCallback) createCallbacks.Call(*this);
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	Release();
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CAutoFlipD3DDevice::Release(bool bCallCallback)
	{
	if (!pDDS && backs.Size() == 0) return;
	CDD_ENTER_CRITICAL;
	ReleasePurposeTable();
	if (!pCDD) goto leave;
	backs.Clear();
	CD3DDevice::Release(bCallCallback);
leave:
	CDD_LEAVE_CRITICAL;
	}

END_NAMESPACE_HASE
