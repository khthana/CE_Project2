#ifndef HASE_D3D_HRMVISUALEX_H
#define HASE_D3D_HRMVISUALEX_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"
#include "Hase/D3D/HRMVisual.h"
BEGIN_NAMESPACE_HASE
class DLLCLASS CRMColSphere: public CColSphere
	{
	public:
	CRMColSphere(D3DVALUE r=D3DVALUE(1));
	};
class DLLCLASS CRMColPlane: public CColPlane
	{
	};
class DLLCLASS CRMColDisc: public CColDisc
	{
	public:
	CRMColDisc(CD3DVec3 n, D3DVALUE r);
	};
class DLLCLASS CRMColRect: public CColRect
	{
	public:
	CRMColRect(const CD3DVec2& rect);
	};
class DLLCLASS CRMColBox: public CColBox
	{
	public:
	CRMColBox(const CD3DVec3& b);
	};
class DLLCLASS CRMColMesh: public CColMesh
	{
	protected:
	DWORD nVtx;
	D3DVECTOR* vtx;
	DWORD nFace;
	DWORD **face;
	DWORD nFaceData;
	DWORD* faceData;

	public:
	CRMColMesh();
	virtual ~CRMColMesh();
	virtual void Set(IDirect3DRMObject* p);
	void GetVertex();
	void ReleaseVertex();
	void UpdateVertex();
	void Update();
	IDirect3DRMMeshBuilder* PMeshB(){return (IDirect3DRMMeshBuilder*) pRMObj;}
	virtual int NFace();			//	�ʂ̐�
	virtual int NVertex();			//	���_�̐�
	virtual int NVertex(int fn);	//	�� fn �̒��_�̐�
	virtual int VertexID(int fn, int n);
									//	�� fn �� n �Ԗڂ̒��_��ID
	virtual CD3DVec3 Pos(int id);	//	ID �� id �̒��_�̈ʒu
	};

class DLLCLASS CRMMeshEx: public CRMMesh
	{
	protected:
	virtual void UpdateMesh();
	public:
	CRMMeshEx(){}
	CRMMeshEx(const CRMMesh& m):CRMMesh(m){}
	CRMMeshEx(std::string fname):CRMMesh(fname){}
	virtual bool Load(std::string fname);
	virtual bool Scale(const CD3DVec3& s);
	virtual bool Pos(const CD3DVec3& s);
	virtual bool Add(CRMFace& face);
	virtual int Add(CRMVertex& vtx);
	const CMotionMaterial& MotMtr(){return Ext().MotMtr();}
	void MotMtr(CMotionMaterial& m){Ext().MotMtr(m);}
	CRMColMesh::EColPrec& ColPrec(){return Ext().colPrec;}

	bool IsExtend();
	CColVisual& Ext();
	void Ext(CColVisual* pVis);
	};

END_NAMESPACE_HASE
#endif