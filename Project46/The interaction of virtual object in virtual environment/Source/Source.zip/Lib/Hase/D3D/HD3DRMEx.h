#ifndef HASE_D3D_HD3DRMEX_H
#define HASE_D3D_HD3DRMEX_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Hase/Misc/Inc.h"
#include "Hase/D3D/HD3DAffine.h"
//-----------------------------------------------------------------------------
//	Hase/3D �̋@�\����荞��
//
#include "Hase/D3D/HD3DRMExDef.h"
BEGIN_NAMESPACE_HASE
struct DLLCLASS FindFrameExt
	{
	FindFrameExt();
	~FindFrameExt();
	int nFrame;
	int curr;
	};
struct DLLCLASS FindVisualExt
	{
	FindVisualExt();
	~FindVisualExt();
	int nVisual;
	int curr;
	};
class DLLCLASS CRMObjExt
	{
	protected:
	IDirect3DRMObject* pRMObj;
	static void DestroyCallback(IDirect3DRMObject* pObj, void* pArg);
	
	public:
	typedef void (*CallbackFunc)(CRMObjExt* pExt);
	CallbackFunc userDeleteCallback;
	void* userData;
	CRMObjExt(IDirect3DRMObject* p=NULL);
	virtual void Set(IDirect3DRMObject* p);
	virtual ~CRMObjExt();
	static CRMObjExt* GetExt(IDirect3DRMObject* p);
	static void SetExt(IDirect3DRMObject* p, CRMObjExt* ext);
	virtual void Update(){}
	};
END_NAMESPACE_HASE
//	�C���N���[�h
#include "Hase/3D/FrameB.h"
#include "Hase/3D/VisualB.h"
#include "Hase/3D/MotionB.h"
//	�}�N���̏���
#define UNDEF_ALL_FRAMEB
#include "Hase/3D/FrameB.h"
//-----------------------------------------------------------------------------

#include "Hase/D3D/HD3DRM.h"
#include "Hase/D3D/HRMFrameEx.h"
#include "Hase/D3D/HRMVisualEx.h"

BEGIN_NAMESPACE_HASE
class DLLCLASS CD3DRMEx:public CD3DRM
	{
	public:
	CRMFrameEx Scene(){return scene;}
	CRMFrameEx Camera(){return camera;}
	void Scene(const CRMFrameEx& s);
	void Scene(CRMFrameEx& s);
	void Camera(const CRMFrameEx& c);
	void Camera(CRMFrameEx& c);
	};
END_NAMESPACE_HASE

#endif