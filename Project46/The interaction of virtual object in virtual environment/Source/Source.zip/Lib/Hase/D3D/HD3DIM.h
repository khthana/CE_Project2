#ifndef HASE_D3D_HD3DIM_H
#define HASE_D3D_HD3DIM_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"
#include "Hase/DX/HDXObj.h"
#include "Hase/D3D/HD3DDev.h"
#include "Hase/D3D/HD3DAffine.h"
#define IMERRMSG(n, msg)		error.DXERRMSG(n, msg)
#define CKIMERR(n)				error.CKDXERR(n)
#define CKIMERRMSG(n,msg)		error.CKDXERRMSG(n, msg)

BEGIN_NAMESPACE_HASE
inline D3DCOLORVALUE D3DCV(REAL r, REAL g, REAL b, REAL a=1)
	{
	D3DCOLORVALUE c;
	c.r = r;
	c.g = g;
	c.b = b;
	c.a = a;
	return c;
	}
inline D3DVERTEX D3DVertex(D3DVECTOR pos, D3DVECTOR n, REAL u=0, REAL v=1)
	{
	D3DVERTEX vtx;
	vtx.dvX = pos.x;
	vtx.dvY = pos.y;
	vtx.dvZ = pos.z;
	vtx.dvNX = n.x;
	vtx.dvNY = n.y;
	vtx.dvNZ = n.z;
	vtx.dvTU = u;
	vtx.dvTV = v;
	return vtx;
	}
#define D3DInst(op, dat, count)	D3DInstFunc_(op, sizeof(dat), count)
#define D3DInstN(op, count)		D3DInstFunc_(op, 0, count)
inline D3DINSTRUCTION D3DInstFunc_(D3DOPCODE op, size_t sz, WORD count)
	{
	D3DINSTRUCTION inst;
	inst.bOpcode = op;
	inst.bSize = sz;
	inst.wCount = count;
	return inst;
	}
inline D3DSTATE D3DSTTrans(D3DTRANSFORMSTATETYPE tt, DWORD hMat)
	{
	D3DSTATE st;
	st.dtstTransformStateType = tt;
	st.dwArg[0] = hMat;
	return st;
	}
inline D3DSTATE D3DSTLight(D3DLIGHTSTATETYPE lt, DWORD dw)
	{
	D3DSTATE st;
	st.dlstLightStateType = lt;
	st.dwArg[0] = dw;
	return st;
	}
inline D3DSTATE D3DSTLight(D3DLIGHTSTATETYPE lt, D3DFOGMODE dw)
	{
	return D3DSTLight(lt, (DWORD)dw);
	}
inline D3DSTATE D3DSTLight(D3DLIGHTSTATETYPE lt, D3DVALUE dv)
	{
	D3DSTATE st;
	st.dlstLightStateType = lt;
	st.dvArg[0] = dv;
	return st;
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, DWORD dw)
	{
	D3DSTATE st;
	st.drstRenderStateType = rt;
	st.dwArg[0] = dw;
	return st;
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DTEXTUREADDRESS dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DFILLMODE dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DSHADEMODE dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DLINEPATTERN dw)
	{
	return D3DSTRender(rt, *(DWORD*)&dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DTEXTUREFILTER dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DBLEND dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DTEXTUREBLEND dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DCULL dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DCMPFUNC dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DFOGMODE dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, bool dw)
	{
	return D3DSTRender(rt, (DWORD)dw);
	}
inline D3DSTATE D3DSTRender(D3DRENDERSTATETYPE rt, D3DVALUE dv)
	{
	D3DSTATE st;
	st.drstRenderStateType = rt;
	st.dvArg[0] = dv;
	return st;
	}
inline D3DPROCESSVERTICES D3DProcVtx(DWORD flg, WORD num, WORD start=0, WORD dest=0)
	{
	D3DPROCESSVERTICES pv;
	pv.dwFlags = flg;
	pv.wStart  = start;           /* First source vertex */
	pv.wDest   = dest;
	pv.dwCount = num;
	pv.dwReserved = 0;
	return pv;
	}
inline D3DTRIANGLE D3DTriangle(WORD v1, WORD v2, WORD v3, WORD flg)
	{
	D3DTRIANGLE tri;
	tri.v1 = v1;
	tri.v2 = v2;
	tri.v3 = v3;
	tri.wFlags = flg;
	return tri;
	}
class DLLCLASS CIMObject:public CDXObject
	{
	protected:
	CD3DIM* pIM;
	DWORD handle;
	bool bCreated;

	public:
	CIMObject();
	CIMObject(CIMObject& o);
	CIMObject(IUnknown* o);
	virtual void AfterDevCreate(){}
	virtual void BeforeDevRelease(){handle = NULL;}
	void CheckIM();
	operator DWORD()
		{
		return handle;
		}
	virtual bool Create();
	virtual void Release();
	};
class DLLCLASS CIMMaterial:public CIMObject, public D3DMATERIAL
	{
	protected:
	IDirect3DMaterial*& PMaterial() const
		{
		return (IDirect3DMaterial*&) pObject;
		}
	virtual void AfterDevCreate();
	public:
	CIMMaterial(IDirect3DMaterial* m=NULL);
	CIMMaterial(const CIMMaterial& m);
	//							�g�U					��				����			�n�C���C�g		�n�C���C�g�̉s��
	CIMMaterial(D3DCOLORVALUE diffuse, D3DCOLORVALUE ambient, D3DCOLORVALUE specular, D3DCOLORVALUE emmisive, REAL power);
	//				���̂̐F	�n�C���C�g�̉s��
	CIMMaterial(D3DCOLORVALUE c, REAL power);
	//						�g�U					��				����			�n�C���C�g		�n�C���C�g�̉s��
	virtual ~CIMMaterial();
	void Set(D3DCOLORVALUE diffuse, D3DCOLORVALUE ambient, D3DCOLORVALUE specular, D3DCOLORVALUE emmisive, REAL power);
	//				���̂̐F	�n�C���C�g�̉s��
	void Set(D3DCOLORVALUE c, REAL power);
	bool Set();
	bool Get();
	virtual bool Create();
	void Release();
	operator IDirect3DMaterial* () const
		{
		return (IDirect3DMaterial*) pObject;
		}
	operator DWORD ()
		{
		Create();
		return handle;
		}
	};
class DLLCLASS CIMMatrix: public CIMObject
	{
	protected:
	void AfterDevCreate();

	public:
	CD3DAffine mat;
	CIMMatrix(REAL front, REAL back, CD3DVec2 center=CD3DVec2(0,0), CD3DVec2 size=CD3DVec2(1,1));
	CIMMatrix(const CD3DAffine& af);
	CIMMatrix(const CIMMatrix& m);
	CIMMatrix();
	~CIMMatrix();
	bool Create();
	void Release();
	operator CD3DAffine();
	CIMMatrix operator = (const CD3DAffine& af);
	CIMMatrix operator = (const CIMMatrix& m);
	bool Get();
	bool Set();
	};
class DLLCLASS CIMLight:public CIMObject, public D3DLIGHT
	{
	protected:
	IDirect3DLight*& PLight() const
		{
		return (IDirect3DLight*&) pObject;
		}
	virtual void AfterDevCreate();
	public:
	CIMLight(const CIMLight& l);
	CIMLight(IDirect3DLight* l=NULL);
	~CIMLight();
	bool Create();
	void Release();
	bool Set();
	bool Get();
	operator IDirect3DLight*() const
		{
		return (IDirect3DLight*)pObject;
		}
	};

class DLLCLASS CIMExecuteBuffer:public CIMObject
	{
	protected:
	bool bLock;
	BYTE* pCur;
	D3DEXECUTEDATA data;
	D3DEXECUTEBUFFERDESC desc, descOld;
	IDirect3DExecuteBuffer*& PBuf()
		{
		return (IDirect3DExecuteBuffer*&)pObject;
		}
	void AfterDevCreate();
	void BeforeDevRelease();

	public:
	CIMExecuteBuffer();
	bool Create();
	void Release();
	operator IDirect3DExecuteBuffer*() const
		{
		return (IDirect3DExecuteBuffer*)pObject;
		}
	DWORD Size();
	DWORD Caps();
	void Size(size_t sz);
	void Caps(DWORD flags);
	bool Lock();
	void Unlock();
	void EndVertex();
	void EndInst();
	//	vertex
	D3DVERTEX*& PVertex()
		{
		return (D3DVERTEX*&) pCur;
		}
	//	instruction
	D3DINSTRUCTION*& PInst()
		{
		return (D3DINSTRUCTION*&) pCur;
		}
	//	op code
	D3DPOINT*& PPoint()
		{
		return (D3DPOINT*&) pCur;
		}
	D3DLINE*& PLine()
		{
		return (D3DLINE*&) pCur;
		}
	D3DTRIANGLE*& PTri()
		{
		return (D3DTRIANGLE*&) pCur;
		}
	D3DMATRIXLOAD*& PMatLoad()
		{
		return (D3DMATRIXLOAD*&) pCur;
		}
	D3DMATRIXMULTIPLY*& PMatMulti()
		{
		return (D3DMATRIXMULTIPLY*&) pCur;
		}
	D3DSTATE*& PState()
		{
		return (D3DSTATE*&) pCur;
		}
	D3DPROCESSVERTICES*& PProcVtx()
		{
		return (D3DPROCESSVERTICES*&) pCur;
		}
	D3DTEXTURELOAD*& PTexLoad()
		{
		return (D3DTEXTURELOAD*&) pCur;
		}
	D3DBRANCH*& PBrach()
		{
		return (D3DBRANCH*&) pCur;
		}
	D3DSPAN*& PSpan()
		{
		return (D3DSPAN*&) pCur;
		}
	D3DSTATUS*& PStatus()
		{
		return (D3DSTATUS*&) pCur;
		}
	};
class DLLCLASS CD3DIM
	{
	protected:
	static CD3DIM* last;
	CD3DDevice* pCD3DDev;
	IDirect3DViewport* pView;
	static void CreateCallback(CDDSurface& surf, void*);
	static void ReleaseCallback(CDDSurface& surf, void*);
	static void DeleteCallback(CDDSurface& surf, void*);
	bool UpdateViewport();
	public:
	CDDError error;
	class DLLCLASS CIMObjects:public CDXObjects
		{
		public:
			void Add(CIMObject& o){CDXObjects::Add(o);}
			void Del(CIMObject& o){CDXObjects::Del(o);}
			void AfterDevCreate();
			void BeforeDevRelease();
		}objs;			//	pDDraw�̊J���O�ɊJ������I�u�W�F�N�g
	CIMExecuteBuffer exbuf;

	CD3DIM();
	~CD3DIM();
	void Surf(CD3DDevice& surf);
	bool Create();
	void Release();
	bool Clear(DWORD mtr);
	bool Execute(DWORD dwClip);
	bool BeginScene();
	bool EndScene();
	
	CDDraw*				PCDD(){return pCD3DDev->PCDD();}
	CD3DDevice*			PCDev(){return pCD3DDev;}
	IDirect3D*			PD3D(){return pCD3DDev->PCDD()->pD3D;}
	IDirect3DDevice*	PDev(){return pCD3DDev->pD3DDev;}
	IDirect3DViewport*	PView(){return pView;}
	static CD3DIM& GetLastCreate(){return *last;}
	};
END_NAMESPACE_HASE
#endif
