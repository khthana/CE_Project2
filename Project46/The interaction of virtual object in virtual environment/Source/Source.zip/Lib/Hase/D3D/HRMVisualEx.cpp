#include "Hase/D3D/HD3DRMEx.h"
BEGIN_NAMESPACE_HASE
CColVisual* CRMColFrame::NextVisual(FindVisualExt& fv)
	{
	while(fv.curr+1 < fv.nVisual)
		{
		fv.curr ++;
		IDirect3DRMVisual* pVis = NULL;
		CKRMERR(pVisuals->GetElement(fv.curr, &pVis));
		if (pVis) pVis->Release();
		CColVisual* pExtVis = (CColVisual*)CRMObjExt::GetExt(pVis);
		if (pExtVis) return pExtVis;
		//	ExtVis���Ȃ��ꍇ�͍��B
		IDirect3DRMMeshBuilder* pMB=NULL;
		pVis->QueryInterface(IID_IDirect3DRMMeshBuilder, (void**)&pMB);
		if (pMB)
			{
			pMB->Release();
			pExtVis = new CRMColMesh;
			}
		else pExtVis = new CRMColSphere;
		pExtVis->Set(pVis);
		return pExtVis;
		}
	return NULL;
	}
//-----------------------------------------------------------------------------
//	CRMColSphere
//
CRMColSphere::CRMColSphere(D3DVALUE r)
	{
	radius = r;
	}
//-----------------------------------------------------------------------------
//	CRMColDisc
//
CRMColDisc::CRMColDisc(CD3DVec3 n, D3DVALUE r)
	{
	normal = n;
	radius = r;
	}
//-----------------------------------------------------------------------------
//	CRMColRect
//
CRMColRect::CRMColRect(const CD3DVec2& rect)
	{
	rc = rect;
	}
//-----------------------------------------------------------------------------
//	CRMColBox
//
CRMColBox::CRMColBox(const CD3DVec3& b)
	{
	box = b;
	}
//-----------------------------------------------------------------------------
//	CRMColMesh
//
CRMColMesh::CRMColMesh()
	{
	vtx = NULL;
	nVtx = 0;
	nFace = 0;
	face = NULL;
	nFaceData = 0;
	faceData = NULL;
	}
CRMColMesh::~CRMColMesh()
	{
	ReleaseVertex();
	}
void CRMColMesh::Set(IDirect3DRMObject* p)
	{
	CRMObjExt::Set(p);
	Update();
	}
void CRMColMesh::ReleaseVertex()
	{
	delete vtx;
	vtx = NULL;
	nVtx = 0;
	nFace = 0;
	delete [] face;
	face = NULL;
	nFaceData = 0;
	delete [] faceData;
	faceData = NULL;
	}
void CRMColMesh::Update()
	{
	UpdateVertex();
	UpdateGlobe();
	}
void CRMColMesh::UpdateVertex()
	{
	ReleaseVertex();
	}
void CRMColMesh::GetVertex()
	{
	if (vtx) return;

	DWORD nNormal;
	PMeshB()->GetVertices(&nVtx, NULL, &nNormal, NULL, &nFaceData, NULL);
	vtx = new D3DVECTOR[nVtx];
	faceData = new DWORD[nFaceData];
	DWORD* pf = faceData;
	PMeshB()->GetVertices(&nVtx, vtx, &nNormal, NULL, &nFaceData, faceData);
	while(*pf)
		{
		pf += (*pf)*2 + 1;
		nFace ++;
		}
	face = new DWORD*[nFace];
	pf = faceData;
	for(int i=0; *pf; i++)
		{
		face[i] = pf;
		pf += (*pf)*2 + 1;
		}
	}
int CRMColMesh::NFace()
	{
	GetVertex();
	return nFace;
	}
int CRMColMesh::NVertex()
	{
	GetVertex();
	return nVtx;
	}
int CRMColMesh::NVertex(int fn)
	{
	GetVertex();
	return face[fn][0];
	}
int CRMColMesh::VertexID(int fn, int n)
	{
	GetVertex();
	ASSERT(0<=fn && fn < nFace);
	ASSERT(0<=n && n < face[fn][0]);
	return face[fn][1+n*2];
	}
CD3DVec3 CRMColMesh::Pos(int id)
	{
	GetVertex();
	return vtx[id];
	}
//-----------------------------------------------------------------------------
//	CRMMeshEx
//
void CRMMeshEx::UpdateMesh()
	{
	Ext().Update();
	}
bool CRMMeshEx::Load(std::string fname)
	{
	bool rtv = CRMMesh::Load(fname);
	return rtv;
	}
bool CRMMeshEx::Scale(const CD3DVec3& s)
	{
	bool rtv = CRMMesh::Scale(s);
	return rtv;
	}
bool CRMMeshEx::Pos(const CD3DVec3& p)
	{
	bool rtv = CRMMesh::Pos(p);
	return rtv;
	}
bool CRMMeshEx::Add(CRMFace& face)
	{
	bool rtv = CRMMesh::Add(face);
	return rtv;
	}
int CRMMeshEx::Add(CRMVertex& vtx)
	{
	int rtv = CRMMesh::Add(vtx);
	return rtv;
	}
bool CRMMeshEx::IsExtend()
	{
	if (!PMeshB()) return false;
	CRMColMesh* pExt = (CRMColMesh*)(CRMObjExt::GetExt(PMeshB()));
	return pExt != NULL;
	}
CColVisual& CRMMeshEx::Ext()
	{
	if (!CheckCreate()) abort();
	CColVisual* pExt = (CColVisual*)(CRMObjExt::GetExt(PMeshB()));
	if (!pExt)
		{
		pExt = new CRMColMesh;
		pExt->Set(PMeshB());
		}
	return *pExt;
	}
void CRMMeshEx::Ext(CColVisual* v)
	{
	if (!CheckCreate()) abort();
	v->Set(PVisual());
	}

END_NAMESPACE_HASE
