#define SCALER				D3DVALUE

#define Vec2				CD3DVec2
#define VEC2_BASE			D3DVECTOR2
#define VEC2_BASE_X			x
#define VEC2_BASE_Y			y

#define Matrix2				CMatrix2
#define MATRIX2_BASE		CMatrix2Base
#define MATRIX2_BASE_EX_X	ex.x
#define MATRIX2_BASE_EX_Y	ex.y
#define MATRIX2_BASE_EY_X	ey.x
#define MATRIX2_BASE_EY_Y	ey.y

#define Vec3				CD3DVec3
#define VEC3_BASE			D3DVECTOR
#define VEC3_BASE_X			x
#define VEC3_BASE_Y			y
#define VEC3_BASE_Z			z

#define Matrix3				CMatrix3
#define MATRIX3_BASE		CMatrix3Base
#define MATRIX3_BASE_EX_X	ex.x
#define MATRIX3_BASE_EX_Y	ex.y
#define MATRIX3_BASE_EX_Z	ex.z
#define MATRIX3_BASE_EY_X	ey.x
#define MATRIX3_BASE_EY_Y	ey.y
#define MATRIX3_BASE_EY_Z	ey.z
#define MATRIX3_BASE_EZ_X	ez.x
#define MATRIX3_BASE_EZ_Y	ez.y
#define MATRIX3_BASE_EZ_Z	ez.z

#define Affine				CD3DAffine
#define AFFINE_BASE			CD3DMatrix
#define AFFINE_BASE_EX_X	_11
#define AFFINE_BASE_EX_Y	_12
#define AFFINE_BASE_EX_Z	_13
#define AFFINE_BASE_EY_X	_21
#define AFFINE_BASE_EY_Y	_22
#define AFFINE_BASE_EY_Z	_23
#define AFFINE_BASE_EZ_X	_31
#define AFFINE_BASE_EZ_Y	_32
#define AFFINE_BASE_EZ_Z	_33
#define AFFINE_BASE_POS_X	_41
#define AFFINE_BASE_POS_Y	_42
#define AFFINE_BASE_POS_Z	_43
