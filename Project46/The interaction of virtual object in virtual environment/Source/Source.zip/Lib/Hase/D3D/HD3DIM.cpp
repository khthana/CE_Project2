#include "Hase/D3D/HD3DIM.h"
#include <d3d.h>
#pragma hdrstop
#define CKERR(hr)			pIM->CKIMERR(hr)
#define CKERRMSG(hr,msg)	pIM->CKIMERRMSG(hr,msg)
/*--------------*/
/*	CIMObject	*/
/*--------------*/
BEGIN_NAMESPACE_HASE
CIMObject::CIMObject():
	CDXObject()
	{
	pIM = NULL;
	handle = NULL;
	bCreated = false;
	}
CIMObject::CIMObject(CIMObject& o):
	CDXObject(o)
	{
	pIM = NULL;
	handle = NULL;
	bCreated = false;
	}
CIMObject::CIMObject(IUnknown* o):
	CDXObject(o)
	{
	pIM = NULL;
	handle = NULL;
	bCreated = false;
	}
void CIMObject::CheckIM()
	{
	if (pIM) return;
	pIM = &CD3DIM::GetLastCreate();
	}
bool CIMObject::Create()
	{
	CheckIM();
	if (bCreated) return true;
	pIM->objs.Add(*this);
	bCreated = true;
	bRelease = true;
	return true;
	}
void CIMObject::Release()
	{
	if (bCreated)
		{
		pIM->objs.Del(*this);
		bCreated = false;
		}
	RELEASE(pObject);
	}
/*--------------*/
/*	CIMMatrix	*/
/*--------------*/
CIMMatrix::CIMMatrix()
	{
	}
CIMMatrix::CIMMatrix(REAL front, REAL back, CD3DVec2 center, CD3DVec2 size)
	{
	REAL tmp = back/(back-front);
	REAL invN = 1/front;
	mat._11 = 1/size.x;			mat._12 = 0;				mat._13 = 0;		mat._14=0;
	mat._21 = 0;				mat._22 = 1/size.y;			mat._23 = 0;		mat._24=0;
	mat._31 = center.x*invN;	mat._32 = center.y*invN;	mat._33 = tmp*invN;	mat._34 = invN;
	mat._41 = 0;				mat._42 = 0;				mat._43 = -tmp;		mat._44 = 0;
	}
CIMMatrix::CIMMatrix(const CD3DAffine& af)
	{
	mat = af;
	}
CIMMatrix::CIMMatrix(const CIMMatrix& m)
	{
	mat = m.mat;
	}
CIMMatrix::~CIMMatrix()
	{
	Release();
	}
bool CIMMatrix::Create()
	{
	CIMObject::Create();
	if (handle) return true;
	if (!pIM->PDev()) pIM->PCDev()->Create();
	AfterDevCreate();
	return handle!=0;
	}
void CIMMatrix::Release()
	{
	CIMObject::Release();
	if (!handle) return;
	CKERR(pIM->PDev()->DeleteMatrix(handle));
	handle = NULL;
	}
CIMMatrix::operator CD3DAffine()
	{
	return mat;
	}
CIMMatrix CIMMatrix::operator = (const CD3DAffine& af)
	{
	mat = af;
	if (handle) Set();
	return *this;
	}
CIMMatrix CIMMatrix::operator = (const CIMMatrix& m)
	{
	mat = m.mat;
	if (handle) Set();
	return *this;
	}
void CIMMatrix::AfterDevCreate()
	{
	CheckIM();
	if (CKERR(pIM->PDev()->CreateMatrix(&handle))) Release();
	if (CKERR(pIM->PDev()->SetMatrix(handle, &mat))) Release();
	}
bool CIMMatrix::Get()
	{
	if (!handle) return false;
	return !CKERR(pIM->PDev()->GetMatrix(handle, &mat));
	}
bool CIMMatrix::Set()
	{
	if (!handle)
		{
		return Create();
		}
	return !CKERR(pIM->PDev()->SetMatrix(handle, &mat));
	}
/*--------------*/
/*	CIMLight	*/
/*--------------*/
CIMLight::CIMLight(const CIMLight& l):
	CIMObject(l)
	{
	*(D3DLIGHT*)this = *(D3DLIGHT*)&l;
	}
CIMLight::CIMLight(IDirect3DLight* l):
	CIMObject(l)
	{
	memset((D3DLIGHT*)this, 0, sizeof(D3DLIGHT));
	dwSize = sizeof(D3DLIGHT);
	if (PLight()) Get();
	}
CIMLight::~CIMLight()
	{
	Release();
	}
bool CIMLight::Create()
	{
	CIMObject::Create();
	if (PLight()) return true;
	CheckIM();
	if (CKERR(pIM->PD3D()->CreateLight(&PLight(), NULL)) ) return false;
	return true;
	}
void CIMLight::Release()
	{
	CIMObject::Release();
	if (!PLight()) return;
	}
void CIMLight::AfterDevCreate()
	{
	Set();
	}
bool CIMLight::Set()
	{
	Create();
	return !CKERR(PLight()->SetLight(this));
	}
bool CIMLight::Get()
	{
	Create();
	return !CKERR(PLight()->GetLight(this));
	}
/*--------------*/
/*	CIMMaterial	*/
/*--------------*/
CIMMaterial::CIMMaterial(const CIMMaterial& m):
	CIMObject(m)
	{
	*(D3DMATERIAL*)this = *(D3DMATERIAL*)&m;
	}
CIMMaterial::CIMMaterial(IDirect3DMaterial* m):
	CIMObject(m)
	{
	memset((D3DMATERIAL*)this, 0, sizeof(D3DMATERIAL));
	dwSize = sizeof(D3DMATERIAL);
	if (PMaterial()) Get();
	}
CIMMaterial::CIMMaterial(D3DCOLORVALUE di, D3DCOLORVALUE am, D3DCOLORVALUE sp, D3DCOLORVALUE em, REAL pw)
	{
	memset((D3DMATERIAL*)this, 0, sizeof(D3DMATERIAL));
	dwSize = sizeof(D3DMATERIAL);
	Set(di, am, sp, em, pw);
	}
CIMMaterial::CIMMaterial(D3DCOLORVALUE c, REAL pw)
	{
	memset((D3DMATERIAL*)this, 0, sizeof(D3DMATERIAL));
	dwSize = sizeof(D3DMATERIAL);
	Set(c, pw);
	}
CIMMaterial::~CIMMaterial()
	{
	Release();
	}
bool CIMMaterial::Create()
	{
	CIMObject::Create();
	if (PMaterial()) return true;
	CheckIM();
	if ( !PMaterial() && CKERR(pIM->PD3D()->CreateMaterial(&PMaterial(), NULL)) ) return false;
	return true;
	}
void CIMMaterial::Release()
	{
	CIMObject::Release();
	if (!PMaterial()) return;
	RELEASE(PMaterial());
	}
void CIMMaterial::AfterDevCreate()
	{
	CheckIM();
	CKERR( PMaterial()->GetHandle(pIM->PCDev()->pD3DDev, &handle) );
	}
void CIMMaterial::Set(D3DCOLORVALUE c, REAL pw)
	{
	D3DCOLORVALUE dcvZero = {D3DVAL(0), D3DVAL(0), D3DVAL(0), D3DVAL(0)};
	Set(c, c, c, dcvZero, pw);
	}
void CIMMaterial::Set(D3DCOLORVALUE di, D3DCOLORVALUE am, D3DCOLORVALUE sp, D3DCOLORVALUE em, REAL pw)
	{
	Create();
	diffuse = di;
	ambient = am;
	specular = sp;
	emissive = em;
	power = pw;
	Set();
	}
bool CIMMaterial::Set()
	{
	Create();
	return !CKERR(PMaterial()->SetMaterial(this));
	}
bool CIMMaterial::Get()
	{
	return !CKERR(PMaterial()->GetMaterial(this));
	}

/*----------------------*/
/*	CIMExecuteBuffer	*/
/*----------------------*/
CIMExecuteBuffer::CIMExecuteBuffer():
	CIMObject()
	{
	bLock = false;
	pCur = NULL;
	memset(&desc, 0, sizeof(desc));
	desc.dwSize = sizeof(desc);
	memset(&data, 0, sizeof(data));
	data.dwSize = sizeof(data);
	}
bool CIMExecuteBuffer::Create()
	{
	CIMObject::Create();
	if (PBuf()) return true;
	CheckIM();
	if (!pIM->PCDev()) return false;
	if (!pIM->PCDev()->Restore()) return false;
	if (PBuf()) return true;
	descOld = desc;
	if (CKERR(pIM->PDev()->CreateExecuteBuffer(&desc, &PBuf(), NULL))) return false;
	return true;
	}
void CIMExecuteBuffer::AfterDevCreate()
	{
	Create();
	}
void CIMExecuteBuffer::Release()
	{
	CIMObject::Release();
	BeforeDevRelease();
	}
void CIMExecuteBuffer::BeforeDevRelease()
	{
	if (!PBuf()) return;
	Unlock();
	RELEASE(PBuf());
	desc = descOld;
	}
DWORD CIMExecuteBuffer::Size()
	{
	return desc.dwBufferSize;
	}
void CIMExecuteBuffer::Size(size_t sz)
	{
	desc.dwFlags |= D3DDEB_BUFSIZE;
	desc.dwBufferSize = sz;
	}
DWORD CIMExecuteBuffer::Caps()
	{
	return desc.dwCaps;
	}
void CIMExecuteBuffer::Caps(DWORD c)
	{
	desc.dwFlags |= D3DDEB_CAPS;
	desc.dwCaps = c;
	}
bool CIMExecuteBuffer::Lock()
	{
	if (bLock) return true;
	CDD_ENTER_CRITICAL;	
	if (!Create())
		{
		CDD_LEAVE_CRITICAL;	
		return false;
		}
	if (CKERR(PBuf()->Lock(&desc)))
		{
		CDD_LEAVE_CRITICAL;	
		return false;
		}
	bLock = true;
	pCur = (BYTE*)desc.lpData;
    data.dwVertexCount = 0;
    data.dwInstructionOffset = 0;
    data.dwInstructionLength = 0;
	return true;
	}
void CIMExecuteBuffer::Unlock()
	{
	if (!bLock) return;
	CKERR(PBuf()->Unlock());
	bLock = false;
	pCur = NULL;
	CKERR(PBuf()->SetExecuteData(&data));
	CDD_LEAVE_CRITICAL;
	}
void CIMExecuteBuffer::EndVertex()
	{
    data.dwVertexCount = PVertex() - (D3DVERTEX*)desc.lpData;
    data.dwInstructionOffset = pCur - (BYTE*)desc.lpData;
	}
void CIMExecuteBuffer::EndInst()
	{
    data.dwInstructionLength = (pCur - (BYTE*)desc.lpData) - data.dwInstructionOffset;
	}
/*----------------------*/
/*	CD3DIM::CIMObjects	*/
/*----------------------*/
void CD3DIM::CIMObjects::AfterDevCreate()
	{
	if (End())
		for(iterator it = End()-1; it>=Bgn(); it--)
			((CIMObject*)(*it))->AfterDevCreate();
	}
void CD3DIM::CIMObjects::BeforeDevRelease()
	{
	if (End())
		for(iterator it = End()-1; it>=Bgn(); it--)
			((CIMObject*)(*it))->BeforeDevRelease();
	}
/*------------------*/
/*		CD3DIM		*/
/*------------------*/
DLLCLASS CD3DIM* CD3DIM::last;
CD3DIM::CD3DIM()
	{
	pView = NULL;
	pCD3DDev = NULL;
	}
CD3DIM::~CD3DIM()
	{
	Release();
	}
void CD3DIM::Surf(CD3DDevice& dev)
	{
	if (PView())
		{
		if (pCD3DDev->pDDS) ReleaseCallback(*pCD3DDev, this);
		DeleteCallback(*pCD3DDev, this);
		pCD3DDev = &dev;
		UpdateViewport();
		pCD3DDev->createCallbacks.Add(CreateCallback, this);
		pCD3DDev->createCallbacks.Add(ReleaseCallback, this);
		pCD3DDev->deleteCallbacks.Add(DeleteCallback, this);
		pCD3DDev->Create();
		}
	else
		{
		pCD3DDev = &dev;
		}
	}
bool CD3DIM::Create()
	{
	last = this;
	if (pView) return true;
	CDD_ENTER_CRITICAL;
	if (!pCD3DDev)
		{
		IMERRMSG(2, "Call Set(CD3DDevice&) before calling Create().");
		goto leave;
		}
	if (!pCD3DDev->Create()) goto leave;
	if (!exbuf.Create()) goto leave;
	if (CKIMERR( pCD3DDev->PCDD()->pD3D->CreateViewport(&pView, NULL) )) goto leave;
	UpdateViewport();
	pCD3DDev->createCallbacks.Add(CreateCallback, this);
	pCD3DDev->releaseCallbacks.Add(ReleaseCallback, this);
	pCD3DDev->deleteCallbacks.Add(DeleteCallback, this);
	CDD_LEAVE_CRITICAL;
	return true;
leave:
	RELEASE(pCD3DDev);
	exbuf.Release();
	RELEASE(pView);
	CDD_LEAVE_CRITICAL;
	return false;
	}
void CD3DIM::Release()
	{
	if (!pView) return;
	CDD_ENTER_CRITICAL;
	pCD3DDev->createCallbacks.Del(CreateCallback, this);
	pCD3DDev->releaseCallbacks.Del(ReleaseCallback, this);
	pCD3DDev->deleteCallbacks.Del(DeleteCallback, this);
	objs.Release();
	RELEASE(pView);
	CDD_LEAVE_CRITICAL;
	}
bool CD3DIM::Clear(DWORD mtr)
	{
	if (!PView() && !Create()) return false;
	if (!PCDev()) return false;
	PView()->SetBackground(mtr);
	D3DRECT rc;
	rc.x1 = 0;
	rc.y1 = 0;
	rc.x2 = PCDev()->Size().cx;
	rc.y2 = PCDev()->Size().cy;
	if (PView()->Clear(1, &rc, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER) != D3D_OK)
		{
		if (!PCDev()->Restore()) return false;
		CKIMERR(PView()->Clear(1, &rc, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER));
		}
	return true;
	}
bool CD3DIM::Execute(DWORD dwClip)
	{
	if (!PView() && !Create()) return false;
	if (!PCDev()) return false;
	if (PDev()->Execute(exbuf, pView, dwClip) != D3D_OK)
		{
		if (!PCDev()->Restore()) return false;
		return !CKIMERR(PDev()->Execute(exbuf, pView, dwClip));
		}
	return true;
	}
bool CD3DIM::BeginScene()
	{
	if (!PCDev()->Create()) return false;
	return !CKIMERR(PDev()->BeginScene());
	}
bool CD3DIM::EndScene()
	{
	if (!PCDev()->Create()) return false;
	return !CKIMERR(PDev()->EndScene());
	}
void CD3DIM::CreateCallback(CDDSurface& surf, void* pContext)
	{
	CD3DIM* pIM = (CD3DIM*)pContext;
	if (!pIM->UpdateViewport()) pIM->Release();
	pIM->objs.AfterDevCreate();
	}
void CD3DIM::ReleaseCallback(CDDSurface& surf, void* pContext)
	{
	CD3DIM* pIM = (CD3DIM*)pContext;
	pIM->objs.BeforeDevRelease();
	}
void CD3DIM::DeleteCallback(CDDSurface& surf, void* pContext)
	{
	CD3DIM* pIM = (CD3DIM*)pContext;
	pIM->Release();
	}
bool CD3DIM::UpdateViewport()
	{
	if (CKIMERR( pCD3DDev->pD3DDev->AddViewport(pView) )) return false;
	D3DVIEWPORT d3dViewport;
    ZeroMemory(&d3dViewport, sizeof(d3dViewport));
    d3dViewport.dwSize   = sizeof(d3dViewport);
    d3dViewport.dwX      = 0UL;
    d3dViewport.dwY      = 0UL;
    d3dViewport.dwWidth  = PCDev()->Size().cx;
    d3dViewport.dwHeight = PCDev()->Size().cy;
    d3dViewport.dvScaleX = D3DVAL(d3dViewport.dwWidth);
    d3dViewport.dvScaleY = D3DVAL(d3dViewport.dwHeight);
    d3dViewport.dvMaxX   = D3DVAL(1.0);
    d3dViewport.dvMaxY   = D3DVAL(1.0);
    if (CKIMERR(PView()->SetViewport(&d3dViewport))) return false;
	return true;
	}
END_NAMESPACE_HASE
