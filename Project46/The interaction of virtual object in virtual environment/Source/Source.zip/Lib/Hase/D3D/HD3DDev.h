#ifndef HASE_D3D_HD3DDev_H
#define HASE_D3D_HD3DDev_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"
#include "Hase/DDraw/HDDraw.h"
#include "Hase/DDraw/HDDFSurf.h"
#include <d3d.h>

BEGIN_NAMESPACE_HASE
inline D3DVECTOR D3DVec(REAL x=0, REAL y=0, REAL z=0)
	{
	D3DVECTOR v;
	v.x = x;
	v.y = y;
	v.z = z;
	return v;
	}
//----------------------------------------------------------------------------
//	CD3DDevice
//
class CD3DDevice;
class DLLCLASS CD3DDriver
	{
	public:
	GUID guid;
	std::string about; 
	std::string name; 
	D3DDEVICEDESC desc;
	bool bHAL;
	DWORD zBufferDepth;

	bool CheckRendDepth(int bitPerPixel);
	bool operator < (const CD3DDriver) const{return false;}
	bool operator == (const CD3DDriver) const{return true;}
	friend HRESULT PASCAL EnumDevicesCallback(GUID* pGuid, char* d, char* n, D3DDEVICEDESC* pHAL, D3DDEVICEDESC* pHEL, void* pContext);
	friend CD3DDevice;
	};
//----------------------------------------------------------------------------
//	CD3DDrivers
//
class DLLCLASS CD3DDrivers: public Array<CD3DDriver>
	{
	protected:
	int cur;
	bool Select(int rendDepth, bool bHALOK=true);
	friend CD3DDevice;

	public:
	int prefer;
	CD3DDrivers();
    int Cur(){return cur;}
	CD3DDriver& CurDriver();
	void Set(int id);
	};
//----------------------------------------------------------------------------
//	CD3DDevice
//
class CD3DRM;
class CD3DIM;
class DLLCLASS CD3DDevice:public CFlipSurface
	{
	public:
	CD3DDrivers drivers;
	IDirect3DDevice* pD3DDev;
#if DIRECTDRAW_VERSION >= 0x0500
	IDirect3DDevice2* pD3DDev2;
#endif
	CD3DDevice();
	~CD3DDevice();
	virtual void DDraw(CDDraw& dd);
	virtual bool EnumDrivers();
	bool Create(){return Create(true);}
	void Release(){Release(true);}
	virtual bool Restore();
	protected:
	virtual bool Create(bool bCallCallback, int nBackBuffer=1);
	virtual void Release(bool bCallCallback);
	class CZSurface:public CDDSurface
		{
		bool Create(DWORD depth, bool bHardWare, bool bCallCallback=true);
		friend CD3DDevice;
		}zBuffer;
	friend CD3DRM;
	friend CD3DIM;
	};
struct DLLCLASS CD3DDevInterface:public CDDSInterface
	{
	IDirect3DDevice* pD3DDev;
	CD3DDevInterface();
	CD3DDevInterface(const CD3DDevInterface&);
	~CD3DDevInterface();
	};
//----------------------------------------------------------------------------
//	CAutoFlipD3DDevice
//
//	�t���ዾ�ɂ�闧�̎��̂��߂�D3DDevice�B
//	�����������荞�݂��g���Ȃ����o�[�W�����ł͌��ʂ��Ȃ��B
class DLLCLASS CAutoFlipD3DDevice:public CD3DDevice, public CAutoFlip
	{
	friend CD3DRM;
	protected:
	Array<CD3DDevInterface> backs;			//	�o�b�N�o�b�t�@
	static HRESULT WINAPI EnumSurfacesCallback(IDirectDrawSurface* pDDS, DDSURFACEDESC* pDesc, void* pContext);
	virtual bool CreatePurposeTable();
	virtual bool Create(bool bCallCallback);
	virtual void Release(bool bCallback);
	virtual bool Restore();
	virtual CDDSInterface& BackBuffer(int p, int t);
	virtual void CurBuffer(CDDSInterface& nb);
	virtual CDDSInterface& FrontBuffer();
	virtual CDDSurface& Surf(){return *this;}
	
	public:
	CAutoFlipD3DDevice();
	~CAutoFlipD3DDevice();
	bool Create(){return Create(true);}
	void Release(){Release(true);}
	//	�`��o�b�t�@�ƕ\���o�b�t�@�̓���ւ�
	virtual bool Flip();
	//	n�Ԗڂ̕`��o�b�t�@��\��
	virtual bool Flip(int n);
	};
END_NAMESPACE_HASE
#endif
