#include "Hase/D3D/HD3DRMEx.h"
BEGIN_NAMESPACE_HASE
//-----------------------------------------------------------------------------
//	CRMColFrame
//
CRMColFrame::CRMColFrame(IDirect3DRMFrame* fr)
	{
	Set(fr);
	pStops = NULL;
	pVisuals = NULL;
	}
CRMColFrame::~CRMColFrame()
	{
	Cleanup();
	delete pStops;
	pStops = NULL;
	RELEASE(pVisuals);
	}
void CRMColFrame::UpdateHelper(CRMColFrame* p)
	{
	delete p->pStops;
	p->pStops = NULL;
	RELEASE(p->pVisuals);

//	p->MoveMoves();
//	FOREACH_VISUALEXT(*p) pVisual->Update();
	FOREACH_STOPEXT(*p) UpdateHelper(pStop);
	FOREACH_MOVEEXT(*p) UpdateHelper(pMove);
	}
void CRMColFrame::Update()
	{
	UpdateHelper(this);
	CColFrame::Update();
	}
CD3DAffine CRMColFrame::AfParentImp()
	{
	if (!PFrame()) return CD3DAffine();
	return CRMFrame::FromI(PFrame()).AfParent();
	}
void CRMColFrame::AfParentImp(const CD3DAffine& af)
	{
	CRMFrame::FromI(PFrame()).AfParent(af);
	}
CColFrame* CRMColFrame::Parent()	//	�e
	{
	if (!PFrame()) return NULL;
	CRMFrameEx frParent = CRMFrameEx::FromI(PFrame()).Parent();
	if (!frParent) return NULL;
	return &(frParent.Ext());
	}
void CRMColFrame::InitStop(FindFrameExt& ff)
	{
	ff.curr = 0;
	if (!pStops)
		{
		pStops = new CRMColFrames;
		if (PFrame())
			{
			CRMFrameEx fr=CRMFrameEx::FromI(PFrame());
			int nFrame = fr.NChild();
			for(int i=0; i<nFrame; i++)
				{
				CRMFrameEx frChild = CRMFrameEx::FromI(PFrame()).Child(i);
				if (!frChild.Ext().IsMove()) pStops->Add(&frChild.Ext());
				}
			}
		pStops->Add(NULL);
		}
	}
CColFrame* CRMColFrame::NextStop(FindFrameExt& ff)
	{
	return (*pStops)[ff.curr++];
	}
void CRMColFrame::InitMove(FindFrameExt& ff)
	{
	ff.curr = -1;
	ff.nFrame = CRMFrameEx::FromI(PFrame()).NChild();
	}
CColFrame* CRMColFrame::NextMove(FindFrameExt& ff)
	{
	while(ff.curr+1 < ff.nFrame)
		{
		ff.curr ++;
		CRMFrameEx fr = CRMFrameEx::FromI(PFrame()).Child(ff.curr);
		if (fr.Ext().IsMove()) return &fr.Ext();
		}
	return NULL;
	}
void CRMColFrame::InitVisual(FindVisualExt& fv)
	{
	if (!pVisuals && PFrame()) CKRMERR(PFrame()->GetVisuals(&pVisuals));
	if (pVisuals) fv.nVisual = pVisuals->GetSize();
	else fv.nVisual = 0;
	fv.curr = -1;
	}
void CRMColFrame::MoveThis()
	{
	if (IsMove()) return;
	CColFrame::MoveThis();
	if (IsMove() && Parent() && ((CRMColFrame*)Parent())->pStops) ((CRMColFrame*)Parent())->pStops->FindDel(this);
	}
void CRMColFrame::StopThis()
	{
	if (!IsMove()) return;
	CColFrame::StopThis();
	if (!IsMove() && Parent() && ((CRMColFrame*)Parent())->pStops) ((CRMColFrame*)Parent())->pStops->Add(this);
	}
//-----------------------------------------------------------------------------
//	CRMFrameEx
//
bool CRMFrameEx::IsExtend() const
	{
	if (!PFrame()) return false;
	CRMColFrame* pExt = (CRMColFrame*)(CRMObjExt::GetExt(PFrame()));
	return pExt != NULL;
	}
CRMFrameEx& CRMFrameEx::FromI(IDirect3DRMFrame* pFr)
	{
	static CRMFrameEx fr;
	delete fr.name;
	fr.name = NULL;
	fr.pObject = pFr;
	return fr;
	}
void CRMFrameEx::Add(const CForce& f)
	{
	Ext().AddForce(f);
	}
void CRMFrameEx::Add(CRMFrameEx& fr)
	{
	fr.Parent(*this);
	}
void CRMFrameEx::Del(CRMFrameEx& fr)
	{
	fr.Ext().StopThis();
	CRMFrame::Del(fr);
	Ext().Update();
	}
void CRMFrameEx::DelThis()
	{
	if (Parent()) Parent().Del(*this);
	}
void CRMFrameEx::Clear()
	{
	Create();
	int i;
	for(i=NChild()-1; i>=0; i--) Del((IDirect3DRMFrame*)Child(i));
	for(i=NVisual()-1; i>=0; i--) Del(Visual(i));
	for(i=NLight()-1; i>=0; i--) Del((IDirect3DRMLight*)Light(i));
	}
void CRMFrameEx::Add(CRMVisual& vis)
	{
	CRMFrame::Add(vis);
	Ext().Update();
	}
void CRMFrameEx::Del(const CRMVisual& vis)
	{
	CRMFrame::Del(vis);
	Ext().Update();
	}
bool CRMFrameEx::Load(const char* fname)
	{
	if (CRMFrame::Load(fname))
		{
		ExtAll();
		return true;
		}
	return false;
	}
void CRMFrameEx::Ori(const CD3DVec3& ez, const CD3DVec3& ey, const CRMFrameEx& frRef)
	{
	CRMFrame::Ori(ez, ey, frRef);
	Ext().UpdateMove();
	}
void CRMFrameEx::Pos(const CD3DVec3& v, const CRMFrameEx& frRef)
	{
	CRMFrame::Pos(v, frRef);
	Ext().UpdateMove();
	}
CRMFrameEx CRMFrameEx::Child(int id)
	{
	IDirect3DRMFrameArray* fa=NULL;
	if (CKRMERR(PFrame()->GetChildren(&fa))) return CRMFrameEx();
	IDirect3DRMFrame* f=NULL;
	if (!CKRMERR(fa->GetElement(id, &f)) && f)
		{
		int ref = f->Release();
		TRACEALL("CRMFrameEx::Parent ref = %d\n", ref);
		}
	RELEASE(fa);
	return f;
	}
void CRMFrameEx::Parent(IDirect3DRMFrame* fr)
	{
	bool bMoveOld = Ext().IsMove();
	StopThis();
	CRMFrameEx oldParent = Parent();
	CRMFrame::Parent(fr);
	if (bMoveOld) MoveThis();
	if (oldParent) oldParent.Ext().Update();
	Parent().Ext().Update();
	}
CRMColFrame& CRMFrameEx::Ext()
	{
	Create();
	CRMColFrame* pExt = (CRMColFrame*)(CRMObjExt::GetExt(PFrame()));
	if (!pExt) pExt = new CRMColFrame(PFrame());
	return *pExt;
	}
static void FrameExtAll(CRMFrameEx& f)
	{
	//	�q�t���[�����g��
	for(int i=0; i<f.NChild(); i++) FrameExtAll(f.Child(i));
	//	�r�W���A�����g��
	FindVisualExt fv;
	f.Ext().InitVisual(fv);
	CColVisual* v;
	while(1)
		{
		v = f.Ext().NextVisual(fv);
		if (!v) break;
		}
	}
void CRMFrameEx::ExtAll()
	{
	FrameExtAll(*this);
	//	�t���[���g�����X�V
	Ext().Update();
	}
END_NAMESPACE_HASE
