#define SCALER			D3DVALUE
#define Vec2			CD3DVec2
#define Vec3			CD3DVec3
#define Affine			CD3DAffine
#define Matrix3			CMatrix3
#define FindFrame		FindFrameExt
#define FindVisual		FindVisualExt

#define CFrameBase		CRMObjExt
#define CFrame			CColFrame
#define CFrames			CColFrames
#define CVisualBase		CRMObjExt
#define CVisual			CColVisual
#define CPlane			CColPlane
#define CSphere			CColSphere
#define CDisc			CColDisc
#define CRect			CColRect
#define CBox			CColBox
#define CMesh			CColMesh

#define CIsect		CRMIsect
#define CIsects		CRMIsects
