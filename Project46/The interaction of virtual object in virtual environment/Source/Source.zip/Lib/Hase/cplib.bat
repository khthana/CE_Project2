copy debug\haselib.lib .
copy debug\haselib.dll .
copy haselib.dll samples\d3dsdiex\haselib.dll
