d:
cd d:\home\hase\c\lib\hase
if "%1"=="" lha32 x f:\haselib.lzh
if not "%1"=="" lha32 x %1\haselib.lzh
