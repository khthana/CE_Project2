#ifndef HASE_DDRAW_CCKDXERROR_H
#define HASE_DDRAW_CCKDXERROR_H
#include "Hase/Misc/Inc.h"

#define DXERRMSG(n, msg) \
	Message(n, (msg), __FILE__, __LINE__)
#define CKDXERR(err)	\
	Check((err), "", __FILE__, __LINE__)
#define CKDXERRMSG(err, msg)	\
	Check((err), (msg), __FILE__, __LINE__)

#ifndef TRACE
#define TRACE CDXError::DebugPrintF
#endif

BEGIN_NAMESPACE_HASE
class DLLCLASS CDXError
	{
	protected:
	DWORD num;
	char* err;
	char* desc;
	std::string msg;
	std::string fname;
	int line;
	public:
	CDXError();
	DWORD Num(){return num;}
	const char* Err(){return err;}
	const char* Desc(){return desc;}
	virtual bool Check(DWORD n, const char* msg, const char* fn=NULL, int ln=0);
	virtual void Message(DWORD n, const char* msg, const char* fn=NULL, int ln=0);
    static void DebugPrintF(const char* f,...);
	};
END_NAMESPACE_HASE

#endif