#include "Hase/DX/HDXObj.h"
#pragma hdrstop
BEGIN_NAMESPACE_HASE
//-----------------------------------------------------------------------------
//	CDXObject
//
CDXObject::CDXObject(const CDXObject& o)
	{
	bRelease = false;
	pObject = o.pObject;
	if (pObject)
		{
		pObject->AddRef();
		bRelease = true;
		}
	}
CDXObject::CDXObject(IUnknown* pObj)
	{
	bRelease = false;
	pObject = pObj;
	if (pObject)
		{
		pObject->AddRef();
		bRelease = true;
		}
	}
CDXObject::~CDXObject()
	{
	Release();
	}
void CDXObject::Release()
	{
	if (pObject && bRelease)
		{
		int ref = pObject->Release();
		TRACEALL("CDXObject::Release ref = %d\n", ref);
		pObject = NULL;
		bRelease = false;
		}
	}
CDXObject CDXObject::operator = (CDXObject& o)
	{
	Release();
	pObject = o.pObject;
	if (pObject) 
		{
		pObject->AddRef();
		bRelease = true;
		}
	return *this;
	}
const IID& CDXObject::InterfaceID() const
	{
	return IID_IUnknown;
	}
const IID& CDXObject::ClassID() const
	{
	static GUID guidNULL;
	return guidNULL;
	}

//-----------------------------------------------------------------------------
//	CDXObjects
//
CDXObjects::CDXObjects()
	{
	}
CDXObjects::~CDXObjects()
	{
	}
void CDXObjects::Add(CDXObject& o)
	{
	if (End())
		for(It it = End()-1; it>=Bgn(); it--)
			if (*it == &o) Del(it);
	Add(&o);
	}
void CDXObjects::Del(CDXObject& o)
	{
	if (End())
		for(It it = End()-1; it>=Bgn(); it--)
			if (*it == &o) Del(it);
	}
void CDXObjects::Release()
	{
	if (End())
		for(It it = End()-1; it>=Bgn(); it--)
			(*it)->Release();
	}
END_NAMESPACE_HASE
