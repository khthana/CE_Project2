#ifndef HASE_MISC_HSTRING_H
#define HASE_MISC_HSTRING_H

BEGIN_NAMESPACE_HASE

#include <Hase/Misc/Inc.h>
inline bool operator == (const std::string& s1, const std::string& s2)
	{
	return s1.compare(s2) == 0;
	}
inline std::istream& operator >> (std::istream& istr, std::string& s)
	{
	char buf[1024];
	istr >> buf;
	s = buf;
	return istr;
	}

END_NAMESPACE_HASE

#endif