#ifndef HASE_DEFS_H
#define HASE_DEFS_H

#if defined _MSC_VER && defined _CPPUNWIND
 #define SUPPORT_EXCEPTION
#endif

// export all classes
#ifdef CREATE_DLL
 #ifdef _MSC_VER
  #define DLLCLASS __declspec( dllexport )
  #pragma warning (disable: 4275 4251)
 #endif
#elif defined STATIC_LINK
 #define DLLCLASS
#else
 #ifdef _MSC_VER
  #define DLLCLASS __declspec( dllimport )
 #elif __BORLANDC__ >= 0x0530
  #define DLLCLASS PACKAGE
 #else
  #define DLLCLASS
 #endif
#endif
#ifdef _MSC_VER
 //	thread local
 #define THREAD __declspec( thread )
#pragma warning (disable: 4786)
#endif

// use/don't use MFC
#if (!defined NOMFC) && (!defined USEMFC)
 #if (!defined _MSC_VER) && (!defined _MFC_VER)
  #define NOMFC
 #else
  #define USEMFC
 #endif
#endif

// namespace for Hase
#define NAMESPACE_HASE Hase
#define NAMESPACE_HASE__ NAMESPACE_HASE::
#define BEGIN_NAMESPACE_HASE	namespace NAMESPACE_HASE{
#define END_NAMESPACE_HASE		}
#define USING_NAMESPACE_HASE	using namespace NAMESPACE_HASE

// std namespace for stream
#define USE_NEW_STREAM
#if ((defined USE_NEW_STREAM) && (defined _MSC_VER)) \
    || (__BORLANDC__ >= 0x0540)
 #define STREAM_STD__ std::
#else
 #define STREAM_STD__
#endif

#endif // HASE_DEFS_H
