#ifndef MMTIMER_H
#define MMTIMER_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"
BEGIN_NAMESPACE_HASE

class DLLCLASS CMMTimer
	{
	static int count;
	int tick;
	public:
	typedef void MMTimerFunc(void* arg);

	protected:
	static UINT resolution;
	UINT interval;
	MMTimerFunc* func;
	UINT timerID;
	void* arg;
	volatile bool bCreated;
	volatile bool bThread;
    volatile bool bRun;
	HANDLE hThread;
	static void CALLBACK TimerCallback(UINT uID, UINT, DWORD dwUser, DWORD, DWORD);
	static DWORD WINAPI ThreadCallback(void* arg);
	void BeginPeriod();
	void EndPeriod();

	public:
	volatile int heavy;

	CMMTimer();
	~CMMTimer();
	UINT Resolution();
	void Resolution(UINT res);
	UINT Interval();
	void Interval(UINT i);
	void Set(MMTimerFunc* f, void* arg);
	bool Create();
	bool Thread();
	bool IsCreated(){return bCreated;}
	bool IsThread(){return bThread;}
	void Release();
	};

END_NAMESPACE_HASE
#endif
