#ifndef HASE_MISC_HANDLE_H
#define HASE_MISC_HANDLE_H
#include <Hase/Misc/Inc.h>
BEGIN_NAMESPACE_HASE
template <class T>
class Handle:protected PArray<T>
	{
	protected:
	public:
	int Size() const
		{
		return PArray<T>::Size();
		}
	Handle()
		{
		PArray<T>::Add(NULL);
		}
	int Add(T* t)
		{
		for(It it=Bgn()+1; it<End(); it++)
			{
			if (*it == NULL)
				{
				*it = t;
				return it-Bgn();
				}
			}
		PArray<T>::Add(t);
		return Size()-1;
		}
	void Del(int i)
		{
		ASSERT(i<Size());
		if (Bgn()[i])
			{
			delete Bgn()[i];
			Bgn()[i] = NULL;
			}
		if (i==Size()-1)
			{
			for(It it=End()-1; it>Bgn(); it--)
				{
				if (!*it) PArray<T>::Del(it);
				else break;
				}
			}
		}
	void Clear()
		{
		PArray<T>::Clear();
		PArray<T>::Add(NULL);
		}
	T* operator[] (int i)
		{
		ASSERT(i>0);
		return Bgn()[i];
		}
	};
END_NAMESPACE_HASE
#endif
