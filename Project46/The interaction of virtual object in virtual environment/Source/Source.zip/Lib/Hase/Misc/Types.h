#ifndef HASE_TYPES_H
#define HASE_TYPES_H

#include "Hase/Misc/Inc.h"

#ifdef _MSC_VER
 #pragma warning (disable: 4786)
#endif

#ifdef _MIN
 #undef min
 #define min(x,y) _MIN(x,y)
#endif
#ifdef _MAX
 #undef max
 #define max(x,y) _MAX(x,y)
#endif

BEGIN_NAMESPACE_HASE
//	Array: array of value. Array inherits std::vector, which is one of the stl's container class.
//	Push f1 key on the word `Cont' or `�R���e�i' to see the help.
template <class T>
#define AVOID_CLASSVIEW_BUG_STD_VECTOR_T std::vector<T>
class Array : AVOID_CLASSVIEW_BUG_STD_VECTOR_T
#undef AVOID_CLASSVIEW_BUG_STD_VECTOR_T
	{
	public:
    typedef std::vector<T>::iterator iterator;
    typedef std::vector<T>::const_iterator const_iterator;
    typedef std::vector<T>::size_type size_type;
	typedef iterator It;			//	can use like a pointer. (T* pointer)
	typedef const_iterator CIt;		//	can use like a pointer to a constant. (const T* pointer)
	typedef T Type;
	virtual ~Array(){}
	virtual It Find(const T& key)	
		{
		It i;
		for(i=begin(); i!=end(); i++) if (*i== key) return i;
		return NULL;
		}
	It Bgn() {return begin();}
	CIt Bgn() const {return begin();}
	It End() {return end();}
	CIt End() const {return end();}
	virtual void Add(It b, It e)
		{
		insert(end(), b, e);
		}
	virtual void Add(Array<T> a)
		{
		Add(a.Bgn(), a.End());
		}
	virtual void Add(const T& x)
		{
#ifdef __BORLANDC__
		It b=(It)&x;
		It e=b+1;
		Add(b, e);
#else
		push_back(x);
#endif
		}
	virtual void Del(It it)
		{
		erase(it);
		}
	virtual void Del(It first, It last)
		{
		erase(first, last);
		}
	virtual bool FindDel(const T& t)
		{
		It it = Find(t);
		if (it)
			{
			Del(it);
			return true;
			}
		return false;
		}
	int Size() const
		{
		return size();
		}
	virtual void Size(int sz)
		{
		resize(sz);
		}
	virtual void Clear()
		{
		Del(Bgn(), End());
		}
	virtual void Marge(Array<T>& a)
		{
		Add(a);
		a.Clear();
		}
	virtual It Ins(It it)
		{
		T x;
		return insert(it, x);
		}
	virtual It Ins(It it, const T& x)
		{
		return insert(it, x);
		}
	virtual void Ins(It it, size_type n, const T& x)
		{
		insert(it, n, x);
		}
	virtual void Ins(It it, CIt first, CIt last)
		{
		insert(it, first, last);
		}
	virtual void Reserve(int n)
		{
		reserve(n);
		}
	const T& operator[](size_type p) const
		{
		return (*(Bgn() + p)); 
		}
	T& operator[](size_type p)
		{
		return (*(Bgn() + p)); 
		}
	const T& Item(size_type p) const
		{
		return (*(Bgn() + p)); 
		}
	T& Item(size_type p)
		{
		return (*(Bgn() + p)); 
		}
	bool operator==(const Array<T>& x) const
		{
		return (Size() == x.Size() && std::equal(Bgn(), End(), x.Bgn()));
		}
	bool operator<(const Array<T>& x) const
		{return (std::lexicographical_compare(begin(), end(), x.begin(), x.end())); }
	bool operator>(const Array<T>& x) const
		{return (x < *this); }
	bool operator<=(const Array<T>& x) const
		{return (!(x < *this)); }
	bool operator>=(const Array<T>& x) const
		{return (!(*this < x)); }
	};

//	PArray	array of pointer
template <class T>
class PArray : public Array<T*>
	{
	public:
    typedef Array<T*>::It It;
    typedef Array<T*>::CIt CIt;
	virtual ~PArray()
		{
		for(It i=Bgn(); i<End(); i++)
			{
			delete (*i);
			*i = NULL;
			}
		}
	virtual void Del(It it)
		{
		delete (*it);
		Array<T*>::Del(it);
		}
	virtual void Del(It first, It last)
		{
		for(It i=first; i<last; i++) delete (*i);
	 	Array<T*>::Del(first, last);
		}
	virtual void Marge(PArray<T>& a)
		{
		Add(a);
	 	Array<T*>::Del(a.Bgn(), a.End());
		}
	};
class CRefCount
	{
	int refCount;
	public:
	CRefCount(){refCount = 1;}
	virtual ~CRefCount(){ASSERT(refCount == 0);}
	int AddRef(){refCount++; return refCount;}
	int Release()
		{
		refCount--;
		int ref = refCount;
		if (ref == 0) delete this;
		return ref;
		}
	};
END_NAMESPACE_HASE

#ifndef REAL
typedef float REAL;
#endif
#ifndef BYTE
typedef unsigned char BYTE;
#endif
#ifndef WORD
typedef unsigned short WORD;
#endif
#ifndef DWORD
typedef unsigned long DWORD;
#endif
#ifndef UINT
typedef unsigned int UINT;
#endif

#endif
