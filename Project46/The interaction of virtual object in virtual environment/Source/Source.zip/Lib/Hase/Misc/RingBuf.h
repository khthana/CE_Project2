#ifndef HASE_MISC_RINGBUF_H
#define HASE_MISC_RINGBUF_H
#include <Hase/Misc/Inc.h>
BEGIN_NAMESPACE_HASE
template <class T>
class RingBuffer:protected Array<T>
	{
	protected:
	int cur;
	public:
	T zero;
	RingBuffer(int sz=0, T z=T())
		{
		cur = 0;
		zero = z;
		Size(sz);
		}
	int Size() const
		{
		return Array<T>::Size();
		}
	void Size(int sz)
		{
		Array<T>::Size(sz);
		if (cur >= Size()) cur = 0;
		}
	void Clear()
		{
		for(int i=0; i<Size(); i++) Bgn()[i] = zero;
		}
	void Add()
		{
		cur ++;
		if (cur>=Size()) cur = 0;
		}
	void Del()
		{
		cur --;
		if (cur<0) cur = Size()-1;
		}
	T& operator[] (int i)
		{
		i += cur;
		i = i % Size();
		return Bgn()[i];
		}
	};
END_NAMESPACE_HASE
#endif
