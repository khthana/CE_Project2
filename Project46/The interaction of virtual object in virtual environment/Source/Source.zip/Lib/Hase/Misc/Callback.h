#ifndef HASE_MISC_CALLBACK_H
#define HASE_MISC_CALLBACK_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "Hase/Misc/Inc.h"

BEGIN_NAMESPACE_HASE
template <class TParam>
struct CCallback
	{
	typedef void (*Func)(TParam&, void*);
	typedef TParam Param;
	void* pDat;
	Func func;
	bool operator <(const CCallback& cb) const
		{
		if (func == cb.func) return pDat < cb.pDat;
		return func < cb.func;
		}
	bool operator ==(const CCallback& cb) const
		{
		return (func==cb.func) && (pDat==cb.pDat);
		}
	};

template <class TParam>
class CCallbacks
	{
	typedef CCallback<TParam> Callback;
	protected:
	Array<Callback> callbacks;
	public:
	void Add(Callback::Func f, void* p)
		{
		int res = Del(f, p);
		ASSERT(!res);
		Callback cb;
		cb.func = f;
		cb.pDat = p;
		callbacks.Add(cb);
		}
	bool Del(Callback::Func f, void* p)
		{
		Callback cb;
		cb.func = f;
		cb.pDat = p;
		for(UINT i=0; i < callbacks.Size(); i++)
			{
			if (callbacks.Bgn()[i] == cb)
				{
				callbacks.Del(callbacks.Bgn()+i);
				return true;
				}
			}
		return false;
		}
	void Call(Callback::Param& p)
		{
		if (callbacks.Size())
			{
			for(Array<Callback>::It it=callbacks.End()-1; it >= callbacks.Bgn(); it--)
				it->func(p, it->pDat);
			}
		}
	};
END_NAMESPACE_HASE

#endif