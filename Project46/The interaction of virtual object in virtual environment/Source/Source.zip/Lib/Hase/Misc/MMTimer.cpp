#include "Hase/Misc/MMTimer.h"
#include <mmsystem.h>

BEGIN_NAMESPACE_HASE

using namespace std;
int CMMTimer::count;
UINT CMMTimer::resolution=1;
CMMTimer::CMMTimer()
	{
	func = NULL;
	arg = NULL;
	timerID = 0;
	interval = resolution;
	if (interval==0) interval = 1;
    bRun = false;
	bCreated = false;
	bThread = false;
	hThread = NULL;
	heavy = 0;
	}
CMMTimer::~CMMTimer()
	{
	Release();
	}
bool CMMTimer::Create()
	{
	heavy = 0;
	tick = GetTickCount();
	if (bCreated) return true;
	if (bThread) Release();
	if (count == 0) BeginPeriod();
	count ++;
	timerID = timeSetEvent(interval, resolution, TimerCallback, (DWORD)this, TIME_PERIODIC);
	bCreated = (timerID != 0);
	return bCreated;
	}
bool CMMTimer::Thread()
	{
	heavy = 0;
	if (bThread) return true;
	if (bCreated) Release();
	DWORD id=0;
	bThread = true;
	hThread = CreateThread(NULL, 0x1000, ThreadCallback, this, 0, &id);
	if (hThread)
		{
		bRun = true;
		SetThreadPriority(hThread, THREAD_PRIORITY_ABOVE_NORMAL);
		}
	else bThread = false;
	return bThread;
	}
void CMMTimer::Release()
	{
	if (bThread)
		{
		bThread = false;
		for(int t=0; t<100 && bRun; t++) Sleep(20);
		CloseHandle(hThread);
		hThread = NULL;
		}
	if (bCreated)
		{
		timeKillEvent(timerID);
		for(int i=0; i<100; i++)
			{
			if (!bRun) break;
			Sleep(10); 
			}
		count --;
		if (count == 0)	EndPeriod();
		bCreated = false;
		}
	}
void CMMTimer::BeginPeriod()
	{
	TIMECAPS tc;
	if (timeGetDevCaps(&tc, sizeof(TIMECAPS)) != TIMERR_NOERROR) 
		{
		OutputDebugString("CMMTimer::Resolution()  Fail to get resolution.\n");
		ASSERT(0);
		}
	resolution = min(max(tc.wPeriodMin, resolution), tc.wPeriodMax);
	timeBeginPeriod(resolution);
	}
void CMMTimer::EndPeriod()
	{
	timeEndPeriod(resolution);
	}
void CALLBACK CMMTimer::TimerCallback(UINT uID, UINT, DWORD dwUser, DWORD, DWORD)
	{
	CMMTimer& mmtimer = *(CMMTimer*)dwUser;
#if 0
    int tick = GetTickCount();
	int delta = tick - mmtimer.tick;
	if (delta > mmtimer.interval+1) mmtimer.heavy ++;
	mmtimer.tick = tick;
#endif
	mmtimer.bRun = true;
	mmtimer.func(mmtimer.arg);
    mmtimer.bRun = false;
	}
DWORD WINAPI CMMTimer::ThreadCallback(void* arg)
	{
	CMMTimer& mmtimer = *(CMMTimer*)arg;
	while(mmtimer.bThread)
		{
		mmtimer.func(mmtimer.arg);
		Sleep(mmtimer.interval);
		}
	mmtimer.bRun = false;
	return 0;
	}
UINT CMMTimer::Resolution()
	{
	return resolution;
	}
void CMMTimer::Resolution(UINT res)
	{
	if (resolution == res) return;
	if (count)
		{
		EndPeriod();
		BeginPeriod();
		}
	}
UINT CMMTimer::Interval()
	{
	return interval;
	}
void CMMTimer::Interval(UINT i)
	{
	if (i == interval) return;
	interval = i;
	if (bCreated)
		{
		Release();
		Create();
		}
	}
void CMMTimer::Set(MMTimerFunc* f, void* a)
	{
	func = f;
	arg = a;
	}

END_NAMESPACE_HASE
