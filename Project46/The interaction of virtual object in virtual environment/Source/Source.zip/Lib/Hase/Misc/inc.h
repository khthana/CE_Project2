#ifndef HASELIB_MISC_INC_H
#define HASELIB_MISC_INC_H

#include "hase/misc/Defs.h"
//	include <afxwin.h> or <windows.h>
#ifdef USEMFC
 #include <afxwin.h>
#else
 #ifndef STRICT
 #define STRICT
 #endif
 #include <windows.h>
#endif

//	stl and stream
#ifdef USE_NEW_STREAM
#include <strstream>
#include <fstream>
#include <iomanip>
#else
#include <strstrea.h>
#include <fstream.h>
#include <iomanip.h>
#endif
#include <algorithm>
#include <vector>
#include <string>

//	assersion
#include <assert.h>
#ifndef ASSERT
 #define ASSERT assert
#endif

#include "hase/misc/Types.h"

#endif