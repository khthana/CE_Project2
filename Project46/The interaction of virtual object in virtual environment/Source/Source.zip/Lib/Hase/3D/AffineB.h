/*
        -------------------------------------------------------
        | Hase/3D/AffineB.h  Hase/Misc/AffineB.cpp �̎g���� |
        -------------------------------------------------------

���̃t�@�C���̓x�N�g����Affine�s����`����̂���������̂ł��B

1.�@�\�̎������@�ɂ���
	�����̃t�@�C��(AffineB.*) �̓x�N�g����A�t�B���ϊ��̃��\�b�h��
	��`���܂��B

	D3D�̂悤��3D�����_���͕��ʃx�N�g���^��s��^�������Œ�`���Ă���
	���B
	�������A�����̌^�ɂ͕֗��ȃ��\�b�h�≉�Z�q���Ȃ����߁A�h��
	�N���X����肽���Ȃ�܂��B

	���܂��܂�3D�����_���ɂ������āA�x�N�g���^��s��^�̔h���N���X��
	���Ɠ����R�[�h�����ꂼ��̌^���Ƃɏ����Ȃ��Ă͂Ȃ炸�ώG�ł��B

	���̂悤�ȏꍇ�AC++�ł̓e���v���[�g��p���ĉ������邱�ƂɂȂ��Ă�
	�܂��B
	�������c�O�Ȃ��ƂɁA3D�����_���̒�`����x�N�g���^��s��^�̃���
	�o�̖��O�̓����_�����Ƃɂ܂��܂��Ȃ̂ŁA�e���v���[�g�����ł́A��
	�\�b�h��t�������邱�Ƃ��ł��܂���B

	�����ł��̃R�[�h�ł̓}�N����p���āA�ǂ̂悤�ȍs��^��x�N�g���^
	�ɑ΂��Ă����Z�q�⃁�\�b�h��t����������悤�ɂ��Ă��܂��B

2.AffineB.*����`����^�ƃ��\�b�h�Ɖ��Z�q
	
	��`����^
		2�����x�N�g��		Vec2
		2�����s��			Matrix2
		3�����x�N�g��		Vec3
		3�����A�t�B���s��	Affine

	�e�^�̃��\�b�h

	Vec2

	�\�z
		Vec2(SCALER xi = SCALER(0), SCALER yi = SCALER(0));

	���Z�q
		Vec2& operator *= (const SCALER& k)
		Vec2& operator += (const Vec2& v)
		Vec2& operator -= (const Vec2& v)
		Vec2 operator + (const Vec2& v) const
		Vec2 operator - (const Vec2& v) const
		Vec2 operator * (SCALER k) const
		Vec2 operator / (SCALER k) const
		SCALER operator * (const Vec2& v) const
		SCALER operator ^ (const Vec2& v) const
		Vec2 operator - () const
		bool operator == (const Vec2& v) const
		bool operator < (const Vec2& v) const
	�O���[�o�����Z�q
		inline Vec2 operator * (SCALER k, const Vec2& v)
	�x�N�g���̑傫����2���Ԃ�
		SCALER Square() const
	�x�N�g���̑傫����Ԃ�
		SCALER Size() const
	�P�ʃx�N�g����Ԃ�
		Vec2 Unit() const


	Matrix2

	�\�z |a b|
	     |c d|
		Matrix2( SCALER aa = 1 , SCALER bb = 0 , SCALER cc = 0 , SCALER dd = 1 )
	�s��
		SCALER Det(){ return MATRIX2_BASE_EX_X * MATRIX2_BASE_EY_Y - MATRIX2_BASE_EY_X * MATRIX2_BASE_EX_Y;};
	���Z�q
		Matrix2 operator /( SCALER dd )
		Vec2 operator *( Vec2 v )
	�t�s��
		Matrix2 inv()


	Vec3

	�\�z
	Vec3 (SCALER xi = SCALER(0), SCALER yi = SCALER(0), SCALER zi = SCALER(0))
	���Z�q
		Vec3& operator *= (const SCALER& k)
		Vec3& operator *= (const Affine& af);
		Vec3& operator += (const Vec3& v){*this=*this + v; return *this;}
		Vec3& operator -= (const Vec3& v){*this=*this - v; return *this;}
		Vec3 operator + (const Vec3& v) const
		Vec3 operator - (const Vec3& v) const
		Vec3 operator * (const SCALER& k) const
		Vec3 operator / (const SCALER& k) const
		SCALER operator * (const Vec3& v) const
		Vec3 operator ^ (const Vec3& v) const	//	�O��
		Vec3 operator - () const
		bool operator == (const Vec3& v) const
		bool operator < (const Vec3& v) const	//	�傫�����r
	�傫��
		SCALER Size() const
	�傫����2��
		SCALER Square() const
	���������̒P�ʃx�N�g��
		Vec3 Unit() const
	���Z�q(�O���[�o��)
		inline Vec3 operator * (const SCALER& k, const Vec3& v)
		ostream& operator << (ostream& ostr, const Vec3& v);
		istream& operator >> (istream& istr, Vec3& v);
	�o�C�i���ǂݏ���(�O���[�o��)
		void binRead(STREAM_STD__ istream& istr, Vec3&);
		void binWrite(STREAM_STD__ ostream& ostr, const Vec3&);
		size_t binLen(const Vec3&);

	
	Affine
	
	���x�N�g���ւ̃A�N�Z�X
		const Vec3 Ex() const		//	x���̊��x�N�g��
		void Ex(Vec3& v)
		const Vec3 Ey() const		//	x���̊��x�N�g��
		void Ey(const Vec3& v)
		const Vec3 Ez() const		//	x���̊��x�N�g��
		void Ez(const Vec3& v)
		const Vec3 Pos() const		//	x���̊��x�N�g��
		void Pos(const Vec3& v)
	�\�z
		Affine()					//	�P�ʍs��(�P���ϊ�)
		Affine(SCALER px,SCALER py,SCALER pz)
									//	���s�ړ��̂�
		Affine(Vec3 exi, Vec3 eyi, Vec3 posi=Vec3())
									//	x��, y��, �ʒu ���w��
		Affine(Vec3 exi, Vec3 eyi, char axis, Vec3 posi=Vec3());
									//	axis��, axis++��, �ʒu ���w��
		Affine(SCALER th, char axis , Vec3 posi=Vec3());
		Affine(SCALER th, Vec3 axis , Vec3 posi=Vec3())
			//	axis���܂���]
	��]�g��ϊ��݂̂��s��
		Vec3 Rot(const Vec3& v) const
	���Z�q
		Vec3 operator * (const Vec3& v) const
		Affine operator *= (const Affine& af)
		Affine operator * (const Affine& af) const
		Affine operator *= (const SCALER k)
		Affine operator * (const SCALER k) const
	�g���]�s�񕔂̍s��
		SCALER	Det() const
	�t�s��
		Affine Inv() const
	z���̌����� posi �Ɍ�����
		void LookAt(Vec3 posi);
	���Z�q(�O���[�o��)
		inline Affine operator * (const SCALER k, const Affine& s)
		inline Vec3& Vec3::operator *= (const Affine& af)
		ostream& operator << (ostream& ostr, const Affine& s);
		istream& operator >> (istream& istr, Affine& s);
	�o�C�i���ǂݏ���(�O���[�o��)
		void binRead(STREAM_STD__ istream& istr, Affine&);
		void binWrite(STREAM_STD__ ostream& ostr, const Affine&);
		binLen(const Affine&);



3.AffineB.*�� �g����
	1. AffineB �̓�������߂邽�߂ɁA�}�N�����`���܂�
	2. AffineB.* �� #include ���܂��B
	<��>
	---HD3DAffine.h�t�@�C��---------------------
	#define SCALER				D3DVALUE		//	�X�J���[�^�̒�`
	#define Vec3				CD3DVec3		//	�V���ɍ��x�N�g���^
	#define VEC3_BASE			D3DVECTOR		//	��ƂȂ�x�N�g���^
	#define VEC3_BASE_X			dvX				//	�x�N�g���̗v�f x �̕ϐ���
		:
	#define Affine				CD3DAffine		//	�V���ɍ��Affine�s��^
	#define AFFINE_BASE			CD3DMatrix		//	��ƂȂ�s��^
	#define AFFINE_BASE_EX_X	_11				//	��ƂȂ�s��^�� ex.x �̕ϐ���
	#define AFFINE_BASE_EX_Y	_12				//	��ƂȂ�s��^�� ex.y �̕ϐ���
		:
	#define AFFINE_BASE_POS_Z	_43				//	��ƂȂ�s��^�� pos.z �̕ϐ���

	#include <Hase/3D/AffineB.h>				//	#include ���܂��B
	
	#ifndef DONT_UNDEF
	#define UNDEF_ALL_AFFINEB					//	�}�N������������悤�w�����܂�
	#include <Hase/3D/AffineB.h>				//	�}�N�����������܂�
	#endif
	---HD3DAffine.cpp�t�@�C��-------------------
	#define DONT_UNDEF
	#include <Hase/3D/AffineB.cpp> 				//	#include ���܂��B
		:
	#undef DONT_UNDEF
	#define UNDEF_ALL_AFFINEB
	#include <Hase/3D/AffineB.h>				//	�}�N�����������܂�
	--------------------------------------------

4.�g�p����ۂɒ�`����}�N��
	SCALER					�X�J���[�^

	Vec2					�V���ɍ��x�N�g���^
	VEC2_BASE				��ƂȂ�x�N�g���^
	VEC2_BASE_X				��ƂȂ�x�N�g���^�̗v�f x �̕ϐ���
	VEC2_BASE_Y				��ƂȂ�x�N�g���^�̗v�f y �̕ϐ���

	Matrix2					�V���ɍ��2x2�s��^
	MATRIX2_BASE			��ƂȂ�2x2�s��^
	MATRIX2_BASE_EX_X			��ƂȂ�s��^��1�s1��v�f�̕ϐ���
	MATRIX2_BASE_EY_X			��ƂȂ�s��^��1�s2��v�f�̕ϐ���
	MATRIX2_BASE_EX_Y			��ƂȂ�s��^��2�s1��v�f�̕ϐ���
	MATRIX2_BASE_EY_Y			��ƂȂ�s��^��2�s2��v�f�̕ϐ���

	Vec3					�V���ɍ��x�N�g���^
	VEC3_BASE				��ƂȂ�x�N�g���^
	VEC3_BASE_X				��ƂȂ�x�N�g���^�̗v�f x �̕ϐ���
	VEC3_BASE_Y				��ƂȂ�x�N�g���^�̗v�f y �̕ϐ���
	VEC3_BASE_Z				��ƂȂ�x�N�g���^�̗v�f z �̕ϐ���

	Matrix3					�V���ɍ��3x3�s��^
	Matrix3Base				��ƂȂ�s��^
	MATRIX3_BASE_EX_X		��ƂȂ�s��^��x�����x�N�g���̗v�fx�̕ϐ���
	MATRIX3_BASE_EX_Y		��ƂȂ�s��^��x�����x�N�g���̗v�fy�̕ϐ���
	MATRIX3_BASE_EX_Z		��ƂȂ�s��^��x�����x�N�g���̗v�fz�̕ϐ���
	MATRIX3_BASE_EY_X		��ƂȂ�s��^��y�����x�N�g���̗v�fx�̕ϐ���
	MATRIX3_BASE_EY_Y		��ƂȂ�s��^��y�����x�N�g���̗v�fy�̕ϐ���
	MATRIX3_BASE_EY_Z		��ƂȂ�s��^��y�����x�N�g���̗v�fz�̕ϐ���
	MATRIX3_BASE_EZ_X		��ƂȂ�s��^��z�����x�N�g���̗v�fx�̕ϐ���
	MATRIX3_BASE_EZ_Y		��ƂȂ�s��^��z�����x�N�g���̗v�fy�̕ϐ���
	MATRIX3_BASE_EZ_Z		��ƂȂ�s��^��z�����x�N�g���̗v�fz�̕ϐ���

	Affine					�V���ɍ��Affine�s��^
	AFFINE_BASE				��ƂȂ�s��^
	AFFINE_BASE_EX_X		��ƂȂ�s��^��x�����x�N�g���̗v�fx�̕ϐ���
	AFFINE_BASE_EX_Y		��ƂȂ�s��^��x�����x�N�g���̗v�fy�̕ϐ���
	AFFINE_BASE_EX_Z		��ƂȂ�s��^��x�����x�N�g���̗v�fz�̕ϐ���
	AFFINE_BASE_EY_X		��ƂȂ�s��^��y�����x�N�g���̗v�fx�̕ϐ���
	AFFINE_BASE_EY_Y		��ƂȂ�s��^��y�����x�N�g���̗v�fy�̕ϐ���
	AFFINE_BASE_EY_Z		��ƂȂ�s��^��y�����x�N�g���̗v�fz�̕ϐ���
	AFFINE_BASE_EZ_X		��ƂȂ�s��^��z�����x�N�g���̗v�fx�̕ϐ���
	AFFINE_BASE_EZ_Y		��ƂȂ�s��^��z�����x�N�g���̗v�fy�̕ϐ���
	AFFINE_BASE_EZ_Z		��ƂȂ�s��^��z�����x�N�g���̗v�fz�̕ϐ���
	AFFINE_BASE_POS_X		��ƂȂ�s��^�̕��s�ړ��x�N�g���̗v�fx�̕ϐ���
	AFFINE_BASE_POS_Y		��ƂȂ�s��^�̕��s�ړ��x�N�g���̗v�fy�̕ϐ���
	AFFINE_BASE_POS_Z		��ƂȂ�s��^�̕��s�ړ��x�N�g���̗v�fz�̕ϐ���
*/
#ifdef UNDEF_ALL_AFFINEB	//	�}�N���̏���
 #undef UNDEF_ALL_AFFINEB

 #undef SCALER

 #undef Vec2
 #undef VEC2_BASE
 #undef VEC2_BASE_X
 #undef VEC2_BASE_Y

 #undef Matrix2
 #undef MATRIX2_BASE
 #undef MATRIX2_BASE_EX_X
 #undef MATRIX2_BASE_EY_X
 #undef MATRIX2_BASE_EX_Y
 #undef MATRIX2_BASE_EY_Y

 #undef Vec3
 #undef VEC3_BASE
 #undef VEC3_BASE_X
 #undef VEC3_BASE_Y
 #undef VEC3_BASE_Z 

 #undef Matrix3
 #undef MATRIX3_BASE
 #undef MATRIX3_BASE_EX_X
 #undef MATRIX3_BASE_EX_Y
 #undef MATRIX3_BASE_EX_Z
 #undef MATRIX3_BASE_EY_X
 #undef MATRIX3_BASE_EY_Y
 #undef MATRIX3_BASE_EY_Z
 #undef MATRIX3_BASE_EZ_X
 #undef MATRIX3_BASE_EZ_Y
 #undef MATRIX3_BASE_EZ_Z

 #undef Affine
 #undef AFFINE_BASE
 #undef AFFINE_BASE_EX_X
 #undef AFFINE_BASE_EX_Y
 #undef AFFINE_BASE_EX_Z
 #undef AFFINE_BASE_EY_X
 #undef AFFINE_BASE_EY_Y
 #undef AFFINE_BASE_EY_Z
 #undef AFFINE_BASE_EZ_X
 #undef AFFINE_BASE_EZ_Y
 #undef AFFINE_BASE_EZ_Z
 #undef AFFINE_BASE_POS_X
 #undef AFFINE_BASE_POS_Y
 #undef AFFINE_BASE_POS_Z

#else	//	UNDEF_ALL_AFFINEB

#include "Hase/Misc/Inc.h"
#include <math.h>

//	�ėp�}�N����`
#ifndef M_PI
 #define M_PI	(3.14159265358979323846)
#endif
#ifndef MIN
 #define MIN(x,y)	( (x) <= (y)  ?  (x)  :  (y) )
#endif
 #ifndef MAX
#define MAX(x,y)	( (x) >= (y)  ?  (x)  :  (y) )
#endif
#ifndef ABS
 #define ABS(x)		( (x) > 0  ?  (x)  :  -(x) )
#endif
#undef SIGN
#define SIGN(x)	( (x) > 0  ?  (1)  :  (-1) )
typedef float REAL;

BEGIN_NAMESPACE_HASE

#ifndef AFFINEB_H_SCALER_UTILITY
#define AFFINEB_H_SCALER_UTILITY
inline REAL Rad(REAL deg)
	{
	return (REAL)(deg/360*2*M_PI);
	}
inline REAL Deg(REAL rad)
	{
	return (REAL)((rad/(2*M_PI)) * 360);
	}
template <class SC>
inline SC Square(SC x)
	{
	return x*x;
	}
template <class SC>
inline SC Det2(SC a, SC b, SC c, SC d)
	{
	return ((a)*(d) - (b)*(c));
	}
#endif

//	�o�C�i���`���ł̓ǂݏ����̂��߂̃��\�b�h
#ifndef AFFINEB_H_BIN_READ_WRITE
#define AFFINEB_H_BIN_READ_WRITE
template <class T>
inline void binRead(STREAM_STD__ istream& istr, T& t)
	{
	istr.read((char*)&t, sizeof t);
	}
template <class T>
inline void binWrite(STREAM_STD__ ostream& ostr,const T& t)
	{
	ostr.write((char*)&t, sizeof t);
	}
template <class T>
inline size_t binLen(const T&)
	{
	return sizeof(T);
	}
#endif

#if defined Vec2
//-----------------------------------------------------------------------------
//		Vec2
//
class DLLCLASS Vec2:public VEC2_BASE
	{
	static char puncChar;
	public:
	static char& PuncChar();
	Vec2(SCALER xi = SCALER(0), SCALER yi = SCALER(0))
		{
		VEC2_BASE_X = xi;
		VEC2_BASE_Y = yi;
		}
	Vec2& operator *= (const SCALER& k)
		{
		VEC2_BASE_X *= k;
		VEC2_BASE_Y *= k;
		return *this;
		}
	Vec2& operator += (const Vec2& v)
		{
		*this=*this + v; return *this;
		}
	Vec2& operator -= (const Vec2& v)
		{
		*this=*this - v; return *this;
		}
	Vec2 operator + (const Vec2& v) const
		{
		return Vec2(VEC2_BASE_X + v.VEC2_BASE_X, VEC2_BASE_Y + v.VEC2_BASE_Y);
		}
	Vec2 operator - (const Vec2& v) const
		{
		return Vec2(VEC2_BASE_X - v.VEC2_BASE_X, VEC2_BASE_Y - v.VEC2_BASE_Y);
		}
	Vec2 operator * (SCALER k) const
		{
		return Vec2(VEC2_BASE_X*k, VEC2_BASE_Y*k);
		}
	Vec2 operator / (SCALER k) const
		{
		return Vec2(VEC2_BASE_X/k, VEC2_BASE_Y/k);
		}
	SCALER operator * (const Vec2& v) const
		{
		return VEC2_BASE_X*v.VEC2_BASE_X + VEC2_BASE_Y*v.VEC2_BASE_Y;
		}
	SCALER operator ^ (const Vec2& v) const
		{
		return VEC2_BASE_X*v.VEC2_BASE_Y - VEC2_BASE_Y*v.VEC2_BASE_X;
		}
	Vec2 operator - () const
		{
		return Vec2(-VEC2_BASE_X, -VEC2_BASE_Y);
		}
	bool operator == (const Vec2& v) const
		{
		return (VEC2_BASE_X == v.VEC2_BASE_X) && (VEC2_BASE_Y == v.VEC2_BASE_Y);
		}
	bool operator < (const Vec2& v) const
		{
		return Size() < v.Size();
		}
	SCALER Square() const
		{
		return VEC2_BASE_X*VEC2_BASE_X + VEC2_BASE_Y*VEC2_BASE_Y;
		}
	SCALER Size() const
		{
		return SCALER(sqrt(Square()));
		}
	Vec2 Unit() const
		{
		SCALER s = Size();
		if ((s>0?s:-s) > 1E-10) return *this / s;
		else return Vec2(SCALER(0),SCALER(1));
		}
	};
inline Vec2 operator * (SCALER k, const Vec2& v)
	{
	return Vec2(v.VEC2_BASE_X*k, v.VEC2_BASE_Y*k);
	}
DLLCLASS void binRead(STREAM_STD__ istream& istr, Vec2&);
DLLCLASS void binWrite(STREAM_STD__ ostream& ostr, const Vec2&);
DLLCLASS size_t binLen(const Vec2 &);
DLLCLASS STREAM_STD__ ostream& operator << (STREAM_STD__ ostream& ostr, const Vec2& v);
DLLCLASS STREAM_STD__ istream& operator >> (STREAM_STD__ ostream& ostr, Vec2& v);
#endif	// defined Vec2

#if defined Matrix2
//-----------------------------------------------------------------------------
//		Matrix2
//
class DLLCLASS Matrix2:public MATRIX2_BASE
	{
	public:
	Matrix2( SCALER aa = 1 , SCALER bb = 0 , SCALER cc = 0 , SCALER dd = 1 )
		{
		MATRIX2_BASE_EX_X = aa , MATRIX2_BASE_EY_X = bb , MATRIX2_BASE_EX_Y = cc , MATRIX2_BASE_EY_Y = dd;
		}
	Matrix2(Vec2 exi, Vec2 eyi)
		{
		MATRIX2_BASE_EX_X = exi.VEC2_BASE_X;
		MATRIX2_BASE_EX_Y = exi.VEC2_BASE_Y;
		MATRIX2_BASE_EY_X = eyi.VEC2_BASE_X;
		MATRIX2_BASE_EY_Y = eyi.VEC2_BASE_Y;
		}
	SCALER Det(){ return MATRIX2_BASE_EX_X * MATRIX2_BASE_EY_Y - MATRIX2_BASE_EY_X * MATRIX2_BASE_EX_Y;};
	const Matrix2 operator /( SCALER dd )
		{
		if( dd == 0 ) return Matrix2();
		return Matrix2( MATRIX2_BASE_EX_X / dd , MATRIX2_BASE_EY_X / dd , MATRIX2_BASE_EX_Y / dd , MATRIX2_BASE_EY_Y / dd );
		}
	Vec2 operator *( Vec2 v )
		{
		return Vec2( MATRIX2_BASE_EX_X * v.x + MATRIX2_BASE_EY_X * v.y , MATRIX2_BASE_EX_Y * v.x + MATRIX2_BASE_EY_Y * v.y );
		}
	Matrix2 Inv()
		{
		return Matrix2( MATRIX2_BASE_EY_Y , -MATRIX2_BASE_EY_X , -MATRIX2_BASE_EX_Y , MATRIX2_BASE_EX_X ) / Det();
		}
	};
#endif //	defined Matrix2



#if (defined Vec3 || defined Affine || defined Matrix3)
//-----------------------------------------------------------------------------
//		Vec3
//
#ifdef Affine
class Affine;
#endif
#ifdef Matrix3
class Matrix3;
#endif
class DLLCLASS Vec3 :public VEC3_BASE
	{
	static char puncChar;
	public:
	static char& PuncChar();
	Vec3 (SCALER xi = SCALER(0), SCALER yi = SCALER(0), SCALER zi = SCALER(0))
		{
		VEC3_BASE_X = xi;
		VEC3_BASE_Y = yi;
		VEC3_BASE_Z = zi;
		}
	Vec3 (const VEC3_BASE& v)
		{
		VEC3_BASE_X = v.VEC3_BASE_X;
		VEC3_BASE_Y = v.VEC3_BASE_Y;
		VEC3_BASE_Z = v.VEC3_BASE_Z;
		}
	Vec3& operator *= (const SCALER& k)
		{
		VEC3_BASE_X *= k;	VEC3_BASE_Y *= k;	VEC3_BASE_Z *= k;
		return *this;
		}
#ifdef Affine
	Vec3& operator *= (const Affine& af);
#endif
#ifdef Matrix3
	Vec3& operator *= (const Matrix3& mt);
#endif
	Vec3& operator += (const Vec3& v){*this=*this + v; return *this;}
	Vec3& operator -= (const Vec3& v){*this=*this - v; return *this;}
	Vec3 operator + (const Vec3& v) const
		{
		return Vec3( VEC3_BASE_X + v.VEC3_BASE_X,  VEC3_BASE_Y + v.VEC3_BASE_Y,  VEC3_BASE_Z + v.VEC3_BASE_Z );
		}
	Vec3 operator - (const Vec3& v) const
		{
		return Vec3( VEC3_BASE_X - v.VEC3_BASE_X,  VEC3_BASE_Y - v.VEC3_BASE_Y,  VEC3_BASE_Z - v.VEC3_BASE_Z );
		}
	Vec3 operator * (const SCALER& k) const
		{
		return Vec3( VEC3_BASE_X * k,  VEC3_BASE_Y * k,  VEC3_BASE_Z * k );
		}
	Vec3 operator / (const SCALER& k) const
		{
		return Vec3( VEC3_BASE_X / k,  VEC3_BASE_Y / k,  VEC3_BASE_Z / k );
		}
	SCALER operator * (const Vec3& v) const
		{
		return VEC3_BASE_X*v.VEC3_BASE_X + VEC3_BASE_Y*v.VEC3_BASE_Y + VEC3_BASE_Z*v.VEC3_BASE_Z;
		}
	Vec3 operator ^ (const Vec3& v) const
		{
		return Vec3(VEC3_BASE_Y*v.VEC3_BASE_Z - VEC3_BASE_Z*v.VEC3_BASE_Y, VEC3_BASE_Z*v.VEC3_BASE_X - VEC3_BASE_X*v.VEC3_BASE_Z, VEC3_BASE_X*v.VEC3_BASE_Y - VEC3_BASE_Y*v.VEC3_BASE_X);
		}
	Vec3 operator - () const
		{
		return Vec3(-VEC3_BASE_X, -VEC3_BASE_Y, -VEC3_BASE_Z);
		}
	bool operator == (const Vec3& v) const
		{
		return (VEC3_BASE_X == v.VEC3_BASE_X) && (VEC3_BASE_Y == v.VEC3_BASE_Y) && (VEC3_BASE_Z == v.VEC3_BASE_Z);
		}
	bool operator != (const Vec3& v) const
		{
		return !(*this == v);
		}
	bool operator < (const Vec3& v) const
		{
		return Size() < v.Size();
		}
	bool operator > (const Vec3& v) const
		{
		return Size() > v.Size();
		}
	SCALER Square() const
		{
		return VEC3_BASE_X*VEC3_BASE_X + VEC3_BASE_Y*VEC3_BASE_Y + VEC3_BASE_Z*VEC3_BASE_Z;
		}
	SCALER Size() const
		{
		return (SCALER)sqrt(Square());
		}
	Vec3 Unit() const
		{
		SCALER s = Size();
		if ((s>0?s:-s) >= 1E-10) return *this / s;
		else return Vec3(SCALER(0),SCALER(0),SCALER(1));
		}
	};
inline Vec3 operator * (const SCALER& k, const Vec3& v)
	{
	return Vec3(v.VEC3_BASE_X*k, v.VEC3_BASE_Y*k, v.VEC3_BASE_Z*k);
	}
DLLCLASS STREAM_STD__ ostream& operator << (STREAM_STD__ ostream& ostr, const Vec3& v);
DLLCLASS STREAM_STD__ istream& operator >> (STREAM_STD__ istream& istr, Vec3& v);
DLLCLASS void binRead(STREAM_STD__ istream& istr, Vec3&);
DLLCLASS void binWrite(STREAM_STD__ ostream& ostr, const Vec3&);
DLLCLASS size_t binLen(const Vec3&);

#endif //	(defined Vec3 || defined Affine || defined Matrix3)

#if defined PitchYawRoll
//-----------------------------------------------------------------------------
//	PitchYawRoll
//
class DLLCLASS PitchYawRoll
	{
	PitchYawRoll(Vec3 a);
	Vec3 angle;
	};
#endif

#if defined Matrix3
//-----------------------------------------------------------------------------
//	Matrix3
//
class DLLCLASS Matrix3 :public MATRIX3_BASE
	{
	public:
	operator MATRIX3_BASE&() const
		{
		return *(MATRIX3_BASE*) this;
		}
	//	�P�ʃx�N�g���ւ̃A�N�Z�X
	const Vec3 Ex() const
		{
		return Vec3(MATRIX3_BASE_EX_X, MATRIX3_BASE_EX_Y, MATRIX3_BASE_EX_Z);
		}
	void Ex(const Vec3& v)
		{
		MATRIX3_BASE_EX_X = v.VEC3_BASE_X;
		MATRIX3_BASE_EX_Y = v.VEC3_BASE_Y;
		MATRIX3_BASE_EX_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Ey() const
		{
		return Vec3(MATRIX3_BASE_EY_X, MATRIX3_BASE_EY_Y, MATRIX3_BASE_EY_Z);
		}
	void Ey(const Vec3& v)
		{
		MATRIX3_BASE_EY_X = v.VEC3_BASE_X;
		MATRIX3_BASE_EY_Y = v.VEC3_BASE_Y;
		MATRIX3_BASE_EY_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Ez() const
		{
		return Vec3(MATRIX3_BASE_EZ_X, MATRIX3_BASE_EZ_Y, MATRIX3_BASE_EZ_Z);
		}
	void Ez(const Vec3& v)
		{
		MATRIX3_BASE_EZ_X = v.VEC3_BASE_X;
		MATRIX3_BASE_EZ_Y = v.VEC3_BASE_Y;
		MATRIX3_BASE_EZ_Z = v.VEC3_BASE_Z;
		}
	SCALER& ExX() {return MATRIX3_BASE_EX_X;}
	SCALER& ExY() {return MATRIX3_BASE_EX_Y;}
	SCALER& ExZ() {return MATRIX3_BASE_EX_Z;}
	SCALER& EyX() {return MATRIX3_BASE_EY_X;}
	SCALER& EyY() {return MATRIX3_BASE_EY_Y;}
	SCALER& EyZ() {return MATRIX3_BASE_EY_Z;}
	SCALER& EzX() {return MATRIX3_BASE_EZ_X;}
	SCALER& EzY() {return MATRIX3_BASE_EZ_Y;}
	SCALER& EzZ() {return MATRIX3_BASE_EZ_Z;}
	//---------------------------------
	//	�������ƍ\�z
	//
	//	�P�ʍs��
	void InitUnit()
		{
		MATRIX3_BASE_EX_X = 1;	MATRIX3_BASE_EX_Y = 0;	MATRIX3_BASE_EX_Z = 0;
		MATRIX3_BASE_EY_X = 0;	MATRIX3_BASE_EY_Y = 1;	MATRIX3_BASE_EY_Z = 0;
		MATRIX3_BASE_EZ_X = 0;	MATRIX3_BASE_EZ_Y = 0;	MATRIX3_BASE_EZ_Z = 1;
		}
	Matrix3(){InitUnit();}
	//	x��, y�� ���w��
	void InitDirect(Vec3 exi, Vec3 eyi)
		{
		Ex(exi.Unit());
		Ey(  ( eyi - (eyi*Ex())*Ex() ).Unit()  );
		Ez(Ex() ^ Ey());
		}
	Matrix3(Vec3 exi, Vec3 eyi){InitDirect(exi, eyi);}
	void InitDirect(Vec3 exi, Vec3 eyi, Vec3 ezi)
		{
		Ex(exi); Ey(eyi); Ez(ezi);
		}
	Matrix3(Vec3 exi, Vec3 eyi, Vec3 ezi){InitDirect(exi, eyi, ezi);}
	//	axis��, axis++��, �ʒu ���w��
	void InitDirect(Vec3 a, Vec3 b, char axis);
	Matrix3(Vec3 a, Vec3 b, char axis) {InitDirect(a, b, axis);}
	//	axis���܂���]
	void InitRot(SCALER th, char axis);
	Matrix3(SCALER th, char axis) {InitRot(th, axis);}
	//	axis���܂���]
	void InitRot(SCALER th, Vec3 axis)
		/*  +																	   +
			|u^2+(1-u^2)cos(th)      uv(1-cos(th))-wsin(th)  wu(1-cos(th))+vsin(th)|
		R =	|uv(1-cos(th))+wsin(th)  v^2+(1-v^2)cos(th)      vw(1-cos(th))-usin(th)|
			|wu(1-cos(th))-vsin(th)  vw(1-cos(th))+usin(th)  w^2+(1-w^2)cos(th)    |
			+																	   +*/
		{
			SCALER s = (SCALER)sin(th), c = (SCALER)cos(th);
			SCALER u = axis.VEC3_BASE_X, v = axis.VEC3_BASE_Y, w = axis.VEC3_BASE_Z;
			Ex(Vec3(
				u*u + (SCALER(1)-u*u)*c,
				u*v*(SCALER(1)-c) + w*s,
				w*u*(SCALER(1)-c) - v*s));
			Ey(Vec3(
				u*v*(SCALER(1)-c) - w*s,
				v*v + (SCALER(1)-v*v)*c,
				v*w*(SCALER(1)-c) + u*s));
			Ez(Vec3(
				w*u*(SCALER(1)-c) + v*s,
				v*w*(SCALER(1)-c) - u*s,
				w*w + (SCALER(1)-w*w)*c));
		}
	void InitRot(Vec3 rvec)
		{
		SCALER size=rvec.Size();
		InitRot(size, rvec/size);
		}
	Matrix3(SCALER th, Vec3 axis){InitRot(th, axis.Unit());}
	//---------------------------------
	//	���Z
	//
	bool operator == (const Matrix3& mt) const
		{
		return
		MATRIX3_BASE_EX_X == mt.MATRIX3_BASE_EX_X &&
		MATRIX3_BASE_EX_Y == mt.MATRIX3_BASE_EX_Y &&
		MATRIX3_BASE_EX_Z == mt.MATRIX3_BASE_EX_Z &&
		MATRIX3_BASE_EY_X == mt.MATRIX3_BASE_EY_X &&
		MATRIX3_BASE_EY_Y == mt.MATRIX3_BASE_EY_Y &&
		MATRIX3_BASE_EY_Z == mt.MATRIX3_BASE_EY_Z &&
		MATRIX3_BASE_EZ_X == mt.MATRIX3_BASE_EZ_X &&
		MATRIX3_BASE_EZ_Y == mt.MATRIX3_BASE_EZ_Y &&
		MATRIX3_BASE_EZ_Z == mt.MATRIX3_BASE_EZ_Z;
		}
	Vec3 operator * (const Vec3& v) const
		{
		return Vec3(
			MATRIX3_BASE_EX_X * v.VEC3_BASE_X + MATRIX3_BASE_EY_X * v.VEC3_BASE_Y + MATRIX3_BASE_EZ_X * v.VEC3_BASE_Z,
			MATRIX3_BASE_EX_Y * v.VEC3_BASE_X + MATRIX3_BASE_EY_Y * v.VEC3_BASE_Y + MATRIX3_BASE_EZ_Y * v.VEC3_BASE_Z,
			MATRIX3_BASE_EX_Z * v.VEC3_BASE_X + MATRIX3_BASE_EY_Z * v.VEC3_BASE_Y + MATRIX3_BASE_EZ_Z * v.VEC3_BASE_Z
			);
		}
	Matrix3 operator * (const Matrix3& mt) const
		{
		Matrix3 rtv;
		rtv.MATRIX3_BASE_EX_X = MATRIX3_BASE_EX_X*mt.MATRIX3_BASE_EX_X + MATRIX3_BASE_EY_X*mt.MATRIX3_BASE_EX_Y + MATRIX3_BASE_EZ_X*mt.MATRIX3_BASE_EX_Z;
		rtv.MATRIX3_BASE_EX_Y = MATRIX3_BASE_EX_Y*mt.MATRIX3_BASE_EX_X + MATRIX3_BASE_EY_Y*mt.MATRIX3_BASE_EX_Y + MATRIX3_BASE_EZ_Y*mt.MATRIX3_BASE_EX_Z;
		rtv.MATRIX3_BASE_EX_Z = MATRIX3_BASE_EX_Z*mt.MATRIX3_BASE_EX_X + MATRIX3_BASE_EY_Z*mt.MATRIX3_BASE_EX_Y + MATRIX3_BASE_EZ_Z*mt.MATRIX3_BASE_EX_Z;

		rtv.MATRIX3_BASE_EY_X = MATRIX3_BASE_EX_X*mt.MATRIX3_BASE_EY_X + MATRIX3_BASE_EY_X*mt.MATRIX3_BASE_EY_Y + MATRIX3_BASE_EZ_X*mt.MATRIX3_BASE_EY_Z;
		rtv.MATRIX3_BASE_EY_Y = MATRIX3_BASE_EX_Y*mt.MATRIX3_BASE_EY_X + MATRIX3_BASE_EY_Y*mt.MATRIX3_BASE_EY_Y + MATRIX3_BASE_EZ_Y*mt.MATRIX3_BASE_EY_Z;
		rtv.MATRIX3_BASE_EY_Z = MATRIX3_BASE_EX_Z*mt.MATRIX3_BASE_EY_X + MATRIX3_BASE_EY_Z*mt.MATRIX3_BASE_EY_Y + MATRIX3_BASE_EZ_Z*mt.MATRIX3_BASE_EY_Z;

		rtv.MATRIX3_BASE_EZ_X = MATRIX3_BASE_EX_X*mt.MATRIX3_BASE_EZ_X + MATRIX3_BASE_EY_X*mt.MATRIX3_BASE_EZ_Y + MATRIX3_BASE_EZ_X*mt.MATRIX3_BASE_EZ_Z;
		rtv.MATRIX3_BASE_EZ_Y = MATRIX3_BASE_EX_Y*mt.MATRIX3_BASE_EZ_X + MATRIX3_BASE_EY_Y*mt.MATRIX3_BASE_EZ_Y + MATRIX3_BASE_EZ_Y*mt.MATRIX3_BASE_EZ_Z;
		rtv.MATRIX3_BASE_EZ_Z = MATRIX3_BASE_EX_Z*mt.MATRIX3_BASE_EZ_X + MATRIX3_BASE_EY_Z*mt.MATRIX3_BASE_EZ_Y + MATRIX3_BASE_EZ_Z*mt.MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	Matrix3 operator *= (const Matrix3& mt)
		{
		return *this = *this * mt;
		}
	Matrix3 operator *= (const SCALER k)
		{
		return *this = *this * k;
		}
	Matrix3 operator * (const SCALER k) const
		{
		Matrix3 rtv;
		rtv.MATRIX3_BASE_EX_X = k * MATRIX3_BASE_EX_X;
		rtv.MATRIX3_BASE_EX_Y = k * MATRIX3_BASE_EX_Y;
		rtv.MATRIX3_BASE_EX_Z = k * MATRIX3_BASE_EX_Z;

		rtv.MATRIX3_BASE_EY_X = k * MATRIX3_BASE_EY_X;
		rtv.MATRIX3_BASE_EY_Y = k * MATRIX3_BASE_EY_Y;
		rtv.MATRIX3_BASE_EY_Z = k * MATRIX3_BASE_EY_Z;

		rtv.MATRIX3_BASE_EZ_X = k * MATRIX3_BASE_EZ_X;
		rtv.MATRIX3_BASE_EZ_Y = k * MATRIX3_BASE_EZ_Y;
		rtv.MATRIX3_BASE_EZ_Z = k * MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	Matrix3 operator += (const Matrix3& mt)
		{
		return *this = *this + mt;
		}
	Matrix3 operator + (const Matrix3 mt)
		{
		Matrix3 rtv = *this;
		rtv.MATRIX3_BASE_EX_X += mt.MATRIX3_BASE_EX_X;
		rtv.MATRIX3_BASE_EX_Y += mt.MATRIX3_BASE_EX_Y;
		rtv.MATRIX3_BASE_EX_Z += mt.MATRIX3_BASE_EX_Z;

		rtv.MATRIX3_BASE_EY_X += mt.MATRIX3_BASE_EY_X;
		rtv.MATRIX3_BASE_EY_Y += mt.MATRIX3_BASE_EY_Y;
		rtv.MATRIX3_BASE_EY_Z += mt.MATRIX3_BASE_EY_Z;

		rtv.MATRIX3_BASE_EZ_X += mt.MATRIX3_BASE_EZ_X;
		rtv.MATRIX3_BASE_EZ_Y += mt.MATRIX3_BASE_EZ_Y;
		rtv.MATRIX3_BASE_EZ_Z += mt.MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	Matrix3 operator -= (const Matrix3& mt)
		{
		return *this = *this - mt;
		}
	Matrix3 operator - (const Matrix3 mt)
		{
		Matrix3 rtv = *this;
		rtv.MATRIX3_BASE_EX_X -= mt.MATRIX3_BASE_EX_X;
		rtv.MATRIX3_BASE_EX_Y -= mt.MATRIX3_BASE_EX_Y;
		rtv.MATRIX3_BASE_EX_Z -= mt.MATRIX3_BASE_EX_Z;

		rtv.MATRIX3_BASE_EY_X -= mt.MATRIX3_BASE_EY_X;
		rtv.MATRIX3_BASE_EY_Y -= mt.MATRIX3_BASE_EY_Y;
		rtv.MATRIX3_BASE_EY_Z -= mt.MATRIX3_BASE_EY_Z;

		rtv.MATRIX3_BASE_EZ_X -= mt.MATRIX3_BASE_EZ_X;
		rtv.MATRIX3_BASE_EZ_Y -= mt.MATRIX3_BASE_EZ_Y;
		rtv.MATRIX3_BASE_EZ_Z -= mt.MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	Matrix3 operator - ()
		{
		Matrix3 rtv = *this;
		rtv.MATRIX3_BASE_EX_X = -MATRIX3_BASE_EX_X;
		rtv.MATRIX3_BASE_EX_Y = -MATRIX3_BASE_EX_Y;
		rtv.MATRIX3_BASE_EX_Z = -MATRIX3_BASE_EX_Z;

		rtv.MATRIX3_BASE_EY_X = -MATRIX3_BASE_EY_X;
		rtv.MATRIX3_BASE_EY_Y = -MATRIX3_BASE_EY_Y;
		rtv.MATRIX3_BASE_EY_Z = -MATRIX3_BASE_EY_Z;

		rtv.MATRIX3_BASE_EZ_X = -MATRIX3_BASE_EZ_X;
		rtv.MATRIX3_BASE_EZ_Y = -MATRIX3_BASE_EZ_Y;
		rtv.MATRIX3_BASE_EZ_Z = -MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	SCALER	Det() const
		{
		return
		( MATRIX3_BASE_EX_X * MATRIX3_BASE_EY_Y * MATRIX3_BASE_EZ_Z  +  MATRIX3_BASE_EX_Y * MATRIX3_BASE_EY_Z * MATRIX3_BASE_EZ_X  +  MATRIX3_BASE_EX_Z * MATRIX3_BASE_EY_X * MATRIX3_BASE_EZ_Y ) -
		( MATRIX3_BASE_EX_Z * MATRIX3_BASE_EY_Y * MATRIX3_BASE_EZ_X  +  MATRIX3_BASE_EX_X * MATRIX3_BASE_EY_Z * MATRIX3_BASE_EZ_Y  +  MATRIX3_BASE_EX_Y * MATRIX3_BASE_EY_X * MATRIX3_BASE_EZ_Z );
		}
	Matrix3 Inv() const
		{
		Matrix3 rtv;
		SCALER det_ = 1 / Det();
		rtv.MATRIX3_BASE_EX_X = Det2(MATRIX3_BASE_EY_Y, MATRIX3_BASE_EZ_Y, MATRIX3_BASE_EY_Z, MATRIX3_BASE_EZ_Z) * det_;
		rtv.MATRIX3_BASE_EX_Y = Det2(MATRIX3_BASE_EZ_Y, MATRIX3_BASE_EX_Y, MATRIX3_BASE_EZ_Z, MATRIX3_BASE_EX_Z) * det_;
		rtv.MATRIX3_BASE_EX_Z = Det2(MATRIX3_BASE_EX_Y, MATRIX3_BASE_EY_Y, MATRIX3_BASE_EX_Z, MATRIX3_BASE_EY_Z) * det_;
			
		rtv.MATRIX3_BASE_EY_X = Det2(MATRIX3_BASE_EY_Z, MATRIX3_BASE_EZ_Z, MATRIX3_BASE_EY_X, MATRIX3_BASE_EZ_X) * det_;
		rtv.MATRIX3_BASE_EY_Y = Det2(MATRIX3_BASE_EZ_Z, MATRIX3_BASE_EX_Z, MATRIX3_BASE_EZ_X, MATRIX3_BASE_EX_X) * det_;
		rtv.MATRIX3_BASE_EY_Z = Det2(MATRIX3_BASE_EX_Z, MATRIX3_BASE_EY_Z, MATRIX3_BASE_EX_X, MATRIX3_BASE_EY_X) * det_;
		
		rtv.MATRIX3_BASE_EZ_X = Det2(MATRIX3_BASE_EY_X, MATRIX3_BASE_EZ_X, MATRIX3_BASE_EY_Y, MATRIX3_BASE_EZ_Y) * det_;
		rtv.MATRIX3_BASE_EZ_Y = Det2(MATRIX3_BASE_EZ_X, MATRIX3_BASE_EX_X, MATRIX3_BASE_EZ_Y, MATRIX3_BASE_EX_Y) * det_;
		rtv.MATRIX3_BASE_EZ_Z = Det2(MATRIX3_BASE_EX_X, MATRIX3_BASE_EY_X, MATRIX3_BASE_EX_Y, MATRIX3_BASE_EY_Y) * det_;
		return rtv;
		}
	Matrix3 Trans() const
		{
		Matrix3 rtv;
		rtv.MATRIX3_BASE_EX_X = MATRIX3_BASE_EX_X;	rtv.MATRIX3_BASE_EX_Y = MATRIX3_BASE_EY_X;	rtv.MATRIX3_BASE_EX_Z = MATRIX3_BASE_EZ_X;
		rtv.MATRIX3_BASE_EY_X = MATRIX3_BASE_EX_Y;	rtv.MATRIX3_BASE_EY_Y = MATRIX3_BASE_EY_Y;	rtv.MATRIX3_BASE_EY_Z = MATRIX3_BASE_EZ_Y;
		rtv.MATRIX3_BASE_EZ_X = MATRIX3_BASE_EX_Z;	rtv.MATRIX3_BASE_EZ_Y = MATRIX3_BASE_EY_Z;	rtv.MATRIX3_BASE_EZ_Z = MATRIX3_BASE_EZ_Z;
		return rtv;
		}
	SCALER ScaleMax()
		{
		SCALER scaleMax = std::max(Ex().Square(), Ey().Square());
		scaleMax = std::max(scaleMax, Ez().Square());
		return SCALER(sqrt(scaleMax));
		}
	};
inline Matrix3 operator * (const SCALER k, const Matrix3& s)
	{
	return (Matrix3)s * k;
	}
inline Vec3& Vec3::operator *= (const Matrix3& mt)
	{
	return (*this) = mt * (*this);
	}
DLLCLASS STREAM_STD__ ostream& operator << (STREAM_STD__ ostream& ostr, const Matrix3& s);
DLLCLASS STREAM_STD__ istream& operator >> (STREAM_STD__ istream& istr, Matrix3& s);
DLLCLASS void binRead(STREAM_STD__ istream& istr, Matrix3&);
DLLCLASS void binWrite(STREAM_STD__ ostream& ostr, const Matrix3&);
DLLCLASS size_t binLen(const Matrix3&);

#endif	//	defined Matrix3

#if defined Affine
//-----------------------------------------------------------------------------
//	Affine
//
class DLLCLASS Affine :public AFFINE_BASE
	{
	public:
	operator AFFINE_BASE&() const
		{
		return *(AFFINE_BASE*) this;
		}
	//	�P�ʃx�N�g���ւ̃A�N�Z�X
	const Vec3 Ex() const
		{
		return Vec3(AFFINE_BASE_EX_X, AFFINE_BASE_EX_Y, AFFINE_BASE_EX_Z);
		}
	void Ex(const Vec3& v)
		{
		AFFINE_BASE_EX_X = v.VEC3_BASE_X;
		AFFINE_BASE_EX_Y = v.VEC3_BASE_Y;
		AFFINE_BASE_EX_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Ey() const
		{
		return Vec3(AFFINE_BASE_EY_X, AFFINE_BASE_EY_Y, AFFINE_BASE_EY_Z);
		}
	void Ey(const Vec3& v)
		{
		AFFINE_BASE_EY_X = v.VEC3_BASE_X;
		AFFINE_BASE_EY_Y = v.VEC3_BASE_Y;
		AFFINE_BASE_EY_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Ez() const
		{
		return Vec3(AFFINE_BASE_EZ_X, AFFINE_BASE_EZ_Y, AFFINE_BASE_EZ_Z);
		}
	void Ez(const Vec3& v)
		{
		AFFINE_BASE_EZ_X = v.VEC3_BASE_X;
		AFFINE_BASE_EZ_Y = v.VEC3_BASE_Y;
		AFFINE_BASE_EZ_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Trn() const
		{
		return Vec3(AFFINE_BASE_POS_X, AFFINE_BASE_POS_Y, AFFINE_BASE_POS_Z);
		}
	void Trn(const Vec3& v)
		{
		AFFINE_BASE_POS_X = v.VEC3_BASE_X;
		AFFINE_BASE_POS_Y = v.VEC3_BASE_Y;
		AFFINE_BASE_POS_Z = v.VEC3_BASE_Z;
		}
	const Vec3 Pos() const {return Trn();}
	void Pos(const Vec3& v)	{Trn(v);}
	SCALER& ExX() {return AFFINE_BASE_EX_X;}
	SCALER& ExY() {return AFFINE_BASE_EX_Y;}
	SCALER& ExZ() {return AFFINE_BASE_EX_Z;}
	SCALER& EyX() {return AFFINE_BASE_EY_X;}
	SCALER& EyY() {return AFFINE_BASE_EY_Y;}
	SCALER& EyZ() {return AFFINE_BASE_EY_Z;}
	SCALER& EzX() {return AFFINE_BASE_EZ_X;}
	SCALER& EzY() {return AFFINE_BASE_EZ_Y;}
	SCALER& EzZ() {return AFFINE_BASE_EZ_Z;}
	SCALER& TrnX() {return AFFINE_BASE_POS_X;}
	SCALER& TrnY() {return AFFINE_BASE_POS_Y;}
	SCALER& TrnZ() {return AFFINE_BASE_POS_Z;}
	SCALER& PosX() {return AFFINE_BASE_POS_X;}
	SCALER& PosY() {return AFFINE_BASE_POS_Y;}
	SCALER& PosZ() {return AFFINE_BASE_POS_Z;}
	//---------------------------------
	//	�������ƍ\�z
	//
	//	�P�ʍs��
	void InitUnit()
		{
		AFFINE_BASE_EX_X = 1;	AFFINE_BASE_EX_Y = 0;	AFFINE_BASE_EX_Z = 0;
		AFFINE_BASE_EY_X = 0;	AFFINE_BASE_EY_Y = 1;	AFFINE_BASE_EY_Z = 0;
		AFFINE_BASE_EZ_X = 0;	AFFINE_BASE_EZ_Y = 0;	AFFINE_BASE_EZ_Z = 1;
		AFFINE_BASE_POS_X = 0;	AFFINE_BASE_POS_Y = 0;	AFFINE_BASE_POS_Z = 0;
		}
	//	���s�ړ�
	void InitTrn(SCALER px, SCALER py, SCALER pz)
		{
		InitUnit();
		AFFINE_BASE_POS_X = px;	AFFINE_BASE_POS_Y = py;	AFFINE_BASE_POS_Z = pz;
		}
	//	x��, y��, �ʒu ���w��
	void InitDirect(Vec3 exi, Vec3 eyi, Vec3 posi=Vec3())
		{
		Ex(exi.Unit());
		Ey(  ( eyi - (eyi*Ex())*Ex() ).Unit()  );
		Ez(Ex() ^ Ey());
		Pos(posi);
		}
	//	axis��, axis++��, �ʒu ���w��
	void InitDirect(Vec3 a, Vec3 b, char axis, Vec3 posi=Vec3());
	//	axis���܂���]
	void InitRot(SCALER th, char axis , Vec3 posi=Vec3());
	//	axis���܂���]
	void InitRot(SCALER th, Vec3 axis , Vec3 posi=Vec3())
		/*  +																	   +
			|u^2+(1-u^2)cos(th)      uv(1-cos(th))-wsin(th)  wu(1-cos(th))+vsin(th)|
		R =	|uv(1-cos(th))+wsin(th)  v^2+(1-v^2)cos(th)      vw(1-cos(th))-usin(th)|
			|wu(1-cos(th))-vsin(th)  vw(1-cos(th))+usin(th)  w^2+(1-w^2)cos(th)    |
			+																	   +*/
		{
			SCALER s = (SCALER)sin(th), c = (SCALER)cos(th);
			SCALER u = axis.VEC3_BASE_X, v = axis.VEC3_BASE_Y, w = axis.VEC3_BASE_Z;
			Ex(Vec3(
				u*u + (SCALER(1)-u*u)*c,
				u*v*(SCALER(1)-c) + w*s,
				w*u*(SCALER(1)-c) - v*s));
			Ey(Vec3(
				u*v*(SCALER(1)-c) - w*s,
				v*v + (SCALER(1)-v*v)*c,
				v*w*(SCALER(1)-c) + u*s));
			Ez(Vec3(
				w*u*(SCALER(1)-c) + v*s,
				v*w*(SCALER(1)-c) - u*s,
				w*w + (SCALER(1)-w*w)*c));
			Pos(posi);
		}
	void InitRot(Vec3 rvec, Vec3 posi=Vec3())
		{
		SCALER size=rvec.Size();
		InitRot(size, rvec/size, posi);
		}
	Affine(){InitUnit();}
	Affine(SCALER px, SCALER py, SCALER pz){InitTrn(px, py, pz);}
	Affine(Vec3 exi, Vec3 eyi, Vec3 posi=Vec3()){InitDirect(exi, eyi, posi);}
	Affine(Vec3 a, Vec3 b, char axis, Vec3 posi=Vec3()) {InitDirect(a, b, axis, posi);}
	Affine(SCALER th, char axis , Vec3 posi=Vec3()) {InitRot(th, axis , posi);}
	Affine(SCALER th, Vec3 axis , Vec3 posi=Vec3()){InitRot(th, axis.Unit(), posi);}
#ifdef Matrix3
	Affine(const Matrix3& m, const Vec3 posi=Vec3())
		{
		AFFINE_BASE_EX_X = m.MATRIX3_BASE_EX_X;
		AFFINE_BASE_EX_Y = m.MATRIX3_BASE_EX_Y;
		AFFINE_BASE_EX_Z = m.MATRIX3_BASE_EX_Z;
		AFFINE_BASE_EY_X = m.MATRIX3_BASE_EY_X;
		AFFINE_BASE_EY_Y = m.MATRIX3_BASE_EY_Y;
		AFFINE_BASE_EY_Z = m.MATRIX3_BASE_EY_Z;
		AFFINE_BASE_EZ_X = m.MATRIX3_BASE_EZ_X;
		AFFINE_BASE_EZ_Y = m.MATRIX3_BASE_EZ_Y;
		AFFINE_BASE_EZ_Z = m.MATRIX3_BASE_EZ_Z;
		AFFINE_BASE_POS_X = posi.VEC3_BASE_X;
		AFFINE_BASE_POS_Y = posi.VEC3_BASE_Y;
		AFFINE_BASE_POS_Z = posi.VEC3_BASE_Z;
		}
	operator Matrix3() const
		{
		Matrix3 m;
		m.MATRIX3_BASE_EX_X = AFFINE_BASE_EX_X;
		m.MATRIX3_BASE_EX_Y = AFFINE_BASE_EX_Y;
		m.MATRIX3_BASE_EX_Z = AFFINE_BASE_EX_Z;
		m.MATRIX3_BASE_EY_X = AFFINE_BASE_EY_X;
		m.MATRIX3_BASE_EY_Y = AFFINE_BASE_EY_Y;
		m.MATRIX3_BASE_EY_Z = AFFINE_BASE_EY_Z;
		m.MATRIX3_BASE_EZ_X = AFFINE_BASE_EZ_X;
		m.MATRIX3_BASE_EZ_Y = AFFINE_BASE_EZ_Y;
		m.MATRIX3_BASE_EZ_Z = AFFINE_BASE_EZ_Z;
		return m;
		}
#endif
	//---------------------------------
	//	���Z
	//
	bool operator == (const Affine& af) const
		{
		return
		AFFINE_BASE_EX_X == af.AFFINE_BASE_EX_X &&
		AFFINE_BASE_EX_Y == af.AFFINE_BASE_EX_Y &&
		AFFINE_BASE_EX_Z == af.AFFINE_BASE_EX_Z &&
		AFFINE_BASE_EY_X == af.AFFINE_BASE_EY_X &&
		AFFINE_BASE_EY_Y == af.AFFINE_BASE_EY_Y &&
		AFFINE_BASE_EY_Z == af.AFFINE_BASE_EY_Z &&
		AFFINE_BASE_EZ_X == af.AFFINE_BASE_EZ_X &&
		AFFINE_BASE_EZ_Y == af.AFFINE_BASE_EZ_Y &&
		AFFINE_BASE_EZ_Z == af.AFFINE_BASE_EZ_Z &&
		AFFINE_BASE_POS_X == af.AFFINE_BASE_POS_X &&
		AFFINE_BASE_POS_Y == af.AFFINE_BASE_POS_Y &&
		AFFINE_BASE_POS_Z == af.AFFINE_BASE_POS_Z;
		}
	Vec3 Rot(const Vec3& v) const	//��]�g��ϊ��݂̂��s��
		{
		return Vec3(
			AFFINE_BASE_EX_X * v.VEC3_BASE_X + AFFINE_BASE_EY_X * v.VEC3_BASE_Y + AFFINE_BASE_EZ_X * v.VEC3_BASE_Z,
			AFFINE_BASE_EX_Y * v.VEC3_BASE_X + AFFINE_BASE_EY_Y * v.VEC3_BASE_Y + AFFINE_BASE_EZ_Y * v.VEC3_BASE_Z,
			AFFINE_BASE_EX_Z * v.VEC3_BASE_X + AFFINE_BASE_EY_Z * v.VEC3_BASE_Y + AFFINE_BASE_EZ_Z * v.VEC3_BASE_Z
			);
		}
	Affine Rot(Affine af) const	//��]�g��ϊ��݂̂��s��
		{
		Affine rtv;
		rtv.AFFINE_BASE_EX_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EX_Z;
		rtv.AFFINE_BASE_EX_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EX_Z;
		rtv.AFFINE_BASE_EX_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EY_Z;
		rtv.AFFINE_BASE_EY_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EY_Z;
		rtv.AFFINE_BASE_EY_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EZ_Z;
		rtv.AFFINE_BASE_EZ_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EZ_Z;
		rtv.AFFINE_BASE_EZ_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EZ_Z;
		
		rtv.AFFINE_BASE_POS_X = af.AFFINE_BASE_POS_X;
		rtv.AFFINE_BASE_POS_Y = af.AFFINE_BASE_POS_Y;
		rtv.AFFINE_BASE_POS_Z = af.AFFINE_BASE_POS_Z;
		return rtv;
		}
	Vec3 operator * (const Vec3& v) const
		{
		return Rot(v) + Pos();
		}
	Affine operator *= (const Affine& af)
		{
		return *this = *this * af;
		}
	Affine operator * (const Affine& af) const
		{
		Affine rtv;
		rtv.AFFINE_BASE_EX_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EX_Z;
		rtv.AFFINE_BASE_EX_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EX_Z;
		rtv.AFFINE_BASE_EX_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EX_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EX_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EY_Z;
		rtv.AFFINE_BASE_EY_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EY_Z;
		rtv.AFFINE_BASE_EY_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EY_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EY_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X = AFFINE_BASE_EX_X*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_X*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_X*af.AFFINE_BASE_EZ_Z;
		rtv.AFFINE_BASE_EZ_Y = AFFINE_BASE_EX_Y*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_Y*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_Y*af.AFFINE_BASE_EZ_Z;
		rtv.AFFINE_BASE_EZ_Z = AFFINE_BASE_EX_Z*af.AFFINE_BASE_EZ_X + AFFINE_BASE_EY_Z*af.AFFINE_BASE_EZ_Y + AFFINE_BASE_EZ_Z*af.AFFINE_BASE_EZ_Z;

		rtv.Pos(Rot(af.Pos()) + Pos());
		return rtv;
		}
	Affine operator *= (const SCALER k)
		{
		return *this = *this * k;
		}
	Affine operator * (const SCALER k) const
		{
		Affine rtv;
		rtv.AFFINE_BASE_EX_X = k * AFFINE_BASE_EX_X;
		rtv.AFFINE_BASE_EX_Y = k * AFFINE_BASE_EX_Y;
		rtv.AFFINE_BASE_EX_Z = k * AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X = k * AFFINE_BASE_EY_X;
		rtv.AFFINE_BASE_EY_Y = k * AFFINE_BASE_EY_Y;
		rtv.AFFINE_BASE_EY_Z = k * AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X = k * AFFINE_BASE_EZ_X;
		rtv.AFFINE_BASE_EZ_Y = k * AFFINE_BASE_EZ_Y;
		rtv.AFFINE_BASE_EZ_Z = k * AFFINE_BASE_EZ_Z;

		rtv.AFFINE_BASE_POS_X = AFFINE_BASE_POS_X;
		rtv.AFFINE_BASE_POS_Y = AFFINE_BASE_POS_Y;
		rtv.AFFINE_BASE_POS_Z = AFFINE_BASE_POS_Z;
		return rtv;
		}
	Affine operator += (const Affine& af)
		{
		return *this = *this + af;
		}
	Affine operator + (const Affine af)
		{
		Affine rtv = *this;
		rtv.AFFINE_BASE_POS_X += af.AFFINE_BASE_POS_X;
		rtv.AFFINE_BASE_POS_Y += af.AFFINE_BASE_POS_Y;
		rtv.AFFINE_BASE_POS_Z += af.AFFINE_BASE_POS_Z;

		rtv.AFFINE_BASE_EX_X += af.AFFINE_BASE_EX_X;
		rtv.AFFINE_BASE_EX_Y += af.AFFINE_BASE_EX_Y;
		rtv.AFFINE_BASE_EX_Z += af.AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X += af.AFFINE_BASE_EY_X;
		rtv.AFFINE_BASE_EY_Y += af.AFFINE_BASE_EY_Y;
		rtv.AFFINE_BASE_EY_Z += af.AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X += af.AFFINE_BASE_EZ_X;
		rtv.AFFINE_BASE_EZ_Y += af.AFFINE_BASE_EZ_Y;
		rtv.AFFINE_BASE_EZ_Z += af.AFFINE_BASE_EZ_Z;
		return rtv;
		}
	Affine operator -= (const Affine& af)
		{
		return *this = *this - af;
		}
	Affine operator - (const Affine af)
		{
		Affine rtv = *this;
		rtv.AFFINE_BASE_POS_X -= af.AFFINE_BASE_POS_X;
		rtv.AFFINE_BASE_POS_Y -= af.AFFINE_BASE_POS_Y;
		rtv.AFFINE_BASE_POS_Z -= af.AFFINE_BASE_POS_Z;

		rtv.AFFINE_BASE_EX_X -= af.AFFINE_BASE_EX_X;
		rtv.AFFINE_BASE_EX_Y -= af.AFFINE_BASE_EX_Y;
		rtv.AFFINE_BASE_EX_Z -= af.AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X -= af.AFFINE_BASE_EY_X;
		rtv.AFFINE_BASE_EY_Y -= af.AFFINE_BASE_EY_Y;
		rtv.AFFINE_BASE_EY_Z -= af.AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X -= af.AFFINE_BASE_EZ_X;
		rtv.AFFINE_BASE_EZ_Y -= af.AFFINE_BASE_EZ_Y;
		rtv.AFFINE_BASE_EZ_Z -= af.AFFINE_BASE_EZ_Z;
		return rtv;
		}
	Affine operator -()
		{
		Affine rtv = *this;
		rtv.AFFINE_BASE_POS_X = -AFFINE_BASE_POS_X;
		rtv.AFFINE_BASE_POS_Y = -AFFINE_BASE_POS_Y;
		rtv.AFFINE_BASE_POS_Z = -AFFINE_BASE_POS_Z;

		rtv.AFFINE_BASE_EX_X = -AFFINE_BASE_EX_X;
		rtv.AFFINE_BASE_EX_Y = -AFFINE_BASE_EX_Y;
		rtv.AFFINE_BASE_EX_Z = -AFFINE_BASE_EX_Z;

		rtv.AFFINE_BASE_EY_X = -AFFINE_BASE_EY_X;
		rtv.AFFINE_BASE_EY_Y = -AFFINE_BASE_EY_Y;
		rtv.AFFINE_BASE_EY_Z = -AFFINE_BASE_EY_Z;

		rtv.AFFINE_BASE_EZ_X = -AFFINE_BASE_EZ_X;
		rtv.AFFINE_BASE_EZ_Y = -AFFINE_BASE_EZ_Y;
		rtv.AFFINE_BASE_EZ_Z = -AFFINE_BASE_EZ_Z;
		return rtv;
		}
	SCALER	Det() const
		{
		return
		( AFFINE_BASE_EX_X * AFFINE_BASE_EY_Y * AFFINE_BASE_EZ_Z  +  AFFINE_BASE_EX_Y * AFFINE_BASE_EY_Z * AFFINE_BASE_EZ_X  +  AFFINE_BASE_EX_Z * AFFINE_BASE_EY_X * AFFINE_BASE_EZ_Y ) -
		( AFFINE_BASE_EX_Z * AFFINE_BASE_EY_Y * AFFINE_BASE_EZ_X  +  AFFINE_BASE_EX_X * AFFINE_BASE_EY_Z * AFFINE_BASE_EZ_Y  +  AFFINE_BASE_EX_Y * AFFINE_BASE_EY_X * AFFINE_BASE_EZ_Z );
		}
	Affine Inv() const
		{
		Affine rtv;
		SCALER det_ = 1 / Det();
		rtv.AFFINE_BASE_EX_X = Det2(AFFINE_BASE_EY_Y, AFFINE_BASE_EZ_Y, AFFINE_BASE_EY_Z, AFFINE_BASE_EZ_Z) * det_;
		rtv.AFFINE_BASE_EX_Y = Det2(AFFINE_BASE_EZ_Y, AFFINE_BASE_EX_Y, AFFINE_BASE_EZ_Z, AFFINE_BASE_EX_Z) * det_;
		rtv.AFFINE_BASE_EX_Z = Det2(AFFINE_BASE_EX_Y, AFFINE_BASE_EY_Y, AFFINE_BASE_EX_Z, AFFINE_BASE_EY_Z) * det_;
			
		rtv.AFFINE_BASE_EY_X = Det2(AFFINE_BASE_EY_Z, AFFINE_BASE_EZ_Z, AFFINE_BASE_EY_X, AFFINE_BASE_EZ_X) * det_;
		rtv.AFFINE_BASE_EY_Y = Det2(AFFINE_BASE_EZ_Z, AFFINE_BASE_EX_Z, AFFINE_BASE_EZ_X, AFFINE_BASE_EX_X) * det_;
		rtv.AFFINE_BASE_EY_Z = Det2(AFFINE_BASE_EX_Z, AFFINE_BASE_EY_Z, AFFINE_BASE_EX_X, AFFINE_BASE_EY_X) * det_;
		
		rtv.AFFINE_BASE_EZ_X = Det2(AFFINE_BASE_EY_X, AFFINE_BASE_EZ_X, AFFINE_BASE_EY_Y, AFFINE_BASE_EZ_Y) * det_;
		rtv.AFFINE_BASE_EZ_Y = Det2(AFFINE_BASE_EZ_X, AFFINE_BASE_EX_X, AFFINE_BASE_EZ_Y, AFFINE_BASE_EX_Y) * det_;
		rtv.AFFINE_BASE_EZ_Z = Det2(AFFINE_BASE_EX_X, AFFINE_BASE_EY_X, AFFINE_BASE_EX_Y, AFFINE_BASE_EY_Y) * det_;
		
		rtv.Pos(-rtv.Rot(Pos()));
		return rtv;
		}
	Affine LookAt(Vec3 posi);
	SCALER ScaleMax() const
		{
		SCALER scaleMax = std::max(Ex().Square(), Ey().Square());
		scaleMax = std::max(scaleMax, Ez().Square());
		return SCALER(sqrt(scaleMax));
		}
	};
inline Affine operator * (const SCALER k, const Affine& s)
	{
	return (Affine)s * k;
	}
inline Vec3& Vec3::operator *= (const Affine& af)
	{
	return (*this) = af * (*this);
	}
DLLCLASS STREAM_STD__ ostream& operator << (STREAM_STD__ ostream& ostr, const Affine& s);
DLLCLASS STREAM_STD__ istream& operator >> (STREAM_STD__ istream& istr, Affine& s);
DLLCLASS void binRead(STREAM_STD__ istream& istr, Affine&);
DLLCLASS void binWrite(STREAM_STD__ ostream& ostr, const Affine&);
DLLCLASS size_t binLen(const Affine&);

#endif	//	defined Affine

END_NAMESPACE_HASE

#endif	//	UNDEF_ALL_AFFINEB
