#ifdef DEBUG_STREAM
#define debStr DEBUG_STREAM
#define DEBUG
#endif

BEGIN_NAMESPACE_HASE
using namespace std;
#define EPSILON 10E-8f
//-----------------------------------------------------------------------------
//	CMotionMaterial
//
CMotionMaterial mmatDef;
CMotionMaterial::CMotionMaterial()
	{
	moveFriction = SCALER(0.2);
	stopFriction = SCALER(0.4);
	bound = SCALER(0.7);
	elast = SCALER(1);
	damper = SCALER(1);
	}
CMotionMaterial::~CMotionMaterial()
	{
	}
CMotionMaterial* CMotionMaterial::Clone()
	{
	CMotionMaterial* pM = new CMotionMaterial(*this);
	return pM;
	}
CMotionMaterial& CMotionMaterial::Def()
	{
	return mmatDef;
	}
//-----------------------------------------------------------------------------
//	CVisual
//
int CVisual::count;
CIsectCheckers* CVisual::pIsectCheckers;
CVisual::CVisual()
	{
	radius = SCALER(0);
	colPrec = MESH;
	pMotionMtr = NULL;
	count ++;
	}
CVisual::CVisual(CVisual& v)
	{
	radius = v.radius;
	colPrec = v.colPrec;
	pMotionMtr = v.pMotionMtr ? v.pMotionMtr->Clone() : NULL;
	count ++;
	}
CVisual::~CVisual()
	{
	delete pMotionMtr;
	count --;
	if (count == 0)
		{
		delete pIsectCheckers;
		pIsectCheckers = NULL;
		}
	}
CIsectCheckers& CVisual::IsectCheckers()
	{
	if (!pIsectCheckers) pIsectCheckers = new CIsectCheckers;
	return *pIsectCheckers;
	}
void CVisual::MotMtr(CMotionMaterial& m)
	{
	delete pMotionMtr;
	pMotionMtr = NULL;
	pMotionMtr = m.Clone();
	}
//-----------------------------------------------------------------------------
//	CPlane
//
static int planeVisualID;
int& CPlane::VisualID()
	{
	return planeVisualID;
	}
CPlane::CPlane()
	{
	}
CPlane::~CPlane()
	{
	}
//-----------------------------------------------------------------------------
//	CSphere
//
static int sphereVisualID;
int& CSphere::VisualID()
	{
	return sphereVisualID;
	}
CSphere::CSphere()
	{
	if (!VisualID())
		{
		IsectCheckers().Set(FindIsectPlane, this, &CPlane());
		IsectCheckers().Set(FindIsectSphere, this, this);
		}
	}
CSphere::~CSphere()
	{
	}
bool CSphere::FindIsectPlane(CIsects& colsSph, CVisual* visSph, const Affine& afSph, CFrame* pFrSph,
							 CIsects& colsPln, CVisual* visPln, const Affine& afPln, CFrame* pFrPln)
	{
	CSphere* sph = (CSphere*) visSph;
	CPlane* pln = (CPlane*) visPln;
	SCALER rSph = sph->radius * afSph.ScaleMax();
	Vec3 normal = afPln.Ez();
	Vec3 pos = afPln.Pos();
	Vec3 center = afSph.Pos();
	Vec3 l = center - pos;
	SCALER h = l * normal;
	if (h > rSph) return false;
	CIsect* colSph=new CIsect;
	CIsect* colPln=new CIsect;

	colSph->normal = -normal;
	colSph->pos = center - normal * rSph;
	colSph->ct = CIsect::SOLID;
	colSph->pFrame = pFrSph;
	colSph->pVisual = sph;
	colSph->overlap = rSph - h;
	colsSph.Add(colSph);

	colPln->normal = normal;
	colPln->pos = center - normal * h;
	colPln->ct = CIsect::SOLID;
	colPln->pFrame = pFrPln;
	colPln->pVisual = pln;
	colPln->overlap = rSph - h;
 	colsPln.Add(colPln);
	colPln->Pair(colSph);
	return true;
	}
bool CSphere::FindIsectSphere(CIsects& cols1, CVisual* v1, const Affine& af1, CFrame* pFr1,
							  CIsects& cols2, CVisual* v2, const Affine& af2, CFrame* pFr2)
	{
	SCALER sc1 = af1.ScaleMax();
	SCALER sc2 = af2.ScaleMax();
	Vec3 v3L = af2.Pos() - af1.Pos();
	SCALER ll = v3L.Square();
	SCALER r1 = sc1*v1->radius;
	SCALER r2 = sc2*v2->radius;
	SCALER r =  r1+r2;
	SCALER rr = Square(r);
	if (ll <= rr)
		{
		CIsect* colV1=new CIsect;
		CIsect* colV2=new CIsect;
		REAL l = (SCALER)sqrt(ll);
		colV1->normal = v3L/l;
		colV1->pos = af1.Pos() + r1*colV1->normal;
		colV1->ct = CIsect::SOLID;
		colV1->pFrame = pFr1;
		colV1->pVisual = v1;
		colV1->overlap = r - l;
		cols1.Add(colV1);

		colV2->normal = -colV1->normal;
		colV2->pos = af2.Pos() + r2*colV2->normal;
		colV2->ct = CIsect::SOLID;
		colV2->pFrame = pFr2;
		colV2->pVisual = v2;
		colV2->overlap = r - l;
		cols2.Add(colV2);
		colV1->Pair(colV2);
		return true;
		}
	return false;
	}

//-----------------------------------------------------------------------------
//	CDisc
//
static int discVisualID;
int& CDisc::VisualID()
	{
	return discVisualID;
	}
CDisc::CDisc()
	{
	normal = Vec3();
	if (!VisualID())
		{
		IsectCheckers().Set(FindIsectSphere, this, &CSphere());
		IsectCheckers().Set(FindIsectDisc, this, this);
		}
	}
CDisc::~CDisc()
	{
	}
bool CDisc::FindIsectSphere(CIsects& cols1, CVisual* v1, const Affine& afDisc, CFrame* pFr1,
							  CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	CDisc* disc = (CDisc*)v1;
	CSphere* sph = (CSphere*)v2;
	SCALER rDisc = afDisc.ScaleMax() * disc->radius;
	SCALER rSph = afSph.ScaleMax() * sph->radius;
	Vec3 discNormal = afDisc.Rot(disc->normal);
	SCALER h = discNormal * (afSph.Pos() - afDisc.Pos());
	if (ABS(h) > rSph) return false;
	if (h<0)
		{
		discNormal = -discNormal;
		h = -h;
		}
	Vec3 hpDisc = afSph.Pos() - h*discNormal;
	if ((hpDisc-afDisc.Pos()).Square() > Square(rDisc))
		{
		SCALER dd = (afDisc.Pos() - afSph.Pos()).Square();
		SCALER l = SCALER(sqrt(dd-h*h));
		SCALER rsrs = Square(l-rDisc) + h*h;
		if (rsrs > rSph*rSph) return false;
		hpDisc = afDisc.Pos() + (hpDisc - afDisc.Pos()).Unit() * rDisc;
		discNormal = (afSph.Pos() - hpDisc).Unit();
		}
	Vec3 hpSph = afSph.Pos() - rSph * discNormal;
	CIsect* colD1=new CIsect;
	CIsect* colV2=new CIsect;
	colD1->normal = discNormal;
	colD1->pos = hpDisc;
	colD1->ct = CIsect::SOLID;
	colD1->pFrame = pFr1;
	colD1->pVisual = disc;
	colD1->overlap = (hpDisc-hpSph).Size();
	cols1.Add(colD1);

	colV2->normal = -discNormal;
	colV2->pos = hpSph;
	colV2->ct = CIsect::SOLID;
	colV2->pFrame = pFr2;
	colV2->pVisual = v2;
	colV2->overlap = colD1->overlap;
	cols2.Add(colV2);
	colD1->Pair(colV2);
	return true;
	}
bool CDisc::FindIsectDisc(CIsects& cols1, CVisual* v1, const Affine& afDisc, CFrame* pFr1,
						  CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	return false;
	}
//-----------------------------------------------------------------------------
//	CRect
//
static int rectVisualID;
int& CRect::VisualID()
	{
	return rectVisualID;
	}
CRect::CRect(const Vec2& rect)
	{
	rc = rect;
	if (!VisualID())
		{
		IsectCheckers().Set(FindIsectSphere, this, &CSphere());
		}
	}
CRect::~CRect()
	{
	}
bool CRect::FindIsectSphere(CIsects& cols1, CVisual* v1, const Affine& afRect, CFrame* pFr1,
						  CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	CRect* rect = (CRect*)v1;
	CSphere* sph = (CSphere*)v2;
	SCALER rSph = afSph.ScaleMax() * sph->radius;
	Vec2& rc = rect->rc;
	Vec3 lc;	//	�����`���猩�����̒��S(localCenter)
	Vec3 delta = afSph.Pos() - afRect.Pos();
	lc.z = delta * afRect.Ez();
	if (ABS(lc.z) > rSph) return false;
	lc.x = delta * afRect.Ex();
	if (lc.x < -rSph || rc.x+rSph < lc.x) return false;
	lc.y = delta * afRect.Ey();
	if (lc.y < -rSph || rc.y+rSph < lc.y) return false;
	//	���a�𑫂��������`�ɂ͓����Ă���
	Vec3 hpRect;
	Vec3 rectN;
	Vec3 hpSph;

	Vec2 pos;	//	�����`���̏Փ˓_�̈ʒu(�����`���W�n)
	if (0 <=lc.x && lc.x <= rc.x)		//	x�����͒����`�ɓ����Ă���
		{
		pos.x = lc.x;
		if (0 <=lc.y && lc.y <= rc.y)	//	y�����������`�ɓ����Ă���
			pos.y = lc.y;
		else if (lc.y < 0)
			{
			if (Square(lc.y) + Square(lc.z) > Square(rSph)) return false;
			pos.y = 0;
			}
		else
			{
			if (Square(lc.y-rc.y) + Square(lc.z) > Square(rSph)) return false;
			pos.y = rc.y;
			}
		}
	else	//	x�����͒����`�ɓ����Ă��Ȃ�
		{
		if (lc.x < 0) pos.x = 0;
		else pos.x = rc.x;
		if (0 <=lc.y && lc.y <= rc.y)	//	y�����͒����`�ɓ����Ă���
			{
			if (Square(lc.x-pos.x) + Square(lc.z>0?lc.z:0) > Square(rSph)) return false;
				pos.y = lc.y;
			}
		else							//	�ǂ���������Ă��Ȃ�
			{
			if (lc.y < 0) pos.y = 0;
			else pos.y = rc.y;
			if (Square(lc.x-pos.x) + Square(lc.y-pos.y) + Square(lc.z>0?lc.z:0) > Square(rSph)) return false;
			}
		}
	hpRect = afRect.Pos() + afRect.Ex() * pos.x + afRect.Ey() * pos.y;
	if (lc.z < 0) hpRect += lc.z * afRect.Ez();
	rectN = (afSph.Pos() - hpRect).Unit();
	hpSph = afSph.Pos() - rectN * rSph;
	CIsect* colR1=new CIsect;
	CIsect* colS2=new CIsect;
	colR1->normal = rectN;
	colR1->pos = hpRect;
	colR1->ct = CIsect::SOLID;
	colR1->pFrame = pFr1;
	colR1->pVisual = rect;
	colR1->overlap = (hpRect-hpSph).Size();
	cols1.Add(colR1);

	colS2->normal = -rectN;
	colS2->pos = hpSph;
	colS2->ct = CIsect::SOLID;
	colS2->pFrame = pFr2;
	colS2->pVisual = v2;
	colS2->overlap = colR1->overlap;
	cols2.Add(colS2);
	colR1->Pair(colS2);
	return true;
	}
//-----------------------------------------------------------------------------
//	CBox
//
static int boxVisualID;
int& CBox::VisualID()
	{
	return boxVisualID;
	}
CBox::CBox(const Vec3& b)
	{
	box = b;
	if (!VisualID())
		{
		IsectCheckers().Set(FindIsectSphere, this, &CSphere());
		IsectCheckers().Set(FindIsectPlane, this, &CPlane());
		}
	}
CBox::~CBox()
	{
	}
bool CBox::FindIsectPlane(CIsects& cols1, CVisual* v1, const Affine& afBox, CFrame* pFr1,
						  CIsects& cols2, CVisual* v2, const Affine& afPln, CFrame* pFr2)
	{
	int i;
	CBox* box = (CBox*)v1;
	CPlane* pln = (CPlane*)v2;
	Vec3 vtx[8];
	vtx[1] = Vec3(box->box.x, 0, 0);
	vtx[2] = Vec3(0, box->box.y, 0);
	vtx[3] = Vec3(0, 0, box->box.z);
	vtx[4] = Vec3(box->box.x, box->box.y, 0);
	vtx[5] = Vec3(0, box->box.y, box->box.z);
	vtx[6] = Vec3(box->box.x, 0, box->box.z);
	vtx[7] = box->box;
	for(i=0; i<8; i++) vtx[i] = afBox * vtx[i];
	Vec3 n = afPln.Ez();
	Vec3 p = afPln.Pos();
	REAL overLap[8];
	int nCol = 0;
	REAL sumOverlap=0;
	Vec3 hitPos;
	for(i=0; i<8; i++)
		{
		overLap[i] = - (vtx[i]-p) * n;
		if (overLap[i] >= 0)
			{
			nCol ++;
			sumOverlap += overLap[i];
			hitPos += vtx[i] * overLap[i];
			}
		}
	if (nCol == 0) return false;
	if (sumOverlap >  EPSILON)
		{
		hitPos = hitPos / sumOverlap;
		}
	else
		{
		for(i=0; i<8; i++)
			if (overLap[i]>=0) hitPos += vtx[i];
		hitPos = hitPos / nCol;
		}
	CIsect* colB1=new CIsect;
	CIsect* colP2=new CIsect;
	REAL ovl = (p - hitPos)*n;
	colP2->normal = n;
	colP2->pos = hitPos + ovl*n;
	colP2->ct = CIsect::SOLID;
	colP2->pFrame = pFr2;
	colP2->pVisual = pln;
	colP2->overlap = ovl;
	cols2.Add(colP2);

	colB1->normal = -n;
	colB1->pos = hitPos;
	colB1->ct = CIsect::SOLID;
	colB1->pFrame = pFr1;
	colB1->pVisual = box;
	colB1->overlap = ovl;
	cols1.Add(colB1);
	colB1->Pair(colP2);
	return true;
	}
bool CBox::FindIsectSphere(CIsects& cols1, CVisual* v1, const Affine& afBox, CFrame* pFr1,
						  CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	CBox* box = (CBox*)v1;
	CSphere* sph = (CSphere*)v2;
	SCALER rSph = afSph.ScaleMax() * sph->radius;
	Vec3& b = box->box;
	Affine afBoxInv = afBox.Inv();
	Vec3 lc = afBoxInv * afSph.Pos();	//	local center
	SCALER lRSph = afBoxInv.ScaleMax() * rSph;
	Vec3 lim0 = Vec3(-lRSph, -lRSph, -lRSph);
	Vec3 lim1 = Vec3();
	Vec3 lim2 = b;
	Vec3 lim3 = b + Vec3(lRSph, lRSph, lRSph);
	if (lc.x < lim0.x || lc.y < lim0.y || lc.z < lim0.z
		|| lc.x > lim3.x || lc.y > lim3.y || lc.z > lim3.z) return false;
	int area=0;
	if (lc.x < lim1.x) area += 0;
	else if (lc.x <= lim2.x) area += 1;
	else area += 2;
	if (lc.y < lim1.y) area += 3*0;
	else if (lc.y <= lim2.y) area += 3*1;
	else area += 3*2;
	if (lc.z < lim1.z) area += 3*3*0;
	else if (lc.z <= lim2.z) area += 3*3*1;
	else area += 3*3*2;
	enum ColType {POINT, LINE, PLANE, INSIDE};
	static int colType[27] = 
		{
		POINT,	LINE,	POINT,
		LINE,	PLANE,	LINE,
		POINT,	LINE,	POINT,

		LINE,	PLANE,	LINE,
		PLANE,	INSIDE,	PLANE,
		LINE,	PLANE,	LINE,

		POINT,	LINE,	POINT,
		LINE,	PLANE,	LINE,
		POINT,	LINE,	POINT};
#define X 1
#define Y 2
#define Z 4
#define N 0
	static int axis[27] = 
		{
		N,	X,	N,
		Y,	-Z,	Y,
		N,	X,	N,

		Z,	-Y,	Z,
		-X,	N,	+X,
		Z,	+Y,	Z,

		N,	X,	N,
		Y,	+Z,	Y,
		N,	X,	N
		};
	static int value[27] = 
		{
		0,	0,	X,
		0,	0,	X,
		Y,	Y,	X|Y,

		0,	0,	X,
		0,	0,	X,
		Y,	Y,	X|Y,

		Z,	Z,	Z|X,
		Z,	Z,	Z|X,
		Z|Y,Z|Y,Z|X|Y
		};
	Vec3 boxNormal;
	Vec3 boxColPos;
	REAL dist;
	if (colType[area] == INSIDE)
		{
		//	���ɓ����Ă���ꍇ�A1�ԋ߂��̕��ʂɐU�蕪����
		Vec3 b_lc = b - lc;
		bool x=false;
		bool y=false;
		bool z=false;
		Vec3 nearest;
		if (b_lc.x < lc.x) 
			{
			x = true;
			nearest.x = b_lc.x;
			}
		else nearest.x = lc.x;
		if (b_lc.y < lc.y)
			{
			y = true;
			nearest.y = b_lc.y;
			}
		else nearest.y = lc.y;
		if (b_lc.z < lc.z)
			{
			z = true;
			nearest.z = b_lc.z;
			}
		else nearest.z = lc.z;
		if (nearest.x < nearest.z)
			{
			if (nearest.x < nearest.y) area = x ? 14 : 12;
			else area = y ? 16 : 10;
			}
		else
			{
			if (nearest.z < nearest.y) area = z ? 22 : 4;
			else area = y ? 16 : 10;
			}
		}
	if (colType[area] == PLANE)
		{
		if (axis[area] == -X)
			{
			boxNormal = -afBox.Ex();
			boxColPos = afBox * Vec3(0, lc.y, lc.z);
			dist = -lc.x;
			}
		else if (axis[area] == X)
			{
			boxNormal = afBox.Ex();
			boxColPos = afBox * Vec3(b.x, lc.y, lc.z);
			dist = lc.x - b.x;
			}
		else if (axis[area] == -Y)
			{
			boxNormal = -afBox.Ey();
			boxColPos = afBox * Vec3(lc.x, 0, lc.z);
			dist = -lc.y;
			}
		else if (axis[area] == Y)
			{
			boxNormal = afBox.Ey();
			boxColPos = afBox * Vec3(lc.x, b.y, lc.z);
			dist = lc.y - b.y;
			}
		else if (axis[area] == -Z)
			{
			boxNormal = -afBox.Ez();
			boxColPos = afBox * Vec3(lc.x, lc.y, 0);
			dist = -lc.z;
			}
		else if (axis[area] == Z)
			{
			boxNormal = afBox.Ez();
			boxColPos = afBox * Vec3(lc.x, lc.y, b.z);
			dist = lc.z - b.z;
			}
		}
	else if (colType[area] == LINE)
		{
		Vec3 linePos;
		if (value[area] & X) linePos.x = b.x;
		if (value[area] & Y) linePos.y = b.y;
		if (value[area] & Z) linePos.z = b.z;
		if (axis[area]==X)
			{
			boxNormal = lc - linePos;
			boxNormal.x = 0;
			dist = boxNormal.Size();
			boxNormal *= REAL(1)/dist;
			boxColPos = linePos + Vec3(lc.x, 0, 0);
			}
		else if (axis[area]==Y)
			{
			boxNormal = lc - linePos;
			boxNormal.y = 0;
			dist = boxNormal.Size();
			boxNormal *= REAL(1)/dist;
			boxColPos = linePos + Vec3(0, lc.y, 0);
			}
		else if (axis[area]==Z)
			{
			boxNormal = lc - linePos;
			boxNormal.z = 0;
			dist = boxNormal.Size();
			boxNormal *= REAL(1)/dist;
			boxColPos = linePos + Vec3(0, 0, lc.z);
			}
		boxNormal = afBox.Rot(boxNormal);
		boxColPos = afBox * (boxColPos);
		}
	else
		{
		Vec3 pointPos;
		if (value[area] & X) pointPos.x = b.x;
		if (value[area] & Y) pointPos.y = b.y;
		if (value[area] & Z) pointPos.z = b.z;
		boxNormal = lc - pointPos;
		dist = boxNormal.Size();
		boxNormal *= REAL(1)/dist;
		boxColPos = pointPos;
		boxNormal = afBox.Rot(boxNormal);
		boxColPos = afBox * (boxColPos);
		}
	dist *= afBox.ScaleMax();
	if (dist > rSph) return false;
	CIsect* colB1=new CIsect;
	CIsect* colS2=new CIsect;
	colB1->normal = boxNormal;
	colB1->pos = boxColPos;
	colB1->ct = CIsect::SOLID;
	colB1->pFrame = pFr1;
	colB1->pVisual = box;
	colB1->overlap = rSph - dist;
	cols1.Add(colB1);

	colS2->normal = -boxNormal;
	colS2->pos = afSph.Pos() + colS2->normal * rSph;
	colS2->ct = CIsect::SOLID;
	colS2->pFrame = pFr2;
	colS2->pVisual = v2;
	colS2->overlap = colB1->overlap;
	cols2.Add(colS2);
	colB1->Pair(colS2);
	return true;
	}
//-----------------------------------------------------------------------------
//	CMesh
//
static int meshVisualID;
int& CMesh::VisualID()
	{
	return meshVisualID;
	}
CMesh::CMesh()
	{
	radius = SCALER(0);
	if (!meshVisualID)
		{
		IsectCheckers().Set(FindIsectSphere, this, &CSphere());
		IsectCheckers().Set(FindIsectDisc, this, &CDisc());
		IsectCheckers().Set(FindIsectPlane, this, &CPlane());
		IsectCheckers().Set(FindIsectMesh, this, this);
		}
	}
CMesh::~CMesh()
	{
	}
//	�ӂ�\��
struct Edge
	{
	int b, e;
	operator == (const Edge& ed) const
		{
		return b == ed.b && e == ed.e;
		}
	operator < (const Edge& ed) const
		{
		return b < ed.b;
		}
	};
struct CEdges:public Array<Edge>
	{
	int Find(int b, int e)
		{
		for(It it=Bgn(); it<End(); it++)
			if (it->b == b && it->e == e) return it - Bgn();
		return -1;
		}
	bool Add(int i, int j)
		{
		int b = std::min(i,j);
		int e = std::max(i,j);
		if (Find(b, e) < 0)
			{
			Edge ed;
			ed.b = b;
			ed.e = e;
			Array<Edge>::Add(ed);
			return true;
			}
		return false;
		}
	};
struct Faces:public Array<int>
	{
	void Add(int f)
		{
		for(It it=Bgn(); it<End(); it++) if (*it == f) return;
		Array<int>::Add(f);
		}
	};
struct Vertex:public Vec3
	{
	Faces faces;				//	���_���܂ޖʂ�ID
	bool bNeverCol;				//	���_���Փ˓_�ɂȂ蓾�Ȃ��ꍇ true
	Vertex(){bNeverCol=true;}
	};
bool CMesh::FindIsectSphere(CIsects& cols1, CVisual* v1, const Affine& afMesh, CFrame* pFr1,
							CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	/*
	�Փ˔���̎d��
	�P	���_�̍��W�����[���h�n�ɕϊ�����B
	�Q	�`����\������e�ʂɂ��āu���S�ƕ��ʂ̋��� <= ���a�v
	�R	�Q�̖ʂɂ��āA�u�ʂ��\����������Ɩʂ̖@�����܂ޖʁv�𑤖ʂƂ���B
	�S	���S�����ׂĂ̑��ʂ̓����Ȃ狅�͂Q�̖ʂɓ������Ă���B
	�T	���ׂĂ̑��ʂɂ��āu���S�����ʂ̓����v���u���ʂ���̋���<=���a�v
	�U	�u�Q�̖ʂ��\����������ƒ��S�̋���<=���a�v�Łu�����ɐ����Ő����̒[�_
		��ʂ�����ɐ����ȕ��ʁi2����j�ɒ��S�����܂�Ă���v�Ƃ����͐�����
		�������Ă���B
	�V	�u�Q�̖ʂ��\�����钸�_�ƒ��S�̋���<=���a�v�̂Ƃ����͒��_�ɐڂ��Ă���B
	*/
	{
	CMesh* pMesh = (CMesh*) v1;
	CSphere* pSph = (CSphere*) v2;
	REAL rSph = afSph.ScaleMax() * pSph->radius;
	Vec3 center = afSph.Pos();						//	���̒��S
	int i,j;
	bool rtv = false;
	int nVertex = pMesh->NVertex();					//	���_��
	Vertex* vtx = new Vertex[nVertex];				//	World�n�ł̒��_
	for (i=0; i<nVertex; i++) (Vec3&)(vtx[i]) = afMesh * pMesh->Pos(i);
	int nFace = pMesh->NFace();						//	�ʐ�
	Vec3* fn = new Vec3[nFace];						//	�ʂ̖@��
	SCALER* ds = new SCALER[nVertex];				//	�ʂ��ʂƂ���p���̑��ʂƋ��̋���
	CEdges edges;									//	�Փˉ\���̂����
	int* lines = new int [nFace];					//	���_�ɂȂ����
	SCALER rr = Square(rSph);						//	���̔��a��2��
	for (i=0; i<nFace; i++)
		{
		int nFaceVertex = pMesh->NVertex(i);
		//	�ʂł͂Ȃ����̂̏���
		if (nFaceVertex == 2) edges.Add(pMesh->VertexID(i,0), pMesh->VertexID(i,1));
													//	�ӂ�o�^
		if (nFaceVertex < 3) continue;
		//	�ʂƂ̏Փ˔���
		fn[i] = (vtx[pMesh->VertexID(i,1)] - vtx[pMesh->VertexID(i,0)])
					^ (vtx[pMesh->VertexID(i,2)] - vtx[pMesh->VertexID(i,0)]);
		fn[i] = fn[i].Unit();
		SCALER d = fn[i] * (center - vtx[pMesh->VertexID(i,0)]);
													//	�ʂƋ��̒��S�Ƃ̋���
		if (-rSph <= d && d <= rSph)				//	-���a <= ���� <= ���a��������
			{
			//	���̎��_�ŋ����ʂɈ����������Ă������Ƃ��m��B
			for (j=0; j<nFaceVertex; j++)
				{
				int bgnID = pMesh->VertexID(i,j);
				int endID = pMesh->VertexID(i, (j+1)<nFaceVertex ? j+1 : 0);
				Vec3 ns = - fn[i] ^ (vtx[endID] - vtx[bgnID]);
				ns = ns.Unit();						//	���ʂ̖@��
				ds[j] = ns * (center-vtx[bgnID]);	//	���ʂƒ��S�̋���
				vtx[bgnID].faces.Add(i);			//	�ʂ𒸓_�ɓo�^
				vtx[bgnID].bNeverCol = false;		//	���_���Փ˂���\������
				}
			for(j=0; j<nFaceVertex && ds[j] <= 0; j++);
			if (j==nFaceVertex && -EPSILON <= d)	//	���S�͖ʂ̒� && �\��
				{
				//	�������̖ʂƌ�����Ă��邱�Ƃ��m��
#ifdef DEBUG
				debStr << "register face. (";
				for (j=0; j<nFaceVertex; j++) debStr << pMesh->VertexID(i,j) << ",";
				debStr << ")\n";
#endif
				for (j=0; j<nFaceVertex; j++) vtx[pMesh->VertexID(i,j)].bNeverCol = true;
				CIsect* colMesh = new CIsect;
				CIsect* colV2 = new CIsect;
				colMesh->normal = fn[i];
				colMesh->pos = center - d*fn[i];
				colMesh->ct = CIsect::FACE;
				colMesh->face = i;
				colMesh->pFrame = pFr1;
				colMesh->pVisual = pMesh;
				colV2->overlap = rSph-ABS(d);
				cols1.Add(colMesh);
				
				colV2->normal = - colMesh->normal;
				colV2->pos = center + rSph*colV2->normal;
				colV2->ct = CIsect::SOLID;
				colV2->pFrame = pFr2;
				colV2->pVisual = pSph;
				colV2->overlap = colMesh->overlap;
				cols2.Add(colV2);
				colMesh->Pair(colV2);
				rtv = true;
				continue;			//	���̖ʂ�
				}
			for(j=0; j<nFaceVertex; j++)
				{
				if (-EPSILON <= ds[j] && ds[j] < rSph)	//	�����ӂ̊O���Ɉ����������Ă�
					{
					int bgnID = pMesh->VertexID(i,j);
					int endID = pMesh->VertexID(i, (j+1)<nFaceVertex ? j+1 : 0);
					edges.Add(bgnID, endID);	//	�ӂ�o�^
					}
				}
			}
		}
	//	�o�^���ꂽ�ӂ̏Փ˔���
	for (i=0; i<edges.Size(); i++)
		{
		int bgnID = edges[i].b;
		int endID = edges[i].e;
		Vec3 l = vtx[endID] - vtx[bgnID];
		SCALER ll = l.Square();
		if (ll == 0) continue;
		Vec3 bgnToCenter = center - vtx[bgnID];
		SCALER dl = (bgnToCenter * l) / ll;	//	l * dl = ���̒��S����ӂɂ��낵�������̑�
		if (0 <= dl && dl <= 1)				//	�ӂ̂���͈͂�center������
			{
			SCALER dd = bgnToCenter.Square() - dl*dl * ll;
			//	dd: center�ƕӂ̋�����2��
			if (dd <= rr)					//	�ӂɋ����������Ă���
				{
				vtx[bgnID].bNeverCol = true;
				vtx[endID].bNeverCol = true;
				//	�ӂ��܂ޖʂ�T��(2����͂�)
				int edgeFace[2];
				int curEdgeFace=0;
				for(int f=0; f < vtx[bgnID].faces.Size(); f++)
					{
					for(int g=0; g < vtx[endID].faces.Size(); g++)
						{
						if (vtx[bgnID].faces[f] == vtx[endID].faces[g])
							{
							edgeFace[curEdgeFace] = vtx[bgnID].faces[f];
							curEdgeFace ++;	
							if (curEdgeFace == 2) goto NEXT;
							}
						}
					}
				continue;
NEXT:
				Vec3 meshNormal = (bgnToCenter - dl*l).Unit();
				if ((fn[edgeFace[0]]^meshNormal) * (meshNormal^fn[edgeFace[1]]) >= -EPSILON)
					{
#ifdef DEBUG
					debStr << "register edge. (" << bgnID << "-" << endID << ")\n";
#endif
					CIsect* colMesh = new CIsect;
					CIsect* colV2 = new CIsect;
					colMesh->normal = meshNormal;
					colMesh->pos = vtx[bgnID] + dl*l;
					colMesh->ct = CIsect::EDGE;
					colMesh->edge[0] = bgnID;
					colMesh->edge[1] = endID;
					colMesh->pFrame = pFr1;
					colMesh->pVisual = pMesh;
					colV2->overlap = sqrt(rr-dd);
					cols1.Add(colMesh);

					colV2->normal = -colMesh->normal;
					colV2->pos = center + rSph * colV2->normal;
					colV2->ct = CIsect::SOLID;
					colV2->pFrame = pFr2;
					colV2->pVisual = pSph;
					colV2->overlap = colMesh->overlap;
					cols2.Add(colV2);
					colMesh->Pair(colV2);
					rtv = true;
					}
				}
			}
		}
	//	���_�̏Փ˔���
	for (j=0; j<nVertex; j++)
		{
		if (vtx[j].bNeverCol) continue;
		SCALER dd = (center - vtx[j]).Square();
		if (dd <= rr)						//	���_�ɋ����������Ă���
			{
			int f;
			Vec3 meshNormal = (center - vtx[j]).Unit();
			Faces& faces = vtx[j].faces;
			for(f=0; f < faces.Size(); f++)
				{
				int nFVtx = pMesh->NVertex(faces[f]);
                int g;
				for(g=0; g<nFVtx; g++)
					{
					if (pMesh->VertexID(faces[f], g) == j)
						{
						lines[f] = pMesh->VertexID(faces[f], g+1<nFVtx ?g+1:0);
						break;
						}
					}
				ASSERT(g < nFVtx);
				}
			for(f=0; f<faces.Size(); f++)
				{
				Vec3 l = vtx[j] - vtx[lines[f]];
				if (l*meshNormal <= 0) goto PassRegVtx;
				}
#ifdef DEBUG
			debStr << "register vertex " << j << ".\n";
#endif
			CIsect* colMesh = new CIsect;
			CIsect* colV2 = new CIsect;
			colMesh->normal = meshNormal;
			colMesh->pos = vtx[j];
			colMesh->ct = CIsect::VERTEX;
			colMesh->vertex = j;
			colMesh->pFrame = pFr1;
			colMesh->pVisual = pMesh;
			colV2->overlap = sqrt(rr-dd);
			cols1.Add(colMesh);
			
			colV2->normal = -colMesh->normal;
			colV2->pos = center + rSph * colV2->normal;
			colV2->ct = CIsect::SOLID;
			colV2->pFrame = pFr2;
			colV2->pVisual = pSph;
			colV2->overlap = colMesh->overlap;
			cols2.Add(colV2);
			colMesh->Pair(colV2);
			rtv = true;
			}
PassRegVtx:;
		}
	delete [] vtx;
	delete [] ds;
	delete [] lines;
	delete [] fn;
	return rtv;
	}
bool CMesh::FindIsectDisc(CIsects& cols1, CVisual* v1, const Affine& afMesh, CFrame* pFr1,
							CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	return false;
	}
bool CMesh::FindIsectPlane(CIsects& cols1, CVisual* v1, const Affine& afMesh, CFrame* pFr1,
							CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	return false;
	}
bool CMesh::FindIsectLine(CIsects& cols1, CVisual* v1, const Affine& afMesh, CFrame* pFrMesh,
							CIsects& cols2, CVisual* v2, const Affine& afLine, CFrame* pFrLine)
	{
#if 0
	CMesh& mesh = *(CMesh*)v1;
	CLine& line = *(CLine*)v2;
	bool rtv = false;
	int nVtx = mesh.NVertex();					//	���_��
	Vec3* vtx = new Vec3[nVtx];					//	CLine�̍��W�n�ł̒��_
	Affine afMeshToLine = afLine.Inv() * afMesh;
	for (i=0; i<nVtx; i++) vtx[i] = afMeshToLine * mesh.Pos(i);
	int nFace = mesh.NFace();					//	�ʐ�
	for(i=0; i<nFace; i++)
		{
		int nFVtx = mesh.NVertex(i);
		for(j=0; j<nFVtx; j++)
			{
			int b = j;
			int e = (j+1)%nFVtx;
			if (edges.Add(b, e))
				{
				//	�ӂ̃`�F�b�N
				
				}
			}
		}
#endif
	return false;
	}
bool CMesh::FindIsectMesh(CIsects& cols1, CVisual* v1, const Affine& afMesh, CFrame* pFr1,
							CIsects& cols2, CVisual* v2, const Affine& afSph, CFrame* pFr2)
	{
	return false;
	}

void CMesh::UpdateGlobe()
	{
	int nVtx = NVertex();
	SCALER rr = 0;
	for(int i=0; i<nVtx; i++) rr = std::max(rr, Pos(i).Square());
	radius = sqrt(rr);
	}
//-----------------------------------------------------------------------------
//	CIsectCheckers
//
static int isectCheckersNextID;
CIsectCheckers::CIsectCheckers()
	{
	}
void CIsectCheckers::Set(IsectCheckerType* f, CVisual* v1, CVisual* v2)
	{
	if (isectCheckersNextID==0) isectCheckersNextID = 1;
	if (!v1->VisualID()) v1->VisualID() = isectCheckersNextID++;
	if (!v2->VisualID()) v2->VisualID() = isectCheckersNextID++;
	int size = std::max(v1->VisualID(), v2->VisualID()) + 1;
	while (func.Size() < size) func.Add(CIsectCheckerArray());
	for(int i=0; i<func.Size(); i++)
		while (func[i].Size() < size) func[i].Add(NULL);
	func[v1->VisualID()][v2->VisualID()] = f;
	}
bool CIsectCheckers::Call(CIsects& cols1, CVisual* v1, CFrame* pFr1, CIsects& cols2, CVisual* v2, CFrame* pFr2)
	{
	return Call(cols1, v1, pFr1->AfWorld(), pFr1, cols2, v2, pFr2->AfWorld(), pFr2);
	}
bool CIsectCheckers::Call(CIsects& cols1, CVisual* v1, const Affine& af1, CFrame* pFr1,
						  CIsects& cols2, CVisual* v2, const Affine& af2, CFrame* pFr2)
	{
	int id1, id2;
	if (v1->colPrec == CVisual::NONE || v2->colPrec == CVisual::NONE) return false;
	if (v1->colPrec == CVisual::GLOBE) id1 = sphereVisualID;
	else id1 = v1->VisualID();
	if (v2->colPrec == CVisual::GLOBE) id2 = sphereVisualID;
	else id2 = v2->VisualID();
	if (func[id1][id2]) return func[id1][id2](cols1, v1, af1, pFr1, cols2, v2, af2, pFr2);
	if (func[id2][id1]) return func[id2][id1](cols2, v2, af2, pFr2, cols1, v1, af1, pFr1);
	return false;
	}
END_NAMESPACE_HASE
