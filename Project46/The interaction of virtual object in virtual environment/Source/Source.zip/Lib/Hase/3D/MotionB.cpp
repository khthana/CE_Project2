#include "Hase/3D/FrameBUtil.h"
BEGIN_NAMESPACE_HASE
//-----------------------------------------------------------------------------
//	CIsect
//
CIsect::CIsect(ColType c, Vec3 p, Vec3 n, CVisual* pVis, CFrame* pFr)
	{
	ct		= c;
	pFrame	= pFr;
	pVisual	= pVis;
	pos		= p;
	normal	= n;
	pair	= NULL;
	face	= 0;
	vertex	= 0;
	edge[0]	= 0;
	edge[1]	= 0;
	bDone = false;
	}
CIsect::CIsect()
	{
	pair	= NULL;
	pFrame	= NULL;
	pVisual	= NULL;
	ct		= SOLID;
	face	= 0;
	vertex	= 0;
	edge[0]	= 0;
	edge[1]	= 0;
	bDone = false;
	}
void CIsect::Pair(CIsect* pOpp)
	{
	pair = pOpp;
	pOpp->pair = this;
	}
//-----------------------------------------------------------------------------
//	CIsects
//
void CIsects::Effect()
	{
	for (It it = Bgn(); it<End(); it++)
		if (!it[0]->bDone) CMotion::FuncTable().Call(it[0]);
	}
//-----------------------------------------------------------------------------
//	CForce
//
CMoveFrames& CForce::Moves()
	{
	return pRoot->moves;
	}
CForces& CForce::Forces()
	{
	return pRoot->forces;
	}
//-----------------------------------------------------------------------------
//	CForces
//
void CForces::Step(SCALER dt)
	{
	for(It it=Bgn(); it<End(); it++) it[0]->Step(dt);
	}
void CForces::BeforeDeleteMotion(CMotion* m)
	{
	for(It it=Bgn(); it<End(); it++) it[0]->BeforeDeleteMotion(m);
	}
void CForces::BeforeDeleteFrame(CFrame* f)
	{
	for(It it=Bgn(); it<End(); it++) it[0]->BeforeDeleteFrame(f);
	}
void CForces::Add(CForce* f)
	{
	f->pRoot = pFrame->Root();
	PArray<CForce>::Add(f);
	}
void CForces::Add(const CForce& fc)
	{
	CForce* f = fc.Clone();
	f->pRoot = pFrame->Root();
	PArray<CForce>::Add(f);
	}
void CForces::Add(CForces& fs)
	{
	for(It it=fs.Bgn(); it<fs.End(); it++)
		it[0]->pRoot = pFrame->Root();
	PArray<CForce>::Add(fs);
	}
//-----------------------------------------------------------------------------
//	CMotionFuncTable
//
int CMotionFuncTable_lastID;
CMotionFuncTable::CMotionFuncTable()
	{
	}
void CMotionFuncTable::Set(MotionFuncType* f, CMotion* m1, CMotion* m2)
	{
	if (!m1->MotionID()) m1->MotionID() = ++CMotionFuncTable_lastID;
	if (!m2->MotionID()) m2->MotionID() = ++CMotionFuncTable_lastID;
	int id1 = m1->MotionID();
	int id2 = m2->MotionID();
	int size = std::max(id1, id2) + 1;
	while (func.Size() < size) func.Add(CMotionFuncArray());
	for(int i=0; i<func.Size(); i++) 
		while (func[i].Size() < size) func[i].Add(NULL);
	func[id1][id2] = f;
	}
bool CMotionFuncTable::Call(CIsect* pCol)
	{
	CMotion* m1=NULL;
	CMotion* m2=NULL;
	if (pCol->pFrame) m1 = pCol->pFrame->PMotion();
	if (pCol->pair->pFrame) m2 = pCol->pair->pFrame->PMotion();
	if (!m1 && !m2) return false;
	int id1, id2;
	id1 = m1 ? m1->MotionID() : 0;
	id2 = m2 ? m2->MotionID() : 0;
	if (func[id1][id2])
		{
		func[id1][id2](m1, pCol, m2, pCol->pair);
		return true;
		}
	if (func[id2][id1])
		{
		func[id2][id1](m2, pCol->pair, m1, pCol);
		return true;
		}
	return false; 
	}

//-----------------------------------------------------------------------------
//	CMotion
//
CMotionFuncTable* CMotion::pFuncTable;
int CMotion_count;
SCALER CMotion::minBoundVel = SCALER(0);
CMotion::CMotion(Vec3 v, Vec3 av, Vec3 p)
	{
	pFrame = NULL;
	bAbs = false;
	vel = v;
	angVel = av;
	pos = p;
	CMotion_count ++;
	bDone = false;
	nFixed = 0;
	}
CMotion::CMotion()
	{
	pFrame = NULL;
	bAbs = false;
	CMotion_count ++;
	bDone = false;
	nFixed = 0;
	}
CMotion::CMotion(const CMotion& m)
	{
	pFrame = NULL;
	CMotion_count ++;
	pos = m.pos;
	vel = m.vel;
	angVel = m.angVel;
	bAbs = m.bAbs;
	bDone = false;
	nFixed = 0;
	}
CMotion::~CMotion()
	{
	if (pFrame)
		{
		pFrame->Root()->forces.BeforeDeleteMotion(this);
		Detach(pFrame);
		}
	CMotion_count --;
	if (CMotion_count == 0)
		{
		delete pFuncTable;
		pFuncTable = NULL;
		}
	}
CMotionFuncTable& CMotion::FuncTable()
	{
	if (!pFuncTable) pFuncTable = new CMotionFuncTable;
	return *pFuncTable;
	}
void CMotion::DetachHelper(CFrame* pFr, CMotion* mOrg)
	{
	if (pFr->PMotion() != mOrg) return;
	pFr->pMotion = NULL;
	FOREACH_STOP(pFr) DetachHelper(pStop, mOrg);
	FOREACH_MOVE(pFr) DetachHelper(pMove, mOrg);
	}
void CMotion::Detach(CFrame* pFr)
	{
	DetachHelper(pFr, this);	//	�����Ǝq�� pMotion = NULL
	if (pFr == pFrame)			//	�����̎����傪 pFr ��������
		{						//	�����̎�����͂Ȃ��Ȃ�
		pFrame = NULL;
		}
	}
void CMotion::AttachHelper(CFrame* pFr, CMotion* mOrg)
	{
	if (pFr->pMotion != mOrg) return;
	pFr->pMotion = this;
	FOREACH_STOP(pFr) AttachHelper(pStop, mOrg);
	FOREACH_MOVE(pFr) AttachHelper(pMove, mOrg);
	}
void CMotion::Attach(CFrame* pFr)
	{
	if (pFr->pMotion == this) return;
	if (pFr->pMotion && pFr->pMotion->pFrame == pFr)
		delete pFr->pMotion;	//	pFr �̌��̃��[�V����������
	AttachHelper(pFr, pFr->pMotion);
	}
void CMotion::PFrame(CFrame* pFr)
	{
	if (pFrame) Detach(pFrame);
	pFrame = pFr;
	Attach(pFrame);
	}
void CMotion::Move(const Vec3& dp)
	{
	Affine afW = pFrame->AfWorld();
	Vec3 oldPos = afW.Pos();
	afW.Pos(afW.Pos() + dp);
	pFrame->AfWorld(afW);
	for(CIsects::It it = cols.Bgn(); it<cols.End(); it++)
		{
		it[0]->overlap -= it[0]->normal * dp;
		it[0]->pair->overlap = it[0]->overlap;
		}
	}
void CMotion::Clear()
	{
	bDone = false;
	nFixed = 0;
	cols.Clear();
	}
void CMotion::StepCalc(SCALER dt)
	{
	CalcAngVel();
	deltaPos += vel * dt;
	deltaAng += angVel * dt;
	dPosSize = deltaPos.Size();
	dPosUnit = dPosSize>0 ? deltaPos/dPosSize : Vec3(0,0,1);
	dAngSize = deltaAng.Size();
	dAngUnit = dAngSize>0 ? deltaAng/dAngSize : Vec3(0,0,1);
	}
void CMotion::Step()
	{
	if (dPosSize==0 && dAngSize==0) return;
	Affine afW = pFrame->AfWorld();
	Vec3 oldPos = afW.Pos();
	if (dAngSize == 0) afW.Pos(afW.Pos() + deltaPos);
	else
		{
		Affine R(dAngSize, dAngUnit);
		Vec3 wPos = afW.Rot(pos);
		Vec3 wRPos = R*wPos;
		afW = R.Rot(afW);
		afW.Pos(afW.Pos() + deltaPos + (wPos - wRPos));
		}
	pFrame->AfWorld(afW);
	for(CIsects::It it = cols.Bgn(); it<cols.End(); it++)
		{
		Vec3 dp = (deltaAng^(it[0]->pos-oldPos)) + deltaPos;
		it[0]->overlap -= it[0]->normal * dp;
		it[0]->pair->overlap = it[0]->overlap;
		}
	deltaPos = Vec3(0,0,0); 
	deltaAng = Vec3(0,0,0); 
	}
void CSolidMotion::CalcAngVel(){
	Matrix3 inW, rot;
	rot = PFrame()->AfWorld();
	inW.ExX() = inertia.x;
	inW.EyY() = inertia.y;
	inW.EzZ() = inertia.z;
	inW = rot * inW * rot.Inv();
	angVel = inW.Inv() * angMom;
}
void CSolidMotion::CalcAngMom(){
	Matrix3 inW, rot;
	if (PFrame()) rot = PFrame()->AfWorld();
	inW.ExX() = inertia.x;
	inW.EyY() = inertia.y;
	inW.EzZ() = inertia.z;
	inW = rot * inW * rot.Inv();
	angVel = inW * angMom;
}

//-----------------------------------------------------------------------------
//	CAbsMotion
//
int CAbsMotion::motionID;
int& CAbsMotion::MotionID()
	{
	return motionID;
	}
CAbsMotion::CAbsMotion():CMotion()
	{
	bAbs = true;
	}
CAbsMotion::CAbsMotion(Vec3 v, Vec3 av, Vec3 p):CMotion(v, av, p)
	{
	bAbs = true;
	}
CMotion* CAbsMotion::Clone() const
	{
	return new CAbsMotion(*this);
	}
//-----------------------------------------------------------------------------
//	CPointMotion
//
CPointMotion CPointMotion::pointMot;
int CPointMotion::motionID;
int& CPointMotion::MotionID()
	{
	return motionID;
	}
CPointMotion::CPointMotion()
	{
	mass = 1;
	CAbsMotion absMot;
	if (!motionID)
		{
		FuncTable().Set(CollideAbsMotion, this, &absMot);
		FuncTable().Set(CollidePointMotion, this, this);
		}
	}
CMotion* CPointMotion::Clone() const
	{
	return new CPointMotion(*this);
	}
void CPointMotion::AddForce(const Vec3& ft, const Vec3& tq, const Vec3& p)
	{
	vel += ft / mass;
	}
void CPointMotion::CollideAbsMotion(CMotion* pMyM, CIsect* pMyCol, CMotion* pOppM, CIsect* pOppCol)
	{
	CPointMotion* pMy = (CPointMotion*)pMyM;
	CAbsMotion* pOpp = (CAbsMotion*)pOppM;
	//	���̂̏Փˌv�Z
	Vec3 p1, p2, V1, V2;
	Vec3 n = pMyCol->normal;
	p1 = pMyCol->pos - pMy->pFrame->AfWorld()*pMy->pos;
	p2 = pOppCol->pos - pOpp->PFrame()->AfWorld()*pOpp->pos;
	V1 = (pMy->AngVel() ^ p1) + pMy->vel;
	V2 = (pOpp->AngVel() ^ p2) + pOpp->vel;
	if ((V2-V1)*n >= 0)		//	�������̂ŏՓ˂��Ă��Ȃ�
		{
		pMyCol->bDone = true;
		pOppCol->bDone = true;
		return;
		}

	SCALER M = 1/pMy->mass;
	Affine afM;
	afM.ExX() = M;
	afM.EyY() = M;
	afM.EzZ() = M;
	//	���C�ƒ��˕Ԃ�
	SCALER e1 = CMotionMaterial::Def().Bound();
	SCALER e2 = e1;
	SCALER fric1 = CMotionMaterial::Def().MoveFriction();
	SCALER fric2 = fric1;
	if (pMyCol->pVisual && pMyCol->pVisual->pMotionMtr)
		{
		e1 = pMyCol->pVisual->pMotionMtr->Bound();
		fric1 = pMyCol->pVisual->pMotionMtr->MoveFriction();
		}
	if (pOppCol->pVisual && pOppCol->pVisual->pMotionMtr)
		{
		e2 = pOppCol->pVisual->pMotionMtr->Bound();
		fric2 = pOppCol->pVisual->pMotionMtr->MoveFriction();
		}
	//	�Փ˂̗͐ς��v�Z
	Vec3 f = afM.Inv() * (V2-V1 + (e1*e2*(V2-V1)*n)*n);
	SCALER fnSize = f*(-n);
	Vec3 fn = fnSize * (-n);
	Vec3 fu = f - fn;
	SCALER fuSize = fu.Size();
	if (fuSize/fnSize > fric1+fric2)
		f = fn + (fric1+fric2) * fnSize / fuSize * fu;
	pMy->AddForce(f, Vec3(), p1);
	pMyCol->bDone = true;
	pOppCol->bDone = true;
	}
void CPointMotion::CollidePointMotion(CMotion* pMyM, CIsect* pMyCol, CMotion* pOppM, CIsect* pOppCol)
	{
	CPointMotion* pMy = (CPointMotion*)pMyM;
	CPointMotion* pOpp = (CPointMotion*)pOppM;

	//	���̂̏Փˌv�Z
	Vec3 p1, p2, V1, V2;
	Vec3 n = pMyCol->normal;
	p1 = pMyCol->pos - pMy->pFrame->AfWorld()*pMy->pos;
	p2 = pOppCol->pos - pOpp->pFrame->AfWorld()*pOpp->pos;
	V1 = (pMy->angVel ^ p1) + pMy->vel;
	V2 = (pOpp->angVel ^ p2) + pOpp->vel;
	if ((V2-V1)*n >= 0)		//	�������̂ŏՓ˂��Ă��Ȃ�
		{
		pMyCol->bDone = true;
		pOppCol->bDone = true;
		return;
		}

	SCALER M = 1/pMy->mass + 1/pOpp->mass;
	Affine afM;
	afM.ExX() = M;
	afM.EyY() = M;
	afM.EzZ() = M;
	//	���C�ƒ��˕Ԃ�
	SCALER e1 = CMotionMaterial::Def().Bound();
	SCALER e2 = e1;
	SCALER fric1 = CMotionMaterial::Def().MoveFriction();
	SCALER fric2 = fric1;
	if (pMyCol->pVisual && pMyCol->pVisual->pMotionMtr)
		{
		e1 = pMyCol->pVisual->pMotionMtr->Bound();
		fric1 = pMyCol->pVisual->pMotionMtr->MoveFriction();
		}
	if (pOppCol->pVisual && pOppCol->pVisual->pMotionMtr)
		{
		e2 = pOppCol->pVisual->pMotionMtr->Bound();
		fric2 = pOppCol->pVisual->pMotionMtr->MoveFriction();
		}
	//	�Փ˂̗͐ς��v�Z
	Vec3 f = afM.Inv() * (V2-V1 + (e1*e2*(V2-V1)*n)*n);
	SCALER fnSize = f*(-n);
	Vec3 fn = fnSize * (-n);
	Vec3 fu = f - fn;
	SCALER fuSize = fu.Size();
	if (fuSize/fnSize > fric1+fric2)
		f = fn + (fric1+fric2) * fnSize / fuSize * fu;
	pMy->AddForce(f, Vec3(), p1);
	pOpp->AddForce(-f, Vec3(), p2);
	pMyCol->bDone = true;
	pOppCol->bDone = true;
	}

//-----------------------------------------------------------------------------
//	CSolidMotion
//
int CSolidMotion::motionID;
int& CSolidMotion::MotionID()
	{
	return motionID;
	}
CSolidMotion::CSolidMotion()
	{
	inertia = Vec3(1,1,1);
	CAbsMotion absMot;
	CPointMotion pointMot;
	if (!motionID)
		{
		FuncTable().Set(CollideAbsMotion, this, &absMot);
		FuncTable().Set(CollidePointMotion, this, &pointMot);
		FuncTable().Set(CollideSolidMotion, this, this);
		}
	}
CMotion* CSolidMotion::Clone() const
	{
	return new CSolidMotion(*this);
	}
void CSolidMotion::AddForce(const Vec3& forceT, const Vec3& tqT, const Vec3& r)
	{
	//	�͐ς����[�����g�ςƏd�S�ւ̗͐ςɕϊ����ĉ�����
	Vec3 torqueT = r ^ forceT;
	//	tq��������
	torqueT += tqT;
	//	���x�A�p���x���X�V
	vel += forceT / mass;
	angMom += torqueT;
	}
void CSolidMotion::AddIntForce(const Vec3& forceTT, const Vec3& tqTT, const Vec3& r)
	{
	//	�͐ϐς����[�����g�ϐςƏd�S�ւ̗͐ϐςɕϊ����ĉ�����
	Vec3 torqueTT = r ^ forceTT;
	//	tq��������
	torqueTT += tqTT;
	//	�ʒu�A�p�x�̕ω��ʂ�ݒ�
	deltaPos += forceTT / mass;
	CMatrix3 rotW = PFrame()->AfWorld();
	Vec3 dAng = rotW.Inv() * torqueTT;
	dAng.x /= inertia.x;
	dAng.y /= inertia.y;
	dAng.z /= inertia.z;
	deltaAng = rotW * dAng;
	}
inline Affine CalcA(const Vec3& in, const Vec3& p)
	{
	Affine A;
	Vec3 i;
 	i.x = 1/in.x;
	i.y = 1/in.y;
	i.z = 1/in.z;
	A.ExX() =  i.z*Square(p.y) + i.y*Square(p.z);
	A.ExY() = -i.z*p.y*p.x;
	A.ExZ() = -i.y*p.z*p.x;

	A.EyX() = -i.z*p.x*p.y;
	A.EyY() = i.x*Square(p.z) + i.z*Square(p.x);
	A.EyZ() = -i.x*p.z*p.x;

	A.EzX() = -i.y*p.x*p.z;
	A.EzY() = -i.x*p.y*p.z;
	A.EzZ() = i.y*Square(p.x) + i.x*Square(p.y);
	return A;
	}
void CSolidMotion::CollideAbsMotion(CMotion* pMyM, CIsect* pMyCol, CMotion* pOppM, CIsect* pOppCol)
	{
	CSolidMotion* pMy = (CSolidMotion*)pMyM;
	CAbsMotion* pOpp = (CAbsMotion*)pOppM;
	//	���̂̏Փˌv�Z
	Vec3 p1, p2, V1, V2;
	Affine A1;
	Vec3 n = pMyCol->normal;
	p1 = pMyCol->pos - pMy->pFrame->AfWorld()*pMy->pos;
	p2 = pOppCol->pos - pOpp->PFrame()->AfWorld()*pOpp->pos;
	V1 = (pMy->AngVel() ^ p1) + pMy->vel;
	V2 = (pOpp->AngVel() ^ p2) + pOpp->vel;
	//	����ɖ��܂�Ȃ��悤�Ɉړ�����
#if 0
	Affine afW = pMyCol->pFrame->AfWorld();
	afW.Pos(afW.Pos() + (pOppCol->pos - pMyCol->pos));
	pMyCol->pFrame->AfWorld(afW);
#endif
	SCALER rVelN = (V2-V1)*n;
	if (rVelN >= 0)		//	�������̂ŏՓ˂��Ă��Ȃ�
		{
		pMyCol->bDone = true;
		pOppCol->bDone = true;
		return;
		}
	A1 = CalcA(pMy->inertia, p1);
	SCALER M = 1/pMy->mass;
	Affine afM;
	afM.ExX() = M;
	afM.EyY() = M;
	afM.EzZ() = M;
	//	���C�ƒ��˕Ԃ�
	SCALER e1, e2, fric1, fric2;
	if (pMyCol->pVisual && pMyCol->pVisual->pMotionMtr)
		{
		e1 = pMyCol->pVisual->pMotionMtr->Bound();
		fric1 = pMyCol->pVisual->pMotionMtr->MoveFriction();
		}
	else
		{
		e1 = CMotionMaterial::Def().Bound();
		fric1 = CMotionMaterial::Def().MoveFriction();
		}
	if (pOppCol->pVisual && pOppCol->pVisual->pMotionMtr)
		{
		e2 = pOppCol->pVisual->pMotionMtr->Bound();
		fric2 = pOppCol->pVisual->pMotionMtr->MoveFriction();
		}
	else
		{
		e2 = CMotionMaterial::Def().Bound();
		fric2 = CMotionMaterial::Def().MoveFriction();
		}
	if (-rVelN < minBoundVel) e1=e2=0;
	//	�Փ˂̗͐ς��v�Z
	Vec3 f = (A1 + afM).Inv() * (V2-V1 + (e1*e2*(V2-V1)*n)*n);
	SCALER fnSize = f*(-n);
	Vec3 fn = fnSize * (-n);
	Vec3 fu = f - fn;
	SCALER fuSize = fu.Size();
	if (fuSize/fnSize > fric1+fric2)
		f = fn + (fric1+fric2) * fnSize / fuSize * fu;
	pMy->AddForce(f, Vec3(), p1);
	//	�v�Z���I��������ƋL�^���Ă���
	pMyCol->bDone = true;
	pOppCol->bDone = true;
	}
void CSolidMotion::CollidePointMotion(CMotion* pMyM, CIsect* pMyCol, CMotion* pOppM, CIsect* pOppCol)
	{
	CSolidMotion* pMy = (CSolidMotion*)pMyM;
	CPointMotion* pOpp = (CPointMotion*)pOppM;

	//	���̂̏Փˌv�Z
	Vec3 p1, p2, V1, V2;
	Affine A1;
	Vec3 n = pMyCol->normal;
	p1 = pMyCol->pos - pMy->pFrame->AfWorld()*pMy->pos;
	p2 = pOppCol->pos - pOpp->PFrame()->AfWorld()*pOpp->pos;
	V1 = (pMy->AngVel() ^ p1) + pMy->vel;
	V2 = (pOpp->AngVel() ^ p2) + pOpp->vel;
	if ((V2-V1)*n >= 0)		//	�������̂ŏՓ˂��Ă��Ȃ�
		{
		pMyCol->bDone = true;
		pOppCol->bDone = true;
		return;
		}

	A1 = CalcA(pMy->inertia, p1);
	SCALER M = 1/pMy->mass + 1/pOpp->mass;
	Affine afM;
	afM.ExX() = M;
	afM.EyY() = M;
	afM.EzZ() = M;
	//	���C�ƒ��˕Ԃ�
	SCALER e1 = CMotionMaterial::Def().Bound();
	SCALER e2 = e1;
	SCALER fric1 = CMotionMaterial::Def().MoveFriction();
	SCALER fric2 = fric1;
	if (pMyCol->pVisual && pMyCol->pVisual->pMotionMtr)
		{
		e1 = pMyCol->pVisual->pMotionMtr->Bound();
		fric1 = pMyCol->pVisual->pMotionMtr->MoveFriction();
		}
	if (pOppCol->pVisual && pOppCol->pVisual->pMotionMtr)
		{
		e2 = pOppCol->pVisual->pMotionMtr->Bound();
		fric2 = pOppCol->pVisual->pMotionMtr->MoveFriction();
		}
	//	�Փ˂̗͐ς��v�Z
	Vec3 f = (A1 + afM).Inv() * (V2-V1 + (e1*e2*(V2-V1)*n)*n);
	SCALER fnSize = f*(-n);
	Vec3 fn = fnSize * (-n);
	Vec3 fu = f - fn;
	SCALER fuSize = fu.Size();
	if (fuSize/fnSize > fric1+fric2)
		f = fn + (fric1+fric2) * fnSize / fuSize * fu;
	pMy->AddForce(f, Vec3(), p1);
	pOpp->AddForce(-f, Vec3(), p2);
	pMyCol->bDone = true;
	pOppCol->bDone = true;
	}
void CSolidMotion::CollideSolidMotion(CMotion* pMyM, CIsect* pMyCol, CMotion* pOppM, CIsect* pOppCol)
	{
	CSolidMotion* pMy = (CSolidMotion*)pMyM;
	CSolidMotion* pOpp = (CSolidMotion*)pOppM;

	//	���̂̏Փˌv�Z
	Vec3 p1, p2, V1, V2;
	Affine A1, A2;
	Vec3 n = pMyCol->normal;
	p1 = pMyCol->pos - pMy->pFrame->AfWorld()*pMy->pos;
	p2 = pOppCol->pos - pOpp->pFrame->AfWorld()*pOpp->pos;
	V1 = (pMy->angVel ^ p1) + pMy->vel;
	V2 = (pOpp->angVel ^ p2) + pOpp->vel;
	//	����ɖ��܂�Ȃ��悤�Ɉړ�����
#if 0
	Affine afMyW = pMyCol->pFrame->AfWorld();
	Affine afOppW = pOppCol->pFrame->AfWorld();
	Vec3 mv = (pOppCol->pos - pMyCol->pos) / 2;
	afMyW.Pos(afMyW.Pos() + mv);
	afOppW.Pos(afOppW.Pos() - mv);
	pMyCol->pFrame->AfWorld(afMyW);
	pOppCol->pFrame->AfWorld(afOppW);
#endif
	
	SCALER rVelN = (V2-V1)*n;
	if (rVelN >= 0)		//	�������̂ŏՓ˂��Ă��Ȃ�
		{
		pMyCol->bDone = true;
		pOppCol->bDone = true;
		return;
		}

	A1 = CalcA(pMy->inertia, p1);
	A2 = CalcA(pOpp->inertia, p2);
	SCALER M = 1/pMy->mass + 1/pOpp->mass;
	Affine afM;
	afM.ExX() = M;
	afM.EyY() = M;
	afM.EzZ() = M;
	//	���C�ƒ��˕Ԃ�
	SCALER e1, e2, fric1, fric2;
	if (pMyCol->pVisual && pMyCol->pVisual->pMotionMtr)
		{
		e1 = pMyCol->pVisual->pMotionMtr->Bound();
		fric1 = pMyCol->pVisual->pMotionMtr->MoveFriction();
		}
	else
		{
		e1 = CMotionMaterial::Def().Bound();
		fric1 = CMotionMaterial::Def().MoveFriction();
		}
	if (pOppCol->pVisual && pOppCol->pVisual->pMotionMtr)
		{
		e2 = pOppCol->pVisual->pMotionMtr->Bound();
		fric2 = pOppCol->pVisual->pMotionMtr->MoveFriction();
		}
	else
		{
		e2 = CMotionMaterial::Def().Bound();
		fric2 = CMotionMaterial::Def().MoveFriction();
		}
	if (-rVelN < minBoundVel) e1=e2=0;
	//	�Փ˂̗͐ς��v�Z
	Vec3 f = (A1 + A2 + afM).Inv() * (V2-V1 + (e1*e2*(V2-V1)*n)*n);
	SCALER fnSize = f*(-n);
	Vec3 fn = fnSize * (-n);
	Vec3 fu = f - fn;
	SCALER fuSize = fu.Size();
	if (fuSize/fnSize > fric1+fric2)
		f = fn + (fric1+fric2) * fnSize / fuSize * fu;
	pMy->AddForce(f, Vec3(), p1);
	pOpp->AddForce(-f, Vec3(), p2);
	//	�v�Z���I��������ƋL�^���Ă���
	pMyCol->bDone = true;
	pOppCol->bDone = true;
	}

//-----------------------------------------------------------------------------
//	CForce
//
CForce::CForce()
	{
	pRoot = NULL;
	}
CForce::CForce(const CForce&)
	{
	pRoot = NULL;
	}
CForce::~CForce()
	{
	if (pRoot) pRoot->Root()->forces.FindDel(this);
	pRoot = NULL;
	}
//-----------------------------------------------------------------------------
//	CGravity
//
CGravity::CGravity()
	{
	CSolidMotion solid;
	motIDs.Add(solid.MotionID());
	CPointMotion point;
	motIDs.Add(point.MotionID());
	}
CGravity::CGravity(Vec3 g)
	{
	CSolidMotion solid;
	motIDs.Add(solid.MotionID());
	CPointMotion point;
	motIDs.Add(point.MotionID());
	gravity = g;
	}
CForce* CGravity::Clone() const
	{
	return new CGravity(*this);
	}
void CGravity::Step(SCALER dt)
	{
	for (CMoveFrames::It it = Moves().rel.Bgn(); it < Moves().rel.End(); it ++)
		{
		if (! motIDs.Find(it[0]->PMotion()->MotionID())) continue;
		SCALER mass = ( (CPointMotion*)(it[0]->PMotion()) )->mass;
		it[0]->PMotion()->AddForce(dt*gravity*mass, Vec3(), Vec3());
		}
	}
//-----------------------------------------------------------------------------
//	CDamper
//
CDamper::CDamper()
	{
	damp = SCALER(0.0001);
	angDamp = SCALER(0.0001);
	fric = SCALER(0.0001);
	angFric = SCALER(0.0001);
	CSolidMotion solid;
	motIDs.Add(solid.MotionID());
	CPointMotion point;
	motIDs.Add(point.MotionID());
	}
CDamper::CDamper(SCALER d, SCALER ad, SCALER f, SCALER af)
	{
	damp = d;
	angDamp = ad;
	fric = f;
	angFric = af;
	CSolidMotion solid;
	motIDs.Add(solid.MotionID());
	CPointMotion point;
	motIDs.Add(point.MotionID());
	}
CForce* CDamper::Clone() const
	{
	return new CDamper(*this);
	}
void CDamper::Step(SCALER dt)
	{
	for (CMoveFrames::It it = Moves().rel.Bgn(); it < Moves().rel.End(); it ++)
		{
		if (! motIDs.Find(it[0]->PMotion()->MotionID())) continue;
		Vec3 vel = it[0]->PMotion()->vel;
		Vec3 angVel = it[0]->PMotion()->AngVel();
		if (it[0]->PMotion())
			{
			Vec3 ft = - dt*damp*vel - dt*fric*vel.Unit();
			Vec3 aft = - dt*angDamp*angVel - dt*angFric*angVel.Unit();
			it[0]->PMotion()->AddForce(ft, aft, it[0]->PMotion()->pos);
			}
		if (vel * it[0]->PMotion()->vel <= 0) it[0]->PMotion()->vel = Vec3();
		if (angVel * it[0]->PMotion()->AngVel() <= 0) it[0]->PMotion()->AngVel(Vec3());
		}
	}
//-----------------------------------------------------------------------------
//	CJoint
//
CJoint::CJoint(SCALER s, SCALER d, Vec3 p, CMotion& b, CMotion& e)
	{
	spring = s;
	damper = d;
	posBgn = p;
	Affine afBToE = motEnd->PFrame()->AfWorld().Inv() * motBgn->PFrame()->AfWorld();
	posEnd = afBToE * posBgn;
	motBgn = &b;
	motEnd = &e;
	}
CForce* CJoint::Clone() const
	{
	return new CJoint(*this);
	}
void CJoint::Step(SCALER dt)
	{
	if (!motBgn || !motEnd) return;
	Affine afBToE = motEnd->PFrame()->AfWorld().Inv() * motBgn->PFrame()->AfWorld();
	Vec3 posEndNow = afBToE * posEnd;
	Vec3 velEndNow = afBToE.Rot( motEnd->vel + ((posEnd-motEnd->pos) ^ motEnd->AngVel()) );
	Vec3 velBgnNow = motBgn->vel + ((posBgn-motBgn->pos) ^ motBgn->AngVel());
	Vec3 fBgn = (posEndNow-posBgn)*spring + (velEndNow-velBgnNow)*damper;

	motBgn->AddForce(fBgn, posBgn, Vec3());
	Vec3 fEnd = afBToE.Rot(fBgn);
	motEnd->AddForce(fEnd, posEnd, Vec3());
	}

END_NAMESPACE_HASE
