#include <Hase/3D/Frame.h>
#include <Hase/3D/FrameDef.h>
#pragma hdrstop
#include <Hase/3D/MotionB.cpp>
#define UNDEF_ALL_FRAMEB
#include <Hase/3D/FrameB.h>
