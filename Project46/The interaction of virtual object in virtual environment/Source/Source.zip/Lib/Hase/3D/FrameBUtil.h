#ifndef HASE_3D_FRAMEBUTIL_H
#define HASE_3D_FRAMEBUTIL_H

//	���Ԃɏ������邽�߂̃}�N��
#define FOREACH_VISUAL(f)					\
	FindVisual findVis;						\
	(f)->InitVisual(findVis);				\
	CVisual* pVis;							\
	while((pVis = (f)->NextVisual(findVis)) != NULL)

#define FOREACH_STOP(f)						\
	FindFrame findStop;						\
	(f)->InitStop(findStop);				\
	CFrame* pStop;							\
	while((pStop = (f)->NextStop(findStop)) != NULL)

#define FOREACH_MOVE(f)						\
	FindFrame findMove;						\
	(f)->InitMove(findMove);				\
	CFrame* pMove;							\
	while((pMove = (f)->NextMove(findMove)) != NULL)

#endif
