#include "Hase/3D/FrameBUtil.h"

BEGIN_NAMESPACE_HASE

//-----------------------------------------------------------------------------
//	CMoveFrames
//
void CMoveFrames::Add(CFrame* f)
	{
	if (f->PMotion()->IsAbs()) abs.Add(f);
	else rel.Add(f);
	}
void CMoveFrames::Move(CMoveFrames& fs)
	{
	abs.Add(fs.abs);
	rel.Add(fs.rel);
	fs.abs.Clear();
	fs.rel.Clear();
	}
bool CMoveFrames::FindDel(CFrame* f)
	{
	if (abs.FindDel(f)) return true;
	return rel.FindDel(f);
	}
CMoveFrames::It CMoveFrames::Find(CFrame* f)
	{
	CMoveFrames::It it = abs.Find(f);
	if (it) return it;
	it = rel.Find(f);
	if (it) return it;
	return NULL;
	}
void CMoveFrames::Clear()
	{
	int i,sz;
	sz = abs.Size();
	for(i=0; i<sz; i++) abs[i]->bMovesHaveThis = false;
	abs.Clear();
	sz = rel.Size();
	for(i=0; i<sz; i++) rel[i]->bMovesHaveThis = false;
	rel.Clear();
	}
//-----------------------------------------------------------------------------
//	CFrame
//
CFrame::CFrame()
	{
	radius = SCALER(0);
	pMotion = NULL;
	bMove = false;
	bMovesHaveThis = false;
	forces.pFrame = this;
	pMove = NULL;
	}
CFrame::~CFrame()
	{
	ASSERT(!bMove);		//	�j������O�� CFrame::Cleanup() ���Ă�ł��������B
	ASSERT(!pMotion);	//	�j������O�� CFrame::Cleanup() ���Ă�ł��������B
	for(int i=0; i<forces.Size(); i++)
		{
		forces[i]->pRoot = NULL;
		delete forces[i];
		forces[i] = NULL;
		}
	}
void CFrame::Cleanup()
	{
	Root()->forces.BeforeDeleteFrame(this);
	StopThis();
	moves.Clear();
	PMotion(NULL);
	}
CFrame* CFrame::Root()
	{
	CFrame* pFrame = this;
	CFrame* pParent = Parent();
	while(pParent)
		{
		pFrame = pParent;
		pParent = pFrame->Parent();
		}
	return pFrame;
	}
void CFrame::MoveThis()
	{
	//	������Motion�������Ă��Ȃ��t���[���͓����Ȃ�
	if (bMove) return;
	if (!pMotion || pMotion->PFrame() != this) return;
	Root()->moves.Add(this);
	bMove = true;
	bMovesHaveThis = true;
	UpdateMove();
	if (Parent()) Parent()->UpdateGlobe();
	}
void CFrame::StopThis()
	{
	if (!bMove) return;
	Root()->moves.FindDel(this);
	bMove = false;
	bMovesHaveThis = false;
	UpdateMove();
	if (Parent()) Parent()->UpdateGlobe();
	}
void CFrame::MoveMoves()	//	moves��root�Ɉڂ�
	{
	CFrame* rt = Root();
	if (this != rt)
		{
		rt->moves.Move(moves);
		if (bMove && !bMovesHaveThis)
			{
			rt->moves.Add(this);
			bMovesHaveThis = true;
			}
		rt->forces.Add(forces);
		forces.Clear();
		}
	}
void CFrame::PMotionHelper(CFrame* pFr, CMotion* m)
	{
	if (pFr->pMotion == m)
		{
		pFr->pMotion = NULL;
		FOREACH_STOP(pFr) PMotionHelper(pStop, m);
		FOREACH_MOVE(pFr) PMotionHelper(pMove, m);
		}
	}
void CFrame::PMotion(CMotion* m)
	{
	if (pMotion && pMotion->PFrame() == this) delete pMotion;
	if (m) m->PFrame(this);
	else PMotionHelper(this, pMotion);
	if (m) MoveThis();
	else StopThis();
	}
void CFrame::Motion(const CMotion& m)
	{
	CMotion* pM = m.Clone();
	PMotion(pM);
	}
bool CFrame::OwnMotion()
	{
	if (pMotion && pMotion->PFrame() == this) return true;
	return false;
	}
bool CFrame::HasMotion()
	{
	if (pMotion) return true;
	return false;
	}
void CFrame::CalcParentGlobe()
	{
	if (radius > 0 && Parent())
		{
		SCALER r = AfParent().Pos().Size() * AfWorld().ScaleMax() + radius;
		if (Parent()->radius < r)
			{
			Parent()->radius = r;
			Parent()->CalcParentGlobe();
			}
		}
	}
void CFrame::CalcVisualGlobe()
	{
	SCALER sc = AfWorld().ScaleMax();
	radius = 0;
	FOREACH_VISUAL(this)
		{
		pVis->UpdateGlobe();
		radius = std::max(radius, pVis->radius * sc);
		}
#ifdef TRACEALL
	TRACEALL("CFrame(%x)::CalcVisualGlobe radius = %f.\n", this, radius);
#endif
	}
void CFrame::UpdateGlobeHelper(CFrame* f)
	{
	f->CalcVisualGlobe();					//	�����̃r�W���A���̓��鋅�ɂ���
	FOREACH_STOP(f)							//	�~�܂��Ă���q������悤�ɂ���
		{
		UpdateGlobeHelper(pStop);			//	�q�̑傫�����v�Z
		SCALER r = pStop->AfParent().Pos().Size() * pStop->AfWorld().ScaleMax() + pStop->radius;
		if (f->radius < r) f->radius = r;	//	�q������悤�ɍL����
		}
	}
void CFrame::UpdateGlobe()
	{
	UpdateGlobeHelper(this);				//	�����Ǝq�����鋅�ɂ���
	CalcParentGlobe();						//	�e���L����
	}
Affine CFrame::AfWorld()
	{
	if (IsMove()) return afMove;
	if (pMove) return pMove->afMove * afMove;
	return afMove;
	}
void CFrame::AfParent(const Affine& afP)
	{
	Affine afPOld = AfParent();
	AfParentImp(afP);
	if (IsMove())
		{
		if (Parent()) afMove = Parent()->AfWorld() * afP;
		else afMove = afP;
		}
	else UpdateAfMove();
	if (afPOld.ScaleMax() < afP.ScaleMax()) Update();
	}
void CFrame::AfWorld(const Affine& afW)
	{
	Affine afPW;
	CFrame* parent = Parent();
	if (parent) afPW = parent->AfWorld();
	AfParent( afPW.Inv() * afW );
	if (IsMove()) afMove = afW;
	else UpdateAfMove();
	}
void CFrame::UpdateAfMoveHelper(CFrame* pFr, const Affine& afM)
	{
	pFr->afMove = afM * pFr->AfParent();
	FOREACH_STOP(pFr) UpdateAfMoveHelper(pStop, pFr->afMove);
	}
void CFrame::UpdateAfMove()
	{
	if (IsMove())
		{
		if (Parent()) afMove = Parent()->AfWorld() * AfParent();
		else afMove = AfParent();
		FOREACH_STOP(this) UpdateAfMoveHelper(pStop, Affine());
		}
	else
		{
		if (Parent())
			{
			if (Parent()->IsMove()) afMove = AfParent();
			else afMove = Parent()->afMove * AfParent();
			}
		else afMove = AfParent();
		FOREACH_STOP(this) UpdateAfMoveHelper(pStop, afMove);
		UpdateGlobe();
		}
	}
void CFrame::UpdatePMove(CFrame* pFr, CFrame* pM)
	{
	pFr->pMove = pM;
	FOREACH_STOP(pFr) UpdatePMove(pStop, pM);
	}
void CFrame::Update()
	{
	UpdateMove();
	UpdateGlobe();
	CMoveFrames::It it;
	for(it=moves.abs.Bgn(); it<moves.abs.End(); it++)
		if (it[0] !=this) it[0]->Update();
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
		if (it[0] !=this) it[0]->Update();
	}
void CFrame::UpdateMove()
	{
	CFrame* pM;
	if (IsMove())
		{
		pMove = NULL;
		pM = this;
		}
	else if (Parent())
		{
		if (Parent()->IsMove()) pM = pMove = Parent();
		else  pM = pMove = Parent()->pMove;
		}
	else pM = pMove = NULL;
	MoveMoves();
	FOREACH_STOP(this) UpdatePMove(pStop, pM);
	UpdateAfMove();
	}
//----------------------------------------------------------------------------
//	�r�W���A���Ƃ̌�������
//
//	�r�W���A��v (�t���[��pFrVis) �̌�������
bool CFrame::FindIsect(CIsects& colsThis, CIsects& colsVis, CVisual* v, CFrame* pFrVis)
	{
	Affine afVis;
	if (pFrVis) afVis= pFrVis->AfWorld();
	return FindIsect(colsThis, colsVis, v, afVis, pFrVis);
	}
//	�r�W���A��v (�p��afVis, �t���[��pFrVis(�t���[���̎p���͖���)) �̌�������
bool CFrame::FindIsect(CIsects& colsThis, CIsects& colsVis, CVisual* v, const Affine& afVis, CFrame* pFrVis)
	{
	bool rtv = false;
	SCALER scVis = afVis.ScaleMax();
	Affine afW = AfWorld();
	if ((afVis.Pos()-AfWorld().Pos()).Square() <= Square(scVis*v->radius+radius))
		{
		FOREACH_VISUAL(this) rtv |= CVisual::IsectCheckers().Call(colsThis, pVis, afW, this, colsVis, v, afVis, pFrVis);
		FOREACH_STOP(this) rtv |= pStop->FindIsect(colsThis, colsVis, v, afVis, pFrVis);
		}
#ifdef TRACEALL
	TRACEALL("CFrame(%x)::FindIsect radius = %f.\n", this, radius);
#endif
	return rtv;
	}
//	�r�W���A���ƃV�[���̌�������
bool CFrame::FindSceneIsect(CIsects& colsRoot, CIsects& colsVis, CVisual* pVis, const Affine& afVis, CFrame* pFrVis)
	{
	CFrame* pRoot = Root();
	CMoveFrames::It it;
	bool rtv = pRoot->FindIsect(colsRoot, colsVis, pVis, afVis, pFrVis);
	for(it = pRoot->moves.abs.Bgn(); it<pRoot->moves.abs.End(); it++) 
		rtv |= it[0]->FindIsect(colsRoot, colsVis, pVis, afVis, pFrVis);
	for(it = pRoot->moves.rel.Bgn(); it<pRoot->moves.rel.End(); it++) 
		rtv |= it[0]->FindIsect(colsRoot, colsVis, pVis, afVis, pFrVis);
	return rtv;
	}
//----------------------------------------------------------------------------
//	�t���[���Ƃ̌�������
//
//	�t���[�� fr(�~�܂��Ă���q���܂�) �Ƃ��̃t���[��(�~�܂��Ă���q���܂�)�̌�������
bool CFrame::FindIsect(CIsects& colsThis, CIsects& colsFr, CFrame* fr)
	{
	if (radius == 0 || fr->radius == 0 || fr==this) return false;
	bool rtv = false;
	if ((fr->AfWorld().Pos()-AfWorld().Pos()).Square() <= Square(fr->radius+radius))
		{
		FOREACH_VISUAL(fr) rtv |= FindIsect(colsThis, colsFr, pVis, fr);
		FOREACH_STOP(fr) rtv |= FindIsect(colsThis, colsFr, pStop);
		}
	return rtv;
	}

//	���̃t���[��(�~�܂��Ă���q���܂�) �� �V�[���̌�������
bool CFrame::FindSceneIsect(CIsects& colsThis, CIsects& colsRoot)
	{
	CFrame* pRoot = Root();
	bool rtv = pRoot->FindIsect(colsRoot, colsThis, this);
	CMoveFrames::It it;
	for(it = pRoot->moves.abs.Bgn(); it<pRoot->moves.abs.End(); it++) 
		rtv |= it[0]->FindIsect(colsRoot, colsThis, this);
	for(it = pRoot->moves.rel.Bgn(); it<pRoot->moves.rel.End(); it++) 
		rtv |= it[0]->FindIsect(colsRoot, colsThis, this);
	return rtv;
	}

void CFrame::AddForce(CForce* f)
	{
	forces.Add(f);
	}
void CFrame::AddForce(const CForce& f)
	{
	forces.Add(f);
	}
void CFrame::ForceStep(SCALER dt)
	{
	forces.Step(dt);
	}

//	�P�X�e�b�v�i�߂�B�K��Root�̃��\�b�h���ĂԂ���
void CFrame::MotionStep(SCALER dt)
	{
	CMoveFrames::It it;
	//	�Փ˔��茋�ʂ̃N���A
	for(it=moves.abs.Bgn(); it<moves.abs.End(); it++) it[0]->Motion().Clear();
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++) it[0]->Motion().Clear();
	//	���x���ʒu��
	for(it=moves.abs.Bgn(); it<moves.abs.End(); it++)
		if (it[0]->pMotion) it[0]->pMotion->Step(dt);
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
		if (it[0]->pMotion) it[0]->pMotion->Step(dt);
	//	abs��rel�̔���
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
		{
		CMoveFrames::It itA;
		for(itA=moves.abs.Bgn(); itA<moves.abs.End(); itA++)
			it[0]->FindIsect(it[0]->Motion().cols, itA[0]->Motion().cols, itA[0]);
		it[0]->Motion().nFixed = it[0]->Motion().cols.Size();
		}
	//	rel��rel�̔���
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
		{
		CMoveFrames::It itr;
		for(itr=it+1; itr<moves.rel.End(); itr++)
			it[0]->FindIsect(it[0]->Motion().cols, itr[0]->Motion().cols, itr[0]);
		}
	//	�Փˌ��ʂ𑬓x�ɔ��f������
	ColEffect();
	//	�Փː��̑������̂��珇�Ɋ�����������
	while(1)
		{
		int nFixedMax = 0;
		CMoveFrames::It itMax=NULL;
		for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
			{
			if (it[0]->Motion().nFixed > nFixedMax && it[0]->Motion().bDone==false)
				{
				nFixedMax = it[0]->Motion().nFixed;
				itMax = it;
				}
			}
		if (!itMax) break;
		CMotion& mot = itMax[0]->Motion();
		CIsects& isects = itMax[0]->Motion().cols;
		mot.bDone = true;
		for(CIsects::It iti=isects.Bgn(); iti<isects.End(); iti++)
			{
			CIsect* isec = *iti;
			CIsect* opp = isec->pair;
			CMotion& motOpp = opp->pFrame->Motion();
			if (motOpp.IsAbs() || motOpp.bDone)
				{
				mot.Move(isec->overlap * opp->normal);
				}
			}
		}
	}

void CFrame::ColEffect()
	{
	CMoveFrames::It it;
	for(it=moves.abs.Bgn(); it<moves.abs.End(); it++)
		it[0]->Motion().cols.Effect();
	for(it=moves.rel.Bgn(); it<moves.rel.End(); it++)
		it[0]->Motion().cols.Effect();
	}
void CFrame::Step(SCALER dt)			//	������i�߂�
	{
	CFrame& root = *Root();
	root.ForceStep(dt);
	root.MotionStep(dt);
	}
END_NAMESPACE_HASE
