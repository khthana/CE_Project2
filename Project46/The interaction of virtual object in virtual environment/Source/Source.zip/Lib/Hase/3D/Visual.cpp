#include <Hase/Misc/Defs.h>
#include <Hase/3D/Frame.h>
#include <Hase/3D/FrameDef.h>
#include <Hase/3D/VisualB.cpp>
#define UNDEF_ALL_FRAMEB
#include <Hase/3D/FrameB.h>
