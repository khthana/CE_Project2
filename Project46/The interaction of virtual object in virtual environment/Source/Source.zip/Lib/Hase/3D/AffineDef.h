#define SCALER			float

#define Vec2			Vec2
#define VEC2_BASE		Vec2Base
#define VEC2_BASE_X		x
#define VEC2_BASE_Y		y
#define VEC2_BASE_Z		z

#define Matrix2			Matrix2
#define MATRIX2_BASE	Matrix2Base
#define MATRIX2_BASE_EX_X ex.x
#define MATRIX2_BASE_EX_Y ex.y
#define MATRIX2_BASE_EY_X ey.x
#define MATRIX2_BASE_EY_Y ey.y

#define Vec3			Vec3
#define VEC3_BASE		Vec3Base
#define VEC3_BASE_X		x
#define VEC3_BASE_Y		y
#define VEC3_BASE_Z		z

#define Matrix3				Matrix3
#define MATRIX3_BASE		Matrix3Base
#define MATRIX3_BASE_EX_X	ex.x
#define MATRIX3_BASE_EX_Y	ex.y
#define MATRIX3_BASE_EX_Z	ex.z
#define MATRIX3_BASE_EY_X	ey.x
#define MATRIX3_BASE_EY_Y	ey.y
#define MATRIX3_BASE_EY_Z	ey.z
#define MATRIX3_BASE_EZ_X	ez.x
#define MATRIX3_BASE_EZ_Y	ez.y
#define MATRIX3_BASE_EZ_Z	ez.z

#define Affine				Affine
#define AFFINE_BASE			AffineBase
#define AFFINE_BASE_EX_X	ex.x
#define AFFINE_BASE_EX_Y	ex.y
#define AFFINE_BASE_EX_Z	ex.z
#define AFFINE_BASE_EY_X	ey.x
#define AFFINE_BASE_EY_Y	ey.y
#define AFFINE_BASE_EY_Z	ey.z
#define AFFINE_BASE_EZ_X	ez.x
#define AFFINE_BASE_EZ_Y	ez.y
#define AFFINE_BASE_EZ_Z	ez.z
#define AFFINE_BASE_POS_X	pos.x
#define AFFINE_BASE_POS_Y	pos.y
#define AFFINE_BASE_POS_Z	pos.z
