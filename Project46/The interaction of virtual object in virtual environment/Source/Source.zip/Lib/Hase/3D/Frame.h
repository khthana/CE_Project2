#ifndef HASE_3D_FRAME_H
#define HASE_3D_FRAME_H

#include <Hase/Misc/Inc.h>
#include <Hase/3D/Affine.h>
#include <Hase/3D/FrameDef.h>	//	FrameB.h �̂��߂̃}�N��
#include <Hase/3D/FrameB.h>
#include <Hase/3D/MotionB.h>
#include <Hase/3D/VisualB.h>

//	�}�N���̏���
#define UNDEF_ALL_FRAMEB
#include <Hase/3D/FrameB.h>
#endif
