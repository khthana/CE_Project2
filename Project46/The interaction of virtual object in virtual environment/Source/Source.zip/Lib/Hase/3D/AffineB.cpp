#include "Hase/Misc/Inc.h"
#pragma hdrstop
BEGIN_NAMESPACE_HASE
using namespace std;

#if defined Vec2
//-----------------------------------------------------------------------------
//		Vec2
//
#ifdef _MSC_VER
size_t binLen(const Vec2& v)
	{
	return (sizeof v.VEC2_BASE_X) + (sizeof v.VEC2_BASE_Y);
	}
void binRead(istream& istr, Vec2& v)
	{
	binRead(istr, v.VEC2_BASE_X);
	binRead(istr, v.VEC2_BASE_Y);
	};
void binWrite(ostream& ostr, const Vec2& v)
	{
	binWrite(ostr, v.VEC2_BASE_X);
	binWrite(ostr, v.VEC2_BASE_Y);
	}
#endif
char Vec2::puncChar=',';
char& Vec2::PuncChar()
	{
	return puncChar;
	}
ostream& operator << (ostream& ostr, const Vec2& v)
	{
	ostr << "(" << setw(6) << v.VEC2_BASE_X << Vec2::PuncChar() << setw(6) << v.VEC2_BASE_Y << ")";
	return ostr;
	}
istream& operator >> (istream& istr, Vec2& v)
	{
	char ch;
	istr >> ch;
	if(('0' <= ch && ch <= '9') || ch == '.' || ch == '-') istr.putback(ch);
	istr >> v.VEC2_BASE_X;
	istr >> ch;
	if(('0' <= ch && ch <= '9') || ch == '.' || ch == '-') istr.putback(ch);
	istr >> v.VEC2_BASE_Y;
	if (istr.good())
		{
		if (istr.peek() == ')') istr >> ch;
		if (istr.rdstate()&ios::eofbit) istr.clear();
		}
	return istr;
	}
#endif	//	defined Vec2


#if defined Vec3
//-----------------------------------------------------------------------------
//		Vec3
//
#ifdef _MSC_VER
size_t binLen(const Vec3& v)
	{
	return (sizeof v.VEC3_BASE_X) + (sizeof v.VEC3_BASE_Y) + (sizeof v.VEC3_BASE_Z);
	}
void binRead(istream& istr, Vec3& v)
	{
	binRead(istr, v.VEC3_BASE_X);
	binRead(istr, v.VEC3_BASE_Y);
	binRead(istr, v.VEC3_BASE_Z);
	}
void binWrite(ostream& ostr, const Vec3& v)
	{
	binWrite(ostr, v.VEC3_BASE_X);
	binWrite(ostr, v.VEC3_BASE_Y);
	binWrite(ostr, v.VEC3_BASE_Z);
	}
#endif
char Vec3::puncChar=',';
char& Vec3::PuncChar()
	{
	return puncChar;
	}
ostream& operator << (ostream& ostr,const Vec3& v)
	{
	ostr << "(" << setw(3) << v.VEC3_BASE_X;
	ostr << Vec3::PuncChar() << setw(3) << v.VEC3_BASE_Y;
	ostr << Vec3::PuncChar() << setw(3) << v.VEC3_BASE_Z << ")";
	return ostr;
	}
istream& operator >> (istream& istr, Vec3& v)
	{
	char ch;
	istr >> ch;
	if(('0' <= ch && ch <= '9') || ch == '.' || ch == '-') istr.putback(ch);
	istr >> v.VEC3_BASE_X;
	istr >> ch;
	if(('0' <= ch && ch <= '9') || ch == '.' || ch == '-') istr.putback(ch);
	istr >> v.VEC3_BASE_Y;
	istr >> ch;
	if(('0' <= ch && ch <= '9') || ch == '.' || ch == '-') istr.putback(ch);
	istr >> v.VEC3_BASE_Z;
	if (istr.good())
		{
		if (istr.peek() == ')') istr >> ch;
		if (istr.rdstate()&ios::eofbit) istr.clear();
		}
	return istr;
	}
#endif	//	defined Vec3


#if defined Matrix3
//-----------------------------------------------------------------------------
//		Matrix3
//
void Matrix3::InitDirect(Vec3 a, Vec3 b, char axis)
	{
	switch(axis)
		{
		case 'x':
		case 'X':
			Ex(a.Unit());
			Ey( (b - (b*Ex())*Ex()).Unit() );
			Ez(Ex() ^ Ey());
			break;
		case 'y':
		case 'Y':
			Ey(a.Unit());
			Ez( (b - (b*Ey())*Ey()).Unit() );
			Ex(Ey() ^ Ez());
			break;
		case 'z':
		case 'Z':
			Ez(a.Unit());
			Ex( (b - (b*Ez())*Ez()).Unit() );
			Ey(Ez() ^ Ex());
			break;
		}
	}
void Matrix3::InitRot(SCALER th, char axis)
	{
	switch(axis)
		{
		case 'X':
		case 'x':
		case '0':
			MATRIX3_BASE_EX_X = SCALER(1),		MATRIX3_BASE_EY_X =	SCALER(0),			MATRIX3_BASE_EZ_X = SCALER(0);
			MATRIX3_BASE_EX_Y = SCALER(0),		MATRIX3_BASE_EY_Y =	SCALER(cos(th)),	MATRIX3_BASE_EZ_Y = -SCALER(sin(th));
			MATRIX3_BASE_EX_Z = SCALER(0),		MATRIX3_BASE_EY_Z =	SCALER(sin(th)),	MATRIX3_BASE_EZ_Z = SCALER(cos(th));
			break;
		case 'Y':
		case 'y':
		case '1':
			MATRIX3_BASE_EX_X = SCALER(cos(th)),	MATRIX3_BASE_EY_X =SCALER(0),		MATRIX3_BASE_EZ_X = SCALER(sin(th));
			MATRIX3_BASE_EX_Y = SCALER(0),			MATRIX3_BASE_EY_Y =SCALER(1),		MATRIX3_BASE_EZ_Y = SCALER(0);
			MATRIX3_BASE_EX_Z = -SCALER(sin(th)),	MATRIX3_BASE_EY_Z =SCALER(0),		MATRIX3_BASE_EZ_Z = SCALER(cos(th));
			break;
		case 'Z':
		case 'z':
		case '2':
			MATRIX3_BASE_EX_X = SCALER(cos(th)),	MATRIX3_BASE_EY_X =-SCALER(sin(th)),	MATRIX3_BASE_EZ_X = SCALER(0);
			MATRIX3_BASE_EX_Y = SCALER(sin(th)),	MATRIX3_BASE_EY_Y =SCALER(cos(th)),	MATRIX3_BASE_EZ_Y = SCALER(0);
			MATRIX3_BASE_EX_Z = SCALER(0),		MATRIX3_BASE_EY_Z =SCALER(0),		MATRIX3_BASE_EZ_Z = SCALER(1);
			break;
		default:
			{
			ASSERT(0);	//	axis �̎w�肪�s���ł�
			*this = Matrix3();
			}
			break;
		}
	}

#ifdef _MSC_VER
size_t binLen(const Matrix3& mt)
	{
	return binLen(mt.Ex()) + binLen(mt.Ey())
		+ binLen(mt.Ez());
	}
void binRead(istream& istr, Matrix3& mt)
	{
	binRead(istr, mt.Ex());
	binRead(istr, mt.Ey());
	binRead(istr, mt.Ez());
	};
void binWrite(ostream& ostr, const Matrix3& mt)
	{
	binWrite(ostr, mt.Ex());
	binWrite(ostr, mt.Ey());
	binWrite(ostr, mt.Ez());
	}
#endif
ostream& operator << (ostream& ostr, const Matrix3& mt)
	{
	ostr << mt.Ex() << " " << mt.Ey() << " " << mt.Ez();
	return ostr;
	}
istream& operator >> (istream& istr, Matrix3& mt)
	{
	Vec3 v;
	istr >> v;
	mt.Ex(v);
	istr >> v;
	mt.Ey(v);
	istr >> v;
	mt.Ez(v);
	return istr;
	}
#endif	//	defined Matrix3


#if defined Affine
//-----------------------------------------------------------------------------
//		Affine
//
void Affine::InitDirect(Vec3 a, Vec3 b, char axis, Vec3 posi)
	{
	switch(axis)
		{
		case 'x':
		case 'X':
			Ex(a.Unit());
			Ey( (b - (b*Ex())*Ex()).Unit() );
			Ez(Ex() ^ Ey());
			break;
		case 'y':
		case 'Y':
			Ey(a.Unit());
			Ez( (b - (b*Ey())*Ey()).Unit() );
			Ex(Ey() ^ Ez());
			break;
		case 'z':
		case 'Z':
			Ez(a.Unit());
			Ex( (b - (b*Ez())*Ez()).Unit() );
			Ey(Ez() ^ Ex());
			break;
		}
	Pos(posi);
	}
Affine Affine::LookAt(Vec3 posi)
	{
	Affine rtv;
	Vec3 relv = posi - Pos();
	Vec3 tv;
	SCALER sx = Ex().Size();
	SCALER sy = Ey().Size();
	SCALER sz = Ez().Size();

	// y -> x
	tv.x = relv.x;
	tv.y = SCALER(0);
	tv.z = relv.z;
	rtv.Ex((Vec3(SCALER(0), SCALER(1), SCALER(0)) ^ tv.Unit()).Unit());
	rtv.Ez(relv.Unit());
	rtv.Ey(rtv.Ez() ^ rtv.Ex());

	if (AFFINE_BASE_EY_Y < SCALER(0)) rtv *= Affine(SCALER(M_PI), 'z', Vec3());

	rtv.Ex(rtv.Ex() * sx);
	rtv.Ey(rtv.Ey() * sy);
	rtv.Ez(rtv.Ez() * sz);
	rtv.Pos(Pos());
	return rtv;
	}
void Affine::InitRot(SCALER th, char axis , Vec3 posi)
	{
	switch(axis)
		{
		case 'X':
		case 'x':
		case '0':
			AFFINE_BASE_EX_X = SCALER(1),		AFFINE_BASE_EY_X =	SCALER(0),			AFFINE_BASE_EZ_X = SCALER(0);
			AFFINE_BASE_EX_Y = SCALER(0),		AFFINE_BASE_EY_Y =	SCALER(cos(th)),	AFFINE_BASE_EZ_Y = -SCALER(sin(th));
			AFFINE_BASE_EX_Z = SCALER(0),		AFFINE_BASE_EY_Z =	SCALER(sin(th)),	AFFINE_BASE_EZ_Z = SCALER(cos(th));
			break;
		case 'Y':
		case 'y':
		case '1':
			AFFINE_BASE_EX_X = SCALER(cos(th)),	AFFINE_BASE_EY_X =SCALER(0),		AFFINE_BASE_EZ_X = SCALER(sin(th));
			AFFINE_BASE_EX_Y = SCALER(0),			AFFINE_BASE_EY_Y =SCALER(1),		AFFINE_BASE_EZ_Y = SCALER(0);
			AFFINE_BASE_EX_Z = -SCALER(sin(th)),	AFFINE_BASE_EY_Z =SCALER(0),		AFFINE_BASE_EZ_Z = SCALER(cos(th));
			break;
		case 'Z':
		case 'z':
		case '2':
			AFFINE_BASE_EX_X = SCALER(cos(th)),	AFFINE_BASE_EY_X =-SCALER(sin(th)),	AFFINE_BASE_EZ_X = SCALER(0);
			AFFINE_BASE_EX_Y = SCALER(sin(th)),	AFFINE_BASE_EY_Y =SCALER(cos(th)),	AFFINE_BASE_EZ_Y = SCALER(0);
			AFFINE_BASE_EX_Z = SCALER(0),		AFFINE_BASE_EY_Z =SCALER(0),		AFFINE_BASE_EZ_Z = SCALER(1);
			break;
		default:
			{
			ASSERT(0);	//	axis �̎w�肪�s���ł�
			*this = Affine();
			}
			break;
		}
	Pos(posi);
	}

#ifdef _MSC_VER
size_t binLen(const Affine& af)
	{
	return binLen(af.Ex()) + binLen(af.Ey())
		+ binLen(af.Ez()) + binLen(af.Pos());
	}
void binRead(istream& istr, Affine& af)
	{
	binRead(istr, af.Ex());
	binRead(istr, af.Ey());
	binRead(istr, af.Ez());
	binRead(istr, af.Pos());
	};
void binWrite(ostream& ostr, const Affine& af)
	{
	binWrite(ostr, af.Ex());
	binWrite(ostr, af.Ey());
	binWrite(ostr, af.Ez());
	binWrite(ostr, af.Pos());
	}
#endif
ostream& operator << (ostream& ostr, const Affine& af)
	{
	ostr << af.Ex() << " " << af.Ey() << " " << af.Ez() << " " << af.Pos();
	return ostr;
	}
istream& operator >> (istream& istr, Affine& af)
	{
	Vec3 v;
	istr >> v;
	af.Ex(v);
	istr >> v;
	af.Ey(v);
	istr >> v;
	af.Ez(v);
	istr >> v;
	af.Pos(v);
	return istr;
	}
#endif	//	defined Affine

END_NAMESPACE_HASE