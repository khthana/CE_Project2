#ifndef FindFrame
 #define FindFrame int
#endif
#ifndef FindVisual
 #define FindVisual int
#endif
#ifndef SCALER
 #define SCALER REAL
#endif
