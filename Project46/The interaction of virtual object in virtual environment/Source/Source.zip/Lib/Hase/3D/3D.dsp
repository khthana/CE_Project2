# Microsoft Developer Studio Project File - Name="3D" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=3D - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "3D.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "3D.mak" CFG="3D - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "3D - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe
# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MDd /W3 /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "CREATE_DLL" /YX /FD /c
# SUBTRACT CPP /Fr
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o /win32 "NUL"
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o /win32 "NUL"
# ADD BASE RSC /l 0x411 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 /nologo /subsystem:windows /dll /profile /debug /machine:I386 /out:"Debug/3DD.dll"
# Begin Target

# Name "3D - Win32 Debug"
# Begin Group "Source"

# PROP Default_Filter ".cpp"
# Begin Source File

SOURCE=.\Affine.cpp
# End Source File
# Begin Source File

SOURCE=.\Frame.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\Motion.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\Visual.cpp
# PROP Exclude_From_Build 1
# End Source File
# End Group
# Begin Group "Header"

# PROP Default_Filter ".h"
# Begin Source File

SOURCE=.\Affine.h
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\AffineB.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\AffineB.h
# End Source File
# Begin Source File

SOURCE=.\AffineDef.h
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\Frame.h
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\FrameB.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\FrameB.h
# End Source File
# Begin Source File

SOURCE=.\FrameDef.h
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\MotionB.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\MotionB.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\VisualB.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\VisualB.h
# End Source File
# End Group
# End Target
# End Project
