#include <Hase/3D/Affine.h>
#include <Hase/3D/AffineDef.h>
#include <Hase/3D/AffineB.cpp>
#define UNDEF_ALL_AFFINEB
#include <Hase/3D/AffineB.h>
