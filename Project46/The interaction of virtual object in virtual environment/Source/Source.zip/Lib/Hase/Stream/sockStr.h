#ifndef SOCKSTR_H
#define SOCKSTR_H
#include <Hase/Misc/Inc.h>
#include <afxsock.h>
#include "strbufBase.h"


BEGIN_NAMESPACE_HASE
class CSockStream;
class CSockStreambuf;
class DLLCLASS CCloseSocket:public CSocket
	{
public:
	CCloseSocket();
	~CCloseSocket();
	CSockStream* stream;
	virtual void OnClose(int nErrorCode);
	};
class DLLCLASS CSockStreambuf:public CStreambufBase
	{
	friend CSockStream;
	public:
	int lastError;
	char* lastErrorStr;
	CSockStreambuf(char* gb, int gl, char* pb, int pl);
	~CSockStreambuf();
	protected:
	UINT read(void* buf, UINT bufLen);
	UINT write(void* buf, UINT bufLen);
	virtual int in_avail_stream();

	CCloseSocket sock;
	CAsyncSocket server;
	UINT port;
	volatile bool bConnected;
	volatile bool bListening;
	volatile bool bServer;
	public:
	bool IsConnected(){return bConnected;}
	bool IsListening(){return bListening;}
	bool IsServer(){return bServer;}
	};
class DLLCLASS CSockStream:public STREAM_STD__ iostream
	{
	friend CCloseSocket;
	void OnClose(int nError);
	public:
	const char* LastError();
	CSockStream();
	~CSockStream();
	CSockStreambuf buf;
	bool connect(const char* addr, UINT port);
	bool listen(UINT port);
	bool accept();
	bool IsConnected();
	enum{BUFFERLEN = 1000};
	char getBuffer[BUFFERLEN];
	char putBuffer[BUFFERLEN];
	char* errorMessage(int errorNum);
	int avail();
	void close();
	};
END_NAMESPACE_HASE
#endif