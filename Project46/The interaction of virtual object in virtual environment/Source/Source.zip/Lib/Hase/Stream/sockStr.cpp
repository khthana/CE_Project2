#include "sockStr.h"
#pragma hdrstop
BEGIN_NAMESPACE_HASE
using namespace std;
CCloseSocket::CCloseSocket()
	{
	stream = NULL;
	}
CCloseSocket::~CCloseSocket()
	{
	if (stream) stream->OnClose(0);
	}
void CCloseSocket::OnClose(int nErrorCode)
	{
	CSocket::OnClose(nErrorCode);
	if (stream) stream->OnClose(nErrorCode);
	}

CSockStreambuf::CSockStreambuf(char* gb, int gl, char* pb, int pl):
	CStreambufBase(gb, gl, pb, pl)
	{
	bConnected = false;
	bListening = false;
	bServer = false;
	lastError = 0;
	lastErrorStr = NULL;
	AfxSocketInit();
	}
CSockStreambuf::~CSockStreambuf()
	{
	sock.Close();
	server.Close();
	}
#undef MIN
#define MIN(x,y)	((x)<(y) ? (x) : (y))
UINT CSockStreambuf::read(void* buf, UINT bufLen)
	{
	if (!bConnected) return 0;	
	DWORD avail=0;
	sock.IOCtl(FIONREAD, &avail);
	if (avail <= 0) return 0;
	return sock.Receive(buf, MIN(bufLen, avail));
	}
UINT CSockStreambuf::write(void* buf, UINT bufLen)
	{
	if (!bConnected) return 0;	
	return sock.Send(buf, bufLen);
	}
int CSockStreambuf::in_avail_stream()
	{
	DWORD av = 0;
	if (bConnected)	sock.IOCtl(FIONREAD, &av);
	return av;
	}

CSockStream::CSockStream():
	buf(getBuffer, BUFFERLEN, putBuffer, BUFFERLEN),
	iostream(&buf)
	{
	clear(ios::badbit);
	buf.sock.stream = this;
	}
CSockStream::~CSockStream()
	{
	buf.sock.stream = NULL;
	}
void CSockStream::OnClose(int nError)
	{
	buf.bConnected = false;
	if (buf.bServer)
		{
		//buf.bServer = false;
		buf.bListening = false;
		listen(buf.port);
		}
	}

bool CSockStream::connect(const char* addr, UINT port)
	{
	buf.server.Close();
	buf.sock.Close();
	if (buf.bConnected) Sleep(1000);
	buf.bConnected = false;
	buf.bServer = false;
	buf.bListening = false;
	buf.sock.Create();
	if (buf.sock.Connect(addr, port))
		{
		buf.bConnected = true;
		flush();
		clear();
		return true;
		}
	else
		{
		buf.lastError = buf.sock.GetLastError();
		buf.lastErrorStr = errorMessage(buf.lastError);
		return false;
		}
	}
bool CSockStream::listen(UINT p)
	{
	if (buf.bListening) return false;
	buf.server.Close();
	buf.sock.Close();
	if (buf.bConnected) Sleep(1000);
	buf.bConnected = false;
	buf.bServer = false;
	if (buf.server.Create(p) == 0)
		{
		buf.lastError = buf.server.GetLastError();
		buf.lastErrorStr = errorMessage(buf.lastError);
		return false;
		}
	buf.port = p;
	if (buf.server.Listen())
		{
		buf.bListening = true;
		return true;
		}
	else
		{
		buf.lastError = buf.server.GetLastError();
		buf.lastErrorStr = errorMessage(buf.lastError);
		buf.bListening = false;
		return false;
		}
	}
bool CSockStream::accept()
	{
	if (buf.bConnected) return false;
	if (!buf.bListening) return false;
	if (buf.server.Accept(buf.sock))
		{
		buf.bListening = false;
		buf.bConnected = true;
		buf.bServer = true;
		clear();
		return true;
		}
	else
		{
		buf.lastError = buf.server.GetLastError();
		return false;
		}
	}
bool CSockStream::IsConnected()
	{
	return buf.bConnected;
	}

int CSockStream::avail()
	{
	if(!good()) return -1;
#if 1
	DWORD av = 0;
	DWORD rtv = buf.in_avail();
	if (buf.bConnected)	
		{
		buf.sock.IOCtl(FIONREAD, &av);
		}
	else return -1;
	return rtv + av;
#else
	return tellg();
#endif
	}
void CSockStream::close()
	{
	buf.sock.Close();
	buf.server.Close();
	buf.bConnected = false;
	buf.bServer = false;
	buf.bListening = false;
	}

char* CSockStream::errorMessage(int errorNum)
	{
	char* rtv = "";
	switch(errorNum)
		{
		case WSANOTINITIALISED:	rtv = "A successful WSAStartup must occur before using this function.";	break;
		case WSAENETDOWN:		rtv = "The Windows Sockets implementation has detected that the network subsystem has failed.";	break;
		case WSAEADDRINUSE:		rtv = "An attempt has been made to listen on an address in use.";	break;
		case WSAEINPROGRESS:	rtv = "A blocking Windows Sockets operation is in progress.";	break;
		case WSAEINVAL:			rtv = "The socket has not been bound with bind or is already connected.";	break;
		case WSAEISCONN:		rtv = "The socket is already connected.";	break;
		case WSAEMFILE:			rtv = "No more file descriptors are available.";	break;
		case WSAENOBUFS:		rtv = "No buffer space is available.";	break;
		case WSAENOTSOCK:		rtv = "The descriptor is not a socket.";	break;
		case WSAEOPNOTSUPP:		rtv = "The referenced socket is not of a type that supports the listen operation.";	break;
		case WSAEFAULT:			rtv = "The addrlen argument is too small (less than the size of a sockets address structure).";	break;
		case WSAEINTR:			rtv = "The (blocking) call was canceled using WSACancelBlockingCall.";	break;
		case WSAEWOULDBLOCK:	rtv = "The socket is marked as nonblocking and no connections are present to be accepted.";	break;
		case WSAEADDRNOTAVAIL:	rtv = "The specified address is not available from the local computer.";	break;
		case WSAEAFNOSUPPORT:	rtv = "Addresses in the specified family cannot be used with this socket.";	break;
		case WSAECONNREFUSED:	rtv = "The attempt to connect was forcefully rejected.";	break;
		case WSAENETUNREACH:	rtv = "The network can't be reached from this host at this time.";	break;
		case WSAETIMEDOUT:		rtv = "Attempt to connect timed out without establishing a connection.";	break;
		case WSAEHOSTUNREACH:	rtv = "The host can't be reached from this host."; break;
		default:
			{
			static char buf[256];
			ostrstream ostr(buf, 256);
			ostr.setf(ios::dec);
			ostr << "Unknown error #" << errorNum << " occuered." << '\0';
			rtv = buf;
			}break;
		}
	return rtv;
	}

const char* CSockStream::LastError()
	{
	return errorMessage(buf.lastError);
	}
END_NAMESPACE_HASE
