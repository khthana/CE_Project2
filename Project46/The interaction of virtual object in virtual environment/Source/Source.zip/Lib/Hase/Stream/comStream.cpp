#pragma hdrstop
#include <hase/stream/comStream.h>
BEGIN_NAMESPACE_HASE
using namespace std;
//----------------------------------------------------------------------------
//	CComStatus
//
CComStatus::CComStatus()
	{
	flowControl	= FC_NONE;	//	�t���[����Ȃ�
	port		= 0;		//	COM1
	boudRate	= 9600;		//	9600bps
	byteSize	= 8;		//	8bit
	parity		= 0;		//	�p���e�B�Ȃ�
	stopBits	= 0;		//	�X�g�b�v�r�b�g�P
	}

//----------------------------------------------------------------------------
//	CComStreamBuf
//
CComStreambuf::CComStreambuf(const CComStatus& cs, char* gb, int gl, char* pb, int pl):
	CStreambufBase(gb, gl, pb, pl),
	CComStatus(cs)
	{
	hFile = NULL;
	}

CComStreambuf::~CComStreambuf()
	{
	}

bool CComStreambuf::init(const CComStatus& cs)
	{
	*(CComStatus*)this = cs;
	return init();
	}
bool CComStreambuf::init()
	{
	if (!openConnection()) return false;
	if (!setupConnection())
		{
		closeConnection();
		return false;
		}
	return true;
	}

bool CComStreambuf::openConnection()
	{
	// load the COM prefix string and append port number
	char szPort[256];
	ostrstream(szPort, 256) << "COM" << port+1 << '\0';

	// open COMM device
	hFile = CreateFile( szPort, GENERIC_READ | GENERIC_WRITE,
			0,                    // exclusive access
			NULL,                 // no security attrs
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,//|FILE_FLAG_OVERLAPPED,
			NULL );
	if (hFile == (HANDLE)-1 ) return false;

	// get any early notifications
	int error = 0;
	if (!SetCommMask ( hFile, EV_RXCHAR ))
		error = GetLastError();

	// setup device buffers
	if (!SetupComm( hFile, COMBUFLEN, COMBUFLEN )) 
		error = GetLastError();

	// purge any information in the buffer
	if (!PurgeComm( hFile, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ))
		error = GetLastError();
	
	// �ł��邾���ǂݏo���̃^�C���A�E�g�͒Z������B
	COMMTIMEOUTS commTimeOuts;
	if (!GetCommTimeouts( hFile, &commTimeOuts ))
		error = GetLastError();
	commTimeOuts.ReadIntervalTimeout = 1;
	commTimeOuts.ReadTotalTimeoutMultiplier = 0;
	commTimeOuts.ReadTotalTimeoutConstant = 1;
	// CBR_9600 is approximately 1byte/ms. For our purposes, allow
	// double the expected time per character for a fudge factor.
	commTimeOuts.WriteTotalTimeoutMultiplier = 2*CBR_9600/ boudRate;
	commTimeOuts.WriteTotalTimeoutConstant = 0 ;
	if (!SetCommTimeouts( hFile, &commTimeOuts ))
		error = GetLastError();
	return true;
	}

bool CComStreambuf::setupConnection()
	{
	DCB	dcb;
	int error;
	dcb.DCBlength = sizeof( DCB ) ;
	if (!GetCommState(hFile, &dcb))
		error = GetLastError();
	dcb.BaudRate	= boudRate;
	dcb.ByteSize	= byteSize;
	dcb.Parity		= parity;
	dcb.StopBits	= stopBits;
	// setup hardware flow control
	bool fSet;
	fSet = (flowControl == FC_DTRDSR || flowControl == FC_HARDWARE);
	dcb.fOutxDsrFlow = fSet;
	if (fSet) dcb.fDtrControl = DTR_CONTROL_HANDSHAKE ;
	else dcb.fDtrControl = DTR_CONTROL_ENABLE ;

	fSet = (flowControl == FC_RTSCTS || flowControl == FC_HARDWARE);
	dcb.fOutxCtsFlow = fSet ;
	if (fSet) dcb.fRtsControl = RTS_CONTROL_HANDSHAKE ;
	else dcb.fRtsControl = RTS_CONTROL_ENABLE ;


	// setup software flow control
	fSet = (flowControl == FC_XONXOFF);
	dcb.fInX = dcb.fOutX = fSet ;
	dcb.XonChar = ASCII_XON ;
	dcb.XoffChar = ASCII_XOFF ;
	dcb.XonLim = 100 ;
	dcb.XoffLim = 100 ;
	// other various settings
/*
	dcb.fBinary = TRUE ;
*/
	dcb.fParity = TRUE ;
	if (SetCommState(hFile, &dcb) == 0)
		{
		int error = GetLastError();
		return false;
		};
	return true;
	}

void CComStreambuf::closeConnection()
	{
	if (!hFile) return;

	// drop DTR
	EscapeCommFunction( hFile, CLRDTR ) ;

	// purge any outstanding reads/writes and close device handle
	PurgeComm( hFile, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR ) ;
	CloseHandle( hFile ) ;
	hFile = NULL;
	return;
	}
void CComStreambuf::cleanup()
	{
	closeConnection();
	}

UINT CComStreambuf::read(void* buf, UINT bufLen)
	{
	DWORD len = std::min(bufLen, comAvail());
	ReadFile(hFile, buf, len, &len, NULL);
	return len;
	}

UINT CComStreambuf::write(void* buf, UINT bufLen)
	{
	DWORD len = std::min(bufLen, COMBUFLEN - comWaiting());
	if ((int)len <= 0) return 0;
	WriteFile(hFile, buf, len, &len, NULL);
	return len;
	}
UINT CComStreambuf::comAvail()
	{
	COMSTAT comStat;
	DWORD dwErrorFlags;
	ClearCommError(hFile, &dwErrorFlags, &comStat);
	return comStat.cbInQue;
	}
UINT CComStreambuf::comWaiting()
	{
	COMSTAT comStat;
	DWORD dwErrorFlags;
	ClearCommError(hFile, &dwErrorFlags, &comStat);
	return comStat.cbOutQue;
	}

//----------------------------------------------------------------------------
//	CComStream
//
CComStream::CComStream():
	buf(comStatus, getbuf, sizeof getbuf, putbuf, sizeof putbuf),
	iostream(&buf)
	{
	init(comStatus);
	}
CComStream::CComStream(const CComStatus& cs):
	buf(cs, NULL,0,NULL,0),
	iostream(&buf)
	{
	init(cs);
	}
int CComStream::avail()
	{
	if (!good()) return -1;
	return buf.in_avail() + buf.comAvail();
	}
bool CComStream::init(const CComStatus& cs)
	{
	buf.closeConnection();
	if (buf.init(cs))
		{
		clear();
		return true;
		}
	setf (ios::badbit);
	return false;
	}

CComStream::~CComStream()
	{
	buf.cleanup();
	}
END_NAMESPACE_HASE
