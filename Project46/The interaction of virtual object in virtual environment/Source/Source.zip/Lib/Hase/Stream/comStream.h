#ifndef COMSTREAM_H
#define COMSTREAM_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <Hase/Misc/Inc.h>
#include <Hase/Stream/StrbufBase.h>

BEGIN_NAMESPACE_HASE
class CComStream;
class CComStreambuf;
struct DLLCLASS CComStatus
	{
	enum {FC_NONE, FC_DTRDSR, FC_RTSCTS, FC_HARDWARE,
		FC_XONXOFF, FC_SOFTWARE=FC_XONXOFF} flowControl;
	int		port;
	DWORD	boudRate;
	BYTE	byteSize;
	BYTE	parity;
	BYTE	stopBits;
	CComStatus();
	};
class DLLCLASS CComStreambuf:public CStreambufBase, public CComStatus
	{
	friend CComStream;
	public:
	enum {COMBUFLEN = 4096};	
	enum {ASCII_XON = 0x11, ASCII_XOFF = 0x13};
	CComStreambuf(const CComStatus& cs,
		char* gb, int gl, char* pb, int pl);
	~CComStreambuf();
	protected:
	HANDLE hFile;
	bool init();
	bool init(const CComStatus& cs);
	bool openConnection();
	bool setupConnection();
	void closeConnection();
	void cleanup();
	UINT read(void* buf, UINT bufLen);
	UINT write(void* buf, UINT bufLen);
	UINT comAvail();
	UINT comWaiting();
	virtual int in_avail_stream()
		{
		return comAvail();
		}
	};
class DLLCLASS CComStream:public STREAM_STD__ iostream
	{
	char getbuf[1024];
	char putbuf[1024];
	public:
	CComStatus comStatus;
	CComStream(const CComStatus& cs);
	CComStream();
	~CComStream();
	CComStreambuf buf;
	int avail();
	bool init(const CComStatus& cs);
	};
END_NAMESPACE_HASE
#endif