#include <hase/stream/WinStream.h>
#ifdef USEMFC
#include <afxext.h>
#endif
#pragma hdrstop
using namespace std;
BEGIN_NAMESPACE_HASE
//----------------------------------------------------------------------------
//	CWinStream
//
static CWinStream* firstCreate;
CWinStream& CWinStream::First()
	{
	if (firstCreate) return *firstCreate;
	static CWinStream ostr;
	return ostr;
	}
CWinStream::CWinStream(int nLine):
	buf(nLine),
	CPrintfStream<ostream>(&buf)
	{
	buf.ws = this;
	topLine = 0;
	leftX = 0;
	lineBlank = 2;
	lineHeight = lineBlank;
	bEraseBkGnd = true;
	hFont = CreateFont(0, 0, 0, 0, FW_NORMAL, false, false, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, "�l�r �S�V�b�N");
	hWnd = NULL;
	deleteCallback = NULL;
	arg = NULL;
	if (!firstCreate) firstCreate = this;
	}
CWinStream::~CWinStream()
	{
	if (firstCreate==this) firstCreate = NULL;
	if (deleteCallback) deleteCallback(arg);
	DeleteObject(hFont);
	}
void CWinStream::Lines(int nLine)
	{
	buf.Lines(nLine);
	}
void CWinStream::OnDraw(HDC hDC)
	{
	HGDIOBJ hOldFont = SelectObject(hDC, hFont);
	if (hWnd)
		{
		if (topLine > Lines() - WinLines())
			topLine = Lines() - WinLines();
		if (topLine < 0) topLine = 0;
		if (Lines() > WinLines())
			{
			ShowScrollBar(hWnd, SB_VERT, true);
			SetScrollRange(hWnd, SB_VERT, 0, std::max(0, Lines() - WinLines()), true);
			SetScrollPos(hWnd, SB_VERT, topLine, true);
			}
		else
			{
			ShowScrollBar(hWnd, SB_VERT, false);
			}
		if (Width() > WinWidth())
			{
			ShowScrollBar(hWnd, SB_HORZ, true);
			SetScrollRange(hWnd, SB_HORZ, 0, std::max(0, Width() - WinWidth()), true);
			SetScrollPos(hWnd, SB_HORZ, leftX, true);
			}
		else
			{
			ShowScrollBar(hWnd, SB_HORZ, false);
			}
		}
	SIZE szCharW, szCharH;
	GetTextExtentPoint32(hDC, "W", strlen("W"), &szCharW);
	GetTextExtentPoint32(hDC, "fg��", strlen("fg��"), &szCharH);
	viewportWidth = szCharW.cx * buf.colMax;
	lineHeight = szCharH.cy + lineBlank;
	int drawLines = (rcDraw.bottom-rcDraw.top) / lineHeight + 1;
	int textLines = std::min(drawLines, (int)buf.vbuf.Size() - topLine);
	for(int y=0; y<textLines; y++)
		{
		RECT rc;
		rc.left = 0;
		rc.top = y*lineHeight;
		rc.right = rcDraw.right-rcDraw.left + leftX;
		rc.bottom = y*lineHeight+lineHeight;
		ExtTextOut(hDC, -leftX, y*lineHeight, ETO_OPAQUE|ETO_CLIPPED, &rc,
			buf.vbuf[y+topLine].c_str(), buf.vbuf[y+topLine].length(), NULL);
		}
	for(; y<drawLines; y++)
		{
		RECT rc;
		rc.left = 0;
		rc.top = y*lineHeight;
		rc.right = rcDraw.right - rcDraw.left;
		rc.bottom = y*lineHeight+lineHeight;
		ExtTextOut(hDC, 0, y*lineHeight, ETO_OPAQUE|ETO_CLIPPED, &rc, "", 0, NULL);
		}
	SelectObject(hDC, hOldFont);
	}
void CWinStream::Invalidate()
	{
	if (hWnd) InvalidateRect(hWnd, &rcDraw, false);
	}
void CWinStream::OnSize()
	{
	bool flag = false;
	if (topLine >= Lines() - WinLines()) flag = true;
	if (hWnd) GetClientRect(hWnd, &rcDraw);
	if (flag) topLine = std::max(Lines() - WinLines(), 0);
	if (WinWidth() > Width()-leftX) leftX = Width()-WinWidth();
	if (leftX<0) leftX = 0;
	}

void CWinStream::OnHScroll(UINT nSBCode, UINT nPos)
	{
	switch(nSBCode)
		{
		case SB_THUMBTRACK:
		case SB_THUMBPOSITION:
			leftX = nPos;
			break;
		case SB_BOTTOM:
			leftX = Width() - WinWidth();
			break;
		case SB_LINEDOWN:
			leftX++;
			if (leftX > Width() - WinWidth())
				leftX = Width() - WinWidth();
			break;
		case SB_PAGEDOWN:
			leftX+= WinWidth();
			if (leftX > Width() - WinWidth())
				leftX = Width() - WinWidth();
			break;
		case SB_LINEUP:
			leftX--;
			if (leftX < 0) leftX = 0;
			break;
		case SB_PAGEUP:
			leftX-= WinWidth();
			if (leftX < 0) leftX = 0;
			break;
		}
	Invalidate();
	}
void CWinStream::OnVScroll(UINT nSBCode, UINT nPos)
	{
	switch(nSBCode)
		{
		case SB_THUMBTRACK:
		case SB_THUMBPOSITION:
			topLine = nPos;
			break;
		case SB_BOTTOM:
			topLine = Lines() - WinLines();
			break;
		case SB_LINEDOWN:
			topLine++;
			if (topLine > Lines() - WinLines())
				topLine = Lines() - WinLines();
			break;
		case SB_PAGEDOWN:
			topLine+= WinLines();
			if (topLine > Lines() - WinLines())
				topLine = Lines() - WinLines();
			break;
		case SB_LINEUP:
			topLine--;
			if (topLine < 0) topLine = 0;
			break;
		case SB_PAGEUP:
			topLine-= WinLines();
			if (topLine < 0) topLine = 0;
			break;
		}
	if (topLine < 0) topLine = 0;
	Invalidate();
	}

//----------------------------------------------------------------------------
//	CWinStreambuf
//
CWinStreambuf::CWinStreambuf(int nLine):
	CStreambufBase(NULL, 0, NULL, 0),
	vbuf(nLine)
	{
	ws = NULL;
	cur = 0;
	colMax = 0;
	}
CWinStreambuf::~CWinStreambuf()
	{
	}
void CWinStreambuf::CalcColMax()
	{
	for(int i=0; i<=cur; i++)
		colMax = std::max(colMax, (int)vbuf[i].length());
	}
UINT CWinStreambuf::write(void* buf, UINT bufLen)
	{
	char* str = (char*)buf;
	for(UINT i=0; i<bufLen; i++)
		{
		if (str[i] == '\n')
			{
			if (cur < vbuf.Size()-1) cur++;
			else		//	�o�b�t�@�ɋ󂫂��Ȃ��̂Ń����O�o�b�t�@��i�߂�B
				{
				if (vbuf[0].length() == colMax) CalcColMax();
				vbuf[0] = "";	//	��ԌÂ��o�b�t�@(0�s��)���폜
				vbuf.Add();		//	�����O�o�b�t�@��i�߂�
				ws->topLine --;	//	�擪�s���������̂ŁA�\���ʒu�J�n�s��1���炷
				}
			//	�����ŉ��s��\�����Ă���Ύ����X�N���[��������B
			if (ws->topLine >= ws->Lines() - ws->WinLines()-1) ws->topLine ++;
			}
		else vbuf[cur] += str[i];
		}
	colMax = std::max(colMax, (int) vbuf[cur].length());
	ws->Invalidate();
	return bufLen;
	}
void CWinStreambuf::Lines(int nLine)
	{
	if (nLine < vbuf.Size())
		{
		return; //	not yet implimented.
		}
	vbuf.Size(nLine);
	}
//----------------------------------------------------------------------------
//	CWinStreamView
//
#ifdef USEMFC
using namespace Hase;
IMPLEMENT_DYNCREATE(CWinStreamView, CView)
CWinStreamView::CWinStreamView()
	{
	pWinStr = NULL;
	}
CWinStreamView::~CWinStreamView()
	{
	if (pWinStr)
		{
		pWinStr->deleteCallback = NULL;
		pWinStr->arg = NULL;
		}
	}
static void CStreamView_deleteCallback(void* arg)
	{
	CWinStreamView* v = (CWinStreamView*) arg;
	v->pWinStr = NULL;
	}
void CWinStreamView::WinStream(CWinStream& ws)
	{
	pWinStr = &ws;
	pWinStr->hWnd = m_hWnd;
	pWinStr->deleteCallback = CStreamView_deleteCallback;
	pWinStr->arg = this;
	}
BEGIN_MESSAGE_MAP(CWinStreamView, CView)
	//{{AFX_MSG_MAP(CWinStreamView)
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//
// CWinStreamView ���b�Z�[�W �n���h��
//
int CWinStreamView::OnCreate(LPCREATESTRUCT pCS)
	{
	CView::OnCreate(pCS);
	if (pWinStr) pWinStr->hWnd = m_hWnd;	
	return 0;
	}
void CWinStreamView::OnDestroy()
	{
	if (pWinStr) pWinStr->hWnd = NULL;
	CView::OnDestroy();
	}
void CWinStreamView::OnSize(UINT nType, int cx, int cy) 
	{
	CView::OnSize(nType, cx, cy);
	
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����Ă�������
	if (pWinStr) pWinStr->OnSize();
	}
afx_msg BOOL CWinStreamView::OnEraseBkgnd( CDC* pDC )
	{
	return true;
	}

BOOL CWinStreamView::PreCreateWindow(CREATESTRUCT& cs)
	{
	cs.lpszName = "CWinStreamView";
	return CWnd::PreCreateWindow(cs);
	}
void CWinStreamView::OnDraw(CDC* pDC) 
	{
	if (pWinStr) pWinStr->OnDraw(pDC->m_hDC);
	else
		{
		CRect rc;
		GetClientRect(rc);
		pDC->PatBlt(rc.left, rc.top, rc.Size().cx, rc.Size().cy, WHITENESS);
		}
	}
void CWinStreamView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
	{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	if (pWinStr) pWinStr->OnHScroll(nSBCode, nPos);
	CView::OnHScroll(nSBCode, nPos, pScrollBar);
	}
void CWinStreamView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
	{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	if (pWinStr) pWinStr->OnVScroll(nSBCode, nPos);
	CView::OnVScroll(nSBCode, nPos, pScrollBar);
	}
//----------------------------------------------------------------------------
//	CStreamFrame
//
class CStreamFrame:public CFrameWnd
	{
	public:
	CWinStreamWin* streamWin;
	CStreamFrame(CWinStreamWin* sw)
		{
		streamWin = sw;
		}
	//{{AFX_MSG(CStreamFrame)
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	};
BEGIN_MESSAGE_MAP(CStreamFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CStreamFrame)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
void CStreamFrame::OnDestroy()
	{
	streamWin->wndFrame = NULL;
	}
//----------------------------------------------------------------------------
//	CWinStreamWin
//
CWinStreamWin::CWinStreamWin(const char* cap)
	{
	caption = cap ? cap : "";
	wndFrame = NULL;
	rect.top = 10;
	rect.left = 10;
	rect.bottom = 300;
	rect.right = 300;
	}
CWinStreamWin::~CWinStreamWin()
	{
	if (wndFrame) wndFrame->DestroyWindow();
	}
void CWinStreamWin::DestroyWindow()
	{
	if (wndFrame) wndFrame->DestroyWindow();
	}
bool CWinStreamWin::Toggle()
	{
	return Toggle(AfxGetMainWnd());
	}
bool CWinStreamWin::Toggle(CWnd* parent)
	{
	if (wndFrame)
		{
		wndFrame->DestroyWindow();
		return false;
		}
	return Create(parent);
	}
bool CWinStreamWin::Create()
	{
	return Create(AfxGetMainWnd());
	}
bool CWinStreamWin::Create(CWnd* parent)
	{
	if (wndFrame)
		{
		wndFrame->SetParent(parent);
		wndFrame->SetWindowPos(&CWnd::wndNoTopMost, 0,0,0,0, SWP_NOMOVE|SWP_NOSIZE);
		return true;
		}
	CCreateContext cc;
	cc.m_pNewViewClass = RUNTIME_CLASS(CWinStreamView);
	wndFrame = new CStreamFrame(this);
	wndFrame->Create(NULL, caption.c_str(), WS_OVERLAPPEDWINDOW|WS_POPUP|WS_VISIBLE, rect, parent, NULL, NULL, &cc);
	CWinStreamView* sv = (CWinStreamView*)wndFrame->GetWindow(GW_CHILD);
	if (!sv && wndFrame)
		{
		wndFrame->DestroyWindow();
		return false;
		}
	sv->WinStream(*this);
	return true;
	}
#endif
END_NAMESPACE_HASE
