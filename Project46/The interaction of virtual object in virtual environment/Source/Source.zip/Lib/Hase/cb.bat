lha32 u -rx haselib.lzh makefile *.mak *.h *.c *.cpp *.asm *.pas *.dfm *.dat *.cnf *.def *.bat *.doc *.mdp *.dsw *.dsp *.rc* *.ico *.bmp *.cur *.3dwav *.wav *.x *.jpg *.htm *.html
