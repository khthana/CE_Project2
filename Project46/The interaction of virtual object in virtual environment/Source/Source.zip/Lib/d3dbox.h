//--------------------------------------------------------------------------
#ifndef D3DBoxH
#define D3DBoxH
//---------------------------------------------------------------------------
#include <vcl\SysUtils.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
//---------------------------------------------------------------------------
#define NOMFC
#pragma warn -csu
#pragma warn -pch
#pragma warn -hid
#include <Hase/Misc/inc.h>
#include <Hase/D3D/HD3DRMEx.h>
#pragma warn .pch
#pragma warn .csu


typedef void  __fastcall (__closure* TD3DBuildSceneEvent)(Hase::CD3DRMEx& rm);
typedef void  __fastcall (__closure* TD3DRenderEvent)(Hase::CD3DRMEx& rm, Hase::CDDSurface& surf);
class TD3DBox : public TWinControl
	{
private:
	TD3DBuildSceneEvent buildSceneEvent;
	TD3DRenderEvent beforeRenderEvent;
	TD3DRenderEvent afterRenderEvent;
	int fullWidth, fullHeight, fullBPP;
	bool fullscreen;
	static int instanceCount;
	void __fastcall SetDriver(int drv);
	int __fastcall GetDriver();
	void __fastcall SetFullscreen(bool f);
	bool __fastcall IsFullscreen();
protected:
	BEGIN_MESSAGE_MAP
		MESSAGE_HANDLER(WM_SIZE, TWMSize, WMSize)
		MESSAGE_HANDLER(WM_PAINT, TWMPaint, WMPaint)
	END_MESSAGE_MAP(TWinControl)
	virtual void __fastcall WMSize(TWMSize& msg);
	virtual void __fastcall WMPaint(TWMPaint& msg);
	virtual void __fastcall CreateWindowHandle(const TCreateParams &Params);
	virtual void __fastcall DestroyWindowHandle(void);
public:
	static Hase::CDDraws* pDDraw;
	Hase::CD3DDevice* pSurf;
	Hase::CD3DRMEx* pRM;
	virtual __fastcall TD3DBox(TComponent* Owner);
	virtual __fastcall ~TD3DBox();
//	propertys	---------------------------------------------------------------
__published:
	__property TD3DBuildSceneEvent BuildScene = {read=buildSceneEvent, write = buildSceneEvent};
	__property TD3DRenderEvent BeforeRender = {read=beforeRenderEvent, write = beforeRenderEvent};
	__property TD3DRenderEvent AfterRender = {read=afterRenderEvent, write = afterRenderEvent};
	__property int FullWidth = {read=fullWidth, write = fullWidth};
	__property int FullHeight = {read=fullHeight, write = fullHeight};
	__property int FullBPP = {read=fullBPP, write = fullBPP};
	__property int Driver = {read=GetDriver, write = SetDriver};
	__property Align;
	__property Width;
	__property Height;
	__property Visible;
public:
	__property bool Fullscreen = {read = IsFullscreen, write=SetFullscreen};

//	methods	---------------------------------------------------------------
	bool __fastcall Render();
//	-----------------------------------------------------------------------
};
//---------------------------------------------------------------------------
#pragma warn .hid
#endif
