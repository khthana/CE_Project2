Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
<WebService(Namespace := "http://tempuri.org/")> _
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region
    <WebMethod()> Public Function GetUrl() As DataSet
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        sql = "select homeurl from Homeplan"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "Homeplan")
        oSQLConn.Close()
        Return mySet
    End Function


    <WebMethod()> Public Function ShowModel(ByVal modelId As String, ByVal width As String, ByVal height As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim strtag As String
        Dim sql As String
        Dim str As String
        sql = "select homeurl from Homeplan where homeid = '" & modelId & "'"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "Homeplan")
        Dim st As String
        st = CStr(mySet.Tables("Homeplan").Rows(0).Item("homeurl"))
        strtag = "<OBJECT CLASSID = 'CLSID:86A88967-7A20-11d2-8EDA-00600818EDB1'"
        strtag += "CODEBASE = 'http://161.246.6.113/vrml/cortvrml.cab'"
        strtag += "WIDTH ='" + width + "' HEIGHT='" + height + "'>"
        strtag += "<PARAM NAME='SRC' VALUE='" + st + "'>"
        strtag += "<PARAM NAME='VRML_BACKGROUND_COLOR' VALUE='#FFF7B2'>"
        strtag += "<PARAM NAME='VRML_DASHBOARD' VALUE='false'>"
        strtag += "<PARAM NAME='VRML_SPLASHSCREEN' VALUE='false'>"
        strtag += "<PARAM NAME='CONTEXTMENU' VALUE='true'></OBJECT>"
        strtag += "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
        strtag += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='" + thisUrl(modelId) + "' target='_blank'><b><font color='red'>FULL_SCREEN</font><b></a>"
        oSQLConn.Close()
        Return strtag
    End Function


    <WebMethod()> Public Function thisUrl(ByVal modelId As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        sql = "select homeurl from Homeplan where homeid = '" & modelId & "'"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "Homeplan")
        Dim url As String
        url = CStr(mySet.Tables("Homeplan").Rows(0).Item("homeurl"))
        Return url
    End Function


    <WebMethod()> Public Function searchHomePlan(ByVal Area As String, ByVal Style As String, ByVal Floors As String, ByVal Width As String, ByVal Depth As String, ByVal Detail As String, ByVal bathrooms As String, ByVal bedrooms As String) As DataSet
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        Dim a() As String = {Area, Style, Floors, Width, Depth, Detail, bathrooms, bedrooms}
        Dim i, j As Integer
        Dim b() As Integer = {0, 0, 0, 0, 0, 0, 0, 0}
        j = 0
        Dim t As String
        For i = 0 To 7
            If a(i) <> "" Then
                j = j + 1
                b(i) = 1
            End If
        Next
        t = ""
        If j > 0 Then t += "WHERE "
        If a(0) <> "" Then
            Dim ar() As String = Split(Area, "-", -1, 1)
            t += "(Area > " + ar(0) + ") and (Area < " + ar(1) + ")"
            If (b(1) = 1) Or (b(2) = 1) Or (b(3) = 1) Or (b(4) = 1) Or (b(5) = 1) Or (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(1) <> "" Then
            t += "Style = '" & Style & "'"
            If (b(2) = 1) Or (b(3) = 1) Or (b(4) = 1) Or (b(5) = 1) Or (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(2) <> "" Then
            t += ("Floors = " + Floors)
            If (b(3) = 1) Or (b(4) = 1) Or (b(5) = 1) Or (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(3) <> "" Then
            Dim w() As String = Split(Width, "-", -1, 1)
            t += "(Width > " + w(0) + ") and (Width < " + w(1) + ")"
            If (b(4) = 1) Or (b(5) = 1) Or (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(4) <> "" Then
            Dim d() As String = Split(Depth, "-", -1, 1)
            t += "(Depth > " + d(0) + ") and (Depth < " + d(1) + ")"
            If (b(5) = 1) Or (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(5) <> "" Then
            t += splt(Detail)
            If (b(6) = 1) Or (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(6) <> "" Then
            t += ("bathroom = " + bathrooms)
            If (b(7) = 1) Then
                t += " and "
            End If
        End If
        If a(7) <> "" Then
            t += ("bedrooms = " + bedrooms)
        End If
        sql = "SELECT homeid,Style,Area,Width,Depth,Floors,bathroom,bedrooms,Detail,homepic FROM  Homeplan " + t
        Dim myAdapter1 As New SqlDataAdapter(sql, oSQLConn)
        myAdapter1.Fill(mySet, "Homeplan")
        oSQLConn.Close()
        Return mySet
    End Function


    Private Function splt(ByVal str As String)
        Dim z() As String = Split(str, ",", -1, 1)
        Dim t As String
        Dim i As Integer
        t += ""
        For i = 0 To z.GetUpperBound(0)
            t += "(Detail like '%" + z(i) + "%')"
            If i <> z.GetUpperBound(0) Then
                t += " AND "
            End If
        Next
        Return t
    End Function


    <WebMethod()> Public Function orderPlan(ByVal hid As String) As DataSet
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        sql = "select p.homeid,t.Pname,p.Price from Homeplan h,Price p,PriceType t where (h.homeid='" + hid + "')and(h.homeid=p.homeid) and (p.PriceId=t.PriceId) order by h.homeid,Pname"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "order")
        oSQLConn.Close()
        Return mySet
    End Function

    <WebMethod()> Public Function objPrice(ByVal hid As String, ByVal objname As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        If objname = "" Then
            Return "0"

        Else
            sql = "select p.Price from Price p,PriceType t where (p.homeid='" + hid + "')and(t.Pname='" + objname + "')and (p.PriceId=t.PriceId)"
            Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
            myAdapter.Fill(mySet, "objPrice")
            oSQLConn.Close()
            Return mySet.Tables("objPrice").Rows(0).Item(0)
        End If
    End Function


    <WebMethod()> Public Function submitOrderPlan(ByVal ContactID As String, ByVal homeid As String, ByVal PayType As String, ByVal detail As String, ByVal totalPrice As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"

        Dim myRow As DataRow
        Dim mySet As DataSet = New DataSet()
        Dim mySet2 As DataSet = New DataSet()
        Dim Cmd As SqlCommand
        Dim Cmd2 As SqlCommand
        Dim sql As String
        Dim sql1 As String
        Dim sql2 As String
        Dim sql3, sql4 As String
        Dim strReturn1 As String = "No ContactID Please Login"
        Dim strReturn2 As String = "Complete"
        Dim count As Decimal
        Dim count2 As String

        sql = "select ContactID from Contact where (ContactID = '" + ContactID + "') and (Committ='0')"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "chkContact")
        count = mySet.Tables("chkContact").Rows.Count

        sql3 = "SELECT count(ContactDetailID) FROM  ContactDetail"
        Dim myAdapter3 As New SqlDataAdapter(sql3, oSQLConn)
        myAdapter3.Fill(mySet2, "chk")
        count2 = CInt(mySet2.Tables("chk").Rows(0).Item(0))
        count2 = count2 + 1
        If count = 0 Then
            oSQLConn.Close()
            Return strReturn1
        Else
            sql2 = "INSERT INTO Payment (PayID,PayType,TimePay,totalPrice) VALUES ('" & count2 & "','" & PayType & "',1," + totalPrice + ")"
            Cmd2 = New SqlCommand(sql2, oSQLConn)
            oSQLConn.Open()
            Cmd2.ExecuteNonQuery()
            oSQLConn.Close()

            sql1 = "INSERT INTO ContactDetail (ContactDetailID,homeid,ContactID,PayID,detail)"
            sql1 += " VALUES ('" & count2 & "','" & homeid & "','" & ContactID & "','" & count2 & "','" & detail & "')"
            Cmd = New SqlCommand(sql1, oSQLConn)
            oSQLConn.Open()
            Cmd.ExecuteNonQuery()
            oSQLConn.Close()

            sql4 = "UPDATE Contact SET Committ = '1' WHERE ContactID = '" & ContactID & "'"
            Cmd = New SqlCommand(sql4, oSQLConn)
            oSQLConn.Open()
            Cmd.ExecuteNonQuery()
            oSQLConn.Close()


            Return strReturn2

        End If
    End Function

    <WebMethod()> Public Function preOrder(ByVal ContactID As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql As String
        Dim count As Integer
        Dim mySet As DataSet = New DataSet()
        Dim strReturn1 As String = "No ContactID Please Login"
        Dim strReturn2 As String = "OK"
        sql = "select ContactID from Contact where (ContactID = '" + ContactID + "') and (Committ='0')"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "chkContact")
        count = mySet.Tables("chkContact").Rows.Count
        If count = 0 Then
            oSQLConn.Close()
            Return strReturn1
        Else
            Return strReturn2
        End If

    End Function

    <WebMethod()> Public Function submitOrderHomeBuild(ByVal ContactID As String, ByVal homeid As String, ByVal PayType As String, ByVal hClass As String, ByVal HomeColor As String, ByVal RoofColor As String, ByVal Place_Build As String, ByVal OtherDescription As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"

        Dim mySet As DataSet = New DataSet()
        Dim mySet2 As DataSet = New DataSet()
        Dim Cmd As SqlCommand
        Dim Cmd2 As SqlCommand
        Dim Cmd3 As SqlCommand
        Dim sql As String
        Dim sql1 As String
        Dim sql2 As String
        Dim sql3 As String
        Dim sql4 As String
        Dim sql5 As String
        Dim strReturn1 As String = "No ContactID Please Login"
        Dim strReturn2 As String = "Complete"
        Dim count, count2 As Integer
        Dim hr As String

        sql = "select ContactID from Contact where (ContactID = '" + ContactID + "') and (Committ='0')"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "chkContact")
        count = mySet.Tables("chkContact").Rows.Count

        sql3 = "SELECT count(ContactDetailID) FROM  ContactDetail"
        Dim myAdapter3 As New SqlDataAdapter(sql3, oSQLConn)
        myAdapter3.Fill(mySet2, "chk")
        count2 = CInt(mySet2.Tables("chk").Rows(0).Item(0))
        count2 = count2 + 1
        hr = "h" + CStr(count2)
        count2 = CStr(count2)
        If count = 0 Then
            oSQLConn.Close()
            Return strReturn1
        Else
            sql2 = "INSERT INTO Payment (PayID,PayType) VALUES ('" & count2 & "','" & PayType & "')"
            Cmd2 = New SqlCommand(sql2, oSQLConn)
            oSQLConn.Open()
            Cmd2.ExecuteNonQuery()
            oSQLConn.Close()

            sql4 = "INSERT INTO HomeRequire (HomeRequireID,Class,HomeColor,RoofColor,Place_Build,OtherDescription) VALUES ('" & hr & "','" & hClass & "','" & HomeColor & "','" & RoofColor & "','" & Place_Build & "','" & OtherDescription & "')"
            Cmd3 = New SqlCommand(sql4, oSQLConn)
            oSQLConn.Open()
            Cmd3.ExecuteNonQuery()
            oSQLConn.Close()

            sql1 = "INSERT INTO ContactDetail (ContactDetailID,homeid,ContactID,HomeRequireID,PayID) VALUES ('" & count2 & "','" & homeid & "','" & ContactID & "','" & hr & "','" & count2 & "')"
            Cmd = New SqlCommand(sql1, oSQLConn)
            oSQLConn.Open()
            Cmd.ExecuteNonQuery()
            oSQLConn.Close()

            sql5 = "UPDATE Contact SET Committ = '1' WHERE ContactID = '" & ContactID & "'"
            Cmd = New SqlCommand(sql5, oSQLConn)
            oSQLConn.Open()
            Cmd.ExecuteNonQuery()
            oSQLConn.Close()

            Return strReturn2

        End If
    End Function

    <WebMethod()> Public Function preSignUp(ByVal Username As String, ByVal IDcard As String) As Boolean
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql2 As String
        Dim myset As DataSet = New DataSet()
        Dim myset2 As DataSet = New DataSet()
        Dim Cmd As SqlCommand
        Dim c As String
        Dim c1 As Integer
        Dim myserv As Service1

        sql2 = "SELECT count(CustomerID) FROM  Customer WHERE (IDcard = '" + IDcard + "') OR (Username='" + Username + "')"
        Dim myAdapter3 As New SqlDataAdapter(sql2, oSQLConn)
        myAdapter3.Fill(myset2, "chksignup")
        c1 = CInt(myset2.Tables("chksignup").Rows(0).Item(0))
        If (c1 <> 0) Then
            oSQLConn.Close()
            Return False
        Else
            'myserv.SignUp(FirstName, LastName, Age, Sex, Address, Mobile, Telephone, Occupation, Salary, Username, Password, Mail, IDcard)
            Return True
        End If
    End Function


    <WebMethod()> Public Function SignUp(ByVal FirstName As String, ByVal LastName As String, ByVal Age As String, ByVal Sex As String, ByVal Address As String, ByVal Mobile As String, ByVal Telephone As String, ByVal Occupation As String, ByVal Salary As String, ByVal Username As String, ByVal Password As String, ByVal Mail As String, ByVal IDcard As String)
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql As String
        Dim sql1 As String
        Dim sql2 As String
        Dim myset As DataSet = New DataSet()
        Dim myset2 As DataSet = New DataSet()
        Dim Cmd As SqlCommand
        Dim c As String
        Dim c1 As Integer
        Dim myserv As Service1
        Dim CustomerID As String = GenCustomerID()
        If Age = "" Then Age = 0
        If Salary = "" Then Salary = 0
        'sql2 = "SELECT count(CustomerID) FROM  Customer WHERE (IDcard = '" + IDcard + "') OR (Username='" + Username + "')"
        'Dim myAdapter3 As New SqlDataAdapter(sql2, oSQLConn)
        'myAdapter3.Fill(myset2, "chksignup")
        'c1 = CInt(myset2.Tables("chksignup").Rows(0).Item(0))
        'If (c1 <> 0) Then
        '    oSQLConn.Close()
        '    Return "Username or IDcard is alleady used"
        'Else
        sql = "INSERT INTO Customer (CustomerID,FirstName,LastName,Age,Sex,Address,Mobile,Telephone,Occupation,Salary,Username,Password,Mail,IDcard)"
        sql += " VALUES ('" & CustomerID & "','" & FirstName & "','" & LastName & "'," & Age & ",'" & Sex & "','" & Address & "','" & Mobile & "','" & Telephone & "','" & Occupation & "','" & Salary & "','" & Username & "','" & Password & "','" & Mail & "','" & IDcard & "')"

        Cmd = New SqlCommand(sql, oSQLConn)
        oSQLConn.Open()
        Cmd.ExecuteNonQuery()
        oSQLConn.Close()
        'End If
    End Function


    Private Function GenCustomerID() As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql As String
        Dim myset As DataSet = New DataSet()
        Dim id As String
        Dim num(4) As Char
        Dim k(4) As Char
        Dim Y As Date
        Dim c1 As Integer
        Dim chk As Boolean = False
        Y = Y.Today
        Dim t() As String = Split(CStr(Y), "/", -1, 1)
        k = t(2)
        num = CStr(CInt(Rnd() * (9999 - 1) + 100))
        If num.Length < 4 Then num = "0" & num
        If num.Length > 4 Then num = num(0) & num(1) & num(2) & num(3)
        id = k(2) + k(3) + num
        While (chk <> True)
            num = CStr(CInt(Rnd() * (9999 - 1) + 100))
            If num.Length < 4 Then num = "0" & num
            If num.Length > 4 Then num = num(0) & num(1) & num(2) & num(3)
            id = k(2) + k(3) + num
            sql = "SELECT count(CustomerID) FROM  Customer WHERE CustomerID= '" + id + "'"
            Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
            myAdapter.Fill(myset, "chkid")
            c1 = CInt(myset.Tables("chkid").Rows(0).Item(0))
            If c1 = 0 Then chk = True Else chk = False
        End While
        Return id
    End Function


    <WebMethod()> Public Function Login(ByVal user As String, ByVal pass As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        Dim cid As Decimal
        Dim str2 As String = "Invalid"
        Dim cusid, conid As String
        sql = "SELECT CustomerID FROM  Customer WHERE (Username = '" + user + "') and (Password= '" + pass + "')"
        Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
        myAdapter.Fill(mySet, "login")
        cid = mySet.Tables("login").Rows.Count

        If cid = 0 Then
            oSQLConn.Close()
            Return str2
        Else
            cusid = mySet.Tables("login").Rows(0).Item("CustomerID")
            oSQLConn.Close()
            conid = CreateContact(cusid)
            Return conid
        End If
    End Function


    Private Function CreateContact(ByVal cusid As String) As String
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"

        Dim sql1, sql2, sql3, sql4 As String
        Dim conid As Integer
        Dim oconid As String
        Dim dt As DateTime = dt.Now
        Dim strDate As String = CStr(dt)
        Dim mySet2 As DataSet = New DataSet()
        Dim mySet1 As DataSet = New DataSet()
        Dim cmd As SqlCommand

        sql3 = "SELECT count(ContactID) FROM Contact WHERE (CustomerID = '" & cusid & "')and(Committ='0')"
        Dim myAdapter1 As New SqlDataAdapter(sql3, oSQLConn)
        myAdapter1.Fill(mySet1, "contact1")
        oconid = CInt(mySet1.Tables("contact1").Rows(0).Item(0))

        If oconid <> 0 Then
            sql4 = "SELECT count(ContactID) FROM Contact"
            Dim myAdapter3 As New SqlDataAdapter(sql4, oSQLConn)
            myAdapter3.Fill(mySet1, "contact3")
            oconid = CInt(mySet1.Tables("contact3").Rows(0).Item(0))
            oSQLConn.Close()
            Return oconid
        Else
            sql1 = "SELECT count(ContactID) FROM  Contact"
            Dim myAdapter2 As New SqlDataAdapter(sql1, oSQLConn)
            myAdapter2.Fill(mySet2, "contact2")
            conid = CInt(mySet2.Tables("contact2").Rows(0).Item(0))
            conid = conid + 1

            sql2 = "INSERT INTO Contact (ContactID,CustomerID,ContactDate,Committ) VALUES ('" & conid & "','" & cusid & "','" & strDate & "','0')"
            cmd = New SqlCommand(sql2, oSQLConn)
            oSQLConn.Open()
            cmd.ExecuteNonQuery()
            oSQLConn.Close()
            Return conid
        End If
    End Function

    <WebMethod()> Public Function CancelContact(ByVal conid As String)
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql1 As String
        Dim Cmd As SqlCommand
        sql1 = "DELETE FROM Contact WHERE ContactID = '" & conid & "'"
        Cmd = New SqlCommand(sql1, oSQLConn)
        oSQLConn.Open()
        Cmd.ExecuteNonQuery()
        oSQLConn.Close()
    End Function

    <WebMethod()> Public Function getPicUrl(ByVal id As String) As DataSet
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                    "Data Source=161.246.6.113,1433;" & _
                                    "Initial Catalog=HomeForYou;" & _
                                    "User ID=sa;" & _
                                    "Password=wx5k,x6hp"
        Dim sql1 As String
        Dim myset As DataSet = New DataSet()
        sql1 = "Select homepic,planpic,homeurl FROM Homeplan WHERE homeid = '" & id & "'"
        Dim myAdapter As New SqlDataAdapter(sql1, oSQLConn)
        myAdapter.Fill(myset, "pic")
        oSQLConn.Close()
        Return myset
    End Function

End Class
