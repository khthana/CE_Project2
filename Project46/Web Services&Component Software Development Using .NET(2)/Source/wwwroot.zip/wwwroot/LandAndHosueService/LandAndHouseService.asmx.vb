Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.DataSet
'Imports System.Array
<WebService(Namespace := "http://tempuri.org/")> _
Public Class LandAndHouseService
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    ' WEB SERVICE EXAMPLE
    ' The HelloWorld() example service returns the string Hello World.
    ' To build, uncomment the following lines then save and build the project.
    ' To test this web service, ensure that the .asmx file is the start page
    ' and press F5.
    '
    

    <WebMethod()> Public Function login(ByVal user As String, ByVal pass As String) As String


        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        ' Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        Dim id As String
        'sur = ""

        sql = "SELECT customer_ID FROM  Customer_1 WHERE (username = '" + user + "') and (password= '" + pass + "')"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")
        For Each myRow In mySet.Tables("dtname").Rows

            id = Trim((myRow("customer_ID")))

        Next

        Return id

        myConn.Close()

    End Function
    <WebMethod()> Public Function search(ByVal street As String, ByVal district As String, ByVal aumper As String, ByVal price1 As String, ByVal price2 As String, ByVal _
                                          productTypeName As String, ByVal garden As String, ByVal bathroom As String, ByVal bedroom As String, ByVal homeType As String, ByVal _
                                          pool As String, ByVal productType As String) As DataSet

        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        Dim sur As String
        Dim a() As String = {street, district, aumper, price1, garden, bathroom, bedroom, homeType, pool, productTypeName}
        Dim b(9) As Decimal
        'Dim c(9) As Decimal
        Dim i, j, k As Decimal
        j = 0
        k = 0
        sur = ""
        sql = "SELECT Product_ID,ProductTypeName,AddressNumber,AddressRoad,AddressDistrict,AddressAumper,AddressCity,Width,Length,UsedArea,TotalArea,SalePrice,NumberOfBathroom,NumberOfBedroom,NumberOfOffice,HomeType,Garden,Pool FROM  Product inner join ProductType on Product.ProductType_ID=ProductType.ProductType_ID WHERE ((ProductStatus = 'Empty') and "

        If (productType = "land") Then
            sql += " (ProductType.ProductTypeName = 'land' )"
        Else
            sql += " (ProductType.ProductTypeName <> 'land' )"
        End If

        sql += " and "



        sql += " "



        For i = 0 To 9 Step 1
            If a(i) <> "" Then
                b(j) = i
                j = j + 1
            End If
        Next
        k = j - 1
        For i = 0 To j - 1 Step 1
            Select Case b(i)
                Case 0
                    sql += " (AddressRoad= '" + street + "')"
                Case 1
                    sql += " (AddressDistrict= '" + district + "')"
                Case 2
                    sql += " (AddressAumper= '" + aumper + "')"
                Case 3
                    sql += " ((SalePrice > '" + price1 + "') and (SalePrice < '" + price2 + "'))"
                Case 4
                    sql += " (Garden= '" + garden + "')"
                Case 5
                    sql += " (NumberOfBathroom= '" + bathroom + "')"
                Case 6
                    sql += " (NumberOfBedroom= '" + bedroom + "')"
                Case 7
                    sql += " (HomeType= '" + homeType + "')"
                Case 8
                    sql += " (Pool= '" + pool + "')"
                Case 9
                    sql += " (Product.ProductType_ID= (Select ProductType.ProductType_ID from ProductType where ProductTypeName =  '" + productTypeName + "'))"
                    ' Case 10
                    '  sql += " (Product.ProductType_ID= (Select ProductType.ProductType_ID from ProductType where ProductTypeName =  '" + productTypeName + "'))"


            End Select
            If k <> 0 Then
                sql += " and "
                k = k - 1
            End If
        Next
        sql += ")"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")
        'For Each myRow In mySet.Tables("dtname").Rows
        ' Label1.Text &= myRow("surname")
        ' sur = Trim((myRow("surname")))

        'Next

        Return mySet
        myConn.Close()

    End Function
    <WebMethod()> Public Function showCredit(ByVal product_ID As String, ByVal CreditCompanyName As String) As DataSet
        'HelloWorld = "Hello World"
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")
        Dim mySet As DataSet = New DataSet()

        Dim sql As String
        sql = "SELECT * FROM  ProductCredit inner join CreditCompany on ProductCredit.CreditCompany_ID=CreditCompany.CreditCompany_ID WHERE "
        sql += "(product_ID = '" + product_ID + "') and (ProductCredit.CreditCompany_ID = (select CreditCompany.CreditCompany_ID from CreditCompany where CreditCompany.CreditCompanyName = '" + CreditCompanyName + "'))"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")

        Return mySet
        myConn.Close()
    End Function

    <WebMethod()> Public Function order(ByVal product_ID As String, ByVal CreditCompany_ID As String) As DataSet
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()


        Dim sql As String
        sql = "select * from ProductCredit inner join CreditCompany on ProductCredit.CreditCompany_ID = CreditCompany.CreditCompany_ID "
        sql += "where (product_ID = '" + product_ID + "') and (ProductCredit.CreditCompany_ID = '" + CreditCompany_ID + "')"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")

        Return mySet
        myConn.Close()
    End Function
    <WebMethod()> Public Function submit(ByVal Customer_ID As String, ByVal SaleDate As String, ByVal SaleType As String, _
                                         ByVal ContactDate As String, ByVal SalePrice As String, ByVal CreditCompanyName As String, _
                                         ByVal PaidDate As String, ByVal PaidPerMonth As String, ByVal Product_ID As String) As DataSet
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()
        Dim Cmd As SqlCommand
        Dim Cmd1 As SqlCommand
        Dim Cmd2 As SqlCommand
        Dim sql As String
        Dim sql1 As String
        Dim sql2 As String
        Dim sql3 As String
        Dim saledate1, paiddate1, tmpdate As Date


        saledate1 = saledate1.Today
        paiddate1 = paiddate1.Today
        tmpdate = "10/10/2000"


        sql = "select * from Contact where customer_ID = '" + Customer_ID + "'"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")



        'For Each myRow In mySet.Tables("dtname").Rows
        Dim count As Decimal
        count = mySet.Tables("dtname").Rows.Count

        If count = 0 Then

            sql1 = "INSERT INTO Contact (Customer_ID,NumberOfItem)"
            sql1 += "VALUES ('" & Customer_ID & "',"
            sql1 += "'1')"

            Cmd = New SqlCommand(sql1, myConn)
            myConn.Open()
            Cmd.ExecuteNonQuery()

            Dim myAdapter1 As New SqlDataAdapter(sql, myConn)
            myAdapter1.Fill(mySet, "dtname1")


            'Cmd = New SqlCommand(sql, myConn)

            Dim contact_IdForNewContact As Decimal = mySet.Tables("dtname1").Rows(0).Item(0)
            contact_IdForNewContact.ToString()

            sql2 = "INSERT INTO ContactDetail (Contact_ID,ItemNumber,SaleDate,SaleType,ContactDate,SalePrice,CreditCompanyName,PaidDate,PaidPerMonth,Product_ID,CustomerPaidDate,NumberOfLateDate,TotalPaidNow,NetToPaid,StatusPaid)"
            sql2 += "VALUES ('" & contact_IdForNewContact & "'," & "'1','" & saledate1 & "','" & SaleType & "','" & ContactDate & "','" & SalePrice & "','" & CreditCompanyName
            sql2 += "','" & paiddate1.AddMonths(1) & "','" & PaidPerMonth & "','" & Product_ID & "','" & tmpdate & "','0','0','" & PaidPerMonth & "','no')"

            Dim Sold As String = "Sold"

            sql3 = "update Product set ProductStatus = '" & Sold & "' "
            sql3 += "where Product_ID = '" & Product_ID & "'"


            Cmd1 = New SqlCommand(sql2, myConn)
            Cmd2 = New SqlCommand(sql3, myConn)
            ' myConn.Open()


            Cmd1.ExecuteNonQuery()
            Cmd2.ExecuteNonQuery()
        Else

            Dim contact_IdForOldContact As Decimal = mySet.Tables("dtname").Rows(0).Item(0)
            Dim NumberItemForOldContact As String = (CDec(mySet.Tables("dtname").Rows(0).Item(2)) + 1).ToString

            sql1 = "update Contact set NumberOfItem = '" & NumberItemForOldContact & "' "
            sql1 += "where Customer_ID = '" & Customer_ID & "'"

            sql2 = "INSERT INTO ContactDetail (Contact_ID,ItemNumber,SaleDate,SaleType,ContactDate,SalePrice,CreditCompanyName,PaidDate,PaidPerMonth,Product_ID,CustomerPaidDate,NumberOfLateDate,TotalPaidNow,NetToPaid,StatusPaid)"
            sql2 += "VALUES ('" & contact_IdForOldContact & "','" & NumberItemForOldContact & "','" & saledate1 & "','" & SaleType & "','" & ContactDate & "','" & SalePrice & "','" & CreditCompanyName
            sql2 += "','" & paiddate1.AddMonths(1) & "','" & PaidPerMonth & "','" & Product_ID & "','" & tmpdate & "','0','0','" & PaidPerMonth & "','no')"

            sql3 = "update Product set ProductStatus = 'Sold' "
            sql3 += "where Product_ID = '" & Product_ID & "'"

            Cmd = New SqlCommand(sql1, myConn)
            Cmd1 = New SqlCommand(sql2, myConn)
            Cmd2 = New SqlCommand(sql3, myConn)
            myConn.Open()
            Cmd.ExecuteNonQuery()
            Cmd1.ExecuteNonQuery()
            Cmd2.ExecuteNonQuery()

        End If
        'Next



        Return mySet
        myConn.Close()


    End Function
    <WebMethod()> Public Function showcontact(ByVal Customer_ID As String) As DataSet
        'showcontact = "Hello World"
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()
        Dim mySet1 As DataSet = New DataSet()
        Dim sql As String
        Dim sql1 As String


        sql = "select Contact_ID,NumberOfItem from Contact where Customer_ID = '" & Customer_ID & "'"

        Dim myAdapter As New SqlDataAdapter(sql, myConn)
        myAdapter.Fill(mySet, "dtname")

        Dim Contact_ID As Integer = mySet.Tables("dtname").Rows(0).Item(0)


        sql1 = "select * from ContactDetail where Contact_ID = '" & Contact_ID.ToString() & "'"

        'sql = "select ProductType.ProductTypeName from ProductType where ProductType.ProductType_ID = "
        'sql += "(select ProductType_ID from Product where Product_ID = '" & Product_ID & "') "


        myAdapter = New SqlDataAdapter(sql1, myConn)
        myAdapter.Fill(mySet1, "dtname1")

        '  Dim count As Integer = mySet.Tables("dtname").Rows.Count
        ''  Dim Product_ID() As Integer
        '  Dim ProductTypeName() As String
        '  Dim i As Integer = 0
        ' For Each myRow In mySet.Tables("dtname").Rows
        '    Product_ID(i) = CInt(Trim((myRow("Product_ID"))))
        '    i += 1
        'Next

        'For i = 0 To i - 1 Step 1

        'sql = "select ProductType.ProductTypeName from ProductType where ProductType.ProductType_ID = "
        '  sql += "(select ProductType_ID from Product where Product_ID = '" & Product_ID(i) & "') "
        ' myAdapter = New SqlDataAdapter(sql, myConn)
        'myAdapter.Fill(mySet, "dtname1")

        ' ProductTypeName(i) = mySet.Tables("dtname1").Rows(0).Item(0)
        ' i += 1

        ' Next

        Return mySet1
        myConn.Close()
    End Function
    ' <WebMethod()> Public Function showProductTypeName(ByVal Product_ID As Array, ByVal NumberOfItem As String) As Array
    'HelloWorld = "Hello World"


    ' Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")
    ' Dim mySet As DataSet = New DataSet()
    ' Dim sql As String
    ' Dim i As Integer
    ' Dim ProductTypeName() As String




    'For i = 0 To i - 1 Step 1

    ' sql = "select ProductType.ProductTypeName from ProductType where ProductType.ProductType_ID = "
    'sql += "(select ProductType_ID from Product where Product_ID = '" & Product_ID(i) & "') "

    'Dim myAdapter As New SqlDataAdapter(sql, myConn)
    ' myAdapter.Fill(mySet, "dtname1")

    ' ProductTypeName(i) = mySet.Tables("dtname1").Rows(0).Item(0)
    ' i += 1

    'Next

    ' Return ProductTypeName
    ' myConn.Close()
    ' End Function

    <WebMethod()> Public Function CancelContact(ByVal Customer_ID As String, ByVal Product_ID As String) As Boolean
        'HelloWorld = "Hello World"

        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

        Dim myRow As DataRow
        Dim myBuilder As SqlCommandBuilder
        Dim mySet As DataSet = New DataSet()
        Dim sql As String
        Dim sql1 As String
        Dim sql2 As String
        Dim sql3 As String
        Dim Empty As String = "Empty"
        Dim Cmd As SqlCommand
        Dim Cmd1 As SqlCommand
        Dim Cmd2 As SqlCommand
        'sql = "select Contact_ID from Contact where Customer_ID = '" & Customer_ID & "'"


        sql1 = " select ItemNumber from ContactDetail where (Product_ID = '" & Product_ID & "') and ("
        sql1 += "Contact_ID = ( select Contact_ID from Contact where Customer_ID = '" & Customer_ID & "'))"

        Dim myAdapter As New SqlDataAdapter(sql1, myConn)
        myAdapter.Fill(mySet, "dtname1")

        Dim count As Decimal = mySet.Tables("dtname1").Rows.Count
        If count <> 0 Then

            sql2 = "select NumberOfItem from Contact where Customer_ID = '" & Customer_ID & "'"
            myAdapter = New SqlDataAdapter(sql2, myConn)
            myAdapter.Fill(mySet, "dtname2")

            Dim NumberOfItem As String = (CInt(mySet.Tables("dtname2").Rows(0).Item(0)) - 1).ToString

            sql = "update Contact set NumberOfItem = '" & NumberOfItem & "'  "
            sql += "where Customer_ID = '" & Customer_ID & "'"

            Cmd = New SqlCommand(sql, myConn)
            myConn.Open()
            Cmd.ExecuteNonQuery()

            sql1 = "update Product set ProductStatus = '" & Empty & "' "
            sql1 += "where Product_ID = '" & Product_ID & "'"

            Cmd1 = New SqlCommand(sql1, myConn)
            Cmd1.ExecuteNonQuery()

            sql2 = "delete from ContactDetail where Product_ID = '" & Product_ID & "'"
            Cmd2 = New SqlCommand(sql2, myConn)
            Cmd2.ExecuteNonQuery()

            CancelContact = True

        Else
            Return False
        End If


        'Return mySet1
        myConn.Close()
    End Function

    <WebMethod()> Public Function signup(ByVal name As String, ByVal surname As String, ByVal sex As String, ByVal address As String, ByVal telephone As String, ByVal email As String, ByVal job As String, ByVal salary As String, ByVal username As String, ByVal password As String) As Boolean
        'HelloWorld = "Hello World"
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")
        Dim Cmd As SqlCommand
        Dim sql As String
        Dim sql1 As String
        Dim count As Decimal
        sql1 = "select username from Customer_1 where username = '" & username & "'"
        Dim mySet As DataSet = New DataSet()
        Dim myRow As DataRow

        myConn.Open()
        Dim myAdapter As New SqlDataAdapter(sql1, myConn)
        myAdapter.Fill(mySet, "dtname")


        count = mySet.Tables("dtname").Rows.Count


        If count = 0 Then
            sql = "INSERT INTO Customer_1 (name,surname,sex,address,telephone,email,job,salary,username,password)"
            sql &= "VALUES ('" & name & "',"
            sql &= "'" & surname & "',"
            sql &= "'" & sex & "',"
            sql &= "'" & address & "',"
            sql &= "'" & telephone & "',"
            sql &= "'" & email & "',"
            sql &= "'" & job & "',"
            sql &= "'" & salary & "',"
            sql &= "'" & username & "',"
            sql &= "'" & password & "')"

            Cmd = New SqlCommand(sql, myConn)
            Cmd.ExecuteNonQuery()

            Return True
        Else : Return False
        End If

    End Function
    <WebMethod()> Public Function showdetailforpay(ByVal product_ID As String, ByVal customer_ID As String) As DataSet
        'HelloWorld = "Hello World"
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")
        Dim Cmd As SqlCommand
        Dim sql As String
        Dim sql1 As String
        Dim count As Decimal
        sql1 = "select SaleDate,PaidDate,SalePrice,PaidPerMonth,TotalPaidNow,NumberOfLateDate,NetToPaid from ContactDetail where Product_ID = '" & product_ID & "'"
        Dim mySet As DataSet = New DataSet()
        Dim myRow As DataRow

        myConn.Open()
        Dim myAdapter As New SqlDataAdapter(sql1, myConn)
        myAdapter.Fill(mySet, "dtname")
        Return mySet
        myConn.Close()
    End Function

    <WebMethod()> Public Function pay(ByVal product_ID As String) As Boolean
        'PaidDate,CustomerPaidDate,NumberOfLateDate,TotalPaidNow,NetToPaid,StatusPaid
        Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")
        Dim Cmd As SqlCommand
        Dim sql, sql1 As String
        Dim mySet As DataSet = New DataSet()
        Dim myRow As DataRow
        Dim date1 As Date
        Dim mySet1 As DataSet = New DataSet()
        Dim myRow1 As DataRow
        Dim SalePrice, TotalPaidNow, NetToPaid, PaidPerMonth As Decimal

        'sql = 

        sql1 = "select SaleDate,PaidDate,SalePrice,PaidPerMonth,TotalPaidNow,NumberOfLateDate,NetToPaid from ContactDetail where Product_ID = '" & product_ID & "'"

        myConn.Open()
        Dim myAdapter As New SqlDataAdapter(sql1, myConn)
        myAdapter.Fill(mySet, "dtname")

        TotalPaidNow = CDec(mySet.Tables("dtname").Rows(0).Item(4))
        NetToPaid = CDec(mySet.Tables("dtname").Rows(0).Item(6))
        PaidPerMonth = CDec(mySet.Tables("dtname").Rows(0).Item(3))
        SalePrice = CDec(mySet.Tables("dtname").Rows(0).Item(2))
        date1 = mySet.Tables("dtname").Rows(0).Item(1)

        'TotalPaidNow = CDec(TotalPaidNow)

        sql = "update ContactDetail set PaidDate = '" & date1.AddMonths(1) & "', " & _
                                       "CustomerPaidDate = '" & date1.Today & "', " & _
                                       "NumberOfLateDate = '" & 0 & "', " & _
                                       "TotalPaidNow = '" & TotalPaidNow + NetToPaid & "', " & _
                                       "NetToPaid = '" & PaidPerMonth & "', "
        If (TotalPaidNow + NetToPaid) >= SalePrice Then
            sql += "StatusPaid = 'yes' "
        Else
            sql += "StatusPaid = 'no' "
        End If

        sql += "where Product_ID = '" & product_ID & "'"



        Cmd = New SqlCommand(sql, myConn)
        Cmd.ExecuteNonQuery()
        myConn.Close()
        Return True

    End Function


End Class
