<%@ WebService Language="vb" Codebehind="LandAndHouseService.asmx.vb" Class="LandAndHosueService.LandAndHouseService" %>
