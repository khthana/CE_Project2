<%@ Page Language="vb" AutoEventWireup="false" Codebehind="error.aspx.vb" Inherits="LandandHouseApp._error"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>error</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"><IMG style="Z-INDEX: 110; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355"><IMG style="Z-INDEX: 111; LEFT: 17px; POSITION: absolute; TOP: 1px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 101; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 102; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 109; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink>
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 108; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 107; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 106; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 105; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 104; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 103; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
				<asp:Label id="Label1" style="Z-INDEX: 112; LEFT: 338px; POSITION: absolute; TOP: 320px" runat="server" ForeColor="#FFC080">���ɴ��¤س</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 113; LEFT: 465px; POSITION: absolute; TOP: 320px" runat="server" ForeColor="#FF8000"></asp:Label></FONT>
		</form>
	</body>
</HTML>
