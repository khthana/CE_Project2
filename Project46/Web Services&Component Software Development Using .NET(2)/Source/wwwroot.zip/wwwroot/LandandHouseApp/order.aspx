<%@ Page Language="vb" AutoEventWireup="false" Codebehind="order.aspx.vb" Inherits="LandandHouseApp.order1"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>order</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 381px; POSITION: absolute; TOP: 272px" runat="server">��¡���Թ��ҷ��س��觫���</asp:label><IMG style="Z-INDEX: 125; LEFT: 17px; POSITION: absolute; TOP: 3px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="new.jpg" NavigateUrl="index.html">˹����ѡ</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 119; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="signup.jpg" NavigateUrl="signup.aspx">��Ѥ���Ҫԡ</asp:HyperLink>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 120; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="login.jpg" NavigateUrl="login.aspx">�������к�</asp:HyperLink>
			<asp:HyperLink id="HyperLink4" style="Z-INDEX: 121; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="search.jpg" NavigateUrl="search_house.aspx">����</asp:HyperLink>
			<asp:HyperLink id="HyperLink5" style="Z-INDEX: 122; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
			<asp:HyperLink id="HyperLink6" style="Z-INDEX: 123; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="ShowContact.jpg" NavigateUrl="ShowContact.aspx">�ʴ���������´ contact</asp:HyperLink>
			<asp:HyperLink id="HyperLink7" style="Z-INDEX: 124; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="contact.jpg" NavigateUrl="mailto:webmaster@landandhappyhome.com">�Դ������</asp:HyperLink>
			<asp:datagrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 102; LEFT: 60px; POSITION: absolute; TOP: 366px" runat="server" Width="922px" Height="168px">
				<Columns>
					<asp:BoundColumn DataField="product_ID" HeaderText="�Թ���" />
					<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
					<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
					<asp:BoundColumn DataField="NetPrice" HeaderText="�ҤҢ�¨�ԧ" />
					<asp:BoundColumn DataField="PreCash" HeaderText="�Թ��ǹ�" />
					<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
					<asp:BoundColumn DataField="DurationToPaid" HeaderText="������ҷ���ͧ���¨���" />
					<asp:BoundColumn DataField="IntFirstYear" HeaderText="�͡���»��á" />
					<asp:BoundColumn DataField="IntPerMonth" HeaderText="�͡���µ����͹" />
					<asp:BoundColumn DataField="IntForPaidLatePerDate" HeaderText="�͡���¨��ª��" />
				</Columns>
			</asp:datagrid>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 103; LEFT: 381px; POSITION: absolute; TOP: 554px" runat="server" ImageUrl="\LandandHouseApp\submit.gif"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 104; LEFT: 489px; POSITION: absolute; TOP: 554px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:ImageButton>
			<asp:Image id="Image1" style="Z-INDEX: 105; LEFT: 11px; POSITION: absolute; TOP: 147px" runat="server" ImageUrl="\LandandHouseApp\tips.jpg" Height="183px" Width="281px"></asp:Image>
			<asp:Label id="Label2" style="Z-INDEX: 106; LEFT: 322px; POSITION: absolute; TOP: 740px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label><A href="search_house.aspx"></A><A href="login.aspx"></A><A href="signup.aspx"></A><A href="index.html"></A><A href="ShowContact.aspx"></A><A href="mailto:webmaster@landandhappyhome.com"></A>&nbsp;&nbsp;</form>
	</body>
</HTML>
