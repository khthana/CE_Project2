<%@ Page Language="vb" AutoEventWireup="false" Codebehind="ShowContact.aspx.vb" Inherits="LandandHouseApp.ShowContact"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_ShowContact</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 101; LEFT: 57px; POSITION: absolute; TOP: 258px" runat="server" Width="820px" Height="156px">
				<Columns>
					<asp:BoundColumn DataField="product_ID" HeaderText="�Թ��Ҫ�Դ���" />
					<asp:BoundColumn DataField="ItemNumber" HeaderText="�ӹǹ" />
					<asp:BoundColumn DataField="SaleDate" HeaderText="�ѹ������" />
					<asp:BoundColumn DataField="ContactDate" HeaderText="�ѹ���Ѵ���ѭ��" />
					<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
					<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
					<asp:BoundColumn DataField="PaidDate" HeaderText="�ѹ����ͧ�����Թ" />
					<asp:BoundColumn DataField="CustomerPaidDate" HeaderText="�ѹ����١��Ҩ����Թ" />
					<asp:BoundColumn DataField="NumberOfLateDate" HeaderText="�ӹǹ�ѹ�����ª��" />
					<asp:BoundColumn DataField="PaidPerMonth" HeaderText="�ӹǹ����ͧ���е����͹" />
					<asp:BoundColumn DataField="TotalPaidNow" HeaderText="���������" />
					<asp:BoundColumn DataField="StatusToPaid" HeaderText="�Ǵ������Ǩ���������" />
				</Columns>
			</asp:DataGrid><IMG style="Z-INDEX: 119; LEFT: 17px; POSITION: absolute; TOP: 2px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 111; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 112; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 113; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 114; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
			<asp:HyperLink id="HyperLink4" style="Z-INDEX: 115; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
			<asp:HyperLink id="HyperLink5" style="Z-INDEX: 116; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 109; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 110; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
			<asp:HyperLink id="HyperLink6" style="Z-INDEX: 117; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
			<asp:HyperLink id="HyperLink7" style="Z-INDEX: 118; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink>
			<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 42px; POSITION: absolute; TOP: 516px" runat="server">��س���������Ţ����ͧ���¡��ԡ��èͧ</asp:Label>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 103; LEFT: 354px; POSITION: absolute; TOP: 510px" runat="server" Width="63px" BorderColor="#FFE0C0"></asp:TextBox>
			<asp:Button id="Button1" style="Z-INDEX: 104; LEFT: 479px; POSITION: absolute; TOP: 513px" runat="server" Text="submit"></asp:Button>
			<asp:Button id="Button2" style="Z-INDEX: 105; LEFT: 591px; POSITION: absolute; TOP: 513px" runat="server" Text="cancel"></asp:Button>
			<asp:Image id="Image1" style="Z-INDEX: 106; LEFT: 34px; POSITION: absolute; TOP: 148px" runat="server" ImageUrl="\LandandHouseApp\oganise.gif"></asp:Image>
			<asp:Label id="Label2" style="Z-INDEX: 107; LEFT: 362px; POSITION: absolute; TOP: 587px" runat="server" BackColor="#FFFFC0"></asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 108; LEFT: 343px; POSITION: absolute; TOP: 775px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label>
			<asp:HyperLink id="HyperLink8" style="Z-INDEX: 120; LEFT: 338px; POSITION: absolute; TOP: 655px" runat="server" NavigateUrl="pay.aspx" ForeColor="#FF8000">Click</asp:HyperLink>
			<asp:Label id="Label4" style="Z-INDEX: 121; LEFT: 210px; POSITION: absolute; TOP: 655px" runat="server" ForeColor="#FFC080">��ͧ��è����Թ</asp:Label>
		</form>
	</body>
</HTML>
