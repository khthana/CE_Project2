Imports System.Data
Imports System.Data.SqlClient
Public Class result_search
    Inherits System.Web.UI.Page
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink7 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink6 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim street As String
        Dim district As String
        Dim aumper As String
        Dim price1 As String
        Dim price2 As String
        Dim productTypeName As String
        Dim garden As String
        Dim bathroom As String
        Dim bedroom As String
        Dim homeType As String
        Dim pool As String
        Dim productType As String

        Dim mySearch As New localhost.LandAndHouseService()
        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow
        Dim ret_str As String


        street = Request.QueryString("street")
        district = Request.QueryString("district")
        aumper = Request.QueryString("aumper")
        price1 = Request.QueryString("price1")
        price2 = Request.QueryString("price2")
        productTypeName = Request.QueryString("productTypeName")
        garden = Request.QueryString("garden")
        bathroom = Request.QueryString("bathroom")
        bedroom = Request.QueryString("bedroom")
        homeType = Request.QueryString("homeType")
        pool = Request.QueryString("pool")
        productType = Request.QueryString("productType")

        'Dim mySearch As New localhost.LandAndHouseService()


        mySet = mySearch.search(street, district, aumper, price1, price2, productTypeName, garden, bathroom, bedroom, homeType, pool, productType)
        'Dim count As Decimal
        'count = mySet.Tables("dtname").Rows.Count
        myTable.Columns.Add(New DataColumn("product_ID", GetType(String)))
        myTable.Columns.Add(New DataColumn("productTypeName", GetType(String)))
        myTable.Columns.Add(New DataColumn("Price", GetType(String)))

        myTable.Columns.Add(New DataColumn("ClickHereForDetailCredit", GetType(String)))

        Dim i As Decimal = 0
        'Dim link As String
        'link = "<a href=pre_order.aspx" + "ppp" + "</a>"
        For Each myRow In mySet.Tables("dtname").Rows
            myRow = myTable.NewRow()
            myRow(0) = "<center>" & "<a href=product" & mySet.Tables("dtname").Rows(i).Item(0) & ".html  target=_blank  >" & mySet.Tables("dtname").Rows(i).Item(0) & "</a>" & "</center>"
            myRow(1) = "<center>" & mySet.Tables("dtname").Rows(i).Item(1) & "</center>"
            myRow(2) = "<center>" & mySet.Tables("dtname").Rows(i).Item(11) & "</center>"


            myRow(3) = "<center>" & "<a href=pre_order.aspx?product_ID=" & mySet.Tables("dtname").Rows(i).Item(0) & ">" & "���͹��Թ����" & "</a>" & "</center>"


            'ret_str = "pre_order.aspx?product_ID=" & mySet.Tables("dtname").Rows(i).Item(0)

            myTable.Rows.Add(myRow)
            i += 1


        Next



        DataGrid1.DataSource = myTable
        DataGrid1.DataBind()




    End Sub

End Class
