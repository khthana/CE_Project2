<%@ Page Language="vb" AutoEventWireup="false" Codebehind="search_house.aspx.vb" Inherits="LandandHouseApp.search"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_search</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 100; LEFT: 520px; POSITION: absolute; TOP: 199px" runat="server" Width="267px">����Ẻ��ҹ�ҡ������ͧ��âͧ�س</asp:label><IMG style="Z-INDEX: 145; LEFT: 17px; POSITION: absolute; TOP: 1px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 117; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 120; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 121; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 123; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 124; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 126; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 127; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink><asp:dropdownlist id="DropDownList2" style="Z-INDEX: 131; LEFT: 685px; POSITION: absolute; TOP: 752px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="1">1 ��ͧ</asp:ListItem>
					<asp:ListItem Value="2">2 ��ͧ</asp:ListItem>
					<asp:ListItem Value="3">3 ��ͧ</asp:ListItem>
					<asp:ListItem Value="4">4 ��ͧ</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label6" style="Z-INDEX: 105; LEFT: 540px; POSITION: absolute; TOP: 506px" runat="server">�Ҥ�</asp:label><asp:label id="Label2" style="Z-INDEX: 101; LEFT: 543px; POSITION: absolute; TOP: 296px" runat="server">���ŷ����</asp:label><asp:label id="Label3" style="Z-INDEX: 102; LEFT: 579px; POSITION: absolute; TOP: 337px" runat="server">���</asp:label><asp:label id="Label4" style="Z-INDEX: 103; LEFT: 576px; POSITION: absolute; TOP: 385px" runat="server">�ǧ</asp:label><asp:label id="Label5" style="Z-INDEX: 104; LEFT: 586px; POSITION: absolute; TOP: 429px" runat="server">ࢵ</asp:label><asp:textbox id="TextBox1" style="Z-INDEX: 106; LEFT: 669px; POSITION: absolute; TOP: 334px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox2" style="Z-INDEX: 107; LEFT: 670px; POSITION: absolute; TOP: 382px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:label id="Label7" style="Z-INDEX: 108; LEFT: 824px; POSITION: absolute; TOP: 506px" runat="server">�֧</asp:label><asp:label id="Label8" style="Z-INDEX: 109; LEFT: 504px; POSITION: absolute; TOP: 467px" runat="server">��������´�ͧ</asp:label><asp:label id="Label9" style="Z-INDEX: 110; LEFT: 541px; POSITION: absolute; TOP: 570px" runat="server">�����ç���</asp:label><asp:label id="Label10" style="Z-INDEX: 111; LEFT: 299px; POSITION: absolute; TOP: 1626px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:label><asp:label id="Label11" style="Z-INDEX: 112; LEFT: 547px; POSITION: absolute; TOP: 603px" runat="server">ʹ��˭��</asp:label><asp:radiobutton id="RadioButton1" style="Z-INDEX: 113; LEFT: 615px; POSITION: absolute; TOP: 658px" runat="server" GroupName="garden" Text="��ʹ��˭��"></asp:radiobutton><asp:radiobutton id="RadioButton2" style="Z-INDEX: 116; LEFT: 813px; POSITION: absolute; TOP: 659px" runat="server" Width="123px" GroupName="garden" Text="�����ʹ��˭��"></asp:radiobutton><asp:label id="Label12" style="Z-INDEX: 119; LEFT: 560px; POSITION: absolute; TOP: 699px" runat="server">��ͧ���</asp:label><asp:label id="Label13" style="Z-INDEX: 122; LEFT: 556px; POSITION: absolute; TOP: 755px" runat="server">��ͧ�͹</asp:label><asp:label id="Label14" style="Z-INDEX: 125; LEFT: 536px; POSITION: absolute; TOP: 800px" runat="server">�ѡɳк�ҹ</asp:label><asp:dropdownlist id="DropDownList3" style="Z-INDEX: 128; LEFT: 687px; POSITION: absolute; TOP: 801px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="Single">��ҹ�����</asp:ListItem>
					<asp:ListItem Value="Double">��ҹ���</asp:ListItem>
					<asp:ListItem Value="Townhouse">��ǹ�������</asp:ListItem>
				</asp:dropdownlist><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 130; LEFT: 681px; POSITION: absolute; TOP: 702px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="1">1 ��ͧ</asp:ListItem>
					<asp:ListItem Value="2">2 ��ͧ</asp:ListItem>
					<asp:ListItem Value="3">3 ��ͧ</asp:ListItem>
					<asp:ListItem Value="4">4 ��ͧ</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label15" style="Z-INDEX: 132; LEFT: 552px; POSITION: absolute; TOP: 841px" runat="server">������¹��</asp:label><asp:radiobutton id="RadioButton3" style="Z-INDEX: 133; LEFT: 612px; POSITION: absolute; TOP: 889px" runat="server" BorderColor="#FFE0C0" GroupName="pool" Text="��"></asp:radiobutton><asp:radiobutton id="RadioButton4" style="Z-INDEX: 134; LEFT: 755px; POSITION: absolute; TOP: 885px" runat="server" Width="63px" BorderColor="#FFE0C0" GroupName="pool" Text="�����"></asp:radiobutton><asp:textbox id="TextBox3" style="Z-INDEX: 135; LEFT: 671px; POSITION: absolute; TOP: 431px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox4" style="Z-INDEX: 136; LEFT: 675px; POSITION: absolute; TOP: 503px" runat="server" Width="127px" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox5" style="Z-INDEX: 137; LEFT: 852px; POSITION: absolute; TOP: 504px" runat="server" Width="110px" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox6" style="Z-INDEX: 138; LEFT: 677px; POSITION: absolute; TOP: 571px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:imagebutton id="ImageButton1" style="Z-INDEX: 139; LEFT: 667px; POSITION: absolute; TOP: 951px" runat="server" ImageUrl="\LandandHouseApp\search.gif"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 140; LEFT: 803px; POSITION: absolute; TOP: 952px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:imagebutton><asp:label id="Label16" style="Z-INDEX: 141; LEFT: 422px; POSITION: absolute; TOP: 254px" runat="server">��س����͡ Search ��ҹ,���Թ</asp:label><asp:dropdownlist id="DropDownList4" style="Z-INDEX: 142; LEFT: 665px; POSITION: absolute; TOP: 256px" runat="server">
					<asp:ListItem Value="��س����͡" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="house">��ҹ������ٻ</asp:ListItem>
					<asp:ListItem Value="land">���Թ����</asp:ListItem>
				</asp:dropdownlist><asp:image id="Image1" style="Z-INDEX: 144; LEFT: 24px; POSITION: absolute; TOP: 165px" runat="server" ImageUrl="\LandandHouseApp\news.jpg"></asp:image></FONT></form>
	</body>
</HTML>
