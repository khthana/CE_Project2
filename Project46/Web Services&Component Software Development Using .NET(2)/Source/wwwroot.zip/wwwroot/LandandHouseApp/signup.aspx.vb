Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Public Class signup
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents RequiredFieldValidator2 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents TextBox8 As System.Web.UI.WebControls.TextBox
    Protected WithEvents RequiredFieldValidator3 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox9 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox10 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label18 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink7 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink6 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink

#End Region
    Dim myConn As SqlConnection = New SqlConnection("Data Source=W\NETSDK; Initial Catalog=test; " & "Integrated Security=SSPI")

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim sex As String = ""
        If RadioButton1.Checked Then
            sex = "male"
        ElseIf RadioButton1.Checked Then
            sex = "female"
        End If

        Try
            Dim Cmd As SqlCommand
            Dim sql As String
            Dim sql1 As String
            Dim count As Decimal
            sql1 = "select username from Customer_1 where username = '" & TextBox1.Text & "'"
            Dim mySet As DataSet = New DataSet()
            Dim myRow As DataRow

            myConn.Open()
            Dim myAdapter As New SqlDataAdapter(sql1, myConn)
            myAdapter.Fill(mySet, "dtname")
            ' For Each myRow In mySet.Tables("dtname").Rows
            'ID = Trim((myRow("username")))
            'Next


            count = mySet.Tables("dtname").Rows.Count


            If count = 0 Then
                sql = "INSERT INTO Customer_1 (name,surname,sex,address,telephone,email,job,salary,username,password)"
                sql &= "VALUES ('" & TextBox1.Text & "',"
                sql &= "'" & TextBox2.Text & "',"
                sql &= "'" & sex & "',"
                sql &= "'" & TextBox3.Text & "',"
                sql &= "'" & TextBox9.Text & "',"
                sql &= "'" & TextBox4.Text & "',"
                sql &= "'" & TextBox10.Text & "',"
                sql &= "'" & TextBox8.Text & "',"
                sql &= "'" & TextBox5.Text & "',"
                sql &= "'" & TextBox6.Text & "')"

                Cmd = New SqlCommand(sql, myConn)

                'myConn.Open()
                Cmd.ExecuteNonQuery()
                Response.Redirect("login.aspx")
            Else
                Label18.Text = "Username �ͧ�س�դ�������"
            End If

        Catch

        Finally
            myConn.Close()
        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        TextBox10.Text = ""
        RadioButton1.Checked = False

    End Sub
End Class
