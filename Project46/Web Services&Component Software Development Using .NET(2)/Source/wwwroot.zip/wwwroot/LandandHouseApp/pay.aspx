<%@ Page Language="vb" AutoEventWireup="false" Codebehind="pay.aspx.vb" Inherits="LandandHouseApp.pay"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>pay</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:TextBox id="TextBox1" style="Z-INDEX: 100; LEFT: 212px; POSITION: absolute; TOP: 261px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 115; LEFT: 897px; POSITION: absolute; TOP: 105px" runat="server" ImageUrl="contact.jpg" NavigateUrl="mailto:webmaster@landandhappyhome.com">�Դ������</asp:HyperLink><IMG style="Z-INDEX: 102; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 111; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="ShowContact.jpg" NavigateUrl="ShowContact.aspx">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 110; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 101; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162">
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 109; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="search.jpg" NavigateUrl="search_house.aspx">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 108; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="login.jpg" NavigateUrl="login.aspx">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 107; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="signup.jpg" NavigateUrl="signup.aspx">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 105; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="new.jpg" NavigateUrl="index.html">˹����ѡ</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 17px; POSITION: absolute; TOP: 1px" height="94" src="head1.jpg" width="174" align="absMiddle"><FONT face="Tahoma"><IMG style="Z-INDEX: 113; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355"></FONT>
				<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 103; LEFT: 103px; POSITION: absolute; TOP: 349px" runat="server">
					<Columns>
						<asp:BoundColumn DataField="SaleDate" HeaderText="�ѹ�����" />
						<asp:BoundColumn DataField="PaidDate" HeaderText="�ѹ�����¤��駵���" />
						<asp:BoundColumn DataField="SalePrice" HeaderText="�ҤҢ��" />
						<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
						<asp:BoundColumn DataField="TotalPaidNow" HeaderText="���������" />
						<asp:BoundColumn DataField="NumberOfLateDate" HeaderText="�ѹ�����ª��" />
						<asp:BoundColumn DataField="NetToPaid" HeaderText="�ط�Է���ͧ����" />
					</Columns>
				</asp:DataGrid>
				<asp:Button id="Button1" style="Z-INDEX: 104; LEFT: 420px; POSITION: absolute; TOP: 259px" runat="server" Text="showdetail"></asp:Button>
				<asp:Button id="Button2" style="Z-INDEX: 106; LEFT: 542px; POSITION: absolute; TOP: 259px" runat="server" Text="pay"></asp:Button></FONT>
		</form>
	</body>
</HTML>
