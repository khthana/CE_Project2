<%@ Page Language="vb" AutoEventWireup="false" Codebehind="pre_order.aspx.vb" Inherits="LandandHouseApp.order"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>order</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 380px; POSITION: absolute; TOP: 320px" runat="server">��س����͡����ѷ�Թ����</asp:label><IMG style="Z-INDEX: 125; LEFT: 17px; POSITION: absolute; TOP: 3px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 119; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 120; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 121; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 122; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 123; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 124; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink><asp:textbox id="TextBox1" style="Z-INDEX: 102; LEFT: 635px; POSITION: absolute; TOP: 254px" runat="server" BorderColor="#FFE0C0" Enabled="False" Width="93px"></asp:textbox><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 103; LEFT: 636px; POSITION: absolute; TOP: 319px" runat="server">
					<asp:ListItem Value="NoBank">��س����͡����ѷ�Թ����</asp:ListItem>
					<asp:ListItem Value="Thaipanit_Bank">��Ҥ���¾ҳԪ��</asp:ListItem>
					<asp:ListItem Value="Asia_Bank">��Ҥ�������</asp:ListItem>
					<asp:ListItem Value="Thanachad_Bank">��Ҥ�ø��ҵ�</asp:ListItem>
				</asp:dropdownlist><asp:imagebutton id="ImageButton1" style="Z-INDEX: 104; LEFT: 374px; POSITION: absolute; TOP: 547px" runat="server" ImageUrl="\LandandHouseApp\submit.gif"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 105; LEFT: 545px; POSITION: absolute; TOP: 545px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:imagebutton><asp:label id="Label2" style="Z-INDEX: 106; LEFT: 322px; POSITION: absolute; TOP: 261px" runat="server">�����Ţ�Թ��ҷ��س��ͧ��ë���</asp:label><asp:datagrid id="DataGrid1" style="Z-INDEX: 107; LEFT: 25px; POSITION: absolute; TOP: 362px" runat="server" AutoGenerateColumns="False" AlternatingItemStyle-BackColor="#ffcc66" ItemStyle-BackColor="#ffffcc" HeaderStyle-ForeColor="#ffffff" HeaderStyle-BackColor="#99ccff">
					<Columns>
						<asp:BoundColumn DataField="product_ID" HeaderText="�Թ���" />
						<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
						<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
						<asp:BoundColumn DataField="NetPrice" HeaderText="�ҤҢ�¨�ԧ" />
						<asp:BoundColumn DataField="PreCash" HeaderText="�Թ��ǹ�" />
						<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
						<asp:BoundColumn DataField="DurationToPaid" HeaderText="������ҷ���ͧ���¨���" />
						<asp:BoundColumn DataField="IntFirstYear" HeaderText="�͡���»��á" />
						<asp:BoundColumn DataField="IntPerMonth" HeaderText="�͡���µ����͹" />
						<asp:BoundColumn DataField="IntForPaidLatePerDate" HeaderText="�͡���¨��ª��" />
						<asp:BoundColumn DataField="VATRate" HeaderText="�ѵ������" />
						<asp:BoundColumn DataField="ContactName" HeaderText="������ҹ�ҹ" />
						<asp:BoundColumn DataField="Address" HeaderText="������������ҹ�ҹ" />
						<asp:BoundColumn DataField="Telephone" HeaderText="Tel ������ҹ�ҹ" />
					</Columns>
				</asp:datagrid><asp:image id="Image1" style="Z-INDEX: 108; LEFT: 15px; POSITION: absolute; TOP: 149px" runat="server" Width="305px" ImageUrl="\LandandHouseApp\cal.jpg" Height="167px"></asp:image><asp:label id="Label3" style="Z-INDEX: 109; LEFT: 285px; POSITION: absolute; TOP: 724px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:label></FONT></form>
	</body>
</HTML>
