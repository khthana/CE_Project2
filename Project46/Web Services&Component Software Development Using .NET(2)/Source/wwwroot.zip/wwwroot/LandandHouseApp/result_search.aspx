<%@ Page Language="vb" AutoEventWireup="false" Codebehind="result_search.aspx.vb" Inherits="LandandHouseApp.result_search"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_result_search</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:datagrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 101; LEFT: 246px; POSITION: absolute; TOP: 350px" runat="server">
					<Columns>
						<asp:BoundColumn DataField="product_ID" HeaderText="�Թ���" />
						<asp:BoundColumn DataField="productTypeName" HeaderText="�����ç���" />
						<asp:BoundColumn DataField="Price" HeaderText="�Ҥ�" />
						<asp:BoundColumn DataField="ClickHereForDetailCredit" HeaderText="�Թ����" />
					</Columns>
				</asp:datagrid><IMG style="Z-INDEX: 125; LEFT: 17px; POSITION: absolute; TOP: 2px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 119; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 120; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 121; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 122; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 123; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 124; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink>
				<asp:Image id="Image1" style="Z-INDEX: 102; LEFT: 12px; POSITION: absolute; TOP: 152px" runat="server" ImageUrl="\LandandHouseApp\hotgprs.gif"></asp:Image>
				<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 269px; POSITION: absolute; TOP: 630px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label></FONT></form>
	</body>
</HTML>
