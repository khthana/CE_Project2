<%@ Page Language="vb" AutoEventWireup="false" Codebehind="signup.aspx.vb" Inherits="LandandHouseApp.signup"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_signup</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 100; LEFT: 333px; POSITION: absolute; TOP: 230px" runat="server">����</asp:label><IMG style="Z-INDEX: 148; LEFT: 17px; POSITION: absolute; TOP: 1px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 119; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="index.html" ImageUrl="new.jpg">˹����ѡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 120; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="signup.aspx" ImageUrl="signup.jpg">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 122; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" NavigateUrl="login.aspx" ImageUrl="login.jpg">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 124; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="search_house.aspx" ImageUrl="search.jpg">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 125; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 127; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="ShowContact.aspx" ImageUrl="ShowContact.jpg">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 128; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" NavigateUrl="mailto:webmaster@landandhappyhome.com" ImageUrl="contact.jpg">�Դ������</asp:HyperLink>
				<asp:radiobutton id="RadioButton2" style="Z-INDEX: 108; LEFT: 602px; POSITION: absolute; TOP: 287px" runat="server" Text="˭ԧ" GroupName="Gender"></asp:radiobutton>
				<asp:radiobutton id="RadioButton1" style="Z-INDEX: 107; LEFT: 430px; POSITION: absolute; TOP: 284px" runat="server" Text="���" GroupName="Gender"></asp:radiobutton>
				<asp:textbox id="TextBox2" style="Z-INDEX: 103; LEFT: 724px; POSITION: absolute; TOP: 220px" runat="server"></asp:textbox>
				<asp:textbox id="TextBox1" style="Z-INDEX: 101; LEFT: 369px; POSITION: absolute; TOP: 226px" runat="server" Width="136px"></asp:textbox>
				<asp:label id="Label2" style="Z-INDEX: 102; LEFT: 640px; POSITION: absolute; TOP: 227px" runat="server">���ʡ��</asp:label>
				<asp:label id="Label3" style="Z-INDEX: 104; LEFT: 361px; POSITION: absolute; TOP: 359px" runat="server">�������������ö�Դ�����</asp:label>
				<asp:textbox id="TextBox3" style="Z-INDEX: 105; LEFT: 549px; POSITION: absolute; TOP: 325px" runat="server" Width="363px" TextMode="MultiLine" Height="67px"></asp:textbox>
				<asp:label id="Label4" style="Z-INDEX: 106; LEFT: 368px; POSITION: absolute; TOP: 289px" runat="server">��</asp:label>
				<asp:Label id="Label5" style="Z-INDEX: 109; LEFT: 458px; POSITION: absolute; TOP: 507px" runat="server">E-mail</asp:Label>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 110; LEFT: 549px; POSITION: absolute; TOP: 506px" runat="server" Width="259px"></asp:TextBox>
				<asp:Label id="Label6" style="Z-INDEX: 111; LEFT: 449px; POSITION: absolute; TOP: 618px" runat="server">�����</asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 112; LEFT: 378px; POSITION: absolute; TOP: 671px" runat="server">Sign in name ������</asp:Label>
				<asp:TextBox id="TextBox5" style="Z-INDEX: 113; LEFT: 547px; POSITION: absolute; TOP: 669px" runat="server"></asp:TextBox>
				<asp:Label id="Label8" style="Z-INDEX: 117; LEFT: 444px; POSITION: absolute; TOP: 714px" runat="server"> Password</asp:Label>
				<asp:TextBox id="TextBox6" style="Z-INDEX: 118; LEFT: 548px; POSITION: absolute; TOP: 711px" runat="server" Width="152px" TextMode="Password"></asp:TextBox>
				<asp:Label id="Label9" style="Z-INDEX: 121; LEFT: 402px; POSITION: absolute; TOP: 750px" runat="server">�׹�ѹ Password</asp:Label>
				<asp:TextBox id="TextBox7" style="Z-INDEX: 123; LEFT: 548px; POSITION: absolute; TOP: 749px" runat="server" TextMode="Password"></asp:TextBox>
				<asp:Button id="Button1" style="Z-INDEX: 126; LEFT: 545px; POSITION: absolute; TOP: 799px" runat="server" Text="Submit"></asp:Button>
				<asp:Button id="Button2" style="Z-INDEX: 130; LEFT: 717px; POSITION: absolute; TOP: 799px" runat="server" Text="Clear"></asp:Button>
				<asp:Label id="Label10" style="Z-INDEX: 131; LEFT: 517px; POSITION: absolute; TOP: 235px" runat="server" ForeColor="Red">*</asp:Label>
				<asp:Label id="Label11" style="Z-INDEX: 132; LEFT: 891px; POSITION: absolute; TOP: 224px" runat="server" ForeColor="Red">*</asp:Label>
				<asp:Label id="Label12" style="Z-INDEX: 133; LEFT: 722px; POSITION: absolute; TOP: 672px" runat="server" ForeColor="Red">*</asp:Label>
				<asp:Label id="Label13" style="Z-INDEX: 134; LEFT: 723px; POSITION: absolute; TOP: 720px" runat="server" ForeColor="Red">*</asp:Label>
				<asp:Label id="Label14" style="Z-INDEX: 135; LEFT: 726px; POSITION: absolute; TOP: 757px" runat="server" ForeColor="Red">*</asp:Label>
				<asp:RequiredFieldValidator id="RequiredFieldValidator1" ControlToValidate="TextBox1" style="Z-INDEX: 136; LEFT: 550px; POSITION: absolute; TOP: 230px" runat="server" Width="50px" ErrorMessage="required"></asp:RequiredFieldValidator>
				<asp:RequiredFieldValidator id="RequiredFieldValidator2" style="Z-INDEX: 137; LEFT: 922px; POSITION: absolute; TOP: 221px" runat="server" ErrorMessage="required" ControlToValidate="TextBox2"></asp:RequiredFieldValidator>
				<asp:TextBox id="TextBox8" style="Z-INDEX: 138; LEFT: 546px; POSITION: absolute; TOP: 616px" runat="server"></asp:TextBox>
				<asp:RequiredFieldValidator id="RequiredFieldValidator3" style="Z-INDEX: 139; LEFT: 764px; POSITION: absolute; TOP: 671px" runat="server" ErrorMessage="required" ControlToValidate="TextBox5"></asp:RequiredFieldValidator>
				<asp:CompareValidator id="CompareValidator1" style="Z-INDEX: 140; LEFT: 763px; POSITION: absolute; TOP: 745px" runat="server" ErrorMessage="not equall" ControlToValidate="TextBox6" ControlToCompare="TextBox7" Display="Dynamic"></asp:CompareValidator>
				<asp:Label id="Label15" style="Z-INDEX: 141; LEFT: 428px; POSITION: absolute; TOP: 438px" runat="server">Telephone</asp:Label>
				<asp:TextBox id="TextBox9" style="Z-INDEX: 142; LEFT: 548px; POSITION: absolute; TOP: 435px" runat="server"></asp:TextBox>
				<asp:Label id="Label16" style="Z-INDEX: 143; LEFT: 458px; POSITION: absolute; TOP: 564px" runat="server">�Ҫվ</asp:Label>
				<asp:TextBox id="TextBox10" style="Z-INDEX: 144; LEFT: 550px; POSITION: absolute; TOP: 555px" runat="server"></asp:TextBox>
				<asp:Label id="Label17" runat="server" style="Z-INDEX: 145; LEFT: 305px; POSITION: absolute; TOP: 965px" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label>
				<asp:Image id="Image1" style="Z-INDEX: 146; LEFT: 10px; POSITION: absolute; TOP: 174px" runat="server" Height="154px" Width="290px" ImageUrl="\LandandHouseApp\contact1.jpg"></asp:Image>
				<asp:Label id="Label18" style="Z-INDEX: 147; LEFT: 386px; POSITION: absolute; TOP: 913px" runat="server" ForeColor="Red"></asp:Label>
			</FONT>
		</form>
	</body>
</HTML>
