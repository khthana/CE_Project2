Imports System.Data
Imports System.Data.SqlClient
Public Class order
    Inherits System.Web.UI.Page
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink7 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink6 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim product_ID As String
        'Dim contact_ID As String = Session(contact_ID)

        product_ID = Request.QueryString("product_ID")
        TextBox1.Text = product_ID

    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim creditbank As String
        Dim product_ID As String

        Try
            product_ID = Request.QueryString("product_ID")

            If DropDownList1.SelectedItem.Value() = "NoBank" Then
                creditbank = ""
            Else
                creditbank = DropDownList1.SelectedItem.Value()
            End If

            Dim mypre_order As New localhost.LandAndHouseService()
            Dim mySet As New DataSet()
            Dim myTable As New DataTable()
            Dim myRow As DataRow

            mySet = mypre_order.showCredit(product_ID, creditbank)
            'Dim count As Decimal
            'count = mySet.Tables("dtname").Rows.Count

            'myTable.Columns.Add(New DataColumn("ClickHereForDetail", GetType(String)))
            myTable.Columns.Add(New DataColumn("product_ID", GetType(String)))
            myTable.Columns.Add(New DataColumn("CreditCompanyName", GetType(String)))
            myTable.Columns.Add(New DataColumn("SalePrice", GetType(String)))
            myTable.Columns.Add(New DataColumn("NetPrice", GetType(String)))
            myTable.Columns.Add(New DataColumn("PreCash", GetType(String)))
            myTable.Columns.Add(New DataColumn("PaidPerMonth", GetType(String)))
            myTable.Columns.Add(New DataColumn("DurationToPaid", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntFirstYear", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntPerMonth", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntForPaidLatePerDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("VATRate", GetType(String)))
            myTable.Columns.Add(New DataColumn("ContactName", GetType(String)))
            myTable.Columns.Add(New DataColumn("Address", GetType(String)))
            myTable.Columns.Add(New DataColumn("Telephone", GetType(String)))




            Dim i As Decimal = 0

            For Each myRow In mySet.Tables("dtname").Rows
                myRow = myTable.NewRow()
                myRow(0) = "<center>" & mySet.Tables("dtname").Rows(i).Item(0) & "</center>"

                'myRow(3) = link '"<center><img src=Image/cakeid" & rs(r).cake_id & "".jpg width=100 height=100>" & "</center>"

                myRow(1) = "<center>" & "<a href=order.aspx?product_ID=" & mySet.Tables("dtname").Rows(i).Item(0) & "&" & "CreditCompany_ID=" & mySet.Tables("dtname").Rows(i).Item(11) & ">" & mySet.Tables("dtname").Rows(i).Item(12) & "</a>" & "</center>"
                myRow(2) = "<center>" & mySet.Tables("dtname").Rows(i).Item(2) & "</center>"
                myRow(3) = "<center>" & mySet.Tables("dtname").Rows(i).Item(3) & "</center>"
                myRow(4) = "<center>" & mySet.Tables("dtname").Rows(i).Item(4) & "</center>"
                myRow(5) = "<center>" & mySet.Tables("dtname").Rows(i).Item(5) & "</center>"
                myRow(6) = "<center>" & mySet.Tables("dtname").Rows(i).Item(6) & "</center>"
                myRow(7) = "<center>" & mySet.Tables("dtname").Rows(i).Item(7) & "</center>"
                myRow(8) = "<center>" & mySet.Tables("dtname").Rows(i).Item(8) & "</center>"
                myRow(9) = "<center>" & mySet.Tables("dtname").Rows(i).Item(9) & "</center>"
                myRow(10) = "<center>" & mySet.Tables("dtname").Rows(i).Item(10) & "</center>"
                myRow(11) = "<center>" & mySet.Tables("dtname").Rows(i).Item(11) & "</center>"
                myRow(12) = "<center>" & mySet.Tables("dtname").Rows(i).Item(13) & "</center>"
                myRow(13) = "<center>" & mySet.Tables("dtname").Rows(i).Item(14) & "</center>"


                myTable.Rows.Add(myRow)
                i += 1
            Next


            'mySet.Tables("dtname").Clear()
            DataGrid1.DataSource = myTable
            'Dim myView As DataView = mySet.Tables("dtname").DefaultView

        DataGrid1.DataBind()
        Catch

        End Try
    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click

        DropDownList1.SelectedItem.Value() = "NoBank"
        Response.Redirect("search_house.aspx")

    End Sub
End Class
