<%@ Page Language="vb" AutoEventWireup="false" Codebehind="login.aspx.vb" Inherits="LandandHouseApp.index"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_Login</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 517px; POSITION: absolute; TOP: 249px" runat="server"> Username</asp:label><IMG style="Z-INDEX: 125; LEFT: 17px; POSITION: absolute; TOP: 2px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355"><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 124; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="contact.jpg" NavigateUrl="mailto:webmaster@landandhappyhome.com">�Դ������</asp:HyperLink>
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 123; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="ShowContact.jpg" NavigateUrl="ShowContact.aspx">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 122; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 121; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="search.jpg" NavigateUrl="search_house.aspx">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 120; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="login.jpg" NavigateUrl="login.aspx">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 119; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="signup.jpg" NavigateUrl="signup.aspx">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="new.jpg" NavigateUrl="index.html">˹����ѡ</asp:HyperLink><asp:button id="Button2" style="Z-INDEX: 106; LEFT: 698px; POSITION: absolute; TOP: 351px" runat="server" Height="26px" Width="52px" Text="Clear"></asp:button><asp:label id="Label2" style="Z-INDEX: 102; LEFT: 518px; POSITION: absolute; TOP: 309px" runat="server">Password</asp:label><asp:textbox id="TextBox1" style="Z-INDEX: 103; LEFT: 619px; POSITION: absolute; TOP: 246px" runat="server" ForeColor="#404040" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox2" style="Z-INDEX: 104; LEFT: 620px; POSITION: absolute; TOP: 305px" runat="server" TextMode="Password" BorderColor="#FFE0C0"></asp:textbox><asp:button id="Button1" style="Z-INDEX: 105; LEFT: 615px; POSITION: absolute; TOP: 353px" runat="server" Text="Submit"></asp:button><asp:label id="Label3" style="Z-INDEX: 107; LEFT: 532px; POSITION: absolute; TOP: 421px" runat="server" Width="318px" ForeColor="Red"></asp:label>
				<asp:Image id="Image1" style="Z-INDEX: 108; LEFT: 12px; POSITION: absolute; TOP: 169px" runat="server" ImageUrl="\LandandHouseApp\job.jpg"></asp:Image>
				<asp:Label id="Label4" style="Z-INDEX: 109; LEFT: 292px; POSITION: absolute; TOP: 706px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label></FONT></form>
	</body>
</HTML>
