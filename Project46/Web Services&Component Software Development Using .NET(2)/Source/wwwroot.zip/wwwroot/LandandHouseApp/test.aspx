<%@ Page Language="vb" AutoEventWireup="false" Codebehind="test.aspx.vb" Inherits="LandandHouseApp.test"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>test</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:TextBox id="TextBox1" style="Z-INDEX: 101; LEFT: 210px; POSITION: absolute; TOP: 110px" runat="server"></asp:TextBox>
				<asp:Button id="Button1" style="Z-INDEX: 102; LEFT: 220px; POSITION: absolute; TOP: 171px" runat="server" Text="Button"></asp:Button></FONT>
		</form>
	</body>
</HTML>
