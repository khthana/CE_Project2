<%@ Page Language="vb" AutoEventWireup="false" Codebehind="thank.aspx.vb" Inherits="LandandHouseApp.thank"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>thank</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 372px; POSITION: absolute; TOP: 520px" runat="server" ForeColor="Red">Copy right by Land & happyhome 2003</asp:Label><IMG style="Z-INDEX: 125; LEFT: 17px; POSITION: absolute; TOP: 2px" height="94" src="head1.jpg" width="174" align="absMiddle"><IMG style="Z-INDEX: 116; LEFT: 191px; POSITION: absolute; TOP: 0px" height="97" src="logo.jpg" width="355">
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 118; LEFT: 353px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="new.jpg" NavigateUrl="index.html">˹����ѡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 119; LEFT: 403px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="signup.jpg" NavigateUrl="signup.aspx">��Ѥ���Ҫԡ</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 120; LEFT: 469px; POSITION: absolute; TOP: 104px" runat="server" ImageUrl="login.jpg" NavigateUrl="login.aspx">�������к�</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 121; LEFT: 521px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="search.jpg" NavigateUrl="search_house.aspx">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 122; LEFT: 586px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="project.jpg">HyperLink</asp:HyperLink><IMG style="Z-INDEX: 114; LEFT: 547px; POSITION: absolute; TOP: 4px" height="94" src="head3.jpg" width="162"><IMG style="Z-INDEX: 115; LEFT: 709px; POSITION: absolute; TOP: 4px" height="94" src="head2.jpg" width="289">
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 123; LEFT: 790px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="ShowContact.jpg" NavigateUrl="ShowContact.aspx">�ʴ���������´ contact</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 124; LEFT: 904px; POSITION: absolute; TOP: 103px" runat="server" ImageUrl="contact.jpg" NavigateUrl="mailto:webmaster@landandhappyhome.com">�Դ������</asp:HyperLink>
				<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 357px; POSITION: absolute; TOP: 323px" runat="server" ForeColor="#FF8000">�Թ�շ�����Ѻ��س</asp:Label></FONT>
		</form>
	</body>
</HTML>
