Public Class pay
    Inherits System.Web.UI.Page
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink6 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink7 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

    End Sub

   
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim myShowpay As New localhost.LandAndHouseService()
        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow

        Dim customer_ID As String = Session.Contents("customer_ID")

        If (Session.Contents("customer_ID") = "") Then
            Response.Redirect("login.aspx")
        End If

        mySet = myShowpay.showdetailforpay(TextBox1.Text, customer_ID)
        'SaleDate,PaidDate,SalePrice,PaidPerMonth,TotalPaidNow,NumberOfLateDate,NetToPaid from ContactDetail where Product_ID = '" & product_ID & "'"

        myTable.Columns.Add(New DataColumn("SaleDate", GetType(String)))
        myTable.Columns.Add(New DataColumn("PaidDate", GetType(String)))
        myTable.Columns.Add(New DataColumn("SalePrice", GetType(String)))
        myTable.Columns.Add(New DataColumn("PaidPerMonth", GetType(String)))
        myTable.Columns.Add(New DataColumn("TotalPaidNow", GetType(String)))
        myTable.Columns.Add(New DataColumn("NumberOfLateDate", GetType(String)))
        myTable.Columns.Add(New DataColumn("NetToPaid", GetType(String)))



        myRow = myTable.NewRow()
        myRow(0) = "<center>" & mySet.Tables("dtname").Rows(0).Item(0) & " <center>"
        myRow(1) = "<center>" & mySet.Tables("dtname").Rows(0).Item(1) & " <center>"
        myRow(2) = "<center>" & mySet.Tables("dtname").Rows(0).Item(2) & " <center>"
        myRow(3) = "<center>" & mySet.Tables("dtname").Rows(0).Item(3) & " <center>"
        myRow(4) = "<center>" & mySet.Tables("dtname").Rows(0).Item(4) & " <center>"
        myRow(5) = "<center>" & mySet.Tables("dtname").Rows(0).Item(5) & " <center>"
        myRow(6) = "<center>" & mySet.Tables("dtname").Rows(0).Item(6) & " <center>"




        myTable.Rows.Add(myRow)

        DataGrid1.DataSource = myTable
        DataGrid1.DataBind()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim myPay As New localhost.LandAndHouseService()
        Dim result As Boolean

        result = myPay.pay(TextBox1.Text)

        If (result) Then
            Response.Redirect("ShowContact.aspx")
        Else : Response.Redirect("error.aspx")
        End If

    End Sub
End Class
