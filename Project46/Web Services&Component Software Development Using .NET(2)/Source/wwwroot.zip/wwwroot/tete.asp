<HTML>
<HEAD>
<TITLE> New Document </TITLE>
</HEAD>

<BODY>
<table>
<%
	Set Conn = Server.CreateObject("ADODB.Connection")
	Conn.Open "PROVIDER=sqloledb; DATA SOURCE=W\NETSDK;INITIAL CATALOG=tete;USER ID=sa;PASSWORD=123456;"
	sql = "Select * From test"
	Set Rs = Server.CreateObject("ADODB.Recordset")
	Rs.Open sql,Conn,1,3
	Rs.MoveFirst
	Do While Not Rs.Eof
%>
<tr>
	<td><%=Rs("id")%></td>
	<td><%=Rs("aaa")%></td>
	<td><%=Rs("bbb")%></td>
</tr>
<%
	Rs.MoveNext
	Loop
	Rs.Close
	Conn.Close
%>
</table>
</BODY>
</HTML>
