Imports System.Data
Imports System.Data.SqlClient
Imports HomeForYouApp.WebReference1

Public Class signup
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label
    Protected WithEvents Label18 As System.Web.UI.WebControls.Label
    Protected WithEvents Label19 As System.Web.UI.WebControls.Label
    Protected WithEvents Label20 As System.Web.UI.WebControls.Label
    Protected WithEvents Label21 As System.Web.UI.WebControls.Label
    Protected WithEvents Label22 As System.Web.UI.WebControls.Label
    Protected WithEvents Label23 As System.Web.UI.WebControls.Label
    Protected WithEvents Label24 As System.Web.UI.WebControls.Label
    Protected WithEvents Label25 As System.Web.UI.WebControls.Label
    Protected WithEvents Label26 As System.Web.UI.WebControls.Label
    Protected WithEvents Label27 As System.Web.UI.WebControls.Label
    Protected WithEvents Label28 As System.Web.UI.WebControls.Label
    Protected WithEvents txtFirstName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtLastName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtNationID As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAge As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtAddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMobile As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtJob As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdConfirm As System.Web.UI.WebControls.Button
    Protected WithEvents cmdCancel As System.Web.UI.WebControls.Button
    Protected WithEvents ddlSalary As System.Web.UI.WebControls.DropDownList
    Protected WithEvents RadioButtonList1 As System.Web.UI.WebControls.RadioButtonList

    
    Protected WithEvents txtPass As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents txtConfirmPass As System.Web.UI.HtmlControls.HtmlInputText
    Dim finish As String
    Dim myConn As SqlConnection = New SqlConnection()
    Dim signupService As Service1 = New Service1()
    Dim x As Integer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cmdConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConfirm.Click

        
        Session.Add("firstname", txtFirstName.Text)
        Session.Add("lastname", txtLastName.Text)
        Session.Add("age", txtAge.Text)
        Session.Add("sex", RadioButtonList1.SelectedItem.Value)
        Session.Add("address", txtAddress.Text)
        Session.Add("mobile", txtMobile.Text)
        Session.Add("phone", txtPhone.Text)
        Session.Add("job", txtJob.Text)
        Session.Add("salary", ddlSalary.SelectedItem.Value)
        Session.Add("username", txtUsername.Text)
        Session.Add("password", txtPass.Value)
        Session.Add("mail", txtMail.Text)
        Session.Add("idcard", txtNationID.Text)

        Dim username, idcard As String
        username = Session.Contents("username")
        
        idcard = Session.Contents("idcard")
        Dim serv As Service1 = New Service1()
        Dim chk As Boolean
        chk = serv.preSignUp(username, idcard)
        If (chk = False) Then
            MsgBox("����ҹ")
        Else
            'serv.SignUp(firstname, lastname, age, sex, address, mobile, phone, job, salary, username, password, mail, idcard)
            Response.Redirect("completeSignup.aspx")
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtNationID.Text = ""
        txtAge.Text = ""
        RadioButtonList1.ClearSelection()
        txtAddress.Text = ""
        txtPhone.Text = ""
        txtMobile.Text = ""
        ddlSalary.ClearSelection()
        txtJob.Text = ""
        txtMail.Text = ""
        txtUsername.Text = ""
        txtPass.Value = ""
        txtConfirmPass.Value = ""
    End Sub

    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub

End Class
