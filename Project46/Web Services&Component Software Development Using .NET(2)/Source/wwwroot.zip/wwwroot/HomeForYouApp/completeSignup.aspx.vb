Imports HomeForYouApp.WebReference1
Public Class completeSignup
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim firstname, lastname, age, sex, address, mobile, phone, job, salary, username, password, mail, idcard As String
        firstname = Session.Contents("firstname")
        lastname = Session.Contents("lastname")
        age = Session.Contents("age")
        sex = Session.Contents("sex")
        address = Session.Contents("address")
        mobile = Session.Contents("mobile")
        phone = Session.Contents("phone")
        job = Session.Contents("job")
        salary = Session.Contents("salary")
        username = Session.Contents("username")
        password = Session.Contents("password")
        mail = Session.Contents("mail")
        idcard = Session.Contents("idcard")
        Dim serv As Service1 = New Service1()
        serv.SignUp(firstname, lastname, age, sex, address, mobile, phone, job, salary, username, password, mail, idcard)
        MsgBox("�Թ�յ�͹�Ѻ�سŧ����¹���º��������")

    End Sub
    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub
End Class
