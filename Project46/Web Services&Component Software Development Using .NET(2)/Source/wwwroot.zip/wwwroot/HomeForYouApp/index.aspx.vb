Imports HomeForYouApp.WebReference1
Imports System.Data
Imports System.Data.SqlClient
Public Class index
    Inherits System.Web.UI.Page
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton9 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton8 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton6 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton5 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton4 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DIV1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Enter As System.Web.UI.WebControls.Button
    Protected WithEvents Cancel As System.Web.UI.WebControls.Button
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton10 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton11 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Password1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents ImageButton12 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Dim serv As Service1 = New Service1()
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Dim modelID As String
    Protected WithEvents cusname As System.Web.UI.WebControls.Label
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents greet As System.Web.UI.WebControls.Label
    Dim t As Boolean
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Function TimeToSeconds(ByVal newTime As Date) As Long
        TimeToSeconds = Hour(newTime) * 3600 + Minute(newTime) * 60 + Second _
            (newTime)
    End Function
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim r As Integer = Rnd() * (2)
        Dim mid, te As String

        Dim url(3) As String
        url(0) = "C:\Inetpub\wwwroot\HomeForYouApp\Pictures\H101.jpg"
        url(1) = "C:\Inetpub\wwwroot\HomeForYouApp\Pictures\H201.jpg"
        url(2) = "C:\Inetpub\wwwroot\HomeForYouApp\Pictures\H301.jpg"
        If r = 0 Then mid = "H201" Else mid = "H301"
        modelID = mid
        DIV1.InnerHtml = serv.ShowModel(mid, 300, 220)
        'If (Session.Contents("login") <> "true") Then
        Panel2.Visible = False
        greet.Visible = False
        'End If
        Dim r1 As Integer

        r1 = Rnd() * (2)

        If r1 = 0 Then Image1.ImageUrl() = url(0) Else 
        If r1 = 1 Then Image1.ImageUrl() = url(1) Else 
        If r1 = 2 Then Image1.ImageUrl() = url(2)

    End Sub


    Private Sub Enter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Enter.Click
        Dim oSQLConn As SqlConnection = New SqlConnection()
        oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                            "Data Source=161.246.6.113,1433;" & _
                            "Initial Catalog=HomeForYou;" & _
                            "User ID=sa;" & _
                            "Password=wx5k,x6hp"
        Dim check As String
        If ((TextBox1.Text <> "") And (Password1.Value <> "")) Then
            check = serv.Login(TextBox1.Text, Password1.Value)
            If (check <> "Invalid") Then
                Session.Add("ContactID", check)
                greet.Visible = True
                Panel1.Visible = False

                Panel2.Visible = True
                Session.Add("login", "true")
                Dim cname As String
                Dim myset As DataSet = New DataSet()
                Dim sql As String
                Dim str As String
                sql = "select FirstName from Customer where Username = '" & TextBox1.Text & "'"
                Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
                myAdapter.Fill(myset, "cus")
                cname = CStr(myset.Tables("cus").Rows(0).Item(0))
                cusname.Text = cname

            Else
                MsgBox("Username and Password invalid")
            End If
        Else
            MsgBox("��سҡ�͡ Username and Password ����")
        End If
        oSQLConn.Close()
    End Sub


    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        TextBox1.Text = " "
        Password1.Value = " "
    End Sub


    Private Sub ImageButton3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Response.Redirect("signup.aspx")
    End Sub

    Private Sub ImageButton8_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton8.Click
        Response.Redirect("search.aspx")
    End Sub


    Private Sub ImageButton4_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton4.Click
        Response.Redirect("allplan.aspx")
    End Sub

    Private Sub ImageButton6_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton6.Click
        Response.Redirect("orderPlan.aspx")
    End Sub
    Private Sub ImageButton5_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton5.Click
        Response.Redirect("orderBuildhome.aspx")
    End Sub
End Class
