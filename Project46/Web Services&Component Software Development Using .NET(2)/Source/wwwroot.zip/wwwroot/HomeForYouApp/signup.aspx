<%@ Page Language="vb" AutoEventWireup="false" Codebehind="signup.aspx.vb" Inherits="HomeForYouApp.signup"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>signup</title>
		<META content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<META content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<META content="JavaScript" name="vs_defaultClientScript">
		<META content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<!--<META http-equiv="refresh" content="3; url=completeSignup.aspx">-->
		<script language="VBScript">
Dim Bar, Line, SP
Bar = 0  
Line = "||"
SP = 100
Function Window_onLoad()
  Bar = 95
  SP = 10
End Function

Function Count()
  If Bar < 100 Then
    Bar = Bar + 1
    Window.Status = "Loading : " & Bar & "%" &  " " & String(Bar, Line)
    setTimeout "Count()", SP
  Else
    Window.Status = "HomeForYou The dream of house "
    Document.Body.Style.Display = ""
  End If    
End Function
Call Count()
		</script>
	</HEAD>
	<BODY bgColor="#fcecdd" MS_POSITIONING="GridLayout">
		<FORM id="Form1" method="post" runat="server">
			<FONT face="Tahoma"><FONT face="Tahoma">
					<asp:label id="Label25" style="Z-INDEX: 126; LEFT: 123px; POSITION: absolute; TOP: 824px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><IMG style="Z-INDEX: 144; LEFT: 11px; WIDTH: 476px; POSITION: absolute; TOP: 61px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\house-plans-logo1.gif" width="476"><IMG style="Z-INDEX: 104; LEFT: 485px; WIDTH: 121px; POSITION: absolute; TOP: 61px; HEIGHT: 60px" height="60" alt="" src="..\HomeForYouApp\Pictures\menu_01.gif" width="121"><IMG style="Z-INDEX: 101; LEFT: 604px; WIDTH: 365px; POSITION: absolute; TOP: 60px; HEIGHT: 61px" height="61" alt="" src="..\HomeForYouApp\Pictures\menu_03.jpg" width="365"><asp:label id="Label24" style="Z-INDEX: 125; LEFT: 125px; POSITION: absolute; TOP: 383px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:label id="Label23" style="Z-INDEX: 124; LEFT: 124px; POSITION: absolute; TOP: 790px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:label id="Label22" style="Z-INDEX: 123; LEFT: 124px; POSITION: absolute; TOP: 344px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:label id="Label21" style="Z-INDEX: 122; LEFT: 128px; POSITION: absolute; TOP: 515px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:label id="Label20" style="Z-INDEX: 121; LEFT: 121px; POSITION: absolute; TOP: 866px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:label id="Label1" style="Z-INDEX: 102; LEFT: 345px; POSITION: absolute; TOP: 239px" runat="server" Width="281px" Height="25px" ForeColor="#8080FF" Font-Size="Medium" BackColor="Lime" Font-Bold="True">�Թ�յ�͹�Ѻ�������к�ŧ����¹</asp:label><asp:label id="Label2" style="Z-INDEX: 103; LEFT: 155px; POSITION: absolute; TOP: 301px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">����</asp:label><asp:label id="Label3" style="Z-INDEX: 105; LEFT: 155px; POSITION: absolute; TOP: 343px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">���ʡ��</asp:label><asp:label id="Label4" style="Z-INDEX: 106; LEFT: 157px; POSITION: absolute; TOP: 382px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">�Ţ�ѵû�Шӵ�ǻ�ЪҪ�</asp:label><asp:label id="Label5" style="Z-INDEX: 107; LEFT: 155px; POSITION: absolute; TOP: 423px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">����</asp:label><asp:label id="Label6" style="Z-INDEX: 108; LEFT: 156px; POSITION: absolute; TOP: 457px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">��</asp:label><asp:label id="Label7" style="Z-INDEX: 109; LEFT: 154px; POSITION: absolute; TOP: 510px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">�������������ö�Դ�����</asp:label><asp:label id="Label8" style="Z-INDEX: 110; LEFT: 156px; POSITION: absolute; TOP: 603px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">�������Ѿ��</asp:label><asp:label id="Label9" style="Z-INDEX: 111; LEFT: 156px; POSITION: absolute; TOP: 642px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">��Ͷ��</asp:label><asp:label id="Label10" style="Z-INDEX: 112; LEFT: 154px; POSITION: absolute; TOP: 713px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">�Ҫվ</asp:label><asp:label id="Label11" style="Z-INDEX: 113; LEFT: 155px; POSITION: absolute; TOP: 680px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">�Թ��͹</asp:label><asp:label id="Label13" style="Z-INDEX: 114; LEFT: 155px; POSITION: absolute; TOP: 755px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">E-mail</asp:label><asp:label id="Label14" style="Z-INDEX: 115; LEFT: 155px; POSITION: absolute; TOP: 790px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">Username</asp:label><asp:label id="Label15" style="Z-INDEX: 116; LEFT: 157px; POSITION: absolute; TOP: 825px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">Password</asp:label><asp:label id="Label16" style="Z-INDEX: 117; LEFT: 156px; POSITION: absolute; TOP: 865px" runat="server" Width="200px" Height="25px" ForeColor="DarkBlue">Confirm Password</asp:label><asp:label id="Label17" style="Z-INDEX: 118; LEFT: 230px; POSITION: absolute; TOP: 921px" runat="server" Width="89px" Height="34px" ForeColor="DarkBlue">�����˵� :</asp:label><asp:label id="Label18" style="Z-INDEX: 119; LEFT: 343px; POSITION: absolute; TOP: 920px" runat="server" Width="308px" Height="51px" ForeColor="Red">��سҡ�͡���������ú�ء��ͧ ��੾�� ���������ͧ���� * ��ҧ˹�� </asp:label><asp:label id="Label19" style="Z-INDEX: 120; LEFT: 125px; POSITION: absolute; TOP: 303px" runat="server" Width="18px" Height="15px" ForeColor="Red">*</asp:label><asp:textbox id="txtFirstName" style="Z-INDEX: 127; LEFT: 362px; POSITION: absolute; TOP: 302px" tabIndex="1" runat="server" Width="250px" Height="25px" MaxLength="30"></asp:textbox><asp:textbox id="txtLastName" style="Z-INDEX: 128; LEFT: 362px; POSITION: absolute; TOP: 342px" tabIndex="2" runat="server" Width="250px" Height="25px" MaxLength="30"></asp:textbox><asp:textbox id="txtNationID" style="Z-INDEX: 129; LEFT: 361px; POSITION: absolute; TOP: 383px" tabIndex="3" runat="server" Width="250px" Height="25px" MaxLength="13"></asp:textbox><asp:textbox id="txtAge" style="Z-INDEX: 130; LEFT: 361px; POSITION: absolute; TOP: 422px" tabIndex="4" runat="server" Width="60px" Height="25px" MaxLength="3"></asp:textbox><asp:textbox id="txtAddress" style="Z-INDEX: 131; LEFT: 360px; POSITION: absolute; TOP: 503px" tabIndex="6" runat="server" Width="250px" Height="80px" TextMode="MultiLine" MaxLength="100"></asp:textbox><asp:textbox id="txtPhone" style="Z-INDEX: 132; LEFT: 359px; POSITION: absolute; TOP: 600px" tabIndex="7" runat="server" Width="250px" Height="25px" MaxLength="12"></asp:textbox><asp:textbox id="txtMobile" style="Z-INDEX: 133; LEFT: 358px; POSITION: absolute; TOP: 640px" tabIndex="8" runat="server" Width="250px" Height="25px" MaxLength="12"></asp:textbox><asp:textbox id="txtJob" style="Z-INDEX: 134; LEFT: 361px; POSITION: absolute; TOP: 713px" tabIndex="10" runat="server" Width="250px" Height="25px" MaxLength="25"></asp:textbox><asp:textbox id="txtMail" style="Z-INDEX: 135; LEFT: 361px; POSITION: absolute; TOP: 752px" tabIndex="11" runat="server" Width="250px" Height="25px" MaxLength="25"></asp:textbox><asp:textbox id="txtUsername" style="Z-INDEX: 136; LEFT: 360px; POSITION: absolute; TOP: 792px" tabIndex="12" runat="server" Width="250px" Height="25px" MaxLength="25"></asp:textbox><asp:button id="cmdConfirm" style="Z-INDEX: 137; LEFT: 353px; POSITION: absolute; TOP: 1004px" tabIndex="15" runat="server" Width="120px" Height="30px" Font-Bold="True" Text="��ŧ" ForeColor="MidnightBlue" BackColor="#FFE0C0"></asp:button><asp:button id="cmdCancel" style="Z-INDEX: 138; LEFT: 502px; POSITION: absolute; TOP: 1004px" tabIndex="16" runat="server" Width="120px" Height="30px" Font-Bold="True" Text="¡��ԡ" ForeColor="MidnightBlue" BackColor="#FFE0C0"></asp:button><asp:label id="Label26" style="Z-INDEX: 139; LEFT: 632px; POSITION: absolute; TOP: 829px" runat="server" Width="159px" Height="34px" ForeColor="DarkBlue">���ҧ���� 6 ����ѡ�� �������ͧ��ҧ</asp:label><asp:label id="Label27" style="Z-INDEX: 140; LEFT: 482px; POSITION: absolute; TOP: 422px" runat="server" Width="51px" Height="24px" ForeColor="DarkBlue">��</asp:label><asp:dropdownlist id="ddlSalary" style="Z-INDEX: 141; LEFT: 360px; POSITION: absolute; TOP: 680px" tabIndex="9" runat="server" Width="150px" Height="35px">
						<asp:ListItem Value="0">�Թ��͹</asp:ListItem>
						<asp:ListItem Value="�ҡ���� 100,000 ">�ҡ���� 100,000 </asp:ListItem>
						<asp:ListItem Value="80,000 - 99,999">80,000 - 99,999</asp:ListItem>
						<asp:ListItem Value="60,000 - 79,999">60,000 - 79,999</asp:ListItem>
						<asp:ListItem Value="40,000 - 59,999">40,000 - 59,999</asp:ListItem>
						<asp:ListItem Value="20,000 - 39,999">20,000 - 39,999</asp:ListItem>
						<asp:ListItem Value="���¡��� 20,000">���¡��� 20,000</asp:ListItem>
					</asp:dropdownlist><asp:label id="Label28" style="Z-INDEX: 142; LEFT: 543px; POSITION: absolute; TOP: 676px" runat="server" Width="32px" Height="31px" ForeColor="DarkBlue">�ҷ</asp:label><asp:radiobuttonlist id="RadioButtonList1" style="Z-INDEX: 143; LEFT: 397px; POSITION: absolute; TOP: 457px" tabIndex="5" runat="server" Width="200px" Height="30px" RepeatDirection="Horizontal" ForeColor="DarkBlue">
						<asp:ListItem Value="Male">���</asp:ListItem>
						<asp:ListItem Value="Female">˭ԧ</asp:ListItem>
					</asp:radiobuttonlist>
					<DIV style="DISPLAY: inline; Z-INDEX: 145; LEFT: 450px; WIDTH: 70px; POSITION: absolute; TOP: 1060px; HEIGHT: 62px" ms_positioning="FlowLayout"></DIV>
					<IMG style="Z-INDEX: 146; LEFT: 11px; POSITION: absolute; TOP: 121px" alt="" src="..\HomeForYouApp\Pictures\head_1fl2.gif">
					<INPUT id="txtPass" style="Z-INDEX: 147; LEFT: 359px; WIDTH: 251px; POSITION: absolute; TOP: 831px; HEIGHT: 26px" type="password" size="36" name="Password1" runat="server">
					<INPUT style="Z-INDEX: 148; LEFT: 360px; WIDTH: 248px; POSITION: absolute; TOP: 870px; HEIGHT: 26px" type="password" size="36" id="txtConfirmPass" name="Password1" runat="server"></FONT></FONT></FORM>
	</BODY>
</HTML>
