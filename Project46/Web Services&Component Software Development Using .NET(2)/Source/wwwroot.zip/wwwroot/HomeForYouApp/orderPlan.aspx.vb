Imports HomeForYouApp.WebReference1
Imports System.Data.SqlClient
Public Class orderPlan
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents CheckBox1 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox2 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox3 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox4 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox5 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox6 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton3 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Label18 As System.Web.UI.WebControls.Label
    Protected WithEvents Label19 As System.Web.UI.WebControls.Label
    Protected WithEvents Label20 As System.Web.UI.WebControls.Label
    Protected WithEvents Label21 As System.Web.UI.WebControls.Label
    Protected WithEvents Label22 As System.Web.UI.WebControls.Label
    Protected WithEvents Label23 As System.Web.UI.WebControls.Label
    Protected WithEvents Label24 As System.Web.UI.WebControls.Label
    Protected WithEvents Label25 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton5 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton6 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton9 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton8 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton4 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButtonList1 As System.Web.UI.WebControls.RadioButtonList
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Dim serv As Service1 = New Service1()
    Dim Pname(6) As String
    'Dim pload As Boolean = False
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        ImageButton6.Enabled = False
        'If Not Page.IsPostBack Then

        Dim p As Integer
        p = Session.Contents("Pageload")
        If p <> 1 Then
            Dim oSQLConn As SqlConnection = New SqlConnection()
            oSQLConn.ConnectionString = "Network Library=DBMSSOCN;" & _
                                        "Data Source=161.246.6.113,1433;" & _
                                        "Initial Catalog=HomeForYou;" & _
                                        "User ID=sa;" & _
                                        "Password=wx5k,x6hp"
            Dim ds As DataSet = New DataSet()
            Dim sql As String
            sql = "select homeid from Homeplan"
            Dim myAdapter As New SqlDataAdapter(sql, oSQLConn)
            myAdapter.Fill(ds, "order")
            oSQLConn.Close()
            Dim c, i As Integer
            c = CInt(ds.Tables("order").Rows.Count)
            i = 0
            While (i <> c)
                DropDownList1.Items.Add(New ListItem(ds.Tables("order").Rows(i).Item(0), ds.Tables("order").Rows(i).Item(0)))
                i += 1
            End While
            DropDownList1.DataBind()

        'If Session.Contents("ContactID") <> "" Then
            Session.Add("Pageload", 1)
            'Session.Add("nProduct", c)
        End If
        'End If
        'If DropDownList1.Items(0).Value = "0" Then MsgBox("EMPTY")
        'End If
    End Sub
    
    Private Sub ImageButton3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Session.Add("Pageload", 0)
        Response.Redirect("signup.aspx")
    End Sub

    Private Sub ImageButton8_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton8.Click
        Session.Add("Pageload", 0)
        Response.Redirect("search.aspx")
    End Sub


    Private Sub ImageButton4_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton4.Click
        Session.Add("Pageload", 0)
        Response.Redirect("allplan.aspx")
    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Session.Add("Pageload", 0)
        Response.Redirect("index.aspx")
    End Sub
    Private Sub ImageButton5_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton5.Click
        Session.Add("Pageload", 0)
        Response.Redirect("orderBuildhome.aspx")
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Session.Add("Pageload", 0)
        Dim chk, id, detail As String
        If CheckBox1.Checked = True Then
            detail += "Ẻ��ҧ,"
            Pname(0) = "ProtoPlan"
        Else : Pname(0) = ""
        End If
        If CheckBox2.Checked = True Then
            detail += "��������� 1 �ش,"
            Pname(1) = "GreenPrint_1"
        Else : Pname(1) = ""
        End If
        If CheckBox3.Checked = True Then
            detail += "��������� 5 �ش,"
            Pname(2) = "GreenPrint_5"
        Else : Pname(2) = ""
        End If
        If CheckBox4.Checked = True Then
            detail += "��������,"
            Pname(3) = "PrintCopy"
        Else : Pname(3) = ""
        End If
        If CheckBox5.Checked = True Then
            detail += "��Ѻ��ҹ���¢��,"
            Pname(4) = "ReverseSide_RL"
        Else : Pname(4) = ""
        End If
        If CheckBox6.Checked = True Then
            detail += "Ẻ��д���,"
            Pname(5) = "CarbonPaperPlan"
        Else : Pname(5) = ""
        End If
        id = Session.Contents("ContactID")
        If id = "" Then
            MsgBox("��س���͡�Թ��͹����¡��")
            'Response.Redirect("index.aspx")
        Else
            chk = serv.preOrder(id)
            If (chk = "OK") Then
                Dim totalprice As Integer = cal()
                chk = serv.submitOrderPlan(id, DropDownList1.SelectedItem.Value, RadioButtonList1.SelectedItem.Value, detail, totalprice)
            End If
            If chk = "Complete" Then
                Session.Add("Pageload", 0)
                Session.Add("order", "plan")
                Response.Redirect("thanks.aspx")
            End If
        End If
    End Sub

    Public Sub MsgBox(ByVal Message As String)
        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)
        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Dim totalprice As Integer = cal()
        Session.Add("Pageload", 1)
        TextBox1.Text = cal()
    End Sub

    Public Function cal() As String
        Dim i As Integer
        If CheckBox1.Checked = True Then

            Pname(0) = "ProtoPlan"
        Else : Pname(0) = ""
        End If
        If CheckBox2.Checked = True Then

            Pname(1) = "GreenPrint_1"
        Else : Pname(1) = ""
        End If
        If CheckBox3.Checked = True Then

            Pname(2) = "GreenPrint_5"
        Else : Pname(2) = ""
        End If
        If CheckBox4.Checked = True Then

            Pname(3) = "PrintCopy"
        Else : Pname(3) = ""
        End If
        If CheckBox5.Checked = True Then

            Pname(4) = "ReverseSide_RL"
        Else : Pname(4) = ""
        End If
        If CheckBox6.Checked = True Then

            Pname(5) = "CarbonPaperPlan"
        Else : Pname(5) = ""
        End If
        Dim totalprice = CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(0))) + CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(1))) + CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(2))) + CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(3))) + CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(4))) + CInt(serv.objPrice(DropDownList1.SelectedItem.Value, Pname(5)))
        Return totalprice
    End Function

    
End Class
