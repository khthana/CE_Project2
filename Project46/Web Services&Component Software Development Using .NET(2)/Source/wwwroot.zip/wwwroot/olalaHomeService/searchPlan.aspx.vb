Imports System.Data
Imports System.Data.SqlClient
Public Class WebForm2
    Inherits System.Web.UI.Page
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox8 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here


    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click

        Dim mySearchHomePlan As New WebReference1.Service1()
        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow

        
        'Try


        mySet = mySearchHomePlan.searchHomePlan(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, _
        TextBox5.Text, TextBox8.Text, TextBox6.Text, TextBox7.Text)

        myTable.Columns.Add(New DataColumn("homeid", GetType(String)))
        myTable.Columns.Add(New DataColumn("Style", GetType(String)))
        myTable.Columns.Add(New DataColumn("Area", GetType(String)))
        myTable.Columns.Add(New DataColumn("Width", GetType(String)))
        myTable.Columns.Add(New DataColumn("Depth", GetType(String)))
        myTable.Columns.Add(New DataColumn("Floors", GetType(String)))
        myTable.Columns.Add(New DataColumn("bathroom", GetType(String)))
        myTable.Columns.Add(New DataColumn("bedrooms", GetType(String)))
        myTable.Columns.Add(New DataColumn("Detail", GetType(String)))
        myTable.Columns.Add(New DataColumn("homepic", GetType(String)))

        'homeid(, Style, Area, Width, Depth, Floors, bathroom, bedrooms, Detail, homepic)
        Dim i As Decimal = 0

        For Each myRow In mySet.Tables("Homeplan").Rows


            myRow = myTable.NewRow()
            myRow(0) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(0) & "</center>"
            myRow(1) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(1) & "</center>"
            myRow(2) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(2) & "</center>"
            myRow(3) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(3) & "</center>"
            myRow(4) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(4) & "</center>"
            myRow(5) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(5) & "</center>"
            myRow(6) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(6) & "</center>"
            myRow(7) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(7) & "</center>"
            myRow(8) = "<center>" & mySet.Tables("Homeplan").Rows(i).Item(8) & "</center>"
            myRow(9) = "<center>" & "<img src=" & mySet.Tables("Homeplan").Rows(i).Item(9) & ">" & "</center>"

            myTable.Rows.Add(myRow)
            i += 1


        Next
        DataGrid1.DataSource = myTable
        DataGrid1.DataBind()
        'Catch


        'End Try


    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""

    End Sub
End Class
