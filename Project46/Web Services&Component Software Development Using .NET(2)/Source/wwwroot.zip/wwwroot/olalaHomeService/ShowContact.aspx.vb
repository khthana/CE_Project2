Public Class ShowContact
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink9 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim customer_ID As String = Session.Contents("customer_ID")

        If (Session.Contents("customer_ID") = "") Then
            Response.Redirect("loginAll.aspx")
        End If
        Try
            Dim myShowContact As New localhost.LandAndHouseService()
            Dim mySet As New DataSet()
            Dim myTable As New DataTable()
            Dim myRow As DataRow

            mySet = myShowContact.showcontact(customer_ID)

            'Dim count As Integer = mySet.Tables("dtname").Rows.Count

            myTable.Columns.Add(New DataColumn("product_ID", GetType(String)))
            myTable.Columns.Add(New DataColumn("ItemNumber", GetType(String)))
            myTable.Columns.Add(New DataColumn("SaleDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("SaleType", GetType(String)))
            myTable.Columns.Add(New DataColumn("ContactDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("SalePrice", GetType(String)))
            myTable.Columns.Add(New DataColumn("CreditCompanyName", GetType(String)))
            myTable.Columns.Add(New DataColumn("PaidDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("CustomerPaidDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("NumberOfLateDate", GetType(String)))
            myTable.Columns.Add(New DataColumn("PaidPerMonth", GetType(String)))
            myTable.Columns.Add(New DataColumn("TotalPaidNow", GetType(String)))
            myTable.Columns.Add(New DataColumn("NetToPaid", GetType(String)))
            'myTable.Columns.Add(New DataColumn("DurationToPaid", GetType(String)))
            myTable.Columns.Add(New DataColumn("StatusToPaid", GetType(String)))

            Dim i As Decimal = 0

            For Each myRow In mySet.Tables("dtname1").Rows

                myRow = myTable.NewRow()
                myRow(0) = "<center>" & "<a href=product" & mySet.Tables("dtname1").Rows(i).Item(14) & ".html target=_blank >" & mySet.Tables("dtname1").Rows(i).Item(14) & "</a>" & "</center>"
                myRow(1) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(1) & "</center>"
                myRow(2) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(2) & "</center>"
                myRow(3) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(3) & "</center>"
                myRow(4) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(4) & "</center>"
                myRow(5) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(5) & "</center>"
                myRow(6) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(6) & "</center>"
                myRow(7) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(7) & "</center>"
                myRow(8) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(8) & "</center>"
                myRow(9) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(9) & "</center>"
                myRow(10) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(10) & "</center>"
                myRow(11) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(11) & "</center>"
                myRow(12) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(12) & "</center>"
                myRow(13) = "<center>" & mySet.Tables("dtname1").Rows(i).Item(13) & "</center>"

                myTable.Rows.Add(myRow)
                i += 1

            Next

            DataGrid1.DataSource = myTable
            DataGrid1.DataBind()

        Catch ex As Exception
            'Response.Write(ex.Message)

            'Finally

        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Product_ID As String
        Product_ID = TextBox1.Text
        Dim customer_ID As String = Session.Contents("customer_ID")
        Dim myCancelContact As New localhost.LandAndHouseService()

        If (myCancelContact.CancelContact(customer_ID, Product_ID)) Then
            Label2.Text = "��������١�Ѿവ����"
            Response.Redirect("ShowContact.aspx")

        Else

            'Response.Redirect("ShowContact.aspx")
            Label2.Text = "�����żԴ��Ҵ �������ö�Ѿവ��"
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label2.Text = ""
        TextBox1.Text = ""
    End Sub
End Class
