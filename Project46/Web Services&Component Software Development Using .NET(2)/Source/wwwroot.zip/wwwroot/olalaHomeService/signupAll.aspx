<%@ Page Language="vb" AutoEventWireup="false" Codebehind="signupAll.aspx.vb" Inherits="olalaHomeService.signupAll"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>signupAll</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label8" style="Z-INDEX: 119; LEFT: 239px; POSITION: absolute; TOP: 791px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map><FONT face="Tahoma">
			<FORM id="Form1" method="post" runat="server">
				<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
				<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>&nbsp;
				<asp:ImageButton id="ImageButton1" style="Z-INDEX: 100; LEFT: 455px; POSITION: absolute; TOP: 672px" runat="server" ImageUrl="\olalaHomeService\submit.gif"></asp:ImageButton>
				<asp:ImageButton id="ImageButton2" style="Z-INDEX: 101; LEFT: 556px; POSITION: absolute; TOP: 672px" runat="server" ImageUrl="\olalaHomeService\cancel.gif"></asp:ImageButton>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 567px; POSITION: absolute; TOP: 241px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 103; LEFT: 570px; POSITION: absolute; TOP: 292px" runat="server" BorderColor="#FFE0C0"></asp:TextBox><TEXTAREA id="TEXTAREA1" style="Z-INDEX: 104; LEFT: 569px; WIDTH: 198px; POSITION: absolute; TOP: 457px; HEIGHT: 60px" name="TEXTAREA1" rows="3" cols="22" runat="server">
				</TEXTAREA>
				<asp:TextBox id="TextBox3" style="Z-INDEX: 105; LEFT: 569px; POSITION: absolute; TOP: 342px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:Label id="Label1" style="Z-INDEX: 106; LEFT: 370px; POSITION: absolute; TOP: 241px" runat="server">����</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 107; LEFT: 409px; POSITION: absolute; TOP: 290px" runat="server">���ʡ��</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 108; LEFT: 400px; POSITION: absolute; TOP: 399px" runat="server">Password</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 109; LEFT: 397px; POSITION: absolute; TOP: 464px" runat="server">�������</asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 110; LEFT: 399px; POSITION: absolute; TOP: 540px" runat="server">������</asp:Label>
				<asp:DropDownList id="DropDownList1" style="Z-INDEX: 111; LEFT: 461px; POSITION: absolute; TOP: 243px" runat="server">
					<asp:ListItem Value="Mr.">Mr.</asp:ListItem>
					<asp:ListItem Value="Miss">Miss</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label6" style="Z-INDEX: 112; LEFT: 389px; POSITION: absolute; TOP: 340px" runat="server">Username</asp:Label>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 113; LEFT: 569px; POSITION: absolute; TOP: 543px" runat="server" BorderColor="#FFE0C0" MaxLength="9"></asp:TextBox>
				<asp:TextBox id="TextBox5" style="Z-INDEX: 114; LEFT: 568px; POSITION: absolute; TOP: 395px" runat="server" BorderColor="#FFE0C0" TextMode="Password"></asp:TextBox>
				<asp:TextBox id="TextBox6" style="Z-INDEX: 116; LEFT: 570px; POSITION: absolute; TOP: 593px" runat="server" MaxLength="13" BorderColor="#FFE0C0" TextMode="Password"></asp:TextBox>
				<asp:Label id="Label7" style="Z-INDEX: 117; LEFT: 355px; POSITION: absolute; TOP: 598px" runat="server">�����Ţ credit card</asp:Label>
				<asp:Image id="Image1" style="Z-INDEX: 118; LEFT: 10px; POSITION: absolute; TOP: 194px" runat="server" ImageUrl="\olalaHomeService\signup_10.jpg"></asp:Image>
		</FONT></FORM>
	</body>
</HTML>
