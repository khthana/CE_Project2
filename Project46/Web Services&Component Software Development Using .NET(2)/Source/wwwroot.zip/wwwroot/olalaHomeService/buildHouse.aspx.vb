Public Class buildHouse
    Inherits System.Web.UI.Page
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents TEXTAREA1 As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents TEXTAREA2 As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton3 As System.Web.UI.WebControls.RadioButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim myBuildHome As New WebReference1.Service1()

    End Sub



  
    Public Function cal() As String
        Dim myCalBuild As New WebReference1.Service1()
        Dim type As String
        Dim result As String

        If RadioButton1.Checked Then
            type = "BuildPriceClassA_million"
        ElseIf RadioButton2.Checked Then
            type = "BuildPriceClassB_million"
        Else : type = "BuildPriceClassC_million"
        End If

        result = CInt(myCalBuild.objPrice(TextBox1.Text, type))

        Return result

    End Function



    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click

        Dim contact_ID As String
        Dim contact_id1 As String
        Dim result As String
        Dim resultSubmit As String
        Dim type As String
        Dim detail As String

        Dim myPreOrder As New WebReference1.Service1()


        If RadioButton1.Checked Then
            type = "BuildPriceClassA_million"
        ElseIf RadioButton2.Checked Then
            type = "BuildPriceClassB_million"
        Else : type = "BuildPriceClassC_million"
        End If



        If (Session.Contents("contact_ID") <> "") Then
            contact_id1 = Session.Contents("contact_ID")

            result = myPreOrder.preOrder(contact_id1)

            If (result = "OK") Then

                resultSubmit = myPreOrder.submitOrderHomeBuild(contact_id1, TextBox1.Text, "Credit", type, DropDownList1.SelectedItem.Value, DropDownList2.SelectedItem.Value, TEXTAREA1.Value, TEXTAREA2.Value, TextBox4.Text)

                'TextBox5.Text = resultSubmit
                'Else : Response.Redirect("loginPLan.aspx")

            End If

        Else : Response.Redirect("loginAll.aspx")

        End If


        If (resultSubmit = "Complete") Then
            Response.Redirect("thank.aspx")
        Else : Response.Redirect("loginAll.aspx")

        End If


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        TextBox4.Text = cal()
    End Sub
End Class
