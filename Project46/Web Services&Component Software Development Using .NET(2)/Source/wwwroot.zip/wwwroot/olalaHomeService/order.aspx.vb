Public Class order
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim customer_ID As String
        Dim product_ID As String
        Dim CreditCompany_ID As String
        Try
            product_ID = Request.QueryString("product_ID")
            CreditCompany_ID = Request.QueryString("CreditCompany_ID")

            If (Session.Contents("customer_ID") = "") Then
                Response.Redirect("loginAll.aspx")
            End If

            Dim myOrder As New localhost.LandAndHouseService()
            Dim mySet As New DataSet()
            Dim myTable As New DataTable()
            Dim myRow As DataRow

            mySet = myOrder.order(product_ID, CreditCompany_ID)
            myTable.Columns.Add(New DataColumn("product_ID", GetType(String)))
            myTable.Columns.Add(New DataColumn("CreditCompanyName", GetType(String)))
            myTable.Columns.Add(New DataColumn("SalePrice", GetType(String)))
            myTable.Columns.Add(New DataColumn("NetPrice", GetType(String)))
            myTable.Columns.Add(New DataColumn("PreCash", GetType(String)))
            myTable.Columns.Add(New DataColumn("PaidPerMonth", GetType(String)))
            myTable.Columns.Add(New DataColumn("DurationToPaid", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntFirstYear", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntPerMonth", GetType(String)))
            myTable.Columns.Add(New DataColumn("IntForPaidLatePerDate", GetType(String)))


            Dim i As Decimal = 0

            For Each myRow In mySet.Tables("dtname").Rows


                myRow = myTable.NewRow()
                myRow(0) = "<center>" & "<a href=product" & mySet.Tables("dtname").Rows(i).Item(0) & ".html target=_blank>" & mySet.Tables("dtname").Rows(i).Item(0) & "</a>" & "</center>"
                myRow(1) = "<center>" & mySet.Tables("dtname").Rows(i).Item(12) & "</center>"
                myRow(2) = "<center>" & mySet.Tables("dtname").Rows(i).Item(2) & "</center>"
                myRow(3) = "<center>" & mySet.Tables("dtname").Rows(i).Item(3) & "</center>"
                myRow(4) = "<center>" & mySet.Tables("dtname").Rows(i).Item(4) & "</center>"
                myRow(5) = "<center>" & mySet.Tables("dtname").Rows(i).Item(5) & "</center>"
                myRow(6) = "<center>" & mySet.Tables("dtname").Rows(i).Item(6) & "</center>"
                myRow(7) = "<center>" & mySet.Tables("dtname").Rows(i).Item(7) & "</center>"
                myRow(8) = "<center>" & mySet.Tables("dtname").Rows(i).Item(8) & "</center>"
                myRow(9) = "<center>" & mySet.Tables("dtname").Rows(i).Item(9) & "</center>"

                myTable.Rows.Add(myRow)
                i += 1


            Next


            DataGrid1.DataSource = myTable
            DataGrid1.DataBind()
        Catch


        End Try

    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim mySubmit As New localhost.LandAndHouseService()
        Dim mySet1 As New DataSet()
        Dim myTable1 As New DataTable()
        Dim myRow1 As DataRow

        Dim Customer_ID As String
        Dim SaleDate As String
        Dim SaleType As String
        Dim ContactDate As String
        Dim SalePrice As String
        Dim CreditCompanyName As String
        Dim PaidDate As String
        Dim PaidPerMonth As String

        Dim myOrder As New localhost.LandAndHouseService()
        Dim mySet As New DataSet()
        Dim myTable As New DataTable()
        Dim myRow As DataRow
        Dim product_ID As String
        Dim CreditCompany_ID As String

        product_ID = Request.QueryString("product_ID")
        CreditCompany_ID = Request.QueryString("CreditCompany_ID")

        mySet = myOrder.order(product_ID, CreditCompany_ID)


        Dim i As Decimal = 0

        For Each myRow In mySet.Tables("dtname").Rows


            myRow = myTable.NewRow()

            CreditCompanyName = mySet.Tables("dtname").Rows(i).Item(12)
            SalePrice = mySet.Tables("dtname").Rows(i).Item(2)
            PaidPerMonth = mySet.Tables("dtname").Rows(i).Item(5)
            myTable.Rows.Add(myRow)
            i += 1


        Next
        Customer_ID = Session.Contents("customer_ID")

        mySet1 = mySubmit.submit(Customer_ID, SaleDate, SaleType, _
                                ContactDate, SalePrice, CreditCompanyName, _
                                PaidDate, PaidPerMonth, product_ID)

        Response.Redirect("thank.aspx")

    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("searchHouse.aspx")
    End Sub
End Class
