<%@ Page Language="vb" AutoEventWireup="false" Codebehind="searchDecor.aspx.vb" Inherits="olalaHomeService.searchDecor"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>searchDecor</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 234px; POSITION: absolute; TOP: 997px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 413px; POSITION: absolute; TOP: 279px" runat="server">�����Թ���</asp:label><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><asp:textbox id="TextBox1" style="Z-INDEX: 102; LEFT: 519px; POSITION: absolute; TOP: 275px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:imagebutton id="ImageButton1" style="Z-INDEX: 103; LEFT: 472px; POSITION: absolute; TOP: 343px" runat="server" ImageUrl="\olalaHomeService\submit.gif"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 104; LEFT: 608px; POSITION: absolute; TOP: 343px" runat="server" ImageUrl="\olalaHomeService\cancel.gif"></asp:imagebutton><asp:datagrid id="DataGrid1" style="Z-INDEX: 105; LEFT: 65px; POSITION: absolute; TOP: 468px" runat="server" AutoGenerateColumns="False" AlternatingItemStyle-BackColor="#ffcc66" ItemStyle-BackColor="#ffffcc" HeaderStyle-ForeColor="#ffffff" HeaderStyle-BackColor="#99ccff">
				<Columns>
					<asp:BoundColumn DataField="�ӴѺ" HeaderText="�ӴѺ" />
					<asp:BoundColumn DataField="�����Թ���" HeaderText="�����Թ���" />
					<asp:BoundColumn DataField="�����Թ���" HeaderText="�����Թ���" />
					<asp:BoundColumn DataField="�Ҥ�" HeaderText="�Ҥ�" />
					<asp:BoundColumn DataField="���� barcode" HeaderText="���� barcode" />
					<asp:BoundColumn DataField="�ٻ�Ҿ" HeaderText="�ٻ�Ҿ" />
					<asp:BoundColumn DataField="��������´�Թ���" HeaderText="��������´�Թ���" />
					<asp:BoundColumn DataField="1" HeaderText="" />
				</Columns>
			</asp:datagrid>
			<asp:Image id="Image1" style="Z-INDEX: 106; LEFT: 11px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\homeDecor.jpg"></asp:Image></form>
	</body>
</HTML>
