Public Class WebForm3
    Inherits System.Web.UI.Page
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents CheckBox1 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox2 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox3 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox4 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox5 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents CheckBox6 As System.Web.UI.WebControls.CheckBox
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton3 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Dim Pname(6) As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
       

    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim contact_ID As String
        Dim contact_id1 As String
        Dim result As String
        Dim resultSubmit As String
        Dim type As String
        Dim detail As String

        Dim myPreOrder As New WebReference1.Service1()

       
        If RadioButton1.Checked Then
            type = "1"
        ElseIf RadioButton2.Checked Then
            type = "2"
        Else
            type = "3"
        End If

        If CheckBox1.Checked Then
            detail += "Ẻ��ҧ,"
        End If
        
        If CheckBox2.Checked Then
            detail += "��������� 1 �ش,"

        End If
        If CheckBox3.Checked = True Then
            detail += "��������� 5 �ش,"

        End If
        If CheckBox4.Checked = True Then
            detail += "��������,"

        End If
        If CheckBox5.Checked = True Then
            detail += "��Ѻ��ҹ���¢��,"

        End If
        If CheckBox6.Checked = True Then
            detail += "Ẻ��д���,"

        End If

        If (Session.Contents("contact_ID")) Then
            contact_id1 = Session.Contents("contact_ID")
            result = myPreOrder.preOrder(contact_id1)
            If (result = "OK") Then

                resultSubmit = myPreOrder.submitOrderPlan(contact_id1, TextBox1.Text, type, detail, TextBox2.Text)

                'TextBox5.Text = resultSubmit
                'Else : Response.Redirect("loginPLan.aspx")

            End If

        Else : Response.Redirect("loginPlan.aspx")

        End If


        If (resultSubmit = "Complete") Then
            Response.Redirect("thank.aspx")
        Else : Response.Redirect("loginAll.aspx")

        End If



    End Sub

    Public Function cal() As String
        Dim i As Integer
        Dim totalprice As String


        Dim myCalOrder As New WebReference1.Service1()

        If CheckBox1.Checked Then

            Pname(0) = "ProtoPlan"
        Else : Pname(0) = ""
        End If
        If CheckBox2.Checked Then

            Pname(1) = "GreenPrint_1"
        Else : Pname(1) = ""
        End If
        If CheckBox3.Checked Then

            Pname(2) = "GreenPrint_5"
        Else : Pname(2) = ""
        End If
        If CheckBox4.Checked Then

            Pname(3) = "PrintCopy"
        Else : Pname(3) = ""
        End If
        If CheckBox5.Checked Then

            Pname(4) = "ReverseSide_RL"
        Else : Pname(4) = ""
        End If
        If CheckBox6.Checked Then

            Pname(5) = "CarbonPaperPlan"
        Else : Pname(5) = ""
        End If

        totalprice = CInt(myCalOrder.objPrice(TextBox1.Text, Pname(0))) + CInt(myCalOrder.objPrice(TextBox1.Text, Pname(1))) + CInt(myCalOrder.objPrice(TextBox1.Text, Pname(2))) + CInt(myCalOrder.objPrice(TextBox1.Text, Pname(3))) + CInt(myCalOrder.objPrice(TextBox1.Text, Pname(4))) + CInt(myCalOrder.objPrice(TextBox1.Text, Pname(5)))
        Return totalprice
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox2.Text = cal()
    End Sub
End Class
