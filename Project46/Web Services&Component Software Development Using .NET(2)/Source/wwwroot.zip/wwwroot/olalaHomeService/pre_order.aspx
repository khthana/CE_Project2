<%@ Page Language="vb" AutoEventWireup="false" Codebehind="pre_order.aspx.vb" Inherits="olalaHomeService.pre_order"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>order</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 108; LEFT: 263px; POSITION: absolute; TOP: 776px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 100; LEFT: 380px; POSITION: absolute; TOP: 424px" runat="server">��س����͡����ѷ�Թ����</asp:label><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><asp:textbox id="TextBox1" style="Z-INDEX: 101; LEFT: 635px; POSITION: absolute; TOP: 358px" runat="server" BorderColor="#FFE0C0" Enabled="False" Width="93px"></asp:textbox><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 102; LEFT: 636px; POSITION: absolute; TOP: 423px" runat="server">
					<asp:ListItem Value="NoBank">��س����͡����ѷ�Թ����</asp:ListItem>
					<asp:ListItem Value="Thaipanit_Bank">��Ҥ���¾ҳԪ��</asp:ListItem>
					<asp:ListItem Value="Asia_Bank">��Ҥ�������</asp:ListItem>
					<asp:ListItem Value="Thanachad_Bank">��Ҥ�ø��ҵ�</asp:ListItem>
				</asp:dropdownlist>
				<asp:imagebutton id="ImageButton1" style="Z-INDEX: 103; LEFT: 374px; POSITION: absolute; TOP: 651px" runat="server" ImageUrl="\LandandHouseApp\submit.gif"></asp:imagebutton>
				<asp:imagebutton id="ImageButton2" style="Z-INDEX: 104; LEFT: 545px; POSITION: absolute; TOP: 649px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:imagebutton>
				<asp:label id="Label2" style="Z-INDEX: 105; LEFT: 322px; POSITION: absolute; TOP: 365px" runat="server">�����Ţ�Թ��ҷ��س��ͧ��ë���</asp:label>
				<asp:datagrid id="DataGrid1" style="Z-INDEX: 106; LEFT: 25px; POSITION: absolute; TOP: 466px" runat="server" AutoGenerateColumns="False" AlternatingItemStyle-BackColor="#ffcc66" ItemStyle-BackColor="#ffffcc" HeaderStyle-ForeColor="#ffffff" HeaderStyle-BackColor="#99ccff">
					<Columns>
						<asp:BoundColumn DataField="product_ID" HeaderText="�Թ���" />
						<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
						<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
						<asp:BoundColumn DataField="NetPrice" HeaderText="�ҤҢ�¨�ԧ" />
						<asp:BoundColumn DataField="PreCash" HeaderText="�Թ��ǹ�" />
						<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
						<asp:BoundColumn DataField="DurationToPaid" HeaderText="������ҷ���ͧ���¨���" />
						<asp:BoundColumn DataField="IntFirstYear" HeaderText="�͡���»��á" />
						<asp:BoundColumn DataField="IntPerMonth" HeaderText="�͡���µ����͹" />
						<asp:BoundColumn DataField="IntForPaidLatePerDate" HeaderText="�͡���¨��ª��" />
						<asp:BoundColumn DataField="VATRate" HeaderText="�ѵ������" />
						<asp:BoundColumn DataField="ContactName" HeaderText="������ҹ�ҹ" />
						<asp:BoundColumn DataField="Address" HeaderText="������������ҹ�ҹ" />
						<asp:BoundColumn DataField="Telephone" HeaderText="Tel ������ҹ�ҹ" />
					</Columns>
				</asp:datagrid><asp:image id="Image1" style="Z-INDEX: 107; LEFT: 10px; POSITION: absolute; TOP: 276px" runat="server" Width="305px" ImageUrl="\LandandHouseApp\cal.jpg" Height="167px"></asp:image></FONT></form>
	</body>
</HTML>
