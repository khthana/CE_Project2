<%@ Page Language="vb" AutoEventWireup="false" Codebehind="searchPlan.aspx.vb" Inherits="olalaHomeService.WebForm2"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>WebForm2</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label11" style="Z-INDEX: 125; LEFT: 312px; POSITION: absolute; TOP: 1062px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:ImageButton id="ImageButton1" style="Z-INDEX: 100; LEFT: 507px; POSITION: absolute; TOP: 616px" runat="server" ImageUrl="\olalaHomeService\submit.gif"></asp:ImageButton><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
				<asp:ImageButton id="ImageButton2" style="Z-INDEX: 101; LEFT: 609px; POSITION: absolute; TOP: 614px" runat="server" ImageUrl="\olalaHomeService\cancel.gif"></asp:ImageButton>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 591px; POSITION: absolute; TOP: 251px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 103; LEFT: 591px; POSITION: absolute; TOP: 291px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox3" style="Z-INDEX: 104; LEFT: 591px; POSITION: absolute; TOP: 330px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 105; LEFT: 591px; POSITION: absolute; TOP: 367px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox5" style="Z-INDEX: 106; LEFT: 591px; POSITION: absolute; TOP: 409px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox6" style="Z-INDEX: 107; LEFT: 591px; POSITION: absolute; TOP: 452px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox7" style="Z-INDEX: 108; LEFT: 591px; POSITION: absolute; TOP: 491px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:TextBox id="TextBox8" style="Z-INDEX: 109; LEFT: 591px; POSITION: absolute; TOP: 538px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:Label id="Label1" style="Z-INDEX: 110; LEFT: 397px; POSITION: absolute; TOP: 254px" runat="server">����ǳ</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 111; LEFT: 394px; POSITION: absolute; TOP: 296px" runat="server">�ٻẺ</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 112; LEFT: 396px; POSITION: absolute; TOP: 334px" runat="server">���</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 113; LEFT: 396px; POSITION: absolute; TOP: 370px" runat="server">���ҧ</asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 114; LEFT: 396px; POSITION: absolute; TOP: 413px" runat="server">�֡</asp:Label>
				<asp:Label id="Label6" style="Z-INDEX: 116; LEFT: 395px; POSITION: absolute; TOP: 455px" runat="server">��ͧ���</asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 117; LEFT: 394px; POSITION: absolute; TOP: 496px" runat="server">��ͧ�͹</asp:Label>
				<asp:Label id="Label8" style="Z-INDEX: 118; LEFT: 396px; POSITION: absolute; TOP: 543px" runat="server">��������´��� �</asp:Label>
				<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 119; LEFT: 54px; POSITION: absolute; TOP: 761px" runat="server">
					<Columns>
						<asp:BoundColumn DataField="homeid" HeaderText="Home ID" />
						<asp:BoundColumn DataField="Style" HeaderText="�ٻẺ" />
						<asp:BoundColumn DataField="Area" HeaderText="��鹷�������" />
						<asp:BoundColumn DataField="Width" HeaderText="���ҧ" />
						<asp:BoundColumn DataField="Depth" HeaderText="�֡" />
						<asp:BoundColumn DataField="Floors" HeaderText="���" />
						<asp:BoundColumn DataField="bathroom" HeaderText="��ͧ���" />
						<asp:BoundColumn DataField="bedrooms" HeaderText="��ͧ�͹" />
						<asp:BoundColumn DataField="Detail" HeaderText="��������´�Թ���" />
						<asp:BoundColumn DataField="homepic" HeaderText="�ٻ�Թ���" />
					</Columns>
				</asp:DataGrid>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 120; LEFT: 345px; POSITION: absolute; TOP: 723px" runat="server" NavigateUrl="orderPlan.aspx" ForeColor="#FFC080">Click</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 121; LEFT: 345px; POSITION: absolute; TOP: 687px" runat="server" NavigateUrl="buildHouse.aspx" ForeColor="#FFC080">Click</asp:HyperLink>
				<asp:Label id="Label9" style="Z-INDEX: 122; LEFT: 184px; POSITION: absolute; TOP: 685px" runat="server">��ҵ�ͧ������ҧ��ҹ</asp:Label>
				<asp:Label id="Label10" style="Z-INDEX: 123; LEFT: 184px; POSITION: absolute; TOP: 722px" runat="server">��ҵ�ͧ��ë���Ẻ��ҹ</asp:Label>
				<asp:Image id="Image1" style="Z-INDEX: 124; LEFT: 11px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\HomeForyou6.jpg"></asp:Image></FONT>
		</form>
	</body>
</HTML>
