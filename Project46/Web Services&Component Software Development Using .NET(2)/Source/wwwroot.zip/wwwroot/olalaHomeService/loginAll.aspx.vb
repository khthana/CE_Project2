Public Class loginAll
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
       
    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim myLoginDecor As New WebReference2.HomeandDecor()
        Dim myLoginPlan As New WebReference1.Service1()
        Dim myloginLandAndHouse As New localhost.LandAndHouseService()

        Dim resultDecor As Boolean
        Dim resultPlan As String
        Dim resultLandAndHouse As String

        resultDecor = myLoginDecor.Login(TextBox1.Text, TextBox2.Text)
        resultPlan = myLoginPlan.Login(TextBox1.Text, TextBox2.Text)
        resultLandAndHouse = myloginLandAndHouse.login(TextBox1.Text, TextBox2.Text)

        If (resultDecor = True And resultPlan <> "" And resultLandAndHouse <> "") Then
            Session.Add("name", TextBox1.Text)
            Session.Add("pass", TextBox2.Text)
            Session.Add("contact_ID", resultPlan)
            Session.Add("customer_ID", resultLandAndHouse)
            Response.Redirect("index.aspx")
        Else : Response.Redirect("signupAll.aspx")
        End If


    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
End Class
