<%@ Page Language="vb" AutoEventWireup="false" Codebehind="index.aspx.vb" Inherits="olalaHomeService.index"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>index</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 118; LEFT: 368px; POSITION: absolute; TOP: 1162px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map" style="LEFT: 9px; TOP: 15px"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"><FONT face="Tahoma"></FONT>
				<asp:HyperLink id="HyperLink9" style="Z-INDEX: 100; LEFT: 1125px; POSITION: absolute; TOP: 111px" runat="server" NavigateUrl="showContactPlan.aspx" ImageUrl="\olalaHomeService\viewbillplan.gif">HyperLink</asp:HyperLink></FONT>
			<OBJECT style="Z-INDEX: 101; LEFT: 303px; WIDTH: 181px; POSITION: absolute; TOP: 346px; HEIGHT: 150px" codeBase="http://161.246.6.113/vrml/cortvrml.cab" height="150" width="181" classid="CLSID:86A88967-7A20-11d2-8EDA-00600818EDB1" VIEWASTEXT>
				<PARAM NAME="NavigationBar" VALUE="0">
				<PARAM NAME="ConsoleMode" VALUE="0">
				<PARAM NAME="ShowFps" VALUE="0">
				<PARAM NAME="ShowRenderingTime" VALUE="0">
				<PARAM NAME="ShowProgress" VALUE="-1">
				<PARAM NAME="WaitForAllResources" VALUE="0">
				<PARAM NAME="Scene" VALUE="/olalaHomeService/Sofa1.wrl">
				<PARAM NAME="RendererName" VALUE="">
				<PARAM NAME="RendererHints" VALUE="1024">
				<PARAM NAME="Collider" VALUE="0">
				<PARAM NAME="ColliderMode" VALUE="0">
				<PARAM NAME="HeadLight" VALUE="-1">
				<PARAM NAME="NavigationMode" VALUE="3">
				<PARAM NAME="viewpoint_transition_mode" VALUE="0">
				<PARAM NAME="show_hidden_viewpoints" VALUE="0">
				<PARAM NAME="TravelSpeed" VALUE="2">
				<PARAM NAME="BackColor" VALUE="11728895">
				<PARAM NAME="ShowLogo" VALUE="0">
				<PARAM NAME="ContextMenu" VALUE="0">
				<PARAM NAME="VRML_BACKGROUND_COLOR" VALUE="#fff7b2">
				<PARAM NAME="VRML_DASHBOARD" VALUE="FALSE">
				<PARAM NAME="Mask" VALUE="">
				<PARAM NAME="LoadDroppedScene" VALUE="-1">
				<PARAM NAME="MuteSound" VALUE="0">
				<PARAM NAME="Appearance" VALUE="0">
				<PARAM NAME="CpuLoading" VALUE="80">
				<PARAM NAME="RendererOptimization" VALUE="1">
				<PARAM NAME="Skin" VALUE="{1706B265-E103-4332-9871-7FEE6C37C699}">
				<PARAM NAME="NavigationStyle" VALUE="turn">
				<PARAM NAME="NavigationType" VALUE="EXAMINE">
				<PARAM NAME="InputDevices" VALUE="7">
			</OBJECT>
			<OBJECT style="Z-INDEX: 102; LEFT: 571px; WIDTH: 183px; POSITION: absolute; TOP: 343px; HEIGHT: 153px" codeBase="http://161.246.6.113/vrml/cortvrml.cab" height="153" width="183" classid="CLSID:86A88967-7A20-11d2-8EDA-00600818EDB1" VIEWASTEXT>
				<PARAM NAME="NavigationBar" VALUE="0">
				<PARAM NAME="ConsoleMode" VALUE="0">
				<PARAM NAME="ShowFps" VALUE="0">
				<PARAM NAME="ShowRenderingTime" VALUE="0">
				<PARAM NAME="ShowProgress" VALUE="-1">
				<PARAM NAME="WaitForAllResources" VALUE="0">
				<PARAM NAME="Scene" VALUE="/olalaHomeService/table3.wrl">
				<PARAM NAME="RendererName" VALUE="">
				<PARAM NAME="RendererHints" VALUE="1024">
				<PARAM NAME="Collider" VALUE="0">
				<PARAM NAME="ColliderMode" VALUE="0">
				<PARAM NAME="HeadLight" VALUE="-1">
				<PARAM NAME="NavigationMode" VALUE="3">
				<PARAM NAME="viewpoint_transition_mode" VALUE="0">
				<PARAM NAME="show_hidden_viewpoints" VALUE="0">
				<PARAM NAME="TravelSpeed" VALUE="2">
				<PARAM NAME="BackColor" VALUE="11728895">
				<PARAM NAME="ShowLogo" VALUE="0">
				<PARAM NAME="ContextMenu" VALUE="0">
				<PARAM NAME="VRML_BACKGROUND_COLOR" VALUE="#fff7b2">
				<PARAM NAME="VRML_DASHBOARD" VALUE="FALSE">
				<PARAM NAME="Mask" VALUE="">
				<PARAM NAME="LoadDroppedScene" VALUE="-1">
				<PARAM NAME="MuteSound" VALUE="0">
				<PARAM NAME="Appearance" VALUE="0">
				<PARAM NAME="CpuLoading" VALUE="80">
				<PARAM NAME="RendererOptimization" VALUE="1">
				<PARAM NAME="Skin" VALUE="{1706B265-E103-4332-9871-7FEE6C37C699}">
				<PARAM NAME="NavigationStyle" VALUE="turn">
				<PARAM NAME="NavigationType" VALUE="EXAMINE">
				<PARAM NAME="InputDevices" VALUE="7">
			</OBJECT>
			<asp:Image id="Image1" style="Z-INDEX: 103; LEFT: 268px; POSITION: absolute; TOP: 543px" runat="server" ImageUrl="\olalaHomeService\Home&amp;Decor.gif"></asp:Image>
			<asp:Image id="Image5" style="Z-INDEX: 104; LEFT: 573px; POSITION: absolute; TOP: 545px" runat="server" ImageUrl="\olalaHomeService\Home&amp;Decor.gif"></asp:Image>
			<DIV id="DIV1" style="Z-INDEX: 106; LEFT: 294px; WIDTH: 100px; POSITION: absolute; TOP: 655px; HEIGHT: 100px" runat="server" ms_positioning="FlowLayout"></DIV>
			<DIV id="DIV2" style="Z-INDEX: 107; LEFT: 604px; WIDTH: 100px; POSITION: absolute; TOP: 655px; HEIGHT: 100px" runat="server" ms_positioning="FlowLayout"></DIV>
			<asp:Image id="Image6" style="Z-INDEX: 108; LEFT: 264px; POSITION: absolute; TOP: 829px" runat="server" ImageUrl="\olalaHomeService\homeforyou.gif"></asp:Image>
			<asp:Image id="Image8" style="Z-INDEX: 109; LEFT: 575px; POSITION: absolute; TOP: 825px" runat="server" ImageUrl="\olalaHomeService\homeforyou.gif"></asp:Image>
			<asp:Image id="Image11" style="Z-INDEX: 110; LEFT: 260px; POSITION: absolute; TOP: 1062px" runat="server" ImageUrl="\olalaHomeService\landandhome.gif"></asp:Image>
			<asp:Image id="Image12" style="Z-INDEX: 111; LEFT: 576px; POSITION: absolute; TOP: 1059px" runat="server" ImageUrl="\olalaHomeService\landandhome.gif"></asp:Image>
			<asp:Image id="Image4" style="Z-INDEX: 112; LEFT: 10px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\olala.jpg"></asp:Image>
			<asp:HyperLink id="HyperLink1" style="Z-INDEX: 113; LEFT: 273px; POSITION: absolute; TOP: 909px" runat="server" ImageUrl="\olalaHomeService\11.jpg" NavigateUrl="\olalaHomeService\product1.html">HyperLink</asp:HyperLink>
			<asp:HyperLink id="HyperLink2" style="Z-INDEX: 114; LEFT: 605px; POSITION: absolute; TOP: 912px" runat="server" ImageUrl="\olalaHomeService\4.jpg" NavigateUrl="\olalaHomeService\product2.html">HyperLink</asp:HyperLink>
			<asp:HyperLink id="HyperLink3" style="Z-INDEX: 116; LEFT: 312px; POSITION: absolute; TOP: 602px" runat="server" ImageUrl="\olalaHomeService\th_add.gif" NavigateUrl="preOrderDecor.aspx?Id=7">����</asp:HyperLink>
			<asp:HyperLink id="HyperLink4" style="Z-INDEX: 117; LEFT: 565px; POSITION: absolute; TOP: 606px" runat="server" ImageUrl="\olalaHomeService\th_add.gif" NavigateUrl="preOrderDecor.aspx?Id=12">����</asp:HyperLink>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
		</form>
	</body>
</HTML>
