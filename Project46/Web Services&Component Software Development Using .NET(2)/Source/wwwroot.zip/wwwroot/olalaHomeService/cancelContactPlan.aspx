<%@ Page Language="vb" AutoEventWireup="false" Codebehind="cancelContactPlan.aspx.vb" Inherits="olalaHomeService.cancelContactPlan"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>cancelContactPlan</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label4" style="Z-INDEX: 116; LEFT: 279px; POSITION: absolute; TOP: 529px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 330px; POSITION: absolute; TOP: 360px" runat="server" ForeColor="#FFC080">��¡���ѭ�Ңͧ�س</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 486px; POSITION: absolute; TOP: 362px" runat="server" ForeColor="#FF8000"></asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 551px; POSITION: absolute; TOP: 363px" runat="server" ForeColor="#FFC080">��١¡��ԡ����</asp:Label>
			<asp:Image id="Image1" style="Z-INDEX: 104; LEFT: 10px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\HomeForyou6.jpg"></asp:Image>
		</form>
	</body>
</HTML>
