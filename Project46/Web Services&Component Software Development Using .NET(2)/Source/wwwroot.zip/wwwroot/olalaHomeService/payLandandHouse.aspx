<%@ Page Language="vb" AutoEventWireup="false" Codebehind="payLandandHouse.aspx.vb" Inherits="olalaHomeService.payLandandHouse"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>payLandandHouse</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 271px; POSITION: absolute; TOP: 793px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 101; LEFT: 151px; POSITION: absolute; TOP: 500px" runat="server">
				<Columns>
					<asp:BoundColumn DataField="SaleDate" HeaderText="�ѹ�����" />
					<asp:BoundColumn DataField="PaidDate" HeaderText="�ѹ�����¤��駵���" />
					<asp:BoundColumn DataField="SalePrice" HeaderText="�ҤҢ��" />
					<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
					<asp:BoundColumn DataField="TotalPaidNow" HeaderText="���������" />
					<asp:BoundColumn DataField="NumberOfLateDate" HeaderText="�ѹ�����ª��" />
					<asp:BoundColumn DataField="NetToPaid" HeaderText="�ط�Է���ͧ����" />
				</Columns>
			</asp:DataGrid>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 350px; POSITION: absolute; TOP: 316px" runat="server"></asp:TextBox>
			<asp:Button id="Button1" style="Z-INDEX: 103; LEFT: 557px; POSITION: absolute; TOP: 314px" runat="server" Text="showdetail"></asp:Button>
			<asp:Button id="Button2" style="Z-INDEX: 104; LEFT: 664px; POSITION: absolute; TOP: 315px" runat="server" Text="pay"></asp:Button>
			<asp:Image id="Image1" style="Z-INDEX: 105; LEFT: 13px; POSITION: absolute; TOP: 195px" runat="server" ImageUrl="\olalaHomeService\land_4.jpg"></asp:Image>
		</form>
	</body>
</HTML>
