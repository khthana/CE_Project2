<%@ Page Language="vb" AutoEventWireup="false" Codebehind="order.aspx.vb" Inherits="olalaHomeService.order"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>order</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 304px; POSITION: absolute; TOP: 770px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<asp:label id="Label1" style="Z-INDEX: 100; LEFT: 381px; POSITION: absolute; TOP: 359px" runat="server">��¡���Թ��ҷ��س��觫���</asp:label><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<asp:datagrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 105; LEFT: 60px; POSITION: absolute; TOP: 453px" runat="server" Width="922px" Height="168px">
				<Columns>
					<asp:BoundColumn DataField="product_ID" HeaderText="�Թ���" />
					<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
					<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
					<asp:BoundColumn DataField="NetPrice" HeaderText="�ҤҢ�¨�ԧ" />
					<asp:BoundColumn DataField="PreCash" HeaderText="�Թ��ǹ�" />
					<asp:BoundColumn DataField="PaidPerMonth" HeaderText="���µ����͹" />
					<asp:BoundColumn DataField="DurationToPaid" HeaderText="������ҷ���ͧ���¨���" />
					<asp:BoundColumn DataField="IntFirstYear" HeaderText="�͡���»��á" />
					<asp:BoundColumn DataField="IntPerMonth" HeaderText="�͡���µ����͹" />
					<asp:BoundColumn DataField="IntForPaidLatePerDate" HeaderText="�͡���¨��ª��" />
				</Columns>
			</asp:datagrid>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 106; LEFT: 381px; POSITION: absolute; TOP: 641px" runat="server" ImageUrl="\LandandHouseApp\submit.gif"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 110; LEFT: 489px; POSITION: absolute; TOP: 641px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:ImageButton>
			<asp:Image id="Image1" style="Z-INDEX: 112; LEFT: 28px; POSITION: absolute; TOP: 224px" runat="server" ImageUrl="\olalaHomeService\land_4.jpg" Height="183px" Width="281px"></asp:Image></form>
	</body>
</HTML>
