<%@ Page Language="vb" AutoEventWireup="false" Codebehind="searchHouse.aspx.vb" Inherits="olalaHomeService.searchHouse"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_search</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label17" style="Z-INDEX: 135; LEFT: 321px; POSITION: absolute; TOP: 1253px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 100; LEFT: 520px; POSITION: absolute; TOP: 239px" runat="server" Width="267px">����Ẻ��ҹ�ҡ������ͧ��âͧ�س</asp:label><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><asp:dropdownlist id="DropDownList2" style="Z-INDEX: 121; LEFT: 685px; POSITION: absolute; TOP: 792px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="1">1 ��ͧ</asp:ListItem>
					<asp:ListItem Value="2">2 ��ͧ</asp:ListItem>
					<asp:ListItem Value="3">3 ��ͧ</asp:ListItem>
					<asp:ListItem Value="4">4 ��ͧ</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label6" style="Z-INDEX: 105; LEFT: 540px; POSITION: absolute; TOP: 546px" runat="server">�Ҥ�</asp:label><asp:label id="Label2" style="Z-INDEX: 101; LEFT: 543px; POSITION: absolute; TOP: 336px" runat="server">���ŷ����</asp:label><asp:label id="Label3" style="Z-INDEX: 102; LEFT: 579px; POSITION: absolute; TOP: 377px" runat="server">���</asp:label><asp:label id="Label4" style="Z-INDEX: 103; LEFT: 576px; POSITION: absolute; TOP: 425px" runat="server">�ǧ</asp:label><asp:label id="Label5" style="Z-INDEX: 104; LEFT: 586px; POSITION: absolute; TOP: 469px" runat="server">ࢵ</asp:label><asp:textbox id="TextBox1" style="Z-INDEX: 106; LEFT: 669px; POSITION: absolute; TOP: 374px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox2" style="Z-INDEX: 107; LEFT: 670px; POSITION: absolute; TOP: 422px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:label id="Label7" style="Z-INDEX: 108; LEFT: 824px; POSITION: absolute; TOP: 506px" runat="server">�֧</asp:label><asp:label id="Label8" style="Z-INDEX: 109; LEFT: 504px; POSITION: absolute; TOP: 507px" runat="server">��������´�ͧ</asp:label><asp:label id="Label9" style="Z-INDEX: 110; LEFT: 541px; POSITION: absolute; TOP: 610px" runat="server">�����ç���</asp:label><asp:label id="Label11" style="Z-INDEX: 112; LEFT: 547px; POSITION: absolute; TOP: 643px" runat="server">ʹ��˭��</asp:label><asp:radiobutton id="RadioButton1" style="Z-INDEX: 113; LEFT: 615px; POSITION: absolute; TOP: 698px" runat="server" Text="��ʹ��˭��" GroupName="garden"></asp:radiobutton><asp:radiobutton id="RadioButton2" style="Z-INDEX: 114; LEFT: 813px; POSITION: absolute; TOP: 699px" runat="server" Width="123px" Text="�����ʹ��˭��" GroupName="garden"></asp:radiobutton><asp:label id="Label12" style="Z-INDEX: 116; LEFT: 560px; POSITION: absolute; TOP: 739px" runat="server">��ͧ���</asp:label><asp:label id="Label13" style="Z-INDEX: 117; LEFT: 556px; POSITION: absolute; TOP: 795px" runat="server">��ͧ�͹</asp:label><asp:label id="Label14" style="Z-INDEX: 118; LEFT: 536px; POSITION: absolute; TOP: 840px" runat="server">�ѡɳк�ҹ</asp:label><asp:dropdownlist id="DropDownList3" style="Z-INDEX: 119; LEFT: 687px; POSITION: absolute; TOP: 841px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="Single">��ҹ�����</asp:ListItem>
					<asp:ListItem Value="Double">��ҹ���</asp:ListItem>
					<asp:ListItem Value="Townhouse">��ǹ�������</asp:ListItem>
				</asp:dropdownlist><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 120; LEFT: 681px; POSITION: absolute; TOP: 742px" runat="server">
					<asp:ListItem Value="0" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="1">1 ��ͧ</asp:ListItem>
					<asp:ListItem Value="2">2 ��ͧ</asp:ListItem>
					<asp:ListItem Value="3">3 ��ͧ</asp:ListItem>
					<asp:ListItem Value="4">4 ��ͧ</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label15" style="Z-INDEX: 122; LEFT: 552px; POSITION: absolute; TOP: 881px" runat="server">������¹��</asp:label><asp:radiobutton id="RadioButton3" style="Z-INDEX: 123; LEFT: 612px; POSITION: absolute; TOP: 929px" runat="server" BorderColor="#FFE0C0" Text="��" GroupName="pool"></asp:radiobutton><asp:radiobutton id="RadioButton4" style="Z-INDEX: 124; LEFT: 755px; POSITION: absolute; TOP: 925px" runat="server" Width="63px" BorderColor="#FFE0C0" Text="�����" GroupName="pool"></asp:radiobutton><asp:textbox id="TextBox3" style="Z-INDEX: 125; LEFT: 671px; POSITION: absolute; TOP: 471px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox4" style="Z-INDEX: 126; LEFT: 675px; POSITION: absolute; TOP: 543px" runat="server" Width="127px" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox5" style="Z-INDEX: 127; LEFT: 852px; POSITION: absolute; TOP: 544px" runat="server" Width="110px" BorderColor="#FFE0C0"></asp:textbox><asp:textbox id="TextBox6" style="Z-INDEX: 128; LEFT: 677px; POSITION: absolute; TOP: 611px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:imagebutton id="ImageButton1" style="Z-INDEX: 129; LEFT: 667px; POSITION: absolute; TOP: 991px" runat="server" ImageUrl="\LandandHouseApp\search.gif"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 130; LEFT: 803px; POSITION: absolute; TOP: 992px" runat="server" ImageUrl="\LandandHouseApp\cancel.gif"></asp:imagebutton><asp:label id="Label16" style="Z-INDEX: 131; LEFT: 422px; POSITION: absolute; TOP: 294px" runat="server">��س����͡ Search ��ҹ,���Թ</asp:label><asp:dropdownlist id="DropDownList4" style="Z-INDEX: 132; LEFT: 665px; POSITION: absolute; TOP: 296px" runat="server">
					<asp:ListItem Value="��س����͡" Selected="True">��س����͡</asp:ListItem>
					<asp:ListItem Value="house">��ҹ������ٻ</asp:ListItem>
					<asp:ListItem Value="land">���Թ����</asp:ListItem>
				</asp:dropdownlist>
				<asp:Image id="Image1" style="Z-INDEX: 134; LEFT: 9px; POSITION: absolute; TOP: 191px" runat="server" ImageUrl="\olalaHomeService\land_4.jpg"></asp:Image></FONT></form>
	</body>
</HTML>
