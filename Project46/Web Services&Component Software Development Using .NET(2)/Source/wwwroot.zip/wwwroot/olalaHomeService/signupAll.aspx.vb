Public Class signupAll
    Inherits System.Web.UI.Page
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TEXTAREA1 As System.Web.UI.HtmlControls.HtmlTextArea
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim mySignupDecor As New WebReference2.HomeandDecor()
        Dim mySignupPlan As New WebReference1.Service1()
        Dim mySignupLandAndHouse As New localhost.LandAndHouseService()

        Dim resultDecor As Boolean
        Dim resultPlan As String
        Dim resultLandAndHouse As String


        resultDecor = mySignupDecor.Signup(DropDownList1.SelectedItem.Value, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox5.Text, TEXTAREA1.Value, TextBox4.Text)
        resultPlan = mySignupPlan.SignUp(TextBox1.Text, TextBox2.Text, "", "", TEXTAREA1.Value, TextBox4.Text, TextBox4.Text, "", "", TextBox3.Text, TextBox5.Text, "", TextBox6.Text)
        resultLandAndHouse = mySignupLandAndHouse.signup(TextBox1.Text, TextBox2.Text, "", TEXTAREA1.Value, TextBox4.Text, "", "", "", TextBox3.Text, TextBox5.Text)

        If (resultDecor = True And resultPlan = True And resultLandAndHouse = True) Then
            Session.Add("name", TextBox3.Text)
            Response.Redirect("thank.aspx")

        Else : Response.Redirect("error.aspx")
        End If

    End Sub
End Class
