Imports System.Data
Imports System.Data.SqlClient
Public Class searchHouse
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList3 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents RadioButton3 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents RadioButton4 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents DropDownList4 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim street As String
        Dim district As String
        Dim aumper As String
        Dim price1 As String
        Dim price2 As String
        Dim productTypeName As String
        Dim garden As String
        Dim bathroom As String
        Dim bedroom As String
        Dim homeType As String
        Dim pool As String

        'If (DropDownList4.SelectedItem.Value = "��س����͡") And (check = 1) Then



        If RadioButton1.Checked Then
            garden = "Yes"
        ElseIf RadioButton2.Checked Then
            garden = "No"
        Else
            garden = ""
        End If

        If DropDownList1.SelectedItem.Value() = 0 Then
            bathroom = ""
        Else
            bathroom = DropDownList1.SelectedItem.Value()
        End If

        If DropDownList2.SelectedItem.Value() = 0 Then
            bedroom = ""
        Else
            bedroom = DropDownList2.SelectedItem.Value()
        End If

        If DropDownList3.SelectedItem.Value() = "0" Then
            homeType = ""
        Else
            homeType = DropDownList3.SelectedItem.Value()
        End If


        If RadioButton3.Checked Then
            pool = "Yes"
        ElseIf RadioButton4.Checked Then
            pool = "No"
        Else
            pool = ""
        End If

        Dim ret_str As String
        ret_str = "result_search.aspx?street=" & TextBox1.Text & "&" & "district=" & TextBox2.Text & "&" & "aumper=" & TextBox3.Text & "&" & "price1=" & TextBox4.Text & "&" & "price2=" & TextBox5.Text & "&" & "productTypeName=" & TextBox6.Text & "&" & "garden=" & garden & "&" & "bathroom=" & bathroom & "&" & "bedroom=" & bedroom & "&" & "homeType=" & homeType & "&" & "pool=" & pool & "&" & "productType=" & DropDownList4.SelectedItem.Value()
        Response.Redirect(ret_str)

    End Sub

    
    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox1.Text = ""
        TextBox1.Text = ""
        TextBox1.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
    End Sub
End Class
