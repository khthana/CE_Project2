Public Class viewBillDecor
    Inherits System.Web.UI.Page
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim myViewBillDecor As New WebReference2.HomeandDecor()
        Dim result() As String
        Dim user, password As String
        Dim length As Decimal
        Dim i, j, k, y As Integer
        j = 1

        If (Session.Contents("name") <> "") Then

            user = Session.Contents("name")
            password = Session.Contents("pass")

            result = myViewBillDecor.ViewBill(user, password)
            length = result.Length


            Dim myTable As New DataTable()
            Dim myRow As DataRow

            myTable.Columns.Add(New DataColumn("�ӴѺ", GetType(String)))
            myTable.Columns.Add(New DataColumn("Page", GetType(String)))

            For i = 0 To length - 1 Step +1

                myRow = myTable.NewRow()
                myRow(0) = "<center>" & j & "</center>"


                myRow(1) = "<center><a href=" & result(i) & ">" & result(i) & "</center>"

                myTable.Rows.Add(myRow)

                j = j + 1



            Next


            DataGrid1.DataSource = myTable
            DataGrid1.DataBind()

        Else : Response.Redirect("loginAll.aspx")
        End If

    End Sub

End Class
