<%@ Page Language="vb" AutoEventWireup="false" Codebehind="showContactPlan.aspx.vb" Inherits="olalaHomeService.showContactPlan"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>showContactPlan</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 255px; POSITION: absolute; TOP: 587px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:datagrid id="DataGrid1" style="Z-INDEX: 101; LEFT: 317px; POSITION: absolute; TOP: 284px" runat="server" AutoGenerateColumns="False" AlternatingItemStyle-BackColor="#ffcc66" ItemStyle-BackColor="#ffffcc" HeaderStyle-ForeColor="#ffffff" HeaderStyle-BackColor="#99ccff">
					<Columns>
						<asp:BoundColumn DataField="contact_ID" HeaderText="contact_ID" />
						<asp:BoundColumn DataField="�ѹ�����ѭ��" HeaderText="�ѹ�����ѭ��" />
						<asp:BoundColumn DataField="Home_ID" HeaderText="Home_ID" />
						<asp:BoundColumn DataField="��������´" HeaderText="��������´" />
					</Columns>
				</asp:datagrid><FONT face="Tahoma"></FONT>
				<asp:Button id="Button2" style="Z-INDEX: 102; LEFT: 498px; POSITION: absolute; TOP: 474px" runat="server" Text="Button"></asp:Button>
				<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 127px; POSITION: absolute; TOP: 472px" runat="server">��ͧ���¡��ԡ�ѭ�ҡ�س�</asp:Label>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 104; LEFT: 317px; POSITION: absolute; TOP: 473px" runat="server" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:Image id="Image1" style="Z-INDEX: 105; LEFT: 10px; POSITION: absolute; TOP: 191px" runat="server" ImageUrl="\olalaHomeService\viewbillHomeforYou.jpg"></asp:Image></FONT></form>
	</body>
</HTML>
