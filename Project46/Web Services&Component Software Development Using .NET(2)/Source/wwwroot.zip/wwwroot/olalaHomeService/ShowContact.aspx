<%@ Page Language="vb" AutoEventWireup="false" Codebehind="ShowContact.aspx.vb" Inherits="olalaHomeService.ShowContact"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Land & HappyHome_ShowContact</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 101; LEFT: 57px; POSITION: absolute; TOP: 514px" runat="server" Width="820px" Height="156px">
				<Columns>
					<asp:BoundColumn DataField="product_ID" HeaderText="�Թ��Ҫ�Դ���" />
					<asp:BoundColumn DataField="ItemNumber" HeaderText="�ӹǹ" />
					<asp:BoundColumn DataField="SaleDate" HeaderText="�ѹ������" />
					<asp:BoundColumn DataField="ContactDate" HeaderText="�ѹ���Ѵ���ѭ��" />
					<asp:BoundColumn DataField="SalePrice" HeaderText="�Ҥ�" />
					<asp:BoundColumn DataField="CreditCompanyName" HeaderText="����ѷ�Թ����" />
					<asp:BoundColumn DataField="PaidDate" HeaderText="�ѹ����ͧ�����Թ" />
					<asp:BoundColumn DataField="CustomerPaidDate" HeaderText="�ѹ����١��Ҩ����Թ" />
					<asp:BoundColumn DataField="NumberOfLateDate" HeaderText="�ӹǹ�ѹ�����ª��" />
					<asp:BoundColumn DataField="PaidPerMonth" HeaderText="�ӹǹ����ͧ���е����͹" />
					<asp:BoundColumn DataField="TotalPaidNow" HeaderText="���������" />
					<asp:BoundColumn DataField="StatusToPaid" HeaderText="�Ǵ������Ǩ���������" />
				</Columns>
			</asp:DataGrid><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 42px; POSITION: absolute; TOP: 777px" runat="server">��س���������Ţ����ͧ���¡��ԡ��èͧ</asp:Label>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 107; LEFT: 354px; POSITION: absolute; TOP: 771px" runat="server" Width="63px" BorderColor="#FFE0C0"></asp:TextBox>
			<asp:Button id="Button1" style="Z-INDEX: 109; LEFT: 479px; POSITION: absolute; TOP: 774px" runat="server" Text="submit"></asp:Button>
			<asp:Button id="Button2" style="Z-INDEX: 111; LEFT: 591px; POSITION: absolute; TOP: 774px" runat="server" Text="cancel"></asp:Button>
			<asp:Image id="Image1" style="Z-INDEX: 113; LEFT: 34px; POSITION: absolute; TOP: 226px" runat="server" ImageUrl="\olalaHomeService\viewbillLand.jpg"></asp:Image>
			<asp:Label id="Label2" style="Z-INDEX: 115; LEFT: 362px; POSITION: absolute; TOP: 848px" runat="server" BackColor="#FFFFC0"></asp:Label>
			<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 287px; POSITION: absolute; TOP: 955px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
			<asp:Label id="Label4" style="Z-INDEX: 121; LEFT: 47px; POSITION: absolute; TOP: 901px" runat="server" ForeColor="#C04000">��ͧ��è����Թ</asp:Label>
			<asp:HyperLink id="HyperLink9" style="Z-INDEX: 122; LEFT: 169px; POSITION: absolute; TOP: 901px" runat="server" NavigateUrl="payLandandHouse.aspx" ForeColor="#FF8000">Click</asp:HyperLink>
		</form>
	</body>
</HTML>
