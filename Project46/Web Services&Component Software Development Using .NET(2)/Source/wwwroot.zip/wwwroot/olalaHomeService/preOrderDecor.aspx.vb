Public Class preOrderDecor
    Inherits System.Web.UI.Page
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim myPreOrder As New WebReference2.HomeandDecor()
        Dim name, pass As String
        Dim user, password As String
        Dim result As Boolean
        Dim result_view()() As String
        Dim length As Decimal
        Dim summary As Decimal

        Dim myTable As New DataTable()
        Dim myRow As DataRow

        Dim i As Decimal
        Dim y As Integer
        Dim k As Decimal
        Dim j As Decimal = 1

        Dim product_id As String

        product_id = Request.QueryString("Id")


        If (Session.Contents("name") <> "") Then
          
            user = Session.Contents("name")
            password = Session.Contents("pass")

            result = myPreOrder.AddKeepSession(user, password, product_id)

            If (result = True) Then
                'Response.Redirect("searchDecor.aspx")
                result_view = myPreOrder.ViewKeepSession(user, password)

                length = result_view.Length()


                myTable.Columns.Add(New DataColumn("�ӴѺ", GetType(String)))
                myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
                myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
                myTable.Columns.Add(New DataColumn("�ӹǹ���ͧ", GetType(String)))
                myTable.Columns.Add(New DataColumn("price/unit", GetType(String)))
                myTable.Columns.Add(New DataColumn("price", GetType(String)))
               

                For i = 0 To length - 1 Step +1

                    myRow = myTable.NewRow()
                    myRow(0) = "<center>" & j & "</center>"

                    For y = 0 To 3 Step +1
                        If y <> 2 Then
                            myRow(y + 1) = "<center>" & result_view(i)(y) & "</center>"
                        Else
                            myRow(y + 1) = "<center>" & result_view(i)(y) & "</center>"

                        End If
                    Next

                    myRow(5) = "<center>" & result_view(i)(2) * result_view(i)(3) & "</center>"

                    summary += CDec(result_view(i)(2) * result_view(i)(3))

                    myTable.Rows.Add(myRow)

                    j = j + 1
                    'z = z + 1
                    k = k + 1

                Next


                DataGrid1.DataSource = myTable
                DataGrid1.DataBind()

                Label2.Text = summary

            Else : Response.Redirect("error.aspx")

            End If



        Else : Response.Redirect("loginAll.aspx")
        End If

    End Sub

  
   
    
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("searchDecor.aspx")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim myPreOrder1 As New WebReference2.HomeandDecor()
        Dim user As String
        Dim password As String
        Dim result As String

        user = Session.Contents("name")
        password = Session.Contents("pass")

        result = myPreOrder1.AddBuyProduct(user, password, 100, 1)

        If (result = True) Then
            Response.Redirect("thank.aspx")
        Else : Response.Redirect("error.aspx")

        End If

    End Sub
End Class
