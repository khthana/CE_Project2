Public Class searchDecor
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim mySearch As New WebReference2.HomeandDecor()
        Dim resultId() As String
        Dim resultProduct() As String
        Dim i As Decimal
        Dim j As Decimal = 1
        Dim k As Decimal = 0
        Dim x As Decimal = 0
        Dim y As Integer = 0
        Dim z As Decimal = 0
        Dim length1 As Decimal
        Dim length2 As Decimal

        Dim myTable As New DataTable()
        Dim myRow As DataRow

        resultId = mySearch.SearchProduct(TextBox1.Text)

        length1 = resultId.Length()

        Try
            myTable.Columns.Add(New DataColumn("�ӴѺ", GetType(String)))
            myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
            myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
            myTable.Columns.Add(New DataColumn("�Ҥ�", GetType(String)))
            myTable.Columns.Add(New DataColumn("���� barcode", GetType(String)))
            myTable.Columns.Add(New DataColumn("�ٻ�Ҿ", GetType(String)))
            myTable.Columns.Add(New DataColumn("��������´�Թ���", GetType(String)))
            myTable.Columns.Add(New DataColumn("1", GetType(String)))



            resultProduct = mySearch.ViewDetailProduct(resultId(k))

            For i = 0 To length1 - 1 Step +1


                resultProduct = mySearch.ViewDetailProduct(resultId(k))

                myRow = myTable.NewRow()
                myRow(0) = "<center>" & j & "</center>"
                myRow(7) = "<center>" & "<a href=preOrderDecor.aspx?Id=" & resultId(k) & "><img src=th_add.gif >" & "</center>"


                For y = 0 To 5 Step +1

                    myRow(y + 1) = "<center>" & resultProduct(y) & "</center>"

                Next
                myTable.Rows.Add(myRow)

                j = j + 1
                z = z + 1
                k = k + 1

            Next

            DataGrid1.DataSource = myTable
            DataGrid1.DataBind()
        Catch
        End Try
    End Sub

    Private Sub ImageButton3_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs)

        Dim myPreOrder As New WebReference2.HomeandDecor()
        Dim myViewKeepSession As New WebReference2.HomeandDecor()

        Dim name, pass As String
        Dim user, password As String
        Dim length As Decimal
        Dim result As Boolean
        Dim result1()() As String

        Dim myTable As New DataTable()
        Dim myRow As DataRow

        Dim i As Decimal
        Dim j As Decimal = 0
        Dim y As Integer = 0

        If (Session.Contents("name") <> "") Then

            user = Session.Contents("name")
            password = Session.Contents("pass")

            result = myPreOrder.AddKeepSession(user, password, TextBox1.Text)

            If (result = True) Then

                result1 = myViewKeepSession.ViewKeepSession(user, password)

                myTable.Columns.Add(New DataColumn("�ӴѺ", GetType(String)))
                myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
                myTable.Columns.Add(New DataColumn("�����Թ���", GetType(String)))
                myTable.Columns.Add(New DataColumn("�Ҥ�", GetType(String)))

                length = result1.Length()
                Dim k As String

                For i = 0 To length - 1 Step +1

                    myRow = myTable.NewRow()
                    myRow(0) = "<center>" & j & "</center>"

                    For y = 0 To 5 Step +1

                        myRow(y + 1) = "<center>" & result1(i)(y) & "</center>"

                    Next
                    myTable.Rows.Add(myRow)

                    j = j + 1

                Next

                DataGrid1.DataSource = myTable
                DataGrid1.DataBind()




            Else : Response.Redirect("")

            End If



        Else : Response.Redirect("loginAll.aspx")
        End If
    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        TextBox1.Text = ""
    End Sub


End Class
