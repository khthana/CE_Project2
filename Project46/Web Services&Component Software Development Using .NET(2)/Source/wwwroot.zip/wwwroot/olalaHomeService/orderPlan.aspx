<%@ Page Language="vb" AutoEventWireup="false" Codebehind="orderPlan.aspx.vb" Inherits="olalaHomeService.WebForm3"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>WebForm3</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<img src="index3.jpg" border="0" usemap="#Map" style="LEFT: 10px; TOP: 120px"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:textbox id="TextBox1" style="Z-INDEX: 101; LEFT: 464px; POSITION: absolute; TOP: 340px" runat="server" BorderColor="#FFE0C0"></asp:textbox><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><asp:imagebutton id="ImageButton1" style="Z-INDEX: 102; LEFT: 479px; POSITION: absolute; TOP: 689px" runat="server" ImageUrl="\olalaHomeService\submit.gif"></asp:imagebutton><asp:imagebutton id="ImageButton2" style="Z-INDEX: 103; LEFT: 606px; POSITION: absolute; TOP: 688px" runat="server" ImageUrl="\olalaHomeService\cancel.gif"></asp:imagebutton><asp:textbox id="TextBox2" style="Z-INDEX: 104; LEFT: 489px; POSITION: absolute; TOP: 476px" runat="server" BorderColor="#FFE0C0"></asp:textbox><asp:label id="Label1" style="Z-INDEX: 105; LEFT: 407px; POSITION: absolute; TOP: 344px" runat="server">id</asp:label><asp:button id="Button1" style="Z-INDEX: 106; LEFT: 359px; POSITION: absolute; TOP: 475px" runat="server" Text="�ӹǹ�Ҥ�"></asp:button><asp:checkbox id="CheckBox1" style="Z-INDEX: 107; LEFT: 281px; POSITION: absolute; TOP: 384px" runat="server" Text="Ẻ��ҧ"></asp:checkbox><asp:checkbox id="CheckBox2" style="Z-INDEX: 108; LEFT: 390px; POSITION: absolute; TOP: 386px" runat="server" Text="��������� 1 �ش"></asp:checkbox><asp:checkbox id="CheckBox3" style="Z-INDEX: 109; LEFT: 538px; POSITION: absolute; TOP: 385px" runat="server" Text="��������� 5 �ش"></asp:checkbox><asp:checkbox id="CheckBox4" style="Z-INDEX: 110; LEFT: 633px; POSITION: absolute; TOP: 424px" runat="server" Text="��������"></asp:checkbox><asp:checkbox id="CheckBox5" style="Z-INDEX: 111; LEFT: 434px; POSITION: absolute; TOP: 420px" runat="server" Text="��Ѻ��ҹ���� - ���" Width="157px"></asp:checkbox><asp:checkbox id="CheckBox6" style="Z-INDEX: 112; LEFT: 279px; POSITION: absolute; TOP: 418px" runat="server" Text="Ẻ��д���"></asp:checkbox><asp:radiobutton id="RadioButton1" style="Z-INDEX: 113; LEFT: 433px; POSITION: absolute; TOP: 549px" runat="server" Text="Ẻ 1 " GroupName="Ẻ"></asp:radiobutton><asp:radiobutton id="RadioButton2" style="Z-INDEX: 114; LEFT: 534px; POSITION: absolute; TOP: 551px" runat="server" Text="Ẻ 2 " GroupName="Ẻ"></asp:radiobutton><asp:radiobutton id="RadioButton3" style="Z-INDEX: 115; LEFT: 638px; POSITION: absolute; TOP: 551px" runat="server" Text="Ẻ 3" GroupName="Ẻ"></asp:radiobutton>
				<asp:Image id="Image1" style="Z-INDEX: 116; LEFT: 4px; POSITION: absolute; TOP: 213px" runat="server" ImageUrl="\olalaHomeService\HomeForyou6.jpg"></asp:Image></FONT></form>
	</body>
</HTML>
