<%@ Page Language="vb" AutoEventWireup="false" Codebehind="test.aspx.vb" Inherits="olalaHomeService.test"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>test</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<img src="\olalaHomeService\index3.jpg" width="821" height="577" border="0" usemap="#Map">
		<map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="#" target="1.html">
			<area shape="RECT" coords="543,159,633,177" href="#" target="1.html">
			<area shape="RECT" coords="445,159,544,177" href="#" target="1.html">
			<area shape="RECT" coords="329,159,446,177" href="#" target="1.html">
			<area shape="RECT" coords="248,159,330,177" href="#" target="1.html">
			<area shape="RECT" coords="161,159,249,177" href="#" target="1.html">
			<area shape="RECT" coords="116,159,162,177" href="#" target="1.html">
			<area shape="RECT" coords="65,159,117,177" href="#" target="1.html">
			<area shape="RECT" coords="14,159,66,177" href="#" target="1.html">
		</map>
		<form id="Form1" method="post" runat="server">
		</form>
	</body>
</HTML>
