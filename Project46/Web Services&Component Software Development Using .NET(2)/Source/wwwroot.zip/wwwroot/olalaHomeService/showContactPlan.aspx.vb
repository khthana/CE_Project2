Public Class showContactPlan
    Inherits System.Web.UI.Page
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        

        'Else : Response.Redirect("loginAll.aspx")
        'End If
        Dim myShowContact As New WebReference1.Service1()
        Dim contact_ID As String
        Dim mySet As New DataSet()

        Dim myTable As New DataTable()
        Dim myRow As DataRow
        Dim i As Decimal

        If (Session.Contents("name") <> "") Then
            contact_ID = Session.Contents("contact_ID")
            'contact_ID = TextBox1.Text

            mySet = myShowContact.ShowContact(contact_ID)

            myTable.Columns.Add(New DataColumn("contact_ID", GetType(String)))
            myTable.Columns.Add(New DataColumn("�ѹ�����ѭ��", GetType(String)))
            myTable.Columns.Add(New DataColumn("Home_ID", GetType(String)))
            myTable.Columns.Add(New DataColumn("��������´", GetType(String)))


            For Each myRow In mySet.Tables("cd").Rows
                myRow = myTable.NewRow()
                myRow(0) = "<center>" & mySet.Tables("cd").Rows(i).Item(0) & "</center>"
                myRow(1) = "<center>" & mySet.Tables("cd").Rows(i).Item(1) & "</center>"
                myRow(2) = "<center>" & mySet.Tables("cd").Rows(i).Item(2) & "</center>"
                myRow(3) = "<center>" & mySet.Tables("cd").Rows(i).Item(3) & "</center>"


                myTable.Rows.Add(myRow)
                i += 1
            Next
        Else : Response.Redirect("loginAll.aspx")
        End If

        DataGrid1.DataSource = myTable
        DataGrid1.DataBind()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim myCancelContact As New WebReference1.Service1()
        Dim contact_ID As String
        Dim result As String


        contact_ID = Session.Contents("contact_ID")
        'contact_ID = TextBox1.Text
        result = myCancelContact.CancelContact(contact_ID)
        If (result = "OK") Then
            Response.Redirect("cancelContactPlan.aspx")
        End If

    End Sub


End Class
