<%@ Page Language="vb" AutoEventWireup="false" Codebehind="loginAll.aspx.vb" Inherits="olalaHomeService.loginAll"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>loginAll</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 119; LEFT: 309px; POSITION: absolute; TOP: 584px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 100; LEFT: 424px; POSITION: absolute; TOP: 248px" runat="server">Username</asp:Label><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
				<asp:Label id="Label2" style="Z-INDEX: 105; LEFT: 426px; POSITION: absolute; TOP: 310px" runat="server">Password</asp:Label>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 109; LEFT: 536px; POSITION: absolute; TOP: 244px" runat="server" ForeColor="Black" BorderColor="#FFE0C0"></asp:TextBox></FONT>
			<asp:ImageButton id="ImageButton1" style="Z-INDEX: 111; LEFT: 466px; POSITION: absolute; TOP: 400px" runat="server" ImageUrl="submit.gif"></asp:ImageButton>
			<asp:ImageButton id="ImageButton2" style="Z-INDEX: 113; LEFT: 574px; POSITION: absolute; TOP: 399px" runat="server" ImageUrl="cancel.gif"></asp:ImageButton>
			<asp:TextBox id="TextBox2" style="Z-INDEX: 117; LEFT: 538px; POSITION: absolute; TOP: 301px" runat="server" BorderColor="#FFE0C0" TextMode="Password" Width="152px"></asp:TextBox>
			<asp:Image id="Image1" style="Z-INDEX: 118; LEFT: 11px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\login_11.jpg"></asp:Image>
		</form>
	</body>
</HTML>
