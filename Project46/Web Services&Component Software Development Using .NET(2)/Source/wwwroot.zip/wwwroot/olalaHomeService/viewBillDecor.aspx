<%@ Page Language="vb" AutoEventWireup="false" Codebehind="viewBillDecor.aspx.vb" Inherits="olalaHomeService.viewBillDecor"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>viewBillDecor</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label3" style="Z-INDEX: 116; LEFT: 262px; POSITION: absolute; TOP: 568px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:DataGrid HeaderStyle-BackColor="#99ccff" HeaderStyle-ForeColor="#ffffff" ItemStyle-BackColor="#ffffcc" AlternatingItemStyle-BackColor="#ffcc66" AutoGenerateColumns="False" id="DataGrid1" style="Z-INDEX: 101; LEFT: 381px; POSITION: absolute; TOP: 275px" runat="server">
					<Columns>
						<asp:BoundColumn DataField="�ӴѺ" HeaderText="�ӴѺ" />
						<asp:BoundColumn DataField="Page" HeaderText="Page" />
					</Columns>
				</asp:DataGrid>
				<asp:Image id="Image1" style="Z-INDEX: 102; LEFT: 9px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\viewbilldecor_5.jpg"></asp:Image><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT></FONT></form>
	</body>
</HTML>
