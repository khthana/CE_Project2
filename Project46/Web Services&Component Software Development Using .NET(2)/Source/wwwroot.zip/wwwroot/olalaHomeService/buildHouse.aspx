<%@ Page Language="vb" AutoEventWireup="false" Codebehind="buildHouse.aspx.vb" Inherits="olalaHomeService.buildHouse"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>buildHouse</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<asp:Label id="Label8" style="Z-INDEX: 121; LEFT: 238px; POSITION: absolute; TOP: 981px" runat="server" ForeColor="Red">Copy right by Olala Home Services 2004</asp:Label>
		<img src="index3.jpg" border="0" usemap="#Map"> <map name="MapMap">
			<area shape="RECT" coords="65,159,114,177" href="#" target="1.html">
		</map><map name="Map">
			<area shape="RECT" coords="632,159,759,177" href="ShowContact.aspx" target="">
			<area shape="RECT" coords="543,159,633,177" href="showContactPlan.aspx" target="">
			<area shape="RECT" coords="445,159,544,177" href="viewBillDecor.aspx" target="">
			<area shape="RECT" coords="329,159,446,177" href="searchHouse.aspx" target="">
			<area shape="RECT" coords="248,159,330,177" href="searchPlan.aspx" target="">
			<area shape="RECT" coords="161,159,249,177" href="searchDecor.aspx" target="">
			<area shape="RECT" coords="116,159,162,177" href="loginAll.aspx" target="">
			<area shape="RECT" coords="65,159,117,177" href="signupAll.aspx" target="">
			<area shape="RECT" coords="14,159,66,177" href="index.aspx" target="">
		</map>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:TextBox id="TextBox1" style="Z-INDEX: 100; LEFT: 388px; POSITION: absolute; TOP: 217px" runat="server" Width="103px" BorderColor="#FFE0C0"></asp:TextBox><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
				<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 302px; POSITION: absolute; TOP: 223px" runat="server">ID</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 304px; POSITION: absolute; TOP: 271px" runat="server">��ʴء�����ҧ</asp:Label>
				<asp:RadioButton id="RadioButton1" style="Z-INDEX: 103; LEFT: 420px; POSITION: absolute; TOP: 270px" runat="server" Text="���ҧ��" GroupName="��ʴ�"></asp:RadioButton>
				<asp:RadioButton id="RadioButton2" style="Z-INDEX: 104; LEFT: 555px; POSITION: absolute; TOP: 269px" runat="server" Text="�ҹ��ҧ" GroupName="��ʴ�"></asp:RadioButton>
				<asp:RadioButton id="RadioButton3" style="Z-INDEX: 105; LEFT: 691px; POSITION: absolute; TOP: 270px" runat="server" Text="������" GroupName="��ʴ�"></asp:RadioButton>
				<asp:Label id="Label3" style="Z-INDEX: 106; LEFT: 303px; POSITION: absolute; TOP: 338px" runat="server">�պ�ҹ</asp:Label>
				<asp:DropDownList id="DropDownList1" style="Z-INDEX: 107; LEFT: 397px; POSITION: absolute; TOP: 338px" runat="server" BackColor="White">
					<asp:ListItem Value="0">��س����͡</asp:ListItem>
					<asp:ListItem Value="white">white</asp:ListItem>
					<asp:ListItem Value="red">red</asp:ListItem>
					<asp:ListItem Value="blue">blue</asp:ListItem>
					<asp:ListItem Value="green">green</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label4" style="Z-INDEX: 108; LEFT: 308px; POSITION: absolute; TOP: 394px" runat="server">����ѧ��</asp:Label>
				<asp:DropDownList id="DropDownList2" style="Z-INDEX: 109; LEFT: 398px; POSITION: absolute; TOP: 391px" runat="server">
					<asp:ListItem Value="0">��س����͡</asp:ListItem>
					<asp:ListItem Value="white">white</asp:ListItem>
					<asp:ListItem Value="red">red</asp:ListItem>
					<asp:ListItem Value="blue">blue</asp:ListItem>
					<asp:ListItem Value="green">green</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label5" style="Z-INDEX: 110; LEFT: 301px; POSITION: absolute; TOP: 450px" runat="server">ʶҹ��������ҧ</asp:Label><TEXTAREA id="TEXTAREA1" style="Z-INDEX: 111; LEFT: 429px; WIDTH: 184px; POSITION: absolute; TOP: 450px; HEIGHT: 94px" rows="6" cols="20" runat="server">
				</TEXTAREA>
				<asp:Label id="Label7" style="Z-INDEX: 112; LEFT: 275px; POSITION: absolute; TOP: 586px" runat="server">��������´�������</asp:Label><TEXTAREA id="TEXTAREA2" style="Z-INDEX: 113; LEFT: 430px; WIDTH: 184px; POSITION: absolute; TOP: 596px; HEIGHT: 98px" name="TEXTAREA2" rows="6" cols="20" runat="server">
				</TEXTAREA>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 114; LEFT: 433px; POSITION: absolute; TOP: 771px" runat="server" Width="69px" BorderColor="#FFE0C0"></asp:TextBox>
				<asp:ImageButton id="ImageButton2" style="Z-INDEX: 116; LEFT: 411px; POSITION: absolute; TOP: 853px" runat="server" ImageUrl="submit.gif"></asp:ImageButton>
				<asp:ImageButton id="ImageButton3" style="Z-INDEX: 117; LEFT: 540px; POSITION: absolute; TOP: 855px" runat="server" ImageUrl="cancel.gif"></asp:ImageButton>
				<asp:Button id="Button1" style="Z-INDEX: 118; LEFT: 651px; POSITION: absolute; TOP: 771px" runat="server" Text="�ӹǳ�Ҥ�"></asp:Button>
				<asp:Label id="Label6" style="Z-INDEX: 119; LEFT: 542px; POSITION: absolute; TOP: 774px" runat="server">��ҹ�ҷ</asp:Label>
				<asp:Image id="Image1" style="Z-INDEX: 120; LEFT: 10px; POSITION: absolute; TOP: 192px" runat="server" ImageUrl="\olalaHomeService\HomeForyou6.jpg"></asp:Image></FONT>
		</form>
	</body>
</HTML>
