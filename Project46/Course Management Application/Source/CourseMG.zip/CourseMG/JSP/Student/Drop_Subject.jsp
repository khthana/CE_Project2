<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String ridSubjects[] = request.getParameterValues("ridSubjects");

	if(ridSubjects!= null) {
		for (int i = 0;i<ridSubjects.length;i++){
			ridSubjects[i] = thaistring.MS874ToUnicode(ridSubjects[i]);
			System.out.println(ridSubjects[i]);
			System.out.println("1");
			student.dropSubject(ridSubjects[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	response.sendRedirect("Subject_Student_Menu.jsp");
%>




<!--- End Footer --->
<% } %>