<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridNews =	request.getParameter("idNews");
		if (ridNews == null)  ridNews = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t  N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t  N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
 .



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >










<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="left">
			<table border="0" cellpadding="0" cellspacing="0" width="575">
				<tr>
						<td><a href="Subject_Student_SyllabusTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavproducts" src="Picture/Tab_Syllabus.gif"  width="82" height="25" border="0"></a></td>
   					    <td><a href="Subject_Student_NewsTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavcustomers" src="Picture/Tab_News_Selected.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_TimetableTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavpartners" src="Picture/Tab_Timetable.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_WebboardTab_Detail.jsp?idSubject=<%=ridSubject%>"><img name="topnavsupport" src="Picture/Tab_Webboard.gif" width="82" height="25" border="0"></a></td>
 						<td><a href="Subject_Student_ChatTab.jsp?idSubject=<%=ridSubject%>"><img name="topnavdeveloper" src="Picture/Tab_Chat.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_AssignmentTab_View.jsp?idSubject=<%=ridSubject%>"><img name="topnavcompany" src="Picture/Tab_Assignment.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_ExamTab_View.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Examination.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_ScoreTab.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Score.gif" width="82" height="25" border="0"></a></td>
						<td width="*"><img name="topnavdeveloper" src="Picture/Tab_Blank.gif" width="171" height="25" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/spacer.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="98%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	
		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
    

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
   <td width="846">
	<table border="0" cellspacing="0" cellpadding="0" width="650">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <table width="100%" border="1"  align="left" cellpadding="0" cellspacing="3"  bgcolor="EFFAD1">
                    <tr background="Picture/bg.gif">
                      <td colspan="4" class="headerdarkblue">
					  <img src="Picture/news_detail.gif" width="95" height="20" border="0"/><img src="Picture/middle.gif" width="505" height="20" border="0"/><img src="Picture/end.gif" width="50" height="20" border="0"/></td>
                    </tr>
				    <%ClassMGR.News.News news = student.queryNews(ridNews);%>  	
                    <tr>
                      <td bordercolor="EFFAD1"><span class="detailblue">Date ::</span></td>
                      <td width="566"  colspan="3" bordercolor="EFFAD1" class="detailblack" ><%=news.getdatePost()%></td>
                    </tr>
                    <tr>
                      <td bordercolor="EFFAD1"><span class="detailblue">Topic :: </span></td>
                      <td width="566" colspan="3" bordercolor="EFFAD1" class="detailblack"><%=news.gettopic()%></td>
                    </tr>
                    <tr background="Picture/line_x.gif">
                      <td colspan="4" bordercolor="EFFAD1" background="Picture/line_x.gif"><img src="Picture/line_x.gif"  width="10" height="1" border="0" /></td>
                    </tr>
                    <tr background="Picture/line_x.gif">
                      <td colspan="4" bordercolor="EFFAD1" background="Picture/line_x.gif"><img src="Picture/line_x.gif"  width="10" height="1" border="0" /></td>
                    </tr>
                    <tr>
                      <td bordercolor="EFFAD1"><span class="detailblue">Description :: </span></td>
                      <td colspan="3" width="566" bordercolor="EFFAD1"></td>
                    </tr>
                    <tr>
                      <td   align="right" bordercolor="EFFAD1" class="detailblue">&nbsp;</td>
                      <td width="566"  colspan="3" bordercolor="EFFAD1" class="detailblack"><%=news.getdescritption()%></td>
                    </tr>
                    <tr background="Picture/line_x.gif">
                      <td colspan="4" bordercolor="EFFAD1" background="Picture/line_x.gif"><img src="Picture/line_x.gif" width="10" height="1" border="0" /></td>
                    </tr>
                    <tr background="Picture/line_x.gif">
                      <td colspan="4" bordercolor="EFFAD1" background="Picture/line_x.gif"><img src="Picture/line_x.gif"  width="10" height="1" border="0" /></td>
                    </tr>
                    <tr>
                      <td width="80" align="right" bordercolor="EFFAD1" class="detailblue"> Writer :: </td>
                      <td colspan="3" width="566" bordercolor="EFFAD1" class="detailblack" ><%=student.queryNameUser(news.getidPoster(),news.gettypePoster())%> <%=student.querySurnameUser(news.getidPoster(),news.gettypePoster())%></td>
                    </tr>
                    <tr bordercolor="EFFAD1">
                      <td width="80"  align="right" bordercolor="EFFAD1" ></td>
                      <td colspan="3"><p>&nbsp; </p>
                          <p >&nbsp; </p></td>
                    </tr>
                    <tr bordercolor="EFFAD1"></tr>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                </h4></td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
    </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>