<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridAssignment =	request.getParameter("idAssignment");
		if (ridAssignment == null)  ridAssignment = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t  A s s i g n m e n t ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t  A s s i g n m e n t ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="left">
			<table border="0" cellpadding="0" cellspacing="0" width="575">
				<tr>
						<td><a href="Subject_Student_SyllabusTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavproducts" src="Picture/Tab_Syllabus.gif"  width="82" height="25" border="0"></a></td>
   					    <td><a href="Subject_Student_NewsTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavcustomers" src="Picture/Tab_News.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_TimetableTab.jsp?idSubject=<%=ridSubject%>" ><img name="topnavpartners" src="Picture/Tab_Timetable.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_WebboardTab_Detail.jsp?idSubject=<%=ridSubject%>"><img name="topnavsupport" src="Picture/Tab_Webboard.gif" width="82" height="25" border="0"></a></td>
 						<td><a href="Subject_Student_ChatTab.jsp?idSubject=<%=ridSubject%>"><img name="topnavdeveloper" src="Picture/Tab_Chat.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_AssignmentTab_View.jsp?idSubject=<%=ridSubject%>"><img name="topnavcompany" src="Picture/Tab_Assignment_Selected.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_ExamTab_View.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Examination.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_Student_ScoreTab.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Score.gif" width="82" height="25" border="0"></a></td>
						<td width="*"><img name="topnavdeveloper" src="Picture/Tab_Blank.gif" width="171" height="25" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/spacer.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="98%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	

		<td width="180">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->
            <p>
			  <a href="Home_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
              <a href="Subject_Student_WebboardTab_Detail.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject_Selected.gif"  /></a><br />
  			 </p>
				<%String[] idSubjects = student.queryidSubjectsStudying()	;%> 
				  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
						  <%ClassMGR.Subject.Subject subject = student.querySubject(idSubjects[i]);%>  	
					 <div ><a class="sidelink" href="Subject_Student_AssignmentTab_View.jsp?idSubject=<%=subject.getidSubject()%>" ><%=subject.getnameEng()%></a></div>
				<% }  %>
			  <p>

              <a href="Chat_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="Assignment_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a><br />
              <a href="Examination_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Examiantion" width="170" height="25" src="Picture\Menu_Examination.gif" /></a><br />
              <a href="Score_Student.jsp" ><img border="0" hspace="0" vspace="0" alt="Score" width="170" height="25" src="Picture\Menu_Score.gif" /></a></p> 
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
		    <table width="158" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><div align="left"><span class="detaildarkblue">
				       <%=student.getname()%> : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Student.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="EditProfile_Student.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->



<!--- Begin Body --->
 <td width="1" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
   <td width="802">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
				   <%ClassMGR.Subject.Subject subject = student.querySubject(ridSubject);%>  				     
                  <table width="500" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				  <tr bordercolor="87F59B">
					<td colspan="4" background="Picture/bg.gif" ><img src="Picture/assignment.gif" width="200" height="20" border="0"><img src="Picture/end.gif" width="291" height="20" border="0" /></td>
				  </tr>  
				<tr bordercolor="87F59B" bgcolor="#CAFD97">
             <td colspan="4" class="detailblue"><%=subject.getnameEng()%></td>
           </tr>
		  <%ClassMGR.Assignment.Assignment assignment = student.queryAssignment(ridAssignment);%>  					  
		<tr bordercolor="#87F59B" bgcolor="#B2E57F">
             <td height="20" colspan="4" class="headerblue"><p class="detailblue"><%=assignment.getname()%></p></td>
           </tr>
				<tr bordercolor="#87F59B" class="detaildarkblue">
					 <td width="75" ><div align="center">���ʹѡ�֡��</div></td>
					 <td width="300" ><div align="center">����-���ʡ��</div></td>
			   </tr>
				<%String[] idStudents = student.queryidStdNotSend(ridAssignment)	;%> 
				  <%for(int i = 0 ; i < idStudents.length ; i++) { %>
							<tr bordercolor="#87F59B" class="detaildarkblue">
								 <td width="75" ><div align="center"><%=idStudents[i]%></div></td>
								 <td width="300" ><div align="center"><%=student.queryNameUser(idStudents[i],"Student")%></div></td>
						   </tr>
				<% }  %>

				</table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                </h4></td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
    </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
<% } %>