<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridMsg =	 thaistring.MS874ToUnicode(request.getParameter("idMsg"));
		if (ridMsg != null) {
			ridMsg = ridMsg.replaceAll(" ","");
			ClassMGR.Msg.Msg msg = student.queryMsg(ridMsg);  	
			student.readMessage(msg);
		}
		response.sendRedirect("Message_View.jsp?idMsg="+ridMsg);

%>
<% } %>