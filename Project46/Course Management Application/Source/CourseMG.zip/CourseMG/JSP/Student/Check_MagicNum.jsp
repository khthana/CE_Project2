<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
	response.sendRedirect("../log_in.jsp"); 
	} else {
		String rmagicNum =	 thaistring.MS874ToUnicode(request.getParameter("strMagicNum"));
		rmagicNum = rmagicNum.replaceAll(" ","");
		System.out.println(rmagicNum);
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		ridSubject = ridSubject.replaceAll(" ","");
		System.out.println(ridSubject);
		String ridExam =	 thaistring.MS874ToUnicode(request.getParameter("idExam"));
		ridExam = ridExam.replaceAll(" ","");
		System.out.println(ridExam);
		
		ClassMGR.Exam.Exam exam = student.queryExam(ridExam);
	

		if (exam.getmagicNum().equals(rmagicNum)) {
			String[] idQuestions = student.queryidQuestionsForExam(exam.getidExam());
			if (idQuestions != null) {
				String no = "0";
				String[] answers = new String[idQuestions.length];
				session.setAttribute("idQuestions",idQuestions);
				session.setAttribute("no",no);
				session.setAttribute("answers",answers);

				ClassMGR.Exam.Question question = student.queryQuestion(idQuestions[0]);
				if (question.gettype().equals("Arrange")) {
					response.sendRedirect("Examination_Student_Arrange.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
				}
				else if (question.gettype().equals("Choice")) {
					response.sendRedirect("Examination_Student_Choice.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
				}
				else if (question.gettype().equals("Pair")) {
					response.sendRedirect("Examination_Student_Pair.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
				}
				else {
					response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
				}
			} else {
					response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
			}
		} else {
			response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
		}
//		response.sendRedirect("Examination_Student_Choice.jsp");
//		response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
	}


%>
