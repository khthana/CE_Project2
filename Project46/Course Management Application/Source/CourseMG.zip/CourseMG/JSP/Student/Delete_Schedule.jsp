<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String checkdelete[] = request.getParameterValues("checkdelete");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			student.deleteRemind(checkdelete[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	String rdateDate =	 thaistring.MS874ToUnicode(request.getParameter("dateDate"));
	response.sendRedirect("Schedule_Student.jsp?date="+rdateDate);
%>




<!--- End Footer --->
<% } %>