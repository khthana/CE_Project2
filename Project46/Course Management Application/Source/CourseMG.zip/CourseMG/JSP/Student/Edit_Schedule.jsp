<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridRemind =	 thaistring.MS874ToUnicode(request.getParameter("idRemind"));
		String rdateDate =	 thaistring.MS874ToUnicode(request.getParameter("dateDate"));
		String rdateTime =	 thaistring.MS874ToUnicode(request.getParameter("dateTime"));
		String rstrTopic =	 thaistring.MS874ToUnicode(request.getParameter("strTopic"));
		String rstrDescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));
		String rstrWarningType =	 thaistring.MS874ToUnicode(request.getParameter("strWarningType"));
		String rdateWarningDate =	 thaistring.MS874ToUnicode(request.getParameter("dateWarningDate"));
		System.out.println(rdateDate);
		System.out.println(rdateTime);
		System.out.println(rstrTopic);
		System.out.println(rstrDescription);
		System.out.println(rstrWarningType);
		System.out.println(rdateWarningDate);

		student.editRemind(ridRemind,rstrTopic,rstrDescription,rdateDate,rdateTime,rstrWarningType,rdateWarningDate);
		response.sendRedirect("Schedule_Student.jsp?date="+rdateDate);

%>
<% } %>