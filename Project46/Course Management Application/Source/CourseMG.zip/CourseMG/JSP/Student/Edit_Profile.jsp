<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rname =	 thaistring.MS874ToUnicode(request.getParameter("strName"));
		String rsurname =	 thaistring.MS874ToUnicode(request.getParameter("strSurname"));
		String rnickname =	 thaistring.MS874ToUnicode(request.getParameter("strNickname"));
		String remail =	 thaistring.MS874ToUnicode(request.getParameter("strEmail"));
		String rtel =	 thaistring.MS874ToUnicode(request.getParameter("strTel"));
		String rmobile =	 thaistring.MS874ToUnicode(request.getParameter("strMobile"));
//			student.editSubject("2","Computer","Computer Eng","Seng Na Rak","?????????","1","3","1","noooo","","100","","","","noooo","");
//			student.editProfile("11111111111","asdasd","dfasd","dfsd","dfsd","dfsd","dfsd","","","dfsd","dfsd","dfsd","dfsd","dfsd");			
    student.editProfile(rname,rsurname,rnickname,remail,rtel,rmobile);
	student.setname(rname);
	student.setsurname(rsurname);
	student.setnickname(rnickname);
	student.setemail(remail);
	student.setTel(rtel);
	student.setmobile(rmobile);

		response.sendRedirect("Profile_Student.jsp");
%>
<% } %>