<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String ridTopic =	 thaistring.MS874ToUnicode(request.getParameter("idTopic"));
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));

		student.addReply(rdescription,student.getidStudent(),"Student",ridTopic);
		response.sendRedirect("Subject_Student_WebboardTab_Reply.jsp?idSubject="+ridSubject+"&idTopic="+ridTopic);

%>
<% } %>