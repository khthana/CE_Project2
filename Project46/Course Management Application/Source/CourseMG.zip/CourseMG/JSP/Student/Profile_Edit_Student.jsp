<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: E d i t P r o f i l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: E d i t P r o f i l e ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
    <link href="style1.css" rel="stylesheet" type="text/css" />
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="210">
		
		


<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
<td width="738">
	<table border="0" cellspacing="0" cellpadding="0" width="691">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		
		<tr> 
			    <td width="691">                  
				 <FORM  method='POST' action='Edit_Profile.jsp' name="form1">
		                <table width="86%" border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="14296F" bgcolor="EFFAD1">
                          <tr bgcolor="#FFFFFF" background="Picture/bg.gif">
                            <td colspan="4" class="headerdarkblue"><img name="lmenu_id_r1_c1" src="Picture/t_profile_edit1.gif" width="174" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="391" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/end.gif" width="71" height="20" border="0" /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">���ʹѡ�֡�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="stridStudent" type="text" id="strUsername4" value="<%=student.getidStudent()%>"   size="50" maxlength="100"  disabled /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">���� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strName" type="text" id="strUsername4" value="<%=student.getname()%>"   size="50" maxlength="100"  /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">���ʡ�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strSurname" type="text" id="strUsername4" value="<%=student.getsurname()%>"   size="50" maxlength="100"  /></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">������� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strNickname" type="text" id="strUsername4" value="<%=student.getnickname()%>"   size="50" maxlength="100"  /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">��ѡ�ٵ� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strCourse" type="text" id="strUsername4" value="<%=student.getcourse()%>"   size="50" maxlength="100"  disabled /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strSex" type="text" id="strUsername4" value="<%=student.getsex()%>"   size="50" maxlength="100"  disabled /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">������ :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strEmail" type="text" id="strUsername4" value="<%=student.getemail()%>"   size="50" maxlength="100"   /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�������Ѿ�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strTel" type="text" id="strUsername4" value="<%=student.getTel()%>"   size="50" maxlength="100"   /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�������Ѿ����Ͷ�� :: </td>
                             <td width="325" bordercolor="EFFAD1" ><input name="strMobile" type="text" id="strUsername4" value="<%=student.getmobile()%>"   size="50" maxlength="100"   /></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" ></td>
                            <td colspan="2"><p class="style11">
								<input name="OK" type="submit" id="OK" value="Edit" />                                
								<input name="Reset" type="reset" value="Reset" />
								<input name="Cancel" type="button" value="Cancel" onclick="window.location='Profile_Student.jsp'" />
								</p>
                           </td>
                          </tr>
						  <tr bordercolor="EFFAD1"></tr>
                      </table>
                    </form>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
				
		
	</table>
	
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
		  </table>
				
	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


<% } %>