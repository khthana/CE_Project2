<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: M e s s a g e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: M e s s a g e ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/message2.gif" width="65" height="20" border="0"><img src="Picture/middle.gif" width="531" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
<!--- End Left Nav Bar --->




<!--- Begin Body --->
          <td width="842">  

			<table width="510" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="#EFFAD1">
			 <form name="form1" id="form1" method="post" action="">
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td><p class="detailblue">��èѺ�����</p> </td>
                    </tr>
              <tr bordercolor="87F59B">
                <td width="510" bordercolor="#87F59B" background="Picture/bg.gif"><img src="Picture/join_group_list.gif" width="200" height="20" border="0" /><img src="Picture/middle.gif" width="172" height="20" border="0" /><img src="Picture/end.gif" width="129" height="20" border="0" /></td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input name="radiobutton" type="radio" value="radiobutton" />                  
                  &nbsp;&nbsp;&nbsp;��ª��͡����
                  </td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input name="radiobutton" type="radio" value="radiobutton" />                  
                  &nbsp;&nbsp;&nbsp;��ª��͡����
                  </td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input name="radiobutton" type="radio" value="radiobutton" />                  
                  &nbsp;&nbsp;&nbsp;��ª��͡����
                  </td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input name="radiobutton" type="radio" value="radiobutton" />                  
                  &nbsp;&nbsp;&nbsp;��ª��͡����
                  </td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input name="radiobutton" type="radio" value="radiobutton" />                  
                  &nbsp;&nbsp;&nbsp;��ª��͡����
                  </td>
              </tr>
              <tr>
                <td  bordercolor="#EFFAD1" class="detaildarkblue">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="Submit" type="submit" id="Submit" value="Select"/></td>
              </tr>
			  </form>
            </table>
					
			
			</td>
                <!---</td> End: This is a dynamic td tag, it is added only if right nav exists. see code above--->
              </tr>
              <tr> 
                <td colspan="2"> <h4> 
                    <p align="center">&nbsp;</p>
                  </h4>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
              </tr>
      </table></td>	

<!--- End Body --->



<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>