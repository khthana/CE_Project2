<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( (student == null)  ||  (!student.getRole().equals("Student"))  )  { 
	response.sendRedirect("../log_in.jsp"); 
	} else {
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		if (ridSubject == null)  ridSubject = "";
		ridSubject = ridSubject.replaceAll(" ","");
		System.out.println("idSubject " + ridSubject);
		String ridExam =	 thaistring.MS874ToUnicode(request.getParameter("idExam"));
		if (ridExam == null)  ridExam = "";
		ridExam = ridExam.replaceAll(" ","");
		System.out.println(ridExam);

		String[] idQuestions = (String[])session.getAttribute("idQuestions"); 
		String no = (String)session.getAttribute("no"); 
		String[] answers = (String[])session.getAttribute("answers"); 
  		
		for ( int i = 0 ; i < idQuestions.length ; i++ ) { 
			System.out.println("question :: " +i+" :: "+idQuestions[i]);
		}
		for ( int i = 0 ; i < answers.length ; i++ ) { 
			if (answers[i]==null) answers[i]="0";
			System.out.println("ans :: " +i+" :: "+answers[i]);
		}

		System.out.println("no :: " +no);

		if ((idQuestions != null) && (no != null) && (answers != null) &&  (!ridSubject.equals("")) &&  (!ridExam.equals(""))  ){ 
							// cal score for this exam
							student.doExam(ridExam,answers,idQuestions);
							session.removeAttribute("idQuestions");
							session.removeAttribute("no");
							session.removeAttribute("answers");
							response.sendRedirect("Examination_Finnish.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
		} else {
					session.removeAttribute("idQuestions");
					session.removeAttribute("no");
					session.removeAttribute("answers");
				System.out.println("aaaaaaaaa");
				response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
		}
//				response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);

	}


%>
