<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: P r o f i l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: P r o f i l e ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">
	
		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/profile.gif" width="57" height="20" border="0"><img src="Picture/middle.gif" width="518" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->

<td width="783">
	<table border="0" cellspacing="0" cellpadding="0" width="500">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->




		<tr> 
			    <td>                  
					  <table border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="#14296F" bgcolor="#EFFAD1" >
					  <form action="" method="Post">
                          <tr bordercolor="#87F59B"> 
                            <td colspan="2" ><img src="Picture/profile1.gif" width="57" height="20" border="0" /><img src="Picture/middle.gif" width="390" height="20" border="0"><a href="Profile_Edit_Student.jsp"><img src="Picture/b_edit.gif" width="43" height="20" border="0"></a></td>
                        </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="150"  align="right" bordercolor="#87F59B" class="detailblue">���ʹѡ�֡�� ::</td>
                            <td width="350" class="detailblack"><%=student.getidStudent()%>&nbsp; </td>
                          </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">���� :: </td>
                            <td width="244" class="detailblack"><%=student.getname()%>&nbsp;</td>
                          </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">���ʡ�� :: </td>
                            <td width="244" class="detailblack"><%=student.getsurname()%>&nbsp;</td>
                          </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">������� :: </td>
                            <td width="244" class="detailblack"><%=student.getnickname()%>&nbsp;</td>
                           </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">��ѡ�ٵ� :: </td>
                            <td width="244" class="detailblack"><%=student.getcourse()%>&nbsp;</td>
                           </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">�� :: </td>
                            <td width="244" class="detailblack"><%=student.getsex()%>&nbsp;</td>
                           </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">������ :: </td>
                            <td width="244" class="detailblack"><%=student.getemail()%>&nbsp; </td>
                           </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">�������Ѿ�� :: </td>
                            <td width="244" class="detailblack"><%=student.getTel()%>&nbsp; </td>
                           </tr>
                           <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="153"  align="right" bordercolor="#87F59B" class="detailblue">�������Ѿ����Ͷ�� :: </td>
                            <td width="244" bordercolor="87F59B" bgcolor="#EFFAD1" class="detailblack"><%=student.getmobile()%>&nbsp;</td>
                           </tr>
                          <tr bordercolor="87F59B">
			<td colspan = "2" align="center" >
				<img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="200" height="20" border="0" /><a href="Home_Student.jsp"><img name="lmenu_id_r1_c1" src="Picture/home.gif" width="90" height="20" border="0" /></a><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="200" height="20" border="0" />
			</td>
		</tr>
	   <tr bordercolor="87F59B">
			<td colspan = "2" align="center" >
				<img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="180" height="20" border="0" /><a href="PasswordChange.jsp"><img name="lmenu_id_r1_c1" src="Picture/ChangePass.gif" width="126" height="20" border="0" /></a><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="180" height="20" border="0" />
			</td>
		</tr>
                        <tr bordercolor="#EFFAD1" bgcolor="#EFFAD1"> 
                            <td width="153" >&nbsp;</td>
                          <td width="244" >&nbsp;                          </td>
                        </tr>
						</form>
				  </table>
					
					
             </td>
		</tr>
	</table>
</td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
<% } %>