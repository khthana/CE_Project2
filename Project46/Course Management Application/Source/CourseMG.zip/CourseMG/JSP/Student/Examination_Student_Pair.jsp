<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridExam =	request.getParameter("idExam");
		if (ridExam == null)  ridExam = "";
		String[] idQuestions = (String[])session.getAttribute("idQuestions"); 
		String no = (String)session.getAttribute("no"); 
		String[] answers = (String[])session.getAttribute("answers"); 

		if ((idQuestions != null) && (no != null) && (answers != null) &&  (!ridSubject.equals("")) &&  (!ridExam.equals("")) ) { 
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: E x a m i n a t i o n ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: E x a m i n a t i o n ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/exam.gif" width="94" height="20" border="0"><img src="Picture/middle.gif" width="493" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1040">
				<tr valign=top>	

		<td width="180">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->         
			  <br />
					<img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="175" height="10" border="0" /> <br /><br />
						  <%ClassMGR.Subject.Subject subject = student.querySubject(ridSubject);%>  	
		<table width="177" cellspacing="0" cellpadding="0">
			  <tr >
			  		<td width="175" height="31"><div align="left" class="detailblue">
				        ����ͺ�Ԫ� : <br/> <%=subject.getnameEng()%> </div></td>
			  </tr>
					 <%ClassMGR.Exam.Exam exam = student.queryExam(ridExam);%>  	
			  <tr>
			  		<td width="175" height="31"><div align="left" class="detailhead">
				        ������ : <%=exam.gettype()%> 
				</div></td>
			  </tr>
			  <tr>
			  		<td width="175" height="31"><div align="left" class="detailhead">
				        �ѹ����ͺ : <%=exam.getexamDate()%>
				</div></td>
			  </tr>
			  <tr>
			  		<td width="175" height="31"><div align="left" class="detailhead">
				        ����������ͺ : <%=helper.padZeroForTime(exam.getstartTime())%> 
				</div></td>
			  </tr>
			  <tr>
			  		<td width="175" height="31"><div align="left" class="detailhead">
				        ��������ش����ͺ : <%=helper.padZeroForTime(exam.getstopTime())%>
				</div></td>
			  </tr>
			</table><br />
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="175" height="10" border="0"> 
              <br /><img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="175" height="10" border="0" />
<table width="158" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><div align="left"><span class="headerdarkblue">
				        <%=student.getname()%>: Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="Profile_Student.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="EditProfile_Student.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>

			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->




<!--- Begin Body --->
<td width="10" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>
		<%String[] idExams = student.queryidExams(ridSubject)	;%> 
          <td width="700"> <table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="#EFFAD1">
            <tr bordercolor="87F59B">
              <td  bordercolor="#87F59B" background="Picture/bg.gif" 4 ><img src="Picture/examination.gif" width="94" height="20" border="0" /><img src="Picture/middle.gif" width="298" height="20" border="0" /><img src="Picture/end.gif" width="258" height="20" border="0" /></td>
            </tr>
               <tr bordercolor="#B2E57F" bgcolor="#B2E57F">
                    <td  bordercolor="#EFFAD1" bgcolor="#EFFAD1" class="detaildarkblue" ><%=subject.getnameEng()%></td>
              </tr>
			  <% String[] idParts = student.queryidParts(exam.getidExSet()); %>
			  <% String idPart = student.queryidPart(ridExam,idQuestions[Integer.parseInt(no)]); %>
			  <% int partno = 0; %>
				<%for(int i = 0 ; i < idParts.length ; i++) { %>
					<% if (idPart.equals(idParts[i])) partno = i; %>
				<% } %>
               <tr bordercolor="#B2E57F" bgcolor="#B2E57F">
                    <td  bordercolor="#EFFAD1" bgcolor="#EFFAD1" class="detaillightblue" >�͹��� <%=partno+1%></td>
              </tr>

            <tr bordercolor="#33CC00"bgcolor="#EFFAD1">
              <td>
                <form name="form1" id="form1" method="post" action="Next_Question_Pair.jsp">
                  <table width="650" border="0">
                    <tr>
                      <td  colspan="2" class="detailhead">���Ѻ����ͷ��١��ͧ����ش</td>
                    </tr>
			  <% int lenght = 0; %>
				<% // make array of question of Pair type %>
				<% String[] idQuestionsForThisPart = student.queryidQuestions(idPart); %>
				<%for(int j = 0 ; j < idQuestionsForThisPart.length ; j++) { %>
					<% String[] idAnswersForThisQuestion = student.queryidAnswers(idQuestionsForThisPart[j]); %>
					<%for(int k = 0 ; k < idAnswersForThisQuestion.length ; k++) { %>
						<% lenght++; %>
					<% } %>
				<% } %>

			  <% String[] idAnswersForThisPart = new String [lenght]; %>
			  <% int index = 0; %>
				<% // make array of question of Pair type %>
				<%for(int j = 0 ; j < idQuestionsForThisPart.length ; j++) { %>
					<% String[] idAnswersForThisQuestion = student.queryidAnswers(idQuestionsForThisPart[j]); %>
					<%for(int k = 0 ; k < idAnswersForThisQuestion.length ; k++) { %>
						<% idAnswersForThisPart[index] = idAnswersForThisQuestion[k]; %>
						<% index++; %>
					<% } %>
				<% } %>
				<% System.out.println(idQuestionsForThisPart.length); %>
				<% System.out.println(idAnswersForThisPart.length); %>
				<% idAnswersForThisPart = helper.swapChoice(idAnswersForThisPart); %>
				<%for(int i = 0 ; i < idAnswersForThisPart.length ; i++) { %>
                    <tr>
					<% if (i < idQuestionsForThisPart.length) { %>				 
						<%ClassMGR.Exam.Question question = student.queryQuestion(idQuestionsForThisPart[i]);%>  	
						<td width="328" class="detailblue" height="20"><input name="answer" type="text" size="2" maxlength="2" />&nbsp;<%=i+1%>. &nbsp;<%=question.getdescription()%> </td>
					<% } else { %>
						<td width="328" class="detailblue" height="25">&nbsp; </td>
					<% } %>
					<% if (i < idAnswersForThisPart.length) { %>				 
						<%ClassMGR.Exam.Answer answer = student.queryAnswer(idAnswersForThisPart[i]);%>  	
                        <td width="312" class="detailblue"><%=i+1%>. &nbsp;<%=answer.getDescription()%> </td>
					<% } else { %>
						 <td width="328" class="detailblue">&nbsp; </td>
					<% } %>
                    </tr>
				<% } %>
						     <tr>
							 <td colspan="2">
						<% for ( int i = 0 ; i < idAnswersForThisPart.length ; i++ ) {  %>
								<input name="idAnswers" type="hidden" id="Submit" value="<%=idAnswersForThisPart[i]%>"  />
						<% } %> 
							 <input name="idExam" type="hidden" id="Submit" value="<%=ridExam%>"  />
							 <input name="idSubject" type="hidden" id="Submit" value="<%=ridSubject%>"  />
							 <input name="Next" type="Submit" id="Submit" value="Next" <%if ((Integer.parseInt(no)+idQuestionsForThisPart.length) >= (idQuestions.length-1) ) { %> disabled<% } %>/>&nbsp;<span class="detailblue"> ��ѧ��ͶѴ� </span>
						 </form>

                     <form name="form2"  method="post" action="Back_Question.jsp">
						<% for ( int i = 0 ; i < idAnswersForThisPart.length ; i++ ) {  %>
								<input name="idAnswers" type="hidden" id="Submit" value="<%=idAnswersForThisPart[i]%>"  />
						<% } %> 
							 <input name="idExam" type="hidden" id="Submit" value="<%=ridExam%>"  />
							 <input name="idSubject" type="hidden" id="Submit" value="<%=ridSubject%>"  />
						<input name="Back" type="button" id="Back" value="Back" onclick="sendBackForm()" <%if (Integer.parseInt(no) == 0 ) { %> disabled<% } %>/><span class="detailblue"> ��ѧ��ͷ���ҹ�� </span>
                     </form>
<%//						<input name="Next" type="button" id="Submit" value="Next" onClick="checknull('Add')"/> %>
						<div align="right">
                     <form name="form3"  method="post" action="Send_Exam.jsp">
						 <input name="idExam" type="hidden" id="Submit" value="<%=ridExam%>"  />
						 <input name="idSubject" type="hidden" id="Submit" value="<%=ridSubject%>"  />
						 <span class="detailblue"> �觢���ͺ </span> &nbsp; &nbsp;  <input name="Send" type="submit" id="Send"  value="Send" />
                     </form>
						</div>
						  </td>
                        </tr>
                    </table>
					</td>
                  </tr>
				  
    
          
              </table></td>
            </tr>
          </table></td>
                <!---</td> End: This is a dynamic td tag, it is added only if right nav exists. see code above--->
              </tr>
              <tr> 
                <td colspan="2"> <h4> 
                    <p align="center">&nbsp;</p>
                  </h4>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
              </tr>
      </table></td>	

<!--- End Body --->



<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>


<!--Begin Add Java Script -->
<SCRIPT LANGUAGE="JavaScript">
<!--
	var doc = document.form1
	function sendBackForm(){
			document.form2.action = "Back_Question.jsp?answer="+document.form1.answer.value;
		document.form2.submit();
	}//sendBackForm
	function checknull(n){
		if	(!isNaN(doc.answer.value))
					{doc.submit();} 
		else
		{
			alert("��سҡ�͡�ӵͺ����繵���Ţ");
		}	
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script-->

<!--- End Footer --->

<%
		} else {
				response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
		}
%>
<% } %>