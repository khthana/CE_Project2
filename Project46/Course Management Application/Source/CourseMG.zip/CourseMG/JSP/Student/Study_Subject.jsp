<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String ridSubjects[] = request.getParameterValues("idSubjects");
	String magicNumbers[] = request.getParameterValues("magicNumber");
	String	idSubjects[] = student.queryidSubjectsNotStudy();
    int j = 0;
	if((ridSubjects!= null) && (idSubjects != null)) {
		for (int i = 0;i<idSubjects.length;i++){
			magicNumbers[j] = magicNumbers[j].replaceAll(" ","");
					System.out.println(magicNumbers[j]);
			if (!magicNumbers[j].equals("")) {
				ridSubjects[i] = ridSubjects[i].replaceAll(" ","");
//				if (idSubjects[i].equals(ridSubjects[j])) { 
					System.out.println("aaaaaaaaa");
					student.registerSubject(ridSubjects[i],"0",magicNumbers[i]);
					j++;
//				}
			}
//			System.out.println(idSubjects[i] + ridSubjects[j] + magicNumbers[i]);
		}//for
	}
	response.sendRedirect("Subject_Student_Menu.jsp");
%>




<!--- End Footer --->
<% } %>