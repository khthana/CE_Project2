<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( (student == null)  ||  (!student.getRole().equals("Student"))  )  { 
	response.sendRedirect("../log_in.jsp"); 
	} else {
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		if (ridSubject == null)  ridSubject = "";
		ridSubject = ridSubject.replaceAll(" ","");
		System.out.println("idSubject " + ridSubject);
		String ridExam =	 thaistring.MS874ToUnicode(request.getParameter("idExam"));
		if (ridExam == null)  ridExam = "";
		ridExam = ridExam.replaceAll(" ","");
		System.out.println(ridExam);
		String ranswer =	 thaistring.MS874ToUnicode(request.getParameter("answer"));
		if (ranswer == null)  ranswer = "";
		ranswer = ranswer.replaceAll(" ","");
		System.out.println(ranswer);
		String idAnswers[] = request.getParameterValues("idAnswers");
		
		System.out.println("Answer");
		for ( int i = 0 ; i < idAnswers.length ; i++ ) { 
			idAnswers[i] = thaistring.MS874ToUnicode(idAnswers[i]);   
			System.out.println(idAnswers[i]);
		}

		String[] idQuestions = (String[])session.getAttribute("idQuestions"); 
		String no = (String)session.getAttribute("no"); 
		String[] answers = (String[])session.getAttribute("answers"); 

		if ((idQuestions != null) && (no != null) && (answers != null) &&  (!ridSubject.equals("")) &&  (!ridExam.equals("")) ){ 

			if ((!idQuestions.equals("")) && (Integer.parseInt(no) < idQuestions.length )){
				System.out.println("aaaaaaaaa");
				ClassMGR.Exam.Question question = student.queryQuestion(idQuestions[Integer.parseInt(no)]);
//				String[] idAnswers = student.queryidAnswers(question.getidQuestion()); 
				
				boolean correctFormAnswer = true;
				for ( int i = 0 ; i < ranswer.length() ; i++ ) { 
					if (((ranswer.equals("")) && (Integer.parseInt(ranswer.substring(i,i+1))-1) > idAnswers.length ) ) {
						correctFormAnswer = false;
					}
				}

				if (correctFormAnswer) {
/*							//check format ranswer must suffix with ' ;'
							char suffix = ranswer.charAt(ranswer.length()-1);
							if (suffix != ';') {
								ranswer = ranswer + ";";
							}
	*/					answers[Integer.parseInt(no)] = "";
						for ( int i = 0 ; i < ranswer.length() ; i++ ) { 
							answers[Integer.parseInt(no)] = answers[Integer.parseInt(no)] + idAnswers[Integer.parseInt(ranswer.substring(i,i+1))-1] + ";";
						}
						System.out.println("fffffffffffffffffffffff");
						System.out.println(answers[Integer.parseInt(no)]);
						int tmp = (Integer.parseInt(no)+1);
						no = String.valueOf(tmp);
						System.out.println("bbbbbbbbbb");

						if  (Integer.parseInt(no) < idQuestions.length ) {

			//				session.setAttribute("idQuestions",idQuestions);
							session.setAttribute("no",no);
							session.setAttribute("answers",answers);

							ClassMGR.Exam.Question question1 = student.queryQuestion(idQuestions[Integer.parseInt(no)]);
	//						ClassMGR.Exam.Question question = student.queryQuestion(idQuestions[Integer.parseInt(no)]);
						System.out.println(question1.gettype());
						if (question1.gettype().equals("Arrange")) {
								response.sendRedirect("Examination_Student_Arrange.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else if (question1.gettype().equals("Choice")) {
								response.sendRedirect("Examination_Student_Choice.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else if (question1.gettype().equals("Pair")) {
								response.sendRedirect("Examination_Student_Pair.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else {
								session.removeAttribute("idQuestions");
								session.removeAttribute("no");
								session.removeAttribute("answers");
								response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
						} else {
							// cal score for this exam
							System.out.println("ddddddddddddd");
							for ( int i = 0 ; i < idQuestions.length ; i++ ) { 
								System.out.println(idQuestions[i]);
							}
							System.out.println("eeeeeeeeeeeee");
							for ( int i = 0 ; i < answers.length ; i++ ) { 
								System.out.println(answers[i]);
							}
							// cal score for this exam
							student.doExam(ridExam,answers,idQuestions);
							session.removeAttribute("idQuestions");
							session.removeAttribute("no");
							session.removeAttribute("answers");
							response.sendRedirect("Examination_Finnish.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
						}
				} else {
						if (question.gettype().equals("Arrange")) {
								response.sendRedirect("Examination_Student_Arrange.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else if (question.gettype().equals("Choice")) {
								response.sendRedirect("Examination_Student_Choice.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else if (question.gettype().equals("Pair")) {
								response.sendRedirect("Examination_Student_Pair.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
							else {
								session.removeAttribute("idQuestions");
								session.removeAttribute("no");
								session.removeAttribute("answers");
								response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
							}
				}
			} else {
					session.removeAttribute("idQuestions");
					session.removeAttribute("no");
					session.removeAttribute("answers");
					response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
			}
		} else {
				response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
		}
//		response.sendRedirect("Examination_Student_Choice.jsp");
//		response.sendRedirect("Examination_Login.jsp?idSubject="+ridSubject+"&idExam="+ridExam);
	}


%>
