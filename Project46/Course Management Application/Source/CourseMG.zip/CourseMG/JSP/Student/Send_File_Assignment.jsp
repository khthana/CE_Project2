<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )   { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();
	
	String filename = mySmartUpload.getFiles().getFile(0).getFileName();

	String idSubject = new String();
	String idAssignment = new String();


	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters 	
	while (e.hasMoreElements()) {  		
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("idSubject")){
			idSubject = thaistring.MS874ToUnicode(values[0]);
		}//idSubject
		if(key.equals("idAssignment")){
			idAssignment = thaistring.MS874ToUnicode(values[0]);
		}//idAssignment
	}//while

	String upfilename = "S" + idSubject + "A" + idAssignment + "ID" + student.getidStudent() + helper.getTypeFile(filename);
	if(!(filename.equals(""))){
		mySmartUpload.getFiles().getFile(0).saveAs("/Upload/Assignment/"+upfilename.toLowerCase());




	   String idGroup = student.queryidGroupOfStd(idAssignment);
		student.sendFile(idGroup,upfilename.toLowerCase());
	}//if
	
response.sendRedirect("Subject_Student_AssignmentTab_Detail.jsp?idSubject="+idSubject+"&idAssignment="+idAssignment);
%>

<% } %>