<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="student" class="ClassMGR.User.Student" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	student=(Student)session.getAttribute("auth"); %>
<%	if( student == null  ||  !student.getRole().equals("Student")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String ridAssignment =	 thaistring.MS874ToUnicode(request.getParameter("idAssignment"));
		String rnameGroup =	 thaistring.MS874ToUnicode(request.getParameter("nameGroup"));
		if (rnameGroup != null) {
			ridSubject = ridSubject.replaceAll(" ","");
			ridAssignment = ridAssignment.replaceAll(" ","");
			student.addGroup(rnameGroup,ridAssignment);
		}
		response.sendRedirect("Subject_Student_AssignmentTab_Detail.jsp?idSubject="+ridSubject+"&idAssignment="+ridAssignment);

%>
<% } %>