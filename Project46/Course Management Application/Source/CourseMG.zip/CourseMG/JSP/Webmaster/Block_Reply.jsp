<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridReply =	 thaistring.MS874ToUnicode(request.getParameter("idReply"));
		ridReply = ridReply.replaceAll(" ","");
		String ridTopic =	 thaistring.MS874ToUnicode(request.getParameter("idTopic"));
		ridTopic = ridTopic.replaceAll(" ","");
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		ridSubject = ridSubject.replaceAll(" ","");
		
        if((ridReply!=null) && (ridTopic!=null) && (ridSubject !=null)) {
			webmaster.blockReply(ridReply);
			response.sendRedirect("Webboard_Webmaster_Reply.jsp?idSubject="+ridSubject+"&idTopic="+ridTopic);
		} 

%>
<% } %>