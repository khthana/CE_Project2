<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridTopic=	request.getParameter("idTopic");
		if (ridTopic == null)  ridTopic = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: W e b b o a r d ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: W e b b o a r d ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/webboard5.gif" width="78" height="20" border="0"><img src="Picture/middle.gif" width="520" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->

		


<!--- End Left Nav Bar --->




<!--- Begin Body --->

<td width="842">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
                  <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="702" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				  <tr bordercolor="87F59B">
					<td colspan="6" background="Picture/bg.gif" ><img src="Picture/webboard1.gif" width="120" height="20" border="0"><img src="Picture/middle.gif" width="500" height="20" border="0"><img src="Picture/end.gif" width="68" height="20" border="0"></td>
				  </tr>
                   </tr>
				   <%ClassMGR.Subject.Subject subject = webmaster.querySubject(ridSubject);%>  	
				  <tr bordercolor="87F59B" bgcolor="#CAFD97">
				  <td colspan="6" class="detailblue"   ><%=subject.getnameEng()%></td>
				  </tr>
				<%ClassMGR.Webboard.Topic topic = webmaster.queryTopic(ridTopic);%>  	
                   <tr bordercolor="#87F59B" bgcolor="#99CCFF">
                     <td width="50" class="detailblue">Poster</td>
                     <td width="639" class="detailblue"><%=topic.getname()%></td>
                   </tr>
                   <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                     <td width="50" class="detaildarkblue"><%=webmaster.queryNameUser(topic.getidPoster(),topic.gettypePoster())%></td>
                     <td width="639" class="detaildarkblue">Post Date : <%=topic.getcreateDate()%>
                         <hr/>
                         <%=topic.getdescription()%></td>
                   </tr>
                   <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                     <td width="50" class="detaildarkblue" colspan="2">&nbsp;</td>
                   </tr>
				<%String[] idReplys = webmaster.queryidReplys(topic.getidTopic());%> 
					  <%for(int i = 0 ; i < idReplys.length ; i++) { %>
					  <%ClassMGR.Webboard.Reply reply = webmaster.queryReply(idReplys[i]);%>  	
						  <% if (reply.getisVisible().booleanValue()) { %>
							   <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
						  <% } else { %>
							   <tr bordercolor="#87F59B" bgcolor="#E4E4E4">
						  <% } %>
						 <td width="50" class="detaildarkblue">
						  <%=webmaster.queryNameUser(reply.getidPoster(),reply.gettypePoster())%>
						  <% if (reply.getisVisible().booleanValue()) { %>
								  <form name="form1" id="form1" method="post" action="Block_Reply.jsp">
									 <input type="hidden" name="idSubject" value="<%=ridSubject%>" />
									 <input type="hidden" name="idTopic" value="<%=topic.getidTopic()%>" />
									 <input type="hidden" name="idReply" value="<%=reply.getidReply()%>" />
									 <input type="submit" name="Submit" value="Block" />
								  </form>
								  <% } else { %>
 								  <form name="form1" id="form1" method="post" action="Unblock_Reply.jsp">
									 <input type="hidden" name="idSubject" value="<%=ridSubject%>" />
									 <input type="hidden" name="idTopic" value="<%=topic.getidTopic()%>" />
									 <input type="hidden" name="idReply" value="<%=reply.getidReply()%>" />
                                   <input type="submit" name="Submit" value="Unblock" />
								  </form>
								  <% } %>
						  <%System.out.println("cccccccccccccc");%>
						</td>
						 <td width="639" class="detaildarkblue">Post Date : <%=reply.getcreateDate()%>
							 <hr/>
							 <%=reply.getdescription()%></td>
					   </tr>
					<% } %>
</table>

					    </td>
                      </tr>
                    </tbody>
                  </table>
                  <form action="Add_Reply.jsp" method="post">
                    <table border="0" align="center" cellpadding="0" cellspacing="3" width="100%">
                      <tr>
                        <td width="40">&nbsp;</td>
                        <td width="105" class="style7">&nbsp;</td>
                        <td width="431">&nbsp;</td>
                        <td width="143">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="40">&nbsp;</td>
                        <td width="105" class="detaildarkblue">Description : </td>
                        <td width="431"><textarea name="strDescription" cols="50" rows="10" id="strDescription"></textarea></td>
                        <td width="143">&nbsp;</td>
                      </tr>
             <tr>
               <td ><input name="idSubject" type="hidden"  size="30" maxlength="30"   value="<%=ridSubject%>" /></td>
               <td ><input name="idTopic" type="hidden"  size="30" maxlength="30"   value="<%=ridTopic%>" /></td>
             <tr>
               <td width="40">&nbsp;</td>
               <td width="105" >&nbsp;</td>
               <td><input name="Submit" type="submit" value="Post" />
                   <input name="Reset" type="reset" value="Reset" /> 
				   <input name="Back" type="button" value="Back" onclick="window.location='Webboard_Webmaster.jsp'" /></td>
             </tr>
                    </table>
                  </form>                  <p>&nbsp;</p>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	

<!--- End Body --->



<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>