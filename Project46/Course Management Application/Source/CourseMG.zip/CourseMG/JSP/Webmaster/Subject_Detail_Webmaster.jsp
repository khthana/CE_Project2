<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t S y l l a b u s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t S y l l a b u s ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
 .



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0" /></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>



<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="460" height="20" border="0"><img src="Picture/subject.gif" width="80" height="20" border="0"><img src="Picture/middle.gif" width="480" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><br / >
			<table border="0" cellpadding="0" cellspacing="0">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* --><p>			  
			<a href="Home_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Webmaster_Detail.jsp?date=<%=webmaster.getnewday()%>"  ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
			  <a href="Subject_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject_Selected.gif"  /></a><br />
              <a href="Webboard_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="User_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture/Menu_User.gif" /></a></p>
              
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0" />              <table width="167" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><div align="left"><span class="headerdarkblue">
				        <%=webmaster.getname()%>: Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="Profile_Webmaster.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="Profile_Edit_Webmaster.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
		  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>


<!--- End Left Nav Bar --->



<!--- Begin Body --->
 <td width="1" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
   <td width="802">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 										
				   <%ClassMGR.Subject.Subject subject = webmaster.querySubject(ridSubject);
					%>  	
                  <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="#EFFAD1">
				  <tr bordercolor="87F59B">
					<td width="650" bordercolor="#EFFAD1" background="Picture/bg.gif" ><img src="Picture/detail_syllabus.gif" width="200" height="20" border="0"><img src="Picture/middle.gif" width="397" height="20" border="0"><a href="Subject_Edit_Webmaster.jsp?idSubject=<%=subject.getidSubject()%>"><img src="Picture/b_edit.gif" width="43" height="20" border="0" /></a></td>
				  </tr>
				  <tr bordercolor="87F59B" bgcolor="#CAFD97">
				  <td  class="detaildarkblue"   ><%=subject.getnameEng()%></td>
				</tr>
				   <tr>
                            <td bordercolor="#EFFAD1" bgcolor="#B2E57F" class="detaildarkblue">��������´�ͧ�Ԫ�</td>
                  </tr>
				   <tr>
                            <td bordercolor="#EFFAD1"><blockquote>
									<span class="detailblue">��ѡ�ٵ�:<%=subject.getcurriculum()%>  <br />
                                    �����Ԫ� :<%=subject.getidSubject()%> <br />
                                    �����Ԫ������� :<%=subject.getname()%> <br />
                                    �����Ԫ������ѧ��� :<%=subject.getnameEng()%> <br />
                                    ˹��¡Ե (������-��Ժѵԡ��) : <%=subject.getcredit()%> <br />
									<%ClassMGR.Subject.Subject subject1 = webmaster.querySubject(subject.getrequireSubject());%>  	
                                   �ԪҺѧ�Ѻ��͹ :<%=subject1.getname()%>  <%=subject1.getnameEng()%></span>
							  </blockquote></td>
                          </tr>
				  <tr>
                            <td bordercolor="#EFFAD1" bgcolor="#B2E57F" class="detaildarkblue">����������Ԫ�</td>
                         
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"><blockquote>
                                <p class="detailblue"><%=subject.getdescritption()%></p>
                            </blockquote></td>
                          </tr>
				   <tr>
                            <td bordercolor="#EFFAD1"  bgcolor="#B2E57F" class="detaildarkblue">�������¹</td>
                          </tr>
                          <tr>
                            <td colspan="2" bordercolor="#EFFAD1"><blockquote>
                                <p>	<span class="detailblue"><%=subject.gettimeStudy()%><span ><br />
                				</span> </p>
                            </blockquote></td>
                            
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"  bgcolor="#B2E57F" class="detaildarkblue">��û����Թ��㹡�����¹</td>
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"><blockquote>
                                <table width="310" border="1" bordercolor="#87F59B">
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113"  align="center" ><div align="left"><span >��û����Թ��</span></div></td>
                                    <td width="287" align="center"><span >�ӹǹ����ૹ��</span></td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113" align="left" >1. Examination</td>
                                    <td width="287" align="center" >&nbsp;</td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113"  > &nbsp;&nbsp;&nbsp;&nbsp; Mid Term</td>
                                    <td width="287" align="center" ><%=subject.getscaleMidterm()%> %</td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113" >&nbsp;&nbsp;&nbsp;&nbsp; Final </td>
                                    <td width="287" align="center" ><%=subject.getscaleFinal()%> % </td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113" >2. Quiz</td>
                                    <td width="287" align="center" ><%=subject.getscaleQuiz()%> %</td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113"  >3. Assignment</td>
                                    <td width="287" align="center" > <%=subject.getscaleAssignment()%> % </td>
                                  </tr>
                                  <tr bordercolor="87F59B" class="detailblue">
                                    <td width="113" >4. Lab</td>
                                    <td width="287" align="center" ><%=subject.getscaleLab()%> % </td>
                                  </tr>
                                </table>
                            </blockquote></td>
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"  bgcolor="#B2E57F" class="detaildarkblue">������Ҿ����ͧʹ���</td>
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"><blockquote>
                                <p class="detailblue"><%=subject.gettimeTalking	()%> </p>
                            </blockquote>                            </td>
                          </tr>
                          
                          <tr>
                            <td bordercolor="#EFFAD1"  bgcolor="#B2E57F" class="detaildarkblue">�͡�����ҹ��Сͺ</td>
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"><blockquote class="detailblue"><%=subject.gettextBook()%></blockquote></td>
                          </tr>
                          
                          <tr>
                            <td bordercolor="#EFFAD1" bgcolor="#B2E57F" class="detaildarkblue">�Ҩ�������͹</td>
                          </tr>
                          <tr>
                            <td bordercolor="#EFFAD1"><blockquote>
								<% String[] idTeachers = subject.getidTeachers(); %>
								<% for (int i = 0 ; i < idTeachers.length ; i ++ ) { %>
									<a href="Profile_Teacher1.jsp?idTeacher=<%=idTeachers[i]%>" class="detailblue" target="_blank"> <%=webmaster.queryNameUser(idTeachers[i],"Teacher")%></a> &nbsp;
							   <% } %>
							  </blockquote></td>
                          </tr>
</table>

					    </td>
                      </tr>
                    </tbody>
                  </table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
<% } %>