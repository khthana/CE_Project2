<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rdateDate =	 thaistring.MS874ToUnicode(request.getParameter("dateDate"));
		String rdateDate2 =	 thaistring.MS874ToUnicode(request.getParameter("dateDate2"));
		String rdateTime =	 thaistring.MS874ToUnicode(request.getParameter("dateTime"));
		String rstrTopic =	 thaistring.MS874ToUnicode(request.getParameter("strTopic"));
		String rstrDescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));
		String rstrWarningType =	 thaistring.MS874ToUnicode(request.getParameter("strWarningType"));
		String rdateWarningDate =	 thaistring.MS874ToUnicode(request.getParameter("dateWarningDate"));
		System.out.println(rdateDate);
		System.out.println(rdateDate2);
		System.out.println(rdateTime);
		System.out.println(rstrTopic);
		System.out.println(rstrDescription);
		System.out.println(rstrWarningType);
		System.out.println(rdateWarningDate);

		webmaster.addRemind(rstrTopic,rstrDescription,rdateDate,rdateTime,rstrWarningType,rdateWarningDate,webmaster.getidWM());
		response.sendRedirect("Schedule_Webmaster_Detail.jsp?date="+rdateDate);
%>
<% } %>
