<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rusername =	 thaistring.MS874ToUnicode(request.getParameter("username"));
		String rtype =	 thaistring.MS874ToUnicode(request.getParameter("type"));
		String rname =	 thaistring.MS874ToUnicode(request.getParameter("name"));
		String rsurname =	 thaistring.MS874ToUnicode(request.getParameter("surname"));
		String rpassword =	 thaistring.MS874ToUnicode(request.getParameter("password"));
		String rpassword2 =	 thaistring.MS874ToUnicode(request.getParameter("password2"));

		rusername = rusername.replaceAll(" ","");
		rtype = rtype.replaceAll(" ","");
		rname = rname.replaceAll(" ","");
		rsurname = rsurname.replaceAll(" ","");
		rpassword = rpassword.replaceAll(" ","");
		rpassword2 = rpassword2.replaceAll(" ","");

		if ( (rusername != null) && (rname != null) && (rname != null) && (rsurname != null) && (rpassword != null) && (rpassword != null) ) {
			if (rpassword.equals(rpassword2)) {
				if(rtype.equals("Webmaster")) {
					webmaster.registerWM(rusername,rpassword,rname,rsurname);
					response.sendRedirect("UserWebmaster.jsp");
				} else if(rtype.equals("Teacher")) {
					webmaster.register(rusername,rpassword,rname,rsurname);
					response.sendRedirect("UserTeacher.jsp");
				} else if(rtype.equals("Student")) {
					webmaster.addStudent(rusername,rpassword,rname,rsurname);
					response.sendRedirect("UserStudent.jsp");
				 } else {
					response.sendRedirect("User_Webmaster.jsp");
				 }
			}
		}
%>
<%}%>