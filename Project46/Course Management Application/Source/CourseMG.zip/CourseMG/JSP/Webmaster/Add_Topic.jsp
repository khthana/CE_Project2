<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String strTopicName =	 thaistring.MS874ToUnicode(request.getParameter("strTopicName"));
		String strTopicDescription =	 thaistring.MS874ToUnicode(request.getParameter("strTopicDescription"));

		webmaster.addTopic(strTopicName,strTopicDescription,webmaster.getidWM(),"Webmaster",ridSubject);
		response.sendRedirect("Webboard_Webmaster.jsp");

%>
<%}%>