<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String checkdelete[] = request.getParameterValues("idTopics");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			System.out.print(checkdelete[i]);
			webmaster.deleteTopic(checkdelete[i]);
		}//for
	}
	response.sendRedirect("Webboard_Webmaster.jsp");
%>
<% } %>



<!--- End Footer --->
