<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String strPassword =	 thaistring.MS874ToUnicode(request.getParameter("strPassword"));
		strPassword = strPassword.replaceAll(" ","");
		String strNewPassword =	 thaistring.MS874ToUnicode(request.getParameter("strNewPassword"));
		strNewPassword =	 strNewPassword.replaceAll(" ","");
		String strConfirmNewPassword =	 thaistring.MS874ToUnicode(request.getParameter("strConfirmNewPassword"));
		strConfirmNewPassword =	 strConfirmNewPassword.replaceAll(" ","");
		
		System.out.println(strNewPassword);
		System.out.println(strConfirmNewPassword);

		if (strNewPassword.equals(strConfirmNewPassword)) {
			System.out.println(strPassword);
			webmaster.changePassword(strPassword,strNewPassword);
		}
		response.sendRedirect("Profile_Webmaster.jsp");
%>
<% } %>