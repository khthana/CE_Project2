<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: W e b b o a r d ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: W e b b o a r d ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/webboard5.gif" width="78" height="20" border="0"><img src="Picture/middle.gif" width="517" height="20" border="0" /><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
  
		


<!--- End Left Nav Bar --->




<!--- Begin Body --->

<td width="842">
	<table border="0" cellspacing="0" cellpadding="0" width="650">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
			     
                  <table width="95%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				  <tr bordercolor="87F59B">
					<td colspan="6" background="Picture/bg.gif" ><img src="Picture/delete_webboard.gif" width="300" height="20" border="0"><img src="Picture/middle.gif" width="222" height="20" border="0"><a href="Webboard_Webmaster_AddTopic.htm"><img src="Picture/end.gif" width="119" height="20" border="0" /></a></td>
				  </tr>
				  <tr bordercolor="87F59B">
				  </tr>
				<form name="form1" id="form1" method="post" action="Delete_Topic.jsp">
                          <tr bordercolor="87F59B" background="Picture/bg.gif">
                            <td width="22" class="detailblack" >&nbsp;</td>
                            <td width="40" class="detailblack" >Created</td>
                            <td width="133" class="detailblack" >Subject</td>
                            <td width="190" class="detailblack" >Topic</td>
                            <td width="66"><span class="detailblack" >Update</span></td>
                            <td width="38"><span class="detailblack" >Reply</span></td>
                          </tr>
				<% String[] idSubjects = webmaster.queryidSubjects(); %> 
						<%String[] idTopics = webmaster.queryidTopicsForSubjects(idSubjects);%> 
							  <%for(int i = 0 ; i < idTopics.length ; i++) { %>
							  <%ClassMGR.Webboard.Topic topic = webmaster.queryTopic(idTopics[i]);%>  	
								  <% if (topic.getisVisible().booleanValue()) { %>
									<tr bordercolor="87F59B" background="Picture/bg.gif">
								  <% } else { %>
									<tr bordercolor="87F59B" bgcolor="E4E4E4" background="Picture/bg1.gif">
								  <% } %>
									<td  class="headerdarkblue"><input type="checkbox" name="idTopics" value="<%=topic.getidTopic()%>" /></td>
							  <td  class="detaildarkblue"><%=helper.convertDate(topic.getcreateDate())%></td>
	                         <%ClassMGR.Subject.Subject subject = webmaster.querySubject(topic.getidSubject());%>  	
                            <td class="detailblue"><a class="headerpurple" href="Webboard_Webmaster_Subject.jsp?idSubject=<%=topic.getidSubject()%>"  target="_blank" ><%=subject.getnameEng()%></a></td>
							  <td  bordercolor="87F59B" class="headerdarkblue"><a href="Webboard_Webmaster_Reply.jsp?idSubject=<%=topic.getidSubject()%>&idTopic=<%=idTopics[i]%>" class="detailblue" target="_blank" ><%=topic.getname()%></a></td>
							  <td class="detaildarkblue"><%=helper.convertDate(topic.queryLastPost())%></td>
							  <td class="detaildarkblue"><%=topic.getCountReplys()%></td>
							</tr>
						<% } %>
  						   <tr bordercolor="87F59B" background="Picture/bg.gif">
						    <td width="22" class="detailblue"></td>
                            <td colspan="6" width="300" class="detaildarkblue">
								  <input name="Submit" type="submit" id="Submit" value="Delete" />                                
                                    <input name="Reset" type="reset" value="Reset" /> 
									<input name="Back" type="button" value="Cancle" onclick="window.location='Webboard_Webmaster.jsp'" /></td>
							</td>
                          </tr>
  </form>
</table>

					    </td>
                      </tr>
                    </tbody>
                  </table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	

<!--- End Body --->



<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>