<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rcurriculum =	 thaistring.MS874ToUnicode(request.getParameter("curriculum"));
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String rthaiName =	 thaistring.MS874ToUnicode(request.getParameter("thaiName"));
		String rengName =	 thaistring.MS874ToUnicode(request.getParameter("engName"));
		String rcredit =	 thaistring.MS874ToUnicode(request.getParameter("credit"));
		String rrequireSubject =	 thaistring.MS874ToUnicode(request.getParameter("requireSubject"));
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("description"));
		String rtimeStudy =	 thaistring.MS874ToUnicode(request.getParameter("timeStudy"));
		String rscaleMidterm =	 thaistring.MS874ToUnicode(request.getParameter("scaleMidterm"));
		String rscaleFinal =	 thaistring.MS874ToUnicode(request.getParameter("scaleFinal"));
		String rscaleQuiz =	 thaistring.MS874ToUnicode(request.getParameter("scaleQuiz"));
		String rscaleAssignment =	 thaistring.MS874ToUnicode(request.getParameter("scaleAssignment"));
		String rscaleLab =	 thaistring.MS874ToUnicode(request.getParameter("scaleLab"));
		String rtimeTalking =	 thaistring.MS874ToUnicode(request.getParameter("timeTalking"));
		String rtextBook =	 thaistring.MS874ToUnicode(request.getParameter("textBook"));
		String rmagicNumber =	 thaistring.MS874ToUnicode(request.getParameter("magicNumber"));

		webmaster.addSubject(ridSubject,rthaiName,rengName,rdescription,rcurriculum,"0",rcredit,rrequireSubject,rtimeStudy,rscaleMidterm,rscaleFinal,rscaleQuiz,rscaleAssignment,rscaleLab,rmagicNumber,rtextBook,rtimeTalking);
		response.sendRedirect("Subject_Webmaster.jsp");

%>
<% } %>