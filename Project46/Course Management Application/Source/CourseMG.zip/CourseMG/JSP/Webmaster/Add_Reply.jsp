<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String ridTopic =	 thaistring.MS874ToUnicode(request.getParameter("idTopic"));
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));

		webmaster.addReply(rdescription,webmaster.getidWM(),"Webmaster",ridTopic);
		response.sendRedirect("Webboard_Webmaster_Reply.jsp?idSubject="+ridSubject+"&idTopic="+ridTopic);

%>
<%}%>