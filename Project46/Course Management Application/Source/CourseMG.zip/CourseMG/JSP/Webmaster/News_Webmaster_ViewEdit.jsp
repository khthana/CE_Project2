<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/news1.gif" width="100" height="20" border="0"><img src="Picture/middle.gif" width="480" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	
		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
                
   
             </td>

		


<!--- End Left Nav Bar --->




<!--- Begin Body --->
<td width="858">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
			     
                  <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="600" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F">
				  <tr bordercolor="87F59B">
					<td colspan="3" background="Picture/bg.gif" ><img src="Picture/microprocessor_news.gif" width="374" height="20" border="0"><img src="Picture/middle.gif" width="193" height="20" border="0"><a href="News_Edit_Teacher.htm"><img src="Picture/end.gif" width="52" height="20" border="0" /></a></td>
				  </tr>
				 
				
				 
				 
				  <tr bordercolor="87F59B">
					<td width="72" height="25"  background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
					<td width="606" height="25"background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
				  </tr>
  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>

  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">

    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>

  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
   
  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">

    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td height="25" background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
</table>

					    <p>&nbsp;</p></td>
                      </tr>
                    </tbody>
                  </table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	

<!--- End Body --->



<!--- Begin Footer --->



			  </tr>
		  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
