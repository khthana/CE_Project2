<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String stridNews =	 thaistring.MS874ToUnicode(request.getParameter("stridNews"));
		String strDatePost =	 thaistring.MS874ToUnicode(request.getParameter("strDatePost"));
		String strTopic =	 thaistring.MS874ToUnicode(request.getParameter("strTopic"));
		String strDescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));
		String strNum2Del =	 thaistring.MS874ToUnicode(request.getParameter("strNum2Del"));
		String stridSubject =	 thaistring.MS874ToUnicode(request.getParameter("stridSubject"));
		stridNews = stridNews.replaceAll(" ","");
		strNum2Del = strNum2Del.replaceAll(" ","");
		System.out.println(stridNews);
		System.out.println(strDatePost);
		System.out.println(strTopic);
		System.out.println(strDescription);
		System.out.println(strNum2Del);
//		System.out.println(stridSubject);

		
		webmaster.editNews(stridNews,strTopic,strDescription,strDatePost,strNum2Del);
		response.sendRedirect("News_Webmaster_Detail.jsp?idNews="+stridNews);

%>
<% } %>