<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String rtype=	request.getParameter("type");
	System.out.println(rtype);
	if (rtype == null)  rtype = "";
	String checkdelete[] = request.getParameterValues("idUsers");
	System.out.println("aaaaaaaaaaaaa");
	if(checkdelete!= null) {
	System.out.println("aaaaaaaaaaaaa");
		if(rtype.equals("Webmaster")) {
			for (int i = 0;i<checkdelete.length;i++){
				System.out.println("bbbbbbbbb");
				checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
				System.out.print(checkdelete[i]);
				webmaster.deleteWM(checkdelete[i]);
			}//for
			response.sendRedirect("UserWebmaster.jsp");
		} else if(rtype.equals("Teacher")) {
			for (int i = 0;i<checkdelete.length;i++){
				checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
				System.out.print(checkdelete[i]);
				webmaster.deleteTeacher(checkdelete[i]);
			}//for
			response.sendRedirect("UserTeacher.jsp");
		} else if(rtype.equals("Student")) {
			for (int i = 0;i<checkdelete.length;i++){
				checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
				System.out.print(checkdelete[i]);
				webmaster.deleteStudent(checkdelete[i]);
			}//for
			response.sendRedirect("UserStudent.jsp");
		 } else {
			response.sendRedirect("User_Webmaster.jsp");
		 }
	}
%>
<% } %>



