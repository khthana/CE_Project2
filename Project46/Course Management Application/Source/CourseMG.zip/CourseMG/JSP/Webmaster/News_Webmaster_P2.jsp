<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/news1.gif" width="100" height="20" border="0"><img src="Picture/middle.gif" width="480" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="179">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            <p>
			<a href="Home_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Webmaster_P1.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News_Selected.gif"  /></a><br />
			  <a href="Schedule_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
			  <a href="Subject_SyllabusTab_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject.gif"  /></a><br />
              <a href="Webboard_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="User_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture/Menu_User.gif" /></a></p>
              <img alt="" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt=""  src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
		    <table width="161" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><div align="left"><span class="detaildarkblue">
				        Webmaster : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><span >
					    <a href="Login.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><span >
					    <a href="Profile_Webmaster.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><span >
					    <a href="Profile_Webmaster_Edit.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->




<!--- Begin Body --->
<td width="10" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>
<td width="831">
	<table border="0" cellspacing="0" cellpadding="0" width="650">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
			     
                  <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F">
					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
				  <tr bordercolor="87F59B">
				  
					<td width="92" background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
					<td width="614" background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
				  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="News_Webmaster_Detail.htm" >News Topic</a></span></td>
  </tr>
					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>

					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>

					<tr bordercolor="87F59B" bgcolor="#CAFD97"><td colspan="2" class="detailhead">Subject</td></tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
  <tr bordercolor="87F59B">
    <td background="Picture/bg.gif"><span class="headerdarkblue">10/02/2004</span></td>
    <td background="Picture/bg.gif"><span class="headerdarkblue"><a href="#" >News Topic</a></span></td>
  </tr>
           <tr bordercolor="#EFFAD1" bgcolor="#EFFAD1" background="Picture/bg.gif"> 
                <td colspan="2"><span>&nbsp;<a href="News_Webmaster_P3.jsp" class="detailgreen">NEXT &gt;&gt;</a> &nbsp;&nbsp;<a href="News_Webmaster_P1.jsp"><img src="Picture/n1.gif" width="19" height="20" border="0"></a>&nbsp;<a href="News_Webmaster_P2.jsp"><img src="Picture/n2.gif" width="19" height="20" border="0"></a>&nbsp;<a href="News_Webmaster_P3.jsp"><img src="Picture/n3.gif" width="19" height="20" border="0"></a>&nbsp;<img src="Picture/n4.gif" width="19" height="20">&nbsp;<img src="Picture/n5.gif" width="19" height="20">&nbsp;<img src="Picture/n6.gif" width="19" height="20">&nbsp;<img src="Picture/n7.gif" width="19" height="20">&nbsp;<img src="Picture/n8.gif" width="19" height="20">&nbsp;<img src="Picture/n9.gif" width="19" height="20">&nbsp;<img src="Picture/n10.gif" width="26" height="20"></span></td>
              </tr>
            </table>
          </td>
        </tr>




</table>

					    </td>
                      </tr>
                    </tbody>
                  </table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp; </p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	

<!--- End Body --->



<!--- Begin Footer --->



			  </tr>
		  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
