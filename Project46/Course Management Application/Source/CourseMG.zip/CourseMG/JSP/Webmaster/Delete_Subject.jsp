<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String ridSubjects[] = request.getParameterValues("ridSubjects");

	if(ridSubjects!= null) {
		for (int i = 0;i<ridSubjects.length;i++){
			ridSubjects[i] = thaistring.MS874ToUnicode(ridSubjects[i]);
			System.out.println(ridSubjects[i]);
			webmaster.deleteSubject(ridSubjects[i]);
		}//for
	}
	response.sendRedirect("Subject_Webmaster.jsp");
%>
<% } %>



<!--- End Footer --->
