<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%
	String ridSubject2 =	request.getParameter("ridSubject");
	if (ridSubject2 == null)  ridSubject2 = "";
	String checkdelete[] = request.getParameterValues("checkdelete");
	System.out.println(checkdelete[0]);
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			System.out.println(checkdelete[i]);
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			webmaster.deleteNews(checkdelete[i]);
		}//for
	}
	System.out.println(ridSubject2);
	 if (!ridSubject2.equals("")) { 
			response.sendRedirect("News_Webmaster_View.jsp?idSubject="+ridSubject2);
	 } else {
			response.sendRedirect("News_Webmaster.jsp");
	 }
%>
<% } %>



