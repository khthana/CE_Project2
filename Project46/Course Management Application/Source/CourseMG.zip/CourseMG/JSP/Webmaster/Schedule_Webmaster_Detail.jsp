<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rDate =	request.getParameter("date");
		String rid =	request.getParameter("id");
		if (rid == null)  rid = "";
		if (rDate == null)  rDate = webmaster.getnewday();
		System.out.println(rDate);
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S c h e d u l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S c h e d u l e ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0" /></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>



<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/home.gif" width="100" height="20" border="0"><img src="Picture/middle.gif" width="480" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* --><p>			  
			<a href="Home_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Webmaster_Detail.jsp?date=<%=webmaster.getnewday()%>"  ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule_Selected.gif" /></a><br />
			  <a href="Subject_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject.gif"  /></a><br />
              <a href="Webboard_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="User_Webmaster.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture/Menu_User.gif" /></a></p>
              
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0" />              <table width="167" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><div align="left"><span class="headerdarkblue">
				        <%=webmaster.getname()%>: Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="Profile_Webmaster.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="142"><span >
					    <a href="Profile_Edit_Webmaster.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
		  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>


<!--- End Left Nav Bar --->



<!--- Begin Body --->
<td width="10" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>

          <td width="832"> <table width="650" border="1" cellpadding="0" cellspacing="0" bordercolor="#14296F" background="Picture/bg.gif" bgcolor="#EFFAD1">
              <!--Display the spacer line if there is no graphical header (text only)-->
              <!--- Display local nav (if used)--->
              <!--- Local Nav --->
              <!---BUILD OUT PARTNERS NAV--->
              <!--- End Local Nav --->
              <tr> 
         		<td width="650" colspan="6" ><p><img src="Picture/schedule.gif" width="71" height="20" border="0"><img src="Picture/middle.gif" width="472" height="20" border="0"><img src="Picture/end.gif" width="103" height="20" border="0" /></p>
         		  <table width="100%" height="350" border="1" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
                    <tr> 
                      <td width="50%" height="300" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1"> <table  height="300" width="100%" border="1" bordercolor="#66CC00">
                          <tr bordercolor="#EFFAD1" bgcolor="#EFFAD1">  
							<td><h5><a href="Schedule_Webmaster_Detail.jsp?date=<%=helper.convertFormalDate(helper.subMonth(rDate))%>" class="headerdarkblue">&lt;&lt;</a></h5></td>
							<td colspan="5" align="center" class="headerdarkblue"><h5><%=helper.convertToNameMonth(rDate)%> , <%=helper.getYear(rDate)%> </h5></td>
							<td><h5><a href="Schedule_Webmaster_Detail.jsp?date=<%=helper.convertFormalDate(helper.addMonth(rDate))%>" class="headerdarkblue">&gt;&gt;</a></h5></td>
                          </tr>
                          <tr class="detailblack"> 
                            <td width="14%">S</td>
                            <td width="14%">M</td>
                            <td width="14%">T</td>
                            <td width="14%">W</td>
                            <td width="14%">T</td>
                            <td width="14%">F</td>
                            <td width="14%">S</td>
                          </tr>
						   <tr class="detailblue"> 
						    <% String[] dateSchedule = webmaster.queryDateForMonth(helper.getMonth(rDate),helper.getYear(rDate));%>
							 <%int idateSchedule = 0;%>
						       <%int firstDay = helper.queryFirstDayForMonth(rDate);%>
							  <%String lastDate = helper.queryLastDateForMonth(rDate);%>
					   		<%System.out.println(Integer.parseInt(helper.getDate(rDate)));%>
					   		<%System.out.println(firstDay);%>
						    <%System.out.println(lastDate);%>
							  <% int count = 0; %>
							  <% for(int i = 1 ; i <=Integer.parseInt(lastDate) ; count++) { %>
									<%	if (count == 7) { %>
						  </tr>
										<tr class="detailblue">
										<%count = 0;%>
									<% } %>
									<%	if ((i == 1) && ((firstDay-1) != count)){ %>
											<td>&nbsp;</td>
									<% } else { %>
											<%	if (i == Integer.parseInt(helper.getDate(rDate))) { %>
												<td bgcolor="#99FF66"><a href="Schedule_Webmaster_Detail.jsp?date=<%=i+"-"+helper.getMonth(rDate)+"-"+helper.getYear(rDate)%>"><%=i%><a/>
											<%} else {%>
												<td><a href="Schedule_Webmaster_Detail.jsp?date=<%=i+"-"+helper.getMonth(rDate)+"-"+helper.getYear(rDate)%>"><%=i%><a/>
											<% } %>
											<% if (dateSchedule.length != 0) { %>
												<% if (i ==Integer.parseInt(dateSchedule[idateSchedule])) { %>
													 <font  color="#FF0000">*</font>
													 <%if (idateSchedule < (dateSchedule.length-1)) {%>
														<% idateSchedule++; %>
													 <% } %>
												 <% } %>
											<% } %>
											</td>
											<%i++;%>
									<% } %>
							<% } %>
							<% for(int i = count ; i < 7 ; i++) { %>
									<td>&nbsp;</td>
							<% } %>
                                </tr>
                      </table></td>

                      <td width="50%" valign="top" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
					    <table width="100%" height="151" border="0" align="top">
                          <tr> 
                            <td  colspan="3" height="20" >
							<a href="Schedule_Webmaster_Add.jsp?date=<%=helper.convertFormalDate(rDate)%>"><img src="Picture/b_add.gif" width="38" height="20" border="0"/></a>
							<a href="Schedule_Webmaster_Edit.jsp?date=<%=helper.convertFormalDate(rDate)%>"><img src="Picture/b_edit.gif" width="43" height="20" border="0"/></a>
							<a href="Schedule_Webmaster_Delete.jsp?date=<%=helper.convertFormalDate(rDate)%>"><img src="Picture/b_delete.gif" width="59"" height="20" border="0"/></a></td>
                          </tr>
                          <tr> 
                            <td height="57" colspan="3"><br/><span class="detaildarkblue">To Do List</span></td>
                          </tr>
						  <%String[] idReminds = webmaster.queryidRemindsForDate(rDate);%>
						  <%for(int i = 0 ; i < idReminds.length ; i++) { %>
                         	  <%ClassMGR.Schedule.Remind remind = webmaster.queryRemind(idReminds[i]);%>  	
						  <tr> 
                            <td width="15" valign="top" class="detailblue"><span><%=remind.gettime()%></font></td>
                            <td colspan="2" valign="top"><span><a href="Schedule_Webmaster_Detail.jsp?date=<%=helper.convertFormalDate(rDate)%>&id=<%=idReminds[i]%>" class="detailgreen"><%=remind.gettopic()%></a></span></td>
                          </tr>
					<% } %>
						  <tr> 
                            <td colspan="3"height="15">&nbsp;</td>
                          </tr>
					  </table></td>
                    </tr>
					
					<tr >
						<td colspan="2" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">&nbsp;</td>
					</tr>
					
                 
					
					<tr bgcolor="#FFFFFF"> 
					  <td height="150" colspan="2" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
					  <% if (rid!="")  { %>
					  <table width="100%" height="161" border="0" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
                          <tr> 
                            <td height="33" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1"><h5><span class="headergreen">Present Project </span></h5></td>
                          </tr>
                          <tr> 
                         	  <%ClassMGR.Schedule.Remind remind = webmaster.queryRemind(rid);%>  	
                            <td height="33" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1" class="detaillightblue">&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 
                              <%=remind.getdescription()%></td>
                          </tr>
                          <tr> 
                            <td height="34" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1" ><a href="Schedule_Webmaster_Edit.jsp?date=<%=helper.convertFormalDate(rDate)%>&id=<%=rid%>"><img src="Picture/b_edit.gif" width="43" height="20" border="0"></a></td>
                          </tr>
                          <tr> 
                            <td bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">&nbsp; </td>
                          </tr>
                          <tr> 
                            <td bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">&nbsp;</td>
                          </tr>
                      </table>
					<% } %>
					</td>
                    </tr>
                </table></td>
              </tr>
              <tr> 
                <!---<td width="185"> Begin: This is a dynamic td tag, it is added only if right nav exists. see code below--->
                <!--- Begin: Optional Right Nav Block --->
              </table></td>
                <!---</td> End: This is a dynamic td tag, it is added only if right nav exists. see code above--->
              </tr>
              <tr> 
                <td colspan="2"> <h4> 
                    <p align="center">&nbsp;</p>
                  </h4>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
              </tr>
      </table></td>	

<!--- End Body --->


<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>