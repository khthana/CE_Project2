<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S c h e d u l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S c h e d u l e ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/schedule1.gif" width="72" height="20" border="0"><img src="Picture/middle.gif" width="530" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="178">
            <p>			  
			 <a href="Home_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Webmaster_P1.htm" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />  
              <a href="Schedule_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule_Selected.gif" /></a><br />
              <a href="Webboard_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture/Menu_Webboard.gif" /></a> <br />   
              <a href="Chat_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
            <a href="Assignment_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a></p>
              <img alt=""  src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
 <table width="176" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><div align="left"><span class="detaildarkblue">
				        Webmaster  : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><span >
					    <a href="Login.htm" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			    <tr>
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><span >
					    <a href="Profile_Webmaster.htm" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><span >
					    <a href="Profile_Webmaster_Edit.htm" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->




<!--- Begin Body --->
<td width="11" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>

          <td width="823"> <table width="650" border="1" cellpadding="0" cellspacing="0" bordercolor="#14296F" background="Picture/bg.gif" bgcolor="#EFFAD1">
              <!--Display the spacer line if there is no graphical header (text only)-->
              <!--- Display local nav (if used)--->
              <!--- Local Nav --->
              <!---BUILD OUT PARTNERS NAV--->
              <!--- End Local Nav --->
              <tr> 
         		<td width="650" colspan="6" ><p><img src="Picture/schedule.gif" width="71" height="20" border="0"><img src="Picture/middle.gif" width="472" height="20" border="0"><img src="Picture/end.gif" width="103" height="20" border="0" /></p>
         		  <table width="100%" height="350" border="1" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
                    <tr> 
                      <td width="50%" height="300" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1"> <table  height="300" width="100%" border="1" bordercolor="#66CC00">
                          <tr bordercolor="#EFFAD1" bgcolor="#EFFAD1"> 
							<td><h5><a href="aaa" class="headerdarkblue">&lt;&lt;</a></h5></td>
                            <td colspan="5" align="center" class="headerdarkblue"><h5>October , 2003 </h5></td>
							<td><h5><a href="aaa" class="headerdarkblue">&gt;&gt;</a></h5></td>
                          </tr>
                          <tr class="detailblack"> 
                            <td width="14%">S</td>
                            <td width="14%">M</td>
                            <td width="14%">T</td>
                            <td width="14%">W</td>
                            <td width="14%">T</td>
                            <td width="14%">F</td>
                            <td width="14%">S</td>
                          </tr>
                                  <tr class="detailblue"><td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td>&nbsp;</td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 1</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 2</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 3</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 4</a></td>
                                </tr>
                                <tr class="detailblue"> 
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 5</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277" > 6</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 7</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 8</a></td>
                                   <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277">9</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 10</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 11</a></td>
                          </tr>
                                <tr class="detailblue"> 
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 12</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 13</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 14</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 15</a></td>
                                   <td bgcolor="#99FF66" ><a href="http://www.ce.kmitl.ac.th/news/?header_id=277">16</a> <font  color="#FF0000">*</font></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 17</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 18</a></td>
                          </tr>
                                <tr class="detailblue"> 
							<!--<font color="#FF0000">*</font>-->
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 19</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 20</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 21</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 22</a></td>
                                   <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277">23</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 24</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 25</a></td>
                          </tr>
                                <tr class="detailblue"> 
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 26</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 27</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 28</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277"> 29</a></td>
                                   <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277">30</a></td>
                                  <td><a href="http://www.ce.kmitl.ac.th/news/?header_id=277">31</a></td>
                                  <td>&nbsp;</td>
                          </tr>
                      </table></td>
                      <td width="50%" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">
					  <table width="100%" height="300" border="0">
                         
                          <tr> 
                            <td height="15" colspan="3"><span class="detaildarkblue">To Do List</span></td>
                          </tr>
                          <tr> 
                            <td width="15" height="15" class="detailblue"><span>17.30</font></td>
                            <td height="15" colspan="2"><span><a href="Schedule_Webmaster_Edit.htm" class="detailgreen">present project</a></span></td>
                          </tr>
                             <tr> 
                            <td width="15" height="15" class="detailblue"><span>17.30</font></td>
                            <td height="15" colspan="2"><span><a href="Schedule_Webmaster_Edit.htm" class="detailgreen">present project</a></span></td>
                          </tr>
						  <tr> 
                            <td colspan="3"height="15">&nbsp;</td>
                          </tr>
						    <tr> 
                            <td colspan="3"height="15">&nbsp;</td>
                          </tr>
						 <tr> 
                            <td colspan="3"height="15">&nbsp;</td>
                          </tr>
						  <tr> 
                            <td colspan="3"height="15">&nbsp;</td>
                          </tr>
						  <tr> 
                            <td colspan="3"height="90">&nbsp;</td>
                          </tr>
						
						  
						
                      </table></td>
                    </tr>
					
					<tr >
						<td colspan="2" bordercolor="#EFFAD1" background="Picture/bg.gif" bgcolor="#EFFAD1">&nbsp;</td>
					</tr>
                </table></td>
              </tr>
              <tr> 
                <!---<td width="185"> Begin: This is a dynamic td tag, it is added only if right nav exists. see code below--->
                <!--- Begin: Optional Right Nav Block --->
              </table></td>
                <!---</td> End: This is a dynamic td tag, it is added only if right nav exists. see code above--->
              </tr>
              <tr> 
                <td colspan="2"> <h4> 
                    <p align="center">&nbsp;</p>
                  </h4>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p></td>
              </tr>
      </table></td>	

<!--- End Body --->



<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
