<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: W e b b o a r d ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: W e b b o a r d ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
body,td,th {
	font-size: 14px;
}



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/webboard5.gif" width="78" height="20" border="0"><img src="Picture/middle.gif" width="517" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1020">
				<tr valign=top>	

		<td width="178">
            <p>
			  <a href="Home_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Webmaster_P1.htm" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />  
              <a href="Schedule_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
              <a href="Webboard_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture/Menu_Webboard_Selected.gif" /></a><br />
              <a href="Chat_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="Assignment_Webmaster.htm" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a></p>
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
 <table width="176" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><div align="left"><span class="detaildarkblue">
				        Webmaster  : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><span >
					    <a href="Login.htm" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			    <tr>
			  		<td width="11" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="14" height="31" >&nbsp;</td>
			  		<td width="141"><span >
					    <a href="Profile_Webmaster.htm" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="10" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="13" height="31" >&nbsp;</td>
			  		<td width="151"><span >
					    <a href="Profile_Webmaster_Edit.htm" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
   </table>			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->



<!--- Begin Body --->

<td width="842">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
			     
                  <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td bordercolor="14296F">
						<table width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				  <tr bordercolor="87F59B">
					<td colspan="6" background="Picture/bg.gif" ><img src="Picture/computer_network_webboard.gif" width="300" height="20" border="0"><img src="Picture/middle.gif" width="335" height="20" border="0"><a href="Webboard_Webmaster_Reply.htm"><img src="Picture/b_reply.gif" width="52" height="20" border="0" /></a></td>
				  </tr>
      <tr bordercolor="#87F59B" bgcolor="#99CCFF">
                                  <td width="54" class="detailblue">Poster</td>
                                  <td width="645" class="detailblue">Topic</td>
                            </tr>
                                <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                                  <td width="54" class="detaildarkblue">Poster</td>
                                  <td width="645" class="detaildarkblue">Post Date : 11 / 2 / 2004 
                                  <hr/>asdasdasdasdasdasdasd</td>
                            </tr>
								  <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                                  <td width="54" class="detaildarkblue">Poster</td>
                                  <td width="645" class="detaildarkblue">Post Date : 11 / 2 / 2004 
                                    <hr/>asdasdasdasdasdasdasd</td>
                            </tr>
								  <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                                  <td width="54" class="detaildarkblue">Poster</td>
                                  <td width="645" class="detaildarkblue">Post Date : 11 / 2 / 2004 
                                    <hr/>asdasdasdasdasdasdasd</td>
                            </tr>
								  <tr bordercolor="#87F59B" bgcolor="#EFFAD1">
                                  <td width="54" class="detaildarkblue">Poster</td>
                                  <td width="645" class="detaildarkblue">Post Date : 11 / 2 / 2004 
                                    <hr/>asdasdasdasdasdasdasd</td>
                            </tr>
								  <tr bordercolor="87F59B">
					<td colspan="6" background="Picture/bg.gif" ><a href="Webboard_Webmaster_Reply.htm"><img src="Picture/b_reply.gif" width="52 height="20" border="0" /></a><img src="Picture/middle.gif" width="335" height="20" border="0"><img src="Picture/end.gif" width="304" height="20" border="0"></td>
				  </tr>
</table>

					    </td>
                      </tr>
                    </tbody>
                  </table>
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                  </h4></td>
		
		</tr>
	</table>
</td>	

<!--- End Body --->



<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
