<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String rname =	 thaistring.MS874ToUnicode(request.getParameter("strName"));
		String rsurname =	 thaistring.MS874ToUnicode(request.getParameter("strSurname"));
		String remail =	 thaistring.MS874ToUnicode(request.getParameter("strEmail"));
    webmaster.editProfile(rname,rsurname,remail);
	webmaster.setname(rname);
	webmaster.setsurname(rsurname);
	webmaster.setemail(remail);

		response.sendRedirect("Profile_Webmaster.jsp");
%>
<% } %>