<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridUser =	request.getParameter("idUser");
		if (ridUser == null)  ridUser = "";
		String rtype=	request.getParameter("type");
		if (rtype == null)  rtype = "";
		String rpassword =	request.getParameter("password");
		if (rpassword == null)  rpassword = "";
		System.out.println(rpassword);
		
		
        if(rpassword!=null) {
			if(rtype.equals("WebMaster")) {
				webmaster.changePasswordWM(ridUser,rpassword);
				response.sendRedirect("UserWebmaster.jsp");
			} else if(rtype.equals("Teacher")) {
				webmaster.changeTeacherPassword(ridUser,rpassword);
				response.sendRedirect("UserTeacher.jsp");
			} else if(rtype.equals("Student")) {
				webmaster.changeStdPassword(ridUser,rpassword);
				response.sendRedirect("UserStudent.jsp");
			 } else {
			 	response.sendRedirect("User_Webmaster.jsp");
			 }
		} 

%>
<% } %>