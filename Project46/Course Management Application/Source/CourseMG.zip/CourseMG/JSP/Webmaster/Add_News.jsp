<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject2 =	request.getParameter("ridSubject");
		if (ridSubject2 == null)  ridSubject2 = "";
		String rtopic =	 thaistring.MS874ToUnicode(request.getParameter("topic"));
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("description"));
		String rnum2Del =	 thaistring.MS874ToUnicode(request.getParameter("num2Del"));
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));

	String subjects[] = new String[1];
	subjects[0] = ridSubject.replaceAll(" ","");
		webmaster.addNews(subjects,rtopic,rdescription,webmaster.getidWM(),"WebMaster",rnum2Del);

	System.out.println(ridSubject2);
	 if (!ridSubject2.equals("")) { 
			response.sendRedirect("News_Webmaster_View.jsp?idSubject="+ridSubject2);
	 } else {
			response.sendRedirect("News_Webmaster.jsp");
	 }

%>
<%}%>