<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="webmaster" class="ClassMGR.User.WM" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	webmaster=(WM)session.getAttribute("auth"); %>
<%	if( webmaster == null  ||  !webmaster.getRole().equals("WebMaster")  )  { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
    <link href="style1.css" rel="stylesheet" type="text/css" />
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="210">
		
		


<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
<td width="738">
	<table border="0" cellspacing="0" cellpadding="0" width="686">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		
		<tr> 
			    <td width="650"><form name="form1" action="Add_News.jsp" method="Post">
			      <table width="100%" border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="14296F" bgcolor="EFFAD1">
                          <tr bgcolor="#FFFFFF" background="Picture/bg.gif">
                            <td colspan="4" class="headerdarkblue"><img name="lmenu_id_r1_c1" src="Picture/add_news.gif" width="110" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="400" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/end.gif" width="140" height="20" border="0" /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue"> Date :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strUsername" type="text" id="strUsername4"   size="30" maxlength="30"  value="<%=helper.querySysDateAll()%>" disabled /></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Subject  :: </td>
                            <td width="325" bordercolor="EFFAD1">
								  <select name="idSubject" size="1">
												 <option value="0" <% if(ridSubject.equals("0")) { %> selected <% } %>>General News</option>
												<%String[] idSubjects = webmaster.queryidSubjects()	;%> 
												  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
														  <%ClassMGR.Subject.Subject subject = webmaster.querySubject(idSubjects[i]);%>  	
														 <option value="<%=subject.getidSubject()%>" <% if(ridSubject.equals(subject.getidSubject())) { %> selected <% } %>><%=subject.getnameEng()%></option>
												<% }  %>
								</select>
							</td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Topic  :: </td>
                            <td width="325" bordercolor="EFFAD1"><textarea name="topic" cols="70" rows="2" id="strPassword3"></textarea></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Description :: </td>
                            <td width="325" bordercolor="EFFAD1"><textarea name="description" cols="70" rows="10" id="textarea4"></textarea></td>
                          </tr>
							<tr>
							  <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Delete Days :: </td>
							  <td width="325" bordercolor="EFFAD1"><input name="num2Del" type="text" id="strUsername4"   size="12" maxlength="8"/></td>
							</tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue"> Writer :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strUsername" type="text" id="strUsername4"   size="30" maxlength="30"  value="<%=webmaster.getname()%>" disabled /></td>
                          </tr>
                         
                          
                         
                          
                          
                        
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" ></td>
                            <td colspan="2"><p class="style11">
								<input name="Add" type="button" id="Add" value="Add" onClick="checknull('Add')"/>                                
								<input name="Reset" type="reset" value="Reset" />
								<% if (!ridSubject.equals("")) { %>
									<input name="ridSubject" type="hidden"  value="<%=ridSubject%>" />
									<input name="Cancle" type="button" value="Back" onclick="window.location='News_Webmaster_View.jsp?idSubject=<%=ridSubject%>'" />
								<% } else { %>
									<input name="Cancel" type="button" value="Cancel" onclick="window.location='News_Webmaster.jsp'" />
								<% } %>
                            <p >&nbsp;                            </p></td>
                          </tr>
						  <tr bordercolor="EFFAD1"></tr>
                    </table>
                    </form>
                 
                </td>
				
		
	</table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
		  </table>
				
	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->

<!--Begin Add Java Script -->
<SCRIPT LANGUAGE="JavaScript">
<!--
//topic, description, num2Del,
//isNaN
	var doc = document.form1
	function checknull(n){
		if((!((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value)))))&&
		(!((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value)))))&&
		(!((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))))
		{
			if(!isNaN(doc.num2Del.value))
				{doc.submit();} 
			else
				alert('��سҡ�͡ Delete Days ���١��ͧ');
		}
		else {
			var strAlert = "��سҡ�͡ ";
			if(((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))) strAlert = strAlert + " Topic  " ;
			if(((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))) strAlert = strAlert + " Description  " ;
			if(((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))) strAlert = strAlert + " Delete Day  " ;
			alert(strAlert);
		}
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script--> 
 
 
 
<% } %>