<%@ page language="java" contentType="text/html; charset=windows-874" %>
<jsp:useBean id="authen" class="ClassMGR.User.Authenticate" scope="session" />
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>SignOut</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body>
<%
    session.removeAttribute("auth");
	session.invalidate(); // destroy session
	response.sendRedirect("/ClassMG/log_in.jsp");
%>
</body>
</html>