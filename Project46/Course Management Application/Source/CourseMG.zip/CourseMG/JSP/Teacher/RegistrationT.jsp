<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: R e g i s t r a t i o n ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: R e g i s t r a t i o n ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">
	
		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/registration.gif" width="150" height="20" border="0"><img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->

<td width="777">
	<table border="0" cellspacing="0" cellpadding="0" width="600">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->




		<tr> 
			    <td>                  
					  <table border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="#14296F" bgcolor="#EFFAD1" >
					  <form action="" method="Post">
                          <tr bordercolor="#87F59B"> 
                            <td colspan="3" ><img src="Picture/registration1.gif" width="150" height="20" border="0" /><img src="Picture/middle.gif" width="108" height="20" border="0"><img src="Picture/end.gif" width="373" height="20" border="0"></td>
                        </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="147"  align="right" bordercolor="#87F59B" class="detailblue">Username : </td>
                            <td colspan="2"><input name="strUsername" type="text" id="strUsername"   size="20" maxlength="20"/></td>
                        </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="147"  align="right" bordercolor="#87F59B" class="detailblue">Password : </td>
                            <td colspan="2"><input name="strPassword" type="text" id="strPassword"   size="20" maxlength="20"/></td>
                        </tr>
                          <tr bordercolor="87F59B" bgcolor="#EFFAD1"> 
                            <td width="147"  align="right" bordercolor="#87F59B" class="detailblue">Confirm Password : </td>
                            <td colspan="2"><input name="strConfirmPassword" type="text" id="strConfirmPassword"   size="20" maxlength="20"/></td>
                        </tr>
                             <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">����-���ʡ�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strUsername" type="text" id="strUsername4"   size="50" maxlength="100"/></td>
                            <td width="150" bordercolor="EFFAD1"rowspan="3"><img name="" src="" width="150" height="150" alt="" /></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">���˹� :: </td>
                            <td width="325" bordercolor="EFFAD1"><input name="strPassword" type="text" id="strPassword3"   size="50" maxlength="100"/></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">����ѵԡ���֡�� :: </td>
                            <td width="325" bordercolor="EFFAD1"><textarea name="strConfirmPassword" cols="50" rows="5" id="textarea4"></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�Ԫҷ���͹ :: </td>
                            <td colspan="2"><textarea name="strName" cols="50" rows="5" id="textarea5"></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�͹��дѺ :: </td>
                            <td colspan="2" class="detailblue"><input name="checkbox" type="checkbox" value="checkbox" />
      ��ԭ�ҵ��
        <input name="checkbox2" type="checkbox" value="checkbox" />
      ��ԭ���
      <input type="checkbox" name="checkbox3" value="checkbox" />
      ��ԭ���͡</td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�ŧҹ�ҧ�Ԫҡ�� :: </td>
                            <td colspan="2"><textarea name="strNickname" cols="50" rows="5" id="textarea6"></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�ԧ����ǹ��� :: </td>
                            <td colspan="2"><input name="strCourse" type="text" id="strCourse4"   size="50" maxlength="100"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">������ :: </td>
                            <td colspan="2"><input name="strCourse2" type="text" id="strCourse23"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�������Ѿ�� ::</td>
                            <td colspan="2"><input name="strEmail" type="text" id="strEmail3"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">��ͧ�ӧҹ ::</td>
                            <td colspan="2"><input name="strTel" type="text" id="strTel3"   size="50" maxlength="50"/></td>
                          </tr>
                      <tr bordercolor="#EFFAD1" bgcolor="#EFFAD1"> 
                            <td width="147" >&nbsp;</td>
                          <td width="325" ><input name="Submit" type="submit" value="OK" />
                          <input name="Reset" type="reset" value="Cancel" /></td>
                        </tr>
						</form>
				  </table>
					
					
             </td>
		</tr>
	</table>
</td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
