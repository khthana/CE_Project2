<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String strPassword =	 thaistring.MS874ToUnicode(request.getParameter("strPassword"));
		strPassword = strPassword.replaceAll(" ","");
		String strNewPassword =	 thaistring.MS874ToUnicode(request.getParameter("strNewPassword"));
		strNewPassword =	 strNewPassword.replaceAll(" ","");

		teacher.changePassword(strPassword,strNewPassword);

		response.sendRedirect("Profile_Teacher.jsp");
%>
<% } %>
