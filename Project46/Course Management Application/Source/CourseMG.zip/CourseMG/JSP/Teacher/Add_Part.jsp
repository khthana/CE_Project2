<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) { response.sendRedirect("../log_in.jsp"); 
} else {%>
<%	
		String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String idExSet =	 thaistring.MS874ToUnicode(request.getParameter("idExSet"));
		String no =	 thaistring.MS874ToUnicode(request.getParameter("no"));
		String type    =	 thaistring.MS874ToUnicode(request.getParameter("type"));
		String scoreWeight    =	 thaistring.MS874ToUnicode(request.getParameter("scoreWeight"));

		if (idSubject == null)  idSubject = "";
		if (idExSet == null)  idExSet = "";
		if (scoreWeight  == null)  scoreWeight   = "";
		if (no  == null)  no   = "";

		 scoreWeight   = scoreWeight.replaceAll(" ","");
		idSubject = idSubject.replaceAll(" ","");
		idExSet = idExSet.replaceAll(" ","");
		no = no.replaceAll(" ","");
	


	if (!idExSet.equals("")) {
		 if ((!scoreWeight.equals("")) ||     (!type.equals(" ")) )  {teacher.addPart(type,scoreWeight,idExSet); }
	}

	response.sendRedirect("Subject_ExamTab_ExamSet_Show_Teacher.jsp?idSubject="+idSubject+"&no="+no+"&idExSet="+idExSet);

%>
<%}%>