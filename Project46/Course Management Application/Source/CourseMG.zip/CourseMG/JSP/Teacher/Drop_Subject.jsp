<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
	String ridSubjects[] = request.getParameterValues("ridSubjects");

	if(ridSubjects!= null) {
		for (int i = 0;i<ridSubjects.length;i++){
			ridSubjects[i] = thaistring.MS874ToUnicode(ridSubjects[i]);
			System.out.println(ridSubjects[i]);
			teacher.dropSubject(ridSubjects[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	response.sendRedirect("Subject_SyllabusTab_Teacher.jsp");
%>




<!--- End Footer --->
<% } %>
