<%@ page isErrorPage="true" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <body>
    Receive the exeception: <br>
    <font color=red><%= exception.toString() %></font>
    <BR>
<a href="log_in.jsp">Go to Login Page </a> 
</body>
</html>