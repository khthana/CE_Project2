<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String type1    =	 thaistring.MS874ToUnicode(request.getParameter("type1"));
		String type2    =	 thaistring.MS874ToUnicode(request.getParameter("type2"));
		String type3    =	 thaistring.MS874ToUnicode(request.getParameter("type3"));
		String type4    =	 thaistring.MS874ToUnicode(request.getParameter("type4"));
		String type5    =	 thaistring.MS874ToUnicode(request.getParameter("type5"));
		String type6    =	 thaistring.MS874ToUnicode(request.getParameter("type6"));
		String type7    =	 thaistring.MS874ToUnicode(request.getParameter("type7"));
		String type8    =	 thaistring.MS874ToUnicode(request.getParameter("type8"));
		String type9    =	 thaistring.MS874ToUnicode(request.getParameter("type9"));
		String type10  =	 thaistring.MS874ToUnicode(request.getParameter("type10"));
		String type11  =	 thaistring.MS874ToUnicode(request.getParameter("type11"));
		String type12  =	 thaistring.MS874ToUnicode(request.getParameter("type12"));
		String type13  =	 thaistring.MS874ToUnicode(request.getParameter("type13"));
		String type14  =	 thaistring.MS874ToUnicode(request.getParameter("type14"));
		String type15  =	 thaistring.MS874ToUnicode(request.getParameter("type15"));
		String weight1    =	 thaistring.MS874ToUnicode(request.getParameter("weight1"));
		String weight2    =	 thaistring.MS874ToUnicode(request.getParameter("weight2"));
		String weight3    =	 thaistring.MS874ToUnicode(request.getParameter("weight3"));
		String weight4    =	 thaistring.MS874ToUnicode(request.getParameter("weight4"));
		String weight5    =	 thaistring.MS874ToUnicode(request.getParameter("weight5"));
		String weight6    =	 thaistring.MS874ToUnicode(request.getParameter("weight6"));
		String weight7    =	 thaistring.MS874ToUnicode(request.getParameter("weight7"));
		String weight8    =	 thaistring.MS874ToUnicode(request.getParameter("weight8"));
		String weight9    =	 thaistring.MS874ToUnicode(request.getParameter("weight9"));
		String weight10  =	 thaistring.MS874ToUnicode(request.getParameter("weight10"));
		String weight11  =	 thaistring.MS874ToUnicode(request.getParameter("weight11"));
		String weight12  =	 thaistring.MS874ToUnicode(request.getParameter("weight12"));
		String weight13  =	 thaistring.MS874ToUnicode(request.getParameter("weight13"));
		String weight14  =	 thaistring.MS874ToUnicode(request.getParameter("weight14"));
		String weight15  =	 thaistring.MS874ToUnicode(request.getParameter("weight15"));



		if (idSubject == null)  idSubject = "";
		if (weight1  == null)  weight1   = "";
		if (weight2  == null)  weight2   = "";
		if (weight3  == null)  weight3   = "";
		if (weight4  == null)  weight4   = "";
		if (weight5  == null)  weight5   = "";
		if (weight6  == null)  weight6   = "";
		if (weight7  == null)  weight7   = "";
		if (weight8  == null)  weight8   = "";
		if (weight9  == null)  weight9   = "";
		if (weight10== null) weight10 = "";
		if (weight11== null) weight11 = "";
		if (weight12== null) weight12 = "";
		if (weight13== null) weight13 = "";
		if (weight14== null) weight14 = "";
		if (weight15== null) weight15 = "";

		System.out.println(idSubject);
		System.out.println(weight1);
		System.out.println(weight2);
		System.out.println(weight3);
		System.out.println(weight4);
		System.out.println(weight5);
		System.out.println(weight6);
		System.out.println(weight7);
		System.out.println(weight8);
		System.out.println(weight9);
		System.out.println(weight10);
		System.out.println(weight11);
		System.out.println(weight12);
		System.out.println(weight13);
		System.out.println(weight14);
		System.out.println(weight15);
		System.out.println(type1);
		System.out.println(type2);
		System.out.println(type3);
		System.out.println(type4);
		System.out.println(type5);
		System.out.println(type6);
		System.out.println(type7);
		System.out.println(type8);
		System.out.println(type9);
		System.out.println(type10);
		System.out.println(type11);
		System.out.println(type12);
		System.out.println(type13);
		System.out.println(type14);
		System.out.println(type15);

		 weight1   = weight1.replaceAll(" ","");
		 weight2   = weight2.replaceAll(" ","");
		 weight3   = weight3.replaceAll(" ","");
		 weight4   = weight4.replaceAll(" ","");
		 weight5   = weight5.replaceAll(" ","");
		 weight6   = weight6.replaceAll(" ","");
		 weight7   = weight7.replaceAll(" ","");
		 weight8   = weight8.replaceAll(" ","");
		 weight9   = weight9.replaceAll(" ","");
		 weight10 = weight10.replaceAll(" ","");
		 weight11 = weight11.replaceAll(" ","");
		 weight12 = weight12.replaceAll(" ","");
		 weight13 = weight13.replaceAll(" ","");
		 weight14 = weight14.replaceAll(" ","");
		 weight15 = weight15.replaceAll(" ","");
		idSubject = idSubject.replaceAll(" ","");
	
		String idExSet = "";
		if (
			 ((!weight1.equals("")) &&     (!type1.equals(" ")) ) || 
			 ((!weight2.equals("")) &&     (!type2.equals(" ")) ) ||	
			 ((!weight3.equals("")) &&     (!type3.equals(" "))) ||
			 ((!weight4.equals("")) &&     (!type4.equals(" "))) ||
			 ((!weight5.equals("")) &&     (!type5.equals(" ")) ) ||	
			 ((!weight6.equals("")) &&     (!type6.equals(" ")) ) ||	
			 ((!weight7.equals("")) &&     (!type7.equals(" "))) || 	
			 ((!weight8.equals("")) &&     (!type8.equals(" ")) ) ||	
			 ((!weight9.equals("")) &&     (!type9.equals(" ")) ) ||	
			 ((!weight10.equals("")) &&  (!type10.equals(" "))) || 
			 ((!weight11.equals("")) &&  (!type11.equals(" "))) || 
			( (!weight12.equals("")) &&  (!type12.equals(" "))) || 
			( (!weight13.equals("")) &&  (!type13.equals(" "))) || 
			( (!weight14.equals("")) &&  (!type14.equals(" "))) || 
			( (!weight15.equals("")) &&  (!type15.equals(" "))) 
		)  { idExSet = teacher.addExSet("0",idSubject); }
				System.out.println(idExSet);


	if (!idExSet.equals("")) {
		 if ((!weight1.equals("")) ||     (!type1.equals(" ")) )  {System.out.println("111111111111111111");
teacher.addPart(type1,weight1,idExSet); }
		 if ((!weight2.equals("")) ||     (!type2.equals(" ")) )	{System.out.println("22222222"); teacher.addPart(type2,weight2,idExSet); }
		 if ((!weight3.equals("")) ||     (!type3.equals(" "))) 	{System.out.println("333333333");  teacher.addPart(type3,weight3,idExSet); }
		 if ((!weight4.equals("")) ||     (!type4.equals(" "))) 	{System.out.println("44444444");  teacher.addPart(type4,weight4,idExSet); }
		 if ((!weight5.equals("")) ||     (!type5.equals(" ")) )	{System.out.println("5555555");  teacher.addPart(type5,weight5,idExSet); }
		 if ((!weight6.equals("")) ||     (!type6.equals(" ")) )	{System.out.println("66666665");  teacher.addPart(type6,weight6,idExSet); }
		 if ((!weight7.equals("")) ||     (!type7.equals(" "))) 	{System.out.println("77777777");  teacher.addPart(type7,weight7,idExSet); }
		 if ((!weight8.equals("")) ||     (!type8.equals(" ")) )	{System.out.println("888888888");  teacher.addPart(type8,weight8,idExSet); }
		 if ((!weight9.equals("")) ||     (!type9.equals(" ")) )	{System.out.println("99999999");  teacher.addPart(type9,weight9,idExSet); }
		 if ((!weight10.equals("")) ||  (!type10.equals(" "))) {System.out.println("aaaaaaaaa"); teacher.addPart(type10,weight10,idExSet);  }
		 if ((!weight11.equals("")) ||  (!type11.equals(" "))) {System.out.println("bbbbbbb"); teacher.addPart(type11,weight11,idExSet);  }
		if ( (!weight12.equals("")) ||  (!type12.equals(" "))) {System.out.println("ccccccccc"); teacher.addPart(type12,weight12,idExSet);  }
		if ( (!weight13.equals("")) ||  (!type13.equals(" "))) {System.out.println("dddddddddd"); teacher.addPart(type13,weight13,idExSet);  }
		if ( (!weight14.equals("")) ||  (!type14.equals(" "))) {System.out.println("eeeeeeeee"); teacher.addPart(type14,weight14,idExSet);  }
		if ( (!weight15.equals("")) ||  (!type15.equals(" "))) {System.out.println("fffffffffff"); teacher.addPart(type15,weight15,idExSet);  }
	}

	response.sendRedirect("Subject_ExamTab_ExamSet_Teacher.jsp?idSubject="+idSubject);

%>
<%}%>