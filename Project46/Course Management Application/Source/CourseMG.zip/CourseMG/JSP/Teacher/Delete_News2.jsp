<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
	String checkdelete[] = request.getParameterValues("checkdelete");
	System.out.println(checkdelete[0]);
	System.out.println("aaaaaaaaaaaaaaaaaaaaaa");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			System.out.println(checkdelete[i]);
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			teacher.deleteNews(checkdelete[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
	response.sendRedirect("News_Teacher.jsp");
%>
<% } %>



