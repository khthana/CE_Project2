<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
			ridSubject = ridSubject.replaceAll(" ","");

	String idStudents[] = request.getParameterValues("idStudent");
	String scores[] = request.getParameterValues("score");
	if(idStudents!= null) {
		for (int i = 0;i<idStudents.length;i++){
			idStudents[i] = thaistring.MS874ToUnicode(idStudents[i]);
			scores[i] = thaistring.MS874ToUnicode(scores[i]);
			teacher.fillScoreFinal(idStudents[i],ridSubject,scores[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}

//		teacher.editRemind(ridRemind,rstrTopic,rstrDescription,rdateDate,rdateTime,rstrWarningType,rdateWarningDate);
		response.sendRedirect("Subject_ScoreTab_View_Teacher.jsp?idSubject="+ridSubject);

%>
<% } %>