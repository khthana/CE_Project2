<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) { response.sendRedirect("../log_in.jsp"); 
} else {%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String strTopicName =	 thaistring.MS874ToUnicode(request.getParameter("strTopicName"));
		String strTopicDescription =	 thaistring.MS874ToUnicode(request.getParameter("strTopicDescription"));

		teacher.addTopic(strTopicName,strTopicDescription,teacher.getidTeacher(),"Teacher",ridSubject);
		response.sendRedirect("Subject_WebboardTab_Detail_Teacher.jsp?idSubject="+ridSubject);

%>
<%}%>