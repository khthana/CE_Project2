<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String rcurriculum =	 thaistring.MS874ToUnicode(request.getParameter("curriculum"));
//		rcurriculum = rcurriculum.replaceAll(" ","");
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		ridSubject =	 ridSubject.replaceAll(" ","");
		String rthaiName =	 thaistring.MS874ToUnicode(request.getParameter("thaiName"));
//		rthaiName = rthaiName.replaceAll(" ","");
		String rengName =	 thaistring.MS874ToUnicode(request.getParameter("engName"));
//		rengName = rengName.replaceAll(" ","");
		String rcredit =	 thaistring.MS874ToUnicode(request.getParameter("credit"));
		rcredit = rcredit.replaceAll(" ","");
		String rrequireSubject =	 thaistring.MS874ToUnicode(request.getParameter("requireSubject"));
//		rrequireSubject = rrequireSubject.replaceAll(" ","");
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("description"));
//		rdescription = rdescription.replaceAll(" ","");
		String rtimeStudy =	 thaistring.MS874ToUnicode(request.getParameter("timeStudy"));
//		rtimeStudy = rtimeStudy.replaceAll(" ","");
		String rscaleMidterm =	 thaistring.MS874ToUnicode(request.getParameter("scaleMidterm"));
		rscaleMidterm = rscaleMidterm.replaceAll(" ","");
		String rscaleFinal =	 thaistring.MS874ToUnicode(request.getParameter("scaleFinal"));
		rscaleFinal = rscaleFinal.replaceAll(" ","");
		String rscaleQuiz =	 thaistring.MS874ToUnicode(request.getParameter("scaleQuiz"));
		rscaleQuiz = rscaleQuiz.replaceAll(" ","");
		String rscaleAssignment =	 thaistring.MS874ToUnicode(request.getParameter("scaleAssignment"));
		rscaleAssignment = rscaleAssignment.replaceAll(" ","");
		String rscaleLab =	 thaistring.MS874ToUnicode(request.getParameter("scaleLab"));
		rscaleLab = rscaleLab.replaceAll(" ","");
		String rtimeTalking =	 thaistring.MS874ToUnicode(request.getParameter("timeTalking"));
//		rtimeTalking = rtimeTalking.replaceAll(" ","");
		String rtextBook =	 thaistring.MS874ToUnicode(request.getParameter("textBook"));
//		rtextBook = rtextBook.replaceAll(" ","");
		String rmagicNumber =	 thaistring.MS874ToUnicode(request.getParameter("magicNumber"));
//		rtextBook = rtextBook.replaceAll(" ","");
teacher.editSubject(ridSubject,rthaiName,rengName,rdescription,rcurriculum,"0",rcredit,rrequireSubject,rtimeStudy,rscaleMidterm,rscaleFinal,rscaleQuiz,rscaleAssignment,rscaleLab,rtextBook,rtimeTalking);
		teacher.editMagicNum(ridSubject,rmagicNumber);
		System.out.println("aaaaaaaa");
		response.sendRedirect("Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject="+ridSubject);
%>
<% } %>