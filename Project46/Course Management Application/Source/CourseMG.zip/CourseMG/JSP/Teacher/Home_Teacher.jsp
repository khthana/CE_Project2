<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: H o m e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: H o m e ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	

               

<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0" /></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>



<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/home.gif" width="100" height="20" border="0"><img src="Picture/middle.gif" width="480" height="20" border="0"><img src="Picture/Space_Menu.gif" width="1464%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            <p>
			  <a href="Home_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home_Selected.gif" /></a><br />
              <a href="News_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Teacher.jsp?date=<%=teacher.getnewday()%>" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
			  <a href="Subject_SyllabusTab_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject.gif"  /></a><br />
              <a href="Webboard_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="Assignment_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a><br />
              <a href="Exam_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Examiantion" width="170" height="25" src="Picture\Menu_Examination.gif" /></a><br />
			  </p>
              
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
		    <table width="158" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><div align="left"><span class="detaildarkblue">
				        <%=teacher.getname()%> : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Teacher.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Edit_Teacher.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->



<!--- Begin Body --->
 <td width="9" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>
          <td width="500"> <table width="500" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
            <tr> </tr>
            <tr>
              <td height="1">
                <table width="500" height="*"  border="0" align="center" cellpadding="0" cellspacing="0">
                  <tbody>
                    <tr>
                      <td width="500" height="*" align="left" valign="top">
                        <table width="100%" height="*" border="1" align="center" bordercolor="#FFFFFF"  >
                          <tbody>
                            <tr>
                            <td colspan="4" ><a href="News_Teacher.jsp"><img src="Picture/general_news2.gif" width="110" height="20" border="0"></a><img src="Picture/middle.gif" width="200" height="20" border="0"><img src="Picture/end.gif" width="190" height="20" border="0"></td>
                          </tr>
                            <tr valign="top">
                              <td>
                                <table cellspacing="0" cellpadding="1" border="0">
                                  <tbody>
                         <%String[] idGeneralNews = teacher.queryidGeneralNewsesForPeriod();%>
						  <%for(int i = 0 ; i < idGeneralNews.length ; i++) { %>
                         		 <%ClassMGR.News.News news = teacher.queryNews(idGeneralNews[i]);%>  	
                                  	<tr valign="top">
                                      <td width="1">&nbsp;</td>
                                      <td class="detailgreen" width="55"><%=helper.convertDate(news.getdatePost())%></td>
                                      <td width="456" class="normal"><a href="News_Detail.jsp?idNews=<%=news.getidNews()%>" class="detailblue" target="_blank"><%=news.gettopic()%></a></td>
                                    </tr>
                         <% }  %>
						<%String[] idSubjects = teacher.queryidSubjectsTeaching()	;%> 
						  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
                         	  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
							 <tr>
                              <td  colspan="3"height="26"><a href="Subject_NewsTab_View_Teacher.jsp?idSubject=<%=subject.getidSubject()%>" class="detaildarkblue"><%=subject.getnameEng()%></a></td>
                             </tr>
							 <%String[] idNews = teacher.queryidNewsesForPeriod(idSubjects[i]);%>
							  <%for(int j = 0 ; j < idNews.length ; j++) { %>
									 <%ClassMGR.News.News news = teacher.queryNews(idNews[j]);%>  	
										<tr valign="top">
										  <td width="1">&nbsp;</td>
										  <td class="detailgreen" width="55"><%=helper.convertDate(news.getdatePost())%></td>
										  <td width="456" class="normal"><a target="_blank" href="Subject_NewsTab_Detail_Teacher.jsp?idSubject=<%=idSubjects[i]%>&idNews=<%=news.getidNews()%>" class="detailblue"><%=news.gettopic()%></a></td>
										</tr>
							   <% }  %>
							<% }  %>
                                  </tbody>
                              </table></td>
                            </tr>
                          </tbody>
                        </table>
                        <table width="100% "  align="center" border="0" 
                        name="News Table">
                          <tbody>
                          </tbody>
                        </table>
                        <table width="100%" align="center" border="0"  >
                          <tbody>
                            <tr>
                              
                            </tr>
                          </tbody>
                      </table>
                        <hr /></td>
                    </tr>
                    <tr>
                      <td> <table width="100%" height="*" border="0" align="center"  >
                          <tbody>
                            <tr>
                            <td colspan="4" bordercolor="#FFFFFF" bgcolor="#FFFFFF" ><img src="Picture/webboard1.gif" width="87" height="20" border="0" /><img src="Picture/middle.gif" width="200" height="20" border="0"><img src="Picture/end.gif" width="213" height="20" border="0"></td>
                          </tr>
                            <tr valign="top">
                              <td bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                                <table cellspacing="0" cellpadding="1" border="0">
                                  <tbody>
  						  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
                         	  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	                                 
                          <tr valign="top">                             
                              <td  colspan="2" width="438" class="normal"> <a href="Subject_WebboardTab_Detail_Teacher.jsp?idSubject=<%=subject.getidSubject()%>" class="detailblue" ><%=subject.getnameEng()%></a></td>
                            </tr>
							 <%String[] idTopics = teacher.queryidTopicsForPeriod(idSubjects[i]);%>
							  <%for(int j = 0 ; j < idTopics.length ; j++) { %>
									 <%ClassMGR.Webboard.Topic topic = teacher.queryTopic(idTopics[j]);%>  	
                           <tr valign="top">
                              <td colspan="2 width="438" class="normal"> <p>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="Subject_WebboardTab_Reply_Teacher.jsp?idSubject=<%=idSubjects[i]%>&idTopic=<%=topic.getidTopic()%>" class="detaillightblue" target="_blank"><%=topic.getname()%></a></p></td>
                            </tr>
							 <% }  %>
						    <tr valign="top">
                              
                              <td  colspan="2"width="438" class="normal"> </td>
                            </tr>
							<tr valign="top">
					  <% }  %>         
                                  </tbody>
                              </table></td>
                            </tr>
                          </tbody>
                        </table></td>
                    </tr>
                    <tr valign="top">
                      <td><hr /></td>
                    </tr>
					  
					  <tr>
                      <td> 
  
					  <table width="100%" height="*" border="0" align="center"  >
                          <tbody>
<!--                            <tr>
                            <td colspan="4" bordercolor="#FFFFFF" bgcolor="#FFFFFF" ><img src="Picture/message1.gif" width="76" height="20" border="0"><img src="Picture/middle.gif" width="200" height="20" border="0"><img src="Picture/end.gif" width="222" height="20" border="0"></td>
                          </tr>
      -->                      
							<tr valign="top">
                              <td height="*" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                                <table width="501" border="0" cellpadding="1" cellspacing="0">
                                  <tbody>
                         <%//String[] idMsgs = teacher.queryidMsgs();%>
						  <%//for(int i = 0 ; i < idMsgs.length ; i++) { %>
                         		 <%//ClassMGR.Msg.Msg msg = teacher.queryMsg(idMsgs[i]);%>  	
                          <tr valign="top">
                              <td colspan="2 width="438" class="normal"> <p>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="message_view.jsp?id=<%//=msg.getidMsg()%>" class="detaillightblue"><%//=msg.gettopic()%></a></p></td>
                            </tr>
                           <%// }  %>                
                                  </tbody>
                              </table></td>
                            </tr>
                          </tbody>
                        </table>
			
						</td>
                    </tr>
                    <tr valign="top">
                      <td>
                   
                 
                   
                   
                  
                
                   
                   
				   
                
                    
                  
                  
                     
                  </tbody>
                </table>
                </td>
				
             
            
            </tr>
            <!--Display the spacer line if there is no graphical header (text only)-->
            <!--- Display local nav (if used)--->
            <!--- Local Nav --->
            <!---BUILD OUT PARTNERS NAV--->
            <!--- End Local Nav --->
         
          
            <tr>
     
            </tr>
          </table></td>	
		  <td width="9" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
    </td>
	  <td width="9" align="left" valign="top" height="384"> 

 <table width="219" height="382" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="55" colspan="3"><img src="Picture/schedule_home.gif" width="228" height="58" border="0" /></td>
                  </tr>
                  <tr>
                    <td width="10" height="300" background="Picture/action_bg-left.gif" ><img src="Picture\action_bg-left.gif" width="17" height="330" border="0" /></td>
                    <td width="199" class="small">                    <table border="0" cellpadding="3" cellspacing="0" width="184" height="271">
                      <tr valign="top">
                        <td width="192" height="182" colspan="2"> <span> </span>
                            <table width="100%" border="1" bordercolor="#66CC00">
                              <tr class="detailblack">
                                <td colspan="7" align="center"><strong><font color="#000000"><%=helper.convertToNameMonth(teacher.getnewday())%></font></strong></td>
							  </tr>
                              <tr class="detailblack">
                                <td width="10%">S</td>
                                <td width="10%">M</td>
                                <td width="10%">T</td>
                                <td width="10%">W</td>
                                <td width="10%">T</td>
                                <td width="10%">F</td>
                                <td width="10%">S</td>
                              </tr>
							  <tr class="detailblack">
                              <%int firstDay = helper.queryFirstDayForThisMonth();%>
							  <%String lastDate = helper.queryLastDateForThisMonth();%>
							  <% int count = 0; %>
							  <% for(int i = 1 ; i <=Integer.parseInt(lastDate) ; count++) { %>
									<%	if (count == 7) { %>
										</tr>
										<tr class="detailblack">
										<%count = 0;%>
									<% } %>
									<%	if ((i == 1) && ((firstDay-1) != count)){ %>
											<td>&nbsp;</td>
									<% } else { %>
											<%	if (i == helper.querySysDate()) { %>
												<td bgcolor="#99FF66" ><%=i%></td>
											<%} else {%>
												<td><%=i%></td>
											<% } %>
											<%i++;%>
									<% } %>
							<% } %>
							<% for(int i = count ; i < 7 ; i++) { %>
									<td>&nbsp;</td>
							<% } %>
							</tr>
                            </table>
                        <span> </span> </td>
                      </tr>
                      <tr valign="top">
                        <td>
                          <p><span><a href="Schedule_Teacher.jsp?date=<%=teacher.getnewday()%>" class="detaildarkblue">To Do List</a></span></p>
						  <%String[] idReminds = teacher.queryidRemindsForThisDate();%>
						  <%for(int i = 0 ; i < idReminds.length ; i++) { %>
                         	  <%ClassMGR.Schedule.Remind remind = teacher.queryRemind(idReminds[i]);%>  	
							 <p><span class="detailblack"><%=remind.gettime()%> - <a href="Schedule_Teacher.jsp?date=<%=teacher.getnewday()%>&id=<%=idReminds[i]%>" class="detailblue"><%=remind.gettopic()%> </a></span></p>
                          <% } %>
						  </td>
                      </tr>
                    </table></td>
                    <td width="10" background="Picture/action_bg-right.gif"><img src="Picture/action_bg-right.gif"  width="10" height="327" border="0" /></td>
                  </tr>
                  <tr valign="bottom">
                    <td colspan="3"><img src="Picture/action-bottom-185.gif" width="226" height="27" border="0" /></td>
                  </tr>
            </table>
			<br />
    <table border="0" cellpadding="0" cellspacing="0" width="217">
      <tr bgcolor="#333366">
        <td width="23" valign="top"><img src="Picture\element-topleft.gif"  width="11" height="23" border="0" /></td>
        <td width="166" class="smalltextbold"><b><font color="#66CC00">Chat Room</font></b></td>
        <td width="28" valign="top" align="right"><img src="Picture\element-topright.gif" width="8" height="22" border="0" /></td>
      </tr>
      <tr>
        <td width="23" background="Picture\element_bg-left.gif" ><img src="Picture\element_bg-left.gif" width="26" height="179" border="0" /></td>
        <td width="166" class="smalltext"> 
            <table cellpadding="5" cellspacing="0" border="0" width="165">
			  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
                   <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
              <tr valign="top">
                <td colspan="2" class="detailblack"><span class="detailhead"><a href="http://161.246.6.70:8080/jchatbox/skin_multilanguage/login.jsp?name=<%=teacher.getidTeacher()%>&chatrooms=<%=idSubjects[i]%>" target="_blank"><%=subject.getnameEng()%></a> :</span> Student 0<br />
            Teacher1 0</td>
              </tr>
              <tr valign="top">
                <td colspan="2" class="detailblack">&nbsp;</td>
              </tr>
			 <% } %>
            </table>
            <br />
            </td>
        <td width="28" ><img src="Picture\element_bg-right.gif"  width="26" height="177" border="0" /></td>
      </tr>
      <tr valign="bottom">
        <td colspan="3"><img src="Picture\element-bottom-185.gif"width="217" height="19" border="0" /></td>
      </tr>
    </table></td>

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
	  </table>	  </td>
  </tr>
	
	
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->
<% } %>