<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  response.sendRedirect("../log_in.jsp"); %>
<%	
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: P r o f i l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: P r o f i l e ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
    <link href="style1.css" rel="stylesheet" type="text/css" />
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="210">
		
		


<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->

<td width="738">
	<table border="0" cellspacing="0" cellpadding="0" width="736">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr> 
			    <td>                  
                    <form action="" method="Post">
		                <table width="76%" border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="14296F" bgcolor="EFFAD1">
                          <tr bgcolor="#FFFFFF" background="Picture/bg.gif">
                            <td colspan="4" class="headerdarkblue"><img name="lmenu_id_r1_c1" src="Picture/t_profile1.gif" width="120" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="435" height="20" border="0" /><a href="Profile_Edit_Teacher.jsp"><img name="lmenu_id_r1_c1" src="Picture/b_edit.gif" width="40" height="20" border="0" /></a></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151" align="right" bordercolor="87F59B" class="detailblue"><div align="right">����-���ʡ�� :: </div></td>
                            <td width="325" bordercolor="87F59B" class="detaildarkblue" ><%=teacher.getname()%> <%=teacher.getsurname()%></td>
                            <td width="152"rowspan="3" bordercolor="87F59B"><img name="" 	src="../Upload/Picture/<%=teacher.getpicture().toLowerCase()%>" 			width="150" height="150" alt="" /></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" bordercolor="87F59B" class="detailblue"><div align="right">���˹� :: </div></td>
                            <td width="325" class="detaildarkblue"><%=teacher.getRole()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" bordercolor="87F59B" class="detailblue"><div align="right">����ѵԡ���֡�� :: </div></td>
                            <td width="325" class="detaildarkblue"><%=teacher.getqualification()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">�Ԫҷ���͹ :: </td>
							<td colspan="2" bordercolor="87F59B" class="detaildarkblue">
							<%String[] idSubjects = teacher.queryidSubjectsTeaching()	;%> 
							  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
									  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
								 <a class="sidelink" href="Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject=<%=subject.getidSubject()%>" > -  <%=subject.getnameEng()%></a> <br />
							<% }  %>
							</td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">�ŧҹ�ҧ�Ԫҡ�� :: </td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getresearch()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">����ʹ� :: </td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getinteresting()%></td>
                          </tr>
                           <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">���ʺ��ó� :: </td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getexp()%></td>
                          </tr>
                         <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">�ԧ����ǹ��� :: </td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getlink()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">������ :: </td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getemail()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">�������Ѿ�� ::</td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.gettel()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">��ͧ�ӧҹ ::</td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getcontactroom()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
                            <td width="151"  align="right" class="detailblue">������Ҿ� ::</td>
                            <td colspan="2" bordercolor="87F59B" class="detaildarkblue"><%=teacher.getmeetingTime()%></td>
                          </tr>
                          <tr bordercolor="87F59B">
			<td colspan = "3" align="center" >
				<img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="250" height="20" border="0" /><a href="Home_Teacher.jsp"><img name="lmenu_id_r1_c1" src="Picture/home.gif" width="90" height="20" border="0" /></a><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="258" height="20" border="0" />
			</td>
		</tr>
	   <tr bordercolor="87F59B">
			<td colspan = "3" align="center" >
				<img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="250" height="20" border="0" /><a href="PasswordChange.jsp"><img name="lmenu_id_r1_c1" src="ChangePass.gif" width="126" height="20" border="0" /></a><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="222" height="20" border="0" />
			</td>
		</tr>
                         <tr bordercolor="EFFAD1"></tr>
						  <tr bordercolor="EFFAD1"></tr>
                      </table>
                    </form>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
				
		</tr>
		 <tr bordercolor="#FFFFFF">
                            <td width="200 >&nbsp;</td>
                            <td colspan="2" bordercolor="#FFFFFF" >&nbsp;</td>
              </tr>
	</table>

</td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
			  <tr></tr>
		  </table>
				
	  </td>
  </tr>
  <tr></tr>
	</table>
	
<table width="1024" bgcolor="#FFFFFF" >
  <tr>

  </tr>
</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
