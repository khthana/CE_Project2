<%@ page language="java" contentType="text/html; charset=windows-874" %>
<jsp:useBean id="authen" class="ClassMGR.User.Authenticate" scope="session" />
<%@ page import="ClassMGR.User.*" %>
<%
	session.removeAttribute("auth"); // remove existing session
	String user_id=new String();
	String password=new String();
	if( request.getMethod().equals("POST") ){ // prove is redirect from page use post method
		if( request.getParameter("user_id") != null ){
			user_id=request.getParameter("user_id");
			//pageContext.forward("log_in.jsp");
			System.out.println(user_id+"asdasd "+password);
			if( request.getParameter("password") != null ){
				password=request.getParameter("password");
				System.out.println(user_id+" "+password);
				//pageContext.forward("log_in.jsp");
				Role authority = authen.login("teacher1","asd");
//				pageContext.forward("log_in.jsp");
				if( authority != null ){
					System.out.println(authority.getRole());
				    if( authority.getRole().equals("WebMaster") ){
						session.setAttribute("auth",(WM)authority);
						pageContext.forward("Admin_Menu_Pre_Register.jsp");
					}else 
					if (authority.getRole().equals("Teacher") ){
						session.setAttribute("auth",(Teacher)authority);
						response.sendRedirect("Home_Teacher.jsp");
					}
					/*else if (authority.getRole().equals("Student") ){
						session.setAttribute("auth",(Student)authority);
						pageContext.forward("Std_Main.jsp");
					}*/
				}else
					throw new Exception("Login Fail");
			}else
				throw new Exception("You must Enter Password");
		}else
			throw new Exception("You must Enter User-id");
	}else
		throw new Exception("You Shall NOT PASS");
%>
123