<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String idQuestion =	 thaistring.MS874ToUnicode(request.getParameter("idQuestion"));
		String description =	 thaistring.MS874ToUnicode(request.getParameter("description"));
		String rank =	 thaistring.MS874ToUnicode(request.getParameter("rank"));
		String type =	 thaistring.MS874ToUnicode(request.getParameter("type"));
		String idAns1 =	 thaistring.MS874ToUnicode(request.getParameter("idAns1"));
		String idAns2 =	 thaistring.MS874ToUnicode(request.getParameter("idAns2"));
 		String idAns3 =	 thaistring.MS874ToUnicode(request.getParameter("idAns3"));
		String idAns4 =	 thaistring.MS874ToUnicode(request.getParameter("idAns4"));
		String idAns5 =	 thaistring.MS874ToUnicode(request.getParameter("idAns5"));
		String descAns1 =	 thaistring.MS874ToUnicode(request.getParameter("descAns1"));
		String descAns2 =	 thaistring.MS874ToUnicode(request.getParameter("descAns2"));
 		String descAns3 =	 thaistring.MS874ToUnicode(request.getParameter("descAns3"));
		String descAns4 =	 thaistring.MS874ToUnicode(request.getParameter("descAns4"));
		String descAns5 =	 thaistring.MS874ToUnicode(request.getParameter("descAns5"));
		String collectAns =	 thaistring.MS874ToUnicode(request.getParameter("collectAns"));

		if (idAns1 == null)  idAns1 = "";
		if (idAns2 == null)  idAns2 = "";
		if (idAns3 == null)  idAns3 = "";
		if (idAns4 == null)  idAns4 = "";
		if (idAns5 == null)  idAns5 = "";
		if (collectAns == null)  collectAns = "";
		if (rank == null)  rank = "";

		 rank = rank.replaceAll(" ","");
		 idAns1 = idAns1.replaceAll(" ","");
		 idAns2 = idAns2.replaceAll(" ","");
 		 idAns3 = idAns3.replaceAll(" ","");
		 idAns4 = idAns4.replaceAll(" ","");
		 idAns5 = idAns5.replaceAll(" ","");
		 descAns1 = descAns1.replaceAll(" ","");
		 descAns2 = descAns2.replaceAll(" ","");
 		 descAns3 = descAns3.replaceAll(" ","");
		 descAns4 = descAns4.replaceAll(" ","");
		 descAns5 = descAns5.replaceAll(" ","");
		 collectAns = collectAns.replaceAll(" ","");
		idSubject = idSubject.replaceAll(" ","");
		idQuestion = idQuestion.replaceAll(" ","");
		

	  	if ((!descAns1.equals("")) && (!idAns1.equals(""))) { teacher.editAnswer(idAns1,descAns1); }
	  	if ((!descAns2.equals("")) && (!idAns2.equals(""))) { teacher.editAnswer(idAns2,descAns2); }
	  	if ((!descAns3.equals("")) && (!idAns3.equals(""))) { teacher.editAnswer(idAns3,descAns3); }
	  	if ((!descAns4.equals("")) && (!idAns4.equals(""))) { teacher.editAnswer(idAns4,descAns4); }
	  	if ((!descAns5.equals("")) && (!idAns5.equals(""))) { teacher.editAnswer(idAns5,descAns5); }

	  	if ((!descAns1.equals("")) && (idAns1.equals(""))) { idAns1 = teacher.addAnswer(descAns1,idQuestion);}
	  	if ((!descAns2.equals("")) && (idAns2.equals(""))) { idAns2 = teacher.addAnswer(descAns2,idQuestion);}
	  	if ((!descAns3.equals("")) && (idAns3.equals(""))) { idAns3 = teacher.addAnswer(descAns3,idQuestion);}
	  	if ((!descAns4.equals("")) && (idAns4.equals(""))) { idAns4 = teacher.addAnswer(descAns4,idQuestion);}
	  	if ((!descAns5.equals("")) && (idAns5.equals(""))) { idAns5 = teacher.addAnswer(descAns5,idQuestion);}

		if ((descAns1.equals("")) && (!idAns1.equals(""))) { teacher.deleteAnswer(idAns1); }
	  	if ((descAns2.equals("")) && (!idAns2.equals(""))) { teacher.deleteAnswer(idAns2); }
	  	if ((descAns3.equals("")) && (!idAns3.equals(""))) { teacher.deleteAnswer(idAns3); }
	  	if ((descAns4.equals("")) && (!idAns4.equals(""))) { teacher.deleteAnswer(idAns4); }
	  	if ((descAns5.equals("")) && (!idAns5.equals(""))) { teacher.deleteAnswer(idAns5); }
		
		String collectidAns = "";
		for (int i=0; (i*2)< collectAns.length() ; i=i+1) {
			String tmp = collectAns.substring(i*2,i*2+1);
		System.out.println(i);
		System.out.println(tmp);
			if (tmp.equals("1") && (!descAns1.equals("") ) && (!idAns1.equals("0") )) collectidAns = collectidAns + idAns1 + ";";
			if (tmp.equals("2") && (!descAns2.equals("") ) && (!idAns2.equals("0") )) collectidAns = collectidAns + idAns2 + ";";
			if (tmp.equals("3") && (!descAns3.equals("") ) && (!idAns3.equals("0") )) collectidAns = collectidAns + idAns3 + ";";
			if (tmp.equals("4") && (!descAns4.equals("") ) && (!idAns4.equals("0") )) collectidAns = collectidAns + idAns4 + ";";
			if (tmp.equals("5") && (!descAns5.equals("") ) && (!idAns5.equals("0") )) collectidAns = collectidAns + idAns5 + ";";
		}
		System.out.println(collectidAns);
		//teacher.addQuestion(description,type,idSubject,teacher.getidTeacher(),collectidAns)
		teacher.editQuestion(idQuestion,description,type,collectidAns,rank);

	response.sendRedirect("Subject_ExamTab_ExamQuestion"+type+"_Show_Teacher.jsp?idSubject="+idSubject+"&idQuestion="+idQuestion);

%>
<% } %>