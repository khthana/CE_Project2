<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
	String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		if (idSubject == null)  idSubject = "";
		idSubject = idSubject.replaceAll(" ","");

	String no =	 thaistring.MS874ToUnicode(request.getParameter("no"));
		if (no == null)  no = "";
		no = no.replaceAll(" ","");

	String idExSet =	 thaistring.MS874ToUnicode(request.getParameter("idExSet"));
		if (idExSet == null)  idExSet = "";
		idExSet = idExSet.replaceAll(" ","");

	String checkdelete[] = request.getParameterValues("checkdelete");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			teacher.deletePart(checkdelete[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	response.sendRedirect("Subject_ExamTab_ExamSet_Show_Teacher.jsp?idSubject="+idSubject+"&no="+no+"&idExSet="+idExSet);
%>




<!--- End Footer --->
<% } %>
