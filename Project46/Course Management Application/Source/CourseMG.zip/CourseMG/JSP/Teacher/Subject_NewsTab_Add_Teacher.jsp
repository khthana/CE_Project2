<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  response.sendRedirect("../log_in.jsp"); %>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t  N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t  N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
 .



-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="left">
			<table border="0" cellpadding="0" cellspacing="0" width="575">
				<tr>
						<td><a href="Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavproducts" src="Picture/Tab_Syllabus.gif"  width="82" height="25" border="0"></a></td>
   					    <td><a href="Subject_NewsTab_View_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavcustomers" src="Picture/Tab_News_Selected.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_TimetableTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavpartners" src="Picture/Tab_Timetable.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_WebboardTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavsupport" src="Picture/Tab_Webboard.gif" width="82" height="25" border="0"></a></td>
 						<td><a href="Subject_ChatTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdeveloper" src="Picture/Tab_Chat.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_AssignmentTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavcompany" src="Picture/Tab_Assignment.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ExamTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Examination.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ScoreTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Score.gif" width="82" height="25" border="0"></a></td>
						<td width="*"><img name="topnavdeveloper" src="Picture/Tab_Blank.gif" width="171" height="25" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/spacer.gif" width="1464%" height="9" border="0"></td>
	</tr>
</table>

<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="99%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	

		<td width="178">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
   <td width="834">
	<table border="0" cellspacing="0" cellpadding="0" width="650">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
                  <table width="100% "  align="center" border="0" 
                        name="News Table">
                    <tbody>
                    </tbody>
                  </table>
				<form name="form1" id="form1" method="post" action="Add_News.jsp">
                  <table width="100%" border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="14296F" bgcolor="EFFAD1">
                    <tr bgcolor="#FFFFFF" background="Picture/bg.gif">
                      <td colspan="4" class="headerdarkblue"><img src="Picture/add_news.gif" name="lmenu_id_r1_c1" width="110" height="20" border="0" id="lmenu_id_r1_c1" /><img src="Picture/middle.gif" name="lmenu_id_r1_c1" width="400" height="20" border="0" id="lmenu_id_r1_c1" /><img src="Picture/end.gif" name="lmenu_id_r1_c1" width="140" height="20" border="0" id="lmenu_id_r1_c1" /></td>
                    </tr>
                    <tr>
                      <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Topic :: </td>
                      <td width="325" bordercolor="EFFAD1"><textarea name="topic" cols="70" rows="2" id="strPassword3"></textarea></td>
                    </tr>
                    <tr>
                      <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Description :: </td>
                      <td width="325" bordercolor="EFFAD1"><textarea name="description" cols="70" rows="10" id="textarea4"></textarea></td>
                    </tr>
                    <tr>
                      <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">Delete Days :: </td>
                      <td width="325" bordercolor="EFFAD1"><input name="num2Del" type="text" id="strUsername4"   size="12" maxlength="8"/></td>
                    </tr>
                    <tr>
                      <td width="152" align="right" bordercolor="EFFAD1" class="detailblue"> Writer :: </td>
                      <td width="325" bordercolor="EFFAD1" ><input name="namePoster" type="text" id="strUsername4"   size="30" maxlength="30"  disabled  value="<%=teacher.getname()%>" /></td>
                    </tr>
                    <tr>
                      <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">&nbsp; </td>
                      <td width="325" bordercolor="EFFAD1" ><input name="idSubject" type="hidden" id="strUsername4"   size="30" maxlength="30"  value="<%=ridSubject%>" /></td>
                    </tr>
                    <tr bordercolor="EFFAD1">
                      <td width="152"  align="right" ></td>
                      <td colspan="2"><p class="style11">
                          <input name="Add" type="button" id="Add" value="Add" onClick="checknull('Add')" />
                          <input name="Reset" type="reset" id="Reset" value="Reset" />
                          <input name="Cancel" type="button" id="Cancel" value="Back" onclick="window.location='Subject_NewsTab_View_Teacher.jsp?idSubject=<%=ridSubject%>'" />
                        </p>
                          <p >&nbsp; </p></td>
                    </tr>
                    <tr bordercolor="EFFAD1"></tr>
                  </table>
  				</form>

                  <h4>
                    <p align="center">&nbsp;</p>
                    <p align="center">&nbsp;</p>
                </h4></td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
	  </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->

<!--Begin Add Java Script-->
<SCRIPT LANGUAGE="JavaScript">
<!--
//topic, description, num2Del, namePoster
	var doc = document.form1
	function checknull(n){
		if(((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))&&
		(!((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value)))))&&
		(!((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))))
			{alert('��سҡ�͡ Topic');} 
		else if (((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))&&
		(!((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value)))))&&
		(!((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))))
			{alert('��سҡ�͡ Description');} 
		else if (((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))&&
		(!((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value)))))&&
		(!((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))))
			{alert('��سҡ�͡ Delete Days');} 
		else if (((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))&&
		((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))&&
		(!((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))))
			{alert('��سҡ�͡Topic ��� Delete Days');} 
		else if ((!((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value)))))&&
		((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))&&
		((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value)))))
			{alert('��سҡ�͡ Topic ��� Description');} 
		else if (((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value))))&&
		(!((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value)))))&&
		((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value)))))
			{alert('��سҡ�͡ Description ��� Delete Days');} 
		else if (((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))&&
		((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))&&
		((doc.num2Del.value=='')||((doc.num2Del.value!='')&&(isallspace(doc.num2Del.value)))))
			{alert('��س�Topic, Description, DeleteDays');} 
		else {
			doc.submit(); 
		}
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script-->
 
 
