<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
		String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String idExSet =	 thaistring.MS874ToUnicode(request.getParameter("idExSet"));
		String no =	 thaistring.MS874ToUnicode(request.getParameter("no"));
		String idPart    =	 thaistring.MS874ToUnicode(request.getParameter("idPart"));
		String partno    =	 thaistring.MS874ToUnicode(request.getParameter("partno"));

		if (idSubject == null)  idSubject = "";
		if (idExSet == null)  idExSet = "";
		if (no == null)  no = "";
		if (idPart == null)  idPart = "";
		if (partno == null)  partno = "";

		 idSubject = idSubject.replaceAll(" ","");
		 idExSet = idExSet.replaceAll(" ","");
		 no = no.replaceAll(" ","");
 		 idPart = idPart.replaceAll(" ","");
		 partno = partno.replaceAll(" ","");

String checkdelete[] = request.getParameterValues("checkdelete");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
				teacher.deleteQuestion2Part(idPart,checkdelete[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	response.sendRedirect("Subject_ExamTab_ExamSectionChoice_Show_Teacher.jsp?idSubject="+idSubject+"&no="+no+"&idExSet="+idExSet+"&idPart="+idPart+"&partno="+partno);
%>




<!--- End Footer --->
<% } %>
