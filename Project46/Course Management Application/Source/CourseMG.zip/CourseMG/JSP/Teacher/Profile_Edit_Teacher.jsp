<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: E d i t P r o f i l e ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: E d i t P r o f i l e ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
    <link href="style1.css" rel="stylesheet" type="text/css" />
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="210">
		
		


<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
<td width="738">
	<table border="0" cellspacing="0" cellpadding="0" width="691">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		
		<tr> 
			    <td width="691">                  
				 <FORM ENCTYPE='multipart/form-data' method='POST' action='Edit_Profile.jsp' name="form1">
		                <table width="86%" border="1"  align="left" cellpadding="0" cellspacing="3" bordercolor="14296F" bgcolor="EFFAD1">
                          <tr bgcolor="#FFFFFF" background="Picture/bg.gif">
                            <td colspan="4" class="headerdarkblue"><img name="lmenu_id_r1_c1" src="Picture/t_profile_edit1.gif" width="174" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/middle.gif" width="391" height="20" border="0" /><img name="lmenu_id_r1_c1" src="Picture/end.gif" width="71" height="20" border="0" /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">���� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strName" type="text" id="strUsername4" value="<%=teacher.getname()%>"   size="50" maxlength="100"  /></td>
                          </tr>
                          <tr>
                            <td width="152" align="right" bordercolor="EFFAD1" class="detailblue">���ʡ�� :: </td>
                            <td width="325" bordercolor="EFFAD1" ><input name="strSurname" type="text" id="strUsername4" value="<%=teacher.getsurname()%>"   size="50" maxlength="100"  /></td>
                          </tr>
                           <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">�ٻ���� :: </td>
                            <td width="325" bordercolor="EFFAD1"><input name="strPicture" type="text" id="strPassword3" value="<%=teacher.getpicture()%> "   size="50" maxlength="100" disabled/> <input name="filesend" type="file" /></td>
                          </tr>
                         <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">���˹� :: </td>
                            <td width="325" bordercolor="EFFAD1"><input name="strRole" type="text" id="strPassword3" value="<%=teacher.getRole()%> "   size="50" maxlength="100" disabled /></td>
                          </tr>
                          <tr>
                            <td width="152"  align="right" bordercolor="EFFAD1" class="detailblue">����ѵԡ���֡�� :: </td>
                            <td width="325" bordercolor="EFFAD1"><textarea name="strQualification" cols="50" rows="5" id="textarea4"><%=teacher.getqualification()%></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�ŧҹ�ҧ�Ԫҡ�� :: </td>
                            <td colspan="2"><textarea name="strResearch" cols="50" rows="5" id="textarea6"><%=teacher.getresearch()%></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">����ʹ� :: </td>
                            <td colspan="2"><textarea name="strInteresting" cols="50" rows="5" id="textarea6"><%=teacher.getinteresting()%></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">���ʺ��ó� :: </td>
                            <td colspan="2"><textarea name="strExp" cols="50" rows="5" id="textarea6"><%=teacher.getexp()%></textarea></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�ԧ����ǹ��� :: </td>
                            <td colspan="2"><input name="strLink" type="text" id="strCourse4" value="<%=teacher.getlink()%> "   size="50" maxlength="100"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">������ :: </td>
                            <td colspan="2"><input name="strEmail" type="text" id="strCourse23" value="<%=teacher.getemail()%>"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">�������Ѿ�� ::</td>
                            <td colspan="2"><input name="strTel" type="text" id="strEmail3" value="<%=teacher.gettel()%>"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">��ͧ�ӧҹ ::</td>
                            <td colspan="2"><input name="strContactroom" type="text" id="strTel3" value="<%=teacher.getcontactroom()%>"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" class="detailblue">������Ҿ� ::</td>
                            <td colspan="2"><input name="strMeetingTime" type="text" id="strTel3" value="<%=teacher.getmeetingTime()%>"   size="50" maxlength="50"/></td>
                          </tr>
                          <tr bordercolor="EFFAD1">
                            <td width="152"  align="right" ></td>
                            <td colspan="2"><p class="style11">
								<input name="OK" type="button" id="OK" value="Edit" onClick="checknull('Edit')"/>                                
								<input name="Reset" type="reset" value="Reset" />
								<input name="Back" type="button" id="Back" onclick="window.location='Profile_Teacher.jsp'" value="Back" />
								</p>
                           </td>
                          </tr>
						  <tr bordercolor="EFFAD1"></tr>
                      </table>
                    </form>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></td>
				
		
	</table>
	
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
		  </table>
				
	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


  <!--Begin Add Java Script-->
<SCRIPT LANGUAGE="JavaScript">
<!--
//strName, strSurname, strPicture, strRole, strQualification, strResearch, strInteresting, strExp, strLink, strEmail, strTel, strContactroom, strMeetingTime
	var doc = document.form1
	function checknull(n){
		if((!((doc.strName.value=='')||((doc.strName.value!='')&&(isallspace(doc.strName.value)))))&&
		(!((doc.strSurname.value=='')||((doc.strSurname.value!='')&&(isallspace(doc.strSurname.value)))))&&
//		(!((doc.strPicture.value=='')||((doc.strPicture.value!='')&&(isallspace(doc.strPicture.value)))))&&
		(!((doc.strQualification.value=='')||((doc.strQualification.value!='')&&(isallspace(doc.strQualification.value)))))&&
		(!((doc.strResearch.value=='')||((doc.strResearch.value!='')&&(isallspace(doc.strResearch.value)))))&&
		(!((doc.strInteresting.value=='')||((doc.strInteresting.value!='')&&(isallspace(doc.strInteresting.value)))))&&
		(!((doc.strExp.value=='')||((doc.strExp.value!='')&&(isallspace(doc.strExp.value)))))&&
		(!((doc.strLink.value=='')||((doc.strLink.value!='')&&(isallspace(doc.strLink.value)))))&&
		(!((doc.strEmail.value=='')||((doc.strEmail.value!='')&&(isallspace(doc.strEmail.value)))))&&
		(!((doc.strTel.value=='')||((doc.strTel.value!='')&&(isallspace(doc.strTel.value)))))&&
		(!((doc.strContactroom.value=='')||((doc.strContactroom.value!='')&&(isallspace(doc.strContactroom.value)))))&&		
		(!((doc.strMeetingTime.value=='')||((doc.strMeetingTime.value!='')&&(isallspace(doc.strMeetingTime.value))))))
			{doc.submit();} 
		else {
			var strAlert = "��سҡ�͡ ";
			if(((doc.strName.value=='')||((doc.strName.value!='')&&(isallspace(doc.strName.value))))) strAlert = strAlert + " ����  " ;
			if(((doc.strSurname.value=='')||((doc.strSurname.value!='')&&(isallspace(doc.strSurname.value))))) strAlert = strAlert + " ���ʡ��  " ;
//			if(((doc.strPicture.value=='')||((doc.strPicture.value!='')&&(isallspace(doc.strPicture.value))))) strAlert = strAlert + " �ٻ����  " ;
			if(((doc.strQualification.value=='')||((doc.strQualification.value!='')&&(isallspace(doc.strQualification.value))))) strAlert = strAlert + " ����ѵԡ���֡��  " ;
			if(((doc.strResearch.value=='')||((doc.strResearch.value!='')&&(isallspace(doc.strResearch.value))))) strAlert = strAlert + " �ŧҹ�ҧ�Ԫҡ��  " ;
			if(((doc.strInteresting.value=='')||((doc.strInteresting.value!='')&&(isallspace(doc.strInteresting.value))))) strAlert = strAlert + " ����ʹ�  " ;
			if(((doc.strExp.value=='')||((doc.strExp.value!='')&&(isallspace(doc.strExp.value))))) strAlert = strAlert + " ���ʺ��ó�  " ;
			if(((doc.strLink.value=='')||((doc.strLink.value!='')&&(isallspace(doc.strLink.value))))) strAlert = strAlert + " �ԧ����ǹ���  " ;
			if(((doc.strEmail.value=='')||((doc.strEmail.value!='')&&(isallspace(doc.strEmail.value))))) strAlert = strAlert + " �������  " ;
			if(((doc.strTel.value=='')||((doc.strTel.value!='')&&(isallspace(doc.strTel.value))))) strAlert = strAlert + " �������Ѿ��  " ;
			if(((doc.strContactroom.value=='')||((doc.strContactroom.value!='')&&(isallspace(doc.strContactroom.value))))) strAlert = strAlert + " ��ͧ�ӧҹ  " ;
			if(((doc.strMeetingTime.value=='')||((doc.strMeetingTime.value!='')&&(isallspace(doc.strMeetingTime.value))))) strAlert = strAlert + "  ������Ҿ�  " ;
			alert(strAlert);			 
		}
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script-->
 
<% } %>