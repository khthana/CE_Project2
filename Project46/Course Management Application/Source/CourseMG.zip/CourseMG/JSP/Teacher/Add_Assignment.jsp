<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="com.jspsmart.upload.*"%>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
	response.sendRedirect("../log_in.jsp");
	} else { %>
<%	
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();

		String filename = mySmartUpload.getFiles().getFile(0).getFileName();

	String ridSubject		= new String(); 
	String rtopic		= new String(); 
	String rdescription		= new String(); 
	String rsendDate		= new String(); 
	String rmaxScore		= new String(); 
	String rwarningDate		= new String(); 
	String rmaxGroup		= new String(); 

		
	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters 	
	while (e.hasMoreElements()) {  		
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("idSubject")){
			ridSubject = thaistring.MS874ToUnicode(values[0]);
		}//idSubject
		if(key.equals("topic")){
			rtopic = thaistring.MS874ToUnicode(values[0]);
		}//topic
		if(key.equals("description")){
			rdescription = thaistring.MS874ToUnicode(values[0]);
		}//topic
		if(key.equals("sendDate")){
			rsendDate = thaistring.MS874ToUnicode(values[0]);
		}//sendDate
		if(key.equals("maxScore")){
			rmaxScore = thaistring.MS874ToUnicode(values[0]);
		}//maxScore
		if(key.equals("warningDate")){
			rwarningDate = thaistring.MS874ToUnicode(values[0]);
		}//warningDate
		if(key.equals("maxGroup")){
			rmaxGroup = thaistring.MS874ToUnicode(values[0]);
		}//maxGroup
	}//while

	ridSubject = ridSubject.replaceAll(" ","");
	String idAssignment =  teacher.addAssignment(rtopic,rdescription,rsendDate,rmaxScore,"",rwarningDate,rmaxGroup,ridSubject);

	String upfilename = "";
	if(!(filename.equals(""))){
	     upfilename =upfilename + "s" + ridSubject + "a" + idAssignment + helper.getTypeFile(filename);
		mySmartUpload.getFiles().getFile(0).saveAs("/Upload/AssignmentT/"+upfilename.toLowerCase());
	} 
	teacher.editAssignmentPicture(idAssignment,upfilename.toLowerCase());
	response.sendRedirect("Subject_AssignmentTab_View_Teacher.jsp?idSubject="+ridSubject);

%>
<%}%>