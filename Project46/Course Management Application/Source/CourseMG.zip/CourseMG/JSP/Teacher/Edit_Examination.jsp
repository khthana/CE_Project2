<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridExam =	 thaistring.MS874ToUnicode(request.getParameter("idExam"));
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String rtype =	 thaistring.MS874ToUnicode(request.getParameter("type"));
		String ridExSet =	 thaistring.MS874ToUnicode(request.getParameter("idExSet"));
		String rmaxScore =	 thaistring.MS874ToUnicode(request.getParameter("maxScore"));
		String rrealScore =	 thaistring.MS874ToUnicode(request.getParameter("realScore"));
 		String rexamDate =	 thaistring.MS874ToUnicode(request.getParameter("examDate"));
		String rstartTime =	 thaistring.MS874ToUnicode(request.getParameter("startTime"));
		String rstopTime =	 thaistring.MS874ToUnicode(request.getParameter("stopTime"));
		String rmagicnum =	 thaistring.MS874ToUnicode(request.getParameter("magicnum"));
		
	System.out.println(ridSubject);
	System.out.println(rtype);
	System.out.println(ridExSet);
	System.out.println(rmaxScore);
	System.out.println(rmaxScore);
	System.out.println(rrealScore);
	System.out.println(rexamDate);
	System.out.println(rstartTime);
	System.out.println(rstopTime);
	System.out.println(rmagicnum);

	ridSubject = ridSubject.replaceAll(" ","");
	ridExSet = ridExSet.replaceAll(" ","");
	ridExam = ridExam.replaceAll(" ","");
	if (ridExam!=null) {
	ridExam = ridExam.replaceAll(" ","");
	teacher.editExam(ridExam,rmaxScore,rrealScore,rtype,rexamDate,rstartTime,rstopTime,"0",ridSubject,ridExSet,rmagicnum);
	}

		response.sendRedirect("Subject_ExamTab_Examination_Teacher.jsp?idSubject="+ridSubject);

%>
<% } %>