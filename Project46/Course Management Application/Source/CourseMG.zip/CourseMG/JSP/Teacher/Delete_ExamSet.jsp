<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
	String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		if (idSubject == null)  idSubject = "";
		idSubject = idSubject.replaceAll(" ","");

	String checkdelete[] = request.getParameterValues("checkdelete");
	if(checkdelete!= null) {
		for (int i = 0;i<checkdelete.length;i++){
			checkdelete[i] = thaistring.MS874ToUnicode(checkdelete[i]);
			teacher.deleteExSet(checkdelete[i]);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	response.sendRedirect("Subject_ExamTab_ExamSet_Teacher.jsp?idSubject="+idSubject);
%>




<!--- End Footer --->
<% } %>
