<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: N e w s ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: N e w s ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--

-->
    </style>
    <link href="style1.css" rel="stylesheet" type="text/css" />
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="178">
		
		


<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
<td width="776">
	<table border="0" cellspacing="0" cellpadding="0" width="686">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		
		<tr> 
			    <td width="650">
				         <table width="100%" align="center" border="0"  >
                    <tbody>
                    
                      <tr valign="top">
                        <td height="191" bordercolor="14296F" background="Picture/bg.gif">
						<table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F">
				  <tr bordercolor="87F59B" bgcolor="EFFAD1">
					<td colspan="3" background="Picture/bg.gif" ><img src="Picture/delete_news.gif" width="115" height="20" border="0"><img src="Picture/middle.gif" width="400" height="20" border="0"><a href="#"><img src="Picture/end.gif" width="135" height="20" border="0" /></a></td>
				  </tr>
				<form action="Delete_News2.jsp" method="Post">
				<tr bordercolor="87F59B">
						<td colspan="3" background="Picture/bg.gif" ><div  class="headerpurple"> General News</div></td>
				</tr>
                   <%String[] idGeneralNews = teacher.queryidGeneralNewses();%>
				  <%for(int i = 0 ; i < idGeneralNews.length ; i++) { %>
                   		 <%ClassMGR.News.News news = teacher.queryNews(idGeneralNews[i]);%>  	
						  <tr bordercolor="87F59B" bgcolor="EFFAD1">
							<td width="25" height="25"  background="Picture/bg.gif"><div align="center"><input name="checkdelete" type="checkbox" value="<%=idGeneralNews[i]%>" /></div></td>
							<td width="75" height="25"  background="Picture/bg.gif"><span class="headerdarkblue"><%=news.getdatePost()%></span></td>
							<td width="550" height="25" background="Picture/bg.gif"><span class="headerdarkblue"><%=news.gettopic()%></span></td>
						  </tr>
	           <% }  %>
				<%String[] idSubjects = teacher.queryidSubjectsTeaching()	;%> 
						  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
                         	  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
									<tr bordercolor="87F59B">
												<td colspan="3" background="Picture/bg.gif" ><div  class="headerpurple"> <%=subject.getnameEng()%></div></td>
									</tr>
							 <%String[] idNews = teacher.queryidNewses(idSubjects[i]);%>
							  <%for(int j = 0 ; j < idNews.length ; j++) { %>
									 <%ClassMGR.News.News news = teacher.queryNews(idNews[j]);%>  	
										  <tr bordercolor="87F59B" bgcolor="EFFAD1">
											<td width="25" height="25"  background="Picture/bg.gif"><div align="center"><input name="checkdelete" type="checkbox" value="<%=idNews[j]%>" /></div></td>
											<td width="75" height="25"  background="Picture/bg.gif"><span class="headerdarkblue"><%=news.getdatePost()%></span></td>
											<td width="550" height="25" background="Picture/bg.gif"><span class="headerdarkblue"><%=news.gettopic()%></span></td>
										  </tr>
							   <% }  %>
							<% }  %>
  
  <tr bordercolor="EFFAD1" bgcolor="EFFAD1" >
            <td colspan="1" bordercolor="EFFAD1" background="Picture/bg.gif">
			<p align="right">
						<input name="Delete" type="submit" id="Delete" value="Delete" />
			</p>            </td>
			   <td colspan="2" bordercolor="EFFAD1" background="Picture/bg.gif" bgcolor="EFFAD1">
			<p>
						<input name="Reset" type="reset" value="Reset" />
						<input name="Cancle" type="button" value="Back" onclick="window.location='News_Teacher.jsp'" />
			</p>
            </td>
</tr>
</form>					
</table>
			    </td>
                      </tr>
                    </tbody>
                  </table>
                 
                </td>
				
		
	</table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
		  </table>
				
	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
<% } %>