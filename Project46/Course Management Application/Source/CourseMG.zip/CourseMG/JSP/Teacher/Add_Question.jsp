<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) { 
			response.sendRedirect("../log_in.jsp"); 
		} else {
%>
<%	
		String idSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String description =	 thaistring.MS874ToUnicode(request.getParameter("description"));
		String rank =	 thaistring.MS874ToUnicode(request.getParameter("rank"));
		String type =	 thaistring.MS874ToUnicode(request.getParameter("type"));
		String descAns1 =	 thaistring.MS874ToUnicode(request.getParameter("descAns1"));
		String descAns2 =	 thaistring.MS874ToUnicode(request.getParameter("descAns2"));
 		String descAns3 =	 thaistring.MS874ToUnicode(request.getParameter("descAns3"));
		String descAns4 =	 thaistring.MS874ToUnicode(request.getParameter("descAns4"));
		String descAns5 =	 thaistring.MS874ToUnicode(request.getParameter("descAns5"));
		String collectAns =	 thaistring.MS874ToUnicode(request.getParameter("collectAns"));
		String idAns1 =	"";
		String idAns2 =	"";
 		String idAns3 =	"";
		String idAns4 =   "";
		String idAns5 =	"";

		
		System.out.println(idSubject);


		if (idSubject == null)  idSubject = "";
		if (collectAns == null)  collectAns = "";
		if (rank == null)  rank = "";

		 rank = rank.replaceAll(" ","");
		 descAns1 = descAns1.replaceAll(" ","");
		 descAns2 = descAns2.replaceAll(" ","");
 		 descAns3 = descAns3.replaceAll(" ","");
		 descAns4 = descAns4.replaceAll(" ","");
		 descAns5 = descAns5.replaceAll(" ","");
		 collectAns = collectAns.replaceAll(" ","");
		idSubject = idSubject.replaceAll(" ","");

		String collectidAns = "  ";
		System.out.println(description);
		System.out.println(type);
		System.out.println(collectidAns);
		System.out.println(idSubject);
		System.out.println("11111111111111111");
		String idQuestion = teacher.addQuestion(description,type,idSubject,teacher.getidTeacher(),collectidAns,rank);
		System.out.println(idQuestion);
		System.out.println(descAns1);
		System.out.println(descAns2);
		System.out.println(descAns3);
		System.out.println(descAns4);
		System.out.println(descAns5);
		if (!descAns1.equals("")) { idAns1 = teacher.addAnswer(descAns1,idQuestion);}
	  	if (!descAns2.equals("")) { idAns2 = teacher.addAnswer(descAns2,idQuestion);}
	  	if (!descAns3.equals("")) { idAns3 = teacher.addAnswer(descAns3,idQuestion);}
	  	if (!descAns4.equals("")) { idAns4 = teacher.addAnswer(descAns4,idQuestion);}
	  	if (!descAns5.equals("")) { idAns5 = teacher.addAnswer(descAns5,idQuestion);}

		System.out.println(collectAns);
		System.out.println("11111111111111111");


		for (int i=0; (i*2)< collectAns.length() ; i=i+1) {
		    collectidAns = collectidAns.replaceAll(" ","");
			String tmp = collectAns.substring(i*2,i*2+1);
			System.out.println(tmp);
		System.out.println(i);
		System.out.println(tmp);
			if (tmp.equals("1") && (!descAns1.equals("") ) && (!idAns1.equals("") )) { collectidAns = collectidAns + idAns1 + ";"; }
			if (tmp.equals("2") && (!descAns2.equals("") ) && (!idAns2.equals("") )) { collectidAns = collectidAns + idAns2 + ";"; }
			if (tmp.equals("3") && (!descAns3.equals("") ) && (!idAns3.equals("") )) { collectidAns = collectidAns + idAns3 + ";"; }
			if (tmp.equals("4") && (!descAns4.equals("") ) && (!idAns4.equals("") )) { collectidAns = collectidAns + idAns4 + ";"; } 
			if (tmp.equals("5") && (!descAns5.equals("") ) && (!idAns5.equals("") )) { collectidAns = collectidAns + idAns5 + ";"; }
		}


		System.out.println(collectidAns);
		//teacher.addQuestion(description,type,idSubject,teacher.getidTeacher(),collectidAns)
//		teacher.addQuestion(description,type,idSubject,teacher.getidTeacher(),collectidAns,rank);
		System.out.println("11111111111111111");
		System.out.println(idQuestion);
		System.out.println(description);
		System.out.println(type);
		System.out.println(collectidAns);
		teacher.editQuestion(idQuestion,description,type,collectidAns,rank);

	response.sendRedirect("Subject_ExamTab_ExamQuestion_Teacher.jsp?idSubject="+idSubject);

%>
<% } %>