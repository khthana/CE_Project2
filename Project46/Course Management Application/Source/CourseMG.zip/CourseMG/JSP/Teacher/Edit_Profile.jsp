<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="com.jspsmart.upload.*"%>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();

		String filename = mySmartUpload.getFiles().getFile(0).getFileName();

	String rname		= new String(); 
	String rsurname		= new String(); 
	String rqualification	= new String(); 
	String rresearch		= new String(); 
	String rexp			= new String(); 
	String rinteresting	= new String(); 
	String rlink			= new String(); 
	String remail			= new String(); 
	String rtel			= new String(); 
	String rcontactroom 	= new String(); 
	String rmeetingTime	= new String(); 

	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters 	
	while (e.hasMoreElements()) {  		
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("strName")){
			rname = thaistring.MS874ToUnicode(values[0]);
		}//rname
		if(key.equals("strSurname")){
			rsurname = thaistring.MS874ToUnicode(values[0]);
		}//rsurname
		if(key.equals("strQualification")){
			rqualification = thaistring.MS874ToUnicode(values[0]);
		}//rqualification
		if(key.equals("strResearch")){
			rresearch = thaistring.MS874ToUnicode(values[0]);
		}//rresearch
		if(key.equals("strExp")){
			rexp = thaistring.MS874ToUnicode(values[0]);
		}//rexp
		if(key.equals("strInteresting")){
			rinteresting = thaistring.MS874ToUnicode(values[0]);
		}//rinteresting
		if(key.equals("strLink")){
			rlink = thaistring.MS874ToUnicode(values[0]);
		}//rlink
		if(key.equals("strEmail")){
			remail = thaistring.MS874ToUnicode(values[0]);
		}//remail
		if(key.equals("strTel")){
			rtel = thaistring.MS874ToUnicode(values[0]);
		}//rtel
		if(key.equals("strContactroom")){
			rcontactroom = thaistring.MS874ToUnicode(values[0]);
		}//rcontactroom
		if(key.equals("strMeetingTime")){
			rmeetingTime = thaistring.MS874ToUnicode(values[0]);
		}//rmeetingTime
	}//while
	String upfilename = "";
	if((!filename.equals(""))){
	     upfilename =upfilename + "t" + teacher.getidTeacher() + helper.getTypeFile(filename);
		mySmartUpload.getFiles().getFile(0).saveAs("/Upload/Picture/"+upfilename.toLowerCase());
	} else {
		upfilename = teacher.getpicture();
	}
teacher.editProfile(rname,rsurname,remail,rtel,rlink,rqualification,rresearch,"","",rmeetingTime,rinteresting,rexp,rcontactroom,upfilename.toLowerCase());
	teacher.setname(rname);
	teacher.setsurname(rsurname);
	teacher.setemail(remail);
	teacher.settel(rtel);
	teacher.setlink(rlink);
	teacher.setqualification(rqualification);
	teacher.setresearch(rresearch);
	teacher.setmeetingTime(rmeetingTime);
	teacher.setinteresting(rinteresting);
	teacher.setexp(rexp);
	teacher.setcontactroom(rcontactroom);
//	teacher.setpicture(upfilename.toLowerCase());

		response.sendRedirect("Profile_Teacher.jsp");
%>
<% } %>