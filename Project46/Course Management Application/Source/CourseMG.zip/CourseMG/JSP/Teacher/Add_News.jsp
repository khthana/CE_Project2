<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) { 
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String date =	 thaistring.MS874ToUnicode(request.getParameter("date"));
		String rtopic =	 thaistring.MS874ToUnicode(request.getParameter("topic"));
		String rdescription =	 thaistring.MS874ToUnicode(request.getParameter("description"));
		String rnum2Del =	 thaistring.MS874ToUnicode(request.getParameter("num2Del"));
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));

	String subjects[] = new String[1];
	subjects[0] = ridSubject.replaceAll(" ","");
	System.out.println(rtopic);
	System.out.println(rdescription);
	System.out.println(rnum2Del);
	System.out.println(ridSubject);
		teacher.addNews(subjects,rtopic,rdescription,teacher.getidTeacher(),"Teacher",rnum2Del);
		response.sendRedirect("Subject_NewsTab_View_Teacher.jsp?idSubject="+ridSubject);

%>
<%}%>