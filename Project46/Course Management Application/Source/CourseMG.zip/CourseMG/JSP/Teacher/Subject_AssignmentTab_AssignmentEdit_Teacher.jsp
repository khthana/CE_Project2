<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridAssignment =	request.getParameter("idAssignment");
		if (ridAssignment == null)  ridAssignment = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t  A s s i g n m e n t ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t  A s s i g n m e n t ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="left">
			<table border="0" cellpadding="0" cellspacing="0" width="575">
				<tr>
						<td><a href="Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavproducts" src="Picture/Tab_Syllabus.gif"  width="82" height="25" border="0"></a></td>
   					    <td><a href="Subject_NewsTab_View_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavcustomers" src="Picture/Tab_News.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_TimetableTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavpartners" src="Picture/Tab_Timetable.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_WebboardTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavsupport" src="Picture/Tab_Webboard.gif" width="82" height="25" border="0"></a></td>
 						<td><a href="Subject_ChatTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdeveloper" src="Picture/Tab_Chat.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_AssignmentTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavcompany" src="Picture/Tab_Assignment_Selected.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ExamTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Examination.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ScoreTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Score.gif" width="82" height="25" border="0"></a></td>
						<td width="*"><img name="topnavdeveloper" src="Picture/Tab_Blank.gif" width="171" height="25" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/spacer.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="98%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	

		<td width="171">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->

		
				
            <p>
			  <a href="Home_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Teacher.jsp?date=<%=teacher.getnewday()%>" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
			  <a href="Subject_SyllabusTab_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject_Selected.gif"  /></a><br />
		    </p>
				<%String[] idSubjects = teacher.queryidSubjectsTeaching()	;%> 
				  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
						  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
					 <div ><a class="sidelink" href="Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject=<%=subject.getidSubject()%>" ><%=subject.getnameEng()%></a></div>
				<% }  %>
			  <p>
              <a href="Webboard_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="Assignment_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a><br />
              <a href="Exam_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Examiantion" width="170" height="25" src="Picture\Menu_Examination.gif" /></a><br />
			  </p>
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
		    <table width="158" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><div align="left"><span class="detaildarkblue">
						  <%=teacher.getname()%> : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Teacher.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Edit_Teacher.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
 <td width="1" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
   <td width="802">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
				   <%ClassMGR.Subject.Subject subject = teacher.querySubject(ridSubject);%>  	
                  <table width="649" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				  
				  <tr bordercolor="87F59B">
					<td colspan="2" background="Picture/bg.gif" ><img src="Picture/assignment.gif" width="200" height="20" border="0"></a><img src="Picture/middle.gif" width="300" height="20" border="0"><img src="../Student/Picture/end.gif" width="140" height="20" border="0"></td>
				  </tr>
				<tr bordercolor="87F59B" bgcolor="#CAFD97">
             <td colspan="2" class="detailblue"><%=subject.getnameEng()%></td>
           </tr>
				  <%ClassMGR.Assignment.Assignment assignment = teacher.queryAssignment(ridAssignment);%>  					  
				 <FORM ENCTYPE='multipart/form-data' method='POST' action='Edit_Assignment.jsp' name="form1">
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="25" colspan="2" class="headerblue"><p class="detailblue">Assignment 
					  <input name="idAssignment" type="hidden" value="<%=assignment.getidAssignment()%>" size="70" maxlength="70" />
					  <input name="idSubject" type="hidden" value="<%=ridSubject%>" size="70" maxlength="70" />
                      </p></td>
                    </tr>
					<tr bordercolor="#87F59B" class="detaildarkblue">
                                <td colspan="2" class="detailhead" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��������´</td>
                   </tr>
                    <tr bordercolor="#87F59B" class="detaildarkblue">
                         <td width="14%" class="detailblue">��Ǣ��</td>
                      <td width="86%"><input name="topic" type="text" value="<%=assignment.getname()%>" size="70" maxlength="70" />
                      </td>
                   </tr>
                   
				    <tr bordercolor="#87F59B" class="detaildarkblue">
                         <td class="detailblue">��������´</td>
                      <td><textarea name="description" cols="70" rows="3"><%=assignment.getdescription()%></textarea>
                      </td>
                   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
                          <td class="detailblue">�ѹ��觧ҹ</td>
                      <td><input name="assignDate" type="text" value="<%=assignment.getassignDate()%>" size="15" maxlength="15"  disabled/></td>
                   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
                     <td class="detailblue">�ѹ�觧ҹ</td>
                      <td><input name="sendDate" type="text" value="<%=assignment.getsendDate()%>" size="15" maxlength="15" />
                      </td>
                   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
                       <td class="detailblue">��ṹ���</td>
                      <td><input name="maxScore" type="text" value="<%=assignment.getmaxScore()%>" size="3" maxlength="3" />
                      </td>
                   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
				         <td class="detailblue">�ӹǹ����͡����</td>
                         <td><input name="maxGroup" type="text" value="<%=assignment.getsizeOfGroup()%>" size="3" maxlength="3" />
                         </td>
				   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
				         <td class="detailblue">�ѹ���������ӡ����͹</td>
                         <td><input name="warningDate" type="text" value="<%=assignment.getwarningDate()%>" size="15" maxlength="15" />
                         </td>
				   </tr>
				    <tr bordercolor="#87F59B" class="detaildarkblue">
				       <td class="detailblue">�͡���Ṻ</td>
                       <td><input name="aaaaa" type="text" value="<%=assignment.getfileDetail()%>" size="70" maxlength="70"  disabled/>             </td>
				   </tr>
				   <tr bordercolor="#87F59B" class="detaildarkblue">
				       <td>&nbsp;</td>
                      <td>
                          <input name="filename" type="file"  />
                      </td>
				   </tr>
				    	<td  colspan="2" bordercolor="#EFFAD1" class="detailblue">                       
					    <input name="Edit" type="button"  value="Edit" onClick="checknull('Edit')"/>
					    <input name="Reset" type="reset" value="Reset" />
					    <input name="Back" type="button"  id="Back" onclick="window.location='Subject_AssignmentTab_AssignmentDetail_Teacher.jsp?idSubject=<%=ridSubject%>&idAssignment=<%=ridAssignment%>'" value="Back" />
						</td>
				   </tr>
				   </form>
				</table>
                 
                </td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
    </table>	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><img src="Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->

<!--Begin Add Java Script-->
<SCRIPT LANGUAGE="JavaScript">
<!--
//topic, description, sendDate, warningDate, maxScore, maxGroup, filename
	var doc = document.form1
	function checknull(n){
		if((!((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value)))))&&
		(!((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value)))))&&
		(!((doc.sendDate.value=='')||((doc.sendDate.value!='')&&(isallspace(doc.sendDate.value)))))&&
//		(!((doc.warningDate.value=='')||((doc.warningDate.value!='')&&(isallspace(doc.warningDate.value)))))&&
		(!((doc.maxScore.value=='')||((doc.maxScore.value!='')&&(isallspace(doc.maxScore.value)))))&&
		(!((doc.maxGroup.value=='')||((doc.maxGroup.value!='')&&(isallspace(doc.maxGroup.value))))))
		{
			if((!isNaN(doc.maxScore.value))&&(!isNaN(doc.maxGroup.value)))
				{doc.submit();} 
			else{
				var stalert ="��سҡ�͡ ";
				if(isNaN(doc.maxScore.value)) stalert = stalert + " ��ṹ���  ";
				if(isNaN(doc.maxGroup.value)) stalert = stalert + " �ӹǹ����͡����  ";
				stalert = stalert + " ���١��ͧ";
				alert(stalert);
			}
		}
		else {
			var strAlert = "��سҡ�͡ "
			if(((doc.topic.value=='')||((doc.topic.value!='')&&(isallspace(doc.topic.value))))) strAlert = strAlert + " ��Ǣ��  " ;
			if(((doc.description.value=='')||((doc.description.value!='')&&(isallspace(doc.description.value))))) strAlert = strAlert + " ��������´  " ;
			if(((doc.sendDate.value=='')||((doc.sendDate.value!='')&&(isallspace(doc.sendDate.value))))) strAlert = strAlert + " �ѹ�觧ҹ  " ;
//			if(((doc.warningDate.value=='')||((doc.warningDate.value!='')&&(isallspace(doc.warningDate.value))))) strAlert = strAlert + " �ѹ���������ӡ����͹  " ;
			if(((doc.maxScore.value=='')||((doc.maxScore.value!='')&&(isallspace(doc.maxScore.value))))) strAlert = strAlert + " ��ṹ���  " ;
			if(((doc.maxGroup.value=='')||((doc.maxGroup.value!='')&&(isallspace(doc.maxGroup.value))))) strAlert = strAlert + " �ӹǹ����͡����  " ;
			alert(strAlert);			 
		}
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script-->
 
 
<% } %>