<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String stridNews =	 thaistring.MS874ToUnicode(request.getParameter("stridNews"));
		String strDatePost =	 thaistring.MS874ToUnicode(request.getParameter("strDatePost"));
		String strTopic =	 thaistring.MS874ToUnicode(request.getParameter("strTopic"));
		String strDescription =	 thaistring.MS874ToUnicode(request.getParameter("strDescription"));
		String strNum2Del =	 thaistring.MS874ToUnicode(request.getParameter("strNum2Del"));
		String stridSubject =	 thaistring.MS874ToUnicode(request.getParameter("stridSubject"));
		stridNews = stridNews.replaceAll(" ","");
		strNum2Del = strNum2Del.replaceAll(" ","");
		System.out.println(stridNews);
		System.out.println(strDatePost);
		System.out.println(strTopic);
		System.out.println(strDescription);
		System.out.println(strNum2Del);
//		System.out.println(stridSubject);

		
		teacher.editNews(stridNews,strTopic,strDescription,strDatePost,strNum2Del);
        if(stridSubject==null) {
			response.sendRedirect("News_Teacher.jsp");
		} 
		else {
			stridSubject = stridSubject.replaceAll(" ","");
			response.sendRedirect("Subject_NewsTab_Detail_Teacher.jsp?idSubject="+stridSubject+"&idNews="+stridNews);
		}

%>
<% } %>