<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridExam =	request.getParameter("idExam");
		if (ridExam == null)  ridExam = "";
		String ridExSet =	request.getParameter("idExSet");
		if (ridExSet == null)  ridExSet = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t E x a m ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t E x a m ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="left">
			<table border="0" cellpadding="0" cellspacing="0" width="575">
				<tr>
						<td><a href="Subject_SyllabusTab_DetailSubject_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavproducts" src="Picture/Tab_Syllabus.gif"  width="82" height="25" border="0"></a></td>
   					    <td><a href="Subject_NewsTab_View_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavcustomers" src="Picture/Tab_News.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_TimetableTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>" ><img name="topnavpartners" src="Picture/Tab_Timetable.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_WebboardTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavsupport" src="Picture/Tab_Webboard.gif" width="82" height="25" border="0"></a></td>
 						<td><a href="Subject_ChatTab_Detail_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdeveloper" src="Picture/Tab_Chat.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_AssignmentTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavcompany" src="Picture/Tab_Assignment.gif"  width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ExamTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Examination_Selected.gif" width="82" height="25" border="0"></a></td>
						<td><a href="Subject_ScoreTab_View_Teacher.jsp?idSubject=<%=ridSubject%>"><img name="topnavdownloads" src="Picture/Tab_Score.gif" width="82" height="25" border="0"></a></td>
						<td width="*"><img name="topnavdeveloper" src="Picture/Tab_Blank.gif" width="171" height="25" border="0"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/spacer.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="91%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	

		<td width="171">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->

		
				
            <p>
			  <a href="Home_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Home" width="170" height="25" src="Picture/Menu_Home.gif" /></a><br />
              <a href="News_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="News" width="170" height="25" src="Picture\Menu_News.gif"  /></a><br />
			  <a href="Schedule_Teacher.jsp?date=<%=teacher.getnewday()%>" ><img border="0" hspace="0" vspace="0" alt="Schedule" width="170" height="25" src="Picture\Menu_Schedule.gif" /></a><br />
			  <a href="Subject_SyllabusTab_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Subject" width="170" height="25" src="Picture\Menu_Subject_Selected.gif"  /></a><br />
  			 </p>
				<%String[] idSubjects = teacher.queryidSubjectsTeaching()	;%> 
				  <%for(int i = 0 ; i < idSubjects.length ; i++) { %>
						  <%ClassMGR.Subject.Subject subject = teacher.querySubject(idSubjects[i]);%>  	
					 <div ><a class="sidelink" href="Subject_ExamTab_View_Teacher.jsp?idSubject=<%=subject.getidSubject()%>" ><%=subject.getnameEng()%></a></div>
				<% }  %>
			  <p>
              <a href="Webboard_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Webbord" width="170" height="25" src="Picture\Menu_Webboard.gif" /></a><br />          
			  <a href="Chat_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Chat" width="170" height="25" src="Picture\Menu_Chat.gif" /></a><br />
              <a href="Assignment_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Assignment" width="170" height="25" src="Picture\Menu_Assignment.gif" /></a><br />
              <a href="Exam_Teacher.jsp" ><img border="0" hspace="0" vspace="0" alt="Examiantion" width="170" height="25" src="Picture\Menu_Examination.gif" /></a><br />
			  </p>
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->
              <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> 
			  <br />
              <img alt="" src="Picture\spacer.gif" width="1" height="15" border="0" vspace="0" hspace="0"> <br/>
              <img alt="" name="Picture\leftnav_curve_head.gif" src="Picture/leftnav_curve_head.gif"  width="171" height="10" border="0"> 
		    <table width="158" cellspacing="0" cellpadding="0">
			  <tr bgcolor="#E1E1E1">
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><div align="left"><span class="detaildarkblue">
						  <%=teacher.getname()%> : Online
				    </span></div></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="../signout.jsp" class="bottomblue">[ Log Off ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Teacher.jsp" class="bottomblue">[ Profile ]</a>
					</span></td>
			  </tr>
			  <tr>
			  		<td width="8" height="31" bgcolor="#FFFFFF">&nbsp;</td>
			  		<td width="10" height="31" >&nbsp;</td>
			  		<td width="98"><span >
					    <a href="Profile_Edit_Teacher.jsp" class="bottomblue">[ Edit Profile ]</a>
					</span></td>
			  </tr>
		    </table>
			  
			   <img alt="" name="Picture/leftnav_curve.gif" src="Picture/leftnav_curve.gif"  width="171" height="10" border="0"> 
              <br />
              <img alt="" src="Picture/spacer.gif" width="1" height="25" border="0" vspace="0" hspace="0"><br>
              <img alt="" src="Picture/spacer.gif" width="171" height="1" border="0">	
            </p>            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->
 <td width="1" align="left" valign="top" height="384"> 
      <table width="1" border="0" cellspacing="0" cellpadding="0" height="1000">
        <tr> 
          <td background="Picture/line_y.GIF" align="left" valign="top"><img src="Picture/line_y.GIF"width="7" height="17"></td>
        </tr>
      </table>
   <td width="802">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
				   <%ClassMGR.Subject.Subject subject = teacher.querySubject(ridSubject);%>  	
                  <table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
				    <tr bordercolor="87F59B">
                      <td   background="Picture/bg.gif" ><img src="Picture/examination.gif" width="94" height="20" border="0" /><img src="Picture/middle.gif" width="358" height="20" border="0" /><img src="Picture/end.gif" width="194" height="20" border="0" /></td>
                    </tr>
				<tr bordercolor="87F59B" bgcolor="#CAFD97">
             <td class="detailblue"><%=subject.getnameEng()%></td>
               </tr>
				<% ClassMGR.Exam.Exam exam = teacher.queryExam(ridExam); %>
					<form name="form1" id="form1" method="post" action="Edit_Examination.jsp">
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bordercolor="#87F59B" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�������ͧ����ͺ ::  &nbsp;&nbsp;
                        <select name="type" size="1">
                          <option <% if (exam.gettype().equals("Exam")) { %> selected="selected" <% } %>>Exam</option>
                          <option <% if (exam.gettype().equals("Quiz")) { %> selected="selected" <% } %>>Quiz</option>
                          <option <% if (exam.gettype().equals("Midterm")) { %> selected="selected" <% } %>>Midterm</option>
                          <option <% if (exam.gettype().equals("Final")) { %> selected="selected" <% } %>>Final</option>
                          <option <% if (exam.gettype().equals("Lab")) { %> selected="selected" <% } %>>Lab</option>
                        </select></td>
                    </tr>
					
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; �ش����ͺ����� :: 
                        <input name="idExSet" type="text" 
						<% if (!ridExSet.equals("")) { %>
								value="<%=ridExSet%>"
						<% } else {%>
								value="<%=exam.getidExSet()%>"
						<% } %>		
						 size="3" maxlength="3" /> <a href="ExamSet1.jsp?idSubject=<%=ridSubject%>&idExam=<%=ridExam%>"  >���͡�٪ش����ͺ</a> </td>
                    </tr>
										<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; ��ṹ����ͧ����ͺ :: 
                        <input name="maxScore" type="text" value="<%=exam.getmaxScore()%>" size="5" maxlength="5" /></td>
                    </tr>

					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; ��ṹ���Դ��ԧ :: 
                        <input name="realScore" type="text" value="<%=exam.getrealScore()%>" size="5" maxlength="5" /></td>
                    </tr>

					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; �ѹ����ͺ :: 
                        
                        
                        <input name="examDate" type="text" value="<%=exam.getexamDate()%>" size="10" maxlength="10" /></td>
                    </tr>
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; ����������ͺ :: 
                        <input name="startTime" type="text" value="<%=helper.padZeroForTime(exam.getstartTime())%>" size="10" maxlength="10" /></td>
                    </tr>
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; ��������ش����ͺ :: 
                        <input name="stopTime" type="text" value="<%=helper.padZeroForTime(exam.getstopTime())%>" size="10" maxlength="10" /></td>
                    </tr>
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; magic no. :: 
                        <input name="magicnum"  type="password" value="<%=exam.getmagicNum()%>" size="10" maxlength="10" /> 
                        </td>
                    </tr>
					<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                      <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;&nbsp;&nbsp; Confirm magic no. :: 
                        <input name="magicnum2"  type="password" value="<%=exam.getmagicNum()%>" size="10" maxlength="10" /> 
                        </td>
                    </tr>
					  <tr bordercolor="#1BE4E4" bgcolor="#1BE4E4" class="detaildarkblue">
                        <td bordercolor="#87F59B" bgcolor="#EFFAD1"   class="detailblue">
                          <input type="hidden" name="idSubject" value="<%=ridSubject%>" />
                          <input type="hidden" name="idExam" value="<%=ridExam%>" />
                          <input type="button" name="Submit" value="Edit" onClick="checknull('Edit')"/>
						   <input name="Reset" type="reset" value="Reset" /> 
						   <input name="Back" type="button" value="Back" onClick="window.location='Subject_ExamTab_Examination_Teacher.jsp?idSubject=<%=ridSubject%>'" /></td>
						</td>
                      </tr>
					</form>
                  </table>
             
                </td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
    </table>	  <a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"></td>
  </tr>
	</table>

		</a><table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><img src="Picture/spacer.gif" width="1" height="1" border="0"></a></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><img src="Picture/spacer.gif" width="1" height="18" border="0"></a></td>	
			</tr>												
		</table>

		
		<a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><span>&nbsp;<br></span>

	</a></body>
</html>




<!--- End Footer --->


<!--Begin Add Java Script -->
<SCRIPT LANGUAGE="JavaScript">
<!--
//idExSet, maxScore, realScore, examDate, startTime, stopTime, magicnum, magicnum2
//isNaN
	var doc = document.form1
	function checknull(n){
		if((!((doc.idExSet.value=='')||((doc.idExSet.value!='')&&(isallspace(doc.idExSet.value)))))&&
		(!((doc.maxScore.value=='')||((doc.maxScore.value!='')&&(isallspace(doc.maxScore.value)))))&&
		(!((doc.realScore.value=='')||((doc.realScore.value!='')&&(isallspace(doc.realScore.value)))))&&
		(!((doc.examDate.value=='')||((doc.examDate.value!='')&&(isallspace(doc.examDate.value)))))&&
		(!((doc.startTime.value=='')||((doc.startTime.value!='')&&(isallspace(doc.startTime.value)))))&&
		(!((doc.stopTime.value=='')||((doc.stopTime.value!='')&&(isallspace(doc.stopTime.value)))))&&
			(!((doc.magicnum.value=='')||((doc.magicnum.value!='')&&(isallspace(doc.magicnum.value)))))&&
		(!((doc.magicnum2.value=='')||((doc.magicnum2.value!='')&&(isallspace(doc.magicnum2.value))))))		{
			if	((!isNaN(doc.idExSet.value))&&(!isNaN(doc.maxScore.value))&&(!isNaN(doc.realScore.value)))
			{
				if(doc.magicnum.value == doc.magicnum2.value)
					{doc.submit();} 
				else
					alert("magic no. �Ѻ confirm magic no. �������͹�ѹ");
			}
			else {
				var stAlert ="��سҡ�͡";
				if(isNaN(doc.idExSet.value)) stAlert = stAlert +"� ش����ͺ  ";
				if(isNaN(doc.maxScore.value)) stAlert = stAlert +" ��ṹ����ͧ����ͺ  ";
				if(isNaN(doc.realScore.value)) stAlert = stAlert +" ��ṹ���Դ��ԧ  ";
				stAlert = stAlert + " ���١��ͧ";
				alert(stAlert);
			}
		}
		else {
			var strAlert = "��سҡ�͡ ";
			if(((doc.idExSet.value=='')||((doc.idExSet.value!='')&&(isallspace(doc.idExSet.value))))) strAlert = strAlert + " �ش����ͺ  " ;
			if(((doc.maxScore.value=='')||((doc.maxScore.value!='')&&(isallspace(doc.maxScore.value))))) strAlert = strAlert + " ��ṹ����ͧ����ͺ  " ;
			if(((doc.realScore.value=='')||((doc.realScore.value!='')&&(isallspace(doc.realScore.value))))) strAlert = strAlert + " ��ṹ���Դ��ԧ  " ;
			if(((doc.examDate.value=='')||((doc.examDate.value!='')&&(isallspace(doc.examDate.value))))) strAlert = strAlert + " �ѹ����ͺ  " ;
			if(((doc.startTime.value=='')||((doc.startTime.value!='')&&(isallspace(doc.startTime.value))))) strAlert = strAlert + " �ѹ������ͺ  " ;
			if(((doc.stopTime.value=='')||((doc.stopTime.value!='')&&(isallspace(doc.stopTime.value))))) strAlert = strAlert + " �ѹ����ش����ͺ  " ;
			if(((doc.magicnum.value=='')||((doc.magicnum.value!='')&&(isallspace(doc.magicnum.value))))) strAlert = strAlert + "  magic no.  " ;
			if(((doc.magicnum2.value=='')||((doc.magicnum2.value!='')&&(isallspace(doc.magicnum2.value))))) strAlert = strAlert + "  Confirm magic no.  " ;
			alert(strAlert);
		}
	}//checknull
	function isallspace(src){
		var i=0;
		var testtemp=0;
		for (i=0;i<src.length;i++)
		{
			if (src.charAt(i)!=' ')
			{
				return false;
			}
		}//for
		return true;
	}//isallspace
	-->
</SCRIPT>
<!--End Add Java Script--> 
 
 
<% } %>