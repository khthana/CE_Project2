<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	request.getParameter("idSubject");
		if (ridSubject == null)  ridSubject = "";
		String ridExam =	request.getParameter("idExam");
		if (ridExam == null)  ridExam = "";
%>
<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: S u b j e c t E x a m ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: S u b j e c t E x a m ::. Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >









<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Picture/header-bg.gif" ><img src="Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Picture/Space_Menu.gif" width="1464%" height="10" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/middle.gif" width="420" height="20" border="0"><img src="Picture/subject.gif" width="68" height="20" border="0"><img src="Picture/middle.gif" width="535" height="20" border="0"><img src="Picture/Space_Menu.gif" width="98%" height="15" border="0" /><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="1024">
				<tr valign=top>	

		<td width="171">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->

		
				
              <!-- *******************************************    END: PRODUCTS   ************************************************************* -->
              <!-- *******************************************    BEGIN: CUSTOMERS (Formerly SOLUTIONS)   ********************************************************** -->
              <!-- *******************************************    END: SOLUTIONS   ************************************************************* -->
              <!-- *******************************************    BEGIN: PARTNERS   ************************************************************ -->
              <!--- *******************************************    END: PARTNERS   ************************************************************* --->
              <!--- *******************************************    Begin: Developer   ************************************************************* --->
              <!--- *******************************************    END: Developer   ************************************************************* --->
              <!--- *******************************************    BEGIN: Support   ************************************************************* --->
              <!--- *******************************************    END: Support   ************************************************************* --->
              <!--- *******************************************    Begin: Company   ************************************************************* --->
              <!--- *******************************************    END: Company   ************************************************************* --->
              <!--- *******************************************    Begin: Downloads  ************************************************************* --->
              <!--- *******************************************    END: Downloads   ************************************************************* --->


<!--- End Left Nav Bar --->


<!--- Begin Body --->
 <td width="1" align="left" valign="top" height="384"> 
   <td width="802">
	<table border="0" cellspacing="0" cellpadding="0" width="791">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			
		</tr> 
		<tr> 
			    <td> 
				   <%ClassMGR.Subject.Subject subject = teacher.querySubject(ridSubject);%>  	
                  <table width="650" border="1" cellpadding="1" cellspacing="1" bordercolor="14296F" bgcolor="EFFAD1">
					<form action="Send_ExamSet1.jsp" method="post">
				    <tr bordercolor="87F59B">
                      <td   background="Picture/bg.gif" ><img src="Picture/ExaminationSet.gif" width="300" height="20" border="0" /><img src="Picture/middle.gif" width="245" height="20" border="0" /><img src="Picture/end.gif" width="97" height="20" border="0" /></td>
                    </tr>
				<tr bordercolor="87F59B" bgcolor="#CAFD97">
             <td class="detailblue"><%=subject.getnameEng()%></td>
               </tr>
				<%String[] idExSets = teacher.queryidExSets(ridSubject);%> 
					  <%for(int i = 0 ; i < idExSets.length ; i++) { %>

					  <%ClassMGR.Exam.ExSet exSet = teacher.queryExSet(idExSets[i]);%>  	
						<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
						  <td height="15" bgcolor="#EFFAD1" class="detailblue" >&nbsp;&nbsp;
						    <input name="idExSet" type="radio" value="<%=idExSets[i]%>" />						    &nbsp;&nbsp;&nbsp;<a href="Subject_ExamTab_ExamSet_Show_Teacher.jsp?idSubject=<%=ridSubject%>&no=<%=i+1%>&idExSet=<%=exSet.getidExSet()%>" target="_blank">�ش��� <%=i+1%></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ţ�ش <%=exSet.getidExSet()%>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��Сͺ���� <%=exSet.getCountParts()%> part</td>
						</tr>
				    <% } %>   
						<tr bordercolor="#87F59B" bgcolor="#B2E57F"> 
                            <td width="543" bordercolor="#87F59B" bgcolor="#EFFAD1">
                          <input type="hidden" name="idSubject" value="<%=ridSubject%>" />
                          <input type="hidden" name="idExam" value="<%=ridExam%>" />
								<input name="Submit" type="submit" value="Add" />
							   <input name="Reset" type="reset" value="Reset" /> 
							   <input name="Back" type="button" value="Back" onclick="window.location='Subject_ExamTab_Examination_Edit_Teacher.jsp?idSubject=<%=ridSubject%>&idExam=<%=ridExam%>'" /></td>
							</td>
						</tr>
				    </form>
                  </table>
            
                </td>
		
		</tr>
	</table>
</td>	
	
	

</tr>
</table></td>	
<!--- End Body --->


<!--- Begin Footer --->



  </tr>
    </table>	  </td>
  </tr>
	</table>

		</a><table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><img src="Picture/spacer.gif" width="1" height="1" border="0"></a></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Picture/footer-bg.gif" ><a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><img src="Picture/spacer.gif" width="1" height="18" border="0"></a></td>	
			</tr>												
		</table>

		
		<a href="Subject_ScoreTab_SubjectFinal_Teacher1.jsp"><span>&nbsp;<br></span>

	</a></body>
</html>




<!--- End Footer --->


 
 
<% } %>