<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
			ridSubject = ridSubject.replaceAll(" ","");
		String ridExam =	 thaistring.MS874ToUnicode(request.getParameter("idExam"));
			ridExam = ridExam.replaceAll(" ","");
		String rcheckbox =	 thaistring.MS874ToUnicode(request.getParameter("checkbox"));
	System.out.println(ridExam);
	System.out.println(rcheckbox);
	if(rcheckbox!= null) {
			teacher.setAnnouceExam(ridExam,rcheckbox);
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
	} else {
			teacher.setAnnouceExam(ridExam,"0");
	}

//		teacher.editRemind(ridRemind,rstrTopic,rstrDescription,rdateDate,rdateTime,rstrWarningType,rdateWarningDate);
		response.sendRedirect("Subject_ExamTab_Examination_Teacher.jsp?idSubject="+ridSubject);

%>
<% } %>