<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  )  {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%
	String idGroups[] = request.getParameterValues("idGroup");
	String scores[] = request.getParameterValues("score");
	if(idGroups!= null) {
		for (int i = 0;i<idGroups.length;i++){
			idGroups[i] = thaistring.MS874ToUnicode(idGroups[i]);
			scores[i] = thaistring.MS874ToUnicode(scores[i]);
			scores[i] = scores[i].replaceAll(" ","");
			System.out.println(idGroups[i]);
			System.out.println(scores[i]);
			if (!scores[i].equals("")) {
				teacher.checkGroup(idGroups[i],scores[i]);
			}
			//adminpower.writedocumenttype.deleteDocumentType(new Integer(checkdelete[i]));
		}//for
	}
	String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
	String ridAssignment =	 thaistring.MS874ToUnicode(request.getParameter("idAssignment"));
	ridAssignment = ridAssignment.replaceAll(" ","");
	ridSubject = ridSubject.replaceAll(" ","");

	response.sendRedirect("Subject_AssignmentTab_AssignmentDetail_Teacher.jsp?idSubject="+ridSubject+"&idAssignment="+ridAssignment);
%>
<% } %>



<!--- End Footer --->
