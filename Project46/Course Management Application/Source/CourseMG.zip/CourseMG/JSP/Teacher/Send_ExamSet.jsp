<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="ClassMGR.News.*" %>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
		String ridSubject =	 thaistring.MS874ToUnicode(request.getParameter("idSubject"));
		String ridExSet =	 thaistring.MS874ToUnicode(request.getParameter("idExSet"));
	   if (ridExSet == null) ridExSet = "";
		ridSubject = ridSubject.replaceAll(" ","");
		response.sendRedirect("Subject_ExamTab_Examination_Add_Teacher.jsp?idSubject="+ridSubject+"&idExSet="+ridExSet);

%>
<% } %>