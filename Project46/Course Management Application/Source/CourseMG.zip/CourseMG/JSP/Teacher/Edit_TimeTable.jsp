<%@page contentType="text/html; charset=windows-874"%> 
<jsp:useBean id="thaistring" class="ClassMGR.ThaiString" scope="application"/>
<jsp:useBean id="teacher" class="ClassMGR.User.Teacher" scope="application"/>
<jsp:useBean id="helper" class="ClassMGR.Helper" scope="application"/>
<jsp:useBean id="mySmartUpload" scope="page" class="com.jspsmart.upload.SmartUpload" />
<%@ page import="ClassMGR.User.*" %>
<%@ page import="java.text.*" %>
<%@ page import="java.util.*" %>
<%@ page import="com.jspsmart.upload.*"%>
<%	teacher=(Teacher)session.getAttribute("auth"); %>
<%	if( teacher == null  ||  !teacher.getRole().equals("Teacher")  ) {
		response.sendRedirect("../log_in.jsp"); 
	} else {
%>
<%	
	mySmartUpload.initialize(pageContext);
	mySmartUpload.upload();

		String filename = mySmartUpload.getFiles().getFile(0).getFileName();

	String idTimeTable		= new String(); 
	String idSubject		= new String(); 
	String type		= new String(); 
	String topic		= new String(); 
	String description		= new String(); 

		
	java.util.Enumeration e = mySmartUpload.getRequest().getParameterNames();  	
	// Retreive parameters 	
	while (e.hasMoreElements()) {  		
		String key = (String)e.nextElement(); 		
		String[] values = mySmartUpload.getRequest().getParameterValues(key);			 		 	
		// Browse the current parameter values 		
		if(key.equals("idTimeTable")){
			idTimeTable = thaistring.MS874ToUnicode(values[0]);
		}//idTimeTable
		if(key.equals("idSubject")){
			idSubject = thaistring.MS874ToUnicode(values[0]);
		}//idSubject
		if(key.equals("type")){
			type = thaistring.MS874ToUnicode(values[0]);
		}//type
		if(key.equals("topic")){
			topic = thaistring.MS874ToUnicode(values[0]);
		}//topic
		if(key.equals("description")){
			description = thaistring.MS874ToUnicode(values[0]);
		}//description
	}//while

		idSubject = idSubject.replaceAll(" ","");
		idTimeTable = idTimeTable.replaceAll(" ","");
		type = type.replaceAll(" ","");

		String rtype = " ";
		if(type.equals("�Ҥ��ɮ�")) rtype = "theory";
		if(type.equals("�Ҥ��Ժѵ�")) rtype = "action";


	String upfilename = "";
	if(!(filename.equals(""))){
	     upfilename =upfilename + "s" + idSubject + "t" + idTimeTable + helper.getTypeFile(filename);
		mySmartUpload.getFiles().getFile(0).saveAs("/Upload/TimeTable/"+upfilename.toLowerCase());
	} 

		
		teacher.editTimeTable(idTimeTable,rtype,topic,description,upfilename.toLowerCase());
		response.sendRedirect("Subject_TimetableTab_Detail_Teacher.jsp?idSubject="+idSubject);

%>
<% } %>