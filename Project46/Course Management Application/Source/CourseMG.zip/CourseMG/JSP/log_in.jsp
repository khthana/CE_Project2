<?xml version="1.0" encoding="windows-874"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>.:: L o g i n ::.</title>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
		<title>.:: L o g i n ::.Course Management</title>
		<link rel="stylesheet" href="style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">  	
<!--		<script language="JavaScript1.2" src="file:///E|/Project/groove/fw_menu.js" tppabs="http://www.groove.net/js/fw_menu.js"></script> -->
	<style type="text/css">
<!--
.style2 {font-size: 14px}
.style7 {color: #0000CC; font-family: Arial, Helvetica, sans-serif; font-size: 14px;}
.style10 {color: #006699; font-family: Arial, Helvetica, sans-serif; font-size: 14px; }
-->
    </style>
</head>
	<body bgcolor="#B2E57F" topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" style="background-image: url(/images/common/header-bg.gif); background-repeat: no-repeat;" >








<!--- End Header --->

<!--- Begin Top Nav Bar --->



<script language="JavaScript"><!--
if (self.location != top.location) top.location = self.location;
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="1024">
	
	<tr valign=top>	
	
		
		<td rowspan="3" width="135"><img src="Teacher/Picture/Logo.jpg"  width="135" height="70" border="0" /></td>
			
	
	
		<td rowspan=3 width="60"><img src="Teacher/Picture/header-curve1.gif" width="60" height="70" border="0"></td>
		<td width="92" background="Teacher/Picture/header-bg.gif" ><img src="Teacher/Picture/header-curve2.gif" width="40" height="36" border="0"></td>
		<td width="800" background="Teacher/Picture/header-bg.gif" align=right>
	</tr>
	<tr valign=top>	
		<td colspan=2 align="right">
		</td>
	</tr>
	<tr valign=top>	
		<td bgcolor="#FFFFFF" colspan="20"><img src="Teacher/Picture/Space_Menu.gif" width="1464%" height="9" border="0"></td>
<!--		<td bgcolor="#FFFFFF"><img src="file:///E|/Project/groove/spacer.gif" tppabs="http://www.groove.net/images/common/spacer.gif" width="1" height="9" border="0"></td>
-->
	</tr>
</table>




<!--- End Top Nav Bar --->

<!--- Begin Left Nav Bar --->




<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>	
		<td bgcolor="#FFFFFF">

		<img src="Picture/spacer.gif" width="1" height="15" border="0"><BR>
			<table border="0" cellpadding="0" cellspacing="0" width="948">
				<tr valign=top>	

		<td width="210">
		
		



<!-- *******************************************    BEGIN: PRODUCTS   ************************************************************* -->


		
				
            </td>

		


<!--- End Left Nav Bar --->


<!--- Begin Body --->

<td width="738">
	<table border="0" cellspacing="0" cellpadding="0" width="736">
		<!--Display the spacer line if there is no graphical header (text only)-->
		
		
		
		
		<!--- Display local nav (if used)--->
		
		
		

 
<!--- Local Nav --->

	<!---BUILD OUT PARTNERS NAV--->
	
	
		
		
				
	
		
<!--- End Local Nav --->



		
		
		<tr>
			<td width="210" colspan="2">
				<img src="Teacher/Picture/spacer.gif"  width="10" height="15" border="0"></td>
		</tr> 
		<tr> 
			    <td>                  
                    <form action="signin.jsp" method="Post">
					  <table border="0" align="center" cellpadding="0" cellspacing="3" width="96%">
                          <tr> 
                            <td colspan="3" bgcolor="#66CC00" class="bodythai12"><strong class="style7">Log in </strong></td>
                          </tr>
                          <tr> 
                            <td width="38">&nbsp;</td>
                            <td width="103" class="style7">Username : </td>
                            <td width="203"><input name="user_id" type="text"   size="20"/></td>
                             <td width="348">&nbsp;</td>
                         </tr>
                          <tr> 
                            <td width="38">&nbsp;</td>
                            <td width="103" class="style7">Password : </td>
                            <td width="203"><input name="password" type="password"   size="20"/></td>
                            <td width="348">&nbsp;</td>
                         </tr>
                          <tr> 
                            <td width="38">&nbsp;</td>
                            <td width="103" class="style7">&nbsp;</td>
                        <td width="203">
                          <input type="submit" name="Submit" value="Login" />
                          </a>
                          <input type="reset" name="Submit2" value="Reset" /></td>
                             <td width="348">&nbsp;</td>
                         </tr>
      
						</table>
					
					</form>
                  <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                  <p>&nbsp;</p>
                  <p>&nbsp;</p>
                <p>&nbsp;</p></td>
		</tr>
	</table>
</td>	

<!--- End Body --->


<!--- Begin Footer --->



			  </tr>
		  </table>
				
	  </td>
  </tr>
	</table>

		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td bgcolor="#333366"><img src="Picture/spacer.gif" width="1" height="1" border="0"></td>	
			</tr>
			<tr>	
				
    <td width="100%" bgcolor="#333366">&nbsp; </td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0">		
			<tr>
				<td colspan="3" background="Teacher/Picture/footer-bg.gif" ><img src="Teacher/Picture/spacer.gif" width="1" height="18" border="0"></td>	
			</tr>												
		</table>

		
		<span>&nbsp;<br></span>

	</body>
</html>




<!--- End Footer --->


 
 
