//----------------------------------------------------------------------------
// File: VoiceServer.cpp
//
// Desc: The VoiceClientServer sample is a simple DirectPlay 
//       voice-based client/server application. 
//
// Copyright (c) 1999-2001 Microsoft Corp. All rights reserved.
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <basetsd.h>
#include <dplay8.h>
#include <dpaddr.h>
#include <dxerr8.h>
#include <tchar.h>
#include "NetVoice.h"
#include "VoiceClientServer.h"
#include "DXUtil.h"
#include "DSUtil.h"
#include "resource.h"
#include <dsound.h>
#pragma comment(lib,"dsound.lib")
#include <fstream>
#include <string>
#include <iostream>
#include <process.h>
using std::string;
using namespace std;






//-----------------------------------------------------------------------------
// Player context locking defines
//-----------------------------------------------------------------------------
CRITICAL_SECTION g_csPlayerContext;
#define PLAYER_LOCK()                   EnterCriticalSection( &g_csPlayerContext ); 
#define PLAYER_ADDREF( pPlayerInfo )    if( pPlayerInfo ) pPlayerInfo->lRefCount++;
#define PLAYER_RELEASE( pPlayerInfo )   if( pPlayerInfo ) { pPlayerInfo->lRefCount--; if( pPlayerInfo->lRefCount <= 0 ) SAFE_DELETE( pPlayerInfo ); } pPlayerInfo = NULL;
#define PLAYER_UNLOCK()                 LeaveCriticalSection( &g_csPlayerContext );


//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
#define VOICESERVER_DEFAULT_PORT           0x6502 // arbitrary port number for this app





//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
IDirectPlay8Server* g_pDPServer                  = NULL;    // DirectPlay server object
CNetVoice*         g_pNetVoice                   = NULL;    // DirectPlay voice helper class
HINSTANCE          g_hInst                       = NULL;    // HINST of app
HWND               g_hDlg                        = NULL;    // HWND of main dialog
LONG               g_lNumberOfActivePlayers      = 0;       // Number of players currently in session
TCHAR              g_strAppName[256]             = TEXT("VoiceServer");
TCHAR              g_strSessionName[MAX_PATH];              // Session name
DWORD              g_dwPort;                                // Port
HRESULT            g_hrDialog;                              // Exit code for app 
BOOL               g_bServerStarted              = FALSE;   // TRUE if the server has started
GUID               g_guidDVSessionCT;                       // GUID for choosen voice compression

//..........Sound File.........
CWaveFile*                  g_pWaveFile;



//-----------------------------------------------------------------------------
// Function-prototypes
//-----------------------------------------------------------------------------
HRESULT WINAPI   DirectPlayMessageHandler( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer );
HRESULT CALLBACK DirectPlayVoiceServerMessageHandler( LPVOID lpvUserContext, DWORD dwMessageType, LPVOID lpMessage );
INT_PTR CALLBACK ServerDlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );
HRESULT  StartServer( HWND hDlg );
VOID     StopServer( HWND hDlg );
VOID     DisplayPlayers( HWND hDlg );
HRESULT  SendCreatePlayerMsg( APP_PLAYER_INFO* pPlayerInfo, DPNID dpnidTarget );
HRESULT  SendWorldStateToNewPlayer( DPNID dpnidPlayer );
HRESULT  SendDestroyPlayerMsgToAll( APP_PLAYER_INFO* pPlayerInfo );
HRESULT  EnumVoiceCompressionCodecs( HWND hDlg );
HRESULT SetGroupAndTarget( MSG_STATECHANGE_CLIENT* pPlayerStateChangedMsg);
HRESULT	CreateGroupForTalk(DPNID*  dwGroup);
HRESULT DeleteGroupStopTalk(MSG_STATECHANGE_CLIENT* pPlayerStateChangedMsg);
void SendClientChangeState(MSG_STATECHANGE_CLIENT* pTmpMsg , DPNID dpnidTarget );
void SendSet_IDToNewPlayer( DPNID dpnidNewPlayer );
HRESULT  RemoveClientFormConference(DPNID clientDPNID);
HRESULT AddNewClientToConference(DPNID dpnidNewPlayer);
HRESULT SetTransmitionToConference(DPNID dpnidNewPlayer);
//......Save VoiceMail form Client........
VOID OnSaveSoundFile( HWND hDlg,WAVEFORMATEX* wfxWaveFormat,DPNID senderName,char* FolderName) ;
HRESULT RecordCapturedData(VOID* pbCaptureData,DWORD dwCaptureLength,VOID* pbCaptureData2,DWORD dwCaptureLength2) ;

//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point for the application.  Since we use a simple dialog for 
//       user interaction we don't need to pump messages.
//-----------------------------------------------------------------------------
INT APIENTRY WinMain( HINSTANCE hInst, HINSTANCE hPrevInst, 
                      LPSTR pCmdLine, INT nCmdShow )
{
    HKEY    hDPlaySampleRegKey;
    BOOL    bConnectSuccess = FALSE;

    g_hInst = hInst; 
    InitializeCriticalSection( &g_csPlayerContext );

    // Read persistent state information from registry
    RegCreateKeyEx( HKEY_CURRENT_USER, DPLAY_SAMPLE_KEY, 0, NULL,
                    REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, 
                    &hDPlaySampleRegKey, NULL );
    DXUtil_ReadStringRegKey( hDPlaySampleRegKey, TEXT("Session Name"), 
                             g_strSessionName, MAX_PATH, TEXT("Test") );
    DXUtil_ReadIntRegKey( hDPlaySampleRegKey, TEXT("VoiceServer Port"), 
                          &g_dwPort, VOICESERVER_DEFAULT_PORT );

    // Init COM so we can use CoCreateInstance
    CoInitializeEx( NULL, COINIT_MULTITHREADED );
    // For this sample, we just start a simple dialog box server
    g_hrDialog = S_OK;
    DialogBox( hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC) ServerDlgProc );

    if( FAILED( g_hrDialog ) )
    {
        if( g_hrDialog == DPNERR_CONNECTIONLOST )
        {
            MessageBox( NULL, TEXT("The DirectPlay session was lost. ")
                        TEXT("The server will now quit."),
                        g_strAppName, MB_OK | MB_ICONERROR );
        }
        else
        {
            DXTRACE_ERR( TEXT("DialogBox"), g_hrDialog );
            MessageBox( NULL, TEXT("An error occured. ")
                        TEXT("The server will now quit."),
                        g_strAppName, MB_OK | MB_ICONERROR );
        }
    }

    DXUtil_WriteStringRegKey( hDPlaySampleRegKey, TEXT("Session Name"), g_strSessionName );
    DXUtil_WriteIntRegKey( hDPlaySampleRegKey, TEXT("VoiceServer Port"), g_dwPort );

    StopServer( NULL );

    RegCloseKey( hDPlaySampleRegKey );
    DeleteCriticalSection( &g_csPlayerContext );
    CoUninitialize();

    return TRUE;
}




//-----------------------------------------------------------------------------
// Name: ServerDlgProc()
// Desc: Handles dialog messages
//-----------------------------------------------------------------------------
INT_PTR CALLBACK ServerDlgProc( HWND hDlg, UINT msg, 
                                WPARAM wParam, LPARAM lParam )
{
    switch( msg ) 
    {
        case WM_INITDIALOG:
        {
            g_hDlg = hDlg;
			// Load and set the icon
            HICON hIcon = LoadIcon( g_hInst, MAKEINTRESOURCE( IDI_ICON2 ) );
            SendMessage( hDlg, WM_SETICON, ICON_BIG,   (LPARAM) hIcon );  // Set big icon
            SendMessage( hDlg, WM_SETICON, ICON_SMALL, (LPARAM) hIcon );  // Set small icon

            SetWindowText( hDlg, TEXT("VoiceServer") );
            SetDlgItemText( hDlg, IDC_SESSION_NAME, g_strSessionName );

            // Set the port to either a number or blank
            if( g_dwPort != 0 )
                SetDlgItemInt( hDlg, IDC_PORT, g_dwPort, FALSE );
            else
                SetDlgItemText( hDlg, IDC_PORT, TEXT("") );

            SetDlgItemText( hDlg, IDC_STATUS, TEXT("Server stoped.") );

            EnumVoiceCompressionCodecs( hDlg );
            CheckRadioButton( hDlg, IDC_FORWARDING, IDC_MIXING, IDC_FORWARDING );

	         PostMessage( hDlg, WM_APP_UPDATE_STATS, 0, 0 );

            break;
        }

        case WM_APP_UPDATE_STATS:
        {
            // Update the number of Client
            TCHAR strNumberPlayers[32];

            wsprintf( strNumberPlayers, TEXT("%d"), g_lNumberOfActivePlayers );
            SetDlgItemText( hDlg, IDC_NUM_PLAYERS, strNumberPlayers );
            DisplayPlayers( hDlg );
            break;
        }

        case WM_COMMAND:
        {
            switch( LOWORD(wParam) )
            {
                case IDC_START:
                    if( !g_bServerStarted )
                    {
                        if( FAILED( g_hrDialog = StartServer( hDlg ) ) )
                        {
                            DXTRACE_ERR( TEXT("StartServer"), g_hrDialog );
                            EndDialog( hDlg, 0 );
                        }
                    }
                    else
                    {
                        StopServer( hDlg );
                    }

                    // Update the UI
                    if( g_bServerStarted )
                        SetDlgItemText( hDlg, IDC_START, TEXT("Stop Server") );
                    else
                        SetDlgItemText( hDlg, IDC_START, TEXT("Start Server") );

                    EnableWindow( GetDlgItem( hDlg, IDC_SESSION_NAME ), !g_bServerStarted );
                    EnableWindow( GetDlgItem( hDlg, IDC_COMPRESSION_COMBO ), !g_bServerStarted );
                    EnableWindow( GetDlgItem( hDlg, IDC_FORWARDING ), !g_bServerStarted );
                    EnableWindow( GetDlgItem( hDlg, IDC_MIXING ), !g_bServerStarted );                                               
                    EnableWindow( GetDlgItem( hDlg, IDC_PORT ), !g_bServerStarted );

                    break;

                case IDCANCEL:
                    StopServer( hDlg );
                    EndDialog( hDlg, 0 );
                    return TRUE;
            }
            break;
        }
    }

    return FALSE; // Didn't handle message
}




//-----------------------------------------------------------------------------
// Name: EnumVoiceCompressionCodecs()
// Desc: Asks DirectPlay Voice what voice compression codecs are availible
//       and fills the combo box thier names and GUIDs.
//-----------------------------------------------------------------------------
HRESULT EnumVoiceCompressionCodecs( HWND hDlg )
{
    LPDIRECTPLAYVOICECLIENT pVoiceClient        = NULL;
    LPDVCOMPRESSIONINFO     pdvCompressionInfo  = NULL;
    LPGUID  pGuid         = NULL;
    LPBYTE  pBuffer       = NULL;
    DWORD   dwSize        = 0;
    DWORD   dwNumElements = 0;
    HWND    hPulldown     = GetDlgItem( hDlg, IDC_COMPRESSION_COMBO );
    HRESULT hr;
    LONG    lIndex;
    LONG    lFirst;

    CoInitializeEx( NULL, COINIT_MULTITHREADED );
    if( FAILED( hr = CoCreateInstance( CLSID_DirectPlayVoiceClient, NULL, 
                                       CLSCTX_INPROC_SERVER, IID_IDirectPlayVoiceClient, 
                                       (VOID**) &pVoiceClient ) ) )
        return DXTRACE_ERR( TEXT("CoCreateInstance"), hr );

    hr = pVoiceClient->GetCompressionTypes( pBuffer, &dwSize, &dwNumElements, 0 );
    if( hr != DVERR_BUFFERTOOSMALL && FAILED(hr) )
        return DXTRACE_ERR( TEXT("GetCompressionTypes"), hr );

    pBuffer = new BYTE[dwSize];
    if( FAILED( hr = pVoiceClient->GetCompressionTypes( pBuffer, &dwSize, 
                                                        &dwNumElements, 0 ) ) )
        return DXTRACE_ERR( TEXT("GetCompressionTypes"), hr );

    SAFE_RELEASE( pVoiceClient );
    CoUninitialize();

    pdvCompressionInfo = (LPDVCOMPRESSIONINFO) pBuffer;
    for( DWORD dwIndex = 0; dwIndex < dwNumElements; dwIndex++ )
    {
        TCHAR strName[MAX_PATH];
        DXUtil_ConvertWideStringToGeneric( strName, 
                                           pdvCompressionInfo[dwIndex].lpszName );

        lIndex = (LONG)SendMessage( hPulldown, CB_ADDSTRING, 0, (LPARAM) strName );

        pGuid = new GUID;
        (*pGuid) = pdvCompressionInfo[dwIndex].guidType;
        SendMessage( hPulldown, CB_SETITEMDATA, lIndex, (LPARAM) pGuid );

        if( pdvCompressionInfo[dwIndex].guidType == DPVCTGUID_SC03 )
            lFirst = lIndex;
    }

    SAFE_DELETE_ARRAY( pBuffer );
    SendMessage( hPulldown, CB_SETCURSEL, lFirst, 0 );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DirectPlayMessageHandler
// Desc: Handler for DirectPlay messages.  This function is called by
//       the DirectPlay message handler pool of threads, so be careful of thread
//       synchronization problems with shared memory
//-----------------------------------------------------------------------------
HRESULT WINAPI DirectPlayMessageHandler( PVOID pvUserContext, 
                                         DWORD dwMessageId, 
                                         PVOID pMsgBuffer )
{
    // Try not to stay in this message handler for too long, otherwise
    // there will be a backlog of data.  The best solution is to 
    // queue data as it comes in, and then handle it on other threads.
    
    // This function is called by the DirectPlay message handler pool of 
    // threads, so be careful of thread synchronization problems with shared memory

    switch( dwMessageId )
    {
        case DPN_MSGID_CREATE_PLAYER:
        {
            HRESULT hr;
            PDPNMSG_CREATE_PLAYER pCreatePlayerMsg;
            pCreatePlayerMsg = (PDPNMSG_CREATE_PLAYER)pMsgBuffer;

            // Get the peer info and extract its name
            DWORD dwSize = 0;
            DPN_PLAYER_INFO* pdpPlayerInfo = NULL;
            hr = g_pDPServer->GetClientInfo( pCreatePlayerMsg->dpnidPlayer, 
                                             pdpPlayerInfo, &dwSize, 0 );
            if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            {
                if( hr == DPNERR_INVALIDPLAYER )
                {
                    // Ignore this message if this is for the host
                    break;
                }

                return DXTRACE_ERR( TEXT("GetClientInfo"), hr );
            }
            pdpPlayerInfo = (DPN_PLAYER_INFO*) new BYTE[ dwSize ];
            ZeroMemory( pdpPlayerInfo, dwSize );
            pdpPlayerInfo->dwSize = sizeof(DPN_PLAYER_INFO);
            hr = g_pDPServer->GetClientInfo( pCreatePlayerMsg->dpnidPlayer, 
                                       pdpPlayerInfo, &dwSize, 0 );
            if( FAILED(hr) )
                return DXTRACE_ERR( TEXT("GetClientInfo"), hr );

            // Create a new and fill in a APP_PLAYER_INFO
            APP_PLAYER_INFO* pPlayerInfo = new APP_PLAYER_INFO;
            ZeroMemory( pPlayerInfo, sizeof(APP_PLAYER_INFO) );
            pPlayerInfo->lRefCount   = 1;
            pPlayerInfo->dpnidPlayer = pCreatePlayerMsg->dpnidPlayer;
			pPlayerInfo->ps.dwGroup  = pCreatePlayerMsg->dpnidPlayer;
			pPlayerInfo->ps.dwTarget=0;

            // This stores a extra TCHAR copy of the player name for 
            // easier access.  This will be redundent copy since DPlay 
            // also keeps a copy of the player name in GetClientInfo()
            DXUtil_ConvertWideStringToGeneric( pPlayerInfo->strPlayerName, 
                                               pdpPlayerInfo->pwszName, MAX_PLAYER_NAME );

            SAFE_DELETE_ARRAY( pdpPlayerInfo );
			
            // Tell DirectPlay to store this pPlayerInfo 
            // pointer in the pvPlayerContext.
            pCreatePlayerMsg->pvPlayerContext = pPlayerInfo;

			SendSet_IDToNewPlayer(pCreatePlayerMsg->dpnidPlayer);
            // Send all connected players a message telling about this new player
            SendCreatePlayerMsg( pPlayerInfo, DPNID_ALL_PLAYERS_GROUP );

            // Tell this new player about the world state
            SendWorldStateToNewPlayer( pCreatePlayerMsg->dpnidPlayer );


            // Update the number of active players, and 
            // post a message to the dialog thread to update the 
            // UI.  This keeps the DirectPlay message handler 
            // from blocking
            InterlockedIncrement( &g_lNumberOfActivePlayers );
            if( g_hDlg != NULL )
                PostMessage( g_hDlg, WM_APP_UPDATE_STATS, 0, 0 );

            break;
        }

        case DPN_MSGID_DESTROY_PLAYER:
        {
            PDPNMSG_DESTROY_PLAYER pDestroyPlayerMsg;
            pDestroyPlayerMsg = (PDPNMSG_DESTROY_PLAYER)pMsgBuffer;
            APP_PLAYER_INFO* pPlayerInfo = (APP_PLAYER_INFO*) pDestroyPlayerMsg->pvPlayerContext;

            // Ignore this message if this is the host player
            if( pPlayerInfo == NULL )
                break; 

            // Send all connected players a message telling about this destroyed player
            SendDestroyPlayerMsgToAll( pPlayerInfo );

            PLAYER_LOCK();                  // enter player context CS
            PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
            PLAYER_UNLOCK();                // leave player context CS

            // Update the number of active players, and 
            // post a message to the dialog thread to update the 
            // UI.  This keeps the DirectPlay message handler 
            // from blocking
            InterlockedDecrement( &g_lNumberOfActivePlayers );
            if( g_hDlg != NULL )
                PostMessage( g_hDlg, WM_APP_UPDATE_STATS, 0, 0 );

            break;
        }

        case DPN_MSGID_TERMINATE_SESSION:
        {
            PDPNMSG_TERMINATE_SESSION pTerminateSessionMsg;
            pTerminateSessionMsg = (PDPNMSG_TERMINATE_SESSION)pMsgBuffer;

            g_hrDialog = DPNERR_CONNECTIONLOST;
            EndDialog( g_hDlg, 0 );
            break;
        }

        case DPN_MSGID_RECEIVE:
        {
             PDPNMSG_RECEIVE pReceiveMsg;
            pReceiveMsg = (PDPNMSG_RECEIVE)pMsgBuffer;
            APP_PLAYER_INFO* pPlayerInfo = (APP_PLAYER_INFO*) pReceiveMsg->pvPlayerContext;

            MSG_GENERIC* pMsg = (MSG_GENERIC*) pReceiveMsg->pReceiveData;
            // This simple voice server doesn't expect any msgs from the clients
			switch (pMsg->dwType)
			{
				case MESSAGE_MSGID_STATECHANGE_CLIENT:
				{
					MSG_STATECHANGE_CLIENT* pTmpMsg;
					pTmpMsg = (MSG_STATECHANGE_CLIENT*) pMsg;
					HRESULT	hr;
					if (pTmpMsg->flage==1)
					{
				//	 Create the groups if we are the host player
						hr=CreateGroupForTalk(&pPlayerInfo->ps.dwGroup);
						if(FAILED(hr))
							return DXTRACE_ERR( TEXT("CreateGroup"), hr );
 			    // Add Client and Set Transmittion between dwGroup,dwTarget
						hr=SetGroupAndTarget(pTmpMsg);
						if(FAILED(hr))
							return DXTRACE_ERR( TEXT("SetGroupAndTarget"), hr );
					} 
					else if (pTmpMsg->flage==2)
					{
						if (pTmpMsg->conference==FALSE)
						{
					 //DeleteGroupe->dwGroup or dwTarget
							hr=DeleteGroupStopTalk(pTmpMsg);
							if(FAILED(hr))
								return DXTRACE_ERR( TEXT("DeleteGroupStopTalk"), hr );
							pTmpMsg->ps.dwTarget=0;
						}
						else if (pTmpMsg->conference==TRUE)
						{		//remove client form conference session
							hr=RemoveClientFormConference(pTmpMsg->dpnidPlayer);
					 		if(FAILED(hr))
								return DXTRACE_ERR( TEXT("RemoveClientFormConference"), hr );
							pTmpMsg->conference=FALSE;
						}
					}
					else if (pTmpMsg->flage==0)
						if(pTmpMsg->conference==TRUE)
						{
							//Add new Client to Conference Session
							AddNewClientToConference( pTmpMsg->dpnidPlayer);

							hr=SetTransmitionToConference(pTmpMsg->dpnidPlayer) ;						
							if(  FAILED( hr ) )
								return DXTRACE_ERR( TEXT("AddPlayerToConference"), hr );
						}
					SendClientChangeState(pTmpMsg,DPNID_ALL_PLAYERS_GROUP);
					break;
				}
				
				case MESSAGE_MSGID_CREATVOICEMAIL:
					{
						MSG_CREATE_VOICEMAIL* pTmpMsg;
						pTmpMsg = (MSG_CREATE_VOICEMAIL*) pMsg;
						WAVEFORMATEX wfxWaveFormat;
						HRESULT	hr;
						wfxWaveFormat.cbSize=pTmpMsg->cbSize;
						wfxWaveFormat.nAvgBytesPerSec=pTmpMsg->nAvgBytesPerSec;
						wfxWaveFormat.nBlockAlign=pTmpMsg->nBlockAlign;
						wfxWaveFormat.nChannels=pTmpMsg->nChannels;
						wfxWaveFormat.nSamplesPerSec=pTmpMsg->nSamplesPerSec;
						wfxWaveFormat.wBitsPerSample=pTmpMsg->wBitsPerSample;
						wfxWaveFormat.wFormatTag=pTmpMsg->wFormatTag;
						OnSaveSoundFile(g_hDlg,&wfxWaveFormat,pTmpMsg->dpnidPlayer,pTmpMsg->FolderName );
						break;
					}

				case MESSAGE_MSGID_FINISH_VOICEMAIL:
					{
			        // Close the wav file
				        SAFE_DELETE( g_pWaveFile );
						break;
					}
				default :
					{
						UINT    dwDataWrote;
						HRESULT hr;
						if( FAILED(  hr=g_pWaveFile->Write( pReceiveMsg->dwReceiveDataSize, 
                                              (BYTE*)pReceiveMsg->pReceiveData, 
                                              &dwDataWrote ) ) )
							return DXTRACE_ERR( TEXT("Write"), hr );
						break;
					}

			}

	break;
        }
    }
    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: DirectPlayVoiceServerMessageHandler()
// Desc: The callback for DirectPlayVoice server messages.  
//-----------------------------------------------------------------------------
HRESULT CALLBACK DirectPlayVoiceServerMessageHandler( LPVOID lpvUserContext, DWORD dwMessageType,
                                                      LPVOID lpMessage )
{
    // This simple sample doesn't respond to any server messages
//	MessageBox(NULL,dwMessageType,TEXT("ERROR",),MB_OK | MB_ICONERROR );
    HWND hDlg = (HWND) lpvUserContext;

    switch( dwMessageType )
    {
		case DVMSGID_CONNECTRESULT :
			break;
		case DVMSGID_CREATEVOICEPLAYER :
			break;
		case DVMSGID_DELETEVOICEPLAYER :
			break;
		case DVMSGID_DISCONNECTRESULT :
			break;
		case DVMSGID_GAINFOCUS :
			break;
		case DVMSGID_HOSTMIGRATED :
			break;
		case DVMSGID_INPUTLEVEL :
			break;
		case DVMSGID_LOCALHOSTSETUP :
			break;
		case DVMSGID_LOSTFOCUS :
			break;

		case DVMSGID_OUTPUTLEVEL :
			break;
		case DVMSGID_PLAYEROUTPUTLEVEL :
			break;
		case DVMSGID_PLAYERVOICESTART :
			{
				DVMSG_PLAYERVOICESTART* pMsg = (DVMSG_PLAYERVOICESTART*) lpMessage;
				break;
			}
		case DVMSGID_PLAYERVOICESTOP :
			{
				DVMSG_PLAYERVOICESTOP* pMsg = (DVMSG_PLAYERVOICESTOP*) lpMessage;
				break;
			}
		case DVMSGID_RECORDSTART :
			{
			DVMSG_RECORDSTART* pMsg = (DVMSG_RECORDSTART*) lpMessage;
			break;
			}
		case DVMSGID_RECORDSTOP :
			{
				DVMSG_RECORDSTOP* pMsg = (DVMSG_RECORDSTOP*) lpMessage;
				break;
			}
		case DVMSGID_SESSIONLOST:
			{
				g_hrDialog = DPNERR_CONNECTIONLOST;
				EndDialog( hDlg, 0 );
				break;
			}
		case DVMSGID_SETTARGETS :
			break;


    }
	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: StartServer
// Desc: 
//-----------------------------------------------------------------------------
HRESULT StartServer( HWND hDlg )
{

    DWORD dwSessionType;
    int lCurSelection;
    HRESULT hr;
    PDIRECTPLAY8ADDRESS pDP8AddrLocal = NULL;

    SetDlgItemText( hDlg, IDC_STATUS, TEXT("Starting server...") );
    SetCursor( LoadCursor(NULL, IDC_WAIT) );

    WCHAR wstrSessionName[MAX_PATH];
    GetDlgItemText( hDlg, IDC_SESSION_NAME, g_strSessionName, MAX_PATH );
    DXUtil_ConvertGenericStringToWide( wstrSessionName, g_strSessionName );

    BOOL bPortTranslated;
    g_dwPort = GetDlgItemInt( hDlg, IDC_PORT, &bPortTranslated, FALSE );
    if( !bPortTranslated )
        g_dwPort = 0;

    // Create IDirectPlay8Server
    if( FAILED( hr = CoCreateInstance( CLSID_DirectPlay8Server, NULL, 
                                       CLSCTX_INPROC_SERVER,
                                       IID_IDirectPlay8Server, 
                                       (LPVOID*) &g_pDPServer ) ) )
        return DXTRACE_ERR( TEXT("CoCreateInstance"), hr );

    // Init IDirectPlay8Server
    if( FAILED( hr = g_pDPServer->Initialize( NULL, DirectPlayMessageHandler, 0 ) ) )
        return DXTRACE_ERR( TEXT("Initialize"), hr );

    hr = CoCreateInstance( CLSID_DirectPlay8Address, NULL, 
                           CLSCTX_ALL, IID_IDirectPlay8Address, 
                           (LPVOID*) &pDP8AddrLocal );
    if( FAILED(hr) )
    {
        DXTRACE_ERR( TEXT("CoCreateInstance"), hr );
        goto LCleanup;
    }

    hr = pDP8AddrLocal->SetSP( &CLSID_DP8SP_TCPIP );
    if( FAILED(hr) )
    {
        DXTRACE_ERR( TEXT("SetSP"), hr );
        goto LCleanup;
    }

    // Add the port to pDP8AddrLocal, if the port is non-zero.
    // If the port is 0, then DirectPlay will pick a port, 
    // Application will typically hard code the port so the 
    // user need not know it
    if( g_dwPort != 0 )
    {
        if( FAILED( hr = pDP8AddrLocal->AddComponent( DPNA_KEY_PORT, 
                                                      &g_dwPort, sizeof(g_dwPort),
                                                      DPNA_DATATYPE_DWORD ) ) )
            return DXTRACE_ERR( TEXT("AddComponent"), hr );
    }

    DPN_APPLICATION_DESC dpnAppDesc;
    ZeroMemory( &dpnAppDesc, sizeof(DPN_APPLICATION_DESC) );
    dpnAppDesc.dwSize           = sizeof( DPN_APPLICATION_DESC );
    dpnAppDesc.dwFlags          = DPNSESSION_CLIENT_SERVER;
    dpnAppDesc.guidApplication  = g_guidApp;
    dpnAppDesc.pwszSessionName  = wstrSessionName;

    hr = g_pDPServer->Host( &dpnAppDesc, &pDP8AddrLocal, 1, NULL, NULL, NULL, 0  );
    if( FAILED(hr) )
    {
        DXTRACE_ERR( TEXT("Host"), hr );
        goto LCleanup;
    }

    // Get the selected compression codec
    g_guidDVSessionCT = DPVCTGUID_DEFAULT;

    lCurSelection = (LONG)SendDlgItemMessage( hDlg, IDC_COMPRESSION_COMBO, CB_GETCURSEL, 0, 0 );
    if( lCurSelection != CB_ERR )
    {
        GUID* pGuidCT = (LPGUID) SendDlgItemMessage( hDlg, IDC_COMPRESSION_COMBO, 
                                                    CB_GETITEMDATA, lCurSelection, 0 );
        if( pGuidCT != NULL )
            g_guidDVSessionCT = (*pGuidCT);
    }

    // Create a DirectPlay Voice session
    g_pNetVoice = new CNetVoice( NULL, DirectPlayVoiceServerMessageHandler );

    if( IsDlgButtonChecked( hDlg, IDC_MIXING ) == BST_CHECKED )
        dwSessionType = DVSESSIONTYPE_MIXING;
    else
        dwSessionType = DVSESSIONTYPE_FORWARDING;

    if( FAILED( g_hrDialog = g_pNetVoice->Init( hDlg, TRUE, FALSE,
                                                g_pDPServer, dwSessionType, 
                                                &g_guidDVSessionCT, NULL ) ) )
    {
        if( FAILED(g_hrDialog) ) 
            DXTRACE_ERR( TEXT("Init"), g_hrDialog );

        EndDialog( hDlg, 0 );
        return g_hrDialog;
    }

    SetCursor( LoadCursor(NULL, IDC_ARROW) );
    g_bServerStarted = TRUE;
    SetDlgItemText( hDlg, IDC_STATUS, TEXT("Server started.") );
	// create conference session
	DWORD varConference=1;
	hr=CreateGroupForTalk(&varConference);
	 if( FAILED(hr) ) 
            DXTRACE_ERR( TEXT("CreateGroupForTalk(&varConference)"), g_hrDialog );

LCleanup:
    SAFE_RELEASE( pDP8AddrLocal );
    SAFE_RELEASE( pDP8AddrLocal );

    return hr;
}




//-----------------------------------------------------------------------------
// Name: StopServer
// Desc: 
//-----------------------------------------------------------------------------
VOID StopServer( HWND hDlg )
{
    if( hDlg )
        SetDlgItemText( hDlg, IDC_STATUS, TEXT("Stopping server...") );
    SetCursor( LoadCursor(NULL, IDC_WAIT) );

    // Disconnect from the DirectPlayVoice session, 
    // and destory it if we are the host player.
    SAFE_DELETE( g_pNetVoice ); 

    if( g_pDPServer )
    {
        g_pDPServer->Close(0);
        SAFE_RELEASE( g_pDPServer );
    }
    g_bServerStarted = FALSE;

    SetCursor( LoadCursor(NULL, IDC_ARROW) );
    if( hDlg )
        SetDlgItemText( hDlg, IDC_STATUS, TEXT("Server stoped.") );
}



    
//-----------------------------------------------------------------------------
// Name: DisplayPlayers
// Desc: 
//-----------------------------------------------------------------------------
VOID DisplayPlayers( HWND hDlg )
{
    HRESULT hr;
    DWORD dwNumPlayers = 0;
    DPNID* aPlayers = NULL;

    SendMessage( GetDlgItem(hDlg, IDC_PLAYER_LIST), LB_RESETCONTENT, 0, 0 );

    if( NULL == g_pDPServer )
        return;

    // Enumerate all the connected players
    while( TRUE )
    {
        hr = g_pDPServer->EnumPlayersAndGroups( aPlayers, &dwNumPlayers, DPNENUM_PLAYERS );
        if( SUCCEEDED(hr) )
            break;

        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return;

        SAFE_DELETE_ARRAY( aPlayers );
        aPlayers = new DPNID[ dwNumPlayers ];
    }

    // For each player, send a "create player" message to the new player
    for( DWORD i = 0; i<dwNumPlayers; i++ )
    {
        APP_PLAYER_INFO* pPlayerInfo = NULL;

        do
        {
            // Get the player context accosicated with this DPNID
            // Call GetPlayerContext() until it returns something other than DPNERR_NOTREADY
            // DPNERR_NOTREADY will be returned if the callback thread has not 
            // yet returned from DPN_MSGID_CREATE_PLAYER, which sets the player's context
            hr = g_pDPServer->GetPlayerContext( aPlayers[i], (LPVOID*) &pPlayerInfo, 0 );
        } 
        while( hr == DPNERR_NOTREADY ); 

        // Ignore this player if we can't get the context
        if( pPlayerInfo == NULL || FAILED(hr) )
            continue; 

        TCHAR strTemp[MAX_PATH];
        wsprintf( strTemp, TEXT(pPlayerInfo->strPlayerName ));
        int nIndex = (int)SendMessage( GetDlgItem(hDlg, IDC_PLAYER_LIST), LB_ADDSTRING, 
                                       0, (LPARAM)strTemp );
    }

    SAFE_DELETE_ARRAY( aPlayers );
}

                                       

    
//-----------------------------------------------------------------------------
// Name: SendCreatePlayerMsg
// Desc: Send the target player a creation message about the player identified
//       in the APP_PLAYER_INFO struct.
//-----------------------------------------------------------------------------
HRESULT SendCreatePlayerMsg( APP_PLAYER_INFO* pPlayerAbout, DPNID dpnidTarget )
{
    MSG_CREATE_CLIENT msgCreatePlayer;
    msgCreatePlayer.dwType = MESSAGE_MSGID_CREATE_CLIENT;
    msgCreatePlayer.dpnidPlayer = pPlayerAbout->dpnidPlayer;
    _tcscpy( msgCreatePlayer.strPlayerName, pPlayerAbout->strPlayerName );
	msgCreatePlayer.ps.dwGroup=pPlayerAbout->ps.dwGroup;
	msgCreatePlayer.ps.dwTarget=pPlayerAbout->ps.dwTarget;
    DPN_BUFFER_DESC bufferDesc;
    bufferDesc.dwBufferSize = sizeof(MSG_CREATE_CLIENT);
    bufferDesc.pBufferData  = (BYTE*) &msgCreatePlayer;

    // DirectPlay will tell via the message handler 
    // if there are any severe errors, so ignore any errors 
    DPNHANDLE hAsync;
    g_pDPServer->SendTo( dpnidTarget, &bufferDesc, 1,
                         0, NULL, &hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: SendSet_IDToNewPlayer
// Desc: Tell this player the dpnid of itself
//-----------------------------------------------------------------------------
void SendSet_IDToNewPlayer( DPNID dpnidNewPlayer )
{
    // Tell this player the dpnid of itself
    MSG_SET_ID msgSetID;
    msgSetID.dwType      = MESSAGE_MSGID_SET_ID;
    msgSetID.dpnidPlayer = dpnidNewPlayer;

    DPN_BUFFER_DESC bufferDesc;
    bufferDesc.dwBufferSize = sizeof(MSG_SET_ID);
    bufferDesc.pBufferData  = (BYTE*) &msgSetID;

    // DirectPlay will tell via the message handler 
    // if there are any severe errors, so ignore any errors 
    DPNHANDLE hAsync;
    g_pDPServer->SendTo( dpnidNewPlayer, &bufferDesc, 1,
                         0, NULL, &hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED );

}


    
//-----------------------------------------------------------------------------
// Name: SendWorldStateToNewPlayer
// Desc: Send the world state to the new player.  For this sample, it is just
//       "create player" message for every connected player
//-----------------------------------------------------------------------------
HRESULT SendWorldStateToNewPlayer( DPNID dpnidNewPlayer )
{
    HRESULT hr;
    DWORD dwNumPlayers = 0;
    DPNID* aPlayers = NULL;

    // Enumerate all the connected players
    while( TRUE )
    {
        hr = g_pDPServer->EnumPlayersAndGroups( aPlayers, &dwNumPlayers, DPNENUM_PLAYERS );
        if( SUCCEEDED(hr) )
            break;

        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );

        SAFE_DELETE_ARRAY( aPlayers );
        aPlayers = new DPNID[ dwNumPlayers ];
    }

    // For each player, send a "create player" message to the new player
    for( DWORD i = 0; i<dwNumPlayers; i++ )
    {
        APP_PLAYER_INFO* pPlayerInfo = NULL;

        // Don't send a create msg to the new player about itself.  This will 
        // be already done when we sent one to DPNID_ALL_PLAYERS_GROUP
        if( aPlayers[i] == dpnidNewPlayer )
            continue;  

        // Get the player context accosicated with this DPNID
        hr = g_pDPServer->GetPlayerContext( aPlayers[i], (LPVOID*) &pPlayerInfo, 0 );

        // Ignore this player if we can't get the context
        if( pPlayerInfo == NULL || FAILED(hr) )
            continue; 

        SendCreatePlayerMsg( pPlayerInfo, dpnidNewPlayer );
    }

    SAFE_DELETE_ARRAY( aPlayers );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: SendDestroyPlayerMsgToAll
// Desc: 
//-----------------------------------------------------------------------------
HRESULT SendDestroyPlayerMsgToAll( APP_PLAYER_INFO* pPlayerInfo )
{
    MSG_DESTROY_CLIENT msgDestroyPlayer;
    msgDestroyPlayer.dwType = MESSAGE_MSGID_DESTROY_CLIENT;
    msgDestroyPlayer.dpnidPlayer = pPlayerInfo->dpnidPlayer;

    DPN_BUFFER_DESC bufferDesc;
    bufferDesc.dwBufferSize = sizeof(MSG_CREATE_CLIENT);
    bufferDesc.pBufferData  = (BYTE*) &msgDestroyPlayer;

    // DirectPlay will tell via the message handler 
    // if there are any severe errors, so ignore any errors 
    DPNHANDLE hAsync;
    g_pDPServer->SendTo( DPNID_ALL_PLAYERS_GROUP, &bufferDesc, 1,
                         0, NULL, &hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: CreateGroup()
// Desc: 
//-----------------------------------------------------------------------------

HRESULT CreateGroupForTalk(DWORD*  dwGroup)
{
	HRESULT hr;
	DPN_GROUP_INFO dpGroupInfo;
    DWORD* pdwData = new DWORD;
	//pdwData=&pPlayerInfo->ps.dwGroup;
	pdwData=dwGroup;
    ZeroMemory( &dpGroupInfo, sizeof(DPN_GROUP_INFO) );
	dpGroupInfo.dwSize = sizeof( DPN_GROUP_INFO );
    dpGroupInfo.dwInfoFlags = DPNINFO_DATA;
	dpGroupInfo.pvData = pdwData;
    dpGroupInfo.dwDataSize = sizeof(DWORD);
    DPNHANDLE hAsync;
    hr = g_pDPServer->CreateGroup( &dpGroupInfo, NULL,
                                     NULL, &hAsync, 0 );
    if( FAILED( hr ) ) 
          return DXTRACE_ERR( TEXT("CreateGroup"), hr );
	else 
		 return S_OK;

}
//-----------------------------------------------------------------------------
// Name: DeleteGroupStopTalk()
// Desc: 
//-----------------------------------------------------------------------------
HRESULT DeleteGroupStopTalk(MSG_STATECHANGE_CLIENT* pPlayerStateChangedMsg)
{
	HRESULT hr;
	DPNID* aGroupsDPNID = NULL;
    DWORD dwCount = 0;

	LPDIRECTPLAYVOICESERVER pVoiceServer =g_pNetVoice->GetVoiceServer();

    do
    {
        SAFE_DELETE_ARRAY( aGroupsDPNID );
        if( dwCount ) 
            aGroupsDPNID = new DPNID[ dwCount ];
        hr = g_pDPServer->EnumPlayersAndGroups( aGroupsDPNID, &dwCount, DPNENUM_GROUPS );
    }
    while( hr == DPNERR_BUFFERTOOSMALL && dwCount != 0 );
    if( FAILED(hr) && dwCount != 0 )
        return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );
	// stop transmittion of voice 
	hr=pVoiceServer->SetTransmitTargets( pPlayerStateChangedMsg->ps.dwGroup,NULL,0,0);
	if(FAILED(hr))
		return DXTRACE_ERR( TEXT("SetTransmitTargets_Group"), hr );
	hr=pVoiceServer->SetTransmitTargets(pPlayerStateChangedMsg->ps.dwTarget,NULL,0,0);
	if(FAILED(hr))
        return DXTRACE_ERR( TEXT("SetTransmitTargets_Target"), hr );

    for( DWORD i=0; i<dwCount; i++ )
    {
        // Get group info 
        DWORD dwGroupNumber;
        DWORD dwSize = 0;
        DPN_GROUP_INFO* pdpGroupInfo = NULL;
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        pdpGroupInfo = (DPN_GROUP_INFO*) new BYTE[ dwSize ];
        ZeroMemory( pdpGroupInfo, dwSize );
        pdpGroupInfo->dwSize = sizeof(DPN_GROUP_INFO); 
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        
		if( pdpGroupInfo->pvData )
            dwGroupNumber = *( (DWORD*) pdpGroupInfo->pvData );
        else
            dwGroupNumber = 0;

        SAFE_DELETE_ARRAY( pdpGroupInfo );

		DPNHANDLE hAsync;
		if(dwGroupNumber==pPlayerStateChangedMsg->ps.dwGroup||dwGroupNumber==pPlayerStateChangedMsg->ps.dwTarget)
			if(FAILED(hr = g_pDPServer->DestroyGroup(aGroupsDPNID[i],NULL, &hAsync, 0 )))
					MessageBox(NULL,TEXT("DVERR_INVALIDTARGET"),TEXT("ERROR",),MB_OK | MB_ICONERROR );

	}

	SAFE_DELETE_ARRAY( aGroupsDPNID );
	return S_OK;
}
//-----------------------------------------------------------------------------
// Name: SetGroupAndTarget( DWORD dpnidPlayer )
// Desc: Add Client to Group and SetTransmittion between connection client
//-----------------------------------------------------------------------------
HRESULT SetGroupAndTarget( MSG_STATECHANGE_CLIENT* pPlayerStateChangedMsg)
{
    HRESULT hr;

	LPDIRECTPLAYVOICESERVER pVoiceServer =g_pNetVoice->GetVoiceServer();


    // Enumerate all groups to figure out which group we are target, and joining
    DPNID* aGroupsDPNID = NULL;
    DWORD dwCount = 0;

    do
    {
        SAFE_DELETE_ARRAY( aGroupsDPNID );
        if( dwCount ) 
            aGroupsDPNID = new DPNID[ dwCount ];
        hr = g_pDPServer->EnumPlayersAndGroups( aGroupsDPNID, &dwCount, DPNENUM_GROUPS );
    }
    while( hr == DPNERR_BUFFERTOOSMALL && dwCount != 0 );
    if( FAILED(hr) && dwCount != 0 )
        return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );

    for( DWORD i=0; i<dwCount; i++ )
    {
        // Get group info 
        DWORD dwGroupNumber;
        DWORD dwSize = 0;
        DPN_GROUP_INFO* pdpGroupInfo = NULL;
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        pdpGroupInfo = (DPN_GROUP_INFO*) new BYTE[ dwSize ];
        ZeroMemory( pdpGroupInfo, dwSize );
        pdpGroupInfo->dwSize = sizeof(DPN_GROUP_INFO); 
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        
		if( pdpGroupInfo->pvData )
            dwGroupNumber = *( (DWORD*) pdpGroupInfo->pvData );
        else
            dwGroupNumber = 0;

        SAFE_DELETE_ARRAY( pdpGroupInfo );

		DPNHANDLE hAsync;
		if( dwGroupNumber ==pPlayerStateChangedMsg->ps.dwGroup)
		{

            // Add first Client to this group
           if(  FAILED( g_pDPServer->AddPlayerToGroup( aGroupsDPNID[i], pPlayerStateChangedMsg->ps.dwGroup, 
                                                    NULL, &hAsync, 0 ) ) ) 
					return DXTRACE_ERR( TEXT("AddPlayerToGroup"), hr );
		   // Add Target Client to this group
		   else if (FAILED( g_pDPServer->AddPlayerToGroup( aGroupsDPNID[i], pPlayerStateChangedMsg->ps.dwTarget, 
                                                      NULL, &hAsync, 0 ) ) )
  					return DXTRACE_ERR( TEXT("AddPlayerToGroup"), hr );
			// set transmitTarget 
		    hr=pVoiceServer->SetTransmitTargets( pPlayerStateChangedMsg->dpnidPlayer,&aGroupsDPNID[i],1,0);
			if(FAILED(hr))
                 return DXTRACE_ERR( TEXT("SetTransmitTargets"), hr );
			hr=pVoiceServer->SetTransmitTargets(pPlayerStateChangedMsg->ps.dwTarget,&aGroupsDPNID[i],1,0);
	        if(FAILED(hr))
                 return DXTRACE_ERR( TEXT("SetTransmitTargets"), hr );
		}
	}
    SAFE_DELETE_ARRAY( aGroupsDPNID );

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: SendClientChangeState()
// Desc: 
//-----------------------------------------------------------------------------
void SendClientChangeState(MSG_STATECHANGE_CLIENT* pTmpMsg , DPNID dpnidTarget )
{

    MSG_STATECHANGE_CLIENT pPlayerStateChangedMsg;
	pPlayerStateChangedMsg.dwType = MESSAGE_MSGID_STATECHANGE_CLIENT;
	pPlayerStateChangedMsg.dpnidPlayer=pTmpMsg->dpnidPlayer;
	pPlayerStateChangedMsg.ps=pTmpMsg->ps;
	pPlayerStateChangedMsg.flage=pTmpMsg->flage;
	pPlayerStateChangedMsg.talk=pTmpMsg->talk;
	pPlayerStateChangedMsg.conference=pTmpMsg->conference;
	DPN_BUFFER_DESC bufferDesc;
	bufferDesc.dwBufferSize = sizeof(MSG_STATECHANGE_CLIENT);
	bufferDesc.pBufferData  = (BYTE*) &pPlayerStateChangedMsg;

	// send message to all client for telling about changing state 
	DPNHANDLE hAsync;
	g_pDPServer->SendTo( dpnidTarget, // dpnid
                        &bufferDesc,  // pBufferDesc
                         1,           // cBufferDesc
                         0,           // dwTimeOut
                         NULL,        // pvAsyncContext
                         &hAsync,        // pvAsyncHandle
                         DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED );

}
//-----------------------------------------------------------------------------
// Name: AddNewClientToConference()
// Desc: 
//-----------------------------------------------------------------------------

HRESULT AddNewClientToConference(DPNID dpnidNewPlayer)
{   
	HRESULT hr;

	LPDIRECTPLAYVOICESERVER pVoiceServer =g_pNetVoice->GetVoiceServer();


    // Enumerate all groups to figure out which group we are target, and joining
    DPNID* aGroupsDPNID = NULL;
    DWORD dwCount = 0;

    do
    {
        SAFE_DELETE_ARRAY( aGroupsDPNID );
        if( dwCount ) 
            aGroupsDPNID = new DPNID[ dwCount ];
        hr = g_pDPServer->EnumPlayersAndGroups( aGroupsDPNID, &dwCount, DPNENUM_GROUPS );
    }
    while( hr == DPNERR_BUFFERTOOSMALL && dwCount != 0 );
    if( FAILED(hr) && dwCount != 0 )
        return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );

    for( DWORD i=0; i<dwCount; i++ )
    {
        // Get group info 
        DWORD dwGroupNumber;
        DWORD dwSize = 0;
        DPN_GROUP_INFO* pdpGroupInfo = NULL;
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        pdpGroupInfo = (DPN_GROUP_INFO*) new BYTE[ dwSize ];
        ZeroMemory( pdpGroupInfo, dwSize );
        pdpGroupInfo->dwSize = sizeof(DPN_GROUP_INFO); 
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        
		if( pdpGroupInfo->pvData )
            dwGroupNumber = *( (DWORD*) pdpGroupInfo->pvData );
        else
            dwGroupNumber = 0;

        SAFE_DELETE_ARRAY( pdpGroupInfo );

		DPNHANDLE hAsync;
		if( dwGroupNumber ==1)
		{
            // Add first Client to this group
           if(  FAILED( g_pDPServer->AddPlayerToGroup( aGroupsDPNID[0], dpnidNewPlayer, 
                                                    NULL, &hAsync, 0 ) ) ) 
					return DXTRACE_ERR( TEXT("AddPlayerToGroup"), hr );
		}
	}
    SAFE_DELETE_ARRAY( aGroupsDPNID );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: SetTransmitionToConference(DPNID dpnidNewPlayer)
// Desc: 
//-----------------------------------------------------------------------------

HRESULT SetTransmitionToConference(DPNID dpnidNewPlayer)
{   
	HRESULT hr;

	LPDIRECTPLAYVOICESERVER pVoiceServer =g_pNetVoice->GetVoiceServer();


    // Enumerate all groups to figure out which group we are target, and joining
    DPNID* aGroupsDPNID = NULL;
    DWORD dwCount = 0;

    do
    {
        SAFE_DELETE_ARRAY( aGroupsDPNID );
        if( dwCount ) 
            aGroupsDPNID = new DPNID[ dwCount ];
        hr = g_pDPServer->EnumPlayersAndGroups( aGroupsDPNID, &dwCount, DPNENUM_GROUPS );
    }
    while( hr == DPNERR_BUFFERTOOSMALL && dwCount != 0 );
    if( FAILED(hr) && dwCount != 0 )
        return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );

    for( DWORD i=0; i<dwCount; i++ )
    {
        // Get group info 
        DWORD dwGroupNumber;
        DWORD dwSize = 0;
        DPN_GROUP_INFO* pdpGroupInfo = NULL;
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        pdpGroupInfo = (DPN_GROUP_INFO*) new BYTE[ dwSize ];
        ZeroMemory( pdpGroupInfo, dwSize );
        pdpGroupInfo->dwSize = sizeof(DPN_GROUP_INFO); 
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        
		if( pdpGroupInfo->pvData )
            dwGroupNumber = *( (DWORD*) pdpGroupInfo->pvData );
        else
            dwGroupNumber = 0;

        SAFE_DELETE_ARRAY( pdpGroupInfo );

		if( dwGroupNumber ==1)
		{
			// set transmitTarget 
		    hr=pVoiceServer->SetTransmitTargets( dpnidNewPlayer,&aGroupsDPNID[0],1,0);
			if(FAILED(hr))
                 return DXTRACE_ERR( TEXT("SetTransmitTargets"), hr );
		}
	}
    SAFE_DELETE_ARRAY( aGroupsDPNID );

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: RemoveClientFormConference();
// Desc: 
//-----------------------------------------------------------------------------
HRESULT  RemoveClientFormConference(DPNID clientDPNID)
{
		HRESULT hr;

	LPDIRECTPLAYVOICESERVER pVoiceServer =g_pNetVoice->GetVoiceServer();
	hr=pVoiceServer->SetTransmitTargets  ( clientDPNID,NULL,0,0);
	if(FAILED(hr))
          return DXTRACE_ERR( TEXT("SetTransmitTargets"), hr );


    // Enumerate all groups to figure out which group we are target, and joining
    DPNID* aGroupsDPNID = NULL;
    DWORD dwCount = 0;

    do
    {
        SAFE_DELETE_ARRAY( aGroupsDPNID );
        if( dwCount ) 
            aGroupsDPNID = new DPNID[ dwCount ];
        hr = g_pDPServer->EnumPlayersAndGroups( aGroupsDPNID, &dwCount, DPNENUM_GROUPS );
    }
    while( hr == DPNERR_BUFFERTOOSMALL && dwCount != 0 );
    if( FAILED(hr) && dwCount != 0 )
        return DXTRACE_ERR( TEXT("EnumPlayersAndGroups"), hr );

    for( DWORD i=0; i<dwCount; i++ )
    {
        // Get group info 
        DWORD dwGroupNumber;
        DWORD dwSize = 0;
        DPN_GROUP_INFO* pdpGroupInfo = NULL;
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) && hr != DPNERR_BUFFERTOOSMALL )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        pdpGroupInfo = (DPN_GROUP_INFO*) new BYTE[ dwSize ];
        ZeroMemory( pdpGroupInfo, dwSize );
        pdpGroupInfo->dwSize = sizeof(DPN_GROUP_INFO); 
        hr = g_pDPServer->GetGroupInfo( aGroupsDPNID[i], pdpGroupInfo, &dwSize, 0 );
        if( FAILED(hr) )
            return DXTRACE_ERR( TEXT("GetGroupInfo"), hr );
        
		if( pdpGroupInfo->pvData )
            dwGroupNumber = *( (DWORD*) pdpGroupInfo->pvData );
        else
            dwGroupNumber = 0;

        SAFE_DELETE_ARRAY( pdpGroupInfo );

		DPNHANDLE hAsync;
		if( dwGroupNumber ==1)
		{
            // Add first Client to this group
			if(  FAILED( g_pDPServer->RemovePlayerFromGroup( aGroupsDPNID[0], clientDPNID, 
                                                    NULL, &hAsync, 0 ) ) ) 
					return DXTRACE_ERR( TEXT("AddPlayerToGroup"), hr );
		}
	}
    SAFE_DELETE_ARRAY( aGroupsDPNID );

    return S_OK;

}

//-----------------------------------------------------------------------------
// Name: OnSaveSoundFile()
// Desc: Called when the user requests to save to a sound file
//-----------------------------------------------------------------------------
VOID  OnSaveSoundFile( HWND hDlg,WAVEFORMATEX* wfxWaveFormat,DPNID senderName,char* FolderName) 
{
    HRESULT hr;
    static TCHAR strFileName[MAX_PATH] = TEXT("");
    static TCHAR strPath[MAX_PATH] = TEXT("");

	// Setup the OPENFILENAME structure
    OPENFILENAME ofn = { sizeof(OPENFILENAME), hDlg, NULL,
                         TEXT("Wave Files\0*.wav\0All Files\0*.*\0\0"), NULL,
						 0, 1,strFileName, MAX_PATH, NULL, 0, strPath ,
                         TEXT("Save Sound File"),
                         OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | 
                         OFN_HIDEREADONLY    | OFN_NOREADONLYRETURN, 
                         0, 0, TEXT(".wav"), 0, NULL, NULL };
    strcpy( strPath, "C:\\SoundBuffer\\" );
	char* fullPath=strncat(strPath,FolderName,MAX_PATH);
	strcpy(strPath,fullPath);
	strcpy(  strFileName,strPath);
	char* file=strncat(FolderName,".wav",MAX_PATH);
	char* fullFile=strncat( strFileName,"\\",MAX_PATH);
	fullPath=strncat(fullFile,file,MAX_PATH);
	strcpy( strFileName,fullPath);
	//strFileName=strcat(strPath,(char*)folderName);
    SAFE_DELETE( g_pWaveFile );
    g_pWaveFile = new CWaveFile;

    // Get the format of the capture buffer in g_wfxCaptureWaveFormat
    
    // Load the wave file
    if( FAILED( hr = g_pWaveFile->Open( strFileName, wfxWaveFormat, WAVEFILE_WRITE ) ) )
    {
        DXTRACE_ERR( TEXT("Open"), hr );
        return;
    }

    // Remember the path for next time
    strcpy( strPath, strFileName );
    char* strLastSlash = strrchr( strPath, '\\' );
    strLastSlash[0] = '\0';
}
//------------------------------------------------------------------------ -----
// Name: RecordCapturedData()
// Desc: Copies data from the capture buffer to the output buffer 
//-----------------------------------------------------------------------------
HRESULT RecordCapturedData(VOID* pbCaptureData,DWORD dwCaptureLength) 
{
    HRESULT hr;
    UINT    dwDataWrote;

    // Write the data into the wav file
    if( FAILED( hr = g_pWaveFile->Write( dwCaptureLength, 
                                              (BYTE*)pbCaptureData, 
                                              &dwDataWrote ) ) )
        return DXTRACE_ERR( TEXT("Write"), hr );

    return S_OK;
}
