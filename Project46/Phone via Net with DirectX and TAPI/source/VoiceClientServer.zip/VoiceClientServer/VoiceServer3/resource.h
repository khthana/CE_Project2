//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VoiceServer.rc
//
#define IDD_MAIN                        101
#define IDI_ICON1                       105
#define IDI_ICON2                       105
#define IDC_NUM_PLAYERS                 1002
#define IDC_SESSION_NAME                1004
#define IDC_START                       1005
#define IDC_STATUS                      1006
#define IDC_PORT                        1007
#define IDC_COMPRESSION_COMBO           1008
#define IDC_FORWARDING                  1009
#define IDC_MIXING                      1010
#define IDC_PLAYER_LIST                 1016
#define IDI_MAIN                        11014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
