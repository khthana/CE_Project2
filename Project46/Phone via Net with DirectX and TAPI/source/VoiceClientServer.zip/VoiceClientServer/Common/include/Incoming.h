#ifndef _INCOMING_H_
#define _INCOMING_H_


#include <windows.h>
#include <dplay8.h>
#include <dpaddr.h>
#include <tchar.h>
#define MAXTERMINALS    = 5;

class INCOMING
{
public: 
	INCOMING(HINSTANCE hInst, HWND hWndParent);
	~INCOMING();
	BOOL CALLBACK IncomingDialogProc( HWND hDlg,
									UINT uMsg,
									WPARAM wParam,
									LPARAM lParam
								);

	HRESULT  RegisterTapiEventInterface();
	HRESULT  ListenOnAddresses();
	HRESULT  ListenOnThisAddress(ITAddress * pAddress);
	HRESULT	 AnswerTheCall();
	HRESULT  DisconnectTheCall();
	void	ReleaseTheCall();
	void	DoMessage(LPWSTR pszMessage );
	void	SetStatusMessage(LPWSTR pszMessage);
	HRESULT	InitializeTapi();
	void	ShutdownTapi();
	void	EnableButton(int ID );
	void	DisableButton(int ID );
	BOOL	AddressSupportsMediaType(ITAddress * pAddress,
									long lMediaType );
	HRESULT InitIncomimg();
	BOOL   IsVideoCaptureStream(ITStream * pStream );
	HRESULT	GetVideoRenderTerminal(ITAddress   * pAddress,
                   ITTerminal ** ppTerminal
                  );
	HRESULT	EnablePreview(
              ITAddress * pAddress,
              ITStream * pStream
             );
	HRESULT	GetTerminal(
            ITAddress   * pAddress,
            ITStream    * pStream,
            ITTerminal ** ppTerminal
           );

	HRESULT	SelectTerminalsOnCall(
                     ITAddress * pAddress,
                     ITBasicCallControl * pCall
                     );



	HINSTANCE               ghInst;
	ITTAPI *                gpTapi;
	ITBasicCallControl *    gpCall;
	HWND                    ghDlg;
	BOOL                    gfAutoAnswer;
	CTAPIEventNotification      * gpTAPIEventNotification;
	ULONG                         gulAdvise;

}

#endif 