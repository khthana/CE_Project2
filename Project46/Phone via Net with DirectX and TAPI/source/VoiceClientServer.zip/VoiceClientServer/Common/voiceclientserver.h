//----------------------------------------------------------------------------
// File: VoiceClientServer.h
//
// Desc: see voiceclient.cpp
//
// Copyright (c) 1999-2001 Microsoft Corp. All rights reserved.
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
#define DPLAY_SAMPLE_KEY        TEXT("Software\\Microsoft\\DirectX DirectPlay Samples")
#define MAX_PLAYER_NAME         14
#define WM_APP_DISPLAY_PLAYERS  (WM_APP + 0)
#define WM_APP_UPDATE_STATS     (WM_APP + 1)
#define WM_CHANGE_BUTTONSTATE    (WM_APP + 2)

// This GUID allows DirectPlay to find other instances of the same game on
// the network.  So it must be unique for every game, and the same for 
// every instance of that game.  // {AD8EF550-EB5D-49b8-9C13-DC6CCDA33FC5}
GUID g_guidApp = { 0xad8ef550, 0xeb5d, 0x49b8, { 0x9c, 0x13, 0xdc, 0x6c, 0xcd, 0xa3, 0x3f, 0xc5 } };

//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
struct PLAYER_STATE
{	
    DPNID        dwGroup;   // Group # that player joined in
    DPNID        dwTarget;  // Group # that player is targeting 
						    // and it is the same name of plyer
};


struct APP_PLAYER_INFO
{
    LONG  lRefCount;                        // Ref count so we can cleanup when all  threads 
		                                    // are done w/ this object
    DPNID dpnidPlayer;                      // DPNID of player
    BOOL  bTalking;                         // Is the player talking
											//btalking=0 -> not talk
											//btalking=1 -> talk with a client
	BOOL conference;
	int bStatus	;							// 0=active,1=talking,2=slient  ...jam...
    BOOL  bHalfDuplex;                      // If true, then player cannot talk
    TCHAR strPlayerName[MAX_PLAYER_NAME];   // Player name
    PLAYER_STATE ps;                        // State of player
    APP_PLAYER_INFO* pNext;
    APP_PLAYER_INFO* pPrev;
};





//-----------------------------------------------------------------------------
// App specific DirectPlay messages and structures 
//-----------------------------------------------------------------------------
#define MESSAGE_MSGID_STATECHANGE_CLIENT   4
#define MESSAGE_MSGID_CREATE_CLIENT    1
#define MESSAGE_MSGID_DESTROY_CLIENT   2
#define MESSAGE_MSGID_SET_ID           3
#define MESSAGE_MSGID_FINISH_VOICEMAIL        5
#define MESSAGE_MSGID_CREATVOICEMAIL        6

// Change compiler pack alignment to be BYTE aligned, and pop the current value
#pragma pack( push, 1 )


struct MSG_GENERIC
{
    DWORD dwType;
};

struct MSG_SET_ID : public MSG_GENERIC
{
    DPNID dpnidPlayer;                 // dpnid of the player 
};

struct MSG_CREATE_CLIENT : public MSG_GENERIC
{
    DPNID dpnidPlayer;                       // dpnid of the player created
    TCHAR strPlayerName[MAX_PLAYER_NAME];   // name of the player created
    PLAYER_STATE ps;
};

struct MSG_DESTROY_CLIENT : public MSG_GENERIC
{
    DPNID dpnidPlayer;                 // dpnid of the player destroyed
};
struct MSG_STATECHANGE_CLIENT : public MSG_GENERIC
{
    PLAYER_STATE ps;
	DPNID dpnidPlayer;//jam
	char  flage;		// flage=1->join for creat group of talk
						// flage=2->stop for destroy group of talk
						// flage=0->send state to client
	BOOL  talk;			//talk=0 -> not talk
						//talk=1 -> talk with a client
	BOOL conference;
};
struct MSG_FINISH_VOICEMAIL : public MSG_GENERIC
{
	DPNID dpnidPlayer; 
};

struct MSG_CREATE_VOICEMAIL : public MSG_GENERIC
{
	char FolderName[MAX_PATH];
	DPNID dpnidPlayer; 
	WORD  wFormatTag; 
	WORD  nChannels; 
	DWORD nSamplesPerSec; 
	DWORD nAvgBytesPerSec; 
	WORD  nBlockAlign; 
	WORD  wBitsPerSample; 
	WORD  cbSize; 
};

// Pop the old pack alignment
#pragma pack( pop )



