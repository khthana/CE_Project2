//----------------------------------------------------------------------------
// File: VoiceClient.cpp
//
// Desc: The VoiceClientServer sample is a simple DirectPlay 
//       voice-based client/server application. 
//
// Copyright (c) 1999-2001 Microsoft Corp. All rights reserved.
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <basetsd.h>
#include <commctrl.h>
#include <cguid.h>
#include <dplay8.h>
#include <dpaddr.h>
#include <dplobby8.h>
#include <dxerr8.h>
#include <tchar.h>
#include "DXUtil.h"
#include "DSUtil.h"
#include "NetVoice.h"
#include "VoiceClientServer.h"
#include "NetClient.h"
#include "resource.h"

//...DirectSound
//#include <commdlg.h>
//#include <mmreg.h>
#include <dsound.h>
#pragma comment(lib,"dsound.lib")


//-----------------------------------------------------------------------------
// player struct locking defines
//-----------------------------------------------------------------------------
CRITICAL_SECTION g_csPlayerContext;
#define PLAYER_LOCK()                   EnterCriticalSection( &g_csPlayerContext ); 
#define PLAYER_ADDREF( pPlayerInfo )    if( pPlayerInfo ) pPlayerInfo->lRefCount++;
#define PLAYER_RELEASE( pPlayerInfo )   if( pPlayerInfo ) { pPlayerInfo->lRefCount--; if( pPlayerInfo->lRefCount <= 0 ) DestoryPlayerStruct( pPlayerInfo ); } pPlayerInfo = NULL;
#define PLAYER_UNLOCK()                 LeaveCriticalSection( &g_csPlayerContext );






//-----------------------------------------------------------------------------
//    Global variables
//-----------------------------------------------------------------------------
IDirectPlay8Client*     g_pDPClient                   = NULL;    // DirectPlay peer object
CNetClientWizard*       g_pNetClientWizard            = NULL;    // Connection wizard
IDirectPlay8LobbiedApplication* g_pLobbiedApp         = NULL;    // DirectPlay lobbied app 
CNetVoice*              g_pNetVoice                   = NULL;    // DirectPlay voice helper class
BOOL                    g_bWasLobbyLaunched           = FALSE;   // TRUE if lobby launched
HINSTANCE               g_hInst                       = NULL;    // HINST of app
HWND                    g_hDlg                        = NULL;    // HWND of main dialog
LONG                    g_lNumberOfActivePlayers      = 0;       // Number of players currently in game
APP_PLAYER_INFO         g_playerHead;
APP_PLAYER_INFO         g_pPlayerLocal;							 // Local Player Info
TCHAR                   g_strAppName[256]             = TEXT("VoiceClient");
HRESULT                 g_hrDialog;                              // Exit code for app 
DVCLIENTCONFIG          g_dvClientConfig;                        // Voice client config
BOOL                    g_bMixingSessionType          = FALSE;   // TRUE if the server is mixing, otherwise its forwarding.
BOOL					check=0;
char					g_RecrieverID[MAX_PATH];
//-----------------------------------------------------------------------------
// Defines, constants, and global variables  in DirectSound
//-----------------------------------------------------------------------------
#define NUM_REC_NOTIFICATIONS  16
//#define MAX_CLINT_NAME  20
#define MAX(a,b)        ( (a) > (b) ? (a) : (b) )

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

LPDIRECTSOUNDCAPTURE       g_pDSCapture         = NULL;
LPDIRECTSOUNDCAPTUREBUFFER g_pDSBCapture        = NULL;
LPDIRECTSOUNDNOTIFY        g_pDSNotify          = NULL;
//HINSTANCE                  g_hInst              = NULL;
GUID                       g_guidCaptureDevice  = GUID_NULL;
BOOL                       g_bRecording;
WAVEFORMATEX               g_wfxInput;
DSBPOSITIONNOTIFY          g_aPosNotify[ NUM_REC_NOTIFICATIONS + 1 ];  
HANDLE                     g_hNotificationEvent; 
BOOL                       g_abInputFormatSupported[16];
DWORD                      g_dwCaptureBufferSize;
DWORD                      g_dwNextCaptureOffset;
DWORD                      g_dwNotifySize;
CWaveFile*                 g_pWaveFile;



//-----------------------------------------------------------------------------
// Function-prototypes
//-----------------------------------------------------------------------------
HRESULT WINAPI   DirectPlayMessageHandler( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer );
HRESULT WINAPI   DirectPlayLobbyMessageHandler( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer );
HRESULT WINAPI   DirectPlayVoiceClientMessageHandler( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer );
INT_PTR CALLBACK SampleDlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );
INT_PTR CALLBACK VoiceConfigDlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );
INT_PTR CALLBACK VoiceMailDlgProc( HWND hDlg, UINT msg,WPARAM wParam, LPARAM lParam );
VOID     OnInitDialog( HWND hDlg );
HRESULT  InitDirectPlay();
VOID     AppendTextToEditControl( HWND hDlg, TCHAR* strNewLogLine );
HRESULT  GetPlayerStruct( DPNID dpnidPlayer, APP_PLAYER_INFO** ppPlayerInfo );
VOID     DestoryPlayerStruct( APP_PLAYER_INFO* pPlayerInfo );
VOID     AddPlayerStruct( APP_PLAYER_INFO* pPlayerInfo );
HRESULT  DisplayPlayersInChat( HWND hDlg );
VOID     VoiceConfigDlgOnOK( HWND hDlg );
void     SetPlayerTalking( APP_PLAYER_INFO* pPlayerInfo, BOOL bTalking );
DWORD	RetrivePlayerFromText(char* lvText);
HRESULT SendLocalStateToServer( APP_PLAYER_INFO* pPlayerInfo,char localFlage);
BOOL CheckClientTalk(DPNID dpnidPlayer);
void ChangeStateButton( HWND hDlg );
HRESULT StartRecord(  );
HRESULT StopRecord(  );
HRESULT SendCreatVoiceMail( APP_PLAYER_INFO* pPlayerInfo,char*  RecrieverID,WAVEFORMATEX* wfxCaptureWaveFormat);
HRESULT SendFinishVoiceMail()

//---------Capture sound------------
HRESULT InitDirectSound( HWND hDlg, GUID* pDeviceGuid );
HRESULT ScanInputFormatForCreateBuffer();
VOID GetWaveFormatFromIndex( INT nIndex, WAVEFORMATEX* pwfx );HRESULT RecordCapturedData() ;
HRESULT InitNotifications();
HRESULT FreeDirectSound();
VOID OnSaveSoundFile( HWND hDlg ) ;
HRESULT CreateCaptureBuffer( WAVEFORMATEX* pwfxInput );


//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point for the application.  Since we use a simple dialog for 
//       user interaction we don't need to pump messages.
//-----------------------------------------------------------------------------
INT APIENTRY WinMain( HINSTANCE hInst, HINSTANCE hPrevInst, 
                      LPSTR pCmdLine, INT nCmdShow )
{
    HRESULT hr;
    HKEY    hDPlaySampleRegKey;
    BOOL    bConnectSuccess = FALSE;

    InitCommonControls();

    ZeroMemory( &g_playerHead, sizeof(APP_PLAYER_INFO) );
    g_playerHead.pNext = &g_playerHead;
    g_playerHead.pPrev = &g_playerHead;

    ZeroMemory( &g_pPlayerLocal, sizeof(APP_PLAYER_INFO) );
    g_pPlayerLocal.pNext = &g_pPlayerLocal;
    g_pPlayerLocal.pPrev = &g_pPlayerLocal;
	

    g_hInst = hInst; 
    InitializeCriticalSection( &g_csPlayerContext );

    // Read persistent state information from registry
    RegCreateKeyEx( HKEY_CURRENT_USER, DPLAY_SAMPLE_KEY, 0, NULL,
                    REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, 
                    &hDPlaySampleRegKey, NULL );
    DXUtil_ReadStringRegKey( hDPlaySampleRegKey, TEXT("Player Name"), 
		g_pPlayerLocal.strPlayerName, MAX_PATH, TEXT("TestPlayer") );

    // Init COM so we can use CoCreateInstance
    CoInitializeEx( NULL, COINIT_MULTITHREADED );

	// Create helper class
    g_pNetClientWizard = new CNetClientWizard( hInst, g_strAppName, &g_guidApp );
    g_pNetVoice        = new CNetVoice( DirectPlayVoiceClientMessageHandler, NULL );
	

    if( FAILED( hr = InitDirectPlay() ) )
    {
        DXTRACE_ERR( TEXT("InitDirectPlay"), hr );
        MessageBox( NULL, TEXT("Failed initializing IDirectPlay8Peer. ")
                    TEXT("The sample will now quit."),
                    g_strAppName, MB_OK | MB_ICONERROR );
        return FALSE;
    }

    // If we were launched from a lobby client, then we may have connection settings
    // that we can use either host or join a game.  If not, then we'll need to prompt 
    // the user to detrimine how to connect.
    if( g_bWasLobbyLaunched && g_pNetClientWizard->HaveConnectionSettingsFromLobby() )
    {
        // If were lobby launched then the DPL_MSGID_CONNECT has already been
        // handled, and since the lobby client also sent us connection settings
        // we can use them to either host or join a DirectPlay session. 
        if( FAILED( hr = g_pNetClientWizard->ConnectUsingLobbySettings() ) )
        {
            DXTRACE_ERR( TEXT("ConnectUsingLobbySettings"), hr );
            MessageBox( NULL, TEXT("Failed to connect using lobby settings. ")
                        TEXT("The sample will now quit."),
                        g_strAppName, MB_OK | MB_ICONERROR );

            bConnectSuccess = FALSE;
        }
        else
        {
            // Read information from g_pNetClientWizard
			_tcscpy( g_pPlayerLocal.strPlayerName, g_pNetClientWizard->GetPlayerName() );

            bConnectSuccess = TRUE; 
        }
    }
    else
    {
        // If not lobby launched, prompt the user about the network 
        // connection and which session they would like to join or 
        // if they want to create a new one.

        // Setup connection wizard
        g_pNetClientWizard->SetPlayerName( g_pPlayerLocal.strPlayerName );

        // Start a connection wizard.  The wizard uses GDI dialog boxes.
        // More complex games can use this as a starting point and add a 
        // fancier graphics layer such as Direct3D.
        hr = g_pNetClientWizard->DoConnectWizard();        
        if( FAILED( hr ) ) 
        {
            DXTRACE_ERR( TEXT("DoConnectWizard"), hr );
            MessageBox( NULL, TEXT("Multiplayer connect failed. ")
                        TEXT("The sample will now quit."),
                        g_strAppName, MB_OK | MB_ICONERROR );
            bConnectSuccess = FALSE;
        } 
        else if( hr == NCW_S_QUIT ) 
        {
            // The user canceled the Multiplayer connect, so quit 
            bConnectSuccess = FALSE;
        }
        else
        {
            bConnectSuccess = TRUE; 

            // Read information from g_pNetClientWizard
            _tcscpy( g_pPlayerLocal.strPlayerName, g_pNetClientWizard->GetPlayerName() );

            // Write information to the registry
            DXUtil_WriteStringRegKey( hDPlaySampleRegKey, TEXT("Player Name"), g_pPlayerLocal.strPlayerName );
        }
    }

    if( bConnectSuccess )
    {
        // Set default DirectPlayVoice setup options
        ZeroMemory( &g_dvClientConfig, sizeof(g_dvClientConfig) );
        g_dvClientConfig.dwSize                 = sizeof(g_dvClientConfig);
        g_dvClientConfig.dwFlags                = DVCLIENTCONFIG_AUTOVOICEACTIVATED |
                                                  DVCLIENTCONFIG_AUTORECORDVOLUME;
        g_dvClientConfig.lPlaybackVolume        = DVPLAYBACKVOLUME_DEFAULT;
        g_dvClientConfig.dwBufferQuality        = DVBUFFERQUALITY_DEFAULT;
        g_dvClientConfig.dwBufferAggressiveness = DVBUFFERAGGRESSIVENESS_DEFAULT;
        g_dvClientConfig.dwThreshold            = DVTHRESHOLD_UNUSED;
        g_dvClientConfig.lRecordVolume          = DVRECORDVOLUME_LAST;
        g_dvClientConfig.dwNotifyPeriod         = 0;

        // App is now connected via DirectPlay, so start the game.  

        // For this sample, we just start a simple dialog box game.
        g_hrDialog = S_OK;
        DialogBox( hInst, MAKEINTRESOURCE(IDD_MAIN_GAME), NULL, 
                   (DLGPROC) SampleDlgProc );

        if( FAILED( g_hrDialog ) )
        {
            if( g_hrDialog == DPNERR_CONNECTIONLOST )
            {
                MessageBox( NULL, TEXT("The DirectPlay session was lost. ")
                            TEXT("The sample will now quit."),
                            g_strAppName, MB_OK | MB_ICONERROR );
            }
            else
            {
                DXTRACE_ERR( TEXT("DialogBox"), g_hrDialog );
                MessageBox( NULL, TEXT("An error occured during the game. ")
                            TEXT("The sample will now quit."),
                            g_strAppName, MB_OK | MB_ICONERROR );
            }
        }
    }

    // Disconnect from the DirectPlayVoice session, 
    // and destory it if we are the host player.
    SAFE_DELETE( g_pNetVoice ); 

    // Cleanup DirectPlay and helper classes
    if( g_pDPClient )
    {
        g_pDPClient->Close( 0 );
        SAFE_RELEASE( g_pDPClient );
    }

    if( g_pLobbiedApp )
    {
        g_pLobbiedApp->Close( 0 );
        SAFE_RELEASE( g_pLobbiedApp );
    }

    // Don't delete the wizard until we know that 
    // DirectPlay is out of its message handlers.
    // This will be true after Close() has been called. 
    SAFE_DELETE( g_pNetClientWizard );

    RegCloseKey( hDPlaySampleRegKey );
    DeleteCriticalSection( &g_csPlayerContext );
    CoUninitialize();

    return TRUE;
}




//-----------------------------------------------------------------------------
// Name: InitDirectPlay()
// Desc: 
//-----------------------------------------------------------------------------
HRESULT InitDirectPlay()
{
    DPNHANDLE hLobbyLaunchedConnection = NULL;
    HRESULT hr;

    // Create IDirectPlay8Client
    if( FAILED( hr = CoCreateInstance( CLSID_DirectPlay8Client, NULL, 
                                       CLSCTX_INPROC_SERVER,
                                       IID_IDirectPlay8Client, 
                                       (LPVOID*) &g_pDPClient ) ) )
        return DXTRACE_ERR( TEXT("CoCreateInstance"), hr );

    // Create IDirectPlay8LobbiedApplication
    if( FAILED( hr = CoCreateInstance( CLSID_DirectPlay8LobbiedApplication, NULL, 
                                       CLSCTX_INPROC_SERVER,
                                       IID_IDirectPlay8LobbiedApplication, 
                                       (LPVOID*) &g_pLobbiedApp ) ) )
        return DXTRACE_ERR( TEXT("CoCreateInstance"), hr );

    // Init the helper class, now that g_pDP and g_pLobbiedApp are valid
    g_pNetClientWizard->Init( g_pDPClient, g_pLobbiedApp );

    // Init IDirectPlay8Client
    if( FAILED( hr = g_pDPClient->Initialize( NULL, DirectPlayMessageHandler, 0 ) ) )
        return DXTRACE_ERR( TEXT("Initialize"), hr );

    // Init IDirectPlay8LobbiedApplication.  Before this Initialize() returns 
    // a DPL_MSGID_CONNECT msg may come in to the DirectPlayLobbyMessageHandler 
    // so be prepared ahead of time.
    if( FAILED( hr = g_pLobbiedApp->Initialize( NULL, DirectPlayLobbyMessageHandler, 
                                                &hLobbyLaunchedConnection, 0 ) ) )
        return DXTRACE_ERR( TEXT("Initialize"), hr );

    // IDirectPlay8LobbiedApplication::Initialize returns a handle to a connnection
    // if we have been lobby launced.  Initialize is guanteeded to return after 
    // the DPL_MSGID_CONNECT msg has been processed.  So unless a we are expected 
    // multiple lobby connections, we do not need to remember the lobby connection
    // handle since it will be recorded upon the DPL_MSGID_CONNECT msg.
    g_bWasLobbyLaunched = ( hLobbyLaunchedConnection != NULL );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: SampleDlgProc()
// Desc: Handles dialog messages
//-----------------------------------------------------------------------------
INT_PTR CALLBACK SampleDlgProc( HWND hDlg, UINT msg, 
                                WPARAM wParam, LPARAM lParam )
{
    switch( msg ) 
    {
        case WM_INITDIALOG:
        {
            OnInitDialog( hDlg );
            break;
        }

        case WM_APP_DISPLAY_PLAYERS:
        {
            DisplayPlayersInChat( hDlg );
            break;
        }

		case WM_CHANGE_BUTTONSTATE:
		{
			ChangeStateButton(hDlg)	;
			break;
		}

        case WM_TIMER:
        {
            DWORD            dwNumPlayers;
            DWORD            iIndex;
            LVITEM           lvItem;
            APP_PLAYER_INFO* pPlayerInfo = NULL;
            HWND             hListView = GetDlgItem( hDlg, IDC_PEOPLE_LIST );

            dwNumPlayers = ListView_GetItemCount( hListView );

            // Now that they are added and the listview sorted them by name,
            // run through them all caching the listview index with its dpnid
            for( iIndex = 0; iIndex < dwNumPlayers; iIndex++ )
            {
                HRESULT hr;
                APP_PLAYER_INFO* pPlayerInfo = NULL;
                DPNID dpnidPlayer;

                lvItem.mask  = LVIF_PARAM;
                lvItem.iItem = iIndex;
                ListView_GetItem( hListView, &lvItem );

                dpnidPlayer = (DPNID) lvItem.lParam;

                PLAYER_LOCK(); // enter player context CS
                hr = GetPlayerStruct( dpnidPlayer, &pPlayerInfo );
                PLAYER_ADDREF( pPlayerInfo ); // addref player, since we are using it now
                PLAYER_UNLOCK(); // leave player context CS

                if( FAILED(hr) || pPlayerInfo == NULL )
                {
                    // The player who sent this may have gone away before this 
                    // message was handled, so just ignore it
                    continue;
                }

                TCHAR strStatus[255];

                if( pPlayerInfo->bHalfDuplex )
                {
                    _tcscpy( strStatus, TEXT("Can't talk") );
                }
                else
                {
                    if( g_bMixingSessionType )
                    {
                        // With mixing servers, you can't tell which
                        // client is talking.
                        _tcscpy( strStatus, TEXT("n/a") );
                    }
                    else
                    {
                       if(g_pPlayerLocal.ps.dwTarget==pPlayerInfo->ps.dwGroup||g_pPlayerLocal.ps.dwGroup==pPlayerInfo->ps.dwTarget)
						{
							if( pPlayerInfo->bStatus==1 )
								_tcscpy( strStatus, TEXT("Talking") );
							else if( pPlayerInfo->bStatus==2)
								_tcscpy( strStatus, TEXT("Silent") );
							else if( pPlayerInfo->bStatus==0 )
								 _tcscpy( strStatus, TEXT("Online") );
						}
					    else if(pPlayerInfo->conference==TRUE)
						{
							/*if(pPlayerInfo->bTalking==TRUE)
								_tcscpy( strStatus, TEXT("Busy") );
							else*/
								_tcscpy( strStatus, TEXT("Conference") );
						}
						else if(pPlayerInfo->bTalking==TRUE)
							_tcscpy( strStatus, TEXT("Busy") );
						else
							_tcscpy( strStatus, TEXT("Online") );
                    }
                }

                lvItem.iItem      = iIndex;
                lvItem.iSubItem   = 1;
                lvItem.mask       = LVIF_TEXT;
                lvItem.pszText    = strStatus;

                PLAYER_LOCK();
                PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
                PLAYER_UNLOCK();
                SendMessage( hListView, LVM_SETITEM, 0, (LPARAM) &lvItem );
            }
            break;
        }

        case WM_COMMAND:
        {
            switch( LOWORD(wParam) )
            {
                case IDC_SETUP:
                    {
                        // Ask the user for DirectPlayVoice setup params
                        DWORD dwResult = (DWORD)DialogBox( g_hInst, 
                                                           MAKEINTRESOURCE(IDD_VOICE_SETUP), 
                                                           hDlg, (DLGPROC) VoiceConfigDlgProc );
                        if( dwResult != IDCANCEL )
                            g_pNetVoice->ChangeVoiceClientSettings( &g_dvClientConfig );
                    }
                    return TRUE;
                case IDC_JOIN_TALK:
					{
					char Text[255]={0};
					LVITEM  lvItem;
				    HWND    hListView = GetDlgItem( hDlg, IDC_PEOPLE_LIST );
					int iSelected=0;
					iSelected=SendMessage(hListView,LVM_GETNEXTITEM,-1,LVNI_FOCUSED);
					memset(&lvItem,0,sizeof(lvItem));
					lvItem.mask=LVIF_TEXT;
					lvItem.iSubItem=0;
					lvItem.pszText=Text;
					lvItem.cchTextMax=256;
					lvItem.iItem=iSelected;
					SendMessage(hListView,LVM_GETITEMTEXT, iSelected, (LPARAM)&lvItem);
					if (lvItem.pszText==NULL||*lvItem.pszText==0)
					{
						MessageBox( hDlg, TEXT("Choose a person from the list.  "), 
							TEXT("DirectPlay Sample"), MB_OK );
						return TRUE;
					}

			   //...Retrive dpnidPlayer form lvItem.pszText ...
					DPNID Target=RetrivePlayerFromText(lvItem.pszText);

				if(!CheckClientTalk(Target))
				{
					MessageBox( hDlg, TEXT("Please wait,your target is busy. "),
								TEXT("DirectPlay Sample"), MB_OK );
				}
				else
				{
					g_pPlayerLocal.bTalking=TRUE;
			   //...Check Client
					g_pPlayerLocal.ps.dwTarget=Target;
					SendLocalStateToServer(&g_pPlayerLocal,1);
					HRESULT hr;
					APP_PLAYER_INFO* pPlayerInfo;
					// get pPlayerInfo form dpnidPlayer
					hr=GetPlayerStruct(Target,&pPlayerInfo);
					if( FAILED(hr) || pPlayerInfo == NULL )
					{
		                PLAYER_UNLOCK(); // leave player context CS
				        return TRUE;
					}
					PLAYER_LOCK(); 
					PLAYER_ADDREF( pPlayerInfo ); 
					PLAYER_UNLOCK(); 
					pPlayerInfo->ps.dwTarget=g_pPlayerLocal.ps.dwGroup;
					pPlayerInfo->bTalking=TRUE;
					SendLocalStateToServer( pPlayerInfo,0);
					PLAYER_LOCK();
					PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
					PLAYER_UNLOCK();
			//...Disable Join Button
					 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ), FALSE );
			//...Enable  Stop Button
					 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),TRUE );
			//...Disable  conference Button
					 EnableWindow( GetDlgItem( hDlg, IDC_CONFERENCE ),FALSE );
					}
				return TRUE;
				}
                case IDC_STOP_TALK:
					  if(g_pPlayerLocal.conference==TRUE)
					  {
						g_pPlayerLocal.bTalking=FALSE;
						SendLocalStateToServer( &g_pPlayerLocal,2);
						g_pPlayerLocal.conference=FALSE;
					  }
					  else
					  {
						g_pPlayerLocal.bTalking=FALSE;
						HRESULT hr;
						APP_PLAYER_INFO* pPlayerInfo;
						hr=GetPlayerStruct(g_pPlayerLocal.ps.dwTarget,&pPlayerInfo);
						if( FAILED(hr) || pPlayerInfo == NULL )
						{
			                PLAYER_UNLOCK(); // leave player context CS
					        return TRUE;
						}
						PLAYER_LOCK(); 
						PLAYER_ADDREF( pPlayerInfo ); 
						PLAYER_UNLOCK(); 
						pPlayerInfo->ps.dwTarget=0;
						pPlayerInfo->bTalking=FALSE;
						SendLocalStateToServer(pPlayerInfo,0);
						PLAYER_LOCK();
						PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
						PLAYER_UNLOCK();
						SendLocalStateToServer( &g_pPlayerLocal,2);
					  }
			//...Disable Stop Button
					 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),FALSE);
			//...Enable  Join Button
					 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ),TRUE );
   			//...Enable  conference Button
					 EnableWindow( GetDlgItem( hDlg, IDC_CONFERENCE ),TRUE );
					return TRUE;
				case IDC_CONFERENCE:
			//...Disable Join Button
					 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ), FALSE );
			//...Enable  Stop Button
					 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),TRUE );
			//...Disable  conference Button
					 EnableWindow( GetDlgItem( hDlg, IDC_CONFERENCE ),FALSE );
					 g_pPlayerLocal.conference=TRUE;
                     SendLocalStateToServer( &g_pPlayerLocal,0);
					return TRUE;
				case IDC_VOICEMAIL:
					{
						BOOL  bDone;
					    DWORD dwResult;
						MSG   message;
						HRESULT hr;
						g_hNotificationEvent = CreateEvent( NULL, FALSE, FALSE, NULL );

						// Create the main dialog box, but keep it hidden for now
						hDlg = CreateDialog( g_hInst, MAKEINTRESOURCE(IDD_VOICEMAIL), NULL, VoiceMailDlgProc );

			//...capture voice...
					// ..1.Enumerate the capture devices 
					//The first device enumerated is always called the Primary Sound Driver
					//and the lpGUID parameter of the callback is NULL. 
					//This device represents the preferred playback device set by the user in Control Panel
					//GUID* pCaptureGUID = GUID_NULL;
					//g_guidCaptureDevice = *pCaptureGUID;

					// Init DirectSound
					if( FAILED( hr = InitDirectSound( hDlg, &g_guidCaptureDevice ) ) )
					{
						DXTRACE_ERR( TEXT("InitDirectSound"), hr );
						MessageBox( hDlg, "Error initializing DirectSound.  Sample will now exit.", 
							"DirectSound Sample", MB_OK | MB_ICONERROR );
						PostQuitMessage( 0 );
					}
					//..2.Test Format 
					if( FAILED( ScanInputFormatForCreateBuffer() ) )
					{
						DXTRACE_ERR( TEXT("InitDirectSound"), hr );
						MessageBox( hDlg, "Error ScaInputFormatForCreateBuffer DirectSound.  Sample will now exit.", 
							"DirectSound Sample", MB_OK | MB_ICONERROR );
						PostQuitMessage( 0 );
					}
					//...3.create capture Buffer ...->8000 MHz 8bit mono
				    if( FAILED( hr = CreateCaptureBuffer( &g_wfxInput ) ) )
						return DXTRACE_ERR( TEXT("CreateCaptureBuffer"), hr );

				 ShowWindow( hDlg, SW_SHOW ); 

				bDone = FALSE;
				while( !bDone ) 
				{ 
				dwResult = MsgWaitForMultipleObjects( 1, &g_hNotificationEvent, 
                                              FALSE, INFINITE, QS_ALLEVENTS );
				switch( dwResult )
				{
					case WAIT_OBJECT_0 + 0:
				//	 g_hNotificationEvents[0] is signaled

                // This means that DirectSound just finished playing 
                // a piece of the buffer, so we need to fill the circular 
                // buffer with new sound from the wav file

					if( FAILED( hr = RecordCapturedData() ) )
					{
                    DXTRACE_ERR( TEXT("RecordCapturedData"), hr );
                    MessageBox( hDlg, "Error handling DirectSound notifications. "
                               "Sample will now exit.", "DirectSound Sample", 
                               MB_OK | MB_ICONERROR );
                    bDone = TRUE;
					}
					
					break;

				case WAIT_OBJECT_0 + 1:
                // Windows messages are available
                while( PeekMessage( &message, NULL, 0, 0, PM_REMOVE ) ) 
                { 
                     if( !IsDialogMessage( hDlg, &message ) )  
                    {
                        TranslateMessage( &message ); 
                        DispatchMessage( &message ); 
                    }

                    if( message.message == WM_QUIT )
                        bDone = TRUE;
                }

                break;
				
				}
			}
				    // Clean up everything
					FreeDirectSound();

					CloseHandle( g_hNotificationEvent );

					return TRUE;
					}
                case IDCANCEL:
                    g_hrDialog = S_OK;
                    EndDialog( hDlg, 0 );
                    return TRUE;
            }
            break;
        }
    }

    return FALSE; // Didn't handle message
}

//-----------------------------------------------------------------------------
// Name: SampleDlgProc()
// Desc: Handles dialog messages
//-----------------------------------------------------------------------------
INT_PTR CALLBACK VoiceMailDlgProc( HWND hDlg, UINT msg,WPARAM wParam, LPARAM lParam )
{
	HRESULT hr;
    switch( msg ) 
    {
        case WM_INITDIALOG:

			return TRUE;
        case WM_COMMAND:
        {
            switch( LOWORD(wParam) )
			{
				case IDC_RECORD:
					{
						//TCHAR ID[MAX_PATH];
					    //GetDlgItemText( hDlg, IDC_PLAYER_NAME_EDIT, m_strLocalPlayerName, MAX_PATH );
						GetDlgItemText  (hDlg, IDC_RECRIEVERID,g_RecrieverID, MAX_PATH );
						//strcpy(g_RecrieverID,ID);
						SetDlgItemText( hDlg, IDC_PHONESTUTUS ,TEXT("Record...") );
						OnSaveSoundFile( hDlg ) ;
						if( FAILED( hr = StartRecord( ) ) )
		                {
				            DXTRACE_ERR( TEXT("StartRecord"), hr );
						    MessageBox( hDlg, "Error with DirectSoundCapture buffer."                            
                                "Sample will now exit.", "DirectSound Sample", 
                                MB_OK | MB_ICONERROR );
							PostQuitMessage( 0 );
						}
					//...Enable Stop Button
						 EnableWindow( GetDlgItem( hDlg, IDC_STOPRECORD),TRUE);

					//...Disable Record Button
						 EnableWindow( GetDlgItem( hDlg, IDC_RECORD),FALSE);

		
					return TRUE;
					}
				case IDC_STOPRECORD:
                    SetDlgItemText( hDlg, IDC_PHONESTUTUS ,TEXT("Stop Record") );
	                if( FAILED( hr = StopRecord( ) ) )
		                {
				            DXTRACE_ERR( TEXT("StopRecord"), hr );
						    MessageBox( hDlg, "Error with DirectSoundCapture buffer."                            
                                "Sample will now exit.", "DirectSound Sample", 
                                MB_OK | MB_ICONERROR );
							PostQuitMessage( 0 );
						}

				
					//...Disable Stop Button
						 EnableWindow( GetDlgItem( hDlg, IDC_STOPRECORD),FALSE);

					//...Enable Stop Button
						 EnableWindow( GetDlgItem( hDlg, IDC_RECORD),TRUE);

					return TRUE;

				case IDC_CANCLE:
					{
						// Stop the capture and read any data that was not caught by a notification
						StopRecord();

						// Clean up everything
						FreeDirectSound();

						CloseHandle( g_hNotificationEvent );
		                g_hrDialog = S_OK;
	                    EndDialog( hDlg, 0 );
						return TRUE;
					}
			}
		}
		break;

 
	}
	return FALSE;
}

//-----------------------------------------------------------------------------
// Name: OnInitDialog()
// Desc: Inits the dialog 
//-----------------------------------------------------------------------------
VOID OnInitDialog( HWND hDlg )
{
    LVCOLUMN column;
    RECT     rctListView;
    TCHAR    strHeader[255];
    DWORD    dwVertScrollBar;
    DWORD    dwListViewWidth;

    g_hDlg = hDlg;

    // Load and set the icon
    HICON hIcon = LoadIcon( g_hInst, MAKEINTRESOURCE( IDI_MAIN ) );
    SendMessage( hDlg, WM_SETICON, ICON_BIG,   (LPARAM) hIcon );  // Set big icon
    SendMessage( hDlg, WM_SETICON, ICON_SMALL, (LPARAM) hIcon );  // Set small icon

    SetWindowText( hDlg, g_strAppName );

    // Display local player's name
    SetDlgItemText( hDlg, IDC_PLAYER_NAME, g_pPlayerLocal.strPlayerName );

    // Setup the listview
    HWND hListView = GetDlgItem( hDlg, IDC_PEOPLE_LIST );
    dwVertScrollBar = GetSystemMetrics( SM_CXVSCROLL );  
    GetClientRect( hListView, &rctListView );
    dwListViewWidth = rctListView.right - dwVertScrollBar;
    column.mask     = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
    column.fmt      = LVCFMT_LEFT;
    column.iSubItem = -1;

    // Insert the Name column
    _tcscpy( strHeader, TEXT("Name") );
    column.cx         = dwListViewWidth * 5 / 10;
    column.pszText    = strHeader;
    column.cchTextMax = _tcslen( strHeader );
    ListView_InsertColumn( hListView, 0, &column );

    // Insert the Status column
    _tcscpy( strHeader, TEXT("Status") );
    column.cx         = dwListViewWidth * 5 / 10;
    column.pszText    = strHeader;
    column.cchTextMax = _tcslen( strHeader );
    ListView_InsertColumn( hListView, 1, &column );
		//...Disable Stop Button
		 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),FALSE);
		//...Enable  Join Button
	  	 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ),TRUE );

    // Connect to the DirectPlay Voice session
    if( FAILED( g_hrDialog = g_pNetVoice->Init( hDlg, FALSE, TRUE,
                                                g_pDPClient, DVSESSIONTYPE_FORWARDING, 
                                                NULL, &g_dvClientConfig ) ) )
    {
        if( g_hrDialog == DVERR_USERBACK )
        {
            MessageBox( hDlg, TEXT("The user backed out of the wizard.  ")
                        TEXT("This simple sample does not handle this case, so ")
                        TEXT("the sample will quit."), TEXT("DirectPlay Sample"), MB_OK );
            g_hrDialog = S_OK;
        }

        if( g_hrDialog == DVERR_USERCANCEL )
        {
            MessageBox( hDlg, TEXT("The user canceled the wizard. ")
                        TEXT("This simple sample does not handle this case, so ")
                        TEXT("the sample will quit."), TEXT("DirectPlay Sample"), MB_OK );
            g_hrDialog = S_OK;
        }

        if( g_hrDialog == DVERR_ALREADYPENDING )
        {
            MessageBox( hDlg, TEXT("Another instance of the Voice Setup Wizard is already running. ")
                        TEXT("This simple sample does not handle this case, so ")
                        TEXT("the sample will quit."), TEXT("DirectPlay Sample"), MB_OK );
            g_hrDialog = S_OK;
        }

        if( FAILED(g_hrDialog) ) 
            DXTRACE_ERR( TEXT("Init"), g_hrDialog );

        EndDialog( hDlg, 0 );
        return;
    }

    // Get the session description to figure out if we are connected to a mixing server
    IDirectPlayVoiceClient* pVoiceClient = g_pNetVoice->GetVoiceClient();
	DVSESSIONDESC dvsd;
    ZeroMemory( &dvsd, sizeof(DVSESSIONDESC) );
    dvsd.dwSize = sizeof(DVSESSIONDESC);
    pVoiceClient->GetSessionDesc( &dvsd );
    g_bMixingSessionType = (dvsd.dwSessionType == DVSESSIONTYPE_MIXING);

    // Display a warning to the user if they are in half duplex mode
    if( g_pNetVoice->IsHalfDuplex() ) 
    {
        MessageBox( hDlg, TEXT("You are running in half duplex mode. ")
                    TEXT("In half duplex mode no recording takes place."), 
                    TEXT("DirectPlay Sample"), MB_OK );
    }

    // Make a timer to update the listbox 
    // 'Status' column every so often 
    SetTimer( hDlg, 0, 250, NULL );

    PostMessage( hDlg, WM_APP_DISPLAY_PLAYERS, 0, 0 );
}




//-----------------------------------------------------------------------------
// Name: DisplayPlayersInChat()
// Desc: Displays the active players in the listview
//-----------------------------------------------------------------------------
HRESULT DisplayPlayersInChat( HWND hDlg )
{
    if( hDlg == NULL )
        return S_OK;

    LVITEM  lvItem;
    HWND    hListView = GetDlgItem( hDlg, IDC_PEOPLE_LIST );
    TCHAR   strStatus[32];
    TCHAR   strNumberPlayers[32];
    DWORD   dwNumPlayers = 0;

    // Remove all the players and re-add them in the player enum callback
    ListView_DeleteAllItems( hListView );

    PLAYER_LOCK(); // enter player context CS

    APP_PLAYER_INFO* pCurPlayer = g_playerHead.pNext;    
    while ( pCurPlayer != &g_playerHead )
    {
	/*// check dwTarget for update state of button
	  if (pCurPlayer->ps.dwTarget==g_pPlayerLocal.dpnidPlayer&&check==0)
      		  check=1;
	*/
	  if (pCurPlayer->dpnidPlayer!=g_pPlayerLocal.dpnidPlayer)
	  {
		ZeroMemory( &lvItem, sizeof(lvItem) );
        // Add the item, saving the player's name and dpnid in the listview
        lvItem.mask       = LVIF_TEXT | LVIF_PARAM;
        lvItem.iItem      = 0;
        lvItem.iSubItem   = 0;
        lvItem.pszText    = pCurPlayer->strPlayerName;
        lvItem.lParam     = (LONG) pCurPlayer->dpnidPlayer;
        lvItem.cchTextMax = _tcslen( pCurPlayer->strPlayerName );
        int nIndex = ListView_InsertItem( hListView, &lvItem );

        if( pCurPlayer->bHalfDuplex )
        {
            _tcscpy( strStatus, TEXT("Can't talk") );
        }
        else
        {
            if( g_bMixingSessionType )
            {
                // With mixing servers, you can't tell which
                // client is talking.
                _tcscpy( strStatus, TEXT("n/a") );
            }
            else
            {
                if(g_pPlayerLocal.ps.dwTarget==pCurPlayer->ps.dwGroup||g_pPlayerLocal.ps.dwGroup==pCurPlayer->ps.dwTarget)
				{
 					if( pCurPlayer->bStatus==1 )
							_tcscpy( strStatus, TEXT("Talking") );
					else if( pCurPlayer->bStatus==2)
							_tcscpy( strStatus, TEXT("Silent") );
					else if( pCurPlayer->bStatus==0 )
							 _tcscpy( strStatus, TEXT("Online") );
				}
				else if(pCurPlayer->conference==TRUE)
				{
					/*if(pCurPlayer->bTalking==TRUE)
						_tcscpy( strStatus, TEXT("Busy") );
					else*/
						_tcscpy( strStatus, TEXT("Conference") );
				}
				else if(pCurPlayer->bTalking==TRUE)
					_tcscpy( strStatus, TEXT("Busy") );
				else
					_tcscpy( strStatus, TEXT("Online") );
               }
        }
        // Start the player's status off as silent.  
        lvItem.mask       = LVIF_TEXT;
        lvItem.iItem      = nIndex;
        lvItem.iSubItem   = 1;
        lvItem.pszText    = strStatus;
        lvItem.cchTextMax = _tcslen( strStatus );
        ListView_SetItem( hListView, &lvItem );
	  }
      dwNumPlayers++;
      pCurPlayer = pCurPlayer->pNext;
	  
    }

    PLAYER_UNLOCK(); // leave player context CS
		

    wsprintf( strNumberPlayers, TEXT("%d"), dwNumPlayers );
    SetDlgItemText( hDlg, IDC_NUM_PLAYERS, strNumberPlayers );
	if (g_pPlayerLocal.conference==TRUE)
		SetDlgItemText( hDlg, IDC_STATUS, "Conference" );
	else if (g_pPlayerLocal.bTalking==TRUE)
		SetDlgItemText( hDlg, IDC_STATUS, "Talking");
	else
		SetDlgItemText( hDlg, IDC_STATUS, "Online" );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: ChangeStateButton()
// Desc: Displays the active players in the listview
//-----------------------------------------------------------------------------
void ChangeStateButton( HWND hDlg )
{
		// change state of join-stop button
		if (check==0)
		{	
		//...Disable Stop Button
		 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),FALSE);
		//...Enable  Join Button
	  	 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ),TRUE );
		//...Enable  conference Button
		 EnableWindow( GetDlgItem( hDlg, IDC_CONFERENCE ),TRUE );
		
		}else
		{
		//...Disable Join Button
		 EnableWindow( GetDlgItem( hDlg, IDC_JOIN_TALK ),FALSE);
		//...Enable  Stop Button
	  	 EnableWindow( GetDlgItem( hDlg, IDC_STOP_TALK ),TRUE );
		//...Disable  conference Button
		 EnableWindow( GetDlgItem( hDlg, IDC_CONFERENCE ),FALSE );
		}
}


//-----------------------------------------------------------------------------
// Name: DirectPlayMessageHandler
// Desc: Handler for DirectPlay messages.  This function is called by
//       the DirectPlay message handler pool of threads, so be careful of thread
//       synchronization problems with shared memory
//-----------------------------------------------------------------------------
HRESULT WINAPI DirectPlayMessageHandler( PVOID pvUserContext, 
                                         DWORD dwMessageId, 
                                         PVOID pMsgBuffer )
{
    // Try not to stay in this message handler for too long, otherwise
    // there will be a backlog of data.  The best solution is to 
    // queue data as it comes in, and then handle it on other threads.
    
    // This function is called by the DirectPlay message handler pool of 
    // threads, so be careful of thread synchronization problems with shared memory

    switch( dwMessageId )
    {
        case DPN_MSGID_TERMINATE_SESSION:
        {
            PDPNMSG_TERMINATE_SESSION pTerminateSessionMsg;
            pTerminateSessionMsg = (PDPNMSG_TERMINATE_SESSION)pMsgBuffer;

            g_hrDialog = DPNERR_CONNECTIONLOST;
            EndDialog( g_hDlg, 0 );
            break;
        }

        case DPN_MSGID_RECEIVE:
        {
            HRESULT hr;
            PDPNMSG_RECEIVE pReceiveMsg;
            pReceiveMsg = (PDPNMSG_RECEIVE)pMsgBuffer;

            MSG_GENERIC* pMsg = (MSG_GENERIC*) pReceiveMsg->pReceiveData;
            switch( pMsg->dwType )
            {
                case MESSAGE_MSGID_SET_ID:
                {
                    // The host is tell us the DPNID for this client
                    MSG_SET_ID* pSetIDMsg;
                    pSetIDMsg = (MSG_SET_ID*)pReceiveMsg->pReceiveData;
					g_pPlayerLocal.dpnidPlayer = pSetIDMsg->dpnidPlayer;
                    break;
                }

                case MESSAGE_MSGID_CREATE_CLIENT:
                {
                    // The host is telling us about a new player 
                    MSG_CREATE_CLIENT* pCreatePlayerMsg;
                    pCreatePlayerMsg = (MSG_CREATE_CLIENT*)pReceiveMsg->pReceiveData;

                    // Create a new and fill in a APP_PLAYER_INFO
                    APP_PLAYER_INFO* pPlayerInfo = new APP_PLAYER_INFO;
                    ZeroMemory( pPlayerInfo, sizeof(APP_PLAYER_INFO) );
                    pPlayerInfo->lRefCount   = 1;
                    pPlayerInfo->dpnidPlayer = pCreatePlayerMsg->dpnidPlayer;
                    _tcscpy( pPlayerInfo->strPlayerName, pCreatePlayerMsg->strPlayerName );
 					pPlayerInfo->ps.dwGroup=pCreatePlayerMsg->ps.dwGroup;
					pPlayerInfo->ps.dwTarget=pCreatePlayerMsg->ps.dwTarget;
					PLAYER_LOCK(); // enter player struct CS
                    AddPlayerStruct( pPlayerInfo );
                    PLAYER_UNLOCK(); // leave player struct CS
					
					if (g_pPlayerLocal.ps.dwGroup==0)
						g_pPlayerLocal.ps.dwGroup=pCreatePlayerMsg->ps.dwGroup;

					//SendLocalStateToServer(&g_pPlayerLocal,0);

                    // Update the number of active players, and 
                    // post a message to the dialog thread to update the 
                    // UI.  This keeps the DirectPlay message handler 
                    // from blocking
                    InterlockedIncrement( &g_lNumberOfActivePlayers );

                    if( g_hDlg != NULL )
                        PostMessage( g_hDlg, WM_APP_DISPLAY_PLAYERS, 0, 0 );
                    break;
                };
				case MESSAGE_MSGID_STATECHANGE_CLIENT:
				{
					HRESULT hr;
					MSG_STATECHANGE_CLIENT* pPlayerStateChangedMsg;
 					pPlayerStateChangedMsg = (MSG_STATECHANGE_CLIENT*) pMsg;
					APP_PLAYER_INFO* pPlayerInfo;
					hr=GetPlayerStruct(pPlayerStateChangedMsg->dpnidPlayer,&pPlayerInfo);
					if (FAILED(hr))
						  return DXTRACE_ERR( TEXT("GetPlayerStruct"), hr );
					PLAYER_LOCK(); // enter player context CS
					PLAYER_ADDREF( pPlayerInfo ); // addref player, since we are using it now
					PLAYER_UNLOCK(); // leave player context CS

				// check flage for set button
					if(pPlayerStateChangedMsg->dpnidPlayer!=g_pPlayerLocal.dpnidPlayer)
					{
						if(pPlayerStateChangedMsg->flage==1)
						{
							if(pPlayerStateChangedMsg->ps.dwTarget==g_pPlayerLocal.dpnidPlayer)
							{//-> ����¹�� enable stop button
								check=1;
								if( g_hDlg != NULL )
									PostMessage( g_hDlg, WM_CHANGE_BUTTONSTATE, 0, 0 );
							}
						}
						else if(pPlayerStateChangedMsg->flage==2)
						{
							if(pPlayerInfo->ps.dwTarget==g_pPlayerLocal.dpnidPlayer&&pPlayerInfo->ps.dwTarget!=pPlayerStateChangedMsg->ps.dwTarget&&pPlayerStateChangedMsg->ps.dwTarget==0)
							{
								check=0;
								if( g_hDlg != NULL )
									PostMessage( g_hDlg, WM_CHANGE_BUTTONSTATE, 0, 0 );
							}
						}
					}
					
					pPlayerInfo->bTalking=pPlayerStateChangedMsg->talk;
					pPlayerInfo->conference=pPlayerStateChangedMsg->conference;

					if( pPlayerInfo )
						pPlayerInfo->ps = pPlayerStateChangedMsg->ps;
					if(pPlayerInfo->dpnidPlayer==g_pPlayerLocal.dpnidPlayer)
					{
						g_pPlayerLocal.ps=pPlayerStateChangedMsg->ps;
						g_pPlayerLocal.bTalking=pPlayerStateChangedMsg->talk;
						g_pPlayerLocal.conference=pPlayerStateChangedMsg->conference;
					}

					
					
					PLAYER_LOCK();
					PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
					PLAYER_UNLOCK();
					// Post a message to the dialog thread to update the 
					// UI.  This keeps the DirectPlay message handler 
					// from blocking
					if( g_hDlg != NULL )
							PostMessage( g_hDlg, WM_APP_DISPLAY_PLAYERS, 0, 0 );
					break;

					
				};
                case MESSAGE_MSGID_DESTROY_CLIENT:
                {
                    // The host is telling us about a player that's been destroyed
                    APP_PLAYER_INFO*        pPlayerInfo = NULL;
                    MSG_DESTROY_CLIENT* pDestroyPlayerMsg;
                    pDestroyPlayerMsg = (MSG_DESTROY_CLIENT*)pReceiveMsg->pReceiveData;

                    // Get the player struct accosicated with this DPNID
                    PLAYER_LOCK(); // enter player struct CS
                    hr = GetPlayerStruct( pDestroyPlayerMsg->dpnidPlayer, &pPlayerInfo );
                    PLAYER_UNLOCK(); // leave player struct CS
                    if( FAILED(hr) || pPlayerInfo == NULL )
                    {
                        // The player who sent this may have gone away before this 
                        // message was handled, so just ignore it
                        break;
                    }
                    // Release the player struct
                    PLAYER_LOCK();                  // enter player struct CS
                    PLAYER_RELEASE( pPlayerInfo );  // Release player and cleanup if needed
                    PLAYER_UNLOCK();                // leave player struct CS

                    // Update the number of active players, and 
                    // post a message to the dialog thread to update the 
                    // UI.  This keeps the DirectPlay message handler 
                    // from blocking
                    InterlockedDecrement( &g_lNumberOfActivePlayers );

                    if( g_hDlg != NULL )
                        PostMessage( g_hDlg, WM_APP_DISPLAY_PLAYERS, 0, 0 );
                    break;
                };
            }

            break;
        }
    }

    // Make sure the DirectPlay MessageHandler calls the CNetConnectWizard handler, 
    // so it can be informed of messages such as DPN_MSGID_ENUM_HOSTS_RESPONSE.
    if( g_pNetClientWizard )
        g_pNetClientWizard->MessageHandler( pvUserContext, dwMessageId, pMsgBuffer );
    
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: AddPlayerStruct()
// Desc: Add pPlayerInfo to the circular linked list, g_playerHead
//-----------------------------------------------------------------------------
VOID AddPlayerStruct( APP_PLAYER_INFO* pPlayerInfo )
{
    pPlayerInfo->pNext = g_playerHead.pNext;
    pPlayerInfo->pPrev = &g_playerHead;

    g_playerHead.pNext->pPrev = pPlayerInfo;    
    g_playerHead.pNext = pPlayerInfo;    
}




//-----------------------------------------------------------------------------
// Name: DestoryPlayerStruct() 
// Desc: Remove pPlayerInfo from the circular linked list, g_playerHead
//-----------------------------------------------------------------------------
VOID DestoryPlayerStruct( APP_PLAYER_INFO* pPlayerInfo )
{
    pPlayerInfo->pNext->pPrev = pPlayerInfo->pPrev;
    pPlayerInfo->pPrev->pNext = pPlayerInfo->pNext;

    SAFE_DELETE( pPlayerInfo );
}




//-----------------------------------------------------------------------------
// Name: GetPlayerStruct() 
// Desc: Searchs the circular linked list, g_playerHead, for dpnidPlayer
//-----------------------------------------------------------------------------
HRESULT GetPlayerStruct( DPNID dpnidPlayer, APP_PLAYER_INFO** ppPlayerInfo )
{
    if( ppPlayerInfo == NULL )
        return E_FAIL;

    APP_PLAYER_INFO* pCurPlayer = g_playerHead.pNext;
    
    *ppPlayerInfo = NULL;
    while ( pCurPlayer != &g_playerHead )
    {
        if( pCurPlayer->dpnidPlayer == dpnidPlayer )
        {
            *ppPlayerInfo = pCurPlayer;
            return S_OK;
        }
            
        pCurPlayer = pCurPlayer->pNext;
    }

    // Not found.
    return E_FAIL;
}




//-----------------------------------------------------------------------------
// Name: DirectPlayLobbyMessageHandler
// Desc: Handler for DirectPlay lobby messages.  This function is called by
//       the DirectPlay lobby message handler pool of threads, so be careful of 
//       thread synchronization problems with shared memory
//-----------------------------------------------------------------------------
HRESULT WINAPI DirectPlayLobbyMessageHandler( PVOID pvUserContext, 
                                              DWORD dwMessageId, 
                                              PVOID pMsgBuffer )
{
    switch( dwMessageId )
    {
        case DPL_MSGID_CONNECT:
        {
            PDPL_MESSAGE_CONNECT pConnectMsg;
            pConnectMsg = (PDPL_MESSAGE_CONNECT)pMsgBuffer;

            // The CNetConnectWizard will handle this message for us,
            // so there is nothing we need to do here for this simple
            // sample.
            break;
        }

        case DPL_MSGID_DISCONNECT:
        {
            PDPL_MESSAGE_DISCONNECT pDisconnectMsg;
            pDisconnectMsg = (PDPL_MESSAGE_DISCONNECT)pMsgBuffer;

            // We should free any data associated with the lobby 
            // client here, but there is none.
            break;
        }

        case DPL_MSGID_RECEIVE:
        {
            PDPL_MESSAGE_RECEIVE pReceiveMsg;
            pReceiveMsg = (PDPL_MESSAGE_RECEIVE)pMsgBuffer;

            // The lobby client sent us data.  This sample doesn't
            // expected data from the client, but it is useful 
            // for more complex apps.
            break;
        }

        case DPL_MSGID_CONNECTION_SETTINGS:
        {
            PDPL_MESSAGE_CONNECTION_SETTINGS pConnectionStatusMsg;
            pConnectionStatusMsg = (PDPL_MESSAGE_CONNECTION_SETTINGS)pMsgBuffer;

            // The lobby client has changed the connection settings.  
            // This simple sample doesn't handle this, but more complex apps may
            // want to.
            break;
        }
    }

    // Make sure the DirectPlay MessageHandler calls the CNetConnectWizard handler, 
    // so the wizard can be informed of lobby messages such as DPL_MSGID_CONNECT
    if( g_pNetClientWizard )
        return g_pNetClientWizard->LobbyMessageHandler( pvUserContext, dwMessageId, 
                                                         pMsgBuffer );
    
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DirectPlayVoiceClientMessageHandler()
// Desc: The callback for DirectPlayVoice client messages.  
//       This handles client messages and updates the UI the whenever a client 
//       starts or stops talking.  
//-----------------------------------------------------------------------------
HRESULT CALLBACK DirectPlayVoiceClientMessageHandler( LPVOID lpvUserContext, DWORD dwMessageType,
                                                      LPVOID lpMessage )
{
    // Try not to stay in this message handler for too long, otherwise
    // there will be a backlog of data.  The best solution is to 
    // queue data as it comes in, and then handle it on other threads.
    
    // This function is called by the DirectPlay message handler pool of 
    // threads, so be care of thread synchronization problems with shared memory
    HRESULT hr;
    HWND hDlg = (HWND) lpvUserContext;

    DPNID dpnidPlayer;
    BOOL bTalking;

    switch( dwMessageType )
    {
        case DVMSGID_SESSIONLOST:
            g_hrDialog = DPNERR_CONNECTIONLOST;
            EndDialog( hDlg, 0 );
            break;

        case DVMSGID_GAINFOCUS:
        case DVMSGID_LOSTFOCUS:
        {
            TCHAR strWindowName[MAX_PATH];
            wsprintf( strWindowName, TEXT("%s%s"), g_strAppName,
                (dwMessageType == DVMSGID_LOSTFOCUS) ? TEXT(" (Focus Lost)") : TEXT("") );

            SetWindowText( hDlg, strWindowName );
            break;
        }

        case DVMSGID_RECORDSTART:             
		{ 
			DVMSG_RECORDSTART* pMsg = (DVMSG_RECORDSTART*) lpMessage;
			dpnidPlayer = g_pPlayerLocal.dpnidPlayer;
            bTalking    = 1;
            break;
        }

        case DVMSGID_RECORDSTOP:             
        {
			DVMSG_RECORDSTOP* pMsg = (DVMSG_RECORDSTOP*) lpMessage;
            dpnidPlayer = g_pPlayerLocal.dpnidPlayer;
            bTalking    = 2;
            break;
        }

        case DVMSGID_PLAYERVOICESTART:
        {
            DVMSG_PLAYERVOICESTART* pMsg = (DVMSG_PLAYERVOICESTART*) lpMessage;
            dpnidPlayer = pMsg->dvidSourcePlayerID;
            bTalking    = 1;
            break;
        }

        case DVMSGID_PLAYERVOICESTOP:
        {
            DVMSG_PLAYERVOICESTOP* pMsg = (DVMSG_PLAYERVOICESTOP*) lpMessage;
            dpnidPlayer = pMsg->dvidSourcePlayerID;
            bTalking    = 2;
            break;
        }
    }

    // With a mixing sever, the client won't recieve DVMSGID_RECORDSTART/STOP msgs.  
    // It will still receieve DVMSGID_PLAYERVOICESTART/STOP messages whenever
    // audio occurs, however the messages do not identify the source.  So
    // in this sample, if the server is in mixing mode then it just reports
    // 'n/a' for the players.  This could be done differently in more complex apps.
    if( g_bMixingSessionType )
        return S_OK;

    switch( dwMessageType )
    {
        case DVMSGID_RECORDSTART:             
        case DVMSGID_RECORDSTOP:             
        case DVMSGID_PLAYERVOICESTART:
        case DVMSGID_PLAYERVOICESTOP:
        {
            APP_PLAYER_INFO* pPlayerInfo = NULL;

            PLAYER_LOCK(); // enter player context CS
            hr = GetPlayerStruct( dpnidPlayer, &pPlayerInfo );

            if( FAILED(hr) || pPlayerInfo == NULL )
            {
                // The player who sent this may have gone away before this 
                // message was handled, so just ignore it
                PLAYER_UNLOCK(); // leave player context CS
                break;
            }

            // Update the talking status
            pPlayerInfo->bStatus = bTalking; 	

            PLAYER_UNLOCK(); // leave player context CS
        }
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: VoiceConfigDlgProc()
// Desc: Prompt the user for DirectPlayVoice setup options
//-----------------------------------------------------------------------------
INT_PTR CALLBACK VoiceConfigDlgProc( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam )
{
    DWORD dwSliderPos;

    switch( msg ) 
    {
        case WM_INITDIALOG:
            // Set the range on the sliders
            SendDlgItemMessage( hDlg, IDC_PLAYBACK_SLIDER,       TBM_SETRANGE, FALSE, MAKELONG( 0, 100 ) );
            SendDlgItemMessage( hDlg, IDC_RECORD_SLIDER,         TBM_SETRANGE, FALSE, MAKELONG( 0, 100 ) );
            SendDlgItemMessage( hDlg, IDC_QUALITY_SLIDER,        TBM_SETRANGE, FALSE, MAKELONG( DVBUFFERQUALITY_MIN, DVBUFFERQUALITY_MAX ) );
            SendDlgItemMessage( hDlg, IDC_THRESHOLD_SLIDER,    TBM_SETRANGE, FALSE, MAKELONG( DVTHRESHOLD_MIN,  DVTHRESHOLD_MAX ) );
            SendDlgItemMessage( hDlg, IDC_AGGRESSIVENESS_SLIDER, TBM_SETRANGE, FALSE, MAKELONG( DVBUFFERAGGRESSIVENESS_MIN, DVBUFFERAGGRESSIVENESS_MAX ) );

            // Setup the dialog based on the globals 

            // Set the playback controls
            if( g_dvClientConfig.lPlaybackVolume == DVPLAYBACKVOLUME_DEFAULT )
            {
                CheckRadioButton( hDlg, IDC_PLAYBACK_DEFAULT, IDC_PLAYBACK_SET, IDC_PLAYBACK_DEFAULT );
            }
            else
            {
                dwSliderPos = (DWORD) ( ( g_dvClientConfig.lPlaybackVolume - DSBVOLUME_MIN ) * 
                                          100.0f / (DSBVOLUME_MAX-DSBVOLUME_MIN) );
                CheckRadioButton( hDlg, IDC_PLAYBACK_DEFAULT, IDC_PLAYBACK_SET, IDC_PLAYBACK_SET );
                SendDlgItemMessage( hDlg, IDC_PLAYBACK_SLIDER, TBM_SETPOS, TRUE, dwSliderPos );
            }

            // Set the record controls
            if( g_dvClientConfig.dwFlags & DVCLIENTCONFIG_AUTORECORDVOLUME )
            {
                CheckRadioButton( hDlg, IDC_RECORD_DEFAULT, IDC_RECORD_AUTO, IDC_RECORD_AUTO );
            }
            else if( g_dvClientConfig.lRecordVolume == DVPLAYBACKVOLUME_DEFAULT )
            {
                CheckRadioButton( hDlg, IDC_RECORD_DEFAULT, IDC_RECORD_AUTO, IDC_RECORD_DEFAULT );
            }
            else
            {
                dwSliderPos = (DWORD) ( ( g_dvClientConfig.lRecordVolume - DSBVOLUME_MIN ) * 
                                          100.0f / (DSBVOLUME_MAX-DSBVOLUME_MIN) );
                CheckRadioButton( hDlg, IDC_RECORD_DEFAULT, IDC_RECORD_AUTO, IDC_RECORD_SET );
                SendDlgItemMessage( hDlg, IDC_RECORD_SLIDER, TBM_SETPOS, TRUE, dwSliderPos );
            }

            // Set the threshold controls
            if( g_dvClientConfig.dwFlags & DVCLIENTCONFIG_AUTOVOICEACTIVATED )
            {
                CheckRadioButton( hDlg, IDC_THRESHOLD_DEFAULT, IDC_THRESHOLD_AUTO, IDC_THRESHOLD_AUTO );
            }
            else if( g_dvClientConfig.dwThreshold == DVTHRESHOLD_DEFAULT )
            {
                CheckRadioButton( hDlg, IDC_THRESHOLD_DEFAULT, IDC_THRESHOLD_AUTO, IDC_THRESHOLD_DEFAULT );
            }
            else
            {
                CheckRadioButton( hDlg, IDC_THRESHOLD_DEFAULT, IDC_THRESHOLD_AUTO, IDC_THRESHOLD_SET );
                SendDlgItemMessage( hDlg, IDC_THRESHOLD_SLIDER, TBM_SETPOS, TRUE, g_dvClientConfig.dwThreshold );
            }

            // Set the quality controls
            if( g_dvClientConfig.dwBufferQuality == DVBUFFERQUALITY_DEFAULT )
            {
                CheckRadioButton( hDlg, IDC_QUALITY_DEFAULT, IDC_QUALITY_SET, IDC_QUALITY_DEFAULT );
            }
            else
            {
                CheckRadioButton( hDlg, IDC_QUALITY_DEFAULT, IDC_QUALITY_SET, IDC_QUALITY_SET );
                SendDlgItemMessage( hDlg, IDC_QUALITY_SLIDER, TBM_SETPOS, TRUE, g_dvClientConfig.dwBufferQuality );
            }

            // Set the aggressiveness controls
            if( g_dvClientConfig.dwBufferAggressiveness == DVBUFFERAGGRESSIVENESS_DEFAULT )
            {
                CheckRadioButton( hDlg, IDC_AGGRESSIVENESS_DEFAULT, IDC_AGGRESSIVENESS_SET, IDC_AGGRESSIVENESS_DEFAULT );
            }
            else
            {
                CheckRadioButton( hDlg, IDC_AGGRESSIVENESS_DEFAULT, IDC_AGGRESSIVENESS_SET, IDC_AGGRESSIVENESS_SET );
                SendDlgItemMessage( hDlg, IDC_AGGRESSIVENESS_SLIDER, TBM_SETPOS, TRUE, g_dvClientConfig.dwBufferAggressiveness );
            }

            return TRUE;

        case WM_NOTIFY:
            #ifndef NM_RELEASEDCAPTURE
                #define NM_RELEASEDCAPTURE (NM_FIRST-16)
            #endif
            if( ((LPNMHDR) lParam)->code == NM_RELEASEDCAPTURE )
            {
                // If this is a release capture from a slider, then automatically check 
                // its 'Set' radio button.
                switch( ((LPNMHDR) lParam)->idFrom )
                {
                case IDC_PLAYBACK_SLIDER:
                    CheckRadioButton( hDlg, IDC_PLAYBACK_DEFAULT, IDC_PLAYBACK_SET, IDC_PLAYBACK_SET );
                    break;
    
                case IDC_RECORD_SLIDER:
                    CheckRadioButton( hDlg, IDC_RECORD_DEFAULT, IDC_RECORD_AUTO, IDC_RECORD_SET );
                    break;
    
                case IDC_THRESHOLD_SLIDER:
                    CheckRadioButton( hDlg, IDC_THRESHOLD_DEFAULT, IDC_THRESHOLD_AUTO, IDC_THRESHOLD_SET );
                    break;
    
                case IDC_QUALITY_SLIDER:
                    CheckRadioButton( hDlg, IDC_QUALITY_DEFAULT, IDC_QUALITY_SET, IDC_QUALITY_SET );
                    break;
    
                case IDC_AGGRESSIVENESS_SLIDER:
                    CheckRadioButton( hDlg, IDC_AGGRESSIVENESS_DEFAULT, IDC_AGGRESSIVENESS_SET, IDC_AGGRESSIVENESS_SET );
                    break;
                }
            }
            return TRUE;            

        case WM_COMMAND:
            switch( LOWORD(wParam) )
            {
                case IDOK:
                    VoiceConfigDlgOnOK( hDlg );
                    return TRUE;

                case IDCANCEL:
                    EndDialog( hDlg, IDCANCEL );
                    return TRUE;
            }
            break;
    }

    return FALSE; // Didn't handle message
}




//-----------------------------------------------------------------------------
// Name: VoiceConfigDlgOnOK()
// Desc: Figure out all the DirectPlayVoice setup params from the dialog box,
//       and store them in global vars.
//-----------------------------------------------------------------------------
VOID VoiceConfigDlgOnOK( HWND hDlg )
{
    DWORD dwSliderPos;

    g_dvClientConfig.dwFlags = 0;

    // Figure out the playback params
    if( IsDlgButtonChecked( hDlg, IDC_PLAYBACK_DEFAULT ) )
    {
        g_dvClientConfig.lPlaybackVolume = DVPLAYBACKVOLUME_DEFAULT;
    }
    else 
    {
        dwSliderPos = (DWORD)SendDlgItemMessage( hDlg, IDC_PLAYBACK_SLIDER, TBM_GETPOS, 0, 0 );
        g_dvClientConfig.lPlaybackVolume = DSBVOLUME_MIN + (LONG) ( dwSliderPos / 100.0f * 
                                                                    (DSBVOLUME_MAX-DSBVOLUME_MIN) );
    }

    // Figure out the record params
    if( IsDlgButtonChecked( hDlg, IDC_RECORD_AUTO ) )
    {
        g_dvClientConfig.lRecordVolume = 0;
        g_dvClientConfig.dwFlags       |= DVCLIENTCONFIG_AUTORECORDVOLUME;
    }
    else if( IsDlgButtonChecked( hDlg, IDC_RECORD_DEFAULT ) )
    {
        g_dvClientConfig.lRecordVolume = DVPLAYBACKVOLUME_DEFAULT;
    }
    else 
    {
        dwSliderPos = (DWORD)SendDlgItemMessage( hDlg, IDC_RECORD_SLIDER, TBM_GETPOS, 0, 0 );
        g_dvClientConfig.lRecordVolume = DSBVOLUME_MIN + (LONG) ( dwSliderPos / 100.0f * 
                                                                  (DSBVOLUME_MAX-DSBVOLUME_MIN) );
    }

    // Figure out the threshold params
    if( IsDlgButtonChecked( hDlg, IDC_THRESHOLD_AUTO ) )
    {
        g_dvClientConfig.dwThreshold = DVTHRESHOLD_UNUSED;
        g_dvClientConfig.dwFlags       |= DVCLIENTCONFIG_AUTOVOICEACTIVATED;
    }
    else if( IsDlgButtonChecked( hDlg, IDC_THRESHOLD_DEFAULT ) )
    {
        g_dvClientConfig.dwThreshold = DVTHRESHOLD_DEFAULT;
        g_dvClientConfig.dwFlags       |= DVCLIENTCONFIG_MANUALVOICEACTIVATED;
    }
    else 
    {
        dwSliderPos = (DWORD)SendDlgItemMessage( hDlg, IDC_THRESHOLD_SLIDER, TBM_GETPOS, 0, 0 );
        g_dvClientConfig.dwThreshold = dwSliderPos;
        g_dvClientConfig.dwFlags       |= DVCLIENTCONFIG_MANUALVOICEACTIVATED;
    }

    // Figure out the quality params
    if( IsDlgButtonChecked( hDlg, IDC_QUALITY_DEFAULT ) )
    {
        g_dvClientConfig.dwBufferQuality = DVBUFFERQUALITY_DEFAULT;
    }
    else 
    {
        dwSliderPos = (DWORD)SendDlgItemMessage( hDlg, IDC_QUALITY_SLIDER, TBM_GETPOS, 0, 0 );
        g_dvClientConfig.dwBufferQuality = dwSliderPos;
    }

    // Figure out the aggressiveness params
    if( IsDlgButtonChecked( hDlg, IDC_AGGRESSIVENESS_DEFAULT ) )
    {
        g_dvClientConfig.dwBufferAggressiveness = DVBUFFERAGGRESSIVENESS_DEFAULT;
    }
    else 
    {
        dwSliderPos = (DWORD)SendDlgItemMessage( hDlg, IDC_AGGRESSIVENESS_SLIDER, TBM_GETPOS, 0, 0 );
        g_dvClientConfig.dwBufferAggressiveness = dwSliderPos;
    }

    EndDialog( hDlg, IDOK );
}

//-----------------------------------------------------------------------------
// Name: RetrivePlayerFromText()
// Desc: Retrive 
//-----------------------------------------------------------------------------


DPNID RetrivePlayerFromText(char* lvText)
{
    APP_PLAYER_INFO* pCurPlayer = g_playerHead.pNext;    
    while ( pCurPlayer != &g_playerHead )
	{
		if (strcmp(pCurPlayer->strPlayerName,lvText)==0)
			return pCurPlayer->dpnidPlayer;
		pCurPlayer = pCurPlayer->pNext;
	}

return NULL;
}
//-----------------------------------------------------------------------------
// Name: SendLocalStateToServer()
// Desc: Send the local player's state to Server
//-----------------------------------------------------------------------------
HRESULT SendLocalStateToServer( APP_PLAYER_INFO* pPlayerInfo,char localFlage)
{
        MSG_STATECHANGE_CLIENT msgPlayerStateChange;
        msgPlayerStateChange.dwType = MESSAGE_MSGID_STATECHANGE_CLIENT;
		msgPlayerStateChange.ps     = pPlayerInfo->ps;
		msgPlayerStateChange.talk   = pPlayerInfo->bTalking;
		msgPlayerStateChange.conference  = pPlayerInfo->conference;
		msgPlayerStateChange.flage	=localFlage;
		msgPlayerStateChange.dpnidPlayer=pPlayerInfo->dpnidPlayer;
        DPN_BUFFER_DESC bufferDesc;
        bufferDesc.dwBufferSize = sizeof(MSG_STATECHANGE_CLIENT);
        bufferDesc.pBufferData  = (BYTE*) &msgPlayerStateChange;
	// send message to server for telling about changing state 
        DPNHANDLE hAsync;
		g_pDPClient->Send(&bufferDesc,1,0,NULL,&hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED);
    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: SendFinishVoiceMail()
// Desc: Send the local player's state to Server
//-----------------------------------------------------------------------------
HRESULT SendFinishVoiceMail()
{
        MSG_FINISH_VOICEMAIL msgVoiceMailState;
	    msgVoiceMailState.dwType = MESSAGE_MSGID_FINISH_VOICEMAIL;
		msgVoiceMailState.dpnidPlayer=g_pPlayerLocal.dpnidPlayer;
        DPN_BUFFER_DESC bufferDesc;
        bufferDesc.dwBufferSize = sizeof(MSG_FINISH_VOICEMAIL);
        bufferDesc.pBufferData  = (BYTE*) &msgVoiceMailState;
	// send message to server for telling about changing state 
        DPNHANDLE hAsync;
		g_pDPClient->Send(&bufferDesc,1,0,NULL,&hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED);
    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: SendCreatVoiceMail()
// Desc: Send the local player's state to Server
//-----------------------------------------------------------------------------
HRESULT SendCreatVoiceMail( APP_PLAYER_INFO* pPlayerInfo,char*  RecrieverID,WAVEFORMATEX* wfxCaptureWaveFormat)
{
        MSG_CREATE_VOICEMAIL msgCreateVoiceMail;
		msgCreateVoiceMail.dwType = MESSAGE_MSGID_CREATVOICEMAIL;
		msgCreateVoiceMail.dpnidPlayer=pPlayerInfo->dpnidPlayer;
		strcpy(msgCreateVoiceMail.FolderName,RecrieverID);
		//msgCreateVoiceMail.FolderName=*RecrieverID;
		msgCreateVoiceMail.cbSize =wfxCaptureWaveFormat->cbSize;
		msgCreateVoiceMail.nAvgBytesPerSec= wfxCaptureWaveFormat->nAvgBytesPerSec;
		msgCreateVoiceMail.nBlockAlign=wfxCaptureWaveFormat->nBlockAlign;
		msgCreateVoiceMail.nChannels=wfxCaptureWaveFormat->nChannels;
		msgCreateVoiceMail.nSamplesPerSec=wfxCaptureWaveFormat->nSamplesPerSec;
		msgCreateVoiceMail.wBitsPerSample=wfxCaptureWaveFormat->wBitsPerSample;
		msgCreateVoiceMail.wFormatTag=wfxCaptureWaveFormat->wFormatTag;
        DPN_BUFFER_DESC bufferDesc;
        bufferDesc.dwBufferSize = sizeof(MSG_CREATE_VOICEMAIL);
        bufferDesc.pBufferData  = (BYTE*) &msgCreateVoiceMail;
	// send message to server for telling about changing state 
        DPNHANDLE hAsync;
		g_pDPClient->Send(&bufferDesc,1,0,NULL,&hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED);
    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: CheckClientTalk()
// Desc: Checking a Client who want to talk is talking
//-----------------------------------------------------------------------------
BOOL CheckClientTalk(DPNID dpnidPlayer)
{
	HRESULT hr;
	APP_PLAYER_INFO* pPlayerInfo = NULL;
    PLAYER_LOCK(); // enter player context CS
    hr = GetPlayerStruct( dpnidPlayer, &pPlayerInfo );
    if( FAILED(hr) || pPlayerInfo == NULL || pPlayerInfo->bTalking==1)
    {
	    PLAYER_UNLOCK(); // leave player context CS
        return 0;
    }
    PLAYER_UNLOCK(); 
	return 1;
}

//...........Capture Sound..........

//-----------------------------------------------------------------------------
// Name: InitDirectSound()
// Desc: Initilizes DirectSound
//-----------------------------------------------------------------------------
HRESULT InitDirectSound( HWND hDlg, GUID* pDeviceGuid )
{
    HRESULT hr;

    ZeroMemory( &g_aPosNotify, sizeof(DSBPOSITIONNOTIFY) * 
                               (NUM_REC_NOTIFICATIONS + 1) );
    g_dwCaptureBufferSize = 0;
    g_dwNotifySize        = 0;
    g_pWaveFile           = NULL;

    // Create IDirectSoundCapture using the preferred capture device
    if( FAILED( hr = DirectSoundCaptureCreate( pDeviceGuid, &g_pDSCapture, NULL ) ) )
        return DXTRACE_ERR( TEXT("DirectSoundCaptureCreate"), hr );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: ScanInputFormatForCreateBuffer()
// Desc: Tests to see if 16 different standard wave formats are supported by
//       the capture device 
//-----------------------------------------------------------------------------
HRESULT ScanInputFormatForCreateBuffer()
{
    HRESULT       hr;
    WAVEFORMATEX  wfx;
    //HCURSOR       hCursor;
    DSCBUFFERDESC dscbd;
    LPDIRECTSOUNDCAPTUREBUFFER pDSCaptureBuffer = NULL;
    
    // This might take a second or two, so throw up the hourglass
    //hCursor = GetCursor();
    //SetCursor( LoadCursor( NULL, IDC_WAIT ) );
    
    ZeroMemory( &wfx, sizeof(wfx));
    wfx.wFormatTag = WAVE_FORMAT_PCM;

    ZeroMemory( &dscbd, sizeof(dscbd) );
    dscbd.dwSize = sizeof(dscbd);

    // Try 16 different standard formats to see if they are supported
    for( INT iIndex = 0; iIndex < 16; iIndex++ )

    {
        GetWaveFormatFromIndex( iIndex, &wfx );

        // To test if a capture format is supported, try to create a 
        // new capture buffer using a specific format.  If it works
        // then the format is supported, otherwise not.
        dscbd.dwBufferBytes = wfx.nAvgBytesPerSec;
        dscbd.lpwfxFormat = &wfx;
        
        if( FAILED( hr = g_pDSCapture->CreateCaptureBuffer( &dscbd, 
                                                            &pDSCaptureBuffer, 
                                                            NULL ) ) )
		{
			g_abInputFormatSupported[ iIndex ] = FALSE;
		}
        else
		{
			g_abInputFormatSupported[ iIndex ] = TRUE;
			//if (wfx.nSamplesPerSec==8000 && wfx.wBitsPerSample==16)
			if(iIndex==4)
			{
				g_wfxInput=wfx;
				break;
			}
		}

    }

    //SetCursor( hCursor );
     SAFE_RELEASE( pDSCaptureBuffer );

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: GetWaveFormatFromIndex()
// Desc: Returns 16 different wave formats based on nIndex
//-----------------------------------------------------------------------------
VOID GetWaveFormatFromIndex( INT nIndex, WAVEFORMATEX* pwfx )
{
    INT iSampleRate = nIndex / 4;
    INT iType = nIndex % 4;

    switch( iSampleRate )
    {
        case 0: pwfx->nSamplesPerSec =  8000; break;
        case 1: pwfx->nSamplesPerSec = 11025; break;
        case 2: pwfx->nSamplesPerSec = 22050; break;
        case 3: pwfx->nSamplesPerSec = 44100; break;
    }

    switch( iType )
    {
        case 0: pwfx->wBitsPerSample =  8; pwfx->nChannels = 1; break;
        case 1: pwfx->wBitsPerSample = 16; pwfx->nChannels = 1; break;
        case 2: pwfx->wBitsPerSample =  8; pwfx->nChannels = 2; break;
        case 3: pwfx->wBitsPerSample = 16; pwfx->nChannels = 2; break;
    }

    pwfx->nBlockAlign = pwfx->nChannels * ( pwfx->wBitsPerSample / 8 );
    pwfx->nAvgBytesPerSec = pwfx->nBlockAlign * pwfx->nSamplesPerSec;
}

//-----------------------------------------------------------------------------
// Name: StartRecord()
// Desc: Starts or stops the capture buffer from recording
//-----------------------------------------------------------------------------
HRESULT StartRecord( )
{
    HRESULT hr;
        // Create a capture buffer, and tell the capture 
        // buffer to start recording   
        if( FAILED( hr = CreateCaptureBuffer( &g_wfxInput ) ) )
            return DXTRACE_ERR( TEXT("CreateCaptureBuffer"), hr );

        if( FAILED( hr = g_pDSBCapture->Start( DSCBSTART_LOOPING ) ) )
            return DXTRACE_ERR( TEXT("Start"), hr );
	    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: StopRecord()
// Desc: Starts or stops the capture buffer from recording
//-----------------------------------------------------------------------------
HRESULT StopRecord( )
{
    HRESULT hr;

      // Stop the capture and read any data that 
        // was not caught by a notification
        if( NULL == g_pDSBCapture )
            return S_OK;

        // Stop the buffer, and read any data that was not 
        // caught by a notification
        if( FAILED( hr = g_pDSBCapture->Stop() ) )
            return DXTRACE_ERR( TEXT("Stop"), hr );

        if( FAILED( hr = RecordCapturedData() ) )
            return DXTRACE_ERR( TEXT("RecordCapturedData"), hr );

		SendFinishVoiceMail();

        // Close the wav file
        SAFE_DELETE( g_pWaveFile );
  
    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: CreateCaptureBuffer()
// Desc: Creates a capture buffer and sets the format 
//-----------------------------------------------------------------------------
HRESULT CreateCaptureBuffer( WAVEFORMATEX* pwfxInput )
{
    HRESULT hr;
    DSCBUFFERDESC dscbd;

    SAFE_RELEASE( g_pDSNotify );
    SAFE_RELEASE( g_pDSBCapture );

    // Set the notification size
    g_dwNotifySize = MAX( 1024, pwfxInput->nAvgBytesPerSec / 8 );
    g_dwNotifySize -= g_dwNotifySize % pwfxInput->nBlockAlign;   

    // Set the buffer sizes 
    g_dwCaptureBufferSize = g_dwNotifySize * NUM_REC_NOTIFICATIONS;

    SAFE_RELEASE( g_pDSNotify );
    SAFE_RELEASE( g_pDSBCapture );

    // Create the capture buffer
    ZeroMemory( &dscbd, sizeof(dscbd) );
    dscbd.dwSize        = sizeof(dscbd);
    dscbd.dwBufferBytes = g_dwCaptureBufferSize;
    dscbd.lpwfxFormat   = pwfxInput; // Set the format during creatation

    if( FAILED( hr = g_pDSCapture->CreateCaptureBuffer( &dscbd, 
                                                        &g_pDSBCapture, 
                                                        NULL ) ) )
        return DXTRACE_ERR( TEXT("CreateCaptureBuffer"), hr );

    g_dwNextCaptureOffset = 0;
    if( FAILED( hr = InitNotifications() ) )
        return DXTRACE_ERR( TEXT("InitNotifications"), hr );

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: InitNotifications()
// Desc: Inits the notifications on the capture buffer which are handled
//       in WinMain()
//-----------------------------------------------------------------------------
HRESULT InitNotifications()
{
    HRESULT hr; 

    if( NULL == g_pDSBCapture )
        return E_FAIL;

    // Create a notification event, for when the sound stops playing
    if( FAILED( hr = g_pDSBCapture->QueryInterface( IID_IDirectSoundNotify, 
                                                    (VOID**)&g_pDSNotify ) ) )
        return DXTRACE_ERR( TEXT("QueryInterface"), hr );

    // Setup the notification positions
    for( INT i = 0; i < NUM_REC_NOTIFICATIONS; i++ )
    {
        g_aPosNotify[i].dwOffset = (g_dwNotifySize * i) + g_dwNotifySize - 1;
        g_aPosNotify[i].hEventNotify = g_hNotificationEvent;             
    }
    
    // Tell DirectSound when to notify us. the notification will come in the from 
    // of signaled events that are handled in WinMain()
    if( FAILED( hr = g_pDSNotify->SetNotificationPositions( NUM_REC_NOTIFICATIONS, 
                                                            g_aPosNotify ) ) )
        return DXTRACE_ERR( TEXT("SetNotificationPositions"), hr );

    return S_OK;
}



//------------------------------------------------------------------------ -----
// Name: RecordCapturedData()
// Desc: Copies data from the capture buffer to the output buffer 
//-----------------------------------------------------------------------------
HRESULT RecordCapturedData() 
{
    HRESULT hr;
    VOID*   pbCaptureData    = NULL;
    DWORD   dwCaptureLength;
    VOID*   pbCaptureData2   = NULL;
    DWORD   dwCaptureLength2;
    VOID*   pbPlayData       = NULL;
    UINT    dwDataWrote;
    DWORD   dwReadPos;
    DWORD   dwCapturePos;
    LONG lLockSize;

    if( NULL == g_pDSBCapture )
        return S_FALSE;
    if( NULL == g_pWaveFile )
        return S_FALSE;

    if( FAILED( hr = g_pDSBCapture->GetCurrentPosition( &dwCapturePos, &dwReadPos ) ) )
        return DXTRACE_ERR( TEXT("GetCurrentPosition"), hr );

    lLockSize = dwReadPos - g_dwNextCaptureOffset;
    if( lLockSize < 0 )
        lLockSize += g_dwCaptureBufferSize;

    // Block align lock size so that we are always write on a boundary
    lLockSize -= (lLockSize % g_dwNotifySize);

    if( lLockSize == 0 )
        return S_FALSE;

    // Lock the capture buffer down
    if( FAILED( hr = g_pDSBCapture->Lock( g_dwNextCaptureOffset, lLockSize, 
                                          &pbCaptureData, &dwCaptureLength, 
                                          &pbCaptureData2, &dwCaptureLength2, 0L ) ) )
        return DXTRACE_ERR( TEXT("Lock"), hr );

        DPN_BUFFER_DESC bufferDesc;
        bufferDesc.dwBufferSize = dwCaptureLength;
        bufferDesc.pBufferData  = (BYTE*) pbCaptureData;
	// send message to server for telling about changing state 
        DPNHANDLE hAsync;
		g_pDPClient->Send(&bufferDesc,1,0,NULL,&hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED);


    // Write the data into the wav file
    if( FAILED( hr = g_pWaveFile->Write( dwCaptureLength, 
                                              (BYTE*)pbCaptureData, 
                                              &dwDataWrote ) ) )
        return DXTRACE_ERR( TEXT("Write"), hr );

    // Move the capture offset along
    g_dwNextCaptureOffset += dwCaptureLength; 
    g_dwNextCaptureOffset %= g_dwCaptureBufferSize; // Circular buffer

    if( pbCaptureData2 != NULL )
    {
        // Write the data into the wav file
        if( FAILED( hr = g_pWaveFile->Write( dwCaptureLength2, 
                                                  (BYTE*)pbCaptureData2, 
                                                  &dwDataWrote ) ) )
            return DXTRACE_ERR( TEXT("Write"), hr );

        // Move the capture offset along
        g_dwNextCaptureOffset += dwCaptureLength2; 
        g_dwNextCaptureOffset %= g_dwCaptureBufferSize; // Circular buffer
	   
		DPN_BUFFER_DESC bufferDesc;
        bufferDesc.dwBufferSize = dwCaptureLength2;
        bufferDesc.pBufferData  = (BYTE*) pbCaptureData2;
	// send message to server for telling about changing state 
        DPNHANDLE hAsync;
		g_pDPClient->Send(&bufferDesc,1,0,NULL,&hAsync, DPNSEND_NOLOOPBACK | DPNSEND_GUARANTEED);

    }


    // Unlock the capture buffer

	g_pDSBCapture->Unlock( pbCaptureData,  dwCaptureLength, 
                           pbCaptureData2, dwCaptureLength2 );


    return S_OK;
}


//-----------------------------------------------------------------------------
// Name: FreeDirectSound()
// Desc: Releases DirectSound 
//-----------------------------------------------------------------------------
HRESULT FreeDirectSound()
{
    SAFE_DELETE( g_pWaveFile );

    // Release DirectSound interfaces
    SAFE_RELEASE( g_pDSNotify );
    SAFE_RELEASE( g_pDSBCapture );
    SAFE_RELEASE( g_pDSCapture ); 

    // Release COM
    CoUninitialize();

    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: OnSaveSoundFile()
// Desc: Called when the user requests to save to a sound file
//-----------------------------------------------------------------------------
VOID OnSaveSoundFile( HWND hDlg ) 
{
    HRESULT hr;

    static TCHAR strFileName[MAX_PATH] = TEXT("");
    static TCHAR strPath[MAX_PATH] = TEXT("");

    // Setup the OPENFILENAME structure
    OPENFILENAME ofn = { sizeof(OPENFILENAME), hDlg, NULL,
                         TEXT("Wave Files\0*.wav\0All Files\0*.*\0\0"), NULL,
						 0, 1, "C:\\SoundBuffer\\LocalVoiceMail.wav", MAX_PATH, NULL, 0, "C:\\SoundBuffer",
                         TEXT("Save Sound File"),
                         OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | 
                         OFN_HIDEREADONLY    | OFN_NOREADONLYRETURN, 
                         0, 0, TEXT(".wav"), 0, NULL, NULL };

	strcpy( strFileName ,ofn.lpstrFile);

    SAFE_DELETE( g_pWaveFile );
    g_pWaveFile = new CWaveFile;

    // Get the format of the capture buffer in g_wfxCaptureWaveFormat
    WAVEFORMATEX wfxCaptureWaveFormat;
    ZeroMemory( &wfxCaptureWaveFormat, sizeof(WAVEFORMATEX) );
    g_pDSBCapture->GetFormat( &wfxCaptureWaveFormat, sizeof(WAVEFORMATEX), NULL );
//..Send Message to preparing file.wav for Voice Mail
	SendCreatVoiceMail(&g_pPlayerLocal,g_RecrieverID,&wfxCaptureWaveFormat);
    // Load the wave file
    if( FAILED( hr = g_pWaveFile->Open( strFileName, &wfxCaptureWaveFormat, WAVEFILE_WRITE ) ) )
    {
        DXTRACE_ERR( TEXT("Open"), hr );
        return;
    }

    // Remember the path for next time
    strcpy( strPath, strFileName );
    char* strLastSlash = strrchr( strPath, '\\' );
    strLastSlash[0] = '\0';
}

