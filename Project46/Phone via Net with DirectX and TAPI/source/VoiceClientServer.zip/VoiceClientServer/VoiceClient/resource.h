//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VoiceClient.rc
//
#define IDD_MAIN_GAME                   101
#define IDD_DIAL                        102
#define IDD_VOICEMAIL                   102
#define IDD_LOBBY_WAIT_STATUS           105
#define IDI_ICON1                       106
#define IDI_ICON_VOICE                  106
#define IDD_VOICE_SETUP                 108
#define IDC_WAVE                        1001
#define IDC_NUM_PLAYERS                 1002
#define IDC_PLAYER_NAME                 1003
#define IDC_STOP                        1006
#define IDC_STOP_TALK                   1006
#define IDC_JOIN_TALK                   1007
#define IDC_BUTTON1                     1008
#define IDC_CONFERENCE                  1008
#define IDC_STOPRECORD                  1008
#define IDC_STATUS                      1009
#define IDC_DIAL                        1010
#define IDC_VOICEMAIL                   1010
#define IDC_PHONENUMBER                 1011
#define IDC_PHONESTUTUS                 1012
#define IDC_CANCLE                      1013
#define IDC_DIAL1                       1014
#define IDC_LOG_EDIT                    1016
#define IDC_RECORD                      1016
#define IDC_RECRIEVERID                 1017
#define IDC_CAPTURE_DEVICE_COMBO        1018
#define IDC_PEOPLE_LIST                 1035
#define IDC_SESSIONCOMPRESION_GROUP     1059
#define IDC_SETUP                       1062
#define IDC_QUALITY_DEFAULT             1201
#define IDC_QUALITY_SET                 1202
#define IDC_QUALITY_SLIDER              1203
#define IDC_AGGRESSIVENESS_DEFAULT      1301
#define IDC_AGGRESSIVENESS_SET          1302
#define IDC_AGGRESSIVENESS_SLIDER       1303
#define IDC_RECORD_DEFAULT              1501
#define IDC_RECORD_SET                  1502
#define IDC_RECORD_AUTO                 1503
#define IDC_RECORD_SLIDER               1504
#define IDC_THRESHOLD_DEFAULT           1601
#define IDC_THRESHOLD_SET               1602
#define IDC_THRESHOLD_AUTO              1603
#define IDC_THRESHOLD_SLIDER            1604
#define IDC_PLAYBACK_DEFAULT            1701
#define IDC_PLAYBACK_SET                1702
#define IDC_PLAYBACK_SLIDER             1703
#define IDD_CLIENT_CONNECT              12001
#define IDC_PLAYER_NAME_EDIT            12100
#define IDC_GAMES_LIST                  12101
#define IDC_JOIN                        12102
#define IDC_IP_ADDRESS                  12103
#define IDC_SEARCH_CHECK                12104
#define IDC_WAIT_TEXT                   12105
#define IDI_MAIN                        12200
#define IDI_MAIN1                       12200

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
