//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script.rc
//
#define IDD_DLGLOGIN                    101
#define IDD_CHAT                        102
#define IDD_CHATMESSAGE                 103
#define IDC_USER                        1000
#define IDC_PASSWD                      1001
#define IDC_LOGIN                       1002
#define IDC_EXIT                        1003
#define IDC_PLAYER                      1004
#define IDC_EDITMESSAGE                 1005
#define IDC_LISTMESSAGE                 1006
#define IDC_SEND                        1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
