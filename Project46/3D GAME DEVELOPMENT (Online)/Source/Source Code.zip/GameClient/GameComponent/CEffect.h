#ifndef _CEFFECT_H
#define _CEFFECT_H

#include "HGlobal.h"

#define MAX_PARTICLES 120

typedef struct Particle{
    D3DXVECTOR3 m_vCurPos;
    D3DXVECTOR3 m_vCurVel;
	D3DCOLOR    m_vColor;
} Particle;

class CEffect
{
private :
	CGraphic*				m_Graphics;

	LPDIRECT3DVERTEXBUFFER8 pVB;
	LPDIRECT3DTEXTURE8      pTexture;
	Particle				particles[MAX_PARTICLES];
	float					SpinX;
	float					SpinY;
	double					dLastFrameTime;
	D3DXVECTOR3				vPosit;

public :
	CEffect();
	~CEffect();
	BOOL		Init(CGraphic* Graphic, char* filename, D3DXVECTOR3 vPos);
	bool		Render();
	float		getRandomMinMax(float,float);
	D3DXVECTOR3 getRandomVector(void);
	void		updatePointSprites( void );
};

#endif