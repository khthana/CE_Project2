
#include "CLandscape.h"
#include <stdlib.h>
#include <fstream.h>

//============================================================================
// Class : CLandscape
//============================================================================
CLandscape::CLandscape()
{
  m_Graphics    = NULL;
  m_Frustum		= NULL;		
  m_LandMesh	= NULL;		
  //m_DecorMesh	= NULL;		
  m_LandNode	= NULL;		
  //m_DecorNode	= NULL;
  m_CanMove		= FALSE;
  m_MID = -1;
}

CLandscape::~CLandscape()
{
  Cleanup();
}

BOOL CLandscape::Cleanup()
{
  SAFE_DELETE(m_LandNode);
  //SAFE_DELETE(m_DecorNode);
  SAFE_DELETE(m_LandMesh);
  //SAFE_DELETE(m_DecorMesh);

  SAFE_DELETE(m_Frustum);

  m_CanMove		= FALSE;

  m_Graphics = NULL;
  
  return TRUE;
}

BOOL CLandscape::Create(CGraphic *Graphics,char* FileName,char* TexturePath, int MID, int Pos)
{
  Cleanup();

  if(Graphics == NULL)
    return FALSE;

  // Get D3D COM
  m_Graphics = Graphics;

  POS = Pos;
  // Create Frustum
  m_Frustum = new CFrustum();

  // Temp string of filename
  char szTemp[127];
  
  // Create Land & Decorate Mesh
  m_LandMesh = new CMesh();
  if(m_LandMesh->Load(m_Graphics, FileName, TexturePath, TRUE,0x0ffff00ff) == FALSE)
	  return FALSE;

  // Create Land & Decorate NodeTreeMesh Object
  m_LandNode = new CNodeTreeMesh();
  if(m_LandNode->Create(m_Graphics, m_LandMesh) == FALSE)
	  return FALSE;

  // Get map array from file
  sprintf(szTemp, ".\\Model\\Map\\Map%d.txt", MID);
  fstream mapFile( szTemp, ios::in | ios::binary );
  if( !mapFile )
      return false;

  
  /*int nrows = 3;
  int ncolumns = 3;
  int **array1 = (int **)malloc(nrows * sizeof(int *));
  for(int i = 0; i < nrows; i++)
		array1[i] = (int *)malloc(ncolumns * sizeof(int));
*/

  m_MapArray = (BYTE**)malloc(POS * sizeof(BYTE*));
  for (int i=0; i < POS; i++)
	  m_MapArray[i] = (BYTE*)malloc(POS * sizeof(BYTE));

  const unsigned int BUFF_SIZE = POS+2;
  char* buff;//[ BUFF_SIZE ];
  buff = (char*)malloc(BUFF_SIZE* sizeof(char));

  int line = POS-1;
  while( !mapFile.eof() && line >=0){
	  mapFile.read( buff, BUFF_SIZE );
	  unsigned int buffsize = mapFile.gcount();
	  for(int i=0 ; i<POS ; i++){
		  if (buff[i] == '0')
			  m_MapArray[i][line] = '0';
		  else if (buff[i] == '1')
			  m_MapArray[i][line] = '1';
	  }
	  line--;
  }

  m_MID = MID;

  return TRUE;
}

BOOL CLandscape::Render()
{
  if(m_Graphics == NULL || m_Frustum == NULL)
	  return FALSE;
  if(m_LandNode == NULL)// || m_DecorNode == NULL)
	  return FALSE;

  if(m_Frustum->Construct(m_Graphics) == FALSE)
	  return FALSE;
 
  if(m_LandNode->Render(m_Frustum) == FALSE)
	  return FALSE;

  return TRUE;  
}

float CLandscape::GetHeight(float XPos, float ZPos)
{
	if (m_LandNode == NULL)
		return -50.0f;
	
	return m_LandNode->GetHeight(XPos, ZPos);
}

D3DXVECTOR2 CLandscape::GetMapPosition(float XPos, float ZPos) 
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	return D3DXVECTOR2((float)xMap, (float)zMap);
}

BOOL CLandscape::ConvertMouseTo3D(long MouseX, long MouseY, D3DVECTOR* target)
{
	if (m_LandNode == NULL)
		return FALSE;

	D3DXMATRIX matProj;
	D3DXMATRIX matView, matInvView;
	D3DXVECTOR3 vecRay, vec, vecDir;

	m_Graphics->GetDevice()->GetTransform(D3DTS_PROJECTION, &matProj);
	m_Graphics->GetDevice()->GetTransform(D3DTS_VIEW, &matView);
	D3DXMatrixInverse(&matInvView, NULL, &matView);

	vec.x =  ( ( ( 2.0f * MouseX ) / m_Graphics->GetWidth() ) - 1 ) / matProj._11;
	vec.y = -( ( ( 2.0f * MouseY ) / m_Graphics->GetHeight() ) - 1 ) / matProj._22;
	vec.z =  1.0f;

	vecRay.x = matInvView._41;
	vecRay.y = matInvView._42;
	vecRay.z = matInvView._43;

	vecDir.x  = vec.x*matInvView._11 + vec.y*matInvView._21 + vec.z*matInvView._31;
	vecDir.y  = vec.x*matInvView._12 + vec.y*matInvView._22 + vec.z*matInvView._32;
	vecDir.z  = vec.x*matInvView._13 + vec.y*matInvView._23 + vec.z*matInvView._33;

	BOOL Hit;
	DWORD Face;
	float u, v ,Dist;

	m_LandNode->CheckIntersect(&vecRay, &vecDir, &Hit, &Face, &u, &v, &Dist);

	if(Hit == TRUE){
		D3DXVECTOR3 vecTarget;
		D3DXVec3Scale(&vecTarget, &vecDir, Dist);
		D3DXVec3Add(&vecTarget, &vecRay, &vecTarget);

		target->x = vecTarget.x;
		target->y = vecTarget.y;
		target->z = vecTarget.z;

		return TRUE;
	}else{
		return FALSE;
	}
}

BOOL CLandscape::MouseOnMap(long MouseX, long MouseY, D3DVECTOR* position)
{
	if(m_LandNode == NULL)
		return FALSE;

	D3DXVECTOR3 vTarget;

	m_CanMove = FALSE;

	if(ConvertMouseTo3D(MouseX, MouseY, &vTarget) == FALSE)
		return FALSE;

	position->x = vTarget.x; 
	position->y = vTarget.y; 
	position->z = vTarget.z; 


	return TRUE;
}
BOOL CLandscape::SetCanMove(float XPos,float ZPos,bool CanMove)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

	if (CanMove)
		m_MapArray[xMap][zMap] = '0';
	else m_MapArray[xMap][zMap] = '1';

	return TRUE;

}
BOOL CLandscape::CanMove(float XPos, float ZPos)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

		// Compare with mapArray whether position can move to or not
	if (m_MapArray[xMap][zMap] == '0')
		return TRUE;

	return FALSE;
}

INT CLandscape::GetValueMap(float XPos, float ZPos)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos);
	zMap = (int)(ZPos);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

		// Compare with mapArray whether position can move to or not
	return m_MapArray[xMap][zMap];
	
}
