#ifndef _CFRUSTUM_H_
#define _CFRUSTUM_H_

class CGraphic;

class CFrustum
{
  private:
    D3DXPLANE m_Planes[6];

  public:
    BOOL Construct(CGraphic *Graphics, float ZDistance = 0.0f);
    BOOL CheckPoint(float XPos, float YPos, float ZPos);
    BOOL CheckCube(float XCenter, float YCenter, float ZCenter, float Size);
    BOOL CheckRectangle(float XCenter, float YCenter, float ZCenter, float XSize, float YSize, float ZSize);
    BOOL CheckSphere(float XCenter, float YCenter, float ZCenter, float Radius);
};

#endif
