#include "HGlobal.h"
#include "CWindow.h"

CWindow::CWindow()
{
  // Clear class data
  m_Graphics = NULL;
  m_Text     = NULL;
  m_TextColor = 0xFFFFFFFF;
}

CWindow::~CWindow()
{
  Cleanup();  // Free class data
}

BOOL CWindow::Create(CGraphic *Graphics)
{
  Cleanup();  // Free previous class data

  // Error checking
  if((m_Graphics = Graphics) == NULL)
    return FALSE;

  m_Font.Create(Graphics,"AngsanaUPC",26);
 
  	// Create new vertex buffer
  m_DlgVB.Create(m_Graphics, 4, WINDOWFVF, sizeof(sVertex));
  m_DlgTexture.Load(m_Graphics,".\\Texture\\dialog.png");

  	// Create new vertex buffer
  m_DlgQuestionVB.Create(m_Graphics, 4, WINDOWFVF, sizeof(sVertex));
  m_DlgQuestion.Load(m_Graphics,".\\Texture\\Question.png");

  return TRUE; // Return success
}
BOOL CWindow::CreateDlg()
{
  if(m_Graphics == NULL)
    return FALSE;

  return TRUE;
}
BOOL CWindow::CreatePicture(CGraphic *Graphics,char *filename)
{
    // Error checking
  if(filename == NULL)
    return FALSE;

  char name[127];
  if(strcmp(filename,".\\Texture\\TitleOnline.bmp"))
	sprintf(name,".\\Texture\\CharPic\\%s.png",filename);
  // Create new vertex buffer
  m_PictureVB.Create(m_Graphics,4, WINDOWFVF, sizeof(sVertex));
  if(strcmp(filename,".\\Texture\\TitleOnline.bmp"))
	  m_Texture.Load(Graphics,name);
  else m_Texture.Load(Graphics,filename);

  return true;
}

BOOL CWindow::Cleanup()
{
  m_Texture.Cleanup();
  m_DlgTexture.Cleanup();
  m_DlgQuestion.Cleanup();
  m_PictureVB.Cleanup();
  m_DlgVB.Cleanup();
  m_DlgQuestionVB.Cleanup();
  m_Font.Cleanup();
  
  delete [] m_Text;   // Delete text buffer
  m_Text = NULL;

  return TRUE;
}

BOOL CWindow::SetText(char *Text, D3DCOLOR TextColor)
{
  // Delete previous text
//  delete [] m_Text;
//  m_Text = NULL;

  m_Text = strdup(Text);       // Copy text string
  m_TextColor = TextColor;     // Store text color

  return TRUE;
}

BOOL CWindow::MoveQuestionDlg(long XPos,long YPos,long Width,long Height)
{
	sVertex Verts[4];
	long i;

	// Clear the vertex data
	for(i=0;i<4;i++) {
		Verts[i].z = 0.0f;
		Verts[i].rhw = 1.0f;
		Verts[i].Diffuse = 0xFFFFFFFF;
		Verts[i].tu = 0;
		Verts[i].tv = 0;
	}

	// Setup the white outline
	Verts[0].x = (float)XPos;
	Verts[0].y = (float)YPos;
	Verts[0].tu = 0.0f;
	Verts[0].tv = 0.0f;

	Verts[1].x  = (float)(XPos+Width);
	Verts[1].y  = (float)YPos ;
	Verts[1].tu = 1.0f;
	Verts[1].tv = 0.0f;

	Verts[2].x  = (float)XPos;
	Verts[2].y  = (float)(YPos+Height);
	Verts[2].tu = 0.0f;
	Verts[2].tv = 1.0f;
		
	Verts[3].x = (float)(XPos+Width);
	Verts[3].y = (float)(YPos+Height);
	Verts[3].tu = 1.0f;
	Verts[3].tv = 1.0f;

	m_DlgQuestionVB.Set(0,4,&Verts);  // Set the vertices

	return TRUE;
}

BOOL CWindow::MoveDialog(long XPos, long YPos,                      \
                   long Width, long Height)
{
  sVertex Verts[4];
  long i;

  // Save the coordinates and calculate height if needed
  m_XPos  = XPos;
  m_YPos  = YPos;
  m_Width = Width;
  if(!(m_Height = Height)) {
    RECT Rect;
    Rect.left   = XPos;
    Rect.top    = 0;
    Rect.right  = XPos + Width - 12;
    Rect.bottom = 1;

    m_Height = m_Font.GetFont()->DrawText(m_Text, -1,     \
                &Rect, DT_CALCRECT | DT_WORDBREAK,            \
                0xFFFFFFFF) + 12;
  }

  // Clear the vertex data
  for(i=0;i<4;i++) {
    Verts[i].z = 0.0f;
    Verts[i].rhw = 1.0f;
    Verts[i].Diffuse = 0xFFFFFFFF;
	Verts[i].tu = 0;
	Verts[i].tv = 0;
  }

  // Setup the white outline
	Verts[0].x = (float)m_XPos;
	Verts[0].y = (float)m_YPos;
	Verts[0].tu = 0.0f;
	Verts[0].tv = 0.0f;

	Verts[1].x  = (float)(m_XPos+m_Width);
	Verts[1].y  = (float)m_YPos ;
	Verts[1].tu = 1.0f;
	Verts[1].tv = 0.0f;

	Verts[2].x  = (float)m_XPos;
	Verts[2].y  = (float)(m_YPos+m_Height);
	Verts[2].tu = 0.0f;
	Verts[2].tv = 1.0f;
		
	Verts[3].x = (float)(m_XPos+m_Width);
	Verts[3].y = (float)(m_YPos+m_Height);
	Verts[3].tu = 1.0f;
	Verts[3].tv = 1.0f;

  m_DlgVB.Set(0,4,&Verts);  // Set the vertices
  
  return TRUE;
}

long CWindow::GetHeight()
{
  return m_Height;
}

BOOL CWindow::RenderDialog(char* name, char *Text, D3DCOLOR Color ,bool border)
{
  // Error checking
  if(m_Graphics == NULL)
    return FALSE;

  // Set rendering states
  m_Graphics->SetTexture(0, &m_DlgTexture);
  m_Graphics->EnableZBuffer(FALSE);
  
  // Draw window
  if(border)
  {
	m_DlgVB.Render(0,2,D3DPT_TRIANGLESTRIP);
  }

  // Only draw text if height > 12
  if(m_Height > 12) {
    // Draw the text
    if(Text == NULL)
      m_Font.Print(m_Text, m_XPos+50, m_YPos+100,               \
                            m_Width-80,m_Height-30,           \
                            m_TextColor, DT_WORDBREAK);
    else
      m_Font.Print(Text, m_XPos+50, m_YPos+100,                 \
                          m_Width-80,m_Height-30,             \
                          Color, DT_WORDBREAK);
  }

  strcpy(m_Text , "");

  return TRUE;
}

BOOL CWindow::MovePicture(long XPos,long YPos,long Width,long Height)
{
	sVertex Verts[4];
	for(int i=0;i<4;i++)
	{
		Verts[i].z = 0.0f;
		Verts[i].rhw = 1.0f;
		Verts[i].Diffuse = 0xffffffff;
	}

	Verts[0].x = (float)XPos;
	Verts[0].y = (float)YPos;
	Verts[0].tu = 0.0f;
	Verts[0].tv = 0.0f;

		Verts[1].x  = (float)(XPos+Width);
		Verts[1].y  = (float)YPos ;
		Verts[1].tu = 1.0f;
		Verts[1].tv = 0.0f;

	Verts[2].x  = (float)XPos;
	Verts[2].y  = (float)(YPos+Height);
	Verts[2].tu = 0.0f;
	Verts[2].tv = 1.0f;
		
		Verts[3].x = (float)(XPos+Width);
		Verts[3].y = (float)(YPos+Height);
		Verts[3].tu = 1.0f;
		Verts[3].tv = 1.0f;

	m_PictureVB.Set(0,4,&Verts);
		return true;
}

BOOL CWindow::RenderPicture()
{
	// Error checking
  if(m_Graphics == NULL)
    return FALSE;

  // Set rendering states
  m_Graphics->SetTexture(0, &m_Texture);
  m_Graphics->EnableZBuffer(FALSE);

  // Draw window
  m_PictureVB.Render(0,2,D3DPT_TRIANGLESTRIP);
  
  return true;
}

BOOL CWindow::RenderQuestion()
{
	if(m_Graphics == NULL)
		return FALSE;
	
	// Set rendering states
	m_Graphics->SetTexture(0, &m_DlgQuestion);
	m_Graphics->EnableZBuffer(FALSE);

	// Draw window
	m_DlgQuestionVB.Render(0,2,D3DPT_TRIANGLESTRIP);

	return TRUE;

}
