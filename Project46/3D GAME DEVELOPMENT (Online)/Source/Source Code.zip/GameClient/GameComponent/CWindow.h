#ifndef _CWindow_H_
#define _CWindow_H_

class CWindow
{
  private:
    typedef struct sVertex {  // Custom vertex 
      float    x, y, z;  // Coordinates in screen space    
	  float    rhw;      // RHW value
      D3DCOLOR Diffuse;  // Diffuse color
	  float    tu,tv;
    } sVertex;
    #define WINDOWFVF (D3DFVF_XYZRHW  | D3DFVF_DIFFUSE|D3DFVF_TEX1)

    CGraphic     *m_Graphics;  // Parent CGraphic object
    CTexture       m_Texture;
	CTexture       m_DlgTexture;
	CTexture	   m_DlgQuestion;
	CFont          m_Font;      // Font object
    CVertexBuffer  m_DlgVB;  // Vertex buffer for window
	CVertexBuffer  m_PictureVB;
	CVertexBuffer  m_DlgQuestionVB;


	char          *m_Text;        // Text to display
    D3DCOLOR       m_TextColor;   // Color to draw text 

    long           m_XPos, m_YPos;     // Window coordinates
    long           m_Width, m_Height;  // Window dimensions

    BOOL           m_DrawTarget;  // Flag to draw bubble pointer

  public:
    CWindow();   // Constructor
    ~CWindow();  // Destructor

    // Functions to create/free a text window
    BOOL Create(CGraphic *Graphics);
	BOOL CreateDlg();
	BOOL CreatePicture(CGraphic *Graphics,char *filename);
    BOOL Cleanup();

   // Set the text and window coordinates/dimensions/colors
    BOOL SetText(char *Text, D3DCOLOR TextColor = 0xFFFFFFFF);

    // Move the window
    BOOL MoveDialog(long XPos, long YPos, long Width,long Height=0);

	BOOL MovePicture(long XPos,long YPos,long Width,long Height);

	BOOL MoveQuestionDlg(long XPos,long YPos,long Width,long Height);

    long GetHeight();  // Get window height after set

    // Render window and text to display
    BOOL RenderDialog(char* name, char *Text = NULL, D3DCOLOR Color = 0xFFFFFFFF,bool border=true);
	BOOL RenderPicture();
	BOOL RenderQuestion();

};

#endif
