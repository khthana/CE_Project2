
#ifndef _CSKYBOX_H
#define _CSKYBOX_H

#include "HGlobal.h"

class CSkybox 
{ 
private :
	typedef struct sSkyBoxVertex
	{
		float x,y,z;
		float u,v;
	}sSkyBoxVertex;
	#define SkyboxFVF (D3DFVF_XYZ | D3DFVF_TEX1)

	CGraphic		*m_Graphics;
	CTexture		m_Textures[6];
	CVertexBuffer	m_VB;
	CWorldPosition	m_Pos;

public:
	CSkybox();
	~CSkybox();
	
	BOOL Create(CGraphic *Graphics);
	BOOL Cleanup();

	BOOL LoadTexture(short Side, char *filename, D3DCOLOR Transparent = 0, D3DFORMAT Format = D3DFMT_UNKNOWN);
	
	BOOL Rotate(float XRot, float YRot, float ZRot);
	BOOL RotateRel(float XRot, float YRot, float ZRot);

	BOOL Render(CCamera *Camera, BOOL Alpha = FALSE);
};

#endif