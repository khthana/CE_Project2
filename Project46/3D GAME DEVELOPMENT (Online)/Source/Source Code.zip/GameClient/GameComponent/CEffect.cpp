#include "CEffect.h"

CEffect::CEffect()
{
	SpinX = 0;
	SpinY = 0;

	m_Graphics = NULL;
}

CEffect::~CEffect() 
{
	m_Graphics = NULL;

	/*if( pVB != NULL )  
		pVB->Release();

    if( pTexture != NULL )
		pTexture->Release();*/
}

BOOL CEffect::Init(CGraphic* Graphic, char* filename, D3DXVECTOR3 vPos)
{
	if ((m_Graphics=Graphic)==NULL)
		return FALSE;

	if (FAILED(D3DXCreateTextureFromFileEx( m_Graphics->GetDevice(), filename, 
                D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
                D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, 
                D3DX_FILTER_TRIANGLE, 0, NULL, NULL, &pTexture )))
		return FALSE;

	m_Graphics->GetDevice()->SetTextureStageState( 0,D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
	m_Graphics->GetDevice()->SetTextureStageState( 0,D3DTSS_MINFILTER, D3DTEXF_LINEAR );
	m_Graphics->GetDevice()->CreateVertexBuffer( 2048 * sizeof(VERTEX_FX), 
                                      D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY | D3DUSAGE_POINTS, 
									  VERTEX_FX::FVF_Flags, D3DPOOL_DEFAULT, 
									  &pVB );

	float fMaxPointSize = 0.0f;
	bool  bDeviceSupportsPSIZE = false;
	
    D3DCAPS8 d3dCaps;
    m_Graphics->GetDevice()->GetDeviceCaps( &d3dCaps );

    fMaxPointSize = d3dCaps.MaxPointSize;

    if( d3dCaps.FVFCaps & D3DFVFCAPS_PSIZE )
        bDeviceSupportsPSIZE = true;
    else
        bDeviceSupportsPSIZE = false;

	for( int i = 0; i < MAX_PARTICLES; ++i )
    {
		particles[i].m_vCurPos = D3DXVECTOR3(vPos.x,40,vPos.y);
		particles[i].m_vCurVel = getRandomVector() * getRandomMinMax( 0.5f, 15.0f );

		particles[i].m_vColor = D3DCOLOR_COLORVALUE( getRandomMinMax( 0.0f, 1.0f ), 
                                                       getRandomMinMax( 0.0f, 1.0f ), 
                                                       getRandomMinMax( 0.0f, 1.0f ), 
                                                       1.0f );
	}
	vPosit = vPos;

	dLastFrameTime = timeGetTime();
    return TRUE;
}

bool CEffect::Render()
{
	D3DXMATRIX matTrans;
	D3DXMATRIX matRot;
	D3DXMATRIX matWorld;

	D3DXMatrixTranslation( &matTrans, 410,40,410 );

	D3DXMatrixRotationYawPitchRoll( &matRot, 
		                            D3DXToRadian(SpinX), 
		                            D3DXToRadian(SpinY), 
		                            0.0f );
	SpinX = SpinX + 3;
    matWorld = matRot * matTrans;

	m_Graphics->GetDevice()->SetTransform( D3DTS_WORLD, &matWorld );

	updatePointSprites();
	m_Graphics->GetDevice()->SetTexture( 0, pTexture );
	m_Graphics->GetDevice()->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );

    m_Graphics->GetDevice()->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
    m_Graphics->GetDevice()->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_ONE );
	
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSPRITEENABLE, TRUE );    // Turn on point sprites
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSCALEENABLE,  TRUE );    // Allow sprites to be scaled with distance
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSIZE,     DWORD(1.0) );  // Float value that specifies the size to use for point size computation in cases where point size is not specified for each vertex.
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSIZE_MIN, DWORD(1.0f) ); // Float value that specifies the minimum size of point primitives. Point primitives are clamped to this size during rendering. 
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSCALE_A,  DWORD(0.0f) ); // Default 1.0
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSCALE_B,  DWORD(0.0f) ); // Default 0.0
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSCALE_C,  DWORD(1.0f) ); // Default 0.0

	VERTEX_FX *pPointVertices;

	pVB->Lock( 0, MAX_PARTICLES * sizeof(VERTEX_FX),
		                   (BYTE**)&pPointVertices, D3DLOCK_DISCARD );

	for(int i = 0; i < MAX_PARTICLES; ++i )
    {
        pPointVertices->posit = D3DXVECTOR3(0,0,0);
        pPointVertices->color = particles[i].m_vColor;
        pPointVertices++;
    }

    pVB->Unlock();
	
    m_Graphics->GetDevice()->SetStreamSource( 0, pVB, sizeof(VERTEX_FX) );
    m_Graphics->GetDevice()->SetVertexShader( VERTEX_FX::FVF_Flags );
	m_Graphics->GetDevice()->DrawPrimitive( D3DPT_POINTLIST, 0, MAX_PARTICLES );

    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSPRITEENABLE, FALSE );
    m_Graphics->GetDevice()->SetRenderState( D3DRS_POINTSCALEENABLE,  FALSE );

    m_Graphics->GetDevice()->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );
    m_Graphics->GetDevice()->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );

	return TRUE;
}

float CEffect::getRandomMinMax( float fMin, float fMax )
{
    float fRandNum = (float)rand () / RAND_MAX;
    return fMin + (fMax - fMin) * fRandNum;
}

D3DXVECTOR3 CEffect::getRandomVector( void )
{
	D3DXVECTOR3 vVector;

    // Pick a random Z between -1.0f and 1.0f.
    vVector.z = getRandomMinMax( -1.0f, 1.0f );
    
    // Get radius of this circle
    float radius = (float)sqrt(1 - vVector.z * vVector.z);
    
    // Pick a random point on a circle.
    float t = getRandomMinMax( -D3DX_PI, D3DX_PI );

    // Compute matching X and Y for our Z.
    vVector.x = vPosit.x + getRandomMinMax( -1.0f, 1.0f);
    vVector.y = radius;

	return vVector;
}

void CEffect::updatePointSprites( void )
{
	double dCurrenFrameTime = timeGetTime();
	double dElpasedFrameTime = (float)((dCurrenFrameTime - dLastFrameTime) * 0.001);
	dLastFrameTime = dCurrenFrameTime;

	//
	// After 5 seconds, repeat the sample by returning all the particles 
	// back to the origin.
	//
	
    for( int i = 0; i < MAX_PARTICLES; ++i )
	{
		/*particles[i].m_vCurPos.x = float(vPosit.x + 1.5*cosf((float)i*5));
		particles[i].m_vCurPos.y += particles[i].m_vCurVel.y * (float)dElpasedFrameTime*2;
		if (particles[i].m_vCurPos.y > 100) particles[i].m_vCurPos.y = 0;
		particles[i].m_vCurPos.z = float(vPosit.z + 1.5*sinf((float)i*5));*/
		particles[i].m_vCurPos += (particles[i].m_vCurVel * (float)dElpasedFrameTime);
		getRandomMinMax(D3DXToRadian(0),D3DXToRadian(360));
		getRandomMinMax(D3DXToRadian(0),D3DXToRadian(360));
	}
}