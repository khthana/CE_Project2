#ifndef _CHARS_H_
#define _CHARS_H_

#include "CLandscape.h"
#include "CRelCamera.h"
#include "MCL.h"
#include "MSL.h"
#include "CStageGame.h"

// Spell references
class  CLandscape;
class  CRelativeCamera;
class  CSpellController;
struct sSpellTracker;
struct sCharacter;

// Number of characters in file
#define NUM_CHARACTER_DEFINITIONS   256

// Character types
#define CHAR_PC          0
#define CHAR_NPC         1
#define CHAR_MONSTER     2
#define CHAR_USER	     3

// AI types
#define CHAR_STAND       0
#define CHAR_WANDER      1
#define CHAR_ROUTE       2
#define CHAR_FOLLOW      3
#define CHAR_EVADE       4

// Action/Animation types
#define CHAR_IDLE        0
#define CHAR_MOVE        1
#define CHAR_ATTACK      2
#define CHAR_SPELL       3
#define CHAR_ITEM        4
#define CHAR_HURT        5
#define CHAR_DIE         6
#define CHAR_TALK        7

// Status ailments
#define AILMENT_POISON          1
#define AILMENT_SLEEP           2
#define AILMENT_PARALYZE        4
#define AILMENT_WEAK            8
#define AILMENT_STRONG         16
#define AILMENT_ENCHANTED      32
#define AILMENT_BARRIER        64
#define AILMENT_DUMBFOUNDED   128
#define AILMENT_CLUMSY        256
#define AILMENT_SUREFOOTED    512 
#define AILMENT_SLOW         1024
#define AILMENT_FAST         2048
#define AILMENT_BLIND        4096
#define AILMENT_HAWKEYE      8192
#define AILMENT_SILENCED    16384

#define MAX_SHORTPATH	100
#define MAX_SHORTCAL	20

typedef struct sItem
{
	int ID;
	int ItemDef;
	int Count;
	float xPos,yPos,zPos;
    float xRot,yRot,zRot;
	sItem *next;
	
	float radius; //for bounding sphere
	sItem(){next = NULL; radius =0 ;}
	~sItem()
	{
		if(next!=NULL)
			delete next;	
	}
	
}sItem;

class CInventory
{
private:
	int count;
	sItem *m_ItemParent; 
	CStageGame *m_StageGame;
	BOOL SetBoundingSphere();
public:
	CInventory(){m_ItemParent = NULL;}
	~CInventory(){Cleanup();}
	
	sItem* FindItem(int itemId);
	sItem* FindItemDef(int id);
	sItem* GetItemParent(){return m_ItemParent;}
	void ClearAllItem(){Cleanup();}
	BOOL LoadInventory(sCharacter *charPtr,CStageGame* stageGame);
	BOOL Save(char* filename);
	BOOL AddItem(long ItemDefId,int count);
	BOOL RenderWeapon(CGraphic* graphics,sCharacter *charPtr);
	void FindListMagicItem(sItem** MgItem,int& amount);
	void FindListHealingItem(sItem** HealItem,int& amount);

	bool Cleanup()
	{
		if(m_ItemParent!=NULL)
		{
			delete m_ItemParent; 
			m_ItemParent = NULL;
		}
		return true;	
	}
};

// Animation info
typedef struct {
  char Name[32];    // Name of animation
  BOOL Loop;        // To loop flag
} sCharAnimationInfo;

// A mesh list
typedef struct sCharacterMeshList {
  char       Filename[MAX_PATH];  // Filename of mesh/anim
  long       Count;               // # characters using mesh
  CMesh      Mesh;                // Mesh object
  CAnimation Animation;           // Animation object

  sCharacterMeshList()  { Count = 0;}
  ~sCharacterMeshList() { Mesh.Cleanup(); Animation.Cleanup(); }
} sCharacterMeshList;

// Path/Route structure
typedef struct {
  float XPos, YPos, ZPos;   // Target position
  float Direction;				// Direction to Target position
} sRoutePoint;

typedef struct sCharacter
{
  long  Definition;         // Character definition #
  long  ID;                 // ID # of character

  char  Name[50];			// Name of character

  long  Type;               // PC, NPC, or MONSTER
  long  AI;                 // STAND, WANDER, etc

  BOOL  Enabled;            // Enabled flag (for updates)

  sCharacterDefinition Def; // Loaded definition
  //CCharICS *CharICS;        // PC character's ICS
  CInventory m_Inventory;	// Item of Character
  sModel	*m_ModelItem;	// Model Item List

  char ItemFilename[64];	//inventory file of character.
  char ScriptFilename[MAX_PATH]; // Associated script

  long  HealthPoints;       // Current health points
  long  ManaPoints;         // Current mana points
  long  Points;				// Point to up stats
  long  Ailments;           // Ailments against character
  float Charge;             // Attack charge

  long  Action;             // Current action
  float XPos, YPos, ZPos;   // Current coordinates
  float XDestPos,ZDestPos;	// Destination Position to Reach
  float Direction;          // Angle character is facing
  long  LastAnim;           // Last animation
  long  LastAnimTime;       // Last animation time
  long  FrameAni;

  BOOL  Locked;             // Specific action lock
  long  ActionTimer;        // Lock action countdown timer

  sCharacter *Attacker;     // Attacking character (if any)
  sCharacter *Victim;       // Character to attack

  long  SpellNum;           // Spell to cast when ready
  long  SpellTarget;        // Target type of spell
  float TargetX, TargetY, TargetZ; // Spell target coords

  float Distance;           // Follow/Evade distance
  int	Delay;				// Delay time to follow
  sCharacter *TargetChar;   // Character to follow
  float MinX, MinY, MinZ;   // Min bounding coordinates
  float MaxX, MaxY, MaxZ;   // Max bounding coordiantes

  long  NumPoints;          // # points in route
  long  CurrentPoint;       // Current route point
  sRoutePoint *Route;       // Route points
  INT**	AllPath;			// All Path in Map Array
  int	MapSize;			// Map size in row or column
  char	TempArr[MAX_SHORTCAL][MAX_SHORTCAL]; // Temp For Calculate Shortest Path

  char  Message[128];       // Text message
  long  MessageTimer;       // Text message timer
  char  MessageChat[128];
  long  ChatTimer;
  D3DCOLOR MessageColor;    // Color of text message
  D3DCOLOR ChatMessageColor;// Color of Chat Message

  CObject Object;           // Character object class
  CMesh   WeaponMesh;       // Weapon mesh
  CObject WeaponObject;     // Weapon object

  sCharacter *Prev, *Next;  // Linked list of characters

  sCharacter()
  {
    Definition = 0;         // Set to definition #0
    ID = -1;                // Set to no ID
    Type = CHAR_NPC;        // Set to NPC character
    Enabled = FALSE;        // Set to not enabled
    
	Points = 5;
	AI	= CHAR_STAND;
    Ailments = 0;           // Set no ailments
    Charge = 0.0f;          // Set no charge

	m_ModelItem  = NULL;
    // Clear definition
    ZeroMemory(&Def, sizeof(sCharacterDefinition));
	ZeroMemory(Name, sizeof(Name));
	
    Action = CHAR_IDLE;     // Set default animation
    LastAnim = -1;          // Reset animation
	FrameAni = 1;

    Locked = FALSE;         // Set no lock
    ActionTimer = 0;        // Set no action timer

    Attacker = NULL;        // Set no attacker
    Victim = NULL;          // Set no victim

    Distance = 0.0f;        // Set distance
    TargetChar = NULL;      // Set no target character

    // Clear bounding box (for limiting movement)
    MinX = MinY = MinZ = MaxX = MaxY = MaxZ = 0.0f;

    NumPoints = 0;          // Set no route points
    Route = (sRoutePoint*)malloc(MAX_SHORTPATH * sizeof(sRoutePoint));// Set no route
	CurrentPoint = 0;

    Message[0] = 0;         // Clear message
    MessageTimer = 0;       // Set no message timer

	ChatTimer = 0;

    Prev = Next = NULL;     // Clear linked list pointers
	
  }
	
  void FreePath()
  {
	//clear Path
	for (int i=0;i<MapSize;i++)
	  for (int j=0;j<MapSize;j++)
		  AllPath[i][j] = 0;

	for (i=0;i<MAX_SHORTPATH;i++) 
	{
		Route[i].Direction = 0;
		Route[i].XPos	  = -1;
		Route[i].YPos	  = -1;
		Route[i].ZPos	  = -1;
	}
	CurrentPoint= 0;
	NumPoints	= 0;
  }

  ~sCharacter()
  {
    delete [] Route;       // Release route
	
	m_Inventory.Cleanup();

	if(m_ModelItem!=NULL) delete[] m_ModelItem;

    WeaponObject.Cleanup();   // Release weapon object
    WeaponMesh.Cleanup();     // Release weapon mesh
    Object.Cleanup();         // Release character object

    delete Next;           // Delete next character in list
  }
} sCharacter;

class CCharacterController
{
  private:
    CGraphic  *m_Graphics;            // Parent graphics object
	CStageGame *m_StageGame;		  // Stage Game
    CFont      *m_Font;                // Font object to use
    CFrustum   *m_Frustum;             // Viewing frustum
	CFont		m_Name;
	CFont		m_Message;

	DWORD		DelaySound1;
	DWORD		DelaySound2;

	CObject		m_Die;
	sCharacterMeshList* m_MeshesDie;
	
    char m_DefinitionFile[MAX_PATH];   // Filename of def. file

    sSpell     *m_MSL;                 // Master spell list

    CSpellController *m_SpellController; // Spell controller
	
	long        m_NumCharacters;       // # characters in list
    sCharacter *m_CharacterParent;     // List of characters

    long        m_NumMeshes;           // # meshes in use
    sCharacterMeshList *m_Meshes;      // Meshes list
    char m_MeshPath[MAX_PATH];         // Weapon mesh path
    char m_TexturePath[MAX_PATH];      // Mesh texture path

    long        m_NumAnimations;       // # animations
    sCharAnimationInfo *m_Animations;  // Animation data

    // Function to overide for playing sounds
    virtual BOOL ActionSound(sCharacter *Character)
            { return TRUE; }

    // Move function for player characters (need to override)
    virtual BOOL PCUpdate(                                    \
                   sCharacter *Character, long Elapsed,       \
                   float *XMove, float *YMove, float *ZMove)  \
            { return TRUE; }

	BOOL UserUpdate(sCharacter *Character, long Elapsed,      \
                    float *XMove, float *YMove, float *ZMove);

    // Character update function for all non-PC characters
    BOOL CharUpdate(sCharacter *Character, long Elapsed,      \
                    float *XMove, float *YMove, float *ZMove);

    // Check for valid movements. Bounds check to other 
    // characters and call ValidateMove (overidden).
    BOOL CheckMove(sCharacter *Character,                     \
                   float *XMove, float *YMove, float *ZMove);

	BOOL MakePath(sCharacter* CharPtr,int Stx, int Sty);

	void ShortestPath(sCharacter* CharPtr,int stx,int sty,int tx,int ty,int step);

	BOOL SortArr(sCharacter* CharPtr);

    // Virtual ValidateMove for outside bounds checking
    // against character movements.
    BOOL ValidateMove(sCharacter *Character,          \
                   float *XMove, float *YMove, float *ZMove);                   

    // Finish movement by setting direction, animation, etc
    BOOL ProcessUpdate(sCharacter *Character,                 \
                   float XMove, float YMove, float ZMove);

    // Process death of a player character
    virtual BOOL PCDeath(sCharacter *Character)               \
                 { return TRUE; }

    // Process death of a non-player character
    virtual BOOL NPCDeath(sCharacter *Character)              \
                 { return TRUE; }

    // Functions to drop money and item when character dies
    virtual BOOL DropMoney(float XPos,float YPos,float ZPos,  \
                           long Quantity)
                 { return TRUE; }

    virtual BOOL DropItem(float XPos, float YPos, float ZPos, \
                          long ItemNum)
                 { return TRUE; }

  public:
	
    CCharacterController();   // Constructor
    ~CCharacterController();  // Destructor

	int ID_PC;

    // Functions to init/shutdown controller class
    BOOL Init(CGraphic *Graphics, CFont *Font, CStageGame* StageGame,   \
              char *DefinitionFile , sSpell *MSL,  \
              long NumCharacterMeshes, char **MeshNames,      \
              char *MeshPath, char *TexturePath,              \
              long NumAnimations, sCharAnimationInfo *Anims,  \
              CSpellController *SpellController);
    BOOL Shutdown();

    // Free class
    BOOL Cleanup();

    // Add a character to the list
    BOOL Add(long IDNum, char* name, long Definition, long Type, long AI, \
             float XPos, float YPos, float ZPos,              \
             float Direction = 0.0f);

    // Remove a character from list
    BOOL Remove(long IDNum);
    BOOL Remove(sCharacter *Character);

    // Save or load an individual character
    BOOL Save(long IDNum, char *Filename);
    BOOL Load(long IDNum, char *Filename);

	long CheckEvent();
	long ClickOnCharacter(CRelativeCamera* Camera, long XMouse,long YMouse,D3DXVECTOR3* m_MouseClickPos);

	BOOL RoutePath(sCharacter *Character,D3DXVECTOR2 CharPos,D3DXVECTOR2 DestPos);

    // Update all characters based on elapsed time
    BOOL Update(long Elapsed,CSoundChannel* Soundaction, CSoundData* SoundData);

    // Render all objects within viewing frustum
    BOOL Render(long       Elapsed = -1,                      \
                CFrustum  *Frustum = NULL,                    \
                float      ZDistance = 0.0f);

    // Retrieve an sCharacter structure
    sCharacter *GetParentCharacter();
    sCharacter *GetCharacter(long IDNum);
	
    // Return X/Z radius of character
    float GetXZRadius(sCharacter *Character);

    // Make sure there's a line of sight between characters
    virtual BOOL LineOfSight(                                 \
                sCharacter *Source, sCharacter *Target,       \
                float SourceX, float SourceY, float SourceZ,  \
                float TargetX, float TargetY, float TargetZ)
                { return TRUE; }

    // Function to retrieve adjusted ability/other info
    float GetSpeed(sCharacter *Character);
    long  GetAttack(sCharacter *Character);
    long  GetDefense(sCharacter *Character);
    long  GetAgility(sCharacter *Character);
    long  GetResistance(sCharacter *Character);
    long  GetMental(sCharacter *Character);
    long  GetToHit(sCharacter *Character);
    float GetCharge(sCharacter *Character);

	BOOL LoadItemListToChar(int IDNum, char* filename=NULL);

    // Set lock and action timer
    BOOL SetLock(long IDNum, BOOL State);
    BOOL SetActionTimer(long IDNum, long Timer);

    // Set evade/follow distance
    BOOL  SetDistance(long IDNum, float Distance);
    float GetDistance(long IDNum);

    // Set route points
    BOOL SetRoute(long IDNum,                                 \
                  long NumPoints, sRoutePoint *Route);

    // Set script 
    BOOL SetScript(long IDNum, char *ScriptFilename);
    char *GetScript(long IDNum);

    // Set enable flags
    BOOL SetEnable(long IDNum, BOOL Enable);
    BOOL GetEnable(long IDNum);

    // Functions to move and get character coordinates
    BOOL Move(long IDNum, float XPos, float YPos, float ZPos);
    BOOL GetPosition(long IDNum,                              \
                     float *XPos, float *YPos, float *ZPos);

    // Functions to Set/Get character bounds
    BOOL SetBounds(long IDNum,                                \
                   float MinX, float MinY, float MinZ,        \
                   float MaxX, float MaxY, float MaxZ);
    BOOL GetBounds(long IDNum,                                \
                   float *MinX, float *MinY, float *MinZ,     \
                   float *MaxX, float *MaxY, float *MaxZ);

    // Functions to Set/Get character type
    BOOL SetType(long IDNum, long Type);
    long GetType(long IDNum);

    // Functions to Set/Get character AI
    BOOL SetAI(long IDNum, long Type);
    long GetAI(long IDNum);

	CStageGame* GetStageGame(){return m_StageGame;}
	BYTE** GetMapArr(){return m_StageGame->GetTerrain()->GetMapArr();}

    // Set a target character
    BOOL SetTargetCharacter(long IDNum, long TargetNum);

    // Set text messages to float up from character
    BOOL SetMessage(sCharacter *Character, char *Text,        \
                long Timer, D3DCOLOR Color=0xFFFFFFFF);

	BOOL SetMessageChat(sCharacter *Character, char *Text,        \
                long Timer, D3DCOLOR Color=0xFFFFFFFF);

    // Process attack damage from spells and physical attacks
    BOOL Damage(sCharacter *Victim,                           \
                BOOL PhysicalAttack, long Amount,             \
                long DmgClass, long CureClass);

    // Process death of an NPC/Monster
    BOOL Death(sCharacter *Attacker, sCharacter *Victim);

    // Process experience up
    virtual BOOL Experience(sCharacter *Character,            \
                            long Amount)                      \
         { Character->Def.Experience += Amount; return TRUE; }

    // Resolve a physical attack from attacker to victim
    BOOL Attack(sCharacter *Attacker, sCharacter *Victim);

    // Process spell ailments when spell completed
    BOOL Spell(sCharacter *Caster,                            \
               sSpellTracker *SpellTracker, sSpell *Spells);
    
    // Apply spell effects
    BOOL SpellEffect(sCharacter *Caster, sCharacter *Target,  \
                     sSpell *Spell);

    // Process equipping/unequipping of item
    BOOL Equip(sCharacter *Character, long ItemNum,           \
               long Type, BOOL Equip);

    // Process a PC teleport spell
    virtual BOOL PCTeleport(sCharacter *Character,            \
                            sSpell *Spell)                    \
            { return TRUE; }

    // Set action (w/timer)
    BOOL SetAction(sCharacter *Character,                     \
                   long Action, long AddTime = 0);

};

#endif
