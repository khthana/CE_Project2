#ifndef _CMiniMap_H_
#define _CMiniMap_H_

#include "HGlobal.h"

class CMiniMap{
	private:
		CGraphic			*m_Graphic;
		
		CVertexBuffer		m_MapVB;
		CVertexBuffer		m_PicVB;

		CTexture			m_MiniMap;
		CTexture			m_Cursor;

		float				m_MXPos;
		float				m_MYPos;
		float				m_PicSize;
		long				m_MapSize;

		
	public:
		CMiniMap();
		~CMiniMap();
	
		BOOL Create(CGraphic* Graphic, char *Filename, float Size, 	\
					  float MXPos, float MYPos, long MapSize);
		
		// Render the map to display
		BOOL Render(float *XPos, float *ZPos, float *Angle);

		void Cleanup();
};

#endif