#ifndef _CLANDSCAPE_H_
#define _CLANDSCAPE_H_


#include "HGlobal.h"
#include "CFrustum.h"
#include "CNodeTree.h"
//============================================================================
// Class : CLandscape
//============================================================================
class CLandscape
{
private:
	CGraphic		*m_Graphics;	// Parent CGraphic object
    CFrustum		*m_Frustum;		// Viewing frustum

	CMesh			*m_LandMesh;	// Land Mesh
	//CMesh			*m_DecorMesh;	// Decorate Mesh
	CNodeTreeMesh	*m_LandNode;	// Land NodeTreemesh Object
	//CNodeTreeMesh   *m_DecorNode;	// Decorate NodeTreemesh Object

	int m_MID;

	typedef struct sVertex{
		FLOAT x, y, z;
		DWORD color;
		FLOAT u,v;
	} sVertex;

	BOOL			m_CanMove;		// to disable mouseOn draw automatically
									// when mouse on position that cannot move to

	BYTE**			m_MapArray; 	// Array of Map

	INT				POS;

	BOOL ConvertMouseTo3D(long MouseX, long MouseY, D3DVECTOR* target); // Use for mouse to find position in 3D world

public:
	CLandscape();	// Constructor
	~CLandscape();	// Destructor

	BOOL Create(CGraphic *Graphics,char* FileName,char* TexturePath, int MID, int Pos);
	BOOL Cleanup();

	BOOL Render();

	BOOL SetCanMove(float XPos,float ZPos,bool CanMove=TRUE);

	D3DXVECTOR2 GetMapPosition(float XPos, float ZPos) ;
	INT			GetNumMap(){return POS;}
	BYTE**		GetMapArr(){return m_MapArray;}
	float		GetHeight(float XPos, float ZPos);	// Get Y value at (XPos, ZPos)
	sMesh*		GetParentMesh(){return m_LandMesh->GetParentMesh();}


	// Draw MouseOn on land
	// return position on map (center of grid)
	// and whether player can move over it
	BOOL MouseOnMap(long MouseX, long MouseY, D3DVECTOR* position);
	BOOL CanMove(float XPos, float ZPos);

	INT GetValueMap(float XPos, float ZPos);

};

#endif
