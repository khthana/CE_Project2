#include "CCharacterControl.h"

BOOL CInventory::LoadInventory(sCharacter* charPtr,CStageGame* stageGame)
{
	FILE *fp;
	char szTemp[127];
	long id;
	sItem *item,*itemPtr=NULL;

	m_StageGame = stageGame;

	sprintf(szTemp, ".\\Script\\Inventory\\%s", charPtr->ItemFilename);

	if((fp=fopen(szTemp,"rb"))==NULL) {
		sprintf(szTemp, ".\\Script\\Inventory\\Default%s", charPtr->ItemFilename);
		if ((fp=fopen(szTemp,"rb"))==NULL)
			return false;
	}
	while(1)
	{
		if(fscanf(fp,"%ld",&id)<=0) break;
		
		item = new sItem();
		if(itemPtr == NULL)
			m_ItemParent = item;
		else
			itemPtr->next = item;
		itemPtr = item;
		
		item->ID = id;
		fscanf(fp,"%ld",&item->ItemDef);
		fscanf(fp,"%ld",&item->Count);
		fscanf(fp,"%f",&item->xPos);
		fscanf(fp,"%f",&item->yPos);
		fscanf(fp,"%f",&item->zPos);
		fscanf(fp,"%f",&item->xRot);
		fscanf(fp,"%f",&item->yRot);
		fscanf(fp,"%f",&item->zRot);

	}
	fclose(fp);
	SetBoundingSphere();

	return true;
}
//*********************
BOOL CInventory::Save(char* filename)
{
	sItem* item = m_ItemParent;
	FILE* fp1;
	char szTemp[127];

	sprintf(szTemp, ".\\Script\\Inventory\\%s", filename);

	if((fp1=fopen(filename,"wb"))==NULL) {
		return false;
	}
	while(item!=NULL)
	{
		fprintf(fp1,"%lu %lu %lu %lu %lu %lu %lu %lu %lu\n",	\
			item->ID,item->ItemDef,item->Count,	\
			item->xPos,item->yPos,item->zPos,	\
			item->xRot,item->yRot,item->zRot);
		item = item->next;
	}
	fclose(fp1);
	return TRUE;
}
//---------------------
BOOL CInventory::SetBoundingSphere()
{
	return TRUE;
}
//---------------------
sItem* CInventory::FindItem(int itemId)
{
	sItem *item = m_ItemParent;
	while(item!=NULL)
	{
		if(item->ID == itemId)
			return item;
		item = item->next;
	}
	return NULL;
}
sItem* CInventory::FindItemDef(int id)
{
	sItem *item = m_ItemParent;
	while(item!=NULL)
	{
		if(item->ItemDef==id)
			return item;
		item = item->next;
	}
	return NULL;
}
BOOL CInventory::AddItem(long ItemDefId,int count)
{
	sItem* ptr = m_ItemParent;
	sItem* tmp;
	int id;

	if (ptr == NULL)
	{
		sItem* item = new sItem();
		m_ItemParent->ID = 0;
		m_ItemParent->ItemDef = ItemDefId;
		m_ItemParent->Count = count;
		m_ItemParent->xPos = 0;
		m_ItemParent->yPos = 0;
		m_ItemParent->zPos = 0;

		m_ItemParent->xRot = m_ItemParent->yRot = m_ItemParent->zRot =0.0;
		m_ItemParent = item;
	}else
	{
		while(ptr!=NULL)
		{
			//Found Item In list then increase count
			if(ptr->ItemDef == ItemDefId)
			{
				ptr->Count = count;
				return true;
			}
			tmp = ptr;
			id  = ptr->ID;
			ptr = ptr->next;
		}
		//*****If item never have been in list then create new Item ************
		sItem* newItem = new sItem();
		newItem->ID = ++id;
		newItem->ItemDef = ItemDefId;
		newItem->Count = count;
		newItem->xPos = 0;
		newItem->yPos = 0;
		newItem->zPos = 0;

		newItem->xRot = newItem->yRot = newItem->zRot =0.0;
		m_StageGame->GetItemDef(*m_StageGame->FindItemDef(newItem->ItemDef),ItemDefId);
		tmp->next = newItem;
	}
	return true;
}
//**************************************
void CInventory::FindListMagicItem(sItem** MgItem,int& amount)
{
	sItem* item = m_ItemParent;
	amount = 0;
	while(item!=NULL)
	{
		if(m_StageGame->FindItemDef(item->ItemDef)->eTypeItem == MAGIC)
		{
			MgItem[amount] = item; 
			amount++;
		}
		item = item->next;
	}
}
//*************************************
void CInventory::FindListHealingItem(sItem** HealItem,int& amount)
{
	sItem* item = m_ItemParent;
	amount = 0;
	while(item!=NULL)
	{
		if(m_StageGame->FindItemDef(item->ItemDef)->eTypeItem == HEALING)
		{
			HealItem[amount++] = item;
		}
		item = item->next;
	}
}
