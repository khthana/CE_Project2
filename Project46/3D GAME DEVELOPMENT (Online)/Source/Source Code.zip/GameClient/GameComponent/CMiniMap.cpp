#include "CMiniMap.h"

CMiniMap::CMiniMap()
{
	m_Graphic = NULL;

}

CMiniMap::~CMiniMap()
{
	Cleanup();
}

void CMiniMap::Cleanup()
{
	m_MapVB.Cleanup();
	m_PicVB.Cleanup();
	m_MiniMap.Cleanup();
}

BOOL CMiniMap::Create(CGraphic* Graphic, char *Filename, float Size, 	\
					  float MXPos, float MYPos, long MapSize)
{
	if ((m_Graphic = Graphic)==NULL)
		return FALSE;

	m_MXPos = MXPos;
	m_MYPos = MYPos;
	m_PicSize = Size;
	m_MapSize = MapSize;
	
	CUSTOMVERTEX sVertex[4]={
        {MXPos, MYPos+Size,		 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        {MXPos, MYPos,			 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        {MXPos+Size, MYPos+Size, 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        {MXPos+Size, MYPos,		 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };

	if (m_MapVB.Create(m_Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX)))
		m_MapVB.Set(0,4,(void*)&sVertex);

	m_MiniMap.Load(m_Graphic, Filename, 0xff000000);

	if (m_PicVB.Create(m_Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX)))
		m_Cursor.Load(m_Graphic, ".\\Texture\\Cursor.bmp", 0x0FFFFFFFF);

	return TRUE;
}

BOOL CMiniMap::Render(float *XPos, float *ZPos, float *Angle)
{
	if (m_MiniMap.IsLoaded())
	{
		m_Graphic->EnableAlphaBlending(TRUE);
		m_Graphic->EnableAlphaTesting();
		m_Graphic->GetDevice()->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
		m_Graphic->GetDevice()->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
		m_Graphic->GetDevice()->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_POINT);
		m_Graphic->SetTexture(0,&m_MiniMap);
		m_MapVB.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	
	float XMapPos,YMapPos;

	XMapPos = ((*XPos)*m_PicSize/(float)m_MapSize)+m_MXPos;
	YMapPos = (-(*ZPos)*m_PicSize/(float)m_MapSize)+m_MYPos+m_PicSize;

	CUSTOMVERTEX sVertex[4]={
        {XMapPos-5, YMapPos+5 ,	 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        {XMapPos-5, YMapPos-5 ,	 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        {XMapPos+5, YMapPos+5 ,  0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        {XMapPos+5, YMapPos-5 ,	 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };

	if (m_PicVB.IsLoaded())
	{
		m_PicVB.Set(0,4,(void*)&sVertex);
		m_Graphic->EnableAlphaTesting();
		m_Graphic->SetTexture(0,&m_Cursor);
		m_PicVB.Render(0,2,D3DPT_TRIANGLESTRIP);
	}

	return TRUE;
}