#include "HGlobal.h"

#include "CCharacterControl.h"
#include "CStageGame.h"
#include "Spell.h"

CCharacterController::CCharacterController()
{
  m_Graphics          = NULL;  // Clear CGraphic pointer
  m_StageGame		  = NULL;  // StageGame Pointer
  m_Font              = NULL;  // Clear CFont pointer
  m_Frustum           = NULL;  // Clear frustum pointer

  m_MSL               = NULL;  // Clear MSL pointer

  m_CharacterParent   = NULL;  // Clear character list
  m_NumCharacters     = 0;

  ZeroMemory(m_DefinitionFile,sizeof(m_DefinitionFile));     // Clear definition filename

  m_NumMeshes         = 0;     // Clear mesh data
  m_Meshes            = NULL;
  m_TexturePath[0]    = 0;

  m_NumAnimations     = 0;     // Clear animation data
  m_Animations        = NULL;

  m_SpellController   = NULL;  // Clear spell controller

  m_MeshesDie		  = new sCharacterMeshList();

  strcpy(m_MeshesDie->Filename,".\\Model\\Character\\die_effect.X");
}

CCharacterController::~CCharacterController()
{
  Shutdown();
}

BOOL CCharacterController::Init(                              \
                          CGraphic *Graphics, CFont *Font,    \
                          CStageGame* StageGame, char *DefinitionFile,  \
                          sSpell *MSL, long NumCharacterMeshes,            \
                          char **MeshNames,                   \
                          char *MeshPath, char *TexturePath,  \
                          long NumAnimations,                 \
                          sCharAnimationInfo *Anims,          \
                          CSpellController *SpellController)
{
	long i;

	Cleanup();  // Free prior init

	// Get parent graphics object and error checking
	if((m_Graphics = Graphics) == NULL || MeshNames == NULL ||  \
	 DefinitionFile == NULL)
	return FALSE;

	m_StageGame = StageGame;
	
	// Get font object pointer
	m_Font = Font;

	m_Name.Create(m_Graphics,"AngsanaUPC",14,TRUE);

	m_Message.Create(m_Graphics,"AngsanaUPC",18);

	// Copy definition file name
	strcpy(m_DefinitionFile, DefinitionFile);

	// Store MSL pointer
	m_MSL = MSL;

	// Copy over mesh path (or set default)
	if(MeshPath != NULL)
	strcpy(m_MeshPath, MeshPath);
	else
	strcpy(m_MeshPath, ".\\");

	// Copy over texture path (or set default)
	if(TexturePath != NULL)
	strcpy(m_TexturePath, TexturePath);
	else
	strcpy(m_TexturePath, ".\\");

	// Get mesh names
	if((m_NumMeshes = NumCharacterMeshes)) {
	m_Meshes = new sCharacterMeshList[NumCharacterMeshes]();
	for(i=0;i<m_NumMeshes;i++)
	  strcpy(m_Meshes[i].Filename, MeshNames[i]);
	}

	m_MeshesDie->Mesh.Load(m_Graphics, m_MeshesDie->Filename,".\\Model\\Character\\",TRUE,0xffff00ff);
    m_MeshesDie->Animation.Load(m_MeshesDie->Filename, &m_MeshesDie->Mesh);
    m_MeshesDie->Animation.SetLoop(TRUE,"die");

	m_Die.Create(m_Graphics, &m_MeshesDie->Mesh);

	// Get animation data
	if((m_NumAnimations = NumAnimations)) {
	m_Animations = new sCharAnimationInfo[m_NumAnimations]();
	for(i=0;i<m_NumAnimations;i++) {
	  memcpy(&m_Animations[i], &Anims[i],                     \
			 sizeof(sCharAnimationInfo));
	}
	}

	// Store spell controller pointer
	m_SpellController = SpellController;

/////////// Item /////////////
	StageGame->LoadItemDef();
	StageGame->LoadEnvDef();
	
  return TRUE;
}

BOOL CCharacterController::Shutdown()
{
  Cleanup();

   // Release mesh list
  delete [] m_Meshes;
  m_Meshes = NULL;
  delete m_MeshesDie;
  m_MeshesDie = NULL;
  m_NumMeshes = 0;
  m_Name.Cleanup();
  m_Message.Cleanup();
  
  // Release animation data
  m_NumAnimations = 0;
  delete [] m_Animations;
  m_Animations = NULL;

  // Clear graphics object
  m_Graphics = NULL;
  m_StageGame = NULL;
  m_Font    = NULL;
  m_Frustum = NULL;

  // Clear paths
  m_DefinitionFile[0] = 0;
  m_MeshPath[0] = 0;
  m_TexturePath[0] = 0;

  // Clear spell controller
  m_SpellController = NULL;

  return TRUE;
}

BOOL CCharacterController::Cleanup()
{
  // Release character structures
  delete m_CharacterParent;
//  m_Meshes = NULL;
  m_CharacterParent = NULL;
  m_NumCharacters = 0;

  return TRUE;
}

BOOL CCharacterController::Add(                               \
             long IDNum, char* name, long Definition,                     \
             long Type, long AI,                              \
             float XPos, float YPos, float ZPos,              \
             float Direction)
{
  sCharacter *CharPtr;
  FILE *fp;
  //char Path[MAX_PATH];
  long i;

  // Error checking
  if(m_Graphics==NULL || m_Meshes==NULL || !m_DefinitionFile[0])
    return FALSE;

  // Allocate a new structure
  CharPtr = new sCharacter();

  ZeroMemory(CharPtr->Name, sizeof(CharPtr->Name));
  // Assign data
  if (name != NULL)
	strcpy(CharPtr->Name, name);

  CharPtr->Definition = Definition;
  CharPtr->ID         = IDNum;
  CharPtr->Type       = Type;
  CharPtr->AI         = AI;
  CharPtr->XPos       = XPos;
  CharPtr->YPos       = YPos;
  CharPtr->ZPos       = ZPos;
  CharPtr->XDestPos	  = XPos;
  CharPtr->ZDestPos	  = ZPos;
  CharPtr->TargetChar = NULL;
  CharPtr->Direction  = Direction;
  CharPtr->Enabled    = TRUE;
  CharPtr->MapSize	  = m_StageGame->GetTerrain()->GetNumMap();
  CharPtr->AllPath	  = (int**)malloc(m_StageGame->GetTerrain()->GetNumMap() * sizeof(int*));
  for (i=0; i < m_StageGame->GetTerrain()->GetNumMap(); i++)
	CharPtr->AllPath[i] = (int*)malloc(m_StageGame->GetTerrain()->GetNumMap() * sizeof(int));

  // Set a random charge amount
  CharPtr->Charge = (float)(rand() % 101);

  // Load character definition
  if((fp=fopen(m_DefinitionFile, "rb"))==NULL) {
    delete CharPtr;
    return FALSE;
  }
  fseek(fp, sizeof(sCharacterDefinition)*Definition, SEEK_SET);
  fread(&CharPtr->Def, 1, sizeof(sCharacterDefinition), fp);
  fclose(fp);

    // Set character stats
  CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
  CharPtr->ManaPoints   = CharPtr->Def.ManaPoints;

    // Load mesh and animation if needed
  if(!m_Meshes[CharPtr->Def.MeshNum].Count) {
    m_Meshes[CharPtr->Def.MeshNum].Mesh.Load(m_Graphics,      \
                   m_Meshes[CharPtr->Def.MeshNum].Filename,   \
                   m_TexturePath);
    m_Meshes[CharPtr->Def.MeshNum].Animation.Load(            \
                   m_Meshes[CharPtr->Def.MeshNum].Filename,   \
                   &m_Meshes[CharPtr->Def.MeshNum].Mesh);

    // Set animation loops
    if(m_NumAnimations) {
      for(i=0;i<m_NumAnimations;i++)
        m_Meshes[CharPtr->Def.MeshNum].Animation.SetLoop(     \
                                      m_Animations[i].Loop,   \
                                      m_Animations[i].Name);
    }
  }

  // Configure graphics object
  CharPtr->Object.Create(m_Graphics,                          \
                        &m_Meshes[CharPtr->Def.MeshNum].Mesh);
  m_Meshes[CharPtr->Def.MeshNum].Count++;

  ZeroMemory(CharPtr->ScriptFilename, sizeof(char));

  strcpy(CharPtr->ScriptFilename,"NONE");

  // Link in to head of list
  if(m_CharacterParent != NULL)
    m_CharacterParent->Prev = CharPtr;
  CharPtr->Next = m_CharacterParent;
  m_CharacterParent = CharPtr;

  return TRUE;
}

BOOL CCharacterController::Remove(long IDNum)
{
  return Remove(GetCharacter(IDNum));
}
 
BOOL CCharacterController::Remove(sCharacter *Character)
{
  // Error checking
  if(Character == NULL)
    return FALSE;

  // Decrease mesh count and release if no more
  m_Meshes[Character->Def.MeshNum].Count--;
  if(!m_Meshes[Character->Def.MeshNum].Count) {
    m_Meshes[Character->Def.MeshNum].Mesh.Cleanup();
    m_Meshes[Character->Def.MeshNum].Animation.Cleanup();
  }

  // Remove from list and free resource
  if(Character->Prev != NULL)
    Character->Prev->Next = Character->Next;
  else
    m_CharacterParent = Character->Next;

  if(Character->Next != NULL)
    Character->Next->Prev = Character->Prev;

  if(Character->Prev == NULL && Character->Next == NULL)
    m_CharacterParent = NULL;

  Character->Prev = Character->Next = NULL;

  delete[] Character->AllPath;
  delete Character;

  return TRUE;
}

BOOL CCharacterController::Save(long IDNum, char *Filename)
{
  sCharacter *CharPtr;
  FILE *fp;
  char szTemp[127];

  // Get pointer to character in list
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Open file
  if((fp=fopen(Filename, "wb"))==NULL)
    return FALSE;

  sItem* item = CharPtr->m_Inventory.GetItemParent();

  // Output character data
  

  fprintf(fp,"%lu %lu", CharPtr->HealthPoints, CharPtr->ManaPoints);
  sprintf(szTemp, ".\\Script\\Inventory\\%s",CharPtr->ItemFilename);
  CharPtr->m_Inventory.Save(szTemp);

  // Close file
  fclose(fp);

  return TRUE;
}

BOOL CCharacterController::Load(long IDNum, char *Filename)
{
  sCharacter *CharPtr;
  FILE *fp;

  // Get pointer to character in list

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Open file
  if((fp=fopen(Filename, "rb"))==NULL)
    return FALSE;

  // Read in character data
  fscanf(fp,"%lu", &CharPtr->HealthPoints);
  fscanf(fp,"%lu", &CharPtr->ManaPoints);
  
  // Close file
  fclose(fp);

  return TRUE;
}

long CCharacterController::ClickOnCharacter(CRelativeCamera* Camera,long XMouse ,long YMouse, D3DXVECTOR3* m_MouseClickPos)
{
	sCharacter* CharPtr;
	float XCamPos,YCamPos,ZCamPos;
	if ((CharPtr = m_CharacterParent) != NULL)
	{
		while (CharPtr != NULL)
		{
			if (CharPtr->Type != CHAR_PC && CharPtr->Enabled)
			{
				m_StageGame->GetTerrain()->MouseOnMap(XMouse,YMouse,m_MouseClickPos);

				XCamPos = Camera->GetCamera()->GetXPos();
				YCamPos = Camera->GetCamera()->GetYPos();
				ZCamPos = Camera->GetCamera()->GetZPos();

				bool equa1=false;
				bool equa2=false;
				bool equa3=false;
				float m1,m2,m3;
				float x1,x2,y1,y2,z1,z2; // bound of Character
				float ax1,ay1,az1,ax2,ay2,az2;

				x1 = CharPtr->XPos-m_MouseClickPos->x+10;
				x2 = CharPtr->XPos-m_MouseClickPos->x-10;
				y1 = 50;
				y2 = 0;
				z1 = CharPtr->ZPos-m_MouseClickPos->z+10;
				z2 = CharPtr->ZPos-m_MouseClickPos->z-10;
				
				m1 = (XCamPos-m_MouseClickPos->x)/(YCamPos-m_MouseClickPos->y);
				m2 = (XCamPos-m_MouseClickPos->x)/(ZCamPos-m_MouseClickPos->z);
				m3 = (ZCamPos-m_MouseClickPos->z)/(YCamPos-m_MouseClickPos->y);
				
				ay1 = x1/m1;		ay2 = x2/m1;		
				ax1 = y1*m1;		ax2 = y2*m1;

				if (y2 < ay1 && ay1 < y1)
					equa1 = true;
				else if (y2 < ay2 && ay2 < y1)
					equa1 = true;
				else if (x2 < ax1 && ax1 < x1)
					equa1 = true;
				else if (x2 < ax2 && ax2 < x1)
					equa1 = true;
				
				az1 = x1/m2;		az2 = x2/m2;
				ax1 = z1*m2;		ax2 = z2*m2;

				if (z2 < az1 && az1 < z1)
					equa2 = true;
				else if (z2 < az2 && az2 < z1)
					equa2 = true;
				else if (x2 < ax1 && ax1 < x1)
					equa2 = true;
				else if (x2 < ax2 && ax2 < x1)
					equa2 = true;

				ay1 = z1/m3;		ay2 = z2/m3;		
				az1 = y1*m3;		az2 = y2*m3;

				if (y2 < ay1 && ay1 < y1)
					equa3 = true;
				else if (y2 < ay2 && ay2 < y1)
					equa3 = true;
				else if (z2 < az1 && az1 < z1)
					equa3 = true;
				else if (z2 < az2 && az2 < z1)
					equa3 = true;

				if (equa1 & equa2 & equa3)
				{
					m_MouseClickPos->x = 0;
					m_MouseClickPos->y = 0;
					m_MouseClickPos->z = 0;
					return CharPtr->ID;
				}
			}
			CharPtr = CharPtr->Next;
		}
	}
	
	return -1;
}

BOOL CCharacterController::Update(long Elapsed, CSoundChannel* Soundaction, CSoundData* SoundData)
{

  sCharacter *CharPtr;
  float XMove, YMove, ZMove;
  static long EffectCounter = 0;
  BOOL ToProcess, DeadChar;

  // Return success if no characters to update
  if((CharPtr = m_CharacterParent) == NULL)
    return TRUE;

  // Loop through all characters
  while(CharPtr != NULL) {

	  if(CharPtr->Enabled == TRUE) 
	  {
		  // Update action timer if in use
		  if(CharPtr->ActionTimer != 0) {
			CharPtr->ActionTimer -= Elapsed;
			if(CharPtr->ActionTimer < 0)
			  CharPtr->ActionTimer = 0;
		  }

		  // Update text message timer
		  if(CharPtr->MessageTimer > 0)
			CharPtr->MessageTimer -= Elapsed;

		  // Update text message timer
		  if(CharPtr->ChatTimer > 0)
			CharPtr->ChatTimer -= Elapsed;

		  // Reset charge counter if attacking, spell, or item
		  if(CharPtr->Action == CHAR_ATTACK ||                    \
			 CharPtr->Action == CHAR_SPELL  ||                    \
			 CharPtr->Action == CHAR_ITEM)
		  {
			CharPtr->Charge = 0.0f;
			
		  }

		  // Mark that processing can continue later on
		  ToProcess = TRUE;

		  // Mark character as still alive
		  DeadChar = FALSE;

		  // Process non-idle, non-walk actions
		  if(CharPtr->Action != CHAR_IDLE &&                      \
			 CharPtr->Action != CHAR_MOVE &&                      \
			 !CharPtr->ActionTimer) {
         
			switch(CharPtr->Action) {
			  case CHAR_ATTACK:
				if(ToProcess == TRUE)
				  Attack(CharPtr, CharPtr->Victim);
				break;
			
			  case CHAR_SPELL:
				// Manually cast a spell
				if(m_SpellController != NULL && m_MSL != NULL &&  \
				   ToProcess == TRUE) {
					m_SpellController->Add(CharPtr->SpellNum,       \
							   CharPtr, CharPtr->SpellTarget,     \
							   CharPtr->XPos,                     \
							   CharPtr->YPos+30,                     \
							   CharPtr->ZPos,                     \
							   CharPtr->TargetX,                  \
							   CharPtr->TargetY,                  \
							   CharPtr->TargetZ);
				}
				CharPtr->Action = CHAR_IDLE;
				break;

			  case CHAR_DIE:
				Death(CharPtr->Attacker, CharPtr);
				CharPtr->Attacker = NULL;
				CharPtr->Enabled = FALSE;
				/*CharPtr->Next = NULL;
				CharPtr->Prev = NULL;*/
				DeadChar = TRUE;   // Mark character as dead
				ToProcess = FALSE; // Don't allow updates
				break;
			}

		  }
		  // Clear movement
		  XMove = ZMove = 0.0f;

		  if(ToProcess == TRUE) {
			  // Only allow updates if lock/timer not in use 
			  if(CharPtr->Enabled == TRUE && CharPtr->Locked == FALSE) {

				  if (CharPtr->Type != CHAR_PC && !CharPtr->ActionTimer) {
						if (CharPtr->Type == CHAR_USER)
						{
							UserUpdate(CharPtr, Elapsed, &XMove, &YMove, &ZMove);
							
							// Check for validity of movement (clear if invalid)
							if(CheckMove(CharPtr,&XMove,&YMove,&ZMove)==FALSE) {
								XMove = ZMove = 0.0f;
								CharPtr->Action = CHAR_IDLE;
							}						
						}else
						{
							CharPtr->Action = CHAR_IDLE;
							CharUpdate(CharPtr, Elapsed, &XMove,&YMove,&ZMove);
							
							// Check for validity of movement (clear if invalid)
							if(CheckMove(CharPtr,&XMove,&YMove,&ZMove)==FALSE) {
								XMove = ZMove = 0.0f;
								CharPtr->Action = CHAR_IDLE;
							}
						}
				  }

				  if(CharPtr->Type == CHAR_PC)
				  {	
					//if (CharPtr->Action == CHAR_ATTACK) CharPtr->Action = CHAR_IDLE;
				    PCUpdate(CharPtr, Elapsed, &XMove, &YMove, &ZMove);
					
					// Check for validity of movement (clear if invalid)
					if(CheckMove(CharPtr,&XMove,&YMove,&ZMove)==FALSE) {
						XMove = ZMove = 0.0f;
						CharPtr->Action = CHAR_IDLE;
					}
				  }
			  }

			  YMove = m_StageGame->GetTerrain()->GetHeight(CharPtr->XPos,CharPtr->ZPos);
			  
			  // Process movement of character
			  ProcessUpdate(CharPtr, XMove, YMove, ZMove);

			  // Increase action charge of character
			  CharPtr->Charge += ((float)Elapsed / 1000.0f *        \
							   GetCharge(CharPtr));
			  if(CharPtr->Charge > 100.0f)
				  CharPtr->Charge = 100.0f;
		  }
	  }

	  // Go to next character
	  CharPtr = CharPtr->Next;
  }

  return TRUE;
}

BOOL CCharacterController::UserUpdate(sCharacter *Character, long Elapsed,      \
                    float *XMove, float *YMove, float *ZMove)
{
	sCharacter *CharPtr;
	float XDiff, ZDiff;

	if ((CharPtr = Character) == NULL)
		return FALSE;

	float	angle = 0;
	D3DXVECTOR2 CharMapPos;
	float Speed;
		
	Speed = 2;
// Move Character
	switch(CharPtr->AI)
	{
		case CHAR_STAND:
		case CHAR_WANDER:
			break;

		case CHAR_ROUTE:
			if (CharPtr->NumPoints > 0)
			{
				XDiff = CharPtr->Route[CharPtr->CurrentPoint].XPos - CharPtr->XPos;
				ZDiff = CharPtr->Route[CharPtr->CurrentPoint].ZPos - CharPtr->ZPos ;

				if (fabs(CharPtr->Direction - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f || 
					fabs(CharPtr->Direction - (CharPtr->Route[CharPtr->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((CharPtr->Direction+(2*D3DX_PI)) - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f)
				{
					CharPtr->Direction = CharPtr->Route[CharPtr->CurrentPoint].Direction;
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);

					float dir = CharPtr->Route[CharPtr->CurrentPoint].Direction - CharPtr->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						CharPtr->Direction += D3DX_PI/12;
					else CharPtr->Direction -= D3DX_PI/12;	

					if (CharPtr->Direction < 0) 
						CharPtr->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					CharPtr->Route[CharPtr->CurrentPoint].XPos = -1;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos = -1;
					CharPtr->CurrentPoint++;
					CharPtr->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				}
				CharPtr->Action = CHAR_MOVE;
			}else {
				CharPtr->AI = CHAR_STAND;
				CharPtr->Action = CHAR_IDLE;
				CharPtr->NumPoints = 0;
			}
			break;
	}

	// Check Victim is in range?
	if (CharPtr->Victim != NULL && !CharPtr->ActionTimer)
	{
		if (fabs(CharPtr->XPos-CharPtr->Victim->XPos) <= 30 && fabs(CharPtr->ZPos-CharPtr->Victim->ZPos) <= 30)
		{

			if(CharPtr->Action == CHAR_ATTACK) 
				CharPtr->Action = CHAR_IDLE;

			CharPtr->FreePath();
			CharPtr->AI = CHAR_STAND;
			CharPtr->TargetChar = NULL;
			D3DXVECTOR2 PCPos = GetStageGame()->GetTerrain()->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);
			D3DXVECTOR2 CharPos = GetStageGame()->GetTerrain()->GetMapPosition(CharPtr->Victim->XPos,CharPtr->Victim->ZPos);

			int x = int(PCPos.x-CharPos.x);
			int z = int(PCPos.y-CharPos.y);

			x = x/abs((x==0?1:x));	
			z = z/abs((z==0?1:z));
  
			if (x==0 && z==-1) CharPtr->Direction = 0;
			else if (x==0 && z==1) CharPtr->Direction = D3DX_PI;
			else if (x==-1 && z==0) CharPtr->Direction = D3DX_PI/2;
			else if (x==1 && z==0) CharPtr->Direction = 3*D3DX_PI/2;
			else if (x==1 && z==1) CharPtr->Direction = 5*D3DX_PI/4;
			else if (x==1 && z==-1) CharPtr->Direction = 7*D3DX_PI/4;
			else if (x==-1 && z==-1) CharPtr->Direction = D3DX_PI/4;
			else if (x==-1 && z==1) CharPtr->Direction = 3*D3DX_PI/4;

			  // Perform attack action
			if (CharPtr->Action != CHAR_ATTACK)
			{
			  SetAction(CharPtr, CHAR_ATTACK);
			}
		}else {
			if (CharPtr->TargetChar == NULL)
			{
				CharPtr->Action = CHAR_IDLE;
				CharPtr->Victim->Attacker = NULL;
				CharPtr->Victim = NULL;
			}
		}
	}
	return TRUE;
}

BOOL CCharacterController::Render(                            \
               long       Elapsed,                            \
               CFrustum  *Frustum,                            \
               float      ZDistance)
{
  CFrustum     ViewFrustum;  // Local viewing frustum
  float        Radius;       // Bounding radius
  sCharacter  *CharPtr; 
  DWORD        Time;

  // Variables for printing messages
  BOOL         GotMatrices = FALSE;
  D3DXMATRIX   matWorld, matView, matProj;
  D3DXVECTOR3  vecPos;
  D3DVIEWPORT8 vpScreen;
  float        MaxY;

  // Error checking
  if(m_Graphics == NULL)
    return FALSE;

  // Return success if no character to draw
  if((CharPtr = m_CharacterParent) == NULL)
    return TRUE;

  // Construct the viewing frustum (if none passed)
  if((m_Frustum = Frustum) == NULL) {
    ViewFrustum.Construct(m_Graphics, ZDistance);
    m_Frustum = &ViewFrustum;
  }

  // Get time to update animations (30fps) if
  // elapsed value passed == -1
   
  // Loop through each character and draw
  while(CharPtr != NULL) {

	if (CharPtr->Enabled)
	{
		// Update animation based on elapsed time passed
		if(Elapsed != -1) {
		  CharPtr->LastAnimTime += (Elapsed/30);
		  Time = CharPtr->LastAnimTime;
		}

		if(Elapsed == -1)
		{
			if (CharPtr->Action == CHAR_MOVE)
				Time = timeGetTime() / 20;
			else Time = timeGetTime() / 30;
		}

		CharPtr->Object.GetBounds(NULL,NULL,NULL,                 \
								  NULL,&MaxY,NULL,&Radius);

		// Draw character if in viewing frustum
		if(m_Frustum->CheckSphere(CharPtr->Object.GetXPos(),      \
								  CharPtr->Object.GetYPos(),      \
								  CharPtr->Object.GetZPos(),      \
								  Radius) == TRUE) {
		  if (CharPtr->Action == CHAR_DIE)
		  {
			m_Die.Move(CharPtr->XPos,CharPtr->YPos,CharPtr->ZPos);
			m_Die.Scale(2.5f,2.5f,2.5f);
			m_Die.SetAnimation(&m_MeshesDie->Animation, "die", timeGetTime()/1000);
			m_Die.UpdateAnimation(timeGetTime()/30, TRUE);
			m_Die.Render();
		  }
		  CharPtr->Object.UpdateAnimation(Time, TRUE);
		  CharPtr->Object.Render();

		   // Draw character's weapon
		  if(CharPtr->Def.Weapon != -1)
			CharPtr->WeaponObject.Render();

		  // Get the matrices and viewport if not done already
		  if(GotMatrices == FALSE) {
		  	  GotMatrices = TRUE;

			  // Get the world, projection, and view transformations
			  D3DXMatrixIdentity(&matWorld);
			  m_Graphics->GetDevice()->GetTransform(           \
		  								  D3DTS_VIEW, &matView);
			  m_Graphics->GetDevice()->GetTransform(           \
										  D3DTS_PROJECTION, &matProj);

				  // Get viewport
			  m_Graphics->GetDevice()->GetViewport(&vpScreen);
		  }

			// Project coordinates to screen  
		  D3DXVec3Project(&vecPos,                              \
					  &D3DXVECTOR3(CharPtr->XPos,                 \
								   CharPtr->YPos+70,     \
								   CharPtr->ZPos),                \
					  &vpScreen, &matProj, &matView, &matWorld);

		  // Draw Character name
		  if (strcmp(CharPtr->Name,""))
			m_Name.Print(CharPtr->Name,(long)vecPos.x-5, (long)vecPos.y+5,0,0,0x0ffff0000);

		  // Print ChatMessage
		  if (CharPtr->ChatTimer > 0) {
			// Print message
			m_Message.Print(CharPtr->MessageChat,                       \
						  (long)vecPos.x-10, (long)vecPos.y-10,         \
						  0, 0, CharPtr->ChatMessageColor);
		  }

		  // Draw message if needed
		  if(CharPtr->MessageTimer > 0 ) {

			// Print message
			m_Font->Print(CharPtr->Message,                       \
						  (long)vecPos.x, (long)vecPos.y+15,         \
						  0, 0, CharPtr->MessageColor);
		  }
		}
	}
    // go to next character    
    CharPtr = CharPtr->Next;
  }

  return TRUE;
}

float CCharacterController::GetXZRadius(sCharacter *Character)
{
  float MinX, MaxX, MinZ, MaxZ;
  float x, z;

  // Error checking
  if(Character == NULL)
    return 0.0f;

  Character->Object.GetBounds(&MinX, NULL, &MinZ,             \
                              &MaxX, NULL, &MaxZ, NULL);
  x = (float)max(fabs(MinX), fabs(MaxX));
  z = (float)max(fabs(MinZ), fabs(MaxZ));

  return max(x, z);
}

long CCharacterController::CheckEvent()
{
	int XDiffMap,ZDiffMap;
	sCharacter* CharPtr;
	sCharacter* CharPC = GetCharacter(CHAR_PC);
	
	if ((CharPtr=m_CharacterParent)==NULL)
		return -1;

	while(CharPtr!=NULL)
	{		
		if (strcmp(CharPtr->ScriptFilename,"NONE"))
		{
			if (CharPC->ID != CharPtr->ID && CharPC->TargetChar != NULL && CharPC->NumPoints == 0 && CharPtr->Enabled)
			{
				XDiffMap = (int)fabs((CharPC->XPos/20)-(CharPtr->XPos/20));
				ZDiffMap = (int)fabs((CharPC->ZPos/20)-(CharPtr->ZPos/20));


				if (XDiffMap <= 1 && ZDiffMap <= 1)
					return CharPtr->ID;
			}
		}
		CharPtr = CharPtr->Next;
	}
	
	return -1;

}
///////////////////////////////////////////////////////////
// Set/Get Functions
///////////////////////////////////////////////////////////
sCharacter *CCharacterController::GetParentCharacter()
{
  return m_CharacterParent;
}

sCharacter *CCharacterController::GetCharacter(long IDNum)
{
  sCharacter *CharPtr;

  // Scan through all characters
  if((CharPtr = m_CharacterParent) != NULL) {
    while(CharPtr != NULL) {
    
      // Return character
      if(IDNum == CharPtr->ID)
        return CharPtr;
   
      // Go to next character
      CharPtr = CharPtr->Next;
    }
  }

  return NULL;
}

float CCharacterController::GetSpeed(sCharacter *Character)
{
  float Speed;
  
  // Error checking
  if(Character == NULL)
    return 0.0f;

  // Calculate adjusted speed
  Speed = Character->Def.Speed;

  if(Character->Ailments & AILMENT_SLOW)
    Speed *= 0.5f;
  if(Character->Ailments & AILMENT_FAST)
    Speed *= 1.5f;

  // Bounds check value
  if(Speed < 1.0f)
    Speed = 1.0f;

  return Speed;
}

long CCharacterController::GetAttack(sCharacter *Character)
{
  long Attack;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted attack
  Attack = Character->Def.Attack;

  // Adjust attack based on item value (in %(Value/100)+1)
  if(Character->Def.Weapon != -1 && m_StageGame->FindItemDef(0) != NULL) {
    Attack = (long)((float)Attack *                           \
             (((float)m_StageGame->FindItemDef(Character->Def.Weapon)->damageAttack /    \
             100.0f) + 1.0f));
  }

  if(Character->Ailments & AILMENT_WEAK)
    Attack = (long)((float)Attack * 0.5f);
  if(Character->Ailments & AILMENT_STRONG)
    Attack = (long)((float)Attack * 1.5f);

  return Attack;
}

long CCharacterController::GetDefense(sCharacter *Character)
{
  long Defense;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted defense
  Defense = Character->Def.Defense;
  
  if(Character->Def.Armor != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Armor)->defense /     \
             100.0f) + 1.0f));

  if(Character->Def.Shield != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Shield)->defense /    \
             100.0f) + 1.0f));

  if(Character->Ailments & AILMENT_WEAK)
    Defense = (long)((float)Defense * 0.5f);
  if(Character->Ailments & AILMENT_STRONG)
    Defense = (long)((float)Defense * 1.5f);

  // Bounds check value
  if(Defense < 0)
    Defense = 0;

  return Defense;
}

long CCharacterController::GetAgility(sCharacter *Character)
{
  long Agility;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted agility
  Agility = Character->Def.Agility;
  
  if(Character->Ailments & AILMENT_CLUMSY)
    Agility = (long)((float)Agility * 0.75f);
  if(Character->Ailments & AILMENT_SUREFOOTED)
    Agility = (long)((float)Agility * 1.5f);

  return Agility;
}

long CCharacterController::GetResistance(sCharacter *Character)
{
  long Resistance;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted resistance
  Resistance = Character->Def.Resistance;
  
  if(Character->Ailments & AILMENT_ENCHANTED)
    Resistance = (long)((float)Resistance * 0.5f);
  if(Character->Ailments & AILMENT_BARRIER)
    Resistance = (long)((float)Resistance * 1.5f);

  return Resistance;
}

long CCharacterController::GetMental(sCharacter *Character)
{
  long Mental;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted mental
  Mental = Character->Def.Mental;
  
  if(Character->Ailments & AILMENT_DUMBFOUNDED)
    Mental = (long)((float)Mental * 0.5f);

  return Mental;
}

long CCharacterController::GetToHit(sCharacter *Character)
{
  long ToHit;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted to hit
  ToHit = Character->Def.ToHit;
  
  if(Character->Ailments & AILMENT_BLIND)
    ToHit = (long)((float)ToHit * 0.75f);
  if(Character->Ailments & AILMENT_HAWKEYE)
    ToHit = (long)((float)ToHit * 1.5f);

  return ToHit;
}

float CCharacterController::GetCharge(sCharacter *Character)
{
  float Charge;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted charge
  Charge = Character->Def.ChargeRate;
  
  if(Character->Ailments & AILMENT_SLOW)
    Charge = Charge * 0.75f;
  if(Character->Ailments & AILMENT_FAST)
    Charge = Charge * 1.5f;

  return Charge;
}

BOOL CCharacterController::SetLock(long IDNum, BOOL State)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->Locked = State;
  return TRUE;
}

BOOL CCharacterController::SetActionTimer(long IDNum, long Timer)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->ActionTimer = Timer;
  return TRUE;
}

BOOL CCharacterController::SetAction(sCharacter *Character,   \
                                     long Action,             \
                                     long AddTime)
{
  long MeshNum;

  // Error checking
  if(Character == NULL)
    return FALSE;

   // Set action
  Character->Action = Action;

  // Play sound effect
  ActionSound(Character);

  // Get mesh number
  MeshNum = Character->Def.MeshNum;

  // Set action time (or set to 1 is addtime = -1)
  if(AddTime == -1)
    Character->ActionTimer = 1;
  else
  {
    Character->ActionTimer = AddTime;//(m_Meshes[MeshNum].Animation.GetLength(m_Animations[Action].Name) * 33) + AddTime;
  }
  return TRUE;
}

BOOL CCharacterController::SetDistance(                       \
               long IDNum, float Distance)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->Distance = Distance;
  return TRUE;
}

float CCharacterController::GetDistance(long IDNum)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return 0.0f;
  return CharPtr->Distance;
}

BOOL CCharacterController::SetRoute(long IDNum,               \
                                    long NumPoints,           \
                                    sRoutePoint *Route)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Free old route
  delete [] CharPtr->Route;
  CharPtr->Route = NULL;

  // Set new route
  if((CharPtr->NumPoints = NumPoints) != NULL) {
    CharPtr->Route = new sRoutePoint[NumPoints];
    memcpy(CharPtr->Route,Route,NumPoints*sizeof(sRoutePoint));
    CharPtr->CurrentPoint = 0;
  }

  return TRUE;
}

BOOL CCharacterController::SetScript(long IDNum,              \
                                     char *ScriptFilename)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new script
  strcpy(CharPtr->ScriptFilename, ScriptFilename);
  return TRUE;
}

char *CCharacterController::GetScript(long IDNum)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return NULL;
  return CharPtr->ScriptFilename;
}

BOOL CCharacterController::SetEnable(long IDNum, BOOL Enabled)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->Enabled = Enabled;
  return TRUE;
}

BOOL CCharacterController::GetEnable(long IDNum)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;
  return CharPtr->Enabled;
}

BOOL CCharacterController::SetMessage(sCharacter *Character,  \
                                   char *Text, long Timer,    \
                                   D3DCOLOR Color)
{
  strcpy(Character->Message, Text);
  Character->MessageTimer = Timer;
  Character->MessageColor = Color;

  return TRUE;
}

BOOL CCharacterController::SetMessageChat(sCharacter *Character,  \
                                   char *Text, long Timer,    \
                                   D3DCOLOR Color)
{
  strcpy(Character->MessageChat, Text);
  Character->ChatTimer = Timer;
  Character->ChatMessageColor = Color;

  return TRUE;
}

BOOL CCharacterController::Move(                              \
               long IDNum,                                    \
               float XPos, float YPos, float ZPos)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new values
  CharPtr->XPos = XPos;
  CharPtr->YPos = YPos;
  CharPtr->ZPos = ZPos;
  return TRUE;
}

BOOL CCharacterController::GetPosition(                       \
               long IDNum,                                    \
               float *XPos, float *YPos, float *ZPos)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  if(XPos != NULL)
    *XPos = CharPtr->XPos;
  if(YPos != NULL)
    *YPos = CharPtr->YPos;
  if(ZPos != NULL)
    *ZPos = CharPtr->ZPos;

  return TRUE;
}

BOOL CCharacterController::SetBounds(                         \
               long IDNum,                                    \
               float MinX, float MinY, float MinZ,            \
               float MaxX, float MaxY, float MaxZ)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new values
  CharPtr->MinX = min(MinX, MaxX);
  CharPtr->MinY = min(MinY, MaxY);
  CharPtr->MinZ = min(MinZ, MaxZ);
  CharPtr->MaxX = max(MinX, MaxX);
  CharPtr->MaxY = max(MinY, MaxY);
  CharPtr->MaxZ = max(MinZ, MaxZ);

  return TRUE;
}

BOOL CCharacterController::GetBounds(                         \
               long IDNum,                                    \
               float *MinX, float *MinY, float *MinZ,         \
               float *MaxX, float *MaxY, float *MaxZ)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  if(MinX != NULL)
    *MinX = CharPtr->MinX;
  if(MinY != NULL)
    *MinY = CharPtr->MinY;
  if(MinZ != NULL)
    *MinZ = CharPtr->MinZ;
  if(MaxX != NULL)
    *MaxX = CharPtr->MaxX;
  if(MaxY != NULL)
    *MaxY = CharPtr->MaxY;
  if(MaxZ != NULL)
    *MaxZ = CharPtr->MaxZ;

  return TRUE;
}

BOOL CCharacterController::SetType(long IDNum, long Type)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->Type = Type;
  return TRUE;
}

long CCharacterController::GetType(long IDNum)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return 0;
  return CharPtr->Type;
}

BOOL CCharacterController::SetAI(long IDNum, long Type)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->AI = Type;
  return TRUE;
}

long CCharacterController::GetAI(long IDNum)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return 0;
  return CharPtr->AI;
}

BOOL CCharacterController::SetTargetCharacter(long IDNum,     \
                                              long TargetNum)
{
  sCharacter *CharPtr, *CharTarget;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Clear if TargetNum == -1
  if(TargetNum == -1)
    CharPtr->TargetChar = NULL;
  else {
    // Scan through list and target 1st TargetNum found
    CharTarget = m_CharacterParent;
    while(CharTarget != NULL) {
      if(CharTarget->ID == TargetNum) {
        CharPtr->TargetChar = CharTarget;
        break;
      }
      CharTarget = CharTarget->Next;
    }

    // Clear target if not found in list
    if(CharTarget == NULL)
      CharPtr->TargetChar = NULL;
  }
  return TRUE;
}

BOOL CCharacterController::CharUpdate(                        \
               sCharacter *Character, long Elapsed,           \
               float *XMove, float *YMove, float *ZMove)
{
  sCharacter *CharPtr;
  float XDiff, ZDiff;

  if ((CharPtr = Character) == NULL)
 	return FALSE;

  float	angle = 0;
  D3DXVECTOR2 CharMapPos;
  float Speed;
		
  Speed = 2;

   switch(CharPtr->AI)
	{
		case CHAR_STAND:
			break;
		case CHAR_WANDER:
			CharPtr->AI = CHAR_STAND;
			break;

		case CHAR_ROUTE:
			if (CharPtr->NumPoints > 0)
			{
				XDiff = CharPtr->Route[CharPtr->CurrentPoint].XPos - CharPtr->XPos;
				ZDiff = CharPtr->Route[CharPtr->CurrentPoint].ZPos - CharPtr->ZPos ;

				if (fabs(CharPtr->Direction - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f || 
					fabs(CharPtr->Direction - (CharPtr->Route[CharPtr->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((CharPtr->Direction+(2*D3DX_PI)) - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f)
				{
					CharPtr->Direction = CharPtr->Route[CharPtr->CurrentPoint].Direction;
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);

					float dir = CharPtr->Route[CharPtr->CurrentPoint].Direction - CharPtr->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						CharPtr->Direction += D3DX_PI/12;
					else CharPtr->Direction -= D3DX_PI/12;	

					if (CharPtr->Direction < 0) 
						CharPtr->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					CharPtr->Route[CharPtr->CurrentPoint].XPos = -1;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos = -1;
					CharPtr->CurrentPoint++;
					CharPtr->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				}
				CharPtr->Action = CHAR_MOVE;
			}else {
				CharPtr->AI = CHAR_STAND;
				CharPtr->Action = CHAR_IDLE;
				CharPtr->NumPoints = 0;
			}
			break;
	}

   if (Character->Victim != NULL && !Character->ActionTimer)
	  if (Character->Type != CHAR_NPC)
	  {
		  if (fabs(Character->XPos-Character->Victim->XPos) <= 35 && fabs(Character->ZPos-Character->Victim->ZPos) <= 35)
		  {
			  Character->FreePath();

			  D3DXVECTOR2 CharPos = m_StageGame->GetTerrain()->GetMapPosition(Character->XPos,Character->ZPos);
			  D3DXVECTOR2 PCPos   = m_StageGame->GetTerrain()->GetMapPosition(Character->Victim->XPos,Character->Victim->ZPos);

			  int x = int(CharPos.x-PCPos.x);
			  int z = int(CharPos.y-PCPos.y);
			  
			  x = x/abs((x==0?1:x));
			  z = z/abs((z==0?1:z));

			  if (x==0 && z==-1) Character->Direction = 0;
			  else if (x==0 && z==1) Character->Direction = D3DX_PI;
			  else if (x==-1 && z==0) Character->Direction = D3DX_PI/2;
			  else if (x==1 && z==0) Character->Direction = 3*D3DX_PI/2;
			  else if (x==1 && z==1) Character->Direction = 5*D3DX_PI/4;
			  else if (x==1 && z==-1) Character->Direction = 7*D3DX_PI/4;
			  else if (x==-1 && z==-1) Character->Direction = D3DX_PI/4;
			  else if (x==-1 && z==1) Character->Direction = 3*D3DX_PI/4;
		
			  // Perform attack action
			  if (Character->Action != CHAR_ATTACK)  {
				SetAction(Character, CHAR_ATTACK);
			  }
		  }
	  }
    /*
  float XDiff,ZDiff;
  float Speed;
  int range = 150;
  int random = rand()%50 + 200;

  // Error checking
  if(Character == NULL)
	return FALSE;

  if (GetCharacter(ID_PC)->Action == CHAR_DIE)
	return FALSE;

  // Calculate movement speed
  Speed = 2;
*/
  /*// Move character based on their type
  switch(Character->AI) {
    case CHAR_STAND:
		Character->Action = CHAR_IDLE;
      break;
      
    case CHAR_WANDER:
      // Calculate new distance and direction if needed
      Character->Distance -= 2;

      if(Character->Distance <= 0.0f) {

		  srand(timeGetTime());
		  float TargetX = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + Character->MinX + 50;
		  srand(timeGetTime()+rand());
		  float TargetZ = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + Character->MinZ + 50;

		  while (TargetX > Character->MaxX || TargetX < Character->MinX)
		  {
			  srand(timeGetTime());
			  TargetX = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + Character->MinX + 50;
		  }

		  while (TargetZ > Character->MaxZ || TargetZ < Character->MinZ) 
		  {
			  srand(timeGetTime()+rand());
			  TargetZ = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + Character->MinZ + 50;
		  }

		  if (m_StageGame->GetTerrain()->CanMove(TargetX,TargetZ))
		  {
			  D3DXVECTOR2 CharMap = m_StageGame->GetTerrain()->GetMapPosition(Character->XPos,Character->ZPos);
			  D3DXVECTOR2 DestMap = m_StageGame->GetTerrain()->GetMapPosition(TargetX, TargetZ);

			  RoutePath(Character,CharMap,DestMap);
			  Character->Distance = (float)(fabs(TargetX-Character->XPos)+fabs(TargetZ-Character->ZPos)) + random;
		  }
		  
      }

      // Process walk or stand still
      if(Character->Distance > random) {
        if (Character->NumPoints != 0)
		{
			XDiff = Character->Route[Character->CurrentPoint].XPos - Character->XPos;
			ZDiff = Character->Route[Character->CurrentPoint].ZPos - Character->ZPos ;

		// Calculate Direction 
			if (fabs(Character->Direction - Character->Route[Character->CurrentPoint].Direction) < 0.1f || 
				fabs(Character->Direction - (Character->Route[Character->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
				fabs((Character->Direction+(2*D3DX_PI)) - Character->Route[Character->CurrentPoint].Direction) < 0.1f)
			{
				Character->Direction = Character->Route[Character->CurrentPoint].Direction;
				if (Character->Direction >= 2*D3DX_PI)
					Character->Direction -= (2*D3DX_PI);
			}
			else 
			{
				if (Character->Direction >= 2*D3DX_PI)
					Character->Direction -= (2*D3DX_PI);

				float dir = Character->Route[Character->CurrentPoint].Direction - Character->Direction;
				if (dir < 0)
					dir += 2*D3DX_PI;

				if (D3DX_PI > dir)
					Character->Direction += D3DX_PI/12;
				else Character->Direction -= D3DX_PI/12;	

				if (Character->Direction < 0) 
					Character->Direction += D3DX_PI*2;
			}
		// Increase to walk
			if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
			{
				*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
				*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

				Character->Route[Character->CurrentPoint].XPos = -1;
				Character->Route[Character->CurrentPoint].ZPos = -1;
				Character->CurrentPoint++;
				Character->NumPoints--;

			}else 
			{
				*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
				*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				Character->Action = CHAR_MOVE;
			}

		}else Character->Action = CHAR_IDLE;
      } else {

        // Stand still for one second
		Character->FreePath();
        Character->Action = CHAR_IDLE;
      }
// Check Frustum of Monster
	  XDiff = GetCharacter(ID_PC)->XPos - Character->XPos;
	  ZDiff = GetCharacter(ID_PC)->ZPos - Character->ZPos;
	  if (fabs(XDiff) < 100 && fabs(ZDiff) < 100 && (GetCharacter(ID_PC)->Action != CHAR_DIE))
	  {	  	

			float angle = atanf((float)fabs(ZDiff)/(float)fabs(XDiff));

			float x = D3DXToDegree(angle);

			if(XDiff >= 0 && ZDiff >=0)
				angle = D3DX_PI/2 - angle;
			else if(XDiff >= 0 && ZDiff <=0)
				angle += D3DX_PI/2;
			else if(XDiff <= 0 && ZDiff <=0)
				angle = 3*D3DX_PI/2 - angle;
			else if(XDiff <= 0 && ZDiff >=0)
				angle += 3*D3DX_PI/2;

			float ang1 = ((angle+(D3DX_PI/4)) > 2*D3DX_PI?(angle+(D3DX_PI/4))-(2*D3DX_PI):angle+(D3DX_PI/4));
			float ang2 = ((angle-(D3DX_PI/4)) < 0        ?(angle-(D3DX_PI/4))+(2*D3DX_PI):angle-(D3DX_PI/4));

			if ( ang1 > Character->Direction && Character->Direction > ang2)
			{
				Character->FreePath();
				Character->AI = CHAR_FOLLOW;
				Character->Direction = angle;
				Character->Delay = 5;
				Character->Victim = GetCharacter(ID_PC);
				GetCharacter(ID_PC)->Attacker = Character;
				Character->Distance = (float)(fabs(GetCharacter(ID_PC)->XPos-Character->XPos)+fabs(GetCharacter(ID_PC)->ZPos-Character->ZPos));
			}
	  }
      break;

    case CHAR_FOLLOW:
      if (Character->Distance > 200)
	  {
		  Character->Victim = NULL;
		  GetCharacter(ID_PC)->Attacker = NULL;
		  Character->Action = CHAR_IDLE;
		  Character->AI = CHAR_WANDER;
		  Character->Distance = 0;
		  Character->FreePath();	  
	  }
	  else
	  {
		  if (Character->NumPoints == 0)
		  {
			  if (fabs(Character->XPos-GetCharacter(ID_PC)->XPos) > 30 || fabs(Character->ZPos-GetCharacter(ID_PC)->ZPos) >= 30)
			  {
				  Character->Delay--;
				  Character->Action = CHAR_IDLE;
				  if (Character->Delay < 0)
				  {
					Character->Delay = 5;
					D3DXVECTOR2 CharPos = m_StageGame->GetTerrain()->GetMapPosition(Character->XPos,Character->ZPos);
					D3DXVECTOR2 DestPos = m_StageGame->GetTerrain()->GetMapPosition(GetCharacter(ID_PC)->XPos,GetCharacter(ID_PC)->ZPos);

					RoutePath(Character,CharPos,DestPos);

					Character->XDestPos = Character->Route[Character->NumPoints-1].XPos;
					Character->ZDestPos = Character->Route[Character->NumPoints-1].ZPos;
				  }
			  }
		  }else
		  {
			    XDiff = Character->Route[Character->CurrentPoint].XPos - Character->XPos;
				ZDiff = Character->Route[Character->CurrentPoint].ZPos - Character->ZPos ;

				if (fabs(Character->Direction - Character->Route[Character->CurrentPoint].Direction) < 0.1f || 
					fabs(Character->Direction - (Character->Route[Character->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((Character->Direction+(2*D3DX_PI)) - Character->Route[Character->CurrentPoint].Direction) < 0.1f)
				{
					Character->Direction = Character->Route[Character->CurrentPoint].Direction;
					if (Character->Direction >= 2*D3DX_PI)
						Character->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (Character->Direction >= 2*D3DX_PI)
						Character->Direction -= (2*D3DX_PI);

					float dir = Character->Route[Character->CurrentPoint].Direction - Character->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						Character->Direction += D3DX_PI/20;
					else Character->Direction -= D3DX_PI/20;	

					if (Character->Direction < 0) 
						Character->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					Character->Route[Character->CurrentPoint].XPos = -1;
					Character->Route[Character->CurrentPoint].ZPos = -1;
					Character->CurrentPoint++;
					Character->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
					Character->Action = CHAR_MOVE;
				}
		  }
		  Character->Distance = (float)(fabs(GetCharacter(ID_PC)->XPos-Character->XPos)+fabs(GetCharacter(ID_PC)->ZPos-Character->ZPos)); 

	  }
      break;
  }

  if (GetCharacter(ID_PC)->Action != CHAR_DIE)
	  if ((Character->Type != CHAR_NPC && Character->AI == CHAR_FOLLOW))// || (Character->Attacker != NULL))
	  {
		  if (fabs(Character->XPos-GetCharacter(ID_PC)->XPos) <= 35 && fabs(Character->ZPos-GetCharacter(ID_PC)->ZPos) <= 35)
		  {
			  Character->FreePath();

			  D3DXVECTOR2 CharPos = m_StageGame->GetTerrain()->GetMapPosition(Character->XPos,Character->ZPos);
			  D3DXVECTOR2 PCPos   = m_StageGame->GetTerrain()->GetMapPosition(GetCharacter(ID_PC)->XPos,GetCharacter(ID_PC)->ZPos);

			  int x = int(CharPos.x-PCPos.x);
			  int z = int(CharPos.y-PCPos.y);
			  
			  x = x/abs((x==0?1:x));
			  z = z/abs((z==0?1:z));

			  if (x==0 && z==-1) Character->Direction = 0;
			  else if (x==0 && z==1) Character->Direction = D3DX_PI;
			  else if (x==-1 && z==0) Character->Direction = D3DX_PI/2;
			  else if (x==1 && z==0) Character->Direction = 3*D3DX_PI/2;
			  else if (x==1 && z==1) Character->Direction = 5*D3DX_PI/4;
			  else if (x==1 && z==-1) Character->Direction = 7*D3DX_PI/4;
			  else if (x==-1 && z==-1) Character->Direction = D3DX_PI/4;
			  else if (x==-1 && z==1) Character->Direction = 3*D3DX_PI/4;
		
			  // Perform attack action
			  if (Character->Action != CHAR_ATTACK)  {
				SetAction(Character, CHAR_ATTACK);
			  }
		  }
	  }
*/
  return TRUE;
}

BOOL CCharacterController::RoutePath(sCharacter *Character,D3DXVECTOR2 CharPos,D3DXVECTOR2 DestPos)
{

	sCharacter* CharPtr,*Char;
	bool Onchar = false;

	if ((CharPtr = Character) == NULL)
		return FALSE;

	if ((Char = m_CharacterParent)!=NULL)
		while(Char != NULL)
		{
			if (Char->Type != CHAR_PC && Char->Enabled)
				if ((int)(Char->XPos/20) == DestPos.x && (int)(Char->ZPos/20) == DestPos.y)
				{
					Onchar = true;
					break;
				}
			Char = Char->Next;
		}
		//clear Path
	CharPtr->FreePath();

	while (CharPos != DestPos)
	{
		int DX = (int)(DestPos.x - CharPos.x);
		int DY = (int)(DestPos.y - CharPos.y);

		if (DX == 0)
		{
			CharPtr->Route[CharPtr->CurrentPoint].XPos 
				= CharPos.x * 20 + 10;
			CharPtr->Route[CharPtr->CurrentPoint].ZPos
				= (CharPos.y +(float)(DY/(fabs(DY)))) * 20 + 10;
			CharPtr->Route[CharPtr->CurrentPoint].Direction
				= ((DY/fabs(DY) > 0)?0:D3DX_PI);

		}else if (DY ==0)
		{
			CharPtr->Route[CharPtr->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			CharPtr->Route[CharPtr->CurrentPoint].ZPos
				= CharPos.y * 20 + 10;
			CharPtr->Route[CharPtr->CurrentPoint].Direction
				= ((DX/fabs(DX) > 0)?D3DX_PI/2:(3*D3DX_PI/2)); 
		}
		else //if (fabs(DX) <> fabs(DY))
		{
			CharPtr->Route[CharPtr->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			CharPtr->Route[CharPtr->CurrentPoint].ZPos
				= (CharPos.y	+(float)(DY/(fabs(DY)))) * 20 + 10;
			if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) > 0)
				CharPtr->Route[CharPtr->CurrentPoint].Direction = D3DX_PI/4; 
			else if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) < 0)
				CharPtr->Route[CharPtr->CurrentPoint].Direction = 3*D3DX_PI/4; 
			else if (DX/(fabs(DX)) < 0 && DY/(fabs(DY)) < 0)
				CharPtr->Route[CharPtr->CurrentPoint].Direction = 5*D3DX_PI/4; 
			else 
				CharPtr->Route[CharPtr->CurrentPoint].Direction = 7*D3DX_PI/4; 

		}
		CharPos.x = (CharPtr->Route[CharPtr->CurrentPoint].XPos -10) / 20;
		CharPos.y = (CharPtr->Route[CharPtr->CurrentPoint].ZPos -10) / 20;
		CharPtr->CurrentPoint++;
	}
	if (Onchar  && CharPtr->CurrentPoint > 0) 
	{
		CharPtr->CurrentPoint--;
		CharPtr->Route[CharPtr->CurrentPoint].XPos=-1;
		CharPtr->Route[CharPtr->CurrentPoint].ZPos=-1;
		CharPtr->Route[CharPtr->CurrentPoint].Direction = 0;
	}
	CharPtr->NumPoints = CharPtr->CurrentPoint;
	CharPtr->CurrentPoint = 0;

	return TRUE;
}

BOOL CCharacterController::CheckMove(sCharacter *CharPtr,   \
               float *XMove, float *YMove, float *ZMove)
{
  sCharacter *Character;

  BYTE** MapArray = GetMapArr();

  // Error checking
  if(CharPtr == NULL)
    return FALSE;  // Don't allow movement

   // Check movement against other characters
  if((Character = m_CharacterParent) != NULL) {
    while(Character != NULL) {
		if ((CharPtr->ID != Character->ID))
		{
			if (CharPtr->AI != CHAR_STAND)
			{
				float x = CharPtr->Route[CharPtr->CurrentPoint].XPos;
				float z = CharPtr->Route[CharPtr->CurrentPoint].ZPos;
				int xDest = int(Character->XPos)/20;
				int zDest = int(Character->ZPos)/20;
				if (x > 0)
					if (!m_StageGame->GetTerrain()->CanMove(x,z) || ((x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled))
					{
						*XMove = 0;
						*ZMove = 0;
						if (CharPtr->NumPoints == 1 && (x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled)
						{
							CharPtr->FreePath();
							break;
						}
						else 
						{
							CharPtr->FreePath();
							if (CharPtr->Type == CHAR_PC || CharPtr->Type == CHAR_USER)
								ValidateMove(CharPtr, XMove, YMove, ZMove);
						}
					}
			}
		}
		Character = Character->Next;
    }

  }

  return TRUE;
}

BOOL CCharacterController::ValidateMove(sCharacter *Character,              \
                    float *XMove, float *YMove, float *ZMove)
{
	sCharacter *CharPtr,*Char;
	D3DXVECTOR2 CharMapPos;
	BYTE** MapArray = GetMapArr();

	if ((CharPtr = Character) == NULL)
		return FALSE;
	
	CharMapPos		= m_StageGame->GetTerrain()->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);

	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != CharPtr->ID && Char->Enabled)
				m_StageGame->GetTerrain()->SetCanMove(Char->XPos,Char->ZPos,false);
			Char = Char->Next;
		}
	}
	
		// Check Out of array 
	if (fabs(CharMapPos.x - (int)(CharPtr->XDestPos)/20) >= MAX_SHORTCAL/2-1 ||	\
		fabs(CharMapPos.y - (int)(CharPtr->ZDestPos)/20) >= MAX_SHORTCAL/2-1)
		return FALSE;

	int x = (int)(CharPtr->XDestPos)/20;
	int y = (int)(CharPtr->ZDestPos)/20;

	MakePath(CharPtr,(int)CharMapPos.x,(int)CharMapPos.y);
			
	CharPtr->Route[0].XPos = (float)x*20+10;
	CharPtr->Route[0].ZPos = (float)y*20+10;
	CharPtr->CurrentPoint = 1;

	while (CharMapPos.x != x || CharMapPos.y != y)
	{
		if (x <=0 && y <= 0) 
		{		
			CharPtr->FreePath();
			break;
		}
		int DX = (int)(CharMapPos.x - x);
		int DY = (int)(CharMapPos.y - y);
		if (DX == 0 && DY == 0) break;
		int dx = (DX == 0?0:DX/abs(DX));
		int dy = (DY == 0?0:DY/abs(DY));
		
		if (abs(DX) > abs(DY))
		{
			if ( CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+dx][y] )
			{
				CharPtr->Route[CharPtr->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				CharPtr->Route[CharPtr->CurrentPoint].ZPos
					= (float)y * 20 + 10;
				CharPtr->Route[CharPtr->CurrentPoint-1].Direction
					= ((dx < 0)?D3DX_PI/2:(3*D3DX_PI/2));
			}else 
			{
				if (y == m_StageGame->GetTerrain()->GetNumMap()-1)
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+dx][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						if (dx > 0)
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
						else 
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 0;
					}
				}
				else if (y == 0)
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+dx][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						if (dx > 0)
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}else 
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 0;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 3*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}
			}

		}else if (abs(DX) < abs(DY))
		{
			if ( CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y+dy] )
			{
				CharPtr->Route[CharPtr->CurrentPoint].XPos 
					= (float)x * 20 + 10;
				CharPtr->Route[CharPtr->CurrentPoint].ZPos
					= (y+(float)dy) * 20 + 10;
				CharPtr->Route[CharPtr->CurrentPoint-1].Direction
					= (dy < 0)?0:D3DX_PI;
			}else 
			{
				if (x == m_StageGame->GetTerrain()->GetNumMap()-1)
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y+dy])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
						else
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= D3DX_PI/4;							
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}
				}
				else if (x == 0)
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y+dy])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else 
							CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;							
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}else 
				{
					if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y+1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y-1])
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 7*D3DX_PI/4;
					}else if ( CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y-1] )
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= 0;
					}else if ( CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y+1] )
					{
						CharPtr->Route[CharPtr->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}
			}
		}else if (abs(DX) == abs(DY))
		{
			
			if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+dx][y+dy])
			{
				CharPtr->Route[CharPtr->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				CharPtr->Route[CharPtr->CurrentPoint].ZPos
					= (y +(float)dy) * 20 + 10;
				
				if (dx > 0 && dy > 0)
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
				if (dx > 0 && dy < 0)
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
				if (dx < 0 && dy > 0)
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
				if (dx < 0 && dy < 0)
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction = D3DX_PI/4;
			}
			else 
			{
				if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+1][y])
				{
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (float)(x+1) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (float)y * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction
						= 3*D3DX_PI/2;
				
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y+1])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (float)(y+1) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction
						= D3DX_PI;
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-1][y])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (float)(x-1) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (float)(y) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction
						= D3DX_PI/2;
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x][y-1])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (float)(y-1) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint-1].Direction
						= 0;
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x+dx][y-dy])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (x +(float)dx) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 3*D3DX_PI/4;
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-dx][y+dy])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (y +(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 7*D3DX_PI/4;
				}else if (CharPtr->AllPath[x][y]-1 == CharPtr->AllPath[x-dx][y-dy])
				{						
					CharPtr->Route[CharPtr->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						CharPtr->Route[CharPtr->CurrentPoint-1].Direction = 5*D3DX_PI/4;
				}
			}
		}
		x = (int)(CharPtr->Route[CharPtr->CurrentPoint].XPos -10) / 20;
		y = (int)(CharPtr->Route[CharPtr->CurrentPoint].ZPos -10) / 20;
		CharPtr->CurrentPoint++;
	}
	SortArr(CharPtr);
	CharPtr->NumPoints = CharPtr->CurrentPoint-1;
	CharPtr->CurrentPoint = 0;
	////////////////
	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != CharPtr->ID && CharPtr->Enabled)
				m_StageGame->GetTerrain()->SetCanMove(Char->XPos,Char->ZPos,true);
			Char = Char->Next;
		}
	}
	return TRUE;
}

BOOL CCharacterController::SortArr(sCharacter* CharPtr)
{
	sRoutePoint* arr = CharPtr->Route;
	sRoutePoint* tmp = new sRoutePoint[MAX_SHORTPATH];
	int i,j,k;

	for (j=0,i = MAX_SHORTPATH-1;i>=0;i--,j++)
	{
		tmp[j] = arr[i];
		arr[i].Direction = 0;
		arr[i].XPos	= -1;
		arr[i].YPos = -1;
		arr[i].ZPos = -1;
	}

	
	i=0;
	while (tmp[i].XPos == -1) 
		i++;
	i++;
	for (j=i,k=0;j<MAX_SHORTPATH;j++,k++)
	{
		arr[k] = tmp[j];
	}
	
	for (j = k;j<MAX_SHORTPATH;j++)
	{
		arr[j].Direction = 0;
		arr[j].XPos = -1;
		arr[j].YPos = -1;
		arr[j].ZPos = -1;
	}

	delete[] tmp;

	return TRUE;
}

void CCharacterController::ShortestPath(sCharacter* CharPtr,int stx,int sty,int tx, int ty, int step)
{
	if (stx == int(CharPtr->XDestPos/20) && sty == (int)(CharPtr->ZDestPos/20))
		return;

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && CharPtr->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0') 
	{
		if (CharPtr->AllPath[stx+1+tx][sty+ty]==0 || CharPtr->AllPath[stx+1+tx][sty+ty]>step)
		{
			CharPtr->AllPath[stx+1+tx][sty+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx+1,ty,step+1);
		}
	}
	
	if (ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx+tx][sty+1+ty]==0 || CharPtr->AllPath[stx+tx][sty+1+ty]>step)
		{
			CharPtr->AllPath[stx+tx][sty+1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && CharPtr->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx-1+tx][sty+ty]==0 || CharPtr->AllPath[stx-1+tx][sty+ty]>step)
		{
			CharPtr->AllPath[stx-1+tx][sty+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx-1,ty,step+1);
		}

	}

	if (ty-1+(MAX_SHORTCAL/2) >=0 && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx+tx][sty-1+ty]==0 || CharPtr->AllPath[stx+tx][sty-1+ty]>step)
		{
			CharPtr->AllPath[stx+tx][sty-1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx,ty-1,step+1);
		}
	}
	
	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& CharPtr->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && CharPtr->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx+1+tx][sty+1+ty]==0 || CharPtr->AllPath[stx+1+tx][sty+1+ty]>step)
		{
			CharPtr->AllPath[stx+1+tx][sty+1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx+1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& CharPtr->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && CharPtr->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx-1+tx][sty+1+ty]==0 || CharPtr->AllPath[stx-1+tx][sty+1+ty]>step)
		{
			CharPtr->AllPath[stx-1+tx][sty+1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx-1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty-1+(MAX_SHORTCAL/2) >= 0 && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& CharPtr->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && CharPtr->TempArr[tx-1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx-1+tx][sty-1+ty]==0 || CharPtr->AllPath[stx-1+tx][sty-1+ty]>step)
		{
			CharPtr->AllPath[stx-1+tx][sty-1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx-1,ty-1,step+1);
		}
	}

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty-1+(MAX_SHORTCAL/2) >= 0 && CharPtr->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& CharPtr->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && CharPtr->TempArr[tx+1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (CharPtr->AllPath[stx+1+tx][sty-1+ty]==0 || CharPtr->AllPath[stx+1+tx][sty-1+ty]>step)
		{
			CharPtr->AllPath[stx+1+tx][sty-1+ty] = step;
			ShortestPath(CharPtr,stx,sty,tx+1,ty-1,step+1);
		}
	}
}

BOOL CCharacterController::MakePath(sCharacter* CharPtr,int Stx,int Sty)
{
	int x,y;

	//FILE* fid = fopen("out.txt","w");
	//FILE* fid2= fopen("out2.txt","w");

	for (int i=0;i<MAX_SHORTCAL;i++)
		for (int j=0;j<MAX_SHORTCAL;j++)	
		{
			if ((Stx-(MAX_SHORTCAL/2)+i)<0 || (Sty-(MAX_SHORTCAL/2)+j)<0)
			{
				CharPtr->TempArr[i][j] = '1';
			}
			else 
			{	
				x = (int)Stx-(MAX_SHORTCAL/2)+i;
				y = (int)Sty-(MAX_SHORTCAL/2)+j;
				CharPtr->TempArr[i][j] = (m_StageGame->GetTerrain()->CanMove((float)x*20, (float)y*20)?'0':'1');
			}
		}

	/*for (i=MAX_SHORTCAL-1;i>=0;i--)
	{
		for(int j=0;j<MAX_SHORTCAL;j++)
		{
			fprintf(fid,"%c",CharPtr->TempArr[j][i]);
		}
		fprintf(fid,"\n\r");
	}
	fclose(fid);
*/
	ShortestPath(CharPtr,Stx,Sty,0,0,1);
	CharPtr->AllPath[Stx][Sty] = 0;

	/*int POS = CharPtr->MapSize;
	for(i=POS-1;i>=0;i--)
	{
		for(int j=0;j<POS;j++)
		{
			if (CharPtr->AllPath[j][i] >= 10)
				fprintf(fid2,"%i",CharPtr->AllPath[j][i]);
			else 
				fprintf(fid2,"%i ",CharPtr->AllPath[j][i]);
		}	
		fprintf(fid2,"\n\r");
	}
	fclose(fid2);
	*/return TRUE;
}

BOOL CCharacterController::ProcessUpdate(                     \
                      sCharacter *Character,
                      float XMove, float YMove, float ZMove)
{
	// Move character
	Character->XPos += XMove;
	Character->YPos = YMove;
	Character->ZPos += ZMove;

	// Move object and point in direction
	Character->Object.Move(Character->XPos,                     \
						 Character->YPos,                     \
						 Character->ZPos);                    \
	Character->Object.Rotate(0.0f, Character->Direction, 0.0f);

	// Set new animation
	if(Character->LastAnim != Character->Action) {
		Character->LastAnim = Character->Action;

		if(m_NumAnimations && m_Animations != NULL) {
		  Character->LastAnimTime = timeGetTime() / 1000;
		  Character->Object.SetAnimation(                         \
					 &m_Meshes[Character->Def.MeshNum].Animation, \
					 m_Animations[Character->Action].Name,        \
					 Character->LastAnimTime);
		}
	}

	return TRUE;
}

BOOL CCharacterController::Attack(sCharacter *Attacker,       \
                                  sCharacter *Victim)
{
	// Error checking
	if(Attacker == NULL || Victim == NULL)
	return FALSE;

	// Don't attack dead or hurt people
	if(Victim->Action == CHAR_DIE)
		return FALSE;

	// Set attacker and victim
	Victim->Attacker = Attacker;
	Attacker->Victim = Victim;

	// Return if hit missed
	/*if((rand() % 1000) > GetToHit(Attacker)) {
		SetMessage(Victim, "Missed!", 500);
		return FALSE;
	}

	// Return if hit dodged
	if((rand() % 1000) <= GetAgility(Victim)) {
		SetMessage(Victim, "Dodged!", 500);
		return FALSE;
	}

	// If character is asleep, randomly wake them up (50% chance)
	if(Victim->Ailments & AILMENT_SLEEP) {
		if((rand() % 100) < 50)
		  Victim->Ailments &= ~AILMENT_SLEEP;
	}

	// Attack landed, apply damage
	Damage(Victim, TRUE, GetAttack(Attacker), -1, -1);
*/
	return TRUE;
}

BOOL CCharacterController::Damage(sCharacter *Victim,         \
                                  BOOL PhysicalAttack,        \
                                  long Amount,                \
                                  long DmgClass,              \
                                  long CureClass)
{
	char Text[128];
	float Resist;
	float Range;
	long  DmgAmount;

	// Error checking
	if(Victim == NULL)
	return FALSE;

	// Can't attack if already dead or being hurt (or not enabled)
	if(Victim->Enabled == FALSE ||                              \
	 Victim->Action==CHAR_DIE)
	return FALSE;

	// Adjust for defense if physical attack
	if(PhysicalAttack == TRUE) {

		// Random value for less/more damage (-+20%)
		Range     = (float)((rand() % 20) + 90) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);

		// Subtract for defense of victim (allow -20% difference)
		Range     = (float)((rand() % 20) + 80) / 100.0f;
		DmgAmount -= (long)((float)GetDefense(Victim) * Range);
	} else {
		// Adjust for magical attack
		Resist = 1.0f - ((float)GetResistance(Victim) / 100.0f);
		DmgAmount = (long)((float)Amount * Resist);
	}

	// Bounds check value
	if(DmgAmount < 0)
	DmgAmount = 1;

	// Check for double damage
	if(Victim->Def.Class == DmgClass)
	DmgAmount *= 2;

	// Check for cure damage
	if(Victim->Def.Class == CureClass)
	DmgAmount = -(labs(DmgAmount)/2);

	// If no physical damage is dealt then randomly deal 
	// 10-20% of damage from the original amount.
	if(!DmgAmount && PhysicalAttack == TRUE) {
		Range     = (float)((rand() % 10) + 10) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);
	}

	// Subtract damage amount
	Victim->HealthPoints -= DmgAmount;

	// Set hurt status and display message
	if(DmgAmount >= 0) {
		sprintf(Text, "-%lu HP", DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(255,64,0,255));

		// Only set hurt if any damage (and idle or moving)
		if(DmgAmount) {
		  if(Victim->Action==CHAR_MOVE || Victim->Action==CHAR_IDLE)
			SetAction(Victim, CHAR_HURT);
		}
	} 

	// Display cure amount
	if(DmgAmount < 0) {
		sprintf(Text, "+%lu HP", -DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(0,64,255,255));
	}

	return TRUE;
}

BOOL CCharacterController::Death(sCharacter *Attacker,        \
                                 sCharacter *Victim)
{
	char Text[128];

	ZeroMemory(Text, sizeof(char));

	// If a PC or NPC dies, then don't remove from list
	if(Victim->Type == CHAR_PC) {
	// Mark character as disabled so no updates
		Victim->Enabled = FALSE;

		PCDeath(Victim);

	} else {
	// Give attacker the victim's experience
	if(Attacker != NULL) {
	  if(Experience(Attacker, Victim->Def.Experience) == TRUE) {
		sprintf(Text, "+%lu exp.", Victim->Def.Experience);
		SetMessage(Attacker, Text, 500);
	  }
	}

	// Drop character's money
	if((m_StageGame->FindItemDef(0) != NULL) && ((rand() % 100) <= Victim->Def.DropChance))
	{
		char ItemName[30];
		strcpy(ItemName,"");
		sItem* item = Victim->m_Inventory.FindItem(0);
		if(item != NULL)
		{
			sItem* itemDrop = GetCharacter(CHAR_PC)->m_Inventory.FindItemDef(item->ItemDef);
			if(itemDrop != NULL)
			{
				itemDrop->Count++;
				if(itemDrop->ItemDef == 0)
					sprintf(ItemName,"Get 1 Energy");
				if(itemDrop->ItemDef == 1)
					sprintf(ItemName,"Get 1 Ether");
				if(itemDrop->ItemDef == 2 && (rand() % 100) > 90)
					sprintf(ItemName,"Get 1 Elixir");

				sprintf(Text, "%s\n %s",Text,ItemName);
				SetMessage(Attacker, Text, 2000);
			}
		}

	}	

	// Decrease mesh count and release if no more
	m_Meshes[Victim->Def.MeshNum].Count--;
	if(!m_Meshes[Victim->Def.MeshNum].Count) {
	  m_Meshes[Victim->Def.MeshNum].Mesh.Cleanup();
	  m_Meshes[Victim->Def.MeshNum].Animation.Cleanup();
	}
	}

	return TRUE;
}

BOOL CCharacterController::Spell(sCharacter *Caster,          \
                                 sSpellTracker *SpellTracker, \
                                 sSpell *Spells)
{
  float SpellRadius;
  sSpell *SpellPtr;
  sCharacter *CharPtr, *ClosestChar;
  float Closest;
  BOOL Allow;

  // Error checking
  if(Caster == NULL || SpellTracker == NULL || Spells == NULL)
    return TRUE;

  // Get pointer to spell
  SpellPtr = &Spells[SpellTracker->SpellNum];

  // Reduce magic
  Caster->ManaPoints -= SpellPtr->Cost;
  if(Caster->ManaPoints < 0)
    Caster->ManaPoints = 0;

  // Can't cast if silenced
  if(Caster->Ailments & AILMENT_SILENCED) {
    SetMessage(Caster, "Silenced!", 500);
    return FALSE;
  }

  // Get radius of spell
  SpellRadius = SpellPtr->Range * SpellPtr->Range;

  // Handle self-targeting spells instantly
  if(SpellPtr->Target == TARGET_SELF) {
    SpellEffect(Caster, Caster, SpellPtr);
    return TRUE;
  }

  // Reset closest character pointer
  ClosestChar = NULL;
  Closest = 0.0f;

  // Scan through all characters and look for hits
  if((CharPtr = m_CharacterParent) == NULL)
    return FALSE;
  while(CharPtr != NULL) {

    // Only bother with characters of allowed types
    // as well as not targeting self. Also, allow 
    // a RAISE_DEAD PC spell to affect any character.
    Allow = FALSE;
    if(CharPtr!=Caster /*&& SpellTracker->Type==CharPtr->Type*/ && CharPtr->Enabled)
      Allow = TRUE;
    if(CharPtr->Type==CHAR_PC && SpellPtr->Effect==RAISE_DEAD)
      Allow = TRUE;

    // Find target(s) if allowed
    if(Allow == TRUE) {

       // Check if character in range
      if (fabs(CharPtr->XPos - SpellTracker->XPos) <= 20 && \
		  fabs(CharPtr->ZPos - SpellTracker->ZPos) <= 20)
	  {
			 // Determine what to do if in range
			if(SpellPtr->Target == TARGET_SINGLE) {
				ClosestChar = CharPtr;
				break;
			} else {
				// Spell hit target if area target
				SpellEffect(Caster, CharPtr, SpellPtr);
			}
	  }
    }

    // Go to next character
    CharPtr = CharPtr->Next;
  }

  // Process spell on closest character if needed
  if(SpellPtr->Target==TARGET_SINGLE && ClosestChar!=NULL)
    SpellEffect(Caster, ClosestChar, SpellPtr);

  return TRUE;
}

BOOL CCharacterController::SpellEffect(sCharacter *Caster,    \
                                       sCharacter *Target,    \
                                       sSpell *Spell)
{
  BOOL CanHit;
  long Chance;
  char Text[64];

  // Error checking
  if(Target == NULL || Spell == NULL || Target->Type == CHAR_NPC)
    return FALSE;

  // Calculate chance of hitting
  if(Caster != NULL) {
    // A spell always lands if target=caster
    if(Caster == Target)
      Chance = 100;
    else
      Chance = (long)(((float)GetMental(Caster) / 100.0f +    \
                           1.0f) * (float)Spell->Chance);
  } else {
    Chance = Spell->Chance;
  }

   // See if spell failed
  if(Chance != 100 && (rand() % 100) >= Chance) {
    SetMessage(Target, "Failed!", 500);
    return FALSE;
  }

  // Flag character to allow effect
  CanHit = TRUE;
  if(Target->Action==CHAR_DIE)
    CanHit = FALSE;

  // Store attacker and victim
  if((Target->Attacker = Caster) != NULL)
    Caster->Victim = Target;
    
  // Process spell effect
  switch(Spell->Effect) {
    case ALTER_HEALTH:     // Alter health
      if(CanHit == FALSE)
        break;

      // Apply damage if value < 0
      if(Spell->Value[0] < 0.0f)
	  {
		  Damage(Target,FALSE,(Caster->Def.Resistance + (rand()%(long)-Spell->Value[0])),\
			  Spell->DmgClass, Spell->CureClass);
	  }

      // Cure damage if value > 0
      if(Spell->Value[0] > 0.0f) {
        Target->HealthPoints += (long)Spell->Value[0];
        if(Target->HealthPoints > Target->Def.HealthPoints)
          Target->HealthPoints = Target->Def.HealthPoints;
        
        // Display amount healed
        sprintf(Text, "+%lu HP", (long)Spell->Value[0]);
        SetMessage(Target,Text,500,D3DCOLOR_RGBA(0,64,255,255));
      }

      break;

    case ALTER_MANA:       // Alter mana
      if(CanHit == FALSE)
        break;

      // Alter mana value
      Target->ManaPoints += (long)Spell->Value[0];
      if(Target->ManaPoints < 0)
        Target->ManaPoints = 0;
      if(Target->ManaPoints > Target->Def.ManaPoints)
        Target->ManaPoints = Target->Def.ManaPoints;

      // Display remove mana message
      if(Spell->Value[0] < 0.0f) {
        sprintf(Text, "%ld MP", (long)Spell->Value[0]);
        SetMessage(Target,Text,500,D3DCOLOR_RGBA(0,128,64,255));
      }

      // Display add mana message
      if(Spell->Value[0] > 0.0f) {
        sprintf(Text, "+%lu MP", (long)Spell->Value[0]);
        SetMessage(Target,Text,500,D3DCOLOR_RGBA(0,255,0,255));
      }

      break;

    case CURE_AILMENT:      // Clear ailment flag
      if(CanHit == FALSE)
        break;

      // Apply ailment and display message
      Target->Ailments |= ~(long)Spell->Value[0];
      SetMessage(Target, "Cure", 500);

      break;

    case CAUSE_AILMENT:     // Set ailment flag
      if(CanHit == FALSE)
        break;

      // Cure ailment and display message
      Target->Ailments |= (long)Spell->Value[0];
      SetMessage(Target, "Ailment", 500);

      break;

    case RAISE_DEAD:       // Raise from dead
      if(Target->Action == CHAR_DIE) {
        Target->HealthPoints = 1;
        Target->ManaPoints   = 0;
        Target->Action       = CHAR_IDLE;
        Target->Locked       = FALSE;
        Target->ActionTimer  = 0;
        Target->Ailments      = 0;
        Target->Enabled      = TRUE;
      }
      break;

    case INSTANT_KILL:     // Kill character
      if(CanHit == FALSE)
        break;

      // Set die action
      SetAction(Target, CHAR_DIE);
      break;

    case DISPEL_MAGIC:     // Remove all ailments
      if(CanHit == FALSE)
        break;

      // Clear all ailments
      Target->Ailments = 0;
      break;

    case TELEPORT:         // Teleport PC/NPC/MONSTER
      if(CanHit == FALSE)
        break;

      // Teleport PCs from seperate function from rest
      if(Target->Type == CHAR_PC)
        PCTeleport(Caster, Spell);
      else {
        Target->XPos = Spell->Value[0];
        Target->YPos = Spell->Value[1];
        Target->ZPos = Spell->Value[2];
      }
      break;
  }

  return TRUE;
}

BOOL CCharacterController::Equip(sCharacter *Character,       \
                                 long ItemNum, long Type,     \
                                 BOOL Equip)
{
  char Path[MAX_PATH];

  // Error checking
  if(m_StageGame->FindItemDef(0) == NULL || Character == NULL)
    return FALSE;

  // Remove current item first and equip new one
  switch(Type) {
    case WEAPON:
      // Remove current item of type
      Character->Def.Weapon = -1;
      Character->WeaponObject.Cleanup();
      Character->WeaponMesh.Cleanup();
      
      // Equip new item of correct type
      if(Equip==TRUE && m_StageGame->FindItemDef(ItemNum)->eTypeItem == WEAPON) {
        Character->Def.Weapon = ItemNum;

        // Setup new weapon mesh and object
        if(m_StageGame->FindItemDef(ItemNum)->name) {

          // Build the mesh path
          sprintf(Path, "%s%s", m_MeshPath,                   \
                  m_StageGame->FindItemDef(Character->Def.Weapon)->name);

          // Load the new mesh
          Character->WeaponMesh.Load(m_Graphics, Path,        \
                                     m_TexturePath);

          // Create the weapon object
          Character->WeaponObject.Create(m_Graphics,          \
                                       &Character->WeaponMesh);

          // Orient and attach the weapon
          Character->WeaponObject.Move(0.0f, 0.0f, 0.0f);
          Character->WeaponObject.Rotate(0.0f, 0.0f, 0.0f);
          Character->WeaponObject.AttachToObject(             \
                             &Character->Object, "WeaponHand");
        }
      }
      break;

    case ARMOR:
      // Remove current item of type
      Character->Def.Armor = -1;

      // Equip new item of correct type
      if(Equip==TRUE && m_StageGame->FindItemDef(ItemNum)->eTypeItem == ARMOR)
        Character->Def.Armor = ItemNum;

      break;
/*
    case SHIELD:
      // Remove current item of type
      Character->Def.Shield = -1;

      // Equip new item of correct type
      if(Equip==TRUE && m_MIL[ItemNum].Category == SHIELD)
        Character->Def.Shield = ItemNum;

      break;

    case ACCESSORY:
      // Remove current item of type
      Character->Def.Accessory = -1;

      // Equip new item of correct type
      if(Equip==TRUE && m_MIL[ItemNum].Category == ACCESSORY)
        Character->Def.Accessory = ItemNum;

      break;
*/
    default: return FALSE;
  }

  return TRUE;
}

BOOL CCharacterController::LoadItemListToChar(int IDNum, char* filename)
{
	sCharacter* CharPtr = GetCharacter(IDNum);
	
	strcpy(CharPtr->ItemFilename,filename);
	CharPtr->m_Inventory.LoadInventory(CharPtr,m_StageGame);
	return TRUE;

}
