#include "CStageGame.h"

CStageGame::CStageGame()
{
	sEnvironment *m_EnvParent;
	m_Graphics = NULL;
	m_MapParent = NULL;
	m_MapCurrent = NULL;
	m_ItemDefParent	  = NULL;
	m_EnvDefParent = NULL;
	m_TransportParent = NULL;
	m_EnvParent = NULL;
	countMap = countModelItem = countModelEnv = 0;
}
CStageGame::~CStageGame()
{
	Shutdown();
}	

BOOL CStageGame::Shutdown()
{
	Cleanup();
	//if(m_TransportParent!= NULL) delete m_TransportParent;
		
//	m_VbWarp.Cleanup();
//	m_TextureWarp.Cleanup();

	m_Meshwarp.Cleanup();
	m_warpAnimation.Cleanup();
	m_warp.Cleanup();
	
	m_MapCurrent = NULL;
	m_MapParent  = NULL;
	m_ItemDefParent = NULL;
	m_EnvDefParent = NULL;
	//if(m_ItemDefParent!=NULL) delete m_ItemDefParent;
  	//if(m_EnvDefParent!=NULL) delete m_EnvDefParent;

	return true;
}
CStageGame::Cleanup()
{
	//if(m_EnvParent != NULL) delete m_EnvParent;
	m_EnvParent = NULL;

	countModelEnv = 0;

	m_Trigger.Cleanup();
	m_BarrierEnv.Cleanup();
	m_TransportParent = NULL;
	//if(m_TransportParent!= NULL) delete m_TransportParent;
	if(m_MapCurrent != NULL) {
		m_Terrain.Cleanup();
		m_MiniMap.Cleanup();
		m_Skybox.Cleanup();
	}
	
}
//----------------------------------
BOOL CStageGame::Init(CGraphic *Graphics,char *fileMap)
{
	m_Graphics = Graphics;

	FILE *fp;
	long id;
	sMap *map,*mapPtr = NULL;
	
	if((fp=fopen(fileMap,"rb"))==NULL)
		return false;

	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0)break;

		map = new sMap();

		++countMap;
		if(mapPtr == NULL)
			m_MapParent = map;
		else
			mapPtr->next = map;
		mapPtr = map;

		map->id = id;
		fscanf(fp,"%s",map->fileTerrain);
		fscanf(fp,"%s",map->fileTexture);
		fscanf(fp,"%s",map->fileMinimap);
		fscanf(fp,"%s",map->fileSkybox);
		fscanf(fp,"%s",map->fileEnv);
		fscanf(fp,"%s",map->fileTransport);
		fscanf(fp,"%s",map->fileInventory);
		fscanf(fp,"%s",map->fileEvent);
		fscanf(fp,"%ld",&map->iRow);
		fscanf(fp,"%ld",&map->iCol);
		fscanf(fp,"%ld",&map->iSizeTile);
	}
	fclose(fp);

	//Initial Stage is #0
	m_MapCurrent = FindMap(0);
	
	//***** Init transport vertex buffer and texture *****
	m_Meshwarp.Load(m_Graphics,".\\Model\\Environment\\warpport.x",".\\Texture\\Environment\\");
	m_warpAnimation.Load(".\\Model\\Environment\\warpport.x",&m_Meshwarp);
	m_warpAnimation.SetLoop(TRUE, "rot");
	m_warp.Create(m_Graphics, &m_Meshwarp);
	return true;
}
//------------------------------
sMap* CStageGame::FindMap(int stageId)
{
	if(stageId<0)return m_MapParent;

	sMap *mapPtr=m_MapParent;

	while(mapPtr!=NULL)
	{
		if(mapPtr->id==stageId)
			return mapPtr;
		mapPtr = mapPtr->next;
	}
	return m_MapParent;
}
//------------------------------
BOOL CStageGame::LoadStage(int stageId)
{
	//if(stageId!=0)

	m_MapCurrent = FindMap(stageId);

	m_Terrain.Create(m_Graphics, m_MapCurrent->fileTerrain,m_MapCurrent->fileTexture,  \
					stageId+1, m_MapCurrent->iCol);
	
	m_MiniMap.Create(m_Graphics, m_MapCurrent->fileMinimap, 150.0f,	\
					(float)m_Graphics->GetWidth()-160.0f,10.0f,		\
					m_MapCurrent->iRow * m_MapCurrent->iSizeTile);

	char SkyboxFilename[6][128],tmp[] = "sky_box.bmp";
	ZeroMemory(SkyboxFilename,sizeof(SkyboxFilename));
	m_Skybox.Create(m_Graphics);
	for(int i=0;i<6;i++)
	{
		sprintf(SkyboxFilename[i],"%s%s",m_MapCurrent->fileSkybox,tmp);
		m_Skybox.LoadTexture(i,SkyboxFilename[i]);
	}

	return true;
}

//---------------------------------

BOOL CStageGame::LoadEnvDef()
{
	sEnvDef *env,*envPtr=NULL;
	FILE *fp;
	long id;
	if((fp=fopen(".\\Script\\EnvDef.def","rb"))==NULL)
		return false;
	
	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0) break;

		env = new sEnvDef();
		if(envPtr ==NULL)
			m_EnvDefParent = env;
		else 
			envPtr->next = env;
		envPtr = env;

		env->id = id;
		fscanf(fp,"%s",env->name);
		fscanf(fp,"%s",env->fileMesh);
		fscanf(fp,"%s",env->fileTexture);
		fscanf(fp,"%s",env->ScriptFilename);
		fscanf(fp,"%s",env->ImageFilename);
	}
	fclose(fp);
	return TRUE;
}
//*****************************************

//--------------------------------
BOOL CStageGame::LoadAllModelEnv(char* filename)
{
	m_EnvParent->~sEnvironment();

	sEnvironment *env,*envPtr=NULL;
	FILE *fp;
	long visible;
	long id;
	if((fp=fopen(filename,"rb"))==NULL)
		return FALSE;
	
	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0) break;

		env = new sEnvironment();
		if(envPtr ==NULL)
			m_EnvParent = env;
		else 
			envPtr->next = env;
		envPtr = env;

		env->id = id;
		fscanf(fp,"%s",env->name);
		fscanf(fp,"%ld",&id);env->xPos = (float)id;
		fscanf(fp,"%ld",&id);env->yPos = (float)id;
		fscanf(fp,"%ld",&id);env->zPos = (float)id;
		fscanf(fp,"%ld",&id);env->xRot = (float)id;
		fscanf(fp,"%ld",&id);env->yRot = (float)id;
		fscanf(fp,"%ld",&id);env->zRot = (float)id;
		fscanf(fp,"%ld",&id);env->xScale = (float)id;
		fscanf(fp,"%ld",&id);env->yScale = (float)id;
		fscanf(fp,"%ld",&id);env->zScale = (float)id;
		fscanf(fp,"%ld",&id);visible = id;
		fscanf(fp,"%ld",&id );env->m_ModelEnv.id = id;

		if (visible) env->visible = TRUE;
		else env->visible = FALSE;
	}
	fclose(fp);
	return true;
}
//******************************************
//------------------------------
BOOL CStageGame::LoadItemDef()
{
	sItemDef *item,*itemPtr=NULL;
	FILE *fp;
	long id;
	long type;
	if((fp=fopen(".\\Script\\ItemDef.def","rb"))==NULL)
		{fclose(fp); return false;}

	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0)return 0;

		item = new sItemDef();
		if(itemPtr ==NULL)
			m_ItemDefParent = item;
		else 
			itemPtr->next = item;
		itemPtr = item;

		item->id = id;
		fscanf(fp,"%ld",&type);
		fscanf(fp,"%s",item->name);
		fscanf(fp,"%ld",&item->damageAttack);
		fscanf(fp,"%ld",&item->damageMagic);
		fscanf(fp,"%ld",&item->defense);
		fscanf(fp,"%ld",&item->increaseHP);
		fscanf(fp,"%ld",&item->increaseMP);
		fscanf(fp,"%ld",&item->manaWant);
		fscanf(fp,"%ld",&item->price);
		fscanf(fp,"%s",item->fileMesh);
		fscanf(fp,"%s",item->fileTexture);
		fscanf(fp,"%s",item->ScriptFilename);
		fscanf(fp,"%s",item->ImageFilename);
		
		item->eTypeItem = (TypeItem)type;
	}
	fclose(fp);
	return TRUE;
}
//---------------------------------
BOOL CStageGame::LoadAllModelItem()
{
	return TRUE;
}
//---------------------------------
sItemDef* CStageGame::FindItemDef(int idDef)
{
	sItemDef *ItemDef = m_ItemDefParent;
	while(ItemDef != NULL)
	{
		if(ItemDef->id==idDef)
			return ItemDef;
		ItemDef = ItemDef->next;
	}
	return m_ItemDefParent;
}
//---------------------------------
void CStageGame::GetItemDef(sItemDef &itemDef,int idDef)
{
	sItemDef *ItemDef = FindItemDef(idDef);
	itemDef.id = ItemDef->id;
	itemDef.eTypeItem = ItemDef->eTypeItem;	
	itemDef.damageAttack = ItemDef->damageAttack;
	itemDef.damageMagic  = ItemDef->damageMagic;
	itemDef.damageMagic  = ItemDef->defense;
	itemDef.increaseHP   = ItemDef->increaseHP;
	itemDef.increaseMP   = ItemDef->increaseMP;
	itemDef.manaWant     = ItemDef->manaWant;
	itemDef.price		 = ItemDef->price;	
	strcpy(itemDef.name,ItemDef->name);
	strcpy(itemDef.fileMesh,ItemDef->fileMesh);
	strcpy(itemDef.fileTexture,ItemDef->fileTexture);
	strcpy(itemDef.ScriptFilename,ItemDef->ScriptFilename);
	strcpy(itemDef.ImageFilename,ItemDef->ImageFilename);

}
//---------------------------------
sEnvDef* CStageGame::FindEnvDef(int idDef)
{
	sEnvDef *envDef = m_EnvDefParent;
	while(envDef != NULL)
	{
		if(envDef->id==idDef)
			return envDef;
		envDef = envDef->next;
	}
	return m_EnvDefParent;
}

//---------------------------------
void CStageGame::GetEnvDef(sEnvDef& envDef,int idDef)
{
	sEnvDef *EnvDef = FindEnvDef(idDef);
	envDef.id = EnvDef->id;
	strcpy(envDef.name,EnvDef->name);
	strcpy(envDef.fileMesh,EnvDef->fileMesh);
	strcpy(envDef.fileTexture,EnvDef->fileTexture);
	strcpy(envDef.ScriptFilename,EnvDef->ScriptFilename);
	strcpy(envDef.ImageFilename,EnvDef->ImageFilename);
}

sModel* CStageGame::GetModelEnv(int modelId)
{
	sEnvironment* env = m_EnvParent;

	while(env != NULL)
	{
		if (env->m_ModelEnv.id == modelId)
			return &env->m_ModelEnv;

		env = env->next;

	}
	return NULL;
}
//***********************************
BOOL CStageGame::AddTransport(sTransport* transportPtr)
{
	sTransport* ptr = m_TransportParent;
	if(m_TransportParent == NULL)
	{
		m_TransportParent = transportPtr;
		ptr = m_TransportParent;
	}
	else
	{		
		while(ptr!=NULL)
		{
			if(ptr->id == transportPtr->id)
			{
				m_Trigger.AddSphere(transportPtr->id,transportPtr->enable,
									transportPtr->xPos,
									transportPtr->yPos,
									transportPtr->zPos,
									20);
				return true;
			}
			else if(ptr->next==NULL)
			{	
				ptr->next = transportPtr;
				ptr = ptr->next;
				break;
			}
			ptr = ptr->next;
		}
	}
	ptr->onMap = m_MapCurrent->id;
	m_Trigger.AddSphere(transportPtr->id,transportPtr->enable,
									transportPtr->xPos,
									transportPtr->yPos,
									transportPtr->zPos,
									20);
	return true;
}
//-------------------------------------
BOOL CStageGame::AddEnvironment(sEnvironment* envPtr)
{
	sEnvDef envdef;
	GetEnvDef(envdef,envPtr->m_ModelEnv.id);
	strcpy(envPtr->m_ModelEnv.fileMesh,envdef.fileMesh);
	strcpy(envPtr->m_ModelEnv.fileTexture,envdef.fileTexture);
	
	envPtr->m_ModelEnv.m_Mesh.Load(m_Graphics,					\
								envPtr->m_ModelEnv.fileMesh,		\
								envPtr->m_ModelEnv.fileTexture);
	envPtr->m_ModelEnv.m_Object.Create(m_Graphics,&envPtr->m_ModelEnv.m_Mesh);

	countModelEnv++;

	if(m_EnvParent == NULL)
		m_EnvParent = envPtr;
	else
	{
		sEnvironment* ptr = m_EnvParent;
		while(ptr!=NULL)
		{
			if(ptr->next==NULL)
			{

				ptr->next = envPtr;
				envPtr->next = NULL;
				break;
			}
			ptr = ptr->next;
		}
	}
	return true;
}
//*************************************
sTransport* CStageGame::GetTransport(int id)
{
	sTransport* warpPtr = m_TransportParent;
		while(warpPtr!=NULL)
		{
			if(warpPtr->id == id)
				return warpPtr;
			warpPtr = warpPtr->next;
		}
		return NULL;
}
int CStageGame::IsTriggTransport(float xPos,float yPos,float zPos)
{
	int id =  m_Trigger.GetTrigger(xPos,yPos,zPos);
	if(id==-1)return -1;	
	
	sTransport* warpPtr = GetTransport(id);
	if(warpPtr==NULL)return -1;			
			if(warpPtr->enable)
				return id;
			else return -1;
	return -1;

}
BOOL CStageGame::CheckBarrier(float xPos,float yPos,float zPos)
{
	return m_BarrierEnv.GetBarrier(xPos,yPos,zPos);
}
//**************************************
BOOL CStageGame::Render()
{
	//**** Render Map
	m_Terrain.Render();
	
	//**** Render Environment
	sEnvironment* envPtr = m_EnvParent;
	sModel* model;
	while(envPtr != NULL)
	{
		if(envPtr->visible)
		{
			model = GetModelEnv(envPtr->m_ModelEnv.id);
			model->m_Object.Move(envPtr->xPos,envPtr->yPos,envPtr->zPos);
			model->m_Object.Rotate(envPtr->xRot,envPtr->yRot,envPtr->zRot);
			model->m_Object.Scale(envPtr->xScale,envPtr->yScale,envPtr->zScale);
			model->m_Object.Render();
		}
		envPtr = envPtr->next;
	}

	//**** Render Transport
	CWorldPosition world;
	sTransport* trpPtr = m_TransportParent;
	m_Graphics->EnableAlphaBlending(TRUE);

	while(trpPtr != NULL)
	{
		if(trpPtr->onMap != m_MapCurrent->id)
		{
			trpPtr = trpPtr->next;
			continue;
		}
		
		m_warp.Scale(4,4,4);
		m_warp.Move(trpPtr->xPos,trpPtr->yPos,trpPtr->zPos);
		m_warp.SetAnimation(&m_warpAnimation, "rot", timeGetTime()/1000);
		m_warp.UpdateAnimation(timeGetTime()/30, TRUE);
		m_warp.Render();

		
		if(trpPtr->yRot >= 6.28f) trpPtr->yRot=0;
		trpPtr = trpPtr->next;
	}

	m_Graphics->EnableAlphaBlending(FALSE);
	
	return 1;
}
