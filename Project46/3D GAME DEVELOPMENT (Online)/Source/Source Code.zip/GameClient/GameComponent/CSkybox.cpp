#include "CSkybox.h"

CSkybox::CSkybox()
{
	m_Graphics = NULL;
}

CSkybox::~CSkybox()
{
	Cleanup();
}

BOOL CSkybox::Cleanup()
{
	m_Graphics = NULL;
	for(int i=0;i<6;i++)
		m_Textures[i].Cleanup();
	m_VB.Cleanup();
	return TRUE;
}
BOOL CSkybox::Create(CGraphic *Graphics)
{
	sSkyBoxVertex Verts[24] = {
		{ -10.0f,  10.0f, -10.0f, 0.0f, 0.0f },  // Top
		{  10.0f,  10.0f, -10.0f, 1.0f, 0.0f },
		{ -10.0f,  10.0f,  10.0f, 0.0f, 1.0f },
		{  10.0f,  10.0f,  10.0f, 1.0f, 1.0f },

		{ -10.0f, -10.0f,  10.0f, 0.0f, 0.0f },  // Bottom
		{  10.0f, -10.0f,  10.0f, 1.0f, 0.0f },
		{ -10.0f, -10.0f, -10.0f, 0.0f, 1.0f },
		{  10.0f, -10.0f, -10.0f, 1.0f, 1.0f },

		{ -10.0f,  10.0f, -10.0f, 0.0f, 0.0f },  // Left
		{ -10.0f,  10.0f,  10.0f, 1.0f, 0.0f },
		{ -10.0f, -10.0f, -10.0f, 0.0f, 1.0f },
		{ -10.0f, -10.0f,  10.0f, 1.0f, 1.0f },

		{  10.0f,  10.0f,  10.0f, 0.0f, 0.0f },  // Right
		{  10.0f,  10.0f, -10.0f, 1.0f, 0.0f },
		{  10.0f, -10.0f,  10.0f, 0.0f, 1.0f },
		{  10.0f, -10.0f, -10.0f, 1.0f, 1.0f },

		{ -10.0f,  10.0f,  10.0f, 0.0f, 0.0f },  // Front
		{  10.0f,  10.0f,  10.0f, 1.0f, 0.0f },
		{ -10.0f, -10.0f,  10.0f, 0.0f, 1.0f },
		{  10.0f, -10.0f,  10.0f, 1.0f, 1.0f },
	    
		{  10.0f,  10.0f, -10.0f, 0.0f, 0.0f },  // Back
		{ -10.0f,  10.0f, -10.0f, 1.0f, 0.0f },
		{  10.0f, -10.0f, -10.0f, 0.0f, 1.0f },
		{ -10.0f, -10.0f, -10.0f, 1.0f, 1.0f }
	};

	Cleanup();

	//Error checking
	if ((m_Graphics = Graphics)==NULL)
		return FALSE;

	//Create the vertex buffer (and copy over sky box vertices)
	if (m_VB.Create(m_Graphics, 24, SkyboxFVF, sizeof(sSkyBoxVertex))==TRUE)
		m_VB.Set(0, 24, (void*)&Verts);

	//Rotate Sky box into default orientation
	Rotate(0.0f, 0.0f, 0.0f);

    return TRUE;
}

BOOL CSkybox::LoadTexture(short Side, char *filename, D3DCOLOR Transparent, D3DFORMAT Format)
{
	//Error checking
	if ((m_Graphics ==NULL) || Side < 0 || Side > 5)
		return FALSE;

	m_Textures[Side].Cleanup();

	return m_Textures[Side].Load(m_Graphics, filename, Transparent, Format);
}

BOOL CSkybox::Rotate(float XRot, float YRot, float ZRot)
{
	return m_Pos.Rotate(XRot,YRot,ZRot);
}

BOOL CSkybox::RotateRel(float XRot, float YRot, float ZRot)
{
	return m_Pos.RotateRel(XRot,YRot,ZRot);
}

BOOL CSkybox::Render(CCamera *Camera, BOOL Alpha)
{
	D3DXMATRIX matWorld;
	short i;

	// Error checking
	if(m_Graphics == NULL || Camera == NULL)
		return FALSE;

	// Position sky box around viewer
	m_Pos.Scale(1000.0f,1000.0f,1000.0f);
	m_Pos.Move(Camera->GetXPos(), Camera->GetYPos(), Camera->GetZPos());
	m_Graphics->SetWorldPosition(&m_Pos);

	// Enable alpha testing and alpha blending
	m_Graphics->EnableAlphaTesting(TRUE);
	if(Alpha == TRUE)
		m_Graphics->EnableAlphaBlending(TRUE, D3DBLEND_SRCCOLOR, D3DBLEND_DESTCOLOR);

	m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
    m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
    m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_POINT);

	// Set Texture-Addressing to clamp
	m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_ADDRESSU, D3DTADDRESS_CLAMP);
    m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_ADDRESSV, D3DTADDRESS_CLAMP);

    // Draw each layer
	for(i=0;i<6;i++) {
		if(m_Textures[i].IsLoaded() == TRUE) {
		m_Graphics->SetTexture(0, &m_Textures[i]);
		m_VB.Render(i*4,2,D3DPT_TRIANGLESTRIP);
		}
	}

	// Disable alpha testing and alpha blending
	m_Graphics->EnableAlphaTesting(FALSE);
	if(Alpha == TRUE)
		m_Graphics->EnableAlphaBlending(FALSE);

	return TRUE;
}