#include "HGlobal.h"
#include "Global_Func.h"
#include "cLayerWindow.h"
#include "CDialogChat.h"
#include "resource.h"

HWND g_hWndChatMsg=NULL;
BOOL g_SendPress;

CDialogChat::CDialogChat()
{
	m_hWndChat = NULL;
	m_hWndChatMessage = NULL;
	m_hWndParent = NULL;
	g_SendPress = FALSE;
}

CDialogChat::ShowDialog(HINSTANCE hInst, int IDD_DLG1, int IDD_DLG2, HWND hWndParent)
{
	if (m_hWndChat != NULL)
		return FALSE;
	if (m_hWndChatMessage != NULL)
		return FALSE;

	m_hWndChat = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DLG1), hWndParent, (DLGPROC)ChatDlgProc);
	m_hWndChatMessage = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DLG2), hWndParent, (DLGPROC)ChatMessageDlgProc);

	if (m_hWndChat == NULL)
		return FALSE;
	if (m_hWndChatMessage == NULL)
		return FALSE;
	
	cWindowLayer WinLayer;
	WinLayer.AddWindowLayer(m_hWndChatMessage);
	WinLayer.SetWindowAlpha(200);
	g_hWndChatMsg = m_hWndChatMessage;
	SetWindowPos(GetDlgItem(g_hWndChatMsg, IDC_LISTMESSAGE), HWND_TOP, 0, 0, 400, 75, SWP_SHOWWINDOW);

	RECT rect;
	GetClientRect(hWndParent, &rect);
	int XPos = rect.left + 5;
	int YPos = rect.bottom - 103;	
	SetWindowPos(m_hWndChat, HWND_TOP, XPos, YPos+75, 400, 24, SWP_SHOWWINDOW);
	SetWindowPos(m_hWndChatMessage, HWND_TOP, XPos, YPos, 400, 75, SWP_SHOWWINDOW);
	HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\chatmessage.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
	HRGN rgn = CreateRegion(m_hWndChat, Background, 400, 24, 255, 0, 255);
	SetWindowRgn(m_hWndChat, rgn, TRUE);
	m_hWndParent = hWndParent;
	
	SendMessage(GetDlgItem(m_hWndChat,IDC_PLAYER),EM_LIMITTEXT,20,0);
	SendMessage(GetDlgItem(m_hWndChat,IDC_EDITMESSAGE),EM_LIMITTEXT,70,0);
	ShowWindow(m_hWndChat, SW_SHOW);
	UpdateWindow(m_hWndChat);
	ShowWindow(m_hWndChatMessage, SW_SHOW);
	UpdateWindow(m_hWndChatMessage);

	return TRUE;
}

BOOL CDialogChat::ClearSendPress()
{

	g_SendPress = FALSE;

	return TRUE;
}

BOOL CDialogChat::SendButtonPress()
{
	return g_SendPress;
}

void CDialogChat::AddMessage(char *Message)
{
	ListBox_InsertString(GetDlgItem(m_hWndChatMessage, IDC_LISTMESSAGE), -1, Message);
	int Sel = ListBox_GetCount(GetDlgItem(m_hWndChatMessage, IDC_LISTMESSAGE));
	SendMessage(GetDlgItem(m_hWndChatMessage, IDC_LISTMESSAGE), LB_SETCURSEL, Sel-1, 0); 
}
HWND CDialogChat::GethWndChat()
{
	return m_hWndChat;
}

HWND CDialogChat::GethWndChatMsgDlg()
{
	return m_hWndChatMessage;
}

char* CDialogChat::GetMessage()
{
	char* Str = NULL;
	Edit_GetText(GetDlgItem(m_hWndChat, IDC_EDITMESSAGE), Str, 128);
	return Str;
}

LRESULT CALLBACK ChatDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			//Set Window Cursor
			MoveWindow(GetDlgItem(hDlg, IDC_PLAYER), 4, 4, 65, 16, TRUE);
			MoveWindow(GetDlgItem(hDlg, IDC_EDITMESSAGE), 72, 4, 278, 16, TRUE);
			MoveWindow(GetDlgItem(hDlg, IDC_SEND),355,4,40,16,TRUE);
		} break;
		case WM_MOVE:
		{
			int XPos = (int)(short)LOWORD(lParam);
			int YPos = (int)(short)HIWORD(lParam);
			MoveWindow(g_hWndChatMsg, XPos, YPos-75, 400, 75, TRUE);
		} break;
		case WM_LBUTTONDOWN:
		{
			int YPos = HIWORD(lParam);

			if ((YPos >= 0)&&(YPos <= 17))
			{
				SendMessage(hDlg, WM_NCLBUTTONDOWN, HTCAPTION,NULL);
			}
		} break;
		case WM_CTLCOLOREDIT:
		{
			HDC hdc = (HDC)wParam;
			SetBkColor(hdc, RGB(240,240,240));
			SetTextColor(hdc, RGB(0,0,0));
			return (long)CreateSolidBrush(RGB(240,240,240));
		} break;
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDC_SEND:
				{
					g_SendPress = TRUE;
				} break;
			}
		} break;
		case WM_DRAWITEM: 
		{			
			LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT) lParam; 
			if (lpdis->CtlType == ODT_BUTTON)
			{
				HDC hdcMem = CreateCompatibleDC(lpdis->hDC);

				if (lpdis->CtlID == IDC_SEND)
				{
					HBITMAP Button1 = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\send.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
					TransBlt(lpdis->hDC, 0, 0, 40, 16, Button1, 255, 0, 255);
					
				}
				DeleteDC(hdcMem); 
			}

			return TRUE; 
		}
		case WM_PAINT:
		{
			HDC hdc = GetDC(hDlg);
			HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\chatmessage.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
			TransBlt(hdc, 0, 0, 400, 24, Background, 255, 0, 255);
			ReleaseDC(hDlg, hdc);
		} break;
	
	}

	return FALSE;
}

LRESULT CALLBACK ChatMessageDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			
		} break;
		case WM_LBUTTONDOWN:
		{
			int YPos = HIWORD(lParam);

			SendMessage(hDlg, WM_NCLBUTTONDOWN, HTCAPTION,NULL);
		} break;
		/*case WM_CTLCOLORSTATIC:
		{
			HDC hdc = (HDC)wParam;
			SetBkColor(hdc, RGB(255,255,255));
			SetTextColor(hdc, RGB(0,0,0));
			return (long)CreateSolidBrush(RGB(255,255,255));
		} break;
		*/case WM_PAINT:
		{
			/*HDC hdc = GetDC(hDlg);
			HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Skin\\basic_interface\\dialog_bg.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
			TransBlt(hdc, 0, 0, 600, 24, Background, 255, 0, 255);
			ReleaseDC(hDlg, hdc);
			*/PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
			HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\dialog_bg.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
			HDC backdc = CreateCompatibleDC(hdc);
			SelectObject(backdc, Background);
			//BitBlt(hdc, ps.rcPaint.left,ps.rcPaint.top, ps.rcPaint.right-ps.rcPaint.left,ps.rcPaint.bottom-ps.rcPaint.top, backdc,ps.rcPaint.left,ps.rcPaint.top,SRCCOPY);
			EndPaint(hDlg, &ps);
		} break;
	}

	return FALSE;
}

