#ifndef _CDialogLogin_H_
#define _CDialogLogin_H_

class CDialogLogin
{
	private:
		HWND m_hWnd;
		HWND m_hWndParent;

	public:
		CDialogLogin();

		BOOL Create(HINSTANCE hInst, int IDD_DIALOG, HWND hWndParent);
		BOOL Close();

		HWND GethWnd();

		BOOL ClearLoginPress();
		BOOL LoginButtonPress();
};

LRESULT CALLBACK LoginDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

#endif
