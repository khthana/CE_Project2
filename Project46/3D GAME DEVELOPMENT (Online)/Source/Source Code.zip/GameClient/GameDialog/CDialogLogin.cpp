#include "HGlobal.h"

#include "CDialogLogin.h"

BOOL g_LoginPress;

CDialogLogin::CDialogLogin()
{
	m_hWnd = NULL;
	m_hWndParent = NULL;
}

BOOL CDialogLogin::ClearLoginPress()
{

	g_LoginPress = FALSE;

	return TRUE;
}

BOOL CDialogLogin::Create(HINSTANCE hInst, int IDD_DIALOG, HWND hWndParent)
{
	if (m_hWnd != NULL)
		m_hWnd = NULL;
		//return FALSE;

	m_hWnd = CreateDialog(hInst, MAKEINTRESOURCE(IDD_DIALOG), hWndParent, (DLGPROC)LoginDlgProc);

	if (m_hWnd == NULL)
		return FALSE;

	RECT rect;
	GetClientRect(hWndParent, &rect);
	int XPos, YPos;
	XPos = (rect.right-rect.left-300)/2;
	YPos = (rect.bottom-rect.top)*56/100;

	SetWindowPos(m_hWnd, HWND_TOP, XPos, YPos, 300, 150, SWP_SHOWWINDOW);
	HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_BG.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
	HRGN rgn = CreateRegion(m_hWnd, Background, 300, 150, 255, 0, 255);
	SetWindowRgn(m_hWnd, rgn, TRUE);
	m_hWndParent = hWndParent;

	g_LoginPress = FALSE;

	ShowWindow(m_hWnd, SW_SHOW);
	UpdateWindow(m_hWnd);

	return TRUE;
}

BOOL CDialogLogin::Close()
{
	g_LoginPress = FALSE;

	return EndDialog(m_hWnd, 0);
}

HWND CDialogLogin::GethWnd()
{
	return m_hWnd;
}

BOOL CDialogLogin::LoginButtonPress()
{
	return g_LoginPress;
}

LRESULT CALLBACK LoginDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			MoveWindow(GetDlgItem(hDlg, IDC_USER), 75, 39, 110, 12, TRUE);
			MoveWindow(GetDlgItem(hDlg, IDC_PASSWD), 75, 70, 111, 12, TRUE);
			MoveWindow(GetDlgItem(hDlg, IDC_LOGIN), 130, 120, 60, 20, TRUE);
			MoveWindow(GetDlgItem(hDlg, IDC_EXIT), 200, 120, 60, 20, TRUE);
		} break;
		case WM_LBUTTONDOWN:
		{
			int YPos = HIWORD(lParam);

			if ((YPos >= 0)&&(YPos <= 17))
			{
				SendMessage(hDlg, WM_NCLBUTTONDOWN, HTCAPTION,NULL);
			}
		} break;
		case WM_CTLCOLOREDIT:
		{
			HDC hdc = (HDC)wParam;
			SetBkColor(hdc, RGB(240,240,240));
			SetTextColor(hdc, RGB(0,0,0));
			return (long)CreateSolidBrush(RGB(240,240,240));
		} break;
        case WM_DRAWITEM: 
		{			
			LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT) lParam; 
			if (lpdis->CtlType == ODT_BUTTON)
			{
				HDC hdcMem = CreateCompatibleDC(lpdis->hDC);

				if (lpdis->CtlID == IDC_LOGIN)
				{
					HBITMAP Button1 = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_login.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
					HBITMAP Button2 = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_login_inv.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
					if (lpdis->itemState & ODS_SELECTED)
						TransBlt(lpdis->hDC, 0, 0, 60, 20, Button2, 255, 0, 255);
					else
						TransBlt(lpdis->hDC, 0, 0, 60, 20, Button1, 255, 0, 255);
				}
				else
				if (lpdis->CtlID == IDC_EXIT)
				{
					HBITMAP Button1 = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_exit.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
					HBITMAP Button2 = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_exit_inv.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
					if (lpdis->itemState & ODS_SELECTED)
						TransBlt(lpdis->hDC, 0, 0, 60, 20, Button2, 255, 0, 255);
					else
						TransBlt(lpdis->hDC, 0, 0, 60, 20, Button1, 255, 0, 255);
				}
				
				DeleteDC(hdcMem); 
			}

			return TRUE; 
		}
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDC_LOGIN:
				{
					g_LoginPress = TRUE;
					//MessageBox(hDlg, "Login", "Login", MB_OK);
				} break;
				case IDC_EXIT:
				{
					EndDialog(hDlg, 0);
					PostQuitMessage(0);
				} break;
			}
		} break;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hDlg, &ps);
			HBITMAP Background = (HBITMAP)LoadImage(NULL, ".\\Texture\\Dialog\\login_BG.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION|LR_DEFAULTSIZE);
			HDC backdc = CreateCompatibleDC(hdc);
			SelectObject(backdc, Background);
			BitBlt(hdc, ps.rcPaint.left,ps.rcPaint.top, ps.rcPaint.right-ps.rcPaint.left,ps.rcPaint.bottom-ps.rcPaint.top, backdc,ps.rcPaint.left,ps.rcPaint.top,SRCCOPY);
			EndPaint(hDlg, &ps);
		} break;
	}

	return FALSE;
}
