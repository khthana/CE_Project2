#ifndef _CDialogChat_H_
#define _CDialogChat_H_

class CDialogChat
{
	private:
		HWND m_hWndChat;
		HWND m_hWndChatMessage;
		HWND m_hWndParent;
	public:
		CDialogChat();

		BOOL ShowDialog(HINSTANCE hInst, int IDD_DLG1, int IDD_DLG2, HWND hWndParent);

		void AddMessage(char *Message);
		char* GetMessage();

		HWND GethWndChat();
		HWND GethWndChatMsgDlg();

		BOOL ClearSendPress();
		BOOL SendButtonPress();
};

LRESULT CALLBACK ChatDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ChatMessageDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

#endif

