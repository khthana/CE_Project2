#ifndef _CDB_H
#define _CDB_H

class CDB
{
	CDatabase m_DB;
public:
	CDB(){}
	~CDB();

	BOOL Init();
	
	CRecordset* Query(char* Query);
	BOOL Update(char* Query);
	BOOL Shutdown();
};

#endif