#include "HGlobal.h"
#include "CDB.h"

CDB::~CDB()
{
	Shutdown();
}

BOOL CDB::Shutdown()
{
	m_DB.Close();

	return TRUE;
}

BOOL CDB::Init()
{
	m_DB.SetLoginTimeout(10);
	CString St("ODBC;UID=hh;PWD=hacker");
	
	if (!m_DB.Open(_T("MSSqlServer"), FALSE, FALSE, St))
		return FALSE;

	return TRUE;
}

BOOL CDB::Update(char* Query)
{
	if (m_DB.CanUpdate())
		m_DB.ExecuteSQL(Query);

	return FALSE;
}

CRecordset* CDB::Query(char* Query)
{
	CRecordset* res  = new CRecordset(&m_DB);
	
	if (!res->Open(CRecordset::forwardOnly, Query))
			return NULL;

	return res;
}