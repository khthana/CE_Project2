// CPortListening.h: interface for the CPortListening class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CPORTLISTENING_H__644E5474_74FB_4C69_896C_0F14466CBAC6__INCLUDED_)
#define AFX_CPORTLISTENING_H__644E5474_74FB_4C69_896C_0F14466CBAC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CThread.h"

class CPortListening : public CThread  
{
public:
	CPortListening(unsigned int port);
	int openListening(unsigned short port);
	void threadProc();
	char* getMessage();
	void stop(unsigned int server);
	void start();
	CPortListening();

private:
	int serverSocket;
	bool quitFlag;
	char* message;
	HANDLE acceptHandle;
	HANDLE mutexHandle;
	FD_SET clientSet;
};

#endif // !defined(AFX_CPORTLISTENING_H__644E5474_74FB_4C69_896C_0F14466CBAC6__INCLUDED_)
