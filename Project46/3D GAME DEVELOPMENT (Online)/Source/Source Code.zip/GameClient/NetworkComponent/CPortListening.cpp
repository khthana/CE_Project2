// CPortListening.cpp: implementation of the CPortListening class.
//
//////////////////////////////////////////////////////////////////////

#include "CPortListening.h"
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPortListening::CPortListening()
{
	serverSocket = openListening(7654);
	quitFlag = false;
}
CPortListening::CPortListening(unsigned int port)
{
	serverSocket = openListening(port);
	quitFlag = false;
}

void CPortListening::start()
{
	FD_ZERO(&clientSet);

	// the main loop ... run forever
	for (;;) {
		if (quitFlag) {
			break;
		}

		WaitForSingleObject(mutexHandle, INFINITE);
		FD_SET pollingSet = clientSet;
		ReleaseMutex(mutexHandle);

		// check if set is empty
		if (pollingSet.fd_count == 0) {
			continue;
		}

		
		timeval waitTime;
		waitTime.tv_sec = 0;
		waitTime.tv_usec = 0;

		int result = select(pollingSet.fd_count, &pollingSet, NULL, NULL, &waitTime);

		if (result == 0) {
			continue;
		}

		if (result == SOCKET_ERROR) {
			printf("Error in select()\n");
			continue;
		}

		
		for (unsigned int i = 0; i < pollingSet.fd_count; i++) {

			unsigned int clientSocket = pollingSet.fd_array[i];
			unsigned int nBytes;

			#define MAX_MESSAGE_SIZE 4096
			char buffer[MAX_MESSAGE_SIZE];
		
			unsigned long messageSize;

			nBytes = recv(clientSocket, (char*)&messageSize, sizeof(messageSize), 0);

			// check for errors
			if (nBytes == SOCKET_ERROR) {

				unsigned int error = WSAGetLastError();

				if (error == WSAECONNRESET) {

					WaitForSingleObject(mutexHandle, INFINITE);
					FD_CLR(clientSocket, &clientSet);
					ReleaseMutex(mutexHandle);

					closesocket(clientSocket);

					printf("client on %d disconnected\n", clientSocket);

					continue;

				} else {

					printf("Recv Failed!\n");
					quitFlag = true;
					break;

				}
			}


			if (nBytes == 0) {
				WaitForSingleObject(mutexHandle, INFINITE);
				FD_CLR(clientSocket, &clientSet);
				ReleaseMutex(mutexHandle);

				closesocket(clientSocket);

				printf("client on %d disconnected\n", clientSocket);

				continue;
			}

			messageSize = ntohl(messageSize);

			nBytes = recv(clientSocket, buffer, messageSize, 0);

			if (nBytes == SOCKET_ERROR) {
				printf("Recv Failed!\n");
				quitFlag = true;
				break;
			}

			// terminate the buffer amd print it
			//buffer[messageSize] = '\0';

			// print the message
			printf("Message Received from client on %d : %s\n", clientSocket, buffer);
		}
	}

	// cleanup
	stop(serverSocket);
}

void CPortListening::stop(unsigned int server)
{
	// kill  thread and  handle
	WaitForSingleObject(threadHandle, INFINITE);
	CloseHandle(threadHandle);
	CloseHandle(mutexHandle);

	// close  socket
	closesocket(server);

	// shutdown winsock
	WSACleanup();
	printf("Server Shutdown\n");
}

char* CPortListening::getMessage()
{
	return message;
}

void CPortListening::threadProc()
{
if (serverSocket == -1) {
		printf("Network Startup Failed!\nProgram Terminating\n");
		return;
	}

	for (;;) {
		unsigned int clientSocket = accept(serverSocket, 0, 0);
		if (clientSocket == SOCKET_ERROR) {
			printf("Accept Failed!\n");
			quitFlag = true;
			return;

		} else {
			
			printf("set clientset\n");

			WaitForSingleObject(mutexHandle, INFINITE);
			FD_SET(clientSocket, &clientSet);
			ReleaseMutex(mutexHandle);

			printf("client on %d connected\n", clientSocket);
		}
	}
}

int CPortListening::openListening(unsigned short port)
{

	int error;
	WSAData wsaData;

	// startup winsock
	if ((error = WSAStartup(MAKEWORD(2, 2), &wsaData)) == SOCKET_ERROR) {
		printf("Could Not Start Up Winsock!\n");
		return -1;
	}

	// create socket
	int mySocket = socket(AF_INET, SOCK_STREAM, 0);

	// create the mutex
	mutexHandle = CreateMutex(NULL, false, NULL);
	if (mutexHandle == NULL) {
		printf("Error creating mutex\n");
		stop(mySocket);
		return -1;
	}
	// error checking
	if (mySocket == SOCKET_ERROR) {
		printf("Error Opening Socket!\n");
		return -1;
	}

	// the address structure
	struct sockaddr_in server;

	// fill the address structure with appropriate data
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = INADDR_ANY;

	// bind socket
	if (bind(mySocket, (sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
		printf("Bind Failed!\n");
		closesocket(mySocket);
		return -1;
	}

	// mark socket for listening
	if (listen(mySocket, 5) == SOCKET_ERROR) {
		printf("Listen Failed!\n");
		closesocket(mySocket);
		return -1;
	}

	printf("Server Started\n");

	return mySocket;

}

/*
void main(){
	CPortListening server = CPortListening(7654);
	server.start();
		
}
*/