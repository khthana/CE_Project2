# Microsoft Developer Studio Project File - Name="3DGAMEONLINE" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=3DGAMEONLINE - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "3DGAMEONLINE.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "3DGAMEONLINE.mak" CFG="3DGAMEONLINE - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "3DGAMEONLINE - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "3DGAMEONLINE - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "3DGAMEONLINE - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "Engin" /D "GameComponent" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "NDEBUG"
# ADD RSC /l 0x41e /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "3DGAMEONLINE - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /I ".\GameComponent" /I ".\GameDialog" /I ".\NetworkComponent" /I ".\\" /I ".\Engin" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "_DEBUG"
# ADD RSC /l 0x41e /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /out:"3DGAMEONLINE.exe" /pdbtype:sept

!ENDIF 

# Begin Target

# Name "3DGAMEONLINE - Win32 Release"
# Name "3DGAMEONLINE - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\GameComponent\CCharacterControl.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CStageGame.cpp
# End Source File
# Begin Source File

SOURCE=.\WinMain.cpp
# End Source File
# Begin Source File

SOURCE=.\WinMain_CChars.cpp
# End Source File
# Begin Source File

SOURCE=.\WinMain_CGamescript.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\GameComponent\CCharacterControl.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CStageGame.h
# End Source File
# Begin Source File

SOURCE=.\NetworkComponent\Packet.h
# End Source File
# Begin Source File

SOURCE=.\WinMain.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\resource.h
# End Source File
# Begin Source File

SOURCE=.\Script.rc
# End Source File
# End Group
# Begin Group "Game Component_Header Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\GameComponent\CBarrier.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CFrustum.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CLandscape.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CMiniMap.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CNodeTree.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CRelCamera.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CScript.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CSkybox.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CTrigger.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CWindow.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\MCL.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\MSL.h
# End Source File
# Begin Source File

SOURCE=.\GameComponent\Spell.h
# End Source File
# End Group
# Begin Group "Game Component_Source Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\GameComponent\CBarrier.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CFrustum.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CInventory.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CLandscape.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CMiniMap.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CNodeTree.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CRelCamera.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CScript.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CSkybox.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CTrigger.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\CWindow.cpp
# End Source File
# Begin Source File

SOURCE=.\GameComponent\Spell.cpp
# End Source File
# End Group
# Begin Group "GameEngin_Header Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Engin\Engin_Application.h
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics.h
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Input.h
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Sound.h
# End Source File
# Begin Source File

SOURCE=.\Global_Func.h
# End Source File
# Begin Source File

SOURCE=.\Engin\HGlobal.h
# End Source File
# End Group
# Begin Group "GameEngin_Source Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Engin\Engin_Application.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Camera.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Font.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Light.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Material.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Mesh_Animation.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Object.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_Texture.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_VertexBuffer.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Graphics_WorldPosition.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Input.cpp
# End Source File
# Begin Source File

SOURCE=.\Engin\Engin_Sound.cpp
# End Source File
# Begin Source File

SOURCE=.\Global_Func.cpp
# End Source File
# End Group
# Begin Group "Common"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\d3dfont.cpp
# End Source File
# Begin Source File

SOURCE=.\d3dfont.h
# End Source File
# Begin Source File

SOURCE=.\d3dutil.cpp
# End Source File
# Begin Source File

SOURCE=.\d3dutil.h
# End Source File
# Begin Source File

SOURCE=.\dxutil.cpp
# End Source File
# Begin Source File

SOURCE=.\dxutil.h
# End Source File
# End Group
# Begin Group "Dialog_Header Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\GameDialog\CDialogChat.h
# End Source File
# Begin Source File

SOURCE=.\GameDialog\CDialogLogin.h
# End Source File
# Begin Source File

SOURCE=.\GameDialog\cLayerWindow.h
# End Source File
# End Group
# Begin Group "Dialog_Source Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\GameDialog\CDialogChat.cpp
# End Source File
# Begin Source File

SOURCE=.\GameDialog\CDialogLogin.cpp
# End Source File
# Begin Source File

SOURCE=.\GameDialog\cLayerWindow.cpp
# End Source File
# End Group
# End Target
# End Project
