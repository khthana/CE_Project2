#ifndef _WINMAIN_H
#define _WINMAIN_H

#include <winsock.h>
#include "D3DFont.h"
#include "CSkybox.h"
#include "CFrustum.h"
#include "CNodeTree.h"
#include "CScript.h"
#include "CLandscape.h"
#include "CStageGame.h"
#include "CCharacterControl.h"
//#include "CEffect.h"
#include "Spell.h"
#include "CRelCamera.h"
#include "CMiniMap.h"
#include "CWindow.h"

//Dialog
#include "CDialogLogin.h" 
#include "CDialogChat.h"

typedef struct sCharacterStats
{
	char Name[50];

	long LV;
	long EXP;
	long Points;
	long HealPoints;
	long ManaPoints;

	long MaxHealPoints;
	long MaxManaPoints;
	long Str;
	long Vit;
	long Int;
	
	long MapID;
	float xPos,zPos;

	// Event
	BOOL Flag[256];

}sCharacterStats;

typedef struct sCharacterItem
{
	int ID;
	int ItemDef;
	int Count;
}sCharacterItem;

class CGame;

class CChars : public CCharacterController
{

  private:
    CGame		*m_App;

	sPacketWalk		pkwalk;
	sPacketToChar	pkchar;
	long			SpellNum;
			
    BOOL PCUpdate(sCharacter *Character, long Elapsed,        \
                  float *XMove, float *YMove, float *ZMove);
    
	long CalculateHeroLV(long LV, long EXP);
  public:

	long CalculateNextLV(long LV);
	BOOL SetData(CGame *App);

};

class CGameScript : public CScript
{
  private:
    BOOL       m_Flags[256];

    CGraphic  *m_Graphics;
    CFont     *m_Font;

    CInputDevice *m_Keyboard;

    CGame      *m_App;
    CWindow    m_Window;
    CChars    *m_CharController;

    long         m_NumRoutePoints;
    sRoutePoint *m_Route;

    // The script function prototypes
    sScript *Script_End(sScript*);
    sScript *Script_IfFlagThen(sScript*);
	sScript *Script_IfHaveItem(sScript*);
    sScript *Script_Else(sScript*);
    sScript *Script_EndIf(sScript*);
    sScript *Script_SetFlag(sScript*);
    sScript *Script_Message(sScript*);
	sScript *Script_CharMessage(sScript*);
	sScript *Script_CharQuestionMessage(sScript*);
    sScript *Script_AddChar(sScript*);
	sScript *Script_AddModel(sScript*);
    sScript *Script_RemoveChar(sScript*);
    sScript *Script_CharType(sScript*);
    sScript *Script_CharAI(sScript*);
    sScript *Script_CharDistance(sScript*);
    sScript *Script_CharBounds(sScript*);
    sScript *Script_TargetChar(sScript*);
    sScript *Script_NoTarget(sScript*);
    sScript *Script_CreateRoute(sScript*);
    sScript *Script_AddPoint(sScript*);
    sScript *Script_AssignRoute(sScript*);
    sScript *Script_MoveChar(sScript*);
    sScript *Script_CharScript(sScript*);
	sScript *Script_SetTransport(sScript*);
	sScript *Script_EnableTransport(sScript*);
	sScript *Script_LoadStage(sScript*);
	sScript *Script_LoadListModel_Env(sScript*);
	sScript *Script_LoadItemToChar(sScript*);
	sScript *Script_PlayMusicMidi(sScript*);
	Script_EndGame(sScript*);
	sScript *Script_Addexp(sScript*);
	sScript *Script_IfCharhaveExp(sScript*);

    // The overloaded processing functions
    BOOL     Prepare();
    BOOL     Release();
    sScript *Process(sScript *Script);

  public:
	CGameScript();
	~CGameScript();

	BOOL* GetFlag(){return m_Flags;}

	BOOL SetFlag(BOOL* flag)
	{
		for(int i=0;i<256;i++)
			m_Flags[i] = flag[i];
		return TRUE;
	}

	BOOL ClearFlag()
	{
		ZeroMemory(m_Flags,sizeof(m_Flags));
		return TRUE;
	}

    BOOL SetData(CGame *Application, CGraphic *Graphics,      \
                 CFont *Font, CInputDevice *Keyboard,         \
                 CChars *Chars);
};

class CGame : public CApplication
{
private:
	friend class	CGameScript;
	friend class	CChars;

	CDialogChat		m_ChatDialog;
	CGraphic		Graphic;
	CRelativeCamera	Camera;
	CLight			Light;
	CFont			FontText;
	CD3DFont*		FontHeader;
	CD3DFont*       FontName;
	//CFont			FontHeader;
	//CFont			FontName;

	CInput			Input;
	CInputDevice    m_Keyboard;
    CInputDevice    m_Mouse;

	CSound			m_Sound;
	CSoundData		m_SoundData[2];
	CSoundChannel	m_Channel[2];
	CMusicChannel	m_Music;

	CSound			m_SoundAct;
	CSoundData		m_SoundDataAct[2];
	CSoundChannel	m_ChannelAct[2];
	CMusicChannel	m_SoundAction;
	
	CStageGame		m_StageGame;
	CChars          m_CharController;
    CSpellController m_SpellController;
	CGameScript     m_Script;
	//CWorldPosition	m_World;

//	CEffect			m_Effect;

// 2D Screen
	// Bar
	CVertexBuffer	m_VB_Bar;
	CTexture		m_Bar;
	CVertexBuffer	m_VB_Barback;
	CTexture		m_Barback;
	CVertexBuffer	m_VB_BarHP;
	CTexture		m_BarHP;
	CVertexBuffer	m_VB_BarMP;
	CTexture		m_BarMP;
	CVertexBuffer	m_VB_BarItem;
	CTexture		m_BarItem;
	CVertexBuffer	m_VB_Stats;
	CTexture		m_Stats;
	CVertexBuffer	m_VB_UpPoint;
	CTexture		m_UpPoint;
	CVertexBuffer	m_VB_Loading;
	CTexture		m_Loading;
	CVertexBuffer	m_VB_Save;
	CTexture		m_Save;
	CVertexBuffer	m_VB_SaveQuestion;
	CTexture		m_SaveQuestion;

// WinSock globals
	SOCKET			m_Socket;
	sockaddr_in		m_Addr;	
	INT				m_IP[4];

// Menu
	BOOL			m_ShowStats;
	BOOL			m_MouseClickOnScreen;

	D3DXVECTOR2		m_DestMap;
	DWORD			m_TimeMouseClick;
	float			m_XPosStats,m_YPosStats;
	long			m_WidthStats,m_HeightStats;
	float			m_XPosChat,m_YPosChat;
	long			m_WidthChat,m_HeightChat;
	float			m_XPosSave,m_YPosSave;

	// State Manage
	CStateManager	m_StateManager;
	static void ShowMenuGame(void *Ptr, long Purpose);
	static void ShowSaveDlg(void *Ptr, long Purpose);
	static void ShowGame(void *Ptr, long Purpose);

	// Thread Management
	HANDLE			m_ThreadHandle;
	bool			m_TerminateThreadFlag;

	sPacketCreateSpawnPlayer* pkCreatePly;
	sPacketCreateMonster pkCreateMon;
	sPacketUpdateSpawnPlayer pkupdate;
	sPacketUpdateMonster pkupdatemon;
	sPacketRemoveSpawnPlayer pkrm;
	sPacketReady pkready; 
	sPacketGetCharacter pkget;
	sPacketWalk pk;
	sPacketToChar pkchar;
	sPacketMessage pkmsg;
	sPacketLogin pklogin;
	sPacketChat pkchat;
	sPacketPlayer pkply;
	sPacketRebornMonster pkreb;
public:
	CGame();
	
	D3DXVECTOR3		m_MouseClickPos;
	Stage			eStage;
	TypeTrick		WarpTrick; 
	BOOL			ToGame;

	BOOL			Init();
	BOOL			Frame();
	BOOL			Shutdown();

	long			CheckInput();
	BOOL			CheckMouseClickOnScreen();

	// Check if player collides with level mesh
    BOOL			CheckIntersect( sMesh* MeshPtr ,               \
								    float XStart, float YStart, float ZStart,    \
									float XEnd,   float YEnd,   float ZEnd, float* dist);
	// Screen
	BOOL			LoadScreen();
	BOOL			LoadingRender();
	BOOL			ScreenRender();
	BOOL			UpdateScreenControl();

	// Game Checking
	BOOL			CameraMoveMent();
			
	BOOL			ClipMouse();
	CInputDevice*	GetMouseControl(){return &m_Mouse;}
	CInputDevice*	GetKeyboard(){return &m_Keyboard;}
	CRelativeCamera*GetCamera(){return &Camera;}
	LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	// Winsock 
	BOOL			ConnectServer(char* IP,int Port);
	SOCKET			GetServerSocket(){return m_Socket;}
	BOOL			CheckPacket(char* buffer);
	BOOL			SendPacket(char* msg,int size);
	
	BOOL			AddCharacter(int id,char* name, float xpos, float zpos, float direction);

	// Load & save Game
	BOOL			LoadGame(char* filename, int MapID = -1);
	BOOL			SaveGame(char* filename);
};

#endif