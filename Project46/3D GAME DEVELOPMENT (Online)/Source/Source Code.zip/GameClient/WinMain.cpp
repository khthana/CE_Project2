#include "HGlobal.h"

#include "WinMain.h"

#define WM_SOCKET	WM_USER+1	// Socket Windows Message

CDialogLogin  g_LoginDlg;
CGame* g_Game;

// Global names of character meshes
char *g_CharMeshNames[] = {
    { ".\\Model\\Character\\Human.x" },   // Mesh # 0
	{ ".\\Model\\Character\\npc_1.x"},
	{ ".\\Model\\Character\\npc_2.x"},
	{ ".\\Model\\Character\\npc_3.x"},
	{ ".\\Model\\Character\\npc_4.x"},
	{ ".\\Model\\Character\\npc_5.x"},
	{ ".\\Model\\Character\\npc_6.x"},
	{ ".\\Model\\Character\\npc_7.x"},
	{ ".\\Model\\Character\\mon_1.x"},
	{ ".\\Model\\Character\\mon_2.x"},
	{ ".\\Model\\Character\\boss.x"},
	{ ".\\Model\\Environment\\Box.x"},
	{ ".\\Model\\Environment\\warpport1.x"},
  };

sCharAnimationInfo g_CharAnimations[] = {
    { "IDLE",  TRUE  },
    { "WALK",  TRUE  },
    { "SWING", TRUE  },
};

char *g_SpellMeshNames[] = {
	{ ".\\Model\\Spell\\fireball.x"}
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, PSTR, int)
{

	float a = D3DX_PI/12;
	float b = D3DXToDegree(a);

	CGame game;
	
	return game.Run();
	 
}

CGame::CGame()
{
	FILE* fp;
		
	if ((fp=fopen(".\\Data\\config.cfg","rb"))!=NULL)
	{
		fscanf(fp,"%d%d%d%d%d",&m_Mode,&m_Width,&m_Height,&m_XPos,&m_YPos);
		fclose(fp);
	}
	
	m_Style = WS_SYSMENU|WS_CLIPCHILDREN|WS_CLIPSIBLINGS;
	WarpTrick = UNTRICK;
	m_TimeMouseClick = timeGetTime();
		
	FontHeader  = new CD3DFont( _T("Times New Roman"), 14, D3DFONT_BOLD );
	FontName    = new CD3DFont( _T("Times New Roman"), 17, D3DFONT_BOLD );
	m_XPosStats = 40;
	m_YPosStats = 100;
	m_XPosSave = (float)m_Width/2 - 150;
	m_YPosSave = (float)m_Height/2 - 150;
	m_XPosChat = 0;
	m_YPosChat = (float)m_Height - 30;
	m_WidthChat = 400;
	m_HeightChat = 30;
	m_WidthStats = 280;
	m_HeightStats = 400;
	m_ShowStats = FALSE;
	m_MouseClickOnScreen = FALSE;
	ToGame = FALSE;
}

BOOL CGame::Init()
{	
	Graphic.Create3D(GetWindowHandle());
	Graphic.UpdateScreen(m_Mode ,TRUE,m_Width,m_Height);
	Graphic.SetPerspective(D3DX_PI/4, 1.3333f, 1.0f, 20000.0f);
	ShowMouse(TRUE);

	Input.Init(GetWindowHandle(), GetInstanceHandle());
	m_Keyboard.Create(&Input, KEYBOARD,TRUE);
	m_Mouse.Create(&Input, MOUSE, TRUE);
	
	m_Sound.Init(GetWindowHandle());
	
	FontText.Create(&Graphic,"Arial",14,TRUE);
	FontHeader->InitDeviceObjects( Graphic.GetDevice() );
	FontName->InitDeviceObjects( Graphic.GetDevice() );
	FontHeader->RestoreDeviceObjects();
	FontName->RestoreDeviceObjects();

	Camera.Create(&Graphic);
	
	// 2D Screen
	LoadScreen();

	// Enable lighting and setup light
	Graphic.SetAmbientLight((char)150,(char)150,(char)150);
	Light.SetType(D3DLIGHT_POINT);
	Light.SetAttenuation0(0.5f);
	Light.SetDiffuseColor(255,255,255);
	Light.SetAmbientColor(255,255,255);
	Light.SetRange(1000.0f);
	Light.Move(0,0,5);
	Graphic.EnableLight(0, TRUE);

	// Dialog Init
	g_LoginDlg.Create(GetInstanceHandle(), IDD_DLGLOGIN, GetWindowHandle());

	//m_ChatDialog.ShowDialog(GetInstanceHandle(), IDD_CHAT, IDD_CHATMESSAGE, GetWindowHandle());

	// Process the startup script
	m_Script.SetData(this, &Graphic, &FontText, &m_Keyboard,   \
					   &m_CharController);
	
	m_StageGame.Init(&Graphic,".\\script\\MapFileScript.mfs");

	m_CharController.SetData(this);
	m_CharController.Init(&Graphic, &FontText, &m_StageGame  ,             \
      ".\\Script\\Character.mcl", m_SpellController.GetSpell(0),  \
      sizeof(g_CharMeshNames)/sizeof(char*), g_CharMeshNames, \
      ".\\Model\\", ".\\Texture\\Character\\",                \
      sizeof(g_CharAnimations) / sizeof(sCharAnimationInfo),  \
      (sCharAnimationInfo*)&g_CharAnimations,                 \
      &m_SpellController);

	// Initialize the spell controller
    m_SpellController.Init(&Graphic,                         \
      ".\\Script\\Spell.msl",                                 \
      sizeof(g_SpellMeshNames)/sizeof(char*),g_SpellMeshNames, \
      ".\\Model\\Spell\\", &m_CharController);

	FILE* fp1 = NULL,*fp2 = NULL;
	m_SoundData[0].Create();
	m_SoundData[0].LoadWAV(".\\Sound\\wav\\attack.wav",fp1);
	m_SoundData[1].Create();
	m_SoundData[1].LoadWAV(".\\Sound\\wav\\spell.wav",fp2);
	
	m_Channel[0].Create(&m_Sound, &m_SoundData[0]);
	m_Channel[1].Create(&m_Sound, &m_SoundData[1]);

	m_StateManager.Push(ShowMenuGame, this);
	
	g_Game = this;

  return TRUE;

}

BOOL CGame::Shutdown()
{

	// close  socket
	closesocket(m_Socket);

	// shutdown winsock
	WSACleanup();

	g_LoginDlg.Close();

	m_StateManager.PopAll(this);

	Graphic.Cleanup();
	FontText.Cleanup();

	FontHeader->DeleteDeviceObjects();
	FontName->DeleteDeviceObjects();
	SAFE_DELETE( FontHeader );
	SAFE_DELETE( FontName );

	m_Keyboard.Cleanup();
	m_Mouse.Cleanup();
	Input.Cleanup();
	m_CharController.Cleanup();
	m_SpellController.Cleanup();
	m_Script.Free();
	m_StageGame.Shutdown();

	m_SoundData[0].Free();
	m_SoundData[1].Free();
	m_Channel[0].Free();
	m_Channel[1].Free();
	m_Music.Stop();
	m_Music.Free();
	m_SoundAction.Stop();
	m_SoundAction.Free();
	m_Sound.Shutdown();

	m_VB_Bar.Cleanup();
	m_Bar.Cleanup();
	m_VB_Barback.Cleanup();
	m_Barback.Cleanup();
	m_VB_BarHP.Cleanup();
	m_BarHP.Cleanup();
	m_VB_BarMP.Cleanup();
	m_BarMP.Cleanup();
	m_VB_BarItem.Cleanup();
	m_BarItem.Cleanup();
	m_VB_Stats.Cleanup();
	m_Stats.Cleanup();
	m_VB_UpPoint.Cleanup();
	m_UpPoint.Cleanup();
	m_VB_Loading.Cleanup();
	m_Loading.Cleanup();
	m_VB_Save.Cleanup();
	m_Save.Cleanup();
	m_VB_SaveQuestion.Cleanup();
	m_SaveQuestion.Cleanup();

	return TRUE;
}

BOOL CGame::Frame()
{
	static DWORD UpdateCounter = timeGetTime();
	
	if(timeGetTime() < UpdateCounter + 30)
		return TRUE;

	dwFrameCount++;

	UpdateCounter = timeGetTime();

	// Read in keyboard
	m_Keyboard.Acquire(TRUE);
	m_Mouse.Acquire(TRUE);

		// Get input
	m_Keyboard.Read();
	m_Mouse.Read();

	// Check Mouse must not move out screen
	if (GetFocus()==GetWindowHandle())
		ClipMouse();
	else
		ClipCursor(NULL);
		
	return m_StateManager.Process(this);
}

void CGame::ShowGame(void *Ptr, long Purpose)
{
	CGame *App = (CGame*)Ptr;


	// Only process frame states
	if(Purpose != FRAMEPURPOSE)
		return;

	// Quit to Save screen if ESCAPE pressed
	if(App->m_Keyboard.GetKeyState(KEY_ESC) == TRUE) 
	{
		App->m_Keyboard.SetLock(KEY_ESC, TRUE);
		App->m_Keyboard.SetButtonState(KEY_ESC, FALSE);
		
		// Push Save state
		App->m_StateManager.Push(App->ShowSaveDlg, App);

		return;
	}

	if (!App->ToGame)
		return;

	sCharacter *CharPtr = App->m_CharController.GetCharacter(App->m_CharController.ID_PC);

	if (CharPtr == NULL) return;

	if(!CharPtr->Enabled)
	{
		// Pop to main menu state
		App->m_StateManager.Pop(App);
		return;
	}

	// Set Camera
	App->CameraMoveMent();

	//Update Position of PC
	App->m_CharController.Update(33,App->m_Channel,App->m_SoundData);
	//App->m_SpellController.Update(33);

	if (App->m_MouseClickOnScreen)
		App->UpdateScreenControl();

	if (App->m_ChatDialog.SendButtonPress())
	{
		App->m_ChatDialog.ClearSendPress();
		char msg[70],user[20];
		GetDlgItemText(App->m_ChatDialog.GethWndChat(), IDC_PLAYER, user, 20);
		GetDlgItemText(App->m_ChatDialog.GethWndChat(), IDC_EDITMESSAGE, msg, 70);
		if (strcmp(msg,"")!=0)
		{
			SetPacketChat(App->pkchat,3,1,App->m_CharController.GetCharacter(App->m_CharController.ID_PC)->ID,user,msg);

			send(App->GetServerSocket(),(char*)&App->pkchat,sizeof(sPacketChat),0);			
		}
		SetDlgItemText(App->m_ChatDialog.GethWndChat(), IDC_PLAYER, "");
		SetDlgItemText(App->m_ChatDialog.GethWndChat(), IDC_EDITMESSAGE, "");
	}

	App->Graphic.ClearScene(D3DCOLOR_RGBA(0,0,0,255));

// ------    RENDER GAME	------//

	if (App->Graphic.BeginScene())
	{
			App->Graphic.EnableZBuffer(TRUE);
			App->Graphic.EnableLighting(TRUE);

			//m_Effect.Render();
	// Render StageGame
			App->m_StageGame.GetSkybox()->Render(App->Camera.GetCamera());
			App->m_StageGame.Render();
			App->m_StageGame.GetMiniMap()->Render(&CharPtr->XPos , &CharPtr->ZPos, 0);
	// Render Character & Spell
			App->m_SpellController.Render();
			App->Graphic.EnableLighting(FALSE);
			App->m_CharController.Render();
	// Render 2D Screen 
			App->ScreenRender();

	// Check Game
		// Check Warp
			int id = App->m_StageGame.IsTriggTransport(CharPtr->XPos,CharPtr->YPos,CharPtr->ZPos);
			
			if(id >= 0 && App->WarpTrick == UNTRICK){
				App->WarpTrick = TRICKED;
				
				App->LoadingRender();

				App->SaveGame(".\\Data\\SaveGame.sav");
				App->LoadGame(".\\Data\\SaveGame.sav", App->m_StageGame.GetTransport(id)->stageId);
			}
			if (id < 0  && App->WarpTrick == TRICKED)
				App->WarpTrick = UNTRICK ;
			// Check Script Event
			id = App->m_CharController.CheckEvent();

			if (id >= 0)
			{
				App->m_Script.Execute(App->m_CharController.GetScript(id));

				CharPtr->TargetChar = NULL;
			}
	//End Render
			App->Graphic.EndScene();
			App->Graphic.Display();
	}
// ------    RENDER GAME	------//

	return;
}

void CGame::ShowMenuGame(void *Ptr, long Purpose)
{
	CGame *App = (CGame*)Ptr;
// Declare input
	static CWindow			m_Menu;

	// Initialize Menu
	if(Purpose == INITPURPOSE)
	{
		//m_Menu.Create(&App->Graphic);

		//m_Menu.CreatePicture(&App->Graphic, ".\\Texture\\TitleOnline.bmp");
		
		return;
	}

	// Shutdown resources used in menu
	if(Purpose == SHUTDOWNPURPOSE) {
		m_Menu.Cleanup();
	
		return;
	}

	if(App->m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
	{
		App->m_Keyboard.SetLock(KEY_ESC, TRUE);
		App->m_Keyboard.SetButtonState(KEY_ESC, FALSE);
		// Pop to main menu state
		App->m_StateManager.Pop(App);
	
		return;
	}
	
	if(App->m_Music.IsPlaying())
		App->m_Music.Stop();

	if(App->m_Channel[0].IsPlaying())
		App->m_Channel[0].Stop();
	if(App->m_Channel[1].IsPlaying())
		App->m_Channel[1].Stop();

	// Render Menu Game
	App->Graphic.ClearScene(D3DCOLOR_RGBA(0,0,0,255));
	if(App->Graphic.BeginScene() == TRUE) {
		
		App->Graphic.EnableZBuffer(FALSE);
		//m_Menu.MovePicture(0,0, App->m_Width,App->m_Height);
		//m_Menu.RenderPicture();
		if (g_LoginDlg.LoginButtonPress())
		{
			if (!App->ConnectServer("161.246.6.99",9999))
			{
				MessageBox(App->GetWindowHandle(),"Not Connect","test",MB_OK | MB_ICONEXCLAMATION);
				App->m_StateManager.PopAll(App);
				return ;
			}
			// ConnectToServer
			char Username[20];
			char Password[20];

			GetDlgItemText(g_LoginDlg.GethWnd(), IDC_USER, Username, 20);
			GetDlgItemText(g_LoginDlg.GethWnd(), IDC_PASSWD, Password, 20);

			if (!strcmp(Username,""))
			{
				MessageBox(App->GetWindowHandle(),"Please Fill ID.","test",MB_OK | MB_ICONEXCLAMATION);
				
				return;
			}
	//0		strcpy(Username,"woen");
	//		strcpy(Password,"woen");

			sPacketLogin pklogin;
			SetPacketLogin(pklogin,1,0,Username,Password);
			send(App->GetServerSocket(),(char*)&pklogin,sizeof(pklogin),0);
			g_LoginDlg.ClearLoginPress();
		}
		App->Graphic.EndScene();
	}
	App->Graphic.Display();

	return;
}

void CGame::ShowSaveDlg(void *Ptr, long Purpose)
{
	CGame *App = (CGame*)Ptr;

	// Quit to menu screen if ESCAPE pressed
	if(App->m_Keyboard.GetKeyState(KEY_ESC) == TRUE) 
	{
		App->m_Keyboard.SetLock(KEY_ESC, TRUE);
		App->m_Keyboard.SetButtonState(KEY_ESC, FALSE);
		
		// Push Save state
		App->m_StateManager.Pop(App);
		
		return;
	}

	if(App->m_Channel[0].IsPlaying())
		App->m_Channel[0].Stop();
	if(App->m_Channel[1].IsPlaying())
		App->m_Channel[1].Stop();

// Check Mouse Click
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient( App->GetWindowHandle(), &pt);
		
	if(App->m_Mouse.GetButtonState(MOUSE_LBUTTON)==TRUE)
	{	
		App->m_Mouse.SetLock(MOUSE_LBUTTON, TRUE);
		App->m_Mouse.SetButtonState(MOUSE_LBUTTON, FALSE);

		pt.x = App->m_Mouse.GetXPos();
		pt.y = App->m_Mouse.GetYPos();

		if( pt.x > App->m_XPosSave + 150 && pt.x < App->m_XPosSave + 217 && \
			pt.y > App->m_YPosSave + 250 && pt.y < App->m_YPosSave + 280)
		{
			//App->SaveGame(".\\Data\\SaveGame.sav");

			App->m_StateManager.PopAll(App);
			//App->m_StateManager.Push(App->ShowMenuGame, App);

			closesocket(App->m_Socket);
			
			return;
		}
		else if( pt.x > App->m_XPosSave + 217 && pt.x < App->m_XPosSave + 285 && \
			pt.y > App->m_YPosSave + 250 && pt.y < App->m_YPosSave + 280)
		{
			// Push Save state
			App->m_StateManager.Pop(App);

			return;
		}
	}

// Render Save Dialog
	App->Graphic.BeginScene();
	if (App->m_Save.IsLoaded()){
		App->Graphic.SetTexture(0,&App->m_Save);
		App->m_VB_Save.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	if (App->m_SaveQuestion.IsLoaded()){
		App->Graphic.SetTexture(0,&App->m_SaveQuestion);
		App->m_VB_SaveQuestion.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	App->FontName->DrawText( App->m_XPosSave+40, App->m_YPosSave+70, D3DCOLOR_ARGB(255,255,0,0), "Quit Game ?" );
	App->Graphic.EndScene();
	App->Graphic.Display();
	return;
}

BOOL CGame::SaveGame(char* filename)
{
	sCharacter *CharPtr;
	sCharacterItem itemsav[127];
	sCharacterStats stats;
	FILE *fp;
	int NumItem = 0;

	// Get pointer to character in list
	if((CharPtr = m_CharController.GetCharacter(m_CharController.ID_PC)) == NULL)
		return FALSE;

	// Open file
	if((fp=fopen(filename, "wb"))==NULL)
		return FALSE;

// Pick parameter to struct
	sItem* item = CharPtr->m_Inventory.GetItemParent();

	while (item != NULL)
	{
		itemsav[NumItem].ID = item->ID;
		itemsav[NumItem].ItemDef = item->ItemDef;
		itemsav[NumItem++].Count = item->Count;
		item = item->next;
	}
	strcpy(stats.Name,CharPtr->Name);
	stats.LV = CharPtr->Def.Level;
	stats.EXP = CharPtr->Def.Experience;
	stats.Points = CharPtr->Points;
	stats.HealPoints = CharPtr->HealthPoints;
	stats.ManaPoints = CharPtr->ManaPoints;

	stats.MaxHealPoints = CharPtr->Def.HealthPoints;
	stats.MaxManaPoints = CharPtr->Def.ManaPoints;
	stats.Str = CharPtr->Def.Attack;
	stats.Vit = CharPtr->Def.Defense;
	stats.Int = CharPtr->Def.Resistance;
	stats.MapID = m_StageGame.GetIdMapCurrent();
	stats.xPos = CharPtr->XPos;
	stats.zPos = CharPtr->ZPos;

	for (int i=0;i<256;i++)
		stats.Flag[i] = m_Script.GetFlag()[i];

	// Output character data
	fwrite(&stats, 1, sizeof(sCharacterStats),fp);
	fwrite(&NumItem, 1, sizeof(int),fp);
	for (i=0;i<NumItem;i++)
		fwrite(&itemsav[i], 1, sizeof(sCharacterItem), fp);
	
	// Close file
	fclose(fp);
	
	return TRUE;
}

BOOL CGame::LoadGame(char* filename, int MapID)
{
	sCharacter *CharPtr;
	sCharacterItem itemsav[100];
	sCharacterStats stats;
	sItem item;
	FILE *fp;
	int NumItem = 0;
	char szTemp[256];

	// Open file
	if((fp=fopen(filename, "rb"))==NULL)
		return FALSE;

	// Input character data
	fread(&stats, 1, sizeof(sCharacterStats),fp);
	sprintf(szTemp,".\\script\\stage\\stage%d.scp", (MapID >= 0?MapID:stats.MapID));
	m_Script.Execute(szTemp);

	CharPtr = m_CharController.GetCharacter(m_CharController.ID_PC);

	strcpy(CharPtr->Name, stats.Name);
	CharPtr->Def.Level = stats.LV;
	CharPtr->Def.Experience = stats.EXP;
	CharPtr->Points = stats.Points;
	CharPtr->HealthPoints = stats.HealPoints;
	CharPtr->ManaPoints = stats.ManaPoints;

	CharPtr->Def.HealthPoints = stats.MaxHealPoints;
	CharPtr->Def.ManaPoints = stats.MaxManaPoints;
	CharPtr->Def.Attack = stats.Str;
	CharPtr->Def.Defense = stats.Vit;
	CharPtr->Def.Resistance = stats.Int;
	if(MapID < 0)
	{
		CharPtr->XPos = stats.xPos;
		CharPtr->ZPos = stats.zPos;
	}

	// Set item to Hero
	//CharPtr->m_Inventory.ClearAllItem();
	fread(&NumItem, 1, sizeof(int),fp);
	for (int i=0;i<NumItem;i++)
	{
		fread(&itemsav[i], 1, sizeof(sCharacterItem), fp);
		CharPtr->m_Inventory.AddItem(itemsav[i].ItemDef, itemsav[i].Count);
	}

	// Set Event
	m_Script.SetFlag(stats.Flag);

	// Close file
	fclose(fp);

	return TRUE;
}

BOOL CGame::UpdateScreenControl()
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient( GetWindowHandle(), &pt);

	m_MouseClickOnScreen = FALSE;

	sCharacter *CharPtr = m_CharController.GetCharacter(m_CharController.ID_PC);

	if (CharPtr->Points > 0)
	{
		long hp = 0;
		long mp = 0;
		if (pt.x >= m_XPosStats+180 && pt.x <= m_XPosStats+200 &&\
			pt.y >= m_YPosStats+208 && pt.y <= m_YPosStats+226)
		{


			
			/*CharPtr->Points--;
			CharPtr->Def.Attack++;
			hp = CharPtr->Def.Attack*20 + CharPtr->Def.Defense*10;
			CharPtr->HealthPoints += hp - CharPtr->Def.HealthPoints;
			CharPtr->Def.HealthPoints = hp;
			*/
		}else if (pt.x >= m_XPosStats+180 && pt.x <= m_XPosStats+200 &&\
			pt.y >= m_YPosStats+228 && pt.y <= m_YPosStats+246)
		{
			/*
			CharPtr->Points--;
			CharPtr->Def.Defense++;
			hp = CharPtr->Def.Attack*20 + CharPtr->Def.Defense*10;
			CharPtr->HealthPoints += hp - CharPtr->Def.HealthPoints;
			CharPtr->Def.HealthPoints = hp;
			*/
		}else if (pt.x >= m_XPosStats+180 && pt.x <= m_XPosStats+200 &&\
			pt.y >= m_YPosStats+248 && pt.y <= m_YPosStats+266)
		{
			/*
			CharPtr->Points--;
			CharPtr->Def.Resistance++;
			mp = CharPtr->Def.Resistance*5;
			CharPtr->ManaPoints += mp - CharPtr->Def.ManaPoints;
			CharPtr->Def.ManaPoints = mp;
			*/
		}
	}

	return TRUE;
}

BOOL CGame::LoadingRender()
{
	Graphic.BeginScene();
	if (m_Loading.IsLoaded()){
		Graphic.SetTexture(0,&m_Loading);
		m_VB_Loading.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	Graphic.EndScene();
	Graphic.Display();	

	return TRUE;
}

BOOL CGame::LoadScreen()
{
	
	CUSTOMVERTEX	Bar[] ={	
		{ (float)(m_Width-325) , (float)(m_Height-40) , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { (float)(m_Width-325) , (float)(m_Height-64) , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { (float)(m_Width-25) , (float)(m_Height-40) , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { (float)(m_Width-25) , (float)(m_Height-64) , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX	Bar_Background[] ={	
		{ (float)(m_Width-325+6) , (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { (float)(m_Width-325+6) , (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { (float)(m_Width-25-6) , (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { (float)(m_Width-25-6) , (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX	Bar_Item[] ={	
		{ (float)(m_Width-295) , (float)(m_Height-10) , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { (float)(m_Width-295) , (float)(m_Height-34) , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { (float)(m_Width-50) , (float)(m_Height-10) , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { (float)(m_Width-50) , (float)(m_Height-34) , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX    Stat[] = {
		{ m_XPosStats			   , m_YPosStats+m_HeightStats , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { m_XPosStats			   , m_YPosStats     , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { m_XPosStats+m_WidthStats , m_YPosStats+m_HeightStats , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { m_XPosStats+m_WidthStats , m_YPosStats     , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	
	CUSTOMVERTEX    UpPt[] = {
		{ m_XPosStats+180 , m_YPosStats+266 , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { m_XPosStats+180 , m_YPosStats+208 , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { m_XPosStats+200 , m_YPosStats+266 , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { m_XPosStats+200 , m_YPosStats+208 , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX    Loading[] = {
		{ 0 , (float)m_Height , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { 0 , 0 , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { (float)m_Width , (float)m_Height , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { (float)m_Width , 0 , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX    Save[] = {
		{ m_XPosSave , m_YPosSave + 300		, 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { m_XPosSave , m_YPosSave			, 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { m_XPosSave +300 , m_YPosSave +300 , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { m_XPosSave +300 , m_YPosSave		, 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	CUSTOMVERTEX    SaveQ[] = {
		{ m_XPosSave +150 , m_YPosSave +280 , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
        { m_XPosSave +150 , m_YPosSave +250 , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
        { m_XPosSave +285 , m_YPosSave +280 , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
        { m_XPosSave +285 , m_YPosSave +250	, 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
    };
	if (m_VB_Bar.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_Bar.Set(0,4,(void*)&Bar);
		m_Bar.Load(&Graphic,"Texture\\Screen\\bar.png");
	}
	if (m_VB_Barback.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_Barback.Set(0,4,(void*)&Bar_Background);
		m_Barback.Load(&Graphic,"Texture\\Screen\\bar_background.png");
	}
	if (m_VB_BarHP.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_BarHP.Load(&Graphic,"Texture\\Screen\\bar_hp.png");
	}
	if (m_VB_BarMP.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_BarMP.Load(&Graphic,"Texture\\Screen\\bar_mp.png");
	}
	if (m_VB_BarItem.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_BarItem.Set(0,4,(void*)&Bar_Item);
		m_BarItem.Load(&Graphic,"Texture\\Screen\\bar_item.png");
	}
	if (m_VB_Stats.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_Stats.Set(0,4,(void*)&Stat);
		m_Stats.Load(&Graphic,"Texture\\dialog.png");
	}
	/*if (m_VB_UpPoint.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_UpPoint.Set(0,4,(void*)&UpPt);
		m_UpPoint.Load(&Graphic,"Texture\\Uppoint.png");
	}*/
	if (m_VB_Loading.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_Loading.Set(0,4,(void*)&Loading);
		m_Loading.Load(&Graphic,"Texture\\loading.bmp");
	}
	if (m_VB_Save.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_Save.Set(0,4,(void*)&Save);
		m_Save.Load(&Graphic,"Texture\\dialog.png");
	}
	if (m_VB_SaveQuestion.Create(&Graphic,4,D3DFVF_CUSTOMVERTEX,sizeof(CUSTOMVERTEX))){
		m_VB_SaveQuestion.Set(0,4,(void*)&SaveQ);
		m_SaveQuestion.Load(&Graphic,"Texture\\Question.png");
	}

	return TRUE;
}

BOOL CGame::ScreenRender()
{
	char Stats[500];
	sCharacter *CharPtr = m_CharController.GetCharacter(m_CharController.ID_PC);

	// Calculator Stats
	float Dec_MP = float((CharPtr->Def.ManaPoints - CharPtr->ManaPoints)*138/CharPtr->Def.ManaPoints);
	CUSTOMVERTEX	Bar_MP[] ={	
		{ (float)(m_Width-325+6) + Dec_MP, (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
		{ (float)(m_Width-325+6) + Dec_MP, (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
		{ (float)(m_Width-325+6+138), (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
		{ (float)(m_Width-325+6+138), (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
	};
	if (m_VB_BarMP.IsLoaded())
		m_VB_BarMP.Set(0,4,(void*)&Bar_MP);
	float Dec_HP = float((CharPtr->Def.HealthPoints - CharPtr->HealthPoints)*138/CharPtr->Def.HealthPoints);
	CUSTOMVERTEX	Bar_HP[] ={	
		{ (float)(m_Width-325+6+150) , (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 0.0f, 1.0f}, // Bottom-Left
		{ (float)(m_Width-325+6+150) , (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 0.0f, 0.0f}, // Top-Left
		{ (float)(m_Width-25-6)-Dec_HP , (float)(m_Height-40-5) , 0.0f, 1.0f, 0xffffffff, 1.0f, 1.0f}, // Bottom-Right
		{ (float)(m_Width-25-6)-Dec_HP , (float)(m_Height-64+4) , 0.0f, 1.0f, 0xffffffff, 1.0f, 0.0f} // Top-Right
	};
	if (m_VB_BarHP.IsLoaded())
		m_VB_BarHP.Set(0,4,(void*)&Bar_HP);
// Display stats
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_GAUSSIANCUBIC );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_GAUSSIANCUBIC );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP );
	Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP );

	if (m_Barback.IsLoaded()){
		Graphic.SetTexture(0,&m_Barback);
		m_VB_Barback.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	if (m_BarMP.IsLoaded()){
		Graphic.SetTexture(0,&m_BarMP);
		m_VB_BarMP.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	if (m_BarHP.IsLoaded()){
		Graphic.SetTexture(0,&m_BarHP);
		m_VB_BarHP.Render(0,2,D3DPT_TRIANGLESTRIP);
	}
	/*if (m_BarItem.IsLoaded()){
		Graphic.SetTexture(0,&m_BarItem);
		m_VB_BarItem.Render(0,2,D3DPT_TRIANGLESTRIP);
	// Render Amount Item
		sprintf(Stats,"%d",CharPtr->m_Inventory.FindItem(0)->Count);
		FontText.Print(Stats,m_Width-293,m_Height-34);
		sprintf(Stats,"%d",CharPtr->m_Inventory.FindItem(1)->Count);
		FontText.Print(Stats,m_Width-264,m_Height-34);
		sprintf(Stats,"%d",CharPtr->m_Inventory.FindItem(2)->Count);
		FontText.Print(Stats,m_Width-235,m_Height-34);
	}*/
	if (m_Bar.IsLoaded()){
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_MINFILTER, D3DTEXF_GAUSSIANCUBIC );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_MAGFILTER, D3DTEXF_GAUSSIANCUBIC );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP );
		Graphic.GetDevice()->SetTextureStageState( 0, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP );

		Graphic.SetTexture(0,&m_Bar);
		m_VB_Bar.Render(0,2,D3DPT_TRIANGLESTRIP);
	}

// Show Hero Stats
	if (m_ShowStats)
	{
		if (m_Stats.IsLoaded()){
			Graphic.SetTexture(0,&m_Stats);
			m_VB_Stats.Render(0,2,D3DPT_TRIANGLESTRIP);
		}
	
		if (CharPtr->Points != 0)
		{
			if (m_UpPoint.IsLoaded()){
				Graphic.SetTexture(0,&m_UpPoint);
				m_VB_UpPoint.Render(0,2,D3DPT_TRIANGLESTRIP);
			}
		}
		sprintf( Stats, "\n\n  LV\t: \n  EXP\t: \n\n  HP\t: \n  MP\t: \n  \
						STR\t: \n  VIT\t: \n  INT\t: \n");
		FontHeader->DrawText( m_XPosStats+40, m_YPosStats+50, 0xfff0e119, Stats );
		
		sprintf( Stats, "        %s\n",CharPtr->Name);
		FontName->DrawText( m_XPosStats+40, m_YPosStats+50, D3DCOLOR_ARGB(255,255,128,0), Stats );
		
		sprintf( Stats, "\n\
						 \n               %d\n               %d  /  %d\n\n               %d  /  %d\n               %d  /  %d\
						 \n               %d\n               %d\n               %d\n",				\
						 CharPtr->Def.Level,CharPtr->Def.Experience,m_CharController.CalculateNextLV(CharPtr->Def.Level),	\
						 CharPtr->HealthPoints,CharPtr->Def.HealthPoints,CharPtr->ManaPoints,\
						 CharPtr->Def.ManaPoints,CharPtr->Def.Attack,CharPtr->Def.Defense,\
						 CharPtr->Def.Resistance);
		FontHeader->DrawText( m_XPosStats+40, m_YPosStats+50, D3DCOLOR_ARGB(255,255,255,255), Stats );

		/*sprintf( Stats, "\n\n\n\n\n\n\n\n\n\n          Point(s)       %d",CharPtr->Points);
		FontHeader->DrawText( m_XPosStats+40, m_YPosStats+50, D3DCOLOR_ARGB(255,255,255,0), Stats );
	*/
	}
	// Render Font
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient( GetWindowHandle(), &pt);

	sprintf(Stats,"FPS : %d",iFrameRate);
	FontText.Print(Stats,10,10);
	/*sprintf(Stats,"XPos : %d",pt.x);
	FontText.Print(Stats,650,525);
	sprintf(Stats,"YPos : %d",pt.y);
	FontText.Print(Stats,650,550);
	/*sprintf(Stats,"X = %f", m_MouseClickPos.x);
	Font.Print(Stats,Graphic.GetWidth()-150,Graphic.GetHeight()-75);
	sprintf(Stats,"Y = %f", m_MouseClickPos.y);
	Font.Print(Stats,Graphic.GetWidth()-150,Graphic.GetHeight()-50);
	sprintf(Stats,"Z = %f", m_MouseClickPos.z);
	Font.Print(Stats,Graphic.GetWidth()-150,Graphic.GetHeight()-25);
	/*sprintf(Stats,"XMap = %f", m_DestMap.x);
	Font.Print(Stats,10,Graphic.GetHeight()-50);
	sprintf(Stats,"ZMap = %f", m_DestMap.y);
	Font.Print(Stats,300,Graphic.GetHeight()-25);
	sprintf(Stats,"XPOS = %f", m_CharController.GetCharacter(0)->XPos);
	Font.Print(Stats,300,Graphic.GetHeight()-50);
	sprintf(Stats,"ZPOS = %f", m_CharController.GetCharacter(0)->ZPos);
	Font.Print(Stats,300,Graphic.GetHeight()-25);*/
	/*sprintf(Stats,"MOVE = %c", m_Land.GetValueMap(m_DestMap.x,m_DestMap.y));
	Font.Print(Stats,100,10);
	sprintf(Stats,"Zeta = %i",  Camera.GetZeta());
	Font.Print(Stats,300,10);
	sprintf(Stats,"Lenght = %f", Camera.GetLength());
	Font.Print(Stats,300,35);*/

	return TRUE;
}
BOOL CGame::CameraMoveMent()
{
	sCharacter	*PC = m_CharController.GetCharacter(m_CharController.ID_PC);

	float Length;
	int	  Zeta;

	Camera.RelateTo(PC->XPos,PC->YPos,PC->ZPos);
	Camera.Update();

	Length	= Camera.GetLength();
	Zeta	= Camera.GetZeta();

	Graphic.SetCamera(Camera.GetCamera());

	Camera.SetLength(Length);
	Camera.SetZeta(Zeta);

	return TRUE;
}

BOOL CGame::ClipMouse()
{
	POINT Point;
	Point.x = 0;
	Point.y = 0;
	ClientToScreen(GetWindowHandle(), &Point);

	RECT rect;
	rect.left = Point.x;
	rect.top = Point.y;
	rect.right = Point.x + m_Width;
	rect.bottom = Point.y + m_Height;

	ClipCursor(&rect);
	
	return TRUE;
}

BOOL CGame::CheckIntersect(  sMesh* MeshPtr  ,              \
                 float XStart, float YStart, float ZStart,    \
                 float XEnd,   float YEnd,   float ZEnd, float* Dist)
{
	// Start with parent mesh
	if(MeshPtr == NULL)
		return FALSE;  // No polygons hit

	BOOL  bHit;
	float u, v;
	float XDiff, YDiff, ZDiff, Size;
	DWORD FaceIndex;
	D3DXVECTOR3 vecDir;

	// Calculate ray
	XDiff = XEnd - XStart;
	YDiff = YEnd - YStart;
	ZDiff = ZEnd - ZStart;
	Size  = (float)sqrt(XDiff*XDiff+YDiff*YDiff+ZDiff*ZDiff);
	D3DXVec3Normalize(&vecDir, &D3DXVECTOR3(XDiff, YDiff, ZDiff));

	// Go through each mesh looking for intersection
	while(MeshPtr != NULL) {
	D3DXIntersect(MeshPtr->m_Mesh,                            \
				&D3DXVECTOR3(XStart,YStart,ZStart), &vecDir,  \
				&bHit, &FaceIndex, &u, &v, Dist,NULL,NULL);

	if(bHit == TRUE) {
	  if(*Dist < Size)
		return TRUE;  // Hit a polygon
	}

	MeshPtr = MeshPtr->m_Next;
	}

	return FALSE;  // No polygons hit
}

BOOL CGame::CheckMouseClickOnScreen()
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient( GetWindowHandle(), &pt);

	if (m_ShowStats)
	{
		if (pt.x >= m_XPosStats && pt.x <= m_XPosStats+m_WidthStats && \
			pt.y >= m_YPosStats && pt.y <= m_YPosStats+m_HeightStats)
		{
			m_MouseClickOnScreen = TRUE;
			return TRUE;
		}
	}

	if (pt.x >= m_XPosChat && pt.x <= m_XPosChat+m_WidthChat && \
			pt.y >= m_YPosChat && pt.y <= m_YPosChat+m_HeightChat)
	{
		m_MouseClickOnScreen = TRUE;
		return TRUE;
	}
	
	m_MouseClickOnScreen = FALSE;
	return FALSE;
}

long CGame::CheckInput()
{
	long Action = 0;
	
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON)==TRUE && (timeGetTime() > m_TimeMouseClick+200)) 
	{
		Action |= 1;
		m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
		m_TimeMouseClick = timeGetTime();
	}

	if(m_Mouse.GetButtonState(MOUSE_RBUTTON)==TRUE) 
		Action |= 2;

	/*if(m_Keyboard.GetKeyState(KEY_F1) == TRUE && (timeGetTime() > m_TimeMouseClick+300)) 
	{
		Action |= 4;
		m_TimeMouseClick = timeGetTime();
	}

	if(m_Keyboard.GetKeyState(KEY_F2) == TRUE && (timeGetTime() > m_TimeMouseClick+300)) 
	{
		Action |= 8;
		m_TimeMouseClick = timeGetTime();
	}

	if(m_Keyboard.GetKeyState(KEY_F3) == TRUE && (timeGetTime() > m_TimeMouseClick+300)) 
	{
		Action |= 16;
		m_TimeMouseClick = timeGetTime();
	}

	if(m_Keyboard.GetKeyState(KEY_1) == TRUE)
	{
		Action |= 32;
	}
*/
	if(m_Keyboard.GetKeyState(KEY_F1) == TRUE && (timeGetTime() > m_TimeMouseClick+200))
	{
		m_ShowStats = !m_ShowStats;
		if (m_ShowStats)
		{
			sPacketGetStatus pkstatus;
			pkstatus.type = 4;
			pkstatus.action = 1;
			SendPacket((char*)&pkstatus,sizeof(sPacketGetStatus));
		}
		m_TimeMouseClick = timeGetTime();
	}
	
	return Action;
	
}

BOOL CGame::ConnectServer(char* IP,int Port)
{
	WSADATA w;
	char txtbuffer[200];

	int error = WSAStartup (0x0202,&w);
	if (error)
	{
		MessageBox (GetWindowHandle(),"Error: You need WinSock 2.2!","Error",MB_OK);
		PostQuitMessage (0);
		return FALSE;
	}
	if (w.wVersion!=0x0202)
	{
		MessageBox (GetWindowHandle(),"Error:  Wrong WinSock version!","Error",MB_OK);
		PostQuitMessage (0);
		WSACleanup ();
		return FALSE;
	}

	m_Socket = socket (AF_INET,SOCK_STREAM,0); // create socket

	WSAAsyncSelect (m_Socket,GetWindowHandle(),WM_SOCKET,(FD_CLOSE | FD_CONNECT | FD_READ));

	char a[16];
	sprintf (a,"%s",IP);

	struct hostent *host_entry;

	// setup the host entry
	if ((host_entry = gethostbyname(a)) == NULL) {
		MsgError("Error!!");
	}

	// connect to server
	m_Addr.sin_family = AF_INET;
	m_Addr.sin_port = htons (Port);
	m_Addr.sin_addr.s_addr = *(unsigned long*) host_entry->h_addr;

	if (connect(m_Socket,(LPSOCKADDR)&m_Addr,sizeof(m_Addr))==SOCKET_ERROR)
	{
 		if (WSAGetLastError()==WSAEWOULDBLOCK)
		{
			Sleep (750);
			connect(m_Socket, (LPSOCKADDR)&m_Addr,sizeof(m_Addr));
		}
		sprintf (txtbuffer,"Error: %d",WSAGetLastError());
		//MsgError("Error!!!");
	//	return 0;
	}

	return TRUE;
}

BOOL CGame::SendPacket(char* msg,int len)
{
	send(m_Socket,msg,len,0);
	return TRUE;
}

UINT ProcAddUserThread(LPVOID pParam)
{
	sPacketCreateSpawnPlayer* packetChar = (sPacketCreateSpawnPlayer*)pParam;
	
	g_Game->AddCharacter(packetChar->ID,packetChar->name,(float)packetChar->xpos*20+10,(float)packetChar->zpos*20+10,packetChar->direction);

	SAFE_DELETE(packetChar);
	
	return 0;
}

BOOL CGame::CheckPacket(char* buf)
{
	FILE* fp;
	sCharacter* CharPtr;
	D3DXVECTOR2 CharMapPos;
	D3DXVECTOR2 DestMap;
	sPacket* packet = (sPacket*)buf;
		
	switch(packet->type)
	{
	case 1 :
		switch(packet->action)
		{
		case 0 : // Check Login
			memcpy(&pklogin,buf,sizeof(sPacketLogin));
			if(!strcmp(pklogin.user,"pass"))
			{
				//MessageBox(GetWindowHandle(),"Correct","test",MB_OK | MB_ICONEXCLAMATION);
				g_LoginDlg.Close();

				LoadingRender();		// Loading Screen
				m_Script.ClearFlag();
				m_Script.Execute(".\\Script\\Stage\\stage1.scp"); // Run Script
				
				m_StateManager.Push(ShowGame, this);

				m_ChatDialog.ShowDialog(GetInstanceHandle(), IDD_CHAT, IDD_CHATMESSAGE, GetWindowHandle());
			}else 
				MessageBox(GetWindowHandle(),"Not Correct","test",MB_OK | MB_ICONEXCLAMATION);
			break;
		case 1 : // Add PC Character
					
			pkCreatePly = new sPacketCreateSpawnPlayer;
			memcpy(pkCreatePly,buf,sizeof(sPacketCreateSpawnPlayer));

			fp=fopen("woen.txt", "a");
			fprintf(fp,"PC ID %d\n",pkCreatePly->ID);
			fclose(fp);

			m_CharController.ID_PC = pkCreatePly->ID;
			m_ThreadHandle = CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ProcAddUserThread,(void *)pkCreatePly, NULL, NULL);
			CloseHandle(m_ThreadHandle);

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
			
			break;
		case 2 : // Add Other Character
			
			pkCreatePly = new sPacketCreateSpawnPlayer;
			memcpy(pkCreatePly,buf,sizeof(sPacketCreateSpawnPlayer));

			fp=fopen("woen.txt", "a");
			fprintf(fp,"USER ID %d\n",pkCreatePly->ID);
			fclose(fp);

			m_ThreadHandle = CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ProcAddUserThread, (void *)pkCreatePly, NULL, NULL);
			CloseHandle(m_ThreadHandle);

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));

			break;
		case 3 : // Add Monster
			
			memcpy(&pkCreateMon,buf,sizeof(sPacketCreateMonster));
			
			fp=fopen("woen.txt", "a");
			fprintf(fp,"%d\n",pkCreateMon.ID);
			fclose(fp);

			CharPtr = m_CharController.GetCharacter(pkCreateMon.ID);

			CharPtr->XPos = (float)pkCreateMon.xpos*20+10;
			CharPtr->ZPos = (float)pkCreateMon.zpos*20+10;

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
			break;
		case 4 : // Get Character
			
			break;
		case 9 :  // ready to run Game
			ToGame = TRUE;

			pkready.type = 1;
			pkready.action = 9;
			SendPacket((char*)&pkready,sizeof(sPacketReady));

			break;
		
		}break;
	case 2 : 
		if (!ToGame) break;
		switch(packet->action)
		{
		case 1 : // Move to Destination
			memcpy(&pk,buf,sizeof(sPacketWalk));

			CharPtr = m_CharController.GetCharacter(pk.ID);

			if (CharPtr == NULL) 
				return TRUE;

			CharPtr->FreePath();
			CharPtr->Action = CHAR_IDLE;

			CharPtr->TargetChar = NULL;

			CharPtr->Victim = NULL;

			if (CharPtr->XPos/20 != pk.xpos || CharPtr->ZPos/20 != pk.zpos)
			{
				CharPtr->XPos = (float)pk.xpos*20+10;

				CharPtr->ZPos = (float)pk.zpos*20+10;
			}

			//Calculate Shortest Path
			CharPtr->Direction = pk.direction;
			CharMapPos		= m_StageGame.GetTerrain()->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);
			DestMap			= m_StageGame.GetTerrain()->GetMapPosition((float)pk.xdest*20,(float)pk.zdest*20);

			m_CharController.RoutePath(CharPtr,CharMapPos,DestMap);

			if (CharPtr->NumPoints != 0)
			{
				CharPtr->XDestPos = CharPtr->Route[CharPtr->NumPoints-1].XPos;
				CharPtr->ZDestPos = CharPtr->Route[CharPtr->NumPoints-1].ZPos;
				CharPtr->AI = CHAR_ROUTE;
			}
			break;
		case 2 : // Set Attack Character
			memcpy(&pkchar,buf,sizeof(sPacketToChar));
			CharPtr = m_CharController.GetCharacter(pkchar.IDVictim);

			if (CharPtr == NULL) 
			{
				pkget.type = 1;
				pkget.action = 4;
				SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
				return TRUE;
			}

			m_CharController.GetCharacter(pkchar.IDAttacker)->Victim = CharPtr;
			CharPtr->Attacker = m_CharController.GetCharacter(pkchar.IDAttacker);
			m_CharController.SetAction(CharPtr->Attacker, CHAR_ATTACK);

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
			break;
		case 3 : // Set Message To Character
			memcpy(&pkmsg,buf,sizeof(sPacketMessage));
			CharPtr = m_CharController.GetCharacter(pkmsg.ID);

			if (CharPtr == NULL) 
				return TRUE;

			m_CharController.SetMessage(CharPtr,pkmsg.text,pkmsg.timer,pkmsg.color);

			break;
		case 6:  // Update Character
			
			memcpy(&pkupdate,buf,sizeof(sPacketUpdateSpawnPlayer));

			CharPtr = m_CharController.GetCharacter(pkupdate.ID);

			if (CharPtr == NULL) 
			{
				pkget.type = 1;
				pkget.action = 4;
				SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
				m_CharController.SetAction(CharPtr,pkupdatemon.act,pkupdatemon.time);
				return TRUE;
			}

			CharPtr->XPos = (float)pkupdate.xpos*20+10;
			CharPtr->ZPos = (float)pkupdate.zpos*20+10;
			CharPtr->Direction = pkupdate.direction;
			CharPtr->Action = pkupdate.act;
			CharPtr->AI = pkupdate.ai;

			m_CharController.SetAction(CharPtr,pkupdate.act,pkupdate.time);

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
			
			break;
		case 7 : // Update Monster
			memcpy(&pkupdatemon,buf,sizeof(sPacketUpdateMonster));

			CharPtr = m_CharController.GetCharacter(pkupdatemon.ID);

			if (CharPtr == NULL) 
			{
				pkget.type = 1;
				pkget.action = 4;
				SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
				m_CharController.SetAction(CharPtr,pkupdatemon.act,pkupdatemon.time);
				return TRUE;
			}

			CharPtr->XPos = (float)pkupdatemon.xpos*20+10;
			CharPtr->ZPos = (float)pkupdatemon.zpos*20+10;
			CharPtr->Direction = pkupdatemon.direction;
			CharPtr->Action = pkupdatemon.act;
			CharPtr->AI = pkupdatemon.ai;

			if (CharPtr->Action == CHAR_DIE)
			{
				sCharacter* Char = m_CharController.GetParentCharacter();
				while(Char!=NULL)
				{
					if (Char->Victim != NULL)
						if (Char->Victim->ID == CharPtr->ID)
						{
							Char->AI = CHAR_WANDER;
							Char->Action = CHAR_IDLE;
							break;
						}
					Char = Char->Next;
				}
								
				pkget.type = 1;
				pkget.action = 4;
				SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));
				m_CharController.SetAction(CharPtr,pkupdatemon.act,pkupdatemon.time);
			}		

			m_CharController.SetAction(CharPtr,pkupdatemon.act,pkupdatemon.time);
			
			break;
		case 8 : // Remove Character
			memcpy(&pkrm,buf,sizeof(sPacketRemoveSpawnPlayer));

			m_CharController.Remove(pkrm.ID);
			
			break;
		case 9 : // Reborn Monster
			memcpy(&pkreb,buf,sizeof(sPacketRebornMonster));

			CharPtr = m_CharController.GetCharacter(pkreb.ID);

			pkget.type = 1;
			pkget.action = 4;
			SendPacket((char*)&pkget,sizeof(sPacketGetCharacter));

			if (CharPtr == NULL) 
				return TRUE;

			CharPtr->Enabled = TRUE;
			CharPtr->Action = CHAR_IDLE;
			CharPtr->Attacker = NULL;
			CharPtr->Victim = NULL;
			CharPtr->AI = CHAR_WANDER;
			CharPtr->Distance = 0;
			CharPtr->TargetChar = NULL;
			
			break;
		}
		break;
	case 3 :
		if (!ToGame) break;
		switch(packet->action)
		{
		case 1 : // Chat Message
			memcpy(&pkchat,buf,sizeof(sPacketChat));

			char text[128];
			CharPtr = m_CharController.GetCharacter(pkchat.ID);
			sprintf(text,"%s : %s",CharPtr->Name,pkchat.msg);
			m_ChatDialog.AddMessage(text);

			sprintf(text,"Say : %s",pkchat.msg);
			m_CharController.SetMessageChat(CharPtr,text,2000);

			break;
		}
		break;
	case 4 :
		if (!ToGame) break;
		switch(packet->action)
		{
		case 1 :
			memcpy(&pkply,buf,sizeof(sPacketPlayer));

			CharPtr = m_CharController.GetCharacter(m_CharController.ID_PC);
			strcpy(CharPtr->Name,pkply.name); 
			CharPtr->HealthPoints = pkply.HP;
			CharPtr->Def.HealthPoints = pkply.HPMAX;
			CharPtr->ManaPoints = pkply.MP;
			CharPtr->Def.ManaPoints = pkply.MPMAX;
			CharPtr->Def.Experience = pkply.EXP;
			CharPtr->Def.Level = pkply.Level;
			CharPtr->Def.Attack = pkply.STR;
			CharPtr->Def.Defense = pkply.VIT;
			CharPtr->Def.Resistance = pkply.INT;
			CharPtr->Points = pkply.Point;
			break;
		}
		break;
	}

	return TRUE;
}

BOOL CGame::AddCharacter(int id,char* name, float xpos, float zpos, float direction)
{
	if (id == m_CharController.ID_PC)
		m_CharController.Add(id,name,0,CHAR_PC,CHAR_STAND,xpos,0,zpos,direction);
	else 
		m_CharController.Add(id,name,0,CHAR_USER,CHAR_STAND,xpos,0,zpos,direction);

	return TRUE;
}

LRESULT CALLBACK CGame::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char txtbuffer[1000];
	switch(uMsg) {
		case WM_DESTROY:
				PostQuitMessage(0);
		break;

		case WM_SOCKET:
		
			if (WSAGETSELECTERROR(lParam))
			{	// error!
				sprintf (txtbuffer,"Error2: %d",WSAGetLastError());
				//MessageBox (GetWindowHandle(),txtbuffer,"Error",MB_OK);
				PostQuitMessage (0);
				return 0;
			}
			switch (WSAGETSELECTEVENT(lParam)){
				case FD_CONNECT:
					break;
				case FD_READ:
					char buffer[1000];
					recv (m_Socket,buffer,1000,0);
					CheckPacket(buffer);
					break;
			}
		break;		
    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;
}