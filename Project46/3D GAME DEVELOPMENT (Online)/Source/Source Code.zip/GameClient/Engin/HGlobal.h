#ifndef _HGLOBAL_H
#define _HGLOBAL_H

// Windows includes
#include <windows.h>
#include <windowsx.h>

// Standard ANSI-C includes
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <resource.h>
#include "Global_Func.h"

// DirectX includes
#include "d3d8.h"
#include "d3dx8.h"
#include "dmusici.h"
#include "dsound.h"
#include "dplay8.h"
#include "dpaddr.h"
#include "dinput.h"
#include "D3d8types.h"
#include "D3dx8math.h"
#include "d3dx8tex.h"

// Winsock
#pragma comment(lib,"wsock32.lib")

// Define Library
#pragma comment(lib,"d3d8.lib")
#pragma comment(lib,"d3dx8.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"dxerr8.lib")
#pragma comment(lib,"d3dxof.lib")
#pragma comment(lib,"winmm.lib")

// Macro Define
#define MsgError(x) MessageBox(NULL, x, "Error", MB_OK | MB_ICONEXCLAMATION);
#define ReleaseCOM(x) if(x) { x->Release(); x = NULL; }
#define SAFE_DELETE(x)       { if(x) { delete (x);     (x)=NULL; } }
#define SAFE_DELETE_ARRAY(x) { if(x) { delete[] (x);   (x)=NULL; } }
#define SAFE_RELEASE(x)      { if(x) { (x)->Release(); (x)=NULL; } }

// Enumerated Screen Type
enum Screen{FULLSCREEN=0,WINDOW};

// Enumerated Game Type
enum TypeTrick{TRICKED=0,UNTRICK};
enum Stage{Start=0,OnGame,Continue,GameOver,Quit};
//***********************
enum TypeItem{HEALING=0,WEAPON,ARMOR,MAGIC,GOLD};
enum TypeEvent{SPEAK=0,ATTACK,GIVEITEM,NOEVENT};
enum ActionStart{NORMAL=0,RAND_START};
enum SelectAction{SEL_ATTACK=0,SEL_FIRE,SEL_FIREWALL,SEL_BOMB,\
					SEL_ITEM,SEL_FULL_HP,SEL_FULL_MP,NO_SEL};
//used to identify an animation


// Enumerated list of of device types
enum InputDevices {
  NONE = 0,
  KEYBOARD,
  MOUSE,
  JOYSTICK
};

// Define Type of vertex
typedef struct sVertex
	{
		float x,y,z;
		float u,v;
	}sVertex;
#define TESTFVF (D3DFVF_XYZ | D3DFVF_TEX1)

struct CUSTOMVERTEX
		{
			FLOAT x, y, z, rhw; // The position of a transformed vertex
			DWORD color;        // The vertex color
			FLOAT tu, tv;       // The texture coordinates
		};
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

struct VERTEX3
{
		FLOAT x,y,z;
		DWORD color;
		FLOAT tu1,tv1;
		FLOAT tu2,tv2;
};
#define D3DFVF_VERTEX3 (D3DFVF_XYZ |D3DFVF_DIFFUSE|D3DFVF_TEX3)

struct VERTEX_FX
{
    D3DXVECTOR3 posit;
    D3DCOLOR    color;

	enum FVF
	{
		FVF_Flags = D3DFVF_XYZ|D3DFVF_DIFFUSE
	};
};

// Engin includes
#include "Engin_Application.h"
#include "Engin_Graphics.h"
#include "Engin_Input.h"
#include "Engin_Sound.h"
#include "Packet.h"

#endif