
#ifndef _ENGIN_APPLICATION_H
#define _ENGIN_APPLICATION_H

#ifndef MAX_PATH
#define MAX_PATH 255
#endif

class CApplication
{
private:
    HWND          m_hWnd;
	HINSTANCE     m_hInst;
  protected:
    char          m_Class[MAX_PATH];
    char          m_Caption[MAX_PATH];

    WNDCLASSEX    m_wndclass;
	
    DWORD         m_Style;
    DWORD         m_XPos;
    DWORD         m_YPos;
    DWORD         m_Width;
    DWORD         m_Height;
	DWORD		  m_Mode;

	DWORD		  dwLastTickCount;
    DWORD		  dwFrameCount;
	int			  iFrameRate;

	BOOL Render3DEnvironment();
  public:
    CApplication();
	
	HWND      GetWindowHandle(){return m_hWnd;}
	HINSTANCE GetInstanceHandle(){return m_hInst;}
	//DWORD	  GetWindowStyle(){return m_Style;}

	BOOL CreateWindowed(char* title, DWORD width, DWORD height,DWORD style=WS_SYSMENU|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
	BOOL Move(DWORD XPos, DWORD YPos);
    BOOL Resize(DWORD Width, DWORD Height);
    BOOL ShowMouse(BOOL Show = TRUE);

	BOOL Run();
	virtual LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
	virtual BOOL Init()       { return TRUE; }
	virtual BOOL Frame()	  { return TRUE; }
    virtual BOOL Shutdown()   { return TRUE; }
};

static CApplication *g_pApplication = NULL;
static LRESULT CALLBACK MsgWinProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return g_pApplication->MsgProc(hWnd, uMsg, wParam, lParam);
}

enum Purposes {
    NOPURPOSE = 0,
    INITPURPOSE,
    SHUTDOWNPURPOSE,
    FRAMEPURPOSE
  };
    
class CStateManager
{
  typedef struct sState {
    void (*Function)(void *Ptr, long Purpose);
    sState *Next;

    sState()
    {
      Function = NULL;
      Next = NULL;
    }

    ~sState()
    {
      delete Next;
    }
  } sState;

  protected:
    sState *m_StateParent;

  public:
    CStateManager();
    ~CStateManager();

    void Push(void (*Function)(void *Ptr, long Purpose), void *DataPtr = NULL);
    BOOL Pop(void *DataPtr = NULL);
    void PopAll(void *DataPtr = NULL);
    BOOL Process(void *DataPtr = NULL);
};

class CProcessManager
{
  typedef struct sProcess {
    void  (*Function)(void *Ptr, long Purpose);
    sProcess *Next;

    sProcess()
    {
      Function = NULL;
      Next = NULL;
    }

    ~sProcess()
    {
      delete Next;
    }
  } sProcess;

  protected:
    sProcess *m_ProcessParent; 

  public:
    CProcessManager();
    ~CProcessManager();

    void Push(void (*Process)(void *Ptr, long Purpose), void *DataPtr = NULL);
    BOOL Pop(void *DataPtr = NULL);
    void PopAll(void *DataPtr = NULL);
    void Process(void *Ptr = NULL);
};

#endif