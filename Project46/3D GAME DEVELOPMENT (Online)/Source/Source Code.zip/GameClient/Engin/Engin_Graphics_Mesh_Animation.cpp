#include "HGlobal.h"

#include "rmxftmpl.h"
#include "rmxfguid.h"

CMesh::CMesh()
{
  m_Graphics = NULL;
  m_NumMeshes = 0;
  m_Meshes = NULL;
  m_NumFrames = 0;
  m_Frames = NULL;

  m_Transparent = FALSE;
  m_Min.x = m_Min.y = m_Min.z = m_Max.x = m_Max.y = m_Max.z = 0.0f;
  m_Radius = 0.0f;
}

CMesh::~CMesh()
{
  Cleanup();
}

BOOL CMesh::Load(CGraphic *Graphics, char *Filename, char *TexturePath, BOOL Transparent, D3DCOLOR ColorKey)
{
  IDirectXFile           *pDXFile = NULL;
  IDirectXFileEnumObject *pDXEnum = NULL;
  IDirectXFileData       *pDXData = NULL;
  sFrame                 *TempFrame, *FramePtr;
  sMesh                  *Mesh;
  D3DXMATRIX             *Matrix;
  DWORD                   i;

  // Free prior mesh object data
  Cleanup();

  // Error checking
  if((m_Graphics = Graphics) == NULL || Filename == NULL)
    return FALSE;

  if (Transparent == TRUE)
  {
	  m_Transparent = TRUE;
	  m_ColorKey = ColorKey;
  }

  // Create the file object
  if(FAILED(DirectXFileCreate(&pDXFile)))
    return FALSE;

  // Register the templates
  if(FAILED(pDXFile->RegisterTemplates((LPVOID)D3DRM_XTEMPLATES, D3DRM_XTEMPLATE_BYTES))) {
    pDXFile->Release();
    return FALSE;
  }

  // Create an enumeration object
  if(FAILED(pDXFile->CreateEnumObject((LPVOID)Filename, DXFILELOAD_FROMFILE, &pDXEnum))) {
    pDXFile->Release();
    return FALSE;
  }

  // Create a temporary frame
  TempFrame = new sFrame();

  // Loop through all objects looking for the frames and meshes
  while(SUCCEEDED(pDXEnum->GetNextDataObject(&pDXData))) {
    ParseXFileData(pDXData, TempFrame, TexturePath);
    ReleaseCOM(pDXData);
  }

  // Release used COM objects
  ReleaseCOM(pDXEnum);
  ReleaseCOM(pDXFile);

  // See if we should keep the tempframe as root
  if(TempFrame->m_MeshList != NULL) {
    m_Frames = TempFrame;
    m_Frames->m_Name = new char[7];
    strcpy(m_Frames->m_Name, "%ROOT%");
  } else {
    // Assign the root frame and release temporary frame
    m_Frames = TempFrame->m_Child;
    FramePtr = m_Frames;
    while(FramePtr != NULL) {
      FramePtr->m_Parent = NULL;
      FramePtr = FramePtr->m_Sibling;
    }
    TempFrame->m_Child = NULL;
    delete TempFrame;
  }

  // Match frames to bones (for matrices)
  MapFramesToBones(m_Frames);
  
  // Generate default mesh (if contains a skin mesh)
  if((Mesh = m_Meshes) != NULL) {
    while(Mesh != NULL) {
      if(Mesh->m_SkinMesh != NULL) {
        Matrix = new D3DXMATRIX[Mesh->m_NumBones];
        for(i=0;i<Mesh->m_NumBones;i++)
          D3DXMatrixIdentity(&Matrix[i]);
        Mesh->m_SkinMesh->UpdateSkinnedMesh(Matrix, NULL,Mesh->m_Mesh);
        delete [] Matrix;
      }
      Mesh = Mesh->m_Next;
    }
  }

  // Calculate bounding box and sphere
  if((Mesh = m_Meshes) != NULL) {
    while(Mesh != NULL) {
      m_Min.x = min(m_Min.x, Mesh->m_Min.x);
      m_Min.y = min(m_Min.y, Mesh->m_Min.y);
      m_Min.z = min(m_Min.z, Mesh->m_Min.z);
      m_Max.x = max(m_Max.x, Mesh->m_Max.x);
      m_Max.y = max(m_Max.y, Mesh->m_Max.y);
      m_Max.z = max(m_Max.z, Mesh->m_Max.z);
      m_Radius = max(m_Radius, Mesh->m_Radius);

      Mesh = Mesh->m_Next;
    }
  }

  return TRUE;
}

void CMesh::ParseXFileData(IDirectXFileData *pDataObj, sFrame *ParentFrame, char *TexturePath)
{
  IDirectXFileObject *pSubObj  = NULL;
  IDirectXFileData   *pSubData = NULL;
  IDirectXFileDataReference *pDataRef = NULL;
  const GUID *Type = NULL;
  char       *Name = NULL;
  DWORD       Size;
  sFrame     *SubFrame = NULL;
  char        Path[MAX_PATH];

  sFrame     *Frame = NULL;
  D3DXMATRIX *FrameMatrix = NULL;

  sMesh         *Mesh = NULL;
  ID3DXBuffer   *MaterialBuffer = NULL;
  D3DXMATERIAL  *Materials = NULL;
  ID3DXBuffer   *Adjacency = NULL;
  DWORD         *AdjacencyIn = NULL;
  DWORD         *AdjacencyOut = NULL;

  DWORD i;
  BYTE  **Ptr;

  // Get the template type
  if(FAILED(pDataObj->GetType(&Type)))
    return;

  // Get the template name (if any)
  if(FAILED(pDataObj->GetName(NULL, &Size)))
    return;
  if(Size) {
    if((Name = new char[Size]) != NULL)
      pDataObj->GetName(Name, &Size);
  }

  // Give template a default name if none found
  if(Name == NULL) {
    if((Name = new char[9]) == NULL)
      return;
    strcpy(Name, "$NoName$");
  }

  // Set sub frame
  SubFrame = ParentFrame;

  // Process the templates

  // Frame
  if(*Type == TID_D3DRMFrame) {
    // Create a new frame structure
    Frame = new sFrame();

    // Store the name
    Frame->m_Name = Name;
    Name = NULL;

    // Add to parent frame
    Frame->m_Parent = ParentFrame;
    Frame->m_Sibling = ParentFrame->m_Child;
    ParentFrame->m_Child = Frame;

    // Increase frame count
    m_NumFrames++;

    // Set sub frame parent
    SubFrame = Frame;
  }

  // Frame transformation matrix
  if(*Type == TID_D3DRMFrameTransformMatrix) {
    if(FAILED(pDataObj->GetData(NULL, &Size, (PVOID*)&FrameMatrix)))
      return;
    ParentFrame->m_matOriginal = *FrameMatrix;
  }

  // Mesh
  if(*Type == TID_D3DRMMesh) {
    // See if mesh already loaded
    if(m_Meshes == NULL || m_Meshes->FindMesh(Name) == NULL) {
      // Create a new mesh structure
      Mesh = new sMesh();

      // Store the name
      Mesh->m_Name = Name;
      Name = NULL;

      // Load mesh data
      if(FAILED(D3DXLoadSkinMeshFromXof(pDataObj, 0,
                  m_Graphics->GetDevice(), 
                  &Adjacency,
                  &MaterialBuffer, &Mesh->m_NumMaterials, 
                  &Mesh->m_BoneNames, &Mesh->m_BoneTransforms,
                  &Mesh->m_SkinMesh))) {
        delete Mesh;
        return;
      }

      // Calculate the bounding box and sphere
      if(SUCCEEDED(Mesh->m_SkinMesh->LockVertexBuffer(D3DLOCK_READONLY, (BYTE**)&Ptr))) {
        D3DXComputeBoundingBox((void*)Ptr, Mesh->m_SkinMesh->GetNumVertices(), Mesh->m_SkinMesh->GetFVF(), &Mesh->m_Min, &Mesh->m_Max);
        D3DXComputeBoundingSphere((void*)Ptr, Mesh->m_SkinMesh->GetNumVertices(), Mesh->m_SkinMesh->GetFVF(), &D3DXVECTOR3(0.0f,0.0f,0.0f), &Mesh->m_Radius);
        Mesh->m_SkinMesh->UnlockVertexBuffer();
      }

      // Convert to regular mesh if no bones
      if(!(Mesh->m_NumBones = Mesh->m_SkinMesh->GetNumBones())) {
        // Convert to a regular mesh
        Mesh->m_SkinMesh->GetOriginalMesh(&Mesh->m_Mesh);
        ReleaseCOM(Mesh->m_SkinMesh);
      } else {
        // Create the bone matrix array and clear it out
        Mesh->m_Matrices = new D3DXMATRIX[Mesh->m_NumBones];
        for(i=0;i<Mesh->m_NumBones;i++)
          D3DXMatrixIdentity(&Mesh->m_Matrices[i]);

        // Create the frame mapping matrix array and clear out
        Mesh->m_FrameMatrices = new D3DXMATRIX*[Mesh->m_NumBones];
        for(i=0;i<Mesh->m_NumBones;i++)
          Mesh->m_FrameMatrices[i] = NULL;

        // Get a pointer to bone matrices
        Mesh->m_BoneMatrices = (D3DXMATRIX*)Mesh->m_BoneTransforms->GetBufferPointer();

        AdjacencyIn  = (DWORD*)Adjacency->GetBufferPointer();
        AdjacencyOut = new DWORD[Mesh->m_SkinMesh->GetNumFaces() * 3];

		        // Generate the skin mesh object
        if(FAILED(Mesh->m_SkinMesh->GenerateSkinnedMesh(
                    D3DXMESH_WRITEONLY, 0.0f, 
                    AdjacencyIn, AdjacencyOut, NULL, NULL,
                    &Mesh->m_Mesh))) {
          // Convert to a regular mesh if error
          Mesh->m_SkinMesh->GetOriginalMesh(&Mesh->m_Mesh);
          ReleaseCOM(Mesh->m_SkinMesh);
          Mesh->m_NumBones = 0;
        }

        delete [] AdjacencyOut;
        ReleaseCOM(Adjacency);
      }

      // Load materials or create a default one if none
      if(!Mesh->m_NumMaterials) {
        // Create a default one
        Mesh->m_Materials = new D3DMATERIAL8[1];
        Mesh->m_Textures  = new LPDIRECT3DTEXTURE8[1];

        ZeroMemory(Mesh->m_Materials, sizeof(D3DMATERIAL8));
        Mesh->m_Materials[0].Diffuse.r = 1.0f;
        Mesh->m_Materials[0].Diffuse.g = 1.0f;
        Mesh->m_Materials[0].Diffuse.b = 1.0f;
        Mesh->m_Materials[0].Diffuse.a = 1.0f;
        Mesh->m_Materials[0].Ambient   = Mesh->m_Materials[0].Diffuse;
        Mesh->m_Materials[0].Specular  = Mesh->m_Materials[0].Diffuse;
        Mesh->m_Textures[0] = NULL;

        Mesh->m_NumMaterials = 1;
      } else {
        // Load the materials
        Materials = (D3DXMATERIAL*)MaterialBuffer->GetBufferPointer();
        Mesh->m_Materials = new D3DMATERIAL8[Mesh->m_NumMaterials];
        Mesh->m_Textures  = new LPDIRECT3DTEXTURE8[Mesh->m_NumMaterials];

        for(i=0;i<Mesh->m_NumMaterials;i++) {
          Mesh->m_Materials[i] = Materials[i].MatD3D;
          Mesh->m_Materials[i].Ambient = Mesh->m_Materials[i].Diffuse;
       
          // Build a texture path and load it
          sprintf(Path, "%s%s", TexturePath, Materials[i].pTextureFilename);
		  if ( m_Transparent == TRUE ){
				if ( FAILED( D3DXCreateTextureFromFileEx( m_Graphics->GetDevice(), 
													  Path,
													  D3DX_DEFAULT,
													  D3DX_DEFAULT,
													  D3DX_DEFAULT,
													  0,
													  D3DFMT_UNKNOWN,
													  D3DPOOL_MANAGED, 
													  D3DX_FILTER_TRIANGLE, 
													  D3DX_FILTER_TRIANGLE,
													  m_ColorKey,  
													  NULL, 
													  NULL, 
													  &Mesh->m_Textures[i] ) ) ){
          			Mesh->m_Textures[i] = NULL;
				}
		  }else{
				if(FAILED(D3DXCreateTextureFromFile(m_Graphics->GetDevice(),
													Path,
													&Mesh->m_Textures[i]))) {
					Mesh->m_Textures[i] = NULL;
				}
		  }
        }
      }
      ReleaseCOM(MaterialBuffer);

      // link in mesh
      Mesh->m_Next = m_Meshes;
      m_Meshes = Mesh;
      m_NumMeshes++;
    } else {
      // Find mesh in list
      Mesh = m_Meshes->FindMesh(Name);
    }

    // Add mesh to frame 
    if(Mesh != NULL)
      ParentFrame->AddMesh(Mesh);
  }

  // Skip animation sets and animations
  if(*Type == TID_D3DRMAnimationSet || *Type == TID_D3DRMAnimation || *Type == TID_D3DRMAnimationKey) {
    delete [] Name;
    return;
  }

  // Release name buffer
  delete [] Name;

  // Scan for embedded templates
  while(SUCCEEDED(pDataObj->GetNextObject(&pSubObj))) {

    // Process embedded references
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileDataReference, (void**)&pDataRef))) {
      if(SUCCEEDED(pDataRef->Resolve(&pSubData))) {
        ParseXFileData(pSubData, SubFrame, TexturePath);
        ReleaseCOM(pSubData);
      }
      ReleaseCOM(pDataRef);
    }

    // Process non-referenced embedded templates
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileData, (void**)&pSubData))) {
      ParseXFileData(pSubData, SubFrame, TexturePath);
      ReleaseCOM(pSubData);
    }
    ReleaseCOM(pSubObj);
  }

  return;
}

void CMesh::MapFramesToBones(sFrame *Frame)
{
  sMesh *Mesh;
  DWORD i;
  char **Name;

  // Return if no more frames to map
  if(Frame == NULL || Frame->m_Name == NULL)
    return;

  // Scan through meshes looking for bone matches
  Mesh = m_Meshes;
  while(Mesh != NULL) {
    if(Mesh->m_NumBones && Mesh->m_BoneNames != NULL && Mesh->m_Matrices != NULL && Mesh->m_FrameMatrices != NULL) {
      Name = (char**)Mesh->m_BoneNames->GetBufferPointer();
      for(i=0;i<Mesh->m_NumBones;i++) {
        if(!strcmp(Frame->m_Name, Name[i])) {
          Mesh->m_FrameMatrices[i] = &Frame->m_matCombined;
          break;
        }
      }
    }
    Mesh = Mesh->m_Next;
  }

  // Scan through child frames
  MapFramesToBones(Frame->m_Child);

  // Scan through sibling frames
  MapFramesToBones(Frame->m_Sibling);
}

BOOL CMesh::Cleanup()
{
  m_Graphics = NULL;
 
  m_NumMeshes = 0;
  delete m_Meshes;
  m_Meshes = NULL;

  m_NumFrames = 0;
  delete m_Frames;
  m_Frames = NULL;

  m_Min.x = m_Min.y = m_Min.z = m_Max.x = m_Max.y = m_Max.z = 0.0f;
  m_Radius = 0.0f;

  return TRUE;
}

BOOL CMesh::IsLoaded()
{
  if(m_Meshes != NULL && m_Frames != NULL)
    return TRUE;
  return FALSE;
}

long CMesh::GetNumFrames()
{
  return m_NumFrames;
}

sFrame *CMesh::GetParentFrame()
{
  return m_Frames;
}

sFrame *CMesh::GetFrame(char *Name)
{
  if(m_Frames == NULL)
    return NULL;
  return m_Frames->FindFrame(Name);
}

long CMesh::GetNumMeshes()
{
  return m_NumMeshes;
}

sMesh *CMesh::GetParentMesh()
{
  return m_Meshes;
}

sMesh *CMesh::GetMesh(char *Name)
{
  if(m_Meshes == NULL)
    return NULL;
  return m_Meshes->FindMesh(Name);
}

BOOL CMesh::GetBounds(float *MinX, float *MinY, float *MinZ, float *MaxX, float *MaxY, float *MaxZ, float *Radius)
{
  if(MinX != NULL)
    *MinX = m_Min.x;
  if(MinY != NULL)
    *MinY = m_Min.y;
  if(MinZ != NULL)
    *MinZ = m_Min.z;

  if(MaxX != NULL)
    *MaxX = m_Max.x;
  if(MaxY != NULL)
    *MaxY = m_Max.y;
  if(MaxZ != NULL)
    *MaxZ = m_Max.z;

  if(Radius != NULL)
    *Radius = m_Radius;

  return TRUE;
}

CAnimation::CAnimation()
{
  m_NumAnimations = 0;
  m_AnimationSet  = NULL;
}

CAnimation::~CAnimation()
{
  Cleanup();
}

BOOL CAnimation::Load(char *Filename, CMesh *MapMesh)
{
  IDirectXFile           *pDXFile = NULL;
  IDirectXFileEnumObject *pDXEnum = NULL;
  IDirectXFileData       *pDXData = NULL;
  
  // Free a prior animation
  Cleanup();

  // Error checking
  if(Filename == NULL)
    return FALSE;

  // Create the file object
  if(FAILED(DirectXFileCreate(&pDXFile)))
    return FALSE;

  // Register the templates
  if(FAILED(pDXFile->RegisterTemplates((LPVOID)D3DRM_XTEMPLATES, D3DRM_XTEMPLATE_BYTES))) {
    pDXFile->Release();
    return FALSE;
  }

  // Create an enumeration object
  if(FAILED(pDXFile->CreateEnumObject((LPVOID)Filename, DXFILELOAD_FROMFILE, &pDXEnum))) {
    pDXFile->Release();
    return FALSE;
  }

  // Loop through all objects looking for the animation
  while(SUCCEEDED(pDXEnum->GetNextDataObject(&pDXData))) {
    ParseXFileData(pDXData, NULL, NULL);
    ReleaseCOM(pDXData);
  }

  ReleaseCOM(pDXEnum);
  ReleaseCOM(pDXFile);

  // Map the animation to the supplied mesh (if any)
  if(MapMesh != NULL)
    MapToMesh(MapMesh);

  return TRUE;
}

void CAnimation::ParseXFileData(IDirectXFileData *pDataObj, sAnimationSet *ParentAnim, sAnimation *CurrentAnim)
{
  IDirectXFileObject *pSubObj  = NULL;
  IDirectXFileData   *pSubData = NULL;
  IDirectXFileDataReference *pDataRef = NULL;
  const GUID      *Type = NULL;
  char            *Name = NULL;
  DWORD            Size;
  PBYTE           *DataPtr;

  DWORD            i;

  DWORD              KeyType, NumKeys, Time;
  sXFileRotateKey   *RotKey;
  sXFileScaleKey    *ScaleKey;
  sXFilePositionKey *PosKey;
  sXFileMatrixKey   *MatKey;

  sAnimationSet   *SubAnimSet = NULL;
  sAnimation      *SubAnim    = NULL;

  sAnimation      *Anim = NULL;
  sAnimationSet   *AnimSet = NULL;
  
  // Get the template type
  if(FAILED(pDataObj->GetType(&Type)))
    return;

  // Get the template name (if any)
  if(FAILED(pDataObj->GetName(NULL, &Size)))
    return;
  if(Size) {
    if((Name = new char[Size]) != NULL)
      pDataObj->GetName(Name, &Size);
  }

  // Give template a default name if none found
  if(Name == NULL) {
    if((Name = new char[9]) == NULL)
      return;
    strcpy(Name, "$NoName$");
  }

  // Set sub frame parent
  SubAnimSet = ParentAnim;
  SubAnim    = CurrentAnim;

  // Process the templates

  // Process an animation set
  if(*Type == TID_D3DRMAnimationSet) {
    // Create a animation set structure
    if((AnimSet = new sAnimationSet()) == NULL)
      return;

    // Set the name
    AnimSet->m_Name = Name;
    Name = NULL;

    // Link into the animation set list
    AnimSet->m_Next = m_AnimationSet;
    m_AnimationSet = AnimSet;

    // Set as new parent
    SubAnimSet = AnimSet;
  }

  // Process an animation
  if(*Type == TID_D3DRMAnimation && ParentAnim != NULL) {
    // Create an animation structure
    if((Anim = new sAnimation()) == NULL)
      return;

    // Set the name
    Anim->m_Name = Name;
    Name = NULL;

    // Link into the animation list
    Anim->m_Next = ParentAnim->m_Animation;
    ParentAnim->m_Animation = Anim;

    SubAnim = Anim;
  }

  // Process an animation key
  if(*Type == TID_D3DRMAnimationKey && CurrentAnim != NULL) {
    // Load in this animation's key data
    if(FAILED(pDataObj->GetData(NULL, &Size, (PVOID*)&DataPtr)))
      return;

    KeyType = ((DWORD*)DataPtr)[0];
    NumKeys = ((DWORD*)DataPtr)[1];

    switch(KeyType) {
      case 0:
        delete [] CurrentAnim->m_RotateKeys;
        if((CurrentAnim->m_RotateKeys = new sRotateKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumRotateKeys = NumKeys;
        RotKey = (sXFileRotateKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_RotateKeys[i].Time = RotKey->Time;
          CurrentAnim->m_RotateKeys[i].Quaternion.x = -RotKey->x;
          CurrentAnim->m_RotateKeys[i].Quaternion.y = -RotKey->y;
          CurrentAnim->m_RotateKeys[i].Quaternion.z = -RotKey->z;
          CurrentAnim->m_RotateKeys[i].Quaternion.w =  RotKey->w;

          if(RotKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = RotKey->Time;

          RotKey += 1;
        }

        break;

      case 1: 
        delete [] CurrentAnim->m_ScaleKeys;
        if((CurrentAnim->m_ScaleKeys = new sScaleKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumScaleKeys = NumKeys;
        ScaleKey = (sXFileScaleKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_ScaleKeys[i].Time  = ScaleKey->Time;
          CurrentAnim->m_ScaleKeys[i].Scale = ScaleKey->Scale;

          if(ScaleKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = ScaleKey->Time;

          ScaleKey += 1;
        }

        // Calculate the interpolation values
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_ScaleKeys[i].ScaleInterpolation = CurrentAnim->m_ScaleKeys[i+1].Scale - CurrentAnim->m_ScaleKeys[i].Scale;
            Time = CurrentAnim->m_ScaleKeys[i+1].Time - CurrentAnim->m_ScaleKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_ScaleKeys[i].ScaleInterpolation /= (float)Time;
          }
        }

        break;
    
      case 2:
        delete [] CurrentAnim->m_PositionKeys;
        if((CurrentAnim->m_PositionKeys = new sPositionKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumPositionKeys = NumKeys;
        PosKey = (sXFilePositionKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_PositionKeys[i].Time = PosKey->Time;
          CurrentAnim->m_PositionKeys[i].Pos  = PosKey->Pos;

          if(PosKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = PosKey->Time;

          PosKey += 1;
        }

        // Calculate the interpolation values
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_PositionKeys[i].PosInterpolation = CurrentAnim->m_PositionKeys[i+1].Pos - CurrentAnim->m_PositionKeys[i].Pos;
            Time = CurrentAnim->m_PositionKeys[i+1].Time - CurrentAnim->m_PositionKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_PositionKeys[i].PosInterpolation /= (float)Time;
          }
        }

        break;

      case 4:
        delete [] CurrentAnim->m_MatrixKeys;
        if((CurrentAnim->m_MatrixKeys = new sMatrixKey[NumKeys]) == NULL)
          return;
        CurrentAnim->m_NumMatrixKeys = NumKeys;
        MatKey = (sXFileMatrixKey*)((char*)DataPtr + (sizeof(DWORD) * 2));
        for(i=0;i<NumKeys;i++) {
          CurrentAnim->m_MatrixKeys[i].Time   = MatKey->Time;
          CurrentAnim->m_MatrixKeys[i].Matrix = MatKey->Matrix;

          if(MatKey->Time > ParentAnim->m_Length)
            ParentAnim->m_Length = MatKey->Time;

          MatKey+=1;
        }

        // Calculate the interpolation matrices
        if(NumKeys > 1) {
          for(i=0;i<NumKeys-1;i++) {
            CurrentAnim->m_MatrixKeys[i].MatInterpolation = CurrentAnim->m_MatrixKeys[i+1].Matrix - CurrentAnim->m_MatrixKeys[i].Matrix;
            Time = CurrentAnim->m_MatrixKeys[i+1].Time - CurrentAnim->m_MatrixKeys[i].Time;
            if(!Time)
              Time = 1;
            CurrentAnim->m_MatrixKeys[i].MatInterpolation /= (float)Time;
          }
        }
        break;
    }
  }

  // Process animation options
  if(*Type == TID_D3DRMAnimationOptions && CurrentAnim != NULL) {
    // Load in this animation's options
    if(FAILED(pDataObj->GetData(NULL, &Size, (PVOID*)&DataPtr)))
      return;

    // Process looping information
    if(!((DWORD*)DataPtr)[0])
      CurrentAnim->m_Loop = TRUE;
    else
      CurrentAnim->m_Loop = FALSE;

    // Process linear information
    if(!((DWORD*)DataPtr)[1])
      CurrentAnim->m_Linear = FALSE;
    else
      CurrentAnim->m_Linear = TRUE;
  }

  // Process a frame reference
  if(*Type == TID_D3DRMFrame && CurrentAnim != NULL) {
    CurrentAnim->m_FrameName = Name;
    Name = NULL;

    // Don't enumerate child templates
    return;
  }

  // Release name buffer
  delete [] Name;

  // Scan for embedded templates
  while(SUCCEEDED(pDataObj->GetNextObject(&pSubObj))) {

    // Process embedded references
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileDataReference, (void**)&pDataRef))) {
      if(SUCCEEDED(pDataRef->Resolve(&pSubData))) {
        ParseXFileData(pSubData, SubAnimSet, SubAnim);
        ReleaseCOM(pSubData);
      }
      ReleaseCOM(pDataRef);
    }

    // Process non-referenced embedded templates
    if(SUCCEEDED(pSubObj->QueryInterface(IID_IDirectXFileData, (void**)&pSubData))) {
      ParseXFileData(pSubData, SubAnimSet, SubAnim);
      ReleaseCOM(pSubData);
    }
    ReleaseCOM(pSubObj);
  }
}

BOOL CAnimation::Cleanup()
{
  delete m_AnimationSet;
  m_AnimationSet  = NULL;
  m_NumAnimations = 0;

  return TRUE;
}

BOOL CAnimation::IsLoaded()
{
  if(m_AnimationSet == NULL)
    return FALSE;
  return TRUE;
}

BOOL CAnimation::MapToMesh(CMesh *Mesh)
{
  sAnimationSet *AnimSet;
  sAnimation    *Anim;

  // Make sure there's a mesh to work with
  if(Mesh == NULL)
    return FALSE;

  // Assign links to frames by name
  if((AnimSet = m_AnimationSet) == NULL)
    return FALSE;

  // Scan through all animation sets
  while(AnimSet != NULL) {
    // Scan through all animations
    Anim = AnimSet->m_Animation;
    while(Anim != NULL) {
      // Find the matching frame from Mesh
      Anim->m_Frame = Mesh->GetFrame(Anim->m_FrameName);
      Anim = Anim->m_Next;
    }
    AnimSet = AnimSet->m_Next;
  }

  return TRUE;
}

long CAnimation::GetNumAnimations()
{
  return m_NumAnimations;
}

sAnimationSet *CAnimation::GetAnimationSet(char *Name)
{
  if(m_AnimationSet == NULL)
    return NULL;
  return m_AnimationSet->FindSet(Name);
}

BOOL CAnimation::SetLoop(BOOL ToLoop, char *Name)
{
  sAnimationSet *AnimSet;
  sAnimation    *Anim;

  if((AnimSet = GetAnimationSet(Name)) == NULL)
    return FALSE;

  Anim = AnimSet->m_Animation;
  while(Anim != NULL) {
    Anim->m_Loop = ToLoop;
    Anim = Anim->m_Next;
  }

  return TRUE;
}

unsigned long CAnimation::GetLength(char *Name)
{
  sAnimationSet *AnimSet;

  if((AnimSet = GetAnimationSet(Name)) == NULL)
    return 0;
  return AnimSet->m_Length;
}

