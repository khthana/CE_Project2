#include"HGlobal.h"

CGraphic::CGraphic()
{
	m_hWnd = NULL;
	  
	m_pD3D = NULL;
	m_pD3DDevice = NULL;
	m_pSprite = NULL;
	m_AmbientRed = m_AmbientGreen = m_AmbientBlue = (char)255;

	m_Windowed = TRUE;
	m_ZBuffer  = FALSE;
	m_HAL      = FALSE;
	m_Width  = 0;
	m_Height = 0;
	m_BPP    = 0;
}

CGraphic::~CGraphic()
{
	Cleanup();
}

BOOL CGraphic::Cleanup()
{
	SAFE_RELEASE(m_pSprite);
	SAFE_RELEASE(m_pD3DDevice);
	SAFE_RELEASE(m_pD3D);

	return TRUE;
}

BOOL CGraphic::Create3D(HWND hWnd)
{
	Cleanup();

	if((m_hWnd = hWnd) == NULL)
	{
		MsgError("Can't Get Window !!!");
		return FALSE;
	}
	if((m_pD3D = Direct3DCreate8(D3D_SDK_VERSION)) == NULL)
	{
		MsgError("Can't Create Direct3D!!!");
		return FALSE;
	}
	return TRUE;
}

HRESULT CGraphic::AdjustWindowForChange()
{
    if( m_Windowed )
    {
		// Set windowed-mode style
		SetWindowLong( m_hWnd, GWL_STYLE, GetWindowStyle(m_hWnd) );
    }
    else
    {
        // Set fullscreen-mode style
        SetWindowLong( m_hWnd, GWL_STYLE, WS_POPUP|WS_SYSMENU|WS_VISIBLE );
    }
    return S_OK;
}

char CGraphic::GetFormatBPP(D3DFORMAT Format)
{
  switch(Format) {
    // 32 bit modes
    case D3DFMT_A8R8G8B8:
    case D3DFMT_X8R8G8B8:
      return 32;
      break;

    // 24 bit modes
    case D3DFMT_R8G8B8:
      return 24;
      break;

    // 16 bit modes
    case D3DFMT_R5G6B5:
    case D3DFMT_X1R5G5B5:
    case D3DFMT_A1R5G5B5:
    case D3DFMT_A4R4G4B4:
      return 16;
      break;

    // 8 bit modes
    case D3DFMT_A8P8:
    case D3DFMT_P8:
      return 8;
      break;

    default:
       return 0;
  }
}

BOOL CGraphic::GetDisplayModeInfo(long Num, D3DDISPLAYMODE *Mode)
{
  long Max;

  if(m_pD3D == NULL)
    return FALSE;

  Max = m_pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT);
  if(Num >= Max)
    return FALSE;

  if(FAILED(m_pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT,
            Num, Mode)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::CheckFormat(D3DFORMAT Format, BOOL Windowed, BOOL HAL)
{
  if(FAILED(m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, 
              (HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,
              Format, Format, Windowed)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::UpdateScreen(BOOL Windowed,BOOL UseZBuffer,long Width, long Height, char BPP)
{
	m_Windowed = Windowed;
	D3DPRESENT_PARAMETERS d3dpp;
	D3DFORMAT             Format, AltFormat;
	RECT                  WndRect, ClientRect;
	long                  WndWidth, WndHeight;
	
	// Prepare window for possible windowed/fullscreen change
	AdjustWindowForChange();

	// Error checking
	if(m_pD3D == NULL)
		return FALSE;

	// Get the current display format
	if(FAILED(m_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &m_d3ddm)))
		return FALSE;

	// Configure width
	if(!Width) 
	{
		// Default to screen width if fullscreen
		if(Windowed == FALSE) 
		{
			m_Width = m_d3ddm.Width;
		} else 
		{
			// Otherwise grab from client size
			GetClientRect(m_hWnd, &ClientRect);
			m_Width = ClientRect.right;
		}
	} else 
	{
		m_Width = Width;
	}

	// Configure height
	if(!Height) 
	{
		// Default to screen height if fullscreen
		if(Windowed == FALSE) {
		m_Height = m_d3ddm.Height;
		} else {
		// Otherwise grab from client size
		GetClientRect(m_hWnd, &ClientRect);
		m_Height = ClientRect.bottom;
		}
	} else 
	{
		m_Height = Height;
	}

	// Configure BPP
	if(!(m_BPP = BPP) || Windowed == TRUE)
	{
		if(!(m_BPP = GetFormatBPP(m_d3ddm.Format)))
		return FALSE;
	}

	if(Windowed == TRUE) 
	{
		GetWindowRect(m_hWnd, &WndRect);
		GetClientRect(m_hWnd, &ClientRect);

		WndWidth  = (WndRect.right  - (ClientRect.right  - m_Width))  - WndRect.left;
		WndHeight = (WndRect.bottom - (ClientRect.bottom - m_Height)) - WndRect.top;

		MoveWindow(m_hWnd, WndRect.left, WndRect.top, WndWidth, WndHeight, TRUE);
	}

	// Clear presentation structure
	ZeroMemory(&d3dpp, sizeof(D3DPRESENT_PARAMETERS));

	// Default to no hardware acceleration detected
	m_HAL = FALSE;

	// Setup Windowed or fullscreen usage
	if((m_Windowed = Windowed) == TRUE) 
	{
		d3dpp.Windowed         = TRUE;
		d3dpp.SwapEffect       = D3DSWAPEFFECT_DISCARD;
		d3dpp.BackBufferFormat = m_d3ddm.Format;

		// See if card supports HAL
		if(CheckFormat(m_d3ddm.Format, TRUE, TRUE) == TRUE) 
		{
			m_HAL = TRUE;
		} else 
		{
			// Return error if not emulated
			if(CheckFormat(m_d3ddm.Format, TRUE, FALSE) == FALSE)
				return FALSE;
		}
	} else 
	{
		d3dpp.Windowed   = FALSE;
		d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	  
		d3dpp.BackBufferWidth  = m_Width;
		d3dpp.BackBufferHeight = m_Height;
		d3dpp.FullScreen_RefreshRateInHz      = D3DPRESENT_RATE_DEFAULT;
		d3dpp.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_ONE; // or D3DPRESENT_INTERVAL_DEFAULT or D3DPRESENT_INTERVAL_IMMEDIATE

		// Figure display format to use
		if(m_BPP == 32) {
		Format    = D3DFMT_X8R8G8B8;
		AltFormat = D3DFMT_X8R8G8B8;
		}
		if(m_BPP == 24) {
		Format    = D3DFMT_R8G8B8;
		AltFormat = D3DFMT_R8G8B8;
		}
		if(m_BPP == 16) {
		Format    = D3DFMT_R5G6B5;
		AltFormat = D3DFMT_X1R5G5B5;
		}
		if(m_BPP == 8) {
		Format    = D3DFMT_P8;
		AltFormat = D3DFMT_P8;
		}

		// Check for HAL device
		if(CheckFormat(Format, FALSE, TRUE) == TRUE) {
		m_HAL = TRUE;
		} else {
		// Check for HAL device in alternate format
		if(CheckFormat(AltFormat, FALSE, TRUE) == TRUE) {
			m_HAL = TRUE;
			Format = AltFormat;
		} else {
			// Check for Emulation device
			if(CheckFormat(Format, FALSE, FALSE) == FALSE) {
			// Check for Emulation device in alternate format
			if(CheckFormat(AltFormat, FALSE, FALSE) == FALSE)
				return FALSE;
			else
				Format = AltFormat;
			}
		}
		}

		d3dpp.BackBufferFormat = Format;
	}

	// Setup Zbuffer format - 16 bit
	if((m_ZBuffer = UseZBuffer) == TRUE) {
		d3dpp.EnableAutoDepthStencil = TRUE;
		d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	} else {
		d3dpp.EnableAutoDepthStencil = FALSE;
	}

	// Create the Direct3D Device object
	if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT, 
				(m_HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF, 
				m_hWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING,
				&d3dpp, &m_pD3DDevice))) {

		// Try to create Direct3D without ZBuffer support 
		// if selected and first call failed.
		if(m_ZBuffer == TRUE) {
		m_ZBuffer = FALSE;
		d3dpp.EnableAutoDepthStencil = FALSE;

		if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT, 
					(m_HAL == TRUE) ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF, 
					m_hWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING,
					&d3dpp, &m_pD3DDevice)))
			return FALSE;
		} else                                   
		return FALSE;
	}
	return TRUE;
}

BOOL CGraphic::BeginScene()
{
	// Error checking
	if(m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->BeginScene()))
		return FALSE;

	return TRUE;
}

BOOL CGraphic::EndScene()
{
	// Error checking
	if(m_pD3DDevice == NULL)
		return FALSE;

	// End the scene
	if(FAILED(m_pD3DDevice->EndScene()))
		return FALSE;

	return TRUE;
}

BOOL CGraphic::Display()
{
	if(m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->Present(NULL, NULL, NULL, NULL)))
		return FALSE;

	return TRUE;
}

BOOL CGraphic::ClearScene(long Color, float ZBuffer)
{
	if(m_pD3DDevice == NULL)
		return FALSE;

	// Only clear screen if no zbuffer
	if(m_ZBuffer == FALSE)
			if (FAILED(m_pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET, Color, 1.0f, 0)))
				return FALSE;

	// Clear display and zbuffer
	if(FAILED(m_pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, Color, ZBuffer, 0)))
		return FALSE;

	return TRUE; 
}

BOOL CGraphic::ClearZBuffer(float ZBuffer)
{
	if(m_pD3DDevice == NULL || m_ZBuffer == FALSE)
		return FALSE;

	if(FAILED(m_pD3DDevice->Clear(0, NULL, D3DCLEAR_ZBUFFER, 0, ZBuffer, 0)))
		return FALSE;

	return TRUE;
}

long CGraphic::GetWidth()
{
	return m_Width;
}

long CGraphic::GetHeight()
{
	return m_Height;
}

char CGraphic::GetBPP()
{
	return m_BPP;
}

BOOL CGraphic::GetHAL()
{
	return m_HAL;
}
    
BOOL CGraphic::GetZBuffer()
{
	return m_ZBuffer;
}

BOOL CGraphic::SetCamera(CCamera *Camera)
{
	if(m_pD3DDevice == NULL || Camera == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_VIEW, Camera->GetMatrix())))
		return FALSE;

	return TRUE;
}

BOOL CGraphic::SetPerspective(float FOV, float Aspect, float Near, float Far)
{
	D3DXMATRIX matProjection;

	if(m_pD3DDevice == NULL)
		return FALSE;

	D3DXMatrixPerspectiveFovLH(&matProjection, FOV, Aspect, Near, Far);
	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_PROJECTION, &matProjection)))
		return FALSE;
	return TRUE;
}

BOOL CGraphic::SetWorldPosition(CWorldPosition *WorldPos)
{
	if(WorldPos == NULL || m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetTransform(D3DTS_WORLD, WorldPos->GetMatrix(this))))
		return FALSE;

	return TRUE;
}

BOOL CGraphic::SetLight(long Num, CLight *Light)
{
	if(Light == NULL)
		return FALSE;
	if(m_pD3DDevice == NULL)
		return FALSE;

	if(FAILED(m_pD3DDevice->SetLight(Num, Light->GetLight())))
		return FALSE;
	return TRUE;
}

BOOL CGraphic::SetMaterial(CMaterial *Material)
{
	if(m_pD3DDevice == NULL)
		return FALSE;

	if(Material != NULL) {
		if(FAILED(m_pD3DDevice->SetMaterial(Material->GetMaterial())))
		return FALSE;
	}

	return TRUE;
}

BOOL CGraphic::SetTexture(short Num, CTexture *Texture)
{
	// Error checking
	if(m_pD3DDevice == NULL || Num < 0 || Num > 7)
		return FALSE;

	if(Texture == NULL) {
		// Clear the texture
		if(FAILED(m_pD3DDevice->SetTexture(Num, NULL)))
		return NULL;
	} else 
	{
		// Set the texture
		if(FAILED(m_pD3DDevice->SetTexture(Num, Texture->GetTexture())))
		return FALSE;
	}

	return TRUE;
}

BOOL CGraphic::SetAmbientLight(char Red, char Green, char Blue)
{
  D3DCOLOR Color;

  if(m_pD3DDevice == NULL)
    return FALSE;

  Color = D3DCOLOR_XRGB((m_AmbientRed = Red), (m_AmbientGreen = Green), (m_AmbientBlue = Blue));
  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_AMBIENT, Color)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::GetAmbientLight(char *Red, char *Green, char *Blue)
{
  if(Red != NULL)
    *Red = m_AmbientRed;
  if(Green != NULL)
    *Green = m_AmbientGreen;
  if(Blue != NULL)
    *Blue = m_AmbientBlue;

  return TRUE;
}

BOOL CGraphic::EnableLight(long Num, BOOL Enable)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->LightEnable(Num, Enable)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::EnableLighting(BOOL Enable)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_LIGHTING, Enable)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::EnableZBuffer(BOOL Enable)
{
  if(m_pD3DDevice == NULL || m_ZBuffer == FALSE)
    return FALSE;

  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ZENABLE, (Enable == TRUE) ? D3DZB_TRUE : D3DZB_FALSE)))
    return FALSE;

  return TRUE;
}

BOOL CGraphic::EnableAlphaBlending(BOOL Enable, DWORD Src, DWORD Dest)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  // Enable or disable
  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, Enable)))
    return FALSE;

  // Set blend type
  if(Enable == TRUE) {
    m_pD3DDevice->SetRenderState(D3DRS_SRCBLEND,  Src);
    m_pD3DDevice->SetRenderState(D3DRS_DESTBLEND, Dest);
  }

  return TRUE;
}

BOOL CGraphic::EnableAlphaTesting(BOOL Enable)
{
  if(m_pD3DDevice == NULL)
    return FALSE;

  if(FAILED(m_pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, Enable)))
    return FALSE;

  // Set test type
  if(Enable == TRUE) {
    m_pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x10);
    m_pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
  }

  return TRUE;
}