#include "HGlobal.h"

CVertexBuffer::CVertexBuffer()
{
  m_Graphics = NULL;
  m_pVB = NULL;
  m_NumVertices = 0;
  m_FVF = 0;
  m_Locked = FALSE;
  m_Ptr = NULL;
  m_NodeTree = FALSE;
}

CVertexBuffer::~CVertexBuffer()
{
  Cleanup();
}

IDirect3DVertexBuffer8 *CVertexBuffer::GetVertexBufferCOM()
{
  return m_pVB;
}

unsigned long CVertexBuffer::GetVertexSize()
{
  return D3DXGetFVFVertexSize(m_FVF);
}

unsigned long CVertexBuffer::GetVertexFVF()
{
  return m_FVF;
}

unsigned long CVertexBuffer::GetNumVertices()
{
  return m_NumVertices;
}

BOOL CVertexBuffer::Create(CGraphic *Graphics, unsigned long NumVertices, DWORD Descriptor, long VertexSize, BOOL nodetree)
{
  Cleanup();

  m_NodeTree = nodetree;
  if((m_Graphics = Graphics) == NULL)
    return FALSE;
  if(m_Graphics->GetDevice() == NULL)
    return FALSE;
  if(!(m_NumVertices = NumVertices) || !(m_FVF = Descriptor) || !(m_VertexSize = VertexSize))
    return FALSE;

  if (m_NodeTree)
  {
		if(FAILED(m_Graphics->GetDevice()->CreateVertexBuffer(
		   m_NumVertices * m_VertexSize,
		   D3DUSAGE_DYNAMIC, m_FVF,
		   D3DPOOL_DEFAULT, &m_pVB)))
		return FALSE;
  }else
  {
		if(FAILED(m_Graphics->GetDevice()->CreateVertexBuffer(
			m_NumVertices * m_VertexSize,
			D3DUSAGE_SOFTWAREPROCESSING , m_FVF,
			D3DPOOL_MANAGED, &m_pVB)))
			return FALSE;
  
  }

  return TRUE;
}

BOOL CVertexBuffer::Cleanup()
{
  Unlock();
  ReleaseCOM(m_pVB);
  m_Graphics = NULL;
  m_NumVertices = 0;
  m_FVF = 0;
  m_Locked = FALSE;
  m_Ptr = NULL;

  return TRUE;
}

BOOL CVertexBuffer::Set(unsigned long FirstVertex, unsigned long NumVertices, void *VertexList)
{
  if(m_Graphics == NULL || VertexList == NULL || m_pVB == NULL)
    return FALSE;
  if(m_Graphics->GetDevice() == NULL)
    return FALSE;

  // Lock the vertex buffer
  if(Lock(FirstVertex, NumVertices) == FALSE)
    return FALSE;

  // Copy vertices to vertex buffer
  memcpy(m_Ptr, VertexList, NumVertices * m_VertexSize);

  // Unlock vertex buffer
  if(Unlock() == FALSE)
    return FALSE;

  return TRUE;
}

BOOL CVertexBuffer::Render(unsigned long FirstVertex, unsigned long NumPrimitives, DWORD Type)
{
  if(m_Graphics->GetDevice() == NULL || m_pVB == NULL)
    return FALSE;

  m_Graphics->GetDevice()->SetStreamSource(0, m_pVB, m_VertexSize);
  m_Graphics->GetDevice()->SetVertexShader(m_FVF);
  m_Graphics->GetDevice()->DrawPrimitive((D3DPRIMITIVETYPE)Type, FirstVertex, NumPrimitives);
  
  return TRUE;
}

BOOL CVertexBuffer::Lock(unsigned long FirstVertex, unsigned long NumVertices)
{
  if(m_pVB == NULL)
    return FALSE;

  if(FAILED(m_pVB->Lock(FirstVertex * m_VertexSize, 
            NumVertices * m_VertexSize, (BYTE**)&m_Ptr, 
            (m_NodeTree?D3DLOCK_NOSYSLOCK | D3DLOCK_DISCARD:0))))
		return FALSE;
  
  m_Locked = TRUE;

  return TRUE;
}

BOOL CVertexBuffer::Unlock()
{ 
  if(m_pVB == NULL)
    return FALSE;

  if(FAILED(m_pVB->Unlock()))
    return FALSE;

  m_Locked = FALSE;

  return TRUE;
}

BOOL CVertexBuffer::IsLoaded()
{
  return (m_pVB == NULL) ? FALSE : TRUE;
}

void *CVertexBuffer::GetPtr()
{
  return (void*)m_Ptr;
}
