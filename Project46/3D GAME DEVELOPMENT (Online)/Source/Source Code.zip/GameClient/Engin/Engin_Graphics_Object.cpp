#include "HGlobal.h"

CObject::CObject()
{
  m_Graphics       = NULL;
  m_Mesh           = NULL;
  m_AnimationSet   = NULL;
}

CObject::~CObject()
{
  Cleanup();
}

BOOL CObject::Create(CGraphic *Graphics, CMesh *Mesh)
{
  if((m_Graphics = Graphics) == NULL)
    return FALSE;
  m_Mesh = Mesh;

  Move(0.0f, 0.0f, 0.0f);
  Rotate(0.0f, 0.0f, 0.0f);
  Scale(1.0f, 1.0f, 1.0f);

  return TRUE;
}

BOOL CObject::Cleanup()
{
  m_Graphics     = NULL;
  m_Mesh         = NULL;
  m_AnimationSet = NULL;

  return TRUE;
}

BOOL CObject::EnableBillboard(BOOL Enable)
{
  m_Pos.EnableBillboard(Enable);
  return TRUE;
}

BOOL CObject::AttachToObject(CObject *Object, char *FrameName)
{
  sFrame *Frame;

  if(Object == NULL || Object->m_Mesh == NULL) {
    m_Pos.SetCombineMatrix1(NULL);
    m_Pos.SetCombineMatrix2(NULL);
  } else {
    Frame = Object->m_Mesh->GetFrame(FrameName);
    if(Frame == NULL) {
      m_Pos.SetCombineMatrix1(NULL);
      m_Pos.SetCombineMatrix2(NULL);
    } else {
      m_Pos.SetCombineMatrix1(&Frame->m_matCombined);
      m_Pos.SetCombineMatrix2(Object->m_Pos.GetMatrix());
    }
  }

  return TRUE;
}

BOOL CObject::Move(float XPos, float YPos, float ZPos)
{
  return m_Pos.Move(XPos, YPos, ZPos);
}

BOOL CObject::MoveRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.MoveRel(XAdd, YAdd, ZAdd);
}

BOOL CObject::Rotate(float XRot, float YRot, float ZRot)
{
  return m_Pos.Rotate(XRot, YRot, ZRot);
}

BOOL CObject::RotateRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.RotateRel(XAdd, YAdd, ZAdd);
}

BOOL CObject::Scale(float XScale, float YScale, float ZScale)
{
  return m_Pos.Scale(XScale, YScale, ZScale);
}

BOOL CObject::ScaleRel(float XAdd, float YAdd, float ZAdd)
{
  return m_Pos.ScaleRel(XAdd, YAdd, ZAdd);
}

D3DXMATRIX *CObject::GetMatrix()
{
  return m_Pos.GetMatrix(); 
}

BOOL CObject::SetMesh(CMesh *Mesh)
{
  m_Mesh = Mesh;

  return TRUE;
}

CMesh *CObject::GetMesh()
{
  return m_Mesh;
}

BOOL CObject::SetAnimation(CAnimation *Animation, char *Name, unsigned long StartTime)
{
  m_StartTime = StartTime;
  if(Animation == NULL)
    m_AnimationSet = NULL;
  else
    m_AnimationSet = Animation->GetAnimationSet(Name);

  return TRUE;
}

char *CObject::GetAnimation()
{
  if(m_AnimationSet == NULL)
    return NULL;
  return m_AnimationSet->m_Name;
}

BOOL CObject::ResetAnimation(unsigned long StartTime)
{
  m_StartTime = StartTime;
  return TRUE;
}

float CObject::GetXPos()
{
  return m_Pos.GetXPos();
}

float CObject::GetYPos()
{
  return m_Pos.GetYPos();
}

float CObject::GetZPos()
{
  return m_Pos.GetZPos();
}

float CObject::GetXRotation()
{
  return m_Pos.GetXRotation();
}

float CObject::GetYRotation()
{
  return m_Pos.GetYRotation();
}

float CObject::GetZRotation()
{
  return m_Pos.GetZRotation();
}

float CObject::GetXScale()
{
  return m_Pos.GetXScale();
}

float CObject::GetYScale()
{
  return m_Pos.GetYScale();
}

float CObject::GetZScale()
{
  return m_Pos.GetZScale();
}

BOOL CObject::GetBounds(float *MinX, float *MinY, float *MinZ, float *MaxX, float *MaxY, float *MaxZ, float *Radius)
{
  float Length, XScale, YScale, ZScale;

  if(m_Mesh == NULL)
    return FALSE;

  m_Mesh->GetBounds(MinX, MinY, MinZ, MaxX, MaxY, MaxZ, Radius);

  // Scale bounds
  XScale = m_Pos.GetXScale();
  YScale = m_Pos.GetYScale();
  ZScale = m_Pos.GetZScale();

  if(MinX != NULL)
    *MinX *= XScale;
  if(MinY != NULL)
    *MinY *= YScale;
  if(MinZ != NULL)
    *MinZ *= ZScale;

  if(MaxX != NULL)
    *MaxX *= XScale;
  if(MaxY != NULL)
    *MaxY *= YScale;
  if(MaxZ != NULL)
    *MaxZ *= ZScale;

  if(Radius != NULL) {
    Length = (float)sqrt(XScale*XScale+YScale*YScale+ZScale*ZScale);
    (*Radius) *= Length;
  }

  return TRUE;
}

BOOL CObject::Update()
{
  // Update the world position
  m_Pos.Update(m_Graphics);

  return TRUE;
}

BOOL CObject::UpdateAnimation(unsigned long Time, BOOL Smooth)
{
  if(m_AnimationSet != NULL) {
    m_Mesh->GetParentFrame()->ResetMatrices();
    m_AnimationSet->Update(Time - m_StartTime, Smooth);
  }

  return TRUE;
}

BOOL CObject::AnimationComplete(unsigned long Time)
{
  if(m_AnimationSet == NULL)
    return TRUE;
  if((Time - m_StartTime) >= m_AnimationSet->m_Length)
    return TRUE;
  return FALSE;
}

BOOL CObject::Render()
{
  D3DXMATRIX Matrix;
  
  // Error checking
  if(m_Graphics == NULL || m_Mesh == NULL || m_Mesh->GetParentFrame() == NULL || m_Mesh->GetParentMesh() == NULL)
    return FALSE;

  // Update the object matrix
  Update();

  // Update the frame matrices
  D3DXMatrixIdentity(&Matrix);
  UpdateFrame(m_Mesh->GetParentFrame(), &Matrix);

  // Copy frame matrices to bone matrices
  m_Mesh->GetParentMesh()->CopyFrameToBoneMatrices();

  // Draw all frame meshes
  DrawFrame(m_Mesh->GetParentFrame());

  return TRUE;
}

void CObject::UpdateFrame(sFrame *Frame, D3DXMATRIX *Matrix)
{
  // Return if no more frames
  if(Frame == NULL)
    return;

  // Calculate frame matrix based on animation or not
  if(m_AnimationSet == NULL)
    D3DXMatrixMultiply(&Frame->m_matCombined, &Frame->m_matOriginal, Matrix);
  else
    D3DXMatrixMultiply(&Frame->m_matCombined, &Frame->m_matTransformed, Matrix);

  // Update child frames
  UpdateFrame(Frame->m_Child, &Frame->m_matCombined);

  // Update sibling frames
  UpdateFrame(Frame->m_Sibling, Matrix);
}

void CObject::DrawFrame(sFrame *Frame)
{
  sFrameMeshList *List;
  sMesh          *Mesh;
  D3DXMATRIX      matWorld;
  DWORD           i;
  int nTextureAddressing = D3DTADDRESS_WRAP;
  
  if(Frame == NULL)
    return;

  if((List = Frame->m_MeshList) != NULL) {
    while(List != NULL) {

      // See if there's a mesh to draw
      if((Mesh = List->m_Mesh) != NULL) {

        // Generate the mesh if using bones and set world matrix
        if(Mesh->m_NumBones && Mesh->m_SkinMesh != NULL) {
          Mesh->m_SkinMesh->UpdateSkinnedMesh(Mesh->m_Matrices,NULL, Mesh->m_Mesh);

          // Set object world transformation
          m_Graphics->GetDevice()->SetTransform(D3DTS_WORLD, m_Pos.GetMatrix());
        } else {
          // Set the world transformation matrix for this frame
          D3DXMatrixMultiply(&matWorld, &Frame->m_matCombined, m_Pos.GetMatrix());
          m_Graphics->GetDevice()->SetTransform(D3DTS_WORLD, &matWorld);
        }

		m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_ADDRESSU, nTextureAddressing);
		m_Graphics->GetDevice()->SetTextureStageState(0, D3DTSS_ADDRESSV, nTextureAddressing);

        // Loop through materials and draw the mesh
        for(i=0;i<Mesh->m_NumMaterials;i++) {
          // Don't draw materials with no alpha (0.0)
          if(Mesh->m_Materials[i].Diffuse.a != 0.0f) {
            m_Graphics->GetDevice()->SetMaterial(&Mesh->m_Materials[i]);
            m_Graphics->GetDevice()->SetTexture(0, Mesh->m_Textures[i]);

            // Enabled alpha blending based on material alpha
            if(Mesh->m_Materials[i].Diffuse.a != 1.0f)
              m_Graphics->EnableAlphaBlending(TRUE, D3DBLEND_SRCCOLOR, D3DBLEND_ONE);

            Mesh->m_Mesh->DrawSubset(i);

            // Disable alpha blending based on material alpha
            if(Mesh->m_Materials[i].Diffuse.a != 1.0f)
              m_Graphics->EnableAlphaBlending(FALSE);
          }
        }
      }

      // Next mesh in list
      List = List->m_Next;
    }
  }

  // Next child mesh
  DrawFrame(Frame->m_Child);
  DrawFrame(Frame->m_Sibling);
}
