#include "HGlobal.h"

CLight::CLight()
{
  // Set a default light to point
  ZeroMemory(&m_Light, sizeof(D3DLIGHT8));
  SetType(D3DLIGHT_POINT);
  Move(0.0f, 0.0f, 0.0f);
  SetDiffuseColor(255,255,255);
  SetAmbientColor(255,255,255);
  SetRange(1000.0f);
}

D3DLIGHT8 *CLight::GetLight()
{
  return &m_Light;
}

BOOL CLight::SetType(D3DLIGHTTYPE Type)
{
  m_Light.Type = Type;
  return TRUE;
}

BOOL CLight::Move(float XPos, float YPos, float ZPos)
{
  m_Light.Position.x = XPos;
  m_Light.Position.y = YPos;
  m_Light.Position.z = ZPos;
  return TRUE;
}

BOOL CLight::MoveRel(float XPos, float YPos, float ZPos)
{
  m_Light.Position.x += XPos;
  m_Light.Position.y += YPos;
  m_Light.Position.z += ZPos;
  return TRUE;
}

BOOL CLight::GetPos(float *XPos, float *YPos, float *ZPos)
{
  if(XPos != NULL)
    *XPos = m_Light.Position.x;
  if(YPos != NULL)
    *YPos = m_Light.Position.y;
  if(ZPos != NULL)
    *ZPos = m_Light.Position.z;
  return TRUE;
}

BOOL CLight::Point(float XFrom, float YFrom, float ZFrom,
                   float XAt,   float YAt,   float ZAt)
{
  D3DXVECTOR3 vecDir;
  
  // Move the light
  Move(XFrom, YFrom, ZFrom);

  // Calculate vector between angles
  vecDir = D3DXVECTOR3( XAt - XFrom, YAt - YFrom, ZAt - ZFrom);

  D3DXVec3Normalize((D3DXVECTOR3*) &m_Light.Direction, &vecDir);


  return TRUE;
}

BOOL CLight::GetDirection(float *XDir, float *YDir, float *ZDir)
{
  if(XDir != NULL)
    *XDir = m_Light.Direction.x;
  if(YDir != NULL)
    *YDir = m_Light.Direction.y;
  if(ZDir != NULL)
    *ZDir = m_Light.Direction.z;
  return TRUE;
}

BOOL CLight::SetDiffuseColor(float Red, float Green, float Blue)
{
  m_Light.Diffuse.r = 1.0f / 255.0f * (float)Red;
  m_Light.Diffuse.g = 1.0f / 255.0f * (float)Green;
  m_Light.Diffuse.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLight::GetDiffuseColor(float *Red, float *Green, float *Blue)
{
  if(Red != NULL)
    *Red = (255.0f * m_Light.Diffuse.r);

  if(Green != NULL)
    *Green = (255.0f * m_Light.Diffuse.g);

  if(Blue != NULL)
    *Blue = (255.0f * m_Light.Diffuse.b);

  return TRUE;
}

BOOL CLight::SetSpecularColor(float Red, float Green, float Blue)
{
  m_Light.Specular.r = 1.0f / 255.0f * (float)Red;
  m_Light.Specular.g = 1.0f / 255.0f * (float)Green;
  m_Light.Specular.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLight::GetSpecularColor(float *Red, float *Green, float *Blue)
{
  if(Red != NULL)
    *Red = (255.0f * m_Light.Specular.r);

  if(Green != NULL)
    *Green = (255.0f * m_Light.Specular.g);

  if(Blue != NULL)
    *Blue = (255.0f * m_Light.Specular.b);

  return TRUE;
}

BOOL CLight::SetAmbientColor(float Red, float Green, float Blue)
{
  m_Light.Ambient.r = 1.0f / 255.0f * (float)Red;
  m_Light.Ambient.g = 1.0f / 255.0f * (float)Green;
  m_Light.Ambient.b = 1.0f / 255.0f * (float)Blue;

  return TRUE;
}

BOOL CLight::GetAmbientColor(float *Red, float *Green, float *Blue)
{
  if(Red != NULL)
    *Red = (255.0f * m_Light.Ambient.r);

  if(Green != NULL)
    *Green = (255.0f * m_Light.Ambient.g);

  if(Blue != NULL)
    *Blue = (255.0f * m_Light.Ambient.b);

  return TRUE;
}

BOOL CLight::SetRange(float Range)
{
  m_Light.Range = Range;
  return TRUE;
}

float CLight::GetRange()
{
  return m_Light.Range;
}

BOOL CLight::SetFalloff(float Falloff)
{
  m_Light.Falloff = Falloff;
  return TRUE;
}

float CLight::GetFalloff()
{
  return m_Light.Falloff;
}

BOOL CLight::SetAttenuation0(float Attenuation)
{
  m_Light.Attenuation0 = Attenuation;
  return TRUE;
}

float CLight::GetAttenuation0()
{
  return m_Light.Attenuation0;
}

BOOL CLight::SetAttenuation1(float Attenuation)
{
  m_Light.Attenuation1 = Attenuation;
  return TRUE;
}

float CLight::GetAttenuation1()
{
  return m_Light.Attenuation1;
}

BOOL CLight::SetAttenuation2(float Attenuation)
{
  m_Light.Attenuation2 = Attenuation;
  return TRUE;
}

float CLight::GetAttenuation2()
{
  return m_Light.Attenuation2;
}

BOOL CLight::SetTheta(float Theta)
{
  m_Light.Theta = Theta;
  return TRUE;
}

float CLight::GetTheta()
{
  return m_Light.Theta;
}

BOOL CLight::SetPhi(float Phi)
{
  m_Light.Phi = Phi;
  return TRUE;
}

float CLight::GetPhi()
{
  return m_Light.Phi;
}
