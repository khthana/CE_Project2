#include "HGlobal.h"

CFont::CFont()
{
	m_Font = NULL;
}

CFont::~CFont()
{
	Cleanup();
}

ID3DXFont *CFont::GetFont()
{
	return m_Font;
}

BOOL CFont::Create(CGraphic *Graphics, char *Name, long Size, BOOL Bold, BOOL Italic, BOOL Underline, BOOL Strikeout)
{
	LOGFONT lf;

	if(Graphics == NULL || Name == NULL)
		return FALSE;
	if(Graphics->GetDevice() == NULL)
		return FALSE;

	// Clear out the font structure
	ZeroMemory(&lf, sizeof(LOGFONT));

	// Set the font name and height
	strcpy(lf.lfFaceName, Name);
	lf.lfHeight = -Size;
	lf.lfWeight = (Bold == TRUE) ? 700 : 0;
	lf.lfItalic = Italic;
	lf.lfUnderline = Underline;
	lf.lfStrikeOut = Strikeout;

	// Create the font object
	if(FAILED(D3DXCreateFontIndirect(Graphics->GetDevice(), &lf, &m_Font)))
		return FALSE;
	return TRUE;
}

BOOL CFont::Cleanup()
{
	SAFE_RELEASE(m_Font);
	return TRUE;
}

BOOL CFont::BeginDraw()
{
	if(m_Font == NULL)
		return FALSE;
	if(FAILED(m_Font->Begin()))
		return FALSE;
	return TRUE;
}

BOOL CFont::EndDraw()
{
	if(m_Font == NULL)
		return FALSE;
	if(FAILED(m_Font->End()))
		return FALSE;
	return TRUE;
}

BOOL CFont::Print(char *Text, long XPos, long YPos, long Width, long Height, D3DCOLOR Color, DWORD Format)
{
	RECT Rect;

	if(m_Font == NULL)
		return FALSE;

	if(!Width)
		Width = 65535;
	if(!Height)
		Height = 65536;

	Rect.right  = XPos + Width;
	Rect.bottom = YPos + Height;

	// Draw Shadow
	Rect.left   = XPos - 2;
	Rect.top    = YPos;
	if(FAILED(m_Font->DrawText(Text, -1, &Rect, Format, 0xff000000)))
		return FALSE;
	Rect.left   = XPos + 2;
	if(FAILED(m_Font->DrawText(Text, -1, &Rect, Format, 0xff000000)))
		return FALSE;
	Rect.left   = XPos;
	Rect.top    = YPos - 1;
	if(FAILED(m_Font->DrawText(Text, -1, &Rect, Format, 0xff000000)))
		return FALSE;
	Rect.top    = YPos + 1;
	if(FAILED(m_Font->DrawText(Text, -1, &Rect, Format, 0xff000000)))
		return FALSE;

	// Draw Text
	Rect.left   = XPos;
	Rect.top    = YPos;
	if(FAILED(m_Font->DrawText(Text, -1, &Rect, Format, Color)))
		return FALSE;

	return TRUE;
}
