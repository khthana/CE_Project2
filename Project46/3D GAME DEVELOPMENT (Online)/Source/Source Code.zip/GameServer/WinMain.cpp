#include "HGlobal.h"

#include "WinMain.h"

#define WM_SOCKET	WM_USER+1	// Socket Windows Message

// Global names of character meshes
char *g_CharMeshNames[] = {
    { ".\\Model\\Character\\Human.x" },   // Mesh # 0
	{ ".\\Model\\Character\\npc_1.x"},
	{ ".\\Model\\Character\\npc_2.x"},
	{ ".\\Model\\Character\\npc_3.x"},
	{ ".\\Model\\Character\\npc_4.x"},
	{ ".\\Model\\Character\\npc_5.x"},
	{ ".\\Model\\Character\\npc_6.x"},
	{ ".\\Model\\Character\\npc_7.x"},
	{ ".\\Model\\Character\\mon_1.x"},
	{ ".\\Model\\Character\\mon_2.x"},
	{ ".\\Model\\Character\\boss.x"},
	{ ".\\Model\\Environment\\Box.x"},
	{ ".\\Model\\Environment\\warpport1.x"},
  };

/*sCharAnimationInfo g_CharAnimations[] = {
    { "IDLE",  TRUE  },
    { "WALK",  TRUE  },
    { "SWING", TRUE  },
};
*/
char *g_SpellMeshNames[] = {
	{ ".\\Model\\Spell\\fireball.x"}
};


CGame::CGame()
{
	FILE* fp;
	
	if ((fp=fopen(".\\Data\\config.cfg","rb"))!=NULL)
	{
		fscanf(fp,"%d%d%d%d%d",&m_Mode,&m_Width,&m_Height,&m_XPos,&m_YPos);
		fclose(fp);
	}
	
	//m_Style  = WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
	strcpy(m_Class, "Hacker Hunter");
	strcpy(m_Caption, "Hacker Hunter");
}

BOOL CGame::Init()
{

	ShowMouse(TRUE);
	
	hDlg = CreateDialog(GetInstanceHandle(),MAKEINTRESOURCE(IDD_DIALOG1),GetWindowHandle(),(DLGPROC)DlgProc);
	ShowWindow(hDlg, SW_SHOW);

	if (!m_DB.Init()) {
		MsgError("Can't connect MS ODBC SQL SERVER DRIVER");
		return FALSE;
	}

	m_Script.SetData(this);
	m_Script.SetMap(2);
	m_StageGame.Init(&m_DB); 
	m_CharacterControl.Init(&m_StageGame,&m_DB);

	m_Script.Execute(".\\Script\\Stage\\stage1.scp");
	 
	mutexHandle = CreateMutex(NULL, false, NULL);
	if (mutexHandle == NULL) {
		SetListAction("Can't Create Mutux");
		return FALSE;
	}

	m_CharacterControl.StartServer();
	
	return TRUE;
}

BOOL CGame::Shutdown()
{
	m_DB.Shutdown();
	m_CharacterControl.Shutdown();
	m_StageGame.Shutdown();
	CloseHandle(mutexHandle);
		
	return TRUE;
}

BOOL CGame::Frame()
{
	static DWORD UpdateCounter = timeGetTime();
	
	if(timeGetTime() < UpdateCounter + 30)
		return TRUE;

	dwFrameCount++;

	UpdateCounter = timeGetTime();

	m_CharacterControl.ListenClient();

	return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, PSTR, int)
{

	float a = D3DX_PI/12;
	float b = D3DXToDegree(a);

	CGame game;
	
	return game.Run();
	 
}

LRESULT CALLBACK CGame::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg) {
		case WM_DESTROY:
				EndDialog(hDlg,0);
				PostQuitMessage(0);
		break;

    default: return DefWindowProc(hWnd, uMsg, wParam, lParam);
  }

  return 0;

}
BOOL SetListConnection(char* msg)
{
	SendDlgItemMessage(hDlg,IDC_USER,LB_INSERTSTRING,-1,(LPARAM)msg);

	return TRUE;
}

BOOL DelListConnection(char* msg)
{
	SendDlgItemMessage(hDlg,IDC_USER,LB_DELETESTRING,SendDlgItemMessage(hDlg,IDC_USER,LB_FINDSTRING,-1,(LPARAM)msg),(LPARAM)msg);

	return TRUE;
}

BOOL SetListAction(char* msg)
{
	SendDlgItemMessage(hDlg,IDC_ACTION,LB_INSERTSTRING,-1,(LPARAM)msg);

	return TRUE;
}

LRESULT CALLBACK DlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{	case WM_INITDIALOG :
			
			break;
		case WM_COMMAND :
			switch (LOWORD(wParam))
			{
				case IDC_QUIT :
					EndDialog(hWnd,0);
					PostQuitMessage(0);
					break;
				default : break;
			}
			break;
		case WM_CLOSE :
			EndDialog(hWnd,0);
			PostQuitMessage(0);
			break;
	}
	return 0;
}