#ifndef _WINMAIN_H
#define _WINMAIN_H

class CGame;

#include "resource.h"
#include "CScript.h"
#include "CCharacterControl.h"
#include "CStageGame.h"

class CGameScript : public CScript
{
  private:
    BOOL       m_Flags[256];

	long		MapID;

//    CChars    *m_CharController;

	CGame		*m_App;
    long         m_NumRoutePoints;
    sRoutePoint *m_Route;

    // The script function prototypes
    sScript *Script_End(sScript*);
    sScript *Script_IfFlagThen(sScript*);
	sScript *Script_IfHaveItem(sScript*);
    sScript *Script_Else(sScript*);
    sScript *Script_EndIf(sScript*);
    sScript *Script_SetFlag(sScript*);
    sScript *Script_Message(sScript*);
	sScript *Script_CharMessage(sScript*);
	sScript *Script_CharQuestionMessage(sScript*);
    sScript *Script_AddChar(sScript*);
	sScript *Script_AddModel(sScript*);
    sScript *Script_RemoveChar(sScript*);
    sScript *Script_CharType(sScript*);
    sScript *Script_CharAI(sScript*);
    sScript *Script_CharDistance(sScript*);
    sScript *Script_CharBounds(sScript*);
    sScript *Script_TargetChar(sScript*);
    sScript *Script_NoTarget(sScript*);
    sScript *Script_CreateRoute(sScript*);
    sScript *Script_AddPoint(sScript*);
    sScript *Script_AssignRoute(sScript*);
    sScript *Script_MoveChar(sScript*);
    sScript *Script_CharScript(sScript*);
	sScript *Script_SetTransport(sScript*);
	sScript *Script_EnableTransport(sScript*);
	sScript *Script_LoadStage(sScript*);
	sScript *Script_LoadListModel_Env(sScript*);
	sScript *Script_LoadItemToChar(sScript*);
	sScript *Script_PlayMusicMidi(sScript*);
	Script_EndGame(sScript*);
	sScript *Script_Addexp(sScript*);
	sScript *Script_IfCharhaveExp(sScript*);

    // The overloaded processing functions
    BOOL     Prepare();
    BOOL     Release();
    sScript *Process(sScript *Script);

  public:
	CGameScript();
	~CGameScript();

	BOOL* GetFlag(){return m_Flags;}

	BOOL SetFlag(BOOL* flag)
	{
		for(int i=0;i<256;i++)
			m_Flags[i] = flag[i];
		return TRUE;
	}

	BOOL SetMap(int ID){MapID = ID;return TRUE;}

	BOOL ClearFlag()
	{
		ZeroMemory(m_Flags,sizeof(m_Flags));
		return TRUE;
	}

    BOOL SetData(CGame *Application);

};

LRESULT CALLBACK DlgProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam);

class CGame : public CApplication
{
private:
	friend class	CGameScript;

	CDB				m_DB;
	CCharacterController	m_CharacterControl;
	CStageGame		m_StageGame;
	CGameScript     m_Script;
	
	// WinSock globals
	SOCKET			m_Socket;
	sockaddr_in		m_Addr;
	INT				m_IP[4];

	INT				m_Mode;
public:
	CGame();

	HANDLE			acceptHandle;

	BOOL			Init();
	BOOL			Frame();
	BOOL			Shutdown();

	// Winsock 

	LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif