#ifndef _CCHARACTER_H
#define _CCHARACTER_H

#include "CStageGame.h"
#include "MCL.h"
#include "CUser.h"

UINT ProcThread(LPVOID pParam);

class CCharacter
{
private:
	CStageGame *m_StageGame;
	sCharacter *m_Character;
	sCharacter *m_CharacterParent;     // List of characters

	   // Character update function for all non-PC characters
    BOOL CharUpdate(long Elapsed,      \
                    float *XMove, float *YMove, float *ZMove);

    // Check for valid movements. Bounds check to other 
    // characters and call ValidateMove (overidden).
    BOOL CheckMove(float *XMove, float *YMove, float *ZMove);

	BOOL MakePath(int Stx, int Sty);

	void ShortestPath(int stx,int sty,int tx,int ty,int step);

	BOOL SortArr();

    // Virtual ValidateMove for outside bounds checking
    // against character movements.
    BOOL ValidateMove(float *XMove, float *YMove, float *ZMove);                   

    // Finish movement by setting direction, animation, etc
    BOOL ProcessUpdate(float XMove, float YMove, float ZMove);

public:
	CUser* m_UserParent;
	CCharacter *Prev, *Next;  // Linked list of characters
	CWinThread* m_Thread;
	int			SERVER_QUIT;

	CCharacter(CStageGame* StageGame, sCharacter* CharParent, sCharacter* Character)
	{
		SERVER_QUIT = 0;
		m_UserParent = NULL;
		m_StageGame = StageGame;
		m_CharacterParent = CharParent;
		m_Character = Character;
		Prev = NULL;
		Next = NULL;
	}
	~CCharacter(){
		SERVER_QUIT = 1;
		CloseThread();
		m_StageGame  = NULL;
		m_Character  = NULL;
		m_CharacterParent = NULL;
		//if (Prev != NULL) delete Prev;
		if (Next != NULL) 
			delete Next;
	}

	void SetUserInfo(CUser* user)
	{
		m_UserParent = user;
	}

	long CheckEvent();

	BOOL RoutePath(D3DXVECTOR2 CharPos,D3DXVECTOR2 DestPos);

    // Update all characters based on elapsed time
	BOOL CreateMonsterthread();

	BOOL CloseThread();

    void Update();

	// Retrieve an sCharacter structure
    sCharacter *GetParentCharacter();

	sCharacter *GetCharacter();
	sCharacter *GetCharacter(long IDNum);

	// Function to retrieve adjusted ability/other info
    // Function to retrieve adjusted ability/other info
    float GetSpeed(sCharacter *Character);
    long  GetAttack(sCharacter *Character);
    long  GetDefense(sCharacter *Character);
    long  GetAgility(sCharacter *Character);
    long  GetResistance(sCharacter *Character);
    long  GetMental(sCharacter *Character);
    long  GetToHit(sCharacter *Character);
    float GetCharge(sCharacter *Character);

	// Set lock and action timer
    BOOL SetLock(BOOL State);
    BOOL SetActionTimer(long IDNum,long Timer);

    // Set evade/follow distance
    BOOL  SetDistance(float Distance);
    float GetDistance();

    // Set route points
    BOOL SetRoute(long NumPoints, sRoutePoint *Route);
	
	// Set script 
    BOOL SetScript(char *ScriptFilename);
    char *GetScript();

    // Set enable flags
    BOOL SetEnable(BOOL Enable);
    BOOL GetEnable();

	BOOL GetPosition(float *XPos, float *YPos, float *ZPos);

	// Functions to Set/Get character type
    BOOL SetType(long Type);
    long GetType();

    // Functions to Set/Get character AI
    BOOL SetAI(long Type);
    long GetAI();

	CStageGame* GetStageGame(){return m_StageGame;}
	BYTE** GetMapArr(int id){return m_StageGame->GetTerrain(id)->GetMapArr();}

	// Set a target character
    BOOL SetTargetCharacter(long TargetNum);

	// Set text messages to float up from character
    BOOL SetMessage(sCharacter *Character, char *Text,        \
                long Timer, D3DCOLOR Color=0xFFFFFFFF);

	// Process attack damage from spells and physical attacks
    BOOL Damage(sCharacter *Victim,                           \
                BOOL PhysicalAttack, long Amount,             \
                long DmgClass, long CureClass);

    // Process death of an NPC/Monster
    BOOL Death(sCharacter *Attacker, sCharacter *Victim);

    // Process experience up
    virtual BOOL Experience(sCharacter *Character,            \
                            long Amount)                      \
         { Character->Def.Experience += Amount; return TRUE; }

    // Resolve a physical attack from attacker to victim
    BOOL Attack(sCharacter *Attacker, sCharacter *Victim);

	// Set action (w/timer)
    BOOL SetAction(sCharacter *Character,                     \
                   long Action, long AddTime = 0);


};

#endif