#ifndef _CCHARACTERCONTROL_H_
#define _CCHARACTERCONTROL_H_

#include "CCharacter.h"
#include "CUser.h"

class CCharacterController
{
  private:
	CDB*	   m_DB;
	CStageGame *m_StageGame;		  // Stage Game
	CCharacter *m_CharsParent;
	CUser	   *m_UserParent;
	sCharacter *m_CharacterParent;     // List of characters

 
	long        m_NumCharacters;       // # characters in list
    //sSpell     *m_MSL;                 // Master spell list

   // CSpellController *m_SpellController; // Spell controller

	int			serverSocket;
	int			ClientSocket[1000];
	int			ClientCount;	

  public:
	CCharacterController();   // Constructor
    ~CCharacterController();  // Destructor

    // Functions to init/shutdown controller class
    BOOL Init(CStageGame* StageGame,CDB* DB);
	BOOL StartServer();
	BOOL ListenClient();
	BOOL Update();
	BOOL ShutdownServer();
    BOOL Shutdown();

    // Free class
    BOOL Cleanup();

    // Add a character to the list
    BOOL Add(long IDNum, char* name, long Definition, long Type, long AI, \
             float XPos, float YPos, float ZPos,              \
             float Direction = 0.0f, int MapID=0);

	BOOL AddUser(int ClSocket,int id);
	
	int CheckLogin(int clsock);

	sCharacter *GetParentCharacter();

	sCharacter *GetCharacter(long IDNum);

	CCharacter* GetChars(){return m_CharsParent;}
    // Remove a character from list
    BOOL Remove(long IDNum);
    BOOL Remove(sCharacter *Character);

	// Functions to Set/Get character bounds
    BOOL SetBounds(long IDNum,                                \
                   float MinX, float MinY, float MinZ,        \
                   float MaxX, float MaxY, float MaxZ);
    BOOL GetBounds(long IDNum,                                \
                   float *MinX, float *MinY, float *MinZ,     \
                   float *MaxX, float *MaxY, float *MaxZ);

	BOOL LoadItemListToChar(int IDNum);

};


#endif