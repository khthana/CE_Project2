#include "HGlobal.h"
#include "CUser.h"

sCharacter *CUser::GetParentCharacter()
{
  return m_CharacterParent;
}

sCharacter *CUser::GetCharacter()
{
  return m_Character;
}

sCharacter *CUser::GetCharacter(long IDNum)
{
  sCharacter *CharPtr;

  // Scan through all characters
  if((CharPtr = m_CharacterParent) != NULL) {
    while(CharPtr != NULL) {
    
      // Return character
      if(IDNum == CharPtr->ID)
        return CharPtr;
   
      // Go to next character
      CharPtr = CharPtr->Next;
    }
  }

  return NULL;
}

long CUser::CheckEvent()
{
	int XDiffMap,ZDiffMap;
	sCharacter* CharPtr;
	sCharacter* CharPC = GetCharacter();
	
	if ((CharPtr=m_CharacterParent)==NULL)
		return -1;

	while(CharPtr!=NULL)
	{		
		if (strcmp(CharPtr->ScriptFilename,"NONE"))
		{
			if (CharPC->ID != CharPtr->ID && CharPC->TargetChar != NULL && CharPC->NumPoints == 0 && CharPtr->Enabled)
			{
				XDiffMap = (int)fabs((CharPC->XPos/20)-(CharPtr->XPos/20));
				ZDiffMap = (int)fabs((CharPC->ZPos/20)-(CharPtr->ZPos/20));


				if (XDiffMap <= 1 && ZDiffMap <= 1)
					return CharPtr->ID;
			}
		}
		CharPtr = CharPtr->Next;
	}
	
	return -1;

}

float CUser::GetSpeed(sCharacter* Character)
{
  float Speed;
  
  // Error checking
  if(Character == NULL)
    return 0.0f;

  // Calculate adjusted speed
  Speed = Character->Def.Speed;

   // Bounds check value
  if(Speed < 1.0f)
    Speed = 1.0f;

  return Speed;
}

long CUser::GetAttack(sCharacter* Character)
{
  long Attack;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted attack
  Attack = Character->Def.Attack;

  // Adjust attack based on item value (in %(Value/100)+1)
  if(Character->Def.Weapon != -1 && m_StageGame->FindItemDef(0) != NULL) {
    Attack = (long)((float)Attack *                           \
             (((float)m_StageGame->FindItemDef(Character->Def.Weapon)->damageAttack /    \
             100.0f) + 1.0f));
  }

  return Attack;
}

long CUser::GetDefense(sCharacter* Character)
{
  long Defense;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted defense
  Defense = Character->Def.Defense;
  
  if(Character->Def.Armor != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Armor)->defense /     \
             100.0f) + 1.0f));

  if(Character->Def.Shield != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Shield)->defense /    \
             100.0f) + 1.0f));


  // Bounds check value
  if(Defense < 0)
    Defense = 0;

  return Defense;
}

long CUser::GetAgility(sCharacter* Character)
{
  long Agility;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted agility
  Agility = Character->Def.Agility;
  
  return Agility;
}

long CUser::GetResistance(sCharacter* Character)
{
  long Resistance;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted resistance
  Resistance = Character->Def.Resistance;
  
  return Resistance;
}

long CUser::GetMental(sCharacter* Character)
{
  long Mental;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted mental
  Mental = Character->Def.Mental;
  
  return Mental;
}

long CUser::GetToHit(sCharacter* Character)
{
  long ToHit;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted to hit
  ToHit = Character->Def.ToHit;

  return ToHit;
}

float CUser::GetCharge(sCharacter* Character)
{
  float Charge;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted charge
  Charge = Character->Def.ChargeRate;
  
  return Charge;
}

BOOL CUser::SetLock(BOOL State)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Locked = State;
  return TRUE;
}

BOOL CUser::SetActionTimer(long IDNum, long Timer)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->ActionTimer = Timer;
  return TRUE;
}

BOOL CUser::SetAction(sCharacter* Character,long Action,             \
                                     long AddTime)
{
  long MeshNum;

  // Error checking
  if(Character == NULL)
    return FALSE;

  // Set action
  Character->Action = Action;

  // Get mesh number
  MeshNum = Character->Def.MeshNum;

  // Set action time (or set to 1 is addtime = -1)
  if(AddTime == -1)
    Character->ActionTimer = 1;
  else
  {
    Character->ActionTimer = (Character->Def.Agility*33) + AddTime;
  }
  return TRUE;
}

BOOL CUser::SetDistance(float Distance)
{

  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Distance = Distance;
  return TRUE;
}

float CUser::GetDistance()
{
 
  if(m_Character == NULL)
    return 0.0f;
  return m_Character->Distance;
}

BOOL CUser::SetRoute(long NumPoints, sRoutePoint *Route)
{
   // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Free old route
  delete [] m_Character->Route;
  m_Character->Route = NULL;

  // Set new route
  if((m_Character->NumPoints = NumPoints) != NULL) {
    m_Character->Route = new sRoutePoint[NumPoints];
    memcpy(m_Character->Route,Route,NumPoints*sizeof(sRoutePoint));
    m_Character->CurrentPoint = 0;
  }

  return TRUE;
}

BOOL CUser::SetScript(char *ScriptFilename)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new script
  strcpy(m_Character->ScriptFilename, ScriptFilename);
  return TRUE;
}

char *CUser::GetScript()
{

  if(m_Character == NULL)
    return NULL;
  return m_Character->ScriptFilename;
}

BOOL CUser::SetEnable(BOOL Enabled)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Enabled = Enabled;
  return TRUE;
}

BOOL CUser::GetEnable()
{
  if(m_Character == NULL)
    return FALSE;
  return m_Character->Enabled;
}

BOOL CUser::SetMessage(sCharacter *Character,char *Text, long Timer,    \
                                   D3DCOLOR Color)
{
  strcpy(Character->Message, Text);
  Character->MessageTimer = Timer;
  
  sPacketMessage pkmsg;
  SetPacketMessage(pkmsg,2,3,Character->ID,Color,Timer,Text);

  WaitForSingleObject(mutexHandle, INFINITE);
	send(ClientSocket,(char*)&pkmsg,sizeof(pkmsg),0);
  ReleaseMutex(mutexHandle);

  return TRUE;
}

BOOL CUser::GetPosition( float *XPos, float *YPos, float *ZPos)
{
  if(m_Character == NULL)
    return FALSE;

  if(XPos != NULL)
    *XPos = m_Character->XPos;
  if(YPos != NULL)
    *YPos = m_Character->YPos;
  if(ZPos != NULL)
    *ZPos = m_Character->ZPos;

  return TRUE;
}

BOOL CUser::SetType(long Type)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Type = Type;
  return TRUE;
}

long CUser::GetType()
{
  
  if(m_Character == NULL)
    return 0;
  return m_Character->Type;
}

BOOL CUser::SetAI(long Type)
{
    // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->AI = Type;
  return TRUE;
}

long CUser::GetAI()
{
 
  if(m_Character == NULL)
    return 0;
  return m_Character->AI;
}

BOOL CUser::SetTargetCharacter(long TargetNum)
{
  sCharacter *CharTarget;

  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Clear if TargetNum == -1
  if(TargetNum == -1)
    m_Character->TargetChar = NULL;
  else {
    // Scan through list and target 1st TargetNum found
    CharTarget = m_CharacterParent;
    while(CharTarget != NULL) {
      if(CharTarget->ID == TargetNum) {
        m_Character->TargetChar = CharTarget;
        break;
      }
      CharTarget = CharTarget->Next;
    }

    // Clear target if not found in list
    if(CharTarget == NULL)
      m_Character->TargetChar = NULL;
  }
  return TRUE;
}

UINT ProcUserThread(LPVOID pParam)
{
	CUser* Char = (CUser*)pParam;

	Char->Update();

	return 0;
}

BOOL CUser::CreateUserthread()
{
	m_Thread = AfxBeginThread(ProcUserThread,(LPVOID)this);

	return TRUE;
}

BOOL CUser::CloseThread()
{
	if(m_Thread)
	{
		HANDLE hThread = m_Thread->m_hThread;

		::WaitForSingleObject(hThread,INFINITE);
	}
	
	return TRUE;
}

BOOL CUser::CheckPacket(char* buf)
{
	D3DXVECTOR2 CharMapPos;
	D3DXVECTOR2 DestMap;
	char str[100];
	sPacket* packet = (sPacket*)buf;
	sPacketWalk pk;
	sPacketChat pkchat;
	sPacketPlayer pkply;

	while(m_UserParent->Prev != NULL)
		m_UserParent = m_UserParent->Prev;
	
	sCharacter* Chars = NULL;
	CUser* user = m_UserParent;

	switch(packet->type)
	{
	case 2 : 
		switch(packet->action)
		{
		case 1 :
			
			memcpy(&pk,buf,sizeof(sPacketWalk));
			sprintf(str,"User :%s ,Move to %d ,%d",m_Character->Name,pk.xdest,pk.zdest);
			SetListAction(str);

			m_Character->FreePath();

			m_Character->TargetChar = NULL;

			m_Character->Victim = NULL;
							
			//Calculate Shortest Path
			m_Character->Direction = pk.direction;
			CharMapPos		= GetStageGame()->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);
			DestMap			= GetStageGame()->GetTerrain(m_Character->MapID)->GetMapPosition((float)pk.xdest*20,(float)pk.zdest*20);

			if (GetStageGame()->GetTerrain(m_Character->MapID)->CanMove((float)pk.xdest*20, (float)pk.zdest*20))
			{
				RoutePath(CharMapPos,DestMap);

				if (m_Character->NumPoints != 0)
				{
					m_Character->XDestPos = m_Character->Route[m_Character->NumPoints-1].XPos;
					m_Character->ZDestPos = m_Character->Route[m_Character->NumPoints-1].ZPos;

					m_Character->AI = CHAR_ROUTE;
				
					while(user != NULL)
					{
						Chars = user->GetCharacter();
						if (Chars->MapID == m_Character->MapID && user->Initial == 1)
						{
							WaitForSingleObject(mutexHandle, INFINITE);
								SetPacketWalk(pk,2,1,m_Character->ID,(char)((int)m_Character->XPos/20),\
									(char)((int)m_Character->ZPos/20),(char)((int)m_Character->XDestPos/20),(char)((int)m_Character->ZDestPos/20),m_Character->Direction);
								send(user->ClientSocket, (char*)&pk, sizeof(pk),0);
							ReleaseMutex(mutexHandle);
							
						}
						user = user->Next;
					}
				}
			}
			break;
		case 2 :
			sPacketToChar pkchar;
			memcpy(&pkchar,buf,sizeof(pkchar));
			sprintf(str,"User :%s ,to char ID[%i]",m_Character->Name, pkchar.IDVictim);
			SetListAction(str);

			m_Character->FreePath();

			m_Character->TargetChar = GetCharacter(pkchar.IDVictim);

			if (m_Character->TargetChar == NULL)
			{
				char aa[100];
				sprintf(aa,"No char ID[%d]",pkchar.IDVictim);
				SetListAction(aa);
				return FALSE;
			}else
			{
				if (m_Character->TargetChar->Type == CHAR_MONSTER)
				{
					m_Character->Victim = m_Character->TargetChar;
					m_Character->TargetChar->Attacker = m_Character;
				}else m_Character->Victim = NULL;
			}
			
			//Calculate Shortest Path
			CharMapPos	= GetStageGame()->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);
			DestMap		= GetStageGame()->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->TargetChar->XPos,m_Character->TargetChar->ZPos);

			RoutePath(CharMapPos,DestMap);

			if (m_Character->NumPoints != 0)
			{
				m_Character->XDestPos = m_Character->Route[m_Character->NumPoints-1].XPos;
				m_Character->ZDestPos = m_Character->Route[m_Character->NumPoints-1].ZPos;

				m_Character->AI = CHAR_ROUTE;
			}

			while(user != NULL)
			{
				Chars = user->GetCharacter();
				if (Chars->MapID == m_Character->MapID && user->Initial == 1) 
				{
					WaitForSingleObject(mutexHandle, INFINITE);
						SetPacketWalk(pk,2,1,m_Character->ID,(char)((int)m_Character->XPos/20),\
								(char)((int)m_Character->ZPos/20),(char)((int)m_Character->XDestPos/20),(char)((int)m_Character->ZDestPos/20),m_Character->Direction);
						send(user->ClientSocket, (char*)&pk, sizeof(pk),0);
					ReleaseMutex(mutexHandle);
					
				}
				user = user->Next;
			}

			break;
		}
	break;
	case 3 :
		switch(packet->action)
		{
		case 1 :
			memcpy(&pkchat,buf,sizeof(sPacketChat));
			pkchat.ID = m_Character->ID;
			sprintf(str,"User :%s SendMessage \"%s\"to user :[%s]",\
				GetCharacter(pkchat.ID)->Name, pkchat.msg,pkchat.name);
			SetListAction(str);

			int sock = -1;
			while(user != NULL)
			{
				Chars = user->GetCharacter();
				if (user->Initial == 1)
					if (!strcmp(pkchat.name,"") && Chars->MapID == m_Character->MapID)
					{
						sock = 0;
					}
					else if (!strcmp(pkchat.name,Chars->Name))
					{
						sock = user->ClientSocket;
					}
				user = user->Next;
			}
			
			user = m_UserParent;
			if (sock == 0)
			{
				while(user != NULL)
				{
					if (user->GetCharacter()->MapID == m_Character->MapID)
					{
						WaitForSingleObject(mutexHandle, INFINITE);
							send(user->ClientSocket, (char*)&pkchat, sizeof(sPacketChat),0);
						ReleaseMutex(mutexHandle);					
					}
					user = user->Next;
				}
			}else if (sock > 0)
			{
				WaitForSingleObject(mutexHandle, INFINITE);
					send(sock, (char*)&pkchat, sizeof(sPacketChat),0);
				ReleaseMutex(mutexHandle);
				
				if (sock != ClientSocket)
				{
					WaitForSingleObject(mutexHandle, INFINITE);
						send(ClientSocket, (char*)&pkchat, sizeof(sPacketChat),0);
					ReleaseMutex(mutexHandle);
				}
			}
			break;
		}
		break;
	case 4 : 
		switch(packet->action)
		{
		case 1 :
			SetPacketPlayer(pkply,4,1,m_Character->Name,m_Character->HealthPoints,\
				m_Character->Def.HealthPoints,m_Character->ManaPoints,m_Character->Def.ManaPoints,\
				m_Character->Def.Experience,m_Character->Def.Level,m_Character->Def.Attack,\
				m_Character->Def.Defense,m_Character->Def.Resistance,m_Character->Points);
			send(ClientSocket,(char*)&pkply,sizeof(sPacketPlayer),0);

			break;

		}break;
	}
	return TRUE;
}

void CUser::Update()
{
	sCharacter *CharPtr;
	float XMove, YMove, ZMove;
	long Elapsed = 33;
	static long EffectCounter = 0;
	BOOL ToProcess, DeadChar;
	sPacketGetCharacter pkget;
	char usr[100];
	//sPacketWalk pk;
	char buf[255];
	FD_SET readfd;
    FD_SET writefd;
    FD_SET exceptfd;
	timeval waittime;
	
	sprintf(usr,"Add Character Name : %s [%d] Connect Suceed",m_Character->Name,m_Character->ID);
	SetListAction(usr);
	SetListConnection(m_Character->Name);
	Sleep(200);
	
	// Return success if no characters to update
	if((CharPtr = m_Character) == NULL)
		return;

	SendPacketCharacter();

	Initial = 1;
	 
	while(!SERVER_QUIT)
	{
		Sleep(30);
		writefd.fd_count = 0;
		exceptfd.fd_count = 0;
		waittime.tv_sec = 0;
		waittime.tv_usec = 0;

		readfd.fd_count = 1;
		readfd.fd_array[0] = ClientSocket;
		if(select(0, &readfd, &writefd, &exceptfd, &waittime))
		{
			ZeroMemory(buf,sizeof(buf));
			ZeroMemory(usr,sizeof(usr));
			int err = recv(ClientSocket,buf,255,0);
			if (err <= 0)
			{
				Initial = 2;
				break;
			}
			CheckPacket(buf);
			sprintf(usr,"[%d]U receive message from socket (%d)",err,ClientSocket);
			//SetListAction(usr);
		}
	
		
		if(CharPtr->Enabled == TRUE) 
		{
		  // Update action timer if in use
		  if(CharPtr->ActionTimer != 0) {
			CharPtr->ActionTimer -= Elapsed;
			if(CharPtr->ActionTimer < 0)
			  CharPtr->ActionTimer = 0;
		  }

		  // Update text message timer
		  if(CharPtr->MessageTimer > 0)
			CharPtr->MessageTimer -= Elapsed;

		  // Reset charge counter if attacking, spell, or item
		  if(CharPtr->Action == CHAR_ATTACK ||                    \
			 CharPtr->Action == CHAR_SPELL  ||                    \
			 CharPtr->Action == CHAR_ITEM)
		  {
			CharPtr->Charge = 0.0f;
		  }

		  // Kill character if no health left
		  if(CharPtr->HealthPoints <= 0 &&                        \
			 CharPtr->Action != CHAR_DIE) {
			
			CharPtr->Attacker->AI = CHAR_WANDER;
			CharPtr->Attacker->Action = CHAR_IDLE;
			CharPtr->Attacker->Victim = NULL;
			CharPtr->Attacker->Attacker = NULL;
			CharPtr->Victim = NULL;
			
			if(m_UserParent != NULL)
				while(m_UserParent->Prev != NULL) m_UserParent = m_UserParent->Prev;
			
			CUser* user = m_UserParent;
			sPacketUpdateSpawnPlayer pkupply;
			while(user != NULL)
			{
				if (user->Initial == 1)
					if (CharPtr->MapID == user->GetCharacter()->MapID)
					{
						WaitForSingleObject(mutexHandle, INFINITE);
							SetPacketUpdateSpawnPlayer(pkupply,2,6,CharPtr->ID,(char)((int)CharPtr->XPos/20),\
								(char)((int)CharPtr->ZPos/20),CharPtr->Direction,CHAR_DIE,CHAR_STAND,2000);
						
							send(user->ClientSocket,(char*)&pkupply,sizeof(sPacketUpdateSpawnPlayer),0);
						ReleaseMutex(mutexHandle);
						
						do
						{
							ZeroMemory(&pkget,sizeof(pkget));
							recv(user->ClientSocket,(char*)&pkget,sizeof(pkget),0);
						}while(pkget.type != 1 || pkget.action != 4);
						//Sleep(100);
					}
				user = user->Next;
			}
			SetAction(CharPtr, CHAR_DIE, 2000);

		  }

		  // Mark that processing can continue later on
		  ToProcess = TRUE;

		  // Mark character as still alive
		  DeadChar = FALSE;

		  // Process non-idle, non-walk actions
		  if(CharPtr->Action != CHAR_IDLE &&                      \
			 CharPtr->Action != CHAR_MOVE &&                      \
			 !CharPtr->ActionTimer) {
 
			switch(CharPtr->Action) {
			  case CHAR_ATTACK:
				// Process attack
				if(ToProcess == TRUE)
				  Attack(CharPtr, CharPtr->Victim);
				break;
			
			  case CHAR_SPELL:
				// Manually cast a spell
		/*				if(m_SpellController != NULL && m_MSL != NULL &&  \
				   ToProcess == TRUE) {
					m_SpellController->Add(CharPtr->SpellNum,       \
							   CharPtr, CharPtr->SpellTarget,     \
							   CharPtr->XPos,                     \
							   CharPtr->YPos+30,                     \
							   CharPtr->ZPos,                     \
							   CharPtr->TargetX,                  \
							   CharPtr->TargetY,                  \
							   CharPtr->TargetZ);
				}
				CharPtr->Action = CHAR_IDLE;
		*/				break;

			  case CHAR_DIE:
				Death(CharPtr->Attacker, CharPtr);
				CharPtr->Attacker = NULL;
				CharPtr->Enabled = FALSE;
				CharPtr->ActionTimer = 90000;
				/*CharPtr->Next = NULL;
				CharPtr->Prev = NULL;*/
				DeadChar = TRUE;   // Mark character as dead
				ToProcess = FALSE; // Don't allow updates
				break;
			}

		  }
		  // Clear movement
		  XMove = ZMove = 0.0f;

		  if(ToProcess == TRUE) {
			  // Only allow updates if lock/timer not in use 
			  if(CharPtr->Enabled == TRUE && CharPtr->Locked == FALSE) {

				  if (!CharPtr->ActionTimer) {
					// Reset action
					CharPtr->Action = CHAR_IDLE;
					CharUpdate(Elapsed, &XMove,&YMove,&ZMove);
					// Check for validity of movement (clear if invalid)
					if(CheckMove(&XMove,&YMove,&ZMove)==FALSE) {
						XMove = ZMove = 0.0f;
						CharPtr->Action = CHAR_IDLE;
					}
				  }
			  }

				// Process movement of character
			  ProcessUpdate(XMove, YMove, ZMove);

			  // Increase action charge of character
			  CharPtr->Charge += ((float)Elapsed / 1000.0f *        \
							   GetCharge(CharPtr));
			  if(CharPtr->Charge > 100.0f)
				  CharPtr->Charge = 100.0f;
		  }
		}else
		{
			if(CharPtr->ActionTimer != 0) {
				CharPtr->ActionTimer -= Elapsed;
				if(CharPtr->ActionTimer < 0)
				  CharPtr->ActionTimer = 0;
			}

			if (CharPtr->ActionTimer ==0){
				CharPtr->FreePath();
				CharPtr->Enabled = TRUE;
				CharPtr->Action = CHAR_IDLE;
				CharPtr->Attacker = NULL;
				CharPtr->Victim = NULL;
				CharPtr->AI = CHAR_WANDER;
				CharPtr->Distance = 0;
				CharPtr->TargetChar = NULL;
				CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
				CharPtr->ManaPoints = CharPtr->Def.ManaPoints;
			}
		}
	}
	// Send Die packet
		CUser* user = m_UserParent;
		sPacketRemoveSpawnPlayer pkrmply;
		pkrmply.type = 2;
		pkrmply.action = 8;
		pkrmply.ID = m_Character->ID;
		//SetPacketRemoveSpawnPlayer(pkrm,2,8,m_Character->ID);
		
		while(user != NULL)
		{
			if (user->GetCharacter() != m_Character)
			{
				WaitForSingleObject(mutexHandle, INFINITE);
					send(user->ClientSocket,(char*)&pkrmply,sizeof(pkrmply),0);
				ReleaseMutex(mutexHandle);
				
			}
			user = user->Next;
		}
	Initial = 2;
}

BOOL CUser::SendPacketCharacter()
{
	CUser* CharPtr;
	sCharacter* Char;
	int show;
	char aa[255];
	sPacketGetCharacter pkget;
	sPacketReady pkready;
	
// Create User
	sPacketCreateSpawnPlayer pkCreatePly;
	SetPacketCreateSpawnPlayer(pkCreatePly,1,1,m_Character->ID,m_Character->Name, \
		(char)((int)m_Character->XPos/20),(char)((int)m_Character->ZPos/20), m_Character->Direction);

	if (m_UserParent != NULL)
		while(m_UserParent->Prev != NULL)	m_UserParent = m_UserParent->Prev;
	
	if ((CharPtr = m_UserParent) == NULL)
		return FALSE;
	// send pc to other char
	while(CharPtr != NULL)
	{
		Char = CharPtr->GetCharacter();
		if (Char->MapID == m_Character->MapID)
		{
			if (m_Character->ID == Char->ID)
				pkCreatePly.action = 1;
			else 
				pkCreatePly.action = 2;
			WaitForSingleObject(mutexHandle, INFINITE);
				show = send(CharPtr->ClientSocket,(char*)&pkCreatePly,sizeof(pkCreatePly),0);
					
				sprintf(aa,"Send Me[%d] To UserID [%d] Amount [%d] bytes",\
					m_Character->ID,Char->ID,show);
				//SetListAction(aa);
				do
				{
					ZeroMemory(&pkget,sizeof(pkget));
					recv(CharPtr->ClientSocket,(char*)&pkget,sizeof(pkget),0);
				}while(pkget.type != 1 || pkget.action != 4);
			ReleaseMutex(mutexHandle);
		}
		CharPtr = CharPtr->Next;
	}

	if ((CharPtr = m_UserParent) == NULL)
		return FALSE;
	// send user to pc
	while(CharPtr != NULL)
	{
		Char = CharPtr->GetCharacter();
		if ((Char->MapID == m_Character->MapID) && (m_Character->ID != Char->ID))
		{
			
			SetPacketCreateSpawnPlayer(pkCreatePly,1,2,Char->ID,Char->Name,\
				(char)((int)Char->XPos/20),(char)((int)Char->ZPos/20),Char->Direction);
			
			WaitForSingleObject(mutexHandle, INFINITE);
				show = send(ClientSocket, (char*)&pkCreatePly, sizeof(pkCreatePly),0);

				sprintf(aa,"Send UserID [%d] To Me[%d] Amount [%d] bytes",\
					Char->ID,m_Character->ID,show);
				//SetListAction(aa);

				do
				{
					ZeroMemory(&pkget,sizeof(pkget));
					recv(ClientSocket,(char*)&pkget,sizeof(pkget),0);
				}while(pkget.type != 1 || pkget.action != 4);
			ReleaseMutex(mutexHandle);
		}
		CharPtr = CharPtr->Next;
	}
// Create Monster
	sPacketCreateMonster pkCreateMon;
	if ((Char = m_CharacterParent)==NULL)
		return FALSE;
	
	while(Char!=NULL)
	{
		if (m_Character->ID != Char->ID && Char->Type == CHAR_MONSTER && (Char->MapID == m_Character->MapID))
		{
			WaitForSingleObject(mutexHandle, INFINITE);
				SetPacketCreateMonster(pkCreateMon,1,3,Char->ID,(char)((int)Char->XPos/20),(char)((int)Char->ZPos/20),Char->Direction);
				send(ClientSocket,(char*)&pkCreateMon,sizeof(pkCreateMon),0);

				sprintf(aa,"Send Monster [%d] To Me[%d] Amount [%d] bytes",\
					Char->ID,m_Character->ID,show);
				//SetListAction(aa);

				do
				{
					ZeroMemory(&pkget,sizeof(pkget));
					recv(ClientSocket,(char*)&pkget,sizeof(pkget),0);
				}while(pkget.type != 1 || pkget.action != 4);
			ReleaseMutex(mutexHandle);
		}
		Char = Char->Next;
	}

// Tell Client To Ready Run Game
	do
	{
		Sleep(100);
		WaitForSingleObject(mutexHandle, INFINITE);
			pkready.type = 1;
			pkready.action = 9;
			send(ClientSocket,(char*)&pkready,sizeof(pkready),0);
			
			pkready.type = 0;
			pkready.action = 0;
			recv(ClientSocket,(char*)&pkready,sizeof(pkready),0);
		ReleaseMutex(mutexHandle);
	}while(pkready.type != 1 || pkready.action != 9);
	
	return TRUE;
}

BOOL CUser::CharUpdate(long Elapsed,float *XMove, float *YMove, float *ZMove)
{
	sCharacter *CharPtr;
	float XDiff, ZDiff;

	if ((CharPtr = m_Character) == NULL)
		return FALSE;

	float	angle = 0;
	D3DXVECTOR2 CharMapPos;
	float Speed;

	Speed = 2;

// Move Character
	switch(CharPtr->AI)
	{
		case CHAR_STAND:
		case CHAR_WANDER:
			break;

		case CHAR_ROUTE:
			if (CharPtr->NumPoints > 0)
			{
				XDiff = CharPtr->Route[CharPtr->CurrentPoint].XPos - CharPtr->XPos;
				ZDiff = CharPtr->Route[CharPtr->CurrentPoint].ZPos - CharPtr->ZPos ;

				if (fabs(CharPtr->Direction - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f || 
					fabs(CharPtr->Direction - (CharPtr->Route[CharPtr->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((CharPtr->Direction+(2*D3DX_PI)) - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f)
				{
					CharPtr->Direction = CharPtr->Route[CharPtr->CurrentPoint].Direction;
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);

					float dir = CharPtr->Route[CharPtr->CurrentPoint].Direction - CharPtr->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						CharPtr->Direction += D3DX_PI/12;
					else CharPtr->Direction -= D3DX_PI/12;

					if (CharPtr->Direction < 0) 
						CharPtr->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					CharPtr->Route[CharPtr->CurrentPoint].XPos = -1;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos = -1;
					CharPtr->CurrentPoint++;
					CharPtr->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				}
				CharPtr->Action = CHAR_MOVE;
			}else {
				CharPtr->AI = CHAR_STAND;
				CharPtr->NumPoints = 0;
				
				WaitForSingleObject(mutexHandle, INFINITE);
					sPacketUpdateSpawnPlayer pkupdate;
					SetPacketUpdateSpawnPlayer(pkupdate,2,6,CharPtr->ID,(char)((int)CharPtr->XPos/20),\
						(char)((int)CharPtr->ZPos/20),CharPtr->Direction,(char)CharPtr->Action,(char)CharPtr->AI,-1);
					send(ClientSocket,(char*)&pkupdate,sizeof(pkupdate),0);
				ReleaseMutex(mutexHandle);
			}
			break;
	}

	sPacketUpdateSpawnPlayer pkact;
	sPacketToChar pkchar;
					
	// Check Victim is in range?
	if (CharPtr->Victim != NULL && !CharPtr->ActionTimer)
	{
		if (fabs(CharPtr->XPos-CharPtr->Victim->XPos) <= 30 && fabs(CharPtr->ZPos-CharPtr->Victim->ZPos) <= 30)
		{
			if(CharPtr->Action == CHAR_ATTACK)
				CharPtr->Action = CHAR_IDLE;
		
			if(m_UserParent != NULL)
				while(m_UserParent->Prev != NULL) m_UserParent = m_UserParent->Prev;
			
			if (CharPtr->TargetChar != NULL)
			{
				CUser* user = m_UserParent;
				while(user != NULL && user->Initial == 1)
				{
					if (CharPtr->Victim != NULL)
					if (CharPtr->MapID == CharPtr->Victim->MapID)
					{	
						Sleep(200);
						WaitForSingleObject(mutexHandle, INFINITE);
							SetPacketToChar(pkchar,2,2,CharPtr->ID,CharPtr->Victim->ID);
							send(user->ClientSocket,(char*)&pkchar,sizeof(sPacketToChar),0);
						ReleaseMutex(mutexHandle);
					}
					user = user->Next;
				}
			}
			CharPtr->FreePath();
			CharPtr->AI = CHAR_STAND;
			CharPtr->TargetChar = NULL;
			D3DXVECTOR2 PCPos = GetStageGame()->GetTerrain(CharPtr->MapID)->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);
			D3DXVECTOR2 CharPos = GetStageGame()->GetTerrain(CharPtr->MapID)->GetMapPosition(CharPtr->Victim->XPos,CharPtr->Victim->ZPos);

			int x = int(PCPos.x-CharPos.x);
			int z = int(PCPos.y-CharPos.y);

			x = x/abs((x==0?1:x));	
			z = z/abs((z==0?1:z));
  
			if (x==0 && z==-1) CharPtr->Direction = 0;
			else if (x==0 && z==1) CharPtr->Direction = D3DX_PI;
			else if (x==-1 && z==0) CharPtr->Direction = D3DX_PI/2;
			else if (x==1 && z==0) CharPtr->Direction = 3*D3DX_PI/2;
			else if (x==1 && z==1) CharPtr->Direction = 5*D3DX_PI/4;
			else if (x==1 && z==-1) CharPtr->Direction = 7*D3DX_PI/4;
			else if (x==-1 && z==-1) CharPtr->Direction = D3DX_PI/4;
			else if (x==-1 && z==1) CharPtr->Direction = 3*D3DX_PI/4;

			  // Perform attack action
			if (CharPtr->Action != CHAR_ATTACK)
			{
				SetAction(CharPtr, CHAR_ATTACK);
			}
		}else{
			if (CharPtr->TargetChar == NULL)
			{
				if(m_UserParent != NULL)
					while(m_UserParent->Prev != NULL) m_UserParent = m_UserParent->Prev;
				
				CUser* user = m_UserParent;
				while(user != NULL && user->Initial == 1)
				{
					if (m_Character->MapID == m_Character->Victim->MapID )
					{
						WaitForSingleObject(mutexHandle, INFINITE);
							SetPacketUpdateSpawnPlayer(pkact,2,6,CharPtr->ID,(char)((int)CharPtr->XPos/20),\
								(char)((int)CharPtr->ZPos/20),CharPtr->Direction,CHAR_IDLE,CHAR_STAND,-1);
							send(user->ClientSocket,(char*)&pkact,sizeof(sPacketUpdateSpawnPlayer),0);
						ReleaseMutex(mutexHandle);
					}
					user = user->Next;
				}
				CharPtr->Action = CHAR_IDLE;
				CharPtr->Victim->Attacker = NULL;
				CharPtr->Victim = NULL;
			}
		}
	}

// Check LV
	if (CharPtr->MessageTimer <= 0)
	{
		long lvup = 0;
		if(lvup = CalculateHeroLV(CharPtr->Def.Level,CharPtr->Def.Experience))
		{
			CharPtr->Def.Level+=lvup;
			CharPtr->Points += (10*lvup);
			CharPtr->Def.Attack+=(lvup*CharPtr->Def.Level);
			CharPtr->Def.Defense+=(lvup*CharPtr->Def.Level);
			CharPtr->Def.Resistance+=(lvup*CharPtr->Def.Level);
			SetMessage(CharPtr,"LvUP !!",1000,0xfff0e119);
		}
	}

	return TRUE;
}

long CUser::CalculateHeroLV(long LV, long EXP)
{
	long LVNum = 0;
		
	long EXPNextLV = CalculateNextLV(LV);	//Calculate Relationship between Exp. & LV
	
	while (EXP >= EXPNextLV){
		LVNum++;
		LV++;
		EXPNextLV = CalculateNextLV(LV);
	}

	return LVNum;
}

long CUser::CalculateNextLV(long LV)
{
	long nextlv;

	nextlv = (long)((pow(2,LV)*1000) - (pow(2,LV)*100));

	return nextlv;
}

BOOL CUser::RoutePath(D3DXVECTOR2 CharPos,D3DXVECTOR2 DestPos)
{

	sCharacter *Char;
	bool Onchar = false;

	if (m_Character == NULL)
		return FALSE;

	if ((Char = m_CharacterParent)!=NULL)
		while(Char != NULL)
		{
			if (Char->Type != CHAR_PC && Char->Enabled)
				if ((int)(Char->XPos/20) == DestPos.x && (int)(Char->ZPos/20) == DestPos.y)
				{
					Onchar = true;
					break;
				}
			Char = Char->Next;
		}
		//clear Path
	m_Character->FreePath();

	while (CharPos != DestPos)
	{
		int DX = (int)(DestPos.x - CharPos.x);
		int DY = (int)(DestPos.y - CharPos.y);

		if (DX == 0)
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= CharPos.x * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= (CharPos.y +(float)(DY/(fabs(DY)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].Direction
				= ((DY/fabs(DY) > 0)?0:D3DX_PI);

		}else if (DY ==0)
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= CharPos.y * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].Direction
				= ((DX/fabs(DX) > 0)?D3DX_PI/2:(3*D3DX_PI/2)); 
		}
		else //if (fabs(DX) <> fabs(DY))
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= (CharPos.y	+(float)(DY/(fabs(DY)))) * 20 + 10;
			if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) > 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = D3DX_PI/4; 
			else if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) < 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = 3*D3DX_PI/4; 
			else if (DX/(fabs(DX)) < 0 && DY/(fabs(DY)) < 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = 5*D3DX_PI/4; 
			else 
				m_Character->Route[m_Character->CurrentPoint].Direction = 7*D3DX_PI/4; 

		}
		CharPos.x = (m_Character->Route[m_Character->CurrentPoint].XPos -10) / 20;
		CharPos.y = (m_Character->Route[m_Character->CurrentPoint].ZPos -10) / 20;
		m_Character->CurrentPoint++;
	}
	if (Onchar  && m_Character->CurrentPoint > 0) 
	{
		m_Character->CurrentPoint--;
		m_Character->Route[m_Character->CurrentPoint].XPos=-1;
		m_Character->Route[m_Character->CurrentPoint].ZPos=-1;
		m_Character->Route[m_Character->CurrentPoint].Direction = 0;
	}
	m_Character->NumPoints = m_Character->CurrentPoint;
	m_Character->CurrentPoint = 0;

	return TRUE;
}

BOOL CUser::CheckMove(float *XMove, float *YMove, float *ZMove)
{
  sCharacter *Character;

  BYTE** MapArray = GetMapArr(m_Character->MapID);

  // Error checking
  if(m_Character == NULL)
    return FALSE;  // Don't allow movement

   // Check movement against other characters
  if((Character = m_CharacterParent) != NULL) {
    while(Character != NULL) {
		if ((m_Character->ID != Character->ID))
		{
			if (m_Character->AI != CHAR_STAND)
			{
				float x = m_Character->Route[m_Character->CurrentPoint].XPos;
				float z = m_Character->Route[m_Character->CurrentPoint].ZPos;
				int xDest = int(Character->XPos)/20;
				int zDest = int(Character->ZPos)/20;
				if (x > 0)
					if (!m_StageGame->GetTerrain(m_Character->MapID)->CanMove(x,z) || ((x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled))
					{
						*XMove = 0;
						*ZMove = 0;
						if (m_Character->NumPoints == 1 && (x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled)
						{
							m_Character->FreePath();
							break;
						}
						else
						{
							m_Character->FreePath();
							if (m_Character->Type == CHAR_PC)
								ValidateMove(XMove, YMove, ZMove);
						}
					}
			}
		}
		Character = Character->Next;
    }

  }

  return TRUE;
}

BOOL CUser::ValidateMove(float *XMove, float *YMove, float *ZMove)
{
	sCharacter *Char;
	D3DXVECTOR2 CharMapPos;
	BYTE** MapArray = GetMapArr(m_Character->MapID);

	if (m_Character == NULL)
		return FALSE;
	
	CharMapPos	= m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);

	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != m_Character->ID && Char->Enabled)
				m_StageGame->GetTerrain(m_Character->MapID)->SetCanMove(Char->XPos,Char->ZPos,false);
			Char = Char->Next;
		}
	}
	
		// Check Out of array 
	if (fabs(CharMapPos.x - (int)(m_Character->XDestPos)/20) >= MAX_SHORTCAL/2-1 ||	\
		fabs(CharMapPos.y - (int)(m_Character->ZDestPos)/20) >= MAX_SHORTCAL/2-1)
		return FALSE;

	int x = (int)(m_Character->XDestPos)/20;
	int y = (int)(m_Character->ZDestPos)/20;

	MakePath((int)CharMapPos.x,(int)CharMapPos.y);
			
	m_Character->Route[0].XPos = (float)x*20+10;
	m_Character->Route[0].ZPos = (float)y*20+10;
	m_Character->CurrentPoint = 1;

	while (CharMapPos.x != x || CharMapPos.y != y)
	{
		if (x <=0 && y <= 0) 
		{		
			m_Character->FreePath();
			break;
		}
		int DX = (int)(CharMapPos.x - x);
		int DY = (int)(CharMapPos.y - y);
		if (DX == 0 && DY == 0) break;
		int dx = (DX == 0?0:DX/abs(DX));
		int dy = (DY == 0?0:DY/abs(DY));
		
		if (abs(DX) > abs(DY))
		{
			if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y] )
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (float)y * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint-1].Direction
					= ((dx < 0)?D3DX_PI/2:(3*D3DX_PI/2));
			}else 
			{
				if (y == m_StageGame->GetTerrain(m_Character->MapID)->GetNumMap()-1)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						if (dx > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
						else 
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}
				}
				else if (y == 0)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						if (dx > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}else 
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}
			}

		}else if (abs(DX) < abs(DY))
		{
			if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+dy] )
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (float)x * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (y+(float)dy) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint-1].Direction
					= (dy < 0)?0:D3DX_PI;
			}else 
			{
				if (x == m_StageGame->GetTerrain(m_Character->MapID)->GetNumMap()-1)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+dy])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
						else
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= D3DX_PI/4;							
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}
				}
				else if (x == 0)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+dy])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else 
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;							
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}else 
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 7*D3DX_PI/4;
					}else if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1] )
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}else if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1] )
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}
			}
		}else if (abs(DX) == abs(DY))
		{
			
			if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y+dy])
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (y +(float)dy) * 20 + 10;
				
				if (dx > 0 && dy > 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
				if (dx > 0 && dy < 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
				if (dx < 0 && dy > 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
				if (dx < 0 && dy < 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4;
			}
			else 
			{
				if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
				{
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)(x+1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)y * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= 3*D3DX_PI/2;
				
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y+1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= D3DX_PI;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)(x-1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= D3DX_PI/2;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y-1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= 0;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y-dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x +(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-dx][y+dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y +(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-dx][y-dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4;
				}
			}
		}
		x = (int)(m_Character->Route[m_Character->CurrentPoint].XPos -10) / 20;
		y = (int)(m_Character->Route[m_Character->CurrentPoint].ZPos -10) / 20;
		m_Character->CurrentPoint++;
	}
	SortArr();
	m_Character->NumPoints = m_Character->CurrentPoint-1;
	m_Character->CurrentPoint = 0;
	////////////////
	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != m_Character->ID && m_Character->Enabled)
				m_StageGame->GetTerrain(m_Character->MapID)->SetCanMove(Char->XPos,Char->ZPos,true);
			Char = Char->Next;
		}
	}
	return TRUE;
}

BOOL CUser::SortArr()
{
	sRoutePoint* arr = m_Character->Route;
	sRoutePoint* tmp = new sRoutePoint[MAX_SHORTPATH];
	int i,j,k;

	for (j=0,i = MAX_SHORTPATH-1;i>=0;i--,j++)
	{
		tmp[j] = arr[i];
		arr[i].Direction = 0;
		arr[i].XPos	= -1;
		arr[i].YPos = -1;
		arr[i].ZPos = -1;
	}

	
	i=0;
	while (tmp[i].XPos == -1) 
		i++;
	i++;
	for (j=i,k=0;j<MAX_SHORTPATH;j++,k++)
	{
		arr[k] = tmp[j];
	}
	
	for (j = k;j<MAX_SHORTPATH;j++)
	{
		arr[j].Direction = 0;
		arr[j].XPos = -1;
		arr[j].YPos = -1;
		arr[j].ZPos = -1;
	}

	delete[] tmp;

	return TRUE;
}

void CUser::ShortestPath(int stx,int sty,int tx, int ty, int step)
{
	if (stx == int(m_Character->XDestPos/20) && sty == (int)(m_Character->ZDestPos/20))
		return;

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0') 
	{
		if (m_Character->AllPath[stx+1+tx][sty+ty]==0 || m_Character->AllPath[stx+1+tx][sty+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty+ty] = step;
			ShortestPath(stx,sty,tx+1,ty,step+1);
		}
	}
	
	if (ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+tx][sty+1+ty]==0 || m_Character->AllPath[stx+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty+ty]==0 || m_Character->AllPath[stx-1+tx][sty+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty+ty] = step;
			ShortestPath(stx,sty,tx-1,ty,step+1);
		}

	}

	if (ty-1+(MAX_SHORTCAL/2) >=0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+tx][sty-1+ty]==0 || m_Character->AllPath[stx+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx,ty-1,step+1);
		}
	}
	
	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+1+tx][sty+1+ty]==0 || m_Character->AllPath[stx+1+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx+1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty+1+ty]==0 || m_Character->AllPath[stx-1+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx-1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty-1+ty]==0 || m_Character->AllPath[stx-1+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx-1,ty-1,step+1);
		}
	}

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+1+tx][sty-1+ty]==0 || m_Character->AllPath[stx+1+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx+1,ty-1,step+1);
		}
	}
}

BOOL CUser::MakePath(int Stx,int Sty)
{
	int x,y;

	//FILE* fid = fopen("out.txt","w");
	//FILE* fid2= fopen("out2.txt","w");

	for (int i=0;i<MAX_SHORTCAL;i++)
		for (int j=0;j<MAX_SHORTCAL;j++)	
		{
			if ((Stx-(MAX_SHORTCAL/2)+i)<0 || (Sty-(MAX_SHORTCAL/2)+j)<0)
			{
				m_Character->TempArr[i][j] = '1';
			}
			else 
			{	
				x = (int)Stx-(MAX_SHORTCAL/2)+i;
				y = (int)Sty-(MAX_SHORTCAL/2)+j;
				m_Character->TempArr[i][j] = (m_StageGame->GetTerrain(m_Character->MapID)->CanMove((float)x*20, (float)y*20)?'0':'1');
			}
		}

	/*for (i=MAX_SHORTCAL-1;i>=0;i--)
	{
		for(int j=0;j<MAX_SHORTCAL;j++)
		{
			fprintf(fid,"%c",CharPtr->TempArr[j][i]);
		}
		fprintf(fid,"\n\r");
	}
	fclose(fid);
*/
	ShortestPath(Stx,Sty,0,0,1);
	m_Character->AllPath[Stx][Sty] = 0;

	/*int POS = CharPtr->MapSize;
	for(i=POS-1;i>=0;i--)
	{
		for(int j=0;j<POS;j++)
		{
			if (CharPtr->AllPath[j][i] >= 10)
				fprintf(fid2,"%i",CharPtr->AllPath[j][i]);
			else 
				fprintf(fid2,"%i ",CharPtr->AllPath[j][i]);
		}	
		fprintf(fid2,"\n\r");
	}
	fclose(fid2);
	*/return TRUE;
}

BOOL CUser::ProcessUpdate(float XMove, float YMove, float ZMove)
{
	// Move character
	m_Character->XPos += XMove;
	m_Character->YPos = YMove;
	m_Character->ZPos += ZMove;

	return TRUE;
}

BOOL CUser::Attack(sCharacter *Attacker,       \
                                  sCharacter *Victim)
{
	// Error checking
	if(Attacker == NULL || Victim == NULL)
	return FALSE;

	// Don't attack dead or hurt people
	if(Victim->Action == CHAR_DIE)
		return FALSE;

	// Set attacker and victim
	Victim->Attacker = Attacker;
	Attacker->Victim = Victim;

	// Return if hit missed
	if((rand() % 1000) > GetToHit(Attacker)) {
		SetMessage(Victim, "Missed!", 500);
		char aa[100];
		sprintf(aa,"[%i] Attack Missed !",Attacker->ID);
		SetListAction(aa);
		return FALSE;
	}

	// Return if hit dodged
	if((rand() % 1000) <= GetAgility(Victim)) {
		SetMessage(Victim, "Dodged!", 500);
		char aa[100];
		sprintf(aa,"[%i] Attack Missed !",Attacker->ID);
		SetListAction(aa);
		return FALSE;
	}

	// Attack landed, apply damage
	Damage(Victim, TRUE, GetAttack(Attacker), -1, -1);

	return TRUE;
}

BOOL CUser::Damage(sCharacter *Victim,         \
                                  BOOL PhysicalAttack,        \
                                  long Amount,                \
                                  long DmgClass,              \
                                  long CureClass)
{
	char Text[128];
	float Resist;
	float Range;
	long  DmgAmount;

	// Error checking
	if(Victim == NULL)
		return FALSE;

	// Can't attack if already dead or being hurt (or not enabled)
	if(Victim->Enabled == FALSE ||                              \
	 Victim->Action==CHAR_DIE)
		return FALSE;

	// Adjust for defense if physical attack
	if(PhysicalAttack == TRUE) {

		// Random value for less/more damage (-+20%)
		Range     = (float)((rand() % 20) + 90) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);

		// Subtract for defense of victim (allow -20% difference)
		Range     = (float)((rand() % 20) + 80) / 100.0f;
		DmgAmount -= (long)((float)GetDefense(Victim) * Range);
	} else {
		// Adjust for magical attack
		Resist = 1.0f - ((float)GetResistance(Victim) / 100.0f);
		DmgAmount = (long)((float)Amount * Resist);
	}

	// Bounds check value
	if(DmgAmount < 0)
		DmgAmount = 1;

	// Check for double damage
	if(Victim->Def.Class == DmgClass)
		DmgAmount *= 2;

	// Check for cure damage
	if(Victim->Def.Class == CureClass)
		DmgAmount = -(labs(DmgAmount)/2);

	// If no physical damage is dealt then randomly deal 
	// 10-20% of damage from the original amount.
	if(!DmgAmount && PhysicalAttack == TRUE) {
		Range     = (float)((rand() % 10) + 10) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);
	}

	// Subtract damage amount
	Victim->HealthPoints -= DmgAmount;

	// Set hurt status and display message
	if(DmgAmount >= 0) {
		sprintf(Text, "-%lu HP", DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(255,64,0,255));
		sprintf(Text,"-%lu Damage to [%i] !",DmgAmount,Victim->ID);
		SetListAction(Text);

		// Only set hurt if any damage (and idle or moving)
		if(DmgAmount) {
		  if(Victim->Action==CHAR_MOVE || Victim->Action==CHAR_IDLE)
			SetAction(Victim, CHAR_HURT);
		}
	} 

	// Display cure amount
	if(DmgAmount < 0) {
		sprintf(Text, "+%lu HP", -DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(0,64,255,255));
		sprintf(Text,"%lu Damage to [%i] !",DmgAmount,Victim->ID);
		SetListAction(Text);
	}

	return TRUE;
}

BOOL CUser::Death(sCharacter *Attacker, sCharacter *Victim)
{
	char Text[128];

	ZeroMemory(Text, sizeof(char));

	// If a PC or NPC dies, then don't remove from list
	if(Victim->Type == CHAR_PC) {
	// Mark character as disabled so no updates
		Victim->Enabled = FALSE;

	} else {
		// Give attacker the victim's experience
		if(Attacker != NULL) {
		  if(Experience(Attacker, Victim->Def.Experience) == TRUE) {
			sprintf(Text, "+%lu exp.", Victim->Def.Experience);
			SetMessage(Attacker, Text, 500);
		  }
		}

		// Drop character's money
		if((m_StageGame->FindItemDef(0) != NULL) && ((rand() % 100) <= Victim->Def.DropChance))
		{
			char ItemName[30];
			strcpy(ItemName,"");
		}	

	}

	return TRUE;
}