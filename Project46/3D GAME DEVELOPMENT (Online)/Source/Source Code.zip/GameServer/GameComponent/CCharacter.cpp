#include "HGlobal.h"
#include "CCharacter.h"

sCharacter *CCharacter::GetParentCharacter()
{
  return m_CharacterParent;
}

sCharacter *CCharacter::GetCharacter()
{
  return m_Character;
}

sCharacter *CCharacter::GetCharacter(long IDNum)
{
  sCharacter *CharPtr;

  // Scan through all characters
  if((CharPtr = m_CharacterParent) != NULL) {
    while(CharPtr != NULL) {
    
      // Return character
      if(IDNum == CharPtr->ID)
        return CharPtr;
   
      // Go to next character
      CharPtr = CharPtr->Next;
    }
  }

  return NULL;
}

long CCharacter::CheckEvent()
{
	int XDiffMap,ZDiffMap;
	sCharacter* CharPtr;
	sCharacter* CharPC = GetCharacter();
	
	if ((CharPtr=m_CharacterParent)==NULL)
		return -1;

	while(CharPtr!=NULL)
	{		
		if (strcmp(CharPtr->ScriptFilename,"NONE"))
		{
			if (CharPC->ID != CharPtr->ID && CharPC->TargetChar != NULL && CharPC->NumPoints == 0 && CharPtr->Enabled)
			{
				XDiffMap = (int)fabs((CharPC->XPos/20)-(CharPtr->XPos/20));
				ZDiffMap = (int)fabs((CharPC->ZPos/20)-(CharPtr->ZPos/20));

				if (XDiffMap <= 1 && ZDiffMap <= 1)
					return CharPtr->ID;
			}
		}
		CharPtr = CharPtr->Next;
	}
	
	return -1;

}

float CCharacter::GetSpeed(sCharacter* Character)
{
  float Speed;
  
  // Error checking
  if(Character == NULL)
    return 0.0f;

  // Calculate adjusted speed
  Speed = Character->Def.Speed;

   // Bounds check value
  if(Speed < 1.0f)
    Speed = 1.0f;

  return Speed;
}

long CCharacter::GetAttack(sCharacter* Character)
{
  long Attack;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted attack
  Attack = Character->Def.Attack;

  // Adjust attack based on item value (in %(Value/100)+1)
  if(Character->Def.Weapon != -1 && m_StageGame->FindItemDef(0) != NULL) {
    Attack = (long)((float)Attack *                           \
             (((float)m_StageGame->FindItemDef(Character->Def.Weapon)->damageAttack /    \
             100.0f) + 1.0f));
  }

  return Attack;
}

long CCharacter::GetDefense(sCharacter* Character)
{
  long Defense;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted defense
  Defense = Character->Def.Defense;
  
  if(Character->Def.Armor != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Armor)->defense /     \
             100.0f) + 1.0f));

  if(Character->Def.Shield != -1 && m_StageGame->FindItemDef(0) != NULL)
    Defense = (long)((float)Defense *                         \
             (((float)m_StageGame->FindItemDef(Character->Def.Shield)->defense /    \
             100.0f) + 1.0f));


  // Bounds check value
  if(Defense < 0)
    Defense = 0;

  return Defense;
}

long CCharacter::GetAgility(sCharacter* Character)
{
  long Agility;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted agility
  Agility = Character->Def.Agility;
  
  return Agility;
}

long CCharacter::GetResistance(sCharacter* Character)
{
  long Resistance;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted resistance
  Resistance = Character->Def.Resistance;
  
  return Resistance;
}

long CCharacter::GetMental(sCharacter* Character)
{
  long Mental;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted mental
  Mental = Character->Def.Mental;
  
  return Mental;
}

long CCharacter::GetToHit(sCharacter* Character)
{
  long ToHit;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted to hit
  ToHit = Character->Def.ToHit;

  return ToHit;
}

float CCharacter::GetCharge(sCharacter* Character)
{
  float Charge;
  
  // Error checking
  if(Character == NULL)
    return 0;

  // Calculate adjusted charge
  Charge = Character->Def.ChargeRate;
  
  return Charge;
}

BOOL CCharacter::SetLock(BOOL State)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Locked = State;
  return TRUE;
}

BOOL CCharacter::SetActionTimer(long IDNum, long Timer)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new value
  CharPtr->ActionTimer = Timer;
  return TRUE;
}

BOOL CCharacter::SetAction(sCharacter* Character,long Action,             \
                                     long AddTime)
{

  // Error checking
  if(Character == NULL)
    return FALSE;

  // Set action
  Character->Action = Action;

  // Set action time (or set to 1 is addtime = -1)
  if(AddTime == -1)
    Character->ActionTimer = 1;
  else
  {
    Character->ActionTimer = (Character->Def.Agility*33) + AddTime;
  }
  return TRUE;
}

BOOL CCharacter::SetDistance(float Distance)
{

  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Distance = Distance;
  return TRUE;
}

float CCharacter::GetDistance()
{
 
  if(m_Character == NULL)
    return 0.0f;
  return m_Character->Distance;
}

BOOL CCharacter::SetRoute(long NumPoints, sRoutePoint *Route)
{
   // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Free old route
  delete [] m_Character->Route;
  m_Character->Route = NULL;

  // Set new route
  if((m_Character->NumPoints = NumPoints) != NULL) {
    m_Character->Route = new sRoutePoint[NumPoints];
    memcpy(m_Character->Route,Route,NumPoints*sizeof(sRoutePoint));
    m_Character->CurrentPoint = 0;
  }

  return TRUE;
}

BOOL CCharacter::SetScript(char *ScriptFilename)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new script
  strcpy(m_Character->ScriptFilename, ScriptFilename);
  return TRUE;
}

char *CCharacter::GetScript()
{

  if(m_Character == NULL)
    return NULL;
  return m_Character->ScriptFilename;
}

BOOL CCharacter::SetEnable(BOOL Enabled)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Enabled = Enabled;
  return TRUE;
}

BOOL CCharacter::GetEnable()
{
  if(m_Character == NULL)
    return FALSE;
  return m_Character->Enabled;
}

BOOL CCharacter::SetMessage(sCharacter *Character,char *Text, long Timer,    \
                                   D3DCOLOR Color)
{
  strcpy(Character->Message, Text);
  Character->MessageTimer = Timer;
  
  sPacketMessage pkmsg;
  SetPacketMessage(pkmsg,2,3,Character->ID,Color,Timer,Text);
  
  if(m_UserParent != NULL)
	while(m_UserParent->Prev != NULL) m_UserParent = m_UserParent->Prev;
		
  CUser* user = m_UserParent;
  while(user!=NULL)
  {
	if (m_Character->Victim != NULL)
	{
		if (user->Initial == 1)
			if (user->GetCharacter()->ID == m_Character->Victim->ID)
			{
				WaitForSingleObject(mutexHandle, INFINITE);
					send(user->ClientSocket,(char*)&pkmsg,sizeof(pkmsg),0);
				ReleaseMutex(mutexHandle);
			}
	}
	user = user->Next;
  }

  return TRUE;
}

BOOL CCharacter::GetPosition( float *XPos, float *YPos, float *ZPos)
{
  if(m_Character == NULL)
    return FALSE;

  if(XPos != NULL)
    *XPos = m_Character->XPos;
  if(YPos != NULL)
    *YPos = m_Character->YPos;
  if(ZPos != NULL)
    *ZPos = m_Character->ZPos;

  return TRUE;
}

BOOL CCharacter::SetType(long Type)
{
  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->Type = Type;
  return TRUE;
}

long CCharacter::GetType()
{
  
  if(m_Character == NULL)
    return 0;
  return m_Character->Type;
}

BOOL CCharacter::SetAI(long Type)
{
    // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Set new value
  m_Character->AI = Type;
  return TRUE;
}

long CCharacter::GetAI()
{
 
  if(m_Character == NULL)
    return 0;
  return m_Character->AI;
}

BOOL CCharacter::SetTargetCharacter(long TargetNum)
{
  sCharacter *CharTarget;

  // Get pointer to character
  if(m_Character == NULL)
    return FALSE;

  // Clear if TargetNum == -1
  if(TargetNum == -1)
    m_Character->TargetChar = NULL;
  else {
    // Scan through list and target 1st TargetNum found
    CharTarget = m_CharacterParent;
    while(CharTarget != NULL) {
      if(CharTarget->ID == TargetNum) {
        m_Character->TargetChar = CharTarget;
        break;
      }
      CharTarget = CharTarget->Next;
    }

    // Clear target if not found in list
    if(CharTarget == NULL)
      m_Character->TargetChar = NULL;
  }
  return TRUE;
}

UINT ProcThread(LPVOID pParam)
{
	CCharacter* Char = (CCharacter*)pParam;

	Char->Update();

	return 0;
}

BOOL CCharacter::CreateMonsterthread()
{
	m_Thread = AfxBeginThread(ProcThread,(LPVOID)this);

	return TRUE;
}

BOOL CCharacter::CloseThread()
{
	if(m_Thread)
	{
		HANDLE hThread = m_Thread->m_hThread;

		::WaitForSingleObject(hThread,INFINITE);
	}
	
	return TRUE;
}

void CCharacter::Update()
{
	sCharacter *CharPtr;
	float XMove, YMove, ZMove;
	long Elapsed = 33;
	BOOL ToProcess, DeadChar;
	sPacketGetCharacter pkget;

	FD_SET readfd;
    FD_SET writefd;
    FD_SET exceptfd;
	timeval waittime;

	writefd.fd_count = 0;
	exceptfd.fd_count = 0;
	waittime.tv_sec = 0;
	waittime.tv_usec = 100;
	readfd.fd_count = 1;
	
while(!SERVER_QUIT)
{
	static long EffectCounter = 0;
	Sleep(30);
	// Return success if no characters to update
	if((CharPtr = m_Character) == NULL)
		return ;

	if(CharPtr->Enabled == TRUE) 
	{
	  // Update action timer if in use
	  if(CharPtr->ActionTimer != 0) {
		CharPtr->ActionTimer -= Elapsed;
		if(CharPtr->ActionTimer < 0)
		  CharPtr->ActionTimer = 0;
	  }

	  // Update text message timer
	  if(CharPtr->MessageTimer > 0)
		CharPtr->MessageTimer -= Elapsed;

	  // Reset charge counter if attacking, spell, or item
	  if(CharPtr->Action == CHAR_ATTACK ||                    \
		 CharPtr->Action == CHAR_SPELL  ||                    \
		 CharPtr->Action == CHAR_ITEM)
	  {
		CharPtr->Charge = 0.0f;
		
	  }

	  // Kill character if no health left
	  if(CharPtr->HealthPoints <= 0 &&                        \
		 CharPtr->Action != CHAR_DIE) {

		//CharPtr->Attacker->AI = CHAR_WANDER;
		CharPtr->Attacker->Action = CHAR_IDLE;
		CharPtr->Attacker->Victim = NULL;
		CharPtr->Attacker->Attacker = NULL;
		CharPtr->Victim = NULL;
		
		sPacketUpdateMonster pkupmon;
		CUser* user = m_UserParent;
		while(user != NULL)
		{
			if (user->Initial == 1)
				if (CharPtr->MapID == user->GetCharacter()->MapID)
				{
					while(1)
					{
						WaitForSingleObject(mutexHandle, INFINITE);
							SetPacketUpdateMonster(pkupmon,2,7,CharPtr->ID,(char)((int)CharPtr->XPos/20),\
								(char)((int)CharPtr->ZPos/20),CharPtr->Direction,CHAR_DIE,CHAR_STAND,2000);
						
							send(user->ClientSocket,(char*)&pkupmon,sizeof(sPacketUpdateMonster),0);
						ReleaseMutex(mutexHandle);

						readfd.fd_array[0] = user->ClientSocket;
						if(select(0, &readfd, &writefd, &exceptfd, &waittime))
						{
							ZeroMemory(&pkget,sizeof(pkget));
							recv(user->ClientSocket,(char*)&pkget,sizeof(pkget),0);
							if(pkget.type == 1 && pkget.action == 4)
							{
								break;
							}
						}
						Sleep(100);
					}
					
				}
			user = user->Next;
		}
		SetAction(CharPtr, CHAR_DIE, 2000);
	  }

	  // Mark that processing can continue later on
	  ToProcess = TRUE;

	  // Mark character as still alive
	  DeadChar = FALSE;

	  // Process non-idle, non-walk actions
	  if(CharPtr->Action != CHAR_IDLE &&                      \
		 CharPtr->Action != CHAR_MOVE &&                      \
		 !CharPtr->ActionTimer) {
 
		switch(CharPtr->Action) {
		  case CHAR_ATTACK:
			// Process attack
			if(ToProcess == TRUE)
			  Attack(CharPtr, CharPtr->Victim);
			break;
		
		  case CHAR_DIE:
			Death(CharPtr->Attacker, CharPtr);
			CharPtr->Attacker = NULL;
			CharPtr->Enabled = FALSE;
			CharPtr->ActionTimer = 90000;
			/*CharPtr->Next = NULL;
			CharPtr->Prev = NULL;*/
			DeadChar = TRUE;   // Mark character as dead
			ToProcess = FALSE; // Don't allow updates
			break;
		}

	  }
	  // Clear movement
	  XMove = ZMove = 0.0f;

	  if(ToProcess == TRUE) {
		  // Only allow updates if lock/timer not in use 
		  if(CharPtr->Enabled == TRUE && CharPtr->Locked == FALSE) {

			  if (!CharPtr->ActionTimer) {
				// Reset action
				CharPtr->Action = CHAR_IDLE;
				CharUpdate(Elapsed, &XMove,&YMove,&ZMove);
				// Check for validity of movement (clear if invalid)
				if(CheckMove(&XMove,&YMove,&ZMove)==FALSE) {
					XMove = ZMove = 0.0f;
					CharPtr->Action = CHAR_IDLE;
				}
			  }
		  }

			// Process movement of character
		  ProcessUpdate(XMove, YMove, ZMove);

		  // Increase action charge of character
		  CharPtr->Charge += ((float)Elapsed / 1000.0f *        \
						   GetCharge(CharPtr));
		  if(CharPtr->Charge > 100.0f)
			  CharPtr->Charge = 100.0f;
	  }
	}else
	{
		if(CharPtr->ActionTimer != 0) {
			CharPtr->ActionTimer -= Elapsed;
			if(CharPtr->ActionTimer < 0)
			  CharPtr->ActionTimer = 0;
		}

		if (CharPtr->ActionTimer <=0){
			CharPtr->FreePath();
			sPacketRebornMonster pkreb;
			pkreb.type = 2;
			pkreb.action = 9;
			pkreb.ID = m_Character->ID;
			CUser* user = m_UserParent;
			while(user != NULL)
			{
				if (user->Initial == 1)
					if (CharPtr->MapID == user->GetCharacter()->MapID)
					{
						while(1)
						{
							WaitForSingleObject(mutexHandle, INFINITE);
								send(user->ClientSocket,(char*)&pkreb,sizeof(sPacketRebornMonster),0);
							ReleaseMutex(mutexHandle);

							readfd.fd_array[0] = user->ClientSocket;
							if(select(0, &readfd, &writefd, &exceptfd, &waittime))
							{
								ZeroMemory(&pkget,sizeof(pkget));
								recv(user->ClientSocket,(char*)&pkget,sizeof(sPacket),0);
								if(pkget.type == 1 && pkget.action == 4)
								{
									break;
								}
							}
							Sleep(50);
						}
					}
				user = user->Next;
			}
			CharPtr->Enabled = TRUE;
			CharPtr->Action = CHAR_IDLE;
			CharPtr->Attacker = NULL;
			CharPtr->Victim = NULL;
			CharPtr->AI = CHAR_WANDER;
			CharPtr->Distance = 0;
			CharPtr->TargetChar = NULL;
			CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
			CharPtr->ManaPoints = CharPtr->Def.ManaPoints;
		}
	}
	}
}


BOOL CCharacter::CharUpdate(long Elapsed,float *XMove, float *YMove, float *ZMove)
{
  float XDiff,ZDiff;
  float Speed;
  int range = 150;
  int random = 300;

  if (m_UserParent != NULL)
  {
	  while(m_UserParent->Prev != NULL)
		m_UserParent = m_UserParent->Prev;
  }
  sCharacter* Chars=NULL;
  CUser* user = m_UserParent;

  // Error checking
  if(m_Character == NULL)
	return FALSE;

    // Calculate movement speed
  Speed = 2;

  // Move character based on their type
  switch(m_Character->AI) {
    case CHAR_STAND:
		m_Character->Action = CHAR_IDLE;
      break;
      
    case CHAR_WANDER:
      // Calculate new distance and direction if needed
      m_Character->Distance -= 2;

      if(m_Character->Distance <= 0) {

		  srand(timeGetTime());
		  float TargetX = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + m_Character->MinX + 50;
		  srand(timeGetTime()+rand());
		  float TargetZ = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + m_Character->MinZ + 50;
		  //float TargetZ = (float)(rand()%(int)(m_Character->MaxZ-m_Character->MinZ)) + m_Character->MinZ;

		  while (TargetX > m_Character->MaxX || TargetX < m_Character->MinX)
		  {
			  srand(timeGetTime());
			  TargetX = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + m_Character->MinX + 50;
		  }

		  while (TargetZ > m_Character->MaxZ || TargetZ < m_Character->MinZ) 
		  {
			  srand(timeGetTime()+rand());
			  TargetZ = (float)(pow(-1,(rand()%2)+1)*(rand() % range)) + m_Character->MinZ + 50;
		  }

		  if (m_StageGame->GetTerrain(m_Character->MapID)->CanMove(TargetX,TargetZ))
		  {
			  D3DXVECTOR2 CharMap = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);
			  D3DXVECTOR2 DestMap = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(TargetX, TargetZ);

			  RoutePath(CharMap,DestMap);

		  	  if (m_UserParent != NULL && m_Character->NumPoints != 0)
			  {
				  m_Character->XDestPos = m_Character->Route[m_Character->NumPoints-1].XPos;
 				  m_Character->ZDestPos = m_Character->Route[m_Character->NumPoints-1].ZPos;
				  while(user != NULL)
				  {
					Chars = user->GetCharacter();
					if (user->Initial == 1)
						if (Chars->MapID == m_Character->MapID)
							if (Chars->ID != m_Character->ID)
							{
								WaitForSingleObject(mutexHandle, INFINITE);
									sPacketWalk pk;
									SetPacketWalk(pk,2,1,m_Character->ID,(char)((int)m_Character->XPos/20),\
										(char)((int)m_Character->ZPos/20),(char)((int)m_Character->XDestPos/20),\
										(char)((int)m_Character->ZDestPos/20),m_Character->Direction);
									send(user->ClientSocket, (char*)&pk, sizeof(pk),0);
								ReleaseMutex(mutexHandle);
								/*char aa[100];
								sprintf(aa,"{%d}[%d][%d][%s] move to %d, %d",\
									pk.ID,pk.type,pk.action,m_Character->Name,pk.xdest,pk.zdest);
								SetListAction(aa);*/
							}
					user = user->Next;
				  }
			  }
			  m_Character->Distance = (float)(fabs(TargetX-m_Character->XPos)+fabs(TargetZ-m_Character->ZPos)) + random;
		  }
      }

      // Process walk or stand still
      if(m_Character->Distance > random) {
        if (m_Character->NumPoints > 0)
		{
			XDiff = m_Character->Route[m_Character->CurrentPoint].XPos - m_Character->XPos;
			ZDiff = m_Character->Route[m_Character->CurrentPoint].ZPos - m_Character->ZPos;

		// Calculate Direction
			if (fabs(m_Character->Direction - m_Character->Route[m_Character->CurrentPoint].Direction) < 0.1f || 
				fabs(m_Character->Direction - (m_Character->Route[m_Character->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
				fabs((m_Character->Direction+(2*D3DX_PI)) - m_Character->Route[m_Character->CurrentPoint].Direction) < 0.1f)
			{
				m_Character->Direction = m_Character->Route[m_Character->CurrentPoint].Direction;
				if (m_Character->Direction >= 2*D3DX_PI)
					m_Character->Direction -= (2*D3DX_PI);
			}
			else 
			{
				if (m_Character->Direction >= 2*D3DX_PI)
					m_Character->Direction -= (2*D3DX_PI);

				float dir = m_Character->Route[m_Character->CurrentPoint].Direction - m_Character->Direction;
				if (dir < 0)
					dir += 2*D3DX_PI;

				if (D3DX_PI > dir)
					m_Character->Direction += D3DX_PI/12;
				else m_Character->Direction -= D3DX_PI/12;	

				if (m_Character->Direction < 0) 
					m_Character->Direction += D3DX_PI*2;
			}
		// Increase to walk
			if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
			{
				*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
				*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

				m_Character->Route[m_Character->CurrentPoint].XPos = -1;
				m_Character->Route[m_Character->CurrentPoint].ZPos = -1;
				m_Character->CurrentPoint++;
				m_Character->NumPoints--;

			}else 
			{
				*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
				*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				m_Character->Action = CHAR_MOVE;
			}

		}else {
			m_Character->Action = CHAR_IDLE;
			
			m_Character->NumPoints = 0;

			m_Character->Distance  = (float)random - 2;
				
			if (m_UserParent != NULL)
			{
				user = m_UserParent;
				while(user != NULL)
				{
					Chars = user->GetCharacter();
					if (user->Initial == 1)
						if (Chars->MapID == m_Character->MapID)
							if (Chars->ID != m_Character->ID)
							{
								WaitForSingleObject(mutexHandle, INFINITE);
									sPacketUpdateMonster pkupdate;
									SetPacketUpdateMonster(pkupdate,2,7,m_Character->ID,(char)((int)m_Character->XPos/20),\
										(char)((int)m_Character->ZPos/20),m_Character->Direction,(char)m_Character->Action,(char)m_Character->AI,-1);
									send(user->ClientSocket,(char*)&pkupdate,sizeof(pkupdate),0);
								ReleaseMutex(mutexHandle);
								/*char aa[100];
								sprintf(aa,"{%d}[%d][%d][%s] update to %d, %d",\
									pkupdate.ID,pkupdate.type,pkupdate.action,m_Character->Name,pkupdate.xpos,pkupdate.zpos);
								SetListAction(aa);*/
							}
					user = user->Next;
				}
			}

		}
      } else {

        // Stand still for one second
		m_Character->FreePath();
        m_Character->Action = CHAR_IDLE;
      }

// Check Frustum of Monster
	  if (m_UserParent!=NULL)
	  {
		  user = m_UserParent;
		  while(user != NULL)
		  {
			  Chars = user->GetCharacter();
			  XDiff = Chars->XPos - m_Character->XPos;
			  ZDiff = Chars->ZPos - m_Character->ZPos;
			  if (fabs(XDiff) < 100 && fabs(ZDiff) < 100 && (Chars->Action != CHAR_DIE))
			  {
					float angle = atanf((float)fabs(ZDiff)/(float)fabs(XDiff));

					float x = D3DXToDegree(angle);

					if(XDiff >= 0 && ZDiff >=0)
						angle = D3DX_PI/2 - angle;
					else if(XDiff >= 0 && ZDiff <=0)
						angle += D3DX_PI/2;
					else if(XDiff <= 0 && ZDiff <=0)
						angle = 3*D3DX_PI/2 - angle;
					else if(XDiff <= 0 && ZDiff >=0)
						angle += 3*D3DX_PI/2;

					float ang1 = ((angle+(D3DX_PI/4)) > 2*D3DX_PI?(angle+(D3DX_PI/4))-(2*D3DX_PI):angle+(D3DX_PI/4));
					float ang2 = ((angle-(D3DX_PI/4)) < 0        ?(angle-(D3DX_PI/4))+(2*D3DX_PI):angle-(D3DX_PI/4));

					if ( ang1 > m_Character->Direction && m_Character->Direction > ang2)
					{
						m_Character->FreePath();
						m_Character->AI = CHAR_FOLLOW;
						char aa[100];
						sprintf(aa,"[%d] follow",m_Character->ID);
						SetListAction(aa);
						m_Character->Direction = angle;
						m_Character->Delay = 5;
						m_Character->Victim = Chars;
						Chars->Attacker = m_Character;
						m_Character->Distance = (float)(fabs(Chars->XPos-m_Character->XPos)+fabs(Chars->ZPos-m_Character->ZPos));
					}
			  }
			  user = user->Next;
		  }
	  }
      break;

    case CHAR_FOLLOW:
      if (m_Character->Distance > 200)
	  {
		  m_Character->Victim->Attacker = NULL;
		  m_Character->Victim = NULL;
		  m_Character->Action = CHAR_IDLE;
		  m_Character->AI = CHAR_WANDER;
		  char aa[100];
		  sprintf(aa,"[%d] wander",m_Character->ID);
		  SetListAction(aa);
		  m_Character->Distance = 0;
		  m_Character->FreePath();
	  }
	  else
	  {
		  if (m_Character->NumPoints == 0)
		  {
			  if (fabs(m_Character->XPos - m_Character->Victim->XPos) > 30 || fabs(m_Character->ZPos - m_Character->Victim->ZPos) >= 30)
			  {
				  m_Character->Delay--;
				  m_Character->Action = CHAR_IDLE;
				  if (m_Character->Delay < 0)
				  {
					m_Character->Delay = 5;
					D3DXVECTOR2 CharPos = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);
					D3DXVECTOR2 DestPos = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->Victim->XPos,m_Character->Victim->ZPos);

					RoutePath(CharPos,DestPos);

					if (m_UserParent != NULL && m_Character->NumPoints != 0)
					{
					  m_Character->XDestPos = m_Character->Route[m_Character->NumPoints-1].XPos;
 					  m_Character->ZDestPos = m_Character->Route[m_Character->NumPoints-1].ZPos;

					  while(m_UserParent->Prev != NULL)
						  m_UserParent = m_UserParent->Prev;
					  user = m_UserParent;
					  while(user != NULL)
					  {
						Chars = user->GetCharacter();
						if (user->Initial == 1)
							if (Chars->MapID == m_Character->MapID)
								if (Chars->ID != m_Character->ID)
								{
									WaitForSingleObject(mutexHandle, INFINITE);
										sPacketWalk pk;
										SetPacketWalk(pk,2,1,m_Character->ID,(char)((int)m_Character->XPos/20),\
											(char)((int)m_Character->ZPos/20),(char)((int)m_Character->XDestPos/20),\
											(char)((int)m_Character->ZDestPos/20),m_Character->Direction);
										send(user->ClientSocket, (char*)&pk, sizeof(pk),0);
									ReleaseMutex(mutexHandle);

									char aa[128];
									sprintf(aa,"[%d][%d][%s] move to %ff, %ff",\
										pk.type,pk.action,m_Character->Name,pk.xdest,pk.zdest);
									SetListAction(aa);
								}
						user = user->Next;
					  }
					}
				  }
			  }
		  }else
		  {
			    XDiff = m_Character->Route[m_Character->CurrentPoint].XPos - m_Character->XPos;
				ZDiff = m_Character->Route[m_Character->CurrentPoint].ZPos - m_Character->ZPos ;

				if (fabs(m_Character->Direction - m_Character->Route[m_Character->CurrentPoint].Direction) < 0.1f || 
					fabs(m_Character->Direction - (m_Character->Route[m_Character->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((m_Character->Direction+(2*D3DX_PI)) - m_Character->Route[m_Character->CurrentPoint].Direction) < 0.1f)
				{
					m_Character->Direction = m_Character->Route[m_Character->CurrentPoint].Direction;
					if (m_Character->Direction >= 2*D3DX_PI)
						m_Character->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (m_Character->Direction >= 2*D3DX_PI)
						m_Character->Direction -= (2*D3DX_PI);

					float dir = m_Character->Route[m_Character->CurrentPoint].Direction - m_Character->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						m_Character->Direction += D3DX_PI/20;
					else m_Character->Direction -= D3DX_PI/20;

					if (m_Character->Direction < 0)
						m_Character->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					m_Character->Route[m_Character->CurrentPoint].XPos = -1;
					m_Character->Route[m_Character->CurrentPoint].ZPos = -1;
					m_Character->CurrentPoint++;
					m_Character->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
					m_Character->Action = CHAR_MOVE;
				}
		  }
		  m_Character->Distance = (float)(fabs(m_Character->Victim->XPos-m_Character->XPos)+fabs(m_Character->Victim->ZPos-m_Character->ZPos)); 

	  }
      break;
  }

  sPacketToChar pkchar;

  if (m_Character->Victim != NULL && !m_Character->ActionTimer)
//	if (m_Character->Victim->Action != CHAR_DIE)
	  if ((m_Character->Type != CHAR_NPC && m_Character->AI == CHAR_FOLLOW))// || (m_Character->Attacker != NULL))
	  {
		  if (fabs(m_Character->XPos-m_Character->Victim->XPos) <= 35 && fabs(m_Character->ZPos-m_Character->Victim->ZPos) <= 35)
		  {
			  if(m_UserParent != NULL)
				while(m_UserParent->Prev != NULL) m_UserParent = m_UserParent->Prev;
			
			  CUser* user = m_UserParent;
		      while(user != NULL)
			  {
				if (user->Initial == 1)
				{
					WaitForSingleObject(mutexHandle, INFINITE);
						pkchar.type = 2;
						pkchar.action = 2;
						pkchar.IDAttacker = m_Character->ID;
						pkchar.IDVictim = m_Character->Victim->ID;
						send(user->ClientSocket,(char*)&pkchar,sizeof(pkchar),0);
					ReleaseMutex(mutexHandle);
				}
				user = user->Next;
			  } 

			  m_Character->FreePath();

			  D3DXVECTOR2 CharPos = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->XPos,m_Character->ZPos);
			  D3DXVECTOR2 PCPos   = m_StageGame->GetTerrain(m_Character->MapID)->GetMapPosition(m_Character->Victim->XPos,m_Character->Victim->ZPos);

			  int x = int(CharPos.x-PCPos.x);
			  int z = int(CharPos.y-PCPos.y);
			  
			  x = x/abs((x==0?1:x));
			  z = z/abs((z==0?1:z));

			  if (x==0 && z==-1) m_Character->Direction = 0;
			  else if (x==0 && z==1) m_Character->Direction = D3DX_PI;
			  else if (x==-1 && z==0) m_Character->Direction = D3DX_PI/2;
			  else if (x==1 && z==0) m_Character->Direction = 3*D3DX_PI/2;
			  else if (x==1 && z==1) m_Character->Direction = 5*D3DX_PI/4;
			  else if (x==1 && z==-1) m_Character->Direction = 7*D3DX_PI/4;
			  else if (x==-1 && z==-1) m_Character->Direction = D3DX_PI/4;
			  else if (x==-1 && z==1) m_Character->Direction = 3*D3DX_PI/4;
		
			  // Perform attack action
			  if (m_Character->Action != CHAR_ATTACK)  {
				SetAction(m_Character,CHAR_ATTACK);
			  }
		  }
	  }

  return TRUE;
}

BOOL CCharacter::RoutePath(D3DXVECTOR2 CharPos,D3DXVECTOR2 DestPos)
{

	sCharacter *Char;
	bool Onchar = false;

	if (m_Character == NULL)
		return FALSE;

	if ((Char = m_CharacterParent)!=NULL)
		while(Char != NULL)
		{
			if (Char->Type != CHAR_PC && Char->Enabled)
				if ((int)(Char->XPos/20) == DestPos.x && (int)(Char->ZPos/20) == DestPos.y)
				{
					Onchar = true;
					break;
				}
			Char = Char->Next;
		}
		//clear Path
	m_Character->FreePath();

	while (CharPos != DestPos)
	{
		int DX = (int)(DestPos.x - CharPos.x);
		int DY = (int)(DestPos.y - CharPos.y);

		if (DX == 0)
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= CharPos.x * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= (CharPos.y +(float)(DY/(fabs(DY)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].Direction
				= ((DY/fabs(DY) > 0)?0:D3DX_PI);

		}else if (DY ==0)
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= CharPos.y * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].Direction
				= ((DX/fabs(DX) > 0)?D3DX_PI/2:(3*D3DX_PI/2)); 
		}
		else //if (fabs(DX) <> fabs(DY))
		{
			m_Character->Route[m_Character->CurrentPoint].XPos 
				= (CharPos.x +(float)(DX/(fabs(DX)))) * 20 + 10;
			m_Character->Route[m_Character->CurrentPoint].ZPos
				= (CharPos.y	+(float)(DY/(fabs(DY)))) * 20 + 10;
			if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) > 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = D3DX_PI/4; 
			else if (DX/(fabs(DX)) > 0 && DY/(fabs(DY)) < 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = 3*D3DX_PI/4; 
			else if (DX/(fabs(DX)) < 0 && DY/(fabs(DY)) < 0)
				m_Character->Route[m_Character->CurrentPoint].Direction = 5*D3DX_PI/4; 
			else 
				m_Character->Route[m_Character->CurrentPoint].Direction = 7*D3DX_PI/4; 

		}
		CharPos.x = (m_Character->Route[m_Character->CurrentPoint].XPos -10) / 20;
		CharPos.y = (m_Character->Route[m_Character->CurrentPoint].ZPos -10) / 20;
		m_Character->CurrentPoint++;
	}
	if (Onchar  && m_Character->CurrentPoint > 0) 
	{
		m_Character->CurrentPoint--;
		m_Character->Route[m_Character->CurrentPoint].XPos=-1;
		m_Character->Route[m_Character->CurrentPoint].ZPos=-1;
		m_Character->Route[m_Character->CurrentPoint].Direction = 0;
	}
	m_Character->NumPoints = m_Character->CurrentPoint;
	m_Character->CurrentPoint = 0;

	return TRUE;
}

BOOL CCharacter::CheckMove(float *XMove, float *YMove, float *ZMove)
{
  sCharacter *Character;

  BYTE** MapArray = GetMapArr(0);

  // Error checking
  if(m_Character == NULL)
    return FALSE;  // Don't allow movement

  if(m_CharacterParent!=NULL)
  {
	while(m_CharacterParent->Prev != NULL)
		m_CharacterParent = m_CharacterParent->Prev;
  }
   // Check movement against other characters
  if((Character = m_CharacterParent) != NULL) {
    while(Character != NULL) {
		if ((m_Character->ID != Character->ID))
		{
			if (m_Character->AI != CHAR_STAND)
			{
				float x = m_Character->Route[m_Character->CurrentPoint].XPos;
				float z = m_Character->Route[m_Character->CurrentPoint].ZPos;
				int xDest = int(Character->XPos)/20;
				int zDest = int(Character->ZPos)/20;
				if (x > 0)
					if (!m_StageGame->GetTerrain(m_Character->MapID)->CanMove(x,z) || ((x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled))
					{
						*XMove = 0;
						*ZMove = 0;
						if (m_Character->NumPoints == 1 && (x-10)/20 == xDest && (z-10)/20 == zDest && Character->Enabled)
						{
							m_Character->FreePath();
							break;
						}
						else 
						{
							m_Character->FreePath();
							if (m_Character->Type == CHAR_PC)
								ValidateMove(XMove, YMove, ZMove);
						}
					}
			}
		}
		Character = Character->Next;
    }

  }

  return TRUE;
}

BOOL CCharacter::ValidateMove(float *XMove, float *YMove, float *ZMove)
{
	sCharacter *Char;
	D3DXVECTOR2 CharMapPos;
	BYTE** MapArray = GetMapArr(0);

	if (m_Character == NULL)
		return FALSE;
	
	CharMapPos	= m_StageGame->GetTerrain(0)->GetMapPosition(m_Character->XPos,m_Character->ZPos);

	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != m_Character->ID && Char->Enabled)
				m_StageGame->GetTerrain(0)->SetCanMove(Char->XPos,Char->ZPos,false);
			Char = Char->Next;
		}
	}
	
		// Check Out of array 
	if (fabs(CharMapPos.x - (int)(m_Character->XDestPos)/20) >= MAX_SHORTCAL/2-1 ||	\
		fabs(CharMapPos.y - (int)(m_Character->ZDestPos)/20) >= MAX_SHORTCAL/2-1)
		return FALSE;

	int x = (int)(m_Character->XDestPos)/20;
	int y = (int)(m_Character->ZDestPos)/20;

	MakePath((int)CharMapPos.x,(int)CharMapPos.y);
			
	m_Character->Route[0].XPos = (float)x*20+10;
	m_Character->Route[0].ZPos = (float)y*20+10;
	m_Character->CurrentPoint = 1;

	while (CharMapPos.x != x || CharMapPos.y != y)
	{
		if (x <=0 && y <= 0) 
		{		
			m_Character->FreePath();
			break;
		}
		int DX = (int)(CharMapPos.x - x);
		int DY = (int)(CharMapPos.y - y);
		if (DX == 0 && DY == 0) break;
		int dx = (DX == 0?0:DX/abs(DX));
		int dy = (DY == 0?0:DY/abs(DY));
		
		if (abs(DX) > abs(DY))
		{
			if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y] )
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (float)y * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint-1].Direction
					= ((dx < 0)?D3DX_PI/2:(3*D3DX_PI/2));
			}else 
			{
				if (y == m_StageGame->GetTerrain(0)->GetNumMap()-1)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						if (dx > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
						else 
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}
				}
				else if (y == 0)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x +(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						if (dx > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}else 
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (x-(float)dx) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}
			}

		}else if (abs(DX) < abs(DY))
		{
			if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+dy] )
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (float)x * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (y+(float)dy) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint-1].Direction
					= (dy < 0)?0:D3DX_PI;
			}else 
			{
				if (x == m_StageGame->GetTerrain(0)->GetNumMap()-1)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+dy])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
						else
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= D3DX_PI/4;							
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}
				}
				else if (x == 0)
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+dy])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (y+(float)dy) * 20 + 10;
						if (dy > 0)
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
						else 
							m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 7*D3DX_PI/4;							
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}
				}else 
				{
					if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)y * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 3*D3DX_PI/2;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 3*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y+1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
								= 5*D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI/4;
					}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y-1])
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)(x+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 7*D3DX_PI/4;
					}else if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1] )
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y-1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= 0;
					}else if ( m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1] )
					{
						m_Character->Route[m_Character->CurrentPoint].XPos 
							= (float)x * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint].ZPos
							= (float)(y+1) * 20 + 10;
						m_Character->Route[m_Character->CurrentPoint-1].Direction
							= D3DX_PI;
					}
				}
			}
		}else if (abs(DX) == abs(DY))
		{
			
			if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y+dy])
			{
				m_Character->Route[m_Character->CurrentPoint].XPos 
					= (x +(float)dx) * 20 + 10;
				m_Character->Route[m_Character->CurrentPoint].ZPos
					= (y +(float)dy) * 20 + 10;
				
				if (dx > 0 && dy > 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
				if (dx > 0 && dy < 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
				if (dx < 0 && dy > 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
				if (dx < 0 && dy < 0)
					m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4;
			}
			else 
			{
				if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+1][y])
				{
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)(x+1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)y * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= 3*D3DX_PI/2;
				
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y+1])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y+1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= D3DX_PI;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-1][y])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)(x-1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= D3DX_PI/2;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x][y-1])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (float)x * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (float)(y-1) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint-1].Direction
						= 0;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x+dx][y-dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x +(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-dx][y+dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y +(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4;
				}else if (m_Character->AllPath[x][y]-1 == m_Character->AllPath[x-dx][y-dy])
				{						
					m_Character->Route[m_Character->CurrentPoint].XPos 
						= (x -(float)dx) * 20 + 10;
					m_Character->Route[m_Character->CurrentPoint].ZPos
						= (y -(float)dy) * 20 + 10;
					
					if (dx > 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = D3DX_PI/4; 
					if (dx > 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 3*D3DX_PI/4; 
					if (dx < 0 && dy > 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 7*D3DX_PI/4; 
					if (dx < 0 && dy < 0)
						m_Character->Route[m_Character->CurrentPoint-1].Direction = 5*D3DX_PI/4;
				}
			}
		}
		x = (int)(m_Character->Route[m_Character->CurrentPoint].XPos -10) / 20;
		y = (int)(m_Character->Route[m_Character->CurrentPoint].ZPos -10) / 20;
		m_Character->CurrentPoint++;
	}
	SortArr();
	m_Character->NumPoints = m_Character->CurrentPoint-1;
	m_Character->CurrentPoint = 0;
	////////////////
	if((Char = m_CharacterParent) != NULL) {
		while(Char != NULL) {
			if (Char->ID != m_Character->ID && m_Character->Enabled)
				m_StageGame->GetTerrain(0)->SetCanMove(Char->XPos,Char->ZPos,true);
			Char = Char->Next;
		}
	}
	return TRUE;
}

BOOL CCharacter::SortArr()
{
	sRoutePoint* arr = m_Character->Route;
	sRoutePoint* tmp = new sRoutePoint[MAX_SHORTPATH];
	int i,j,k;

	for (j=0,i = MAX_SHORTPATH-1;i>=0;i--,j++)
	{
		tmp[j] = arr[i];
		arr[i].Direction = 0;
		arr[i].XPos	= -1;
		arr[i].YPos = -1;
		arr[i].ZPos = -1;
	}

	
	i=0;
	while (tmp[i].XPos == -1) 
		i++;
	i++;
	for (j=i,k=0;j<MAX_SHORTPATH;j++,k++)
	{
		arr[k] = tmp[j];
	}
	
	for (j = k;j<MAX_SHORTPATH;j++)
	{
		arr[j].Direction = 0;
		arr[j].XPos = -1;
		arr[j].YPos = -1;
		arr[j].ZPos = -1;
	}

	delete[] tmp;

	return TRUE;
}

void CCharacter::ShortestPath(int stx,int sty,int tx, int ty, int step)
{
	if (stx == int(m_Character->XDestPos/20) && sty == (int)(m_Character->ZDestPos/20))
		return;

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0') 
	{
		if (m_Character->AllPath[stx+1+tx][sty+ty]==0 || m_Character->AllPath[stx+1+tx][sty+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty+ty] = step;
			ShortestPath(stx,sty,tx+1,ty,step+1);
		}
	}
	
	if (ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+tx][sty+1+ty]==0 || m_Character->AllPath[stx+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty+ty]==0 || m_Character->AllPath[stx-1+tx][sty+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty+ty] = step;
			ShortestPath(stx,sty,tx-1,ty,step+1);
		}

	}

	if (ty-1+(MAX_SHORTCAL/2) >=0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+tx][sty-1+ty]==0 || m_Character->AllPath[stx+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx,ty-1,step+1);
		}
	}
	
	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+1+tx][sty+1+ty]==0 || m_Character->AllPath[stx+1+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx+1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty+1+ty]==0 || m_Character->AllPath[stx-1+tx][sty+1+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty+1+ty] = step;
			ShortestPath(stx,sty,tx-1,ty+1,step+1);
		}
	}

	if (tx-1+(MAX_SHORTCAL/2) >= 0 && ty-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx-1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx-1+tx][sty-1+ty]==0 || m_Character->AllPath[stx-1+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx-1+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx-1,ty-1,step+1);
		}
	}

	if (tx+1+(MAX_SHORTCAL/2) < MAX_SHORTCAL && ty-1+(MAX_SHORTCAL/2) >= 0 && m_Character->TempArr[tx+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0' \
		&& m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty+(MAX_SHORTCAL/2)] == '0' && m_Character->TempArr[tx+1+(MAX_SHORTCAL/2)][ty-1+(MAX_SHORTCAL/2)] == '0')
	{
		if (m_Character->AllPath[stx+1+tx][sty-1+ty]==0 || m_Character->AllPath[stx+1+tx][sty-1+ty]>step)
		{
			m_Character->AllPath[stx+1+tx][sty-1+ty] = step;
			ShortestPath(stx,sty,tx+1,ty-1,step+1);
		}
	}
}

BOOL CCharacter::MakePath(int Stx,int Sty)
{
	int x,y;

	//FILE* fid = fopen("out.txt","w");
	//FILE* fid2= fopen("out2.txt","w");

	for (int i=0;i<MAX_SHORTCAL;i++)
		for (int j=0;j<MAX_SHORTCAL;j++)	
		{
			if ((Stx-(MAX_SHORTCAL/2)+i)<0 || (Sty-(MAX_SHORTCAL/2)+j)<0)
			{
				m_Character->TempArr[i][j] = '1';
			}
			else 
			{	
				x = (int)Stx-(MAX_SHORTCAL/2)+i;
				y = (int)Sty-(MAX_SHORTCAL/2)+j;
				m_Character->TempArr[i][j] = (m_StageGame->GetTerrain(0)->CanMove((float)x*20, (float)y*20)?'0':'1');
			}
		}

	/*for (i=MAX_SHORTCAL-1;i>=0;i--)
	{
		for(int j=0;j<MAX_SHORTCAL;j++)
		{
			fprintf(fid,"%c",CharPtr->TempArr[j][i]);
		}
		fprintf(fid,"\n\r");
	}
	fclose(fid);
*/
	ShortestPath(Stx,Sty,0,0,1);
	m_Character->AllPath[Stx][Sty] = 0;

	/*int POS = CharPtr->MapSize;
	for(i=POS-1;i>=0;i--)
	{
		for(int j=0;j<POS;j++)
		{
			if (CharPtr->AllPath[j][i] >= 10)
				fprintf(fid2,"%i",CharPtr->AllPath[j][i]);
			else 
				fprintf(fid2,"%i ",CharPtr->AllPath[j][i]);
		}	
		fprintf(fid2,"\n\r");
	}
	fclose(fid2);
	*/return TRUE;
}

BOOL CCharacter::ProcessUpdate(float XMove, float YMove, float ZMove)
{
	// Move character
	m_Character->XPos += XMove;
	m_Character->YPos = YMove;
	m_Character->ZPos += ZMove;

	return TRUE;
}

BOOL CCharacter::Attack(sCharacter *Attacker,       \
                                  sCharacter *Victim)
{
	// Error checking
	if(Attacker == NULL || Victim == NULL)
	return FALSE;

	// Don't attack dead or hurt people
	if(Victim->Action == CHAR_DIE)
		return FALSE;

	// Set attacker and victim
	Victim->Attacker = Attacker;
	Attacker->Victim = Victim;

	// Return if hit missed
	if((rand() % 1000) > GetToHit(Attacker)) {
		SetMessage(Victim, "Missed!", 500);
		return FALSE;
	}

	// Return if hit dodged
	if((rand() % 1000) <= GetAgility(Victim)) {
		SetMessage(Victim, "Dodged!", 500);
		return FALSE;
	}

	// Attack landed, apply damage
	Damage(Victim, TRUE, GetAttack(Attacker), -1, -1);

	return TRUE;
}

BOOL CCharacter::Damage(sCharacter *Victim,         \
                                  BOOL PhysicalAttack,        \
                                  long Amount,                \
                                  long DmgClass,              \
                                  long CureClass)
{
	char Text[128];
	float Resist;
	float Range;
	long  DmgAmount;

	// Error checking
	if(Victim == NULL)
	return FALSE;

	// Can't attack if already dead or being hurt (or not enabled)
	if(Victim->Enabled == FALSE ||                              \
	 Victim->Action==CHAR_DIE)
	return FALSE;

	// Adjust for defense if physical attack
	if(PhysicalAttack == TRUE) {

		// Random value for less/more damage (-+20%)
		Range     = (float)((rand() % 20) + 90) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);

		// Subtract for defense of victim (allow -20% difference)
		Range     = (float)((rand() % 20) + 80) / 100.0f;
		DmgAmount -= (long)((float)GetDefense(Victim) * Range);
	} else {
		// Adjust for magical attack
		Resist = 1.0f - ((float)GetResistance(Victim) / 100.0f);
		DmgAmount = (long)((float)Amount * Resist);
	}

	// Bounds check value
	if(DmgAmount < 0)
	DmgAmount = 1;

	// Check for double damage
	if(Victim->Def.Class == DmgClass)
	DmgAmount *= 2;

	// Check for cure damage
	if(Victim->Def.Class == CureClass)
	DmgAmount = -(labs(DmgAmount)/2);

	// If no physical damage is dealt then randomly deal 
	// 10-20% of damage from the original amount.
	if(!DmgAmount && PhysicalAttack == TRUE) {
		Range     = (float)((rand() % 10) + 10) / 100.0f;
		DmgAmount = (long)((float)Amount * Range);
	}

	// Subtract damage amount
	Victim->HealthPoints -= DmgAmount;

	// Set hurt status and display message
	if(DmgAmount >= 0) {
		sprintf(Text, "-%lu HP", DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(255,64,0,255));

		// Only set hurt if any damage (and idle or moving)
		if(DmgAmount) {
		  if(Victim->Action==CHAR_MOVE || Victim->Action==CHAR_IDLE)
			SetAction(Victim, CHAR_HURT);
		}
	} 

	// Display cure amount
	if(DmgAmount < 0) {
		sprintf(Text, "+%lu HP", -DmgAmount);
		SetMessage(Victim, Text, 500, D3DCOLOR_RGBA(0,64,255,255));
	}

	return TRUE;
}

BOOL CCharacter::Death(sCharacter *Attacker,        \
                                 sCharacter *Victim)
{
	char Text[128];

	ZeroMemory(Text, sizeof(char));

	// If a PC or NPC dies, then don't remove from list
	if(Victim->Type == CHAR_PC) {
	// Mark character as disabled so no updates
		Victim->Enabled = FALSE;

	} else {
		// Give attacker the victim's experience
		if(Attacker != NULL) {
		  if(Experience(Attacker, Victim->Def.Experience) == TRUE) {
			sprintf(Text, "+%lu exp.", Victim->Def.Experience);
			SetMessage(Attacker, Text, 500);
		  }
		}

		// Drop character's money
		if((m_StageGame->FindItemDef(0) != NULL) && ((rand() % 100) <= Victim->Def.DropChance))
		{
			char ItemName[30];
			strcpy(ItemName,"");

		}
	}

	return TRUE;
}