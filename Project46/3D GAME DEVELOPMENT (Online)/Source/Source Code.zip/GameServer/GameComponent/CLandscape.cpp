
#include "CLandscape.h"
#include <stdlib.h>
#include <fstream.h>

//============================================================================
// Class : CLandscape
//============================================================================
CLandscape::CLandscape()
{
  m_CanMove		= FALSE;
  m_MID = -1;
  m_MapArray = NULL;
}

CLandscape::~CLandscape()
{
  Cleanup();
}

BOOL CLandscape::Cleanup()
{
  m_CanMove		= FALSE;

  SAFE_DELETE_ARRAY(m_MapArray);

  
  return TRUE;
}

BOOL CLandscape::Create(int MID, int Pos)
{
  Cleanup();

  POS = Pos;
  
  char szTemp[127];
  
  // Get map array from file
  sprintf(szTemp, ".\\Model\\Map\\Map%d.txt", MID);
  fstream mapFile( szTemp, ios::in | ios::binary );
  if( !mapFile )
      return false;

  m_MapArray = (BYTE**)malloc(POS * sizeof(BYTE*));
  for (int i=0; i < POS; i++)
	  m_MapArray[i] = (BYTE*)malloc(POS * sizeof(BYTE));

  const unsigned int BUFF_SIZE = POS+2;
  char* buff;//[ BUFF_SIZE ];
  buff = (char*)malloc(BUFF_SIZE* sizeof(char));

  int line = POS-1;
  while( !mapFile.eof() && line >=0){
	  mapFile.read( buff, BUFF_SIZE );
	  unsigned int buffsize = mapFile.gcount();
	  for(int i=0 ; i<POS ; i++){
		  if (buff[i] == '0')
			  m_MapArray[i][line] = '0';
		  else if (buff[i] == '1')
			  m_MapArray[i][line] = '1';
	  }
	  line--;
  }

  m_MID = MID;

  return TRUE;
}

D3DXVECTOR2 CLandscape::GetMapPosition(float XPos, float ZPos) 
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	return D3DXVECTOR2((float)xMap, (float)zMap);
}

BOOL CLandscape::SetCanMove(float XPos,float ZPos,bool CanMove)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

	if (CanMove)
		m_MapArray[xMap][zMap] = '0';
	else m_MapArray[xMap][zMap] = '1';

	return TRUE;

}
BOOL CLandscape::CanMove(float XPos, float ZPos)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos / 20.0f);
	zMap = (int)(ZPos / 20.0f);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

		// Compare with mapArray whether position can move to or not
	if (m_MapArray[xMap][zMap] == '0')
		return TRUE;

	return FALSE;
}

INT CLandscape::GetValueMap(float XPos, float ZPos)
{
	int xMap, zMap;		// For Map Array
	xMap = (int)(XPos);
	zMap = (int)(ZPos);

	// Out Bound
	if(xMap < 0 || zMap < 0 || xMap >= POS || zMap >= POS)
		return FALSE;

		// Compare with mapArray whether position can move to or not
	return m_MapArray[xMap][zMap];
	
}
