#ifndef _CLANDSCAPE_H_
#define _CLANDSCAPE_H_


#include "HGlobal.h"
//============================================================================
// Class : CLandscape
//============================================================================
class CLandscape
{
private:
	int m_MID;

	BOOL			m_CanMove;		// to disable mouseOn draw automatically
									// when mouse on position that cannot move to

	BYTE**			m_MapArray; 	// Array of Map

	INT				POS;

public:
	CLandscape();	// Constructor
	~CLandscape();	// Destructor

	BOOL Create(int MID, int Pos);
	BOOL Cleanup();


	BOOL SetCanMove(float XPos,float ZPos,bool CanMove=TRUE);

	D3DXVECTOR2 GetMapPosition(float XPos, float ZPos) ;
	INT			GetNumMap(){return POS;}
	BYTE**		GetMapArr(){return m_MapArray;}

	// Draw MouseOn on land
	// return position on map (center of grid)
	// and whether player can move over it
	BOOL CanMove(float XPos, float ZPos);

	INT GetValueMap(float XPos, float ZPos);

};

#endif
