#include "HGlobal.h"

#include "CCharacterControl.h"

CCharacterController::CCharacterController()
{
  m_StageGame		  = NULL;  // StageGame Pointer
 
  m_CharacterParent   = NULL;  // Clear character list
  m_CharsParent		  = NULL;
  m_UserParent		  = NULL;
  m_NumCharacters     = 0;
  serverSocket		  = 0;
  ZeroMemory(ClientSocket,sizeof(ClientSocket));
  ClientCount		  = 0;
  m_DB = NULL;
}

CCharacterController::~CCharacterController()
{
  Shutdown();
}

BOOL CCharacterController::Shutdown()
{

  SAFE_DELETE(m_CharsParent);
  SAFE_DELETE(m_UserParent);

  if(serverSocket != 0)
	  ShutdownServer();
  Cleanup();
  m_DB = NULL;
  m_StageGame = NULL;

  return TRUE;
}

BOOL CCharacterController::Cleanup()
{
  // Release character structures
  delete m_CharacterParent;
  m_CharacterParent = NULL;
  m_NumCharacters = 0;

  return TRUE;
}

BOOL CCharacterController::StartServer()
{
	int error;
	WSAData wsaData;

	// startup winsock
	if ((error = WSAStartup(MAKEWORD(2, 2), &wsaData)) == SOCKET_ERROR) {
		SetListAction("Could Not Start Up Winsock!\n");
		return FALSE;
	}

	// create socket
	serverSocket = socket(AF_INET, SOCK_STREAM, 0);
	
	// error checking
	if (serverSocket == SOCKET_ERROR) {
		SetListAction("Error Opening Socket!\n");
		return FALSE;
	}

	// the address structure
	struct sockaddr_in server;

	// fill the address structure with appropriate data
	server.sin_family = AF_INET;
	server.sin_port = htons(9999);
	server.sin_addr.s_addr = INADDR_ANY;

	// bind socket
	if (bind(serverSocket, (sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
		SetListAction("Bind Failed!\n");
		closesocket(serverSocket);
		return FALSE;
	}
	// mark socket for listening
	if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
		SetListAction("Listen Failed!\n");
		closesocket(serverSocket);
		return FALSE;
	}

	SetListAction("Server Started\n");

	return TRUE;

}

BOOL CCharacterController::ShutdownServer()
{
	// close  socket
	closesocket(serverSocket);

	// shutdown winsock
	WSACleanup();

	return TRUE;
}

BOOL CCharacterController::Update()
{

	return TRUE;
}

int CCharacterController::CheckLogin(int clsock)
{
	sPacketLogin pk;

	recv(clsock,(char*)&pk,sizeof(pk),0);
	
	char sql[100];
	sprintf(sql,"select * from Login where ID='%s'",pk.user);
	CRecordset* res = m_DB->Query(sql);
	CDBVariant dbvar;
	CString usr,pass;
	int id;

	for(int i=0;i<res->GetRecordCount();i++)
	{
		res->GetFieldValue("AID",dbvar);	id = dbvar.m_iVal;
		res->GetFieldValue("ID", usr);	
		res->GetFieldValue("Passwd",pass);
	}
	res->Close();

	WaitForSingleObject(mutexHandle, INFINITE);
		if (!strcmp(usr.GetBuffer(usr.GetLength()),pk.user) && 
			!strcmp(pass.GetBuffer(pass.GetLength()),pk.pass))
		{
			strcpy(pk.user,"pass");

			send(clsock,(char*)&pk,sizeof(pk),0);
			return id;
		}else{
			strcpy(pk.user,"nopass");

			send(clsock,(char*)&pk,sizeof(pk),0);
			closesocket(clsock);
			ClientSocket[ClientCount--] = 0;
		}
	ReleaseMutex(mutexHandle);

	return -1;
}

BOOL CCharacterController::ListenClient()
{
	FD_SET readfd;
	FD_SET writefd;
	writefd.fd_count = 0;
	FD_SET exceptfd;
	exceptfd.fd_count = 0;
	timeval waittime;
	waittime.tv_sec = 0;
	waittime.tv_usec = 0;

	readfd.fd_count = 1;
	readfd.fd_array[0] = serverSocket;
	if(select(0, &readfd, &writefd, &exceptfd, &waittime))
	{
		while(ClientSocket[ClientCount]!=0){
			ClientCount++;
			if (ClientCount >= 1000) ClientCount =0;
		}
		ClientSocket[ClientCount] = accept(serverSocket, NULL, NULL);
		if(ClientSocket[ClientCount] == INVALID_SOCKET)
			return WSAGetLastError();

		int id = CheckLogin(ClientSocket[ClientCount]);
		if(id != -1)
		{
			AddUser(ClientSocket[ClientCount++],id);
		}
		
		if(m_CharsParent!=NULL)
			while(m_CharsParent->Prev != NULL) m_CharsParent = m_CharsParent->Prev;

	
		CCharacter* Char = m_CharsParent;
		while(Char!=NULL)
		{
			Char->SetUserInfo(m_UserParent);
			Char = Char->Next;
		}
	}

	CUser* user = m_UserParent;
	CUser* tmp,*tmp2;
	while(user != NULL)
	{
		if(user->Initial == 2)
		{
			if(m_UserParent != NULL)
				while(m_UserParent->Prev != NULL)
					m_UserParent = m_UserParent->Prev;

			char sql[255];
			CDBVariant dbvar;
			CString st;
			sCharacter* CharPtr = user->GetCharacter();

			sprintf(sql,"Update Charinfo set LV=%i,EXP=%i,HP=%i,MaxHP=%i,MP=%i,MaxMP=%i,Str=%i,Vit=%i,Intel=%i,Money=%i,MapID=%i,Xpos=%f,Zpos=%f where AID = %i",CharPtr->Def.Level,CharPtr->Def.Experience,CharPtr->HealthPoints,CharPtr->Def.HealthPoints,CharPtr->ManaPoints,CharPtr->Def.ManaPoints,CharPtr->Def.Attack,CharPtr->Def.Defense,CharPtr->Def.Resistance,CharPtr->Def.Money,CharPtr->MapID+20000,CharPtr->XPos,CharPtr->ZPos,CharPtr->ID);
			m_DB->Update(sql);
			
			char aa[200];
			sprintf(aa,"[%s] disconnected ... ",CharPtr->Name);
			SetListAction(aa);
			DelListConnection(CharPtr->Name);
			
			if(user->Prev != NULL)
				user->Prev->Next = user->Next;
			else
				m_UserParent = user->Next;

			if(user->Next != NULL)
				user->Next->Prev = user->Prev;

			if(user->Prev == NULL && user->Next == NULL)
				m_UserParent = NULL;

			tmp = user;
			user = user->Next;

			if(m_UserParent != NULL)
				while(m_UserParent->Prev != NULL)
					m_UserParent = m_UserParent->Prev;
			
			tmp2 = m_UserParent;
			while(tmp2!=NULL)
			{
				tmp2->SetUserInfo(m_UserParent);
				tmp2 = tmp2->Next;
			}

			if(m_CharsParent != NULL)
				while(m_CharsParent->Prev != NULL)
					m_CharsParent = m_CharsParent->Prev;

			CCharacter* Char = m_CharsParent;
			while(Char!=NULL)
			{
				Char->SetUserInfo(m_UserParent);
				Char = Char->Next;
			}
			tmp->Next = NULL;
			tmp->Prev = NULL;
			SAFE_DELETE(tmp);
			continue;
		}
		user = user->Next;
	}

	return TRUE;
}

BOOL CCharacterController::AddUser(int ClSocket,int id)
{
  sCharacter *CharPtr;
  CRecordset* res;
  CDBVariant dbvar;
  CString st;
  long i;
  char sql[100];
  
   // Allocate a new structure
  CharPtr = new sCharacter();

  ZeroMemory(CharPtr->Name, sizeof(CharPtr->Name));
  
  sprintf(sql,"select * from Charinfo where AID=%i",id);
  res = m_DB->Query(sql);

  for(i=0;i<res->GetRecordCount();i++)
  {
	  res->GetFieldValue("CharName", st);

	  strcpy(CharPtr->Name, st.GetBuffer(st.GetLength()));
	  CharPtr->Definition = 0;
	  CharPtr->Type       = CHAR_PC;
	  CharPtr->AI         = CHAR_STAND;	  	  
	  CharPtr->XDestPos	  = CharPtr->XPos;
	  CharPtr->ZDestPos	  = CharPtr->ZPos;
	  CharPtr->TargetChar = NULL;
	  CharPtr->Direction  = 0;
	  CharPtr->Enabled    = TRUE;
	  
	  // Set a random charge amount
	  CharPtr->Charge = (float)(rand() % 101);
  
	  res->GetFieldValue("Class", dbvar);	CharPtr->Def.Class = dbvar.m_iVal;
	  res->GetFieldValue("LV", dbvar);		CharPtr->Def.Level = dbvar.m_iVal;
	  res->GetFieldValue("EXP", dbvar);		CharPtr->Def.Experience = dbvar.m_lVal;
	  res->GetFieldValue("MaxHP", dbvar);	CharPtr->Def.HealthPoints = dbvar.m_iVal;
	  res->GetFieldValue("MP", dbvar);		CharPtr->ManaPoints = dbvar.m_iVal;
	  res->GetFieldValue("MaxMP", dbvar);	CharPtr->Def.ManaPoints = dbvar.m_iVal;
	  res->GetFieldValue("Str", dbvar);		CharPtr->Def.Attack = dbvar.m_iVal;
	  res->GetFieldValue("Vit", dbvar);		CharPtr->Def.Defense = dbvar.m_iVal;
	  res->GetFieldValue("Intel", dbvar);	CharPtr->Def.Resistance = dbvar.m_iVal;	
	  res->GetFieldValue("Agi", dbvar);		CharPtr->Def.Agility = dbvar.m_iVal;
	  res->GetFieldValue("Mental", dbvar);	CharPtr->Def.Mental = dbvar.m_iVal;
	  res->GetFieldValue("ToHit", dbvar);	CharPtr->Def.ToHit = dbvar.m_iVal;	
	  res->GetFieldValue("Money", dbvar);	CharPtr->Def.Money = dbvar.m_iVal;
	  res->GetFieldValue("AID", dbvar);		CharPtr->ID       = dbvar.m_iVal;
	  res->GetFieldValue("MapID", dbvar);	CharPtr->MapID	  = dbvar.m_iVal-20000;
	  res->GetFieldValue("Xpos", dbvar);	CharPtr->XPos     = (float)dbvar.m_dblVal;
	  CharPtr->YPos       = 0;
	  res->GetFieldValue("Zpos", dbvar);    CharPtr->ZPos       = (float)dbvar.m_dblVal;

	  CharPtr->MapSize	  = m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap();
	  CharPtr->AllPath	  = (int**)malloc(m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap() * sizeof(int*));
	  for (i=0; i < m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap(); i++)
		CharPtr->AllPath[i] = (int*)malloc(m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap() * sizeof(int));

  }
  res->Close();
    // Set character stats
  CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
  CharPtr->ManaPoints   = CharPtr->Def.ManaPoints;

  ZeroMemory(CharPtr->ScriptFilename, sizeof(char));

  strcpy(CharPtr->ScriptFilename,"NONE");

  // Link in to head of list
  if(m_CharacterParent != NULL)
    m_CharacterParent->Prev = CharPtr;
  CharPtr->Next = m_CharacterParent;
  m_CharacterParent = CharPtr;

  CUser* Chars = new CUser();

  if (m_UserParent != NULL)
	  m_UserParent->Prev = Chars;
  Chars->Next = m_UserParent;
  m_UserParent = Chars;

  Chars->SetData(m_UserParent, m_StageGame, m_CharacterParent, CharPtr, ClSocket);
  Chars->CreateUserthread();
  
  return TRUE;
}

BOOL CCharacterController::Init(CStageGame* StageGame,CDB* DB)
{

	Cleanup();  // Free prior init

	// Get parent graphics object and error checking
	if((m_StageGame = StageGame) == NULL)
		return FALSE;

	if ((m_DB = DB)==NULL)
		return FALSE;

/////////// Item /////////////
	StageGame->LoadItemDef();
	StageGame->LoadEnvDef();
	
  return TRUE;
}

BOOL CCharacterController::Add(                               \
             long IDNum, char* name, long Definition,                     \
             long Type, long AI,                              \
             float XPos, float YPos, float ZPos,              \
             float Direction,int MapID)
{
  sCharacter *CharPtr;
  long i;

   // Allocate a new structure
  CharPtr = new sCharacter();

  ZeroMemory(CharPtr->Name, sizeof(CharPtr->Name));
  // Assign data
  if (name != NULL)
	strcpy(CharPtr->Name, name);

  CharPtr->Definition = Definition;
  CharPtr->ID         = IDNum;
  CharPtr->MapID	  = MapID;
  CharPtr->Type       = Type;
  CharPtr->AI         = AI;
  CharPtr->XPos       = XPos;
  CharPtr->YPos       = YPos;
  CharPtr->ZPos       = ZPos;
  CharPtr->XDestPos	  = XPos;
  CharPtr->ZDestPos	  = ZPos;
  CharPtr->TargetChar = NULL;
  CharPtr->Direction  = Direction;
  CharPtr->Enabled    = TRUE;
  CharPtr->MapSize	  = m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap();
  CharPtr->AllPath	  = (int**)malloc(m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap() * sizeof(int*));
  for (i=0; i < m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap(); i++)
	CharPtr->AllPath[i] = (int*)malloc(m_StageGame->GetTerrain(CharPtr->MapID)->GetNumMap() * sizeof(int));

  // Set a random charge amount
  CharPtr->Charge = (float)(rand() % 101);

  char sql[100];
  sprintf(sql,"select * from Monster where MonID=%d",Definition);
  CRecordset* res = m_DB->Query(sql);
  CDBVariant dbvar;
  CString st;

  for(i=0;i<res->GetRecordCount();i++)
  {
	  res->GetFieldValue("MonName", st);	strcpy(CharPtr->Def.Name,st.GetBuffer(st.GetLength()));
	  res->GetFieldValue("Class", dbvar);	CharPtr->Def.Class = dbvar.m_iVal;
	  res->GetFieldValue("LV", dbvar);		CharPtr->Def.Level = dbvar.m_iVal;
	  res->GetFieldValue("EXP", dbvar);		CharPtr->Def.Experience = dbvar.m_iVal;
	  res->GetFieldValue("HP", dbvar);		CharPtr->Def.HealthPoints = dbvar.m_iVal;
	  res->GetFieldValue("MP", dbvar);		CharPtr->Def.ManaPoints = dbvar.m_iVal;
	  res->GetFieldValue("Str", dbvar);		CharPtr->Def.Attack = dbvar.m_iVal;
	  res->GetFieldValue("Vit", dbvar);		CharPtr->Def.Defense = dbvar.m_iVal;
	  res->GetFieldValue("Intel", dbvar);	CharPtr->Def.Resistance = dbvar.m_iVal;	
	  res->GetFieldValue("Agi", dbvar);		CharPtr->Def.Agility = dbvar.m_iVal;
	  res->GetFieldValue("Mental", dbvar);	CharPtr->Def.Mental = dbvar.m_iVal;
	  res->GetFieldValue("ToHit", dbvar);	CharPtr->Def.ToHit = dbvar.m_iVal;	
	  res->GetFieldValue("Money", dbvar);	CharPtr->Def.Money = dbvar.m_iVal;
	  res->GetFieldValue("DropChance", dbvar);	CharPtr->Def.DropChance = dbvar.m_iVal;

  }
  res->Close();
    // Set character stats
  CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
  CharPtr->ManaPoints   = CharPtr->Def.ManaPoints;

  ZeroMemory(CharPtr->ScriptFilename, sizeof(char));

  strcpy(CharPtr->ScriptFilename,"NONE");

  // Link in to head of list
  if(m_CharacterParent != NULL)
    m_CharacterParent->Prev = CharPtr;
  CharPtr->Next = m_CharacterParent;
  m_CharacterParent = CharPtr;

  CCharacter* Chars = new CCharacter(m_StageGame, m_CharacterParent, CharPtr);

  if (m_CharsParent != NULL)
	  m_CharsParent->Prev = Chars;
  Chars->Next = m_CharsParent;
  m_CharsParent = Chars;

  Chars->CreateMonsterthread();

  return TRUE;
}

sCharacter *CCharacterController::GetParentCharacter()
{
  return m_CharacterParent;
}

sCharacter *CCharacterController::GetCharacter(long IDNum)
{
  sCharacter *CharPtr;

  // Scan through all characters
  if((CharPtr = m_CharacterParent) != NULL) {
    while(CharPtr != NULL) {
    
      // Return character
      if(IDNum == CharPtr->ID)
        return CharPtr;
   
      // Go to next character
      CharPtr = CharPtr->Next;
    }
  }

  return NULL;
}
BOOL CCharacterController::Remove(long IDNum)
{
  return Remove(GetCharacter(IDNum));
}
 
BOOL CCharacterController::Remove(sCharacter *Character)
{
  // Error checking
  if(Character == NULL)
    return FALSE;

  // Remove from list and free resource
  if(Character->Prev != NULL)
    Character->Prev->Next = Character->Next;
  else
    m_CharacterParent = Character->Next;

  if(Character->Next != NULL)
    Character->Next->Prev = Character->Prev;

  if(Character->Prev == NULL && Character->Next == NULL)
    m_CharacterParent = NULL;

  Character->Prev = Character->Next = NULL;

  delete[] Character->AllPath;
  delete Character;

  return TRUE;
}

BOOL CCharacterController::SetBounds(                         \
               long IDNum,                                    \
               float MinX, float MinY, float MinZ,            \
               float MaxX, float MaxY, float MaxZ)
{
  sCharacter *CharPtr;

  // Get pointer to character
  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  // Set new values
  CharPtr->MinX = min(MinX, MaxX);
  CharPtr->MinY = min(MinY, MaxY);
  CharPtr->MinZ = min(MinZ, MaxZ);
  CharPtr->MaxX = max(MinX, MaxX);
  CharPtr->MaxY = max(MinY, MaxY);
  CharPtr->MaxZ = max(MinZ, MaxZ);

  return TRUE;
}

BOOL CCharacterController::GetBounds(                         \
               long IDNum,                                    \
               float *MinX, float *MinY, float *MinZ,         \
               float *MaxX, float *MaxY, float *MaxZ)
{
  sCharacter *CharPtr;

  if((CharPtr = GetCharacter(IDNum)) == NULL)
    return FALSE;

  if(MinX != NULL)
    *MinX = CharPtr->MinX;
  if(MinY != NULL)
    *MinY = CharPtr->MinY;
  if(MinZ != NULL)
    *MinZ = CharPtr->MinZ;
  if(MaxX != NULL)
    *MaxX = CharPtr->MaxX;
  if(MaxY != NULL)
    *MaxY = CharPtr->MaxY;
  if(MaxZ != NULL)
    *MaxZ = CharPtr->MaxZ;

  return TRUE;
}

BOOL CCharacterController::LoadItemListToChar(int IDNum)
{
	sCharacter* CharPtr = GetCharacter(IDNum);
	
	//strcpy(CharPtr->ItemFilename,filename);
//	CharPtr->m_Inventory.LoadInventory(CharPtr,m_StageGame);
	return TRUE;
}