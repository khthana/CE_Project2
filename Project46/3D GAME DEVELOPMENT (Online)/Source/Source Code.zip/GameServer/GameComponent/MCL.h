#ifndef _MCL_H_
#define _MCL_H_

// Number of characters in file
#define NUM_CHARACTER_DEFINITIONS   256

// Character types
#define CHAR_PC          0
#define CHAR_NPC         1
#define CHAR_MONSTER     2

// AI types
#define CHAR_STAND       0
#define CHAR_WANDER      1
#define CHAR_ROUTE       2
#define CHAR_FOLLOW      3
#define CHAR_EVADE       4

// Action/Animation types
#define CHAR_IDLE        0
#define CHAR_MOVE        1
#define CHAR_ATTACK      2
#define CHAR_SPELL       3
#define CHAR_ITEM        4
#define CHAR_HURT        5
#define CHAR_DIE         6
#define CHAR_TALK        7

#define MAX_SHORTPATH	100
#define MAX_SHORTCAL	20

typedef struct sCharacterDefinition
{
  // Misc data
  char  Name[32];           // Name of character
  long  Class;              // Class # of character
  long  Money;              // Amount of money
  float Speed;              // Movement speed
  long  MagicSpells[2];     // Bit flags to mark known spells
  long  MeshNum;            // Mesh/anim # to load

  // Abilities
  long  Agility;            // Agility ability
  long  Attack;             // Attack ability
  long  Defense;            // Defend ability
  long  Resistance;         // Magic resistance ability
  long  Mental;             // Mental ability
  long  ToHit;              // Chance to hit

  // Attributes
  long  HealthPoints;       // # health points (maximum)
  long  ManaPoints;         // # mana points (maximum)
  long  Level;              // Experience level
  long  Experience;         // Experience points

  // Inventory
  char  ItemFilename[100]; // CharICS filename 
  long  Weapon;             // Equipped Weapon
  long  Armor;              // Equipped Armor
  long  Shield;             // Equipped Shield
  long  Accessory;          // Equipped Accessory

  // Dropping item data
  long  DropChance;         // % of dropping item when killed
  long  DropItem;           // Item # to drop when killed
  
  // Attack/Magic chances and effects
  float Range;              // Attack range
  float ChargeRate;         // Countdown rate to attack
  long  ToAttack;           // Percent to attack
  long  ToMagic;            // Percent to use magic
  long  EffectChance;       // Chance of attack effect occuring
  long  Effects;            // Bit flags of attack effects
} sCharacterDefinition;

typedef struct sItem
{
	int ID;
	int ItemDef;
	int Count;
	float xPos,yPos,zPos;
    float xRot,yRot,zRot;
	sItem *next;
	
	float radius; //for bounding sphere
	sItem(){next = NULL; radius =0 ;}
	~sItem()
	{
		if(next!=NULL)
			delete next;	
	}
	
}sItem;

// Path/Route structure
typedef struct {
  float XPos, YPos, ZPos;   // Target position
  float Direction;				// Direction to Target position
} sRoutePoint;


typedef struct sCharacter
{
  long  Definition;         // Character definition #
  long  ID;                 // ID # of character

  char  Name[50];			// Name of character
  int	MapID;				// ID # Map

  long  Type;               // PC, NPC, or MONSTER
  long  AI;                 // STAND, WANDER, etc

  BOOL  Enabled;            // Enabled flag (for updates)

  sCharacterDefinition Def; // Loaded definition
   //CInventory m_Inventory;	// Item of Character

  char ScriptFilename[MAX_PATH]; // Associated script

  long  HealthPoints;       // Current health points
  long  ManaPoints;         // Current mana points
  long  Points;				// Point to up stats
  float Charge;             // Attack charge

  long  Action;             // Current action
  float XPos, YPos, ZPos;   // Current coordinates
  float XDestPos,ZDestPos;	// Destination Position to Reach
  float Direction;          // Angle character is facing
  
  BOOL  Locked;             // Specific action lock
  long  ActionTimer;        // Lock action countdown timer

  sCharacter *Attacker;     // Attacking character (if any)
  sCharacter *Victim;       // Character to attack

  long  SpellNum;           // Spell to cast when ready
  long  SpellTarget;        // Target type of spell
  float TargetX, TargetY, TargetZ; // Spell target coords

  float Distance;           // Follow/Evade distance
  int	Delay;				// Delay time to follow
  sCharacter *TargetChar;   // Character to follow
  float MinX, MinY, MinZ;   // Min bounding coordinates
  float MaxX, MaxY, MaxZ;   // Max bounding coordiantes

  long  NumPoints;          // # points in route
  long  CurrentPoint;       // Current route point
  sRoutePoint *Route;       // Route points
  INT**	AllPath;			// All Path in Map Array
  int	MapSize;			// Map size in row or column
  char	TempArr[MAX_SHORTCAL][MAX_SHORTCAL]; // Temp For Calculate Shortest Path

  char  Message[128];       // Text message
  long  MessageTimer;       // Text message timer

  sCharacter *Prev, *Next;  // Linked list of characters

  sCharacter()
  {
    Definition = 0;         // Set to definition #0
    ID = -1;                // Set to no ID
    Type = CHAR_NPC;        // Set to NPC character
    Enabled = FALSE;        // Set to not enabled
    
	Points = 5;
	AI	= CHAR_STAND;
    Charge = 0.0f;          // Set no charge

    // Clear definition
    ZeroMemory(&Def, sizeof(sCharacterDefinition));
	ZeroMemory(Name, sizeof(Name));
	
    Action = CHAR_IDLE;     // Set default animation

    Locked = FALSE;         // Set no lock
    ActionTimer = 0;        // Set no action timer

    Attacker = NULL;        // Set no attacker
    Victim = NULL;          // Set no victim

    Distance = 0.0f;        // Set distance
    TargetChar = NULL;      // Set no target character

    // Clear bounding box (for limiting movement)
    MinX = MinY = MinZ = MaxX = MaxY = MaxZ = 0.0f;

    NumPoints = 0;          // Set no route points
    Route = (sRoutePoint*)malloc(MAX_SHORTPATH * sizeof(sRoutePoint));// Set no route
	CurrentPoint = 0;

    Message[0] = 0;         // Clear message
    MessageTimer = 0;       // Set no message timer

    Prev = Next = NULL;     // Clear linked list pointers
	
  }
	
  void FreePath()
  {
	//clear Path
	for (int i=0;i<MapSize;i++)
	  for (int j=0;j<MapSize;j++)
		  AllPath[i][j] = 0;

	for (i=0;i<MAX_SHORTPATH;i++) 
	{
		Route[i].Direction = 0;
		Route[i].XPos	  = -1;
		Route[i].YPos	  = -1;
		Route[i].ZPos	  = -1;
	}
	CurrentPoint= 0;
	NumPoints	= 0;
  }

  ~sCharacter()
  {
    delete [] Route;       // Release route
	
	//m_Inventory.Cleanup();

    delete Next;           // Delete next character in list
  }
} sCharacter;

#endif
