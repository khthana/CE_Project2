#include "CStageGame.h"

CStageGame::CStageGame()
{
	m_MapParent = NULL;
	m_MapCurrent = NULL;
	m_ItemDefParent	  = NULL;
	m_EnvDefParent = NULL;
	m_TransportParent = NULL;
	m_EnvParent = NULL;
	m_DB = NULL;
	countMap = countModelItem = countModelEnv = 0;
}
CStageGame::~CStageGame()
{
	Shutdown();
}	

BOOL CStageGame::Shutdown()
{
	Cleanup();
	m_DB = NULL;
	SAFE_DELETE(m_ItemDefParent);
	SAFE_DELETE(m_EnvDefParent);
	SAFE_DELETE(m_MapParent);
	
	return true;
}
CStageGame::Cleanup()
{
	countModelEnv = 0;
	SAFE_DELETE(m_TransportParent);
	SAFE_DELETE(m_EnvParent);

	m_Trigger.Cleanup();
	if(m_MapCurrent != NULL) {
		m_Terrain1.Cleanup();
		m_Terrain2.Cleanup();
		m_Terrain3.Cleanup();
	}
}
//----------------------------------
BOOL CStageGame::Init(CDB* DB)
{
	sMap *map,*mapPtr = NULL;
	if ((m_DB=DB)==NULL)
		return FALSE;
	
	CRecordset* res = m_DB->Query("select * from Map");
	CDBVariant dbvar;
	
	for(int i=0;i<res->GetRecordCount();i++)
	{
		map = new sMap();

		++countMap;
		if(mapPtr == NULL)
			m_MapParent = map;
		else
			mapPtr->next = map;
		mapPtr = map;

		res->GetFieldValue("MapID", dbvar);	map->id = dbvar.m_iVal;
		res->GetFieldValue("Col", dbvar);map->iCol = dbvar.m_iVal;
		res->GetFieldValue("Row", dbvar);map->iRow = dbvar.m_iVal;
		
		map->iSizeTile = 20;
		res->MoveNext();
	}
	res->Close();
	//Initial Stage is #0
	m_MapCurrent = FindMap(0);
	
	return true;
}
//------------------------------
sMap* CStageGame::FindMap(int stageId)
{
	if(stageId<0)return m_MapParent;

	sMap *mapPtr=m_MapParent;

	while(mapPtr!=NULL)
	{
		if(mapPtr->id==stageId)
			return mapPtr;
		mapPtr = mapPtr->next;
	}
	return m_MapParent;
}
//------------------------------
BOOL CStageGame::LoadStage()
{

	m_Terrain1.Create(1, 50);
	m_Terrain2.Create(2, 100);
	m_Terrain3.Create(3, 100);
	
	return true;
}

//---------------------------------

BOOL CStageGame::LoadEnvDef()
{
	sEnvDef *env,*envPtr=NULL;
	FILE *fp;
	long id;
	if((fp=fopen(".\\Script\\EnvDef.def","rb"))==NULL)
		return false;
	
	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0) break;

		env = new sEnvDef();
		if(envPtr ==NULL)
			m_EnvDefParent = env;
		else 
			envPtr->next = env;
		envPtr = env;

		env->id = id;
		fscanf(fp,"%s",env->name);
	}
	fclose(fp);
	return TRUE;
}
//*****************************************

//--------------------------------
BOOL CStageGame::LoadAllModelEnv(char* filename)
{
	m_EnvParent->~sEnvironment();

	sEnvironment *env,*envPtr=NULL;
	FILE *fp;
	long visible;
	long id;
	if((fp=fopen(filename,"rb"))==NULL)
		return FALSE;
	
	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0) break;

		env = new sEnvironment();
		if(envPtr ==NULL)
			m_EnvParent = env;
		else 
			envPtr->next = env;
		envPtr = env;

		env->id = id;
		fscanf(fp,"%s",env->name);
		fscanf(fp,"%ld",&id);env->xPos = (float)id;
		fscanf(fp,"%ld",&id);env->yPos = (float)id;
		fscanf(fp,"%ld",&id);env->zPos = (float)id;
		fscanf(fp,"%ld",&id);env->xRot = (float)id;
		fscanf(fp,"%ld",&id);env->yRot = (float)id;
		fscanf(fp,"%ld",&id);env->zRot = (float)id;
		fscanf(fp,"%ld",&id);env->xScale = (float)id;
		fscanf(fp,"%ld",&id);env->yScale = (float)id;
		fscanf(fp,"%ld",&id);env->zScale = (float)id;
		fscanf(fp,"%ld",&id);visible = id;

		if (visible) env->visible = TRUE;
		else env->visible = FALSE;
	}
	fclose(fp);
	return true;
}
//******************************************
//------------------------------
BOOL CStageGame::LoadItemDef()
{
	sItemDef *item,*itemPtr=NULL;
	FILE *fp;
	long id;
	long type;
	if((fp=fopen(".\\Script\\ItemDef.def","rb"))==NULL)
		{fclose(fp); return false;}

	while(!feof(fp))
	{
		if(fscanf(fp,"%ld",&id)<=0)return 0;

		item = new sItemDef();
		if(itemPtr ==NULL)
			m_ItemDefParent = item;
		else 
			itemPtr->next = item;
		itemPtr = item;

		item->id = id;
		fscanf(fp,"%ld",&type);
		fscanf(fp,"%s",item->name);
		fscanf(fp,"%ld",&item->damageAttack);
		fscanf(fp,"%ld",&item->damageMagic);
		fscanf(fp,"%ld",&item->defense);
		fscanf(fp,"%ld",&item->increaseHP);
		fscanf(fp,"%ld",&item->increaseMP);
		fscanf(fp,"%ld",&item->manaWant);
		fscanf(fp,"%ld",&item->price);
		
		item->eTypeItem = (TypeItem)type;
	}
	fclose(fp);
	return TRUE;
}
//---------------------------------
BOOL CStageGame::LoadAllModelItem()
{
	return TRUE;
}
//---------------------------------
sItemDef* CStageGame::FindItemDef(int idDef)
{
	sItemDef *ItemDef = m_ItemDefParent;
	while(ItemDef != NULL)
	{
		if(ItemDef->id==idDef)
			return ItemDef;
		ItemDef = ItemDef->next;
	}
	return m_ItemDefParent;
}
//---------------------------------
void CStageGame::GetItemDef(sItemDef &itemDef,int idDef)
{
	sItemDef *ItemDef = FindItemDef(idDef);
	itemDef.id = ItemDef->id;
	itemDef.eTypeItem = ItemDef->eTypeItem;	
	itemDef.damageAttack = ItemDef->damageAttack;
	itemDef.damageMagic  = ItemDef->damageMagic;
	itemDef.damageMagic  = ItemDef->defense;
	itemDef.increaseHP   = ItemDef->increaseHP;
	itemDef.increaseMP   = ItemDef->increaseMP;
	itemDef.manaWant     = ItemDef->manaWant;
	itemDef.price		 = ItemDef->price;
	strcpy(itemDef.name,ItemDef->name);

}
//---------------------------------
sEnvDef* CStageGame::FindEnvDef(int idDef)
{
	sEnvDef *envDef = m_EnvDefParent;
	while(envDef != NULL)
	{
		if(envDef->id==idDef)
			return envDef;
		envDef = envDef->next;
	}
	return m_EnvDefParent;
}

//---------------------------------
void CStageGame::GetEnvDef(sEnvDef& envDef,int idDef)
{
	sEnvDef *EnvDef = FindEnvDef(idDef);
	envDef.id = EnvDef->id;
	strcpy(envDef.name,EnvDef->name);
}

//***********************************
BOOL CStageGame::AddTransport(sTransport* transportPtr)
{
	sTransport* ptr = m_TransportParent;
	if(m_TransportParent == NULL)
	{
		m_TransportParent = transportPtr;
		ptr = m_TransportParent;
	}
	else
	{		
		while(ptr!=NULL)
		{
			if(ptr->id == transportPtr->id)
			{
				m_Trigger.AddSphere(transportPtr->id,transportPtr->enable,
									transportPtr->xPos,
									transportPtr->yPos,
									transportPtr->zPos,
									20);
				return true;
			}
			else if(ptr->next==NULL)
			{	
				ptr->next = transportPtr;
				ptr = ptr->next;
				break;
			}
			ptr = ptr->next;
		}
	}
	ptr->onMap = m_MapCurrent->id;
	m_Trigger.AddSphere(transportPtr->id,transportPtr->enable,
									transportPtr->xPos,
									transportPtr->yPos,
									transportPtr->zPos,
									20);
	return true;
}
//-------------------------------------
BOOL CStageGame::AddEnvironment(sEnvironment* envPtr)
{
	sEnvDef envdef;

	countModelEnv++;

	if(m_EnvParent == NULL)
		m_EnvParent = envPtr;
	else
	{
		sEnvironment* ptr = m_EnvParent;
		while(ptr!=NULL)
		{
			if(ptr->next==NULL)
			{

				ptr->next = envPtr;
				envPtr->next = NULL;
				break;
			}
			ptr = ptr->next;
		}
	}
	return true;
}
//*************************************
sTransport* CStageGame::GetTransport(int id)
{
	sTransport* warpPtr = m_TransportParent;
		while(warpPtr!=NULL)
		{
			if(warpPtr->id == id)
				return warpPtr;
			warpPtr = warpPtr->next;
		}
		return NULL;
}
int CStageGame::IsTriggTransport(float xPos,float yPos,float zPos)
{
	int id =  m_Trigger.GetTrigger(xPos,yPos,zPos);
	if(id==-1)return -1;	
	
	sTransport* warpPtr = GetTransport(id);
	if(warpPtr==NULL)return -1;			
			if(warpPtr->enable)
				return id;
			else return -1;
	return -1;

}