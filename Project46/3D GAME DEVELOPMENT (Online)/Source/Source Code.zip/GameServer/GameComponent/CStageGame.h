#ifndef _CSTAGEGAME_H_
#define _CSTAGEGAME_H_

#include "HGlobal.h"
#include "CLandscape.h"
#include "CTrigger.h"

#define MAX_EVENT 10
#define MAX_CHAR  128
#define MAX_ITEM_MODEL 20
#define MAX_ENV_MODEL 20

typedef struct sMap
{
	long id; //#id of map 
/*	char fileTerrain[256];  //name of X file
	char fileTexture[256]; //texture of map
	char fileMinimap[256];  //name of X file
	char fileSkybox[256]; // texture of skybox
	char fileEnv[256];		//name of environment file which keep name of many model in map 
	char fileTransport[256]; //Keep position waypoint of map 
	char fileInventory[256];//keep all item on map
	char fileEvent[256];	//all event on map(position,event type,..)*/
	int iRow;//will use for HEIGHTMAP type map
	int iCol;
	int iSizeTile;
	sMap *next;
	sMap(){next = NULL;}
	~sMap(){}
}sMap;
/*typedef struct sModel
{
	long id;
	char fileMesh[64];
	char fileTexture[64];

	CMesh	m_Mesh;
	CObject m_Object;

	void Cleanup(){
		m_Mesh.Cleanup();
		m_Object.Cleanup();
	}

	~sModel()
	{
		Cleanup();	
	}
}sModel;
*/
typedef struct sItemDef
{
	int id;
	
	TypeItem eTypeItem;
	char name[64];
	long damageAttack;
	long damageMagic;
	long defense;
	long increaseHP;
	long increaseMP;
	long manaWant;
	long price;
	
	/*char  fileMesh[64];
	char  fileTexture[64];
	char  ScriptFilename[64];  // .mls script filename
	char  ImageFilename[64];   // .bmp image filename
*/
	sItemDef *next;
	sItemDef(){
		next = NULL;
	}
	~sItemDef(){
	}
}sItemDef;

typedef struct sEnvDef
{
	long id;

	char name[64];	

	/*char  fileMesh[64];
	char  fileTexture[64];
	char  ScriptFilename[64];  // .mls script filename
	char  ImageFilename[64];   // .bmp image filename
*/
	sEnvDef *next;
	sEnvDef() {next = NULL;}
	~sEnvDef(){	}
}sEnvDef;

typedef struct sEnvironment
{
	long id;
	char name[128];
	float xPos,yPos,zPos;
	float xRot,yRot,zRot;
	float xScale,yScale,zScale;
	BOOL visible;

	//sModel m_ModelEnv;
	
	sEnvironment* next;
	
	sEnvironment(){
		next =NULL;
	}
	~sEnvironment(){
		//m_ModelEnv.Cleanup();
	}

}sEnvironment;

typedef struct sTransport
{
	long id;
	char name[32];
	float xPos,yPos,zPos;
	int stageId;
	BOOL enable;

	long onMap;
	float yRot;

	sTransport* next;
	
	sTransport()
	{
		next = NULL;
		yRot = 0;
	}
	~sTransport(){}
}sTransport;

class CStageGame
{
private:
	int countMap;
	int countModelItem;
	int countModelEnv;
	sMap       *m_MapParent;
	sMap       *m_MapCurrent;
	sItemDef   *m_ItemDefParent;
	sEnvDef	   *m_EnvDefParent;
	sTransport *m_TransportParent;
	
	CDB*		m_DB;
	CTrigger	m_Trigger;
	CLandscape  m_Terrain1;
	CLandscape  m_Terrain2;
	CLandscape  m_Terrain3;
	
	sEnvironment *m_EnvParent;
	
public:
	CStageGame();
	~CStageGame();
	BOOL Shutdown();
	Cleanup();
	
	BOOL Init(CDB* DB);
	BOOL LoadStage();
	BOOL LoadEnvDef();
	BOOL LoadAllModelEnv(char* filename);
	BOOL LoadItemDef();
	BOOL LoadAllModelItem();
	BOOL AddTransport(sTransport*);
	BOOL AddEnvironment(sEnvironment*);
	BOOL CheckBarrier(float xPos,float yPos,float zPos);

	CLandscape* GetTerrain(int id){
		if (id==1) return &m_Terrain1;
		else if(id==2) return &m_Terrain2;
		else return &m_Terrain3;
	}
	sItemDef  *FindItemDef(int idDef);
	sEnvDef   *FindEnvDef(int idDef);
	void      GetItemDef(sItemDef& itemDef,int idDef);
	void      GetEnvDef(sEnvDef& envDef,int idDef);
	long	  GetIdMapCurrent(){return m_MapCurrent->id;}	
	
	sTransport* GetTransport(int id);
	CTrigger*   GetObjTrigger(){return &m_Trigger;} 
	
	TypeEvent	CheckTypeEvent(int id);
	int			IsTriggTransport(float x,float y,float z);
	sMap		*FindMap(int stageId);
};
#endif