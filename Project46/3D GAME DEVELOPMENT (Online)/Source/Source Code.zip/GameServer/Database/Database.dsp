# Microsoft Developer Studio Project File - Name="Database" - Package Owner=<29>
Begin DataProject = "Database"
   Begin DataSource = "HackerHunter (WOEN)"
      ConnectStr = "DSN=MSSqlServer;UID=hh;APP=Microsoft (R) Visual Studio;WSID=WOEN;DATABASE=HackerHunter;LANGUAGE=��;Regional=Yes"
   End
End
