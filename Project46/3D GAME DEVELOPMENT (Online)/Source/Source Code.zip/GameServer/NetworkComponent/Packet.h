#ifndef _PACKET_H
#define _PACKET_H

#define MSG_TYPE_INIT				10
#define MSG_ACTION_LOGIN			11
#define MSG_ACTION_ADDPCPLAYER		12
#define MSG_ACTION_ADDOTHERPLAYER	13
#define MSG_REQUESTMOVE				17
#define MSG_UPDATEPLAYER			18
#define MSG_CREATESPAWNPLAYER		19
#define MSG_UPDATESPAWNPLAYER		20
#define MSG_REMOVESPAWNPLAYER		21
#define MSG_PLAYERDIED				22
#define MSG_CREATEMONSTER			23
#define MSG_UPDATEMONSTER			24
#define MSG_REMOVEMONSTER			25
#define MSG_REBORNMONSTER			26
#define MSG_CHAT					27
#define MSG_ATTACK					28

typedef struct sPacket
{
	unsigned char type;
	unsigned char action;
}sPacket;

typedef struct sPacketLogin  : public sPacket
{
	//sPacket spec;
	char user[20];
	char pass[20];
}sPacketLogin;

typedef struct sPacketGetCharacter : public sPacket
{
}sPacketGetCharacter;

typedef struct sPacketReady  : public sPacket
{
}sPacketReady;

typedef struct sPacketPlayer : public sPacket {
	char name[20];
	int HP;
	int HPMAX;
	int MP;
	int MPMAX;
	long EXP;
	int Level;
	int STR;
	int VIT;
	int INT;
	int Point;
}sPacketPlayer;

typedef struct sPacketGetStatus : public sPacket {
}sPacketGetStatus;

typedef struct sPacketWalk : public sPacket
{
	unsigned int ID;
	unsigned char xpos;
	unsigned char zpos;
	unsigned char xdest;
	unsigned char zdest;
	float direction;
}sPacketWalk;

typedef struct sPacketCreateSpawnPlayer : public sPacket
{
	unsigned int ID;
	char name[20];
	unsigned char xpos;
	unsigned char zpos;
	float direction;
}sPacketCreateSpawnPlayer;

typedef struct sPacketUpdateSpawnPlayer : public sPacket
{
	unsigned int ID;
	unsigned char xpos;
	unsigned char zpos;
	float direction;

	unsigned char act;
	unsigned char ai;
	unsigned int  time;
}sPacketUpdateSpawnPlayer;

typedef struct sPacketCreateMonster : public sPacket
{
	unsigned int ID;
	unsigned char xpos;
	unsigned char zpos;
	float direction;
}sPacketCreateMonster;

typedef struct sPacketUpdateMonster : public sPacket
{
	unsigned int ID;
	unsigned char xpos;
	unsigned char zpos;
	float direction;

	unsigned char act;
	unsigned char ai;
	unsigned int  time;
}sPacketUpdateMonster;

typedef struct sPacketRemoveSpawnPlayer : public sPacket
{
	unsigned int ID;
}sPacketRemoveSpawnPlayer;

typedef struct sPacketRebornMonster : public sPacket
{
	unsigned int ID;
}sPacketRebornMonster;


typedef struct sPacketToChar : public sPacket
{
	unsigned int IDAttacker;
	unsigned int IDVictim;
}sPacketToChar;

typedef struct sPacketMessage : public sPacket
{
	unsigned int ID;
	D3DCOLOR color;
	long timer;
	char text[50];
}sPacketMessage;

typedef struct sPacketChat : public sPacket
{
	unsigned int ID;
	char name[20];
	char msg[128];
}sPacketChat;

////////////////////////  Function  ///////////////////////

static void SetPacketLogin(sPacketLogin &pk,unsigned char type,	unsigned char action,\
			char* user, char* pass)
{
	ZeroMemory(&pk,sizeof(sPacketLogin));
	pk.type = type;
	pk.action = action;
	strcpy(pk.user,user);
	strcpy(pk.pass,pass);
}

static void SetPacketCreateSpawnPlayer(sPacketCreateSpawnPlayer &pk,unsigned char type, unsigned char action,\
	  	    unsigned int id, char* name, unsigned char xpos, unsigned char zpos, float direction)
{
	ZeroMemory(&pk,sizeof(sPacketCreateSpawnPlayer));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
	strcpy(pk.name,name);
	pk.xpos = xpos;
	pk.zpos = zpos;
	pk.direction = direction;	
}

static void SetPacketUpdateSpawnPlayer(sPacketUpdateSpawnPlayer &pk,unsigned char type,	unsigned char action,\
	  	    unsigned int id, unsigned char xpos, unsigned char zpos, float direction,	\
			unsigned char act, unsigned char ai, unsigned int time)
{
	ZeroMemory(&pk,sizeof(sPacketUpdateSpawnPlayer));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
	pk.xpos = xpos;
	pk.zpos = zpos;
	pk.direction = direction;

	pk.act = act;
	pk.ai = ai;
	pk.time = time;
}

static void SetPacketCreateMonster(sPacketCreateMonster &pk,unsigned char type,	unsigned char action,\
	  	    unsigned int id, unsigned char xpos, unsigned char zpos, float direction)
{
	ZeroMemory(&pk,sizeof(sPacketCreateMonster));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
	pk.xpos = xpos;
	pk.zpos = zpos;
	pk.direction = direction;	
}

static void SetPacketUpdateMonster(sPacketUpdateMonster &pk,unsigned char type,	unsigned char action,\
	  	    unsigned int id, unsigned char xpos, unsigned char zpos, float direction,	\
			unsigned char act, unsigned char ai, unsigned int time)
{
	ZeroMemory(&pk,sizeof(sPacketUpdateMonster));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
	pk.xpos = xpos;
	pk.zpos = zpos;
	pk.direction = direction;

	pk.act = act;
	pk.ai = ai;
	pk.time = time;
}

static void SetPacketRemoveSpawnPlayer(sPacketRemoveSpawnPlayer &pk,unsigned char type,	unsigned char action,\
	  	    unsigned int id)
{
	ZeroMemory(&pk,sizeof(sPacketRemoveSpawnPlayer));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
}

static void SetPacketToChar(sPacketToChar &pk,unsigned char type,unsigned char action,\
	  	    unsigned int IDAttacker,unsigned int IDVictim)
{
	ZeroMemory(&pk,sizeof(sPacketToChar));
	pk.type = type;
	pk.action = action;
	pk.IDAttacker = IDAttacker;
	pk.IDVictim = IDVictim;
}

static void SetPacketWalk(sPacketWalk &pk,unsigned char type, unsigned char action,\
	  	    unsigned int id, unsigned char xpos, unsigned char zpos,	\
			unsigned char xdest, unsigned char zdest, float direction)
{
	ZeroMemory(&pk,sizeof(sPacketWalk));
	pk.type = type;
	pk.action = action;
	pk.ID = id;
	pk.xpos = xpos;
	pk.zpos = zpos;
	pk.xdest = xdest;
	pk.zdest = zdest;
	pk.direction = direction;
}

static void SetPacketMessage(sPacketMessage &pk,unsigned char type,unsigned char action,\
	  	    unsigned int ID,D3DCOLOR color,long timer,char* text)
{
	ZeroMemory(&pk,sizeof(sPacketMessage));
	pk.type = type;
	pk.action = action;
	pk.ID = ID;
	pk.color = color;
	pk.timer = timer;
	strcpy(pk.text,text);
}

static void SetPacketChat(sPacketChat &pk,unsigned char type,unsigned char action,\
	  	    unsigned int ID,char* name,char* msg)
{
	ZeroMemory(&pk,sizeof(sPacketChat));
	pk.type = type;
	pk.action = action;
	pk.ID = ID;
	strcpy(pk.name,name);
	strcpy(pk.msg,msg);
}

static void SetPacketPlayer(sPacketPlayer &pk,unsigned char type,unsigned char action,\
	  	    char* name,int HP,int HPMAX,int MP,int MPMAX, long EXP,int Level,int STR,\
			int VIT,int INT,int Point)
{
	ZeroMemory(&pk,sizeof(sPacketPlayer));
	pk.type = type;
	pk.action = action;
	strcpy(pk.name,name);
	pk.HP = HP;
	pk.HPMAX = HPMAX;
	pk.MP = MP;
	pk.MPMAX = MPMAX;
	pk.EXP = EXP;
	pk.Level = Level;
	pk.STR = STR;
	pk.VIT = VIT;
	pk.INT = INT;
	pk.Point = Point;
}
#endif