
#include "HGlobal.h"
#include "WinMain.h"

LRESULT CALLBACK CApplication::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg) 
	{
		case WM_CREATE:										// This message is sent when the window is created.
			
			break;
		case WM_SIZE:										// This Message happens when we resize the window.
	
			break;
		case WM_PAINT:										// This message is sent to the WndProc when the window needs to be repainted.  This might be if we moved the window, resized it, or maximized it, or another window was over it.
			
		    break;
		/*case WM_KEYUP:
            if (wParam == VK_ESCAPE)
            {
                DestroyWindow(hWnd);
				return 0;
            }
			break;*/
		case WM_DESTROY:									// This message is sent when the user closes the window.
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

CApplication::CApplication()
{
	g_pApplication = this;
	// Get the instance handle
	m_hInst = GetModuleHandle(NULL);		

	// Set default window style, position, width, height
	m_XPos   = 0;
	m_YPos   = 0;
	m_Width  = 256;
	m_Height = 256;

	strcpy(m_Class, "MyClass");
	strcpy(m_Caption, "Hacker Hunter");
	m_Style = WS_OVERLAPPEDWINDOW;
	
	// Set Window 
	m_wndclass.cbSize        = sizeof(WNDCLASSEX);
	m_wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	m_wndclass.lpfnWndProc   = MsgWinProc;
	m_wndclass.cbClsExtra    = 0;
	m_wndclass.cbWndExtra    = 0;
	m_wndclass.hInstance     = m_hInst;
	m_wndclass.hIcon         = LoadIcon(NULL,IDI_APPLICATION);
	m_wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
	m_wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH);
	m_wndclass.lpszMenuName  = NULL;
	m_wndclass.lpszClassName = m_Class;
	m_wndclass.hIconSm       = LoadIcon(NULL,IDI_WINLOGO);

	// Init Frame Calculate
	dwFrameCount = 0;

}

BOOL CApplication::CreateWindowed(char* title, DWORD width, DWORD height,DWORD style)
{
	// Set a default window class and caption
	strcpy(m_Caption, title);
	m_Width = width;
	m_Height = height;
	m_Style = style;
	
	// Set Window Variables
	m_wndclass.style         = CS_CLASSDC;

	return TRUE;
}

BOOL CApplication::Run()
{
	// Register window class
	if(!RegisterClassEx(&m_wndclass))
	{
		MsgError("Can't RegisterClassEx !!");
		return FALSE;
	}
	// Create the Main Window
	m_hWnd = CreateWindowEx(NULL,m_Class, m_Caption,
			m_Style, 
			m_XPos, m_YPos,
			m_Width, m_Height,
			NULL, NULL, m_hInst, NULL);
	if(!m_hWnd)
	{
		MsgError("Can't Create Window !!");
		return FALSE;
	}
	
	// Show and update the window
	ShowWindow(m_hWnd, SW_NORMAL);
	UpdateWindow(m_hWnd);

	// Make sure client area is correct size
	Resize(m_Width, m_Height);

	// Initialize COM
	CoInitialize(NULL);
	
	dwLastTickCount = GetTickCount();

	MSG Msg;
	if(Init() == TRUE)
	{
		// Enter the message pump
		ZeroMemory(&Msg, sizeof(MSG));
		while(Msg.message != WM_QUIT) 
		{
			// Handle Windows messages (if any)
			if(PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE)) 
			{
				if(!IsDialogMessage(m_hWnd, &Msg ))
				{
					TranslateMessage(&Msg);
					DispatchMessage(&Msg);
				}

			} else 
			{
				// Do per-frame processing, break on FALSE return value
				if(Render3DEnvironment() == FALSE)
				break;
			}
		}
	}

	DestroyWindow(hDlg);

	Shutdown();

	// Shutdown COM
	CoUninitialize();

	// Unregister the window class
	UnregisterClass(m_Class, m_hInst);

	return TRUE;
}

BOOL CApplication::Move(DWORD XPos, DWORD YPos)
{
  RECT ClientRect;

  GetClientRect(m_hWnd, &ClientRect);
  MoveWindow(m_hWnd, XPos, YPos, ClientRect.right, ClientRect.bottom, TRUE);

  return TRUE;
}

BOOL CApplication::Resize(DWORD Width, DWORD Height)
{
  RECT WndRect, ClientRect;
  long WndWidth, WndHeight;

  GetWindowRect(m_hWnd, &WndRect);
  GetClientRect(m_hWnd, &ClientRect);

  WndWidth  = (WndRect.right  - (ClientRect.right  - Width))  - WndRect.left;
  WndHeight = (WndRect.bottom - (ClientRect.bottom - Height)) - WndRect.top;

  MoveWindow(m_hWnd, WndRect.left, WndRect.top, WndWidth, WndHeight, TRUE);

  return TRUE;
}

BOOL CApplication::ShowMouse(BOOL Show)
{
  ShowCursor(Show);
  return TRUE;
}

BOOL CApplication::Render3DEnvironment()
{

	if (Frame() == FALSE)
		return FALSE;
	//Calcurate Frame Rate
	
	if (abs(GetTickCount() - dwLastTickCount) >= 1000)
	{
		dwLastTickCount = GetTickCount();
		iFrameRate = dwFrameCount;
		dwFrameCount = 0;
	}
	return TRUE;
}

CStateManager::CStateManager() 
{ 
  m_StateParent = NULL; 
}

CStateManager::~CStateManager() 
{
  PopAll();
}

// Push a function on to the stack
void CStateManager::Push(void (*Function)(void *Ptr, long Purpose), void *DataPtr)
{
  sState *StatePtr;

  // Don't push a NULL value
  if(Function != NULL) {
    // Allocate a new state and push it on stack
    StatePtr = new sState();

    StatePtr->Function = Function;
    StatePtr->Next = m_StateParent;

    m_StateParent = StatePtr;

    // Call state with init purpose
    StatePtr->Function(DataPtr, INITPURPOSE);
  }
}

BOOL CStateManager::Pop(void *DataPtr)
{
  sState *StatePtr;

  // Remove the head of stack (if any)
  if((StatePtr = m_StateParent) != NULL) {
    // First call with shutdown purpose
    m_StateParent->Function(DataPtr, SHUTDOWNPURPOSE);

    m_StateParent = StatePtr->Next;
    StatePtr->Next = NULL;
    delete StatePtr;
  }

  // return TRUE if more states exist, FALSE otherwise
  if(m_StateParent == NULL)
    return FALSE;
  return TRUE;
}

void CStateManager::PopAll(void *DataPtr)
{
  while(Pop(DataPtr) == TRUE);
}

BOOL CStateManager::Process(void *DataPtr)
{ 
  // return an error if no more states
  if(m_StateParent == NULL)
    return FALSE;

  // Process the top-most state
  m_StateParent->Function(DataPtr, FRAMEPURPOSE); 

  return TRUE;
}

CProcessManager::CProcessManager() 
{ 
  m_ProcessParent = NULL; 
}

CProcessManager::~CProcessManager() 
{
  // Pop each process
  while(Pop()==TRUE);
}

// Push a function on to the stack
void CProcessManager::Push(void (*Process)(void *Ptr, long Purpose), void *DataPtr)
{
  // Don't push a NULL value
  if(Process != NULL) {
    // Allocate a new process and push it on stack
    sProcess *ProcessPtr = new sProcess();
    ProcessPtr->Function = Process;
    ProcessPtr->Next = m_ProcessParent;
    m_ProcessParent = ProcessPtr;

    // Call process with init purpose
    ProcessPtr->Function(DataPtr, INITPURPOSE);
  }
}

// Pop top process from stack
BOOL CProcessManager::Pop(void *DataPtr)
{
  sProcess *ProcessPtr;

  // Remove the head of stack (if any)
  if((ProcessPtr = m_ProcessParent) != NULL) {
    // First call with shutdown purpose
    m_ProcessParent->Function(DataPtr, SHUTDOWNPURPOSE);

    m_ProcessParent = ProcessPtr->Next;
    ProcessPtr->Next = NULL;
    delete ProcessPtr;
  }

  // return TRUE if more processes exist, FALSE otherwise
  if(m_ProcessParent == NULL)
    return FALSE;
  return TRUE;
}

void CProcessManager::PopAll(void *DataPtr)
{
  while(Pop(DataPtr) == TRUE);
}

// Process all functions
void CProcessManager::Process(void *DataPtr)
{ 
  sProcess *ProcessPtr = m_ProcessParent;

  while(ProcessPtr != NULL) {
    ProcessPtr->Function(DataPtr, FRAMEPURPOSE);
    ProcessPtr = ProcessPtr->Next;
  }
}
