
#ifndef _HGLOBAL_H
#define _HGLOBAL_H

// Windows includes
#include <afxwin.h>
#include <afxdb.h>
#include <mmsystem.h>
#include <fstream.h>

// Standard ANSI-C includes
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Winsock
#pragma comment(lib,"ws2_32.lib")
#include <winsock2.h>

// DirectX includes
#include "d3d8.h"
#include "d3dx8.h"
#include "dmusici.h"
#include "dsound.h"
#include "dplay8.h"
#include "dpaddr.h"
#include "D3d8types.h"
#include "D3dx8math.h"
#include "d3dx8tex.h"

//External includes
#include "CDB.h"

// Define Library 
#pragma comment(lib,"d3d8.lib")
#pragma comment(lib,"d3dx8.lib")
#pragma comment(lib,"dinput8.lib")
#pragma comment(lib,"dxguid.lib")
#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"dxerr8.lib")
#pragma comment(lib,"d3dxof.lib")
#pragma comment(lib,"winmm.lib")

// Macro Define
#define MsgError(x) MessageBox(NULL, x, "Error", MB_OK | MB_ICONEXCLAMATION);
#define ReleaseCOM(x) if(x) { x->Release(); x = NULL; }
#define SAFE_DELETE(x)       { if(x!=NULL) { delete (x);     (x)=NULL; } }
#define SAFE_DELETE_ARRAY(x) { if(x!=NULL) { delete[] (x);   (x)=NULL; } }
#define SAFE_RELEASE(x)      { if(x!=NULL) { (x)->Release(); (x)=NULL; } }

// Enumerated Game Type
enum TypeTrick{TRICKED=0,UNTRICK};
enum Stage{Start=0,OnGame,Continue,GameOver,Quit};
//***********************
enum TypeItem{HEALING=0,WEAPON,ARMOR,MAGIC,GOLD};
enum TypeEvent{SPEAK=0,ATTACK,GIVEITEM,NOEVENT};
enum ActionStart{NORMAL=0,RAND_START};
enum SelectAction{SEL_ATTACK=0,SEL_FIRE,SEL_FIREWALL,SEL_BOMB,\
					SEL_ITEM,SEL_FULL_HP,SEL_FULL_MP,NO_SEL};
//used to identify an animation

// Engin includes
#include "Engin_Application.h"
#include "Packet.h"

static HWND	hDlg;
static HANDLE mutexHandle;
static FD_SET clientSet;
// Set Action List or Connection List
BOOL SetListConnection(char* msg);
BOOL DelListConnection(char* msg);
BOOL SetListAction(char* msg);

#endif

