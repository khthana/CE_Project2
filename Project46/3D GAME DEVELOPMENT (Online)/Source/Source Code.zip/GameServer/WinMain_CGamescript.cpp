#include "HGlobal.h"

#include "WinMain.h"
#include "fstream.h"

#define SCRIPT_ELSE 3
#define SCRIPT_ENDIF 4
///////////////////////////////////////////////////////////
// Overloaded script class functions
///////////////////////////////////////////////////////////
CGameScript::CGameScript()
{
  MapID = 0;
  m_App = NULL;
  for(int i=0;i<256;i++)
    m_Flags[i] = FALSE;
  m_Route = NULL;
}

CGameScript::~CGameScript()
{
   delete [] m_Route;
}

BOOL CGameScript::SetData(CGame *Application)
{
  long i;

  if((m_App = Application) == NULL)
    return FALSE;

  // Clear flags
  for(i=0;i<256;i++)
    m_Flags[i] = FALSE;

  return TRUE;
}

BOOL CGameScript::Prepare()
{
  return TRUE;
}

BOOL CGameScript::Release()
{
  delete [] m_Route;
  m_Route = NULL;
  m_NumRoutePoints = 0;

  return TRUE;
}

sScript *CGameScript::Process(sScript *Script)
{
  switch(Script->Type) {
    case  0: return Script_End(Script);
    case  1: return Script_IfFlagThen(Script);
	case  2: return Script_IfHaveItem(Script);
    case  3: return Script_Else(Script);
    case  4: return Script_EndIf(Script);
    case  5: return Script_SetFlag(Script);
    case  6: return Script_Message(Script);
	case  7: return Script_CharMessage(Script);
	case  8: return Script_CharQuestionMessage(Script);
    case  9: return Script_AddChar(Script);
	case 10: return Script_AddModel(Script);
    case 11: return Script_RemoveChar(Script);
    case 12: return Script_CharType(Script);
    case 13: return Script_CharAI(Script);
    case 14: return Script_CharDistance(Script);
    case 15: return Script_CharBounds(Script);
    case 16: return Script_TargetChar(Script);
    case 17: return Script_NoTarget(Script);
    case 18: return Script_CreateRoute(Script);
    case 19: return Script_AddPoint(Script);
    case 20: return Script_AssignRoute(Script);
    case 21: return Script_MoveChar(Script);
    case 22: return Script_CharScript(Script);
	case 23: return Script_SetTransport(Script);
	case 24: return Script_EnableTransport(Script);
	case 25: return Script_LoadStage(Script);
	case 26: return Script_LoadListModel_Env(Script);
	case 27: return Script_LoadItemToChar(Script);
	case 28: return Script_PlayMusicMidi(Script);
	case 29:		Script_EndGame(Script); break;
	case 30: return Script_Addexp(Script);
	case 31: return Script_IfCharhaveExp(Script);
 }

  return NULL; // Error executing
}

///////////////////////////////////////////////////////////
// Standard script processing functions
///////////////////////////////////////////////////////////
sScript *CGameScript::Script_End(sScript *ScriptPtr)
{
  return NULL;  // Force end of processing
}

sScript *CGameScript::Script_IfFlagThen(sScript *ScriptPtr)
{
  BOOL Skipping;

  // See if a flag matches second entry
  if(m_Flags[ScriptPtr->Entries[0].lValue % 256] ==           \
             ScriptPtr->Entries[1].bValue)
    Skipping = FALSE;
  else 
    Skipping = TRUE;

  // At this point, Skipping states if the script actions
  // need to be skipped due to a conditional if..then statement.
  // Actions are further processed if skipped = FALSE, looking
  // for an else to flip the skip mode, or an endif to end
  // the conditional block.

  // Go to next action to process
  ScriptPtr = ScriptPtr->Next;

  while(ScriptPtr != NULL) {
    // if else, flip skip mode
    if(ScriptPtr->Type == SCRIPT_ELSE)
      Skipping = (Skipping == TRUE) ? FALSE : TRUE;

    // break on end if
    if(ScriptPtr->Type == SCRIPT_ENDIF)
      return ScriptPtr->Next;

    // Process script function in conditional block
    // making sure to skip actions when condition not met.
    if(Skipping == TRUE)
      ScriptPtr = ScriptPtr->Next;
    else {
      if((ScriptPtr = Process(ScriptPtr)) == NULL)
        return NULL;
    }
  }

  return NULL; // End of script reached
}

sScript *CGameScript::Script_IfHaveItem(sScript* ScriptPtr)
{
/*	BOOL skip=true;
	int charId = ScriptPtr->Entries[0].IOValue;
	int itemId = ScriptPtr->Entries[1].IOValue;
	
	sCharacter *charPtr = m_App->m_CharController.GetCharacter(charId);
	sItem* Item = charPtr->m_Inventory.FindItemDef(itemId);
	if(Item!=NULL)
	if(Item->Count==0)
		skip = true;
	else 
		skip = false;
	

  // Go to next action to process
  ScriptPtr = ScriptPtr->Next;

  while(ScriptPtr != NULL) {

    // if else, flip skip mode
    if(ScriptPtr->Type == SCRIPT_ELSE)
      skip = (skip == TRUE) ? FALSE : TRUE;

    // break on end if
    if(ScriptPtr->Type == SCRIPT_ENDIF)
      return ScriptPtr->Next;

    // Process script function in conditional block
    // making sure to skip actions when condition not met.
    if(skip == TRUE)
      ScriptPtr = ScriptPtr->Next;
    else {   
      if((ScriptPtr = Process(ScriptPtr)) == NULL)
        return NULL;
    }
  }
*/
  return NULL; // End of script reached
}

sScript *CGameScript::Script_Else(sScript *ScriptPtr)
{
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_EndIf(sScript *ScriptPtr)
{
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_SetFlag(sScript *ScriptPtr)
{
  // Set boolean value
  m_Flags[ScriptPtr->Entries[0].lValue % 256] =               \
          ScriptPtr->Entries[1].bValue;

  return ScriptPtr->Next;
}

///////////////////////////////////////////////////////////
// Specialized script processing functions
///////////////////////////////////////////////////////////
sScript *CGameScript::Script_Message(sScript *ScriptPtr)
{
	SetListAction(ScriptPtr->Entries[0].Text);
   /*char speech[128];
	
	sprintf(speech,"%s",ScriptPtr->Entries[0].Text);
	m_Window.CreateDlg();
	m_Window.SetText(speech,0xffff7f00);

	//*********** Render Window Dialog **************				
		m_App->Graphic.BeginScene();
									
		m_Window.MoveDialog(40,50,350,400);
		m_Window.RenderDialog("");

		m_App->Graphic.EndScene();
		m_App->Graphic.Display();

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
	
	//****** End Dialog by click mouse	************
		while(m_App->m_Mouse.GetButtonState(MOUSE_LBUTTON)==FALSE)
		{
			m_App->m_Mouse.Read();
		}

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
*/
		return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharMessage(sScript *ScriptPtr)
{
	SetListAction(ScriptPtr->Entries[0].Text);
	/*char speech[128];
    sCharacter *CharPtr;
	CharPtr = m_CharController->GetCharacter(                   \
                                ScriptPtr->Entries[1].lValue);
    	
	sprintf(speech,"%s",ScriptPtr->Entries[0].Text);
	m_Window.CreateDlg();
	m_Window.CreatePicture(&m_App->Graphic,CharPtr->Name);
	m_Window.SetText(speech);

	//*********** Render Window Dialog **************				
		m_App->Graphic.BeginScene();
									
		m_Window.MoveDialog(40,50,350,400);
		m_Window.MovePicture(430,200,300,320);
		m_Window.RenderDialog(CharPtr->Name);
		m_Window.RenderPicture();
		
		m_App->Graphic.EndScene();
		m_App->Graphic.Display();

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
	//****** End Dialog by click mouse	************
		while(m_App->m_Mouse.GetButtonState(MOUSE_LBUTTON)==FALSE)
		{
			m_App->m_Mouse.Read();
		}

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
	*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharQuestionMessage(sScript *ScriptPtr)
{
	SetListAction(ScriptPtr->Entries[0].Text);
	/*char speech[128];
    sCharacter *CharPtr;
	CharPtr = m_CharController->GetCharacter(                   \
                                ScriptPtr->Entries[1].lValue);
    	
	sprintf(speech,"%s",ScriptPtr->Entries[0].Text);
	m_Window.CreateDlg();
	m_Window.CreatePicture(&m_App->Graphic,CharPtr->Name);
	m_Window.SetText(speech);

	//*********** Render Window Dialog **************				
		m_App->Graphic.BeginScene();
									
		m_Window.MoveDialog(40,50,350,400);
		m_Window.MovePicture(430,200,300,320);
		m_Window.MoveQuestionDlg(220,380,130,30);
		m_Window.RenderDialog(CharPtr->Name);
		m_Window.RenderQuestion();
		m_Window.RenderPicture();

		m_App->Graphic.EndScene();
		m_App->Graphic.Display();

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);

	//****** End Dialog by click mouse	************
		while(1)
		{
			m_App->m_Mouse.Read();
			
			if(m_App->m_Mouse.GetButtonState(MOUSE_LBUTTON)==TRUE)
			{
				long ptx,pty;
				//GetCursorPos(&pt);
				ptx = m_App->m_Mouse.GetXPos();
				pty = m_App->m_Mouse.GetYPos();

				if (ptx > 220 && ptx < 285 && pty > 380 && pty < 410)
				{
					m_Flags[255] =  TRUE;
					break;
				}
				if (ptx > 285 && ptx < 350 && pty > 380 && pty < 410)
				{
					m_Flags[255] =  FALSE;
					break;
				}
				else continue;
			}				
		}

		m_App->m_Mouse.SetLock(MOUSE_LBUTTON,TRUE);
*/
	return ScriptPtr->Next;
}

sScript *CGameScript::Script_AddChar(sScript *ScriptPtr)
{
  m_App->m_CharacterControl.Add(ScriptPtr->Entries[0].lValue,         \
						ScriptPtr->Entries[1].Text,
                        ScriptPtr->Entries[2].lValue,         \
                        ScriptPtr->Entries[3].Selection,      \
                        ScriptPtr->Entries[4].Selection,      \
                        ScriptPtr->Entries[5].fValue,         \
                        ScriptPtr->Entries[6].fValue,         \
                        ScriptPtr->Entries[7].fValue,         \
                        ScriptPtr->Entries[8].fValue,
						MapID);

  return ScriptPtr->Next;
}

sScript *CGameScript::Script_AddModel(sScript *ScriptPtr)
{
  /*sEnvironment *env = new sEnvironment;
  env->id   = ScriptPtr->Entries[0].IOValue;
  strcpy(env->name, ScriptPtr->Entries[1].Text);
  env->xPos = ScriptPtr->Entries[2].fValue;
  env->yPos = ScriptPtr->Entries[3].fValue;
  env->zPos = ScriptPtr->Entries[4].fValue;
  env->xRot = ScriptPtr->Entries[5].fValue;
  env->yRot = ScriptPtr->Entries[6].fValue;
  env->zRot = ScriptPtr->Entries[7].fValue;
  env->xScale = ScriptPtr->Entries[8].fValue;
  env->yScale = ScriptPtr->Entries[9].fValue;
  env->zScale = ScriptPtr->Entries[10].fValue;
  env->visible = TRUE;
  env->m_ModelEnv.id = ScriptPtr->Entries[11].IOValue;

  m_App->m_StageGame.AddEnvironment(env);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_RemoveChar(sScript *ScriptPtr)
{
 /* m_CharController->Remove(ScriptPtr->Entries[0].lValue);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharType(sScript *ScriptPtr)
{
 /* m_CharController->SetType(ScriptPtr->Entries[0].lValue,     \
                        ScriptPtr->Entries[1].Selection);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharAI(sScript *ScriptPtr)
{
  /*m_CharController->SetAI(ScriptPtr->Entries[0].lValue,       \
                      ScriptPtr->Entries[1].Selection);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharDistance(sScript *ScriptPtr)
{
 /* m_CharController->SetDistance(ScriptPtr->Entries[0].lValue, \
                            ScriptPtr->Entries[1].fValue);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharBounds(sScript *ScriptPtr)
{
  m_App->m_CharacterControl.SetBounds(ScriptPtr->Entries[0].lValue,   \
                          ScriptPtr->Entries[1].fValue,       \
                          ScriptPtr->Entries[2].fValue,       \
                          ScriptPtr->Entries[3].fValue,       \
                          ScriptPtr->Entries[4].fValue,       \
                          ScriptPtr->Entries[5].fValue,       \
                          ScriptPtr->Entries[6].fValue);

  return ScriptPtr->Next;
}

sScript *CGameScript::Script_TargetChar(sScript *ScriptPtr)
{
  /*m_CharController->SetTargetCharacter(                       \
                            ScriptPtr->Entries[0].lValue,     \
                            ScriptPtr->Entries[1].lValue);*/

  return ScriptPtr->Next;
}

sScript *CGameScript::Script_NoTarget(sScript *ScriptPtr)
{
 /* m_CharController->SetTargetCharacter(                       \
                            ScriptPtr->Entries[0].lValue, -1);*/

  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CreateRoute(sScript *ScriptPtr)
{
  // Release old route
  /*delete [] m_Route;
  m_Route = NULL;
  m_NumRoutePoints = 0;

  m_NumRoutePoints = ScriptPtr->Entries[0].lValue;
  m_Route = new sRoutePoint[m_NumRoutePoints]();
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_AddPoint(sScript *ScriptPtr)
{
 /* m_Route[ScriptPtr->Entries[0].lValue].XPos =                \
                     ScriptPtr->Entries[1].fValue;
  m_Route[ScriptPtr->Entries[0].lValue].YPos =                \
                     ScriptPtr->Entries[2].fValue;
  m_Route[ScriptPtr->Entries[0].lValue].ZPos =                \
                     ScriptPtr->Entries[3].fValue;
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_AssignRoute(sScript *ScriptPtr)
{
 /* m_CharController->SetRoute(ScriptPtr->Entries[0].lValue,    \
                    m_NumRoutePoints, (sRoutePoint*)m_Route);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_MoveChar(sScript *ScriptPtr)
{
 /* m_CharController->Move(ScriptPtr->Entries[0].lValue,        \
                     ScriptPtr->Entries[1].fValue,            \
                     ScriptPtr->Entries[2].fValue,            \
                     ScriptPtr->Entries[3].fValue);
*/
  return ScriptPtr->Next;
}

sScript *CGameScript::Script_CharScript(sScript *ScriptPtr)
{
 /* m_CharController->SetScript(ScriptPtr->Entries[0].lValue,   \
                     ScriptPtr->Entries[1].Text);
*/
  return ScriptPtr->Next;
}

sScript* CGameScript::Script_SetTransport(sScript* ScriptPtr)
{
/*	sTransport *transport = new sTransport;
	transport->id   = ScriptPtr->Entries[0].IOValue;
	strcpy(transport->name, ScriptPtr->Entries[1].Text);
	transport->xPos = ScriptPtr->Entries[2].fValue;
	transport->yPos = ScriptPtr->Entries[3].fValue;
	transport->zPos = ScriptPtr->Entries[4].fValue;
	transport->stageId = ScriptPtr->Entries[5].IOValue;
	transport->enable  = ScriptPtr->Entries[6].bValue;

	m_App->m_StageGame.AddTransport(transport);
*/	return ScriptPtr->Next;
}

sScript* CGameScript::Script_EnableTransport(sScript* scriptPtr)
{
/*	sTransport* warp = m_App->m_StageGame.GetTransport(scriptPtr->Entries[0].IOValue);
	warp->enable = scriptPtr->Entries[1].bValue;
	CTrigger* trigger = m_App->m_StageGame.GetObjTrigger();
	trigger->Enable(scriptPtr->Entries[0].IOValue,warp->enable);
*/	
	return scriptPtr->Next;
}

sScript* CGameScript::Script_LoadStage(sScript* scriptPtr)
{
/*	m_App->m_StageGame.Cleanup();
	m_App->m_CharController.Cleanup();
	m_App->m_StageGame.LoadStage(scriptPtr->Entries[0].IOValue);

*/	m_App->m_StageGame.LoadStage();
	return scriptPtr->Next;
}

sScript* CGameScript::Script_LoadListModel_Env(sScript* scriptPtr)
{
//	m_App->m_StageGame.LoadAllModelEnv(scriptPtr->Entries[0].Text);

	return scriptPtr->Next;
}

sScript* CGameScript::Script_LoadItemToChar(sScript* scriptPtr)
{
//	m_App->m_CharController.LoadItemListToChar(scriptPtr->Entries[1].IOValue,scriptPtr->Entries[0].Text);
	return scriptPtr->Next;
}

//**************************************************
sScript* CGameScript::Script_PlayMusicMidi(sScript* scriptPtr)
{
/*	m_App->m_Music.Stop();
	m_App->m_Music.Free();
	
	m_App->m_Music.Create(&m_App->m_Sound);

	m_App->m_Music.Load(scriptPtr->Entries[0].Text);
	m_App->m_Music.Play(scriptPtr->Entries[1].IOValue,0);
*/	return scriptPtr->Next;
}

//***************************************************
CGameScript::Script_EndGame(sScript* scriptPtr)
{
/*	m_App->m_StateManager.PopAll(m_App);

	m_App->m_StateManager.Push(m_App->ShowMenuGame,m_App);
*/
	return NULL;
}

sScript* CGameScript::Script_Addexp(sScript* scriptPtr)
{
/*	sCharacter* CharPtr = m_App->m_CharController.GetCharacter(scriptPtr->Entries[1].IOValue);

	CharPtr->Def.Experience += scriptPtr->Entries[0].IOValue;
*/
	return scriptPtr->Next;
}

sScript* CGameScript::Script_IfCharhaveExp(sScript* scriptPtr)
{
/*	BOOL skip = TRUE;
	sCharacter* CharPtr = m_App->m_CharController.GetCharacter(scriptPtr->Entries[0].IOValue);

	if (CharPtr->Def.Experience > scriptPtr->Entries[1].IOValue)
		skip = FALSE;
	else skip = TRUE;

	// Go to next action to process
	scriptPtr = scriptPtr->Next;

	while(scriptPtr != NULL) {

		// if else, flip skip mode
		if(scriptPtr->Type == SCRIPT_ELSE)
		  skip = (skip == TRUE) ? FALSE : TRUE;

		// break on end if
		if(scriptPtr->Type == SCRIPT_ENDIF)
		  return scriptPtr->Next;

		// Process script function in conditional block
		// making sure to skip actions when condition not met.
		if(skip == TRUE)
		  scriptPtr = scriptPtr->Next;
		else {   
		  if((scriptPtr = Process(scriptPtr)) == NULL)
			return NULL;
		}
	}
*/	return NULL; // End of script reached
}