//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script.rc
//
#define IDD_DIALOG1                     102
#define IDC_QUIT                        1004
#define IDC_ACTION                      1006
#define IDC_USER                        1007
#define IDC_STATIC2                     1008
#define IDC_CLOSE                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
