
#include "HGlobal.h"

#include "WinMain.h"
///////////////////////////////////////////////////////////
// Overloaded character controller class functions
///////////////////////////////////////////////////////////

BOOL CChars::SetData(CGame *App)
{
  if((m_App = App) == FALSE)
	return FALSE;

  SpellNum = -1;
	
  return TRUE;
}


BOOL CChars::PCUpdate(sCharacter *Character, long Elapsed,    \
                    float *XMove, float *YMove, float *ZMove)
{
	sCharacter *CharPtr;
	float SpellRadius;
	float SpellRadiusIn;
	float XDiff, YDiff, ZDiff, Dist;

	if ((CharPtr = Character) == NULL)
		return FALSE;

	float	angle = 0;
	D3DXVECTOR2 CharMapPos;
	long  Action = 0;
	float Speed;
	// If not PC, then let controller handle movement
	
	Speed = 2;//(float)Elapsed / 2000.0f * GetSpeed(Character);

	// Get the input flags
	if(m_App != NULL)
		Action = m_App->CheckInput();


	//	Wheel Mouse
	float zDelta = (float)m_App->GetMouseControl()->GetZDelta();
	if (zDelta != 0)
		m_App->GetCamera()->AddLength(zDelta*0.5f);

// Check use Item 
	// Use Item Slot 1;
	if(Action & 4)
	{
		if (CharPtr->m_Inventory.FindItem(0)->Count > 0)
		{
			CharPtr->m_Inventory.FindItem(0)->Count--;
			CharPtr->HealthPoints += 100;
			if (CharPtr->HealthPoints > CharPtr->Def.HealthPoints)
				CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
		}else CharPtr->m_Inventory.FindItem(0)->Count = 0;
	}
	// Use Item Slot 2;
	if(Action & 8)
	{
		if (CharPtr->m_Inventory.FindItem(1)->Count > 0)
		{
			CharPtr->m_Inventory.FindItem(1)->Count--;
			CharPtr->ManaPoints += 50;
			if (CharPtr->ManaPoints > CharPtr->Def.ManaPoints)
				CharPtr->ManaPoints = CharPtr->Def.ManaPoints;
		}else CharPtr->m_Inventory.FindItem(1)->Count = 0;
	}
	// Use Item Slot 3;
	if(Action & 16)
	{
		if (CharPtr->m_Inventory.FindItem(2)->Count > 0)
		{
			CharPtr->m_Inventory.FindItem(2)->Count--;
			CharPtr->HealthPoints = CharPtr->Def.HealthPoints;
			CharPtr->ManaPoints = CharPtr->Def.ManaPoints;
		}else CharPtr->m_Inventory.FindItem(2)->Count = 0;
	}

// Get spell number to cast

	// Use Boom
    if(Action & 32)
      SpellNum = 0;
    
// Click Right Mouse 
	if (Action & 2) {
		int Angle = m_App->GetMouseControl()->GetXDelta();
		m_App->GetCamera()->AddAlpha(-1*Angle);

	}
// Check input Mouse
	// Click Left Mouse
	if (Action & 1 ){

		if (!m_App->CheckMouseClickOnScreen())
		{
			CharPtr->FreePath();

			CharPtr->TargetChar = NULL;

			long id = ClickOnCharacter(m_App->GetCamera(),m_App->GetMouseControl()->GetXPos(),m_App->GetMouseControl()->GetYPos(),&m_App->m_MouseClickPos);

			if (SpellNum >= 0)
			{
				if (id != -1)
				{
					m_App->m_MouseClickPos.x = GetCharacter(id)->XPos;
					m_App->m_MouseClickPos.y = GetCharacter(id)->YPos;
					m_App->m_MouseClickPos.z = GetCharacter(id)->ZPos;
				}
				SpellRadius = m_App->m_SpellController.GetSpell(SpellNum)->Distance;
				SpellRadiusIn = m_App->m_SpellController.GetSpell(SpellNum)->Range;
				XDiff = (float)fabs(CharPtr->XPos - m_App->m_MouseClickPos.x);
				YDiff = (float)fabs(CharPtr->YPos - m_App->m_MouseClickPos.y);
				ZDiff = (float)fabs(CharPtr->ZPos - m_App->m_MouseClickPos.z);
				Dist = XDiff*XDiff+YDiff*YDiff+ZDiff*ZDiff;
				if ((Dist >= (SpellRadiusIn * SpellRadiusIn)) && (Dist <= (SpellRadius * SpellRadius)))
				{
					CharPtr->Action = CHAR_IDLE;
					CharPtr->AI = CHAR_STAND;
					CharPtr->SpellNum = SpellNum;
					CharPtr->TargetX = m_App->m_MouseClickPos.x;
					CharPtr->TargetY = m_App->m_MouseClickPos.y+25;
					CharPtr->TargetZ = m_App->m_MouseClickPos.z;
					
					XDiff = (CharPtr->TargetX - CharPtr->XPos);
					ZDiff = (CharPtr->TargetZ - CharPtr->ZPos);
					CharPtr->Direction = (float)atan2(XDiff, ZDiff);
					CharPtr->Direction = D3DXToDegree(CharPtr->Direction);
					Dist = CharPtr->Direction; Dist = float((int)Dist % 45);
					CharPtr->Direction = float((int)CharPtr->Direction-Dist);
					CharPtr->Direction = D3DXToRadian(CharPtr->Direction);
					m_App->m_CharController.SetAction(CharPtr, CHAR_SPELL);
				}
			}else 
			{
				if (id != -1)
				{
					m_App->m_MouseClickPos.x = GetCharacter(id)->XPos;
					m_App->m_MouseClickPos.y = GetCharacter(id)->YPos;
					m_App->m_MouseClickPos.z = GetCharacter(id)->ZPos;
					CharPtr->TargetChar = GetCharacter(id);
					if (CharPtr->TargetChar->Type == CHAR_MONSTER)
					{
						CharPtr->Victim = CharPtr->TargetChar;
						CharPtr->TargetChar->Attacker = CharPtr;
					}
				}else {
					CharPtr->Victim = NULL;
				}
				
				//Calculate Shortest Path
				CharMapPos		= GetStageGame()->GetTerrain()->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);
				m_App->m_DestMap= GetStageGame()->GetTerrain()->GetMapPosition(m_App->m_MouseClickPos.x,m_App->m_MouseClickPos.z);

				if (GetStageGame()->GetTerrain()->CanMove(m_App->m_DestMap.x *20, m_App->m_DestMap.y *20))
				{
				
					RoutePath(CharPtr,CharMapPos,m_App->m_DestMap);

					CharPtr->XDestPos = CharPtr->Route[CharPtr->NumPoints-1].XPos;
					CharPtr->ZDestPos = CharPtr->Route[CharPtr->NumPoints-1].ZPos;

					CharPtr->AI = CHAR_ROUTE;
				}
				else {
					CharPtr->AI = CHAR_STAND;
					CharPtr->Action = CHAR_IDLE;
				}
			}
			SpellNum = -1;
		}
	}
// Check Hero Status
	// Check LV
	if (CharPtr->MessageTimer <= 0)
	{
		long lvup = 0;
		if(lvup = CalculateHeroLV(Character->Def.Level,Character->Def.Experience))
		{
			CharPtr->Def.Level+=lvup;
			CharPtr->Points += (10*lvup);
			SetMessage(CharPtr,"LvUP !!",1000,0xfff0e119);
		}
	}

// Move Character
	switch(CharPtr->AI)
	{
		case CHAR_STAND:
		case CHAR_WANDER:
			break;

		case CHAR_ROUTE:
			if (CharPtr->NumPoints > 0)
			{
				XDiff = CharPtr->Route[CharPtr->CurrentPoint].XPos - CharPtr->XPos;
				ZDiff = CharPtr->Route[CharPtr->CurrentPoint].ZPos - CharPtr->ZPos ;

				if (fabs(CharPtr->Direction - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f || 
					fabs(CharPtr->Direction - (CharPtr->Route[CharPtr->CurrentPoint].Direction+(2*D3DX_PI))) < 0.1f ||
					fabs((CharPtr->Direction+(2*D3DX_PI)) - CharPtr->Route[CharPtr->CurrentPoint].Direction) < 0.1f)
				{
					CharPtr->Direction = CharPtr->Route[CharPtr->CurrentPoint].Direction;
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);
				}
				else 
				{
					if (CharPtr->Direction >= 2*D3DX_PI)
						CharPtr->Direction -= (2*D3DX_PI);

					float dir = CharPtr->Route[CharPtr->CurrentPoint].Direction - CharPtr->Direction;
					if (dir < 0)
						dir += 2*D3DX_PI;

					if (D3DX_PI > dir)
						CharPtr->Direction += D3DX_PI/12;
					else CharPtr->Direction -= D3DX_PI/12;	

					if (CharPtr->Direction < 0) 
						CharPtr->Direction += D3DX_PI*2;
				}

				if (fabs(XDiff) == 2 || fabs(ZDiff) == 2)
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));

					CharPtr->Route[CharPtr->CurrentPoint].XPos = -1;
					CharPtr->Route[CharPtr->CurrentPoint].ZPos = -1;
					CharPtr->CurrentPoint++;
					CharPtr->NumPoints--;
				}else 
				{
					*XMove = (float)(Speed*(XDiff/fabs((XDiff == 0?1:XDiff))));
					*ZMove = (float)(Speed*(ZDiff/fabs((ZDiff == 0?1:ZDiff))));
				}
				CharPtr->Action = CHAR_MOVE;
			}else {
				CharPtr->AI = CHAR_STAND;
				if (CharPtr->Action != CHAR_SPELL)
					CharPtr->Action = CHAR_IDLE;
			}
			break;
	}

	// Check Victim is in range?
	if (CharPtr->Victim != NULL && !CharPtr->ActionTimer)
	{
		if(CharPtr->Action == CHAR_ATTACK) 
			CharPtr->Action = CHAR_IDLE;
		if (fabs(CharPtr->XPos-CharPtr->Victim->XPos) <= 30 && fabs(CharPtr->ZPos-CharPtr->Victim->ZPos) <= 30)
		{
			CharPtr->FreePath();
			CharPtr->AI = CHAR_STAND;
			D3DXVECTOR2 PCPos = GetStageGame()->GetTerrain()->GetMapPosition(CharPtr->XPos,CharPtr->ZPos);
			D3DXVECTOR2 CharPos = GetStageGame()->GetTerrain()->GetMapPosition(CharPtr->Victim->XPos,CharPtr->Victim->ZPos);

			int x = int(PCPos.x-CharPos.x);
			int z = int(PCPos.y-CharPos.y);

			x = x/abs((x==0?1:x));	
			z = z/abs((z==0?1:z));
  
			if (x==0 && z==-1) CharPtr->Direction = 0;
			else if (x==0 && z==1) CharPtr->Direction = D3DX_PI;
			else if (x==-1 && z==0) CharPtr->Direction = D3DX_PI/2;
			else if (x==1 && z==0) CharPtr->Direction = 3*D3DX_PI/2;
			else if (x==1 && z==1) CharPtr->Direction = 5*D3DX_PI/4;
			else if (x==1 && z==-1) CharPtr->Direction = 7*D3DX_PI/4;
			else if (x==-1 && z==-1) CharPtr->Direction = D3DX_PI/4;
			else if (x==-1 && z==1) CharPtr->Direction = 3*D3DX_PI/4;

			  // Perform attack action
			if (CharPtr->Action != CHAR_ATTACK)
			{
			  SetAction(CharPtr, CHAR_ATTACK);
			}
		}
	}

	return TRUE;
}

long CChars::CalculateHeroLV(long LV, long EXP)
{
	long LVNum = 0;
		
	long EXPNextLV = CalculateNextLV(LV);	//Calculate Relationship between Exp. & LV
	
	while (EXP >= EXPNextLV){
		LVNum++;
		LV++;
		EXPNextLV = CalculateNextLV(LV);
	}

	return LVNum;
}

long CChars::CalculateNextLV(long LV)
{
	long nextlv;

	nextlv = (long)((pow(2,LV)*1000) - (pow(2,LV)*100));

	return nextlv;
}