1. create a database name "hackerhunter"
2. import from mysql to mssql server personal through ODBC
3. create user is "HH" and password is "hacker" in mssqlserver
4. set user with that database