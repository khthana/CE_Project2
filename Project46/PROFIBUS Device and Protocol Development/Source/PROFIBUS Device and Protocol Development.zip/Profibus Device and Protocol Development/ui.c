// 
// Profibus DP 
// 
#include "includes.h"
#include "fdl.h"
#include "phy.h"
#include "ddlm.h"
#include "user.h"
#include "ui.h"

/*
#define STATE_POWER_ON			1
#define STATE_WAIT_PRM			2
#define STATE_WAIT_CFG			3
#define STATE_DATA_EXCH		4
#define STATE_FREEZE					5
#define STATE_CLEAR					6
*/

char					Task_4_Data;     
OS_STK			Task_4_Stk[TASK_STK_SIZE];

extern	OS_EVENT	*	sem_printf;


extern TELEFRAM_SD2 ddlm_rx_telegram;
/*
extern INT8U DDLM_Set_Prm_ind;
extern INT8U DDLM_Chk_Cfg_ind;
extern INT8U DDLM_Data_Exchange_ind;
extern INT8U DDLM_Slave_Diag_ind;
extern INT8U DDLM_Global_Control_ind;
extern INT8U DDLM_Set_Slave_ind;
*/
extern INT8U DDLM_STATE;


//  ========================== Slave Variable  ======================= 


INT8U	DP_SLAVE_STATE;

INT8U	DP_SLAVE_Station_Address;

INT8U	DP_SLAVE_Real_Cfg_Data[DP_SLAVE_Real_Cfg_Data_len_const];
INT8U	DP_SLAVE_Output_L[DP_SLAVE_Output_L_len_const];
INT8U	DP_SLAVE_Output_D[DP_SLAVE_INPUT_D_len_const];
INT8U	DP_SLAVE_INPUT_D[DP_SLAVE_INPUT_D_len_const];
INT8U	DP_SLAVE_Periphery_Inp[DP_SLAVE_Periphery_Inp_len_const];
INT8U  Diag_Data[Length_Diag];

INT8U		DP_SLAVE_Real_Output_len;
INT16U	DP_SLAVE_Real_Ident;
INT8U		DP_SLAVE_Active_Groups;

BOOLEAN	DP_SLAVE_Real_No_Add_Chg;
BOOLEAN	DP_SLAVE_Diag_Flag;
BOOLEAN	DP_SLAVE_Sync_Not_Support;
BOOLEAN	DP_SLAVE_Sync_Support;
BOOLEAN	DP_SLAVE_Freeze_Not_Support;
BOOLEAN	DP_SLAVE_Freeze_Support;

static STD_Diag Diag;
	


//  ========================== Slave Function  ======================= 

void UI_Set_Prm_ind (INT8U Req_Add,INT8U * Prm_Data,INT8U Prm_Data_len);	// 61
void UI_Chk_Cfg_ind (INT8U Req_Add,INT8U * Cfg_Data,INT8U Cfg_Data_len  ); // 62
void UI_Data_Exchange_ind (INT8U * Outp_Data,INT8U Outp_Data_len); // 0
void UI_Slave_Diag_ind (INT8U Req_Add);	// 60
void UI_Global_Control_ind (INT8U Req_Add,INT8U Control_Command,INT8U Group_Select ); // 58
void UI_Set_Slave_ind (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg); // 55

void UI_Set_Prm_ind_state_wait_prm (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len);
void UI_Set_Prm_ind_state_wait_cfg (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len);
void UI_Set_Prm_ind_state_data_exch (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len);

void UI_Chk_Cfg_ind_state_wait_cfg (INT8U Req_Add,BOOLEAN Compare_Cfg_Data);
void UI_Chk_Cfg_ind_state_data_exch (INT8U Req_Add,BOOLEAN Compare_Cfg_Data);

void UI_Data_Exchange_ind_state_data_exch (INT8U * Outp_Data,INT8U Outp_Data_len); 

void UI_Slave_Diag_ind_state_wait_cfg (INT8U Req_Add);	
void UI_Slave_Diag_ind_state_data_exch (INT8U Req_Add);	

void UI_Global_Control_ind_state_data_exch (INT8U Req_Add,BOOLEAN Sync,BOOLEAN Unsync,BOOLEAN Reserve,INT8U Group_Select);
void UI_Global_Control_ind_state_freeze (BOOLEAN Freeze,BOOLEAN Unfreeze);
void UI_Global_Control_ind_state_clear(BOOLEAN Clear_Data);

void UI_Set_Slave_ind_state_wait_prm (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg); // 55

void Octet_Diagnostic_Data(STD_Diag *Diag);
void UI_Leave_Master (void);
void  print_user_status(void );
void ui_state_power_on (void);
void Send_Input (INT8U Module,INT8U Value);
INT8U Read_Output (INT8U Module);




void  Task_4 ()
{
	INT8U  err;

	INT8U i,j;
	DDLM_STATE = DDLM_STATE_RUN;
	DP_SLAVE_STATE = STATE_POWER_ON;
	
	while ( 1 )
	{														//											DA      SA    FC      DSAP SSAP DATA1,  2,    3,
 
		//		OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
		//		printf(" USER \n" );
		//		OSSemPost(sem_printf);											// Release semaphore               
			ui_state();

 			OSTimeDly(100);                            /* Delay 1 clock tick                                 */
    }
}

void UI_Set_Prm_ind (INT8U Req_Add,INT8U * Prm_Data,INT8U Prm_Data_len)		// 61
{	
	
	INT8U temp;
	INT8U	*Prm_temp;
	BOOLEAN Lock_Req;
	BOOLEAN Unlock_Req;
	BOOLEAN Sync_Req;
	BOOLEAN Freeze_Req;
	BOOLEAN WD_On;
	BOOLEAN Reserve;
	INT8U WD_Fact_1;
	INT8U WD_Fact_2;
	INT8U minTsdr;
	INT16U Ident_Number;
	INT8U Group_Ident;	
#ifdef ui_debug
	printf("61 UI_Set_Prm_ind \n"); 
#endif	
	memcpy(Prm_temp , Prm_Data  , Prm_Data_len ); 

	if ((*(Prm_temp + 0) & 0x80) == 0x80 )			// Bit 7 of DU_1 Lock_Req
		Lock_Req = TRUE;
	else
		Lock_Req = FALSE;

	if ((*(Prm_temp + 0) & 0x40) == 0x40 )			// Bit 6 of DU_1 Unlock_Req
		Unlock_Req = TRUE;
	else
		Unlock_Req = FALSE;

	if ((*(Prm_temp + 0) & 0x20) == 0x20 )			// Bit 5 of DU_1 Sync_Req
		Sync_Req = TRUE;
	else
		Sync_Req = FALSE;

	if ((*(Prm_temp + 0) & 0x10) == 0x10 )			// Bit 4 of DU_1 Freeze_Req
		Freeze_Req = TRUE;
	else
		Freeze_Req = FALSE;

	if ((*(Prm_temp + 0) & 0x08) == 0x08 )			// Bit 3 of DU_1 WD_On
		WD_On = TRUE;
	else
		WD_On = FALSE;

	if ((*(Prm_temp + 0) & 0x07) == 0x00 )			// Bit 2-0 of DU_1 Reserve = 0 
		Reserve = FALSE;
	else
		Reserve = TRUE;
		
	WD_Fact_1			=	*(Prm_temp + 1)	;					// DU_2 WD_Fact_1
	WD_Fact_2			=  *(Prm_temp + 2)	;					// DU_3 WD_Fact_2
	minTsdr				=	 *(Prm_temp + 3);						// DU_4 minTsdr 
	
	// DU_5 - 6 Ident_Number
	temp = *(Prm_temp + 5);
 	*(Prm_temp + 5) = *(Prm_temp + 4);
 	*(Prm_temp + 4) = temp;
 	
	memcpy(&Ident_Number,(Prm_temp + 4), sizeof(INT16U)  ); 
		
	Group_Ident			=	 *(Prm_temp + 6);						// DU_7 Group_Number
#ifdef  ui_debug
	printf("Lock_Req	= %x \n",Lock_Req) ;
	printf("Unlock_Req	= %x \n",Unlock_Req) ;
	printf("Sync_Req	= %x \n",Sync_Req) ;
	printf("Freeze_Req	= %x \n",Freeze_Req) ;
	printf("WD_On		= %x \n",WD_On) ;
	printf("Reserve		= %x \n",Reserve) ;
	printf("WD_Fact_1	= %x \n",WD_Fact_1) ;
	printf("WD_Fact_2	= %x \n",WD_Fact_2) ;
	printf("minTsdr		= %x \n",minTsdr) ;
	printf("Ident_Number	= %x \n",Ident_Number) ;
	printf("Group_Ident	= %x \n",Group_Ident) ;
#endif
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
		
		break;
		case STATE_WAIT_PRM:
			
				UI_Set_Prm_ind_state_wait_prm (Lock_Req,Unlock_Req,Sync_Req,Freeze_Req,WD_On,Reserve,WD_Fact_1,WD_Fact_2,minTsdr,Ident_Number,Group_Ident,Req_Add,Prm_Data_len);
		break;
		case STATE_WAIT_CFG:
		
				UI_Set_Prm_ind_state_wait_cfg (Lock_Req,Unlock_Req,Sync_Req,Freeze_Req,WD_On,Reserve,WD_Fact_1,WD_Fact_2,minTsdr,Ident_Number,Group_Ident,Req_Add,Prm_Data_len);
		break;
		case STATE_DATA_EXCH:
		
				UI_Set_Prm_ind_state_data_exch (Lock_Req,Unlock_Req,Sync_Req,Freeze_Req,WD_On,Reserve,WD_Fact_1,WD_Fact_2,minTsdr,Ident_Number,Group_Ident,Req_Add,Prm_Data_len);
		break;
		case STATE_FREEZE:
		
		break;
		case STATE_CLEAR:
		
		break;
	}
}

void UI_Set_Prm_ind_state_wait_prm (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len)
{
	if ((Prm_Data_len >= 7)&& !(Lock_Req) && !(Unlock_Req) )
	{
#ifdef ui_debug
		printf(" PRM1 \n") ;
#endif
		DDLM_Set_minTsdr(minTsdr);
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Ident_Number != DP_SLAVE_Real_Ident) || (WD_On) && ( (WD_Fact_1 == 0) || (WD_Fact_2 == 0) ) )
	{
#ifdef ui_debug
		printf(" PRM5 \n") ;
#endif
		Diag.Prm_Fault= TRUE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Ident_Number == DP_SLAVE_Real_Ident) &&( !(WD_On) || ( (WD_Fact_1 > 0) && (WD_Fact_2 > 0) ) )  && ( ( Freeze_Req) && (DP_SLAVE_Freeze_Not_Support) || (Sync_Req) && (DP_SLAVE_Sync_Not_Support) || (Reserve)) )
	{
#ifdef ui_debug
		printf(" PRM6 \n") ;
#endif
		Diag.Not_Supported = TRUE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Prm_Data_len >= 7) && (Lock_Req)  && !(Unlock_Req)  && (Ident_Number == DP_SLAVE_Real_Ident) && (WD_On)  && (WD_Fact_1 > 0) && (WD_Fact_2 > 0) && ( !(Freeze_Req) || (DP_SLAVE_Freeze_Support)) && ((Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" NMAS1 \n") ;
#endif
		Diag.Master_Add = Req_Add;
		Diag.WD_On = TRUE;
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_Active_Groups = Group_Ident;
		Diag.Prm_Fault = FALSE;
		Diag.Prm_Req = FALSE;
		Diag.Not_Supported = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	}
	else if ((Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Ident_Number == DP_SLAVE_Real_Ident) && !(WD_On) && (!(Freeze_Req) || (DP_SLAVE_Freeze_Support)) && (!(Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" NMAS2 \n") ;
#endif
		Diag.Master_Add = Req_Add;
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_Active_Groups = Group_Ident;
		Diag.Prm_Fault = FALSE;
		Diag.Prm_Req = FALSE;
		Diag.Not_Supported = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	}
}


void UI_Set_Prm_ind_state_wait_cfg (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len)
{
	if ((Prm_Data_len >= 7) && (Unlock_Req) && (Diag.Master_Add == Req_Add))
	{
#ifdef ui_debug
		printf(" LEAVE1 \n") ;
#endif
		Diag.Master_Add = Invalid;
		Diag.Prm_Req	= TRUE;
		Diag.WD_On = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Prm_Data_len >= 7)  && !(Unlock_Req) && (Lock_Req) && (Diag.Master_Add == Req_Add) && (Ident_Number != DP_SLAVE_Real_Ident) ||  (WD_On) && ((WD_Fact_1 == 0) || (WD_Fact_2 == 0)) )
	{
#ifdef ui_debug		
		printf(" ABORT1 \n") ;
#endif
		Diag.Prm_Fault = FALSE;
		Diag.Master_Add = Invalid;
		Diag.Prm_Req	= TRUE;
		Diag.WD_On = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Prm_Data_len >= 7) && !(Unlock_Req) && (Lock_Req) && (Diag.Master_Add == Req_Add) && (Ident_Number != DP_SLAVE_Real_Ident) && (!(WD_On) || (WD_Fact_1 > 0) && (WD_Fact_2 > 0)) && (( Freeze_Req) && (DP_SLAVE_Freeze_Not_Support) || (Sync_Req) && (DP_SLAVE_Sync_Not_Support) || (Reserve)) )
	{
#ifdef ui_debug
		printf(" ABORT2 \n") ;
#endif
		Diag.Not_Supported = TRUE;
		Diag.Master_Add = Invalid;
		Diag.Prm_Req	= TRUE;
		Diag.WD_On = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Prm_Data_len >= 7) && !(Unlock_Req) && (Lock_Req) && (Ident_Number == DP_SLAVE_Real_Ident) && (WD_On) && (WD_Fact_1 > 0) && (WD_Fact_2 > 0) && (!(Freeze_Req) || (DP_SLAVE_Freeze_Support)) && (!(Sync_Req) ||(DP_SLAVE_Sync_Support))  && !(Reserve) )
	{
#ifdef ui_debug
		printf(" XMAS1 \n") ;
#endif
		Diag.Master_Add = Req_Add;
		DP_SLAVE_Active_Groups = Group_Ident;
		DDLM_Set_minTsdr(minTsdr);
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	}
	else if ((Prm_Data_len >= 7) && !(Unlock_Req) && (Lock_Req) && (Ident_Number == DP_SLAVE_Real_Ident) && !(WD_On) && (!(Freeze_Req) || (DP_SLAVE_Freeze_Support)) && (!(Sync_Req) ||(DP_SLAVE_Sync_Support))  && !(Reserve) )
	{
#ifdef ui_debug		
		printf(" XMAS2 \n") ;
#endif
		Diag.Master_Add = Req_Add;
		Diag.WD_On = FALSE;
		DP_SLAVE_Active_Groups = Group_Ident;
		DDLM_Set_minTsdr(minTsdr);
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	}
	else if ((Prm_Data_len >= 7) && !(Unlock_Req) && !(Lock_Req))
	{
#ifdef ui_debug
		printf(" CFG3 \n") ;
#endif
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	}
}

void UI_Set_Prm_ind_state_data_exch (BOOLEAN Lock_Req, BOOLEAN Unlock_Req, BOOLEAN Sync_Req, BOOLEAN Freeze_Req, BOOLEAN WD_On, BOOLEAN Reserve, INT8U WD_Fact_1, INT8U WD_Fact_2, INT8U minTsdr, INT16U Ident_Number, INT8U Group_Ident, INT8U Req_Add, INT8U Prm_Data_len)
{
	if ((Prm_Data_len >= 7) && !(Unlock_Req) && !(Lock_Req))
	{
#ifdef ui_debug
		printf(" DXCH12 \n") ;
#endif
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_STATE = STATE_DATA_EXCH;
	}
	else if ((Prm_Data_len >= 7) && (Unlock_Req) && (Diag.Master_Add == Req_Add)  )
	{
#ifdef ui_debug
		printf(" LEAVE2 \n") ;
#endif
		UI_Leave_Master();
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add == Req_Add) && ((Ident_Number != DP_SLAVE_Real_Ident) || (WD_On) && ((WD_Fact_1 == 0) || (WD_Fact_2 == 0))  ) )
	{
#ifdef ui_debug
		printf(" ABORT8 \n") ;
#endif
		Diag.Prm_Fault = TRUE;
		UI_Leave_Master ();
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add == Req_Add) && (Ident_Number == DP_SLAVE_Real_Ident) &&  (!(WD_On) || (WD_Fact_1 > 0) || (WD_Fact_2 > 0))  &&  ( ( Freeze_Req) && (DP_SLAVE_Freeze_Not_Support) || (Sync_Req) && (DP_SLAVE_Sync_Not_Support) || (Reserve))     )
	{
#ifdef ui_debug
		printf(" ABORT9 \n") ;
#endif
		Diag.Not_Supported = TRUE;
		UI_Leave_Master ();
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add == Req_Add) && (Ident_Number == DP_SLAVE_Real_Ident) &&  (WD_On) && (WD_Fact_1 > 0) && (WD_Fact_2 > 0)  &&  ( !( Freeze_Req) || (DP_SLAVE_Freeze_Support))  && (!(Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" DXCH15 \n") ;
#endif
		Diag.WD_On = TRUE;
		DP_SLAVE_Active_Groups = Group_Ident;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add == Req_Add) && (Ident_Number == DP_SLAVE_Real_Ident) &&  !(WD_On)  &&  ( !( Freeze_Req) || (DP_SLAVE_Freeze_Support))  && (!(Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" DXCH16 \n") ;
#endif
		Diag.WD_On = FALSE;
		DP_SLAVE_Active_Groups = Group_Ident;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DDLM_Set_minTsdr(minTsdr);
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add != Req_Add) && (Ident_Number == DP_SLAVE_Real_Ident) &&  (WD_On) && (WD_Fact_1 > 0) && (WD_Fact_2 > 0)  &&  ( !( Freeze_Req) || (DP_SLAVE_Freeze_Support))  && (!(Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" XMAS3 \n") ;
#endif
		Diag.Sync_Mode = FALSE;
		Diag.Freeze_Mode = FALSE;
		Diag.Station_Not_Ready = TRUE;
		Diag.WD_On = TRUE;
		DP_SLAVE_Active_Groups = Group_Ident;
		DDLM_Leave_req();
		memset( &DP_SLAVE_Output_D , 0x00 ,DP_SLAVE_Output_D_len_const); 	//DP_SLAVE_Output_D = 0;
		memset( &DP_SLAVE_Output_L , 0x00 ,DP_SLAVE_Output_L_len_const);  // DP_SLAVE_Output_L = 0;
		DDLM_Set_minTsdr(minTsdr);
		Diag.Master_Add = Req_Add;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE =  STATE_WAIT_CFG;
	}
	else if ( (Prm_Data_len >= 7) && (Lock_Req) && !(Unlock_Req) && (Diag.Master_Add != Req_Add) && (Ident_Number == DP_SLAVE_Real_Ident) &&  !(WD_On)   &&  ( !( Freeze_Req) || (DP_SLAVE_Freeze_Support))  && (!(Sync_Req) || (DP_SLAVE_Sync_Support)) && !(Reserve) )
	{
#ifdef ui_debug
		printf(" XMAS4 \n") ;
#endif
		Diag.Sync_Mode = FALSE;
		Diag.Freeze_Mode = FALSE;
		Diag.Station_Not_Ready = TRUE;
		Diag.WD_On = FALSE;
		DP_SLAVE_Active_Groups = Group_Ident;
		DDLM_Leave_req( );
		memset( &DP_SLAVE_Output_D , 0x00 ,DP_SLAVE_Output_D_len_const); 	//DP_SLAVE_Output_D = 0;
		memset( &DP_SLAVE_Output_L , 0x00 ,DP_SLAVE_Output_L_len_const);  // DP_SLAVE_Output_L = 0;
		DDLM_Set_minTsdr(minTsdr);
		Diag.Master_Add = Req_Add;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE =  STATE_WAIT_CFG;
	}
}
//======================================================================================//
void UI_Chk_Cfg_ind (INT8U Req_Add,INT8U * Cfg_Data,INT8U Cfg_Data_len  )  // 62
{
	INT8U *Cfg_temp;
	BOOLEAN Compare_Cfg_Data;
	INT8U i;

#ifdef ui_debug
	printf("62 UI_Chk_Cfg_ind \n"); 
#endif	
	memcpy(Cfg_temp , Cfg_Data  , Cfg_Data_len ); 
	if (DP_SLAVE_Real_Cfg_Data_len_const == Cfg_Data_len )
	{
		if (memcmp(&DP_SLAVE_Real_Cfg_Data[0],Cfg_temp,DP_SLAVE_Real_Cfg_Data_len_const) == 0x00)
			Compare_Cfg_Data = TRUE;
		else
			Compare_Cfg_Data = FALSE;
	}
	else
			Compare_Cfg_Data = FALSE;
	

#ifdef ui_debug	
	for (i = 0;i<Cfg_Data_len  ;i++ )
	{
		printf("Cfg_temp = %x \n",*(Cfg_temp+i));
	}
	printf("Compare_Cfg_Data = %x \n",Compare_Cfg_Data);
#endif	
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
		
		break;
		case STATE_WAIT_PRM:
			
		break;
		case STATE_WAIT_CFG:
		
				UI_Chk_Cfg_ind_state_wait_cfg (Req_Add, Compare_Cfg_Data);
		break;
		case STATE_DATA_EXCH:
		
				UI_Chk_Cfg_ind_state_data_exch (Req_Add,Compare_Cfg_Data);
		break;
		case STATE_FREEZE:
		
		break;
		case STATE_CLEAR:
	
		break;
	}
}

void UI_Chk_Cfg_ind_state_wait_cfg (INT8U Req_Add,BOOLEAN Compare_Cfg_Data)
{
	if ((Diag.Master_Add == Req_Add) && !(Compare_Cfg_Data))
	{

#ifdef ui_debug	
		printf("ABORT3 \n");
#endif	
		Diag.Cfg_Fault = TRUE;
		Diag.Prm_Req = TRUE;
		Diag.Master_Add = Invalid;
		Diag.WD_On = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE =  STATE_WAIT_PRM;
	}
	else if ((Diag.Master_Add == Req_Add) && (Compare_Cfg_Data))
	{
#ifdef ui_debug
		printf("ENTER1 \n");
#endif	
		DDLM_Enter_req (Diag.Master_Add);
		Diag.Cfg_Fault = FALSE;
		DP_SLAVE_Diag_Flag = TRUE;
		Diag.Station_Not_Ready = FALSE;
		DDLM_RD_Outp_Upd_req (&DP_SLAVE_Output_D[0],DP_SLAVE_Output_D_len_const);
		memcpy(&DP_SLAVE_INPUT_D[0] , &DP_SLAVE_Periphery_Inp[0]  , DP_SLAVE_Periphery_Inp_len_const );       //  DP_SLAVE_INPUT_D = DP_SLAVE_Periphery_Inp; 
		DDLM_RD_Inp_Upd_req(&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DDLM_Data_Exchange_Upd_req(DP_SLAVE_Diag_Flag,&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
}

void UI_Chk_Cfg_ind_state_data_exch (INT8U Req_Add,BOOLEAN Compare_Cfg_Data)
{
	if ((Diag.Master_Add == Req_Add) && (Compare_Cfg_Data))
	{
#ifdef ui_debug
			printf("DXCH11 \n");
#endif
			// WD Triggern
			DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if ((Diag.Master_Add == Req_Add) && !(Compare_Cfg_Data))
	{
#ifdef ui_debug
			printf("ABORT6 \n");
#endif
			Diag.Cfg_Fault = TRUE;
			UI_Leave_Master ();
			DP_SLAVE_STATE =  STATE_WAIT_PRM;
	}
}
//======================================================================================//
void UI_Data_Exchange_ind (INT8U * Outp_Data,INT8U Outp_Data_len)  // 0
{
	INT8U *Outp_temp;
	
#ifdef ui_debug
	INT8U i ;
	printf(" 0 UI_Data_Exchange_ind \n"); 
#endif
	memcpy(Outp_temp,Outp_Data ,Outp_Data_len); 
#ifdef ui_debug
	
	for (i = 0 ;i <Outp_Data_len ;i++ )
	{
		printf("Outp_temp = %x \n",*(Outp_temp+i));
	}
#endif
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
		
		break;
		case STATE_WAIT_PRM:
		
		break;
		case STATE_WAIT_CFG:
		
		break;
		case STATE_DATA_EXCH:
		
				UI_Data_Exchange_ind_state_data_exch (Outp_temp,Outp_Data_len);
		break;
		case STATE_FREEZE:
		
		break;
		case STATE_CLEAR:
		
		break;
	}
}

void UI_Data_Exchange_ind_state_data_exch (INT8U * Outp_Data,INT8U Outp_Data_len)
{
	if ((Outp_Data_len > 0) && (Outp_Data_len == DP_SLAVE_Real_Output_len))
	{
#ifdef ui_debug
		printf("DXCH1 '\n");
		//printf("Outp_Data = %x \n",*Outp_Data);
		//printf("DP_SLAVE_Output_L[0]= %x \n",DP_SLAVE_Output_L[0]);
		//printf("DP_SLAVE_Output_D[0] = %x \n",DP_SLAVE_Output_D[0]);
#endif
		memcpy(&DP_SLAVE_Output_D[0] , Outp_Data  , Outp_Data_len );										// DP_SLAVE_Output_D = Outp_Data;
		memcpy(&DP_SLAVE_Output_L[0] , &DP_SLAVE_Output_D[0]  , DP_SLAVE_Output_D_len_const );  // DP_SLAVE_Output_L = DP_SLAVE_Output_D;
		DDLM_RD_Outp_Upd_req (&DP_SLAVE_Output_D,DP_SLAVE_Output_D_len_const );
		// WD triggern
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if (((Outp_Data_len > 0) && (Outp_Data_len == DP_SLAVE_Real_Output_len))  && (Diag.Sync_Mode ))
	{
#ifdef ui_debug
		printf("DXCH2 '\n");
#endif
		memcpy(&DP_SLAVE_Output_L[0] , Outp_Data  , Outp_Data_len );				// DP_SLAVE_Output_L = Outp_Data;
		// WD triggern
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if ((Outp_Data_len ==0)  && (DP_SLAVE_Real_Output_len == 0))
	{
#ifdef ui_debug
		printf("DXCH3 '\n");
#endif
		// WD triggern
		DP_SLAVE_STATE =  STATE_DATA_EXCH;
	}
	else if (Outp_Data_len != DP_SLAVE_Real_Output_len)
	{
#ifdef ui_debug
		printf("ABORT4 '\n");
#endif
		Diag.Cfg_Fault = TRUE;
		UI_Leave_Master ();
		DP_SLAVE_STATE =  STATE_WAIT_PRM;
	}
}
//======================================================================================//
void UI_Slave_Diag_ind (INT8U Req_Add)// 60
{
#ifdef ui_debug
	printf("61 UI_Slave_Diag_ind \n"); 
#endif

	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
		
		break;
		case STATE_WAIT_PRM:
			
		break;
		case STATE_WAIT_CFG:
			
				UI_Slave_Diag_ind_state_wait_cfg (Req_Add);
		break;
		case STATE_DATA_EXCH:
		
				UI_Slave_Diag_ind_state_data_exch (Req_Add);
		break;
		case STATE_FREEZE:
		
		break;
		case STATE_CLEAR:
		
		break;
	}
}

void UI_Slave_Diag_ind_state_wait_cfg (INT8U Req_Add)
{		
	if (Diag.Master_Add == Req_Add)
	{
#ifdef ui_debug
		printf("CFG4 \n");
#endif
		// WD Triggern
		DP_SLAVE_STATE = STATE_WAIT_CFG;
	} 
}

void UI_Slave_Diag_ind_state_data_exch (INT8U Req_Add)
{
	if ((Diag.Master_Add == Req_Add) && (Diag.Stat_Diag))
	{
#ifdef ui_debug
		printf("DXCH7 \n");
#endif
		// WD Triggern
		DP_SLAVE_STATE = STATE_DATA_EXCH;
	}
	else if ((Diag.Master_Add == Req_Add) && !(Diag.Stat_Diag))
	{
#ifdef ui_debug
		printf("DXCH7 \n");
#endif
		DP_SLAVE_Diag_Flag = FALSE;
		DDLM_Data_Exchange_Upd_req(DP_SLAVE_Diag_Flag ,&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		// WD Triggern
		DP_SLAVE_STATE = STATE_DATA_EXCH;
	}
}
//======================================================================================//
void UI_Global_Control_ind (INT8U Req_Add,INT8U Control_Command,INT8U Group_Select ) // 58
{
	BOOLEAN Reserve;
	BOOLEAN Sync;
	BOOLEAN Unsync;
	BOOLEAN Freeze;
	BOOLEAN Unfreeze;
	BOOLEAN Clear_Data;
	
	if ((Control_Command & 0xc1) == 0x00)          // Bit  7 , 6 , 1 Reserve = 0
		Reserve = TRUE;
	else 
		Reserve = FALSE;

	if ((Control_Command & 0x20) == 0x20)
		Sync = TRUE;
	else 
		Sync = FALSE;

	if ((Control_Command & 0x10) == 0x10)
		Unsync = TRUE;
	else 
		Unsync = FALSE;

	if ((Control_Command & 0x08) == 0x08)
		Freeze = TRUE;
	else 
		Freeze = FALSE;

	if ((Control_Command & 0x04) == 0x04)
		Unfreeze = TRUE;
	else 
		Unfreeze = FALSE;

	if ((Control_Command & 0x02) == 0x02)
		 Clear_Data = TRUE;
	else 
		 Clear_Data = FALSE;
#ifdef ui_debug
	printf("58 UI_Global_Control_ind \n"); 

	printf("Control_Command		= %x \n",Control_Command);
	printf("Group_Select		= %x \n",Group_Select);
	printf("Sync		= %x \n",Sync);
	printf("Unsync		= %x \n",Unsync);
	printf("Freeze		= %x \n",Freeze);
	printf("Unfreeze	= %x \n",Unfreeze);
	printf("Clear_Data	= %x \n",Clear_Data);
	printf("Reserve		= %x \n",Reserve);
#endif
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
	
		break;
		case STATE_WAIT_PRM:
	
		break;
		case STATE_WAIT_CFG:
	
		break;
		case STATE_DATA_EXCH:
				UI_Global_Control_ind_state_data_exch (Req_Add,Sync,Unsync,Reserve,Group_Select);
				if (DP_SLAVE_STATE == STATE_FREEZE )
					UI_Global_Control_ind_state_freeze (Freeze,Unfreeze);
				if (DP_SLAVE_STATE == STATE_CLEAR)
					UI_Global_Control_ind_state_clear(Clear_Data);
		break;
		case STATE_FREEZE:
				
		break;
		case STATE_CLEAR:
		
		break;
	}
}

void UI_Global_Control_ind_state_data_exch (INT8U Req_Add,BOOLEAN Sync,BOOLEAN Unsync,BOOLEAN Reserve,INT8U Group_Select)
{
	if ( (Req_Add == Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00)) && (Unsync) && (DP_SLAVE_Sync_Not_Support) && !(Reserve))
	{
#ifdef ui_debug
		printf("GCTR2 \n");
#endif
		DP_SLAVE_STATE = STATE_FREEZE;
	}
	else if ( (Req_Add != Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00)) && ((Sync) && (DP_SLAVE_Sync_Not_Support) || (Reserve)) )
	{
#ifdef ui_debug
		printf("ABORT10 \n");
#endif
		Diag.Not_Supported = TRUE;
		UI_Leave_Master ();
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ( (Req_Add == Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00)) && (Unsync) && (DP_SLAVE_Sync_Not_Support) && !(Reserve))
	{
#ifdef ui_debug
		printf("GCTR3 \n");
#endif
		Diag.Sync_Mode = FALSE;
		memcpy(&DP_SLAVE_Output_D[0] , &DP_SLAVE_Output_L[0]  , DP_SLAVE_Output_L_len_const );  // DP_SLAVE_Output_D = DP_SLAVE_Output_L;
		DDLM_RD_Outp_Upd_req (&DP_SLAVE_Output_D[0],DP_SLAVE_Output_D_len_const);
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_FREEZE;
	}
	else if (  (Req_Add == Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00))  && !(Unsync) && (Sync) && (DP_SLAVE_Sync_Not_Support) && !(Diag.Sync_Mode) && !(Reserve))
	{
#ifdef ui_debug
		printf("GCTR4 \n");
#endif
		Diag.Sync_Mode = FALSE;
		Octet_Diagnostic_Data(&Diag);
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		DP_SLAVE_STATE = STATE_FREEZE;
	}
	else if ((Req_Add == Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00))  && !(Unsync) && (Sync) && (DP_SLAVE_Sync_Not_Support) && (Diag.Sync_Mode) && !(Reserve))
	{
#ifdef ui_debug
		printf("GCTR5 \n");
#endif
		memcpy(&DP_SLAVE_Output_D , &DP_SLAVE_Output_L  , DP_SLAVE_Output_L_len_const);  // DP_SLAVE_Output_D = DP_SLAVE_Output_L;
		DDLM_RD_Outp_Upd_req (&DP_SLAVE_Output_D[0],DP_SLAVE_Output_D_len_const);
		DP_SLAVE_STATE = STATE_FREEZE;
	}
	else if ( (Req_Add == Diag.Master_Add) && ((Group_Select == 0 ) || ((DP_SLAVE_Active_Groups & Group_Select) != 0x00)) && !(Unsync) && !(Sync) && !(Reserve))
	{
#ifdef ui_debug
			printf("GCTR6 \n");
#endif
			DP_SLAVE_STATE = STATE_FREEZE;
	}
}

void UI_Global_Control_ind_state_freeze (BOOLEAN Freeze,BOOLEAN Unfreeze)
{
	if ( (Unfreeze) && (DP_SLAVE_Freeze_Not_Support))
	{
#ifdef ui_debug
			printf("FREEZE1 \n");
#endif
		DP_SLAVE_STATE = STATE_CLEAR;
	}
	else if (!(Unfreeze) && (Freeze) && (DP_SLAVE_Freeze_Not_Support) )
	{
#ifdef ui_debug
			printf("ABORT11 \n");
#endif
		Diag.Not_Supported = TRUE;
		UI_Leave_Master();
		DP_SLAVE_STATE = STATE_WAIT_PRM;
	}
	else if ((Unfreeze) && DP_SLAVE_Freeze_Support )
	{
#ifdef ui_debug
			printf("FREEZE2 \n");
#endif
		Diag.Freeze_Mode = FALSE;
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		memcpy(&DP_SLAVE_INPUT_D[0] , &DP_SLAVE_Periphery_Inp[0]  , DP_SLAVE_Periphery_Inp_len_const );       //  DP_SLAVE_INPUT_D = DP_SLAVE_Periphery_Inp; 
		DDLM_Data_Exchange_Upd_req(DP_SLAVE_Diag_Flag ,&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DDLM_RD_Inp_Upd_req (&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DP_SLAVE_STATE = STATE_CLEAR;
	}
	else if ( !(Unfreeze) && (Freeze)  && (DP_SLAVE_Freeze_Support) && !(Diag.Freeze_Mode))
	{
#ifdef ui_debug
		printf("FREEZE3 \n");
#endif
		Diag.Freeze_Mode = TRUE;	
		DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
		memcpy(&DP_SLAVE_INPUT_D[0] , &DP_SLAVE_Periphery_Inp[0]  , DP_SLAVE_Periphery_Inp_len_const );       //  DP_SLAVE_INPUT_D = DP_SLAVE_Periphery_Inp; 
		DDLM_Data_Exchange_Upd_req(DP_SLAVE_Diag_Flag ,&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DDLM_RD_Inp_Upd_req (&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DP_SLAVE_STATE = STATE_CLEAR;
	}
	else if ( !(Unfreeze) && (Freeze)  && (DP_SLAVE_Freeze_Support) && (Diag.Freeze_Mode))
	{
#ifdef ui_debug
		printf("FREEZE4 \n");
#endif	
		memcpy(&DP_SLAVE_INPUT_D[0] , &DP_SLAVE_Periphery_Inp[0]  , DP_SLAVE_Periphery_Inp_len_const );       //  DP_SLAVE_INPUT_D = DP_SLAVE_Periphery_Inp; 
		DDLM_Data_Exchange_Upd_req(DP_SLAVE_Diag_Flag ,&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DDLM_RD_Inp_Upd_req (&DP_SLAVE_INPUT_D[0],DP_SLAVE_INPUT_D_len_const);
		DP_SLAVE_STATE = STATE_CLEAR;
	}
	else if (!(Unfreeze) && !(Freeze) )
	{
#ifdef ui_debug
			printf("FREEZE5 \n");
#endif
		DP_SLAVE_STATE = STATE_CLEAR;
	}
}

void UI_Global_Control_ind_state_clear(BOOLEAN Clear_Data)
{
	if (Clear_Data)
	{
#ifdef ui_debug
		printf("CLEAR1 \n");
#endif
		memset( &DP_SLAVE_Output_D , 0x00 ,DP_SLAVE_Output_D_len_const); 	//DP_SLAVE_Output_D = 0;
		memset( &DP_SLAVE_Output_L , 0x00 ,DP_SLAVE_Output_L_len_const);  // DP_SLAVE_Output_L = 0;	
		DDLM_RD_Outp_Upd_req (&DP_SLAVE_Output_D[0],DP_SLAVE_Output_D_len_const);
		DP_SLAVE_STATE = STATE_DATA_EXCH;
	}
	else
	{
#ifdef ui_debug
		printf("CLEAR2 \n");
#endif
		DP_SLAVE_STATE = STATE_DATA_EXCH;
	}
}

//======================================================================================//
void UI_Set_Slave_ind (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg) // 55
{
#ifdef ui_debug
	printf("55 UI_Set_Slave_ind \n"); 
#endif
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
	
		break;
		case STATE_WAIT_PRM:
	
				UI_Set_Slave_ind_state_wait_prm (New_Slave_Add,Ident_Number,No_Add_Chg);
		break;
		case STATE_WAIT_CFG:
		
		break;
		case STATE_DATA_EXCH:
	
		break;
		case STATE_FREEZE:
	
		break;
		case STATE_CLEAR:
	
		break;
	}
}

void UI_Set_Slave_ind_state_wait_prm (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg)
{
	if (!(DP_SLAVE_Real_No_Add_Chg) && (DP_SLAVE_Real_Ident == Ident_Number) &&  (New_Slave_Add<=125))
	{
#ifdef ui_debug
		printf("SADR1 \n");
#endif
		DP_SLAVE_Station_Address = New_Slave_Add;
		DP_SLAVE_Real_No_Add_Chg = No_Add_Chg;
		//Store Atation_address , No_Add_Chg and Rem_Slave_Data
		DP_SLAVE_STATE = STATE_POWER_ON;
	}
}
//========================================================//
INT8U Read_Output (INT8U Module)
{
#ifdef ui_debug
		//printf("User Read_Output \n");
#endif	
	switch (Module)
	{
		case  Module_1:				// Output Only
					//printf("DP_SLAVE_Output_D[0] %x\n",DP_SLAVE_Output_D[0]);
					return (DP_SLAVE_Output_D[0]);
		break;
		case  Module_2:			// Input Only

		break;
		case  Module_3:			// Output Only
				//printf("DP_SLAVE_Output_D[1] %x\n",DP_SLAVE_Output_D[1]);
				return (DP_SLAVE_Output_D[1]);
		break;
		case Module_4:				// Input Only
				
		break;
	}
}
void Send_Input (INT8U Module,INT8U Value)
{
#ifdef ui_debug
		//printf("User Send_Input \n");
#endif		
	switch (Module)
	{
		case  Module_1:				// Output Only
					
		break;
		case  Module_2:				// Input Only
				DP_SLAVE_Periphery_Inp[0] = Value;
		break;
		case  Module_3:			// Output Only
				
		break;
		case  Module_4:				// Input Only
				DP_SLAVE_Periphery_Inp[1] = Value;
		break;
	}


}

//========================================================//
void  print_user_status()
{
	printf("> User Interface Status \n");	

	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
				printf("- DP_SLAVE_STATE    = STATE_POWER_ON \n");	
		break;
		case STATE_WAIT_PRM:
				printf("- DP_SLAVE_STATE    = STATE_WAIT_PRM \n");
		break;
		case STATE_WAIT_CFG:
			printf("- DP_SLAVE_STATE    = STATE_WAIT_CFG\n");
		break;
		case STATE_DATA_EXCH:
				printf("- DP_SLAVE_STATE    = STATE_DATA_EXCH\n");	
			
		break;
		case STATE_FREEZE:
				printf("- DP_SLAVE_STATE    = STATE_FREEZE\n");
			
		break;
		case STATE_CLEAR:
				printf("- DP_SLAVE_STATE    = STATE_CLEAR\n");
			
		break;
	}
	printf("- Station Address   = %02d\n",DP_SLAVE_Station_Address);	
	printf("- Active Groups     = 0x%0X\n",DP_SLAVE_Active_Groups);		
	printf("- Ident Number      = 0x%04X  \n",DP_SLAVE_Real_Ident);
	printf("- Sync Support      = %1d \n",DP_SLAVE_Sync_Support);
	printf("- Freeze Support    = %1d \n",DP_SLAVE_Freeze_Support);

}
//========================================================//
void UI_Leave_Master ()
{
#ifdef ui_debug	
	printf("LEAVE-MASTER \n");
#endif
	Diag.Master_Add = Invalid;
	Diag.Sync_Mode = FALSE;
	Diag.Freeze_Mode = FALSE;
	Diag.Station_Not_Ready = TRUE;
	Diag.WD_On = FALSE;
	DDLM_Leave_req( );
	DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);

}

//========================================================//

void ui_state ( )
{
	switch ( DP_SLAVE_STATE )
	{
		case STATE_POWER_ON:
				ui_state_power_on ();
		break;
		case STATE_WAIT_PRM:
	
		break;
		case STATE_WAIT_CFG:
	
		break;
		case STATE_DATA_EXCH:
	
		break;
		case STATE_FREEZE:
		
		break;
		case STATE_CLEAR:
	
		break;
	}
}

void  ui_state_power_on ()
{	
#ifdef ui_debug	
	printf("\n INT1 \n");
#endif
	// 1. reset , clear all
	
	// 2. set address slave
	DP_SLAVE_Station_Address = 03;
	DP_SLAVE_Real_Ident = 0x1234;	
	DP_SLAVE_Sync_Support = 1;							// Support Sync
	DP_SLAVE_Freeze_Support = 1 ;						// Support Freeze

	DDLM_Slave_Init (DP_SLAVE_Station_Address);

	Diag.Prm_Req = TRUE;							// True
	Diag.Cfg_Fault = FALSE;							// False
	Diag.Prm_Fault = FALSE;							// False
	Diag.Not_Supported = FALSE	;				// False
	Diag.Master_Add = Invalid;						// Invalid
	Diag.WD_On = FALSE;								// False
	Diag.Station_Not_Ready =  TRUE;			// True
	Diag.Sync_Mode = FALSE;						// False
	Diag.Freeze_Mode = FALSE;					//False

	memset( &DP_SLAVE_Output_D , 0x00 ,DP_SLAVE_Output_D_len_const); 	//DP_SLAVE_Output_D = 0;
	memset( &DP_SLAVE_Output_L , 0x00 ,DP_SLAVE_Output_L_len_const);  // DP_SLAVE_Output_L = 0;
	DP_SLAVE_Real_Cfg_Data[0] = 0x10;				// Cosistency byte  input 1 byte		// setzen
	DP_SLAVE_Real_Cfg_Data[1] = 0x20;				// Cosistency byte  output 1 byte		// setzen

	DP_SLAVE_Real_Output_len = DP_SLAVE_Output_D_len_const;						// setzen
	DP_SLAVE_Real_No_Add_Chg = FALSE;				// setzen �������¹�ŧ�������  Address ����ö����������� .. �� = 0 ,����� 1 

	DP_SLAVE_Diag_Flag = FALSE;								// False;

	Octet_Diagnostic_Data(&Diag);
	DDLM_Slave_Diag_Upd_req(&Diag_Data,Length_Diag);
	DDLM_Get_Cfg_Upd_req( &DP_SLAVE_Real_Cfg_Data[0] ,DP_SLAVE_Real_Cfg_Data_len_const );
	
	// 3. next state
	DP_SLAVE_STATE = STATE_WAIT_PRM;
}

//================================ Combine Octet Diag===========================================//

void Octet_Diagnostic_Data(STD_Diag *Diag)
{
	INT8U Octet_Diag[Length_Diag];
	INT8U  i;
	INT8U *Ident;
	/*--------------- Assign Value Octet Diag -----------------------------*/
	/*OCTET 1 -->DU Byte 1 : Station _status 1 */
	if (Diag->Master_Lock)  // Bit 7
		Octet_Diag[0] = Octet_Diag[0]  | 0x80;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0x7F;
	if (Diag->Prm_Fault) // Bit 6
		Octet_Diag[0]  = Octet_Diag[0]  | 0x40;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xBF;
	if ( Diag->Invalid_Slave_Response) // Bit 5
		Octet_Diag[0]  = Octet_Diag[0]  | 0x20;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xDF;
	if (Diag->Not_Supported) // Bit 4
		Octet_Diag[0]  = Octet_Diag[0]  | 0x10;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xEF;
	if (Diag->Ext_Diag)  // Bit 3
		Octet_Diag[0] = Octet_Diag[0] |  0x08;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xF7;
	if (Diag->Cfg_Fault) // Bit 2
		Octet_Diag[0] = Octet_Diag[0]  | 0x06;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xFB;
	if ( Diag->Station_Not_Ready) // Bit 1
		Octet_Diag[0]  = Octet_Diag[0]  | 0x02;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xFD;
	if (Diag->Station_Non_Existent) // Bit 0
		Octet_Diag[0]  = Octet_Diag[0]  | 0x01;
	else
		Octet_Diag[0]  = Octet_Diag[0]  & 0xFE;
	
	/* OCTET 2 -->DU Byte 2 : Station _status 2 */
	if (Diag->Deactivated)  // Bit 7
		Octet_Diag[1]  = Octet_Diag[1]  | 0x80;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0x7F;
	
		Octet_Diag[1]  = Octet_Diag[1]  & 0xBF;  // Bit  6  Reserve

	if ( Diag->Sync_Mode) // Bit 5
		Octet_Diag[1]  = Octet_Diag[1]  | 0x20;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0xDF;
	if (Diag->Freeze_Mode) // Bit 4
		Octet_Diag[1]  = Octet_Diag[1]  | 0x10;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0xEF;
	if (Diag->WD_On)  // Bit 3
		Octet_Diag[1]  = Octet_Diag[1]  | 0x08;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0xF7;

		Octet_Diag[1]  = Octet_Diag[1]  | 0x06;  // Bit  2 Set 1
	
	if ( Diag->Stat_Diag) // Bit 1
		Octet_Diag[1]  = Octet_Diag[1]  | 0x02;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0xFD;
	if (Diag->Prm_Req) // Bit 0
		Octet_Diag[1]  = Octet_Diag[1]  | 0x01;
	else
		Octet_Diag[1]  = Octet_Diag[1]  & 0xFE;
	/* OCTET 3 -->DU Byte 3 : Station_status_3 */	
	if (Diag->Ext_Diag_Overflow)  // Bit 7
		Octet_Diag[2]  = Octet_Diag[2] | 0x80;
	else
		Octet_Diag[2] = Octet_Diag[2] & 0x7F;
	
		Octet_Diag[2] = Octet_Diag[2] & 0x80;  // Bit  6 - 0 Reserve
	
	/* OCTET 4 -->DU Byte 4 : Para Master Address */	
		Octet_Diag[3] =  Diag->Master_Add ;

	/* OCTET 5, 6  -->DU Byte 5 -  6 : Ident_Number High- Low*/	
		Ident = 	&DP_SLAVE_Real_Ident ;
		Octet_Diag[4] =  * (Ident+1) ;
		Octet_Diag[5] =  * Ident ;
		//printf(" 4 %d %d  ",Octet_Diag[4],* (Ident+1) );
		//printf(" 5 %d %d  ",Octet_Diag[5],* (Ident) );
	/*----------------------------------------------------------------------*/
	/* 	Combine 6 OCTET to string --> Diag_Data 	*/
#ifdef ui_debug
	printf("Diag_Data =  ");
#endif
	for ( i = 0;i< Length_Diag ;i++ )
	{ 
		Diag_Data[i] = Octet_Diag[i];
#ifdef ui_debug
		printf("%X ",Diag_Data[i]);
#endif
	}
#ifdef ui_debug
	printf("\n");
#endif
}













