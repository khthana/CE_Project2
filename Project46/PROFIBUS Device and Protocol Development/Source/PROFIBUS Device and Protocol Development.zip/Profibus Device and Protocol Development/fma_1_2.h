// 
// Profibus DP 
// 

#ifndef TASK_STK_SIZE
#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */
#endif


#define fma_debug 1


/* 134 
Ident List
================================
Ident User Data:
The Ident user data contains the station's Ident_List with vendor name
(Vendor_name), PROFIBUS controller type (Controller_type) and hardware and software
release (HW/SW_release). It comprises a maximum of 200 octets:

LE_VN, LE_CT, LE_HR, LE_SR:
1 octet each. Length of corresponding Data Field in octets;
dual coding, significance as in Fig. 19.

Vendor_name, VN:
Name of Manufacturer as ASCII String (ISO 7 Bit Code, b8=0).

Controller_type, CT:
Hardware Controller Type as ASCII String (ISO 7 Bit Code, b8=0).

HW_release, HR:
Hardware Release of Controller as ASCII String (ISO 7 Bit Code, b8=0).

SW_release, SR:
Software Release of Controller as ASCII String (ISO 7 Bit Code, b8=0).

*/


extern INT8U SET_VALUE_FDL_TS							(INT8U   Desired_value);
extern INT8U SET_VALUE_FDL_Baud_rate			(INT16U Desired_value);
extern INT8U SET_VALUE_FDL_Medium_red		(INT8U   Desired_value);
extern INT8U SET_VALUE_FDL_TSL						(INT16U Desired_value);
extern INT8U SET_VALUE_FDL_min_TSDR			(INT16U Desired_value);
extern INT8U SET_VALUE_FDL_SD_count			(INT32U Desired_value);
extern INT8U SET_VALUE_FDL_SD_error_count(INT16U Desired_value);

INT8U FMA_1_2_SET_VALUE_TS							(INT8U   Desired_value);
INT8U FMA_1_2_SET_VALUE_Baud_rate			(INT16U Desired_value);
INT8U FMA_1_2_SET_VALUE_Medium_red		(INT8U   Desired_value);
INT8U FMA_1_2_SET_VALUE_TSL							(INT16U Desired_value);
INT8U FMA_1_2_SET_VALUE_min_TSDR			(INT16U Desired_value);
INT8U FMA_1_2_SET_VALUE_SD_count				(INT32U Desired_value);
INT8U FMA_1_2_SET_VALUE_SD_error_count	(INT16U Desired_value);

INT8U FMA_1_2_RESET();

#define FMA_1_2_SAP_ACTIVATE					FDL_SAP_ACTIVATE
#define FMA_1_2_SAP_DEACTIVATE			FDL_SAP_DEACTIVATE
#define FMA_1_2_RSAP_ACTIVATE				FDL_RSAP_ACTIVATE

