#include "includes.h"
#include "phy.h"

extern  OS_EVENT  * MMM;
extern OS_EVENT	*	sem_printf;
extern OS_EVENT	* mbox_phy_data_rx;
extern OS_EVENT	* sem_rx_fdl_to_phy;
extern OS_EVENT	* TEST_TO_PHY;
extern OS_EVENT	* PHY_TO_TEST;
extern OS_EVENT	* sem_rx_phy_to_fdl;
extern OS_EVENT	* aaaa;
extern OS_EVENT	* PHY_GET;														// use 22/03/47
extern OS_EVENT	* PHY_GET_OK;												// use 22/03/47
extern OS_EVENT	* PHY_PUT;														// use 22/03/47
extern OS_EVENT        * mbox_phy_data_rx;
extern OS_EVENT        * mbox_phy_data_rx_ok;
extern INT8U get_ready;
extern INT8U ISR_RX;
extern OS_EVENT	*	ISR_PHY;
char					Task_3_Data;     
//OS_STK			Task_3_Stk[2048];
 OS_STK			Task_3_Stk[TASK_STK_SIZE];
// Physical Layer Variable_name - PHY - FMA1/2 Interface
INT8U Transmitter_output;							// enabled,disabled
INT8U Received_signal_source;			// primary = 0,alternate = 1;
INT8U Loop;													// enabled,disabled

//INT8U PHY_RX_STATUSx;						// idle = 0 , rx recieve = 1
INT8U phy_rx_int;
INT8U PHY_RX;
INT8U PHY_DATA_GET();

void add_x( )
{
	printf("Xxxx");

}

void  Task_3 ()
{
	INT8U  err;
//	INT8U  err2;
//	INT8U temp;
//	INT16U i,j;




	InitComport ();
	while ( 1 )
	{			
			
 		//if (CheckInterrupt())
 			OSSemPend(PHY_GET, 0, &err);							// Acquire semaphore 

			if (err == OS_NO_ERR) 
			{
 	 
				//PHY_RX = int_getch() ;
				PHY_RX = ISR_RX;

				#ifdef  phy_debug 
 						printf("PHY RX <<< %X \n",PHY_RX );
				#endif
 		 			err = OSSemPost(sem_rx_phy_to_fdl);

					OSSemPend(sem_rx_fdl_to_phy, 0, &err);		

 			}
			err = OSSemPost(PHY_GET_OK);
    }
}


/* =============================================================*/
// Interface between PHY and FDL

INT8U PHY_DATA_PUT(INT8U temp)
{
				INT8U  err;
				// rts = 1
				// out serial
				// rts = 0
				OSSemPend(PHY_PUT, 0, &err);							// Acquire semaphore 
				int_putch(temp);
				OSTimeDly(1);    
				OSSemPost(PHY_PUT);											// Release semaphore          

#ifdef  phy_debug		
				printf("PHY TX >>> %X \n",temp );
#endif
				return temp;
}

INT8U PHY_DATA_GET()
{
				INT8U err;
				// in serial example
 			//	PHY_RX = '1';

		// jane function check recieve

// com86				if (CheckInterrupt())            // check in serial on com86
//		{
				// it ok

				// 2. save octet to phy_data_rx
				// INT8U	phy_data_rx;

// com86				PHY_RX = int_getch();

				// 3. Mail to Mailbox - octet recieved
				// OS_EVENT        * mbox_phy_data_rx;

//				err = OSMboxPost(mbox_phy_data_rx, &PHY_RX);


				#ifdef  phy_debug 
						printf("PHY RX <<< %X \n",PHY_RX );
				#endif
 		 		err = OSSemPost(sem_rx_phy_to_fdl);

		 		OSSemPend(sem_rx_fdl_to_phy, 0, &err);							// Wait PHY_INDICATE
		
//		}
		return PHY_RX;
}

/* =============================================================*/
// PHY - FMA1/2 Interface
// 1. Reset PHY
INT8U PHY_RESET()
{

#ifdef  phy_debug 
				printf("PHY RESET\n");
#endif
 
				PHY_SET_VALUE_Transmitter_output				(	enabled	);			// *enabled = 1,disabled = 0
				PHY_SET_VALUE_Received_signal_source	(	primary		);			// *primary = 0,alternate = 1;
				PHY_SET_VALUE_Loop											(  disabled	);			// enabled= 1, *disabled = 0 
				phy_rx_int = 1;
				// (re) inital serial - Jane Function
 
				return 0;
}	

INT8U PHY_SET_VALUE_Transmitter_output(INT8U Desired_value)
{

#ifdef  phy_debug 
				printf("PHY SET Transmitter_output = %X\n",Desired_value);
#endif

				Transmitter_output = Desired_value;
				return Desired_value;
}

INT8U PHY_SET_VALUE_Received_signal_source(INT8U Desired_value)
{

#ifdef  phy_debug 
				printf("PHY SET Received_signal_source = %X\n",Desired_value);
#endif

				Received_signal_source = Desired_value;
				return Desired_value;
}

INT8U PHY_SET_VALUE_Loop(INT8U Desired_value)
{

#ifdef  phy_debug 
				printf("PHY SET Loop = %X\n",Desired_value);
#endif

				Loop = Desired_value;
				return Desired_value;
}



/* =============================================================*/

INT8U PHY_READ_VALUE_Transmitter_output(  )
{
#ifdef  phy_debug 
				printf("PHY READ Transmitter_output = %X\n",Transmitter_output);
#endif
				return Transmitter_output;
}

INT8U PHY_READ_VALUE_Received_signal_source(	)
{

#ifdef  phy_debug 
				printf("PHY READ Received_signal_source = %X\n",Received_signal_source);
#endif
				return Received_signal_source;
}

INT8U PHY_READ_VALUE_Loop(	)
{

#ifdef  phy_debug 
				printf("PHY READ Loop = %X\n",Loop);
#endif
				return Loop;
}

/* =============================================================*/

/*
INT8U  l_sdu[6];
l_sdu[0] = b1
:
l_sdu[5] = b1

p = &l_sdu[0];
INT8U send(&l_sdu[0] ,6  )
INT8U send(INT8U * l_sdu ,INT8U length )
{


}
*/