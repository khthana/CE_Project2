// 
// Profibus DP 
// 

#ifndef TASK_STK_SIZE
#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */
#endif


#define Module_1 1
#define Module_2 2
#define Module_3 3 
#define Module_4 4

extern void Send_Input (INT8U Module,INT8U Value);
extern INT8U Read_Output (INT8U Module);

