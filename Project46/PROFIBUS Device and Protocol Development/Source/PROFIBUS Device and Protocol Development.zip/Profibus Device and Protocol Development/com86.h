/*
*********************************************************************************************************
*                                        COM86 SUPPORT FUNCTIONS
*
*                               (c) Copyright 2003, NetGadgets Co., Ltd.
*                                           All Rights Reserved
*
* File     : COM86.H
* By       : COM86 Team
* Based on : PC.H by Jean J. Labrosse
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                               CONSTANTS
*                             COLOR ATTRIBUTES FOR VT100 and ANSI TERMINAL
*
* Description: These #defines are used in the COM86_Disp???() functions.  The 'color' argument in these
*              function MUST specify a 'foreground' color, a 'background' and whether the display will
*              blink or not.  If you don't specify a background color, BLACK is assumed.  You would 
*              specify a color combination as follows:
*
*              COM86_DispChar(0, 0, 'A', DISP_FGND_WHITE, DISP_BGND_BLUE, DISP_BLINK);
*
*              To have the ASCII character 'A' blink with a white letter on a blue background.
*********************************************************************************************************
*/

#define DISP_BLACK                      0
#define DISP_RED                        1
#define DISP_GREEN                      2
#define DISP_YELLOW                     3
#define DISP_BLUE                       4
#define DISP_MAGENTA                    5
#define DISP_CYAN                       6
#define DISP_WHITE                      7

#define DISP_BRIGHT                     8       /* Bitmask map to BOLD attribute of ANSI code (1)      */
#define DISP_UNDERLINE                  16      /* Bitmask map to UNDERLINE attribute of ANSI code (4) */
#define DISP_BLINK                      32      /* Bitmask map to BLINK attribute of ANSI code (5)     */
#define DISP_INVERSE                    64      /* Bitmask map to INVERSE attribute of ANSI code (7)   */
#define DISP_INVISIBLE                  128     /* Bitmask map to INVISIBLE attribute of ANSI code (8) */


#define ANSI_DEFAULT                    0
#define ANSI_BOLD                       1
#define ANSI_DIM                        2
#define ANSI_UNDERLINE                  4
#define ANSI_BLINK                      5
#define ANSI_INVERSE                    7
#define ANSI_INVISIBLE                  8

#define ANSI_NOBOLD                     22
#define ANSI_NOUNDERLINE                24
#define ANSI_NOBLINK                    25
#define ANSI_NOINVERSE                  27

#define ANSI_FGND_OFFSET                30      /* ANSI colors of Foreground color between 30-37       */
#define ANSI_BGND_OFFSET                40      /* ANSI colors of Background color between 40-47       */ 
                                                
#define DISP_MAX_X                      80      /* Maximum number of columns                           */
#define DISP_MAX_Y                      24      /* Maximum number of rows                              */

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void    COM86_DispInit(void);
void    COM86_DispClrScr(INT8U fg, INT8U bg);
void    COM86_DispClrLine(INT8U y, INT8U fg, INT8U bg);
void    COM86_DispChar(INT8U x, INT8U y, INT8U c, INT8U fg, INT8U bg);
void    COM86_DispStr(INT8U x, INT8U y, INT8U *s, INT8U fg, INT8U bg);

void    COM86_DOSReturn(void);
void    COM86_DOSSaveReturn(void);

void    COM86_ElapsedInit(void);
void    COM86_ElapsedStart(void);
INT16U  COM86_ElapsedStop(void);

void    COM86_GetDateTime(char *s);
BOOLEAN COM86_GetKey(INT16S *c);

void    COM86_SetTickRate(INT16U freq);

void   *COM86_VectGet(INT8U vect);
void    COM86_VectSet(INT8U vect, void (*isr)(void));
