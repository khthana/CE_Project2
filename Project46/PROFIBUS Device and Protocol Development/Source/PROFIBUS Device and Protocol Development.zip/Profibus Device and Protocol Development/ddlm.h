// 
// Profibus DP 
// 

#ifndef TASK_STK_SIZE
#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */
#endif


#define ddlm_debug 1

#define Length_Diag 6
#define Length_Prm 7
// Interface between User-Interface and User

// Interface between DDLM and User-Interface

// Interface between DDLM and Layer 2
/*
a) FDL services:

- Send and Request Data with Reply (SRD)
- Send Data with No Acknowledge (SDN)

b) FMA1/2 services:
- Reset FMA1/2
- Set Value FMA1/2
- Read Value FMA1/2
- Event FMA1/2
- SAP Activate FMA1/2
- RSAP Activate FMA1/2
- SAP Deactivate FMA1/2
*/
// ===============================================
/* 

SRD - SSAP 62 -> DSAP 0 (NIL)
DDLM_Data_Exchange.req/.ind
DDLM_Data_Exchange.con
DDLM_Data_Exchange_Upd.req

SRD - SSAP 62 -> DSAP 62
DDLM_Chk_Cfg.req/.ind
DDLM_Chk_Cfg.con

SRD - SSAP 62 -> DSAP 61
DDLM_Set_Prm.req/.ind
DDLM_Set_Prm.con

SRD - SSAP 62 -> DSAP 60
DDLM_Slave_Diag.req/.ind
DDLM_Slave_Diag.con
DDLM_Slave_Diag_Upd.req

SRD - SSAP 62 -> DSAP 59
DDLM_Get_Cfg.req
DDLM_Get_Cfg.con
DDLM_Get_Cfg_Upd.req

SRD - SSAP 62 -> DSAP 58
DDLM_Global_Control.req/.ind

SRD - SSAP 62 -> DSAP 57
DDLM_RD_Outp.req
DDLM_RD_Outp.con
DDLM_RD_Outp_Upd.req

SRD - SSAP 62 -> DSAP 56
DDLM_RD_Inp.req
DDLM_RD_Inp.con

SRD - SSAP 62 -> DSAP 55
DDLM_Set_Slave_Add.req/.ind
DDLM_Set_Slave_Add.con


//=========================================================================

 -DDLM_Slave_Init
-DDLM_Fault
-DDLM_Enter
-DDLM_Leave

Additionally the following data transmission services are prescribed:
-DDLM_Slave_Diag
-DDLM_Set_Prm
-DDLM_Chk_Cfg
-DDLM_Data_Exchange
-DDLM_Global_Control
-DDLM_RD_Inp
-DDLM_RD_Outp
-DDLM_Get_Cfg
The following data transmission function can additionally offered from the DDLM:
-DDLM_Set_Slave_Add

*/


/* Diag_Data : consist of  6 byte of statdard   
DU Byte 1 : Station_status_1
Bit 7 - Diag.Master_Lock 
Bit 6 - Diag.Prm_Fault
Bit 5 - Diag.Invalid_Slave_Response
Bit 4 - Diag.Not_Supported
Bit 3 - Diag.Ext_Diag 
Bit 2 - Diag.Cfg_Fault 
Bit 1 - Diag.Station_Not_Ready 
Bit 0 -  Diag.Station_Non_Existent 

DU Byte 2 : Station_status_2
Bit 7 - Diag.Deactivated 
Bit 6 - Reserve 
Bit 5 - Diag.Sync_Mode 
Bit 4 - Diag.Freeze_Mode 
Bit 3 - Diag.WD_On 
Bit 2 - Set to 1 
Bit 1 - Diag.Stat_Diag 
Bit 0 - Diag.Prm_Req  

DU Byte 3 : Station_status_3
Bit 7 - Diag.Ext_Diag_Overflow 
Bit 6 - 0 - Reserve 

DU Byte 4 : Para Master Address
Bit 7 - 0 - Diag.Master_Add 

DU Byte 5 -  6 : Ident_Number High- Low
------------------------------------------------------------------------------ */
typedef struct 
{
	BOOLEAN Master_Lock ;
	BOOLEAN Prm_Fault ;
	BOOLEAN Invalid_Slave_Response ;
	BOOLEAN Not_Supported ;
	BOOLEAN Ext_Diag ;
	BOOLEAN Cfg_Fault ;
	BOOLEAN Station_Not_Ready ;
	BOOLEAN Station_Non_Existent ;
	BOOLEAN Deactivated ;
	BOOLEAN Sync_Mode  ;
	BOOLEAN Freeze_Mode ;
	BOOLEAN WD_On  ;
	BOOLEAN Stat_Diag ;
	BOOLEAN Prm_Req  ;
	BOOLEAN Ext_Diag_Overflow ;
	
	INT8U Master_Add;
	INT8U Ident_High;
	INT8U Ident_Low;

} Diagnostic;

/* ------------------------------------------------------------------------------ */
/* Prm_Data : consis of 7 bytes of standard
DU : Byte 1 Station status
Bit 7 - Lock_Req 
Bit 6 - Unlock_Req
Bit 5 - Sync_Req
Bit 4 - Freeze_Req
Bit 3 - WD_On
Bit 2 - 0  Reserve

DU : Byte 2 WD_Fact_1
DU : Byte 3 WD_Fact_2

DU : Byte 4  Min Station Delay
DU : Byte 5 - 6 Ident_Number
DU : Byte 7 Group_Ident
------------------------------------------------------------------------------*/
typedef struct 
{
	BOOLEAN Lock_Req ;
	BOOLEAN Unlock_Req;
	BOOLEAN Sync_Req;
	BOOLEAN Freeze_Req;
	BOOLEAN WD_On;

	INT8U WD_Fact_1;
	INT8U WD_Fact_2;
	INT8U MinTSDR;
	INT8U Ident_High;
	INT8U Ident_Low;
	INT8U Group_Ident;
} Parameter;
/*------------------------------------------------------------------------------ */
/* Cfg_Data : Configuration Data Standard 1 octet	
	Bit 7 - Consistency over 
	Bit 6 - Lenght 
	Bit 5 - Input
	Bit 4 - Output 
	Bit 3-0 - Length_Data --> lenght of data  0 -15  
*/
/*------------------------------------------------------------------------------ */
typedef struct 
{
	BOOLEAN Consistency;
	BOOLEAN Lenght;
	BOOLEAN Input;
	BOOLEAN Output;
	BOOLEAN Length_Data_1;
	BOOLEAN Length_Data_2;
	BOOLEAN Length_Data_3;
	BOOLEAN Length_Data_4;
} Configuration ;
/*------------------------------------------------------------------------------ */
/* Control : Control Command Standard 1 octet
	Bit 7 - 6  - Reserve
	Bit 5 - Sync 
	Bit 4 - Unsync
	Bit 3 - Freeze
	Bit 2 - Unfreeze
	Bit 1 - Clear_Data  -> All Outputs are cleared
	Bit 0 - Reserve
*/
/*------------------------------------------------------------------------------ */
typedef struct 
{
	BOOLEAN Sync ;
	BOOLEAN Unsync;
	BOOLEAN Freeze;
	BOOLEAN Unfreeze;
	BOOLEAN Clear_Data;

	INT8U Group;
} Control ;

/*------------------------------------------------------------------------------ */

void ddlm_srd_service( );
void ddlm_sdn_service( );
INT8U DDLM_Slave_Init (INT8U Station_Address);
void ddlm_printf(TELEFRAM_SD2 temp);

void ddlm_state();

#define DDLM_STATE_RUN  0
#define DDLM_STATE_INI1	1
#define DDLM_STATE_INI2	2
#define DDLM_STATE_INI3	3
#define DDLM_STATE_INI4	4
#define DDLM_STATE_INI5	5
#define DDLM_STATE_INI6	6


INT8U DDLM_Slave_Init (INT8U Station_Address);
INT8U DDLM_Enter_req (INT8U Master_Add	);
INT8U DDLM_Leave_req( );
INT8U DDLM_Set_minTsdr (INT16U minTSDR);
// SSAP = 0
INT8U DDLM_Data_Exchange_Upd_req(BOOLEAN Diag_Flag,INT8U * Inp_Data ,INT8U Inp_Data_len );
// SSAP = 60
INT8U DDLM_Slave_Diag_Upd_req( INT8U * Diag_Data ,INT8U Diag_Data_len );
// SSAP = 59
INT8U DDLM_Get_Cfg_Upd_req( INT8U * Real_Cfg_Data ,INT8U Real_Cfg_Data_len );
// SSAP = 57
INT8U DDLM_RD_Outp_Upd_req( INT8U * Outp_Data ,INT8U Outp_Data_len );
// SSAP = 56
INT8U DDLM_RD_Inp_Upd_req( INT8U * Inp_Data ,INT8U Inp_Data_len );