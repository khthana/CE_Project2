// 
// Profibus DP 
// 
#include "includes.h"
#include "fdl.h"
#include "phy.h"


char					Task_2_Data;     
OS_STK			Task_2_Stk[TASK_STK_SIZE];
extern OS_EVENT	*	sem_printf;


void  Task_2 ()
{
	INT8U  err;
	INT8U  err2;

	INT16U i,j;


	while ( 1 )
	{
		//		OSSemPend(aaaa, 0, &err);							// Acquire semaphore 
 
		//		OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
		//		printf(" FMA 1/2 \n" );
		//		OSSemPost(sem_printf);											// Release semaphore               
 
				OSTimeDly(1000);                            /* Delay 1 clock tick                                 */
    }

}


INT8U FMA_1_2_SET_VALUE_TS							(INT8U   Desired_value)
{
		return SET_VALUE_FDL_TS ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_Baud_rate			(INT16U Desired_value)
{
		return SET_VALUE_FDL_Baud_rate ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_Medium_red		(INT8U   Desired_value)
{
		return SET_VALUE_FDL_Medium_red ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_TSL							(INT16U Desired_value)
{
		return SET_VALUE_FDL_TSL ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_min_TSDR			(INT16U Desired_value)
{
		return SET_VALUE_FDL_min_TSDR ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_SD_count				(INT32U Desired_value)
{
		return SET_VALUE_FDL_SD_count ( Desired_value );
}
INT8U FMA_1_2_SET_VALUE_SD_error_count	(INT16U Desired_value)
{
		return SET_VALUE_FDL_SD_error_count ( Desired_value );
}

INT8U FMA_1_2_RESET()
{
	PHY_RESET();
 	FDL_RESET();
	return 0;
}