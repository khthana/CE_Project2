#ifndef TASK_STK_SIZE

#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */

#endif


#define fdl_debug 1

#define MTU_TX 44
#define MTU_RX 44
#define MTU_DATA 32
#define TELEGRAM_SD1		0x10
#define TELEGRAM_SD2		0x68
#define TELEGRAM_SD3		0xA2
#define TELEGRAM_SD4		0xDC
#define TELEGRAM_SC		0xE5
#define TELEGRAM_ED		0x16

#define FDL_this_address	9;
#define FDL_baud_rate			0;

#define Service_type_SDA							1
#define Service_type_SDN							2
#define Service_type_SRD							3
#define Service_type_CRSC						4

#define Access_All											127

#define Role_in_service_Initiator				1
#define Role_in_service_Responder		2
#define Role_in_service_Both						3

#define Serv_Class_High								2
#define Serv_Class_Low								1

#define Indication_Mode_All						1
#define Indication_Mode_Data					2
#define Indication_Mode_Unchanged		3

#define Transmit_Multi									2
#define Transmit_Single								1
#define Transmit_no_data							0

 /*
#define SSAP_0		0x00
#define SSAP_54		0x01
#define SSAP_55		0x02
#define SSAP_56		0x03
#define SSAP_57		0x04 
#define SSAP_58		0x05
#define SSAP_59		0x06
#define SSAP_60		0x07
#define SSAP_61		0x08
#define SSAP_62		0x09
*/
typedef struct 
{
	INT8U	SD2_sd;
	INT8U	SD2_da;
	INT8U	SD2_sa;
	INT8U	SD2_fc;
	INT8U   SD2_dsegment;
	INT8U	SD2_dsap;
	INT8U   SD2_ssegment;
	INT8U	SD2_ssap;
	INT8U	SD2_data_unit[MTU_DATA];
	INT8U   SD2_data_length;
} TELEFRAM_SD2;


// Record
typedef struct 
{
	INT8U ssap;
	INT8U access;
	INT8U service_activate;
	INT8U role_in_service;
	void * next;
} SAP_ACTIVATE_LIST;

typedef struct 
{
	INT8U ssap;
	INT8U access;
	INT8U indication_mode;
	void * next;
} RSAP_ACTIVATE_LIST;



void  Task_6 ();
void FDL_parse_telegram( INT8U phy_data_rx);

void FDL_parse_telegram( INT8U phy_data_rx);
INT8U	FDL_indication_82_86();
// ===========================================================================================
/*
4.1 FDL User - FDL Interface

2. Send Data with No Acknowledge (SDN)

= Master
FDL_DATA.request 
(SSAP, DSAP, Rem_add, L_sdu, Serv_class)

= Master/Slave
FDL_DATA.indication
(SSAP, DSAP, Loc_add, Rem_add, L_sdu, Serv_class)

= Master
FDL_DATA.confirm
(SSAP, DSAP, Rem_add, Serv_class, L_status)

*/
//INT8U SDN_put(INT8U SSAP,INT8U DSAP,INT8U Rem_add,INT8U Serv_class,INT8U * data_unit,INT8U data_length);


/*
= Master
FDL_DATA.request 
(SSAP, DSAP, Rem_add, L_sdu, Serv_class)
//INT8U FDL_SDN_put(TELEFRAM_SD2 * temp); - ��������� ���ѹ��ҧ

*/
INT8U FDL_SDN_put(INT8U SRD_SSAP,
												INT8U SRD_DSAP,
													INT8U SRD_Rem_add,
														INT8U * SRD_data_unit,INT8U SRD_data_length,
															INT8U SRD_Serv_class);


/* = Master
= Master/Slave
FDL_DATA.indication
(SSAP, DSAP, Loc_add, Rem_add, L_sdu, Serv_class)

FDL_DATA.confirm
(SSAP, DSAP, Rem_add, Serv_class, L_status)

//void SDN_get(INT8U * SSAP,INT8U * DSAP,INT8U * Rem_add,INT8U * data_unit,INT8U  data_length,INT8U * Serv_class);
 - ��������� ���ѹ��ҧ
*/
void FDL_SDN_get(TELEFRAM_SD2 * temp);
INT8U		FDL_SDN_indication(INT8U );

 









// ===========================================================================================

/*
3. Send and Request Data with Reply (SRD)

= Master
FDL_DATA_REPLY.request
(SSAP, DSAP, Rem_add, L_sdu, Serv_class)

= Master/Slave
FDL_DATA_REPLY.indication
(SSAP, DSAP, Loc_add, Rem_add, L_sdu, Serv_class, Update_status)

= Master
FDL_DATA_REPLY.confirm
(SSAP, DSAP, Rem_add, L_sdu, Serv_class, L_status)

= Master/Slave
FDL_REPLY_UPDATE.request
(SSAP, L_sdu, Serv_class, Transmit)

= Master/Slave
FDL_REPLY_UPDATE.confirm
(SSAP, Serv_class, L_status)

Serv_class	 : 1 = high , 0 = low
Transmit		 : 2 = Multi , 1 = Single , 0 = no data
*/

// Master 
INT8U FDL_SRD_req(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class);

//INT8U FDL_SRD_req(TELEFRAM_SD2 * temp );
 
INT8U FDL_SRD_con( );

// Master-Slave
INT8U FDL_SRD_indication(INT8U );
void EVENT_CLEAR( ) ;
/*
FDL_DATA_REPLY.indication
(SSAP, DSAP, Loc_add, Rem_add, L_sdu, Serv_class, Update_status)
*/

//(SSAP, L_sdu, Serv_class, Transmit)
INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
INT8U FDL_SRD_REPLY_UPDATE_respond(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add);

void FDL_SRD_get(TELEFRAM_SD2 * temp);

// ===========================================================================================




// ===========================================================================================
/*
typedef struct 
{
// Operating Parameters (mandatory)
INT8U	FDL_SSAP_Enable;				// 1 = Enable , 0 = Disable
INT8U	FDL_SSAP_NO;						// 0-63
INT8U	FDL_SSAP_TX_BUFFER[MTU_DATA];		// buffer
INT8U	FDL_SSAP_TX_BUFFER_LEN;						// 32 Max
INT8U	FDL_SSAP_Serv_class;
INT8U	FDL_SSAP_Transmit;
INT8U	FDL_SSAP_TX_READY;
} FDL_SSAP;
*/
typedef struct 
{
// Operating Parameters (mandatory)
INT8U	FDL_SSAP_Enable;				// 1 = Enable , 0 = Disable
INT8U	FDL_SSAP_NO;						// 0-63
INT8U	FDL_SSAP_data_unit[MTU_DATA];		// buffer
INT8U	FDL_SSAP_data_len;				// 32 Max
INT8U	FDL_SSAP_Serv_class;		// 1 = high , 0 = low
INT8U	FDL_SSAP_Transmit;				// 2 = Multi , 1 = Single , 0 = no data
} FDL_SSAP;

typedef struct 
{
// Operating Parameters (mandatory)
INT8U	FDL_SSAP_NO;						// 0-63
INT8U	FDL_SSAP_data_unit[MTU_DATA];		// buffer
INT8U	FDL_SSAP_data_len;				// 32 Max
INT8U	FDL_SSAP_Serv_class;		// 1 = high , 0 = low
INT8U	FDL_SSAP_Transmit;				// 2 = Multi , 1 = Single , 0 = no data
void * next;
} FDL_SRD_SSAP_LIST;
INT8U FDL_SRD_SSAP_CREATE(INT8U );
INT8U	FDL_SRD_SAP_PRINT( );
// ===========================================================================================
/* FDL - FMA1/2 Interface

The FDL provides the following services to FMA1/2:

- Reset FDL
- Set Value FDL
- Read Value FDL
- Fault FDL

- Ident FDL
- LSAP Status FDL
- Live List FDL ( master)
- SAP Activate FDL
- RSAP Activate FDL
- SAP Deactivate FDL

*/

/* =============================================================*/
/* 1. FDL RESET

FDL_RESET.request
(	)
FDL_RESET.confirm
(	)
*/

INT8U FDL_RESET();


// MSAP_0 = 0 
// �纤��

typedef struct 
{
// Operating Parameters (mandatory)
INT8U	FDL_TS;										// 0-126
INT16U	FDL_Baud_rate;						// 9,600; 19,200; 93,7500; 187,500; 50000; 150000kbit/s
INT8U	FDL_Medium_red;					// single, redundance
INT8U	FDL_HW_Release[MTU_DATA];			// 
INT8U	FDL_SW_Release[MTU_DATA];			//
INT16U	FDL_TSL;									//  52 to 2^16-1 (Bit Times	)
INT16U	FDL_min_TSDR;						//  2^0 to 2^16-1 (Bit Times)

// Counters (optional)
INT32U FDL_SD_count;
INT16U FDL_SD_error_count;

} FDL_VAR;

/*
FMA1/2_SET_VALUE.request
(MSAP_0, Variable_name 1 to z, Desired_value 1 to z)

FMA1/2_READ_VALUE.request
(MSAP_0, Variable_name 1 to z)
*/


INT8U SET_VALUE_FDL_TS							(INT8U   Desired_value);
INT8U SET_VALUE_FDL_Baud_rate			(INT16U Desired_value);
INT8U SET_VALUE_FDL_Medium_red		(INT8U   Desired_value);
INT8U SET_VALUE_FDL_TSL						(INT16U Desired_value);
INT8U SET_VALUE_FDL_min_TSDR			(INT16U Desired_value);
INT8U SET_VALUE_FDL_SD_count			(INT32U Desired_value);
INT8U SET_VALUE_FDL_SD_error_count(INT16U Desired_value);

INT8U READ_VALUE_FDL_TS							(  );
INT16U READ_VALUE_FDL_Baud_rate			(  );
INT8U READ_VALUE_FDL_Medium_red		(  );
INT16U READ_VALUE_FDL_TSL						(  );
INT16U READ_VALUE_FDL_min_TSDR		(  );
INT32U READ_VALUE_FDL_SD_count			(  );
INT16U READ_VALUE_FDL_SD_error_count(  );
INT8U  * READ_VALUE_FDL_HW_Release(  );
INT8U  * READ_VALUE_FDL_SW_Release(  );

/*
FDL_FAULT.indication
(Fault_type)

Time_out
Not_syn
*/
/*
��ҹ��� configuration �ͧ LSAP ���  

FMA1/2_LSAP_STATUS.request
(MSAP_0, LSAP, Rem/Loc_add)

FMA1/2_LSAP_STATUS.confirm
(MSAP_0, LSAP, Rem/Loc_add, Access, Service_type 1 to z, Role_in_service 1 to z,M_status)

Access						 
									- values All/0 to 126
									- 0 - 126 , 127 = all
Service_type
									- Send Data with Acknowledge (SDA)					1
									- Send Data with No Acknowledge (SDN)			2
									- Send and Request Data with Reply (SRD)		3
									- Cyclic Send and Request Data (CRSC)				4

Role_in_service	
									- Initiator:					1
									- Responder:			2
									- Both:						3
M_status
									- OK	 - LR		-LS		- RS		- NA	- DS	- NR	- IV
*/


/*
SAP Activate FMA1/2_SAP_ACTIVATE.request Master and Slave
FMA1/2 FMA1/2_SAP_ACTIVATE.confirm - " -
RSAP Activate FMA1/2_RSAP_ACTIVATE.request Master and Slave
FMA1/2 FMA1/2_RSAP_ACTIVATE.confirm - " -
SAP Deactivate FMA1/2_SAP_DEACTIVATE.request Master and Slave
FMA1/2 FMA1/2_SAP_DEACTIVATE.confirm - " -

SAP Activate FMA1/2
FMA1/2_SAP_ACTIVATE.request
(MSAP_2, SSAP, Access, Service_list)

Service_list
+-------+------------------------------------+
! 1 ! Service_list_length (1 + 3.z)
! 2 ! Service_activate 1
! 3 ! Role_in_service 1
! 4 ! L_sdu_length_list 1
! 5 ! Service_activate 2
! 6 ! Role_in_service 2
! 7 ! L_sdu_length_list 2
! . ! . . . !
! . ! . . . !
! . ! . . . !
! k ! Service_activate z 
! k+1 ! Role_in_service z
! k+2 ! L_sdu_length_list z 
+-------+------------------------------------+

(SRD and CSRD).
*/


/*

FMA1/2_RSAP_ACTIVATE.request
(MSAP_2, SSAP, Access, L_sdu_length_list, Indication_mode)
Indication_mode	= All/Data/Unchanged

L_sdu_length_list
+-------+-------------------------------+
! Entry ! Name !
+-------+-------------------------------+
! 1 ! Max_L_sdu_length_req_low !
! 2 ! Max_L_sdu_length_req_high !
! 3 ! Max_L_sdu_length_ind_low !
! 4 ! Max_L_sdu_length_ind_high !
+-------+-------------------------------+

FMA1/2_RSAP_ACTIVATE.confirm
(MSAP_2, SSAP, M_status)
*/
INT8U	FDL_SD2_Parse();

/*
FMA1/2_SAP_ACTIVATE.req(SSAP=NIL, Service_activate=SRD,
Role_in_service=Initiator)

FMA1/2_SAP_ACTIVATE.req(SSAP=62,
Service_activate1=SRD, Role_in_service1=Initiator,
Service_activate2=SDN, Role_in_service2=Initiator)

FMA1/2_SAP_ACTIVATE.req(SSAP=54, Access=All,
Service_activate1=SDN, Role_in_service1=Responder)

FMA1/2_RSAP_ACTIVATE.req(SSAP=57, Access=All,
Indication_Mode=Data)
FMA1/2_RSAP_ACTIVATE.req(SSAP=61, Access=All,
Indication_Mode=All)



*/



INT8U	FDL_SAP_ACTIVATE( INT8U t_ssap,INT8U t_access, INT8U t_service_activate,INT8U role_in_service );
INT8U	FDL_SAP_ACTIVATE_PRINT();
INT8U	FDL_SAP_DEACTIVATE(INT8U t_ssap);

INT8U	FDL_RSAP_ACTIVATE( INT8U t_ssap,INT8U t_access, INT8U indication_mode );
INT8U	FDL_RSAP_ACTIVATE_PRINT();
INT8U	FDL_RSAP_DEACTIVATE(INT8U t_ssap);

INT8U	FDL_SRD_SAP_PRINT( );

INT8U   FDL_SRD_SSAP_CREATE(INT8U t_ssap);


INT8U FDL_SC_respond();
void FDL_SRD_respond();

INT8U	FDL_SD1_Parse();