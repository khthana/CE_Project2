

#ifndef TASK_STK_SIZE

#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */

#endif

// Physical Layer Variable_name - PHY - FMA1/2 Interface
#define enabled 1
#define disabled 0
#define primary 0
#define alternate 1

 //#define phy_debug 1

void add_x( );

//extern char					Task_3_Data;     
//extern OS_STK			Task_3_Stk[TASK_STK_SIZE];

void  Task_3 ();


/* =============================================================*/
/* PHY - FMA1/2 Interface

The PHY Layer offers the following services to FMA1/2:
- Reset PHY
- Set Value PHY
- Read Value PHY
- Event PHY

*/

/* =============================================================*/
/* 1. Reset PHY

PHY_RESET.request
(    )
PHY_RESET.confirm
(    )

*/
INT8U PHY_RESET();

/* =============================================================*/
/*  2. Set Value PHY

PHY_SET_VALUE.request
(Variable_name, Desired_value)
PHY_SET_VALUE.confirm

*/

//INT8U PHY_SET_VALUE(INT8U Variable_name, INT8U Desired_value);

INT8U PHY_SET_VALUE_Transmitter_output(INT8U Desired_value);
INT8U PHY_SET_VALUE_Received_signal_source(INT8U Desired_value);
INT8U PHY_SET_VALUE_Loop(INT8U Desired_value);
/* =============================================================*/
/*  3 Read Value FDL

PHY_READ_VALUE.request
(Variable_name)
PHY_READ_VALUE.confirm
(Current_value)

Transmitter_output							enabled,disabled
Received_signal_source				primary,alternate
Loop														enabled,disabled

*/

//INT8U PHY_READ_VALUE(INT8U Variable_name);
INT8U PHY_READ_VALUE_Transmitter_output(  );
INT8U PHY_READ_VALUE_Received_signal_source(  );
INT8U PHY_READ_VALUE_Loop( );
/* =============================================================*/
/* 4. Event PHY

PHY_EVENT.indication
(Variable_name, New_value)

PHY Variables (Event)
Transmitter_output						disabled; enabled
Received_signal_source			primary; alternate

*/

INT8U PHY_EVENT();

/*
Transmitter_output						-> Transmitter Output									= enabled (indirect); disabled
Received_signal_source			-> Receiver Input											= primary (standard source = Bus a)
Loop													->The Transmitter Output is directed		= enabled; disabled
																to the Receiver Input and not to
																the Medium
*/


/* =============================================================*/
/* Interface between PHY and FDL
 1. 
PHY_DATA.request
(FDL_symbol)
*/
INT8U PHY_DATA_PUT(INT8U);

/*
2. 
PHY_DATA.indication
(FDL_symbol)

*/
INT8U PHY_DATA_GET();


