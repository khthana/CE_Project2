/*
***********************************************************************************************************************************
												Define Variable and Include file
**********************************************************************************************************************************
*/
#include "includes.h"
/*
***********************************************************************************************************************************
													Variable 
**********************************************************************************************************************************
*/
#define INSIZE 10
#define OUTSIZE 10
#define true 1
#define false 0

static unsigned int check = 0;
static unsigned char inbuf[INSIZE];
static unsigned char outbuf[OUTSIZE];
static buffer ch2_in , ch2_out;
void interrupt (*old_handler)();


/*
***********************************************************************************************************************************
													Initial Buffer
**********************************************************************************************************************************
*/
void InitBuffer(buffer *queue, char *buff , int size)
{	/* Initial Curcular Buffer  	*/
	queue->sem = OSSemCreate(0);
	queue->buff = buff;
	queue->bufsize = size;
	queue->empty = true;
	queue->full = false;
	queue->nchar = 0;
	queue->put = 0;
	queue->get = size - 1;
}
/*
***********************************************************************************************************************************
											Put Charecter In Buffer
**********************************************************************************************************************************
*/
int putChar(buffer *ch_out, int ch)
{	/* 	Put charecter in to Buffer If Buffer is full , block untill space is available.
	IF Buffer is empty start transmittion and enable the interrupt */
	unsigned char status;
	if (ch_out->get == ch_out->put)					// if buffer is full block untill space is available.
	{
		ch_out->full = true ;
		OSSemPend (ch_out->sem ,0, &status);
	}
	ch_out->buff[ch_out->put++] = (char) ch;			// put charector in buffer 
	ch_out->nchar++ ;											// increse number  in buffer
	if (ch_out->put >= ch_out->bufsize)
	{	
		ch_out->put = 0;										// wrap around
	}
	return ch; 
} 
/*
***********************************************************************************************************************************
													Send Charecter
**********************************************************************************************************************************
*/
void SendChar(buffer *ch_out)
{
	INT8U  err;
	unsigned char SPSTATRegister ;
	int buf_pntr = ch_out->get+1;

	if (buf_pntr >= ch_out->bufsize)
	{	
		buf_pntr = 0;											// wrap around
	}
	if (buf_pntr != ch_out->put)								// if buffer not empty send data to comport
	{	/* wait for ready to send */
		
		while(!inport(SPSTAT) & SPSTAT_THRE)
		{ }
		
		outport(SPTXD,ch_out->buff[buf_pntr]);
		
		while(!inport(SPSTAT) & SPSTAT_THRE)
		{ }
		ch_out->get = buf_pntr;								// point to next position
		ch_out->nchar--;

		if (ch_out->full &&((ch_out->bufsize - ch_out->nchar) > ch_out->bufsize/5))
		{	/* put data in buffer wait for 20% empty before unblocking  */
			ch_out->full = false;
			OSSemPost(ch_out->sem);						// unblock semaphore
		}
	}
}
/*
***********************************************************************************************************************************
												
**********************************************************************************************************************************
*/
int_putch(int ch)
{	/* Put charecter in buffer for trasmits to comport */
	int ret_ch;

	ret_ch = putChar(&ch2_out,ch);
	OS_ENTER_CRITICAL();
	if (ch2_out.empty)
	{	
		ch2_out.empty = false;		
	}
	SendChar(&ch2_out);											// start transmission and enable Transmit interupt
	OS_EXIT_CRITICAL();
	return ret_ch;
}

/*
***********************************************************************************************************************************
															Read Buffer
**********************************************************************************************************************************
*/
int_getch ()
{
	return getChar(&ch2_in);
}

/*
***********************************************************************************************************************************
															Get Charecter From Buffer
**********************************************************************************************************************************
*/
int getChar(buffer *ch_in)
{
	int buf_pntr = ch_in->get+1;
	unsigned char status;
	if (buf_pntr >= ch_in->bufsize)
	{
		buf_pntr = 0 ;
	}
	if (buf_pntr == ch_in->put)
	{
		ch_in->empty = TRUE;
		OSSemPend(ch_in->sem,0,&status);
	}
	
	ch_in->get = buf_pntr;
	ch_in->nchar--;

	return ch_in->buff[buf_pntr];
}
/*
***********************************************************************************************************************************
												Check Number Charecter
**********************************************************************************************************************************
*/
int CheckNum(buffer *ch_in)
{
	if (ch_in->get+1 != ch_in->put )
	{
		return 1;
	}
	else 
	{
		if (check == 1)
			check = 0;
		return 0;
	}
}
/*
***********************************************************************************************************************************
												Recieve Charecter 
**********************************************************************************************************************************
*/
int CheckInterrupt()
{
	if (check == 1)
	{
		if  (CheckNum(&ch2_in))
			return 1;
		else
			return 0;
	}
	else 
		return 0;
	
}
/*
***********************************************************************************************************************************
												Recieve Charecter 
**********************************************************************************************************************************
*/

void ReadISR(buffer *ch_in)
{
	INT8U  err;
	
	ch_in->buff[ch_in->put] = inport(SPRXD);
	if (++ch_in->put >= ch_in->bufsize)
	{	
		ch_in->put = 0;												// wrap around
	}
	ch_in->nchar++;
	if (ch_in->empty)
	{	
		ch_in->empty  = FALSE;
		OSSemPost(ch_in->sem);								// relase semaphor
	}

}
/*
***********************************************************************************************************************************
													Interupt Comport 2  Com86
**********************************************************************************************************************************
*/
void interrupt ISRComport(void)
{
	unsigned char SPSTATRegister;
	INT16U status;
	
	OSIntEnter();
	if (OSIntNesting == 1)
	{
		OSSaveSP();
	}
	status = inport(SPSTAT);
	if (status & SPSTAT_RDR)
	{
		check = 1;
		ReadISR(&ch2_in);
	}

	outport(SPSTAT,0x0000);
	outport(EOI,EOITYPE_UART);

	OSIntExit();
}

/*
***********************************************************************************************************************************
															Initial Comport (COM2)  For Com86
**********************************************************************************************************************************
*/
void InitComport (void)
{	
	InitBuffer(&ch2_in, inbuf , INSIZE );				// Set Initial Buffer
	InitBuffer(&ch2_out, outbuf , OUTSIZE );
		
	/*
		Setting up UART
	*/
	//outport(SPCON0,inport(SPCON0) & ~SPCON0_TMODE); 
	outport(SPCON0, 0x78) ;
	outport(SPBDV,0x1a);

	outport(SPCON1, inport(SPCON1)|SPCON1_TFEN|SPCON1_TFLUSH|SPCON1_RFEN|SPCON1_RFLUSH);
    outport(SPIMSK, inport(SPIMSK) | SPIMSK_RDR);
    outport(SPCON0, 0x0000 | SPCON0_TMODE | SPCON0_RXIE | SPCON0_RMODE | SPCON0_RSIE);


	/*
		Setting up Interrupt Controller
	*/
	old_handler = getvect(ITYPE_UART);
    setvect(ITYPE_UART, ISRComport);
    outport(SPSTAT, 0x0000);
    outport(CH11CON, inport(CH11CON) | CHCON_SRC_INTERNAL | CHCON_PR3);
    outport(IMASK, inport(IMASK) & ~IMASK_CH11);
}

/*
***********************************************************************************************************************************
																Return Comport
**********************************************************************************************************************************
*/
void ReturnComport(void)
{
	/*
     * Disable Interrupt Channel and Restore save interrupt handler
     */
    outport(IMASK, inport(IMASK) | IMASK_CH11);
    setvect(ITYPE_UART, old_handler);

}