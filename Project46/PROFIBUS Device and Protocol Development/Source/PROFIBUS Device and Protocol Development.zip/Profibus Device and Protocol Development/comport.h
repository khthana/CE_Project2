/*
*********************************************************************************************************
*                                   PC SUPPORT COMPORT FUNCTIONS
*********************************************************************************************************
*                                               CONSTANTS
*                                    RIGISTER VARIABLE FOR COMPORT ON PC
*
*		Description: These #defines are used in the Comport functions.  This register
*		define for comport1 if u want to use comport2 please check register for it.
*		and change variable register
*
*********************************************************************************************************
*/
typedef struct 
{
	OS_EVENT *sem;			// semaphor 
	int put , get , nchar ;		/* put  = position for put the new char , get = position for load char , 
										nchar = number of char in buffer */
	int bufsize;					// buffer size
	BOOLEAN  empty,full;				// check buffer ful or empty
	char *buff;
} buffer;

void InitComport (void);
int putChar(buffer *ch_out, int ch);
void ReadISR(buffer *ch_in);
void InitBuffer(buffer *queue, char *buff , int size);
void SendChar(buffer *ch_out);
int_putch(int ch);
void interrupt ISRComport(void);
void ReturnComport(void);
int_getch (void);
int getChar(buffer *ch_in);
int CheckInterrupt(void);
int CheckNum(buffer *ch_in);