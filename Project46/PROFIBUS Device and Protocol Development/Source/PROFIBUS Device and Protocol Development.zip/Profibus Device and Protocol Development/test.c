/* 
	directory 
	Z:\SOFTWARE\UCOS-II\NU_04\BC45\TEST

*/

#include "includes.h"
#include "phy.h"
#include "fdl.h"
#include "user.h"
#include "fma_1_2.h"
#include "ddlm.h"

#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */
#define  N_TASKS								10			/* Number of identical tasks                          */
#define MAX_RX_BUFFER				 512

#define          Q_SIZE         10      

#define TELEGRAM_SD1		0x10
#define TELEGRAM_SD2		0x68
#define TELEGRAM_SD3		0xA2
#define TELEGRAM_SD4		0xDC
#define TELEGRAM_SC		0xE5
#define TELEGRAM_ED		0x16


#define PLATFORM_COM86		1
//#define PLATFORM_PC				1

OS_STK			TaskStk[N_TASKS][TASK_STK_SIZE];        /* Tasks stacks                                  */
OS_STK			TaskStartStk[TASK_STK_SIZE];
char					TaskData[N_TASKS];                      /* Parameters to pass to each task               */

// Nu-07
OS_EVENT	*	PHY_GET;
OS_EVENT	*	PHY_GET_OK;
OS_EVENT	*	PHY_PUT;

OS_EVENT	*	ISR_PHY;

OS_EVENT	*	sem_printf;
OS_EVENT	*	aaaa;
OS_EVENT	*  e_event;
OS_EVENT	*	e_packet_rx_ready;
OS_EVENT	*	e_datagram_rx_ready;				// �� Datagram ������Ѻ���������
//OS_EVENT	*  e_datagram_rx_copy;					//
OS_EVENT	*	e_event_rx_int;

OS_EVENT        * MMM;
OS_EVENT        * TEST_TO_PHY;
OS_EVENT        *  PHY_TO_TEST;
OS_EVENT        * QQQ;     

OS_EVENT        * sem_rx_fdl_to_phy;			// FDL -> PHY
OS_EVENT        * sem_rx_phy_to_fdl;				// PHY -> FDL
OS_EVENT		*  fdl_event;

INT8U QQQ_buffer_tx[Q_SIZE];                    /*  queue                                */
void *QQQ_buffer[Q_SIZE];


// ���ͺ�ѧ��ѹ
// INT8U FDL_SRD_req(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class);

INT8U test_data_unit[10];
INT8U test_data_unit_len;



char					Task_1_Data;     
OS_STK			Task_1_Stk[TASK_STK_SIZE];
extern char					Task_2_Data;     
extern OS_STK			Task_2_Stk[TASK_STK_SIZE];

extern char					Task_3_Data;     
extern OS_STK			Task_3_Stk[TASK_STK_SIZE];

extern char					Task_4_Data;     
extern OS_STK			Task_4_Stk[TASK_STK_SIZE];

extern  char					Task_5_Data;     
extern OS_STK			Task_5_Stk[TASK_STK_SIZE];

extern char					Task_6_Data;     
extern OS_STK			Task_6_Stk[TASK_STK_SIZE];

char								Task_7_Data;     
OS_STK						Task_7_Stk[TASK_STK_SIZE];

extern char								Task_Module_1_Data;     
extern OS_STK						Task_Module_1_Data_Stk[TASK_STK_SIZE];

extern char								Task_Module_2_Data;     
extern OS_STK						Task_Module_2_Data_Stk[TASK_STK_SIZE];

extern char								Task_Module_3_Data;     
extern OS_STK						Task_Module_3_Data_Stk[TASK_STK_SIZE];

extern char								Task_Module_4_Data;     
extern OS_STK						Task_Module_4_Data_Stk[TASK_STK_SIZE];

OS_EVENT        * mbox_phy_data_rx;
OS_EVENT        * mbox_phy_data_rx_ok;
extern INT8U PHY_RX;
INT8U ISR_RX;
INT8U ISR_RX_BUFFER[MAX_RX_BUFFER];
INT16U ISR_RX_BUFFER_P;
INT16U ISR_RX_BUFFER_K;

extern void  print_user_status();
//	TELEFRAM_SD2 ttt;
/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/
 INT8U get_ready;

extern void add_x( );

void  TaskStart(void *data);                  /* Function prototypes of Startup task           */
 
			 void  Task_1 ();
extern void  Task_2 ();
extern void  Task_3 ();
extern void  Task_4 ();
extern void  Task_5 ();
extern void  Task_6 ();
			 void	Task_7 ();

extern void  Task_Module_1 ();
extern void  Task_Module_2 ();
extern void  Task_Module_3 ();
extern void	Task_Module_4 ();

			
extern void add_x( );

void  main (void)
{
	get_ready = 0;
	memset(&ISR_RX_BUFFER[0] , 0x00 , 200 );
	ISR_RX_BUFFER_P = 0;
	ISR_RX_BUFFER_K = 0;
//	PC_DispClrScr(DISP_FGND_WHITE + DISP_BGND_BLACK);      /* Clear the screen                         */
	
	printf(" Clear Screen \n");

 	printf(" OSInit \n");

/*
	Note: �������� main()
	1. OSInit();																// Initialize uC/OS-II                      
    2. PC_DOSSaveReturn();										// Save environment to return to DOS
    3. PC_VectSet(uCOS, OSCtxSw);                        // Install uC/OS-II's context switch vector 
	4. ���ҧ semaphore , OSSemCreate(1);
	5. ���ҧ task , OSTaskCreate(..............);
	6. ������ӧҹ , OSStart();  
*/

    OSInit();                                              /* Initialize uC/OS-II                      */

	#ifdef PLATFORM_PC
		PC_DOSSaveReturn();                                    /* Save environment to return to DOS        */
		PC_VectSet(uCOS, OSCtxSw);                             /* Install uC/OS-II's context switch vector */
	#endif

	#ifdef  PLATFORM_COM86
		COM86_DOSSaveReturn();                                 /* Save environment to return to DOS        */
		COM86_VectSet(uCOS, OSCtxSw);                          /* Install uC/OS-II's context switch vector */
	#endif

	printf(" OSTaskCreate ->TaskStart \n");

// 4. ���ҧ Semaphore

	sem_printf							= OSSemCreate(1);					 // printf semaphore            
	PHY_GET							= OSSemCreate(0);		
	PHY_GET_OK					= OSSemCreate(0);		

	PHY_PUT							= OSSemCreate(1);

	sem_rx_fdl_to_phy		= OSSemCreate(0);					 // Signal ->
	sem_rx_phy_to_fdl			= OSSemCreate(0);					 // Signal ->

	TEST_TO_PHY				= OSSemCreate(0);					 // Signal ->
	PHY_TO_TEST				= OSSemCreate(0);					 
	aaaa											= OSSemCreate(0);		
	e_packet_rx_ready			= OSSemCreate(0);		
	e_event								= OSSemCreate(0);		
	e_event_rx_int					= OSSemCreate(0);		

	ISR_PHY								= OSSemCreate(0);					// Signal ->
	fdl_event								= OSSemCreate(0);					// Signal ->
    mbox_phy_data_rx = OSMboxCreate((void *)0); 		//mailbox mbox_phy_data_rx

	e_datagram_rx_ready   = OSSemCreate(0);		

   MMM = OSMboxCreate((void *)0); 		//mailbox til pause tasken

//   mbox_phy_data_rx = OSMboxCreate((void *)0); 		//mailbox mbox_phy_data_rx

	QQQ    = OSQCreate(&QQQ_buffer[0], Q_SIZE);          /* Keyboard queue                           */

   mbox_phy_data_rx = OSMboxCreate((void *)0); 		//mailbox mbox_phy_data_rx
	mbox_phy_data_rx_ok = OSMboxCreate((void *)0); 		//mailbox mbox_phy_data_rx
// 5. Initial Status


	// Profibus Reset Function





    OSTaskCreate(TaskStart		, (void *)0										, &TaskStartStk[TASK_STK_SIZE - 1]								, 3					);
	printf(" OSTaskCreate ->Task_Start \n");

								// ���Ϳѧ��ѹ  		  char												  OS_STK			Task_1_Stk[TASK_STK_SIZE];				 priority

	OSTaskCreate(Task_1			, (void *)&Task_1_Data			, &Task_1_Stk[TASK_STK_SIZE - 1]									, 4					);
	printf(" OSTaskCreate ->Task_1 \n");

	OSTaskCreate(Task_2			, (void *)&Task_2_Data			, &Task_2_Stk[TASK_STK_SIZE - 1]									, 5					);
	printf(" OSTaskCreate ->Task_2 \n");

	OSTaskCreate(Task_3			, (void *)&Task_3_Data			, &Task_3_Stk[TASK_STK_SIZE - 1]									, 6					);
	printf(" OSTaskCreate ->Task_3 \n");

	OSTaskCreate(Task_4			, (void *)&Task_4_Data			, &Task_4_Stk[TASK_STK_SIZE - 1]									, 7					);
	printf(" OSTaskCreate ->Task_4 \n");

	OSTaskCreate(Task_5			, (void *)&Task_5_Data			, &Task_5_Stk[TASK_STK_SIZE - 1]									, 8					);
	printf(" OSTaskCreate ->Task_5 \n");

	OSTaskCreate(Task_6			, (void *)&Task_6_Data			, &Task_6_Stk[TASK_STK_SIZE - 1]									, 9					);
	printf(" OSTaskCreate ->Task_6 \n");

	OSTaskCreate(Task_7			, (void *)&Task_7_Data			, &Task_7_Stk[TASK_STK_SIZE - 1]									, 10					);
	printf(" OSTaskCreate ->Task_7 \n");

	OSTaskCreate(Task_Module_1			, (void *)&Task_Module_1_Data			, &Task_Module_1_Data_Stk[TASK_STK_SIZE - 1], 11 );
	printf(" OSTaskCreate ->Task_Module_1_Data \n");
	OSTaskCreate(Task_Module_2			, (void *)&Task_Module_2_Data			, &Task_Module_2_Data_Stk[TASK_STK_SIZE - 1], 12 );
	printf(" OSTaskCreate ->Task_Module_2_Data \n");
	OSTaskCreate(Task_Module_3			, (void *)&Task_Module_3_Data			, &Task_Module_3_Data_Stk[TASK_STK_SIZE - 1], 13 );
	printf(" OSTaskCreate ->Task_Module_3_Data \n");
	OSTaskCreate(Task_Module_4			, (void *)&Task_Module_4_Data			, &Task_Module_4_Data_Stk[TASK_STK_SIZE - 1], 14 );
	printf(" OSTaskCreate ->Task_Module_4_Data \n");

	printf(" OSStart \n");

	#ifdef  PLATFORM_PC
		OS_ENTER_CRITICAL();
		PC_VectSet(0x08, OSTickISR);                           /* Install uC/OS-II's clock tick ISR        */
		PC_SetTickRate(OS_TICKS_PER_SEC);                      /* Reprogram tick rate                      */
		OS_EXIT_CRITICAL();
	#endif

	#ifdef  PLATFORM_COM86
		OS_ENTER_CRITICAL();
		COM86_VectSet(0x08, OSTickISR);                        /* Install uC/OS-II's clock tick ISR        */
		COM86_SetTickRate(OS_TICKS_PER_SEC);                   /* Reprogram tick rate                      */
		OS_EXIT_CRITICAL();
	#endif

	OSStart();                                             /* Start multitasking                       */

/*
	Note : 
		OSStart();		��� �ѧ��ѹ������������ӧҹẺ Multitasking , task ����� Create ����������ӧҹ
*/

}


/*
*********************************************************************************************************
*                                              STARTUP TASK
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{

#if OS_CRITICAL_METHOD == 3                                /* Allocate storage for CPU status register */
    OS_CPU_SR  cpu_sr;
#endif
    char       s[100];
    INT16S     key;
	INT8U  err;
	INT8U  * mDATA;
    pdata = pdata;                                         /* Prevent compiler warning                 */


//    OS_ENTER_CRITICAL();
//    PC_VectSet(0x08, OSTickISR);                           /* Install uC/OS-II's clock tick ISR        */
//    PC_SetTickRate(OS_TICKS_PER_SEC);                      /* Reprogram tick rate                      */
//    OS_EXIT_CRITICAL();

 //   OSStatInit();                                          /* Initialize uC/OS-II's statistics         */


    while ( 1)
	{
		//		mDATA = (INT8U*) OSMboxPend(MMM, 0, &err);
		//		printf("MMM = %d %d \n",err,*mDATA);
//			OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 

			// .......... ���价� critical section
//			printf(" Task Start \n");

//			OSSemPost(sem_printf);											// Release semaphore               
 
	 		OSTimeDlyHMSM(0, 0, 20,0);                         /* Wait one second                          */
  
	}
}
/*
*********************************************************************************************************
*                                           UPDATE THE DISPLAY
*********************************************************************************************************
*/

/*$PAGE*/
/*
*********************************************************************************************************
*                                             CREATE TASKS
*********************************************************************************************************
*/
/*
static  void  TaskStartCreateTasks (void)
{
    INT8U  i;


    for (i = 0; i < N_TASKS; i++) {                        // Create N_TASKS identical tasks           
        TaskData[i] = '0' + i;                             // Each task will display its own letter    
        OSTaskCreate(Task, (void *)&TaskData[i], &TaskStk[i][TASK_STK_SIZE - 1], i + 1);
    }
}
*/

/*
*********************************************************************************************************
*                                                  TASKS
*********************************************************************************************************
*/



void  Task_1 ()
{
	INT8U  err,i;
	INT8U  state;
	INT8U testtest;
	INT8U t_ssap;
	char x;
	//INT8U dddd[3] = { 'a','b','c'};
 	x = 0x00;
	state = 0;
	testtest = 99;
	 t_ssap = 0;
	while ( 1 )
	{
			// .......... ���价� critical section
			if ( state == 0)
			{
				OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
				printf("T1- Input : ");
				OSSemPost(sem_printf);											// Release semaphore               
				state = 1;
			}


  	
			 x = 0x00;
			if (kbhit()) 
			{
					x = getche();
					
					OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
					printf("\n");
					OSSemPost(sem_printf);											// Release semaphore               

		 			state = 0;
			 }  

            if (x == 0x1B || x == 'q' ) {                             /* Yes, see if it's the ESCAPE key          */

		//			


#ifdef  PLATFORM_PC
			ReturnComport();
			PC_DOSReturn();                            /* Return to DOS                            */
#endif

#ifdef  PLATFORM_COM86
			ReturnComport();
			COM86_DOSReturn();                         /* Return to DOS                            */
#endif


            }

            if (x == 'a') {                             /* Yes, see if it's the ESCAPE key          */
				OSSemPost(aaaa);			
            }

            if (x == 'a') {                             /* Yes, see if it's the ESCAPE key          */

				OSSemPost(aaaa);			
            }
            if (x == 's') {                             /* Yes, see if it's the ESCAPE key          */

				print_user_status();	
            }
            if (x == 'e') {                             /* Yes, see if it's the ESCAPE key          */

				OSSemPost(e_event);			
				x = 0x00;

            }

            if (x == 'z') {                         
					FDL_SAP_ACTIVATE_PRINT();
            }

            if (x == '[') {                        
					// INT8U	FDL_SAP_ACTIVATE( INT8U t_ssap,INT8U t_access, INT8U t_service_activate,INT8U role_in_service );
					FDL_SRD_SAP_PRINT();

            }
            if (x == ']') {                         
					FDL_RSAP_ACTIVATE_PRINT();
            }
            if (x == 'v') {                         
					FDL_SAP_DEACTIVATE(2);

            }
									

//INT8U SDN_put(INT8U SSAP,INT8U DSAP,INT8U Rem_add,INT8U Serv_class,INT8U * data_unit,INT8U data_length)

            if (x == 'f') {                            // TEST FDL SDN

					test_data_unit_len = 10;
					for (i=0;i<test_data_unit_len ; i++)
					{
						test_data_unit[i] = 'a'+i;
					}
// INT8U FDL_SRD_req(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class);
					FDL_SRD_req(0,0,0x07,&test_data_unit[0],test_data_unit_len,1);

					FDL_SDN_put(0,0,0x08,&test_data_unit[0],test_data_unit_len,1);
            }

		   if (x == 'i') 
			{         
					test_data_unit_len = 10;
					for (i=0;i<test_data_unit_len ; i++)
					{
						test_data_unit[i] = 'a'+i;
					}
					FDL_SRD_req(61,60,0x07,&test_data_unit[0],test_data_unit_len,1);
			}
		   if (x == '3') 
			{         
					test_data_unit_len = 10;
					for (i=0;i<test_data_unit_len ; i++)
					{
						test_data_unit[i] = 'a'+i;
					}
					FDL_SDN_put(55,55,0x08,&test_data_unit[0],0,1);

			}

		   if (x == '1') 
			{         
					test_data_unit_len = 10;
					for (i=0;i<test_data_unit_len ; i++)
					{
						test_data_unit[i] = '0'+i;
					}
					FDL_SRD_REPLY_UPDATE( 61 , &test_data_unit[0],test_data_unit_len, Serv_Class_High , Transmit_Multi );
			}

		   if (x == '2') 
			{         
					test_data_unit_len = 10;
					for (i=0;i<test_data_unit_len ; i++)
					{
						test_data_unit[i] = 'a'+i;
					}
					FDL_SRD_req(56	 ,55	,0x07,&test_data_unit[0],test_data_unit_len,1);
			}

			OSTimeDly(100);                            /* Delay 1 clock tick                                 */

    }
}


/*
	Note : 	�ѧ�ѹ������Ѻ������ҧ �ա����ҹ�� 2 �ѧ��ѹ���  

	1. OSTaskCreate( void (*task)(void * pd)	 ,	void *pdata		, OS_TSK * ptos			, INT8U prio		);
		��� �ѧ�ѹ������Ѻ������ҧ Task ���� ( Creating Task )

	2. OSTaskCreateEXT()

	����Ѻ Priority �ͧ task �е�ͧ�դ�������ҡѹ�ء task
*/

/*
	Note: 	�����ҹ semaphore
	
	1. ��С�� pointer �ͧ sem ��� global
		->  
				OS_EVENT    *RandomSem;
	2. ���ҧ (create) Sem ����Ҵ��¿ѧ��ѹ OSSemCreate(1) ���� main()
		->
				RandomSem   = OSSemCreate(1);					 // Random number semaphore                  

	3. �����ҹ semaphore ���� task �����
		->
				void task()
				{
					INT8U  err;

					while(1)
					{
						OSSemPend(RandomSem, 0, &err);							// Acquire semaphore to perform random numbers 

						// .......... ���价� critical section
						x = random(80);																	// Find X position where task number will appear     
						y = random(16);																	// Find Y position where task number will appear  
						
						OSSemPost(RandomSem);											// Release semaphore                                 
					}			
				}
*/


BOOLEAN check_p_k()
{
	if ( ISR_RX_BUFFER_P < (MAX_RX_BUFFER-1))   // 0 to 511
	{
		if ( ISR_RX_BUFFER_P+1 == ISR_RX_BUFFER_K )
		{	
			return 1;		// stop
		}
		else
		{
			return 0;	    // fecth
		}
	}
	else	 // P=0 , K = 511 
	{
		if ( ISR_RX_BUFFER_P == 0  && ISR_RX_BUFFER_K == 511)
		{	
			return 1;		// stop
		}
		else
		{
			return 0;	    // fecth
		}	
	}



}

void  Task_7 ()
{
	INT8U  err;
	INT8U phy_data_rx, * phy_data_rx_ok;

	   while(1)
		{
					if ( ISR_RX_BUFFER_P == ISR_RX_BUFFER_K )
					{
						 OSTimeDly(5);                            /* Delay 1 clock tick                                 */
					}
					else
					{
						phy_data_rx = ISR_RX_BUFFER[ISR_RX_BUFFER_K];
 //					 printf("%X \n",phy_data_rx);
						ISR_RX_BUFFER_K++ ;
						if ( ISR_RX_BUFFER_K > MAX_RX_BUFFER-1)
						{
							ISR_RX_BUFFER_K = 0;
						}

						ISR_RX = phy_data_rx;
						OSSemPost(PHY_GET);											// Release semaphore   
 						OSSemPend(PHY_GET_OK, 0, &err);							// Acquire semaphore 

					}

		
		

		}
}
