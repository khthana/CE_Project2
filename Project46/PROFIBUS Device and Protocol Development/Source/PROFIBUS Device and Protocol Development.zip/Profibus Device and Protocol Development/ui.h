// 
// Profibus DP 
// 

#ifndef TASK_STK_SIZE
#define  TASK_STK_SIZE                 1024		/* Size of each task's stacks (# of WORDs)            */
#endif



#define ui_debug 1
#define STATE_POWER_ON			1
#define STATE_WAIT_PRM			2
#define STATE_WAIT_CFG			3
#define STATE_DATA_EXCH			4
#define STATE_FREEZE				5
#define STATE_CLEAR					6

#define Length_Diag 6
#define Invalid 0x0FF
#define DP_SLAVE_Real_Cfg_Data_len_const 2
#define DP_SLAVE_Output_L_len_const 2
#define DP_SLAVE_Output_D_len_const 2
#define DP_SLAVE_INPUT_D_len_const 2
#define DP_SLAVE_Periphery_Inp_len_const 2 

void ui_state ( );
void  ui_state_power_on ();
void  ui_state_wait_prm ();
void  ui_state_wait_cfg ();
void  ui_state_data_exch ();
void  ui_state_freeze ();
void  ui_state_clear ();

extern void DDLM_Set_Prm_ind (  );
extern void DDLM_Chk_Cfg_ind (  );
extern void DDLM_Data_Exchange_ind (  );
extern void DDLM_Slave_Diag_ind (  );
extern void DDLM_Global_Control_ind (  );
extern void DDLM_Set_Slave_ind (  );

extern INT8U DDLM_Slave_Init (INT8U Station_Address);
extern INT8U DDLM_Enter_req (INT8U Master_Add	);
extern INT8U DDLM_Leave_req( );
extern INT8U DDLM_Set_minTsdr (INT16U minTSDR);
// SSAP = 0
extern INT8U DDLM_Data_Exchange_Upd_req(BOOLEAN Diag_Flag,INT8U * Inp_Data ,INT8U Inp_Data_len );
// SSAP = 60
extern INT8U DDLM_Slave_Diag_Upd_req( INT8U * Diag_Data ,INT8U Diag_Data_len );
// SSAP = 59
extern INT8U DDLM_Get_Cfg_Upd_req( INT8U * Real_Cfg_Data ,INT8U Real_Cfg_Data_len );
// SSAP = 57
extern INT8U DDLM_RD_Outp_Upd_req( INT8U * Outp_Data ,INT8U Outp_Data_len );
// SSAP = 56
extern INT8U DDLM_RD_Inp_Upd_req( INT8U * Inp_Data ,INT8U Inp_Data_len );

typedef struct 
{
// Octet 1: Station_status_1
BOOLEAN Master_Lock;
BOOLEAN Prm_Fault;
BOOLEAN Invalid_Slave_Response;
BOOLEAN Not_Supported;
BOOLEAN Ext_Diag;
BOOLEAN Cfg_Fault;
BOOLEAN Station_Not_Ready;
BOOLEAN Station_Non_Existent;

// Octet 2: Station_status_2
BOOLEAN Deactivated;
BOOLEAN B_2_6;
BOOLEAN Sync_Mode;
BOOLEAN Freeze_Mode;
BOOLEAN WD_On;
BOOLEAN B_2_2;
BOOLEAN Stat_Diag;
BOOLEAN Prm_Req;

// Octet 3: Station_status_3
BOOLEAN Ext_Diag_Overflow;
BOOLEAN B_3_6;
BOOLEAN B_3_5;
BOOLEAN B_3_4;
BOOLEAN B_3_3;
BOOLEAN B_3_2;
BOOLEAN B_3_1;
BOOLEAN B_3_0;

//Octet 4: Master_Add
INT8U		Master_Add;

//Octet 5 to 6 (unsigned16): Ident_Number
INT16U		Ident_Number;

}  STD_Diag;