// 
// Profibus DP 
// 
#include "includes.h"
#include "fdl.h"
#include "phy.h"
#include "ddlm.h"
#include "user.h"
#include "ui.h"


INT8U Periphery_1 (void);
void Periphery_2 (INT8U Value);
INT8U Periphery_3 (void);
void  Periphery_4 (INT8U Value);


void  Task_Module_1 ();
void  Task_Module_2 ();
void  Task_Module_3 ();
void  Task_Module_4 ();

char								Task_Module_1_Data;     
OS_STK						Task_Module_1_Data_Stk[TASK_STK_SIZE];

char								Task_Module_2_Data;     
OS_STK						Task_Module_2_Data_Stk[TASK_STK_SIZE];

char								Task_Module_3_Data;     
OS_STK						Task_Module_3_Data_Stk[TASK_STK_SIZE];

char								Task_Module_4_Data;     
OS_STK						Task_Module_4_Data_Stk[TASK_STK_SIZE];


void  Task_Module_1 ()
{
		INT8U  err;
		INT8U  value;
	   while(1)
		{
			value = Periphery_1();
//			printf(" Task_Module_1	 -->	Sensor		%d \n", value);

	        OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
		}
}

void  Task_Module_2 ()
{
		INT8U  err;
		INT8U  value;
		
	   while(1)
		{
			value = 30 + rand() % 5;
//			printf(" Task_Module_2	 -->	Tempurater	%d  \n",value );
			Periphery_2 (value);
	        OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
		}
}

void  Task_Module_3 ()
{
		INT8U  err;
		INT8U  value;

	   while(1)
		{
			value = Periphery_3();
//			printf(" Task_Module_3	 -->	Sensor		%d\n", value);
	        OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
		}
}

void  Task_Module_4 ()
{
		INT8U  err;
		INT8U  value;

	   while(1)
		{
				value = 10 + rand() % 5;
	//			printf(" Task_Module_4	 -->	Voltage		%d\n",value );
				Periphery_4 (value);
				OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
		}
}

INT8U Periphery_1 ()
{
	return (Read_Output (Module_1));
}

void Periphery_2 (INT8U Value)
{
	Send_Input (Module_2, Value);
}

INT8U Periphery_3 ()
{
	return (Read_Output (Module_3));
}

void  Periphery_4 (INT8U Value)
{
	Send_Input (Module_4, Value);
}



