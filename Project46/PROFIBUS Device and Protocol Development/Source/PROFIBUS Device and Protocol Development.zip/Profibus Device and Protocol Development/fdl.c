#include <stdio.h>
#include "includes.h"
#include "fdl.h"
#include "phy.h"

extern  OS_EVENT  * MMM;
extern OS_EVENT	*	sem_printf;
extern OS_EVENT	* mbox_phy_data_rx;
extern OS_EVENT	* sem_rx_fdl_to_phy;
extern OS_EVENT	* sem_rx_phy_to_fdl;
extern OS_EVENT		*  fdl_event;
extern INT8U PHY_RX;

char					Task_6_Data;     
OS_STK			Task_6_Stk[TASK_STK_SIZE];
//OS_STK			Task_6_Stk[2048];
INT8U							fdl_state ;				// State of RX FDL

INT8U fdl_data_rx_telegram_index;							// Index to RX Telegram
INT8U fdl_data_rx_all;														// All length
INT8U fdl_data_rx_telegram[MTU_RX];					// RX Telegram

TELEFRAM_SD2		telegram_rx;
INT8U phy_data_rx;

FDL_VAR					FDL_VARIABLE;
//FDL_SSAP					SSAP[10];
FDL_SSAP					FDL_SRD_SSAP[10];



INT8U	EVENT_SRD_indication;

INT8U	EVENT_SDN_indication;

// SSAP control
SAP_ACTIVATE_LIST * db_sap_activate;
RSAP_ACTIVATE_LIST * db_rsap_activate;
FDL_SRD_SSAP_LIST * db_srd_ssap_list;
void  Task_6 ()
{
	INT8U  err;

	fdl_state = 0;
	while ( 1 )
	{
 				OSSemPend(sem_rx_phy_to_fdl, 1000, &err);						

				if (err == OS_NO_ERR) 
				{
						phy_data_rx = PHY_RX;

//				OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
#ifdef  fdl_debug		
 //						printf(">FDL phy_data_rx = %x \n",phy_data_rx);
#endif 						
//				OSSemPost(sem_printf);											// Release semaphore          
 
						FDL_parse_telegram( phy_data_rx);


				}
				else 
				{
						fdl_state = 0;

//				OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
						printf(" %d Time out Reset State \n",err);
//				OSSemPost(sem_printf);											// Release semaphore       

				}
    }
}





void FDL_parse_telegram( INT8U phy_data_rx)
{
		INT8U	err;
		INT8U i,checksum;	
  	
#ifdef  fdl_debug		
 		printf(" %d FDL fdl parse = %x \n",fdl_state,phy_data_rx);
#endif 						

		if ( fdl_state == 0 )
		{
						switch (fdl_state) 
						{
								//------------------------------------------------------------------------------------------------------------------
								case 0: //  state = 0 Start State (reset state)
								{
										memset(fdl_data_rx_telegram,0x00,sizeof(fdl_data_rx_telegram));
										fdl_data_rx_telegram_index =0;
										fdl_data_rx_all =0;
										fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
										fdl_data_rx_telegram_index++;

										switch (phy_data_rx) 
										{


											case TELEGRAM_SD1:
											{
												// -> next state fdl_state = 10; 
												fdl_state = 10;
											}
											break;
											case TELEGRAM_SD2:
											{
												// -> next state fdl_state = 20; 
												fdl_state = 19;
											}
											break;
											case TELEGRAM_SD3:
											{
												// -> next state fdl_state = 30; 
												fdl_state = 30;
											}
											break;
											case TELEGRAM_SD4:
											{
												// -> next state fdl_state = 40; 
												fdl_state = 40;
											}
											break;

											case TELEGRAM_SC:
											{
												// fdl_state -  End State (next state)
												fdl_state = 85;
											}
											break;

											default:
											{
												// fdl_state -  Start State (reset state)
												fdl_state = 0;
											}
											break;
										} // switch (phy_data_rx) 
								}
								break; //  state = 0 Start State (reset state)

						} // 				switch (fdl_state) 
		}
		else
		if ( fdl_state < 15 )
		{
						switch (fdl_state) 
						{
								//--- + SD1---------------------------------------------------------------------------------------------------------------
								case 10: //  state = 10 - DA
								case 11: //  state = 11 - SA
								case 12: //  state = 12 - FC
								case 13: //  state = 13 - FCS
								{
										fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
										fdl_data_rx_telegram_index++;

										// Next State
										fdl_state++;
								}
								break; //  state = 10 - 13

								case 14: //  state = 14 - ED
								{
										if(phy_data_rx == 0x16)
										{
											fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
											fdl_data_rx_telegram_index++;

											fdl_data_rx_all = fdl_data_rx_telegram_index;
											fdl_state = 81;				// End SD1
										}	
										else
										{
											fdl_state = 91;			
										}
								}
								break; //  state = 14 - ED
								//--- - SD1---------------------------------------------------------------------------------------------------------------
						} // 				switch (fdl_state) 
		}
		else
		if ( fdl_state < 30 )
		{
						switch (fdl_state) 
						{
								//--- + SD2---------------------------------------------------------------------------------------------------------------
								case 19:  // SD2 state = 19 -  LE
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												fdl_state = 20;
								}
								break; // SD2 state = 19 -  LE

								case 20:  // SD2 state = 20 -  LEr
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;
												
												if ( fdl_data_rx_telegram[1] == fdl_data_rx_telegram[2] )
												{
														fdl_state = 21;
												}
												else
												{
														fdl_state = 90;			// error
												}
												
								}
								break; // SD2 state = 20 -  LEr

								case 21:  // SD2state = 21 - SD2
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												// Next State
												fdl_state++;
								}
								break; // SD2state = 21 - SD2

								case 22:  // SD2state = 22 - DA
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												// Next State
												if ( (phy_data_rx & 0x80) == 0x80 )
												{
													fdl_state++;
												}
												else
												{	
													fdl_state = 53;
												}
								}
								break; // SD2state = 22 - 26  DA

								case 23:  // SD2state = 23 - SA
								case 24:  // SD2state = 24 - FC
								case 25:  // SD2state = 25 - DSAP
								case 26:  // SD2state = 26 - SSAP
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												// Next State
												fdl_state++;
								}
								break; // SD2state = 23 - 26  SD2 DA SA FC DSAP SSAP

								case 27:  // SD2state = 27 - Data Unit
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												if ( (fdl_data_rx_telegram[1]+5) == (fdl_data_rx_telegram_index) )
												{
															//printf("x29 %d \n",fdl_data_rx_telegram_index);
															fdl_state = 29;
												}
												else
												if ( (fdl_data_rx_telegram[1]+4) == (fdl_data_rx_telegram_index) )
												{
														if ( fdl_data_rx_telegram[1] == 5)
														{
															//printf(" 29 %d \n",fdl_data_rx_telegram_index);
															fdl_state = 29;
														}
														else
														if ( fdl_data_rx_telegram[1] > 5)
														{
															//printf(" 28 %d \n",fdl_data_rx_telegram_index);
															fdl_state = 28;	
														}
												}
												else	
												{
													//printf(" 27 %d \n",fdl_data_rx_telegram_index);
													fdl_state = 27;
												}

								}
								break; // SD2state = 27 - Data Unit

								case 28: //  state = 28 - FCS
								{
										fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
										fdl_data_rx_telegram_index++;

										// Next State
										fdl_state = 29;			
								}
								break; //  state = 28 - FCS

								case 29: //  state = 29 - ED
								{
										if(phy_data_rx == 0x16)
										{
											fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
											fdl_data_rx_telegram_index++;

											fdl_data_rx_all = fdl_data_rx_telegram_index;
											fdl_state = 82;				// End SD2
										}	
										else
										{
											fdl_state = 91;			
										}

								}
								break; //  state = 29 - ED
								//--- - SD2---------------------------------------------------------------------------------------------------------------
						} // 				switch (fdl_state) 
		}
		else
		if ( fdl_state < 36 )
		{
						switch (fdl_state) 
						{
								//--- + SD3---------------------------------------------------------------------------------------------------------------
								case 30:  // state = 30 - DA
								case 31:  // state = 31 - SA
								case 32:  // state = 32 - FC
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												fdl_state++;
								}
								break; // state = 30 - 32

								case 33:  // state = 33 - DU
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												if ( fdl_data_rx_telegram_index == 12 )
												{
													fdl_state = 34;
												}
												else
												{
													fdl_state = 33;
												}
								}
								break; // state = 33

								case 34: //  state = 34 - FCS
								{
										fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
										fdl_data_rx_telegram_index++;

										fdl_state = 35;				
								}
								break; //  state = 28 - FCS

								case 35: //  state = 35 - ED
								{

										if(phy_data_rx == 0x16)
										{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												fdl_data_rx_all = fdl_data_rx_telegram_index;
												fdl_state = 83;				// End SD3
										}	
										else
										{
												fdl_state = 91;			
										}
								}
								break; //  state = 35 - ED
								//--- - SD3---------------------------------------------------------------------------------------------------------------
						} // 				switch (fdl_state) 
		}
		else
		if ( fdl_state < 43 )
		{
						switch (fdl_state) 
						{
								//--- + SD4---------------------------------------------------------------------------------------------------------------
								case 40:  // state = 30 - DA
								case 41:  // state = 30 - SA
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												if ( fdl_data_rx_telegram_index == 3 )
												{
													fdl_state = 42;
												}
												else
												{
													fdl_state++;
												}
								}
								break; // state = 30 - 33

								case 42: //  state = 42 - ED
								{

										if(phy_data_rx == 0x16)
										{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												fdl_data_rx_all = fdl_data_rx_telegram_index;
												fdl_state = 84;				// End SD4
										}	
										else
										{
												fdl_state = 91;			
										}
								}
								break; //  state = 42 - ED
								//--- - SD4---------------------------------------------------------------------------------------------------------------
						} // 				switch (fdl_state) 
		}
		else
		if ( fdl_state < 58 )
		{
						switch (fdl_state) 
						{
								//--- - SD2- Type no DSAP, SSAP ----------------------------------------------------------------------------
								case 53:  // SD2state = 23 - SA
								case 54:  // SD2state = 24 - FC
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												// Next State
												fdl_state++;
								}
								break; // SD2state = 53 - 54  SA FC 

								case 55:  // SD2state = 25 - Data Unit
								{
												fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
												fdl_data_rx_telegram_index++;

												if ( (fdl_data_rx_telegram[1]+5) == (fdl_data_rx_telegram_index) )
												{
															fdl_state = 57;
												}
												else
												if ( (fdl_data_rx_telegram[1]+4) == (fdl_data_rx_telegram_index) )
												{
													fdl_state = 56;
												}
												else
												{
													fdl_state = 55;
												}
								}
								break; // SD2state = 55 - Data Unit

								case 56: //  state =56 - FCS
								{
										fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
										fdl_data_rx_telegram_index++;

										fdl_state = 57;				
								}
								break; //  state = 56 - FCS

								case 57: //  state =57 - ED
								{
										if(phy_data_rx == 0x16)
										{
											fdl_data_rx_telegram[fdl_data_rx_telegram_index] = phy_data_rx;
											fdl_data_rx_telegram_index++;

											fdl_data_rx_all = fdl_data_rx_telegram_index;
											fdl_state = 86;				// End SD2
										}	
										else
										{
											fdl_state = 91;			
										}

								}
								break; //  state =57 - ED
								//--- - SD2- Type no DSAP, SSAP ----------------------------------------------------------------------------
						} // 				switch (fdl_state) 
		}
		else
		{
						fdl_state = 0;

						#ifdef  fdl_debug		
						OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
						printf(" Reset State - Out of state \n");
						OSSemPost(sem_printf);											// Release semaphore  
						#endif 		

		}  // B-Tree


						switch (fdl_state) 
						{
								//------------------------------------------------------------------------------------------------------------------
								case 81: 
								{
										fdl_state = 0;
#ifdef  fdl_debug		
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SD1 \n ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		
										checksum = 0 ;
										for (i=1;i<4;i++)
										{
											checksum = checksum + fdl_data_rx_telegram[i];
										}

										printf("checksum = %02X  %02X\n",checksum, fdl_data_rx_telegram[4]);
										if ( checksum != fdl_data_rx_telegram[4])
										{
											printf(" error code : bad checksum  \n");
										}
										FDL_SD1_Parse();
								}
								break; //  state = 42 - ED

								case 82: 
								{

										fdl_state = 0;
#ifdef  fdl_debug		
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SD2 ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		
										checksum = 0 ;
										for (i=4;i<fdl_data_rx_all-2;i++)
										{
											checksum = checksum + fdl_data_rx_telegram[i];
										}
#ifdef  fdl_debug		
										printf("checksum = %02X  %02X\n",checksum, fdl_data_rx_telegram[fdl_data_rx_all-2]);
										if ( checksum != fdl_data_rx_telegram[fdl_data_rx_all-2])
										{
											printf(" error code : bad checksum \n");
										}
#endif
 										//FDL_indication_82_86();
										FDL_SD2_Parse();
								}
								break;

								case 83:
								{
										fdl_state = 0;
#ifdef  fdl_debug		
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SD3 ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		

								}
								break;
								case 84:
								{
										fdl_state = 0;
#ifdef  fdl_debug		
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SD4 ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		

								}
								break;
								case 85:
								{
										fdl_state = 0;
										fdl_data_rx_all = 1;
#ifdef  fdl_debug								 
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SC ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		
								}
								break;

								case 86: 
								{
										fdl_state = 0;
#ifdef  fdl_debug		
										OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
										printf(" SD2 - type 2\n ");
										printf("Revieve = %d",fdl_data_rx_all);
										for ( i=0;i<fdl_data_rx_all;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",fdl_data_rx_telegram[i]);
										}
										printf("\n");
										OSSemPost(sem_printf);											// Release semaphore  
#endif 		
										checksum = 0 ;
										for (i=4;i<fdl_data_rx_all-2;i++)
										{
											checksum = checksum + fdl_data_rx_telegram[i];
										}
#ifdef  fdl_debug		
										printf("checksum = %02X  %02X\n",checksum, fdl_data_rx_telegram[fdl_data_rx_all-2]);
										if ( checksum != fdl_data_rx_telegram[fdl_data_rx_all-2])
										{
											printf(" error code : bad checksum  \n");
										}
#endif
										//FDL_indication_82_86();
										FDL_SD2_Parse();
								}
								break;

								case 90:  // error LE != LEr
								{
												fdl_state = 0;
#ifdef  fdl_debug	
												printf(" error code : LE != LEr \n");
#endif 		
								}
								break; // rror LE != LEr
								case 91:  // error LE != LEr
								{
											fdl_state = 0;
#ifdef  fdl_debug	
												printf(" error code : LE > Real Data\n");
#endif 		
									}
								break; // rror LE != LEr

						} // 				switch (fdl_state) 
 // =====================================================================================
  					OSSemPost(sem_rx_fdl_to_phy);											// Signal PHY_INDICATE
		/* 
			SD1	DA	SA	FC	FCS	ED
			10h		xx	xx	x		x			16H

			SD2	LE	LEr	SD2	DA	SA	FC	DSAP	SSAP	DU					FCS	ED	
			68H	xx	xx	68H	xx	xx	x		xx			xx			x.......x				x			16H

			SD3	DA	SA	FC	DU			FCS	ED
			A2H	xx	xx	x		x........x	x			16H
			
			SD4	DA	SA	ED
			DCH	xx	xx	16H

			SC
			E5H
		*/

}


INT8U FDL_SDN_put(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class)
{
	INT8U L_status;
	INT8U telegram_tx[MTU_TX];
	INT8U telegram_tx_len;
	INT8U i,j;
	INT8U checksum;	
	

	// create telegram
	// 1. SD2
	telegram_tx[0] = 0x68;														// SD2
	telegram_tx[3] = 0x68;														// SD2
	// 2. DA - Destination Address
	telegram_tx[4] = SRD_Rem_add;											// DA
	// 3. SA - Source Address = This Address = FDL_VARIABLE.FDL_TS
	telegram_tx[5] = FDL_VARIABLE.FDL_TS;						// SA

	// 4. FC
	telegram_tx[6] = 0x00;

	// 4.1 ��鹡Ѻ��Դ Station , req-respond , ....????
	// x1xx-xxxx	 Request, Send/Request Frame  => 4

	// 4.2
	// Serv_class
	// x1xx-xxxx	 Request, Send/Request Frame  => 4

	// xxxx-0110 Send Data with No Acknow. high => 6
	// xxxx-0100 Send Data with No Acknow. low   => 4

	if ( SRD_Serv_class == 1)
	{
		telegram_tx[6] |= 0x06;
	}
	else
	{
		telegram_tx[6] |= 0x04;
	}

	if (SRD_DSAP > 0)
	{
			telegram_tx[4] = telegram_tx[4] | 0x80;
			telegram_tx[5] = telegram_tx[5] | 0x80;
			telegram_tx[1] = SRD_data_length+5;				// LE
			telegram_tx[2] = SRD_data_length+5;				// LEr

			telegram_tx[7] = SRD_DSAP;									// DSAP
			telegram_tx[8] = SRD_SSAP;									// SSAP
			j = 9;
			for (i=0;i<SRD_data_length;i++)
			{
				 telegram_tx[j] = *(SRD_data_unit+i*sizeof(INT8U) );
				 j++;
			}
	}
	else
	{
			telegram_tx[4] &= 0x7F;
			telegram_tx[5] &= 0x7F;

			telegram_tx[1] = SRD_data_length+3;				// LE
			telegram_tx[2] = SRD_data_length+3;				// LEr

			j = 7;
			for (i=0;i<SRD_data_length;i++)
			{
				 telegram_tx[j] = *(SRD_data_unit+i*sizeof(INT8U) );
				 j++;
			}
	}

	// DATA 
	checksum = 0;
	for (i=4;i<j;i++)
	{
		checksum = checksum + telegram_tx[i];
	}
	telegram_tx[j] = checksum;		// FCS
	 j++;
	telegram_tx[j] = 0x16;					// Ed
	 j++;
	telegram_tx_len = j;

#ifdef  fdl_debug		
										printf(">FDL TX >>> ");
										for ( i=0;i<telegram_tx_len;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",telegram_tx[i]);
										}
										printf("\n- len = %d\n",telegram_tx_len);
#endif 		

	// send telegram
	for (i=0;i<telegram_tx_len;i++)
	{
		PHY_DATA_PUT(telegram_tx[i] );
	}
	// return status
	L_status = 0;

	return L_status;

}
//INT8U FDL_SDN_put(INT8U SSAP,INT8U DSAP,INT8U Rem_add,INT8U Serv_class )
//INT8U FDL_SDN_put(INT8U SSAP,INT8U DSAP,INT8U Rem_add,INT8U Serv_class,INT8U * data_unit,INT8U data_length)
/*
INT8U FDL_SDN_put(TELEFRAM_SD2 * temp)
{
	INT8U L_status;
	INT8U telegram_tx[MTU_TX];
	INT8U telegram_tx_len;
	INT8U i,j;
	INT8U checksum;

	// create telegram
	// SD2
	telegram_tx[0] = 0x68;														// SD2

	telegram_tx[3] = 0x68;														// SD2
	telegram_tx[4] = temp->SD2_da;								// DA
	telegram_tx[5] = temp->SD2_sa;								// SA

	// Serv_class
	// x1xx-xxxx	 Request, Send/Request Frame  => 4

	// xxxx-0110 Send Data with No Acknow. high => 6
	// xxxx-0100 Send Data with No Acknow. low   => 4
	telegram_tx[6] = temp->SD2_fc;									// FC

	if (temp->SD2_dsap != 0)
	{
			telegram_tx[1] = temp->SD2_data_length+5;				// LE
			telegram_tx[2] = temp->SD2_data_length+5;				// LEr

			telegram_tx[7] = temp->SD2_dsap;									// FC
			telegram_tx[8] = temp->SD2_ssap;									// FC
			j = 9;
			for (i=0;i<temp->SD2_data_length;i++)
			{
				 telegram_tx[j] = temp->SD2_data_unit[i];
				 j++;
			}
	}
	else
	{
			telegram_tx[1] = temp->SD2_data_length+3;				// LE
			telegram_tx[2] = temp->SD2_data_length+3;				// LEr

			j = 7;
			for (i=0;i<temp->SD2_data_length;i++)
			{
				 telegram_tx[j] =  temp->SD2_data_unit[i];  // *(data_unit+i*sizeof(INT8U) );
				 j++;
			}
	}

	// DATA 
	checksum = 0;
	for (i=4;i<j;i++)
	{
		checksum = checksum + telegram_tx[i];
	}
	telegram_tx[j] = checksum;		// FCS
	 j++;
	telegram_tx[j] = 0x16;					// Ed
	 j++;
	telegram_tx_len = j;

#ifdef  fdl_debug		
										printf("FDL TX >>> ");
										for ( i=0;i<telegram_tx_len;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",telegram_tx[i]);
										}
										printf("  %d\n",telegram_tx_len);
#endif 		

	// send telegram
	for (i=0;i<telegram_tx_len;i++)
	{
		PHY_DATA_PUT(telegram_tx[i] );
	}
	// return status
	L_status = 0;
	return L_status;
}
*/

INT8U FDL_SDN_indication(INT8U serv_class )
{
 
#ifdef  fdl_debug	
		printf(">FDL FDL_SDN_indication\n");
#endif 		
	ddlm_sdn_service();
/*
	EVENT_SDN_indication = serv_class;
	OSSemPost(fdl_event);											// Release semaphore     
*/
	return 1;
}
							
void FDL_SDN_get(TELEFRAM_SD2 * temp)
{
	memcpy(temp,&telegram_rx,sizeof(temp) );
}

INT8U	FDL_SD1_Parse()
{
	INT8U	temp;

#ifdef  fdl_debug	
	INT8U	i;

#endif 		
	memset(&telegram_rx,0x00,sizeof(telegram_rx));

/*
INT8U fdl_data_rx_telegram_index;							// Index to RX Telegram
INT8U fdl_data_rx_all;														// All length
INT8U fdl_data_rx_telegram[MTU_RX];					// RX Telegram
*/
	printf(">SD1 Parse \n");
	// SD2
	telegram_rx.SD2_sd		= fdl_data_rx_telegram[0];
	// DA
	telegram_rx.SD2_da		=	 fdl_data_rx_telegram[1];
	// SA
	telegram_rx.SD2_sa		=	 fdl_data_rx_telegram[2];
	// FC
	telegram_rx.SD2_fc			=   fdl_data_rx_telegram[3];
	telegram_rx.SD2_dsegment	= 0;
	telegram_rx.SD2_dsap	= 0;
	telegram_rx.SD2_ssegment   = 0;
	telegram_rx.SD2_ssap   = 0;

	telegram_rx.SD2_da &= 0x7F;
	telegram_rx.SD2_sa &= 0x7F;
	telegram_rx.SD2_data_length = 0;

	if ( telegram_rx.SD2_da == FDL_VARIABLE.FDL_TS || telegram_rx.SD2_da == 127)
	{
			// check FC ������ SDN, SRD 
			//				printf("i 10, %d\n",FDL_VARIABLE.FDL_TS);
			if (  (telegram_rx.SD2_fc  & 0x40 ) == 0x40 )	// check �����Ẻ request �������
			{

				
						switch ( (telegram_rx.SD2_fc  & 0x0F )  )
						{
							case 4 :			// SDN Low
							{
								FDL_SDN_indication(Serv_Class_Low );
								printf("- SDN Low \n");
							}						
							break;
							case 6 :			// SDN High
							{
								FDL_SDN_indication(Serv_Class_High);
								printf("- SDN High \n");
							}						
							break;
							case 12 :		// SRD Low
							{
								printf("- SRD Low \n");
//								FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
								FDL_SRD_respond();
								FDL_SRD_indication(Serv_Class_Low);
							}						
							break;
							case 13 :		// SRD High
							{
								printf("- SRD High \n");
//								FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
								FDL_SRD_respond();
								FDL_SRD_indication(Serv_Class_High);
							}						
							break;					
						}
				}
				else
				{
					// ��������
				}

				
		}
		else
		{
//#ifdef  fdl_debug	
			printf("- %02d Drop this telegram : wrong station %02d\n",FDL_VARIABLE.FDL_TS,telegram_rx.SD2_da);
//#endif 		
		}

	return 0;
}


INT8U	FDL_SD2_Parse()
{
	INT8U	temp;
	INT8U  start_data_index;
#ifdef  fdl_debug	
	INT8U	i;

#endif 		
	memset(&telegram_rx,0x00,sizeof(telegram_rx));

/*
INT8U fdl_data_rx_telegram_index;							// Index to RX Telegram
INT8U fdl_data_rx_all;														// All length
INT8U fdl_data_rx_telegram[MTU_RX];					// RX Telegram
*/
	
	// SD2
	telegram_rx.SD2_sd = fdl_data_rx_telegram[0];
	// DA
	telegram_rx.SD2_da		=	 fdl_data_rx_telegram[4];
	// SA
	telegram_rx.SD2_sa		=	 fdl_data_rx_telegram[5];
	// FC
	telegram_rx.SD2_fc			=   fdl_data_rx_telegram[6];

	telegram_rx.SD2_data_length = fdl_data_rx_telegram[1] -3;

	start_data_index = 7;

	if ( (telegram_rx.SD2_da & 0x80) == 0x80 )
	{
	// DSAP
//				printf("i 1 , %d ? %d\n",start_data_index, fdl_data_rx_telegram[start_data_index]);
				if ( ( fdl_data_rx_telegram[start_data_index] & 0xC0) == 0x00 )
				{
//				printf("i 2 , %d\n",start_data_index);
					// DSAP - b7=0 , b6=0 , b5-b0 = DSAP
					telegram_rx.SD2_dsap =   fdl_data_rx_telegram[start_data_index];		// 7
					telegram_rx.SD2_data_length--;
					start_data_index++;
				} 
				else
					if ( ( fdl_data_rx_telegram[start_data_index] & 0xC0) == 0xC0 )						
					{
//					printf("i 3 , %d\n",start_data_index);
						// Region/Segment - b7=1 , b6=1 , b5-b0 = DSAP
						// save 
						telegram_rx.SD2_dsegment =   fdl_data_rx_telegram[start_data_index];		// 7
						telegram_rx.SD2_data_length--;
						start_data_index++;
						 telegram_rx.SD2_dsap =   fdl_data_rx_telegram[start_data_index];				// 8
						telegram_rx.SD2_data_length--;
						start_data_index++;
					} 
	}
	else
	{	
	// DSAP
//					printf("i 0 , %d\n",start_data_index);
		telegram_rx.SD2_dsap =   0;
		telegram_rx.SD2_dsegment = 0;
	//	telegram_rx.SD2_data_length--;
//		start_data_index++;
	}

	if ( (telegram_rx.SD2_sa & 0x80) == 0x80 )
	{
	// SSAP
//				printf("i 4 , %d  ? %x\n",start_data_index, fdl_data_rx_telegram[start_data_index]);
		if ( ( fdl_data_rx_telegram[start_data_index] & 0xC0) == 0x00 )
		{
//				printf("i 5 , %d ? %x\n\n",start_data_index, fdl_data_rx_telegram[start_data_index]);
			// SSAP - b7=0 , b6=0 , b5-b0 = SSAP
			telegram_rx.SD2_ssap =   fdl_data_rx_telegram[start_data_index];		// 7
			telegram_rx.SD2_data_length--;
			start_data_index++;
		} 
		else
			if ( ( fdl_data_rx_telegram[start_data_index] & 0xC0)== 0xC0 )						
			{
//				printf("i 6 , %d\n",start_data_index);
				// Region/Segment - b7=1 , b6=1 , b5-b0 = SSAP
				// save 
				telegram_rx.SD2_ssegment =   fdl_data_rx_telegram[start_data_index];		// 7
				telegram_rx.SD2_data_length--;
				start_data_index++;
				 telegram_rx.SD2_ssap =   fdl_data_rx_telegram[start_data_index];				// 8
				telegram_rx.SD2_data_length--;
				start_data_index++;
			} 
	}
	else
	{	
	// DSAP
//				printf("i 7 , %d\n",start_data_index);
		telegram_rx.SD2_ssap =   0;
		telegram_rx.SD2_ssegment = 0;
//		telegram_rx.SD2_data_length--;
//		start_data_index++;
	}
 		printf("Start Index %02d ",start_data_index);
	// data start_data_index
	memcpy(&telegram_rx.SD2_data_unit[0], &fdl_data_rx_telegram[start_data_index] , telegram_rx.SD2_data_length );


#ifdef  fdl_debug	
		printf(">FDL FDL_sd2_82_86\n");
		printf(" SD DA SA FC DSEG DSAP SSEG SSAP SD2_data_length\n");
		printf(" %02X %02X %02X %02X %4X %4X %4X %4X %d\n",telegram_rx.SD2_sd,telegram_rx.SD2_da
																																,telegram_rx.SD2_sa,telegram_rx.SD2_fc
																																,telegram_rx.SD2_dsegment,telegram_rx.SD2_dsap
																																,telegram_rx.SD2_ssegment,telegram_rx.SD2_ssap, telegram_rx.SD2_data_length);
		for(i=0;i<telegram_rx.SD2_data_length;i++)
		{
			if ( (i % 16 == 0) && (i>0))		{printf("\n"); }
			if ( i % 16 == 0)							{printf("SD2_data= ");}
			printf("%02X ",telegram_rx.SD2_data_unit[i]);		
		}
		printf("\n");
#endif 		

		telegram_rx.SD2_da &= 0x7F;
		telegram_rx.SD2_sa &= 0x7F;
//				printf("i 11, %d\n",FDL_VARIABLE.FDL_TS);
		// ��Ǩ�ͺ����� station ���ǡѹ�������  
		if ( (telegram_rx.SD2_da == FDL_VARIABLE.FDL_TS))
		{
				// check FC ������ SDN, SRD 
//				printf("i 10, %d\n",FDL_VARIABLE.FDL_TS);
				if (  (telegram_rx.SD2_fc  & 0x40 ) == 0x40 )	// check �����Ẻ request �������
				{

				
						switch ( (telegram_rx.SD2_fc  & 0x0F )  )
						{
							case 4 :			// SDN Low
							{
								FDL_SDN_indication(Serv_Class_Low );
								printf("- SDN Low \n");
							}						
							break;
							case 6 :			// SDN High
							{
								FDL_SDN_indication(Serv_Class_High);
								printf("- SDN High \n");
							}						
							break;
							case 12 :		// SRD Low
							{
								printf("- SRD Low \n");
//								FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
								FDL_SRD_respond();
								FDL_SRD_indication(Serv_Class_Low);
							}						
							break;
							case 13 :		// SRD High
							{
								printf("- SRD High \n");
//								FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
								FDL_SRD_respond();
								FDL_SRD_indication(Serv_Class_High);
							}						
							break;					
						}
				}
				else
				{
					// ��������
				}

				
		}
		else
		{
//#ifdef  fdl_debug	
			printf("- %02d Drop this telegram : wrong station %02d\n",FDL_VARIABLE.FDL_TS,telegram_rx.SD2_da);
//#endif 		
		}


	return 1;
}
/*
INT8U	FDL_indication_82_86()
{
	INT8U	temp;
#ifdef  fdl_debug	
	INT8U	i;
#endif 		
	memset(&telegram_rx,0x00,sizeof(telegram_rx));



//INT8U fdl_data_rx_telegram_index;							// Index to RX Telegram
//INT8U fdl_data_rx_all;														// All length
//INT8U fdl_data_rx_telegram[MTU_RX];					// RX Telegram


	
	// SD2
	telegram_rx.SD2_sd = fdl_data_rx_telegram[0];
	// DA
	telegram_rx.SD2_da		=	 fdl_data_rx_telegram[4];
	// SA
	telegram_rx.SD2_sa		=	 fdl_data_rx_telegram[5];
	// FC
	telegram_rx.SD2_fc			=   fdl_data_rx_telegram[6];

	if ( (telegram_rx.SD2_da & 0x80) == 0x80 )
	{
	// DSAP
		telegram_rx.SD2_dsap =   fdl_data_rx_telegram[7];
	// SSAP
		telegram_rx.SD2_ssap =   fdl_data_rx_telegram[8];

		telegram_rx.SD2_data_length =  fdl_data_rx_telegram[1] - 5;
		// data 9->
		memcpy(&telegram_rx.SD2_data_unit[0], &fdl_data_rx_telegram[9] , telegram_rx.SD2_data_length );

	}
	else
	{	
	// DSAP
		telegram_rx.SD2_dsap =   0;
	// SSAP
		telegram_rx.SD2_ssap =   0;

		telegram_rx.SD2_data_length =  fdl_data_rx_telegram[1] - 3;
		// data 7->
		memcpy(&telegram_rx.SD2_data_unit[0], &fdl_data_rx_telegram[7] , telegram_rx.SD2_data_length );
	}

#ifdef  fdl_debug	
		printf("FDL FDL_indication_82_86\n");
		printf("SD2_sd  = %02X\n",telegram_rx.SD2_sd);
		printf("SD2_da  = %02X\n",telegram_rx.SD2_da);
		printf("SD2_sa  = %02X\n",telegram_rx.SD2_sa);
		printf("SD2_fc  = %02X\n",telegram_rx.SD2_fc);
		printf("SD2_dsap= %02X\n",telegram_rx.SD2_dsap);
		printf("SD2_ssap= %02X\n",telegram_rx.SD2_ssap);
		
		for(i=0;i<telegram_rx.SD2_data_length;i++)
		{
			if ( (i % 16 == 0) && (i>0))		{printf("\n"); }
			if ( i % 16 == 0)							{printf("SD2_data= ");}
			printf("%02X ",telegram_rx.SD2_data_unit[i]);		
		}
		printf("\n");
#endif 		

		telegram_rx.SD2_da &= 0x7F;
		telegram_rx.SD2_sa &= 0x7F;
		if ( telegram_rx.SD2_da == FDL_VARIABLE.FDL_TS)
		{
				// SDN
				if (telegram_rx.SD2_dsap == 58)	 // 0x3A
				{
						FDL_SDN_indication();
				}
				// SRD
				else
				{
						// respond 
	 
	//				FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );

						// FDL_SRD_REPLY_UPDATE_respond(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add)
						// indicate
						FDL_SRD_indication();
				}
		}
		else
		{
//#ifdef  fdl_debug	
			printf("%02d Drop this telegram : wrong station %02d\n",FDL_VARIABLE.FDL_TS,telegram_rx.SD2_da);
//#endif 		
		}

	return 1;
}
*/

// =======================================================================================
/*
3. Send and Request Data with Reply (SRD)

= Master
FDL_DATA_REPLY.request
(SSAP, DSAP, Rem_add, L_sdu, Serv_class)

= Master/Slave
FDL_DATA_REPLY.indication
(SSAP, DSAP, Loc_add, Rem_add, L_sdu, Serv_class, Update_status)

= Master
FDL_DATA_REPLY.confirm
(SSAP, DSAP, Rem_add, L_sdu, Serv_class, L_status)

= Master/Slave
FDL_REPLY_UPDATE.request
(SSAP, L_sdu, Serv_class, Transmit)
*/

INT8U FDL_SRD_req(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class)
{
	INT8U L_status;
	INT8U telegram_tx[MTU_TX];
	INT8U telegram_tx_len;
	INT8U i,j;
	INT8U checksum;	
	

	// create telegram
	// 1. SD2
	telegram_tx[0] = 0x68;														// SD2
	telegram_tx[3] = 0x68;														// SD2
	// 2. DA - Destination Address
	telegram_tx[4] = SRD_Rem_add;											// DA
	// 3. SA - Source Address = This Address = FDL_VARIABLE.FDL_TS
	telegram_tx[5] = FDL_VARIABLE.FDL_TS;						// SA

	// 4. FC
	telegram_tx[6] = 0x00;

	// 4.1 ��鹡Ѻ��Դ Station , req-respond , ....????
	// x1xx-xxxx	 Request, Send/Request Frame  => 4

	// 4.2
	// Serv_class 
	// xxxx-1100 Send and Request Data with Reply low	=> 12	 C
	// xxxx-1101 Send and Request Data with Reply high   => 13  D
	if ( SRD_Serv_class == 1)
	{
		telegram_tx[6] |= 0x0C;
	}
	else
	{
		telegram_tx[6] |= 0x0D;
	}

	if (SRD_DSAP > 0)
	{
			telegram_tx[4] = telegram_tx[4] | 0x80;
			telegram_tx[5] = telegram_tx[5] | 0x80;
			telegram_tx[1] = SRD_data_length+5;				// LE
			telegram_tx[2] = SRD_data_length+5;				// LEr

			telegram_tx[7] = SRD_DSAP;									// DSAP
			telegram_tx[8] = SRD_SSAP;									// SSAP
			j = 9;
			for (i=0;i<SRD_data_length;i++)
			{
				 telegram_tx[j] = *(SRD_data_unit+i*sizeof(INT8U) );
				 j++;
			}
	}
	else
	{
			telegram_tx[4] &= 0x7F;
			telegram_tx[5] &= 0x7F;

			telegram_tx[1] = SRD_data_length+3;				// LE
			telegram_tx[2] = SRD_data_length+3;				// LEr

			j = 7;
			for (i=0;i<SRD_data_length;i++)
			{
				 telegram_tx[j] = *(SRD_data_unit+i*sizeof(INT8U) );
				 j++;
			}
	}

	// DATA 
	checksum = 0;
	for (i=4;i<j;i++)
	{
		checksum = checksum + telegram_tx[i];
	}
	telegram_tx[j] = checksum;		// FCS
	 j++;
	telegram_tx[j] = 0x16;					// Ed
	 j++;
	telegram_tx_len = j;

#ifdef  fdl_debug		
										printf(">FDL TX >>> ");
										for ( i=0;i<telegram_tx_len;i++ )
										{
											if ( i % 16 == 0) {printf("\n- ");}
											printf("%02X ",telegram_tx[i]);
										}
										printf("\n- len = %d\n",telegram_tx_len);
#endif 		

	// send telegram
	for (i=0;i<telegram_tx_len;i++)
	{
		PHY_DATA_PUT(telegram_tx[i] );
	}
	// return status
	L_status = 0;

	return L_status;
};






















void FDL_SRD_get(TELEFRAM_SD2 * temp)
{
	memcpy(temp,&telegram_rx,sizeof(TELEFRAM_SD2) );
}

INT8U FDL_SRD_con( )
{

	return 1;
}

// Slave
INT8U FDL_SRD_indication( INT8U serv_class)
{

#ifdef  fdl_debug	
		printf(">FDL SRD_indication\n");
#endif 		
 
		ddlm_srd_service();
//	EVENT_SRD_indication = serv_class;
//	OSSemPost(fdl_event);											// Release semaphore     

	return 1;
}


INT8U FDL_SRD_REPLY_UPDATE2(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit)
{
	INT8U i;

	INT8U index;
/*
	FDL_SSAP					FDL_SRD_SSAP[10];

typedef struct 
{
	// Operating Parameters (mandatory)
	INT8U	FDL_SSAP_Enable;				// 1 = Enable , 0 = Disable
	INT8U	FDL_SSAP_NO;						// 0-63
	INT8U	FDL_SSAP_data_unit[MTU_DATA];		// buffer
	INT8U	FDL_SSAP_data_len;						// 32 Max
	INT8U	FDL_SSAP_Serv_class;
	INT8U	FDL_SSAP_Transmit;
} FDL_SSAP;
*/

	// 1. �� index �ͧ FDL_SRD_SSAP ���������� 0, 54-62 ����ͧ���

	switch(SRD_SSAP)
	{

	case 0:			index= 0;		break;
 	case 54:		index= 1;		break; 
 	case 55:		index= 2;		break; 
 	case 56:		index= 3;		break; 
 	case 57:		index= 4;		break; 
 	case 58:		index= 5;		break; 
 	case 59:		index= 6;		break; 
 	case 60:		index= 7;		break; 
 	case 61:		index= 8;		break; 
 	case 62:		index= 9;		break; 
	default:
		index = 99;
	break; 
	}

	// 2. ��˹���� parameter ��� index �ͧ FDL_SRD_SSAP (0, 54-62)
	if ( index < 10 )
	{
			if (FDL_SRD_SSAP[index].FDL_SSAP_Enable == 1) // FDL_SSAP_Enable[index] == enable
			{
					FDL_SRD_SSAP[index].FDL_SSAP_NO = SRD_SSAP;
					FDL_SRD_SSAP[index].FDL_SSAP_data_len = SRD_data_length;
//					FDL_SRD_SSAP[index].FDL_SSAP_data_unit;

					for (i=0;i<FDL_SRD_SSAP[index].FDL_SSAP_data_len;i++)
					{
						 FDL_SRD_SSAP[index].FDL_SSAP_data_unit[i] = *(SRD_data_unit+i*sizeof(INT8U) );
					}
					FDL_SRD_SSAP[index].FDL_SSAP_Serv_class = SRD_Serv_class;
					FDL_SRD_SSAP[index].	FDL_SSAP_Transmit = SRD_Transmit;

#ifdef  fdl_debug	
					printf(">FDL_SRD_UPDATE\n");
					printf("-> FDL_SSAP_Enable = %02d\n",FDL_SRD_SSAP[index].FDL_SSAP_Enable);
					printf("-> FDL_SSAP_NO         = %02d\n",FDL_SRD_SSAP[index].FDL_SSAP_NO);
					printf("-> FDL_SSAP_data_unit >>>\n");
								for (i=0;i<FDL_SRD_SSAP[index].FDL_SSAP_data_len;i++)
								{
										if ( i % 16 == 0) {printf("\n- ");}
										printf("%02X ",FDL_SRD_SSAP[index].FDL_SSAP_data_unit[i]);
								}
					printf("-> FDL_SSAP_data_len      = %02d \n",FDL_SRD_SSAP[index].FDL_SSAP_data_len);
					printf("-> FDL_SSAP_Serv_class = %02d \n"	,FDL_SRD_SSAP[index].FDL_SSAP_Serv_class);
					printf("-> FDL_SSAP_Transmit      = %02d \n",FDL_SRD_SSAP[index].FDL_SSAP_Transmit);
#endif 		

					return 0;		// no error
			}
			else	// 			FDL_SSAP_Enable[index] == disable
			{
					return 1;		// error
			}

	}
	else
	{
			return 1;		// error
	}

}

INT8U FDL_SRD_REPLY_UPDATE_respond2(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add)
{
	INT8U i;

	INT8U index;
/*
	FDL_SSAP					FDL_SRD_SSAP[10];

typedef struct 
{
	// Operating Parameters (mandatory)
	INT8U	FDL_SSAP_Enable;				// 1 = Enable , 0 = Disable
	INT8U	FDL_SSAP_NO;						// 0-63
	INT8U	FDL_SSAP_data_unit[MTU_DATA];		// buffer
	INT8U	FDL_SSAP_data_len;						// 32 Max
	INT8U	FDL_SSAP_Serv_class;
	INT8U	FDL_SSAP_Transmit;
} FDL_SSAP;
*/

	// 1. �� index �ͧ FDL_SRD_SSAP ���������� 0, 54-62 ����ͧ���

	switch(SRD_SSAP)
	{

	case 0:			index= 0;		break;
 	case 54:		index= 1;		break; 
 	case 55:		index= 2;		break; 
 	case 56:		index= 3;		break; 
 	case 57:		index= 4;		break; 
 	case 58:		index= 5;		break; 
 	case 59:		index= 6;		break; 
 	case 60:		index= 7;		break; 
 	case 61:		index= 8;		break; 
 	case 62:		index= 9;		break; 
	default:
		index = 99;
	break; 
	}

	// 2. ��˹���� parameter ��� index �ͧ FDL_SRD_SSAP (0, 54-62)
	if ( index < 10 )
	{
			if (FDL_SRD_SSAP[index].FDL_SSAP_Enable == 1) // FDL_SSAP_Enable[index] == enable
			{

						if (FDL_SRD_SSAP[index].FDL_SSAP_Transmit  > 0 ) // FDL_SSAP_Enable[index] == enable
						{

										FDL_SRD_req(FDL_SRD_SSAP[index].FDL_SSAP_NO,
																SRD_DSAP,
																	SRD_Rem_add,
																		&FDL_SRD_SSAP[index].FDL_SSAP_data_unit[0],
																			FDL_SRD_SSAP[index].FDL_SSAP_data_len,
																				FDL_SRD_SSAP[index].FDL_SSAP_Serv_class );

										// Single - ��ҹ���������
										if ( FDL_SRD_SSAP[index].FDL_SSAP_Transmit == 1 )
										{
											FDL_SRD_SSAP[index].FDL_SSAP_Transmit = 0;
										}

										return 0;		// no error
							} // (FDL_SRD_SSAP[index].FDL_SSAP_Transmit  > 0 )
							else
							{
										FDL_SRD_req(FDL_SRD_SSAP[index].FDL_SSAP_NO,
																SRD_DSAP,
																	SRD_Rem_add,
																		&FDL_SRD_SSAP[index].FDL_SSAP_data_unit[0],
																			0 , // FDL_SRD_SSAP[index].FDL_SSAP_data_len,
																				FDL_SRD_SSAP[index].FDL_SSAP_Serv_class );

										return 1;		// error
							}

			} // (FDL_SRD_SSAP[index].FDL_SSAP_Enable == 1) 
			else	// 			FDL_SSAP_Enable[index] == disable
			{
					return 1;		// error
			}

	} //( index < 10 )
	else 
	{
			return 1;		// error
	}


}

 			//	test_get_mbox = (INT8U*) OSMboxPend(MMM, 0, &err);
 
	//			OSSemPend(sem_printf, 0, &err);							// Acquire semaphore 
	//			printf(" Task 6\n");
	//			OSSemPost(sem_printf);											// Release semaphore               
 
				// Send Global_Control Telegram - Test call function
			  //	FDL_SDN_put(0x3A,0x3E,0xFF,1);


				// Recieve 
				// 1. Wait PHY Indicate

//				phy_data_rx_msg = (INT8U*) OSMboxPend(mbox_phy_data_rx, 1000, &err);


void EVENT_CLEAR( ) 
{
	EVENT_SRD_indication = 0;
	EVENT_SDN_indication = 0;
}

void SSAP_CLEAR( ) 
{
	INT8U i;
	db_sap_activate = NULL;
	db_rsap_activate = NULL;
	db_srd_ssap_list = NULL;

/*
	for (i=0;i<10;i++)
	{
		memset(&db_sap_activate[i]  ,0x00,sizeof(db_sap_activate[i]));
	}
	for (i=0;i<10;i++)
	{
		memset(&db_rsap_activate[i]  ,0x00,sizeof(db_rsap_activate[i]));
	}
	*/
			printf(">RESET db_sap_activate %x \n",db_sap_activate);
}


INT8U FDL_RESET()
{
	INT8U i;
	fdl_state = 0;
	memset(&telegram_rx,0x00,sizeof(TELEFRAM_SD2));
	memset(&FDL_VARIABLE,0x00,sizeof(FDL_VARIABLE));

	FDL_VARIABLE.FDL_TS = 126;																	// No Address = 126
	FDL_VARIABLE.FDL_Baud_rate = FDL_baud_rate;							// 9,600; 19,200; 93,7500; 187,500; 50000; 150000kbit/s
	FDL_VARIABLE.FDL_Medium_red = 0;													// single, redundance

	sprintf(FDL_VARIABLE.FDL_HW_Release,"ESL PRO-Slave 1.0a\0");
	sprintf(FDL_VARIABLE.FDL_SW_Release,"Profi-Stack 1.0a\0");

	FDL_VARIABLE.FDL_TSL = 1000;																//  52 to 2^16-1 (Bit Times	)
	FDL_VARIABLE.FDL_min_TSDR = 1000;													//  2^0 to 2^16-1 (Bit Times)

// Counters (optional)
	FDL_VARIABLE.FDL_SD_count = 0;
	FDL_VARIABLE.FDL_SD_error_count = 0;

// FDL_SSAP
	EVENT_CLEAR( ) ;
	SSAP_CLEAR();

	for (i=0;i<10;i++)
	{
		memset(&FDL_SRD_SSAP[i]  ,0x00,sizeof(FDL_SRD_SSAP[i]));
 
		FDL_SRD_SSAP[i].FDL_SSAP_Enable = 1;
		if ( i >0 )
		{
			FDL_SRD_SSAP[i].FDL_SSAP_NO = 53 + i;
		}
		else
		{
			FDL_SRD_SSAP[i].FDL_SSAP_NO = 0;
		}
 
	}
 
#ifdef  fdl_debug	
		printf(">FDL FDL_RESET\n");
#endif 		

	return 1;
}

// ============SET VALUE FDL =============================================
INT8U SET_VALUE_FDL_TS							(INT8U   Desired_value)
{
		FDL_VARIABLE.FDL_TS = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_Baud_rate			(INT16U Desired_value)
{
		FDL_VARIABLE.FDL_Baud_rate = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_Medium_red		(INT8U   Desired_value)
{
		FDL_VARIABLE.FDL_Medium_red = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_TSL						(INT16U Desired_value)
{
		FDL_VARIABLE.FDL_TSL = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_min_TSDR			(INT16U Desired_value)
{
		FDL_VARIABLE.FDL_min_TSDR = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_SD_count			(INT32U Desired_value)
{
		FDL_VARIABLE.FDL_SD_count = Desired_value;
		return Desired_value;
}
INT8U SET_VALUE_FDL_SD_error_count(INT16U Desired_value)
{
		FDL_VARIABLE.FDL_SD_error_count = Desired_value;
		return Desired_value;
}

// ============READ VALUE FDL =============================================
INT8U READ_VALUE_FDL_TS							(  )
{
		return FDL_VARIABLE.FDL_TS;
}
INT16U READ_VALUE_FDL_Baud_rate			(  )
{
		return FDL_VARIABLE.FDL_Baud_rate	;
}
INT8U READ_VALUE_FDL_Medium_red		(  )
{
		return FDL_VARIABLE.FDL_Medium_red;
}
INT16U READ_VALUE_FDL_TSL						(  )
{
		return FDL_VARIABLE.FDL_TSL	;
}
INT16U READ_VALUE_FDL_min_TSDR		(  )
{
		return FDL_VARIABLE.FDL_min_TSDR;
}
INT32U READ_VALUE_FDL_SD_count			(  )
{
		return FDL_VARIABLE.FDL_SD_count;
}
INT16U READ_VALUE_FDL_SD_error_count(  )
{
		return FDL_VARIABLE.FDL_SD_error_count;
}
INT8U  * READ_VALUE_FDL_HW_Release(  )
{
		return &FDL_VARIABLE.FDL_HW_Release[0];
}
INT8U  * READ_VALUE_FDL_SW_Release(  )
{
		return &FDL_VARIABLE.FDL_SW_Release[0];
}

INT8U	FDL_SAP_ACTIVATE( INT8U t_ssap,INT8U t_access, INT8U t_service_activate,INT8U t_role_in_service )
{
	INT8U i;
	SAP_ACTIVATE_LIST * temp;
	i = 0;

 	if ( db_sap_activate == NULL )
	{
			db_sap_activate = (SAP_ACTIVATE_LIST *) malloc(sizeof(SAP_ACTIVATE_LIST) ) ;
			if ( db_sap_activate == NULL )
			{
				printf("Not enough memory to allocate buffer\n");
				exit(1);  
			}
 
			db_sap_activate->ssap = t_ssap;
			db_sap_activate->access = t_access;
			db_sap_activate->service_activate = t_service_activate;
			db_sap_activate->role_in_service = t_role_in_service;
			db_sap_activate->next = NULL;		

					temp = db_sap_activate;
					printf(">SAP Activate List = %d\n",temp->ssap);
/*
#ifdef  fdl_debug	
					printf(" SAP Activate List = ? 0\n");
					printf(" No - SSAP - ACCESS - SERVICE - ROLE\n");
					printf(" %d - %4d - %6d - %7d - %4d\n",0, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);
#endif 		
*/
	}
	else
	{
			if (db_sap_activate->next == NULL)
			{
					db_sap_activate->next = (SAP_ACTIVATE_LIST *) malloc(sizeof(SAP_ACTIVATE_LIST)) ;
					temp = db_sap_activate->next;
					temp->ssap = t_ssap;
					temp->access = t_access;
					temp->service_activate = t_service_activate;
					temp->role_in_service = t_role_in_service;
					temp->next = NULL;		
					printf(">SAP Activate List = %d\n",temp->ssap);
/*
#ifdef  fdl_debug	
					printf(">SAP Activate List = ? 1\n");
					printf(">No - SSAP - ACCESS - SERVICE - ROLE\n");
					printf(" %d - %4d - %6d - %7d - %4d\n",0, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);
#endif 		
*/
			}
			else
			{
					temp = db_sap_activate;
					// ǹ��������� � ���͵���ش����
					i = 1;
					while (temp->next != NULL )
					{
						temp = temp->next;
						i++;
					}
					// ���ҧ��������ҵ�ͷ���
//					printf(" Insert %d\n",i);
					temp->next = (SAP_ACTIVATE_LIST *) malloc(sizeof(SAP_ACTIVATE_LIST));
					if ( ( temp) == NULL )
					{
						printf("Not enough memory to allocate buffer\n");
						exit(1);  
					}
					temp = temp->next ;
					temp->ssap = t_ssap;
					temp->access = t_access;
					temp->service_activate = t_service_activate;
					temp->role_in_service = t_role_in_service;
					temp->next = NULL;
					printf(">SAP Activate List = %d\n",temp->ssap);
/*
#ifdef  fdl_debug	
					printf(" SAP Activate List = ? 2\n");
					printf(" No - SSAP - ACCESS - SERVICE - ROLE\n");
					printf(" %d - %4d - %6d - %7d - %4d\n",0, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);
#endif 		
*/
			}
	}
}

INT8U	FDL_SAP_ACTIVATE_PRINT()
{
	INT8U i;
	SAP_ACTIVATE_LIST * temp;
	i = 0;

	temp = db_sap_activate;
	if ( temp == NULL ) // 0
	{
			printf(">SAP Activate List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					printf(">SAP Activate List =\n");
					printf(" No - SSAP - ACCESS - SERVICE - ROLE\n");
					printf(" %d - %4d - %6d - %7d - %4d\n",i, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);
			}
			else
			{		
			// temp->next != NULL

										// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
						printf(">SAP Activate List =\n");
						printf(" No - SSAP - ACCESS - SERVICE - ROLE\n");
						printf(" %d - %4d - %6d - %7d - %4d\n",i, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);
						i++;
						temp = temp->next;
					}
						printf(">SAP Activate List =\n");
						printf(" No - SSAP - ACCESS - SERVICE - ROLE\n");
						printf(" %d - %4d - %6d - %7d - %4d\n",i, temp->ssap ,temp->access , temp->service_activate, temp->role_in_service);

					printf(" End List \n");
			}
	}

			
}



/*

Access						 
									- values All/0 to 126
									- 0 - 126 , 127 = all
Service_type
									- Send Data with Acknowledge (SDA)					1
									- Send Data with No Acknowledge (SDN)			2
									- Send and Request Data with Reply (SRD)		3
									- Cyclic Send and Request Data (CRSC)				4

Role_in_service	
									- Initiator:					1
									- Responder:			2
									- Both:						3
*/					


INT8U	FDL_RSAP_ACTIVATE( INT8U t_ssap,INT8U t_access, INT8U t_indication_mode )
{
	INT8U i;
	RSAP_ACTIVATE_LIST * temp;
	i = 0;

 	if ( db_rsap_activate == NULL )
	{
			db_rsap_activate = (RSAP_ACTIVATE_LIST *) malloc(sizeof(RSAP_ACTIVATE_LIST)) ;
			if ( db_rsap_activate == NULL )
			{
				printf("Not enough memory to allocate buffer\n");
				exit(1);  
			}
 
			db_rsap_activate->ssap = t_ssap;
			db_rsap_activate->access = t_access;
			db_rsap_activate->indication_mode = t_indication_mode;
			db_rsap_activate->next = NULL;		

			temp = db_rsap_activate;

					printf(">RSAP Activate List = %d\n" ,temp->ssap);
/*
#ifdef  fdl_debug	
					printf(">RSAP Activate List = ? 0\n");
					printf(" No - SSAP - ACCESS - indication_mode\n");
					printf(" %d - %4d - %6d - %7d \n",0, temp->ssap ,temp->access , temp->indication_mode);
#endif 		
*/
	}
	else
	{
			if (db_rsap_activate->next == NULL)
			{
					db_rsap_activate->next = (RSAP_ACTIVATE_LIST *) malloc(sizeof(RSAP_ACTIVATE_LIST)) ;
					temp = db_rsap_activate->next;
					temp->ssap = t_ssap;
					temp->access = t_access;
					temp->indication_mode = t_indication_mode;
					temp->next = NULL;		
					printf(">RSAP Activate List = %d\n" ,temp->ssap);
/*
#ifdef  fdl_debug	
					printf(" RSAP Activate List = ? 1\n");
					printf(" No - SSAP - ACCESS - indication_mode\n");
					printf(" %d - %4d - %6d - %7d \n",0, temp->ssap ,temp->access , temp->indication_mode);
#endif 		
*/
			}
			else
			{
					temp = db_rsap_activate;
					// ǹ��������� � ���͵���ش����
					i = 1;
					while (temp->next != NULL )
					{
						temp = temp->next;
						i++;
					}
					// ���ҧ��������ҵ�ͷ���
//					printf(" Insert %d\n",i);
					temp->next = (RSAP_ACTIVATE_LIST *) malloc(sizeof(RSAP_ACTIVATE_LIST));
					if ( ( temp) == NULL )
					{
						printf("Not enough memory to allocate buffer\n");
						exit(1);  
					}
					temp = temp->next ;
					temp->ssap = t_ssap;
					temp->access = t_access;
					temp->indication_mode = t_indication_mode;
					temp->next = NULL;
					printf(">RSAP Activate List = %d\n" ,temp->ssap);
/*
#ifdef  fdl_debug	
					printf(" RSAP Activate List = ? 2\n");
					printf(" No - SSAP - ACCESS - indication_mode\n");
					printf(" %d - %4d - %6d - %7d \n",0, temp->ssap ,temp->access , temp->indication_mode);
#endif 		
*/

			}
	}


	FDL_SRD_SSAP_CREATE(t_ssap);
	// create ssap data reply
	return 1;
}

INT8U   FDL_SRD_SSAP_CREATE(INT8U t_ssap)
{

	INT8U i,j;
	FDL_SRD_SSAP_LIST * temp;
	i = 0;

//	printf(" Create SRD SAP = %d \n",t_ssap);
	printf(">SRD SAP Buffer Created = %d \n",t_ssap);

 	if ( db_srd_ssap_list == NULL )
	{		// ��Ƿ�� 0

			db_srd_ssap_list = (FDL_SRD_SSAP_LIST *) malloc(sizeof(FDL_SRD_SSAP_LIST)) ;
			if ( db_srd_ssap_list == NULL )
			{
				printf("Not enough memory to allocate buffer\n");
				exit(1);  
			}
 
			db_srd_ssap_list->FDL_SSAP_NO = t_ssap;

			for(j=0;j<MTU_DATA;j++) temp->FDL_SSAP_data_unit[i] = 0;
//			memset(&db_srd_ssap_list->FDL_SSAP_data_unit[0],0x00, MTU_DATA );
			db_srd_ssap_list->FDL_SSAP_data_len = 0;
			db_srd_ssap_list->FDL_SSAP_Serv_class = 0;
			db_srd_ssap_list->FDL_SSAP_Transmit = 0;
			db_srd_ssap_list->next = NULL;		
	}
	else
	{

			if (db_srd_ssap_list->next == NULL)
			{
	 
					db_srd_ssap_list->next = (FDL_SRD_SSAP_LIST *) malloc( sizeof(FDL_SRD_SSAP_LIST) ) ;
					temp = db_srd_ssap_list->next;
					temp->FDL_SSAP_NO = t_ssap;

					for(j=0;j<MTU_DATA;j++) temp->FDL_SSAP_data_unit[i] = 0;
//					memset(&temp->FDL_SSAP_data_unit[0],0x00, MTU_DATA );
					temp->FDL_SSAP_data_len = 0;
					temp->FDL_SSAP_Serv_class = 0;
					temp->FDL_SSAP_Transmit = 0;
					temp->next = NULL;		
			}

			else
			{
 					temp = db_srd_ssap_list;
					// ǹ��������� � ���͵���ش����
					i = 1;
					while (temp->next != NULL )
					{
 						temp = temp->next;
						i++;
					}

					// ���ҧ��������ҵ�ͷ���
					temp->next = (FDL_SRD_SSAP_LIST *) malloc(sizeof(FDL_SRD_SSAP_LIST));
					if ( ( temp) == NULL )
					{
						printf("Not enough memory to allocate buffer\n");
						exit(1);  
					}
					temp = temp->next ;
					temp->FDL_SSAP_NO = t_ssap;

					for(j=0;j<MTU_DATA;j++) temp->FDL_SSAP_data_unit[i] = 0;
	//				memset(&temp->FDL_SSAP_data_unit[0],0x00, MTU_DATA );
					temp->FDL_SSAP_data_len = 0;
					temp->FDL_SSAP_Serv_class = 0;
					temp->FDL_SSAP_Transmit = 0;
					temp->next = NULL;		
			}
	}


}

INT8U	FDL_RSAP_ACTIVATE_PRINT()
{
	INT8U i;
	RSAP_ACTIVATE_LIST * temp;
	i = 0;

	temp = db_rsap_activate;
	if ( temp == NULL ) // 0
	{
			printf(">RSAP Activate List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					printf(">RSAP Activate List = ? 0\n");
					printf(" No - SSAP - ACCESS - indication_mode\n");
					printf(" %d - %4d - %6d - %7d \n",i, temp->ssap ,temp->access , temp->indication_mode);
			}
			else
			{		
			// temp->next != NULL

										// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
						printf(">RSAP Activate List = ? 1\n");
						printf(" No - SSAP - ACCESS - indication_mode\n");
						printf(" %d - %4d - %6d - %7d \n",i, temp->ssap ,temp->access , temp->indication_mode);
						i++;
						temp = temp->next;
					}
					printf(">RSAP Activate List = ? 2\n");
					printf(" No - SSAP - ACCESS - indication_mode\n");
					printf(" %d - %4d - %6d - %7d \n",i, temp->ssap ,temp->access , temp->indication_mode);
					printf(" End List \n");
			}
	}

				return 1;
}

INT8U	FDL_SAP_DEACTIVATE(INT8U t_ssap)
{
	INT8U i;
	SAP_ACTIVATE_LIST * temp;
	SAP_ACTIVATE_LIST * l,* r;
	i = 0;
	printf(">Find SAP for DEACTIVATE%d  \n",t_ssap);
	temp = db_sap_activate;
	if ( temp == NULL ) // 0
	{
			printf(">SAP Activate List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					free( db_sap_activate );
					db_sap_activate = NULL;
			}
			else
			{		
			// temp->next != NULL
					temp = db_sap_activate;
					
										// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
						r = temp->next;
						if (temp->ssap == t_ssap)
						{
							free( temp );
							l->next = r;
						}
						l = temp;
						temp = temp->next;
						i++;
					}
						r = temp->next;
						if (temp->ssap == t_ssap)
						{
							free( temp );
							l->next = r;
						}

					printf(" End List \n");
			}
	}


  	FDL_RSAP_DEACTIVATE(t_ssap);		
		return 1;
}

INT8U	FDL_RSAP_DEACTIVATE(INT8U t_ssap)
{
	INT8U i;
	RSAP_ACTIVATE_LIST * temp;
	RSAP_ACTIVATE_LIST * l,* r;
	i = 0;
	printf(">Find SAP for DEACTIVATE\n",t_ssap);
	temp = db_rsap_activate;
	if ( temp == NULL ) // 0
	{
			printf(">SAP Activate List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					free( db_rsap_activate );
					db_rsap_activate = NULL;
			}
			else
			{		
			// temp->next != NULL
					temp = db_rsap_activate;
					
										// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
						r = temp->next;
						if (temp->ssap == t_ssap)
						{
							free( temp );
							l->next = r;
						}
						l = temp;
						temp = temp->next;
						i++;
					}

						r = temp->next;
						if (temp->ssap == t_ssap)
						{
							free( temp );
							l->next = r;
						}

					printf(" End List \n");
			}
	}
	return 1;
}

INT8U	FDL_SRD_SAP_PRINT( )
{
	INT8U i,j;
	FDL_SRD_SSAP_LIST * temp;
	i = 0;


	temp = db_srd_ssap_list;

	if ( temp == NULL ) // 0
	{
			printf(">SRD SAP Buffer List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					printf(">SRD SAP Buffer List = ? 0\n");
					printf(" No - SSAP - S_Class - Transimit\n");
					printf(" %d - %4d - %6d - %6d \n",i, temp->FDL_SSAP_NO ,temp->FDL_SSAP_Serv_class , temp->FDL_SSAP_Transmit );				
					for (j=0;j<temp->FDL_SSAP_data_len;j++ )
					{
						if ( j % 16 == 0) {printf("\n- ");}
						printf("%02X ",temp->FDL_SSAP_data_unit[j]);
					}
					printf(" len = %d\n",temp->FDL_SSAP_data_len);
					// 2 = Multi , 1 = Single , 0 = no data
 			}
			else
			{		
					// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
							printf(">SRD SAP Buffer List = ? 0\n");
							printf(" No - SSAP - S_Class - Transimit\n");
							printf(" %d - %4d - %6d - %6d \n",i, temp->FDL_SSAP_NO ,temp->FDL_SSAP_Serv_class , temp->FDL_SSAP_Transmit );				
							for (j=0;j<temp->FDL_SSAP_data_len;j++ )
							{
								if ( j% 16 == 0) {printf("\n- ");}
								printf("%02X ",temp->FDL_SSAP_data_unit[j]);
							}
							printf(" len = %d\n",temp->FDL_SSAP_data_len);
							// 2 = Multi , 1 = Single , 0 = no data
							i++;
							temp = temp->next;
					}
					printf(">SRD SAP Buffer List = ? 0\n");
					printf(" No - SSAP - S_Class - Transimit\n");
					printf(" %d - %4d - %6d - %6d \n",i, temp->FDL_SSAP_NO ,temp->FDL_SSAP_Serv_class , temp->FDL_SSAP_Transmit );				
					for (j=0;j<temp->FDL_SSAP_data_len;j++ )
					{
						if (j % 16 == 0) {printf("\n- ");}
						printf("%02X ",temp->FDL_SSAP_data_unit[j]);
					}
					printf(" len = %d\n",temp->FDL_SSAP_data_len);
					// 2 = Multi , 1 = Single , 0 = no data
					printf(" End List \n");
			}
	}

				return 1;
}
 /*

INT8U	FDL_SRD_SAP_PRINT( )
{
	INT8U i,j;
	FDL_SRD_SSAP_LIST * temp;
	i = 0;
printf("???? \n");

	temp = db_srd_ssap_list;

	if ( temp == NULL ) // 0
	{
			printf(" SRD_SAP  List = empty \n");
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					printf("=========== %d \n",i);
			}
			else
			{		
			// temp->next != NULL

										// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
					printf("=========== %d \n",i);
						i++;
						temp = temp->next;
					}
					printf("=========== %d \n",i);
					printf(" End List \n");
			}
	}

				return 1;
}

*/



INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit)
{
	INT8U index;
	INT8U error;
	INT8U i,j;
	FDL_SRD_SSAP_LIST * temp;
	FDL_SRD_SSAP_LIST * p;

	i = 0;
	printf(">FDL_SRD_REPLY_UPDATE %d \n",SRD_SSAP);
	// 1. �� index �ͧ FDL_SRD_SSAP ���������� 0, 54-62 ����ͧ���
	temp = db_srd_ssap_list;

	error = 2;
	if ( temp == NULL ) // 0
	{
			printf(">SRD SAP Buffer List = empty \n");
			error = 1;
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					if (  temp->FDL_SSAP_NO == SRD_SSAP)
					{
						p = temp;	error = 0;
					}
 			}
			else
			{		
					// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
							if (  temp->FDL_SSAP_NO == SRD_SSAP)
							{
								p = temp;	error = 0;
							}
							i++;
							temp = temp->next;
					}
							if ( temp ->FDL_SSAP_NO == SRD_SSAP)
							{
								p = temp;	error = 0;
							}

			}
	}

	if (error == 0)
	{
					printf(">UPDATE OK\n");
	// 2. ��˹���� parameter ��� index �ͧ FDL_SRD_SSAP (0, 54-62)
					//temp->FDL_SSAP_NO = SRD_SSAP;
					p->FDL_SSAP_data_len = SRD_data_length ;				
					for (i=0;i<p->FDL_SSAP_data_len;i++)
					{
						 p->FDL_SSAP_data_unit[i] = *(SRD_data_unit+i*sizeof(INT8U) );
					}
					p->FDL_SSAP_Serv_class = SRD_Serv_class;
					p->FDL_SSAP_Transmit  = SRD_Transmit;
	}
	return error;
}

INT8U FDL_SC_respond()
{
	INT8U x;
	x = 0xe5;
	PHY_DATA_PUT( x);
	return 0;
}
void FDL_SRD_respond()
{

		switch ( telegram_rx.SD2_dsap )
		{
				case 0: // SRD-NIL(0)
				{
						FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
				}
				break;
				case 55: // SRD-SAP55 : Change Station Address (Set_Slave_Add)
				{
						//FDL_SC_respond();
				}	
				break;
				case 56: //  SRD-SAP56 : Read Inputs (Rd_Inp)
				{
						FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
				}
				break;
				case 57: // SRD-SAP57 : Read Outputs (Rd_Outp)
				{
						FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
				}
				break;
				case 59: // SRD-SAP59 : Read Configuration Data (Get_Cfg)
				{
 						FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
				}
				break;
				case 60: // SRD-SAP60 : Read Diagnostic Data (Slave_Diagnosis)
				{
						FDL_SRD_REPLY_UPDATE_respond( telegram_rx.SD2_dsap , telegram_rx.SD2_ssap,telegram_rx.SD2_sa );
				}
				break;
				case 61: // SRD-SAP61 : Send Parameterization Data (Set_Prm)
				{
						FDL_SC_respond();
				}
				break;
				case 62: // SRD-SAP62 : Check Configuration Data (Chk_Cfg)
				{
						FDL_SC_respond();
				}
				break;
				case 54: // SRD-SAP54 :  Master-to-Master SAP (M-M Communication)
				default: 
				{
						printf(">SRD Not Respond this sap %02X\n", telegram_rx.SD2_dsap); 				
				}
				break;
		}
	

}

 
INT8U FDL_SRD_REPLY_UPDATE_respond(INT8U SRD_SSAP,INT8U SRD_DSAP,INT8U SRD_Rem_add)
{
// reply _ update
	INT8U index;
	INT8U error;
	INT8U i,j;
	FDL_SRD_SSAP_LIST * temp;
	FDL_SRD_SSAP_LIST * p;
// send srd
	INT8U L_status;
	INT8U telegram_tx[MTU_TX];
	INT8U telegram_tx_len;
 	INT8U checksum;	

	i = 0;
	
	printf(">FDL_SRD_REPLY_UPDATE_respond\n");
	// 1. �� index �ͧ FDL_SRD_SSAP ���������� 0, 54-62 ����ͧ���
	temp = db_srd_ssap_list;

	error = 2;
	if ( temp == NULL ) // 0
	{
			printf(" SRD SAP Buffer List = empty \n");
			error = 1;
	}
	else
	{
			if (temp->next == NULL) // 0
			{
					i = 0;
					if (  temp->FDL_SSAP_NO == SRD_SSAP)
					{ 					printf(" Found SSAP  \n");
						p = temp;	error = 0;
					}
 			}
			else
			{		
					// ǹ��������� � ���͵���ش����
					while (temp->next != NULL )
					{
							if (  temp->FDL_SSAP_NO == SRD_SSAP)
							{						printf(" Found SSAP \n");
								p = temp;	error = 0;
							}
							i++;
							temp = temp->next;
					}
							if (  temp->FDL_SSAP_NO == SRD_SSAP)
							{						printf(" Found SSAP \n");
								p = temp;	error = 0;
							}

			}
	}

				// 2. ��˹���� parameter ��� index �ͧ FDL_SRD_SSAP (0, 54-62)

				// create telegram
				// 1. SD2
				telegram_tx[0] = 0x68;														// SD2
				telegram_tx[3] = 0x68;														// SD2
				// 2. DA - Destination Address
				telegram_tx[4] = SRD_Rem_add;											// DA
				// 3. SA - Source Address = This Address = FDL_VARIABLE.FDL_TS
				telegram_tx[5] = FDL_VARIABLE.FDL_TS;						// SA

				// 4. FC
				telegram_tx[6] = 0x00;



	if (error == 0)
	{
				// 4.1 ��鹡Ѻ��Դ Station , req-respond , ....????
				// x1xx-xxxx	 Request, Send/Request Frame  => 4

				// 4.2
				// Serv_class 
				// xxxx-1100 Send and Request Data with Reply low	=> 8	 8
				// xxxx-1101 Send and Request Data with Reply high   => 10  A
				if ( p->FDL_SSAP_Serv_class == Serv_Class_High)
				{
					telegram_tx[6] |= 0x08;
				}
				else
				{
					telegram_tx[6] |= 0x0A;
				}
				// xxxx-1100 Send and Request ... No Data with Reply low	=> 12	 C
				// xxxx-1101 Send and Request ... No Data with Reply high   => 13  D
				if (p->FDL_SSAP_Transmit == Transmit_no_data )
				{
					if ( p->FDL_SSAP_Serv_class == Serv_Class_High)
					{
						telegram_tx[6] |= 0x0C;
					}
					else
					{
						telegram_tx[6] |= 0x0D;
					}
				}
//				printf("xxx %X \n",telegram_tx[6]);
				if (SRD_DSAP > 0)
				{
						telegram_tx[4] = telegram_tx[4] | 0x80;
						telegram_tx[5] = telegram_tx[5] | 0x80;
						telegram_tx[1] = p->FDL_SSAP_data_len +5;				// LE
						telegram_tx[2] = p->FDL_SSAP_data_len +5;				// LEr

						telegram_tx[7] = SRD_DSAP;									// DSAP
						telegram_tx[8] = SRD_SSAP;									// SSAP
						j = 9;
						for (i=0;i<p->FDL_SSAP_data_len ;i++)
						{
							 telegram_tx[j] =  p->FDL_SSAP_data_unit[i]; //   *(SRD_data_unit+i*sizeof(INT8U) );
							 j++;
						}
				}
				else
				{
						telegram_tx[4] &= 0x7F;
						telegram_tx[5] &= 0x7F;
						telegram_tx[1] = p->FDL_SSAP_data_len +3;				// LE
						telegram_tx[2] = p->FDL_SSAP_data_len +3;				// LEr

						j = 7;
						for (i=0;i<p->FDL_SSAP_data_len ;i++)
						{
							 telegram_tx[j] =  p->FDL_SSAP_data_unit[i]; //   *(SRD_data_unit+i*sizeof(INT8U) );
							 j++;
						}
				}
				// DATA 
				checksum = 0;
				for (i=4;i<j;i++)
				{
					checksum = checksum + telegram_tx[i];
				}
				telegram_tx[j] = checksum;		// FCS
				 j++;
				telegram_tx[j] = 0x16;					// Ed
				 j++;
				telegram_tx_len = j;
				if (p->FDL_SSAP_Transmit == Transmit_Single )
				{
					p->FDL_SSAP_Transmit = Transmit_no_data;
					p->FDL_SSAP_data_len = 0;
				}
	}
	else 
	{
				telegram_tx[6] |= 0x00; 

				if (SRD_DSAP > 0)
				{
						telegram_tx[4] = telegram_tx[4] | 0x80;
						telegram_tx[5] = telegram_tx[5] | 0x80;
						telegram_tx[1] = 0 +5;				// LE
						telegram_tx[2] = 0 +5;				// LEr

						telegram_tx[7] = SRD_DSAP;									// DSAP
						telegram_tx[8] = SRD_SSAP;									// SSAP
						j = 9;
						for (i=0;i<0 ;i++)
						{
							 telegram_tx[j] =  0; //   *(SRD_data_unit+i*sizeof(INT8U) );
							 j++;
						}
				}
				else
				{
						telegram_tx[4] &= 0x7F;
						telegram_tx[5] &= 0x7F;
						telegram_tx[1] = 0 +3;				// LE
						telegram_tx[2] = 0 +3;				// LEr

						j = 7;
						for (i=0;i<0 ;i++)
						{
							 telegram_tx[j] =  0; //   *(SRD_data_unit+i*sizeof(INT8U) );
							 j++;
						}
				}
				// DATA 
				checksum = 0;
				for (i=4;i<j;i++)
				{
					checksum = checksum + telegram_tx[i];
				}
				telegram_tx[j] = checksum;		// FCS
				 j++;
				telegram_tx[j] = 0x16;					// Ed
				 j++;
				telegram_tx_len = j;
	}

			#ifdef  fdl_debug		
													printf(" FDL TX >>> ");
													for ( i=0;i<telegram_tx_len;i++ )
													{
														if ( i % 16 == 0) {printf("\n- ");}
														printf("%02X ",telegram_tx[i]);
													}
													printf("\n- len = %d\n",telegram_tx_len);
			#endif 		
				// send telegram
				for (i=0;i<telegram_tx_len;i++)
				{
					PHY_DATA_PUT(telegram_tx[i] );
				}
	// return status
	L_status = 0;
	return L_status;


}

