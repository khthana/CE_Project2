// 
// Profibus DP 
// 
#include "includes.h"
#include "fdl.h"
#include "phy.h"
#include "ddlm.h"
#include "user.h"
#include "ui.h"

char					Task_5_Data;     
OS_STK			Task_5_Stk[TASK_STK_SIZE];
extern OS_EVENT	*	sem_printf;
extern OS_EVENT	*  fdl_event;
extern INT8U	EVENT_SRD_indication;
extern INT8U	EVENT_SDN_indication;

static Diagnostic Diag1;
static Configuration Cfg1;

void Init_Diagnostic_Data(Diagnostic *Diag);
void Init_Configuration_Data(Configuration *Cfg);
void Octet_Diagnostic_Data(Diagnostic *Diag);
void Octet_Configuration_Data(Configuration *Cfg);
extern TELEFRAM_SD2 telegram_rx;
TELEFRAM_SD2		ddlm_rx_telegram;

// DDLM VAR
BOOLEAN Prev_Diag_Flag;
INT8U Loc_Station_Address;
/*
INT8U DDLM_Set_Prm_ind;
INT8U DDLM_Chk_Cfg_ind;
INT8U DDLM_Data_Exchange_ind;
INT8U DDLM_Slave_Diag_ind;
INT8U DDLM_Global_Control_ind;
INT8U DDLM_Set_Slave_ind;
*/
INT8U DDLM_STATE;

/*
typedef struct 
{
	INT8U	SD2_sd;
	INT8U	SD2_da;
	INT8U	SD2_sa;
	INT8U	SD2_fc;
	INT8U	SD2_dsap;
	INT8U	SD2_ssap;
	INT8U	SD2_data_unit[MTU_DATA];
	INT8U   SD2_data_length;
} TELEFRAM_SD2;
*/

/**************************************** Define Variable ****************************************************/
/*
	INT8U Diag_Data[Length_Diag];
	INT8U Real_Cfg_Data;
		
	INT8U minTSDR;

	INT8U Master_Add;
	INT8U Req_Add;
	INT8U Ready;
*/

// DDLM Function
void DDLM_Set_Prm_ind ();	// 61
void DDLM_Chk_Cfg_ind (); // 62
void DDLM_Data_Exchange_ind (); // 0
void DDLM_Slave_Diag_ind ();	// 60
void DDLM_Global_Control_ind ( ); // 58
void DDLM_Set_Slave_ind (); // 55

// Call Indicate in UI
extern void UI_Set_Prm_ind (INT8U Req_Add,INT8U * Prm_Data,INT8U Prm_Data_len);	// 61
extern void UI_Chk_Cfg_ind (INT8U Req_Add,INT8U * Cfg_Data,INT8U Cfg_Data_len  ); // 62
extern void UI_Data_Exchange_ind (INT8U * Outp_Data,INT8U Outp_Data_len); // 0
extern void UI_Slave_Diag_ind (INT8U Req_Add);	// 60
extern void UI_Global_Control_ind (INT8U Req_Add,INT8U Control_Command,INT8U Group_Select ); // 58
extern void UI_Set_Slave_ind (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg); // 55

void  Task_5 ()
{
	 INT8U  err;
	 INT8U i;	

	 while (1) 

	{
			//ddlm_state();



	 		OSTimeDly(100);                            /* Delay 1 clock tick                                 */
	 }

}



void ddlm_state()
{
		 INT8U  err;

	switch (DDLM_STATE)
	{
		case DDLM_STATE_RUN : // wait all - runing - idle
		{

		}
		break;
		case DDLM_STATE_INI1 :  // ������¡�����¡ DDLM_Slave_Init
		{
				// wait  for DLLM_SLAVE_Init.req - from User Interface
				printf(">DDLM_STATE_INI1 \n");
				FMA_1_2_RESET();
				DDLM_STATE = DDLM_STATE_INI3;			// next state;
		}
		break;
		case DDLM_STATE_INI3 :	// ������¡�����¡ DDLM_STATE_INI1
		{
				printf(">DDLM_STATE_INI3 \n");

				DDLM_STATE = DDLM_STATE_INI4;
	//			DDLM_STATE = DDLM_STATE_RUN;
		}
		break;
		case DDLM_STATE_INI4 : // ������¡�����¡ DDLM_Enter
		{

				DDLM_STATE = DDLM_STATE_INI6;
		}
		break;
		case DDLM_STATE_INI5 : // ������¡�����¡ DDLM_Enter
		{
				// wait  for DLLM_SLAVE_Init.req - from User Interface

		}
		break;
		case DDLM_STATE_INI6:
		{

		}
		break;
	}

}

void ddlm_srd_service( )
{
		// 1. Copy �ҡ FDL ���纷�� DDLM
		printf(">DDLM SRD_indication \n"); 
		ddlm_rx_telegram = telegram_rx;
		ddlm_printf(ddlm_rx_telegram);
		// 2. �����żŵ���ѧ��ѹ��ҧ � 
		switch ( ddlm_rx_telegram.SD2_dsap)
		{
				case 0:
				{
						printf(">DDLM SRD-NIL(0) :  Data Exchange (Write_Read_Data)\n"); 	
						// SAP 0
						DDLM_Data_Exchange_ind (); 
				}
				break;
				case 54:
				{
						printf(">DDLM SRD-SAP54 : Master-to-Master SAP (M-M Communication)\n"); 	
				}
				break;
				case 55:
				{
						printf(">DDLM SRD-SAP55 : Change Station Address (Set_Slave_Add)\n"); 	
						// SAP 55
						DDLM_Set_Slave_ind (); // 55
				}
				break;
				case 56:
				{
						printf(">DDLM SRD-SAP56 : Read Inputs (Rd_Inp)\n"); 					
				}
				break;
				case 57:
				{
						printf(">DDLM SRD-SAP57 : Read Outputs (Rd_Outp)\n"); 				
				}
				break;
				case 59:
				{
						printf(">DDLM SRD-SAP59 : Read Configuration Data (Get_Cfg)\n"); 
				}
				break;
				case 60:
				{
						printf(">DDLM SRD-SAP60 : Read Diagnostic Data (Slave_Diagnosis)\n"); 
						// SAP 60
						DDLM_Slave_Diag_ind ();	 // 60
				}
				break;
				case 61: // 3D
				{
						printf(">DDLM SRD-SAP61 : Send Parameterization Data (Set_Prm)\n"); 				
						// SAP 61
						DDLM_Set_Prm_ind ();	// 61
				}
				break;
				case 62:
				{
						printf(">DDLM SRD-SAP62 : Check Configuration Data (Chk_Cfg)\n"); 				
						// SAP 62
						DDLM_Chk_Cfg_ind (); // 62
				}
				break;
				default: 
				{
						printf(">DDLM SRD No Service\n"); 				
				}
				break;
		}
	

}

void ddlm_sdn_service( )
{
		// 1. Copy �ҡ FDL ���纷�� DDLM
		printf(">DDLM SDN_indication \n"); 
		ddlm_rx_telegram = telegram_rx;
		ddlm_printf(ddlm_rx_telegram);
		// 2. �����żŵ���ѧ��ѹ��ҧ � 
		switch ( ddlm_rx_telegram.SD2_dsap)
		{
				case 58:
				{
						printf(">DDLM SRD-SAP58		Control Commands to a DP Slave (Global_Control)\n"); 	
						//DDLM_Global_Control_ind = 1;		// SAP 58
						DDLM_Global_Control_ind ( ); // 58
				}
				break;
				default: 
				{
						printf(">DDLM SDN No Service\n"); 				
				}
				break;
		}
}
/*
typedef struct 
{
	INT8U	SD2_sd;
	INT8U	SD2_da;
	INT8U	SD2_sa;
	INT8U	SD2_fc;
	INT8U	SD2_dsap;
	INT8U	SD2_ssap;
	INT8U	SD2_data_unit[MTU_DATA];
	INT8U   SD2_data_length;
} TELEFRAM_SD2;
*/
void ddlm_printf(TELEFRAM_SD2 temp)
{
		INT8U i;
		printf(">DDLM printf\n");
		printf(" SD DA SA FC DSAP SSAP\n");
		printf(" %02X %02X %02X %02X %4X %4X\n"
		,temp.SD2_sd,temp.SD2_da,temp.SD2_sa,temp.SD2_fc,temp.SD2_dsap,  temp.SD2_ssap  );

		printf(" DATA=");
		for (i=0;i<temp.SD2_data_length ; i++)
		{
				if ( i % 16 == 0) { printf("\n- ");}
					printf(" %02X",temp.SD2_data_unit[i]);	
		}
		printf("  len = %02X\n",temp.SD2_data_length);

}


// ================================================================================
// new version - Indication

void DDLM_Set_Prm_ind ()	// 61
{
		UI_Set_Prm_ind( ddlm_rx_telegram.SD2_sa, &ddlm_rx_telegram.SD2_data_unit[0] , ddlm_rx_telegram.SD2_data_length );
 //     UI_Set_Prm_ind (INT8U Req_Add,INT8U * Prm_Data,INT8U Prm_Data_len);	// 61
}

void DDLM_Chk_Cfg_ind () // 62
{
		UI_Chk_Cfg_ind( ddlm_rx_telegram.SD2_sa, &ddlm_rx_telegram.SD2_data_unit[0] , ddlm_rx_telegram.SD2_data_length );
//      UI_Chk_Cfg_ind (INT8U Req_Add,INT8U * Cfg_Data,INT8U Cfg_Data_len  ); // 62
}
void DDLM_Data_Exchange_ind () // 0
{
		UI_Data_Exchange_ind(  &ddlm_rx_telegram.SD2_data_unit[0] , ddlm_rx_telegram.SD2_data_length );
 //     UI_Data_Exchange_ind (INT8U * Outp_Data,INT8U Outp_Data_len); // 0
}
void DDLM_Slave_Diag_ind ()	// 60
{
		UI_Slave_Diag_ind( ddlm_rx_telegram.SD2_sa );
//      UI_Slave_Diag_ind (INT8U Req_Add);	// 60
}
void DDLM_Global_Control_ind ( ) // 58
{
		UI_Global_Control_ind(  ddlm_rx_telegram.SD2_sa, ddlm_rx_telegram.SD2_data_unit[0] , ddlm_rx_telegram.SD2_data_unit[1] );
 //     UI_Global_Control_ind (INT8U Req_Add,INT8U Control_Command,INT8U Group_Select ); // 58
}
void DDLM_Set_Slave_ind () // 55
{
		INT8U	New_Slave_Add ;
		INT16U Ident_Number;
		INT8U	temp;
		BOOLEAN No_Add_Chg;

		printf("1-? %02X %02X \n",ddlm_rx_telegram.SD2_data_unit[1],ddlm_rx_telegram.SD2_data_unit[2] );

		New_Slave_Add = ddlm_rx_telegram.SD2_data_unit[0];

 		temp = ddlm_rx_telegram.SD2_data_unit[2];
 		ddlm_rx_telegram.SD2_data_unit[2] = ddlm_rx_telegram.SD2_data_unit[1];
 		ddlm_rx_telegram.SD2_data_unit[1] = temp;
 		memcpy(&Ident_Number,&ddlm_rx_telegram.SD2_data_unit[1], sizeof(INT16U)  );

		if ( ddlm_rx_telegram.SD2_data_unit[3] == 1)
		{				No_Add_Chg = 1;		}
		else
		{				No_Add_Chg = 0;		}
		
		printf("2-? n %d i %04X b = %d\n",New_Slave_Add, Ident_Number,No_Add_Chg );

		if (ddlm_rx_telegram.SD2_data_length == 4)
		{		UI_Set_Slave_ind(  New_Slave_Add, Ident_Number, No_Add_Chg );		}
//      UI_Set_Slave_ind (INT8U New_Slave_Add,INT16U Ident_Number,BOOLEAN No_Add_Chg); // 55s
}




//======================== 1. DDLM_Slave_Init  =========================
//
// DDLM_Slave_Init.request  --> ( Station_Address)
// 

INT8U DDLM_Slave_Init (INT8U Station_Address)
{	
	//INI1
	printf(">DDLM_STATE_INI1 \n");
	Loc_Station_Address = Station_Address;

	FMA_1_2_RESET();
	//INI3
	printf(">DDLM_STATE_INI3 \n");
	FMA_1_2_SET_VALUE_TS	(Loc_Station_Address);
	FDL_RSAP_ACTIVATE(60,Access_All,Indication_Mode_All);
	FDL_RSAP_ACTIVATE(61,Access_All,Indication_Mode_All);
	FDL_RSAP_ACTIVATE(62,Access_All,Indication_Mode_All);
	FDL_RSAP_ACTIVATE(59,Access_All,Indication_Mode_Data);
	FDL_RSAP_ACTIVATE(55,Access_All,Indication_Mode_Data);

	return 0;
}
//======================== 2. DDLM_Enter_req  =========================

INT8U DDLM_Enter_req (INT8U Master_Add	)
{	
	printf(">DDLM_STATE_INI4 \n");
	FDL_RSAP_ACTIVATE(0  ,Access_All,Indication_Mode_All);
	FDL_RSAP_ACTIVATE(56,Access_All,Indication_Mode_All);
	FDL_RSAP_ACTIVATE(57,Access_All,Indication_Mode_All);
	FDL_SAP_ACTIVATE(58,Master_Add,Service_type_SDN,Role_in_service_Responder);

}

//======================== 3. DDLM_Leave_req  =========================
INT8U DDLM_Leave_req (	)
{	
	printf(">DDLM_STATE_INI5 \n");
	FDL_SAP_DEACTIVATE(0);
	FDL_SAP_DEACTIVATE(56);				
	FDL_SAP_DEACTIVATE(57);				
	FDL_SAP_DEACTIVATE(58);
	return 0;
}

//======================= 4. DDLM_Set_minTsdr =========================
// 
// DDLM_Set_minTsdr.request		-->	(minTsdr)
//

INT8U DDLM_Set_minTsdr (INT16U minTSDR)
{
	printf(">DDLM_STATE_INI7 \n");
	FMA_1_2_SET_VALUE_min_TSDR(minTSDR);
	return 0;
}


// Data Transfer
//======================= 5. DDLM_Data_Exchange_Upd_req =========================

INT8U DDLM_Data_Exchange_Upd_req(BOOLEAN Diag_Flag,INT8U * Inp_Data ,INT8U Inp_Data_len )
{	
	// Diag_Flag
	// True: diagnostic existent
	// False: No diagnostic information
	
	if (Diag_Flag == 0 && Prev_Diag_Flag == 0 && Inp_Data_len > 0 )
	{
		// SSAP = 0 , DATA1
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,Inp_Data_len,Serv_Class_Low,Transmit_Multi);
	}
	else
	if (Diag_Flag == 0 && Prev_Diag_Flag == 1 && Inp_Data_len > 0 )
	{
		// SSAP = 0 , DATA3
		Prev_Diag_Flag = 0;
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,Inp_Data_len,Serv_Class_Low,Transmit_Multi);
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,0 ,Serv_Class_High,Transmit_Single);
	}
	else
	if (Diag_Flag == 0 && Prev_Diag_Flag == 1 && Inp_Data_len == 0 )
	{
		// SSAP = 0 , DATA4
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,0 ,Serv_Class_High,Transmit_Single);
		Prev_Diag_Flag = 0;
	}
	else
	if (Diag_Flag == 1 && Inp_Data_len > 0 )
	{
		// SSAP = 0 , DATA5
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,Inp_Data_len,Serv_Class_High,Transmit_Multi);
		Prev_Diag_Flag = 1;
	}
	else
	if (Diag_Flag == 1 && Inp_Data_len == 0 )
	{
		// SSAP = 0 , DATA6
		*Inp_Data = 0;
		FDL_SRD_REPLY_UPDATE(0,Inp_Data,1,Serv_Class_High,Transmit_Multi);
		Prev_Diag_Flag = 1;
	}

	// SSAP = 0
// INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
	return 0;
}

//======================= 6. DDLM_Slave_Diag_Upd_req =========================

INT8U DDLM_Slave_Diag_Upd_req( INT8U * Diag_Data ,INT8U Diag_Data_len )
{	
	// SSAP = 60
	FDL_SRD_REPLY_UPDATE(60 , Diag_Data , Diag_Data_len , Serv_Class_Low  ,  Transmit_Multi  );
// INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
	return 0;
}

//======================= 7. DDLM_Get_Cfg_Upd_req =========================

INT8U DDLM_Get_Cfg_Upd_req( INT8U * Real_Cfg_Data ,INT8U Real_Cfg_Data_len )
{	
	// SSAP = 59
	FDL_SRD_REPLY_UPDATE(59 , Real_Cfg_Data , Real_Cfg_Data_len , Serv_Class_Low  ,  Transmit_Multi  );
// INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
	return 0;
}

//======================= 8. DDLM_RD_Inp_Upd_req =========================

INT8U DDLM_RD_Inp_Upd_req( INT8U * Inp_Data ,INT8U Inp_Data_len )
{	
	// SSAP = 56
	if ( Inp_Data_len > 0 )
	{
		FDL_SRD_REPLY_UPDATE(56 , Inp_Data , Inp_Data_len , Serv_Class_High  ,  Transmit_Multi  );
	}
// INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
	return 0;
}

//======================= 8. DDLM_RD_Outp_Upd_req =========================

INT8U DDLM_RD_Outp_Upd_req( INT8U * Outp_Data ,INT8U Outp_Data_len )
{	
	// SSAP = 57
	if ( Outp_Data_len > 0)
	{
		FDL_SRD_REPLY_UPDATE(57 , Outp_Data , Outp_Data_len , Serv_Class_High  ,  Transmit_Multi  );
	}
// INT8U FDL_SRD_REPLY_UPDATE(INT8U SRD_SSAP,INT8U * SRD_data_unit,INT8U SRD_data_length,INT8U SRD_Serv_class,INT8U SRD_Transmit);
	return 0;
}

INT8U DDLM_FAULT()
{
/*
- FMA1/2_RESET.con (NO/IV)
- FMA1/2_SET_VALUE.con (NO/IV)
- FMA1/2_RSAP_ACTIVATE.con (NO/IV)
- FMA1/2_SAP_ACTIVATE.con (NO/IV)
- FMA1/2_SAP_DEACTIVATE.con (NO/IV)
- FDL_REPLY_UPDATE.con (LS/LR/IV)
- FDL_DATA_REPLY.ind (DSAP inadmissible)
- FDL_DATA.ind (DSAP inadmissible)
- unknown FDL or FMA1/2 primitive
*/
	return 0;
}