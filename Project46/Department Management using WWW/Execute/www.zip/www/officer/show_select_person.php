<?
	session_start();
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	$sql="	select * from administrator where ad_user='$ad_user'";
	$query=mysql_db_query("webce",$sql);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	
	if( ($ad_user!='root')||($ad_code!=$tmp) ){
		session_destroy();
		mysql_close();
		print "<META http-equiv=refresh content='0; URL=http://isag25.ce.kmitl.ac.th/~gead/officer/'>";
		exit();
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>����к�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="./include/stylesheet.css" type=text/css rel=stylesheet>

</head>

<body  leftmargin="0" topmargin="0" >
<table  width="780" border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      <td width="780" valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="pic/headce_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		    <TD height="43" class="linebottom"> <IMG SRC="pic/headce_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		    <TD class="linebottom"> <img src="pic/headce_07.gif" width=222 height=42 alt=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
    </tr>
    <tr> 
      <td valign="top" nowrap bgcolor="#FFFFFF" class="linetop">&nbsp;</td>
    </tr>
    <tr > 
      <td  align="center" height="400" valign="top" nowrap> 
	  <table width="600" border="0" cellspacing="0" cellpadding="0" >
        <?

	

?>
        <tr> 
          <td bgcolor="#F5F5DC" ><br>
            <a href='Admin_person/admin/show_admin.php'>&nbsp; ��䢢����ż������к� 
            </a><br>
            &nbsp;�����źؤ�ҡâͧ�Ҥ�<br>
            <a href='../user/logout.php?logout=logout'>&nbsp;�͡�ҡ�к�</a><br>
            &nbsp; <br>
            </td>
          
          <td valign='top' > <table width='100%' >
              <tr bgcolor='#F7F7F7'> 
                <td height='30'> <div align="center"><strong>�����źؤ�ҡâͧ�Ҥ�Ԫ����ǡ�������������</strong></div></td>
              </tr>
              <tr bgcolor='#F7F7F7'> 
                <td height='23' bgcolor='#F7F7F7'> <div align='center'>
                    <a href='Admin_person/Teacher/teacher_show.php'> 
                    �������Ҩ����</a></div></td>
              </tr>
              <tr bgcolor='#F7F7F7'> 
                <td height='23'> <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
                  <div align='center'>
                    
                      <a href='Admin_person/Officer/officer_show.php'>���������˹�ҷ��</a></font></font></font></div>
                  </div></td>
              </tr>
            </table></td>
        </tr>
      </table>
      <tr >
      <td height="60"  background="pic/b.jpg"><font  color="#000099" size="-2"  class="violet">&nbsp; 
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<br>
        &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font> </td>
    </tr>
  <tr>
    <td height="10">&nbsp;</td>
    </tr>
 
</table>
</body>
</html>
