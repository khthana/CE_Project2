<?
$result = mkdir ("../Admin_person/Teacher/Picture_teacher_397", 0777);
if($result ){
	echo "HEY";
}else{
	echo "FUCK";
}
?>