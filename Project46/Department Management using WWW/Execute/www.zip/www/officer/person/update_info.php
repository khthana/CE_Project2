<?
session_start();
include('connect_home.inc.php');
include('function.php');
$query = "SELECT  * FROM $Officertable WHERE id = '$id' ";
			$result_select1 = mysql_query($query);
			  $row = mysql_fetch_array($result_select1); 
				$status = $row['status'];
	if( $status !== 'officer' ){
		$query = "UPDATE  $Officertable SET   name = '$uname', email = '$email', telephone = '$telephone', link = '$link', address = '$address',
							graduation = '$graduation', schedule = '$schedule', meeting = '$meeting', interest = '$interest', experience = '$experience', last_update = '$date' WHERE id = '$id' ";

	} else {
		$query = "UPDATE  $Officertable SET   name = '$uname', email = '$email', telephone = '$telephone', link = '$link', address = '$address',
							graduation = '$graduation', last_update = '$date' WHERE id = '$id' ";

	}
		$result = mysql_query($query) or die ( mysql_error() );
		if($picture != 'none'){
				$test = @opendir("../Admin_person/Teacher/Picture_teacher_$id");
				if (empty($test)) { 
					mkdir ("../Admin_person/Teacher/Picture_teacher_$id", 0777);
				}
					$result_pic = copy($picture,"../Admin_person/Teacher/Picture_teacher_$id/".$picture_name);
					$query = "UPDATE  $Officertable SET  picture = '$picture_name' WHERE id = '$id' ";
					$result = mysql_query($query) or die ( mysql_error() );
								
		} 	
			if(  !$result ){ 			
				echo Message(35,"red","�������ö upload ��������","��سҵ�Ǩ�ͺ�����١��ͧ","<a href='javascript:history.back(1)'> [ ��Ѻ���� ] </a>");			
		}else{
				echo Message(35,"green"," upload ���������º�������� ","","<a href='http://www.ce.kmitl.ac.th'>[  ˹���á ] </a>&nbsp;&nbsp; <a href='person.php?&id=$id' >[ �٢����� ]</a>");
		}
						  mysql_close();
?>
<html>
<head>
<title>Change Picture</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<LINK href="stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
</body>
</html>

