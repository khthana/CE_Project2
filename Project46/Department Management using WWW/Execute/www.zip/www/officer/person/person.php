<?
session_start();
include ("connect_home.inc.php");
include("function.php");

$query = "Select * From $Officertable Where id = '$id' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result,MYSQL_ASSOC);		
							
								$id = htmlspecialchars($row['id']);														
								$picture = htmlspecialchars($row['picture']);
								$realname = htmlspecialchars($row['name']);
								$email = htmlspecialchars($row['email']);
								$position = htmlspecialchars($row['position']);
								$link = htmlspecialchars($row['link']);
								$telephone = htmlspecialchars($row['telephone']);
								$graduation = $row['graduation'];
								$schedule = $row['schedule'];
								$meeting = $row['meeting'];
								$interest = $row['interest'];
								$experience = $row['experience'];
								$address = $row['address'];
								$status = $row['status'];
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�������Ҩ����  </title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementByid) x=d.getElementByid(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<table  width="780"   border="0" cellpadding="0" cellspacing="0" >
  <tr> 
    <td width="780" valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/person_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="../pic/person_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
  </tr>
  <tr>
    <td class="linetop" valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
          <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF">&nbsp;	           
	</td>
  </tr>
  <tr> 
    <td > <table width="100%" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr> 
          <td  valign="top" nowrap><table width="100%" border="0" cellpadding="0" cellspacing="0" >
              <tr> 
                <td width="3%" rowspan="7" bgcolor="#F5F5F5">&nbsp; </td>
                <td width="16%" rowspan="7" bgcolor="#F5F5F5">
<table align="left" width="150" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    <td align="center" width="150">
                          <? $path = "../Admin_person/Teacher/Picture_teacher_$id/$picture";
						  echo "<img src= '$path' border='1' width='150' align='middle'>"; ?>	
	</td>
  </tr>
</table>
                </td>
                <td width="31%" bgcolor="#F5F5F5"> <div align="right">����-���ʡ�� 
                    :&nbsp;</div></td>
                <td width="50%" bgcolor="#FFF7D7">&nbsp;<? echo $realname; ?> 
                </td>
              </tr>              
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">���˹�/˹�ҷ�� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $position; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">e-mail :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo  $email; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">�������Ѿ�� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $telephone ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">�ԧ����ǹ��� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp; <? echo $link; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">��ͧ�ӧҹ :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $address; ?></td>
              </tr>
              <tr> 
                <td height="20" bgcolor="#F5F5F5"> &nbsp; 
                  <? if(  ($accesslevel >1)&&($id == $pid ) ){ ?>
                  <a   href="http://isag25.ce.kmitl.ac.th/~gead/officer/person/person_info.php"><font color="#FF0000">��䢢�������ǹ���</font></a> 
                  <? } 
				?>
                </td>
                <td bgcolor="#FFF7D7">&nbsp;</td>
              </tr>
              <tr> 
                <td  colspan="4" height="250" valign="top" nowrap ><table width="100%" border="0" cellspacing="2" cellpadding="2">
                    <tr> 
                      <td  align="right" width="40%" bgcolor="#F5F5F5">�س�ز� 
                        �Ң��Ԫ� ʶҹ����֡��</td>
                      <td width="60%" bgcolor="#FFFCF0"><? echo $graduation; ?></td>
                    </tr>
                    <?
if( $status !== 'officer' ){
?>
                    <tr> 
                      <td align="right" bgcolor="#F5F5F5">�ŧҹ�ҧ�Ԫҡ��&nbsp;</td>
                      <td bgcolor="#FFFCF0"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <?
					$query = "Select * From $Research  Where pid = '$id' ";
					$result = mysql_query($query);				
							while($row = mysql_fetch_array($result)){
?>
                          <tr> 
                            <td bgcolor="#FFFCF0"><a href = "research.php?&res_id=<?echo $row['res_id']?>"><? echo $row['title']?></a></td>
                          </tr>
                          <? } ?>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="right" bgcolor="#F5F5F5">�ҹ�͹&nbsp;</td>
                      <td bgcolor="#FFFCF0"><? echo  $schedule;?></td>
                    </tr>
                    <tr> 
                      <td  align="right" bgcolor="#F5F5F5">���Ҿ����Ե&nbsp;</td>
                      <td bgcolor="#FFFCF0"><? echo  $meeting;?></td>
                    </tr>
                    <?
		}			
	?>
                    <tr> 
                      <td  align="right" bgcolor="#F5F5F5">����ʹ�&nbsp;</td>
                      <td bgcolor="#FFFCF0"><? echo $interest?></td>
                    </tr>
                    <tr> 
                      <td  align="right"bgcolor="#F5F5F5">���ʺ��ó�����&nbsp;</td>
                      <td bgcolor="#FFFCF0"><? echo $experience;?></td>
                    </tr>
                    <tr> 
                      <td align="right" bgcolor="#F5F5F5">&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table> </td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">Department 
            of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
        </tr>
      </table></td>
  <tr> 
    <td height="10">&nbsp;</td>
  </tr>
</table>
</body>
</html>
