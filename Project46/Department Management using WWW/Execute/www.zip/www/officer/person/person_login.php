<?
session_start();
include ("connect_home.inc.php");
include("function.php");

if (empty($valid_user))
{
	if($username && $password)
	{			
				$sql = "select * from $Officertable where Username = '$username' and Password = MD5('$password')";
				$result=mysql_query($sql) or die(mysql_error());
	
	if(mysql_num_rows($result)>0){
			$valid_user=$username;
			session_register("valid_user");
		}
	else
		{
		echo "<tr align=center><td><font face = \"MS Sans Serif\" color=\"#ff0000\" size=\"3\">�س�������ö���� login �� </font></td></tr>";
	exit;
		}
	}
}
check_admin();
$query = "Select * From $Officertable Where Username = '$username' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							
								$id = htmlspecialchars($row['ID']);								
								$picture = htmlspecialchars($row['Picture']);
								$name = htmlspecialchars($row['Name']);
								$email = htmlspecialchars($row['Email']);
								$level = htmlspecialchars($row['Level']);
								$tlink = htmlspecialchars($row['Tlink']);
								$telephone = htmlspecialchars($row['Telephone']);
								$graduation = $row['Graduation'];
								$research = $row['Research'];
								$course = $row['Course'];
								$meeting = $row['Meeting'];
								$interest = $row['Interest'];
								$experience = $row['Experience'];
								$address = $row['Address'];
								$status = $row['Status'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�������Ҩ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/homex.gif','../pic/subjectx.gif','../pic/formularx.gif','../pic/resex.gif','../pic/webboardx.gif','../pic/aboutx.gif')" >
<table  width="971"   border="0" cellpadding="0" cellspacing="0" background="../pic/bg.gif">
  <tr> 
    <td width="200" height="100"><img src="../pic/ce2004.gif" width="200" height="100"></td>
    <td width="463" background="../pic/linehead.gif"><table width="84%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="28"></td>
        </tr>
        <tr> 
          <td align="center"><img src="../pic/officerx.gif" width="225" height="49" border="0"></td>
        </tr>
        <tr> </tr>
        <tr></tr>
        <tr></tr>
      </table></td>
    <td width="308"  bgcolor="#FFFFFF"><img src="../pic/tailempty.gif" width="200" height="100" ></td>
  </tr>
  <tr> 
          
    <td  colspan="3"  bgcolor="#FFFFFF"> <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="15%" height="32"><a href="http://www.ce.kmitl.ac.th" onMouseOver="MM_swapImage('Image1','','../pic/homex.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/home.gif" name="Image1" width="150" height="30" border="0" id="Image1"></a> 
          </td>
          <td width="15%"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/homepage/subject/index.php" onMouseOver="MM_swapImage('Image2','','../pic/subjectx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/subject.gif" name="Image2" width="150" height="30" border="0" id="Image2"></a></td>
          <td width="15%"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/index.php" onMouseOver="MM_swapImage('Image3','','../pic/formularx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/formular.gif" name="Image3" width="150" height="30" border="0" id="Image3"></a></td>
          <td width="15%"><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/resex.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/rese.gif" name="Image4" width="150" height="30" border="0" id="Image4"></a></td>
          <td width="10%"><a href="http://www.ce.kmitl.ac.th/webboard/index.php" onMouseOver="MM_swapImage('Image5','','../pic/webboardx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/webboard.gif" name="Image5" width="150" height="30" border="0" id="Image5"></a></td>
          <td width="30%"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/aboutx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/about.gif" name="Image6" width="150" height="30" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
 </tr>
  <tr>
    <td  colspan="3" > 
      <table width="771" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr>
          <td  width="771" > <table  width="793" border="0" cellpadding="0" cellspacing="0" >
              <tr> 
                <td width="20%" rowspan="7"> <img src=<? $path = "../$picPersonDir/$picPerson".$id.".gif"; echo $path;?> width="150" height="170" border="1"></td>
                <td width="31%" bgcolor="#F5F5F5"> <div align="right">����-���ʡ�� 
                    :&nbsp;</div></td>
                <td width="49%" bgcolor="#FFF7D7">&nbsp;<? echo $name; ?> 
                </td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">���˹�/˹�ҷ�� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $level; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">Email-Address :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo  $email; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">�������Ѿ�� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $telephone ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">�ԧ����ǹ��� :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp; <? echo $tlink; ?></td>
              </tr>
              <tr> 
                <td bgcolor="#F5F5F5"> <div align="right">��ͧ�ӧҹ :&nbsp;</div></td>
                <td bgcolor="#FFF7D7">&nbsp;<? echo $address; ?></td>
              </tr>
              <tr> 
                <td height="20" bgcolor="#F5F5F5">			
				<a href="person_info.php"><img src="../pic/editinfo.gif" width="100" height="40" border="0"></a>
	    	  </td>
                <td bgcolor="#FFF7D7">&nbsp;</td>
              </tr>
              <tr> 
                <td colspan="3"><table width="100%" border="0" cellspacing="2" cellpadding="2">

                    <tr> 
                      <td  align="right" width="40%" bgcolor="#F5F5F5">�س�ز� 
                        �Ң��Ԫ� ʶҹ����֡��</td>
                      <td width="60%" bgcolor="#FFFCF0">&nbsp;<? echo $graduation; ?></td>
                    </tr>
<?
if( $status !== 'officer' ){
?>
                    <tr> 
                      <td align="right" bgcolor="#F5F5F5"><a href="../research/mainres.php"><font color="#FF0000">��䢢����� 
                        >></font></a>&nbsp;�ҹ�Ԩ��&nbsp;</td>
                      <td bgcolor="#FFFCF0"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<?
					$query = "Select * From $Research Where ID = '$id' ";
					$result = mysql_query($query);				
							while($row = mysql_fetch_array($result)){
?>
                          <tr> 
                            <td bgcolor="#FFFCF0"><a href = "research.php?&res_id=<?echo $row['res_id']?>"><? echo $row['title']?></a></td>
                          </tr>
<? } ?>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="right" bgcolor="#F5F5F5">�ŧҹ�ҧ�Ԫҡ��&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;<? echo  $research;?></td>
                    </tr>
                    <tr> 
                      <td  align="right" bgcolor="#F5F5F5">���Ҿ����Ե&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;<? echo  $meeting;?></td>
                    </tr>
                    <tr> 
                      <td  align="right" bgcolor="#F5F5F5">����ʹ�&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;<? echo $interest?></td>
                    </tr>
                    <tr> 
                      <td  align="right"bgcolor="#F5F5F5">���ʺ��ó�����&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;<? echo $experience;?></td>
                    </tr>
	<?
		}			
	?>
					 <tr> 
                      <td  height="150'"align="right" bgcolor="#F5F5F5">&nbsp;</td>
                      <td bgcolor="#FFFCF0">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">Department 
            of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>          
        </tr>
      </table>
</td>
		<tr>
    <td height="20" colspan="3">&nbsp;</td>
  </tr>
</table>
</body>
</html>
