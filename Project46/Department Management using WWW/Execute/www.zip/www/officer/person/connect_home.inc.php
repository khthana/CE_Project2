<?
	$Officertable= "personal_detail";
	$Select_teachertable = "select_teacher";
	$Research = "research";
	$File_research = "file_research";

    $dbName = "webce";
	MYSQL_CONNECT('localhost','gead','123qwe')
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>