<?
session_start();
include ("connect_home.inc.php");
include("function.php");
$query = "Select * from $File_research Where id_file = '$id_file' ";
						$result = mysql_query($query);				
						   $row = mysql_fetch_array($result);		
							$res_id = $row['res_id'];
							$res_filename = $row['res_filename'];
	
	
 echo "<img src='../research/file/Research_$res_id/$res_filename'>";
 ?> 
