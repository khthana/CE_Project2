<?
session_start();
include ("connect_home.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�ؤ�ҡ�  �Ҥ�Ԫ����ǡ������������� </title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementByid) x=d.getElementByid(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<table  width="780"   border="0" cellpadding="0" cellspacing="0" >
  <tr> 
    <td  valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/person_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="../pic/person_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/person_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE>

</td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF" class="linetop" valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
          <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF">&nbsp;				
	</td>
  </tr>
  <tr> 
    <td > <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr> 
          <td ><table width="100%" border="0" cellspacing="2" cellpadding="2" align="center" bordercolor="#000000">
              <tr> 
                <td width="2%">&nbsp;</td>
                <td width="20%" height="20" bgcolor="#E6E6FA"><b><font size="3">���˹���Ҥ�Ԫ��</font></b></td>
                <td height="20" width="25%" bgcolor="#E6E6FA"> <div align="center"><strong>��ͧ�ӧҹ</strong></div></td>
                <td width="20%" height="20" bgcolor="#E6E6FA"> <div align="center"><strong>�������Ѿ��</strong></div></td>
                <td width="33%" height="20" bgcolor="#E6E6FA"> <div align="center"><strong>e-mail 
                    </strong> </div></td>
              </tr>
              <?

			  $query_select1 = "Select * From $Select_teachertable Where head = '���˹���Ҥ�Ԫ�' "; 
			  $result_select1 = mysql_query($query_select1);
			  $row = mysql_fetch_array($result_select1); 
              $id_head = $row['id'];
			  $query_Officer2 = "Select * From $Officertable Where id = '$id_head' AND status = 'teacher' "; 
			  $result_Officer2 = mysql_query($query_Officer2);
   		      $row = mysql_fetch_array($result_Officer2); 
              $name_head = $row['name']; 
  			  $address = $row['address']; 
			  $telephone = $row['telephone']; 
			  $email = $row['email'];
			  echo " 
              <tr bgcolor='#FFFCF0' class = 'BBNFont'> 
                <td bgcolor='#FFFFFF'>&nbsp;</td>
                <td height='25' bgcolor='#FFFCF0' width='30%'><a href='person.php?id=$id_head'><font size='2'>$name_head</font></a></font></td>
                <td height='25' bgcolor='#FFFCF0' width='21%'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$address </font></div>
                </td>
                <td width='21%' height='25'> 
                  <div align='center'>$telephone</font></div>
                </td>
                <td width='25%' height='25'> 
                  <div align='center'><A HREF='mailto:$email'>$email</A></font></div>
                </td>
                
              </tr>";
?>
              <tr> 
                <td>&nbsp;</td>
                <td height="20" bgcolor="#E6E6FA"><b><font size="3">�Ţҹء���Ҥ�Ԫ��</font></b></td>
                <td width="25%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>��ͧ�ӧҹ</strong></div></td>
                <td width="20%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>�������Ѿ��</strong></div></td>
                <td width="33%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>e-mail 
                    </strong> </div></td>
              </tr>
              <?
			$query_select3 = "Select * From $Select_teachertable Where second = '�Ţҹء���Ҥ�Ԫ�' "; 
			$result_select3 = mysql_query($query_select3); 
              $row = mysql_fetch_array($result_select3); 
			  $id_second = $row['id']; 
              $query_Officer4 = "Select * From $Officertable Where id = '$id_second' AND status = 'teacher' ";
			  $result_Officer4 = mysql_query($query_Officer4); 
              $row = mysql_fetch_array($result_Officer4);
			  $name_second = $row['name']; 
			  $address = $row['address']; 
              $telephone = $row['telephone']; 
			  $email = $row['email'];
			  echo " 
              <tr bgcolor='#FFFCF0' class = 'BBNFont'> 
				<td bgcolor='#FFFFFF'>&nbsp;</td>
                <td height='25' width='30%'><a href='person.php?id=$id_second'><font size='2'>$name_second</font></a></font></td>
                <td height='25' width='21%'>
				<div align='center'>
				<font face='Tahoma, Microsoft Sans Serif' size='2'>$address</font></td>
				</div>
                <td height='25' width='21%'> 
                  <div align='center'>$telephone</font></div>
                </td>
                <td height='25' width='25%'> 
                  <div align='center'><A HREF='mailto:$email'>$email</A></font></div>
                </td>
                
              </tr>";
?>
              <tr> 
                <td>&nbsp;</td>
                <td height="20" bgcolor="#E6E6FA"><b><font size="3">��Ҩ����</font></b></td>
                <td width="25%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>��ͧ�ӧҹ</strong></div></td>
                <td width="20%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>�������Ѿ��</strong></div></td>
                <td width="33%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>e-mail 
                    </strong> </div></td>
              </tr>
              <?
			  $query_select5= "Select * From $Officertable Where id != '$id_head' AND id != '$id_second' AND status = 'teacher' order by show_order ";
			  $result_select5 = mysql_query($query_select5);
			  $snumber5 = mysql_numrows($result_select5); 
              $si5=0;
			  if ($si5 < $snumber5) 
			{
				$count = 1; 
				while ($row = mysql_fetch_array($result_select5)) 
              { 
				$id_Officer = htmlspecialchars($row['id']); 
				$name_Officer = htmlspecialchars($row['name']); 
				$telephone_Officer = htmlspecialchars($row['telephone']);
				$address_Officer = $row['address']; 
				$email_Officer = htmlspecialchars($row['email']); 
				echo " 
              <tr bgcolor='#FFFCF0' class = 'BBNFont'> 
             	<td bgcolor='#FFFFFF'>&nbsp;</td>
                <td height='25' width='30%'><a href='person.php?id=$id_Officer'><font size='2'>$name_Officer</font></a></font></td>
                <td height='25' width='21%'>
					<div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$address_Officer</font></div>
					</td>
                <td height='25' width='21%'> 
                  <div align='center'>$telephone_Officer</font></div>
                </td>
                <td height='25' width='25%'> 
                  <div align='center'><A HREF='mailto:$email_Officer'>$email_Officer</A></font></div>
                </td>
                
              </tr>";
				}
			}
?>
              <tr> 
                <td>&nbsp;</td>
                <td height="20" bgcolor="#E6E6FA"><b><font size="3">���˹�ҷ��</font></b></td>
                <td width="25%" height="20" bgcolor="#E6E6FA"><div align="center"><strong>��ͧ�ӧҹ</strong></div></td>
                <td width="20%" height="20" bgcolor="#E6E6FA"> <div align="center"><strong>�������Ѿ��</strong></div></td>
                <td width="33%" height="20" bgcolor="#E6E6FA"> <div align="center"><strong>e-mail 
                    </strong> </div></td>
              </tr>
              <?
              $query_select6 = "Select * From $Officertable Where status = 'officer' order by show_order";
			  $result_select6 = mysql_query($query_select6);
			  $snumber6 = mysql_numrows($result_select6); 
              $si6=0; 
			  if ($si6 < $snumber6)
			{
				$count = 1;
				while ($row = mysql_fetch_array($result_select6)) 
              { 
					$id_officer = htmlspecialchars($row['id']);
					$name_officer = htmlspecialchars($row['name']); 
					$telephone_officer = htmlspecialchars($row['telephone']); 
					$address_officer = $row['address']; 
					$email_officer = htmlspecialchars($row['email']);
					echo " 
              <tr bgcolor='#FFFCF0' class = 'BBNFont'> 
               <td bgcolor='#FFFFFF'>&nbsp;</td>
                <td height='25' width='30%'><a href='person.php?id=$id_officer'><font size='2'>$name_officer</font></a></font></td>
                <td height='25' width='21%'>
				<div align='center'>
				<font face='Tahoma, Microsoft Sans Serif' size='2'>$address_officer</font></td>
					</div>
                <td height='25' width='21%'> 
                  <div align='center'>$telephone_officer</font></div>
                </td>
                <td height='25' width='25%'> 
                  <div align='center'><A HREF='mailto:$email_officer'>$email_officer</A></font></div>
                </td>
                
              </tr>";
					}
	}
		 MYSQL_CLOSE();
	?>
              <tr> 
                <td>&nbsp;</td>
                <td height="22">&nbsp;</td>
                <td width="25%" height="22"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;</font></td>
                <td width="20%" height="22">&nbsp;</td>
                <td width="33%" height="22">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">&nbsp; 
            Department of Computer Engineering Faculty of Engineering King Mongkut's 
            Institute of Technology<br>
            &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
        </tr>
      </table></td>
  <tr> 
    <td height="10">&nbsp;</td>
  </tr>
</table>

</body>
</html>
