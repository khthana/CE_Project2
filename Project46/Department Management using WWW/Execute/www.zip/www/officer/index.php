<? session_start();

if($_POST['username']=='' && $_POST['password']=='' ){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>����к�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="./include/stylesheet.css" type=text/css rel=stylesheet>

</head>

<body  leftmargin="0" topmargin="0" >
  <form name="index" method="post" action="index.php">
  <table  width="780" border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      <td width="780" valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="pic/headce_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		    <TD height="43" class="linebottom"> <IMG SRC="pic/headce_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		    <TD class="linebottom"> <img src="pic/headce_07.gif" width=222 height=42 alt=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
    </tr>
    <tr> 
      <td valign="top" nowrap bgcolor="#FFFFFF" class="linetop">&nbsp;</td>
    </tr>
    <tr > 
      <td height="400" valign="top" nowrap> <table align="center" width="63%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="100">&nbsp; </td>
            <td></td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td bgcolor="#9999CC">&nbsp;</td>
            <td bgcolor="#9999CC" align="center"><strong>login</strong></td>
            <td bgcolor="#9999CC">&nbsp;</td>
          </tr>
          <tr> 
            <td width="38%" bgcolor="#F5F5DC"> <div align="right">username&nbsp;</div></td>
            <td width="17%" bgcolor="#F5F5DC"> <input type="text" name="username" maxlength="20" class="violet"></td>
            <td width="45%" bgcolor="#F5F5DC">&nbsp;</td>
          </tr>
          <tr> 
            <td bgcolor="#F5F5DC"> <div align="right">password&nbsp;</div></td>
            <td bgcolor="#F5F5DC"> <input type="password" name="password" maxlength="20" class="violet"></td>
            <td bgcolor="#F5F5DC">&nbsp;</td>
          </tr>
          <tr bgcolor="#E6E6FA"> 
            <td>&nbsp;</td>
            <td align="right" bgcolor="#E6E6FA"> <div align="right">&nbsp; 
                <input type="submit" name="submit" value="  login  "  class="violet">
              </div></td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td >&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
    </tr>
    <tr >
      <td height="60"  background="pic/b.jpg"><font  color="#000099" size="-2"  class="violet">&nbsp; 
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<br>
        &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font> </td>
    </tr>
  </table>
  <tr>
    <td height="10">&nbsp;</td>
    </tr>
 
</table>
</form>
</body>
</html>
<?
}else{

	$username=$_POST['username'];
	$password=$_POST['password'];
	
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
		
	$sql="select * from administrator where ad_passwd=md5('$password.$username') and ad_user='$username' ";
	$result=mysql_query($sql) or die(mysql_error());

	if(mysql_num_rows($result)==1){
			$tmp=session_id(); 		
			$sql2="update administrator set ad_code='$tmp' where ad_user='$username'";
			$db_query2 = mysql_db_query ("webce", $sql2) or die(mysql_error());			

			session_register('ad_code');
			$ad_code = $tmp;
			session_register('ad_user');			
			$ad_user = $username;
			
	    print"<META http-equiv=refresh content='0; URL=http://isag25.ce.kmitl.ac.th/~gead/officer/show_select_person.php'>";
	}else{
				session_destroy();

		exit();
	}	
}		
?>



