<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();
		$query = "DELETE FROM $Research_picture  WHERE picture = '$picture' ";
		$result =  mysql_query($query); 
			if(!$result) { 
				echo Message(35,"red","�������öź�ٻ��","��سҵ�Ǩ�ͺ�����١��ͧ ","<a href='javascript:history.back(1)'> ��Ѻ���� </a>");  
				exit;
			} else  {
				$query = "Select * From $Research_picture Where picture = '$picture' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							$res_id = $row['res_id'];
				$query = "Select * From $Research Where res_id = '$res_id' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							$id = $row['id'];
				$query = "UPDATE $Research SET date = $date WHERE ID = $id ";
				mysql_query($query);	
				echo Message(35,"green","ź�ٻ $picRes$picture ���º��������","","<a href='javascript:history.back(1)'> ��Ѻ���� </a>&nbsp;&nbsp;<a href='mainres.php'>[ ˹���á ]</a>");
			}
?>
<html>
<head>
<title>Change Picture</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<LINK href="stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
</body>
</html>

