<?
session_start();
include('connect_home.inc.php');
include('function.php');
?>
<html>
<head>
<title>ź�����ŧҹ�Ԩ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<LINK href="../include/stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
<?
check_admin();
		$query = "SELECT * FROM $Research WHERE res_id = '$res_id' ";
		$result =  mysql_query($query);
		$row = mysql_fetch_array($result);
		$nameres = $row['title'];
		
		$query  = "DELETE FROM $Research WHERE res_id = '$res_id' ";
		$result1 =  mysql_query($query);
		$query = "SELECT *  FROM $File_research WHERE res_id = '$res_id' ";
			$result = mysql_query( $query );
					
			while( $row = mysql_fetch_array( $result ) ){
						$file_name = $row['res_filename'];
					unlink("./file/Research_$res_id/$file_name");
			}
			rmdir("./file/Research_$res_id");
			
		$query  = "DELETE FROM $File_research WHERE res_id = '$res_id' ";
		$result2 =  mysql_query($query);
			if(!($result1&&$result2) ) { 
				echo Message(35,"red","�������ö�ź�ҹ�Ԩ����","��سҵ�Ǩ�ͺ�����١��ͧ ","<a href='javascript:history.back(1)'> ��Ѻ���� </a>");  
				exit;
			} else {	
				echo Message(35,"green","�ҹ�Ԩ�§���� $nameres �١ź���º��������","","<a href='javascript:history.back(1)'>[  ��Ѻ���� ] </a>&nbsp;&nbsp;<a href='mainres.php'>[ ˹���á ]</a>");			
			}
?>

</body>
</html>

