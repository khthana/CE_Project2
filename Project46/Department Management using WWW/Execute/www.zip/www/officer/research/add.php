<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�����ҹ�Ԩ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<form name="add" method="post" action="loadres.php" enctype="multipart/form-data">
<table  width="780"   border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      <td width="780" valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/res_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="../pic/res_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
    </tr>
    <tr> 
      <td class="linetop" valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
            <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
          </tr>
        </table></td>
    </tr>

    <tr> 
      <td    > <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
          <tr> 
            <td > <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr > 
                  <td height="400"  valign="top" nowrap> <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td height='19'>&nbsp; </td>
                        <td >&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width='24%'><div align='right'>��Ǣ�ͧҹ�Ԩ�� : &nbsp;</div></td>
                        <td width='76%'><input type='text' name='title'  size='40' class=violet></td>
                      </tr>
                      <tr> 
                        <td align='right'>�����ҧҹ�Ԩ�� :&nbsp;</td>
                        <td rowspan='2'><textarea name='detail' cols='80' rows='15' size = '40' class=violet></textarea></td>
                      </tr>
                      <tr> 
                        <td height='160'>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td  > <div align='right'>�ٻ�Ҿ�ҹ�Ԩ�� : &nbsp;</div></td>
                        <td> <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                            <tr> 
                              <td width=70% > <input type='file' name='picture' class=violet size=50></td>
                              <td width=30%><a href="" target="_self" onClick="var s1='?title='+document.all.title.value;
																															var s2='&detail='+document.all.detail.value;																															
																															this.href='addpic.php'+s1+s2">>> 
                                �����ٻ</a> </td>
                            </tr>
                          </table></td>
                      </tr>
                      <tr> 
                        <td height="21" >&nbsp;</td>
                        <td align="right"><input type="submit" name="upload0" value="Upload"  class=violet></td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
		  <tr>
          <td><img src="../pic/add.gif" width="200" height="40"></td>
        </tr>
          <tr> 
            <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">&nbsp; 
              Department of Computer Engineering Faculty of Engineering King Mongkut's 
              Institute of Technology<br>
              &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
          </tr>
        </table></td>
    <tr> 
      <td height="10" >&nbsp;</td>
    </tr>

</table>
</form>
</body>
</html>
