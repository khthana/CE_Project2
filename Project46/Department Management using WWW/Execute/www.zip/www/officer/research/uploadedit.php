<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();

   if($upload0 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload0,"../data/RES".$max.".gif");	
	}
	   if($upload1 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload1,"../data/RES".$max.".gif");	
	}
	   if($upload2 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload2,"../data/RES".$max.".gif");	
	}
	   if($upload3 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload3,"../data/RES".$max.".gif");	
	}
	   if($upload4 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload4,"../data/RES".$max.".gif");	
	}
	   if($upload5 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload5,"../data/RES".$max.".gif");	
	}
	   if($upload6 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload6,"../data/RES".$max.".gif");	
	}
	   if($upload7 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload7,"../data/RES".$max.".gif");	
	}
	   if($upload8 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload8,"../data/RES".$max.".gif");	
	}
	   if($upload9 != 'none'){
		mysql_query("insert into $Research_picture values ('$res_id','$valid_title',' ')");			
		$result = mysql_query("select * from $Research_picture ");
		$max2 = 0; // �Ҥ���ҡ�ش�
		while($row=mysql_fetch_array($result)){
		$max1 =  htmlspecialchars($row['picture']);
		if($max2 < $max1) { $max2 =  $max1; $max = $max1; }
		else $max = $max2;
		}	
		$result = copy($upload9,"../data/RES".$max.".gif");	
	}

		if(!$result){
				echo Message(35,"red","�������ö  Upload �ٻ��","��س����ѡ���� �С�Ѻ�˹����� ","");			
		}else{
	//---------Last_update time
					$query = "Select * From $Research Where res_id = '$res_id' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							$id = $row['id'];
				$query = "UPDATE $Research SET date = $date WHERE ID = $id ";
				mysql_query($query);		
				echo Message(35,"green","Upload �ҹ�Ԩ�����º��������","��س����ѡ���� �С�Ѻ�˹����� ","");
		}
  ?>
 <html>
<head>
<title>Change Picture</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<META HTTP-EQUIV="REFRESH" CONTENT="1; URL=edit.php?&res_id=<?echo $res_id?>" >
<LINK href="stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
</body>
</html>
	 