<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();
?>
<html>
<head>
<title>Change Picture</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<LINK href="../include/stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
<?

		$sql = "Select * from $File_research Where id_file = '$id_file' ";
		$result = mysql_query( $sql ) or die ( mysql_error() );
		$row = mysql_fetch_array( $result );
		$res_id = $row['res_id'];
		$res_filename = $row['res_filename'];

		unlink("./file/Research_$res_id/$res_filename");
		$query  = "DELETE FROM $File_research WHERE id_file = '$id_file' ";
		$result1 =  mysql_query($query);		

			if(!result1 ) { 
				echo Message(35,"red","�������ö�ź�ҹ�Ԩ����","��سҵ�Ǩ�ͺ�����١��ͧ ","<a href='javascript:history.back(1)'> ��Ѻ���� </a>");  
				exit;
			} else {
				echo Message(35,"green","�ҹ�Ԩ�§���� $res_filename �١ź���º��������","","");
				print "<META HTTP-EQUIV='REFRESH' CONTENT='1; URL=javascript:history.back(1)' >";			
			}
?>
</body>
</html>


