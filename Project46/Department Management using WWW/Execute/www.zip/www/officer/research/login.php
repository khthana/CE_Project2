
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>����к�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/homex.gif','../pic/subjectx.gif','../pic/formularx.gif','../pic/resex.gif','../pic/webboardx.gif','../pic/aboutx.gif')" >
<table  width="971"   border="0" cellpadding="0" cellspacing="0" background="../pic/bg.gif">
<form method="post" action="../person/person_login.php" name="loginres" onSubmit="return check()">
  <tr> 
    <td width="200" height="100"><img src="../pic/ce2004.gif" width="200" height="100"></td>
    <td width="463" background="../pic/linehead.gif"><table width="84%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td  height="28">&nbsp;</td>
        </tr>

        <tr> 
            <td align="center"><img src="../pic/research.gif" width="237" height="47"></td>
        </tr>

      </table></td>
    <td width="308"  bgcolor="#FFFFFF"><img src="../pic/tailempty.gif" width="200" height="100" ></td>
  </tr>
  <tr> 
          <td  colspan="3"  bgcolor="#FFFFFF">
		  <table width="91%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                
            <td width="15%" height="32"> <a href="http://www.ce.kmitl.ac.th" onMouseOver="MM_swapImage('Image2','','../pic/homex.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/home.gif" name="Image2" width="150" height="30" border="0" id="Image2"></a></td>
                
            <td width="15%"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/homepage/subject/index.php" onMouseOver="MM_swapImage('Image1','','../pic/subjectx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/subject.gif" name="Image1" width="150" height="30" border="0" id="Image1"></a></td>
            <td width="15%"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/index.php" onMouseOver="MM_swapImage('Image3','','../pic/formularx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/formular.gif" name="Image3" width="150" height="30" border="0" id="Image3"></a></td>
            <td width="15%"><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/resex.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/rese.gif" name="Image4" width="150" height="30" border="0" id="Image4"></a></td>
            <td width="10%"><a href="http://www.ce.kmitl.ac.th/webboard/index.php" onMouseOver="MM_swapImage('Image5','','../pic/webboardx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/webboard.gif" name="Image5" width="150" height="30" border="0" id="Image5"></a></td>
            <td width="30%"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/aboutx.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/about.gif" name="Image6" width="150" height="30" border="0" id="Image6"></a></td>
  </tr>
</table>
</td>
 </tr>
  <tr>
    <td   colspan="3" > 
      <table width="800" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr>
          <td > <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr > 
                  <td>&nbsp;</td>
                </tr>
                <tr > 
                  <td> <table align="center" width="63%" border="0" cellspacing="0" cellpadding="0">
                      <tr bgcolor="#9999CC"> 
                        <td>&nbsp;</td>
                        <td></td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="38%" bgcolor="#F5F5DC"> <div align="right">username&nbsp;</div></td>
                        <td width="17%" bgcolor="#F5F5DC"> <input type="text" name="username" maxlength="20" class="violet"></td>
                        <td width="45%" bgcolor="#F5F5DC">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td bgcolor="#F5F5DC"> <div align="right">password&nbsp;</div></td>
                        <td bgcolor="#F5F5DC"> <input type="password" name="password" maxlength="20" class="violet"></td>
                        <td bgcolor="#F5F5DC">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td bgcolor="#E6E6FA">&nbsp;</td>
                        <td align="right" bgcolor="#E6E6FA"> <div align="right">&nbsp; 
                            <input type="submit" name="submit" value="  login  "  class="violet">
                          </div></td>
                        <td bgcolor="#E6E6FA">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="300">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">&nbsp;
		    Department of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>&nbsp;
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>&nbsp;
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>          
        </tr>
      </table>
</td>
		<tr>
    <td height="20" colspan="3">&nbsp;</td>
  </tr></form>
</table>
</body>
</html>
