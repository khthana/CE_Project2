<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();

$query = "Select * From $Research Where res_id = '$res_id' ";
$result = mysql_query($query);			
		$row = mysql_fetch_array($result,MYSQL_ASSOC)
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��䢧ҹ�Ԩ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/homex.gif','../pic/subjectx.gif','../pic/formularx.gif','../pic/resex.gif','../pic/webboardx.gif','../pic/aboutx.gif')" >
<table  width="780"   border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      
    <td width="780" valign="top" nowrap>
      <TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/res_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="../pic/res_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/res_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
    </tr>
    <tr> 
      <td class="linetop" valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
            <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
          </tr>
        </table></td>
    </tr>
  <tr>
    <td   colspan="3" > 
      <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr>
          <td> 
            <table  width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr > 
                  
                <td> <form name="edit" method="post" action="updateres.php?&res_id=<? echo $res_id; ?>">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        
                      <td >&nbsp; </td>
                        <td >&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="24%"><div align="right">��Ǣ�ͧҹ�Ԩ�� : &nbsp;</div></td>
                        <td width="76%"><input type="text" name="title" size="40" class=violet  value="<? echo $row['title']; ?>"></td>
                      </tr>
                      <tr> 
                        <td align="right">�����ҧҹ�Ԩ�� :&nbsp;</td>
                        <td rowspan="2"><textarea name="detail" cols="80" rows="15" size = "40" class=violet 
						><? echo $row['detail']; ?></textarea></td>
                      </tr>
                      <tr> 
                        
                      <td height="196">&nbsp;</td>
                      </tr>
					  <tr><td>&nbsp;</td><td>
                          <div align="right">
                            <input type="submit" name="Submit2" value="upload" class="violet">&nbsp;&nbsp;&nbsp;
                          </div>
                        </form></td></tr>
   <?   	
  		$query = "Select * From $File_research Where res_id = '$res_id' ";			
							$result = mysql_query($query);								
  						while($row = mysql_fetch_array($result,MYSQL_ASSOC)){
									$file_name = $row['res_filename'];
									$file_type = $row['res_filetype'];
									$id_file = $row['id_file'];
									$file_image = substr($file_type,0,5); 	
						if( $file_image == 'image'  ){			
  ?>
  <tr>
  <form action="changerespic.php?&id_file=<?=$id_file?>" method="post" 
  enctype="multipart/form-data" name="edit" onSubmit="return check()">
                          <td height="102" >&nbsp;</td>
                        <td> 
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">						
                            <tr> 
                              <td width="17%" rowspan="3"><img src=<? echo "./file/Research_$res_id/$file_name"; ?>  border="1" width="100" height="100"></td>
                              <td height="18" colspan="3">&nbsp;&nbsp;<? echo $file_name; ?></td>
                            </tr>
                            <tr> 
                              <td width="5%" height="28">&nbsp;</td>
                              <td width="52%"><a href="del_file.php?&id_file=<?=$id_file?>">[ ź ]</a></td>
                              <td width="26%"></td>
                            </tr>
                            <tr> 
                              <td height="49">&nbsp;</td>
                              <td><input type="file" name="new_pic"  size="40" class="violet"></td>
                              <td align="center"><input type="submit" name="Submit" value="����¹�ٻ�Ҿ"  class="violet"></td>
                            </tr>
                          </table>
                      
				</td>
    			<td>&nbsp;</td>
  </form></tr>
  <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
  <?				}
  		}
	?>  
   <tr><td>&nbsp;</td>
   		  <td>
				<table align="left"width="50%" border="0" cellspacing="2" cellpadding="0">
<? 	
						$result = mysql_query($query);								
  						while($row = mysql_fetch_array($result,MYSQL_ASSOC)){
									$file_name = $row['res_filename'];
									$file_type = $row['res_filetype'];
									$id_file = $row['id_file'];
									$file_image = substr($file_type,0,5); 	
							if( $file_image != 'image'  ){						

					echo "<tr  bgcolor='#F5F5DC'><td><li>$file_name </td><td align='center'><a href='del_file.php?id_file=$id_file'>[  ź ]</a></td></tr>";
			 				}  
  	    				}
				  
		?></table>			  
	</td>
	       
  </tr>        
	 <tr> 
                 <td height="40" ><img src="../pic/edit.gif" width="200" height="40"></td>                        
                <td align="right"> <a href="insertplus.php?&res_id=<?echo $res_id?>">&gt;&gt; 
                  ������� </a> &nbsp; &nbsp;</td>
                      </tr>


            </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099"  size="-2"  class="violet">&nbsp; 
            Department of Computer Engineering Faculty of Engineering King Mongkut's 
            Institute of Technology<br>
            &nbsp;
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>&nbsp;
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>          
        </tr>
      </table>
</td>
		<tr>
    <td height="10" colspan="3" >&nbsp;</td>
  </tr>
</table>

</body>
</html>
