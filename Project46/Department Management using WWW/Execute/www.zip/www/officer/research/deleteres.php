<?
session_start();
include('connect_home.inc.php');
include('function.php');
check_admin();
		$query = "SELECT * FROM $Research WHERE res_id = $res_id ";
		$result =  mysql_query($query);
		$row = mysql_fetch_array($result);
		$nameres = $row['title'];
		
		$query  = "DELETE FROM $Research WHERE res_id = '$res_id' ";
		$result1 =  mysql_query($query);
		$query  = "DELETE FROM $Research_picture WHERE res_id = '$res_id' ";
		$result2 =  mysql_query($query);
		

			if(!($result1&&$result2) ) { 
				echo Message(35,"red","�������ö�ź�ҹ�Ԩ����","��سҵ�Ǩ�ͺ�����١��ͧ ","<a href='javascript:history.back(1)'> ��Ѻ���� </a>");  
				exit;
			} else {
				$query = "Select * From $Research Where res_id = '$res_id' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							$id = $row['id'];
				$query = "UPDATE $Research SET date = $date WHERE ID = $id ";
				mysql_query($query);	
				echo Message(35,"green","�ҹ�Ԩ�§���� $nameres �١ź���º��������","","<a href='javascript:history.back(1)'>[  ��Ѻ���� ] </a>&nbsp;&nbsp;<a href='mainres.php'>[ ˹���á ]</a>");			
			}
?>
<html>
<head>
<title>Change Picture</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<LINK href="stylesheet.css"  type=text/css rel=stylesheet>
</head>
<body>
</body>
</html>

