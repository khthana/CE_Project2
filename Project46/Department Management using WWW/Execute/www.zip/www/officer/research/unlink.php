<?
unlink("Picture_teacher_397/Afroamerikaner.jpg");
unlink("Picture_teacher_397/person.gif");
unlink("Picture_teacher_397/person397.gif");
rmdir("Picture_teacher_397");
?>