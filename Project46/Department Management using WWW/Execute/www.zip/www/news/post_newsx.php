<?PHP
session_start();
include "connect.php";
include "upload_function.php";
include "function_post_news.php";
include "function_check_and_change_date.php";
include "function_delete_file.php";
include "function_check_group_value.php";
include "function_return_group_value.php";
include "function_check_media_value.php";
include "function_return_media_value.php";

function cancel_news(){
}

if( $_POST['post']=='��С��' && $_POST['topic']!='' &&  check_media_value("some") && check_group_value("some") && $_POST['start']!='' && $_POST['end']!=''){
$start=$_POST['start'];
$end=$_POST['end'];
if(!check_and_change_date($start) && !check_and_change_date($end)){
	if(check_and_change_date($start)){
		?> <font color="red">�س����ѹ����������С�ȼԴ<?
		$start="";
	}else{
		?> <font color="red">�س����ѹ�������ش��С�ȼԴ<?
		$end="";
	}
}else{
	post_news();
	header("location:http://isag25.ce.kmitl.ac.th/~best/test/");
	exit;
	}
}
if($_POST['post']!='��С��' || $_POST['topic']=='' ||  check_media_value("all") || check_group_value("all") || $_POST['start']!='' || $_POST['end']!=''){
	$topic=$_POST['topic'];
	$detail=$_POST['detail'];
	$start=$_POST['start'];
	$end=$_POST['end'];
	if(!check_and_change_date($start) && !check_and_change_date($end)){
		if(check_and_change_date($start)){
			$start="";
		}else{
			$end="";
		}
	}
	return_group_value();
	return_media_value();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��С�Ȣ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<form action="" method="post" enctype="multipart/form-data" name="form1" target="_self">
  <table width="75%" border="0">
    <tr bgcolor="#FF6600"> 
      <td colspan="3" nowrap><div align="center"><strong><font size="4">��С�Ȣ���</font></strong></div></td>
    </tr>
    <tr> 
      <td width="15%" nowrap bgcolor="#CCCCCC"><font size="2">��Ǣ�ͻ�С��</font></td>
      <td width="49%" nowrap bgcolor="#3399FF"><input name="topic" type="text" id="topic" size="50" value="<? echo $topic ?>"></td>
      <td width="36%" nowrap bgcolor="#3399FF"><font size="2">* ������������ҡ�Թ�</font></td>
    </tr>
    <tr> 
      <td align="left" valign="top" nowrap bgcolor="#CCCCCC"><font size="2">������</font></td>
      <td nowrap bgcolor="#3399FF"><textarea name="detail" cols="50" rows="5" id="detail"><? if($detail!='') echo $detail ?></textarea></td>
      <td nowrap bgcolor="#3399FF"><font size="2">&nbsp;</font></td>
    </tr>
    <tr> 
      <td nowrap bgcolor="#CCCCCC"><font size="2">���ͷ�����С��</font></td>
      <td nowrap bgcolor="#3399FF"><?
	  												$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
													mysql_select_db("webce",$link) or die(mysql_error());
													$result=mysql_query("select id,name from news_media where `use`='yes'") or die(mysql_error());
													while($row=mysql_fetch_array($result,MYSQL_NUM)){
														if(${"media".$row[0]}==''){
														echo "<input type=checkbox name='media$row[0]' value='on'>$row[1] \n";
														}else{
														echo "<input type=checkbox name='media$row[0]' value='on' checked>$row[1] \n";
														}
													}
													mysql_close($link);
											   ?></td>
      <td nowrap bgcolor="#3399FF"><font size="2">*</font></td>
    </tr>
    <tr> 
      <td height="24" nowrap bgcolor="#CCCCCC"><font size="2">���������Ѻ����</font></td>
      <td nowrap bgcolor="#3399FF"><?

													$result=mysql_query("select id,memberof from accesslevel") or die(mysql_error());
													while($row=mysql_fetch_array($result,MYSQL_NUM)){
														if(${"group".$row[0]}==''){
															echo "<input type=checkbox name='group$row[0]' value='on'>$row[1]<br>\n";
														}else{
															echo "<input type=checkbox name='group$row[0]' value='on' checked>$row[1]<br>\n";
														}
													}
													mysql_close($link);
											   ?></td>
      <td nowrap bgcolor="#3399FF"><font size="2">* </font></td>
    </tr>
    <tr> 
      <td nowrap bgcolor="#CCCCCC"><font size="2">���ʹѡ�֡�ҷ���Ѻ����</font></td>
      <td nowrap bgcolor="#3399FF"><input name="sid" type="text" id="sid" size="50"></td>
      <td nowrap bgcolor="#3399FF"><font size="2">����Ѻ�к��繺ؤ�� �� 44015336,44015365,42....</font></td>
    </tr>
    <tr> 
      <td nowrap bgcolor="#CCCCCC"><font size="2">�ѹ�������С��</font></td>
      <td nowrap bgcolor="#3399FF"><input name="start" type="text" id="start" size="10" maxlength="10" value="<? if($start==''){echo date("d\/m\/Y");}else{echo$start;} ?>"></td>
      <td nowrap bgcolor="#3399FF"><font size="2">* �ٻẺ dd/mm/yyyy</font></td>
    </tr>
    <tr> 
      <td nowrap bgcolor="#CCCCCC"><font size="2">�ѹ����ش��С��</font></td>
      <td nowrap bgcolor="#3399FF"><input name="end" type="text" id="end" size="10" maxlength="10" value="<? if($end==''){echo date("d\/m\/Y",(mktime(date("00,00,00,m,d,Y"))+(5*60*60*24)));}else{echo$end;} ?>"></td>
      <td nowrap bgcolor="#3399FF"><font size="2">* �ٻẺ dd/mm/yyyy</font></td>
    </tr>
    <tr> 
      <td align="left" valign="middle" nowrap bgcolor="#CCCCCC"><font size="2">���Ṻ</font></td>
      <td nowrap bgcolor="#3399FF">
	  <?
	  	$total=$_POST['total'];
		$total_del=$_POST['total_del'];
	  	if($_POST['attach']=="ź���"){
			$next=0;
			while($total_del>0){
	  			$next=delete_file($next);
				$total--;
				$total_del--;
			}
		}
	  	$i=0;
		$j=$total;
	  	while($_POST["filedetail".$i]!='' && $j>=0){
			if($_POST["filedelete".$i]==''){
				$filedetail=$_POST["filedetail".$i];
				?><input type="checkbox" name="<? echo "filedelete".$i ?>" value='on' onClick="var sum=document.all.total_del.value;if(this.value.check){sum--;}else{sum++;};document.all.total_del.value=sum;var j=0;for(var i=0;i<document.forms[0].elements.length;i++){if(document.forms[0].elements[i].checked){j++;}};if(j){document.all.attach.value='ź���';}else{document.all.attach.value='Ṻ���';}"><? echo "Name : $filedetail" ?>
				<input type=hidden name="<? echo "filedetail".$i ?>" value="<? echo $filedetail ?>"><br><?
				$j--;
			}
			$i++;
		}
		if($_POST['attach']=="Ṻ���"){
			$filedetail=upload_file();
		}else{
			$filedetail="";
		}
		if($filedetail!='' && $filedetail!="dup"){
			$total++;
				?><input type="checkbox" name="<? echo "filedelete".$i ?>" value='on' onClick="var sum=document.all.total_del.value;if(this.value.check){sum--;}else{sum++;};document.all.total_del.value=sum;;var j=0;for(var i=0;i<document.forms[0].elements.length;i++){if(document.forms[0].elements[i].checked){j++;}};if(j){document.all.attach.value='ź���';}else{document.all.attach.value='Ṻ���';}"><? echo "Name : $filedetail" ?>
				<input type=hidden name="<? echo "filedetail".$i ?>" value="<? echo $filedetail ?>"><br><?
		}
	  ?>
	  <input type=hidden name="total" value="<? if($total!=''){echo $total;}else{echo "0";}?>">
	  <input type=hidden name="total_del" value="0">
	  <input name="file" type="file" size="30"></td>
      <td nowrap bgcolor="#3399FF"><font size="2">&nbsp;��ԡ���͡������ͧ���ź</font></td>
    </tr>
    <tr> 
      <td nowrap>&nbsp;</td>
      <td colspan="2" nowrap><input name="post" type="submit" id="post" value="��С��"> 
        <input name="attach" type="submit" id="attach" value="Ṻ���">
        <input name="cancel" type="submit" id="cancel" value="¡��ԡ"> </td>
    </tr>
  </table>
</form>
</body>
</html>
