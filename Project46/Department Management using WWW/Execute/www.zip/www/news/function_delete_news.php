<?PHP
function delete_news($news_id){
	//---------------Config-----------------//
	$host="localhost";
	$name="admin";
	$pass="admin";
	$db="webce";
	//-----------SQL statement-------------//
	$query_delete_news="update news 
			    set topic='',detail='',name='',start='',end='' 
			    where id='$news_id'";
	$query_delete_web_view="delete 
				from news_web 
				where news_id='$news_id'";
	$query_delete_email_view="delete 
				  from news_email 
				  where news_id='$news_id'";
	$query_delete_icq_view="delete 
				from news_icq 
				where news_id='$news_id'";
	$query_delete_sms_view="delete 
				from news_sms 
				where news_id='$news_id'";
	//-----------End config----------------//
	$link=mysql_connect($host,$name,$pass) or die(mysql_error());
	mysql_select_db($db) or die(mysql_error());
	$delete_news=mysql_query($query_delete_news) or die(mysql_error());
	$delete_web_views=mysql_query($query_delete_web_view) or die(mysql_error());
	$delete_email_view=mysql_query($query_delete_email_view) or die(mysql_error());
	$delete_icq_view=mysql_query($query_delete_icq_view) or die(mysql_error());
	$delete_sms_view=mysql_query($query_delete_sms_view) or die(mysql_error());
	$mysql_close($link);
}
?>
