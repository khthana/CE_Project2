<?PHP
function check_lang($str){
	$chars = preg_split('//' ,$str ,-1 ,PREG_SPLIT_NO_EMPTY);
	$i=0;
	while($i<strlen($str)){
		if(ord($chars[$i])>160){
			return "thai";
		}
		$i++;
	}
	return "english";
}


function decode_7bit($str){
$decode7bit=array(ord('$'));
//print_r($decode7bit);
//$str=$_GET['string_in'];
$chars = preg_split('//' ,$str ,-1 ,PREG_SPLIT_NO_EMPTY);
//print_r($chars);
$spialchar=array("^","{","}","\\","[","~","]","|");
//print_r($spialchar);
//echo "<br>";
$replace=array("^"=>bindec("00010100"),"{"=>bindec("00101000"),"}"=>bindec("00101001"),"\\"=>bindec("00101111"),"["=>bindec("00111100"),"~"=>bindec("00111101"),"]"=>bindec("00111110"),"|"=>bindec("01000000"));
$char=array("@"=>"0000000","_"=>"0010001","$"=>"0000010");
$padlen=0;
$tempcopy=array();
$number=0;
while($number<strlen($str)){
	if($replace[$chars[$number]]!=''){
		$push1 = chr(bindec("11011"));
		$push2 = chr($replace[$chars[$number]]);
		array_push($tempcopy,$push1,$push2);
		$padlen++;
	}else{
		array_push($tempcopy,$chars[$number]);
	}
	$number++;
}
$chars=$tempcopy;
//print_r($chars);
//echo "<br><br>";
/*
$number=0;
while($number<(strlen($str)+$padlen)){
	echo "$number : " . decbin(ord($chars[$number]))."<br>";
	$number++;
}
*/
$number=0;
while($number<(strlen($str)+$padlen)){
//	echo $number . "<br>";
	if($char[$chars[$number]]!=''){
		$chars[$number]=$char[$chars[$number]];
		$temp=$chars[$number];
	}else{
		$temp=decbin(ord($chars[($number)]));
		while(strlen($temp)<7){
			$temp = "0" . $temp;
		}
	}
	//echo "$number : $temp<br>";
	$loop=0;
	while(($temp[$loop]!="")&&($loop<7)){
		$loop++;
	}
	if($loop!=7){
		$loop=7;
		while($loop>0){
			$temp[$loop]=$temp[($loop-1)];
			$loop--;
		}
		$temp[0]=decbin(0);
	}
//	echo $temp . "<br>";
if((($number%8)==0)&&($number<(strlen($str)-1+$padlen))){
	$loop=0;
	$start=($number*7);
	while($loop<7){
		if($loop==0){$string[($start+1)] = $temp[0];}
		if($loop==1){$string[($start+2)] = $temp[1];}
		if($loop==2){$string[($start+3)] = $temp[2];}
		if($loop==3){$string[($start+4)] = $temp[3];}
		if($loop==4){$string[($start+5)] = $temp[4];}
		if($loop==5){$string[($start+6)] = $temp[5];}
		if($loop==6){$string[($start+7)] = $temp[6];}
		$loop++;
	}
} elseif(($number%8)==0){
	$loop=0;
	$start=($number*7);
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[0];}
		if($loop==1){$string[($start+1)] = $temp[1];}
		if($loop==2){$string[($start+2)] = $temp[2];}
		if($loop==3){$string[($start+3)] = $temp[3];}
		if($loop==4){$string[($start+4)] = $temp[4];}
		if($loop==5){$string[($start+5)] = $temp[5];}
		if($loop==6){$string[($start+6)] = $temp[6];}
		$loop++;
	}
}
if((($number%8)==1)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-7;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[6];}
		if($loop==1){$string[($start+10)] = $temp[0];}
		if($loop==2){$string[($start+11)] = $temp[1];}
		if($loop==3){$string[($start+12)] = $temp[2];}
		if($loop==4){$string[($start+13)] = $temp[3];}
		if($loop==5){$string[($start+14)] = $temp[4];}
		if($loop==6){$string[($start+15)] = $temp[5];}
		$loop++;
	}
} elseif(($number%8)==1){
	$loop=0;
	$start=($number*7)-7;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[6];}
		if($loop==1){$string[($start+8)] = $temp[0];}
		if($loop==2){$string[($start+9)] = $temp[1];}
		if($loop==3){$string[($start+10)] = $temp[2];}
		if($loop==4){$string[($start+11)] = $temp[3];}
		if($loop==5){$string[($start+12)] = $temp[4];}
		if($loop==6){$string[($start+13)] = $temp[5];}
		$loop++;
	}
}
if((($number%8)==2)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-6;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[5];}
		if($loop==1){$string[($start+1)] = $temp[6];}
		if($loop==2){$string[($start+11)] = $temp[0];}
		if($loop==3){$string[($start+12)] = $temp[1];}
		if($loop==4){$string[($start+13)] = $temp[2];}
		if($loop==5){$string[($start+14)] = $temp[3];}
		if($loop==6){$string[($start+15)] = $temp[4];}
		$loop++;
	}
} elseif(($number%8)==2){
	$loop=0;
	$start=($number*7)-6;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[5];}
		if($loop==1){$string[($start+1)] = $temp[6];}
		if($loop==2){$string[($start+8)] = $temp[0];}
		if($loop==3){$string[($start+9)] = $temp[1];}
		if($loop==4){$string[($start+10)] = $temp[2];}
		if($loop==5){$string[($start+11)] = $temp[3];}
		if($loop==6){$string[($start+12)] = $temp[4];}
		$loop++;
	}
}
if((($number%8)==3)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-5;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[4];}
		if($loop==1){$string[($start+1)] = $temp[5];}
		if($loop==2){$string[($start+2)] = $temp[6];}
		if($loop==3){$string[($start+12)] = $temp[0];}
		if($loop==4){$string[($start+13)] = $temp[1];}
		if($loop==5){$string[($start+14)] = $temp[2];}
		if($loop==6){$string[($start+15)] = $temp[3];}
		$loop++;
	}
} elseif(($number%8)==3){
	$loop=0;
	$start=($number*7)-5;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[4];}
		if($loop==1){$string[($start+1)] = $temp[5];}
		if($loop==2){$string[($start+2)] = $temp[6];}
		if($loop==3){$string[($start+8)] = $temp[0];}
		if($loop==4){$string[($start+9)] = $temp[1];}
		if($loop==5){$string[($start+10)] = $temp[2];}
		if($loop==6){$string[($start+11)] = $temp[3];}
		$loop++;
	}
}
if((($number%8)==4)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-4;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[3];}
		if($loop==1){$string[($start+1)] = $temp[4];}
		if($loop==2){$string[($start+2)] = $temp[5];}
		if($loop==3){$string[($start+3)] = $temp[6];}
		if($loop==4){$string[($start+13)] = $temp[0];}
		if($loop==5){$string[($start+14)] = $temp[1];}
		if($loop==6){$string[($start+15)] = $temp[2];}
		$loop++;
	}
} elseif(($number%8)==4){
	$loop=0;
	$start=($number*7)-4;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[3];}
		if($loop==1){$string[($start+1)] = $temp[4];}
		if($loop==2){$string[($start+2)] = $temp[5];}
		if($loop==3){$string[($start+3)] = $temp[6];}
		if($loop==4){$string[($start+8)] = $temp[0];}
		if($loop==5){$string[($start+9)] = $temp[1];}
		if($loop==6){$string[($start+10)] = $temp[2];}
		$loop++;
	}
}
if((($number%8)==5)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-3;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[2];}
		if($loop==1){$string[($start+1)] = $temp[3];}
		if($loop==2){$string[($start+2)] = $temp[4];}
		if($loop==3){$string[($start+3)] = $temp[5];}
		if($loop==4){$string[($start+4)] = $temp[6];}
		if($loop==5){$string[($start+14)] = $temp[0];}
		if($loop==6){$string[($start+15)] = $temp[1];}
		$loop++;
	}
} elseif(($number%8)==5){
	$loop=0;
	$start=($number*7)-3;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[2];}
		if($loop==1){$string[($start+1)] = $temp[3];}
		if($loop==2){$string[($start+2)] = $temp[4];}
		if($loop==3){$string[($start+3)] = $temp[5];}
		if($loop==4){$string[($start+4)] = $temp[6];}
		if($loop==5){$string[($start+8)] = $temp[0];}
		if($loop==6){$string[($start+9)] = $temp[1];}
		$loop++;
	}
}
if((($number%8)==6)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-2;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[1];}
		if($loop==1){$string[($start+1)] = $temp[2];}
		if($loop==2){$string[($start+2)] = $temp[3];}
		if($loop==3){$string[($start+3)] = $temp[4];}
		if($loop==4){$string[($start+4)] = $temp[5];}
		if($loop==5){$string[($start+5)] = $temp[6];}
		if($loop==6){$string[($start+15)] = $temp[0];}
		$loop++;
	}
} elseif(($number%8)==6){
	$loop=0;
	$start=($number*7)-2;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[1];}
		if($loop==1){$string[($start+1)] = $temp[2];}
		if($loop==2){$string[($start+2)] = $temp[3];}
		if($loop==3){$string[($start+3)] = $temp[4];}
		if($loop==4){$string[($start+4)] = $temp[5];}
		if($loop==5){$string[($start+5)] = $temp[6];}
		if($loop==6){$string[($start+8)] = $temp[0];}
		$loop++;
	}
}
if((($number%8)==7)&&($number<(strlen($str)-1))){
	$loop=0;
	$start=($number*7)-1;
	while($loop<7){
		if($loop==0){$string[($start+0)] = $temp[0];}
		if($loop==1){$string[($start+1)] = $temp[1];}
		if($loop==2){$string[($start+2)] = $temp[2];}
		if($loop==3){$string[($start+3)] = $temp[3];}
		if($loop==4){$string[($start+4)] = $temp[4];}
		if($loop==5){$string[($start+5)] = $temp[5];}
		if($loop==6){$string[($start+6)] = $temp[6];}
		$loop++;
	}
}
$number++;
}
//print_r($string);
$loop=0;
$message="";
while($loop<((strlen($str)+$padlen)*7)){
	$cloop=0;
	$print="";
	while(($loop<((strlen($str)+$padlen)*7)) && ($cloop<=7)){
		$print=$print . $string[$loop];
		$loop++;
		$cloop++;
	}
	while($cloop<8){
		$print = "0" . $print;
		$cloop++;
	}
	//print_r($print);
	//echo "<br>";
	//echo $print . " : ";
	if(bindec($print)>15){
		$message=$message . dechex(bindec($print));
		//echo $print . "<br>";
	}else{
		$message=$message . "0" . dechex(bindec($print));
		//echo "0:$print<br>";
	}
}
if((strlen($str)+$padlen)<16){
	return "0" . dechex(strlen($str)+$padlen) . $message;
} else {
	return dechex(strlen($str)+$padlen) . $message;
}
//return $message;
}

function decode_16bit($str){
	$chars = preg_split('//' ,$str ,-1 ,PREG_SPLIT_NO_EMPTY);
	$i=0;
	$message="";
	while($i<strlen($str)){
		if(ord($chars[$i])<128){
                        if(ord($chars[$i])<16){
				$message .= "000" . dechex(ord($chars[$i]));
			}else{
				$message .= "00" . dechex(ord($chars[$i]));
			}
		}else{
			if((ord($chars[$i])-160)<16){
				$message .= "0E0" . dechex(ord($chars[$i])-160);
			}else{
				$message .= "0E" . dechex(ord($chars[$i])-160);
			}
		}
		$i++;
	}
	if((strlen($str)*2)<16){
		return "0" . dechex(strlen($str)*2) . $message;
	}else{
		return dechex(strlen($str)*2) . $message;
	}
}

function create_header($tel){
	$head="001500";
	if(strlen($tel)<16){
		$head .= "0" . dechex(strlen($tel)) . "91";
	}else{
		$head .= dechex(strlen($tel)) . "91";
	}
	$chars = preg_split('//' ,$tel ,-1 ,PREG_SPLIT_NO_EMPTY);
	$i=0;
	while($i<strlen($tel)){
		if(strlen($tel)%2==0 || (strlen($tel)-$i)<2){
			$head .= $chars[$i+1] . $chars[$i];
		}else{
			$head .= "F" . $chars[$i];
		}
		$i+=2;
	}
	return $head;
}

function create_pdu ($tel, $message) {
	if(check_lang($message)=='thai'){
		//echo create_header($tel) . "0008" . decode_16bit($message);
		return create_header($tel) . "0008FF" . decode_16bit($message);
	} else {
		//echo  create_header($tel) . "0000" . decode_7bit($message);
		return create_header($tel) . "0000FF" . decode_7bit($message);
	}
};
/************************ TEST ****************************/
//$tel="6697251244";
//$news="�������������������";
//$news="test ��";
//$news="chr -- Return a specific character";
//echo $news . "<br>";
//if(check_lang($news)=='thai'){
//	echo "<br>". create_header($tel) . "0008" . decode_16bit($news);
//}else{
//	echo "<br>" . create_header($tel) . "0000FF" . decode_7bit($news);
	
//}
/*
?><br><?
//echo "PDU : " . create_pdu($tel,$news);
echo decode_16bit("������������¡���͡Ẻǧ�������Ҵ�˭��ҡ");
?><br><?
echo decode_7bit("!@#$%^&*()");
?><br><?
echo create_pdu("6697251244","Show MySQL runtime information");
echo "<br>" . (2 | 2) . "<br>";
$test=array("64"=>"0","163"=>"1");
echo $test[163];
*/
?>
