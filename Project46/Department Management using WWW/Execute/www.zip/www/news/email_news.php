<?PHP
	include "sendmail.php";
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select news.id,user_email,news.topic,news.detail from news,news_email where news.id=news_email.news_id and news_email.status=''") or die(mysql_error());
	$remain=mysql_num_rows($result) or die(mysql_error());
	$remain--;
	echo "<br>remain news send via E-mail : $remain e-mail";
	if($remain>=0){
		$text=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());
		$news_file=mysql_query("select filename,fileid from news_file where newsid='$text[0]'") or die(mysql_error());
		while($file=mysql_fetch_array($news_file,MYSQL_NUM)){
			$html .= "<a href='http://isag25.ce.kmitl.ac.th/~best/test/news/downloadfile.php?file_id=".$file[1]."'>".$file[0]."</a><br>";
		}
		$text[3]=str_replace("\n","<br>",$text[3]);
		//$row[1]="best3140@hotmail.com";
		//$row[2]="test";
		//$row[3]="test";
		echo "$text[0]<br>$text[1]<br>$text[2]<br>$text[3]<br>$html<br>";
		sendmail("webmaster@ce.kmitl.ac.th","webmaster@ce.kmitl.ac.th",$text[1],"",$text[2],$text[3],$html,$ATTM);
		//echo "<br>now send news id = $row[0] to E-mail : $row[1]<br>Subject : $row[2]<br>Detail : $row[3]";
		$sended=mysql_query("update news_email set status='sended' where news_id='$row[0]' and user_email='$row[1]'") or die(mysql_error());
	}
	mysql_close($link);
?>
