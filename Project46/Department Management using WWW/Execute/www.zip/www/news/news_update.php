<?PHP
session_start();
include('connect.php');
include('function.php');
include "upload_function.php";
include "function_post_news.php";
include "function_check_and_change_date.php";
include "function_delete_file.php";
include "function_check_group_value.php";
include "function_return_group_value.php";
include "function_check_media_value.php";
include "function_return_media_value.php";
include "function_register_file.php";
include "function_start_post.php";
//include "sendicq.php";

if(  session_is_registered('memberof') && ($accesslevel > 2 ) ){

				$query = "Select * From  news Where id = '$news_id' ";
					$result = mysql_query($query);				
							$row = mysql_fetch_array($result);		
							
								$topic = htmlspecialchars($row['topic']);
								$detail = htmlspecialchars($row['detail']);
								$time_start = htmlspecialchars($row['start']);
								$time_end = htmlspecialchars($row['end']);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��䢢��ǻ�С��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>

</head>
<form action="update_news.php" method="post">
  <input type=hidden name="news_id" value="<? echo $news_id ?>">
<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<table  width="780"   border="0" cellpadding="0" cellspacing="0"  valign="top" nowrap>
  <tr> 
    <td width="780"  height="75" valign="top" nowrap >
	<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/post_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD class="linebottom">
			<IMG SRC="../pic/post_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE>
	</td>
  </tr>
  <tr>
    <td  valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td  width="120" height="20"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/homepage/subject/index.php" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
          <td width="120" ><a href="http://www.ce.kmitl.ac.th/alumni/index.php" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/webboard/" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
          <td width="120" ><a href="http://www.kmitl.ac.th/~kcwatcha/newstudent.html" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
          <td width="199"><a href="http://www.kmitl.ac.th/~kcwatcha/faq.html" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr> 
    <td  valign="top" nowrap> <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr> 
          <td height="400"  valign="top" align="center">
  <table width="75%" border="0">
              <tr bgcolor="#9999CC" > 
                <td colspan="3" nowrap> <div align="center"><strong><font color="#FF0000"size="4">��䢢��ǻ�С��</font></strong></div></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td width="13%" nowrap><font size="2">��Ǣ�ͻ�С��</font></td>
                <td width="39%" nowrap> <input name="topic" type="text" id="topic" size="50" value="<? echo $topic ?>"></td>
                <td width="48%" nowrap><font size="2">* ������������ҡ�Թ�</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td align="left" valign="top" nowrap><font size="2">������</font></td>
                <td colspan="2" nowrap> <textarea name="detail" cols="100" rows="5" id="detail"><? echo $detail; ?></textarea> 
                  <font size="2">&nbsp;</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">���ͷ�����С��</font></td>
                <td nowrap><? 	
												$sql = "Select news_id From	news_web  where news_id = '$news_id' ";
												$result = mysql_query( $sql ) or  die ( mysql_error() );
												$row = mysql_fetch_array( $result );
												$n_web = mysql_num_rows( $result );
												if( $n_web != '0' ) echo "[ Web ] <br> ";    
																
												$sql = "Select news_id , status From	news_email  where news_id = '$news_id' ";
												$result = mysql_query( $sql ) or  die ( mysql_error() );
												$row = mysql_fetch_array( $result );
												$n_email = mysql_num_rows( $result );
												if( $n_email != '0' ) echo "[ e-mail status = ".$row['status']." ]<br>  ";    
												
												$sql = "Select news_id , status From	news_icq  where news_id = '$news_id' ";
												$result = mysql_query( $sql ) or  die ( mysql_error() );
												$row = mysql_fetch_array( $result );
												$n_icq = mysql_num_rows( $result ); 
												if( $n_icq != '0' ) echo "[ ICQ status = ".$row['status']." ]<br>  ";    
												
												$sql = "Select news_id , status From	news_sms  where news_id = '$news_id' ";
												$result = mysql_query( $sql ) or  die ( mysql_error() );
												$row = mysql_fetch_array( $result );
												$n_sms = mysql_num_rows( $result );
												if( $n_sms != '0' ) echo "[ SMS status = ".$row['status']." ]<br>  ";    	
																		
										?>					 
				</td>
                <td nowrap>&nbsp;</td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td height="24" nowrap><font size="2">���������Ѻ����</font></td>
                <td nowrap> <table width="100%" height="100%" border="0">
                    <tr> 
                      <td> 
                        <?
										$sql = "Select user_web From	news_web  where news_id = '$news_id' order by user_web";
												$result = mysql_query( $sql ) or  die ( mysql_error() );
												while ($row = mysql_fetch_array( $result )){
														$user_web_check = $row['user_web'];
														if( $user_web_check == '�ؤ�ŷ����' ) $group0 = true ;
														if( $user_web_check == '1D1' ) $group1 = true ; 
														if( $user_web_check == '1D2' ) $group2 = true ; 
														if( $user_web_check == '2D1' ) $group3 = true ; 
														if( $user_web_check == '2D2' ) $group4 = true ; 
														if( $user_web_check == '3D1' ) $group5 = true ; 
														if( $user_web_check == '3D2' ) $group6 = true ; 
														if( $user_web_check == '4D1' ) $group7 = true ;
														if( $user_web_check == '4D2' ) $group8 = true ;
														if( $user_web_check == 'P1' ) $group9 = true ; 
														if( $user_web_check == 'P2' ) $group10 = true ;
														if( $user_web_check == 'P3' ) $group11 = true ;
														if( $user_web_check != '�ؤ�ŷ����' && 
															$user_web_check != '1D1' &&
															$user_web_check != '1D2' &&
															$user_web_check != '2D1' &&
															$user_web_check != '2D2' &&
															$user_web_check != '3D1' &&
															$user_web_check != '3D2' &&
															$user_web_check != '4D1' &&
															$user_web_check != '4D2' &&
															$user_web_check != '1P' &&
															$user_web_check != '2P' &&
															$user_web_check != '3P'&&
															$user_web_check != '0' ){ $temp = $user_web_check;
															$student .= $temp.",";
															$temp = '0';
															}														
												}		

	    if(!$group0){
	    	?>
                        <input type=checkbox name='group0' value='�ؤ�ŷ����'>
                        �ؤ�ŷ����<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group0' value='�ؤ�ŷ����' checked>
                        �ؤ�ŷ����<br> 
                        <?
	    }?>
                      </td>
                      <td>&nbsp; </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
	    if(!$group1){
	    	?>
                        <input type=checkbox name='group1' value='1D1'>
                        �ѡ�֡����ͧ 1D1<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group1' value='1D1' checked>
                        �ѡ�֡����ͧ 1D1<br> 
                        <?
	    }?>
                      </td>
                      <td> 
                        <?
	    if(!$group2){
	    	?>
                        <input type=checkbox name='group2' value='1D2'>
                        �ѡ�֡����ͧ 1D2<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group2' value='1D2' checked>
                        �ѡ�֡����ͧ 1D2<br> 
                        <?
	    }?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group3){
			  	?>
                        <input type=checkbox name='group3' value='2D1'>
                        �ѡ�֡����ͧ 2D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group3' value='2D1' checked>
                        �ѡ�֡����ͧ 2D1<br> 
                        <?
			}?>
                      </td>
                      <td> 
                        <?
		  	if(!$group4){
				?>
                        <input type=checkbox name='group4' value='2D2'>
                        �ѡ�֡����ͧ 2D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group4' value='2D2' checked>
                        �ѡ�֡����ͧ 2D2<br> 
                        <?
			}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group5){
			  	?>
                        <input type=checkbox name='group5' value='3D1'>
                        �ѡ�֡����ͧ 3D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group5' value='3D1' checked>
                        �ѡ�֡����ͧ 3D1<br> 
                        <?
			}?>
                      </td>
                      <td> 
                        <?
			  if(!$group6){
			  	?>
                        <input type=checkbox name='group6' value='3D2'>
                        �ѡ�֡����ͧ 3D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group6' value='3D2' checked>
                        �ѡ�֡����ͧ 3D2<br> 
                        <?
				}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group7){
			  	?>
                        <input type=checkbox name='group7' value='4D1'>
                        �ѡ�֡����ͧ 4D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group7' value='4D1' checked>
                        �ѡ�֡����ͧ 4D1<br> 
                        <?
				}?>
                      </td>
                      <td> 
                        <?
			  if(!$group8){
			  	?>
                        <input type=checkbox name='group8' value='4D2'>
                        �ѡ�֡����ͧ 4D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group8' value='4D2' checked>
                        �ѡ�֡����ͧ 4D2<br> 
                        <?
			}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group9){
			  	?>
                        <input type=checkbox name='group9' value='1P'>
                        �ѡ�֡����ͧ 1P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group9' value='1P' checked>
                        �ѡ�֡����ͧ 1P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group10){
			  	?>
                        <input type=checkbox name='group10' value='2P'>
                        �ѡ�֡����ͧ 2P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group10' value='2P' checked>
                        �ѡ�֡����ͧ 2P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if(!$group11){
			  	?>
                        <input type=checkbox name='group11' value='3P'>
                        �ѡ�֡����ͧ 3P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group11' value='3P' checked>
                        �ѡ�֡����ͧ 3P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                  </table></td>
                <td nowrap><font size="2">* </font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td height="26" nowrap><font size="2">���ʹѡ�֡�ҷ���Ѻ����</font></td>
                <td nowrap> <? echo "   ".$student; ?><br>														
				<input name="sid" type="text" id="sid" size="50"></td>
                <td nowrap><font size="2">����Ѻ�к��繺ؤ�� �� 44015336,44015365,42....</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">�ѹ�������С��</font></td>
                <td nowrap> <input name="start" type="text" id="start" size="10" maxlength="10" value="<? if($start==''){echo date("d\/m\/Y");}else{echo$start;} ?>">
                </td>
                <td nowrap><font size="2">* �ٻẺ dd/mm/yyyy</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">�ѹ����ش��С��</font></td>
                <td nowrap> <input name="end" type="text" id="end" size="10" maxlength="10" value="<? if($end==''){echo date("d\/m\/Y",(mktime(date("00,00,00,m,d,Y"))+(5*60*60*24)));}else{echo$end;} ?>">
                </td>
                <td nowrap><font size="2">* �ٻẺ dd/mm/yyyy</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td align="left" valign="middle" nowrap><font size="2">���Ṻ</font></td>
                <td nowrap>				
				<table bgcolor="#CCFFFF"width='100%' border='1' >
                    <? 							
				$sql = "Select * From news_file Where newsid = '$news_id' ";
				$result = mysql_query( $sql );
					while ( $row  = mysql_fetch_array( $result ) ){ 
						$file_name = $row['filename'];
						echo "<tr><td><li>$file_name</td><td align=center><a href=''>[ ź ]</a></td></tr>";
				}				
				?>
                  </table>
                  <input name="file" type="file" size="30">
                </td>
                <td nowrap><font size="2">&nbsp;</font></td>
              </tr>
              <tr bgcolor="#E6E6FA"> 
                <td nowrap>&nbsp;</td>
                <td colspan="2" nowrap> <input name="post" type="submit" id="post" value="��С��"> 
                  <input name="attach" type="submit" id="attach" value="Ṻ���">
                  <input name="cancle" type="reset" id="cancel" value="¡��ԡ"> 
                </td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">Department 
            of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
        </tr>
      </table></td>
  <tr> 
    <td height="10">&nbsp;</td>
  </tr>
</table>
</body></form>
</html>
<?	
}
else
{
echo "<tr><td><center><font face = \"MS Sans Serif\" color=\"#ff0000\" size=\"3\">�س������Է�������㹡�÷ӧҹ��ǹ��� $name</font></center></td></tr>";
exit;
}
?>