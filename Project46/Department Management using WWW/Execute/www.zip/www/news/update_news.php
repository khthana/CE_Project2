<?PHP
session_start();
include('connect.php');
include('function.php');
if( check_admin() ){
	if( $file != ''){
													$file_name=$_FILES['file']['name'];
													$file_size=$_FILES['file']['size'];
													$file_type=$_FILES['file']['type'];
			
			$sql3 = "select * from  news_file  where res_filename = '$file_name' ";
				$result3 = mysql_query($sql3) or die( mysql_error() );
				$ch_pic = mysql_num_rows($result3);
				if( $ch_pic == 0 ){								
							$uploaddir="./file/";
							$uploadfile=$uploaddir.$_FILES['file']['name'];
															if(move_uploaded_file($_FILES['file']['tmp_name'],$uploadfile)){
															
								$sql4 = "insert into news_file (newsid,filename,file_type,file_size) 
													values ('$news_id','$file_name','$file_type','$file_size') ";
								$result4 = mysql_query($sql4);					
																}											
							}else{
								echo "<font color='red'> $file_name ���������������<br></font>";
						}
				print "<META http-equiv=refresh content='0; URL=http://isag25.ce.kmitl.ac.th/~gead/news/news_update?news_id=$news_id'>";
		}

	$sql = "select * from personal_detail where id = $pid";
	$result = mysql_query( $sql );
	$row = mysql_fetch_array( $result );
	$realname = $row['name'];	
		
			$time_start = date(Ymd000000);
			$time_end = date("Ymd000000",(mktime(date("00,00,00,m,d,Y"))+(5*60*60*24) ) ) ;			

		$sql = "update news set topic = '$topic' , detail = '$detail' , name = '$realname' , start = '$time_start' , end = '$time_end' where id = '$news_id' ";
		$result = mysql_query( $sql );
		
		$sql1 = "delete from news_web where news_id = '$news_id' ";
		$result = mysql_query($sql1) or die ( mysql_error( ) );


		if($group0 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group0')" ) or die ( mysql_error() );
		  }
		if($group1 != ''){ 
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group1')" ) or die ( mysql_error() );
		}
		if($group2 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group2')" ) or die ( mysql_error() );
		}
		if($group3 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group3')" ) or die ( mysql_error() );
		}
		if($group4 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group4')" ) or die ( mysql_error() );
		}
		if($group5 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group5')" ) or die ( mysql_error() );
		}
		if($group6 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group6')" ) or die ( mysql_error() );
		}
		if($group7 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group7')" ) or die ( mysql_error() );
		}
		if($group8 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group8')" ) or die ( mysql_error() );
		}
		if($group9 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group9')" ) or die ( mysql_error() );
		}
		if($group10 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group10')" ) or die ( mysql_error() );
		}
		if($group11 != ''){
			mysql_query( "insert into news_web (news_id,user_web) values ('$news_id','$group11')" ) or die ( mysql_error() );
		}

			print "<META http-equiv=refresh content='0; URL=http://isag25.ce.kmitl.ac.th/~gead/'>";
		
						
}
else
{
echo "<tr><td><center><font face = \"MS Sans Serif\" color=\"#ff0000\" size=\"3\">�س������Է�������㹡�÷ӧҹ��ǹ��� $name</font></center></td></tr>";
}
?>
