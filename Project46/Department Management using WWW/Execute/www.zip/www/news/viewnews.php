<?PHP
	session_start();
	include "connect.php";
	include "show_topic_function.php";
	$news_id=$_GET['id'];
	$result=mysql_query("select news.id,news.topic,news.start,news.detail,news.name from news where news.id='$news_id' and news.start<=now() and news.end>=now()") or die(mysql_error());
	$row=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>���ǻ�С��</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
</head>
<body leftmargin="0" topmargin="0">
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="68" ><img src="../pic/logoce.gif" width="77" height="54"></td>
    <td colspan="3"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td colspan="3" ><a href="viewalltopic.php">&nbsp;�ٻ�С�ȷ�����</a> 
            <? if($accesslevel>1){?>
            &nbsp;|&nbsp; <a href="news_update.php?news_id=<? echo $news_id; ?>"><font color="#FF0000">��䢻�С��</font></a> 
            <? }else{?>
            <? }?>
          </td>
        </tr>
        <tr> 
          <td width="358">&nbsp;</td>
          <td width="249" align="right"><font  color="#990000"><? echo thai_date($row[2]) ?></font></td>
          <td width="111">&nbsp;</td>
        </tr>
        <tr> 
          <td colspan="3"><font  color="#990000"><strong>&nbsp;��С������ͧ</strong> 
            <? echo $row[1] ?> </font></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td rowspan="3" class="lineright">&nbsp;</td>
    <td width="15"   rowspan="3" valign="top" nowrap class="linetop">&nbsp;</td>
    <td  height="250"valign="top" nowrap class="linetop"> <p>&nbsp; <? echo str_replace("\n","<br>\n",$row[3]);?></p></td>
    <td width="78" rowspan="3" class="linetop">&nbsp;</td>
  </tr>
  <tr> 
    <td valign="top" nowrap>&nbsp; 
      <?
				$file=mysql_query("select fileid,filename from news_file where newsid='$news_id'") or die(mysql_error());
				$file_DW=mysql_num_rows($file);
				if($file_DW){ 
				   echo "<font color='#990000'><b>Download</b>  >>   </font>";
						while($file_link=mysql_fetch_array($file,MYSQL_NUM)){
							?>
							<a href="./downloadfile.php?file_id=<? echo $file_link[0] ?>"><? echo $file_link[1] ?></a>&nbsp&nbsp 
							<?
						}
				}
		?>
    </td>
  </tr>
  <tr>
    <td valign="top" nowrap>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"  valign="middle" class="linetop">&nbsp;<font color="#990000"><strong>����С��</strong> 
      <? echo $row[4] ?></font></td>
    <td class="linetop">&nbsp;</td>
  </tr>
</table>

</body>
</html>
