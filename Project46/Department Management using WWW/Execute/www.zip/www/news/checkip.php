<?PHP
function checkip(){
	if (getenv(HTTP_X_FORWARDED_FOR)) {
	 $IP_client = getenv(HTTP_X_FORWARDED_FOR); 
	 } else { 
	 $IP_client= getenv(REMOTE_ADDR);
	 }
	 return $IP_client;
}
//echo checkip();
?>
