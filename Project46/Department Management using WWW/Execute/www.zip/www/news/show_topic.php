<?
$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db("webce",$link) or die(mysql_error());
$sql = 'SELECT id,topic'
        . ' FROM news'
        . " WHERE public = 'Yes' AND start <= now( ) AND end >= now( )"; 
$result=mysql_query($sql) or die(mysql_error());
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<div align="center">
  <p><strong><font size="3"><a href="viewnews.php">���ǻ�С��</a></font></strong> 
  <?echo$time?>
  </p>
  <?
  while($row=mysql_fetch_array($result,MYSQL_NUM)){
  ?>
  <div align="left"><a href="viewnews.php?id=<?echo$row[0]?>" target="_blank"><?echo$row[1]?></a> 
    <?
  }
  ?>
  </div>
</div>
</body>
</html>
<?
mysql_close($link);
?>
