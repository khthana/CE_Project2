<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Test post news</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<form method="post" action="post_news.php">
	<input type="text" name="group1"><br>
	<input type=submit>
</form>
</body>
</html>
