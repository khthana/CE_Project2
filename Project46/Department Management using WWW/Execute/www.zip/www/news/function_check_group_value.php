<?PHP
function check_group_value($check_type){ 
	$row=array('on','1D1','1D2','2D1','2D2','3D1','3D2','4D1','4D2','1P','2P','3P');
	for($i=0;$i<12;$i++){
		if($_POST["group".$i]==$row[$i]){
			$value=1;
		}else{
			$value=0;
		}
		if($check_type=='all'){
			$check &= $value;
		}else{
			$check |= $value;
		}
	}/*
	if($check){
		echo $check_type . "true<br>";
	} else {
		echo $check_type . "false<br>";
	}*/
	return $check;
}
?>
