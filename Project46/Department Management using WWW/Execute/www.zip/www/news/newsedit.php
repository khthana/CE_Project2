<?PHP
$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db("webce") or die(mysql_error());
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<form name="form1" method="post" action="">
  <table width="100%" border="0">
    <!--DWLayoutTable-->
    <tr> 
      <td width="126" height="22" valign="top" bgcolor="#CCCCCC">��Ǣ�ͻ�С��</td>
      <td width="479" valign="top"><input name="textfield" type="text" size="78" maxlength="255"></td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">��������´</td>
      <td valign="top"><textarea name="detail" cols="75" rows="5" id="detail"></textarea></td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">���������Ѻ����</td>
      <td valign="top">
      	<?PHP
	$result=mysql_query("select id,memberof from accesslevel") or die(mysql_error());
	while($row=mysql_fetch_array($result,MYSQL_NUM)){
	?>
      	<input type="checkbox" name="<?echo $row[0]?>" value="on">
        <?echo $row[1]?><br>
	<?
	}
	?>
      </td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">���ʼ���Ѻ����</td>
      <td valign="top"><input name="textfield2" type="text" size="78"></td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">���͡�û�С��</td>
      <td valign="top">
      <?PHP
      	$result=mysql_query("select name from news_media") or die(mysql_error());
	while($row=mysql_fetch_array($result,MYSQL_NUM)){
	?>
	<input type="checkbox" name="<?echo$row[0]?>" value="checkbox">
        <?echo$row[0]?>
	<?
	}
      ?>
      </td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">�ѹ�������С��</td>
      <td valign="top"><input name="start" type="text" size="14" maxlength="14">Date format dd/mm/yyyy</td>
    </tr>
    <tr> 
      <td height="22" valign="top" bgcolor="#CCCCCC">�ѹ����ء��û�С��</td>
      <td valign="top"><input name="end" type="text" size="14" maxlength="14">Date format dd/mm/yyyy</td>
    </tr>
  </table>
  <input name="update" type="submit" id="update" value="Update">
  <input name="reset" type="reset" id="reset" value="reset">
</form>
</body>
</html>
<?
?>

