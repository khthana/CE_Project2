<?PHP
session_start();

include "upload_function.php";
include "function_post_news.php";
include "function_check_and_change_date.php";
include "function_delete_file.php";
include "function_check_group_value.php";
include "function_return_group_value.php";
include "function_check_media_value.php";
include "function_return_media_value.php";
include "function_register_file.php";
include "function_start_post.php";
//include "sendicq.php";
if(  session_is_registered('memberof') && ($accesslevel > 2 ) ){

function cancel_post($news_id){
	$name=$_SESSION['name'];
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select fileid from news_file where newsid='$news_id'") or die(mysql_error());
	while($delete=mysql_fetch_array($result,MYSQL_NUM)){
		system("rm -f ./file/$delete[0]");
	}
	$delete_file=mysql_query("update news_file set `newsid`='',`filename`='',`file_type`='',`file_size`='' where `newsid`='$news_id'") or die(mysql_error());
	$delete_news=mysql_query("update news set `name`='',`start`='',`end`='' where `id`='$news_id' and name='$name'") or die(mysql_error());
	header("location:http//161.246.5.25/~gead/");
}

$news_id=$_POST['news_id'];

if($_POST['cancel']=='¡��ԡ'){
	cancel_post($news_id);
	header("location:http://isag25.ce.kmitl.ac.th/~gead/");
}

if($news_id==''){
	$news_id=start_post($name);
}

if( $_POST['post']=='��С��' && $_POST['topic']!='' &&  check_media_value("some") && (check_group_value("some") || $_POST['sid']!='') && $_POST['start']!='' && $_POST['end']!=''){
$start=$_POST['start'];
$end=$_POST['end'];
if(!check_and_change_date($start) && !check_and_change_date($end)){
	if(check_and_change_date($start)){
		?> <font color="red">�س����ѹ����������С�ȼԴ<?
		$start="";
	}else{
		?> <font color="red">�س����ѹ�������ش��С�ȼԴ<?
		$end="";
	}
}else{
	$topic=$_POST['topic'];
	$detail=$_POST['detail'];
	$message=$_POST['media4'];
	post_news($news_id,$topic,$detail,$name,$start,$end,$message);
	$result=mysql_query("select id,topic from news where id='$news_id'") or die(mysql_error());
	$row=mysql_fetch_array($result,MYSQL_NUM);
	//send_icq($news_id);
	header("location:http://isag25.ce.kmitl.ac.th/~gead/");
	exit;
	}
}
if($_POST['post']!='��С��' || $_POST['topic']=='' ||  check_media_value("all") || check_group_value("all") || $_POST['start']!='' || $_POST['end']!=''){
	$topic=$_POST['topic'];
	$detail=$_POST['detail'];
	$start=$_POST['start'];
	$end=$_POST['end'];
	if(!check_and_change_date($start) && !check_and_change_date($end)){
		if(check_and_change_date($start)){
			$start="";
		}else{
			$end="";
		}
	}
	return_group_value();
	return_media_value();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��С�Ȣ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function count_chars() {
	var dc=document.sendnews;
	var length = 0;	
	var left = 0;
	var maxchar = 160;
	var sendlength=160;
	for (var i = 0;i < 160; i++) {	
		if (dc.media4.value.charCodeAt(i) > 127) {
		    maxchar = 70;
			dc.media4.maxlength=70;
		 }
	}
	for (var i = 0;i < dc.media4.value.length; i++) {	
		if (dc.media4.value.charCodeAt(i) != 13) {	   
			length++;
		}
		if (dc.media4.value.charCodeAt(i) > 127) {
		    maxchar = 70;
			dc.media4.maxlength=70;
		}
	}
	left =(maxchar - length);	
	dc.counter.value = left;
  if(dc.counter.value<0){
	var message="";
  	for (var i = 0;i < maxchar; i++) {
		message = message+dc.media4.value.charAt(i);
	}
	dc.media4.value=message;
	alert("��ͤ����ͧ�س �դ�������ҡ�Թ� �к��зӡ�õѴ���ѵ��ѵ� �¢�ͤ����������մѧ��� : \n"+message);
	}

return true;
}
-->
</script>
</head>
<form action="" method="post" enctype="multipart/form-data" name="sendnews" target="_self">
  <input type=hidden name="news_id" value="<? echo $news_id ?>">
<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<table  width="780"   border="0" cellpadding="0" cellspacing="0"  valign="top" nowrap>
  <tr> 
    <td width="780"  height="75" valign="top" nowrap >
	<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/post_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/post_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD class="linebottom">
			<IMG SRC="../pic/post_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/post_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE>
	</td>
  </tr>
  <tr>
    <td  valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
          <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr> 
    <td  valign="top" nowrap> <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr> 
          <td height="400"  valign="top" align="center">
  <table width="75%" border="0">
              <tr bgcolor="#9999CC" > 
                <td colspan="3" nowrap> <div align="center"><strong><font size="4">��С�Ȣ���</font></strong></div></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td width="15%" nowrap><font size="2">��Ǣ�ͻ�С��</font></td>
                <td width="49%" nowrap> <input name="topic" type="text" id="topic" size="50" value="<? echo $topic ?>"></td>
                <td width="36%" nowrap><font size="2">* ������������ҡ�Թ�</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td align="left" valign="top" nowrap><font size="2">������</font></td>
                <td colspan="2" nowrap> <textarea name="detail" cols="100" rows="5" id="detail"><? if($detail!='') echo $detail ?></textarea> 
                  <font size="2">&nbsp;</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">���ͷ�����С��</font></td>
                <td nowrap> 
                  <?
		$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
		mysql_select_db("webce",$link) or die(mysql_error());
		$result=mysql_query("select id,name from news_media where `use`='yes'") or die(mysql_error());
		while($row=mysql_fetch_array($result,MYSQL_NUM)){
			if(${"media".$row[0]}==''){
				if($row[1]!='SMS'){
					?>
                  <input type="checkbox" name="<? echo "media$row[0]" ?>" value="on"> 
                  <? echo $row[1]?> 
                  <!-- onClick="if(this.checked==true && this.name=='media4' ){showsms.innerHTML='<br>SMS : <input type=text size=30 name=message maxlength=160 onchange=count_chars()><input type=text name=count size=3>'}else{showsms.innerHTML=''}" -->
                  <?
				}else{
					?>
                  <br>
                  SMS : 
                  <input name="media4" type="text" id="media4" onChange=count_chars() onKeyUp=count_chars() onfocus=count_chars() size="20">
                  ������ա 
                  <input name="counter" type="text" id="counter" disabled size="3" maxlength="3">
                  ����ѡ�� 
                  <?
				}
			}else{
				if($row[1]!='SMS'){
					?>
                  <input type="checkbox" name="<? echo "media$row[0]" ?>" value="on"> 
                  <? echo $row[1]?> 
                  <!-- onClick="if(this.checked==true && this.name=='media4' ){showsms.innerHTML='<br>SMS : <input type=text size=30 name=message maxlength=160 onchange=count_chars()><input type=text name=count size=3>'}else{showsms.innerHTML=''}" -->
                  <?
				}else{
					?>
                  <br>
                  SMS : 
                  <input name="media4" type="text" id="media4" value="<? echo ${"media".$row[0]}?>" onChange=count_chars() onfocus=count_chars() onKeyUp=count_chars() size="20">
                  ������ա 
                  <input name="counter" type="text" id="counter" disabled size="3" maxlength="3">
                  ����ѡ�� 
                  <?
				}
			}
		}
		mysql_close($link);?>
                </td>
                <td nowrap><font size="2">*</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td height="24" nowrap><font size="2">���������Ѻ����</font></td>
                <td nowrap> <table width="100%" height="100%" border="0">
                    <tr> 
                      <td> 
                        <?
	    if($_POST['group0']==''){
	    	?>
                        <input type=checkbox name='group0' value='on'>
                        �ؤ�ŷ����<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group0' value='on' checked>
                        �ؤ�ŷ����<br> 
                        <?
	    }?>
                      </td>
                      <td>&nbsp; </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
	    if($_POST['group1']==''){
	    	?>
                        <input type=checkbox name='group1' value='1D1'>
                        �ѡ�֡����ͧ 1D1<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group1' value='1D1' checked>
                        �ѡ�֡����ͧ 1D1<br> 
                        <?
	    }?>
                      </td>
                      <td> 
                        <?
	    if($_POST['group2']==''){
	    	?>
                        <input type=checkbox name='group2' value='1D2'>
                        �ѡ�֡����ͧ 1D2<br> 
                        <?
	    }else{
	    	?>
                        <input type=checkbox name='group2' value='1D2' checked>
                        �ѡ�֡����ͧ 1D2<br> 
                        <?
	    }?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group3']==''){
			  	?>
                        <input type=checkbox name='group3' value='2D1'>
                        �ѡ�֡����ͧ 2D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group3' value='2D1' checked>
                        �ѡ�֡����ͧ 2D1<br> 
                        <?
			}?>
                      </td>
                      <td> 
                        <?
		  	if($_POST['group4']==''){
				?>
                        <input type=checkbox name='group4' value='2D2'>
                        �ѡ�֡����ͧ 2D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group4' value='2D2' checked>
                        �ѡ�֡����ͧ 2D2<br> 
                        <?
			}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group5']==''){
			  	?>
                        <input type=checkbox name='group5' value='3D1'>
                        �ѡ�֡����ͧ 3D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group5' value='3D1' checked>
                        �ѡ�֡����ͧ 3D1<br> 
                        <?
			}?>
                      </td>
                      <td> 
                        <?
			  if($_POST['group6']==''){
			  	?>
                        <input type=checkbox name='group6' value='3D2'>
                        �ѡ�֡����ͧ 3D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group6' value='3D2' checked>
                        �ѡ�֡����ͧ 3D2<br> 
                        <?
				}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group7']==''){
			  	?>
                        <input type=checkbox name='group7' value='4D1'>
                        �ѡ�֡����ͧ 4D1<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group7' value='4D1' checked>
                        �ѡ�֡����ͧ 4D1<br> 
                        <?
				}?>
                      </td>
                      <td> 
                        <?
			  if($_POST['group8']==''){
			  	?>
                        <input type=checkbox name='group8' value='4D2'>
                        �ѡ�֡����ͧ 4D2<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group8' value='4D2' checked>
                        �ѡ�֡����ͧ 4D2<br> 
                        <?
			}?>
                      </td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group9']==''){
			  	?>
                        <input type=checkbox name='group9' value='1P'>
                        �ѡ�֡����ͧ 1P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group9' value='1P' checked>
                        �ѡ�֡����ͧ 1P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group10']==''){
			  	?>
                        <input type=checkbox name='group10' value='2P'>
                        �ѡ�֡����ͧ 2P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group10' value='2P' checked>
                        �ѡ�֡����ͧ 2P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td> 
                        <?
			  if($_POST['group11']==''){
			  	?>
                        <input type=checkbox name='group11' value='3P'>
                        �ѡ�֡����ͧ 3P<br> 
                        <?
			}else{
				?>
                        <input type=checkbox name='group11' value='3P' checked>
                        �ѡ�֡����ͧ 3P<br> 
                        <?
			}?>
                      </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                  </table></td>
                <td nowrap><font size="2">* </font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">���ʹѡ�֡�ҷ���Ѻ����</font></td>
                <td nowrap> <input name="sid" type="text" id="sid" size="50"></td>
                <td nowrap><font size="2">����Ѻ�к��繺ؤ�� �� 44015336,44015365,42....</font></td>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">�ѹ�������С��</font></td>
                <td nowrap> <input name="start" type="text" id="start" size="10" maxlength="10" value="<? if($start==''){echo date("d\/m\/Y");}else{echo$start;} ?>"></td>
                <td nowrap><font size="2">* �ٻẺ dd/mm/yyyy</font></td>    </tr>
              </tr>
              <tr bgcolor="#F5F5DC"> 
                <td nowrap><font size="2">�ѹ����ش��С��</font></td>
                <td nowrap> <input name="end" type="text" id="end" size="10" maxlength="10" value="<? if($end==''){echo date("d\/m\/Y",(mktime(date("00,00,00,m,d,Y"))+(5*60*60*24)));}else{echo$end;} ?>"></td>
                <td nowrap><font size="2">* �ٻẺ dd/mm/yyyy</font></td><tr bgcolor="#F5F5DC"> 
                <td align="left" valign="middle" nowrap><font size="2">���Ṻ</font></td>
                <td nowrap> 
                  <?
	  	$total=$_POST['total'];
		$total_del=$_POST['total_del'];
	  	if($_POST['attach']=="ź���"){
			$next=0;
			while($total_del>0){
	  			$next=delete_file($next);
				$total--;
				$total_del--;
			}
		}
	  	$i=0;
		$j=$total;
	  	while($_POST["filedetail".$i]!='' && $j>=0){
			if($_POST["filedelete".$i]==''){
				$filedetail=$_POST["filedetail".$i];
				?>
                  <input type="checkbox" name="<? echo "filedelete".$i ?>" value='on' onClick="var sum=document.all.total_del.value;if(this.value.check){sum--;}else{sum++;};document.all.total_del.value=sum;var j=0;for(var i=0;i<document.forms[0].elements.length;i++){if(document.forms[0].elements[i].checked){j++;}};if(j){document.all.attach.value='ź���';}else{document.all.attach.value='Ṻ���';}"> 
                  <? echo "Name : $filedetail" ?> <input type=hidden name="<? echo "filedetail".$i ?>" value="<? echo $filedetail ?>"> 
                  <br> 
                  <?
				$j--;
			}
			$i++;
		}
		if($_POST['attach']=="Ṻ���"){
			$filedetail=upload_file($news_id);			
		}else{
			$filedetail="";
		}
		if($filedetail!='' && $filedetail!="dup"){
			$total++;
				?>
                  <input type="checkbox" name="<? echo "filedelete".$i ?>" value='on' onClick="var sum=document.all.total_del.value;if(this.value.check){sum--;}else{sum++;};document.all.total_del.value=sum;;var j=0;for(var i=0;i<document.forms[0].elements.length;i++){if(document.forms[0].elements[i].checked){j++;}};if(j){document.all.attach.value='ź���';}else{document.all.attach.value='Ṻ���';}"> 
                  <? echo "Name : $filedetail" ?> <input type=hidden name="<? echo "filedetail".$i ?>" value="<? echo $filedetail ?>"> 
                  <br> 
                  <?
		}
	  ?>
                  <input type=hidden name="total" value="<? if($total!=''){echo $total;}else{echo "0";}?>"> 
                  <input type=hidden name="total_del" value="0"> <input name="file" type="file" size="30"></td>
                <td nowrap><font size="2">&nbsp;��ԡ���͡������ͧ���ź</font></td>
              </tr>
              <tr bgcolor="#E6E6FA"> 
                <td nowrap>&nbsp;</td>
                <td colspan="2" nowrap> <input name="post" type="submit" id="post" value="��С��"> 
                  <input name="attach" type="submit" id="attach" value="Ṻ���"> 
                  <input name="cancel" type="submit" id="cancel" value="¡��ԡ"> 
                </td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">Department 
            of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
        </tr>
      </table></td>
  <tr> 
    <td height="10">&nbsp;</td>
  </tr>
</table>
</body></form>
</html>
<?
}else{
$url_page = "http://isag25.ce.kmitl.ac.th/~gead/news/post_news.php";
session_register('url_page');
header("location:http://isag25.ce.kmitl.ac.th/~gead/login.php");
exit();
}
?>
