<?PHP
function register_file($news_id,$file_id){ 
	if($news_id!='' && $file_id!=''){
		echo "$news_id<br>$file_id<br>";
		$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
		mysql_select_db("webce") or die(mysql_error());
		$result=mysql_query("update news_file set newsid='$news_id' where fileid='$file_id'") or die(mysql_error());
	}
}
?>