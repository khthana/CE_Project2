<?PHP
include "checkip.php";
session_start();
if(session_is_registered('name')&&session_is_registered('accesslevel')&&session_is_registered('memberof')&&session_is_registered('email')&&session_is_registered('ip')&&$ip==checkip()){
	?>
		User name : <?PHP echo $name?><br>
		User IP : <?PHP echo $ip?><br>
		User member type : <?PHP echo "$memberof"?><br>
		<? if($sid!='') echo "Student ID : $sid<br>\n"?>
		<a href="./../">Home</a>
	<?
} else {
	session_destroy();
	session_start();
	?>
		Please Login<br>
		<a href="./../">Home</a>
	<?
}
?>
