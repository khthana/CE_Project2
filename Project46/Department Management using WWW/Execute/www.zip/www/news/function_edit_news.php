<?PHP
function edit_news($news_id,$topic,$detail,$start,$end,$name,$edit){
	include "function_check_media_value.php";
	include "function_check_group_value.php";
	include "function_check_and_change_date.php";
	//---------------- Config ---------------//
	$host="localhost";
	$name="admin";
	$pass="admin";
	$db="webce";
	$query_news_detail="select topic,detail,start,end from news where id='$news_id'";
	$query_news_email="delete from news_email where news_id='$news_id'";
	$query_news_sms="delete from news_sms where news_id='$news_id'";
	$query_news_icq="delete from news_icq where news_id='$news_id'";
	$query_news_web="delete from news_web where news_id='$news_id'";
	$query_news_file="select fileid,filename from news_file where newsid='$news_id'";
	$query_news_media="select id,name from news_media where `use`='yes'";
	$query_news_group="select id,memberof from accesslevel";
	$query_update_news="update news set topic='$topic',detail='$detail',name='$name',start='$start',end='$end' where id='$news_id'";
	$redirect="http://isag25.ce.kmitl.ac.th/~best/test/";
	//--------------- End config -----------//
	if($news_id!=''){
		if($topic=='' && $detail=='' && $start=='' && $end==''){
			$link=mysql_connect($host,$name,$pass) or die(mysql_error());
			mysql_select_db($db) or die(mysql_error());
			$news_detail=mysql_query($query_news_detail) or die(mysql_error());
			$news_email=mysql_query($query_news_email) or die(mysql_error());
			$news_sms=mysql_query($query_news_sms) or die(mysql_error());
			$news_web=mysql_query($query_news_web) or die(mysql_error());
			$news_icq=mysql_query($query_news_icq) or die(mysql_error());
			$news=mysql_fetch_array($news_detail,MYSQL_NUM) or die(mysql_error());
			$topic=$news[0];
			$detail=$news[1];
			$chars=preg_split('//',$news[2],-1,PREG_SPLIT_NO_EMPTY);
			$start=$chars[6].$chars[7]."/".$chars[4].$chars[5]."/".$chars[0].$chars[1].$chars[2].$chars[3];
			$chars=preg_split('//',$news[3],-1,PREG_SPLIT_NO_EMPTY);
			$end=$chars[6].$chars[7]."/".$chars[4].$chars[5]."/".$chars[0].$chars[1].$chars[2].$chars[3];
			mysql_close($link);
		}
		if($edit=='' || ($topic=='' || $detail=='' || $start=='' || $end=='') || !check_media_value(some) || !check_group_value(some) || !check_and_change_date($start) || !check_and_change_date($end)){
			?>
			<form action="" method="post">
			<input type="hidden" name="news_id" value="<? echo $news_id?>"><br>
			��Ǣ�ͻ�С�� <input type="text" name="topic" value="<? echo $topic?>"><br>
			���ͤ��� <textarea name="detail" rows="5" cols="50"><? echo $detail?></textarea><br>
			����㹡�û�С�� 
			<?
				$link=mysql_connect($host,$name,$pass) or die(mysql_error());
				mysql_select_db($db) or die(mysql_error());
				$news_media=mysql_query($query_news_media) or die(mysql_error());
				while($media=mysql_fetch_array($news_media,MYSQL_NUM)){
					if($media[1]!='SMS'){
						$checked=$_POST["media".$media[0]];
						?>
						<input type="checkbox" name="<? echo "media$media[0]" ?>" value="on" <? if($checked=='on'){echo "checked";} ?>> <?echo $media[1];?>
						<?
					}else{
						$message=$_POST["media".$media[0]];
						?>
						<br><dd>SMS <input type="text" name="<? echo "media$media[0]" ?>" value="<? echo $message?>"><br>
						<?
					}
				}
				mysql_close($link);
			?>
			��������������Ѻ���� <br>
			<?
				$link=mysql_connect($host,$name,$pass) or die(mysql_error());
				mysql_select_db($db) or die(mysql_error());
				$news_group=mysql_query($query_news_group) or die(mysql_error());
				while($group=mysql_fetch_array($news_group,MYSQL_NUM)){
					?>
					<input type="checkbox" name="<? echo "group$group[0]"?>" value="on" <? if($_POST["group".$group[0]]!=''){echo "checked";}?>><? echo $group[1]?><br>
					<?
				}
				mysql_close($link);
			?>
			�ѹ�������С�� <input type="text" name="start" value="<? if(check_and_change_date($start)==false){echo "";}else{echo $start;}?>"><br>
			�ѹ����ش��С�� <input type="text" name="end" value="<? if(check_and_change_date($end)==false){echo "";}else{echo $end;}?>"><br>
			���Ṻ
			<?
				$link=mysql_connect($host,$name,$pass) or die(mysql_error());
				mysql_select_db($db) or die(mysql_error());
				$news_file=mysql_query($query_news_file) or die(mysql_error());
				while($file=mysql_fetch_array($news_file)){
					?>
					<input type="checkbox" name="<? echo $file[0]?>" value="delete"> <?echo $file[1]?><br>
					<?
					$i++;
				}
				mysql_close($link);
			?>
			<input type="submit" name="edit" value="���"> <input type="reset">
			</form>
			<?
		}else{
			//echo "update<br>";
			$start=check_and_change_date($start);
			$end=check_and_change_date($end);
			echo "$start<br>$end<br>";
			$link=mysql_connect($host,$name,$pass) or die(mysql_error());
			mysql_select_db($db) or die(mysql_error());
			$update_news=mysql_query($query_update_news) or die(mysql_error());
			$news_media=mysql_query("select id,name from news_media where `use`='yes'") or die(mysql_error());
			while($media=mysql_fetch_array($news_media,MYSQL_NUM)){
				$news_group=mysql_query("select id,memberof from accesslevel") or die(mysql_error());
				if($_POST["media".$media[0]]==''){
					continue;
				}
				while($group=mysql_fetch_array($news_group,MYSQL_NUM)){
					if($_POST["group".$group[0]]==''){
						continue;
					}
					if($media[1]=="Web"){
					//	if($group[0]==1){
							$update_news_view=mysql_query("insert into news_web(news_id,user_web) values('$news_id','$group[0]')")or die(mysql_error());
					/*	}else{
							$update_news_view=mysql_query("insert into news_web(news_id,user_web) values ('$news_id','$group[0]'") or die(mysql_error());
						}*/
						continue;
					}
					if($media[1]=="Email"){
						if($group[0]==1){
							continue;
						}else{
							$news_email_user=mysql_query("select email from useraccount where memberof='$group[0]'") or die(mysql_error());
							while($email_user=mysql_fetch_array($news_email_user,MYSQL_NUM)){
								if($email_user[0]!=''){
									$update_news_view=mysql_query("insert into news_email (news_id,user_email) value ('$news_id','$email_user[0]')") or die(mysql_error());
								}
							}
						}
							continue;
					}
					if($media[1]=="ICQ"){
						if($group[0]==1){
							continue;
						}else{
							if($group[1]!="�ؤ�ҡ���Ҥ�Ԫ�"){
								$news_icq_user=mysql_query("select icq from student where memberof='$group[1]'") or die(mysql_error());
							}else{
								$news_icq_user=mysql_query("select icq from personal") or die(mysql_error());
							}
							while($icq_user=mysql_fetch_array($news_icq_user,MYSQL_NUM)){
								if($icq_user[0]!=0){
									$update_news_view=mysql_query("insert into news_icq (news_id,user_icq) value ('$news_id','$icq_user[0]')") or die(mysql_error());
								}
							}
							continue;
						}
					}
					if($media[1]=="SMS"){
							if($group[0]==1){
							continue;
						}else{
							if($group[1]!="�ؤ�ҡ���Ҥ�Ԫ�"){
								$news_sms_user=mysql_query("select sms from student where memberof='$group[1]'") or die(mysql_error());
							}else{
								$news_sms_user=mysql_query("select sms from personal") or die(mysql_error());
							}
							while($sms_user=mysql_fetch_array($news_sms_user,MYSQL_NUM)){
								if($sms_user[0]!=0){
									$update_news_view("insert into news_sms (news_id,user_sms) value ('$news_id','$sms_user[0]')") or die(mysql_error());
								}
							}
							continue;
						}
					}
				}
			}
			//$update_news=mysql_query($query_update_news) or die(mysql_error());
			mysql_close($link);
			header("location:".$redirect);
		}
	}else{
		session_start();
		session_unregister("name");
		session_unregister("memberof");
		session_unregister("accesslevel");
		session_destroy();
		header("location:".$redirect);
	}
}
?>
