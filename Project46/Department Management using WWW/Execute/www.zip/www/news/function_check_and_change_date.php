<?
function check_and_change_date($date){ 
	$date_serial=explode("/",$date);
	if(checkdate($date_serial[1],$date_serial[0],$date_serial[2])){
		return $date_serial[2].$date_serial[1].$date_serial[0]."000000";
	}else{
		return false;
	}
}
?>