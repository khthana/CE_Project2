<?PHP
function start_post($name){ 
	if($name!=''){
		$time=date("YmdHis");
		$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
		mysql_select_db("webce") or die(mysql_error());
		$ids=mysql_query("select id from news where name='' and `start`='00000000000000' and `end`='00000000000000' order by id asc") or die(mysql_error());
		if(mysql_num_rows($ids)!=0){
			$id=mysql_fetch_array($ids,MYSQL_NUM) or die(mysql_error());
			$result=mysql_query("update news set `name`='$name',`start`='$time',`end`='$time' where id='$id[0]' and name='' and start='00000000000000' and end='00000000000000'") or die(mysql_error());
			return $id[0];
		}else{
			$insert=mysql_query("insert into news (`name`,`start`,`end`) values ('$name','$time','$time')") or die(mysql_error());
			$id=mysql_query("select `id` from `news` where `name`='$name' and `start`='$time' and `end`='$time'") or die(mysql_error());
			$ida=mysql_fetch_array($id,MYSQL_NUM) or die(mysql_error());
		return $ida[0];
		}
	}
}
?>
