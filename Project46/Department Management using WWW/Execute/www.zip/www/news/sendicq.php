<?PHP
function send_icq(){
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$newsid=mysql_query("select distinct `news_id` from `news_icq` where `status` = 'ready'") or die(mysql_error());
	while($nid=mysql_fetch_array($newsid))
	{
	$news_id=$nid[0];
	$news_message=mysql_query("select topic,detail,name from news where id='$news_id'") or die(mysql_error());
	$news=mysql_fetch_array($news_message,MYSQL_NUM) or die(mysql_error());
	$news_file=mysql_query("select fileid,filename from news_file where newsid='$news_id'") or die(mysql_error());
	$num_file=mysql_num_rows($news_file);
	$des=mysql_query("select user_icq from news_icq where news_id='$news_id' and status='ready'") or die(mysql_error());
	list($usec, $sec) = explode(" ",microtime());
	while($icq_num=mysql_fetch_array($des,MYSQL_NUM)){
		$message = "��С������ͧ : $news[0]".chr(13)."������ : $news[1]".chr(13)."����С�� : $news[2]";
		$message=chr(12)."\nOUT\nMSG\n".$sec."\n".$sec."\n".$message."\n";
		if($num_file!=0){
			$i=0;
			while($file=mysql_fetch_array($news_file,MYSQL_NUM)){
				$message .=chr(13)."����Сͺ��С�� : ".$file[1]." Link : http://isag25.ce.kmitl.ac.th/~gead/news/downloadfile.php?file_id=".$file[0]."\n";
				$i++;

			}
		}
		//echo "$icq_num[0]<br>$message<br>";
		$text = system("echo '$message' >> /var/www/.centericq/$icq_num[0]/offline");
		$text = system("date >> /var/log/icq;echo 'ICQ Number : $icq_num[0]' >> /var/log/icq;echo '$message' >> /var/log/icq");
		$sended=mysql_query("update news_icq set status='sended' where news_id='$news_id' and user_icq='$icq_num[0]'") or die(mysql_error());
	}
	}

}
send_icq();
?>
