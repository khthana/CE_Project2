<?
function show_topic($sid,$name,$memberof,$sroom){
	$link=mysql_connect("localhost","root","abc123") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	if($memberof=='2'){ 
		$sql = 'SELECT news.id, news.topic'
        . ' FROM news, news_web'
        . ' WHERE ( news_web.user_web = \''.$sid.'\' OR news_web.user_web in (\'�ؤ�ŷ����\',\''.$sroom.'\' )) AND news.id = news_web.news_id AND news.start <= now( ) AND news.end >= now( ) ORDER BY news.start DESC, news.id  DESC'; 
	}else{
		if( $memberof !='3'){
		$sql = 'SELECT news.id,news.topic'
			  . ' FROM news,news_web'
              . ' WHERE news.id=news_web.news_id and news_web.user_web=\'�ؤ�ŷ����\' AND news.start <= now( ) AND news.end >= now( ) ORDER BY news.start DESC,news.id DESC';
		}else{
				$sql = 'SELECT news.id,news.topic'
			  . ' FROM news,news_web'
              . ' WHERE news.id=news_web.news_id  AND news.start <= now( ) AND news.end >= now( ) ORDER BY news.start DESC,news.id DESC';
		}
	}
	$result=mysql_query($sql) or die(mysql_error());
	while($row=mysql_fetch_array($result,MYSQL_NUM)){
		?> <div align="left"><img src="http://isag25.ce.kmitl.ac.th/~gead/pic/pin_news.gif" border="0"><a href="./news/viewnews.php?id=<?echo$row[0]?>" target="_blank"> 
<?echo$row[1]?></a> 
<?
	}
	mysql_close($link);
}
/*
function view_news_detail($news_id,$name,$memberof){
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	if($name!='' && $memberof!='�ؤ�ŷ����'){
		$sql = 'select news.topic,news.detail '
				.'from news,news_web '
				.'where news.id=\''.$news_id.'\'news.id=news_web.news_id and news_web.name=\''.$name.'\'';
	}else{
		$sql = 'select news.topic,news.detail '
				.'from news,news_web '
				.'where news.id=\''.$news_id.'\' news.id=news_web.news_id and news_web.name=\'public\'';
	}
	$result=mysql_query($sql) or die(mysql_error());
	if(mysql_num_rows($result)!=1){
		echo "����բ��ǻ�С�ȹ������㹰ҹ������";
	}else{
		$row=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());

	}
}
*/

function thai_date($timestamp){
	$month = array("","���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�á�Ҥ�","�ԧ�Ҥ�","�ѹ��¹","���Ҥ�","��Ȩԡ�¹","�ѹ�Ҥ�");
	$chars = preg_split('//', $timestamp, -1, PREG_SPLIT_NO_EMPTY);
	$d = $chars[6].$chars[7];
	if($d<10){
		$d = $chars[7];
	}
	$M = $chars[4].$chars[5];
	if($M<10){
		$M = $chars[5];
	}	
	$Y = $chars[0].$chars[1].$chars[2].$chars[3];
	return "�ѹ��� ".$d . " ��͹ ".$month[$M]." �.�. ".($Y+543);
}

//echo thai_date(date(Ymd));
?>
