<?PHP
include "checkip.php";
session_start();
if(session_is_registered('name') && session_is_registered('memberof') && session_is_registered('accesslevel') && $accesslevel > 1 && session_is_registered('ip') && $ip==checkip()){
	$topic=$_POST['topic'];
	$detail=$_POST['detail'];
	$start=$_POST['start'];
	$end=$POST['end'];
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	if($topic!='' && $detail!='' && $start!='' && $end!='' && $_POST['post']!='' && $_POST['file']==''){
		$result=mysql_query("insert into news(topic,detail,start,end,name) value('$topic','$detail','$start','$end','$name')") or die(mysql_error());
	}else{
	header("location:http://isag25.ce.kmitl.ac.th/~best/test/news/post");
	}
}else{
	//session_destroy();
	echo "You haven't permission";
}
?>
