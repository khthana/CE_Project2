<?PHP
function return_group_value(){ 
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select id from accesslevel") or die(mysql_error());
	$total=mysql_num_rows($result) or die(mysql_error());
	$total--;
	while($row=mysql_fetch_array($result,MYSQL_NUM)){
		$group="group".$row[0];
		if($_POST[$group]!=''){
			${"group".$row[0]}="on";
		}
		$total--;
	}
	mysql_close($link);
}
?>
