<?PHP
	session_start();
	include "connect.php";
	include "show_topic_function.php";
	$news_id=$_GET['id'];
	$result=mysql_query("select news.id,news.topic,news.start,news.detail,news.name from news where news.id='$news_id' and news.start<=now() and news.end>=now()") or die(mysql_error());
	$row=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<form name="form1" method="post" action="">
  <table width="100%" border="0">
    <tr> 
      <td width="16%"><div align="center"><a href="viewalltopic.php">�ٷ�����</a></div></td>
      <td> 
        <? if($accesslevel>1){?>
        <div align="left"><a href="editnews.php">��䢻�С��</a> 
          <? }else{?>
          <? }?>
        </div></td>
    </tr>
    <tr bgcolor="#66FFFF"> 
      <td colspan="2"><font size="3" color="blue">
        <dd>��С������ͧ <? echo $row[1] ?> ��С������� <? echo thai_date($row[2]) ?></font></td>
    </tr>
    <tr> 
      <td colspan="2"><dd><? echo str_replace("\n","<br>\n",$row[3]);?></td>
    </tr>
    <tr> 
      <td colspan="2"><div align="right"><font size="3">����С�� <? echo $row[4] ?></font></div></td>
    </tr>
    <tr> 
      <td colspan="2">&nbsp;</td>
    </tr>
  </table>
</form>

</body>
</html>
