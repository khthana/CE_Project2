<? session_start();
include "connect.php";
include "notice.php";
include "./include/function.php";
include "./user/checkip.php";		

 session_register('url_error');
 $url_error = 'http://isag25.ce.kmitl.ac.th/~gead/';
 		
if($_POST['username']=='' && $_POST['password']=='' ){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�Ҥ�Ԫ����ǡ�������������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="./include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>  <form name="index" method="post" action="http://isag25.ce.kmitl.ac.th/~gead/index.php">
<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('pic/b_subject_over.gif','pic/b_officer_over.gif','pic/b_oldstudent_over.gif','pic/b_webboard_over.gif','pic/b_newstudent_over.gif','pic/b_faq_over.gif','pic/projectup.gif','pic/formproject.gif','pic/formprojectup.gif','pic/project.gif','pic/hptech.gif','pic/hptechup.gif','pic/newform.gif','pic/newformup.gif','pic/gweb.gif','pic/gwebup.gif','pic/comproject.gif','pic/comprojectup.gif','pic/CE-Webmail.gif','pic/CE-Webmailup.gif')" >
<table  width="780" border="0" cellpadding="0" cellspacing="0" >

<tr><td valign="top" nowrap>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="pic/headce_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		    <TD height="43" class="linebottom"> <IMG SRC="pic/headce_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE>

</td></tr>
    <tr> 
      <td valign="top" nowrap bgcolor="#FFFFFF"  ><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr>
            
          <td  width="120" height="20"><a href="http://www.ce.kmitl.ac.th/webdepartment/course/homepage/subject/index.php" onMouseOver="MM_swapImage('Image1','','pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>         
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
            
          <td width="120" ><a href="http://www.ce.kmitl.ac.th/alumni/index.php" onMouseOver="MM_swapImage('Image3','','pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/webboard/" onMouseOver="MM_swapImage('Image4','','pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
			
          <td width="120" ><a href="http://www.kmitl.ac.th/%7Ekcwatcha/newstudent.html" onMouseOver="MM_swapImage('Image5','','pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
            
          <td width="199"><a href="http://www.kmitl.ac.th/%7Ekcwatcha/faq.html" onMouseOver="MM_swapImage('Image6','','pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
          </tr>
        </table> </td>
    </tr>
    <tr> 
      
    <td valign="top" nowrap> 
      <table  width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor=>
          <tr> 
            
          <td width="780"  valign="top" nowrap  > 
            <table width="780" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="580" background="pic/agetop.png" class="linebottom">&nbsp;
				                      <?
				  if (!empty($name)){
						echo "> $name |  " ;
						if($memberof == '1'){echo "�ؤ�ŷ����";}; 
						if($memberof == '2'){echo $sroom;}; 
						if($memberof=='3'){echo "�ؤ�ҡ�";}						
						session_register('name');
					}
			
				?>
				  </td>
                  <td width="200" background="pic/agetop.png" align="right"><? 					
					echo $thaiweekFull[date("w")]." ".date("j")." ".$thaimonthFull[date("m")-1]." ".$year;
				  	?>&nbsp;</td>
                </tr>
                <tr>
                  
                <td height="528" valign="top" class="lineright"> 
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                      <tr> 
                        <td align="left" valign="top" nowrap><div align="center">
                            <?PHP
		if($accesslevel > 2){echo"<a href='./news/post_news.php'>��С��</a>";
		}else{ ?>
			<img src="./pic/postx.gif">
	   <?	
		}
	   ?>
                            </div></td>
                      </tr>
                      <tr> 
                        
                      <td width="580" align="left" valign="top" nowrap> 
                        <?PHP
				include "./news/show_topic_function.php";
				show_topic($sid,$name,$memberof,$sroom);
		
				?>
                        <font size="2" color="#000080" >&nbsp; </font> 
                        <p align="right"><font size="2"><a href="http://isag25.ce.kmitl.ac.th/~gead/news/viewalltopic.php">�ٻ�С�ȷ����� 
                          &nbsp;</a></font></p></td>
                      </tr>
                    </table>
                    
                  <p>&nbsp; </p></td>
                  
                <td bgcolor="E5E5E5"  valign="top" nowrap> 
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td colspan="2" height="10"></td>
                    </tr>
                    <?		  
					  if(empty($name)){
			?>
                    <tr> 
                      <td width="26%" align="right">&nbsp;����� : </td>
                      <td width="74%" > &nbsp; <input type="text" name="username" id="username4" class="violet"> 
                      </td>
                    </tr>
                    <tr> 
                      <td align="right">&nbsp;���ʼ�ҹ : </td>
                      <td > &nbsp; <input type="password" name="password" class="violet"> 
                      </td>
                    </tr>
                    <tr> 
                      <td colspan="2" align="right"> <input type="submit" name="Submit" value="�������к�" class="violet" > 
                        &nbsp; </td>
                    </tr>
                    <?			  
					  }
		?>
                    <tr> 
                      <?
	  				if(!session_is_registered('name')){ ?>
                      <td colspan=2 align='center'><a href="" target="_self" onClick="var s='?username='+document.all.username.value;this.href='http://isag25.ce.kmitl.ac.th/~gead/user/forget_password.php'+s">������ʼ�ҹ</a> 
                        | <a href='./user/register.php'>ŧ����¹</a></td>
                      <?				
				}else{
				
      				echo "<td colspan=2 align='center'>								
					<a href='./user/logout.php?logout=logout'>��͡��ҷ�<a>&nbsp;|&nbsp;
	  				<a href='./user/changepassword.php'>����¹���ʼ�ҹ</a>
					</td>";      	
		}
	  ?>
                    </tr>
                    <tr> 
                      <td colspan="2">&nbsp;</td>
                    </tr>
                    <tr > 
                      <td height="191" colspan="2" valign="top" nowrap> 
                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                          <tr> 
                            <td width="34%" height="175" valign="top" background="pic/bgbarmenu.gif" noprow > 
                              <table width="100%" border="0" cellpadding="0" cellspacing="0" >
                                <tr> 
                                  <td><a href="http://www.ce.kmitl.ac.th/project/index.php" target="_top" onClick="MM_nbGroup('down','group1','project','pic/project.gif',1)" onMouseOver="MM_nbGroup('over','project','','pic/projectup.gif',1);MM_nbGroup('over','project','pic/projectup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/project.gif" name="project" width="200" height="25" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td ><a href="http://sapphire.ce.kmitl.ac.th/project/index.php" target="_top" onClick="MM_nbGroup('down','group1','formproject','pic/formproject.gif',1)" onMouseOver="MM_nbGroup('over','formproject','pic/formprojectup.gif','',1);MM_nbGroup('over','formproject','pic/formprojectup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/formproject.gif" name="formproject" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td><a href="http://sapphire.ce.kmitl.ac.th/" target="_top" onClick="MM_nbGroup('down','group1','hptech','pic/hptech.gif',1)" onMouseOver="MM_nbGroup('over','hptech','pic/hptechup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/hptech.gif" name="hptech" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td><a href="http://personal.ce.kmitl.ac.th/~thana/new_curriculum.pdf" target="_top" onClick="MM_nbGroup('down','group1','newform','pic/newform.gif',1)" onMouseOver="MM_nbGroup('over','newform','pic/newformup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/newform.gif" name="newform" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td><a href="http://www.ce.kmitl.ac.th/gwebboard/index.php" target="_top" onClick="MM_nbGroup('down','group1','gweb','pic/gweb.gif',1)" onMouseOver="MM_nbGroup('over','gweb','pic/gwebup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/gweb.gif" name="gweb" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td><a href="http://sapphire.ce.kmitl.ac.th/webcomputerproject/Computer%20Project.htm" target="_top" onClick="MM_nbGroup('down','group1','comproject','pic/comproject.gif',1)" onMouseOver="MM_nbGroup('over','comproject','pic/comprojectup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/comproject.gif" name="comproject" border="0"></a></td>
                                </tr>
                                <tr> 
                                  <td><a href="http://sapphire.ce.kmitl.ac.th/webmail/" target="_top" onClick="MM_nbGroup('down','group1','CEWebmail','pic/CE-Webmail.gif',1)" onMouseOver="MM_nbGroup('over','CEWebmail','pic/CE-Webmailup.gif','',1)" onMouseOut="MM_nbGroup('out')"><img src="pic/CE-Webmail.gif" name="CEWebmail" border="0"></a></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td>&nbsp;</td>
                          </tr>
                          <tr> 
                            <td background="pic/mn.gif" align="center" ><font color="#000066" ><b>���� ���ʹ�</b></font></td>
                          </tr>
                          <tr>
                            <td>&nbsp; > <a href="http://whatis.techtarget.com/">IT 
                              Specific encycopedia</a> </td>
                          </tr>
                          <tr>
                            <td>&nbsp; > <a href="http://freshmeat.net/">Freshmeat.net </a>
                              </a> </td>
                          </tr>
                          <tr>
                            <td>&nbsp; > <a href="http://www.winnetmag.com/windowsnt20002003faq/">NT FAQ ? </a>
</td>
                          </tr>
                          <tr>
                            <td>&nbsp; > <a href="http://www.java.sun.com/">Java Searchable Document </a>
</td>
                          </tr>
                          <tr>
                            <td>&nbsp; > <a href="http://www.siamguru.com/">Thai search engine </a></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr >
                      <td height="200" background="pic/mn90.gif" colspan="2" ><table   width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>					
                            <td align="center"><img src="pic/cementbt02.gif" width="158" height="52" ></td>
                          </tr>
						  <tr>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td><div align="center"><a href="http://www.ce.kmitl.ac.th/marketplace/index.php">Ladkrabang 
                                Marketplace</a></div></td>
                          </tr>
                          <tr>
                            <td><div align="center"><a href="http://161.246.4.2/Service/Train.nsf">���ҧ�Թö���µ��ѹ�͡</a> 
                              </div></td>
                          </tr>
                          <tr>
                            <td><div align="center"><a href="http://www.kmitl.ac.th/cgi-bin/web_index.pl">Webboard 
                                ʶҺѹ �</a></div></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                          </tr>
                        </table></td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  
                <td height="40" background="pic/agebottom.gif" class="linetop"><font  color="#000099" size="-2"  class="violet">&nbsp; 
                  Department of Computer Engineering Faculty of Engineering King 
                  Mongkut's Institute of Technology<br>
        &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
                  <td background="pic/agebottom.gif">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            
          <td height="20">&nbsp;</td>
          </tr>
        </table></td>

</table>
</body>  </form>
</html>
<?
}else{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	$sql = "SELECT useraccount.username, useraccount.email, useraccount.memberof, accesslevel.level, useraccount.sid, useraccount.pid' . ' FROM useraccount, accesslevel" . " WHERE useraccount.password=md5('$password.$username') and useraccount.username='$username' and useraccount.memberof=accesslevel.id"; 
	$result=mysql_query($sql) or die(mysql_error());
	if(mysql_num_rows($result)==1){
		$row=mysql_fetch_array($result,MYSQL_NUM);
		session_register('ip_addr');
		$ip_addr =checkip();
		session_register('name');
		$name=$row[0];
		session_register('email');
		$email=$row[1];
		session_register('memberof');
		$memberof=$row[2];
		session_register('accesslevel');
		$accesslevel=$row[3];
		if($row[4]!=null){
			session_register('sid');
			$sid=$row[4];
			$sql = "SELECT name,room"
		    . " FROM student"
			. " WHERE sid = '$sid' ";
			$result=mysql_query($sql) or die(mysql_error);
			$row=mysql_fetch_array($result,MYSQL_NUM); 
			if(mysql_num_rows($result)==1){
				session_register('realname');
				$realname=$row[0];
				session_register('sroom');
				$sroom=$row[1];
			}else{
				session_destroy();

			}
		}
		if($row[5]!=null){
			session_register('pid');
			$pid=$row[5];
			$sql = "SELECT name,position,teaching"
		    . " FROM personal_detail"
			. " WHERE id = '$pid' ";
			$result=mysql_query($sql) or die(mysql_error);			
			$row=mysql_fetch_array($result,MYSQL_NUM); 
								if(mysql_num_rows($result)==1){
									session_register('realname');
									$realname=$row[0];
									session_register('position');
									$position=$row[1];
									session_register('teaching');
									$teaching=$row[2];

								}else{
									session_destroy();

								}
		}
		print "<META http-equiv=refresh content='0; URL=http://isag25.ce.kmitl.ac.th/~gead/'>";
	}else{
		session_destroy();
		notice ("red","�س��� Username  ���� Password ���١��ͧ","[ ˹���á ]");
				exit;
	}
}	
?>