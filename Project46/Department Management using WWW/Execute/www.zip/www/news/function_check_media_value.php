<?PHP
function check_media_value($check_type){ 
	$check_media_value=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select id from news_media") or die(mysql_error());
	$total=mysql_num_rows($result) or die(mysql_error());
	$total--;
	while($row=mysql_fetch_array($result,MYSQL_NUM)){
		$media="media".$row[0];
		if($_POST[$media]!=''){
			$value=1;
		}else{
			$value=0;
		}
		if($check_type=='all'){
			$check &= $value;
		}else{
			$check |= $value;
		}
		$total--;
	}
	mysql_close($check_media_value);
	return $check;
}
?>
