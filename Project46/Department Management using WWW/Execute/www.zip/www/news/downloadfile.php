<?PHP
$file_id=$_GET['file_id'];
$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db("webce") or die(mysql_error());
$sql = 'SELECT filename, file_type, file_size'
        . ' FROM news_file'
        . ' WHERE fileid = \''.$file_id.'\'';
$file_detail=mysql_query($sql) or die(mysql_error());
$file=mysql_fetch_array($file_detail,MYSQL_NUM);
header("Content-Type: $file[1]"); 
header("Content-Disposition: attachment; filename=".$file[0]);
header("Content-Length:".$file[2]);
//header("Expires: 0");
//header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
//header("Pragma: public");	
readfile("/home/gead/public_html/news/file/".$file_id);
exit;
?>
