<?PHP
function delete_file($i){ 
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	//echo "$i<br>";
	while($_POST["filedelete".$i]==''){
		$i++;
	};
	$filedelete=$_POST["filedetail".$i];
	$result=mysql_query("select fileid from news_file where filename='$filedelete'") or die(mysql_error());
	$row=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());
	system("rm -f ./file/$row[0]");
	$result=mysql_query("delete from news_file where filename='$filedelete'") or die(mysql_error());
	return $i;
}
?>
