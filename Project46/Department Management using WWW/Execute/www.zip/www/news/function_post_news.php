<?PHP
include "sms_function.php";
function post_news($news_id,$topic,$detail,$name,$start,$end,$message){
	$link=mysql_connect("localhost","admin","admin") or die("Line 4 ".mysql_error());
	mysql_select_db("webce") or die("Line 5 ".mysql_error());
	$start_serial=check_and_change_date($start);
	$end_serial=check_and_change_date($end);
	$qname=mysql_query("select name from useraccount, officer where useraccount.username='$name' and useraccount.pid=officer.id") or die(mysql_error());
	$rname=mysql_fetch_array($qname,MYSQL_NUM);
	$result=mysql_query("update news set `topic`='$topic',`detail`='$detail',`start`='$start_serial',`end`='$end_serial',`name`='$rname[0]' where name='$name' and id='$news_id'") or die("Error 1 ".mysql_error());
	$news_media=mysql_query("select id,name from news_media where `use`='yes'") or die("Error 2 ".mysql_error());
	while($media=mysql_fetch_array($news_media,MYSQL_NUM)){
		if($_POST["media".$media[0]]==''){
			continue;
		}
		$media[1]=strtolower($media[1]);
		$sgroup=array('on','1D1','1D2','2D1','2D2','3D1','3D2','4D1','4D2','1P','2P','3P');
		$skip=false;
		for($i=0;$i<12;$i++){
			if($_POST["group".$i]=='' && $_POST['sid']==''){
				continue;
			}

			$group=$_POST["group".$i];
			if($media[1]=='web'){
				if($group=='on'){
					if($skip){
						continue;
					}
					$post=mysql_query("insert into news_web(news_id,user_web) values('$news_id','�ؤ�ŷ����')") or die("Error 4 ".mysql_error());
					$skip=true;
					continue;
				}else{
					if($_POST['sid']!=''){
						$id=explode(",",$_POST['sid']);
					};
					$group_stored=mysql_query("select * from news_web where news_id='$news_id' and (user_web='�ؤ�ŷ����' or user_web='$group')") or die("Error 5 ".mysql_error());
					if($group!='' && mysql_num_rows($group_stored)==0){
						$group_store=mysql_query("insert into news_web (news_id,user_web) values ('$news_id','$group')") or die("Error 6 ".mysql_error());
					}
					$j=0;
					while($id[$j]!=''){
						$user_stored=mysql_query("select * from news_web where news_id='$news_id' and user_web='$id[$j]'") or die("Error 7 ".mysql_error());
						if(mysql_num_rows($user_stored)==0){
					
							$user_store=mysql_query("insert into news_web (news_id,user_web) values ('$news_id','$id[$j]')") or die("Error 8 ".mysql_error());
						}
						$j++;
					}
					continue;
				}
			};
		
			if($media[1]=='email'){
				
				$rid='';
				if($_POST['sid']!=''){
					$id=explode(",",$_POST['sid']);
					$j=0;
					$rid='';
					while($id[$j]!=''){
						$rid .= "'$id[$j]'";
						if($id[$j+1]!=''){
							$rid .= ",";
						}
						$j++;
					}
				
				}
				if ( $rid=='' ) $rid="''";
				$user_des=mysql_query("select `email` from `useraccount`,`student` where useraccount.sid=student.sid and (student.room='$group' or useraccount.sid in ($rid))") or die("Line 30 ".mysql_error());
				
			}
			if($media[1]=='icq'){
				$user_des=mysql_query("select student.icq from useraccount,student where useraccount.sid=student.sid and student.room='$group' and student.icq!=''") or die("Line Line 33 ".mysql_error());
			}
			if($media[1]=='sms'){
				$user_des=mysql_query("select student.sms from useraccount,student where useraccount.sid=student.sid and student.room='$group' and student.sms!=''") or die("Line 36 ".mysql_error());
			}
			while($des=mysql_fetch_array($user_des,MYSQL_NUM)){
				$des_stored=mysql_query("select * from news_".$media[1]." where news_id='$news_id' and user_".$media[1]."='$des[0]'") or die("Error 9 ".mysql_error());
				if(mysql_num_rows($des_stored)!=0){
					continue;
				};
				if($media[1]!='sms'){
					$des_store=mysql_query("insert into news_" . $media[1] . "(news_id,user_" . $media[1] . ") values ('$news_id','$des[0]')") or die("Line 39 ".mysql_error());
					continue;
				}
				if($media[1]=='sms' && $message!='') {
					$messagesms=create_pdu($des[0],$message);
					$des_store=mysql_query("insert into news_sms (news_id,user_sms,sms_message) values ( '$news_id','$des[0]','". create_pdu ($user_sms, $messagesms) ."')");
					continue;
				}
			}
		}
	}
}
?>
