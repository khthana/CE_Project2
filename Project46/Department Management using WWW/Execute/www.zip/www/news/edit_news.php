<?PHP
	include "function_edit_news.php";
	edit_news(4,$_POST['topic'],$_POST['detail'],$_POST['start'],$_POST['end'],"best3140",$_POST['edit']);
?>
