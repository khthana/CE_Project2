<?PHP
function upload_file($news_id){
	echo "news_id : $news_id<br>";
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select `filename`,`file_type`,`file_size` from news_file") or die(mysql_error());
	if($_POST['attach']!=''){
		$uploaddir="./file/";
		$uploadfile=$uploaddir.$_FILES['file']['name'];
		if(move_uploaded_file($_FILES['file']['tmp_name'],$uploadfile)){
			$filename=$_FILES['file']['name'];
			$file_size=$_FILES['file']['size'];
			$file_type=$_FILES['file']['type'];
			$result=mysql_query("select fileid from news_file where filename='$filename' and file_type='$file_type' and file_size='$file_size'");
			if(mysql_num_rows($result)!=0){
				unlink("./file/$filename") or die("can't delete file");
				print "<font color='red'>������ $filename ����������<br>\n��س�����¹��������͹ upload</font><br>";
				return "dup";
			}else{
				$result=mysql_query("insert into news_file(newsid,filename,file_type,file_size) values('$news_id','$filename','$file_type','$file_size')") or die(mysql_error());
				$result=mysql_query("select fileid from news_file where filename='$filename' and file_type='$file_type' and file_size='$file_size'");
				$row=mysql_fetch_array($result,MYSQL_NUM);
				rename("./file/$filename","./file/$row[0]");
				system("chmod 400 ./file/*");
			}
		}else{
			print"Possible file upload attack!";
			print_r($_FILES);
		}
		echo "FILE NAME : ".$filename;
		exit;
		return "$filename";
	}else{
		return "";
	}
}
?>
