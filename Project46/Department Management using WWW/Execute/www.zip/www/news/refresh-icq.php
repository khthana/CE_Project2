<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<script language="JavaScript">

//Refresh page script- By Brett Taylor (glutnix@yahoo.com.au)
//Modified by Dynamic Drive for NS4, NS6+
//Visit http://www.dynamicdrive.com for this script

//configure refresh interval (in seconds)
var countDownInterval=10;
//configure width of displayed text, in px (applicable only in NS4)
var c_reloadwidth=200

</script>


<ilayer id="c_reload" width=&{c_reloadwidth}; ><layer id="c_reload2" width=&{c_reloadwidth}; left=0 top=0></layer></ilayer>

<script>

var countDownTime=countDownInterval+1;
function countDown(){
countDownTime--;
if (countDownTime <=0){
countDownTime=countDownInterval;
clearTimeout(counter)
window.location.reload()
return
}
if (document.all) //if IE 4+
document.all.countDownText.innerText = countDownTime+" ";
else if (document.getElementById) //else if NS6+
document.getElementById("countDownText").innerHTML=countDownTime+" "
else if (document.layers){ //CHANGE TEXT BELOW TO YOUR OWN
document.c_reload.document.c_reload2.document.write('Next <a href="javascript:window.location.reload()">Send next ICQ</a> in <b id="countDownText">'+countDownTime+' </b> seconds')
document.c_reload.document.c_reload2.document.close()
}
counter=setTimeout("countDown()", 1000);
}

function startit(){
if (document.all||document.getElementById) //CHANGE TEXT BELOW TO YOUR OWN
document.write('Next <a href="javascript:window.location.reload()">Send next ICQ</a> in <b id="countDownText">'+countDownTime+' </b> seconds')
countDown()
}

if (document.all||document.getElementById)
startit()
else
window.onload=startit

</script>
<?PHP
	include "sendicq.php";
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$result=mysql_query("select news.id,user_icq,news.topic,news.detail,news.name from news,news_icq where news.id=news_icq.news_id and news_icq.status=''") or die(mysql_error());
	$remain=mysql_num_rows($result) or die(mysql_error());
	$remain--;
	echo "<br>remain news send via ICQ : $remain number";
	if($remain>=0){
		$row=mysql_fetch_array($result,MYSQL_NUM) or die(mysql_error());
		send_icq($row[1],"��С������ͧ ". $row[2] . "\n����С�� ". $row[3]);
		echo "<br>now send news id = $row[0] to ICQ : $row[1]<br>��С������ͧ : $row[2]<br>������ : $row[3]<br>����С�� : $row[4]";
		$result=mysql_query("update news_icq set status='sended' where news_id='$row[0]' and user_icq='$row[1]'") or die(mysql_error());
	}
	mysql_close($link);
?>
</body>
</html>
