<?
session_start();
include "checkip.php";
$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db("webce",$link) or die(mysql_error());
if(session_is_registered('name') && session_is_registered('accesslevel') && session_is_registered('memberof') && session_is_registered('ip') && $memberof != '�ؤ�ŷ����' && $ip== checkip()){
	echo "news for $name<br>\n";
	$sql = 'SELECT news.id,news.topic'
	    . ' FROM news,news_web'
	    . " WHERE news.id=news_web.news_id and (news_web.user_name='$name' or news_web.user_name='public') AND news.start <= now( ) AND news.end >= now( )";
}else{
	echo "news for public<br>\n";
	$sql = 'SELECT id,topic'
    	    . ' FROM news,news_web'
    	    . " WHERE news.id=news_web.news_id and news_web.user_name='public' AND news.start <= now( ) AND news.end >= now( )"; 
}
$result=mysql_query($sql) or die(mysql_error());
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<div align="center">
  <p><strong><font size="3"><a href="viewnews.php">���ǻ�С��</a></font></strong> 
  <?echo$time?>
  </p>
  <?
  while($row=mysql_fetch_array($result,MYSQL_NUM)){
  ?>
  <div align="left"><a href="viewnews.php?id=<?echo$row[0]?>" target="_blank"><?echo$row[1]?></a> 
    <?
  }
  ?>
  </div>
</div>
</body>
</html>
<?
mysql_close($link);
?>
