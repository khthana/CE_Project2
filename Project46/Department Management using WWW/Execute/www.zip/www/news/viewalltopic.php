<? 
session_start();

function thai_date($timestamp){
	$month=array("�.�.","�.�.","��.�.","��.�.","�.�.","��.�.","�.�.","�.�.","�.�.","�.�.", "�.�.","�.�.");
	$chars = preg_split('//', $timestamp, -1, PREG_SPLIT_NO_EMPTY);
	$d = $chars[6].$chars[7];
					if($d<10){
						$d = $chars[7];
					}
	$M = $chars[4].$chars[5];
					if($M<10){
						$M = $chars[5];
					}	
	$Y = $chars[0].$chars[1].$chars[2].$chars[3];
	return $d . " ".$month[$M]." ".($Y+543);
}
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	if($memberof>'1'){
		$sql = 'SELECT news.id, news.topic,news.start'
        . ' FROM news, news_web'
        . ' WHERE ( news_web.user_web = \''.$name.'\' OR news_web.user_web in (\'�ؤ�ŷ����\',\''.$sroom.'\' )) AND news.id = news_web.news_id AND news.start <= now( ) AND news.end >= now( ) ORDER BY news.start DESC, news.id  DESC'; 
	}else{
		$sql = 'SELECT news.id,news.topic,news.start'
			  . ' FROM news,news_web'
              . ' WHERE news.id=news_web.news_id and news_web.user_web=\'�ؤ�ŷ����\' AND news.start <= now( ) AND news.end >= now( ) ORDER BY news.start DESC,news.id DESC';
	}

?>			
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�٢��ǻ�С�ȷ�����</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
</head>
<body leftmargin="0" topmargin="0">
<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tr> 
    <td colspan="3"><img src="../pic/cekmitl.gif" width="300" height="50"></td>
  </tr>
  <tr>
    <td colspan="3"><br>
      <table align="center" width="720" cellspacing="0" cellpadding="0" border="1">
        <tr> 
          <td width="13%"><div align="center">�ѹ����С��</div></td>
          <td width="85%"><div align="center">��Ǣ������ͧ</div></td>
        </tr>
        <?
			$result=mysql_query($sql) or die(mysql_error());
			while($row=mysql_fetch_array($result,MYSQL_NUM)){ 
		?>
        <tr> 
          <td align="center"><? echo thai_date($row[2]);?> </td>
          <td>&nbsp; <a href="viewnews.php?id=<?echo$row[0]?>" target="_self"><?echo$row[1]?></a></td>
        </tr>
        <? } ?>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="16" colspan="3">&nbsp;</td>
  </tr>
</table>

</body>
</html>
<?
		mysql_close($link);

?>