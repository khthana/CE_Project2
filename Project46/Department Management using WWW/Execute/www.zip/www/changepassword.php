<?PHP
include "connect.php";
include "checkip.php";
include "logout.php";
session_start();
if(!session_is_registered('name') || !session_is_registered('ip')){
	session_destroy();
	?>
		<META http-equiv=refresh content='3; URL=http://isag25.ce.kmitl.ac.th/~gead/index.php'>
	<?
	echo Message(35,"red","�س�ѧ�����ӡ�� login �������к�<br>","��س� loging ����к���͹��Ѻ","");		
	exit;
}
$password=$_POST['old'];
$result=mysql_query("select username from useraccount where username='$name' and password=md5('$password')") or die(mysql_error());
if(mysql_num_rows($result)==1&&($_POST['new1']!='')&&($_POST['new2']!='')){
	if($_POST['new1']==$_POST['new2']){
		$password=$_POST['new1'];
		$result=mysql_query("update useraccount set password=md5('$password') where username='$name'") or die(mysql_error());
		logout();
		?>
			<META http-equiv=refresh content='3; URL=http://isag25.ce.kmitl.ac.th/~gead/user/login.php'>
		<?
		echo Message(35,"green","�ӡ������¹������ǹ����������º��������<br>","��س� Login �����ҹ�к� �����ա��ѧ","");
	} else {
		die("New password miss math please enter again");
	}
} else{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<head>
<title>����к�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
</head>
<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >
<?PHP
	if(mysql_num_rows($result)!=1&&($_POST['new1']!='')&&($_POST['new2']!='')){ 
		?>
<META http-equiv=refresh content='3; URL=http://isag25.ce.kmitl.ac.th/~gead/user/changepassword.php'>
			<center><font color="#FF0000">�س������ʼ�ҹ���١��ͧ</font></center>
		<? ;		
		 exit;
	}
?>
<table  width="780"   border="0" cellpadding="0" cellspacing="0">
  <form method="post" action="http://isag25.ce.kmitl.ac.th/user/changepassword.php" name="changepwd" onSubmit="return check()">
    <tr> 
      <td  bgcolor="#FFFFFF"><img src="../pic/headfull.gif" width="780" height="75"> 
      </td>
    </tr>
	    <tr> 
      <td  bgcolor="#FFFFFF"><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
            <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
          </tr>
        </table> </td>
    </tr>
    <tr> 
      <td > <table width="800" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
          <tr> 
            <td > <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr > 
                  <td>&nbsp;</td>
                </tr>
                <tr > 
                  <td> <table align="center" width="63%" border="0" cellspacing="0" cellpadding="0">
                      <tr bgcolor="#9999CC"> 
                        <td height="18">&nbsp;</td>
                        <td align="center">����¹������ǹ���</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="38%" height="19" bgcolor="#F5F5DC"> <div align="right">���ʼ�ҹ���&nbsp;</div></td>
                        <td width="17%" bgcolor="#F5F5DC"> <input name="old" type="password" id="old" class="violet"></td>
                        <td width="45%" bgcolor="#F5F5DC">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td bgcolor="#F5F5DC"> <div align="right">���ʼ�ҹ����&nbsp;</div></td>
                        <td bgcolor="#F5F5DC"> <input name="new1" type="password" id="new1" class="violet"></td>
                        <td bgcolor="#F5F5DC">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td bgcolor="#F5F5DC"> <div align="right">���ʼ�ҹ����(�ա����)&nbsp;</div></td>
                        <td bgcolor="#F5F5DC"> <input name="new2" type="password" id="new2" class="violet"></td>
                        <td bgcolor="#F5F5DC">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td bgcolor="#E6E6FA">&nbsp;</td>
                        <td align="right" bgcolor="#E6E6FA"> <div align="right">&nbsp; 
                            <input type="submit" name="submit" value="  login  "  class="violet">
                          </div></td>
                        <td bgcolor="#E6E6FA">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td height="300">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                    </table></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">&nbsp; 
              Department of Computer Engineering Faculty of Engineering King Mongkut's 
              Institute of Technology<br>
              &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
          </tr>
        </table></td>
    <tr> 
      <td height="20">&nbsp;</td>
    </tr>
  </form>
</table>
</body>
</html>
<?
}
?>