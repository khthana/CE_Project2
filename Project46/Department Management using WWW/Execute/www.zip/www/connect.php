<?
    $dbName = "webce";
	MYSQL_CONNECT('localhost','gead','123qwe')
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>