<?PHP
function make_seed() {
    list($usec, $sec) = explode(' ', microtime());
    return (float) $sec + ((float) $usec * 100000);
}
function genpasswd(){
$source1="1QAZ2WSX3EDC4RFV5TGB6YHN7UJM8IK9OL0P";
$source2="p0lo9ki8mju7nhy6bgt5vfr4cde3xsw2zaq1";
//$source3="`/.,';][\=-?~>!<@".'"'."#:$}%{^|&+*_()";
$password="";
srand(make_seed());
for($i=0;$i<8;$i++){
	$select_source=rand(0,1);
	if($select_source==0){
		$password.=substr($source1,rand(0,(strlen($source1)-1)),1);
	}
	if($select_source==1){
		$password.=substr($source2,rand(0,(strlen($source2)-1)),1);
	}/*
	if($select_source==2){
		$password.=substr($source3,rand(0,(strlen($source3)-1)),1);
	}*/
}
return $password;
}
?>
