<?PHP
include "sendmail.php";
sendmail("webmaster@ce.kmitl.ac.th","webmaster@ce.kmitl.ac.th","s4015336@kmitl.ac.th","","your password","Your password is " . "123qwe",$HTML,$ATTM);
echo "finish";
?>