<?PHP 
//------------------------------------------------------------------------------//
$host="localhost";
$name="root";
$passwd="vpjk[vd.8i]jt";
$db="subject_poll";
$time=array("09.00 - 12.00","13.00 - 16.00","17.30 - 20.30");
$day=array("�ѹ���","�ѧ���","�ظ","����ʺ��","�ء��","�����","�ҷԵ��");
$teacher_id=$_POST['tid'];
$thisyear=2004;
$thisterm=1;
$thisround=1;
$link=mysql_connect($host,$name,$passwd) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
//------------------------------------------------------------------------------//
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�к����Ǩ���ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<center>
  <font size="5">�к����ͧ���ŧ����¹</font>
</center>
<form name="form1" method="post" action="admin_register_subject.php"><center>
    <table width="760" border="0">
      <tr> 
        <td colspan="4" nowrap>
            ���� - ʡ�� : <?
			if(($_POST['tid']=="" && $_GET['tid']=="") || ($_POST['tid']=="-" || $_GET['tid']=="-")){
			?><select name="tid">
			<option value="-"></option>
            <?
							$teacher_name=mysql_query("select teacher_id,teacher_name from teacher") or die(mysql_error());
							while($teacher=mysql_fetch_array($teacher_name,MYSQL_NUM)){
								?>
								<option value="<? echo $teacher[0]?>"><? echo $teacher[1]?></option>
            <?
							}
							?>
          </select><input name="view" type="submit" value="view"><?
		  }else{
		  	$tid_get=$_GET['tid'];
			$tid_post=$_POST['tid'];
		  	$teacher_name=mysql_query("select teacher_id,teacher_name from teacher where teacher_id in ('$tid_get','$tid_post')") or die(mysql_error());
			$teacher=mysql_fetch_array($teacher_name,MYSQL_NUM) or die(mysql_error());
			?><? echo $teacher[1]?><input type="hidden" name="tid" value="<? echo $teacher_id=$teacher[0]?>"><input type="submit" name="change" value="change"><?
		  }
		  ?>
          </div></td>
      </tr>
      <tr> 
        <td width="70" nowrap bgcolor="#CCCCCC"> 
          <div align="center">�ѹ\����</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">09.00 - 12.00</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">13.00 - 16.00</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">17.30 - 20.30</div></td>
      </tr>
      <?
      for($i=0;$i<7;$i++){
      ?>
      <tr> 
        <td width="70" nowrap bgcolor="#CCCCCC"> 
          <div align="center"><? echo $day[$i]?></div></td>
        <?
		for($j=0;$j<3;$j++){
		?>
        <td nowrap bgcolor="#FF99FF"> <div align="left"> 
            <?
			$subject_name=mysql_query("select  subject.code,subject.ename,teacher_subject.sroom from subject ,teacher_subject where  subject.code=teacher_subject.subject_id and teacher_subject.teacher_id='$teacher_id' and teacher_subject.day='$day[$i]' and teacher_subject.time='$time[$j]'") or die(mysql_error());
			if(mysql_num_rows($subject_name)==1){
				$subject=mysql_fetch_array($subject_name,MYSQL_NUM);
            ?>
            <input type="checkbox" name="remove<? echo ($i*3)+$j?>" value="�͹"><input type="hidden" name="<? echo "subject$i"?>" value="<? echo $subject[0]?>">
			�Ԫ� : 
            <? echo $subject[1]?><br>
			�ѡ�֡����ͧ : 
			<? echo $subject[2]?>
            <?
	    	}
			?>
          </div></td>
    	<?
		}
		?><td nowrap></div><td nowrap></td>
      </tr>
    <?
    }
    ?>
      <tr align="left" valign="top"> 
        <td colspan="4" nowrap> 
          <div align="left"> ��ͧ����Դ�Ԫ�
				<select name="subject_id">
					<option value='-'><? for($i=0;$i<112;$i++)echo "&nbsp;"?></option>
              <?
			  $subject_detail=mysql_query("select code,ename from subject order by ename asc") or die(mysql_error());	
			  while($detail=mysql_fetch_array($subject_detail,MYSQL_NUM)){
			  	?>
              <option value="<? echo "$detail[0]" ?>"><? echo $detail[1]?> 
              <?
			  }
			  ?>
            </select><br>
			����Ѻ�Ԫ�����<br>
			�����Ԫ� <input type="text" name="new_subject_id" size="10" maxlength="10"> 
			�����Ԫ� <input type="text" name="new_subject_name" size="17" maxlength="100">
			�дѺ����֡�� <select name="new_subject_degree">
									<option value="��ԭ�ҵ��">��ԭ�ҵ��</option>
									<option value="��ԭ���">��ԭ���</option>
									<option value="��ԭ���͡">��ԭ���͡</option>
								</select><br>
			  ��ͧ����͹ �ѹ 
              <select name="subject_day">
              <option value="�ѹ���">�ѹ���</option>
              <option value="�ѧ���">�ѧ���</option>
              <option value="�ظ">�ظ</option>
              <option value="����ʺ��">����ʺ��</option>
              <option value="�ء��">�ء��</option>
              <option value="�����">�����</option>
              <option value="�ҷԵ��">�ҷԵ��</option>
            </select>
              ���� 
              <select name="subject_time">
              <option value="09.00 - 12.00">09.00 - 12.00</option>
              <option value="13.00 - 16.00">13.00 - 16.00</option>
              <option value="17.30 - 20.30">17.30 - 20.30</option>
            </select>
              ������ѡ�֡�� 
              <select name="subject_sroom">
               <option value="1D">1D</option>
               <option value="2D">2D</option>
               <option value="3D">3D</option>
               <option value="4D">4D</option>
               <option value="1P">1P</option>
               <option value="2P">2P</option>
               <option value="3P">3P</option>
               <option value="1D1">1D1</option>
               <option value="1D2">1D2</option>
               <option value="2D1">2D1</option>
               <option value="2D2">2D2</option>
               <option value="3D1">3D1</option>
               <option value="3D2">3D2</option>
               <option value="4D1">4D1</option>
               <option value="4D2">4D2</option>
            </select>
            <input type="submit" name="register" value="�����Ԫ�"><br>
            ��������´�������<br>
            <textarea name="new_subject" cols="50" rows="3"></textarea>
          </div></td>
      </tr>
      <tr> 
        <td colspan="4" nowrap><div align="left"></div>
          </td>
      </tr>
    </table>
    </center>
</form>
</body>
</html>
<?
?>
