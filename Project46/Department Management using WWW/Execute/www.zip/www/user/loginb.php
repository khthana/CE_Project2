<?
include "checkip.php";
session_start();
if(session_is_registered('name')){
	die("You alredy login");
}
if($_POST['username']=='' && $_POST['password']=='' ){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="JavaScript" src="md5.js" type="text/JavaScript"></script>
</head>

<body>
<br>
<br>
<form name="form1" method="post" action="login.php"><center>
    <table width="35%" border="0" bordercolor="#F99F3E" bgcolor="#99FFFF">
      <tr bgcolor="#CCCCCC"> 
        <td colspan="2"><div align="center"><strong>Login</strong></div></td>
      </tr>
      <tr>
        <td>Username</td>
        <td><input type="text" name="username" id="username"></td>
      </tr>
      <tr> 
        <td>Password</td>
        <td><input type="text" name="password">
				<input type="hidden" name="hash" value=""></td>
      </tr>
      <tr> 
        <td> <div align="right"> <font size="2">&nbsp; </font></div></td>
        <td> <div align="left">
            <input name="login" type="submit" id="login" value="Login" onClick="document.all.hash.value=hex_md5(document.all.password.value)">
            <input name="reset" type="reset" id="reset" value="Reset"><br>
            <font size="2" >
				<a href="../index.php">˹���á</a>&nbsp;&nbsp;
				<a href="" target="_self" onClick="var s='?username='+document.all.username.value;this.href='http://isag25.ce.kmitl.ac.th/~best/test/user/forget_password.php'+s">������ʼ�ҹ</a>
			</font></div></td>
      </tr>
    </table>
</center>
</form>
</body>
</html>
<?
}else{
	$username=$_POST['username'];
	$password=$_POST['password'];//$_POST['hash'];
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	$sql = "SELECT useraccount.username, useraccount.email, accesslevel.memberof, accesslevel.level, useraccount.sid, useraccount.pid' . ' FROM useraccount, accesslevel" . " WHERE useraccount.password=md5('$password.$username') and useraccount.username='$username' and useraccount.memberof=accesslevel.id"; 
	$result=mysql_query($sql) or die(mysql_error());
	if(mysql_num_rows($result)==1){
		$row=mysql_fetch_array($result,MYSQL_NUM);
		session_register('time');
		$time=date("YmdHis");
		session_register('ip');
		$ip=checkip();
		session_register('name');
		$name=$row[0];
		session_register('email');
		$email=$row[1];
		session_register('memberof');
		$memberof=$row[2];
		session_register('accesslevel');
		$accesslevel=$row[3];
		if($row[4]!=null){
			session_register('sid');
			$sid=$row[4];
			$sql = "SELECT name,room"
		    . " FROM student"
			. " WHERE sid = '$sid' ";
			$result=mysql_query($sql) or die(mysql_error);
			$row=mysql_fetch_array($result,MYSQL_NUM); 
			if(mysql_num_rows($result)==1){
				session_register('realname');
				$realname=$row[0];
				session_register('sroom');
				$sroom=$row[1];
				header("location:../webboard/");
			}else{
				session_destroy();
				header("location:../webboard/");
			}
		}
		if($row[5]!=null){
			session_register('pid');
			$pid=$row[5];
			$sql = "SELECT name,position,teaching"
		    . " FROM personal_detail"
			. " WHERE id = '$pid' ";
			$result=mysql_query($sql) or die(mysql_error);
			echo mysql_num_rows($result);
			$row=mysql_fetch_array($result,MYSQL_NUM); 
			if(mysql_num_rows($result)==1){
				session_register('realname');
				$realname=$row[0];
				session_register('position');
				$sroom=$row[1];
				session_register('teaching');
				$sroom=$row[2];
				header("location:../webboard/");
			}else{
				session_destroy();
				header("location:../webboard/");
			}
		}
		echo "
�Թ�յ�͹�Ѻ�س : $name<br>
�س����Ҫԡ������ : $memberof<br>
ip �ͧ�س��� : $ip";
		print "<META http-equiv=refresh content='2; URL=../webboard/'>";
	}else{
		session_destroy();
		echo "$password<br>�س��� Username  ���� Password ���١��ͧ";
		print "<META http-equiv=refresh content='2; URL=login.php'>";
		exit;
		//header("location:http://isag25.ce.kmitl.ac.th/~best/test/");
	}
}
?>
