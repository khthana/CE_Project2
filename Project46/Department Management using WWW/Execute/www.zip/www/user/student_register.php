<?
$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db("webce",$link);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body>
<form name="form1" method="post" action="">
  <div align="center">
    <p><font size="3"><strong>ŧ����¹���ҹ����Ѻ�ѡ�֡��</strong></font> </p>
  </div>
  <table width="100%" border="0">
    <tr> 
      <td width="13%">User name</td>
      <td width="87%"><input name="username" type="text" id="username" size="20" maxlength="255"></td>
    </tr>
    <tr> 
      <td>E-mail</td>
      <td><input name="email" type="text" id="email" size="50" maxlength="255"></td>
    </tr>
    <tr> 
      <td>���ʹѡ�֡��</td>
      <td><input name="sid" type="text" id="sid" size="8" maxlength="8"></td>
    </tr>
    <tr> 
      <td>���� - ʡ��</td>
      <td><input name="name" type="text" id="name" size="50" maxlength="255"></td>
    </tr>
    <tr> 
      <td>SMS</td>
      <td><input name="sms" type="text" id="sms" size="11" maxlength="11"></td>
    </tr>
    <tr> 
      <td>ICQ</td>
      <td><input name="icq" type="text" id="icq" size="11" maxlength="11"></td>
    </tr>
    <tr> 
      <td>MSN</td>
      <td><input name="msn" type="text" id="msn" size="50" maxlength="255"></td>
    </tr>
    <tr> 
      <td>�Ӷ��</td>
      <td><input name="question" type="text" id="question" size="50" maxlength="255"></td>
    </tr>
    <tr> 
      <td>�ӵͺ</td>
      <td><input name="answer" type="text" id="answer" size="50" maxlength="255"></td>
    </tr>
  </table><br>
  &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp;  &nbsp;  &nbsp;  &nbsp; &nbsp; 
  <input type="submit" value="ŧ����¹"  name="register">
  <input type="reset" name="reset" value="���������">
</form>
</body>
</html>
<?
?>