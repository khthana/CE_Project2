<?PHP
//----------------------------------------------------------------//
$host="localhost";
$name="root";
$passwd="vpjk[vd.8i]jt";
$db="subject_poll";
$teacher_id=$_POST['tid'];
$day=$_POST['subject_day'];
$time=$_POST['subject_time'];
$sroom=$_POST['subject_sroom'];
$subject_id=$_POST['subject_id'];
$thisyear="2004";
$thisterm="1";
$link=mysql_connect($host,$name,$passwd) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
//---------------------------------------------------------------//
if($teacher_id=='' && $_POST['view']=='view'){
		?>
		<center><font size="+3" color="red">��س����͡���� - ʡ��</font></center>
		<meta http-equiv="refresh" content="0;URL=teacher.php">
		<?
		exit;
}
//---------------- remove select subject -----------------------//
for($i=0;$i<21;$i++){
	if($_POST["remove".$i]=="�͹"){
		$subject_id=$_POST["subject".$i];
		$remove=mysql_query("delete from teacher_subject where `subject_id`='$subject_id' and `teacher_id`='$teacher_id' and `year`='$thisyear' and `term`='$thisterm'") or die(mysql_error());
		mysql_close($link);
	}
}
//--------------- register new subject ---------------------------//
if($_
//--------------- change subject name ----------------------------//
//--------------- register subject -------------------------------//
if($_POST['register']=="�����Ԫ�" && $subject_id!=""){
	$count_subject=mysql_query("select * from  `teacher_subject` where `teacher_id`='$teacher_id' and `year`='$thisyear' and `term`='$thisterm'") or die(mysql_error());
	if(mysql_num_rows($count_subject)<=21){
		$freetime=mysql_query("select * from teacher_subject where teacher_id='$teacher_id' and `year`='$this_year' and `term`='$thisterm' and `day`='$day' and `time`='$time'") or die(mysql_error());
		if(mysql_num_rows($freetime)==0){
		$register_subject=mysql_query("insert into teacher_subject (`teacher_id`,`subject_id`,`year`,`term`,`day`,`time`,`sroom`) values ('$teacher_id','$subject_id','$thisyear','$thisterm','$day','$time','$sroom')") or die(mysql_error());
			?>
			<center><font size="+3">���ѧ�ӡ�û����ż�</font></center>
			<meta http-equiv="refresh" content="URL=admin_subject.php?tid=<? echo $teacher_id?>">
			<?
			exit;
		}else{
		?>
		<center><font size="+3">�������öŧ����¹�� ���ͧ�ҡ�س�����ҧ����Ҵѧ�����</font></center>
		</center><meta http-equiv="refresh" content="URL=admin_subject.php?tid=<? echo $teacher_id?>">
		<?
		exit;
		}
	}else{
		?>
		<center><font size="+3">�������öŧ����¹�� ���ͧ�ҡ�س�����������ҧ�ա����</font></center>
		</center><meta http-equiv="refresh" content="URL=admin_subject.php?tid=<? echo $teacher_id?>">
		<?
		exit;
	}
}

if($_POST['finish']=="Finish"){
	$lock_register=mysql_query("update `student_subject` set `lock`='locked' where student_id='$tid' and year='$thisyear' and term='$thisterm'") or die(mysql_error());
			?>
			<center><font size="+3">���ѧ�ӡ�û����ż�</font></center>
			<meta http-equiv="refresh" content="URL=admin_subject.php?tid=<? echo $teacher_id?>">
			<?
			exit;
}
if($_POST['change']=="change"){
			?>
			<center><font size="+3">�ӡ������¹�������Ҩ����</font></center>
			<meta http-equiv="refresh" content="URL=admin_subject.php">
			<?
			exit;
}
			?>
			<center><font size="+3">���ѧ�ӡ�û����ż�</font></center>
			<meta http-equiv="refresh" content="URL=admin_subject.php?tid=<? echo $teacher_id?>">
			<?
			exit;
?>
