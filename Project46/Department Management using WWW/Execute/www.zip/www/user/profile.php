<?
include "checkip.php";
include "logout.php";
include "notice.php";
session_start();

if( !( $ip_addr == checkip() && session_is_registered('memberof') && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ) ){
	session_destroy();			
	notice("red","�س�ѧ�����ӡ�� login �������к�<br>��س� loging ����к���͹��Ѻ","<a href='http://isag25.ce.kmitl.ac.th/~gead/'>[ login ]</a>");
	exit;
}
	$linkdb=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$linkdb) or die(mysql_error());
	$sql = "select * from useraccount where username = '$name' ";
	$resutl = mysql_query( $sql );
	$row = mysql_fetch_array( $resutl );
	 $username = $row['username'];
	 $emain = $row['email'];
	 $icq = $row['icq'];
	 $sms = $row['sms'];
	 $question = $row['question'];


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>��䢢�������ǹ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
</head>
<form action="update_profile.php" method="post">
<body  leftmargin="0" topmargin="0" >
<table width="770" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td><img src="../pic/cekmitl.gif" width="300" height="50"></td>
  </tr>
  <tr> 
    <td>&nbsp;
      <?
				  if (!empty($name)){
						echo "> $name |  " ;
						if($memberof == '1'){echo "�ؤ�ŷ����";}; 
						if($memberof == '2'){echo $sroom;}; 
						if($memberof=='3'){echo "�ؤ�ҡ�";}						
					}
			
	?>
    </td>
  </tr>
  <tr> 
    <td height="400" align="center" valign="top" nowrap ><table width="760" border="0">
        <tr bgcolor="#9999CC"> 
          <td colspan="3"> <div align="center"><font size="3"><strong>��������ǹ��� 
              </strong></font></div></td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td width="17%"><font color="<? if($username==''){echo "#FF0000";}else{echo "#000000";} ?>">Username 
            </font></td>
          <td width="45%">&nbsp; <? echo $username ?></td>
          <td width="38%">������Ѻ Login �����ҹ�к�</td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td><font color="<? if($username==''){echo "#FF0000";}else{echo "#000000";} ?>">E-mail *</font></td>
          <td> <input name="email" type="text" id="email" size="50" value="<? echo $email ?>"></td>
          <td>����Ѻ�Ѻ���ǻ�С�� ��Т����������</td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td>ICQ</td>
          <td> <input name="icq" type="text" id="icq" value="<? echo $icq ?>" size="10" maxlength="10"></td>
          <td>����Ѻ�Ѻ���ǻ�С�� ��Т����������</td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td>SMS</td>
          <td> <input name="sms" type="text" id="sms" value="<? echo $sms ?>" size="10" maxlength="10"></td>
          <td>����Ѻ�Ѻ���ǻ�С�� ��Т����������</td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td><font color="<? if($question==''){echo "#FF0000";}else{echo "#000000";} ?>">�Ӷ�� 
            * </font></td>
          <td> <input name="question" type="text" id="question" size="50" value="<? echo $question ?>"></td>
          <td>�ҡ������ʼ�ҹ</td>
        </tr>
        <tr bgcolor="#F5F5DC"> 
          <td><font color="<? if($answer==''){echo "#FF0000";}else{echo "#000000";} ?>">�ӵͺ 
            * </font></td>
          <td> <input name="answer" type="text" id="answer" size="50" value=""></td>
          <td>�ҡ������ʼ�ҹ</td>
        </tr>
        <tr bgcolor="#E6E6FA"> 
          <td>&nbsp;</td>
          <td> <input name="register" type="submit" id="update_info" value="��䢢�����">
          </td>
          <td>&nbsp;</td>
        </tr>
      </table></td>
  </tr>
    <tr >
      <td height="60"  background="../pic/b.jpg"><font  color="#000099" size="-2"  class="violet">&nbsp; 
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<br>
        &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font> </td>
    </tr>
</table>

</body>
</html>
