<?PHP
include "checkip.php";
include "logout.php";
include "notice.php";
session_start();

if( !( $ip_addr == checkip() && session_is_registered('memberof') && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ) ){
	session_destroy();			
	notice("red","�س�ѧ�����ӡ�� login �������к�<br>��س� loging ����к���͹��Ѻ","<a href='http://isag25.ce.kmitl.ac.th/~gead/'>[ login ]</a>");
	exit;
}

$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
mysql_select_db('webce') or die(mysql_error());
$password=$_POST['old'];
$result=mysql_query("select username from useraccount where username='$name' and password=md5('$password.$name')") or die(mysql_error());
if(mysql_num_rows($result)==1&&($_POST['new1']!='')&&($_POST['new2']!='')){
			if($_POST['new1']==$_POST['new2']){
				$password=$_POST['new1'];
				$result=mysql_query("update useraccount set password=md5('$password.$name') where username='$name'") or die(mysql_error());
				logout();
				
				notice("green","Changed your password<br>please login again","<a href='http://isag25.ce.kmitl.ac.th/~gead/'>[ login ]</a>");
				exit;
			} else {
				notice("red","not match !!! �س������ʼ�ҹ�����������͹�ѹ","<a href='http://isag25.ce.kmitl.ac.th/~gead/user/changepassword.php'>[ change ]</a>");
		   		exit;
				}
} else{

	if(mysql_num_rows($result)!=1&&($_POST['new1']!='')&&($_POST['new2']!='')){ 
		notice("red","not correct �س������ʼ�ҹ���١��ͧ","<a href='http://isag25.ce.kmitl.ac.th/~gead/user/changepassword.php'>[ change ]</a>");
		exit;	
	}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>change password</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="../include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

</head>
<form name="form1" method="post" action="http://isag25.ce.kmitl.ac.th/~gead/user/changepassword.php">

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('../pic/b_subject_over.gif','../pic/b_officer_over.gif','../pic/b_oldstudent_over.gif','../pic/b_webboard_over.gif','../pic/b_newstudent_over.gif','../pic/b_faq_over.gif')" >

<table  width="780"   border="0" cellpadding="0" cellspacing="0"  valign="top" nowrap>
  <tr> 
    <td width="780"  height="75" valign="top" nowrap >
	<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="../pic/headce_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		    <TD> <img src="../pic/headce_02.gif" width=170 height=33 alt=""></TD>
		<TD>
			<IMG SRC="../pic/headce_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="../pic/headce_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		<TD class="linebottom">
			<IMG SRC="../pic/headce_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/headce_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/headce_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="../pic/headce_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE>
	</td>
  </tr>
  <tr>
    <td  valign="top" nowrap><table width="780" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','../pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
          <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/%7Egead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','../pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','../pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image4','','../pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
          <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','../pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
          <td width="180"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','../pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="../pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td  bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr> 
    <td  valign="top" nowrap> <table width="780" border="0" cellspacing="0" cellpadding="0"  bgcolor="#FFFFFF">
        <tr> 
          <td height="400"  valign="top" align="center">

    <table width="39%" border="0" >
      <tr> 
        <td colspan="2" bgcolor="#9999CC" ><div align="center"><font size="4"><strong>change 
                    password</strong></font></div></td>
      </tr>
      <tr> 
        <td width="54%" bgcolor="#F5F5DC">���ʼ�ҹ���</td>
        <td width="46%" bgcolor="#F5F5DC"><input name="old" type="password" id="old"></td>
      </tr>
      <tr> 
        <td bgcolor="#F5F5DC">���ʼ�ҹ����</td>
        <td bgcolor="#F5F5DC"><input name="new1" type="password" id="new1"></td>
      </tr>
      <tr> 
        <td bgcolor="#F5F5DC">���ʼ�ҹ����(�ա����)</td>
        <td bgcolor="#F5F5DC"><input name="new2" type="password" id="new2"></td>
      </tr>
      <tr> 
        <td colspan="2" bgcolor="#E6E6FA"><div align="center"> 
            <input name="change" type="submit" id="change" value="����¹">
            <input type="reset" name="Reset" value="���������">
          </div></td>
      </tr>
    </table>
</td>
        </tr>
        <tr> 
          <td  height="60"  background="../pic/b.jpg"> <font  color="#000099" size="-2"  class="violet">Department 
            of Computer Engineering Faculty of Engineering King Mongkut's Institute 
            of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th </font></td>
        </tr>
      </table></td>
  <tr> 
    <td height="10">&nbsp;</td>
  </tr>
</table>
</body></form>
</html>
<?
}
?>
