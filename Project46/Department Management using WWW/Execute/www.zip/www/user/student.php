<?PHP 
//------------------------------------------------------------------------------//
$host="localhost";
$name="root";
$passwd="vpjk[vd.8i]jt";
$db="subject_poll";
$time=array("09.00 - 12.00","13.00 - 16.00","17.30 - 20.30");
$day=array("�ѹ���","�ѧ���","�ظ","����ʺ��","�ء��","�����","�ҷԵ��");
$thisyear="2004";
$thisterm="1";
if($_GET['sid']!='' && $_POST['sid']==''){
	$student_id=$_GET['sid'];
}else{
	$student_id=$_POST['sid'];
}
if($_GET['sid']!='' && $_POST['sid']==''){
	$sroom=$_GET['sroom'];
}else{
	$sroom=$_POST['sroom'];
}

$link=mysql_connect($host,$name,$passwd) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
//------------------------------------------------------------------------------//
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>�к����Ǩ���ŧ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<center>
  <font size="5">�к����ͧ���ŧ����¹</font>
</center>
<form name="form1" method="post" action="student_register_subject.php"><center>
    <table width="760" border="0">
      <tr> 
        <td colspan="4" nowrap><div align="left"> ���ʻ�Шӵ�ǹѡ�֡�� : <?
		if($student_id!='' && ($sroom!='-' && $sroom!='')){
			?><? echo $student_id ?> <input  type="hidden" name="sid" value="<? echo $student_id ?>" ><input type="submit" name="change" value="change"><?
		}else{
		?>
		<input type="text" name="sid" value="<? echo $sid?>"><input type="submit" name="view" value="view">
		<?
		}
		?><!--<?// echo $_SESSION['sid']?>--><br>
            ���� - ʡ�� : <? echo $_SESSION['name']?><br>
            ��ͧ : <?
					 if($sroom=='' || $sroom=='-'){
					?>
					<select name="sroom">
						<option value="-"></option>
						<option value="1D">1D</option>
						<option value="2D">2D</option>
						<option value="3D">3D</option>
						<option value="4D">4D</option>
						<option value="1P">1P</option>
						<option value="2P">2P</option>
						<option value="3P">3P</option>
					  </select>
					  <?
					  }else{
					  	?><? echo $sroom?><input type="hidden" name="sroom" value="<? echo $sroom?>"><?
					  }
					  ?>
					  <br>
            ��鹻շ�� : <? echo $_SESSION['year']?><br>
          </div></td>
      </tr>
      <tr> 
        <td width="70" nowrap bgcolor="#CCCCCC">
<div align="center">�ѹ\����</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">09.00 - 12.00</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">13.00 - 16.00</div></td>
        <td width="30%" nowrap bgcolor="#FF6600"><div align="center">17.30 - 20.30</div></td>
      </tr>
      <?
      for($i=0;$i<7;$i++){
      ?>
      <tr> 
        <td width="70" nowrap bgcolor="#CCCCCC">
<div align="center"><? echo $day[$i]?></div></td>
        <?
		for($j=0;$j<3;$j++){
		?>
        <td nowrap bgcolor="#FF99FF"> <div align="left"> 
        	<?
			$subject_name=mysql_query("select  subject.ename,subject.code,teacher.teacher_name,student_subject.lock 
													   from subject ,student_subject,teacher_subject,teacher 
													   where  subject.code=student_subject.subject_id and 
													   			  student_subject.teacher_id=teacher_subject.teacher_id and 
																  teacher_subject.day='$day[$i]' and teacher_subject.time='$time[$j]' and 
																  student_subject.day='$day[$i]' and student_subject.time='$time[$j]' and 
																  teacher.teacher_id=student_subject.teacher_id and 
																  student_subject.student_id='$student_id'") or die(mysql_error());
			if(mysql_num_rows($subject_name)==1){
			$subject=mysql_fetch_array($subject_name,MYSQL_NUM);
				if($subject[3]!="locked"){
					?><input type="checkbox" name="remove<? echo ($i*3)+$j?>" value="�͹"><input type="hidden" name="<? echo "subject".(($i*3)+$j)?>" value="<? echo $subject[1]?>"><?
				}
			?>
             �Ԫ�  : <? echo $subject[0]?> <br>
			 �Ҩ���� : <? echo $subject[2]."<br>" ?>
			 <?
	 		}
	    	?>
          </div></td>
        	<?
	}
	?><td nowrap></div><td nowrap></td>
      </tr>
      <?
      }
      ?>
      <tr> 
        <?
		$query_subject_detail="select subject.code,subject.ename,teacher.teacher_id,teacher_subject.day,teacher_subject.time,teacher.teacher_name 
										  from subject,teacher_subject,teacher
										  where subject.code=teacher_subject.subject_id and 
										  			teacher_subject.status!='close' and 
										  			teacher_subject.sroom='$sroom' and 
										  		    teacher_subject.year='$thisyear' and 
													teacher_subject.term='$thisterm' and
													teacher.teacher_id=teacher_subject.teacher_id ";
		$selected_subject=mysql_query("select subject_id 
													   from student_subject 
													   where `year`='$thisyear' and 
													   				  student_subject.student_id='$student_id' and 
													   			 term='$thisterm'") or die(mysql_error());
		while($selected=mysql_fetch_array($selected_subject,MYSQL_NUM)){
			$query_subject_detail .=  " and subject .code <> '".$selected[0]."'  ";
		}
		$nonfreetime=mysql_query("select  day,time from student_subject where year='$thisyear' and term='$thisterm' and student_id='$student_id'") or die(mysql_error());
		$all_nonfree=mysql_num_rows($nonfreetime);
		while($nonfree=mysql_fetch_array($nonfreetime,MYSQL_NUM)){
			$query_subject_detail .= " and (`day` <> '".$nonfree[0]."' or `time` <> '".$nonfree[1]."')";
		}
      	$subject_detail=mysql_query($query_subject_detail." order by subject.ename asc") or die(mysql_error());	
	?>
        <td colspan="4" nowrap><div align="left">���͡�Ԫ� 
            <select name="select_register">
              <option value="-"></option>
			  <?
			  while($detail=mysql_fetch_array($subject_detail,MYSQL_NUM)){
			  	?><option value="<? echo "$detail[0];$detail[2];$detail[3];$detail[4]";?>"><? echo "<table width="100%" border="0">
            <tr>
              <td>$detail[1]</td>
              <td>�Ҩ���� : $detail[5]</td>
              <td>�ѹ : $detail[3]</td>
              <td>���� : $detail[4]</td>
            </tr>
          </table>"?><?
			  }
			  ?>
            </select>
            <input type="submit" name="register" value="�����Ԫ�">
            <input name="delete" type="submit" id="delete" value="�͹�Ԫ�">
          </div></td>
      </tr>
      <tr> 
        <td colspan="4" nowrap><div align="left">���� �ѹ 
            <select name="select2">
              <option value="-"></option>
              <option value="�ѹ���">�ѹ���</option>
              <option value="�ѧ���">�ѧ���</option>
              <option value="�ظ">�ظ</option>
              <option value="����ʺ��">����ʺ��</option>
              <option value="�ء��">�ء��</option>
              <option value="�����">�����</option>
              <option value="�ҷԵ��">�ҷԵ��</option>
            </select>
            ���� 
            <select name="select3">
              <option value="-"></option>
              <option value="09.00 - 12.00">09.00 - 12.00</option>
              <option value="13.00 - 16.00">13.00 - 16.00</option>
              <option value="17.30 - 20.30">17.30 - 20.30</option>
            </select>
            �Ҩ���� 
            <select name="select4">
              <option value="-"></option>
            </select>
            <input type="submit" name="Submit3" value="����">
          </div>
          <div align="left"></div>
          <div align="left"></div></td>
      </tr>
      <tr > 
        <td colspan="4" nowrap>
			��ͧ���Դ�Ԫ������Ԫ� 
			<select name="new_subject">
              <option value="-"></option>
			</select>
		</td>
      </tr>
      <tr > 
        <td colspan="4" nowrap> <div align="center">
            <input type="submit" name="finish" value="Finish">
          </div></td>
	  </tr>
	  <tr>
        <td colspan="4" nowrap>
			<strong>�����˵� </strong>

          <br>
			<dd>
            <li>�ҡ<font color="red">����ͧ���ŧ����¹�Ԫ�����ա����</font>��سҡ����� 
              <strong>Finish</strong>
			<dd>
            <li>�ҡ��ͧ��ö͹�Ԫ�������͡� checkbox �ͧ����Ԫҹ������ǡ� <strong>�͹�Ԫ�</strong></li>
			<dd>
            <li>�ҡ��<strong>�Ԫ�㴷������㹵��ҧŧ����¹</strong> ��ѧ�ҡ�� 
              <strong>Finish</strong> ������Ԫ�����ҹ�鹨��������ö <strong>�͹</strong> 
              �͡���ա
		</td>
      </tr>
    </table>
    </center>
</form>
</body>
</html>
<?
?>
