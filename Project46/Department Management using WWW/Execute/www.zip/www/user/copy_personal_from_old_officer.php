<?PHP
//-------------------------------------//
$host="localhost";
$name="admin";
$passwd="admin";
$db="webce";
$query_old_detail="select `id`,`name`,`email`,`level` from `officer` where `level`!='' order by `id`";
//-------------------------------------//
$link=mysql_connect($host,$name,$passwd) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
$old_detail=mysql_query($query_old_detail,$link) or die(mysql_error());
while($old=mysql_fetch_array($old_detail,MYSQL_NUM)){
	echo "$old[0] $old[1] $old[2] $old[3]<br>";
	$insert=mysql_query("insert into personal_detail (`id`,`name`,`email`,`position`) values ('$old[0]','$old[1]','$old[2]','$old[3]')") or die(mysql_error());
}
?>