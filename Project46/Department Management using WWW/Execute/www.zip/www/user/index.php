<?
?>
<meta http-equiv="refesh" content="0;login.php">
<?
?>
