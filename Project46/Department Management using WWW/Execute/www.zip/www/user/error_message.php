<?PHP
function error_message($error){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Error</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body>
<center>
<table width="300" height="60" border="0" bgcolor="#66FFFF">
  <tr>
      <td height="27" bgcolor="#FF0000"><div align="center"><strong>�������Դ��Ҵ�ͧ������</strong></div></td>
  </tr>
  <tr>
    <td height="27"><br><center><? echo $error ?></center><br></td>
  </tr>
</table>
</center>
</body>
</html>
<?
}
?>