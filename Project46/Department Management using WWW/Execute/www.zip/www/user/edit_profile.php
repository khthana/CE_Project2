<?PHP
session_start();
if($_SESSION['name']==''){
	include "error_message.php";
	error_message("��ҹ�ѧ�����ӡ�� Login ����к�<br>��س� Loging ����к���͹");
    ?><META http-equiv=refresh content='1; URL=http://isag25.ce.kmitl.ac.th/~best/test/user/login.php'><?
	exit;
}
$username=$_SESSION['name'];
if($_SESSION['memberof']=='1'){
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce") or die(mysql_error());
	$user_detail=mysql_query("select username,email,question,answer from useraccount where username='$username'") or die(mysql_error());
	if(mysql_num_rows($user_detail)!=1){
		session_destroy();
		include "error_message.php";
		error_message("�����Ţͧ��ҹ�Դ��Ҵ ��س� Login �����ա����");
    	?><META http-equiv=refresh content='1; URL=http://isag25.ce.kmitl.ac.th/~best/test/'><?
		exit;
	}
	$detail=mysql_fetch_array($user_detail,MYSQL_NUM) or die(mysql_error());
	$email=$detail[1];
	$question=$detail[2];
	$answer=$detail[3];
	if($username=='' || $email=='' || $question=='' || $answer==''){
		include "error_message.php";
		error_message("�����Ţͧ��ҹ�Դ��Ҵ<br>��سҵԴ��� <a href=error_report.php>webmaster@ce.kmitl.ac.th</a><br><a href=161.246.5.25/~best/test/>Home</a>");
		exit;
	}
	if($_POST['update']==''){
		$email=$detail[1];
		$question=$detail[2];
		$answer=$detail[3];
		$update='';
	}else{
		$email=$_POST['email'];
		$question=$_POST['question'];
		$answer=$_POST['answer'];
		$update=$_POST['update'];
	}
	include "function_edit_profile_public_user.php";
	edit_profile_public_user($username,$email,$question,$answer,$update);
	exit;
}
?>
