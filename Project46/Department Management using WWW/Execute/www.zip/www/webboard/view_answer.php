<?php
	session_start();
	include ("checkip.php");
	include("webboard.inc");
	include("../function.php");
	
	session_register("url_page");
	$url_page = "http://isag25.ce.kmitl.ac.th/~gead/webboard/form_answer.php?q_id=$q_id";							 			
	session_register("login");
	$login[del]=$q_id;
		
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql = "select * from webboardquestion where q_id = '$q_id'";	
	$db_query = mysql_db_query ($dbname, $sql);
	$row = mysql_fetch_array($db_query);	
	if( $row['q_show'] == 'private')	{		
			if( $ip_addr ==checkip() && $memberof > 1 && session_is_registered('memberof') && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ){
				
			}else{
				echo Message(35,"red","�س������Է�����������ǹ���","","");			
				exit();
			}
	}		
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
<?php
	$db_query = mysql_db_query ($dbname, $sql);
	$nums_rows = mysql_num_rows($db_query);
	if ($nums_rows < 1 )
		{
			echo ("<font color=\"red\">����բ������ʴ�</font>");
			exit;
		}	// �� if
?>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760">
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="770" border="0" cellpadding="0" cellspacing="0">
          <tr> 
            <td> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0">	
                <tr> 
                  <td width="48%"> 
                    <div align="left"> <?php print "<a href='form_answer.php?q_id=$q_id'>"; ?><img src="image/t_reply.gif" border="0"> <?php print "</a>"; ?></div>
                  </td>
                  <td width="52%"> 
                    <div align="right"><img src="image/ce-kmitl.gif" border="0"></div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td> 

<?php
	for ($i=0;$i<$nums_rows;$i++){
			$result = mysql_fetch_array($db_query);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_message = $result[q_message];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_icq = $result[q_icq];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];

			$q_id = stripslashes($q_id);
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_update = stripslashes($q_update);
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
}	
				// select level user					
					$sql = "select * from useraccount where username = '$q_name'";
					$result  = mysql_query( $sql );
					$row = mysql_fetch_array( $result ) or die ( mysql_error() );
					$member_level = $row['memberof'];
					if( $member_level =='1') $level_person = $level1;
					if( $member_level =='2') $level_person = $level2;
					if( $member_level =='3') $level_person = $level3;
				// ecd select level user

	print "<table border=0  width=100% cellspacing=1 cellpadding=4   align=center>";
	print "<tr>";
	print "<td bgcolor=$bgt4 width=20%><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Author</font></td>";
	print "<td bgcolor=$bgt4><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></td>";
	print "</tr>";
	
	print "<tr>";
	print "<td bgcolor=$bgt1 width=20% valign='top'>";
	print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
    print "<tr><td>";
	print "<a href='mail.php'><img src='image/mail.gif' ' border='0'></a>";
	print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$q_name</b></font>";
    print "</td></tr><tr>";
    print " <td>&nbsp;</td>";
    print "</tr></table>";
	print "</td>";
	print "<td bgcolor=$bgt1>";
	print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
    print "<tr><td>";
	print "<IMG SRC=$post align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> Posted : $q_date:$q_time</font><hr>";
    print "</td></tr><tr>";
    print " <td>";
	print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_message</font></td></tr><tr><td align='right'>";
	print "<IMG SRC=$level_person  alt=$q_name $align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $q_ip</font>";
    print "</td></tr></table>";
	print "</td>";
	print "</tr>";


	$sql1 = "select * from webboardanswer where a_qid = '$q_id' order by a_id asc";
	$db_query1 = mysql_db_query ($dbname, $sql1);
	if (!$db_query1)
		{
			echo ("��硫Ԥ�ǵ����� SQL �����");
			exit;
		}	// end if

	$num_rows1 = mysql_num_rows($db_query1);
	if ($num_rows1 != 0 )
		{
			for ($i=0;$i<$num_rows1;$i++)	// �Ѻ��Ң����Ũҡ��Ŵ��ҧ � 㹵��ҧ webboardanswer
			{
				$result1 = mysql_fetch_array($db_query1);
				$a_message = $result1[a_message];
				$a_email = $result1[a_email];
				$a_name = $result1[a_name];
				$a_date = $result1[a_datetime];
				$a_icq = $result1[a_icq];
				$a_ip = $result1[a_ip];

				$a_name = stripslashes($a_name);
				$a_email = stripslashes($a_email);
				$a_ip = stripslashes($a_ip);
				$a_date = stripslashes($a_date);
				$a_icq = stripslashes($a_icq);
				// select level user					
					$sql = "select * from useraccount where username = '$a_name'";
					$result  = mysql_query( $sql ) ;
					$row = mysql_fetch_array( $result ) or die ( mysql_error() );
					$member_level = $row['memberof'];
					if( $member_level =='1') $level_person = $level1;
					if( $member_level =='2') $level_person = $level2;
					if( $member_level =='3') $level_person = $level3;
				// ecd select level user	
				$set_color=$i%2;
				if ($set_color!=0){
					print "<tr>";
					print "<td bgcolor=$bgt3 width=20% valign='top'>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<a href='mail.php'><img src='image/mail.gif' ' border='0'></a>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$a_name</b></font>";
				    print "</td></tr><tr>";
				    print " <td>&nbsp;</td>";
				    print "</tr></table>";
					print "</td>";
					print "<td bgcolor=$bgt3>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<IMG SRC=$post1 align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> Posted:$a_date</font><hr>";
				    print "</td></tr><tr>";
				    print " <td>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_message</font></td></tr><tr><td align='right'>";
					print "<IMG SRC=$level_person alt=$a_name align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $a_ip</font>";
				    print "</td></tr></table>";
					print "</td>";
					print "</tr>";
				}
				else{
					print "<tr>";
					print "<td bgcolor=$bgt2 width=20% valign='top'>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<a href='mail.php'><img src='image/mail.gif' ' border='0'></a>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$a_name</b></font>";
				    print "</td></tr><tr>";
				    print " <td>&nbsp;</td>";
				    print "</tr></table>";
					print "</td>";
					print "<td bgcolor=$bgt2>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<IMG SRC=$post1 align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> Posted:$a_date</font><hr>";
				    print "</td></tr><tr>";
				    print " <td>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_message</font></td></tr><tr><td align='right'>";
					print "<IMG SRC=$level_person alt=$a_name align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $a_ip</font>";
				    print "</td></tr></table>";
					print "</td>";
					print "</tr>";
				}
			}	// �� for
		print "</table>";
	}	// �� if
?>
            &nbsp;</td>
          </tr>
		  <tr><td align="right"> 
          <div align="right"><br>
            <?php print "<a href='form_answer.php?q_id=$q_id'>"; ?>
            <img src="image/t_reply.gif" border="0"> 
            <?php print "</a>"; ?>
          </div>
        </td>
      </tr>
	  
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>
</center>
<div align="center">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <td height="35" background="./image/tile_buttom.gif"> 
        <div align="center"><font  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' color="gray" size="1"><b>
          <font size="1"><?php print "Computer Engineering Department King Mongkut's Institue of Technology Ladkrabang<br>Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400"; ?></font> 
          </b></font></div>
      </td>
    </tr>
	</table>
  </div>
 
 </body>
</html>
