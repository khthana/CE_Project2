<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		session_destroy();
		exit;
	}
	if($name=='root'){
		require ('headroot.php');
	}else{
		require ('head.php');
	}
		$sql1 = "select * from administrator";
		$db_query1 = mysql_db_query ($dbname, $sql1);
		$num_rows1 = mysql_num_rows($db_query1);
		if($num_rows1!=0){ 
			for ($i=0;$i<$num_rows1;$i++){
				$sql = "delete from administrator where ad_id='$delad[$i]'";
				$dbquery = mysql_db_query($dbname, $sql);
			}
		}
			print "<META http-equiv=refresh content='0; URL=body.php?q_id=$q_id&id=$id&name=$name'>";
?>