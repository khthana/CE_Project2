<?
session_start();
include ("checkip.php");
if( $ip_addr == checkip() && session_is_registered('memberof') && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="../include/stylesheet.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="770" border="0" cellpadding="0" cellspacing="0">
          <tr> 
            <td> 
            </td>
          </tr>
          <tr> 
            <td> 
              <form name=question action="to_question.php" method=post onSubmit="return check()"  autocomplete="off">
                  <table width="774" border="0" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td> <table cellspacing=1 cellpadding=2 width="80%" border=0 align="center">
                          <tbody>
                            <tr class=header bgcolor="#F5F1ED"> 
                              <td colspan=2 align=center><font  size="3" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��Ǣ�͡�з������</font></td>
                            </tr>
                            <tr > 
                              <td bgcolor=#f7f7f7 align=right width="18%"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">����ͧ 
                                <font color="#FF0000">*</font>:</font></td>
                              <td bgcolor=#f7f7f7 width="82%"> <input size=40 name=q_topic> 
                              </td>
                            </tr>
                            <tr > 
                              <td valign=top bgcolor=#f7f7f7 align=right height="158" width="18%"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��ͤ��� 
                                <font color="#FF0000">*</font>:<br>
                                </font></td>
                              <td width="82%" height="84" bgcolor="#f7f7f7"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
                                <textarea name=q_message rows=9 cols=80></textarea>
                                </font></td>
                            </tr>
                            <?
								if($memberof > 1){
							?>
                            <tr > 
                              <td valign=top bgcolor=#f7f7f7 align=right height="24">�Է����������</td>
                              <td width="82%" height="24" bgcolor="#f7f7f7"><label> 
                                <input name="q_show" type="radio" value="public" checked>
                                ����� </label> <label> 
                                <input type="radio" name="q_show" value="private">
                                <font  color="red"> ੾�������Ҥ�Ԫ��</font></label> 
                              </td>
                            </tr>
                            <? 
							}else{ 
								
							?>
                            <tr > 
                              <td bgcolor='#f7f7f7' >&nbsp;</td>
                              <td width="82%" bgcolor='#f7f7f7'><input type="hidden" name="q_show" value="public">
                                &nbsp;</td>
                            </tr>
                            <?
							}
							?>
                          </tbody>
                        </table></td>
                    </tr>
                    <tr> 
                      <td bgcolor="#FFFFFF"> <div align="center"> <a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border=0></a> 
                          <a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border=0></a> 
                          <a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border=0></a> 
                          <a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border=0></a> 
                          <a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border=0></a> 
                          <a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border=0></a> 
                          <a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" 	border=0></a> 
                          <a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border=0></a> 
                          <a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border=0></a> 
                          <a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border=0></a> 
                          <a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border=0></a><br>
                          <a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border=0></a> 
                          <a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border=0></a> 
                          <a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border=0></a> 
                          <a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border=0></a> 
                          <a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" 	border=0></a> 
                          <a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border=0></a> 
                          <a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border=0></a> 
						  <a href="javascript:setsmile(':--:')"><img src="pics/--.gif" border=0></a> 
                          <a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border=0></a> 
                          <a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border=0></a> 
                          <a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border=0></a> 
                          <a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border=0></a> 
                          <a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border=0></a> 
						  <a href="javascript:setsmile(':lol:')"><img src="pics/lol.jpg" border=0></a> 
                          <a href="javascript:setsmile(':crazy:')"><img src="pics/grazy.gif" border=0></a><br>
                          <font color="#FF9900" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</font> 
                        </div>
                        <div align="center"> 
                          <input type=submit value=Submit name=topicsubmit>
                          <input type=reset value=reset name=topicreset>
                        </div></td>
                    </tr>
                    <tr>
                      <td height=200>&nbsp;</td>
                    </tr>
                  </table>
              </form>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>
    <div align="center">
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
        <td height="35" background="./image/tile_buttom.gif"> 
        <div align="center"><font  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' color="gray" size="1"><b>
          <font size="1"><?php print "Computer Engineering Department King Mongkut's Institue of Technology Ladkrabang<br>Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400"; ?></font> 
          </b></font></div>
      </td>
    </tr>
	</table>
   </div>
 </center>
<script language="JavaScript">
<!--
function check()
{
      var v2 = document.question.q_topic.value;
      var v3 = document.question.q_message.value;
   
	  
		 if (v2.length==0)
           {
           alert("��سһ�͹ Topic");
           document.question.q_topic.focus();           
		   return false;
           }
        else if (v3.length==0)
           {
           alert("��سһ�͹ Message");
           document.question.q_message.focus();           
		   return false;
           }
}
function setsmile(what)
{
	document.question.q_message.value = document.question.elements.q_message.value+" "+what;
	document.question.q_message.focus();
}
//-->
</script> 
</body>
</html>
<?
}else{
header("location:http://isag25.ce.kmitl.ac.th/~gead/login.php");
exit();
}
?>
