<?PHP
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��  e-mail </title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="../include/stylesheet.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
</head>
<body>
<?
if(!session_is_registered('name') ||!session_is_registered('memberof') ||!session_is_registered('ip_addr') ||!session_is_registered('accesslevel')){
	session_unregister('name');
	session_unregister('memberof');
	session_unregister('ip_addr');
	session_unregister('accesslevel');
	session_unregister('sid');
	session_unregister('pid');
	?>
	�������ö�ӡ���� E-mail ����������
	<?
	exit;
}else{
	if($_GET['tname']!='' && $_POST['tname']=='' && $_GET['qid']!='' && $_POST['qid']=='' && $_GET['page']!='' && $_POST['page']==''){
		$tname=$_GET['tname'];
		$qid=$_GET['qid'];
		$page=$_GET['page'];
	}
	if($_POST['subject'] != '' && $_POST['detail'] !='' && $_POST['tname']!='' && $_POST['qid']!=''){
		include "sendmail.php";
		$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
		mysql_select_db("webce") or die(mysql_error());
		$result=mysql_query("select email from useraccount where username='$tname'") or die(mysql_error());
		if(mysql_num_rows($result)!=1){
			session_unregister('name');
			session_unregister('memberof');
			session_unregister('ip_addr');
			session_unregister('accesslevel');
			session_unregister('sid');
			session_unregister('pid');
			?>
			�������ö�ӡ���� E-mail ����
			<?
			exit;
		}
		$To=mysql_fetch_array($result) or die(mysql_error());
		$result2=mysql_query("select email from useraccount where username='$name'") or die(mysql_error());
		if(mysql_num_rows($result2)!=1){
			session_unregister('name');
			session_unregister('memberof');
			session_unregister('ip_addr');
			session_unregister('accesslevel');
			session_unregister('sid');
			session_unregister('pid');
			?>
			�������ö�ӡ���� E-mail ���Ѻ
			<?
			exit;
		}
		$From=mysql_fetch_array($result2) or die(mysql_error());
		$Subject=$_POST['subject'];
		$Html=$_POST['detail'];
		$Html=str_replace("\n","<br>\n",$Html);
		$qid=$_POST['qid'];
		$page=$_POST['page'];
		SendMail($From[0],$From[0],$To[0],$To[0],$Subject,$Text,$Html,$AttmFiles);
		header("Location: http://isag25.ce.kmitl.ac.th/~gead/webboard/index.php");
		exit;
}else{
		?>
		<center>
		<form action="" method="post">
		<input type="hidden" name="tname" value="<?echo $tname?>">
		<input type="hidden" name="qid" value="<?echo $qid?>">
		<input type="hidden" name="page" value="<?echo $page?>">
		<br>
		<br>
		<table>
		  <tr>
		   <td colspan=2><center>�� E-mail �֧��Ҫԡ</center></td>
		  </tr>
		  <tr>
		   <td>Subject</td>
		   <td><input type="text" name="subject" size="52"><td>
		  </tr>
		  <tr>
		   <td valign="top">Detail</td>
		   <td><textarea name="detail" rows="5" cols="50"></textarea></td>
		  </tr>
		 </table>
		 <input type="Submit" value="Send"> <input type="reset">
		</form>
		</center>
		<?
	}
}
?>
</body>
</html>