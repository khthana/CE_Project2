<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Administrator Tool</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<!-- �ѡ������͹仾���� Status Bar-->
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<p align="center"><img src="image/admin.jpg" width="480" height="65"></p>
<hr width="80%">
<?php
include("webboard.inc");
include("md5.js");
if($mem[n]=="root"){
	print "<FORM name=answer action=\"to_answer.php?q_id=$q_id\" method=post onSubmit='return check()'  autocomplete='off'>";
?>
	
<Table border=0 cellspacing=1 cellpadding=4 Bgcolor=#FFFFFF align=center width=398>
  <Tr> 
      <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Name 
        *</font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_name Size=30>
      </Td>
    </Tr>
    <Tr> 
      <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Surname 
        *</font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_surname Size=30>
      </Td>
    </Tr>
    <Tr> 
      <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_name 
        *</font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_user Size=15>
      </Td>
    </Tr>
    <Tr> 
      <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_password 
        *</font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd Size=15>
      </Td>
    </Tr>
    <Tr> 
      <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Password 
        Again *</font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd2 Size=15>
      </Td>
    </Tr>
  </Table>
 
<br>
<div align="center">
<input type=submit value=Submit name=topicsubmit>
<input type=reset value=reset name=topicreset>
</form>
</div>
<?php
	}
?>
</body>
</html>