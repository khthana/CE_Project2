<?php
	session_start();
	include("checkip.php");
	if( $ip_addr == checkip() && session_is_registered('memberof') && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ){

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<?php
	include("webboard.inc");
	include("smtpmail.inc.php");
	include("censor.php");
	include("thai.inc");
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql6 = "select * from webboardquestion where q_id='$q_id'";
	$db_query6 = mysql_db_query ($dbname, $sql6) or die("�Դ��Ͱҹ�����������36");
	$nums_rows6 = mysql_num_rows($db_query6);
	
		if (getenv(HTTP_X_FORWARDED_FOR)){ 
			$ip=getenv(HTTP_X_FORWARDED_FOR); 
		} else { 
			$ip=getenv(REMOTE_ADDR); 
		} 
		$ip = $ip." -->".gethostbyaddr($ip).""; 
		$a_ip = $ip; 
		$a_raddr = getenv(REMOTE_ADDR);
		$message =trim($a_message);
		$name = trim($name);
		$name = eregi_replace(" ","",$name);
		$message = eregi_replace(" ","",$message);

		if(($a_message=="") or ($$nums_rows6!=0) or ($name=="") or ($message=="")){
			print"��سҡ�͡��ͤ������١��ͧ";
			echo "a_message : ".$a_message."<br>";
			echo "muns_rows6 : ".$nums_rows6."<br>";
			echo "name : ".$name."<br>";
			echo "message : ".$message."<br>";
			
				print "<META http-equiv=refresh content=\"20; URL=view.php?q_id=$q_id\">";
			exit;
		}else{
		}

		for ($i=0;$i<$nums_rows6;$i++){
			$result = mysql_fetch_array($db_query6);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
			$q_update = $result[q_update];
			$q_post = $result[q_post];
			$q_reng = $result[q_reng];
			$q_updatemail = $result[q_updatemail];
		}
	if($q_updatemail=="update"){
		$to=$q_email;
		$s="Mail  update";
		$body="�բ���������¹�ŧ㹡�з����س������";
		smail($to,$s,$body);
	}
	else{}
	$a_message = htmlspecialchars($a_message);
	$name = htmlspecialchars($name);
	$email = htmlspecialchars($email);
	$a_icq = htmlspecialchars($a_icq);

	$a_message = nl2br($a_message);
	$a_message = censor($a_message);
	$name = censor($name);
	$email = censor($email);
	$a_icq = censor($a_icq);
   
	$txt = array(":smile:", ":sad:",":red:", ":big:", ":ent:", ":shy:", ":sleepy:", ":sun:", ":sg:", ":embarass:", ":dead:", ":cool:", ":clown:", ":pukey:", ":eek:", ":roll:", ":smoke:", ":angry:", ":confused:", ":cry:", ":lol:", ":yawn:", ":devil:", ":tongue:", ":alien:", ":tasty:", ":crazy:");
	$pic = array("smile.gif","frown.gif","redface.gif","biggrin.gif","blue.gif","shy.gif","sleepy.gif","sunglasses.gif","supergrin.gif","embarass.gif","dead.gif","cool.gif","clown.gif","pukey.gif","eek.gif","sarcblink.gif","smokin.gif","reallymad.gif","confused.gif","crying.gif","lol.gif","yawn.gif","devil.gif","tongue.gif","aysmile.gif","tasty.gif","grazy.gif");
	for ($a=0 ; $a<sizeof($txt) ; $a++) {
		$a_message= eregi_replace($txt[$a],"<img src=\"pics/$pic[$a]\">",$a_message);
	}

	// ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
	$a_message = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>",$a_message);
	$a_message = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>",$a_message); 
	$a_message = preg_replace('#\[b](.+?)\[/b]#is', '<b>\\1</b>', $a_message);
	$a_message = preg_replace('#\[i](.+?)\[/i]#is', '<i>\\1</i>', $a_message);
	$a_message = preg_replace('#\[u](.+?)\[/u]#is', '<u>\\1</u>', $a_message);

	setlocale("LC_TIME","th");
		
		$a2 = date("j")*1440;
		$b2 = strftime("%m")*44640;	
		$c2 = (strftime("%Y")+543)*535680;
		$d2 = date("H")*60;	 // ���Ҫ������
		$f2 = date("i");	 // ���ҹҷ�
		$q_post = $a2+$b2+$c2+$d2+$f2;

	$a1 = date("j");
	$b1 = strftime("%m");
	$e = date("m")-1;	//�������͹����ѡ�Ժ
	$b1 = $ThaiShortMonth[$e];
	$c1 = strftime("%Y")+543;	 // �� �.�.
	$d1 = date("H:i");
	$a_date = "$a1 $b1 $c1:$d1";

	$sql3 = "select * from webboardanswer where a_name = '$name' and a_message='$a_message' and a_qid='$q_id'";
	$db_query3 = mysql_db_query ($dbname, $sql3) or die("�Դ��Ͱҹ�����������113");
	$q_r3 = mysql_num_rows($db_query3);
	if($q_r3=="0"){
		if($email==""){
			$sql = "insert into webboardanswer (a_id, a_qid, a_message, a_name, a_email, a_icq, a_ip, a_datetime, a_post, a_raddr ) values ('0','$q_id','$a_message','$name','$email','$a_icq','$a_ip','$a_date', '$q_post', '$a_raddr' )";
			$result = mysql_db_query($dbname,$sql) or die("�Դ��Ͱҹ�����������118");

			$sql1 = "select * from webboardanswer where a_qid = '$q_id'";
			$db_query1 = mysql_db_query ($dbname, $sql1) or die("�Դ��Ͱҹ�����������121");
			$q_reng = mysql_num_rows($db_query1);

			$sql2="update webboardquestion set q_update='$q_post', q_reng='$q_reng' where q_id='$q_id'";
			$db_query2 = mysql_db_query ($dbname, $sql2) or die("�Դ��Ͱҹ�����������125");
			print "<META http-equiv=refresh content=\"0; URL=view.php?q_id=$q_id\">";
		}
		else{
			if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])",$email)){
				$sql = "insert into webboardanswer (a_id, a_qid, a_message, a_name, a_email, a_icq, a_ip, a_datetime, a_post, a_raddr) values ('0','$q_id','$a_message','$name','$email','$a_icq','$a_ip','$a_date', '$q_post', '$a_raddr')";
				$result = mysql_db_query($dbname,$sql) or die("�Դ��Ͱҹ�����������131");

				$sql1 = "select * from webboardanswer where a_qid = '$q_id'";
				$db_query1 = mysql_db_query ($dbname, $sql1);
				$q_reng = mysql_num_rows($db_query1) or die("�Դ��Ͱҹ�����������135");

				$sql2="update webboardquestion set q_update='$q_post', q_reng='$q_reng' where q_id='$q_id'";
				$db_query2 = mysql_db_query ($dbname, $sql2) or die("�Դ��Ͱҹ�����������138");
				print "<META http-equiv=refresh content=\"0; URL=view.php?q_id=$q_id\">";
			}
			else{
				echo "<br><center><font  size=4> ��سҡ�͡ Email �ͧ��ҹ����</font><br><br>";
				print "<META http-equiv=refresh content=\"2; URL=form_answer.php?q_id=$q_id\">";
			}
		}
	}
	else{
			print "<META http-equiv=refresh content=\"0; URL=view.php?q_id=$q_id\">";
	}
?>
 </body>
</html>
<?
}else{
header("location:http://isag25.ce.kmitl.ac.th/~gead/login.php");
exit();
}
?>