<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center"><img src="image/admin.jpg" width="480" height="65"></p>
<hr width="80%">
<p align="center"><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"><?php print "<a href='regis_admin.php?id=$id&name=$name'>"; ?>Register</a> 
  | <?php print "<a href='del_admin.php?id=$id&name=$name'>"; ?>ź��Ҫԡ</a></font></b></font></p>
</body>
</html>
