<?php
include("webboard.inc");
mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
mysql_select_db($dbname) or die("���͡�ҹ�����������");
$sql="	select * from administrator where ad_user='$name' and ad_passwd='$pwd'";
$query=mysql_db_query($dbname,$sql);
$NRow = mysql_num_rows($query);
$result = mysql_fetch_array($query);
$ad_id = $result[ad_id];
if($NRow==1){ 
	if($pwdnew1 == $pwdnew2){
		$sql2="update administrator set ad_passwd='$pwdnew1', ad_passwd2='$pwdnew2' where ad_id='$ad_id'";
		$db_query2 = mysql_db_query ($dbname, $sql2) or die("�Դ��Ͱҹ�����������125");
	}else{
		?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#F4F4F4" bordercolor="#FF9900">
  <tr> 
    <td height="80"> 
      <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3" color="#CC0000">Password 
        ���ç�ѹ</font></div>
    </td>
  </tr>
</table>
			<?php
			exit;
	}
}
else{
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#F4F4F4" bordercolor="#FF9900">
  <tr> 
    <td height="80"> 
      <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3" color="#CC0000">����� 
        User ���� database</font></div>
    </td>
  </tr>
</table>
<?php
	exit;
}
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#F4F4F4" bordercolor="#FF9900">
  <tr> 
    <td height="80"> 
      <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3" color="#CC0000">Update 
        complete </font></div>
    </td>
  </tr>
</table>