<?php
	print "<FORM name=register action='to_register.php?id=$id&name=$name' method=post>";
?>
<Table border=0 cellspacing=1 cellpadding=4 Bgcolor=#FFFFFF align=center width=398>
  <Tr> 
      
    <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Name 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_name Size=30>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Surname 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_surname Size=30>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_name 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_user Size=15>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_password 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd Size=15>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Password 
      Again <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd2 Size=15>
      </Td>
    </Tr>
  </Table>
<br>
<div align="center">
<input type=submit value=Submit name=topicsubmit>
<input type=reset value=reset name=topicreset>
</div>
</form>
