<?
session_start();
include("webboard.inc");
include("md5.js");
if($name&&$pwd){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	if($NRow==0){ 
?><title>Login Administrator</title>
			
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=dela.php">
<font face="MS Sans Serif, Microsoft Sans Serif" size="3"> 
<?php
	}
	else{
		$row = mysql_fetch_array($result);
		$pwd1=$row["ad_passwd"];
		$pwd1=MD5($pwd1).$challenge;
		$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
		if($name==$row["ad_user"] && $pwd==$pwd1) { 
			$sql1 = "select * from answer where a_qid = '$login[del]'";
			$db_query1 = mysql_db_query ($dbname, $sql1);
			$num_rows1 = mysql_num_rows($db_query1);
			if ($num_rows1 != 0 ){
				print "<center><IMG SRC='image/Admin.jpg'><hr width='80%'>";
				print "<font  face=\"Verdana, Arial, Helvetica, sans-serif\" size=5 color=#000099>ź�ӵͺ����ͧ���</font>";
				print "<form name='weblogin'  method='post'  action='del_answer.php'  autocomplete='off' >";
				print "<center><table width='80%'><tr><td>";
				for ($i=0;$i<$num_rows1;$i++){
					$result1 = mysql_fetch_array($db_query1);
					$a_message = $result1[a_message];
					$a_email = $result1[a_email];
					$a_name = $result1[a_name];
					$a_date = $result1[a_datetime];
					$a_icq = $result1[a_icq];
					$a_id = $result1[a_id];

					$a_name = stripslashes($a_name);
					$a_email = stripslashes($a_email);
					$a_ip = stripslashes($a_ip);
					$a_date = stripslashes($a_date);
					$a_icq = stripslashes($a_icq);
					$t=$i+1;
					print "<input type='radio' name='a[$i]' value=$a_id><font  face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><font color=#FF0000> Name : </font>$a_id $a_name<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#FF0000>Message : </font>$a_message<br><br></font>";
				}
				print "</td></tr></table></center>";	
				print "<center><hr width='80%'><input type='submit' name='Submit' value='Submit'>&nbsp;&nbsp;&nbsp;";
		        print "<input type='reset' name='Submit2' value='Reset'></center>";
				print "</form>";
			}
		}
		else{
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=dela.php">
<font face="MS Sans Serif, Microsoft Sans Serif" size="3"> 
<?php
	 }	
}
}
?>
</font>