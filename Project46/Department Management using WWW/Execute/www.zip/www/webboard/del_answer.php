<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		session_destroy();
		exit;
	}
	if($name=='root'){
		require ('headroot.php');
	}else{
		require ('head.php');
	}
		$sql1 = "select * from webboardanswer where a_qid='$q_id'";
		$db_query1 = mysql_db_query ($dbname, $sql1);
		$num_rows1 = mysql_num_rows($db_query1);
		if($num_rows1==0){ 
		}
		else{
			for ($i=0;$i<$num_rows1;$i++){
				$sql1 = "delete from webboardanswer where a_id='$dela[$i]'";
				$dbquery1 = mysql_db_query($dbname, $sql1);
			}
			$sql2 = "select * from webboardanswer where a_qid='$q_id'";
			$db_query2 = mysql_db_query ($dbname, $sql2);
			$num_rows2 = mysql_num_rows($db_query2);
			
			if($num_rows2!==0){
				$sql3 = "select max(a_post) from webboardanswer where a_qid='$q_id'";
				$query3 = mysql_db_query ($dbname, $sql3);
				$result3 = mysql_fetch_array($query3);

				$sql4="update webboardquestion set q_update='$result3[0]', q_reng='$num_rows2' where q_id='$q_id'";
				$db_query4 = mysql_db_query ($dbname, $sql4) or die("�Դ��Ͱҹ�����������138");
			}
			else{
				$sql3 = "select q_post from webboardquestion where q_id='$q_id'";
				$query3 = mysql_db_query ($dbname, $sql3);
				$result3 = mysql_fetch_array($query3);

				$sql4="update webboardquestion set q_update='$result3[0]', q_reng='$num_rows2' where q_id='$q_id'";
				$db_query4 = mysql_db_query ($dbname, $sql4) or die("�Դ��Ͱҹ�����������138");
			}
		}
			print "<META http-equiv=refresh content='0; URL=admin_view_answer.php?q_id=$q_id&id=$id&name=$name'>";
?>