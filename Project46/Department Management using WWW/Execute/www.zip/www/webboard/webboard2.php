<?php
	session_start();
	session_destroy();
	session_unset();
	include("webboard.inc");
	include("checkip.php");	
	session_register('url_page');
	$url_page = "http://isag25.ce.kmitl.ac.th/~gead/webboard/form_qusetion.php";
	
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	setlocale("LC_TIME","th");	//������Ẻ�� 
	$a2 = date("j")*1440;
	$b2 = strftime("%m")*44640;	
	$c2 = (strftime("%Y")+543)*535680;
	$d2 = date("H")*60;	 // ���Ҫ������
	$f2 = date("i");	 // ���ҹҷ�
	$gif_up = $a2+$b2+$c2+$d2+$f2;

	if (empty($page)){
		$page=1;
	}
	// check level fo member
		if( $ip_addr ==checkip() && $memberof > '1' && session_is_registered('name') && session_is_registered('email') && session_is_registered('ip_addr') ){
			$q_sql = "select * from webboardquestion ";	
		} else {
			$q_sql = "select * from webboardquestion where q_show = 'public' ";
		}

	$q_db_query = mysql_db_query ($dbname, $q_sql);
	$num_rows = mysql_num_rows($q_db_query);
	$rt = $num_rows%$pagesize;
	if($rt!=0) 
		{ 
			$totalpage = floor($num_rows/$pagesize)+1; 
		}
	else
		{
			$totalpage = floor($num_rows/$pagesize); 
		}
	$goto = ($page-1)*$pagesize;
	$sql = $q_sql." order by q_name asc limit $goto,$pagesize";
	$db_query = mysql_db_query ($dbname, $sql);
	if (!$db_query){
		print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
		exit;
	}
	else{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="../include/stylesheet.css" rel=stylesheet  type=text/css>
<BODY aLink=#ffffff bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff9900 marginwidth="0" marginheight="0" onLoad="">
        
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="30%"><?php print "<img src='./image/wb.gif'>"; ?></td>
    <td width="40%" ><div align="center"></div></td>
    <td width="30%" ><div align="right"><?php print "<img src='./image/ce-kmitl.gif'>"; ?></div></td>
  </tr>
</table>
    </td>
  </tr>
  <tr> 
    <td> <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="48%"> <div align="left">
              <?php 	
			print "<a href='form_qusetion.php'><img src='image/t_new.gif' border='0'></a>";										
				?>
            </div></td>
          <td width="52%"> <div align="right"> <a href="help.php"><?php print "������";?></a></div></td>
        </tr>
      </table></td>
  </tr><td>

<?php
		$nums_rows = mysql_num_rows($db_query);
		print "<table align=center border=0  width=100% cellspacing=1 cellpadding=4>";
		print "<tr ><td width=3% background='image/tile_sub.gif' align=center ><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><B><CENTER>[]</CENTER></B></FONT></td>";
		print "<td width=15% background='image/tile_sub.gif' align=center ><a href=\"index.php\"><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><b>�ѹ���</b></font></a></td>";
		print "<td background='image/tile_sub.gif' align=center ><a href=\"webboard1.php\"><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><b>����ͧ</b></font></a></td>";
		print "<td width=15% background='image/tile_sub.gif' align=center ><a href=\"webboard2.php\"><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><b>����駡�з��</b></font></a></td>";
		print "<td width=20% background='image/tile_sub.gif' align=center ><a href=\"webboard3.php\"><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><b>�ͺ��������ش</b></font></a></td>";
		print "<td width=3% background='image/tile_sub.gif' align=center ><a href=\"webboard4.php\"><FONT  face='MS Sans Serif, Tahoma, sans-serif' size=1><b>�ͺ</b></font></a></td></tr>";
		for ($i=0;$i<$nums_rows;$i++){
			$result = mysql_fetch_array($db_query);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
			$q_update = $result[q_update];
			$q_post = $result[q_post];
			$q_reng = $result[q_reng];

			$sql6 = "select max(a_datetime) from webboardanswer where a_qid='$q_id'";
			$query6 = mysql_db_query ($dbname, $sql6);
			$result6 = mysql_fetch_array($query6);
			
			$sql7 = "select * from webboardanswer where a_qid='$q_id'";
			$query7 = mysql_db_query ($dbname, $sql7);
			$nums_rows7 = mysql_num_rows($query7);

			if($nums_rows7!="0"){
				$q_update1 = $result6[0];
			}
			else{
				$q_update1 = "$q_date:$q_time";
				$q_reng = "0";
		}
			$q_id = stripslashes($q_id);
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_update = stripslashes($q_update);
			$q_post = stripslashes($q_post);

			$sql1 = "select * from webboardanswer where a_id='i'";
			$db_query1 = mysql_db_query ($dbname, $sql1);
			$nums_rows1 = mysql_num_rows($db_query1);

			$up=$gif_up-$q_update;
			if($up<=4320){
				if( ($color %2)== '1' ) {  $bg = '#F5F1ED';  $color++; } else { $bg = '#F7F7F7'; $color++; }			
				print "<Tr> <Td bgcolor=$bg width=10 align=center><img src=$new>";
				print "</Td> <Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
				print "<Td  bgcolor=$bg width=40%><a href=\"view_answer.php?q_id=$q_id\" target=\"_blank\">";
				print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
				print "<Td bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
				print "<Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_update1</font></Td>";
				print "<Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
			}
			else if($up>21600){
				$sql5 = "delete from webboardquestion where q_id = '$q_id'";
				$db_query5 = mysql_db_query ($dbname, $sql5);
				
				$sql4 = "delete from webboardanswer where a_qid = '$q_id'";
				$db_query4 = mysql_db_query ($dbname, $sql4);
			}
			else{
				if( ($color %2)== '1' ) {  $bg = '#F5F1ED';  $color++; } else { $bg = '#F7F7F7'; $color++; }			
				print "<Tr> <Td bgcolor=$bg width=10 align=center><img src=$normal>";
				print "</Td> <Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
				print "<Td  bgcolor=$bg width=40%><a href=\"view_answer.php?q_id=$q_id\" target=\"_blank\">";
				print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
				print "<Td bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
				print "<Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_update1</font></Td>";
				print "<Td  bgcolor=$bg align=center><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
			}
		
		}	// end for
	print "</table>";
	} // end else
	print "<table border=0 width=100%><tr>";
	print "<td >";
	print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
	for($i=1 ; $i<$page ; $i++){
		print "<a href='$PHP_SELF?page=$i'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color='#FF9900'><b>$page</b></font> ";
	for($i=$page+1 ; $i<=$totalpage ; $i++){
		print "<a href=$PHP_SELF?page=$i><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print"</td>";
	print "<td  align=right><a href='form_qusetion.php'><img src='image/t_new.gif' border='0'></a></td>";	
	print"</tr></table>";
?></td></tr>
    <tr> 
      <td height="35" background="./image/tile_buttom.gif"> 
        <div align="center"><font  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' color="gray" size="1"><b>
          <font size="1"><?php print "Computer Engineering Department King Mongkut's Institue of Technology Ladkrabang<br>Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400"; ?></font> 
          </b></font></div>
      </td>
    </tr>
  </table>
<div align="center"> </div>
 
 </body>
</html>
