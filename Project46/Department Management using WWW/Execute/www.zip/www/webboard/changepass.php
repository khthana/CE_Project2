<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0026)http://203.101.137.50/swl/ -->
<HTML><HEAD>
<title>Management control group Powered by Software Link</title>
<link rel=stylesheet type='text/css' href='layout/css/win.css'>
<META content="text/html; charset=TIS-620" http-equiv=Content-Type><LINK 
href="index_files/style.css" rel=stylesheet type=text/css>
<META content="MSHTML 5.00.3315.2870" name=GENERATOR>
<script language='JavaScript' src='lib/chkform.js' type='text/javascript'></script>
</HEAD>
<BODY bgColor=#f4f4f4>
  
<form name="login" method="post" action="change.php">
  <DIV align=center><BR>
    <FONT face="Verdana, Arial, Helvetica, sans-serif" 
size=6><B>Webpage Change Password</B></FONT><BR>
    <BR>
<HR align=center SIZE=1 width=400>
<BR></DIV>
  <TABLE align=center bgColor=#666666 border=0 cellPadding=5 cellSpacing=1 width="394">
    <TBODY> 
    <TR bgColor=#99ccff>
    <TD>
        <DIV align=center><FONT face="MS Sans Serif" size=1><B><font face="Arial, Helvetica, sans-serif" size="2">User 
          : Password</font></B></FONT></DIV>
      </TD></TR>
  <TR bgColor=#ffffff>
    <TD>
        <TABLE align=center cellSpacing=5 width="100%">
          <TBODY> 
          <TR> 
            <TD width="38%"> 
              <div align="right"><FONT face="Arial, Helvetica, sans-serif" 
          size=2>Username:</FONT></div>
            </TD>
            <TD colSpan=2 width="62%"><FONT face="Arial, Helvetica, sans-serif" 
            size=2> 
              <INPUT type=text name=name>
              </FONT></TD>
          </TR>
          <TR> 
            <TD width="38%"> 
              <div align="right"><FONT face="Arial, Helvetica, sans-serif" 
          size=2>Password old:</FONT></div>
            </TD>
            <TD colSpan=2 width="62%"><FONT face="Arial, Helvetica, sans-serif" 
            size=2> 
              <INPUT  type=password name=pwd>
              </FONT></TD>
          </TR>
          <TR>
            <TD width="38%">
              <div align="right"><font face="Arial, Helvetica, sans-serif" 
          size=2>Password New:</font></div>
            </TD>
            <TD colSpan=2 width="62%"><font face="Arial, Helvetica, sans-serif" 
            size=2>
              <input  type=password name=pwdnew1>
              </font></TD>
          </TR>
          <TR>
            <TD width="38%" height="27"> 
              <div align="right"><font face="Arial, Helvetica, sans-serif" 
          size=2>Password new again:</font></div>
            </TD>
            <TD colSpan=2 width="62%" height="27"><font face="Arial, Helvetica, sans-serif" 
            size=2> 
              <input  type=password name=pwdnew2>
              </font></TD>
          </TR>
          </TBODY>
        </TABLE>
      </TD></TR>
  <TR bgColor=#99ccff>
    <TD>
      <DIV align=center><INPUT name=submit type=submit value=Login> 
  </DIV></TD></TR></TBODY></TABLE><BR>
<DIV align=center>
<HR align=center SIZE=1 width=400>
<FONT face="Courier New, Courier, mono" size=2><BR><B> Technology provided 
by SWL</B><BR><B>Powered by</B> PHP,MySQL</FONT></DIV></FORM></BODY></HTML>
