<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $user, $passwd) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		require ('overtime.php');
		exit;
	}
	if($name=='root'){
		require ('headroot.php');
	}else{
		require ('head.php');
	}
			$sql4 = "select * from administrator where ad_user='$ad_user'";
			$db_query4 = mysql_db_query ($dbname, $sql4);
			$num_rows4 = mysql_num_rows($db_query4);

			$ad_name = htmlspecialchars($ad_name);
			$ad_surname = htmlspecialchars($ad_surname);
			$ad_user = htmlspecialchars($ad_user);
			$ad_passwd = htmlspecialchars($ad_passwd);
			$ad_passwd2 = htmlspecialchars($ad_passwd2);

			if($num_rows4==0){
				$sql = "insert into administrator (ad_id, ad_name, ad_surname, ad_user, ad_passwd, ad_passwd2) 
								values ('0','$ad_name','$ad_surname','$ad_user',md5('$ad_passwd.$ad_user'),md5('$ad_passwd2.$ad_user') )";
				$result = mysql_db_query($dbname,$sql) or die("�Դ��Ͱҹ�����������23");
			print "<META http-equiv=refresh content='0; URL=body.php?q_id=$q_id&id=$id&name=$name'>";
			}
			else{
				require ('reuser.php');
			}
?>