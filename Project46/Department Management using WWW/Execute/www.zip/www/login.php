<? session_start();
include "connect.php";
include "notice.php";
include "./include/function.php";
include "./user/checkip.php";
 		$url_error = 'http://isag25.ce.kmitl.ac.th/~gead/login.php';
		session_register('url_error');
if($_POST['username']=='' && $_POST['password']=='' ){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>����к�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK  href="./include/stylesheet.css" type=text/css rel=stylesheet>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body  leftmargin="0" topmargin="0" onLoad="MM_preloadImages('pic/b_subject_over.gif','pic/b_officer_over.gif','pic/b_oldstudent_over.gif','pic/b_webboard_over.gif','pic/b_newstudent_over.gif','pic/b_faq_over.gif')" >
  <form name="index" method="post" action="login.php">
  <table  width="780" border="0" cellpadding="0" cellspacing="0" >
    <tr> 
      <td width="780" valign="top" nowrap><TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>
			<IMG SRC="pic/headce_01.gif" WIDTH=168 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_02.gif" WIDTH=170 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_03.gif" WIDTH=222 HEIGHT=33 ALT=""></TD>
		<TD>
			<IMG SRC="pic/headce_04.gif" WIDTH=220 HEIGHT=33 ALT=""></TD>
	</TR>
	<TR>
		    <TD height="43" class="linebottom"> <IMG SRC="pic/headce_05.gif" WIDTH=168 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_06.gif" WIDTH=170 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_07.gif" WIDTH=222 HEIGHT=42 ALT=""></TD>
		<TD class="linebottom">
			<IMG SRC="pic/headce_08.gif" WIDTH=220 HEIGHT=42 ALT=""></TD>
	</TR>
</TABLE></td>
    </tr>
    <tr> 
      <td valign="top" nowrap bgcolor="#FFFFFF" ><table width="780" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td  width="120" height="20"><a href="javascript:;" onMouseOver="MM_swapImage('Image1','','pic/b_subject_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_subject.gif" name="Image1" width="120" height="20" border="0" id="Image1"></a></td>
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/officer/person/officer.php" onMouseOver="MM_swapImage('Image2','','pic/b_officer_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_officer.gif" name="Image2" width="120" height="20" border="0" id="Image2"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image3','','pic/b_oldstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_oldstudent.gif" name="Image3" width="120" height="20" border="0" id="Image3"></a></td>
            <td width="120" ><a href="http://isag25.ce.kmitl.ac.th/~gead/webboard/" onMouseOver="MM_swapImage('Image4','','pic/b_webboard_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_webboard.gif" name="Image4" width="120" height="20" border="0" id="Image4"></a></td>
            <td width="120" ><a href="javascript:;" onMouseOver="MM_swapImage('Image5','','pic/b_newstudent_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_newstudent.gif" name="Image5" width="120" height="20" border="0" id="Image5"></a></td>
            <td width="199"><a href="javascript:;" onMouseOver="MM_swapImage('Image6','','pic/b_faq_over.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="pic/b_faq.gif" name="Image6" width="120" height="20" border="0" id="Image6"></a></td>
          </tr>
        </table></td>
    </tr>
    <tr > 
      <td height="430" valign="top" nowrap> <table align="center" width="63%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="100">&nbsp; </td>
            <td></td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td bgcolor="#9999CC">&nbsp;</td>
            <td bgcolor="#9999CC" align="center"><strong>login</strong></td>
            <td bgcolor="#9999CC">&nbsp;</td>
          </tr>
          <tr> 
            <td width="38%" bgcolor="#F5F5DC"> <div align="right">username&nbsp;</div></td>
            <td width="17%" bgcolor="#F5F5DC"> <input type="text" name="username" maxlength="20" class="violet"></td>
            <td width="45%" bgcolor="#F5F5DC">&nbsp;</td>
          </tr>
          <tr> 
            <td bgcolor="#F5F5DC"> <div align="right">password&nbsp;</div></td>
            <td bgcolor="#F5F5DC"> <input type="password" name="password" maxlength="20" class="violet"></td>
            <td bgcolor="#F5F5DC">&nbsp;</td>
          </tr>
          <tr bgcolor="#E6E6FA"> 
            <td>&nbsp;<a href='./user/register.php'>ŧ����¹</a></td>
            <td rowspan="2" align="right" bgcolor="#E6E6FA"> 
              <div align="right">&nbsp; 
                <input type="submit" name="submit" value="  login  "  class="violet">
              </div></td>
            <td rowspan="2">&nbsp;</td>
          </tr>
          <tr bgcolor="#E6E6FA"> 
            <td>&nbsp;<a href="" target="_self" onClick="var s='?username='+document.all.username.value;this.href='http://isag25.ce.kmitl.ac.th/~gead/user/forget_password.php'+s">������ʼ�ҹ</a></td>
          </tr>
          <tr> 
            <td >&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
    </tr>
    <tr >
      <td height="60"  background="pic/b.jpg"><font  color="#000099" size="-2"  class="violet">&nbsp; 
        Department of Computer Engineering Faculty of Engineering King Mongkut's 
        Institute of Technology<br>
        &nbsp; Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        &nbsp; �觤ӵ����� webmaster@ce.kmitl.ac.th </font> </td>
    </tr>
  </table>
  <tr>
    <td height="10">&nbsp;</td>
    </tr>
 
</table>
</form>
</body>
</html>
<?
}else{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$link=mysql_connect("localhost","admin","admin") or die(mysql_error());
	mysql_select_db("webce",$link) or die(mysql_error());
	$sql = "SELECT useraccount.username, useraccount.email, useraccount.memberof, accesslevel.level, useraccount.sid, useraccount.pid' . ' FROM useraccount, accesslevel" . " WHERE useraccount.password=md5('$password.$username') and useraccount.username='$username' and useraccount.memberof=accesslevel.id"; 
	$result=mysql_query($sql) or die(mysql_error());
	if(mysql_num_rows($result)==1){
		$row=mysql_fetch_array($result,MYSQL_NUM);
		session_register('ip_addr');
		$ip_addr =checkip();
		session_register('name');
		$name=$row[0];
		session_register('email');
		$email=$row[1];
		session_register('memberof');
		$memberof=$row[2];
		session_register('accesslevel');
		$accesslevel=$row[3];
		if($row[4]!=null){
			session_register('sid');
			$sid=$row[4];
			$sql = "SELECT name,room"
		    . " FROM student"
			. " WHERE sid = '$sid' ";
			$result=mysql_query($sql) or die(mysql_error);
			$row=mysql_fetch_array($result,MYSQL_NUM); 
			if(mysql_num_rows($result)==1){
				session_register('realname');
				$realname=$row[0];
				session_register('sroom');
				$sroom=$row[1];

			}else{
				session_destroy();
	
			}
		}
		if($row[5]!=null){
			session_register('pid');
			$pid=$row[5];
			$sql = "SELECT name,position,teaching"
		    . " FROM personal_detail"
			. " WHERE id = '$pid' ";
			$result=mysql_query($sql) or die(mysql_error);			
			$row=mysql_fetch_array($result,MYSQL_NUM); 
								if(mysql_num_rows($result)==1){
									session_register('realname');
									$realname=$row[0];
									session_register('position');
									$position=$row[1];
									session_register('teaching');
									$teaching=$row[2];
	
								}else{
									session_destroy();

								}
		}
		print "<META http-equiv=refresh content='0; URL=$url_page'>";
	}else{
		session_destroy(); 	    
		$url_error = "http://isag25.ce.kmitl.ac.th/~gead/login.php";
		session_register($url_error);
		notice ("red","�س��� Username  ���� Password ���١��ͧ","[ login ]");
		exit;
	}
}	
?>



