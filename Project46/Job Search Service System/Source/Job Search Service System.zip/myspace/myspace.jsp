<html>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 22px;
	font-weight: bold;
}
.style2 {font-family: "-JS Junkaew"}
.style6 {font-family: "-JS Junkaew"; font-size: 18px; }
.style7 {color: #FF0000}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
<body>
<form action="check_password.jsp" method="post" name="login" target="_self" onSubmit="MM_validateForm('username','','R','password','','R');return document.MM_returnValue">
<table width="24%"  border="0" align="center" cellpadding="0">
  <tr>
    <td width="34%"><span class="style1">Login</span></td>
    <td width="66%">&nbsp;</td>
  </tr>
  <tr>
    <td class="style2"><span class="style6">Username</span></td>
    <td>
      <input name="username" type="text" id="username" size="15" maxlength="100">   </td>
  </tr>
  <tr>
    <td height="30" class="style2"><span class="style6">Password</span></td>
    <td><input name="password" type="password" id="password" size="15" maxlength="100"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="login" type="submit" id="login" value="Login"></td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td><a href="register.jsp" class="style2">&lt;New Member&gt; </a></td>
    </tr>
  <tr>
    <td height="55" colspan="2" class="style2"><div align="center" class="style7">
	<%
	String error = request.getParameter("error");
	if (error == null)
	{
				out.print("&nbsp;");
	}
	else
	{
		out.print("Please Check username and password again");
	}
	%>
</div></td>
    </tr>
</table>
</form>
</body>
</html>