<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add My Profile</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String name = request.getParameter("name");
String surname = request.getParameter("surname");
String company = request.getParameter("company");
String mail = request.getParameter("mail");
String quickname = request.getParameter("quickname");
String hidden_id = request.getParameter("hidden_id");


	 String sql_contract = "update mycontact set FIRST_NAME='"+name+"' ,LAST_NAME='"+surname+"',COMPANY_NAME='"+company+"',E_MAIL='"+mail+"',QUICK_NAME='"+quickname+"' where ID = '"+hidden_id+"' ";
     
	 int myresult_contract = stmt.executeUpdate(sql_contract);
	 response.sendRedirect("my_contract.jsp");
%>
</body>
</html>
