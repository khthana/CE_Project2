<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Agent</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
.style6 {
	font-family: "-JS Junkaew";
	font-size: 20px;
	font-weight: bold;
}
-->
</style>




</head>

<body leftmargin="0" topmargin="0"  rightmargin="0" onLoad="MM_preloadImages('Menu_My_Profile_2.gif','Menu_My_Resume_2.gif','Menu_My_Contract_2.gif','Menu_My_History_2.gif','Menu_Webboard_2.gif','Menu_Mail_2.gif','Menu_Jobs_2.gif','Menu_News_2.gif','Menu_Private_Message_2.gif','Menu_E_mail_2.gif','Menu_Agent_2.gif','Menu_Search_2.gif','image/Menu_My_Interview_2.gif')">
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>

<%
String name = "";
String surname = "";
String sql_name = "select NAME,SURNAME from member where ID = '"+id+"'";
ResultSet myresult_name = stmt.executeQuery(sql_name);
while(myresult_name.next())
{ 
	name = myresult_name.getString("NAME"); 
	surname = myresult_name.getString("SURNAME"); 
}
     myresult_name.close();
%>
<div id="Layer1" style="position:absolute; left:17px; top:112px; width:261px; height:22px; z-index:1" class="style4">
<div align="center" class="style5"><%=name+"   "+surname%></div>
</div>
<div id="Layer2" style="position:absolute; left:421px; top:170px; width:90px; height:23px; z-index:2"><a href="my_profile.jsp" target="_self" onMouseOver="MM_swapImage('MyProfile','','image/Menu_My_Profile_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Profile.gif" alt="My Profile" name="MyProfile" width="90" height="23" border="0"></a></div>
<div id="Layer3" style="position:absolute; left:570px; top:165px; width:90px; height:23px; z-index:3"><a href="my_recruitment.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('recruitment','','image/Menu_My_Recruitment_2.gif',1)"><img src="image/Menu_My_Recruitment.gif" alt="Recruitment" name="recruitment" width="105" height="26" border="0"></a></div>
<div id="Layer4" style="position:absolute; left:734px; top:170px; width:89px; height:23px; z-index:4"><a href="my_contract.jsp" target="_self" onMouseOver="MM_swapImage('MyContract','','image/Menu_My_Contract_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Contract.gif" alt="My Contract" name="MyContract" width="89" height="23" border="0"></a></div>
<div id="Layer5" style="position:absolute; left:892px; top:170px; width:89px; height:23px; z-index:5"><a href="my_history.jsp" target="_self" onMouseOver="MM_swapImage('MyHistory','','image/Menu_My_History_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_History.gif" alt="My History" name="MyHistory" width="89" height="23" border="0"></a></div>
<div id="Layer6" style="position:absolute; left:17px; top:246px; width:135px; height:27px; z-index:6"><img src="image/Menu_Information.gif" width="135" height="27"></div>
<div id="Layer7" style="position:absolute; left:30px; top:333px; width:74px; height:24px; z-index:7"><img src="image/Menu_Compose.gif" width="74" height="24"></div>
<div id="Layer8" style="position:absolute; left:30px; top:415px; width:47px; height:24px; z-index:8"><img src="image/Menu_Help.gif" width="47" height="24"></div>
<div id="Layer10" style="position:absolute; left:15px; top:359px; width:161px; height:23px; z-index:10"><a href="private_message.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Private_Message','','image/Menu_Private_Message_2.gif',1)"><img src="image/Menu_Private_Message.gif" alt="Private Message" name="Private_Message" width="161" height="23" border="0"></a></div>
<div id="Layer11" style="position:absolute; left:16px; top:388px; width:161px; height:23px; z-index:11"><a href="e_mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E-Mail','','image/Menu_E_mail_2.gif',1)"><img src="image/Menu_E_mail.gif" alt="E-Mail" name="E-Mail" width="161" height="23" border="0"></a></div>
<div id="Layer12" style="position:absolute; left:15px; top:443px; width:161px; height:23px; z-index:12"><a href="agent.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agent','','image/Menu_Agent_2.gif',1)"><img src="image/Menu_Agent.gif" alt="Agent" name="Agent" width="161" height="23" border="0"></a></div>
<div id="Layer13" style="position:absolute; left:15px; top:470px; width:161px; height:23px; z-index:13"><a href="search.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Search','','image/Menu_Search_2.gif',1)"><img src="image/Menu_Search.gif" alt="Search" name="Search" width="161" height="23" border="0"></a></div>
<div id="Layer14" style="position:absolute; left:15px; top:271px; width:161px; height:23px; z-index:14"><a href="mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mail','','image/Menu_Mail_2.gif',1)"><img src="image/Menu_Mail.gif" alt="Mail" name="Mail" width="161" height="23" border="0"></a></div>
<div id="Layer15" style="position:absolute; left:15px; top:295px; width:161px; height:23px; z-index:15"><a href="jobs.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Jobs','','image/Menu_Jobs_2.gif',1)"><img src="image/Menu_Jobs.gif" alt="Jobs" name="Jobs" width="161" height="23" border="0"></a></div>
<div id="Layer9" style="position:absolute; left:30px; top:512px; width:74px; height:24px; z-index:17"><a href="post_job.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('post_job','','image/Menu_Post_job_2.gif',1)"><img src="image/Menu_Post_job.gif" alt="Post Job" name="post_job" width="74" height="24" border="0"></a></div>
<div id="Layer90" style="position:absolute; left:30px; top:558px; width:81px; height:24px; z-index:17"><a href="boardlist.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('webboard','','../administrator/image/Menu_Webboard_2.gif',1)"><img src="../administrator/image/Menu_Webboard.gif" alt="Webboard" name="webboard" width="81" height="24" border="0"></a></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" height="150" valign="top"><img src="image/Head_Left.jpg" width="280" height="150"></td>
    <td width="80%" height="150" valign="top"><img src="image/Head_Center.jpg" width="100%" height="150"></td>
    <td width="10%" height="150" valign="top"><img src="image/Head_Right.jpg" width="345" height="150"></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="70" width="90%" valign="top"><img src="image/My.jpg" width="930" height="70"></td>
    <td height="70" width="10%" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="220" height="371" rowspan="9" valign="top"><img src="image/Menu_BG.jpg" width="220" height="371"></td>
    <td width="0" height="371" rowspan="9" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td  height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="100%" height="371" rowspan="9">&nbsp;</td>
  </tr>
  <tr>
    <td width="20"  height="12"><img src="image/K_conner_top_left.jpg" width="20" height="12"></td>
    <td width="650"  height="12"><img src="image/K_conner_top_center.jpg" width="710" height="12"></td>
    <td width="40"  height="12"><img src="image/K_conner_top_right.jpg" width="40" height="12"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_top.jpg" width="20" height="20"></td>
    <td width="784" rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0">
      <tr>
        <td align="right"><img src="image/Titel_agent.jpg" width="453" height="35"></td>
      </tr>
      <tr>
        <td align="center">
		










<table width=700" border="1" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td width="222" class="style2">Name</td>
      <td width="55" class="style2">Age</td>
      <td width="98" class="style2">Degree</td>
      <td width="114" class="style2">Department</td>
      <td width="109" class="style2">Faculty</td>
      <td width="88" class="style2">Possibility</td>
    </tr>



<%
int c_id;
double bn_experience1=0,bn_experience2=0,bn_experience3=0;
double possibility;
double percent_rule1,percent_rule2,percent_rule3;
double pass_criteria_rule1,pass_criteria_rule2,pass_criteria_rule3;
int c_rule1,c_rule2,c_rule3;
double criteria_rule1,criteria_rule2,criteria_rule3;
double max_rule1,max_rule2,max_rule3;
int c_age=0,m_age=0;
String m_sex="",c_sex="";
String c_qualification="",m_qualification="";
int m_english=0,m_japan=0,m_chinese=0,c_english=0,c_japan=0,c_chinese=0 ;
String c_position1= "",c_position2= "",c_position3= "",m_position= "";
int c_experience1=0,c_experience2=0,c_experience3=0,m_experience=0;
double m_gpa=0,c_gpa=0;
String m_software="",m_hardware="",m_network="",m_database="",m_os="";
String c_software="",c_hardware="",c_network="",c_database="",c_os="";
double n_english=0,n_japan=0,n_chinese=0,n_position=0,n_experience=0,n_gpa=0,n_knowledge=0;
double bn_software=0,bn_hardware=0,bn_network=0,bn_database=0,bn_os=0;
double w_english_R1	= 2.31;
double w_english_R2	= 0;
double w_english_R3	= 0;
double w_japan_R1	= 1.71;
double w_japan_R2	= 0;
double w_japan_R3	= 0;
double w_chinese_R1	=1.71;
double w_chinese_R2	=0;
double w_chinese_R3	=0;
double w_pos_R1		=0;
double w_pos_R2		=2.11;
double w_pos_R3		=3.27;
double w_ex_R1		=0;
double w_ex_R2		=2.21;
double w_ex_R3		=3.49;
double w_gpa_R1	=0.78;
double w_gpa_R2	=0.98;
double w_gpa_R3	=0;
double w_kb_R1		=0;
double w_kb_R2		=6.65;
double w_kb_R3		=1.24;
double rule_language,rule_technic,rule_experience;


StringTokenizer st_m_software;
StringTokenizer st_m_hardware;
StringTokenizer st_m_network;
StringTokenizer st_m_database;
StringTokenizer st_m_os;
int num_m_software= 0;
int num_m_hardware= 0;
int num_m_network= 0;
int num_m_database= 0;
int num_m_os= 0;
String[ ] sm_software ;
String[ ] sm_hardware ;
String[ ] sm_network ;
String[ ] sm_database ;
String[ ] sm_os ;

StringTokenizer st_c_software;
StringTokenizer st_c_hardware;
StringTokenizer st_c_network;
StringTokenizer st_c_database;
StringTokenizer st_c_os;
int num_c_software= 0;
int num_c_hardware= 0;
int num_c_network= 0;
int num_c_database= 0;
int num_c_os= 0;
String[ ] sc_software ;
String[ ] sc_hardware ;
String[ ] sc_network ;
String[ ] sc_database ;
String[ ] sc_os ;

int num_experience = 0;
int num_kn = 0;
int i=0;
double temp;
int temp2=0;
int w =0;
boolean age = false,qualification = false,sex = false;
//float display_possibility = 0;
String display_possibility ="";
String id_post_job = request.getParameter("id_post_job");
%>


<%
//+++++++++++++Select Job+++++++++++++++++//
	 String sql_job = "select * from job where ID = '"+id_post_job+"' ";
     ResultSet myresult_job = stmt.executeQuery(sql_job);
	 while(myresult_job.next())
	        {  		
             m_english = myresult_job.getInt("ENGLISH");
			 m_japan = myresult_job.getInt("JAPAN");
			 m_chinese = myresult_job.getInt("CHINESE");
			 m_gpa = myresult_job.getDouble("GPA");
			 m_software = myresult_job.getString("SOFTWARE");
			 m_hardware = myresult_job.getString("HARDWARE");
			 m_network = myresult_job.getString("NETWORK");
			 m_database = myresult_job.getString("DB");
			 m_os = myresult_job.getString("OS");
			 m_position = myresult_job.getString("POSITION");
			 m_experience = myresult_job.getInt("EXPERIENCE");
			 m_qualification = myresult_job.getString("QUALIFICATION");
			 m_age = myresult_job.getInt("AGE");
			 m_sex = myresult_job.getString("SEX");
			 }
			myresult_job.close();


st_m_software = new StringTokenizer(m_software,",");
num_m_software = st_m_software.countTokens();
sm_software= new String[num_m_software];
for (i = 0; i<num_m_software; i++)
{ sm_software[i] = new String (st_m_software.nextToken()); }

st_m_hardware = new StringTokenizer(m_hardware,",");
num_m_hardware = st_m_hardware.countTokens();
sm_hardware= new String[num_m_hardware];
for (i = 0; i<num_m_hardware; i++)
{ sm_hardware[i] = new String (st_m_hardware.nextToken()); }

st_m_network = new StringTokenizer(m_network,",");
num_m_network = st_m_network.countTokens();
sm_network= new String[num_m_network];
for (i = 0; i<num_m_network; i++)
{ sm_network[i] = new String (st_m_network.nextToken()); }

st_m_database = new StringTokenizer(m_database,",");
num_m_database = st_m_database.countTokens();
sm_database= new String[num_m_database];
for (i = 0; i<num_m_database; i++)
{ sm_database[i] = new String (st_m_database.nextToken()); }

st_m_os = new StringTokenizer(m_os,",");
num_m_os = st_m_os.countTokens();
sm_os= new String[num_m_os];
for (i = 0; i<num_m_os; i++)
{ sm_os[i] = new String (st_m_os.nextToken()); }

/*out.print("  Num Software = "+num_m_software+"   ");
out.print("  Num Hardware = "+num_m_hardware+"   ");
out.print("  Num Network = "+num_m_network+"   ");
out.print("  Num Database = "+num_m_database+"   ");
out.print("  Num Os = "+num_m_os+"   ");
out.println("<br>");
out.println("<br>");*/
//+++++++++++++Select Job+++++++++++++++++//
%>


<%
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%>
<%
	int row_page = 10;
	int total_row = 0;
	ResultSet myresult0 = stmt.executeQuery("select count(*) as num from member where PRIVACY ='1' and TYPE = '1'  ");
	while(myresult0.next())
	{ total_row = myresult0.getInt("num"); }
	myresult0.close();
	int total_page = (int)Math.ceil((double)total_row/(double)row_page);
	int screen,start;
	
	if(request.getParameter("screen") == null)
		{ screen = 1; }
	else
		{ screen = Integer.parseInt(request.getParameter("screen")); } 
	
	if(screen >= 1 && screen <= total_page)
	{	start = (screen - 1)*row_page;

		ResultSet myresult_members = stmt.executeQuery("select * from member where PRIVACY ='1' and TYPE = '1' order by `ID` DESC limit "+start+","+row_page+" ");
		while(myresult_members.next())
	        {
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
							c_id = myresult_members.getInt("ID");
							c_english = myresult_members.getInt("ENGLISH");
							c_japan = myresult_members.getInt("JAPAN");
							c_chinese = myresult_members.getInt("CHINESE");
							c_gpa = myresult_members.getDouble("GPA");
					 	    c_software = myresult_members.getString("SOFTWARE");
							c_hardware = myresult_members.getString("HARDWARE");
							 c_database = myresult_members.getString("DB");
							 c_os = myresult_members.getString("OS");
							c_network = myresult_members.getString("NETWORK");
							c_position1 = myresult_members.getString("POSITION1");
							c_experience1 = myresult_members.getInt("YEAR1");
							c_position2 = myresult_members.getString("POSITION2");
							c_experience2 = myresult_members.getInt("YEAR2");
							c_position3 = myresult_members.getString("POSITION3");
							c_experience3 = myresult_members.getInt("YEAR3");							
							c_age = myresult_members.getInt("B_YEAR");
							c_qualification = myresult_members.getString("DEGREE");
							c_sex = myresult_members.getString("SEX");
							
							Calendar c = Calendar.getInstance();
							c_age  =  c.get(c.YEAR) - c_age;
							/*out.print(" ID job = "+count_jobs);
							out.print("  english = "+c_english);
							if (c_gpa == 0.20 ) out.print("  gpa = 0.20  ");
							out.println("<br>");*/
							age = false;  qualification = false;  sex = false;
							if ( m_age > c_age )  { age = true; }
							if ( m_qualification.equals(c_qualification) ) {  qualification = true; }
							if ( m_qualification.equals("Bachelor") && c_qualification.equals("Master") || m_qualification.equals("Bachelor") && c_qualification.equals("Doctor") || m_qualification.equals("Master") && m_qualification.equals("Bachelor") ) { qualification = true; }
							if ( m_sex.equals(c_sex) ) { sex = true; }
							if ( m_sex.equals("Male/Female") && c_sex.equals("Male") || m_sex.equals("Male/Female") && c_sex.equals("Female") ) { sex = true; }
					if ( age && qualification && sex)
						{
							//+++++++++++++INPUT LAYER+++++++++++++++++//							
							st_c_software = new StringTokenizer(c_software,",");
							num_c_software = st_c_software.countTokens();
							sc_software= new String[num_c_software];
							for (i = 0; i<num_c_software; i++)
							{ sc_software[i] = new String (st_c_software.nextToken()); }

							st_c_hardware = new StringTokenizer(c_hardware,",");
							num_c_hardware = st_c_hardware.countTokens();
							sc_hardware= new String[num_c_hardware];
							for (i = 0; i<num_c_hardware; i++)
							{ sc_hardware[i] = new String (st_c_hardware.nextToken()); }

							st_c_network = new StringTokenizer(c_network,",");
							num_c_network = st_c_network.countTokens();
							sc_network= new String[num_c_network];
							for (i = 0; i<num_c_network; i++)
							{ sc_network[i] = new String (st_c_network.nextToken()); }

							st_c_database = new StringTokenizer(c_database,",");
							num_c_database = st_c_database.countTokens();
							sc_database= new String[num_c_database];
							for (i = 0; i<num_c_database; i++)
							{ sc_database[i] = new String (st_c_database.nextToken()); }
							
							st_c_os = new StringTokenizer(c_os,",");
							num_c_os = st_c_os.countTokens();
							sc_os= new String[num_c_os];
							for (i = 0; i<num_c_os; i++)
							{ sc_os[i] = new String (st_c_os.nextToken()); }
											 //+++++++C find to M++++++++//
							bn_software = 0;
							for (i = 0; i<num_m_software; i++)
									{	
											temp2 = c_software.indexOf(sm_software[i]);
											if ( temp2<0 )  {bn_software = -1; }											
									}
							bn_hardware = 0;
							for (i = 0; i<num_m_hardware; i++)
									{	
											temp2 = c_hardware.indexOf(sm_hardware[i]);
											if ( temp2<0 )  {bn_hardware = -1; }											
									}	
							bn_network = 0;
							for (i = 0; i<num_m_network; i++)
									{	
											temp2 = c_network.indexOf(sm_network[i]);
											if ( temp2<0 )  {bn_network = -1; }											
									}	
							bn_database = 0;
							for (i = 0; i<num_m_database; i++)
									{	
											temp2 = c_database.indexOf(sm_database[i]);
											if ( temp2<0 )  {bn_database = -1; }											
									}	
							bn_os = 0;
							for (i = 0; i<num_m_os; i++)
									{	
											temp2 = c_os.indexOf(sm_os[i]);
											if ( temp2<0 )  {bn_os = -1; }											
									}	
							                   //++++C find to M++++++//
							
							                 //++++++M find to C+++++++//            		
							num_kn = 0;
							if ( bn_software == 0  &&  !m_software.equals("-") )
								{		w = 0; num_kn = num_kn + 1;
										for (i = 0; i<num_c_software-1; i++)
											{	
												temp2 = m_software.indexOf(sc_software[i]);
												if (temp2<0) {  w = w +1;}																								
											}
										if ( w >= 10 ) { bn_software = 1;}
										if ( w == 9 ) { bn_software = 0.9;}
										if ( w == 8 ) { bn_software = 0.8;}
										if ( w == 7 ) { bn_software = 0.7;}
										if ( w == 6 ) { bn_software = 0.6;}
										if ( w == 5 ) { bn_software = 0.5;}
										if ( w == 4 ) { bn_software = 0.4;}
										if ( w == 3 ) { bn_software = 0.3;}
										if ( w == 2 ) { bn_software = 0.2;}
										if ( w == 1 ) { bn_software = 0.1;}
										if ( w == 0 ) { bn_software = 0.0;}
								}	
								if ( bn_hardware == 0  &&  !m_hardware.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_c_hardware-1; i++)
											{	
												temp2 = m_hardware.indexOf(sc_hardware[i]);
												if (temp2<0) {  w = w +1;}													
											}
										if ( w >= 10 ) { bn_hardware = 1;}
										if ( w == 9 ) { bn_hardware = 0.9;}
										if ( w == 8 ) { bn_hardware = 0.8;}
										if ( w == 7 ) { bn_hardware = 0.7;}
										if ( w == 6 ) { bn_hardware = 0.6;}
										if ( w == 5 ) { bn_hardware = 0.5;}
										if ( w == 4 ) { bn_hardware = 0.4;}
										if ( w == 3 ) { bn_hardware = 0.3;}
										if ( w == 2 ) { bn_hardware = 0.2;}
										if ( w == 1 ) { bn_hardware = 0.1;}
										if ( w == 0 ) { bn_hardware = 0.0;}
								}		
								if ( bn_network == 0  &&  !m_network.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_c_network-1; i++)
											{	
												temp2 = m_network.indexOf(sc_network[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_network = 1;}
										if ( w == 9 ) { bn_network = 0.9;}
										if ( w == 8 ) { bn_network = 0.8;}
										if ( w == 7 ) { bn_network = 0.7;}
										if ( w == 6 ) { bn_network = 0.6;}
										if ( w == 5 ) { bn_network = 0.5;}
										if ( w == 4 ) { bn_network = 0.4;}
										if ( w == 3 ) { bn_network = 0.3;}
										if ( w == 2 ) { bn_network = 0.2;}
										if ( w == 1 ) { bn_network = 0.1;}
										if ( w == 0 ) { bn_network = 0.0;}										
								}		
								if ( bn_database == 0  &&  !m_database.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_c_database-1; i++)
											{	
												temp2 = m_database.indexOf(sc_database[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_database = 1;}
										if ( w == 9 ) { bn_database = 0.9;}
										if ( w == 8 ) { bn_database = 0.8;}
										if ( w == 7 ) { bn_database = 0.7;}
										if ( w == 6 ) { bn_database = 0.6;}
										if ( w == 5 ) { bn_database = 0.5;}
										if ( w == 4 ) { bn_database = 0.4;}
										if ( w == 3 ) { bn_database = 0.3;}
										if ( w == 2 ) { bn_database = 0.2;}
										if ( w == 1 ) { bn_database = 0.1;}
										if ( w == 0 ) { bn_database = 0.0;}
								}	
								if ( bn_os == 0  &&  !m_os.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_c_os-1; i++)
											{	
												temp2 = m_os.indexOf(sc_os[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_os = 1;}
										if ( w == 9 ) { bn_os = 0.9;}
										if ( w == 8 ) { bn_os = 0.8;}
										if ( w == 7 ) { bn_os = 0.7;}
										if ( w == 6 ) { bn_os = 0.6;}
										if ( w == 5 ) { bn_os = 0.5;}
										if ( w == 4 ) { bn_os = 0.4;}
										if ( w == 3 ) { bn_os = 0.3;}
										if ( w == 2 ) { bn_os = 0.2;}
										if ( w == 1 ) { bn_os = 0.1;}
										if ( w == 0 ) { bn_os = 0.0;}
								}	
								//out.print("  BNSoftware = "+bn_software);
								//out.print("  BNHardware = "+bn_hardware);
								//out.print("  BNNetwork = "+bn_network);
								//out.print("  BNDatabase = "+bn_database);
								//out.print("  BNOS = "+bn_os);

								if ( bn_software == -1 || bn_hardware == -1 || bn_network == -1  || bn_database == -1  || bn_os == -1 )
									{  n_knowledge = -1;  }
								if ( bn_software >= 0 && bn_hardware >= 0 && bn_network >= 0  && bn_database >= 0  && bn_os >= 0 )
									{    
											n_knowledge = (bn_software+bn_hardware+bn_network+bn_database+bn_os)/num_kn;
											/*if ( bn_software == 1 || bn_hardware == 1 || bn_network == 1  || bn_database == 1  || bn_os == 1 )
												{  n_knowledge = 1;  }
											if ( bn_software == 0 && bn_hardware == 0 && bn_network == 0  && bn_database == 0  && bn_os == 0 )
												{  n_knowledge = 0;  }*/
									}

							//out.print("  N_Knowledge = "+n_knowledge);out.print("<br>");
							            //++++++M find to C+++++++//
														
							temp2	= c_english -  m_english;
							if ( temp2 == -3 )   n_english = -1;
							if ( temp2 == -2 )   n_english = -0.66;
							if ( temp2 == -1 )   n_english = -0.33;
							if ( temp2 == 0 )   n_english = 0;
							if ( temp2 == 1 )   n_english = 0.33;
							if ( temp2 == 2 )   n_english = 0.66;
							if ( temp2 == 3 )   n_english = 1;							

							temp2	= c_japan -  m_japan;
							if ( temp2 == -3 )   n_japan = -1;
							if ( temp2 == -2 )   n_japan = -0.66;
							if ( temp2 == -1 )   n_japan = -0.33;
							if ( temp2 == 0 )   n_japan = 0;
							if ( temp2 == 1 )   n_japan = 0.33;
							if ( temp2 == 2 )   n_japan = 0.66;
							if ( temp2 == 3 )   n_japan = 1;

							temp2	= c_chinese -  m_chinese;
							if ( temp2 == -3 )   n_chinese = -1;
							if ( temp2 == -2 )   n_chinese = -0.66;
							if ( temp2 == -1 )   n_chinese = -0.33;
							if ( temp2 == 0 )   n_chinese = 0;
							if ( temp2 == 1 )   n_chinese = 0.33;
							if ( temp2 == 2 )   n_chinese = 0.66;
							if ( temp2 == 3 )   n_chinese = 1;

							//out.print("  N_English = "+n_english);out.print("<br>");
							//out.print("  N_Japan = "+n_japan);out.print("<br>");
							//out.print("  N_Chinese = "+n_chinese);out.print("<br>");

							temp = c_gpa - m_gpa;
							if ( temp >= 1.00 ) n_gpa = 1;
							if ( temp >= 0.80 && temp < 1.00 ) n_gpa = 0.80;
							if ( temp >= 0.60 && temp < 0.80 ) n_gpa = 0.60;
							if ( temp >= 0.40 && temp < 0.60 ) n_gpa = 0.40;
							if ( temp >= 0.20 && temp < 0.40 ) n_gpa = 0.20;
							if ( temp >= 0.00 && temp < 0.20 ) n_gpa = 0.00;
							if ( temp >= -0.20 && temp < 0.00 ) n_gpa = -0.20;
							if ( temp >= -0.40 && temp < -0.20 ) n_gpa = -0.40;
							if ( temp >= -0.60 && temp < -0.40 ) n_gpa = -0.60;
							if ( temp >= -0.80 && temp < -0.60 ) n_gpa = -0.80;
							if ( temp <= -1.00 ) n_gpa = -1;
							//out.print("  N_Gpa = "+n_gpa);out.print("<br>");

							n_position = 0;
							num_experience = 0;
							bn_experience1 = 0;
							if ( c_position1.equals(m_position) )	
								{ n_position = n_position+0.33; 
							      temp2 = c_experience1 - m_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience1 = 1; }
								  if ( temp2 == 4 ) { bn_experience1 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience1 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience1 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience1 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience1 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience1 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience1 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience1 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience1 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience1 = -1; }								
								}

							bn_experience2 = 0;
							if ( c_position2.equals(m_position) )	
								{ n_position = n_position+0.33; 
							      temp2 = c_experience2 - m_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience2 = 1; }
								  if ( temp2 == 4 ) { bn_experience2 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience2 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience2 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience2 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience2 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience2 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience2 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience2 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience2 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience2 = -1; }					
								}

							bn_experience3 = 0;
							if ( c_position3.equals(m_position) )	
								{ n_position = n_position+0.33; 
							      temp2 = c_experience3 - m_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience3 = 1; }
								  if ( temp2 == 4 ) { bn_experience3 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience3 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience3 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience3 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience3 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience3 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience3 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience3 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience3 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience3 = -1; }
								}

							if ( num_experience == 0 ) 
								{  
										if ( m_experience == 0 ) { n_experience = 0; }
										if ( m_experience > 0 ) { n_experience = -1; }
								}
							else
								{ n_experience = (bn_experience1+bn_experience2+bn_experience3)/num_experience; }

							//out.print("  N_Position = "+n_position);out.print("<br>");							
							//out.print("  N_Experience = "+n_experience);out.print("<br>");
							//+++++++++++++INPUT LAYER+++++++++++++++++//

							//+++++++++++++RULE LAYER+++++++++++++++++//
							rule_language = (w_english_R1*n_english)+(w_japan_R1*n_japan)+(w_chinese_R1*n_chinese)+(w_pos_R1*n_position)+(w_ex_R1*n_experience)+(w_gpa_R1*n_gpa)+(w_kb_R1*n_knowledge);

							rule_technic = (w_english_R2*n_english)+(w_japan_R2*n_japan)+(w_chinese_R2*n_chinese)+(w_pos_R2*n_position)+(w_ex_R2*n_experience)+(w_gpa_R2*n_gpa)+(w_kb_R2*n_knowledge);

							rule_experience = (w_english_R3*n_english)+(w_japan_R3*n_japan)+(w_chinese_R3*n_chinese)+(w_pos_R3*n_position)+(w_ex_R3*n_experience)+(w_gpa_R3*n_gpa)+(w_kb_R3*n_knowledge);
							//out.print("  Rule_language = "+rule_language);out.print("<br>");
							//out.print("  Rule_technic = "+rule_technic);out.print("<br>");
							//out.print("  Rule_experience = "+rule_experience);out.print("<br>");
							//+++++++++++++RULE LAYER+++++++++++++++++//

							//+++++++++++++CRITERIA LAYER+++++++++++++++++//
							max_rule1 = w_english_R1+w_japan_R1+w_chinese_R1+w_pos_R1+w_ex_R1+w_gpa_R1+w_kb_R1;
							max_rule2 = w_english_R2+w_japan_R2+w_chinese_R2+w_pos_R2+w_ex_R2+w_gpa_R2+w_kb_R2;
							max_rule3 = w_english_R3+w_japan_R3+w_chinese_R3+w_pos_R3+w_ex_R3+w_gpa_R3+w_kb_R3;

							//out.print("  max_rule1 = "+max_rule1);out.print("<br>");
							//out.print("  max_rule2 = "+max_rule2);out.print("<br>");
							//out.print("  max_rule3 = "+max_rule3);out.print("<br>");

							percent_rule1 = (100*Math.abs(rule_language))/max_rule1;
							percent_rule2 = (100*Math.abs(rule_technic))/max_rule2;
							percent_rule3 = (100*Math.abs(rule_experience))/max_rule3;

	  					    if ( rule_language >= 0 ) 
								{	percent_rule1 = 50 + percent_rule1;	}
							if ( rule_language < 0 )
								{	percent_rule1 = 50 - percent_rule1;	}
							if ( rule_technic >= 0 ) 
								{	percent_rule2 = 50 + percent_rule2;	}
							if ( rule_technic < 0 )
								{	percent_rule2 = 50 - percent_rule2;	}
							if ( rule_experience >= 0 ) 
								{	percent_rule3 = 50 + percent_rule3;	}
							if ( rule_experience < 0 )
								{	percent_rule3 = 50 - percent_rule3;	}

							//out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							//out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							//out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");
	/*				
							criteria_rule1 = (max_rule1*c_rule1)/100;
							criteria_rule2 = (max_rule2*c_rule2)/100;
							criteria_rule3 = (max_rule3*c_rule3)/100;

							out.print("  criteria_rule1 = "+criteria_rule1);out.print("<br>");
							out.print("  criteria_rule2 = "+criteria_rule2);out.print("<br>");
							out.print("  criteria_rule3 = "+criteria_rule3);out.print("<br>");

							pass_criteria_rule1 = rule_language - criteria_rule1;
							pass_criteria_rule2 = rule_technic - criteria_rule2;
							pass_criteria_rule3 = rule_experience - criteria_rule3;

							out.print("  pass_criteria_rule1 = "+pass_criteria_rule1);out.print("<br>");
							out.print("  pass_criteria_rule2 = "+pass_criteria_rule2);out.print("<br>");
							out.print("  pass_criteria_rule3 = "+pass_criteria_rule3);out.print("<br>");
							
							percent_rule1 = (50*Math.abs(pass_criteria_rule1))/criteria_rule1;
							percent_rule2 = (50*Math.abs(pass_criteria_rule2))/criteria_rule2;
							percent_rule3 = (50*Math.abs(pass_criteria_rule3))/criteria_rule3;

							out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");

	  					    if ( pass_criteria_rule1 >= 0 ) 
								{	percent_rule1 = percent_rule1;	}
							if ( pass_criteria_rule1 < 0 )
								{	percent_rule1 = 50-percent_rule1;	}
							if ( pass_criteria_rule2 >= 0 ) 
								{	percent_rule2 = percent_rule2;	}
							if ( pass_criteria_rule2 < 0 )
								{	percent_rule2 = 50-percent_rule2;	}
							if ( pass_criteria_rule3 >= 0 ) 
								{	percent_rule3 = percent_rule3;	}
							if ( pass_criteria_rule3 < 0 )
								{	percent_rule3 = 50-percent_rule3;	}
							
							out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");
*/

							possibility = (percent_rule1+percent_rule2+percent_rule3)/3;
							display_possibility = Double.toString(possibility);
							display_possibility = display_possibility.substring(0,5);
							//+++++++++++++CRITERIA LAYER+++++++++++++++++//
						}//end if (go)
						else
						{ display_possibility = "0.00"; }
						//out.print("  Possibility = "+display_possibility);
						//out.print("<br>");out.print("<br>");out.print("<br>");

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%>
<tr>
					<td align="center" class="style1"><a href='agent_job.jsp?screen=<%=screen%>&id_post_job=<%=id_post_job%>' target="_self" onClick="MM_openBrWindow('d_member.jsp?id=<%=myresult_members.getString("ID")%>','','scrollbars=yes,width=650,height=700')"><%=myresult_members.getString("NAME")%>&nbsp;&nbsp;<%=myresult_members.getString("SURNAME")%></a></td>
					<td align="center" class="style1"><%=c_age%></td>
					<td align="center" class="style1"><%=myresult_members.getString("DEGREE")%></td>
					<td align="center" class="style1"><%=myresult_members.getString("DEPARTMENT")%></td>
					<td align="center" class="style1"><%=myresult_members.getString("FACULTY")%></td>
					<td align="center" class="style6"><%=display_possibility%>&nbsp;%</td>
	</tr>
	<%
			}// end while(myresult_jobs.next())
			myresult_members.close();
	}//end if(screen >= 1 && screen <= total_page)


%>
<%
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%>

  </table>

<table width="700" border="0" class="style1">
   <tr>
      <td width="284">&nbsp;</td>
      <td width="406" align="right">Page&nbsp;&nbsp;<%
			if(screen>1)
				{ out.println("<a href='agent_job.jsp?screen="+(screen-1)+"&id_post_job="+id_post_job+"'>Back</a>"); }

			for(int b=1; b<=total_page; b++)
				{
					if ( b == screen) { out.println("<b>"+b+"</b>"); }
					else { out.print(" <a href='agent_job.jsp?screen="+b+"&id_post_job="+id_post_job+"'>"+b+"</a> "); }
				}

			if(screen < total_page)
				{ out.println("<a href='agent_job.jsp?screen="+(screen+1)+"&id_post_job="+id_post_job+"'>Next</a>");}
	  %></td>
    </tr>
  </table>













</td>
      </tr>

    </table></td>
    <td width="35" height="20"><img src="image/K_middel_top2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td width="20" height="249"><img src="image/K_middel_center.jpg" width="20" height="250"></td>
    <td width="40" height="249"><img src="image/K_middel_center2.jpg" width="40" height="250"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_bottom.jpg" width="20" height="20"></td>
    <td width="40" height="20"><img src="image/K_middel_bottom2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td height="30" width="20"><img src="image/K_conner_bottom_left.jpg" width="20" height="30"></td>
    <td height="30" width="650"><img src="image/K_conner_bottom_center.jpg" width="710" height="30"></td>
    <td height="30" width="40"><img src="image/K_conner_bottom_right.jpg" width="40" height="30"></td>
  </tr>
  
  <tr>
    <td height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Left.jpg" width="440" height="15"></td>
    <td width="80%" valign="top" height="15"><img src="image/Tail_Center.jpg" width="100%" height="15"></td>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Right.jpg" width="165" height="15"></td>
  </tr>
</table>
</body>
</html>
