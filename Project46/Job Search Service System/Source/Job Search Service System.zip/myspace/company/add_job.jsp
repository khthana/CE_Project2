<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add Post Job</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String name_job = request.getParameter("name_job");
String position = request.getParameter("position");
String sex = request.getParameter("sex");
String age = request.getParameter("age");
String qualification = request.getParameter("qualification");
String job_type = request.getParameter("job_type");
String salary = request.getParameter("salary");
String experience = request.getParameter("experience");
String gpa = request.getParameter("gpa");
String english = request.getParameter("english");
String japan = request.getParameter("japan");
String chinese = request.getParameter("chinese");
String [ ] b_software = request.getParameterValues("software");
String [ ] b_hardware = request.getParameterValues("hardware");
String [ ] b_network = request.getParameterValues("network");
String [ ] b_db = request.getParameterValues("db");
String [ ] b_os = request.getParameterValues("os");
String company = "";
String location = "";
String city = "";
String software = "";
String hardware = "";
String network = "";
String db = "";
String os = "";
int i = 0;

if ( b_software != null )
{
	for ( i=0; i<b_software.length; i++)
			{	 software = software + b_software[i];
				  if ( i != b_software.length-1) {  software = software + ",";    }  
			}
}

if ( b_hardware != null )
{
	for ( i=0; i<b_hardware.length; i++)
			{	 hardware = hardware + b_hardware[i];
				  if ( i != b_hardware.length-1) {  hardware = hardware + ",";    }  
			}
}

if ( b_network != null )
{
	for ( i=0; i<b_network.length; i++)
			{	 network = network + b_network[i];
				  if ( i != b_network.length-1) {  network = network + ",";    }  
			}
}

if ( b_db != null )
{
	for ( i=0; i<b_db.length; i++)
			{	 db = db + b_db[i];
				  if ( i != b_db.length-1) {  db = db + ",";    }  
			}
}

if ( b_os != null )
{
	for ( i=0; i<b_os.length; i++)
			{	 os = os + b_os[i];
				  if ( i != b_os.length-1) {  os = os + ",";    }  
			}
}

if ( b_software == null )
{ software = "-"; }
if ( b_hardware == null )
{ hardware = "-"; }
if ( b_network == null )
{ network = "-"; }
if ( b_db == null )
{ db = "-"; }
if ( b_os == null )
{ os = "-"; }

if ( job_type == null )
{ job_type = "-"; }


Calendar c = Calendar.getInstance();
int month =  c.get(c.MONTH);
month = month+1;
String day = c.get(c.DAY_OF_MONTH)+"/"+month+"/"+c.get(c.YEAR)  ;

ResultSet myresult_member = stmt.executeQuery("select * from member where ID = '"+id+"' " );
while(myresult_member.next())
{
     company = myresult_member.getString("NAME");
	 location = myresult_member.getString("LOCATION");
	 city = myresult_member.getString("CITY");
}

	String sql_add_job = "INSERT INTO job (ID_COMPANY,NAME_JOB,COMPANY,POSITION,QUALIFICATION,FULL_PART,LOCATION,CITY,SALARY,EXPERIENCE,DATE,AGE,ENGLISH,JAPAN,CHINESE,GPA,SOFTWARE,HARDWARE,NETWORK,DB,OS,SEX) VALUES('"+id+"','"+name_job+"','"+company+"','"+position+"','"+qualification+"','"+job_type+"','"+location+"','"+city+"','"+salary+"','"+experience+"','"+day+"','"+age+"','"+english+"','"+japan+"','"+chinese+"','"+gpa+"','"+software+"','"+hardware+"','"+network+"','"+db+"','"+os+"','"+sex+"');";

    int myresult_add_job = stmt.executeUpdate(sql_add_job);
	response.sendRedirect("post_job.jsp");
%>
</body>
</html>
