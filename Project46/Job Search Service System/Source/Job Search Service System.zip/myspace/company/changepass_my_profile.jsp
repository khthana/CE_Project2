<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Pass My Profile</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String old_pass = request.getParameter("old_pass");
String new_pass = request.getParameter("new_pass");
String com_pass = request.getParameter("com_pass");
String password_from_sql = "";

	 String sql_password = "select PASSWORD from member where ID = '"+id+"' ";
     ResultSet myresult_password = stmt.executeQuery(sql_password); 
	 while(myresult_password.next())
	        { password_from_sql = myresult_password.getString("PASSWORD"); }
	  myresult_password.close();

if ( password_from_sql.equals(old_pass) )
{
	 if ( new_pass.equals(com_pass) )
		{
			String sql_pass_profile = "update member set PASSWORD='"+new_pass+"' where ID = '"+id+"' ";
		    int myresult_pass_profile = stmt.executeUpdate(sql_pass_profile);
			response.sendRedirect("my_profile.jsp");
		}
	 else
		{ response.sendRedirect("pass_my_profile.jsp?error=2");  }
}
else
{ response.sendRedirect("pass_my_profile.jsp?error=1"); }


%>
</body>
</html>
