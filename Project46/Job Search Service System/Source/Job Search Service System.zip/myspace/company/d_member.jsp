<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Member</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
  <form name="form_recruitment" method="post" action="recruitment.jsp">
<%
String id_member = request.getParameter("id");
int num_job = 0;

ResultSet myresult_job = stmt.executeQuery("select count(*) as num from job where id_company = '"+id+"' ");
while(myresult_job.next())
{     num_job = myresult_job.getInt("num");    }
myresult_job.close();

String [ ] name_job = new String [num_job];
String [ ] id_job = new String [num_job];
int n = 0;

ResultSet myresult_name_job = stmt.executeQuery("select * from job where id_company = '"+id+"' ");
while(myresult_name_job.next())
{      name_job[n] = myresult_name_job.getString("name_job");  
		id_job[n] = myresult_name_job.getString("id");   
		 n++;  
}
myresult_name_job.close();



	 String sql_myprofile = "select * from member where ID = '"+id_member+"' ";
     ResultSet myresult_myprofile = stmt.executeQuery(sql_myprofile);
	 while(myresult_myprofile.next())
	        {  
			  %>

<table width="650" border="0">
  <tr align="left">
    <td colspan="4" class="style2"><u>Personal</u></td>
  </tr>
  <tr align="left">
    <td width="90" class="style1">Name</td>
    <td width="220" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("NAME")%></td>
    <td width="70" class="style1">Surname </td>
    <td width="220" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("SURNAME")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Sex </td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("SEX")%></td>
	<%
  			           Calendar c = Calendar.getInstance();
						int age  =  c.get(c.YEAR) - myresult_myprofile.getInt("B_YEAR");         
	%>
    <td class="style1">Birthday </td>
    <td class="style3">:&nbsp;&nbsp;<%=age%></td>
  </tr>
  <tr align="left">
    <td class="style1">Location </td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("LOCATION")%></td>
  </tr>
  <tr align="left">
    <td class="style1">City </td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("CITY")%></td>
    <td class="style1">Code </td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getInt("CODE")%></td>
  </tr>
  <tr align="left">
    <td class="style1">E-Mail </td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("E_MAIL")%></td>
    <td class="style1">Telephone</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("TELEPHONE")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Language </td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%int temp =0;
		if( myresult_myprofile.getInt("ENGLISH") >= 0 )
			{   temp = temp+1; 
				if ( myresult_myprofile.getInt("ENGLISH") == 0 ) { out.print("English(Fluent)  "); }
				if ( myresult_myprofile.getInt("ENGLISH") == 1 ) { out.print("English(Fair)  "); }
				if ( myresult_myprofile.getInt("ENGLISH") == 2 ) { out.print("English(Poor)  "); }
			}
		if( myresult_myprofile.getInt("JAPAN") >= 0 )
			{   if ( temp == 1 ) { out.print(" , "); }
				temp = temp+1; 
				if ( myresult_myprofile.getInt("JAPAN") == 0 ) { out.print("Japan(Fluent)  "); }
				if ( myresult_myprofile.getInt("JAPAN") == 1 ) { out.print("Japan(Fair)  "); }
				if ( myresult_myprofile.getInt("JAPAN") == 2 ) { out.print("Japan(Poor)  "); }
			}
		if( myresult_myprofile.getInt("CHINESE") >=0 )
			{   if ( temp == 2 ) { out.print(" , "); } 
				if ( myresult_myprofile.getInt("CHINESE") == 0 ) { out.print("Chinese(Fluent)  "); }
				if ( myresult_myprofile.getInt("CHINESE") == 1 ) { out.print("Chinese(Fair)  "); }
				if ( myresult_myprofile.getInt("CHINESE") == 2 ) { out.print("Chinese(Poor)  "); }
			}
	%>	</td>
  </tr>
  <%
    StringTokenizer st;
	int num;
	String[ ] knowledge;
	int i;
	int write_knowledge = 0;
  %>

   <% if ( !myresult_myprofile.getString("SOFTWARE").equals("-") )
		{   st = new StringTokenizer(myresult_myprofile.getString("SOFTWARE"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style1"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

  <% if ( !myresult_myprofile.getString("HARDWARE").equals("-") )
		{   st = new StringTokenizer(myresult_myprofile.getString("HARDWARE"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style1"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_myprofile.getString("NETWORK").equals("-") )
		{   st = new StringTokenizer(myresult_myprofile.getString("NETWORK"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style1"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_myprofile.getString("DB").equals("-") )
		{   st = new StringTokenizer(myresult_myprofile.getString("DB"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style1"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_myprofile.getString("OS").equals("-") )
		{   st = new StringTokenizer(myresult_myprofile.getString("OS"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style1"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>



</table>
<table width="650" border="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="650" border="0">
  <tr align="left">
    <td colspan="4" class="style2"><u>University</u></td>
  </tr>
  <tr align="left">
    <td width="90" class="style1">University</td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("UNIVERSITY")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Department</td>
    <td width="220" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("DEPARTMENT")%></td>
    <td width="70" class="style1">Faculty</td>
    <td width="220" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("FACULTY")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Degree</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("DEGREE")%></td>
    <td class="style3">Graduated</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getInt("GRADUATED")%></td>
  </tr>
</table>
<table width="600" border="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>


<table width="650" border="0">
    <% if ( myresult_myprofile.getInt("YEAR1") > 0 || myresult_myprofile.getInt("YEAR2") > 0 || myresult_myprofile.getInt("YEAR3") > 0 )
		{ %>
  <tr align="left">
    <td colspan="2" class="style2"><u>Experience</u></td>
  </tr>
    <% } %>
  <% if ( myresult_myprofile.getInt("YEAR1") > 0 )
		{ %>
  <tr align="left">
    <td width="90" class="style1">Company</td>
    <td width="510" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("COMPANY1")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Position</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("POSITION1")%></td>
  </tr>
      <tr align="left">
	<td class="style1">Year</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getInt("YEAR1")%>&nbsp;&nbsp;(&nbsp;<%=myresult_myprofile.getInt("S_YEAR1")%>&nbsp;-&nbsp;<%=myresult_myprofile.getInt("U_YEAR1")%>&nbsp;)</td>
  </tr>  
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td class="style1">&nbsp;</td>
  </tr>
  <% } %>
    <% if ( myresult_myprofile.getInt("YEAR2") > 0 )
		{ %>
  <tr align="left">
    <td width="90" class="style1">Company</td>
    <td width="510" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("COMPANY2")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Position</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("POSITION2")%></td>
  </tr>
    <tr align="left">
    <td class="style1">Year</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getInt("YEAR2")%>&nbsp;&nbsp;(&nbsp;<%=myresult_myprofile.getInt("S_YEAR2")%>&nbsp;-&nbsp;<%=myresult_myprofile.getInt("U_YEAR2")%>&nbsp;)</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td class="style1">&nbsp;</td>
  </tr>
    <% } %>
    <% if ( myresult_myprofile.getInt("YEAR3") > 0 )
		{ %>
  <tr align="left">
    <td width="90" class="style1">Company</td>
    <td width="510" class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("COMPANY3")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Position</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getString("POSITION3")%></td>
  </tr>
  <tr align="left">
    <td class="style1">Year</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_myprofile.getInt("YEAR3")%>&nbsp;&nbsp;(&nbsp;<%=myresult_myprofile.getInt("S_YEAR3")%>&nbsp;-&nbsp;<%=myresult_myprofile.getInt("U_YEAR3")%>&nbsp;)</td>
  </tr>
      <% } %>
  <tr>
    <td class="style2">Select Job</td>
    <td class="style3">:&nbsp;&nbsp;<select name="id_post_job" id="id_post_job"><%
	for ( int x=0; x<num_job; x++) 
				{out.print("<option value="+id_job[x]+">"+name_job[x]+"</option>"); }
	%> </select></td>
  <tr>
    <td class="style2">Recruitment</td>
    <td class="style3">:&nbsp;&nbsp;<input name="recruitment" type="checkbox" id="recruitment" value="<%=myresult_myprofile.getString("ID")%>">    </td>
  </tr> 
  <tr>
    <td class="style2">&nbsp;&nbsp;</td>
    <td class="style3"><input name="submit_apply" type="submit" id="submit_apply" value="Interview"></td>
  </tr> 
</table>
<input name="id_member" type="hidden" value="<%=myresult_myprofile.getString("ID")%>">
<input name="name" type="hidden" value="<%=myresult_myprofile.getString("NAME")%>">
<input name="surname" type="hidden" value="<%=myresult_myprofile.getString("SURNAME")%>">
<input name="faculty" type="hidden" value="<%=myresult_myprofile.getString("FACULTY")%>">
<input name="department" type="hidden" value="<%=myresult_myprofile.getString("DEPARTMENT")%>">
<input name="degree" type="hidden" value="<%=myresult_myprofile.getString("DEGREE")%>">
<input name="age" type="hidden" value="<%=age%>">
<%
	 }
     myresult_myprofile.close();
	 %>	
	 </form>
</body>
</html>
