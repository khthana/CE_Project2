<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Member</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<% 
String submit_apply = request.getParameter("submit_apply");
String id_member = request.getParameter("id_member");
String id_post_job = request.getParameter("id_post_job");

String name = request.getParameter("name");
String surname = request.getParameter("surname");
String faculty = request.getParameter("faculty");
String department = request.getParameter("department");
String degree = request.getParameter("degree");
String age = request.getParameter("age");

Calendar c = Calendar.getInstance();
int month =  c.get(c.MONTH);
month = month+1;
String day = c.get(c.DAY_OF_MONTH)+"/"+month+"/"+c.get(c.YEAR)  ;

String company ="";
String city ="";

		ResultSet myresult_company = stmt.executeQuery("select * from member where ID = '"+id+"' ");
		while(myresult_company.next())
				{	
					company = myresult_company.getString("NAME");
					city = myresult_company.getString("CITY");
				}
		myresult_company.close();

String position = "";
		ResultSet myresult_position = stmt.executeQuery( "select * from job where ID = '"+id_post_job+"'  ");
		while(myresult_position.next())
				{	
					position = myresult_position.getString("POSITION");
				}
		myresult_position.close();


if (submit_apply != null )
{  	
								String sql_apply = "INSERT INTO history_c (ID_COMPANY,ID_MEMBER,ID_JOB,NAME,SURNAME,AGE,DEPARTMENT,FACULTY,DEGREE,DATE) VALUES('"+id+"','"+id_member+"','"+id_post_job+"','"+name+"','"+surname+"','"+age+"','"+department+"','"+faculty+"','"+degree+"','"+day+"');";
							int myresult_apply = stmt.executeUpdate(sql_apply);

							String sql_apply2 = "INSERT INTO interview (ID_COMPANY,ID_MEMBER,ID_POST,COMPANY,LOCATION,POSITION,DATE) VALUES('"+id+"','"+id_member+"','"+id_post_job+"','"+company+"','"+city+"','"+position+"','"+day+"');";
							int myresult_apply2 = stmt.executeUpdate(sql_apply2);
	 
							if (myresult_apply != 0 && myresult_apply2 != 0)
								{  out.println("Complete To Recruitment"); 	} 

	}
	else
	{  String go_back = "d_member.jsp?id=" + id_member ;
		response.sendRedirect(go_back); 
		}




%>
</body>
</html>
