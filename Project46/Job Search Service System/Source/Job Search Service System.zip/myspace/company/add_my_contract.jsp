<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add My Contract</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String name = request.getParameter("name");
String surname = request.getParameter("surname");
String company = request.getParameter("company");
String mail = request.getParameter("mail");
String quickname = request.getParameter("quickname");

	String sql_add_contract = "INSERT INTO mycontact (FIRST_NAME,LAST_NAME,COMPANY_NAME,E_MAIL,QUICK_NAME,ID_MEMBER) VALUES('"+name+"','"+surname+"','"+company+"','"+mail+"','"+quickname+"','"+id+"');";

    int myresult_add_contract = stmt.executeUpdate(sql_add_contract);
	response.sendRedirect("my_contract.jsp");
%>
</body>
</html>
