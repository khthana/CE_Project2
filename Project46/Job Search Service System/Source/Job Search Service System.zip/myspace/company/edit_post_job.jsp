<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Edit Post Job</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>

</head>

<body leftmargin="0" topmargin="0"  rightmargin="0" onLoad="MM_preloadImages('Menu_My_Profile_2.gif','Menu_My_Resume_2.gif','Menu_My_Contract_2.gif','Menu_My_History_2.gif','Menu_Webboard_2.gif','Menu_Mail_2.gif','Menu_Jobs_2.gif','Menu_News_2.gif','Menu_Private_Message_2.gif','Menu_E_mail_2.gif','Menu_Agent_2.gif','Menu_Search_2.gif','image/Menu_My_Interview_2.gif')">
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>

<%
String name = "";
String surname = "";
String sql_name = "select NAME,SURNAME from member where ID = '"+id+"'";
ResultSet myresult_name = stmt.executeQuery(sql_name);
while(myresult_name.next())
{ 
	name = myresult_name.getString("NAME"); 
	surname = myresult_name.getString("SURNAME"); 
}
     myresult_name.close();
%>
<div id="Layer1" style="position:absolute; left:17px; top:112px; width:261px; height:22px; z-index:1" class="style4">
<div align="center" class="style5"><%=name+"   "+surname%></div>
</div>
<div id="Layer2" style="position:absolute; left:421px; top:170px; width:90px; height:23px; z-index:2"><a href="my_profile.jsp" target="_self" onMouseOver="MM_swapImage('MyProfile','','image/Menu_My_Profile_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Profile.gif" alt="My Profile" name="MyProfile" width="90" height="23" border="0"></a></div>
<div id="Layer3" style="position:absolute; left:570px; top:165px; width:90px; height:23px; z-index:3"><a href="my_recruitment.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('recruitment','','image/Menu_My_Recruitment_2.gif',1)"><img src="image/Menu_My_Recruitment.gif" alt="Recruitment" name="recruitment" width="105" height="26" border="0"></a></div>
<div id="Layer4" style="position:absolute; left:734px; top:170px; width:89px; height:23px; z-index:4"><a href="my_contract.jsp" target="_self" onMouseOver="MM_swapImage('MyContract','','image/Menu_My_Contract_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Contract.gif" alt="My Contract" name="MyContract" width="89" height="23" border="0"></a></div>
<div id="Layer5" style="position:absolute; left:892px; top:170px; width:89px; height:23px; z-index:5"><a href="my_history.jsp" target="_self" onMouseOver="MM_swapImage('MyHistory','','image/Menu_My_History_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_History.gif" alt="My History" name="MyHistory" width="89" height="23" border="0"></a></div>
<div id="Layer6" style="position:absolute; left:17px; top:246px; width:135px; height:27px; z-index:6"><img src="image/Menu_Information.gif" width="135" height="27"></div>
<div id="Layer7" style="position:absolute; left:30px; top:333px; width:74px; height:24px; z-index:7"><img src="image/Menu_Compose.gif" width="74" height="24"></div>
<div id="Layer8" style="position:absolute; left:30px; top:415px; width:47px; height:24px; z-index:8"><img src="image/Menu_Help.gif" width="47" height="24"></div>
<div id="Layer10" style="position:absolute; left:15px; top:359px; width:161px; height:23px; z-index:10"><a href="private_message.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Private_Message','','image/Menu_Private_Message_2.gif',1)"><img src="image/Menu_Private_Message.gif" alt="Private Message" name="Private_Message" width="161" height="23" border="0"></a></div>
<div id="Layer11" style="position:absolute; left:16px; top:388px; width:161px; height:23px; z-index:11"><a href="e_mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E-Mail','','image/Menu_E_mail_2.gif',1)"><img src="image/Menu_E_mail.gif" alt="E-Mail" name="E-Mail" width="161" height="23" border="0"></a></div>
<div id="Layer12" style="position:absolute; left:15px; top:443px; width:161px; height:23px; z-index:12"><a href="agent.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agent','','image/Menu_Agent_2.gif',1)"><img src="image/Menu_Agent.gif" alt="Agent" name="Agent" width="161" height="23" border="0"></a></div>
<div id="Layer13" style="position:absolute; left:15px; top:470px; width:161px; height:23px; z-index:13"><a href="search.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Search','','image/Menu_Search_2.gif',1)"><img src="image/Menu_Search.gif" alt="Search" name="Search" width="161" height="23" border="0"></a></div>
<div id="Layer14" style="position:absolute; left:15px; top:271px; width:161px; height:23px; z-index:14"><a href="mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mail','','image/Menu_Mail_2.gif',1)"><img src="image/Menu_Mail.gif" alt="Mail" name="Mail" width="161" height="23" border="0"></a></div>
<div id="Layer15" style="position:absolute; left:15px; top:295px; width:161px; height:23px; z-index:15"><a href="jobs.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Jobs','','image/Menu_Jobs_2.gif',1)"><img src="image/Menu_Jobs.gif" alt="Jobs" name="Jobs" width="161" height="23" border="0"></a></div>
<div id="Layer9" style="position:absolute; left:30px; top:512px; width:74px; height:24px; z-index:17"><a href="post_job.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('post_job','','image/Menu_Post_job_2.gif',1)"><img src="image/Menu_Post_job.gif" alt="Post Job" name="post_job" width="74" height="24" border="0"></a></div>
<div id="Layer90" style="position:absolute; left:30px; top:558px; width:81px; height:24px; z-index:17"><a href="boardlist.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('webboard','','../administrator/image/Menu_Webboard_2.gif',1)"><img src="../administrator/image/Menu_Webboard.gif" alt="Webboard" name="webboard" width="81" height="24" border="0"></a></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" height="150" valign="top"><img src="image/Head_Left.jpg" width="280" height="150"></td>
    <td width="80%" height="150" valign="top"><img src="image/Head_Center.jpg" width="100%" height="150"></td>
    <td width="10%" height="150" valign="top"><img src="image/Head_Right.jpg" width="345" height="150"></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="70" width="90%" valign="top"><img src="image/My.jpg" width="930" height="70"></td>
    <td height="70" width="10%" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="220" height="371" rowspan="9" valign="top"><img src="image/Menu_BG.jpg" width="220" height="371"></td>
    <td width="0" height="371" rowspan="9" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td  height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="100%" height="371" rowspan="9">&nbsp;</td>
  </tr>
  <tr>
    <td width="20"  height="12"><img src="image/K_conner_top_left.jpg" width="20" height="12"></td>
    <td width="650"  height="12"><img src="image/K_conner_top_center.jpg" width="710" height="12"></td>
    <td width="40"  height="12"><img src="image/K_conner_top_right.jpg" width="40" height="12"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_top.jpg" width="20" height="20"></td>
    <td width="784" rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0">
      <tr>
        <td align="right"><img src="image/Titel_post_job.jpg" width="453" height="35"></td>
      </tr>
      <tr>
        <td align="left">
		
		
		
		
		
		







		
		<%
String post_job = request.getParameter("post_job");
String edit = request.getParameter("edit");
String delete = request.getParameter("delete");



if (edit != null)
{
	
StringTokenizer st_c_software;
StringTokenizer st_c_hardware;
StringTokenizer st_c_network;
StringTokenizer st_c_database;
StringTokenizer st_c_os;
int num_c_software= 0;
int num_c_hardware= 0;
int num_c_network= 0;
int num_c_database= 0;
int num_c_os= 0;
String[ ] sc_software ;
String[ ] sc_hardware ;
String[ ] sc_network ;
String[ ] sc_database ;
String[ ] sc_os ;
String c_software="",c_hardware="",c_network="",c_database="",c_os="";
int i = 0;

int num_namejob = 0;
ResultSet myresult_num_namejob = stmt.executeQuery("select count(*) AS num from name_job");
while(myresult_num_namejob.next())
{ 		num_namejob = myresult_num_namejob.getInt("num");  }
     myresult_num_namejob.close();
String [ ] name_job = new String [num_namejob];
ResultSet myresult_namejob = stmt.executeQuery("select *  from name_job");
while(myresult_namejob.next())
{ 		name_job[myresult_namejob.getInt("ID")-1] = myresult_namejob.getString("NAME");  }
     myresult_namejob.close();


	String sql_post_job = "select * from job where ID = '"+post_job+"' ";
     ResultSet myresult_post_job= stmt.executeQuery(sql_post_job);
	 while(myresult_post_job.next())
	        {  
					 	    c_software = myresult_post_job.getString("SOFTWARE");
							c_hardware = myresult_post_job.getString("HARDWARE");
							 c_database = myresult_post_job.getString("DB");
							 c_os = myresult_post_job.getString("OS");
							c_network = myresult_post_job.getString("NETWORK");

							st_c_software = new StringTokenizer(c_software,",");
							num_c_software = st_c_software.countTokens();
							sc_software= new String[num_c_software];
							for (i = 0; i<num_c_software; i++)
							{ sc_software[i] = new String (st_c_software.nextToken()); }

							st_c_hardware = new StringTokenizer(c_hardware,",");
							num_c_hardware = st_c_hardware.countTokens();
							sc_hardware= new String[num_c_hardware];
							for (i = 0; i<num_c_hardware; i++)
							{ sc_hardware[i] = new String (st_c_hardware.nextToken()); }

							st_c_network = new StringTokenizer(c_network,",");
							num_c_network = st_c_network.countTokens();
							sc_network= new String[num_c_network];
							for (i = 0; i<num_c_network; i++)
							{ sc_network[i] = new String (st_c_network.nextToken()); }

							st_c_database = new StringTokenizer(c_database,",");
							num_c_database = st_c_database.countTokens();
							sc_database= new String[num_c_database];
							for (i = 0; i<num_c_database; i++)
							{ sc_database[i] = new String (st_c_database.nextToken()); }
							
							st_c_os = new StringTokenizer(c_os,",");
							num_c_os = st_c_os.countTokens();
							sc_os= new String[num_c_os];
							for (i = 0; i<num_c_os; i++)
							{ sc_os[i] = new String (st_c_os.nextToken()); }			  
    
			  
			  %>

<form action="update_post_job.jsp" method="post" name="update_post_job">
<input name="hidden_id_post_job" type="hidden" value="<%=post_job%>">
 <table width="700" border="0" class="style1">
    <tr align="left">
      <td colspan="2"><u><b>Edit Job</b></u></td>
    </tr>
    <tr align="left">
      <td width="120">Name Job </td>
      <td width="570">:&nbsp;
      <input name="name_job" type="text" id="name_job" size="20" maxlength="50" value="<%=myresult_post_job.getString("NAME_JOB")%>"></td>
      </tr>
       <tr align="left">
      <td>Position</td>
      <td>:&nbsp;&nbsp;<select name="position">
      <option value="<%=myresult_post_job.getString("POSITION")%>"><%=myresult_post_job.getString("POSITION")%></option>
	  <%for ( i=0; i < num_namejob; i++)	{  out.print("<option value="+name_job[i]+">"+name_job[i]+"</option>" ); }%>
    </select></td>
      </tr>
	   <tr align="left">
      <td>Sex</td>
      <td>:&nbsp;&nbsp;<select name="sex" id="sex">
		 <option value="<%=myresult_post_job.getString("SEX")%>"><%=myresult_post_job.getString("SEX")%></option>
        <option value="Male/Female">Male/Female</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select></td>
      </tr>
	   <tr align="left">
      <td>Age (Not Over)</td>
      <td>:&nbsp;
      <input name="age" type="text" id="age" size="2" maxlength="2"  value="<%=myresult_post_job.getString("AGE")%>"></td>
      </tr>
    <tr align="left">
      <td>Qualification</td>
      <td>:&nbsp;&nbsp;<select name="qualification" id="qualification">
        <option value="<%=myresult_post_job.getString("QUALIFICATION")%>"><%=myresult_post_job.getString("QUALIFICATION")%></option>
		<option value="Bachelor">Bachelor</option>
        <option value="Master">Master</option>
        <option value="Doctor">Doctor</option>
      </select></td>
      </tr>
	  <tr align="left">
      <td>Job Type</td>
      <td>:&nbsp;<input name="job_type" type="radio" value="Full Time" <%if (myresult_post_job.getString("FULL_PART").equals("Full Time")) {out.print("checked");}%>>
      Full Time&nbsp;&nbsp;&nbsp;&nbsp;
	  <input name="job_type" type="radio" value="Part Time" <%if (myresult_post_job.getString("FULL_PART").equals("Part Time")) {out.print("checked");}%>>
	  Part Time</td>
      </tr>    
	   <tr align="left">
      <td>Salary</td>
      <td>:&nbsp;
      <input name="salary" type="text" id="salary" size="8" maxlength="8" value="<%=myresult_post_job.getString("SALARY")%>"></td>
      </tr>
	   <tr align="left">
      <td>Experience</td>
      <td>:&nbsp;
      <input name="experience" type="text" id="experience" size="2" maxlength="2" value="<%=myresult_post_job.getString("EXPERIENCE")%>"></td>
      </tr>	
	  <tr align="left">
	    <td>GPA (Not Lower) </td>
          <td>:&nbsp;
      <input name="gpa" type="text" id="gpa" size="4" maxlength="4" value="<%=myresult_post_job.getString("GPA")%>"></td>
      </tr>
	  <tr align="left">
    <td class="style1">Language </td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;
	 English&nbsp;&nbsp;&nbsp;
	 <input name="english" type="radio" value="2"  <%if (myresult_post_job.getInt("ENGLISH") == 2) {out.print("checked");}%>>
	 Fluent&nbsp;&nbsp;
	 <input name="english" type="radio" value="1"  <%if (myresult_post_job.getInt("ENGLISH") == 1) {out.print("checked");}%>>
	 Fair&nbsp;&nbsp;
	 <input name="english" type="radio" value="0"  <%if (myresult_post_job.getInt("ENGLISH") == 0) {out.print("checked");}%>>
	 Poor&nbsp;&nbsp;
	 <input name="english" type="radio" value="-1"  <%if (myresult_post_job.getInt("ENGLISH") == -1) {out.print("checked");}%>>
	 Can't</td>
  </tr>
   <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;
	 Japan&nbsp;&nbsp;&nbsp;&nbsp;
	 <input name="japan" type="radio" value="2" <%if (myresult_post_job.getInt("JAPAN") == 2) {out.print("checked");}%>>
	 Fluent&nbsp;&nbsp;
	 <input name="japan" type="radio" value="1" <%if (myresult_post_job.getInt("JAPAN") == 1) {out.print("checked");}%>>
	 Fair&nbsp;&nbsp;
	 <input name="japan" type="radio" value="0" <%if (myresult_post_job.getInt("JAPAN") == 0) {out.print("checked");}%>>
	 Poor&nbsp;&nbsp;
	 <input name="japan" type="radio" value="-1" <%if (myresult_post_job.getInt("JAPAN") == -1) {out.print("checked");}%>>
	 Can't</td>
  </tr>
   <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;
	 Chinese&nbsp;&nbsp;
	 <input name="chinese" type="radio" value="2" <%if (myresult_post_job.getInt("CHINESE") == 2) {out.print("checked");}%>>
	 Fluent&nbsp;&nbsp;
	 <input name="chinese" type="radio" value="1" <%if (myresult_post_job.getInt("CHINESE") == 1){out.print("checked");}%>>
	 Fair&nbsp;&nbsp;
	 <input name="chinese" type="radio" value="0" <%if (myresult_post_job.getInt("CHINESE") == 0) {out.print("checked");}%>>
	 Poor&nbsp;&nbsp;
	 <input name="chinese" type="radio" value="-1" <%if (myresult_post_job.getInt("CHINESE") == -1) {out.print("checked");}%>>
	 Can't</td>
  </tr>
   <tr align="left">
    <td class="style1">Knowledge</td>
    <td colspan="3" valign="middle" class="style3">&nbsp;&nbsp;      </td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;&nbsp;-Software</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp; 
		<input type="checkbox" name="software" value=".COM"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals(".COM")) { out.print("checked"); }  }
			%>>.COM&nbsp;
        <input type="checkbox" name="software" value=".NET"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals(".NET")) { out.print("checked"); }  }
			%>>.NET&nbsp;
		<input type="checkbox" name="software" value="ActiveX"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("ActiveX")) { out.print("checked"); }  }
			%>>ActiveX&nbsp;
		<input type="checkbox" name="software" value="ASP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("ASP")) { out.print("checked"); }  }
			%>>ASP&nbsp;
		<input type="checkbox" name="software" value="C/C++"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("C/C++")) { out.print("checked"); }  }
			%>>C/C++&nbsp;
		<input type="checkbox" name="software" value="COBOL"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("COBOL")) { out.print("checked"); }  }
			%>>COBOL&nbsp;
		<input type="checkbox" name="software" value="Delphi"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Delphi")) { out.print("checked"); }  }
			%>>Delphi&nbsp;
		</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="software" value="EJB"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("EJB")) { out.print("checked"); }  }
			%>>EJB&nbsp;
	<input type="checkbox" name="software" value="Foxpro"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Foxpro")) { out.print("checked"); }  }
			%>>Foxpro&nbsp;
	<input type="checkbox" name="software" value="Graphic Design"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Graphic Design")) { out.print("checked"); }  }
			%>>Graphic Design&nbsp;
	<input type="checkbox" name="software" value="Java(J2SE/J2EE)"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Java(J2SE/J2EE)")) { out.print("checked"); }  }
			%>>Java(J2SE/J2EE)&nbsp;
	<input type="checkbox" name="software" value="JSP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("JSP")) { out.print("checked"); }  }
			%>>JSP&nbsp;
	</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="software" value="OOP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("OOP")) { out.print("checked"); }  }
			%>>OOP&nbsp;
	<input type="checkbox" name="software" value="Perl/Unix"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Perl/Unix")) { out.print("checked"); }  }
			%>>Perl/Unix&nbsp;
	<input type="checkbox" name="software" value="PHP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("PHP")) { out.print("checked"); }  }
			%>>PHP&nbsp;
	<input type="checkbox" name="software" value="SAP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("SAP")) { out.print("checked"); }  }
			%>>SAP&nbsp;
	<input type="checkbox" name="software" value="SOAP"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("SOAP")) { out.print("checked"); }  }
			%>>SOAP&nbsp;
	<input type="checkbox" name="software" value="UML"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("UML")) { out.print("checked"); }  }
			%>>UML&nbsp;
	<input type="checkbox" name="software" value="VC++"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("VC++")) { out.print("checked"); }  }
			%>>VC++&nbsp;
	</td>
	  
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="software" value="Web Technology"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("Web Technology")) { out.print("checked"); }  }
			%>>Web Technology&nbsp;
	<input type="checkbox" name="software" value="XML/XSL"<%
			for (i = 0; i<num_c_software; i++)
				{ if (sc_software[i].equals("XML/XSL")) { out.print("checked"); }  }
			%>>XML/XSL&nbsp;
	</td>
	  
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">&nbsp;</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;&nbsp;-Hardware</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="hardware" value="COM86"<%
			for (i = 0; i<num_c_hardware; i++)
				{ if (sc_hardware[i].equals("COM86")) { out.print("checked"); }  }
			%>>COM86&nbsp;
	<input type="checkbox" name="hardware" value="FPGA/CPLD"<%
			for (i = 0; i<num_c_hardware; i++)
				{ if (sc_hardware[i].equals("FPGA/CPLD")) { out.print("checked"); }  }
			%>>FPGA/CPLD&nbsp;
	<input type="checkbox" name="hardware" value="MCS-51"<%
			for (i = 0; i<num_c_hardware; i++)
				{ if (sc_hardware[i].equals("MCS-51")) { out.print("checked"); }  }
			%>>MCS-51&nbsp;
	</td>
  </tr>
    <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="hardware" value="PIC"<%
			for (i = 0; i<num_c_hardware; i++)
				{ if (sc_hardware[i].equals("PIC")) { out.print("checked"); }  }
			%>>PIC&nbsp;
	<input type="checkbox" name="hardware" value="Security devices (VPNs, firewalls, NIDs)"<%
			for (i = 0; i<num_c_hardware; i++)
				{ if (sc_hardware[i].equals("Security devices (VPNs, firewalls, NIDs)")) { out.print("checked"); }  }
			%>>Security devices (VPNs, firewalls, NIDs)&nbsp;
	</td>
  </tr>
    <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">&nbsp;</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;&nbsp;-Network</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="network" value="ATM"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("ATM")) { out.print("checked"); }  }
			%>>ATM&nbsp;
	<input type="checkbox" name="network" value="Data Communication"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("Data Communication")) { out.print("checked"); }  }
			%>>Data Communication&nbsp;
	<input type="checkbox" name="network" value="Distributed system"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("Distributed system")) { out.print("checked"); }  }
			%>>Distributed system&nbsp;
	<input type="checkbox" name="network" value="DNS"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("DNS")) { out.print("checked"); }  }
			%>>DNS&nbsp;
	</td>
  </tr>
    <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="network" value="Firewall"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("Firewall")) { out.print("checked"); }  }
			%>>Firewall&nbsp;
	<input type="checkbox" name="network" value="IDS"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("IDS")) { out.print("checked"); }  }
			%>>IDS&nbsp;
	<input type="checkbox" name="network" value="LAN/WAN"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("LAN/WAN")) { out.print("checked"); }  }
			%>">LAN/WAN&nbsp;
	<input type="checkbox" name="network" value="Network security"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("Network security")) { out.print("checked"); }  }
			%>>Network security&nbsp;
	<input type="checkbox" name="network" value="Proxy Server"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("Proxy Server")) { out.print("checked"); }  }
			%>>Proxy Server&nbsp;
	</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="network" value="TCP/IP"<%
			for (i = 0; i<num_c_network; i++)
				{ if (sc_network[i].equals("TCP/IP")) { out.print("checked"); }  }
			%>>TCP/IP&nbsp;
	</td>
  </tr>
    <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">&nbsp;</td>
  </tr>
  <tr align="left">
    <td class="style1">&nbsp;&nbsp;-Database</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="db" value="Access"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("Access")) { out.print("checked"); }  }
			%>>Access&nbsp;
	<input type="checkbox" name="db" value="DB2"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("DB2")) { out.print("checked"); }  }
			%>>DB2&nbsp;
	<input type="checkbox" name="db" value="Informix"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("Informix")) { out.print("checked"); }  }
			%>>Informix&nbsp;
	<input type="checkbox" name="db" value="Mysql"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("Mysql")) { out.print("checked"); }  }
			%>>Mysql&nbsp;
	</td>
  </tr>
    <tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="db" value="Oracle"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("Oracle")) { out.print("checked"); }  }
			%>>Oracle&nbsp;
	<input type="checkbox" name="db" value="PL/SQL"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("PL/SQL")) { out.print("checked"); }  }
			%>>PL/SQL&nbsp;
	<input type="checkbox" name="db" value="SQL Server 2000"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("SQL Server 2000")) { out.print("checked"); }  }
			%>>SQL Server 2000&nbsp;
	<input type="checkbox" name="db" value="Sybase"<%
			for (i = 0; i<num_c_database; i++)
				{ if (sc_database[i].equals("Sybase")) { out.print("checked"); }  }
			%>>Sybase&nbsp;
	</td>
	<tr align="left">
    <td class="style1">&nbsp;</td>
    <td colspan="3" valign="middle" class="style3">&nbsp;</td>
  </tr>
   <tr align="left">
    <td class="style1">&nbsp;&nbsp;-OS</td>
    <td colspan="3" valign="middle" class="style3">:&nbsp;&nbsp;
	<input type="checkbox" name="os" value="HP-UX"<%
			for (i = 0; i<num_c_os; i++)
				{ if (sc_os[i].equals("HP-UX")) { out.print("checked"); }  }
			%>>HP-UX&nbsp;
	<input type="checkbox" name="os" value="Linux"<%
			for (i = 0; i<num_c_os; i++)
				{ if (sc_os[i].equals("Linux")) { out.print("checked"); }  }
			%>>Linux&nbsp;
	<input type="checkbox" name="os" value="Sun/Solaris"<%
			for (i = 0; i<num_c_os; i++)
				{ if (sc_os[i].equals("Sun/Solaris")) { out.print("checked"); }  }
			%>>Sun/Solaris&nbsp;
	<input type="checkbox" name="os" value="UNIX"<%
			for (i = 0; i<num_c_os; i++)
				{ if (sc_os[i].equals("UNIX")) { out.print("checked"); }  }
			%>>UNIX&nbsp;
	<input type="checkbox" name="os" value="Windows Server 2003"<%
			for (i = 0; i<num_c_os; i++)
				{ if (sc_os[i].equals("Windows Server 2003")) { out.print("checked"); }  }
			%>>Windows Server 2003&nbsp;
	</td>
   </tr>
	  <tr align="left">
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input type="submit" name="Submit" value="Update"></td>
      </tr>
  </table>

	<%
	 }
     myresult_post_job.close();
}
	 %>

<%
if (delete != null)
{ 
	 String sql_delete = "delete from job where ID = '"+post_job+"' ";
	 int myresult_delete = stmt.executeUpdate(sql_delete);   
	 response.sendRedirect("post_job.jsp");
}
%>

</form>	</td>
      </tr>

    </table></td>
    <td width="35" height="20"><img src="image/K_middel_top2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td width="20" height="249"><img src="image/K_middel_center.jpg" width="20" height="860"></td>
    <td width="40" height="249"><img src="image/K_middel_center2.jpg" width="40" height="860"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_bottom.jpg" width="20" height="20"></td>
    <td width="40" height="20"><img src="image/K_middel_bottom2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td height="30" width="20"><img src="image/K_conner_bottom_left.jpg" width="20" height="30"></td>
    <td height="30" width="650"><img src="image/K_conner_bottom_center.jpg" width="710" height="30"></td>
    <td height="30" width="40"><img src="image/K_conner_bottom_right.jpg" width="40" height="30"></td>
  </tr>
  
  <tr>
    <td height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Left.jpg" width="440" height="15"></td>
    <td width="80%" valign="top" height="15"><img src="image/Tail_Center.jpg" width="100%" height="15"></td>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Right.jpg" width="165" height="15"></td>
  </tr>
</table>
</body>
</html>
