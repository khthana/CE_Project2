<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add My Profile</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String name = request.getParameter("name");
String location = request.getParameter("location");
String telephone = request.getParameter("telephone");
String e_mail = request.getParameter("e_mail");
String contract = request.getParameter("contract");
String detail = request.getParameter("detail");
 

	 String sql_add_profile = "update member set NAME='"+name+"',LOCATION='"+location+"',TELEPHONE='"+telephone+"',E_MAIL='"+e_mail+"',CONTRACT='"+contract+"',DETAIL='"+detail+"'   where ID = '"+id+"' ";
     int myresult_add_profile = stmt.executeUpdate(sql_add_profile);
	 response.sendRedirect("my_profile.jsp");
%>
</body>
</html>
