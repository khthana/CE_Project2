<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>My Contract</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
</head>

<body leftmargin="0" topmargin="0"  rightmargin="0" onLoad="MM_preloadImages('Menu_My_Profile_2.gif','Menu_My_Resume_2.gif','Menu_My_Contract_2.gif','Menu_My_History_2.gif','Menu_Webboard_2.gif','Menu_Mail_2.gif','Menu_Jobs_2.gif','Menu_News_2.gif','Menu_Private_Message_2.gif','Menu_E_mail_2.gif','Menu_Agent_2.gif','Menu_Search_2.gif','image/Menu_My_Interview_2.gif')">
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>

<%
String name = "";
String surname = "";
String sql_name = "select NAME,SURNAME from member where ID = '"+id+"'";
ResultSet myresult_name = stmt.executeQuery(sql_name);
while(myresult_name.next())
{ 
	name = myresult_name.getString("NAME"); 
	surname = myresult_name.getString("SURNAME"); 
}
     myresult_name.close();
%>
<div id="Layer1" style="position:absolute; left:17px; top:112px; width:261px; height:22px; z-index:1" class="style4">
<div align="center" class="style5"><%=name+"   "+surname%></div>
</div>
<div id="Layer2" style="position:absolute; left:421px; top:170px; width:90px; height:23px; z-index:2"><a href="my_profile.jsp" target="_self" onMouseOver="MM_swapImage('MyProfile','','image/Menu_My_Profile_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Profile.gif" alt="My Profile" name="MyProfile" width="90" height="23" border="0"></a></div>
<div id="Layer3" style="position:absolute; left:570px; top:165px; width:90px; height:23px; z-index:3"><a href="my_recruitment.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('recruitment','','image/Menu_My_Recruitment_2.gif',1)"><img src="image/Menu_My_Recruitment.gif" alt="Recruitment" name="recruitment" width="105" height="26" border="0"></a></div>
<div id="Layer4" style="position:absolute; left:734px; top:170px; width:89px; height:23px; z-index:4"><a href="my_contract.jsp" target="_self" onMouseOver="MM_swapImage('MyContract','','image/Menu_My_Contract_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Contract.gif" alt="My Contract" name="MyContract" width="89" height="23" border="0"></a></div>
<div id="Layer5" style="position:absolute; left:892px; top:170px; width:89px; height:23px; z-index:5"><a href="my_history.jsp" target="_self" onMouseOver="MM_swapImage('MyHistory','','image/Menu_My_History_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_History.gif" alt="My History" name="MyHistory" width="89" height="23" border="0"></a></div>
<div id="Layer6" style="position:absolute; left:17px; top:246px; width:135px; height:27px; z-index:6"><img src="image/Menu_Information.gif" width="135" height="27"></div>
<div id="Layer7" style="position:absolute; left:30px; top:333px; width:74px; height:24px; z-index:7"><img src="image/Menu_Compose.gif" width="74" height="24"></div>
<div id="Layer8" style="position:absolute; left:30px; top:415px; width:47px; height:24px; z-index:8"><img src="image/Menu_Help.gif" width="47" height="24"></div>
<div id="Layer10" style="position:absolute; left:15px; top:359px; width:161px; height:23px; z-index:10"><a href="private_message.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Private_Message','','image/Menu_Private_Message_2.gif',1)"><img src="image/Menu_Private_Message.gif" alt="Private Message" name="Private_Message" width="161" height="23" border="0"></a></div>
<div id="Layer11" style="position:absolute; left:16px; top:388px; width:161px; height:23px; z-index:11"><a href="e_mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E-Mail','','image/Menu_E_mail_2.gif',1)"><img src="image/Menu_E_mail.gif" alt="E-Mail" name="E-Mail" width="161" height="23" border="0"></a></div>
<div id="Layer12" style="position:absolute; left:15px; top:443px; width:161px; height:23px; z-index:12"><a href="agent.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agent','','image/Menu_Agent_2.gif',1)"><img src="image/Menu_Agent.gif" alt="Agent" name="Agent" width="161" height="23" border="0"></a></div>
<div id="Layer13" style="position:absolute; left:15px; top:470px; width:161px; height:23px; z-index:13"><a href="search.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Search','','image/Menu_Search_2.gif',1)"><img src="image/Menu_Search.gif" alt="Search" name="Search" width="161" height="23" border="0"></a></div>
<div id="Layer14" style="position:absolute; left:15px; top:271px; width:161px; height:23px; z-index:14"><a href="mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mail','','image/Menu_Mail_2.gif',1)"><img src="image/Menu_Mail.gif" alt="Mail" name="Mail" width="161" height="23" border="0"></a></div>
<div id="Layer15" style="position:absolute; left:15px; top:295px; width:161px; height:23px; z-index:15"><a href="jobs.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Jobs','','image/Menu_Jobs_2.gif',1)"><img src="image/Menu_Jobs.gif" alt="Jobs" name="Jobs" width="161" height="23" border="0"></a></div>
<div id="Layer9" style="position:absolute; left:30px; top:512px; width:74px; height:24px; z-index:17"><a href="post_job.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('post_job','','image/Menu_Post_job_2.gif',1)"><img src="image/Menu_Post_job.gif" alt="Post Job" name="post_job" width="74" height="24" border="0"></a></div>
<div id="Layer90" style="position:absolute; left:30px; top:558px; width:81px; height:24px; z-index:17"><a href="boardlist.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('webboard','','../administrator/image/Menu_Webboard_2.gif',1)"><img src="../administrator/image/Menu_Webboard.gif" alt="Webboard" name="webboard" width="81" height="24" border="0"></a></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" height="150" valign="top"><img src="image/Head_Left.jpg" width="280" height="150"></td>
    <td width="80%" height="150" valign="top"><img src="image/Head_Center.jpg" width="100%" height="150"></td>
    <td width="10%" height="150" valign="top"><img src="image/Head_Right.jpg" width="345" height="150"></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="70" width="90%" valign="top"><img src="image/My.jpg" width="930" height="70"></td>
    <td height="70" width="10%" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="220" height="371" rowspan="9" valign="top"><img src="image/Menu_BG.jpg" width="220" height="371"></td>
    <td width="0" height="371" rowspan="9" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td  height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="100%" height="371" rowspan="9">&nbsp;</td>
  </tr>
  <tr>
    <td width="20"  height="12"><img src="image/K_conner_top_left.jpg" width="20" height="12"></td>
    <td width="650"  height="12"><img src="image/K_conner_top_center.jpg" width="650" height="12"></td>
    <td width="40"  height="12"><img src="image/K_conner_top_right.jpg" width="40" height="12"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_top.jpg" width="20" height="20"></td>
    <td width="784" rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0">
      <tr>
        <td align="right"><img src="image/Titel_my_contract.jpg" width="459" height="35"></td>
      </tr>
      <tr>
        <td align="center">
		
		
		
		
		
		
		
		<form action="add_my_contract.jsp" method="post" name="form_add_contract" onSubmit="MM_validateForm('name','','R','surname','','R','company','','R','mail','','RisEmail','quickname','','R');return document.MM_returnValue">
  <table width="500" border="0" class="style1">
    <tr align="left">
      <td colspan="4"><u><b>Add Contact</b></u></td>
    </tr>
    <tr align="left">
      <td width="80">Name</td>
      <td width="170">:&nbsp;
      <input name="name" type="text" id="name" size="20" maxlength="50"></td>
      <td width="80">Surname</td>
      <td width="170">:&nbsp;
      <input name="surname" type="text" id="surname" size="20" maxlength="50"></td>
    </tr>
    <tr align="left">
      <td>Company</td>
      <td>:&nbsp;
      <input name="company" type="text" id="company" size="20" maxlength="50"></td>
      <td>Mail</td>
      <td>:&nbsp;
      <input name="mail" type="text" id="mail" size="20" maxlength="20"></td>
    </tr>
    <tr align="left">
      <td>Quickname</td>
      <td>:&nbsp;
      <input name="quickname" type="text" id="quickname" size="20" maxlength="20"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left">
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input type="submit" name="Submit" value="  Add  "></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>


<form name="form_my_contract" method="post" action="edit_my_contract.jsp">
  <table width="500" border="0" class="style1">
    <tr>
      <td height="29" align="left"><u><b>My Contact</b></u></td>
    </tr>
    <tr>
      <td align="left">
	  <select name="my_contract" size="5" id="my_contract">
          <%
				String sql_mycontract = "select ID,FIRST_NAME,LAST_NAME,COMPANY_NAME,E_MAIL,QUICK_NAME from mycontact where ID_MEMBER = '"+id+"' order by `ID` DESC ";
				ResultSet myresult_mycontract = stmt.executeQuery(sql_mycontract);
				while(myresult_mycontract.next())
					{ %>
						<option value="<%=myresult_mycontract.getString("ID")%>"><%=myresult_mycontract.getString("QUICK_NAME")%></option>
					   <%
					}
				myresult_mycontract.close();		  
		  %>
      </select></td>
    </tr>
    <tr>
      <td align="left"><input name="edit" type="submit" id="edit" value="  Edit  ">
	  &nbsp;&nbsp;&nbsp;<input name="delete" type="submit" id="delete" value="Delete">	  </td>
    </tr>
  </table>
</form>		










	</td>
      </tr>

    </table></td>
    <td width="35" height="20"><img src="image/K_middel_top2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td width="20" height="249"><img src="image/K_middel_center.jpg" width="20" height="345"></td>
    <td width="40" height="249"><img src="image/K_middel_center2.jpg" width="40" height="345"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_bottom.jpg" width="20" height="20"></td>
    <td width="40" height="20"><img src="image/K_middel_bottom2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td height="30" width="20"><img src="image/K_conner_bottom_left.jpg" width="20" height="30"></td>
    <td height="30" width="650"><img src="image/K_conner_bottom_center.jpg" width="650" height="30"></td>
    <td height="30" width="40"><img src="image/K_conner_bottom_right.jpg" width="40" height="30"></td>
  </tr>
  
  <tr>
    <td height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Left.jpg" width="440" height="15"></td>
    <td width="80%" valign="top" height="15"><img src="image/Tail_Center.jpg" width="100%" height="15"></td>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Right.jpg" width="165" height="15"></td>
  </tr>
</table>
</body>
</html>
