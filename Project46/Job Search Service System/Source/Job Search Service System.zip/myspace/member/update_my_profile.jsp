<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add My Profile</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String location = request.getParameter("location");
String telephone = request.getParameter("telephone");
String city = request.getParameter("city");
String code = request.getParameter("code");
String e_mail = request.getParameter("e_mail");

String company1 = request.getParameter("company1");
String company2 = request.getParameter("company2");
String company3 = request.getParameter("company3");
String year1 = request.getParameter("year1");
String year2 = request.getParameter("year2");
String year3 = request.getParameter("year3");
String s_year1 = request.getParameter("s_year1");
String s_year2 = request.getParameter("s_year2");
String s_year3 = request.getParameter("s_year3");
String u_year1 = request.getParameter("u_year1");
String u_year2 = request.getParameter("u_year2");
String u_year3 = request.getParameter("u_year3");
String position1 = request.getParameter("position1");
String position2 = request.getParameter("position2");
String position3 = request.getParameter("position3");
String english = request.getParameter("english");
String japan = request.getParameter("japan");
String chinese = request.getParameter("chinese");
String [] software = request.getParameterValues("software");
String [] hardware = request.getParameterValues("hardware");
String [] network = request.getParameterValues("network");
String [] db = request.getParameterValues("db");
String [] os = request.getParameterValues("os");

String all_software = "";
String all_hardware = "";
String all_network = "";
String all_db = "";
String all_os = "";
/*out.println(english);
out.println(japan);
out.println(chinese);*/

int i = 0;

if ( software != null )
{    for ( i=0; i<software.length; i++)
			{  all_software = all_software+software[i]+","; }
	 all_software = all_software + "-";
 }
 else
 {  all_software = "-"; }
 

if ( hardware != null )
{    for ( i=0; i<hardware.length; i++)
			{  all_hardware = all_hardware+hardware[i]+","; }
	 all_hardware = all_hardware + "-";
 }
 else
 {  all_hardware = "-"; }

if ( network != null )
{    for ( i=0; i<network.length; i++)
			{  all_network = all_network+network[i]+","; }
	 all_network = all_network + "-";
 }
 else
 {  all_network = "-"; }

 if ( db != null )
{    for ( i=0; i<db.length; i++)
			{  all_db = all_db+db[i]+","; }
	 all_db = all_db + "-";
 }
 else
 {  all_db = "-"; }

 if ( os != null )
{    for ( i=0; i<os.length; i++)
			{  all_os = all_os+os[i]+","; }
	 all_os = all_os + "-";
 }
 else
 {  all_os = "-"; }

/*out.println(all_software);out.println("<br>");
out.println(all_hardware);out.println("<br>");
out.println(all_network);out.println("<br>");
out.println(all_db);out.println("<br>");
out.println(all_os);out.println("<br>");
*/
	 String sql_add_profile = "update member set LOCATION='"+location+"' ,ENGLISH='"+english+"',JAPAN='"+japan+"',CHINESE='"+chinese+"',TELEPHONE='"+telephone+"',CITY='"+city+"',CODE='"+code+"',E_MAIL='"+e_mail+"',COMPANY1='"+company1+"',COMPANY2='"+company2+"',COMPANY3='"+company3+"',YEAR1='"+year1+"',YEAR2='"+year2+"',YEAR3='"+year3+"',S_YEAR1='"+s_year1+"',S_YEAR2='"+s_year2+"',S_YEAR3='"+s_year3+"',U_YEAR1='"+u_year1+"',U_YEAR2='"+u_year2+"',U_YEAR3='"+u_year3+"',POSITION1='"+position1+"',POSITION2='"+position2+"',POSITION3='"+position3+"',SOFTWARE='"+all_software+"',HARDWARE='"+all_hardware+"',NETWORK='"+all_network+"',DB='"+all_db+"',OS='"+all_os+"' where ID = '"+id+"' ";
     int myresult_add_profile = stmt.executeUpdate(sql_add_profile);
	 response.sendRedirect("my_profile.jsp");
%>
</body>
</html>
