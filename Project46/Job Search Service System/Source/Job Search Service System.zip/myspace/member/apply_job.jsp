<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Apply Job</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<% 
String submit_apply = request.getParameter("submit_apply");
String company = request.getParameter("company");
String location = request.getParameter("location");
String position = request.getParameter("position");
String city = request.getParameter("city");
String salary = request.getParameter("salary");
String experience = request.getParameter("experience");
String qualification = request.getParameter("qualification");
String full_part = request.getParameter("full_part");
String knowledge = request.getParameter("knowledge");
String id_company = request.getParameter("id_company");
String id_job = request.getParameter("id_job");
String [] apply = request.getParameterValues("apply");

Calendar c = Calendar.getInstance();
int month =  c.get(c.MONTH);
month = month+1;
String day = c.get(c.DAY_OF_MONTH)+"/"+month+"/"+c.get(c.YEAR)  ;

String name ="";
String surname ="";
String department ="";
String faculty ="";
String degree ="";
int age = 0;

		 String sql_member= "select * from member where ID = '"+id+"'  ";
		ResultSet myresult_member = stmt.executeQuery(sql_member);
		while(myresult_member.next())
				{	
					name = myresult_member.getString("NAME");
					surname = myresult_member.getString("SURNAME");
					age = myresult_member.getInt("B_YEAR");
					department = myresult_member.getString("DEPARTMENT");
					faculty = myresult_member.getString("FACULTY");
					degree = myresult_member.getString("DEGREE");
				}
		myresult_member.close();
Calendar cc = Calendar.getInstance();
age  =  cc.get(cc.YEAR) - age;


if (submit_apply != null )
{  	
	if ( apply != null ) 
		{
				for(int i=0; i<apply.length; i++)
					{		
							String sql_apply = "INSERT INTO history (ID_MEMBER,ID_POST,COMPANY,LOCATION,POSITION,DATE) VALUES('"+id+"','"+apply[i]+"','"+company+"','"+city+"','"+position+"','"+day+"');";
							int myresult_apply = stmt.executeUpdate(sql_apply);

							String sql_apply2 = "INSERT INTO apply (ID_MEMBER,ID_COMPANY,ID_JOB,NAME,SURNAME,AGE,DEPARTMENT,FACULTY,DEGREE,DATE) VALUES('"+id+"','"+id_company+"','"+id_job+"','"+name+"','"+surname+"','"+age+"','"+department+"','"+faculty+"','"+degree+"','"+day+"');";
							int myresult_apply2 = stmt.executeUpdate(sql_apply2);
	 
							if (myresult_apply != 0 && myresult_apply2 != 0)
								{ 
										%>

					<table width="600" border="0">
  <tr>
    <td width="70" class="style2">Company</td>
    <td width="530" class="style3">:&nbsp;&nbsp;<%=company%></td>
  </tr>
<tr>
    <td class="style2">Location</td>
    <td class="style3">:&nbsp;&nbsp;<%=location%></td>
  </tr>
  <tr>
    <td class="style2">City</td>
    <td class="style3">:&nbsp;&nbsp;<%=city%></td>
  </tr>
  <tr>
    <td class="style2">Position</td>
    <td class="style3">:&nbsp;&nbsp;<%=position%></td>
  </tr> 
  <tr>
    <td class="style2">Salary</td>
    <td class="style3">:&nbsp;&nbsp;<%=salary%></td>
  </tr> 
  <tr>
    <td class="style2">Experience</td>
    <td class="style3">:&nbsp;&nbsp;<%=experience%></td>
  </tr> 
  <tr>
    <td class="style2">Qualification</td>
    <td class="style3">:&nbsp;&nbsp;<%=qualification%></td>
  </tr> 
  <tr>
    <td class="style2">Job Type</td>
    <td class="style3">:&nbsp;&nbsp;<%=full_part%></td>
  </tr> 
  <tr>
    <td class="style2">Knowledge</td>
    <td class="style3">:&nbsp;&nbsp;<%=knowledge%></td>
  </tr> 
  <tr>
    <td colspan="2" class="style2">&nbsp;&nbsp;&lt;-You Have Already Apply This Job-&gt;</td>
    </tr>
</table>
			
						
								<%									
							} // end if
				} // end for
		}//end if (length == 1)
	else
	{  String go_back = "d_job.jsp?id=" + id_job ;
		response.sendRedirect(go_back); }
} // end if (sumit)



%>
</body>
</html>
