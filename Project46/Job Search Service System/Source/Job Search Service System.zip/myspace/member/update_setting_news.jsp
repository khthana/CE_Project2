<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add My Profile</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String [ ] b_news = request.getParameterValues("news");
String news = "";

int i = 0;

if ( b_news != null )
{
	for ( i=0; i<b_news.length; i++)
			{	 news = news + b_news[i];
				  if ( i != b_news.length-1) {  news = news + ",";    }  
			}
}

if ( b_news == null )
{ news = "-"; }


	 String sql_update_news = "update member set NEWS='"+news+"'  where ID = '"+id+"' ";

	 int myresult_update_news = stmt.executeUpdate(sql_update_news);
	 response.sendRedirect("my_profile.jsp");
%>
</body>
</html>
