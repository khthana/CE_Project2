<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Delete My History</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String [] history = request.getParameterValues("history");

for(int i=0; i < history.length; i++)
{
	 String sql_delete = "delete from history where ID = '"+history[i]+"' ";
	 int myresult_delete = stmt.executeUpdate(sql_delete);   
}
	 response.sendRedirect("my_history.jsp");

%>
</body>
</html>
