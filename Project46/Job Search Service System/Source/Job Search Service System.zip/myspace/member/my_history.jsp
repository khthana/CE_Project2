<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>My History</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>




</head>

<body leftmargin="0" topmargin="0"  rightmargin="0" onLoad="MM_preloadImages('Menu_My_Profile_2.gif','Menu_My_Resume_2.gif','Menu_My_Contract_2.gif','Menu_My_History_2.gif','Menu_Webboard_2.gif','Menu_Mail_2.gif','Menu_Jobs_2.gif','Menu_News_2.gif','Menu_Private_Message_2.gif','Menu_E_mail_2.gif','Menu_Agent_2.gif','Menu_Search_2.gif','image/Menu_My_Interview_2.gif')">
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>

<%
String name = "";
String surname = "";
String sql_name = "select NAME,SURNAME from member where ID = '"+id+"'";
ResultSet myresult_name = stmt.executeQuery(sql_name);
while(myresult_name.next())
{ 
	name = myresult_name.getString("NAME"); 
	surname = myresult_name.getString("SURNAME"); 
}
     myresult_name.close();
%>
<div id="Layer1" style="position:absolute; left:17px; top:112px; width:261px; height:22px; z-index:1" class="style4">
<div align="center" class="style5"><%=name+"   "+surname%></div>
</div>
<div id="Layer9" style="position:absolute; left:30px; top:553px; width:81px; height:24px; z-index:17"><a href="boardlist.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('webboard','','../administrator/image/Menu_Webboard_2.gif',1)"><img src="../administrator/image/Menu_Webboard.gif" alt="Webboard" name="webboard" width="81" height="24" border="0"></a></div>
<div id="Layer2" style="position:absolute; left:421px; top:170px; width:90px; height:23px; z-index:2"><a href="my_profile.jsp" target="_self" onMouseOver="MM_swapImage('MyProfile','','image/Menu_My_Profile_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Profile.gif" alt="My Profile" name="MyProfile" width="90" height="23" border="0"></a></div>
<div id="Layer3" style="position:absolute; left:570px; top:170px; width:90px; height:23px; z-index:3"><a href="my_interview.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('interview','','image/Menu_My_Interview_2.gif',1)"><img src="image/Menu_My_Interview.gif" alt="Interview" name="interview" width="90" height="23" border="0"></a></div>
<div id="Layer4" style="position:absolute; left:734px; top:170px; width:89px; height:23px; z-index:4"><a href="my_contract.jsp" target="_self" onMouseOver="MM_swapImage('MyContract','','image/Menu_My_Contract_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_Contract.gif" alt="My Contract" name="MyContract" width="89" height="23" border="0"></a></div>
<div id="Layer5" style="position:absolute; left:892px; top:170px; width:89px; height:23px; z-index:5"><a href="my_history.jsp" target="_self" onMouseOver="MM_swapImage('MyHistory','','image/Menu_My_History_2.gif',1)" onMouseOut="MM_swapImgRestore()"><img src="image/Menu_My_History.gif" alt="My History" name="MyHistory" width="89" height="23" border="0"></a></div>
<div id="Layer6" style="position:absolute; left:17px; top:222px; width:135px; height:27px; z-index:6"><img src="image/Menu_Information.gif" width="135" height="27"></div>
<div id="Layer7" style="position:absolute; left:30px; top:343px; width:74px; height:24px; z-index:7"><img src="image/Menu_Compose.gif" width="74" height="24"></div>
<div id="Layer8" style="position:absolute; left:30px; top:453px; width:47px; height:24px; z-index:8"><img src="image/Menu_Help.gif" width="47" height="24"></div>
<div id="Layer10" style="position:absolute; left:15px; top:375px; width:161px; height:23px; z-index:10"><a href="private_message.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Private_Message','','image/Menu_Private_Message_2.gif',1)"><img src="image/Menu_Private_Message.gif" alt="Private Message" name="Private_Message" width="161" height="23" border="0"></a></div>
<div id="Layer11" style="position:absolute; left:16px; top:404px; width:161px; height:23px; z-index:11"><a href="e_mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E-Mail','','image/Menu_E_mail_2.gif',1)"><img src="image/Menu_E_mail.gif" alt="E-Mail" name="E-Mail" width="161" height="23" border="0"></a></div>
<div id="Layer12" style="position:absolute; left:15px; top:482px; width:161px; height:23px; z-index:12"><a href="agent.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Agent','','image/Menu_Agent_2.gif',1)"><img src="image/Menu_Agent.gif" alt="Agent" name="Agent" width="161" height="23" border="0"></a></div>
<div id="Layer13" style="position:absolute; left:15px; top:511px; width:161px; height:23px; z-index:13"><a href="search.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Search','','image/Menu_Search_2.gif',1)"><img src="image/Menu_Search.gif" alt="Search" name="Search" width="161" height="23" border="0"></a></div>
<div id="Layer14" style="position:absolute; left:15px; top:251px; width:161px; height:23px; z-index:14"><a href="mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mail','','image/Menu_Mail_2.gif',1)"><img src="image/Menu_Mail.gif" alt="Mail" name="Mail" width="161" height="23" border="0"></a></div>
<div id="Layer15" style="position:absolute; left:15px; top:276px; width:161px; height:23px; z-index:15"><a href="jobs.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Jobs','','image/Menu_Jobs_2.gif',1)"><img src="image/Menu_Jobs.gif" alt="Jobs" name="Jobs" width="161" height="23" border="0"></a></div>
<div id="Layer16" style="position:absolute; left:15px; top:300px; width:161px; height:23px; z-index:16"><a href="new.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('News','','image/Menu_News_2.gif',1)"><img src="image/Menu_News.gif" alt="News" name="News" width="161" height="23" border="0"></a></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" height="150" valign="top"><img src="image/Head_Left.jpg" width="280" height="150"></td>
    <td width="80%" height="150" valign="top"><img src="image/Head_Center.jpg" width="100%" height="150"></td>
    <td width="10%" height="150" valign="top"><img src="image/Head_Right.jpg" width="345" height="150"></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="70" width="90%" valign="top"><img src="image/My.jpg" width="930" height="70"></td>
    <td height="70" width="10%" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="220" height="371" rowspan="9" valign="top"><img src="image/Menu_BG.jpg" width="220" height="371"></td>
    <td width="0" height="371" rowspan="9" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td  height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="100%" height="371" rowspan="9">&nbsp;</td>
  </tr>
  <tr>
    <td width="20"  height="12"><img src="image/K_conner_top_left.jpg" width="20" height="12"></td>
    <td width="650"  height="12"><img src="image/K_conner_top_center.jpg" width="650" height="12"></td>
    <td width="40"  height="12"><img src="image/K_conner_top_right.jpg" width="40" height="12"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_top.jpg" width="20" height="20"></td>
    <td width="784" rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0">
      <tr>
        <td align="right"><img src="image/Titel_my_history.jpg" width="454" height="35"></td>
      </tr>
      <tr>
        <td align="center">
		











		<form name="form_my_history" method="post" action="delete_my_history.jsp">
  <table width=600" border="1" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td width="49">&nbsp;</td>
      <td width="146" class="style2">Company</td>
      <td width="171" class="style2">Location</td>
      <td width="122" class="style2">Position</td>
      <td width="100" class="style2">Date</td>
    </tr>

<%
	int row_page = 10;
	int total_row = 0;
	ResultSet myresult0 = stmt.executeQuery("select count(*) as num from history where ID_MEMBER = '"+id+"'");
	while(myresult0.next())
	{ total_row = myresult0.getInt("num"); }
	myresult0.close();
	int total_page = (int)Math.ceil((double)total_row/(double)row_page);
	int screen,start;
	
	if(request.getParameter("screen") == null)
		{ screen = 1; }
	else
		{ screen = Integer.parseInt(request.getParameter("screen")); } 
	
	if(screen >= 1 && screen <= total_page)
	{	start = (screen - 1)*row_page;

		 String sql_my_history = "select ID,ID_POST,COMPANY,LOCATION,POSITION,DATE from history where ID_MEMBER = '"+id+"' order by `ID` DESC limit "+start+","+row_page+" ";
		ResultSet myresult_my_history = stmt.executeQuery(sql_my_history);
		while(myresult_my_history.next())
	        {  
			  %>
				<tr>
					<td align="center"><input type="checkbox" name="history" value="<%=myresult_my_history.getString("ID")%>"></td>
					<td align="center" class="style1"><a href='my_history.jsp?screen=<%=screen%>' target="_self" onClick="MM_openBrWindow('d_job2.jsp?id=<%=myresult_my_history.getString("ID_POST")%>','','scrollbars=yes,width=400,height=400')"><%=myresult_my_history.getString("COMPANY")%></a></td>
					<td align="center" class="style1"><%=myresult_my_history.getString("LOCATION")%></td>
					<td align="center" class="style1"><%=myresult_my_history.getString("POSITION")%></td>
					<td align="center" class="style1"><%=myresult_my_history.getString("DATE")%></td>
				</tr>
			   <%
			 }
		myresult_my_history.close();
	}
   
%>    
  </table>



  <table width="600" border="0" class="style1">
   <tr>
      <td width="200">&nbsp;</td>
      <td width="400" align="right">Page&nbsp;&nbsp;<%
			if(screen>1)
				{ out.println("<a href='my_history.jsp?screen="+(screen-1)+"' >Back</a>"); }

			for(int i=1; i<=total_page; i++)
				{
					if ( i == screen) { out.println("<b>"+i+"</b>"); }
					else { out.print(" <a href='my_history.jsp?screen="+i+"' >"+i+"</a> "); }
				}

			if(screen < total_page)
				{ out.println("<a href='my_history.jsp?screen="+(screen+1)+"' >Next</a>");}
	  %></td>
    </tr>
    <tr>
      <td align="left"><input type="submit" name="Submit" value="Delete">&nbsp;&nbsp;&nbsp;<input type="reset" name="Submit2" value="Reset"></td>
      <td align="right">&nbsp;</td>
    </tr>  
  </table>

</form>		










</td>
      </tr>

    </table></td>
    <td width="35" height="20"><img src="image/K_middel_top2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td width="20" height="249"><img src="image/K_middel_center.jpg" width="20" height="350"></td>
    <td width="40" height="249"><img src="image/K_middel_center2.jpg" width="40" height="350"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_bottom.jpg" width="20" height="20"></td>
    <td width="40" height="20"><img src="image/K_middel_bottom2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td height="30" width="20"><img src="image/K_conner_bottom_left.jpg" width="20" height="30"></td>
    <td height="30" width="650"><img src="image/K_conner_bottom_center.jpg" width="650" height="30"></td>
    <td height="30" width="40"><img src="image/K_conner_bottom_right.jpg" width="40" height="30"></td>
  </tr>
  
  <tr>
    <td height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Left.jpg" width="440" height="15"></td>
    <td width="80%" valign="top" height="15"><img src="image/Tail_Center.jpg" width="100%" height="15"></td>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Right.jpg" width="165" height="15"></td>
  </tr>
</table>
</body>
</html>
