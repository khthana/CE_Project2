<% 
String id = (String)session.getAttribute("id");
String type_user = (String)session.getAttribute("type");
String user_name = (String)session.getAttribute("user_name");
String session_id_on_web = session.getId();
String session_id_on_database ="null";
 String session_type ="";
 String username = "";

String sql_session = "select TYPE,SESSION,USERNAME from member where ID = '"+id+"'";
ResultSet myresult_session_id = stmt.executeQuery(sql_session);

while ( myresult_session_id.next() )
         { session_id_on_database = myresult_session_id.getString("SESSION"); 
		   session_type = myresult_session_id.getString("TYPE"); 
		   username = myresult_session_id.getString("USERNAME");
		 }
myresult_session_id.close();

if ( session_id_on_database.equals(session_id_on_web)  && type_user.equals("1") )
   {  }
else
  { response.sendRedirect("../myspace.jsp"); }
%>