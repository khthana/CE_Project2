<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Delete My Interview</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String [] interview = request.getParameterValues("interview");

for(int i=0; i < interview.length; i++)
{
	 String sql_delete = "delete from interview where ID = '"+interview[i]+"' ";
	 int myresult_delete = stmt.executeUpdate(sql_delete);   
}
	 response.sendRedirect("my_interview.jsp");

%>
</body>
</html>
