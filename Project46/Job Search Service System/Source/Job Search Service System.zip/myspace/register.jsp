<%@ page contentType="text/html; charset=TIS-620" %>
<%@ page import="mybean.Utility" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>

<html>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
.style6 {color: #FF3366}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
<body>



	










<%
String name = request.getParameter("name");
String surname = request.getParameter("surname");
String sex = request.getParameter("sex");
String location = request.getParameter("location");
String city = request.getParameter("city");
String code = request.getParameter("code");
String e_mail = request.getParameter("e_mail");
String telephone = request.getParameter("telephone");
String university = request.getParameter("university");
String department = request.getParameter("department");
String faculty = request.getParameter("faculty");
String degree = request.getParameter("degree");
String graduated = request.getParameter("graduated");
String day = request.getParameter("day");
String month = request.getParameter("month");
String year = request.getParameter("year");
String user = request.getParameter("user");
String pass = request.getParameter("pass");
String re_pass = request.getParameter("re_pass");
String error = request.getParameter("error");

if (name == null)  {  name = "";  }
if (surname == null)  {  surname = "";  }
if (sex == null)  {  sex = "";  }
if (location == null)  {  location = "";  }
if (city == null)  {  city = "";  }
if (code == null)  {  code = "";  }
if (e_mail == null)  {  e_mail = "";  }
if (telephone == null)  {  telephone = "";  }
if (university == null)  {  university = "";  }
if (department == null)  {  department = "";  }
if (faculty == null)  {  faculty = "";  }
if (degree == null)  {  degree = "";  }
if (graduated == null)  {  graduated = "";  }
if (day == null)  {  day = "";  }
if (month == null)  {  month = "";  }
if (year == null)  {  year = "";  }
if (user == null)  {  user = "";  }
if (pass == null)  {  pass = "";  }
if (re_pass == null)  {  re_pass = "";  }

%>



	<form action="insert_member.jsp" method="post" name="insert_member" onSubmit="MM_validateForm('name','','R','surname','','R','day','','RinRange1:31','month','','RinRange1:12','year','','RisNum','location','','R','city','','R','code','','RisNum','e_mail','','RisEmail','telephone','','R','university','','R','department value=','','R','faculty','','R','graduated','','RisNum','user','','R','pass','','R','re_pass','','R');return document.MM_returnValue" >


<table width="700" border="0">
  <tr align="left">
    <td colspan="4" class="style2"><u>Personal</u><span class="style6"><%
	if ( error != null )
		{
				if (error.equals("1")) 
					{ out.print("              Password and Re-Password does't match");  }
				if (error.equals("2")) 
					{ out.print("              This Username alredy use");  }
		}
	%>
	</td>
  </tr>
  <tr align="left">
    <td width="132" class="style1">Name</td>
    <td width="558" class="style3">:&nbsp;&nbsp;&nbsp;<input name="name" type="text" id="name" value="<%=name%>" size="50" maxlength="50"></td>
  </tr>
  <tr align="left">
    <td width="132" class="style1">Surname</td>
    <td width="558" class="style3">:&nbsp;&nbsp;&nbsp;<input name="surname" type="text" id="surname" value="<%=surname%>" size="50" maxlength="50"></td>
  </tr>
  <tr align="left">
    <td class="style1">Sex </td>
    <td class="style3">:&nbsp;&nbsp;<input name="sex" type="radio" value="Male" <%if(sex.equals("Male")) { out.print("checked"); }%>>
      Male&nbsp;&nbsp;&nbsp;&nbsp;
      <input name="sex" type="radio" value="FeMale" <%if(sex.equals("FeMale")) { out.print("checked"); }%>>
      FeMale</td>
  </tr>
    <tr align="left">
   <td class="style1">Birthday </td>
    <td class="style3">:&nbsp;&nbsp;&nbsp;Day
      <input name="day" type="text" size="2" maxlength="2" value="<%=day%>">      
      &nbsp;&nbsp;&nbsp;Month
      <input name="month" type="text" size="2" maxlength="2" value="<%=month%>">      
      &nbsp;&nbsp;Year
      <input name="year" type="text" size="4" maxlength="4" value="<%=year%>"></td>
    </tr>
  <tr align="left">
    <td class="style1">Location </td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;&nbsp;<input name="location" type="text" id="location" value="<%=location%>" size="75" maxlength="100">    </td>
  </tr>
  <tr align="left">
    <td class="style1">City </td>
    <td class="style3">:&nbsp;&nbsp;
      <input name="city" type="text" id="city" value="<%=city%>" size="25" maxlength="25"></td>
  </tr>
    <tr align="left">
      <td class="style1">Code </td>
    <td class="style3">:&nbsp;&nbsp;
      <input name="code" type="text" id="code" value="<%=code%>" size="5" maxlength="5"></td>
    </tr>
  <tr align="left">
    <td class="style1">E-Mail </td>
    <td class="style3">:&nbsp;&nbsp;
      <input name="e_mail" type="text" id="e_mail" value="<%=e_mail%>" size="25" maxlength="25"></td>
  </tr>
    <tr align="left">
      <td class="style1">Telephone</td>
    <td class="style3">:&nbsp;&nbsp;
      <input name="telephone" type="text" id="telephone" value="<%=telephone%>" size="25" maxlength="25"></td>
    </tr>
 </table>
<table width="700" border="0">
  <tr align="left">
    <td colspan="4" class="style2"><u>University</u></td>
  </tr>
  <tr align="left">
    <td width="130" class="style1">University</td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;
      <input name="university" type="text" id="university" value="<%=university%>" size="25" maxlength="25"></td>
  </tr>
  <tr align="left">
    <td class="style1">Department</td>
    <td width="560" class="style3">:&nbsp;&nbsp;
      <input name="department" type="text" id="department value="<%=department%>" size="25" maxlength="25"></td>
  </tr>
    <tr align="left">
      <td width="130" class="style1">Faculty</td>
    <td width="560" class="style3">:&nbsp;&nbsp;
      <input name="faculty" type="text" id="faculty" value="<%=faculty%>" size="25" maxlength="25"></td>
    </tr>
  <tr align="left">
    <td class="style1">Degree</td>
    <td class="style3">:&nbsp;&nbsp;      <select name="degree">
      <option value="Bachelor">Bachelor</option>
      <option value="Master">Master</option>
      <option value="Doctor">Doctor</option>
    </select></td>
  </tr>
    <tr align="left">
      <td class="style3">Graduated</td>
    <td class="style3">:&nbsp;&nbsp;
      <input name="graduated" type="text" id="graduated" value="<%=graduated%>" size="4" maxlength="4"></td>
    </tr>
	<tr align="left">
      <td class="style2"><u>Login</u></td>
      <td class="style3">&nbsp;      </td>
    </tr>
	<tr align="left">
      <td class="style3">Username</td>
      <td class="style3">:&nbsp;&nbsp;
      <input name="user" type="text" id="user" value="<%=user%>" size="25" maxlength="25"></td>
    </tr>
	<tr align="left">
      <td class="style3">Password</td>
      <td class="style3">:&nbsp;&nbsp;
      <input name="pass" type="password" id="pass" value="<%=pass%>" size="25" maxlength="25"></td>
    </tr>
	<tr align="left">
      <td class="style3">Re-Password</td>
      <td class="style3">:&nbsp;&nbsp;
      <input name="re_pass" type="password" id="re_pass" value="<%=re_pass%>" size="25" maxlength="25"></td>
    </tr>
	<tr align="left">
      <td class="style3">&nbsp;</td>
    <td class="style3">&nbsp;&nbsp; 
      <input type="submit" name="Submit" value="Submit">
      &nbsp;&nbsp;&nbsp;&nbsp;
      <input type="reset" name="Submit2" value="Reset"> </td>
    </tr>
</table>
<table width="700" border="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</form>	
</body>
</html>
