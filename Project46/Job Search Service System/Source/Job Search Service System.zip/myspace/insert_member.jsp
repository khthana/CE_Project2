<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add Company</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>

<%
String name = request.getParameter("name");
String surname = request.getParameter("surname");
String sex = request.getParameter("sex");
String location = request.getParameter("location");
String city = request.getParameter("city");
String code = request.getParameter("code");
String e_mail = request.getParameter("e_mail");
String telephone = request.getParameter("telephone");
String university = request.getParameter("university");
String department = request.getParameter("department");
String faculty = request.getParameter("faculty");
String degree = request.getParameter("degree");
String graduated = request.getParameter("graduated");
String day = request.getParameter("day");
String month = request.getParameter("month");
String year = request.getParameter("year");
String user = request.getParameter("user");
String pass = request.getParameter("pass");
String re_pass = request.getParameter("re_pass");

String check_user = "";

	 ResultSet myresult_username = stmt.executeQuery("select * from member where username = '"+user+"'  ");
	while(myresult_username.next())
			{ 
					check_user = myresult_username.getString("USERNAME");
			}
     myresult_username.close();   




if ( pass.equals(re_pass) &&  !check_user.equals(user) )
{
	String sql_add = "INSERT INTO member (USERNAME,PASSWORD,TYPE,NAME,SURNAME,SEX,LOCATION,TELEPHONE,CITY,CODE,E_MAIL,UNIVERSITY,DEPARTMENT,FACULTY,DEGREE,GRADUATED,PRIVACY,B_DAY,B_MONTH,B_YEAR,ENGLISH,JAPAN,CHINESE,COMPANY1,COMPANY2,COMPANY3,YEAR1,YEAR2,YEAR3,S_YEAR1,S_YEAR2,S_YEAR3,U_YEAR1,U_YEAR2,U_YEAR3,POSITION1,POSITION2,POSITION3,SOFTWARE,HARDWARE,NETWORK,DB,OS,NEWS,GPA,CONTRACT,DETAIL) VALUES('"+user+"','"+pass+"','1','"+name+"','"+surname+"','"+sex+"','"+location+"','"+telephone+"','"+city+"','"+code+"','"+e_mail+"','"+university+"','"+department+"','"+faculty+"','"+degree+"','"+graduated+"','2','"+day+"','"+month+"','"+year+"','-1','-1','-1','-','-','-','0','0','0','0','0','0','0','0','0','-','-','-','-','-','-','-','-','-','0.00','-','-');";

    int myresult_add = stmt.executeUpdate(sql_add);
	response.sendRedirect("myspace.jsp");
}
else
{
	
	if ( check_user.equals(user) )
	{	response.sendRedirect("register.jsp? name = "+name+"&surname = "+surname+"&sex = "+sex+"&location = "+location+"&city = "+city+"&code = "+code+"&e_mail = "+e_mail+"&telephone = "+telephone+"&university = "+university+"&department = "+department+"&faculty = "+faculty+"&degree = "+degree+"&graduated = "+graduated+"&day = "+day+"&month = "+month+"& year = "+year+"&user = "+user+"&pass = "+pass+"& re_pass = "+re_pass+"&error=2");
	}
	else
	{
			response.sendRedirect("register.jsp? name = "+name+"&surname = "+surname+"&sex = "+sex+"&location = "+location+"&city = "+city+"&code = "+code+"&e_mail = "+e_mail+"&telephone = "+telephone+"&university = "+university+"&department = "+department+"&faculty = "+faculty+"&degree = "+degree+"&graduated = "+graduated+"&day = "+day+"&month = "+month+"& year = "+year+"&user = "+user+"&pass = "+pass+"& re_pass = "+re_pass+"&error=1");
	}
	
}
%>
</body>
</html>
