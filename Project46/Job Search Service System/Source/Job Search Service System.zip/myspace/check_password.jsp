<html>
<body>
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
     
<%
    String username = request.getParameter("username");
    String password = request.getParameter("password");

	String password_from_sql = "";
	String type_user = "";
	String id = "";

   String sql_password = "select USERNAME,PASSWORD,TYPE,ID from member where USERNAME = '"+username+"'";
      ResultSet myresult_password = stmt.executeQuery(sql_password);
	 
	 while(myresult_password.next())
	        { 
			   password_from_sql = myresult_password.getString("PASSWORD"); 
  			   type_user = myresult_password.getString("TYPE"); 
			   id = myresult_password.getString("ID");
			   }
     myresult_password.close();

	 if ( password_from_sql.equals(password) )
	    { 
				String session_id = session.getId();
				String sql_session = "update member set SESSION ='"+session_id+"' where USERNAME = '"+username+"' and PASSWORD = '"+password+"';";
				int myresult_sesion = stmt.executeUpdate(sql_session);
				session.setAttribute("id",id);	
				session.setAttribute("type",type_user);	
				session.setAttribute("user_name",username);	
				if ( type_user.equals("0"))
					 { response.sendRedirect("administrator/admin.jsp");	  }
				if ( type_user.equals("1"))
					{ response.sendRedirect("member/member.jsp");	 }
				if ( type_user.equals("2"))
					{ response.sendRedirect("company/company.jsp");	 }
		 }
	else
		 { response.sendRedirect("myspace.jsp?error=1"); }
			
			stmt.close();
            mycon.close();  
%>

</body>
</html>