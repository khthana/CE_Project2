<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>My Agent</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>








<body>
<%
int c_id;
double bn_experience1=0,bn_experience2=0,bn_experience3=0;
double possibility;
double percent_rule1,percent_rule2,percent_rule3;
double pass_criteria_rule1,pass_criteria_rule2,pass_criteria_rule3;
int c_rule1,c_rule2,c_rule3;
double criteria_rule1,criteria_rule2,criteria_rule3;
double max_rule1,max_rule2,max_rule3;
int c_age=0,m_age=0;
String m_sex="",c_sex="";
String c_qualification="",m_qualification="";
int m_english=0,m_japan=0,m_chinese=0,c_english=0,c_japan=0,c_chinese=0 ;
String m_position1= "",m_position2= "",m_position3= "",c_position= "";
int m_experience1=0,m_experience2=0,m_experience3=0,c_experience=0;
double m_gpa=0,c_gpa=0;
String m_software="",m_hardware="",m_network="",m_database="",m_os="";
String c_software="",c_hardware="",c_network="",c_database="",c_os="";
double n_english=0,n_japan=0,n_chinese=0,n_position=0,n_experience=0,n_gpa=0,n_knowledge=0;
double bn_software=0,bn_hardware=0,bn_network=0,bn_database=0,bn_os=0;
double w_english_R1	= 2.31;
double w_english_R2	= 0;
double w_english_R3	= 0;
double w_japan_R1	= 1.71;
double w_japan_R2	= 0;
double w_japan_R3	= 0;
double w_chinese_R1	=1.71;
double w_chinese_R2	=0;
double w_chinese_R3	=0;
double w_pos_R1		=0;
double w_pos_R2		=2.11;
double w_pos_R3		=3.27;
double w_ex_R1		=0;
double w_ex_R2		=2.21;
double w_ex_R3		=3.49;
double w_gpa_R1	=0.78;
double w_gpa_R2	=0.98;
double w_gpa_R3	=0;
double w_kb_R1		=0;
double w_kb_R2		=6.65;
double w_kb_R3		=1.24;
double rule_language,rule_technic,rule_experience;


StringTokenizer st_m_software;
StringTokenizer st_m_hardware;
StringTokenizer st_m_network;
StringTokenizer st_m_database;
StringTokenizer st_m_os;
int num_m_software= 0;
int num_m_hardware= 0;
int num_m_network= 0;
int num_m_database= 0;
int num_m_os= 0;
String[ ] sm_software ;
String[ ] sm_hardware ;
String[ ] sm_network ;
String[ ] sm_database ;
String[ ] sm_os ;

StringTokenizer st_c_software;
StringTokenizer st_c_hardware;
StringTokenizer st_c_network;
StringTokenizer st_c_database;
StringTokenizer st_c_os;
int num_c_software= 0;
int num_c_hardware= 0;
int num_c_network= 0;
int num_c_database= 0;
int num_c_os= 0;
String[ ] sc_software ;
String[ ] sc_hardware ;
String[ ] sc_network ;
String[ ] sc_database ;
String[ ] sc_os ;

int num_experience = 0;
int num_kn = 0;
int i=0;
double temp;
int temp2=0;
int w =0;
boolean age = false,qualification = false,sex = false;
%>

<%
//+++++++++++++Select Member+++++++++++++++++//
	 String sql_myprofile = "select NAME,SURNAME,SEX,LOCATION,TELEPHONE,CITY,CODE,E_MAIL,ENGLISH,JAPAN,CHINESE,UNIVERSITY,DEPARTMENT,FACULTY,DEGREE,GRADUATED,COMPANY1,COMPANY2,COMPANY3,YEAR1,YEAR2,YEAR3,S_YEAR1,S_YEAR2,S_YEAR3,U_YEAR1,U_YEAR2,U_YEAR3,POSITION1,POSITION2,POSITION3,PRIVACY,GPA,SOFTWARE,HARDWARE,NETWORK,DB,OS,B_YEAR from member where ID = '"+id+"' ";
     ResultSet myresult_myprofile = stmt.executeQuery(sql_myprofile);
	 while(myresult_myprofile.next())
	        {  
             m_english = myresult_myprofile.getInt("ENGLISH");
			 m_japan = myresult_myprofile.getInt("JAPAN");
			 m_chinese = myresult_myprofile.getInt("CHINESE");
			 m_gpa = myresult_myprofile.getDouble("GPA");
			 m_software = myresult_myprofile.getString("SOFTWARE");
			 m_hardware = myresult_myprofile.getString("HARDWARE");
			 m_network = myresult_myprofile.getString("NETWORK");
			 m_database = myresult_myprofile.getString("DB");
			 m_os = myresult_myprofile.getString("OS");
			 m_position1 = myresult_myprofile.getString("POSITION1");
			 m_position2 = myresult_myprofile.getString("POSITION2");
			 m_position3 = myresult_myprofile.getString("POSITION3");
			 m_experience1 = myresult_myprofile.getInt("YEAR1");
			 m_experience2 = myresult_myprofile.getInt("YEAR2");
			 m_experience3 = myresult_myprofile.getInt("YEAR3");
			 m_qualification = myresult_myprofile.getString("DEGREE");
			 m_age = myresult_myprofile.getInt("B_YEAR");
			 m_sex = myresult_myprofile.getString("SEX");
			 }
			myresult_myprofile.close();

Calendar c = Calendar.getInstance();
m_age  =  c.get(c.YEAR) - m_age;

st_m_software = new StringTokenizer(m_software,",");
num_m_software = st_m_software.countTokens();
sm_software= new String[num_m_software];
for (i = 0; i<num_m_software; i++)
{ sm_software[i] = new String (st_m_software.nextToken()); }

st_m_hardware = new StringTokenizer(m_hardware,",");
num_m_hardware = st_m_hardware.countTokens();
sm_hardware= new String[num_m_hardware];
for (i = 0; i<num_m_hardware; i++)
{ sm_hardware[i] = new String (st_m_hardware.nextToken()); }

st_m_network = new StringTokenizer(m_network,",");
num_m_network = st_m_network.countTokens();
sm_network= new String[num_m_network];
for (i = 0; i<num_m_network; i++)
{ sm_network[i] = new String (st_m_network.nextToken()); }

st_m_database = new StringTokenizer(m_database,",");
num_m_database = st_m_database.countTokens();
sm_database= new String[num_m_database];
for (i = 0; i<num_m_database; i++)
{ sm_database[i] = new String (st_m_database.nextToken()); }

st_m_os = new StringTokenizer(m_os,",");
num_m_os = st_m_os.countTokens();
sm_os= new String[num_m_os];
for (i = 0; i<num_m_os; i++)
{ sm_os[i] = new String (st_m_os.nextToken()); }

/*out.print("  Num Software = "+num_m_software+"   ");
out.print("  Num Hardware = "+num_m_hardware+"   ");
out.print("  Num Network = "+num_m_network+"   ");
out.print("  Num Database = "+num_m_database+"   ");
out.print("  Num Os = "+num_m_os+"   ");
out.println("<br>");
out.println("<br>");*/
//+++++++++++++Select Member+++++++++++++++++//
%>


<%
//+++++++++++++Select Job+++++++++++++++++//
String sql_jobs;
int num_jobs = 0;
ResultSet myresult_num_jobs = stmt.executeQuery( "select count(*) AS num  from job");
		while(myresult_num_jobs.next())
	        {  num_jobs = myresult_num_jobs.getInt("num"); }
		myresult_num_jobs.close();
int all_jobs_id [ ] = new int [num_jobs] ;
double all_jobs_possibility [ ] = new double [num_jobs] ;
//out.println("Number All Job = "+num_jobs);out.println("<br>");
for ( int count_jobs=1; count_jobs<=num_jobs+1; count_jobs++)
{
		try
			{
					sql_jobs = "select ID,COMPANY,POSITION,QUALIFICATION,FULL_PART,LOCATION,CITY,SALARY,EXPERIENCE,DATE,SOFTWARE,HARDWARE,NETWORK,DB,OS,ENGLISH,JAPAN,CHINESE,GPA,RULE_LANGUAGE,RULE_KNOWLEDGE,RULE_EXPERIENCE,AGE,SEX from job  where ID = '"+count_jobs+"' order by `ID` DESC "; 
					ResultSet myresult_jobs = stmt.executeQuery(sql_jobs);
					while(myresult_jobs.next())
					{  
							c_id = myresult_jobs.getInt("ID");
							c_english = myresult_jobs.getInt("ENGLISH");
							c_japan = myresult_jobs.getInt("JAPAN");
							c_chinese = myresult_jobs.getInt("CHINESE");
							c_gpa = myresult_jobs.getDouble("GPA");
					 	    c_software = myresult_jobs.getString("SOFTWARE");
							c_hardware = myresult_jobs.getString("HARDWARE");
							 c_database = myresult_jobs.getString("DB");
							 c_os = myresult_jobs.getString("OS");
							c_network = myresult_jobs.getString("NETWORK");
							c_position = myresult_jobs.getString("POSITION");
							c_experience = myresult_jobs.getInt("EXPERIENCE");
							c_rule1 = myresult_jobs.getInt("RULE_LANGUAGE");
							c_rule2 = myresult_jobs.getInt("RULE_KNOWLEDGE");
							c_rule3 = myresult_jobs.getInt("RULE_EXPERIENCE");
							c_age = myresult_jobs.getInt("AGE");
							c_qualification = myresult_jobs.getString("QUALIFICATION");
							c_sex = myresult_jobs.getString("SEX");
							
							/*out.print(" ID job = "+count_jobs);
							out.print("  english = "+c_english);
							if (c_gpa == 0.20 ) out.print("  gpa = 0.20  ");
							out.println("<br>");*/
							age = false;  qualification = false;  sex = false;
							if ( m_age <= c_age )  { age = true; }
							if ( m_qualification.equals(c_qualification) ) {  qualification = true; }
							if ( m_qualification.equals("Master") && c_qualification.equals("Bachelor") || m_qualification.equals("Doctor") && c_qualification.equals("Master") || m_qualification.equals("Doctor") && m_qualification.equals("Bachelor") ) { qualification = true; }
							if ( m_sex.equals(c_sex) ) { sex = true; }
							if ( m_sex.equals("Male") && c_sex.equals("Male/Female") || m_sex.equals("Female") && c_sex.equals("Male/Female") ) { sex = true; }
					if ( age && qualification && sex)
						{
							//+++++++++++++INPUT LAYER+++++++++++++++++//							
							st_c_software = new StringTokenizer(c_software,",");
							num_c_software = st_c_software.countTokens();
							sc_software= new String[num_c_software];
							for (i = 0; i<num_c_software; i++)
							{ sc_software[i] = new String (st_c_software.nextToken()); }

							st_c_hardware = new StringTokenizer(c_hardware,",");
							num_c_hardware = st_c_hardware.countTokens();
							sc_hardware= new String[num_c_hardware];
							for (i = 0; i<num_c_hardware; i++)
							{ sc_hardware[i] = new String (st_c_hardware.nextToken()); }

							st_c_network = new StringTokenizer(c_network,",");
							num_c_network = st_c_network.countTokens();
							sc_network= new String[num_c_network];
							for (i = 0; i<num_c_network; i++)
							{ sc_network[i] = new String (st_c_network.nextToken()); }

							st_c_database = new StringTokenizer(c_database,",");
							num_c_database = st_c_database.countTokens();
							sc_database= new String[num_c_database];
							for (i = 0; i<num_c_database; i++)
							{ sc_database[i] = new String (st_c_database.nextToken()); }
							
							st_c_os = new StringTokenizer(c_os,",");
							num_c_os = st_c_os.countTokens();
							sc_os= new String[num_c_os];
							for (i = 0; i<num_c_os; i++)
							{ sc_os[i] = new String (st_c_os.nextToken()); }
							         //+++++++C find to M++++++++//
							bn_software = 0;
							for (i = 0; i<num_c_software; i++)
									{	
											temp2 = m_software.indexOf(sc_software[i]);
											if ( temp2<0 )  {bn_software = -1; }											
									}
							bn_hardware = 0;
							for (i = 0; i<num_c_hardware; i++)
									{	
											temp2 = m_hardware.indexOf(sc_hardware[i]);
											if ( temp2<0 )  {bn_hardware = -1; }											
									}	
							bn_network = 0;
							for (i = 0; i<num_c_network; i++)
									{	
											temp2 = m_network.indexOf(sc_network[i]);
											if ( temp2<0 )  {bn_network = -1; }											
									}	
							bn_database = 0;
							for (i = 0; i<num_c_database; i++)
									{	
											temp2 = m_database.indexOf(sc_database[i]);
											if ( temp2<0 )  {bn_database = -1; }											
									}	
							bn_os = 0;
							for (i = 0; i<num_c_os; i++)
									{	
											temp2 = m_os.indexOf(sc_os[i]);
											if ( temp2<0 )  {bn_os = -1; }											
									}	
							                   //++++C find to M++++++//
							
							                 //++++++M find to C+++++++//            		
							num_kn = 0;
							if ( bn_software == 0  &&  !c_software.equals("-") )
								{		w = 0; num_kn = num_kn + 1;
										for (i = 0; i<num_m_software-1; i++)
											{	
												temp2 = c_software.indexOf(sm_software[i]);
												if (temp2<0) {  w = w +1;}																								
											}
										if ( w >= 10 ) { bn_software = 1;}
										if ( w == 9 ) { bn_software = 0.9;}
										if ( w == 8 ) { bn_software = 0.8;}
										if ( w == 7 ) { bn_software = 0.7;}
										if ( w == 6 ) { bn_software = 0.6;}
										if ( w == 5 ) { bn_software = 0.5;}
										if ( w == 4 ) { bn_software = 0.4;}
										if ( w == 3 ) { bn_software = 0.3;}
										if ( w == 2 ) { bn_software = 0.2;}
										if ( w == 1 ) { bn_software = 0.1;}
										if ( w == 0 ) { bn_software = 0.0;}
								}	
								if ( bn_hardware == 0  &&  !c_hardware.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_m_hardware-1; i++)
											{	
												temp2 = c_hardware.indexOf(sm_hardware[i]);
												if (temp2<0) {  w = w +1;}													
											}
										if ( w >= 10 ) { bn_hardware = 1;}
										if ( w == 9 ) { bn_hardware = 0.9;}
										if ( w == 8 ) { bn_hardware = 0.8;}
										if ( w == 7 ) { bn_hardware = 0.7;}
										if ( w == 6 ) { bn_hardware = 0.6;}
										if ( w == 5 ) { bn_hardware = 0.5;}
										if ( w == 4 ) { bn_hardware = 0.4;}
										if ( w == 3 ) { bn_hardware = 0.3;}
										if ( w == 2 ) { bn_hardware = 0.2;}
										if ( w == 1 ) { bn_hardware = 0.1;}
										if ( w == 0 ) { bn_hardware = 0.0;}
								}		
								if ( bn_network == 0  &&  !c_network.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_m_network-1; i++)
											{	
												temp2 = c_network.indexOf(sm_network[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_network = 1;}
										if ( w == 9 ) { bn_network = 0.9;}
										if ( w == 8 ) { bn_network = 0.8;}
										if ( w == 7 ) { bn_network = 0.7;}
										if ( w == 6 ) { bn_network = 0.6;}
										if ( w == 5 ) { bn_network = 0.5;}
										if ( w == 4 ) { bn_network = 0.4;}
										if ( w == 3 ) { bn_network = 0.3;}
										if ( w == 2 ) { bn_network = 0.2;}
										if ( w == 1 ) { bn_network = 0.1;}
										if ( w == 0 ) { bn_network = 0.0;}										
								}		
								if ( bn_database == 0  &&  !c_database.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_m_database-1; i++)
											{	
												temp2 = c_database.indexOf(sm_database[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_database = 1;}
										if ( w == 9 ) { bn_database = 0.9;}
										if ( w == 8 ) { bn_database = 0.8;}
										if ( w == 7 ) { bn_database = 0.7;}
										if ( w == 6 ) { bn_database = 0.6;}
										if ( w == 5 ) { bn_database = 0.5;}
										if ( w == 4 ) { bn_database = 0.4;}
										if ( w == 3 ) { bn_database = 0.3;}
										if ( w == 2 ) { bn_database = 0.2;}
										if ( w == 1 ) { bn_database = 0.1;}
										if ( w == 0 ) { bn_database = 0.0;}
								}	
								if ( bn_os == 0  &&  !c_os.equals("-")  )
								{		w = 0;  num_kn = num_kn + 1;
										for (i = 0; i<num_m_os-1; i++)
											{	
												temp2 = c_os.indexOf(sm_os[i]);
												if (temp2<0) {  w = w +1;}												
											}
										if ( w >= 10 ) { bn_os = 1;}
										if ( w == 9 ) { bn_os = 0.9;}
										if ( w == 8 ) { bn_os = 0.8;}
										if ( w == 7 ) { bn_os = 0.7;}
										if ( w == 6 ) { bn_os = 0.6;}
										if ( w == 5 ) { bn_os = 0.5;}
										if ( w == 4 ) { bn_os = 0.4;}
										if ( w == 3 ) { bn_os = 0.3;}
										if ( w == 2 ) { bn_os = 0.2;}
										if ( w == 1 ) { bn_os = 0.1;}
										if ( w == 0 ) { bn_os = 0.0;}
								}	
								/*out.print("  BNSoftware = "+bn_software);
								out.print("  BNHardware = "+bn_hardware);
								out.print("  BNNetwork = "+bn_network);
								out.print("  BNDatabase = "+bn_database);
								out.print("  BNOS = "+bn_os);*/

								if ( bn_software == -1 || bn_hardware == -1 || bn_network == -1  || bn_database == -1  || bn_os == -1 )
									{  n_knowledge = -1;  }
								if ( bn_software >= 0 && bn_hardware >= 0 && bn_network >= 0  && bn_database >= 0  && bn_os >= 0 )
									{    
											n_knowledge = (bn_software+bn_hardware+bn_network+bn_database+bn_os)/num_kn;
											/*if ( bn_software == 1 || bn_hardware == 1 || bn_network == 1  || bn_database == 1  || bn_os == 1 )
												{  n_knowledge = 1;  }
											if ( bn_software == 0 && bn_hardware == 0 && bn_network == 0  && bn_database == 0  && bn_os == 0 )
												{  n_knowledge = 0;  }*/
									}

							out.print("  N_Knowledge = "+n_knowledge);out.print("<br>");
							            //++++++M find to C+++++++//
														
							temp2	= m_english -  c_english;
							if ( temp2 == -3 )   n_english = -1;
							if ( temp2 == -2 )   n_english = -0.66;
							if ( temp2 == -1 )   n_english = -0.33;
							if ( temp2 == 0 )   n_english = 0;
							if ( temp2 == 1 )   n_english = 0.33;
							if ( temp2 == 2 )   n_english = 0.66;
							if ( temp2 == 3 )   n_english = 1;							

							temp2	= m_japan -  c_japan;
							if ( temp2 == -3 )   n_japan = -1;
							if ( temp2 == -2 )   n_japan = -0.66;
							if ( temp2 == -1 )   n_japan = -0.33;
							if ( temp2 == 0 )   n_japan = 0;
							if ( temp2 == 1 )   n_japan = 0.33;
							if ( temp2 == 2 )   n_japan = 0.66;
							if ( temp2 == 3 )   n_japan = 1;

							temp2	= m_chinese -  c_chinese;
							if ( temp2 == -3 )   n_chinese = -1;
							if ( temp2 == -2 )   n_chinese = -0.66;
							if ( temp2 == -1 )   n_chinese = -0.33;
							if ( temp2 == 0 )   n_chinese = 0;
							if ( temp2 == 1 )   n_chinese = 0.33;
							if ( temp2 == 2 )   n_chinese = 0.66;
							if ( temp2 == 3 )   n_chinese = 1;

							out.print("  N_English = "+n_english);out.print("<br>");
							out.print("  N_Japan = "+n_japan);out.print("<br>");
							out.print("  N_Chinese = "+n_chinese);out.print("<br>");

							temp = m_gpa - c_gpa;
							if ( temp >= 1.00 ) n_gpa = 1;
							if ( temp >= 0.80 && temp < 1.00 ) n_gpa = 0.80;
							if ( temp >= 0.60 && temp < 0.80 ) n_gpa = 0.60;
							if ( temp >= 0.40 && temp < 0.60 ) n_gpa = 0.40;
							if ( temp >= 0.20 && temp < 0.40 ) n_gpa = 0.20;
							if ( temp >= 0.00 && temp < 0.20 ) n_gpa = 0.00;
							if ( temp >= -0.20 && temp < 0.00 ) n_gpa = -0.20;
							if ( temp >= -0.40 && temp < -0.20 ) n_gpa = -0.40;
							if ( temp >= -0.60 && temp < -0.40 ) n_gpa = -0.60;
							if ( temp >= -0.80 && temp < -0.60 ) n_gpa = -0.80;
							if ( temp <= -1.00 ) n_gpa = -1;
							out.print("  N_Gpa = "+n_gpa);out.print("<br>");

							n_position = 0;
							num_experience = 0;
							bn_experience1 = 0;
							if ( c_position.equals(m_position1) )	
								{ n_position = n_position+0.33; 
							      temp2 = m_experience1 - c_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience1 = 1; }
								  if ( temp2 == 4 ) { bn_experience1 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience1 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience1 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience1 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience1 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience1 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience1 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience1 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience1 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience1 = -1; }								
								}

							bn_experience2 = 0;
							if ( c_position.equals(m_position2) )	
								{ n_position = n_position+0.33; 
							      temp2 = m_experience2 - c_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience2 = 1; }
								  if ( temp2 == 4 ) { bn_experience2 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience2 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience2 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience2 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience2 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience2 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience2 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience2 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience2 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience2 = -1; }					
								}

							bn_experience3 = 0;
							if ( c_position.equals(m_position3) )	
								{ n_position = n_position+0.33; 
							      temp2 = m_experience3 - c_experience;
								  num_experience = num_experience + 1;
								  if ( temp2 >= 5 ) { bn_experience3 = 1; }
								  if ( temp2 == 4 ) { bn_experience3 = 0.8; }
								  if ( temp2 == 3 ) { bn_experience3 = 0.6; }
								  if ( temp2 == 2 ) { bn_experience3 = 0.4; }
								  if ( temp2 == 1 ) { bn_experience3 = 0.2; }
								  if ( temp2 == 0 ) { bn_experience3 = 0.0; }
								  if ( temp2 == -1 ) { bn_experience3 = -0.2; }
								  if ( temp2 == -2 ) { bn_experience3 = -0.4; }
								  if ( temp2 == -3 ) { bn_experience3 = -0.6; }
								  if ( temp2 == -4 ) { bn_experience3 = -0.8; }
								  if ( temp2 <= -5 ) { bn_experience3 = -1; }
								}

							if ( num_experience == 0 ) 
								{  
										if ( c_experience == 0 ) { n_experience = 0; }
										if ( c_experience > 0 ) { n_experience = -1; }
								}
							else
								{ n_experience = (bn_experience1+bn_experience2+bn_experience3)/num_experience; }

							out.print("  N_Position = "+n_position);out.print("<br>");							
							out.print("  N_Experience = "+n_experience);out.print("<br>");
							//+++++++++++++INPUT LAYER+++++++++++++++++//

							//+++++++++++++RULE LAYER+++++++++++++++++//
							rule_language = (w_english_R1*n_english)+(w_japan_R1*n_japan)+(w_chinese_R1*n_chinese)+(w_pos_R1*n_position)+(w_ex_R1*n_experience)+(w_gpa_R1*n_gpa)+(w_kb_R1*n_knowledge);

							rule_technic = (w_english_R2*n_english)+(w_japan_R2*n_japan)+(w_chinese_R2*n_chinese)+(w_pos_R2*n_position)+(w_ex_R2*n_experience)+(w_gpa_R2*n_gpa)+(w_kb_R2*n_knowledge);

							rule_experience = (w_english_R3*n_english)+(w_japan_R3*n_japan)+(w_chinese_R3*n_chinese)+(w_pos_R3*n_position)+(w_ex_R3*n_experience)+(w_gpa_R3*n_gpa)+(w_kb_R3*n_knowledge);
							out.print("  Rule_language = "+rule_language);out.print("<br>");
							out.print("  Rule_technic = "+rule_technic);out.print("<br>");
							out.print("  Rule_experience = "+rule_experience);out.print("<br>");
							//+++++++++++++RULE LAYER+++++++++++++++++//

							//+++++++++++++CRITERIA LAYER+++++++++++++++++//
							max_rule1 = w_english_R1+w_japan_R1+w_chinese_R1+w_pos_R1+w_ex_R1+w_gpa_R1+w_kb_R1;
							max_rule2 = w_english_R2+w_japan_R2+w_chinese_R2+w_pos_R2+w_ex_R2+w_gpa_R2+w_kb_R2;
							max_rule3 = w_english_R3+w_japan_R3+w_chinese_R3+w_pos_R3+w_ex_R3+w_gpa_R3+w_kb_R3;

							out.print("  max_rule1 = "+max_rule1);out.print("<br>");
							out.print("  max_rule2 = "+max_rule2);out.print("<br>");
							out.print("  max_rule3 = "+max_rule3);out.print("<br>");

							percent_rule1 = (100*Math.abs(rule_language))/max_rule1;
							percent_rule2 = (100*Math.abs(rule_technic))/max_rule2;
							percent_rule3 = (100*Math.abs(rule_experience))/max_rule3;

	  					    if ( rule_language >= 0 ) 
								{	percent_rule1 = 50 + percent_rule1;	}
							if ( rule_language < 0 )
								{	percent_rule1 = 50 - percent_rule1;	}
							if ( rule_technic >= 0 ) 
								{	percent_rule2 = 50 + percent_rule2;	}
							if ( rule_technic < 0 )
								{	percent_rule2 = 50 - percent_rule2;	}
							if ( rule_experience >= 0 ) 
								{	percent_rule3 = 50 + percent_rule3;	}
							if ( rule_experience < 0 )
								{	percent_rule3 = 50 - percent_rule3;	}

							out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");
	/*				
							criteria_rule1 = (max_rule1*c_rule1)/100;
							criteria_rule2 = (max_rule2*c_rule2)/100;
							criteria_rule3 = (max_rule3*c_rule3)/100;

							out.print("  criteria_rule1 = "+criteria_rule1);out.print("<br>");
							out.print("  criteria_rule2 = "+criteria_rule2);out.print("<br>");
							out.print("  criteria_rule3 = "+criteria_rule3);out.print("<br>");

							pass_criteria_rule1 = rule_language - criteria_rule1;
							pass_criteria_rule2 = rule_technic - criteria_rule2;
							pass_criteria_rule3 = rule_experience - criteria_rule3;

							out.print("  pass_criteria_rule1 = "+pass_criteria_rule1);out.print("<br>");
							out.print("  pass_criteria_rule2 = "+pass_criteria_rule2);out.print("<br>");
							out.print("  pass_criteria_rule3 = "+pass_criteria_rule3);out.print("<br>");
							
							percent_rule1 = (50*Math.abs(pass_criteria_rule1))/criteria_rule1;
							percent_rule2 = (50*Math.abs(pass_criteria_rule2))/criteria_rule2;
							percent_rule3 = (50*Math.abs(pass_criteria_rule3))/criteria_rule3;

							out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");

	  					    if ( pass_criteria_rule1 >= 0 ) 
								{	percent_rule1 = percent_rule1;	}
							if ( pass_criteria_rule1 < 0 )
								{	percent_rule1 = 50-percent_rule1;	}
							if ( pass_criteria_rule2 >= 0 ) 
								{	percent_rule2 = percent_rule2;	}
							if ( pass_criteria_rule2 < 0 )
								{	percent_rule2 = 50-percent_rule2;	}
							if ( pass_criteria_rule3 >= 0 ) 
								{	percent_rule3 = percent_rule3;	}
							if ( pass_criteria_rule3 < 0 )
								{	percent_rule3 = 50-percent_rule3;	}
							
							out.print("  percent_rule1 = "+percent_rule1);out.print("<br>");
							out.print("  percent_rule2 = "+percent_rule2);out.print("<br>");
							out.print("  percent_rule3 = "+percent_rule3);out.print("<br>");
*/

							possibility = (percent_rule1+percent_rule2+percent_rule3)/3;
							//+++++++++++++CRITERIA LAYER+++++++++++++++++//
						}//end if (go)
						else
						{ possibility = 0; }
						out.print("  Possibility = "+possibility);
						out.print("<br>");out.print("<br>");out.print("<br>");

						all_jobs_id [count_jobs] = c_id;
						all_jobs_possibility [count_jobs] = possibility;
					} // end while
					myresult_jobs.close();
			}// end try
		catch(Exception e)
			{ }
									
															

} // end for
%>











</body>
</html>
