<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Jobs</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<%
String id_jobs = request.getParameter("id");

    StringTokenizer st;
	int num;
	String[ ] knowledge;
	int i;
	int write_knowledge = 0;

	 String sql_d_jobs = "select * from job where ID = '"+id_jobs+"' ";
     ResultSet myresult_d_jobs = stmt.executeQuery(sql_d_jobs);
	 while(myresult_d_jobs.next())
	        {  
			  %>

<table width="600" border="0">
  <tr>
    <td width="70" class="style2">Company</td>
    <td width="530" class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("COMPANY")%></td>
  </tr>
<tr>
    <td class="style2">Location</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("LOCATION")%></td>
  </tr>
  <tr>
    <td class="style2">City</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("CITY")%></td>
  </tr>
  <tr>
    <td class="style2">Position</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("POSITION")%></td>
  </tr> 
  <tr>
    <td class="style2">Salary</td>
    <td class="style3">:&nbsp;&nbsp;<%if (myresult_d_jobs.getInt("SALARY") == 0) { out.print("Negotiate"); } else { out.print( myresult_d_jobs.getInt("SALARY") ); }%></td>
  </tr> 
  <tr>
    <td class="style2">Experience</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("EXPERIENCE")%></td>
  </tr> 
  <tr>
    <td class="style2">Qualification</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("QUALIFICATION")%></td>
  </tr> 
  <tr>
    <td class="style2">Job Type</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("FULL_PART")%></td>
  </tr> 
  <tr>
    <td class="style2">Date Post </td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_jobs.getString("DATE")%></td>
  </tr> 


   <% if ( !myresult_d_jobs.getString("SOFTWARE").equals("-") )
		{   st = new StringTokenizer(myresult_d_jobs.getString("SOFTWARE"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style2"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

  <% if ( !myresult_d_jobs.getString("HARDWARE").equals("-") )
		{   st = new StringTokenizer(myresult_d_jobs.getString("HARDWARE"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style2"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_d_jobs.getString("NETWORK").equals("-") )
		{   st = new StringTokenizer(myresult_d_jobs.getString("NETWORK"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style2"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_d_jobs.getString("DB").equals("-") )
		{   st = new StringTokenizer(myresult_d_jobs.getString("DB"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style2"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>

   <% if ( !myresult_d_jobs.getString("OS").equals("-") )
		{   st = new StringTokenizer(myresult_d_jobs.getString("OS"),",");
			num = st.countTokens();
			knowledge = new String[num];  			
			write_knowledge++;
	%>
  <tr align="left">
    <td class="style2"><%if (write_knowledge == 1 ) { out.print("Knowledge"); } else { out.print("&nbsp;"); }%></td>
    <td colspan="3" class="style3">:&nbsp;&nbsp;<%
		for (i = 0; i<num; i++)
				{	knowledge[i] = new String (st.nextToken()); 
					if ( !knowledge[i].equals("-") ) 
						{ if ( i != 0 ) { out.print(","); } out.print(knowledge[i]); }
				}%></td>
  </tr>
    <% }  %>
	</table>
<%
	 }
     myresult_d_jobs.close();
	 %>

</body>
</html>
