<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
 <%@ page import="ecom.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add File</title>

<%
MultiPart mp = new MultiPart(request);
String Submit_attach = mp.getParameter("Submit_attach");

    // if click Submit_attach
if (Submit_attach != null)
{  	   
	  float sum_size = 0;
	  File file1    = mp.getFile("file1");
      String  filename1 = file1.getName();
	  float size1 = file1.getSize();
	  size1 = size1/1024;
	  sum_size = sum_size + size1;
	  if (filename1.equals("")) { filename1 = "None" ;}

	  File file2    = mp.getFile("file2");
      String  filename2 = file2.getName();
	  float size2 = file2.getSize();
	  size2 = size2/1024;
	 sum_size = sum_size + size2;
	 if (filename2.equals("")) { filename2 = "None" ;}

	  File file3    = mp.getFile("file3");
      String  filename3 = file3.getName();
	  float size3 = file3.getSize();
	  size3 = size3/1024;
      sum_size = sum_size + size3;
	  if (filename3.equals("")) { filename3 = "None" ;}

     if (sum_size < 5000 )
	{
		if ( file1.getSize() > 0 )
			{  mp.save(file1,application,"myspace/attach/");  } 
		if ( file2.getSize() > 0 )
			{  mp.save(file2,application,"myspace/attach/");  } 
		if ( file3.getSize() > 0 )
			{  mp.save(file3,application,"myspace/attach/");  } 
			response.sendRedirect("attach.jsp?file1="+filename1+"&file2="+filename2+"&file3="+filename3+"&size1="+size1+"&size2="+size2+"&size3="+size3+"&ss="+sum_size); 
	}  
	else
	{ response.sendRedirect("attach.jsp?error=1");  }
     
		
	   
	// String sql = "INSERT INTO mail(FILE,SIZE) VALUES('"+filename1+"','"+size1+"');";
    // int myresult = stmt.executeUpdate(sql);
	//	if (myresult != 0)
	//	{ }


}//end if Submit_attach

%>
</body>
</html>
