<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add Company</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String name_company = request.getParameter("name_company");
String location = request.getParameter("location");
String city = request.getParameter("city");
String telephone = request.getParameter("telephone");
String e_mail = request.getParameter("e_mail");
String contract = request.getParameter("contract");
String detail = request.getParameter("detail");
String code = request.getParameter("code");
String user = request.getParameter("user");
String pass = request.getParameter("pass");
String re_pass = request.getParameter("re_pass");

String check_user = "";

	 ResultSet myresult_username = stmt.executeQuery("select * from member where username = '"+user+"'  ");
	while(myresult_username.next())
			{ 
					check_user = myresult_username.getString("USERNAME");
			}
     myresult_username.close();   




if ( pass.equals(re_pass) &&  !check_user.equals(user) )
{
	String sql_add = "INSERT INTO member (USERNAME,PASSWORD,TYPE,NAME,SURNAME,SEX,LOCATION,CITY,E_MAIL,CONTRACT,DETAIL,TELEPHONE,CODE,ENGLISH,JAPAN,CHINESE,UNIVERSITY,DEPARTMENT,FACULTY,DEGREE,GRADUATED,COMPANY1,COMPANY2,COMPANY3,POSITION1,POSITION2,POSITION3,YEAR1,YEAR2,YEAR3,S_YEAR1,S_YEAR2,S_YEAR3,U_YEAR1,U_YEAR2,U_YEAR3,PRIVACY,GPA,SOFTWARE,HARDWARE,NETWORK,DB,OS,B_DAY,B_MONTH,B_YEAR,NEWS) VALUES('"+user+"','"+pass+"','2','"+name_company+"',' ','-','"+location+"','"+city+"','"+e_mail+"','"+contract+"','"+detail+"','"+telephone+"','"+code+"','-1','-1','-1','-','-','-','-','0','-','-','-','-','-','-','0','0','0','0','0','0','0','0','0','0','0','-','-','-','-','-','0','0','0','-');";

    int myresult_add = stmt.executeUpdate(sql_add);
	response.sendRedirect("company.jsp");
}
else
{
	
	if ( check_user.equals(user) )
	{	response.sendRedirect("company.jsp?name_company="+name_company+"&location="+location+"&city="+city+"&telephone="+telephone+"&e_mail="+e_mail+"&contract="+contract+"&detail="+detail+"&user="+user+"&code="+code+"&error=2");
	}
	else
	{
			response.sendRedirect("company.jsp?name_company="+name_company+"&location="+location+"&city="+city+"&telephone="+telephone+"&e_mail="+e_mail+"&contract="+contract+"&detail="+detail+"&user="+user+"&code="+code+"&error=1");
	}
	
}
%>
</body>
</html>
