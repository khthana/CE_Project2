<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>News</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<%
String id_news = request.getParameter("id");

	 String sql_d_news = "select TITLE,SUBJECT,DATE,TEXT from news where ID = '"+id_news+"' ";
     ResultSet myresult_d_news = stmt.executeQuery(sql_d_news);
	 while(myresult_d_news.next())
	        {  
			  %>

<table width="600" border="0">
  <tr>
    <td width="70" class="style2">Title</td>
    <td width="530" class="style3">:&nbsp;&nbsp;<%=myresult_d_news.getString("TITLE")%></td>
  </tr>
  <tr>
    <td class="style2">Subject</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_news.getString("SUBJECT")%></td>
  </tr>
  <tr>
    <td class="style2">Date</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_news.getString("DATE")%></td>
  </tr>
  <tr>
    <td width="70" class="style1">&nbsp;</td>
    <td width="530" class="style3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<%=myresult_d_news.getString("TEXT")%></td>
  </tr>
</table>
<%
	 }
     myresult_d_news.close();
	 %>
</body>
</html>
