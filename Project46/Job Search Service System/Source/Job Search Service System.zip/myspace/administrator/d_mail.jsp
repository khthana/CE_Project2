<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Mail</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<%
String id_mail = request.getParameter("id");

	 String sql_d_mail = "select  ID,TITLE,ME,YOU,TEXT,FILE1,FILE2,FILE3,SIZE1,SIZE2,SIZE3,DATE from mail where ID = '"+id_mail+"' ";
     ResultSet myresult_d_mail = stmt.executeQuery(sql_d_mail);
	 while(myresult_d_mail.next())
	        {  
			  %>

<table width="600" border="0">
  <tr>
    <td width="100" class="style2">From</td>
    <td width="500" class="style3">:&nbsp;&nbsp;<%=myresult_d_mail.getString("ME")%></td>
  </tr>
<tr>
    <td class="style2">To</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_mail.getString("YOU")%></td>
  </tr>
  <tr>
    <td class="style2">Title</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_mail.getString("TITLE")%></td>
  </tr>
  <tr>
    <td class="style2">Date</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_mail.getString("DATE")%></td>
  </tr>
  <%
	if ( myresult_d_mail.getFloat("SIZE1") != 0.000 || myresult_d_mail.getFloat("SIZE2") != 0.000 || myresult_d_mail.getFloat("SIZE3") != 0.000 ) 
		{	 	
				if ( myresult_d_mail.getFloat("SIZE1") != 0.000 ) 
				{ %>
							<tr>
							<td class="style2">Attach File</td>
							<td class="style3">:&nbsp;&nbsp;<%
							if ( myresult_d_mail.getFloat("SIZE1") != 0.000 )   
								{ out.print( "<a href='../attach/"+myresult_d_mail.getString("FILE1")+" '>"+myresult_d_mail.getString("FILE1")+"  ["+myresult_d_mail.getFloat("SIZE1")+" K] "+ "</a>"  );  }  %></td>
							</tr>
				<% }
				if ( myresult_d_mail.getFloat("SIZE2") != 0.000 ) 
			   {   %>
							<tr>
							<td class="style2">&nbsp;</td>
							<td class="style3">:&nbsp;&nbsp;<%
							if ( myresult_d_mail.getFloat("SIZE2") != 0.000 )   
								{ out.print( "<a href='../attach/"+myresult_d_mail.getString("FILE2")+" '>"+myresult_d_mail.getString("FILE2")+"  ["+myresult_d_mail.getFloat("SIZE2")+" K] "+ "</a>"  );  }  %></td>
							</tr>
				<%  }
				if ( myresult_d_mail.getFloat("SIZE3") != 0.000 ) 
			    {   %>
							<tr>
							<td class="style2">&nbsp;</td>
							<td class="style3">:&nbsp;&nbsp;<%
							if ( myresult_d_mail.getFloat("SIZE3") != 0.000 )   
								{ out.print( "<a href='../attach/"+myresult_d_mail.getString("FILE3")+" '>"+myresult_d_mail.getString("FILE3")+"  ["+myresult_d_mail.getFloat("SIZE3")+" K] "+ "</a>"  );  }  %></td>
							</tr>
				<%  }
		   }  
		%>
    <tr>
    <td class="style2">&nbsp;</td>
    <td class="style3">&nbsp;&nbsp;&nbsp;<%=myresult_d_mail.getString("TEXT")%></td>
  </tr> 
</table>
<%
	 }
     myresult_d_mail.close();
	 %>
</body>
</html>
