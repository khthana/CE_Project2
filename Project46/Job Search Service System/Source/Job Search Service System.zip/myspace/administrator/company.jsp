<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Company</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
.style6 {color: #FF3366}
-->
</style>
</head>

<body leftmargin="0" topmargin="0"  rightmargin="0" onLoad="MM_preloadImages('Menu_My_Profile_2.gif','Menu_My_Resume_2.gif','Menu_My_Contract_2.gif','Menu_My_History_2.gif','Menu_Webboard_2.gif','Menu_Mail_2.gif','Menu_Jobs_2.gif','Menu_News_2.gif','Menu_Private_Message_2.gif','Menu_E_mail_2.gif','Menu_Agent_2.gif','Menu_Search_2.gif','image/Menu_Jobs_2.gif','image/Menu_Company_2.gif')">
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>

<%
String name = "";
String surname = "";
String sql_name = "select NAME,SURNAME from member where ID = '"+id+"'";
ResultSet myresult_name = stmt.executeQuery(sql_name);
while(myresult_name.next())
{ 
	name = myresult_name.getString("NAME"); 
	surname = myresult_name.getString("SURNAME"); 
}
     myresult_name.close();
%>
<div id="Layer1" style="position:absolute; left:17px; top:112px; width:261px; height:22px; z-index:1" class="style4">
<div align="center" class="style5"><%=name+"   "+surname%></div>
</div>
<div id="Layer9" style="position:absolute; left:30px; top:485px; width:81px; height:24px; z-index:17"><a href="boardlist.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('webboard','','../administrator/image/Menu_Webboard_2.gif',1)"><img src="../administrator/image/Menu_Webboard.gif" alt="Webboard" name="webboard" width="81" height="24" border="0"></a></div>
<div id="Layer6" style="position:absolute; left:17px; top:176px; width:135px; height:27px; z-index:6"><img src="image/Menu_Information.gif" width="135" height="27"></div>
<div id="Layer7" style="position:absolute; left:30px; top:274px; width:74px; height:24px; z-index:7"><img src="image/Menu_Compose.gif" width="74" height="24"></div>
<div id="Layer8" style="position:absolute; left:30px; top:382px; width:47px; height:24px; z-index:8"><img src="image/Menu_Help.gif" width="47" height="24"></div>
<div id="Layer10" style="position:absolute; left:15px; top:301px; width:161px; height:23px; z-index:10"><a href="private_message.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Private_Message','','image/Menu_Private_Message_2.gif',1)"><img src="image/Menu_Private_Message.gif" alt="Private Message" name="Private_Message" width="161" height="23" border="0"></a></div>
<div id="Layer11" style="position:absolute; left:16px; top:329px; width:161px; height:23px; z-index:11"><a href="e_mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('E-Mail','','image/Menu_E_mail_2.gif',1)"><img src="image/Menu_E_mail.gif" alt="E-Mail" name="E-Mail" width="161" height="23" border="0"></a></div>
<div id="Layer12" style="position:absolute; left:15px; top:409px; width:161px; height:23px; z-index:12"><a href="job.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('job','','image/Menu_Jobs_2.gif',1)"><img src="image/Menu_Jobs.gif" alt="Job" name="job" width="161" height="23" border="0"></a></div>
<div id="Layer13" style="position:absolute; left:15px; top:436px; width:161px; height:23px; z-index:13"><a href="company.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('company','','image/Menu_Company_2.gif',1)"><img src="image/Menu_Company.gif" alt="Company" name="company" width="161" height="23" border="0"></a></div>
<div id="Layer14" style="position:absolute; left:15px; top:205px; width:161px; height:23px; z-index:14"><a href="mail.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mail','','image/Menu_Mail_2.gif',1)"><img src="image/Menu_Mail.gif" alt="Mail" name="Mail" width="161" height="23" border="0"></a></div>
<div id="Layer16" style="position:absolute; left:15px; top:232px; width:161px; height:23px; z-index:16"><a href="new.jsp" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('News','','image/Menu_News_2.gif',1)"><img src="image/Menu_News.gif" alt="News" name="News" width="161" height="23" border="0"></a></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" height="150" valign="top"><img src="image/Head_Left.jpg" width="280" height="150"></td>
    <td width="80%" height="150" valign="top"><img src="image/Head_Center.jpg" width="100%" height="150"></td>
    <td width="10%" height="150" valign="top"><img src="image/Head_Right.jpg" width="345" height="150"></td>
  </tr>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  
  <tr>
    <td width="220" height="371" rowspan="9" valign="top"><img src="image/Menu_BG.jpg" width="220" height="371"></td>
    <td width="0" height="371" rowspan="9" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td  height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="100%" height="371" rowspan="9">&nbsp;</td>
  </tr>
  <tr>
    <td width="20"  height="12"><img src="image/K_conner_top_left.jpg" width="20" height="12"></td>
    <td width="650"  height="12"><img src="image/K_conner_top_center.jpg" width="650" height="12"></td>
    <td width="40"  height="12"><img src="image/K_conner_top_right.jpg" width="40" height="12"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_top.jpg" width="20" height="20"></td>
    <td width="784" rowspan="3" valign="top"><table width="100%" border="0" cellpadding="0">
      <tr>
        <td align="right"><img src="image/Titel_company.jpg" width="460" height="35"></td>
      </tr>
      <tr>
        <td align="left">
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	<%
String name_company = request.getParameter("name_company");
String location = request.getParameter("location");
String city = request.getParameter("city");
String telephone = request.getParameter("telephone");
String e_mail = request.getParameter("e_mail");
String contract = request.getParameter("contract");
String detail = request.getParameter("detail");
String user = request.getParameter("user");
String code = request.getParameter("code");
String error = request.getParameter("error");


if ( name_company == null ) { name_company = ""; }
if ( location == null ) { location = ""; }
if ( city == null ) { city = ""; }
if ( telephone == null ) { telephone = ""; }
if ( e_mail == null ) { e_mail = ""; }
if ( contract == null ) { contract = ""; }
if ( detail == null ) { detail = ""; }
if ( user == null ) { user = ""; }
if ( code == null ) { code = ""; }
	%>
		
		
		
		
		
		<form action="add_company.jsp" method="post" name="form1" onSubmit="MM_validateForm('name_company','','R','location','','R','city','','R','code','','RisNum','telephone','','R','e_mail','','NisEmail','user','','R','pass','','R','re_pass','','R');return document.MM_returnValue" >

<table width="600" border="0">
  <tr valign="top" class="style1">
    <td width="275" height="40"><div align="center"><a href="company.jsp">Add Company</a></div></td>
    <td width="365"><div align="center"><a href="delete_company.jsp">Delete Company</a> </div>      
      <div align="center"></div></td>
    </tr>
</table>

<table width="600" border="0">
  <tr align="left">
    <td colspan="3" class="style2"><u>Company</u><span class="style6"><%
	if ( error != null )
		{
				if (error.equals("1")) 
					{ out.print("              Password and Re-Password does't match");  }
				if (error.equals("2")) 
					{ out.print("              This Username alredy use");  }
		}
	%></span></td>
  </tr>
  <tr align="left">
    <td width="90" class="style1">Name</td>
    <td width="13" class="style1">:</td>
    <td width="483" class="style3">&nbsp;<input name="name_company" type="text" size="25" maxlength="25"  value="<%=name_company%>"></td>
    </tr>
  <tr align="left">
    <td class="style1">Location</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="location" type="text" size="50" maxlength="100"  value="<%=location%>"></td>
    </tr>
  <tr align="left">
    <td class="style1">City</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="city" type="text" id="city" size="25" maxlength="50"  value="<%=city%>"></td>
  </tr>
    <tr align="left">
    <td class="style1">Code</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="code" type="text" id="code" size="5" maxlength="5"  value="<%=code%>"></td>
  </tr>
   <tr align="left">
    <td class="style1">Telephone</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="telephone" type="text" id="telephone" size="25" maxlength="50"  value="<%=telephone%>"></td>
  </tr>
  <tr align="left">
    <td class="style1">E-Mail</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="e_mail" type="text" id="e_mail" size="25" maxlength="50"   value="<%=e_mail%>"></td>
    </tr>
  <tr align="left">
    <td class="style1">Contract</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="contract" type="text" id="contract"  size="50" maxlength="50"  value="<%=contract%>"></td>
    </tr>
	<tr align="left">
    <td valign="top" class="style1">Detail</td>
    <td valign="top" class="style1">:</td>
    <td valign="top" class="style3">&nbsp;<textarea name="detail" cols="50" rows="5" ><%=detail%></textarea></td>
    </tr>
	<tr align="left">
    <td class="style1">Username</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="user" type="text" id="user"  size="20" maxlength="20"  value="<%=user%>"></td>
    </tr>
	<tr align="left">
    <td class="style1">Password</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="pass" type="password" id="pass"  size="20" maxlength="20" ></td>
    </tr>
	<tr align="left">
    <td class="style1">Re-Password</td>
    <td class="style1">:</td>
    <td class="style3">&nbsp;<input name="re_pass" type="password" id="re_pass"  size="20" maxlength="20" ></td>
    </tr>
</table>


<table width="600"  border="0" cellpadding="0">
  <tr>
    <td width="110">&nbsp;</td>
    <td width="484" align="left">&nbsp;<input type="submit" name="Submit" value="  Add  ">&nbsp;&nbsp;&nbsp;<input type="reset" name="Submit2" value="Reset"></td>
    </tr>
</table>
</form>		






































</td>
      </tr>
    </table></td>
    <td width="35" height="20"><img src="image/K_middel_top2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td width="20" height="249"><img src="image/K_middel_center.jpg" width="20" height="510"></td>
    <td width="40" height="249"><img src="image/K_middel_center2.jpg" width="40" height="510"></td>
  </tr>
  <tr>
    <td width="20" height="20"><img src="image/K_middel_bottom.jpg" width="20" height="20"></td>
    <td width="40" height="20"><img src="image/K_middel_bottom2.jpg" width="40" height="20"></td>
  </tr>
  <tr>
    <td height="30" width="20"><img src="image/K_conner_bottom_left.jpg" width="20" height="30"></td>
    <td height="30" width="650"><img src="image/K_conner_bottom_center.jpg" width="650" height="30"></td>
    <td height="30" width="40"><img src="image/K_conner_bottom_right.jpg" width="40" height="30"></td>
  </tr>
  
  <tr>
    <td height="20" colspan="3"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Left.jpg" width="440" height="15"></td>
    <td width="80%" valign="top" height="15"><img src="image/Tail_Center.jpg" width="100%" height="15"></td>
    <td width="10%" valign="top" height="15"><img src="image/Tail_Right.jpg" width="165" height="15"></td>
  </tr>
</table>
</body>
</html>
