<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Company</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
.style5 {font-size: 16px; font-family: "-JS Junkaew";}
-->
</style>
</head>

<body>
<%
String id_company = request.getParameter("id");

	 String sql_d_company = "select * from member where ID = '"+id_company+"' ";
     ResultSet myresult_d_company = stmt.executeQuery(sql_d_company);
	 while(myresult_d_company.next())
	        {  
			  %>

<table width="600" border="0">
  <tr>
    <td width="70" class="style2">Name</td>
    <td width="530" class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("NAME")%></td>
  </tr>
  <tr>
    <td class="style2">Location</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("LOCATION")%></td>
  </tr>
  <tr>
    <td class="style2">City</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("CITY")%></td>
  </tr>
    <tr>
    <td class="style2">Code</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("CODE")%></td>
  </tr>
    <tr>
    <td class="style2">Telephone</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("TELEPHONE")%></td>
  </tr>
    <tr>
    <td class="style2">E-Mail</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("E_MAIL")%></td>
  </tr>
    <tr>
    <td class="style2">Contract</td>
    <td class="style3">:&nbsp;&nbsp;<%=myresult_d_company.getString("CONTRACT")%></td>
  </tr>
  <tr>
    <td width="70" class="style1">&nbsp;</td>
    <td width="530" class="style3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<%=myresult_d_company.getString("DETAIL")%></td>
  </tr>
</table>
<%
	 }
     myresult_d_company.close();
	 %>
</body>
</html>
