<%
/*out.println(to);
out.println(subject);
out.println(text);
out.println(file1);out.println(file2);out.println(file3);
out.println(size1);out.println(size2);out.println(size3);
*/
username =  username+"@myspace.com" ;
	
Calendar c = Calendar.getInstance();
int month =  c.get(c.MONTH);
month = month+1;
String day = c.get(c.DAY_OF_MONTH)+"/"+month+"/"+c.get(c.YEAR)  ;
//out.println(day);

StringTokenizer st = new StringTokenizer(to,",");
int num = st.countTokens();

String[ ] to2 = new String[num];

for (int i = 0; i<num; i++)
{	
	to2[i] = new String(st.nextToken());
	 String sql = "INSERT INTO mail (FILE1,FILE2,FILE3,SIZE1,SIZE2,SIZE3,DATE,TITLE,TEXT,ME,YOU) VALUES('"+file1+"','"+file2+"','"+file3+"','"+size1+"','"+size2+"','"+size3+"','"+day+"','"+subject+"','"+text+"','"+username+"','"+to2[i]+"');";
     int myresult = stmt.executeUpdate(sql);
	 if (myresult != 0)
		{  }
}
if (num >= 1)
{out.println("Private Message Send");}
else
{response.sendRedirect("private_message.jsp");}

%>