<%
					Class.forName("com.mysql.jdbc.Driver").newInstance();				         			
					Connection mycon = DriverManager.getConnection("jdbc:mysql://localhost/myspace?user=monchai&password=monchai");
         		    Statement stmt = mycon.createStatement();
%> 