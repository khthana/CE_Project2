<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html> 
<head> 
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ include file = "connect_to_database.jsp"%>
<%@ include file = "session_member.jsp"%>
<%@page contentType="text/html; charset = TIS-620"%>
<title>Add News</title>
<meta http-equiv="Content-Type" content="text/html; ccharset = TIS-620">
<style type="text/css">
<!--
.style1 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	
}
.style2 {
	font-family: "-JS Junkaew";
	font-size: 18px;
	font-weight: bold;
}
.style3 {
	font-family: "-JS Junkaew";
	font-size: 18px;
}
.style4 {font-size: 12px}
-->
</style>
</head>

<body>
			
<%
String title = request.getParameter("title");
String text = request.getParameter("text");
String subject = request.getParameter("subject");

Calendar c = Calendar.getInstance();
int month =  c.get(c.MONTH);
month = month+1;
String day = c.get(c.DAY_OF_MONTH)+"/"+month+"/"+c.get(c.YEAR)  ;

/*
StringTokenizer st_member;
int num_member= 0;
String[ ] sm_member ;

st_m_software = new StringTokenizer(m_software,",");
num_m_software = st_m_software.countTokens();
sm_software= new String[num_m_software];
for (i = 0; i<num_m_software; i++)
{ sm_software[i] = new String (st_m_software.nextToken()); }
*/

int num_member = 0;

		ResultSet myresult_num_member = stmt.executeQuery("select count(*) as num from member where TYPE = '1' and NEWS like '%"+title+"%' ");
		while(myresult_num_member.next())
					{ 	 num_member = myresult_num_member.getInt("num");}
		myresult_num_member.close();

String  [ ] id_member = new String[num_member+1];
int num = 1;


		ResultSet myresult_id_member = stmt.executeQuery("select * from member where TYPE = '1'  and NEWS like '%"+title+"%' ");
		while(myresult_id_member.next())
					{ 	 id_member[num] = myresult_id_member.getString("ID");	num++; }
		myresult_id_member.close();

id_member[0] = id;

/*for ( int i = 0; i<num_member;  i++)
{  out.print(id_member[i]);   }*/
String sql_add = "";

for ( int i = 0; i<=num_member;  i++)
{ 
	sql_add = "INSERT INTO news (ID_MEMBER,TITLE,SUBJECT,TEXT,DATE) VALUES('"+id_member[i]+"','"+title+"','"+subject+"','"+text+"','"+day+"');"; 
    int myresult_add_contract = stmt.executeUpdate(sql_add);
}
	response.sendRedirect("add_news.jsp");
%>
</body>
</html>
