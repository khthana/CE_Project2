# MySQL-Front 3.0


# Host: monchai    Database: myspace
# ------------------------------------------------------
# Server version 4.0.17-nt

#
# Table structure for table apply
#

CREATE TABLE `apply` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_company` varchar(5) default NULL,
  `id_member` varchar(5) default NULL,
  `id_job` varchar(5) default NULL,
  `name` varchar(100) default NULL,
  `surname` varchar(100) default NULL,
  `age` int(2) default NULL,
  `department` varchar(100) default NULL,
  `faculty` varchar(100) default NULL,
  `degree` varchar(100) default NULL,
  `date` varchar(10) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table apply
#

INSERT INTO `apply` VALUES (15,'3','2','13','Monchai','Pattarachaonakul',22,'Engineer','Computer','Bachelor','20/3/2547');
INSERT INTO `apply` VALUES (16,'3','2','1','Monchai','Pattarachaonakul',22,'Engineer','Computer','Bachelor','20/3/2547');

#
# Table structure for table board_ans
#

CREATE TABLE `board_ans` (
  `id_ans` int(10) unsigned NOT NULL auto_increment,
  `id_ques` int(10) unsigned default NULL,
  `name` varchar(40) default NULL,
  `email` varchar(40) default NULL,
  `detail` varchar(20) default NULL,
  `ip` varchar(15) default NULL,
  `datepost` datetime default NULL,
  PRIMARY KEY  (`id_ans`)
) TYPE=MyISAM;


#
# Dumping data for table board_ans
#

INSERT INTO `board_ans` VALUES (1,9,'sdfsf','sfsfafsaf','safsaffafasf','161.246.5.133','2004-03-21 23:58:55');
INSERT INTO `board_ans` VALUES (2,9,'sadfsfsf','dsafsafsafsaf','safsafsafsfsafsfsafs','161.246.5.133','2004-03-21 23:59:20');
INSERT INTO `board_ans` VALUES (3,9,'sfds','fsafs','fsafaf','161.246.5.133','2004-03-21 23:59:58');

#
# Table structure for table board_ques
#

CREATE TABLE `board_ques` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `topic` varchar(150) default NULL,
  `name` varchar(20) default '0',
  `email` varchar(40) default NULL,
  `detail` text,
  `ip` varchar(15) default NULL,
  `datepost` datetime default '0000-00-00 00:00:00',
  `lastpost` datetime default '0000-00-00 00:00:00',
  `lastname` varchar(40) default NULL,
  `view` smallint(5) unsigned default '0',
  `ans` smallint(5) unsigned default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;


#
# Dumping data for table board_ques
#

INSERT INTO `board_ques` VALUES (8,'Test','Test','Test@Test.com','Test','127.0.0.1','2004-03-21 20:17:25','2004-03-21 20:17:25','Test',6,0);
INSERT INTO `board_ques` VALUES (9,'sdfs','fsfsa','fsfaf','safa','161.246.5.133','2004-03-21 23:58:44','2004-03-21 23:59:58','sfds',6,3);
INSERT INTO `board_ques` VALUES (10,'fsadffsafsaf','sfsa','fsafas','dfsaffd','161.246.5.133','2004-03-21 23:59:49','2004-03-21 23:59:49','sfsa',1,0);
INSERT INTO `board_ques` VALUES (11,'safdss','sfdf','fasff','sfdafdf','161.246.5.133','2004-03-22 01:57:16','2004-03-22 01:57:16','sfdf',0,0);
INSERT INTO `board_ques` VALUES (12,'aaaa','aaa','aaa','aa','161.246.5.133','2004-03-22 01:57:23','2004-03-22 01:57:23','aaa',0,0);
INSERT INTO `board_ques` VALUES (13,'adsfs','afsafdadf','fsa','dfadfafda','161.246.5.133','2004-03-22 01:57:30','2004-03-22 01:57:30','afsafdadf',0,0);
INSERT INTO `board_ques` VALUES (14,'safsa','fafdsaf','saf','afafdfd','161.246.5.133','2004-03-22 01:57:33','2004-03-22 01:57:33','fafdsaf',0,0);
INSERT INTO `board_ques` VALUES (15,'fdsafsaf','safda','dfafafd','afsaf','161.246.5.133','2004-03-22 01:57:37','2004-03-22 01:57:37','safda',0,0);
INSERT INTO `board_ques` VALUES (16,'safsd','dsafa','df','fsadfadff','161.246.5.133','2004-03-22 01:57:40','2004-03-22 01:57:40','dsafa',0,0);
INSERT INTO `board_ques` VALUES (17,'safsa','fffsdadf','afsa','afaff','161.246.5.133','2004-03-22 01:57:44','2004-03-22 01:57:44','fffsdadf',0,0);
INSERT INTO `board_ques` VALUES (18,'sfsaf','dsadf','sdafsafdsa','fsafsaf','161.246.5.133','2004-03-22 01:57:48','2004-03-22 01:57:48','dsadf',8,0);

#
# Table structure for table history
#

CREATE TABLE `history` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_member` varchar(5) default NULL,
  `id_post` varchar(5) default NULL,
  `company` varchar(100) default NULL,
  `location` varchar(100) default NULL,
  `position` varchar(100) default NULL,
  `date` varchar(10) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table history
#

INSERT INTO `history` VALUES (37,'2','13','Company Sony','Bangkok','Programmer','20/3/2547');
INSERT INTO `history` VALUES (36,'2','13','Sony','Bangkok','Programmer','17/3/2547');

#
# Table structure for table history_c
#

CREATE TABLE `history_c` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_company` varchar(5) default NULL,
  `id_member` varchar(5) default NULL,
  `id_job` varchar(5) default NULL,
  `name` varchar(100) default NULL,
  `surname` varchar(100) default NULL,
  `age` int(2) default NULL,
  `department` varchar(100) default NULL,
  `faculty` varchar(100) default NULL,
  `degree` varchar(100) default NULL,
  `date` varchar(10) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table history_c
#

INSERT INTO `history_c` VALUES (1,'3','1','1','Monchai','Pattarachaonakul',22,'Engineer','Engineer','Bachelor','18/03/2547');
INSERT INTO `history_c` VALUES (3,'3','2','1','Monchai','Pattarachaonakul',22,'Engineer','Computer','Bachelor','20/3/2547');
INSERT INTO `history_c` VALUES (4,'3','2','13','Monchai','Pattarachaonakul',22,'Engineer','Computer','Bachelor','20/3/2547');

#
# Table structure for table interview
#

CREATE TABLE `interview` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_company` varchar(10) default NULL,
  `id_member` varchar(10) default NULL,
  `id_post` varchar(4) default NULL,
  `company` varchar(100) default NULL,
  `location` varchar(100) default NULL,
  `position` varchar(100) default NULL,
  `date` varchar(10) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table interview
#

INSERT INTO `interview` VALUES (1,'3','2','1','Sony','Bangkok','Programmer','10-12-2004');
INSERT INTO `interview` VALUES (3,'3','2','1','Company Sony','Bangkok','Computer�Network�Engineer','20/3/2547');
INSERT INTO `interview` VALUES (4,'3','2','13','Company Sony','Bangkok','Programmer','20/3/2547');

#
# Table structure for table job
#

CREATE TABLE `job` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_company` varchar(10) default NULL,
  `name_job` varchar(100) default NULL,
  `company` varchar(100) NOT NULL default '',
  `position` text NOT NULL,
  `qualification` varchar(100) NOT NULL default '',
  `full_part` varchar(100) NOT NULL default '',
  `location` text NOT NULL,
  `city` varchar(100) default NULL,
  `salary` int(10) default NULL,
  `experience` int(2) default NULL,
  `date` varchar(10) default NULL,
  `knowledge` text,
  `age` int(2) default NULL,
  `english` int(2) default NULL,
  `japan` int(2) default NULL,
  `chinese` int(2) default NULL,
  `gpa` double(3,2) default NULL,
  `rule_language` int(3) default NULL,
  `rule_knowledge` int(3) default NULL,
  `rule_experience` int(3) default NULL,
  `software` text,
  `hardware` text,
  `network` text,
  `db` text,
  `os` text,
  `sex` varchar(20) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table job
#

INSERT INTO `job` VALUES (13,'3','1','Company Sony','Programmer','Bachelor','Full Time','95/7 Soi3 Saiload Road Parknum Muang','Bangkok',0,1,'21/3/2547','java,linux,cisco',25,2,0,1,2.75,30,20,40,'.NET,ActiveX','-','-','-','-','Male/Female');

#
# Table structure for table mail
#

CREATE TABLE `mail` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `me` varchar(100) default NULL,
  `you` varchar(100) default NULL,
  `text` text,
  `file1` varchar(100) default NULL,
  `file2` varchar(100) default NULL,
  `file3` varchar(100) default NULL,
  `size1` float(10,3) default NULL,
  `size2` float(10,3) default NULL,
  `size3` float(10,3) default NULL,
  `date` varchar(100) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table mail
#

INSERT INTO `mail` VALUES (53,'test','a@myspace.com','mon5e@hotmail.com','aaa','None','None','None',0,0,0,'21/3/2547');
INSERT INTO `mail` VALUES (54,'test','a@myspace.com','mon5e@hotmail.com','aaa','None','None','None',0,0,0,'21/3/2547');
INSERT INTO `mail` VALUES (55,'sdfs','b@myspace.com','mon5e@myspace.com','fsaff','None','None','None',0,0,0,'22/3/2547');
INSERT INTO `mail` VALUES (56,'web project','a@myspace.com','magician_ch2@hotmail.com','&#3607;&#3604;&#3626;&#3629;&#3610;','null','null','null',0,0,0,'22/3/2547');
INSERT INTO `mail` VALUES (57,'web project','a@myspace.com','019061184@gsmadvance.com','&#3607;&#3604;&#3626;&#3629;&#3610;','null','null','null',0,0,0,'22/3/2547');
INSERT INTO `mail` VALUES (43,'Test 1','mon5e@myspace.com','b@myspace.com','aaaaaaaaaaaaaabbbbbbbbbbbbbbbbb','0024_bea.jpg','0008_110.jpg','None',0.932,0.873,0,'10/3/2547');
INSERT INTO `mail` VALUES (44,'Test 2','mon5e@myspace.com','b@myspace.com','aaaaaaaaaaaaaabbbbbbbbbbbbbbbbb','0024_bea.jpg','0008_110.jpg','None',0.932,0.873,0,'10/3/2547');
INSERT INTO `mail` VALUES (45,'Test 3','mon5e@myspace.com','b@myspace.com','fadfadf','null','null','null',0,0,0,'10/3/2547');

#
# Table structure for table member
#

CREATE TABLE `member` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `type` char(1) NOT NULL default '',
  `session` varchar(100) default NULL,
  `name` varchar(100) NOT NULL default '',
  `surname` varchar(100) NOT NULL default '',
  `sex` varchar(100) default NULL,
  `location` text,
  `telephone` varchar(100) default NULL,
  `city` varchar(100) default NULL,
  `code` int(5) default NULL,
  `e_mail` varchar(100) default NULL,
  `english` int(1) default NULL,
  `japan` int(1) default NULL,
  `chinese` int(1) default NULL,
  `university` varchar(100) default NULL,
  `department` varchar(100) default NULL,
  `faculty` varchar(100) default NULL,
  `degree` varchar(100) default NULL,
  `graduated` int(4) default NULL,
  `company1` varchar(100) default NULL,
  `year1` int(2) default NULL,
  `s_year1` int(4) default NULL,
  `u_year1` int(4) default NULL,
  `position1` varchar(100) default NULL,
  `company2` varchar(100) default NULL,
  `year2` int(2) default NULL,
  `s_year2` int(4) default NULL,
  `u_year2` int(4) default NULL,
  `position2` varchar(100) default NULL,
  `company3` varchar(100) default NULL,
  `year3` int(2) default NULL,
  `s_year3` int(4) default NULL,
  `u_year3` int(4) default NULL,
  `position3` varchar(100) default NULL,
  `privacy` varchar(5) default NULL,
  `gpa` double(3,2) default NULL,
  `software` text,
  `hardware` text,
  `network` text,
  `db` text,
  `os` text,
  `b_day` int(2) default NULL,
  `b_month` int(2) default NULL,
  `b_year` int(4) default NULL,
  `contract` varchar(100) default NULL,
  `detail` text,
  `news` text,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table member
#

INSERT INTO `member` VALUES (1,'a','a','0','7E567513EABE01658D1B7538E51F3C8A','Nareumon','Piyawat','FeMale','95/7 Soi3 Saiload Road Parknum Muang','01-1234567','Bangkok',10270,'mmm@yahoo.com',1,-1,-1,'Chula','Architecture','Industrial Design','Bachelor',2006,'-',0,0,0,'-','-',0,0,0,'-','-',0,0,0,'-','0',3.33,'-','vhdl,fpga','-','-','-',21,10,2525,NULL,NULL,NULL);
INSERT INTO `member` VALUES (2,'b','b','1','6EE90BF2534879B10A5B039B15185750','Monchai','Pattarachaonakul','Male','95/7 Soi3 Saiload Road Parknum Muang','01-8750592','Bangkok',10280,'mon5e@yahoo.com',1,-1,-1,'Kmitl','Engineer','Computer','Bachelor',2004,'aaa',2,0,0,'Programmer','-',0,0,0,'-','-',0,0,0,'-','1',2.7,'.NET,ActiveX,-','MCS-51,-','Data Communication,IDS,-','Oracle,-','Linux,-',21,10,2525,NULL,NULL,'University,Java,VC++,XML,DB2');
INSERT INTO `member` VALUES (3,'c','c','2','6EE90BF2534879B10A5B039B15185750','Company','',NULL,'4524353',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `member` VALUES (4,'d','d','1',NULL,'sdfsf','sfsaf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'University,Java,VC++,XML,DB2');
INSERT INTO `member` VALUES (9,'Reuter','r','0',NULL,'Reuters Software','',NULL,'23rd Floor, U Chu Liang Building 968 Rama IV Road, Silom, Bangrak Bangkok ','0-2637- 5600 ext. 602/606','Bangkok',10500,'bkk.hr@reuters.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Human Resource Department','aaaaaaaaaaaa',NULL);
INSERT INTO `member` VALUES (8,'vv','vv','0',NULL,'sdfsa','',NULL,'fsfsaf','sadff','safafafsafsaf',0,'fsafaf@safsaf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'safddf','dfsafsafsafs',NULL);
INSERT INTO `member` VALUES (10,'Matshita','M','0',NULL,'Matsushita Refrigeration','',NULL,' 60 Moo 19 Navanakorn Estate Zone 2 Phaholyothin Rd. Tumbol Klongneung Amphur Klongluang ','0-2529-1742-6, 0-2909-5710 (8 lines),','Pathumthani',12120,'recruit@marcot.panasonic.co.th',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Human Resources Department','Take A Great Advance Innovation By Activities� The Matsushita Refrigeration Company (Thailand) Limited or MARCOT has dedicated it self to the local supply of parts and they increase of productivity, while making efforts to develop new high-quality products with the transfer of accomplished technology which is highly required for the growth of the community in Thailand. We will continue to devote ourselves to further development to enhance the prosperity and happiness of all the people in the world. MARCOT manufactures five main products : COIL, THERMOSTAT, DEFROST HEATER, WATER SUPPLIES PUMP AND VENDING MECHANISM. ',NULL);
INSERT INTO `member` VALUES (11,'Hitachi','h','0',NULL,'Hitachi Consumer Products','',NULL,'610-1 Moo 9 Tambol Nongki, Amphur Kabinburi,','037-284-000, Fax: 037-284-174','Prachinburi',25110,'recruitment@hcpt.hitachi-asia.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'K.Jakkrist Jaroensiri','Hitachi Consumer Products (Thailand),Ltd. \r\n  We are an affiliated company of Hitachi Home of Life Solutions, Inc.(Japan),one of the leading manufacturers of home appliances. Due to expansion, we are now offering very challenging career opportunities for the right candidates to join our team for the following positions \r\n',NULL);

#
# Table structure for table mycontact
#

CREATE TABLE `mycontact` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_member` varchar(10) NOT NULL default '',
  `quick_name` varchar(100) NOT NULL default '',
  `first_name` varchar(100) NOT NULL default '',
  `last_name` varchar(100) NOT NULL default '',
  `company_name` varchar(100) default NULL,
  `e_mail` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table mycontact
#

INSERT INTO `mycontact` VALUES (1,'2','test 1','monchai','pattara','Kmitl','mon5e@myspace.com');
INSERT INTO `mycontact` VALUES (2,'2','test 2','monchai','pattara','Kmitl','pattarcha@myspace.com');

#
# Table structure for table name_job
#

CREATE TABLE `name_job` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `name_news` varchar(100) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table name_job
#

INSERT INTO `name_job` VALUES (1,'-','University');
INSERT INTO `name_job` VALUES (2,'Assistant&nbsp;System&nbsp;Analyst','.COM');
INSERT INTO `name_job` VALUES (3,'Client&nbsp;Site&nbsp;Service&nbsp;Engineer','.NET&nbsp;Technology&nbsp;');
INSERT INTO `name_job` VALUES (4,'Computer&nbsp;Engineer','ABAP4&nbsp;');
INSERT INTO `name_job` VALUES (5,'Computer&nbsp;Network&nbsp;Engineer','ActiveX');
INSERT INTO `name_job` VALUES (6,'Computer&nbsp;System&nbsp;Officer','ASP');
INSERT INTO `name_job` VALUES (7,'Data&nbsp;Security&nbsp;(Network/&nbsp;OS)','C/C++');
INSERT INTO `name_job` VALUES (8,'Information&nbsp;Technology','COBOL&nbsp;');
INSERT INTO `name_job` VALUES (9,'Integration&nbsp;Application&nbsp;Engineer','Delphi');
INSERT INTO `name_job` VALUES (10,'Intelligent&nbsp;Network&nbsp;Engineer','Design&nbsp;Patterns');
INSERT INTO `name_job` VALUES (11,'IT&nbsp;Manager','EJB');
INSERT INTO `name_job` VALUES (12,'IT&nbsp;Support�','ERP&nbsp;application');
INSERT INTO `name_job` VALUES (13,'JAVA/J2EE&nbsp;A/P&nbsp;with&nbsp;UML','HTML');
INSERT INTO `name_job` VALUES (14,'Network&nbsp;Design&nbsp;and&nbsp;Integration&nbsp;Engineer','J2EE&nbsp;');
INSERT INTO `name_job` VALUES (15,'Network&nbsp;Security&nbsp;Engineer','J2ME');
INSERT INTO `name_job` VALUES (16,'Product&nbsp;Support&nbsp;Engineer','Java');
INSERT INTO `name_job` VALUES (17,'Programmer','Java&nbsp;Script');
INSERT INTO `name_job` VALUES (18,'Programmer&nbsp;Analyst','Java&nbsp;Servlet');
INSERT INTO `name_job` VALUES (19,'Project&nbsp;Manager�','JSP');
INSERT INTO `name_job` VALUES (20,'Project&nbsp;Office&nbsp;Coordinator','JTA');
INSERT INTO `name_job` VALUES (21,'R&D','Macromedia&nbsp;Dreamweaver&nbsp;MX&nbsp;');
INSERT INTO `name_job` VALUES (22,'Senior&nbsp;Database&nbsp;Administration','Macromedia&nbsp;Flash&nbsp;MX');
INSERT INTO `name_job` VALUES (23,'Senior&nbsp;Engineer','Object&nbsp;Oriented&nbsp;Programming');
INSERT INTO `name_job` VALUES (24,'Senior&nbsp;Software&nbsp;developer','Perl&nbsp;script');
INSERT INTO `name_job` VALUES (25,'Senior&nbsp;System&nbsp;Analyst','Perl/Unix&nbsp;programming&nbsp;');
INSERT INTO `name_job` VALUES (26,'Senior&nbsp;Testing&nbsp;and&nbsp;Support&nbsp;Engineer','Photoshop');
INSERT INTO `name_job` VALUES (27,'Senior&nbsp;VB.Net,&nbsp;ASP.Net,&nbsp;SQL&nbsp;2000&nbsp;developer','PHP');
INSERT INTO `name_job` VALUES (28,'Service&nbsp;Maintenance&nbsp;Sales&nbsp;and&nbsp;Marketing�','PL/I&nbsp;');
INSERT INTO `name_job` VALUES (29,'Software&nbsp;Engineer','RPG/400');
INSERT INTO `name_job` VALUES (30,'System&nbsp;Administrator','SAP');
INSERT INTO `name_job` VALUES (31,'System&nbsp;analyst','SOAP');
INSERT INTO `name_job` VALUES (32,'System&nbsp;Developer','SPSS');
INSERT INTO `name_job` VALUES (33,'System&nbsp;Engineer','UML');
INSERT INTO `name_job` VALUES (34,'System&nbsp;Operator','VAX/VMS');
INSERT INTO `name_job` VALUES (35,'Test&nbsp;Manager','VB');
INSERT INTO `name_job` VALUES (36,'Web&nbsp;Application&nbsp;Programmer','VC++');
INSERT INTO `name_job` VALUES (37,'Web&nbsp;Designer','Visaul&nbsp;Foxpro&nbsp;6.0');
INSERT INTO `name_job` VALUES (38,'Web&nbsp;Master','XML/XSL');
INSERT INTO `name_job` VALUES (39,'','ATM');
INSERT INTO `name_job` VALUES (40,'','Computer&nbsp;and&nbsp;Data&nbsp;Communication');
INSERT INTO `name_job` VALUES (41,'','Distributed&nbsp;systems&nbsp;on&nbsp;Sun/Solaris&nbsp;');
INSERT INTO `name_job` VALUES (42,'','DNS');
INSERT INTO `name_job` VALUES (43,'','Firewall');
INSERT INTO `name_job` VALUES (44,'','IDS');
INSERT INTO `name_job` VALUES (45,'','LAN/WAN&nbsp;');
INSERT INTO `name_job` VALUES (46,'','Network&nbsp;security');
INSERT INTO `name_job` VALUES (47,'','Proxy&nbsp;Server');
INSERT INTO `name_job` VALUES (48,'','PSTN&nbsp;fixed&nbsp;telecommunication&nbsp;network');
INSERT INTO `name_job` VALUES (49,'','System&nbsp;and&nbsp;Network&nbsp;implementation&nbsp;');
INSERT INTO `name_job` VALUES (50,'','TCP/IP&nbsp;');
INSERT INTO `name_job` VALUES (51,'','SUN');
INSERT INTO `name_job` VALUES (52,'','Hardware&nbsp;Technology');
INSERT INTO `name_job` VALUES (53,'','IBM&nbsp;AS/400&nbsp;Platform');
INSERT INTO `name_job` VALUES (54,'','IBM&nbsp;S400');
INSERT INTO `name_job` VALUES (55,'','Security&nbsp;devices&nbsp;(VPNs,&nbsp;firewalls,&nbsp;NIDs)');
INSERT INTO `name_job` VALUES (56,'','Access');
INSERT INTO `name_job` VALUES (57,'','AIX');
INSERT INTO `name_job` VALUES (58,'','DB2');
INSERT INTO `name_job` VALUES (59,'','Informix');
INSERT INTO `name_job` VALUES (60,'','Oracle&nbsp;');
INSERT INTO `name_job` VALUES (61,'','PL/SQL');
INSERT INTO `name_job` VALUES (62,'','SQL&nbsp;Server&nbsp;2000');
INSERT INTO `name_job` VALUES (63,'','Sybase');
INSERT INTO `name_job` VALUES (64,'','Mysql');
INSERT INTO `name_job` VALUES (65,'','HP-UX');
INSERT INTO `name_job` VALUES (66,'','Linux');
INSERT INTO `name_job` VALUES (67,'','Netware');
INSERT INTO `name_job` VALUES (68,'','Sun/Solaris');
INSERT INTO `name_job` VALUES (69,'','UNIX');
INSERT INTO `name_job` VALUES (70,'','Windows&nbsp;Server&nbsp;2003');
INSERT INTO `name_job` VALUES (71,NULL,'Other');

#
# Table structure for table news
#

CREATE TABLE `news` (
  `Id` int(10) unsigned NOT NULL auto_increment,
  `id_member` int(10) default NULL,
  `title` varchar(100) default NULL,
  `subject` varchar(100) NOT NULL default '',
  `text` text,
  `date` varchar(10) default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;


#
# Dumping data for table news
#

INSERT INTO `news` VALUES (33,1,'University','&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#','&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3616;&#3634;&#3588;&#3626;&#3609;&#3634;&#3617; &#3617;&#3592;&#3608;. &#3617;&#3637;&#3588;&#3623;&#3634;&#3617;&#3611;&#3619;&#3632;&#3626;&#3591;&#3588;&#3660;&#3619;&#3633;&#3610;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;&#3611;&#3619;&#3632;&#3592;&#3635;&#3611;&#3637;&#3585;&#3634;&#3619;&#3624;&#3638;&#3585;&#3625;&#3634; 2547 \r\n&#3648;&#3586;&#3657;&#3634;&#3624;&#3638;&#3585;&#3625;&#3634;&#3627;&#3621;&#3633;&#3585;&#3626;&#3641;&#3605;&#3619;&#3623;&#3636;&#3607;&#3618;&#3634;&#3624;&#3634;&#3626;&#3605;&#3619;&#3617;&#3627;&#3634;&#3610;&#3633;&#3603;&#3601;&#3636;&#3605; \r\n- &#3626;&#3634;&#3586;&#3634;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3649;&#3621;&#3632;&#3619;&#3632;&#3610;&#3610;&#3629;&#3633;&#3605;&#3650;&#3609;&#3617;&#3633;&#3605;&#3636; &#3592;&#3635;&#3609;&#3623;&#3609; 60 &#3588;&#3609; \r\n- &#3626;&#3634;&#3586;&#3634;&#3585;&#3634;&#3619;&#3614;&#3633;&#3602;&#3609;&#3634;&#3588;&#3623;&#3634;&#3617;&#3626;&#3634;&#3617;&#3634;&#3619;&#3606;&#3607;&#3634;&#3591;&#3585;&#3634;&#3619;&#3649;&#3586;&#3656;&#3591;&#3586;&#3633;&#3609;&#3648;&#3594;&#3636;&#3591;&#3629;&#3640;&#3605;&#3626;&#3634;&#3627;&#3585;&#3619;&#3619;&#3617; &#3592;&#3635;&#3609;&#3623;&#3609; 60 &#3588;&#3609; \r\n&#3612;&#3641;&#3657;&#3626;&#3609;&#3651;&#3592;&#3605;&#3636;&#3604;&#3605;&#3656;&#3629;&#3586;&#3629;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3648;&#3614;&#3636;&#3656;&#3617;&#3652;&#3604;&#3657;&#3607;&#3637;&#3656; &#3588;&#3640;&#3603;&#3586;&#3609;&#3636;&#3625;&#3600;&#3634; &#3624;&#3640;&#3585;&#3619;&#3632;&#3619;&#3640;&#3592;&#3636; \r\nemail: aeyee@fibo.kmutt.ac.th \r\n\"&#3605;&#3638;&#3585;&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3616;&#3634;&#3588;&#3626;&#3609;&#3634;&#3617; (FIBO) \r\n&#3617;&#3627;&#3634;&#3623;&#3636;&#3607;&#3618;&#3634;&#3621;&#3633;&#3618;&#3648;&#3607;&#3588;&#3650;&#3609;&#3650;&#3621;&#3618;&#3637;&#3614;&#3619;&#3632;&#3592;&#3629;&#3617;&#3648;&#3585;&#3621;&#3657;&#3634;&#3608;&#3609;&#3610;&#3640;&#3619;&#3637; \r\n&#3650;&#3607;&#3619; 0-2470-9339, 0-2470-9691 \" \r\nhttp://grad.fibo.kmutt.ac.th \r\nhttp://fibo.kmutt.ac.th','22/3/2547');
INSERT INTO `news` VALUES (32,2,'University','&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#','&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3616;&#3634;&#3588;&#3626;&#3609;&#3634;&#3617; &#3617;&#3592;&#3608;.','22/3/2547');
INSERT INTO `news` VALUES (34,2,'University','&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#','&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3616;&#3634;&#3588;&#3626;&#3609;&#3634;&#3617; &#3617;&#3592;&#3608;. &#3617;&#3637;&#3588;&#3623;&#3634;&#3617;&#3611;&#3619;&#3632;&#3626;&#3591;&#3588;&#3660;&#3619;&#3633;&#3610;&#3609;&#3633;&#3585;&#3624;&#3638;&#3585;&#3625;&#3634;&#3611;&#3619;&#3632;&#3592;&#3635;&#3611;&#3637;&#3585;&#3634;&#3619;&#3624;&#3638;&#3585;&#3625;&#3634; 2547 \r\n&#3648;&#3586;&#3657;&#3634;&#3624;&#3638;&#3585;&#3625;&#3634;&#3627;&#3621;&#3633;&#3585;&#3626;&#3641;&#3605;&#3619;&#3623;&#3636;&#3607;&#3618;&#3634;&#3624;&#3634;&#3626;&#3605;&#3619;&#3617;&#3627;&#3634;&#3610;&#3633;&#3603;&#3601;&#3636;&#3605; \r\n- &#3626;&#3634;&#3586;&#3634;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3649;&#3621;&#3632;&#3619;&#3632;&#3610;&#3610;&#3629;&#3633;&#3605;&#3650;&#3609;&#3617;&#3633;&#3605;&#3636; &#3592;&#3635;&#3609;&#3623;&#3609; 60 &#3588;&#3609; \r\n- &#3626;&#3634;&#3586;&#3634;&#3585;&#3634;&#3619;&#3614;&#3633;&#3602;&#3609;&#3634;&#3588;&#3623;&#3634;&#3617;&#3626;&#3634;&#3617;&#3634;&#3619;&#3606;&#3607;&#3634;&#3591;&#3585;&#3634;&#3619;&#3649;&#3586;&#3656;&#3591;&#3586;&#3633;&#3609;&#3648;&#3594;&#3636;&#3591;&#3629;&#3640;&#3605;&#3626;&#3634;&#3627;&#3585;&#3619;&#3619;&#3617; &#3592;&#3635;&#3609;&#3623;&#3609; 60 &#3588;&#3609; \r\n&#3612;&#3641;&#3657;&#3626;&#3609;&#3651;&#3592;&#3605;&#3636;&#3604;&#3605;&#3656;&#3629;&#3586;&#3629;&#3586;&#3657;&#3629;&#3617;&#3641;&#3621;&#3648;&#3614;&#3636;&#3656;&#3617;&#3652;&#3604;&#3657;&#3607;&#3637;&#3656; &#3588;&#3640;&#3603;&#3586;&#3609;&#3636;&#3625;&#3600;&#3634; &#3624;&#3640;&#3585;&#3619;&#3632;&#3619;&#3640;&#3592;&#3636; \r\nemail: aeyee@fibo.kmutt.ac.th \r\n\"&#3605;&#3638;&#3585;&#3626;&#3606;&#3634;&#3610;&#3633;&#3609;&#3623;&#3636;&#3607;&#3618;&#3634;&#3585;&#3634;&#3619;&#3627;&#3640;&#3656;&#3609;&#3618;&#3609;&#3605;&#3660;&#3616;&#3634;&#3588;&#3626;&#3609;&#3634;&#3617; (FIBO) \r\n&#3617;&#3627;&#3634;&#3623;&#3636;&#3607;&#3618;&#3634;&#3621;&#3633;&#3618;&#3648;&#3607;&#3588;&#3650;&#3609;&#3650;&#3621;&#3618;&#3637;&#3614;&#3619;&#3632;&#3592;&#3629;&#3617;&#3648;&#3585;&#3621;&#3657;&#3634;&#3608;&#3609;&#3610;&#3640;&#3619;&#3637; \r\n&#3650;&#3607;&#3619; 0-2470-9339, 0-2470-9691 \" \r\nhttp://grad.fibo.kmutt.ac.th \r\nhttp://fibo.kmutt.ac.th','22/3/2547');

