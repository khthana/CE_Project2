#include <io8535v.h>
void delay(int num);
void delay(int sec)
{
 	 int i,j;
	 for (i=0;i<=sec;i++)
	 {
	  	 for(j=0;j<=9500;j++);
	 }
}
void main()
{
   unsigned char temp;
  DDRA = 0xFF;  //port A is output
  DDRC = 0xFF;  //port C is output

  PORTC = 0x55;
  delay(100);
  PORTC = 0xAA;
  delay(100);
  

}
