VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form formedit 
   AutoRedraw      =   -1  'True
   Caption         =   "EDITOR"
   ClientHeight    =   7425
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   9315
   FontTransparent =   0   'False
   LinkTopic       =   "Form2"
   ScaleHeight     =   7425
   ScaleWidth      =   9315
   Begin VB.CommandButton INIT 
      Caption         =   "INIT"
      Height          =   495
      Left            =   1560
      TabIndex        =   11
      Top             =   6600
      Width           =   1335
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   -480
      Top             =   7320
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton selectfile 
      Caption         =   "Select File"
      Height          =   375
      Left            =   6360
      TabIndex        =   10
      Top             =   2160
      Width           =   1935
   End
   Begin VB.TextBox filebox 
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1080
      TabIndex        =   8
      Top             =   2160
      Width           =   4935
   End
   Begin VB.ComboBox Combo1 
      Height          =   315
      Left            =   1080
      TabIndex        =   7
      Text            =   " -- select record --"
      Top             =   2880
      Width           =   2295
   End
   Begin VB.CommandButton OK 
      Caption         =   "OK"
      Height          =   495
      Left            =   6480
      TabIndex        =   6
      Top             =   6600
      Width           =   1335
   End
   Begin VB.ListBox List2 
      Height          =   2985
      ItemData        =   "formedit.frx":0000
      Left            =   6000
      List            =   "formedit.frx":0002
      TabIndex        =   5
      Top             =   2880
      Width           =   2295
   End
   Begin VB.ListBox List1 
      Height          =   2595
      ItemData        =   "formedit.frx":0004
      Left            =   1080
      List            =   "formedit.frx":0006
      TabIndex        =   4
      Top             =   3360
      Width           =   2295
   End
   Begin VB.Frame Frame1 
      Height          =   1215
      Left            =   1800
      TabIndex        =   3
      Top             =   240
      Width           =   5655
      Begin VB.Label Label1 
         Caption         =   "�к��Ѵ��â�����ʶҹ���"
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   27.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   855
         Left            =   720
         TabIndex        =   12
         Top             =   240
         Width           =   4095
      End
   End
   Begin VB.CommandButton save2 
      Caption         =   "SAVE"
      Height          =   495
      Left            =   4080
      TabIndex        =   2
      Top             =   6600
      Width           =   1335
   End
   Begin VB.CommandButton remove 
      Caption         =   "REMOVE"
      Height          =   495
      Left            =   4080
      TabIndex        =   1
      Top             =   4800
      UseMaskColor    =   -1  'True
      Width           =   1335
   End
   Begin VB.CommandButton add 
      Caption         =   "ADD"
      Height          =   495
      Left            =   4080
      MousePointer    =   99  'Custom
      TabIndex        =   0
      Top             =   3720
      Width           =   1335
   End
   Begin VB.Label Label3 
      Caption         =   "���͡��� ::"
      Height          =   255
      Left            =   120
      TabIndex        =   9
      Top             =   2280
      Width           =   855
   End
End
Attribute VB_Name = "formedit"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim filename As String
Dim x As Integer
Dim i As Integer
Dim addressCode As String
Dim nameCode As String
Private Sub add_Click()
    Dim str1 As String
    Dim index1 As Integer
    index1 = List1.ListIndex        'return int from list1
    If List1.ListIndex >= 0 Then
        str1 = List1.List(index1)
        List2.AddItem (str1)
    End If
End Sub

Private Sub Combo1_Click()
    Dim datavar As Source
    Dim y, j, k As Integer
    Dim str2(10) As String
    Dim str3(11) As String
    List1.Enabled = True
    remove.Enabled = True
    List2.Enabled = True
    If filename <> "" Then
        y = Combo1.Text
        add.Enabled = True
        If Combo1.ListIndex >= x Then
            List2.Clear
        End If
    'insert function reload data from notepad here
        Get #1, (y + 1), datavar
        If datavar.num1 = "000" Then    ' ������� 000 ����ʴ�
            For k = 0 To 10    ' set str3 ����� 0 ���
                str3(k) = "000"
            Next k
            datavar.num1 = str3(0)
            datavar.num2 = str3(1)
            datavar.num3 = str3(2)
            datavar.num4 = str3(3)
            datavar.num5 = str3(4)
            datavar.num6 = str3(5)
            datavar.num7 = str3(6)
            datavar.num8 = str3(7)
            datavar.num9 = str3(8)
            datavar.num10 = str3(9)
            datavar.num11 = str3(10)
        End If
        If datavar.num1 <> "000" Then   '�ʴ������ҷ����
            cmpName (datavar.num1)
            str2(0) = nameCode
            cmpName (datavar.num2)
            str2(1) = nameCode
            cmpName (datavar.num3)
            str2(2) = nameCode
            cmpName (datavar.num4)
            str2(3) = nameCode
            cmpName (datavar.num5)
            str2(4) = nameCode
            cmpName (datavar.num6)
            str2(5) = nameCode
            cmpName (datavar.num7)
            str2(6) = nameCode
            cmpName (datavar.num8)
            str2(7) = nameCode
            cmpName (datavar.num9)
            str2(8) = nameCode
            cmpName (datavar.num10)
            str2(9) = nameCode
            cmpName (datavar.num11)
            str2(10) = nameCode
            For j = 0 To 10
                If str2(j) <> "000" Then
                    List2.List(j) = str2(j)
                End If
            Next j
        End If
    End If
    
End Sub


Private Sub Combo1_DropDown()
    If filename = "" Then
        MsgBox "No File!@This program doesn't work.@Select File.", _
        vbOKOnly + vbExclamation
    End If
End Sub

Private Sub Form_Load()
    insertList1
    insertCombo1
    add.Enabled = False
    filebox.Enabled = False
    If Combo1.ListIndex < 0 Then
        List1.Enabled = False
        remove.Enabled = False
        List2.Enabled = False
    End If
End Sub

Private Sub INIT_Click()
     Dim datavar As Source
     Dim j, k, a As Integer
     Dim str3(11) As String
     If filename = "" Then
        MsgBox "No File!@This program doesn't work.@Select File.", _
        vbOKOnly + vbExclamation
    Else
        For a = 0 To 15
            datavar.code = Format(a, "000")
            For k = 0 To 10     ' set str3 ����� 0 ���
            str3(k) = "000"
            Next k
                datavar.num1 = str3(0)
                datavar.num2 = str3(1)
                datavar.num3 = str3(2)
                datavar.num4 = str3(3)
                datavar.num5 = str3(4)
                datavar.num6 = str3(5)
                datavar.num7 = str3(6)
                datavar.num8 = str3(7)
                datavar.num9 = str3(8)
                datavar.num10 = str3(9)
                datavar.num11 = str3(10)
                datavar.crlf = Chr(13) & Chr(10)
                Put #1, Val(a + 1), datavar
        Next a
    End If
End Sub





Private Sub OK_Click()
    Unload Me
End Sub

Private Sub remove_Click()
    Dim index2 As Integer
    index2 = List2.ListIndex
    If List2.ListIndex <> -1 Then
        List2.RemoveItem (index2)
    End If

End Sub

Private Sub insertList1()
    List1.AddItem ("0")
    List1.AddItem ("1")
    List1.AddItem ("2")
    List1.AddItem ("3")
    List1.AddItem ("4")
    List1.AddItem ("5")
    List1.AddItem ("6")
    List1.AddItem ("7")
    List1.AddItem ("8")
    List1.AddItem ("9")
    List1.AddItem ("�����Ǣ��")
    List1.AddItem ("�����ǫ���")
    List1.AddItem ("�Կ��")
    List1.AddItem ("�ѹ�")
    List1.AddItem ("��á��")
    List1.AddItem ("��ͧ���")
    List1.AddItem ("END")
End Sub

Private Sub insertCombo1()
    Dim num As Integer
    Dim i As Integer
    For i = 0 To 15
        Combo1.AddItem (Str(i))
    Next i
    
End Sub

Private Sub getFile()
    
    Dim iFileNum As Integer
    Dim datavar As Source
    
    filename = ""
    filename = CommonDialog1.filename
    filebox.Text = filename
    
    If filename <> "" Then
        Open filename For Random As #1 Len = Len(datavar)
    End If
End Sub

Private Sub save2_Click()
    Dim datavar As Source
    Dim j, k As Integer
    Dim str3(11) As String
    Dim str2 As String
    Dim x As Integer
    If List2.ListCount > 12 Then
        MsgBox "Too much information!@Please,Check information agian.@Information chouldn't be over 10.", _
        vbOKOnly + vbExclamation
    Else
        If Combo1.ListIndex < 0 Then
            MsgBox "No File!@This program doesn't work.@Select File.", _
            vbOKOnly + vbExclamation
        Else
            x = Combo1.ListIndex
            For k = 0 To 10     ' set str3 ����� 0 ���
                str3(k) = "000"
            Next k
            i = Combo1.Text
            If List2.ListCount > 0 Then
                datavar.code = Format(i, "000")
                For j = 0 To 10
                    If List2.List(j) <> "END" Then
                        str2 = List2.List(j)
                        cmpAddress (str2)
                        str3(j) = addressCode
                    End If
                    If List2.List(j) = "END" Then
                        j = 11
                    End If
                Next j
            End If
            datavar.num1 = str3(0)
            datavar.num2 = str3(1)
            datavar.num3 = str3(2)
            datavar.num4 = str3(3)
            datavar.num5 = str3(4)
            datavar.num6 = str3(5)
            datavar.num7 = str3(6)
            datavar.num8 = str3(7)
            datavar.num9 = str3(8)
            datavar.num10 = str3(9)
            datavar.num11 = str3(10)
            datavar.crlf = Chr(13) & Chr(10)
            Put #1, Val(i + 1), datavar
        End If
    End If
End Sub

Private Sub selectfile_Click()
    Close #1    'close the old file
    CommonDialog1.ShowOpen
    getFile
End Sub

Private Sub cmpAddress(str2 As String)
        Select Case str2
            Case "0": addressCode = "010"
            Case "1": addressCode = "001"
            Case "2": addressCode = "002"
            Case "3": addressCode = "003"
            Case "4": addressCode = "004"
            Case "5": addressCode = "005"
            Case "6": addressCode = "006"
            Case "7": addressCode = "007"
            Case "8": addressCode = "008"
            Case "9": addressCode = "009"
            Case "�����ǫ���": addressCode = "011"
            Case "�����Ǣ��": addressCode = "012"
            Case "�Կ��": addressCode = "013"
            Case "�ѹ�": addressCode = "014"
            Case "��á��": addressCode = "015"
            Case "��ͧ���": addressCode = "016"
        End Select
        
End Sub


Private Sub Form_Unload(Cancel As Integer)
    Close #1
End Sub


Private Sub cmpName(ByRef str4 As String)
        Select Case str4
            Case "010": nameCode = "0"
            Case "001": nameCode = "1"
            Case "002": nameCode = "2"
            Case "003": nameCode = "3"
            Case "004": nameCode = "4"
            Case "005": nameCode = "5"
            Case "006": nameCode = "6"
            Case "007": nameCode = "7"
            Case "008": nameCode = "8"
            Case "009": nameCode = "9"
            Case "011": nameCode = "�����ǫ���"
            Case "012": nameCode = "�����Ǣ��"
            Case "013": nameCode = "�Կ��"
            Case "014": nameCode = "�ѹ�"
            Case "015": nameCode = "��á��"
            Case "016": nameCode = "��ͧ���"
            Case "000": nameCode = "000"
        End Select
        
End Sub














