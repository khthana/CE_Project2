Attribute VB_Name = "Module1"
Type Source
    code As String * 3
    num1 As String * 3
    num2 As String * 3
    num3 As String * 3
    num4 As String * 3
    num5 As String * 3
    num6 As String * 3
    num7 As String * 3
    num8 As String * 3
    num9 As String * 3
    num10 As String * 3
    num11 As String * 3
    crlf As String * 2
    
End Type

