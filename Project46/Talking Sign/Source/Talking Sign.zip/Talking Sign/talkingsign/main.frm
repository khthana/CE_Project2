VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form main 
   Caption         =   "�к��͡�ҧ���ԡ�÷ҧ��µҴ������§"
   ClientHeight    =   7530
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   10320
   LinkTopic       =   "Form1"
   ScaleHeight     =   7530
   ScaleWidth      =   10320
   StartUpPosition =   3  'Windows Default
   Begin MSCommLib.MSComm MSComm1 
      Left            =   720
      Top             =   6960
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
   End
   Begin VB.CommandButton exit 
      Caption         =   "Exit"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5400
      TabIndex        =   8
      Top             =   6000
      Width           =   1815
   End
   Begin VB.CommandButton edit 
      Caption         =   "Edit"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   7
      Top             =   6000
      Width           =   1815
   End
   Begin VB.CommandButton download 
      Caption         =   "Download"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6480
      TabIndex        =   6
      Top             =   4200
      Width           =   1815
   End
   Begin VB.TextBox filebox 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "System"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2520
      LinkTimeout     =   1000
      TabIndex        =   4
      Top             =   3480
      Width           =   5775
   End
   Begin VB.CommandButton selectfile 
      Caption         =   "Select File"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   2520
      TabIndex        =   3
      Top             =   4200
      Width           =   1935
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   120
      Top             =   6960
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Frame Frame1 
      Height          =   2175
      Left            =   600
      TabIndex        =   0
      Top             =   360
      Width           =   9135
      Begin VB.Label Label2 
         Caption         =   "�к��͡�ҧ���ԡ�÷ҧ��µҴ������§"
         BeginProperty Font 
            Name            =   "Angsana New"
            Size            =   27.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   735
         Left            =   1560
         TabIndex        =   2
         Top             =   1200
         Width           =   6255
      End
      Begin VB.Label Label1 
         Caption         =   "TALKING SIGN"
         BeginProperty Font 
            Name            =   "Times New Roman"
            Size            =   36
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00000000&
         Height          =   855
         Left            =   2040
         TabIndex        =   1
         Top             =   360
         Width           =   5055
      End
   End
   Begin VB.Label Label3 
      Caption         =   "���͡������ͧ��� ::"
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   840
      TabIndex        =   5
      Top             =   3600
      Width           =   1455
   End
End
Attribute VB_Name = "main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub getFile()
    Dim filename As String
    Dim iFileNum As Integer
    Dim datavar As Source
    
    filename = ""
    filename = CommonDialog1.filename
    filebox.Text = filename
    
    If filename <> "" Then
        Open filename For Random As #1 Len = Len(datavar)
        download.Enabled = True
    End If
    
End Sub

Private Sub download_Click()
    Dim datavar As Source
    Dim i As Integer
    If filebox.Text = "" Then
        MsgBox "No File!@This program doesn't work.@Select File.", _
        vbOKOnly + vbExclamation
    Else
        MSComm1.Output = "A"        'Start Send
        ' MSComm1.Output = "B"    'save
        For i = 1 To 16       '16 rows
            Get #1, i, datavar
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.code))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num1))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num2))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num3))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num4))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num5))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num6))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num7))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num8))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num9))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num10))
            delay (50)
            MSComm1.Output = Chr$(Val(datavar.num11))
            delay (50)
        Next i
        MsgBox "@DOWNLOAD  COMPLETE@", _
        vbOKOnly + vbInformation
    End If
End Sub

Private Sub edit_Click()
    filebox.Text = ""
    formedit.Show
End Sub

Private Sub exit_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    MSComm1.CommPort = 1            'use port Com1
    MSComm1.InputLen = 1                'delay 1 s
    MSComm1.PortOpen = True         'open port
    download.Enabled = False
End Sub

Private Sub selectfile_Click()
    Close #1    'close the old file
    CommonDialog1.ShowOpen
    getFile
End Sub

Private Sub delay(f As Integer)
    Dim j, k As Integer
    For j = 0 To f
    For k = 0 To 5000
    Next k
    Next j
End Sub










