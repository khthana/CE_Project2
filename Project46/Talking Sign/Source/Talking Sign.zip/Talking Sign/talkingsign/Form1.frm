VERSION 5.00
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   5115
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   7050
   LinkTopic       =   "Form1"
   ScaleHeight     =   5115
   ScaleWidth      =   7050
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton quite 
      Caption         =   "quite"
      Height          =   1095
      Left            =   4080
      TabIndex        =   2
      Top             =   3600
      Width           =   1935
   End
   Begin MSCommLib.MSComm MSComm1 
      Left            =   0
      Top             =   4560
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
   End
   Begin VB.CommandButton send 
      Caption         =   "send"
      Height          =   1095
      Left            =   4080
      TabIndex        =   1
      Top             =   840
      Width           =   1935
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   36
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1335
      Left            =   360
      TabIndex        =   0
      Top             =   600
      Width           =   3135
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Load()
    
    MSComm1.CommPort = 1            'use port Com1
    MSComm1.InputLen = 1                'delay 1 s
    MSComm1.PortOpen = True         'open port

    
End Sub

Private Sub quite_Click()
    Unload Me
End Sub

Private Sub send_Click()
    Dim a As String
    MSComm1.Output = Chr(33)
    MSComm1.Output = "D"

End Sub
