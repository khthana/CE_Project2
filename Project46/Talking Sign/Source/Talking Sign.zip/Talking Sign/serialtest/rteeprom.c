/*
** purpose:			real-time EEPROM access functions
** version:			1.0
** Author:			Laurence Barker
**							modified from functions provided with ICCAVR
**							originally written by Lars Wicktorsson
*/

// real time EEPROM access functions
// these work for devices with more than 256 bytes of EEPROM

// These functions are provided for real-time systems where waiting for a
// previous write operation to complete may not be acceptable. 
// These functions do not wait for any previous eeprom function to complete.
// the user is responsible for tresting that the eeprom is ready for the
// intended operation.

// work for AVR devices above 2313
#include <io8535v.h>
#include <macros.h>
#include "rteeprom.h"

// function to test if the EEPROM is ready for a read or write operation
// returns non zero if ready, zero if not ready 
unsigned char RTEEPROMReady(void)
{
	return !(EECR & 0x02);
}



// function to initiate an EEPROM write
// writes the specified data byte to the specified location
// this will fail if the EEPROM is not ready!
void RTEEPROMwrite(int location, unsigned char databyte)
{
	unsigned char savedSREG;
	EEAR = location;								// set address
	EEDR = databyte;								// set data	
	savedSREG = SREG;								// keep setting so it can be restored
	CLI();													// disable interrupts
	EECR |= BIT(EEMWE);							// set "write enable" bit
	EECR |= BIT(EEWE);							// set "write" bit
	SREG = savedSREG;								// restore SREG
	EEAR = 0;
}



// function to read from the EEPROM
// reads a byte from the specified location
// this will fail if the EEPROM is not ready!
unsigned char RTEEPROMread(int location)
{
	EEAR = location;								// set address
	EECR |= BIT(EERE);							// set "read enable" bit
	EEAR = 0;
	return (EEDR);
}
