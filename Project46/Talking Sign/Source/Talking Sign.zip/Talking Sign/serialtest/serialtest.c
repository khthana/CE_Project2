#include <io8535v.h>
#include "uart.h"
#include "rteeprom.h"
#include "voice.h"

unsigned char rowAddr[]={1,14,26,38,50,62,74,86,99,110,122,134,146,158,170,182};
unsigned char souAddr[]={4,8,16,24,32,40,48,56,64,72,80,88,96,104,112,120};
unsigned char oldPos;

void startState();
void runMode();
void loadMode();
void main( void )
{
 	 unsigned char temp;
 	 DDRC = 0xFF;   //port c is an output
	 PORTC = 0x10;	//No record voice
	 DDRA = 0xFF;	//port A is an output
	 DDRB = 0x00;	//port B is an input
	 DDRD = 0xFC;	//port D is PD2-PD7 is output
	 InitUART( 51 ); // set the baudrate to 9,600 bps using a 8 MHz crystal 
	 //=====================
	 PORTC = 0x04;
	 delay(100);
	 PORTC = 0x08
	 delay(100);
 	 PORTC = 0x10;
	 delay(100);
	 PORTC = 0x20;
	 delay(100);
	 PORTC = 0x40;
	 delay(100);
	 PORTC = 0x80;
	 delay(100);
	 PORTC = 0xCF; 	//initial state label   number 1
	 delay(50);
	 //====
	 temp = PINB;
	 temp &= 0x80;	 //terminate 7 bit low
	 PORTC = 0x10;	//No record voice
	 if (temp ==0x00)
	 	while(1) runMode();
	 else  //PINB = 0x80  --> load mode
	 {
	 	PORTC = 0x10;	//No record voice
		PORTD = 0x55;
	 	loadMode(); 
	 }
	
}//end of main
//====================================
void runMode()
{
 	 unsigned int row,field;
	 unsigned int code;
	 unsigned char dataCode; //store input data from PINB
	 dataCode = PINB;
	 if (dataCode != oldPos)
	 {
	 for (row=0;row<=15;row++)
	 {
	  	 while(RTEEPROMReady()==0);
		 if (dataCode == RTEEPROMread(rowAddr[row]))
		 {
		  	for (field=1;field<=11;field++)
			{
		  	 	while(RTEEPROMReady()==0);
				code = RTEEPROMread(rowAddr[row]+field);
				if (code != 0)
				play(souAddr[code-1]);
			}//end for
		 }//end if
	 }//end for	
	 }//end if
	 oldPos = dataCode;
}//end runMode
//=====================================
void loadMode()
{
	unsigned int row,field;
	while(ReceiveByte() != 'A' ); //check begin receive from VB
	for (row=0;row<=15;row++)
	{
	 	for(field=0;field<=11;field++)
		{
		    while(RTEEPROMReady()==0);
			RTEEPROMwrite(rowAddr[row]+field,ReceiveByte());
		}//end for field
	}//end for row
	PORTD = 0xAA;
}//end loadMode

void startState()
{
	 PORTC = 0x04;
	 delay(100);
	 PORTC = 0x08
	 delay(100);
 	 PORTC = 0x10;
	 delay(100);
	 PORTC = 0x20;
	 delay(100);
	 PORTC = 0x40;
	 delay(100);
	 PORTC = 0x80;
	 delay(100);
	 PORTC = 0xCF; 	//initial state label   number 1
	 delay(50);
}








