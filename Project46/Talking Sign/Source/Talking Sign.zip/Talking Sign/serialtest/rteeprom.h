
#ifdef _AVR
/* AVR EEPROM real-time access functions */
#ifndef		__RTEEPROM__H
#define		__RTEEPROM__H

unsigned char RTEEPROMReady(void);

void RTEEPROMwrite(int location, unsigned char databyte);

unsigned char RTEEPROMread(int location);

#endif
#endif
