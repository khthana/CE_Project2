
#include <io8535v.h>
#include <macros.h>
#include "uart.h"

/* initialize UART */
void InitUART( unsigned char baudrate )
	{
	UBRR = baudrate; /* set the baud rate */
	UCR = BIT(RXEN) | BIT(TXEN); /* enable UART receiver and transmitter */
	}

/* Read and write functions */
unsigned char ReceiveByte( void )
	{
	while ( !(USR & (1<<RXC)) ) /* wait for incomming data */
		; /* return the data */
	return UDR;
	}

void TransmitByte( unsigned char data )
	{
	while ( !(USR & (1<<UDRE)) )
		; /* wait for empty transmit buffer */
	UDR = data; /* start transmittion */
	}
	
void delay(int msec)
{
 	 int i,j;
	 for (i=0;i<=msec;i++)
	 {
	  	 for(j=0;j<=9500;j++);
	 }
}

