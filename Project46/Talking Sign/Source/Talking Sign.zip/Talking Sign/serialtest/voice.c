#include <io8535v.h>
#include "macros.h"
#include "voice.h"
#include "uart.h"
void play(char num)
{
  unsigned int delay_number;
  //************encode delay**********
  if ((num >= 0x04) && (num<=0x48))
  	 delay_number = 130;
  if (num==0x50 || num==0x58 || num==0x68)
  	 delay_number = 150;
  if (num==0x60)
  	 delay_number = 100;
  if (num==0x70)
  	 delay_number = 200;
  if (num==0x78)
  	 delay_number = 170;
  
  	 //-->Playback
     PORTA = num;		   //insert address
  	 PORTC = 0x10;		   //idle  
  	 delay(50);		   
  	 
  	 PORTC = 0x28;		   //setup for begin '1'   
  	 delay(50);		   //wait for '1' -> '0'   
  	 PORTC = 0x20;		   //begin playback	   		
  	 delay(delay_number);
  	 PORTC = 0x10;		   //end playback 
}
