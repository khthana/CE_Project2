//prototype

void play(char num);   //num is address
