package realtimedata;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import com.borland.jbcl.layout.*;

public class copyDataRealtimeFrame extends JFrame {
    private JPanel contentPane;

    private BufferedReader inputFile;
    private StringBuffer   inputData;
    private int            inputDataLength;
    private PrintWriter    outputFile;
    private String         outputFileName = "realTimeData.txt";
    private URL            url;

    private String DBurl = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
    private Connection DBconnection;
    private Statement selectCompany;
    private PreparedStatement insert_Data;
    private ResultSet resultSet_CompanyName;  // Every company. = { n_security }

    private String lastPrice, change, percentChange, bid, offer, volume, value;
    private double LastPrice, nowPrice, PercentChange, Bid, Offer, Value; // after convert from string
    private int Volume;

    private String SQL_Insert = "INSERT INTO realTimeData(dateTime, symbol, lastPrice, nowPrice, percentChange, bid, offer, volume, value_)"+
				"VALUES(?,?,?,?,?,?,?,?,?)";

    private String dateTime;
    private boolean queried=true;
    public JLabel jLabel1 = new JLabel();
    public JLabel jLabel2 = new JLabel();
    private XYLayout xYLayout1 = new XYLayout();

    //Construct the frame
    public copyDataRealtimeFrame() {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
	try {
	    url = new URL("http://www.settrade.com/actions/customization/IPO/set/SET_StockQuotes.jsp?sym=all");
	} catch (IOException e) {}

	try {
	    inputDataLength = 200000;
	    inputData = new StringBuffer(inputDataLength);
	    inputFile = new BufferedReader(new FileReader(outputFileName));
	    outputFile = new PrintWriter(new FileWriter(outputFileName));
	} catch (IOException e) {
	    JOptionPane.showMessageDialog(null, "File Error : "+e.getMessage(),"File Error",JOptionPane.WARNING_MESSAGE);
	    System.exit(0);
	}
    }

    //Component initialization
    private void jbInit() throws Exception  {
	setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("logo.jpg")));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(xYLayout1);
        this.setSize(new Dimension(372, 119));
        this.setTitle(" :: Real Time Data copier ::");
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 15));
        jLabel1.setAlignmentX((float) 0.5);
        jLabel2.setFont(new java.awt.Font("Dialog", 1, 15));
        jLabel2.setForeground(new Color(164, 0, 0));
        contentPane.add(jLabel1, new XYConstraints(6, 14, 372, -1));
        contentPane.add(jLabel2,  new XYConstraints(6, 44, 372, 33));
    }
    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            System.exit(0);
        }
    }

//=======================================================================================//
//                   Methods                                                             //
//=======================================================================================//
     public void GET_HTTP(String d) {
	 dateTime = d;
	 jLabel1.setText(dateTime);

	 String tmp;
	 // 1. Start Copy Data to file
	 jLabel2.setText(" Retrive Data from www.set.or.th");
	     try {
		 InputStream html = url.openStream();
		 outputFile = new PrintWriter(new FileWriter(outputFileName));

		 int c  = 0; c = html.read();

		 // write data to output file //
		 while (c>0) {
			 if ((char)c == '<') { // delete HTML structure
			     c = html.read();
			     while ((char)c != '>') {
				 c = html.read();
			     }
			     c = html.read();
			 } else { // if it is data.
			     outputFile.print((char)c);
			     c = html.read();
			 }
		 } // end while
		 outputFile.close();
	      }
	      catch (IOException e) {
		  JOptionPane.showMessageDialog(null, "Can not connect to www.set.or.th\nPlease check your internet connection ","Connection Error",JOptionPane.WARNING_MESSAGE);
		  System.exit(0);
	      }
	      jLabel2.setText(" Retrive Data finish");

	// 2. Open file
	      try {
		  inputFile = new BufferedReader(new FileReader(outputFileName));
		  tmp = "";
		  tmp = inputFile.readLine();	// Readline
		  while (tmp != null) {
		      inputData.append(tmp);
		      tmp  = inputFile.readLine(); // Readline
		  }
		  inputFile.close();
	      } catch (IOException e) {
		  JOptionPane.showMessageDialog(null, "File Error : "+e.getMessage(),"File Error",JOptionPane.WARNING_MESSAGE);
		  System.exit(0);
	      }

	// 3. Find company data ( Symbol, Last, Change, %Change, Bid, Offer, Volume, Value )
	if (queried) {
	    queryCompanyName(); // Look for company name from Database
	    queried = false;
	}

	try {
	    while (!resultSet_CompanyName.isAfterLast()) {

		findData(resultSet_CompanyName.getString(1));
		convertString2Real();
		jLabel2.setText(" Insert Data into Database");
		insertData2DB(resultSet_CompanyName.getString(1));

		resultSet_CompanyName.next();
	    }
	    resultSet_CompanyName.first();
	} catch (SQLException e) {
	    JOptionPane.showMessageDialog(null, "ResultSet Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	    System.exit(0);
	}
     } // end method
//=====================================================================================//
     public void queryCompanyName() {
	 // sql is used for find all n_security (company name)
	 String sql = "SELECT MIN(n_security) "+
		      "FROM daily_stock "+
		      "GROUP BY n_security "+
		      "ORDER BY n_security;";
	 try {
	     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

	     DBconnection = DriverManager.getConnection(DBurl,"","");
	     selectCompany = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		     ResultSet.CONCUR_READ_ONLY);
	     resultSet_CompanyName = selectCompany.executeQuery(sql);
	     resultSet_CompanyName.first();

	     insert_Data = DBconnection.prepareStatement(SQL_Insert);
	 } catch (SQLException e) {
	     JOptionPane.showMessageDialog(null, "SQL Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	     System.exit(0);
	 }
	   catch (java.lang.ClassNotFoundException e) {
	       JOptionPane.showMessageDialog(null, "Driver Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	       System.exit(0);
	   }
     }
//=====================================================================================//
     public void findData(String companyName) {
	     //// Start to find String ////
	     int index = inputData.lastIndexOf(companyName);  // if indexOf == -1 , not found
	     int lastChar = 0;

		     if (companyName.equals("S & J") || index == -1) {
			     lastPrice     = "0.0";
			     change        = "0.0";
			     percentChange = "0.0";
			     bid           = "0.0";
			     offer         = "0.0";
			     volume        = "0.0";
			     value         = "0.0";
		     } else { // start to find
	     try {
	       //=== last price =========================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     lastPrice = inputData.substring(index, lastChar);
	       //=== change =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     change = inputData.substring(index, lastChar);
	       //=== % change =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     percentChange = inputData.substring(index, lastChar);
	       //=== bid =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     bid = inputData.substring(index, lastChar);
	       //=== offer =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     offer = inputData.substring(index, lastChar);
	       //=== volume =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }

		     volume = inputData.substring(index, lastChar);
	       //=== value =============================
		     while (inputData.charAt(index) != ' ') { // next until found ' '
			 index++;
		     }
		     while (inputData.charAt(index) == ' ') { // next until found next value
			 index++;
		     }

		     lastChar = index+1;
		     while (inputData.charAt(lastChar)!=' ') { // find value length
			 lastChar++;
		     }
		     value = inputData.substring(index, lastChar);

	     } catch (StringIndexOutOfBoundsException e) {}
		     } // end else
     } // end find
//=====================================================================================//
     public void convertString2Real() {
	 // convert lastPrice -> LastPrice
	 int priceLength=0;
	 if (lastPrice.charAt(0) == '0') {
	     LastPrice = 0.0;
	 } else {
	     priceLength = lastPrice.length();
	     switch (priceLength) {
		 case 4 : {
		     LastPrice = ( (double)lastPrice.charAt(0)-48.00)     +
	                         (((double)lastPrice.charAt(2)-48.00)/10) +
	                         (((double)lastPrice.charAt(3)-48.00)/100);
		     break;
		 }
		 case 5 : {
		     LastPrice = (((double)lastPrice.charAt(0)-48.00)*10) +
	                         ( (double)lastPrice.charAt(1)-48.00)     +
  	                         (((double)lastPrice.charAt(3)-48.00)/10) +
	                         (((double)lastPrice.charAt(4)-48.00)/100);
		     break;
		 }
		 case 6 : {
		     LastPrice = (((double)lastPrice.charAt(0)-48.00)*100)+
			         (((double)lastPrice.charAt(1)-48.00)*10) +
				 ( (double)lastPrice.charAt(2)-48.00)     +
				 (((double)lastPrice.charAt(4)-48.00)/10) +
				 (((double)lastPrice.charAt(5)-48.00)/100);
		     break;
		 }
		 case 8 : {
		     LastPrice = (((double)lastPrice.charAt(0)-48.00)*1000)+
			         (((double)lastPrice.charAt(2)-48.00)*100) +
				 (((double)lastPrice.charAt(3)-48.00)*10)  +
				 ( (double)lastPrice.charAt(4)-48.00)      +
				 (((double)lastPrice.charAt(6)-48.00)/10)  +
				 (((double)lastPrice.charAt(7)-48.00)/100);
		     break;
		 }
	     }
	 } // else

	 // convert change -> nowPrice
	 if (change.charAt(0)=='0') {
	     nowPrice = LastPrice;
	 } else {
	     priceLength = change.length() - 1;
	     if (change.charAt(0)=='+') { // increase change
		 switch (priceLength) {
		     case 4 : {
			 nowPrice = LastPrice + (  ((double)change.charAt(1)-48.00)     +
						  (((double)change.charAt(3)-48.00)/10) +
						  (((double)change.charAt(4)-48.00)/100) );
			 break;
		     }
		     case 5 : {
			 nowPrice = LastPrice + ( (((double)change.charAt(1)-48.00)*10) +
				                   ((double)change.charAt(2)-48.00)     +
						  (((double)change.charAt(4)-48.00)/10) +
						  (((double)change.charAt(5)-48.00)/100) );
			 break;
		     }
		     case 6 : {
			 nowPrice = LastPrice + ( (((double)change.charAt(0)-48.00)*100)+
				                  (((double)change.charAt(1)-48.00)*10) +
						   ((double)change.charAt(2)-48.00)     +
						  (((double)change.charAt(4)-48.00)/10) +
						  (((double)change.charAt(5)-48.00)/100) );
			 break;
		     }
		 }
	     } else { // decrease change
		 switch (priceLength) {
		     case 4 : {
			 nowPrice = LastPrice - (  ((double)change.charAt(1)-48.00)     +
						  (((double)change.charAt(3)-48.00)/10) +
						  (((double)change.charAt(4)-48.00)/100) );
			 break;
		     }
		     case 5 : {
			 nowPrice = LastPrice - ( (((double)change.charAt(1)-48.00)*10) +
						   ((double)change.charAt(2)-48.00)     +
						  (((double)change.charAt(4)-48.00)/10) +
						  (((double)change.charAt(5)-48.00)/100) );
			 break;
		     }
		     case 6 : {
			 nowPrice = LastPrice - ( (((double)change.charAt(0)-48.00)*100)+
						  (((double)change.charAt(1)-48.00)*10) +
						   ((double)change.charAt(2)-48.00)     +
						  (((double)change.charAt(4)-48.00)/10) +
						  (((double)change.charAt(5)-48.00)/100) );
			 break;
		     }
		 }
	     }
	 }

	 // convert percentChange -> PercentChange
	 if (percentChange.charAt(0)=='0') {
	     PercentChange = 0.0;
	 } else {
	     priceLength = percentChange.length() - 1;
	     if (percentChange.charAt(0)=='+') { // increase %change
		 switch (priceLength) {
		     case 4 : {
			 PercentChange =  (   ((double)percentChange.charAt(1)-48.00)     +
			  		     (((double)percentChange.charAt(3)-48.00)/10) +
					     (((double)percentChange.charAt(4)-48.00)/100) );
			 break;
		     }
		     case 5 : {
			 PercentChange = ((((double)percentChange.charAt(1)-48.00)*10) +
					   ((double)percentChange.charAt(2)-48.00)     +
					  (((double)percentChange.charAt(4)-48.00)/10) +
					  (((double)percentChange.charAt(5)-48.00)/100) );
			 break;
		     }
		     case 6 : {
			 PercentChange = ( (((double)percentChange.charAt(0)-48.00)*100)+
					   (((double)percentChange.charAt(1)-48.00)*10) +
					    ((double)percentChange.charAt(2)-48.00)     +
					   (((double)percentChange.charAt(4)-48.00)/10) +
					   (((double)percentChange.charAt(5)-48.00)/100) );
			 break;
		     }
		 }
	     } else { // decrease %change
		 switch (priceLength) {
		     case 4 : {
			 PercentChange = -1* (  ((double)percentChange.charAt(1)-48.00)     +
			                       (((double)percentChange.charAt(3)-48.00)/10) +
					       (((double)percentChange.charAt(4)-48.00)/100) );
			 break;
		     }
		     case 5 : {
			 PercentChange = -1* ( (((double)percentChange.charAt(1)-48.00)*10) +
						((double)percentChange.charAt(2)-48.00)     +
					       (((double)percentChange.charAt(4)-48.00)/10) +
					       (((double)percentChange.charAt(5)-48.00)/100) );
			 break;
		     }
		     case 6 : {
			 PercentChange = -1* ( (((double)percentChange.charAt(0)-48.00)*100)+
			                       (((double)percentChange.charAt(1)-48.00)*10) +
						((double)percentChange.charAt(2)-48.00)     +
					       (((double)percentChange.charAt(4)-48.00)/10) +
					       (((double)percentChange.charAt(5)-48.00)/100) );
			 break;
		     }
		 }
	     }
	 } // end else

	 // convert bid    -> Bid
	 if (bid.charAt(0) == '0') {
	     Bid = 0.0;
	 } else {
	     priceLength = bid.length();
	     switch (priceLength) {
		 case 4 : {
		     Bid = ( (double)bid.charAt(0)-48.00)     +
		           (((double)bid.charAt(2)-48.00)/10) +
			   (((double)bid.charAt(3)-48.00)/100);
		     break;
		 }
		 case 5 : {
		     Bid = (((double)bid.charAt(0)-48.00)*10) +
		           ( (double)bid.charAt(1)-48.00)     +
			   (((double)bid.charAt(3)-48.00)/10) +
			   (((double)bid.charAt(4)-48.00)/100);
		     break;
		 }
		 case 6 : {
		     Bid = (((double)bid.charAt(0)-48.00)*100)+
			   (((double)bid.charAt(1)-48.00)*10) +
			   ( (double)bid.charAt(2)-48.00)     +
			   (((double)bid.charAt(4)-48.00)/10) +
			   (((double)bid.charAt(5)-48.00)/100);
		     break;
		 }
		 case 8 : {
		     Bid = (((double)bid.charAt(0)-48.00)*1000)+
			   (((double)bid.charAt(2)-48.00)*100) +
			   (((double)bid.charAt(3)-48.00)*10)  +
			   ( (double)bid.charAt(4)-48.00)      +
			   (((double)bid.charAt(6)-48.00)/10)  +
			   (((double)bid.charAt(7)-48.00)/100);
		     break;
		 }
	     }
	 }

	 // convert offer  -> Offer
	 if (offer.charAt(0) == '0') {
	     Offer = 0.0;
	 } else {
	     priceLength = offer.length();
	     switch (priceLength) {
		 case 4 : {
		     Offer = ( (double)offer.charAt(0)-48.00)     +
			   (((double)offer.charAt(2)-48.00)/10) +
			   (((double)offer.charAt(3)-48.00)/100);
		     break;
		 }
		 case 5 : {
		     Offer = (((double)offer.charAt(0)-48.00)*10) +
			   ( (double)offer.charAt(1)-48.00)     +
			   (((double)offer.charAt(3)-48.00)/10) +
			   (((double)offer.charAt(4)-48.00)/100);
		     break;
		 }
		 case 6 : {
		     Offer = (((double)offer.charAt(0)-48.00)*100)+
			   (((double)offer.charAt(1)-48.00)*10) +
			   ( (double)offer.charAt(2)-48.00)     +
			   (((double)offer.charAt(4)-48.00)/10) +
			   (((double)offer.charAt(5)-48.00)/100);
		     break;
		 }
		 case 8 : {
		     Offer = (((double)offer.charAt(0)-48.00)*1000)+
			   (((double)offer.charAt(2)-48.00)*100) +
			   (((double)offer.charAt(3)-48.00)*10)  +
			   ( (double)offer.charAt(4)-48.00)      +
			   (((double)offer.charAt(6)-48.00)/10)  +
			   (((double)offer.charAt(7)-48.00)/100);
		     break;
		 }
	     }
	 }

	 // convert volume -> Volume
	 if (volume.charAt(0) == '0') {
	     Volume = 0;
	 } else {
	     priceLength = volume.length();
	     switch (priceLength) {
		 case 1 : {
		     Volume =  (int)volume.charAt(0) - 48;
		     break;
		 }
		 case 2 : {
		     Volume = ((int)volume.charAt(0)-48)*10 +
			      ((int)volume.charAt(1)-48);
		     break;
		 }
		 case 3 : {
		     Volume = ((int)volume.charAt(0)-48)*100 +
			      ((int)volume.charAt(1)-48)*10 +
			      ((int)volume.charAt(2)-48);
		     break;
		 }
		 case 5 : { // x,xxx
		     Volume = ((int)volume.charAt(0)-48)*1000 +
			      ((int)volume.charAt(2)-48)*100 +
			      ((int)volume.charAt(3)-48)*10 +
			      ((int)volume.charAt(4)-48);
		     break;
		 }
		 case 6 : {
		     Volume = ((int)volume.charAt(0)-48)*10000 +
			      ((int)volume.charAt(1)-48)*1000 +
			      ((int)volume.charAt(3)-48)*100 +
			      ((int)volume.charAt(4)-48)*10 +
			      ((int)volume.charAt(5)-48);
		     break;
		 }
		 case 7 : {
		     Volume = ((int)volume.charAt(0)-48)*100000 +
			      ((int)volume.charAt(1)-48)*10000 +
			      ((int)volume.charAt(2)-48)*1000 +
			      ((int)volume.charAt(4)-48)*100 +
			      ((int)volume.charAt(5)-48)*10 +
			      ((int)volume.charAt(6)-48);
		     break;
		 }
		 case 9 : { // x,xxx,xxx
		     Volume = ((int)volume.charAt(0)-48)*1000000 +
			      ((int)volume.charAt(2)-48)*100000 +
			      ((int)volume.charAt(3)-48)*10000 +
			      ((int)volume.charAt(4)-48)*1000 +
			      ((int)volume.charAt(6)-48)*100 +
			      ((int)volume.charAt(7)-48)*10 +
			      ((int)volume.charAt(8)-48);
		     break;
		 }
		 case 10 : {
		     Volume = ((int)volume.charAt(0)-48)*10000000 +
			      ((int)volume.charAt(1)-48)*1000000 +
			      ((int)volume.charAt(3)-48)*100000 +
			      ((int)volume.charAt(4)-48)*10000 +
			      ((int)volume.charAt(5)-48)*1000 +
			      ((int)volume.charAt(7)-48)*100 +
			      ((int)volume.charAt(8)-48)*10 +
			      ((int)volume.charAt(9)-48);
		     break;
		 }
		 case 11 : {
		     Volume = ((int)volume.charAt(0)-48)*100000000 +
			      ((int)volume.charAt(1)-48)*10000000 +
			      ((int)volume.charAt(2)-48)*1000000 +
			      ((int)volume.charAt(4)-48)*100000 +
			      ((int)volume.charAt(5)-48)*10000 +
			      ((int)volume.charAt(6)-48)*1000 +
			      ((int)volume.charAt(8)-48)*100 +
			      ((int)volume.charAt(9)-48)*10 +
			      ((int)volume.charAt(10)-48);
		     break;
		 }
		 case 13 : { // x,xxx,xxx,xxx
		     Volume = ((int)volume.charAt(0)-48)*1000000000 +
			      ((int)volume.charAt(2)-48)*100000000 +
			      ((int)volume.charAt(3)-48)*10000000 +
			      ((int)volume.charAt(4)-48)*1000000 +
			      ((int)volume.charAt(6)-48)*100000 +
			      ((int)volume.charAt(7)-48)*10000 +
			      ((int)volume.charAt(8)-48)*1000 +
			      ((int)volume.charAt(10)-48)*100 +
			      ((int)volume.charAt(11)-48)*10 +
			      ((int)volume.charAt(12)-48);
		     break;
		 }
	     }
	 }

	 // convert value  -> Value
	 if (value.charAt(0) == '0') {
	     Value = 0.0;
	 } else {
	     priceLength = value.length() - 3; // remove .00
	     switch (priceLength) {
		 case 1 : {
		     Value =  (double)value.charAt(0) - 48.0;
		     break;
		 }
		 case 2 : {
		     Value = ((double)value.charAt(0)-48.0)*10 +
		             ((double)value.charAt(1)-48.0);
		     break;
		 }
		 case 3 : {
		     Value =  ((double)value.charAt(0)-48.0)*100 +
			      ((double)value.charAt(1)-48.0)*10 +
			      ((double)value.charAt(2)-48.0);
		     break;
		 }
		 case 5 : { // x,xxx
		     Value =  ((double)value.charAt(0)-48.0)*1000 +
			      ((double)value.charAt(2)-48.0)*100 +
			      ((double)value.charAt(3)-48.0)*10 +
			      ((double)value.charAt(4)-48.0);
		     break;
		 }
		 case 6 : {
		     Value =  ((double)value.charAt(0)-48.0)*10000 +
			      ((double)value.charAt(1)-48.0)*1000 +
			      ((double)value.charAt(3)-48.0)*100 +
			      ((double)value.charAt(4)-48.0)*10 +
			      ((double)value.charAt(5)-48.0);
		     break;
		 }
		 case 7 : {
		     Value =  ((double)value.charAt(0)-48.0)*100000 +
			      ((double)value.charAt(1)-48.0)*10000 +
			      ((double)value.charAt(2)-48.0)*1000 +
			      ((double)value.charAt(4)-48.0)*100 +
			      ((double)value.charAt(5)-48.0)*10 +
			      ((double)value.charAt(6)-48.0);
		     break;
		 }
		 case 9 : { // x,xxx,xxx
		     Value =  ((double)value.charAt(0)-48.0)*1000000 +
			      ((double)value.charAt(2)-48.0)*100000 +
			      ((double)value.charAt(3)-48.0)*10000 +
			      ((double)value.charAt(4)-48.0)*1000 +
			      ((double)value.charAt(6)-48.0)*100 +
			      ((double)value.charAt(7)-48.0)*10 +
			      ((double)value.charAt(8)-48.0);
		     break;
		 }
		 case 10 : {
		     Value =  ((double)value.charAt(0)-48.0)*10000000 +
			      ((double)value.charAt(1)-48.0)*1000000 +
			      ((double)value.charAt(3)-48.0)*100000 +
			      ((double)value.charAt(4)-48.0)*10000 +
			      ((double)value.charAt(5)-48.0)*1000 +
			      ((double)value.charAt(7)-48.0)*100 +
			      ((double)value.charAt(8)-48.0)*10 +
			      ((double)value.charAt(9)-48.0);
		     break;
		 }
	     }
	     Value = Value * 1000;
	 }
     } // end method
//=====================================================================================//
     public void insertData2DB(String company) {
	 int column = 1;
	 if (LastPrice != 0.0 && Volume != 0) {
	     try {
		 insert_Data.setString(column++,dateTime);

		 insert_Data.setString(column++,company);
		 insert_Data.setDouble(column++,LastPrice);
		 insert_Data.setDouble(column++,nowPrice);
		 insert_Data.setDouble(column++,PercentChange);
		 insert_Data.setDouble(column++,Bid);
		 insert_Data.setDouble(column++,Offer);
		 insert_Data.setInt   (column++,Volume);
		 insert_Data.setDouble(column++,Value);

		 insert_Data.executeUpdate();

	     } catch (SQLException e) {
		 JOptionPane.showMessageDialog(null, "SQL Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
		 System.exit(0);
	     }
	 }
     }
//=====================================================================================//
} // end class
