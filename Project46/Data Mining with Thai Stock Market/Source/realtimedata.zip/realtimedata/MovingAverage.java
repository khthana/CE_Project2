package realtimedata;

//1. import lib
import java.sql.*;
//=============

public class MovingAverage {

    //2. create variable for connect database
    private String url = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
    private String sql = "SELECT n_security "+ // sql is used for find all n_security (company name)
			 "FROM company_security "+
			 "WHERE n_security IN (SELECT MIN(n_security) "+
			                      "FROM company_security "+
                                              "GROUP BY i_company) "+
                         "ORDER BY n_security;";

    private String companyName = "";
    private String sql_retrive_closePrice;// = "SELECT n_security, z_close "+
                                          //  "FROM daily_stock02 "+
	                                  //  "WHERE n_security='"+companyName+"' "+
	                                  //  "ORDER BY n_security;";

    private String sql_insert_ = "INSERT INTO Daily_Technical_Value "+
				 "VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";

    private Connection con;
    private ResultSet result_CompanyName; // Global (use in initial, update method)

    private double prev_EMA=0, today_closePrice=0;
    private double EMA5=0, EMA40=0, EMA120=0;

//=======================================
    public MovingAverage() {
	//3. Load driver
	try {
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	} catch (java.lang.ClassNotFoundException e) {System.out.println("Driver Error");}
    } // end constructor
//===============================
    public double init(int period, double input, int day) {
	if (day < period || day==period) return input;
	else return finding_EMA(period, input); // will be replace with EMA later
    }
//===============================
    // This method is used for finding EMA
    double finding_EMA(int periods, double closePrice) {
	double multiplier[] = {0.333,0.200,0.154,0.095,0.074,0.049,0.017};
	int p=0;
	// 1. find out multipier
	switch (periods) {
	    case 5   : p=0; break;
	    case 9   : p=1; break;
	    case 12  : p=2; break;
	    case 20  : p=3; break;
	    case 26  : p=4; break;
	    case 40  : p=5; break;
	    case 120 : p=6; break;
	}
	if (closePrice == 0) {
	    return 0.0;
	} else {
	    double tmp = (((closePrice - prev_EMA) * multiplier[p]) + prev_EMA);
	    prev_EMA = tmp; // save last value
	    return tmp;
	}
    }
//===============================
    public String compare() {
	if      (EMA5 < EMA40 && EMA40 < EMA120)  return "EMA5 < EMA40 < EMA120";
	else if (EMA5 < EMA40 && EMA40 > EMA120)  return "EMA5 < EMA40 > EMA120";
	else if (EMA5 < EMA40 && EMA40 == EMA120) return "EMA5 < EMA40 = EMA120";
	else if (EMA5 > EMA40 && EMA40 < EMA120)  return "EMA5 > EMA40 < EMA120";
	else if (EMA5 > EMA40 && EMA40 > EMA120)  return "EMA5 > EMA40 > EMA120";
	else if (EMA5 > EMA40 && EMA40 == EMA120) return "EMA5 > EMA40 = EMA120";
	else if (EMA5 == EMA40 && EMA40 < EMA120) return "EMA5 = EMA40 < EMA120";
	else if (EMA5 == EMA40 && EMA40 > EMA120) return "EMA5 = EMA40 > EMA120";
	else return "EMA5 = EMA40 = EMA120";
    }
//===============================
    public String comparePrice(double tomorrowClosePrice) {
	if (tomorrowClosePrice == 0) return "Stable";
	else if (today_closePrice > tomorrowClosePrice) return "Down";
	else if (today_closePrice < tomorrowClosePrice) return "Up";
	else return "Stable";
    }
//===============================
    public void initialTable() {
	ResultSet result_closePrice;
	Statement stmt, stmt_closePrice;
	PreparedStatement insertStmt;

	//4. Start work with database
	try {
	    con = DriverManager.getConnection(url,"","");
	    // (I) Query all company name
	    stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
	    result_closePrice = stmt.executeQuery(sql); // **
	    result_CompanyName = stmt.executeQuery(sql);
	    result_CompanyName.first(); // result from query **

	    stmt_closePrice = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
	    // (III) Insert calculated EMA into Daily_Technical_Value table.
	    insertStmt = con.prepareStatement(sql_insert_);

	    int ID=95248;
	    double tmp_closePrice=0;
	    int day = 0;

	while (!result_CompanyName.isAfterLast()) { // Loop visit every company
	    companyName = result_CompanyName.getString(1); // get company name
	    System.out.println(companyName);
	    sql_retrive_closePrice = "SELECT n_security, z_close "+
				     "FROM daily_stock00 "+
				     "WHERE n_security='"+companyName+"' "+
				     "ORDER BY d_trade;";

	    // (II) Query company name & daily close price
	    result_closePrice = stmt_closePrice.executeQuery(sql_retrive_closePrice);
	    result_closePrice.first();

	    while (result_closePrice.getRow()==0) { // if 0 row return find new company
		result_CompanyName.next();
		companyName = result_CompanyName.getString(1); // get company name
		sql_retrive_closePrice = "SELECT n_security, z_close "+
					 "FROM daily_stock00 "+
					 "WHERE n_security='"+companyName+"' "+
					 "ORDER BY d_trade;";

		// (II) Query company name & daily close price
		result_closePrice = stmt_closePrice.executeQuery(sql_retrive_closePrice);
		result_closePrice.first();
	    }

	    while (!result_closePrice.isAfterLast()) { //Loop get everyday company close price
		tmp_closePrice = result_closePrice.getDouble(2);

		insertStmt.setInt(1,ID);                // insert ID#
		insertStmt.setString(2,companyName);    // insert company name
		insertStmt.setDouble(3,tmp_closePrice); // insert daily close price
		day++;

		insertStmt.setDouble(4,init(5,    tmp_closePrice, day));
		EMA5=init(5,    tmp_closePrice, day);
		insertStmt.setDouble(5,init(9,    tmp_closePrice, day));
		insertStmt.setDouble(6,init(12,   tmp_closePrice, day));
		insertStmt.setDouble(7,init(20,   tmp_closePrice, day));
		insertStmt.setDouble(8,init(26,   tmp_closePrice, day));
		insertStmt.setDouble(9,init(40,   tmp_closePrice, day));
		EMA40=init(40,    tmp_closePrice, day);
		insertStmt.setDouble(10,init(120, tmp_closePrice, day));
		EMA120=init(120,    tmp_closePrice, day);

		insertStmt.setString(11,compare());

		today_closePrice = tmp_closePrice;
		result_closePrice.next();
//		tmp_closePrice = result_closePrice.getDouble(2);
		if (!result_closePrice.isAfterLast()) insertStmt.setString(12,comparePrice(result_closePrice.getDouble(2)));

		insertStmt.executeUpdate(); // comit sql insert command

		ID++; // increase primary key value
	//	result_closePrice.next();
	    } // end loop in result_closePrice and absolutely get 1 company close price

	    result_CompanyName.next();
	    day=0;
	    prev_EMA=0;
	} // end loop in result_companyName

	    //5. close connection <finish work>
	    result_CompanyName.close();
	    result_closePrice.close();
	} catch (SQLException e) {System.out.println("SQL Error :" + e);}
    }
//===============================
    public static void main(String[] args) {
        MovingAverage movingAverage1 = new MovingAverage();
	movingAverage1.initialTable();
    }
}