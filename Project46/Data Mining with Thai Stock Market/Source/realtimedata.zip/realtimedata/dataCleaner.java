package realtimedata;

//1. import SQL lib
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;

public class dataCleaner extends JFrame{
    private JPanel contentPane;
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();

    //2. Defind variables
    private String url = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
    private Connection DBconnection;
    private Statement selectCompany, selectDailyData;
    private PreparedStatement insert_Data;
    private String SQL_Insert = "INSERT INTO daily_Technical_Analysis(ID#, Company, daily_High, daily_Low, daily_Close, Volume, closePriceUpDown, EMA5, EMA12, EMA20, EMA26, EMA30, EMA_Result, SMA20, StdDev, Bollinger_Result, MACD_FastSlow_Result, EMA9_Diff_FastSlow, MACD_FastSlow_Signal_Result, RSI, RSI_Result, RSI_Result2, MFI, MFI_Result)"+
                                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private ResultSet resultSet_CompanyName;  // Every company. = { n_security }
    private ResultSet resultSet_EverydayData; // Everyday data. = { n_security,z_high,z_low,z_close }
    private String currentCompany = "AA";

    private int MAX_DAY = 900; // max rows of record for each commpany.
    private double dailyHigh[]  = new double[MAX_DAY];
    private double dailyLow[]   = new double[MAX_DAY];
    private double dailyClose[] = new double[MAX_DAY];
    private double dailyVolume[] = new double[MAX_DAY];

    private double multiplier[] = {0.333, 0.200, 0.154, 0.095, 0.074,0.065, 0.049, 0.0198, 0.017};// use in EMA
    private double prev_EMA = 0.0;

    private double memory_SMA[]   = new double[MAX_DAY];
    private double memory_StandardDeviation[] = new double[MAX_DAY];
    private double memory_EMA5[]  = new double[MAX_DAY];
    private double memory_EMA12[] = new double[MAX_DAY];
    private double memory_EMA20[] = new double[MAX_DAY];
    private double memory_EMA26[] = new double[MAX_DAY];
    private double memory_EMA30[] = new double[MAX_DAY];
    private double memory_RSI[]   = new double[MAX_DAY];
//    private double memory_percentK[] = new double[MAX_DAY];
//    private double memory_percentD[] = new double[MAX_DAY];
    private double memory_MFI[]   = new double[MAX_DAY];
    private double memory_MoneyFlow[] = new double[MAX_DAY];

    private double differenceEMA12_26[] = new double[MAX_DAY];       // Fast & Slow
    private double EMA9OfDifferenceEMA12_26[] = new double[MAX_DAY]; // Signal line

    private double MACD = 0.0; // EMA12 - EMA26 <> 0
    private int numberDayTrade = 0;
    private XYLayout xYLayout1 = new XYLayout();

//======================================================================//
//             Start :: Constructure                                    //
//======================================================================//
    public dataCleaner() {
//	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
	try {
	    jbInit();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
    }

    //Component initialization
    private void jbInit() throws Exception  {
//	setIconImage(Toolkit.getDefaultToolkit().createImage(dataCleaner.class.getResource("logo.jpg")));
	contentPane = (JPanel) this.getContentPane();
	contentPane.setLayout(xYLayout1);
	this.setSize(new Dimension(403, 146));
	this.setTitle(" :: \u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21\u0E2B\u0E32\u0E04\u0E48\u0E32\u0E17\u0E32\u0E07 Technical Analysis ::");
	jLabel1.setFont(new java.awt.Font("Dialog", 0, 15));
	jLabel1.setText("\u0E40\u0E23\u0E34\u0E48\u0E21\u0E17\u0E33\u0E07\u0E32\u0E19 ...");
        contentPane.add(jLabel1, new XYConstraints(5, 7, 372, -1));

	jLabel2.setFont(new java.awt.Font("Dialog", 0, 15));
	jLabel2.setText("");
	contentPane.add(jLabel2,   new XYConstraints(5, 37, 372, -1));

	jLabel3.setFont(new java.awt.Font("Dialog", 0, 15));
	jLabel3.setText("");
	contentPane.add(jLabel3,   new XYConstraints(5, 67, 372, -1));
    }
    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
	super.processWindowEvent(e);
	if (e.getID() == WindowEvent.WINDOW_CLOSING) {
	    System.exit(0);
	}
    }

//======================================================================//
//             Method                                                   //
//======================================================================//
    public void cleanData() {
	int day_=1;  // munber of row per company
	int ID=1; // total row calculate ( ID# )

	//3. Load driver
	try {
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	    jLabel1.setText("\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14 JDBC Driver");

	    // (1) Query all company name
	    queryCompanyName();
	    jLabel1.setText("\u0E01\u0E33\u0E25\u0E31\u0E07 query \u0E0A\u0E37\u0E48\u0E2D\u0E2B\u0E25\u0E31\u0E01\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C");

	    // (2) Start calculate technical analysis
	    while (!resultSet_CompanyName.isAfterLast()) {

		currentCompany = resultSet_CompanyName.getString(1);
		resultSet_CompanyName.next();

		// (2.1) Find each company data
		jLabel1.setText("\u0E01\u0E33\u0E25\u0E31\u0E07 query \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E02\u0E2D\u0E07\u0E2B\u0E25\u0E31\u0E01\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C "+currentCompany);
		queryDailyData();

		/* Start to find all values by Technical Analysis
		(2.1.1) call SMA()
		(2.1.2) call EMA()
		(2.1.3) call Bollinger()
		(2.1.4) call MACD()
		(2.1.5) call RSI()
		(2.1.6) call MFI()
		*/
		jLabel1.setText("\u0E01\u0E33\u0E25\u0E31\u0E07 query \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E02\u0E2D\u0E07\u0E2B\u0E25\u0E31\u0E01\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C "+currentCompany);

		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Exponential Moving Average \u0E41\u0E1A\u0E1A 5 \u0E27\u0E31\u0E19");
		day_=1;
                for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA5[day_-1]=EMA(5,day_);
		    day_++;
		}
		day_=1;

		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Exponential Moving Average \u0E41\u0E1A\u0E1A 12 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA12[day_-1]=EMA(12,day_);  // save EMA12 for MACD
		    day_++;
		}
		day_=1;

		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Exponential Moving Average \u0E41\u0E1A\u0E1A 20 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA20[day_-1]=EMA(20,day_);
		    day_++;
		}
		day_=1;

		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Exponential Moving Average \u0E41\u0E1A\u0E1A 26 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA26[day_-1]=EMA(26,day_);  // save EMA26 for MACD
		    day_++;
		}
		day_=1;

		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Exponential Moving Average \u0E41\u0E1A\u0E1A 30 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
                    memory_EMA30[day_-1]=EMA(30,day_);
                    day_++;
                }
                day_=1;
	//-------------------------------------------------------------------//
		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Simple Moving Average \u0E41\u0E1A\u0E1A 20 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
		    memory_SMA[day_-1]=SMA(20,day_);  // save SMA20 for Bollinger Bands
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//
		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Bollinger Bands \u0E41\u0E1A\u0E1A 20 \u0E27\u0E31\u0E19");
                for (int i=0; i<numberDayTrade; i++) {
		    memory_StandardDeviation[day_-1] = BollingerBands(20, day_); // calculate Bollinger Bands
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//
		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Moving Average Convergence Divergence");
                for (int i=0; i<numberDayTrade; i++) { // Calculate difference between Fast and Slow
                    differenceEMA12_26[i] = memory_EMA12[i] - memory_EMA26[i];
                }
                // Find EMA9 of Difference values between Fast and Slow
                for (int i=0; i<numberDayTrade; i++) {
                    EMA9OfDifferenceEMA12_26[i] = EMA2(9,day_);
                    day_++;
                }
                day_=1;
	//-------------------------------------------------------------------//
		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Relative Strength Index \u0E41\u0E1A\u0E1A 14 \u0E27\u0E31\u0E19");
		RSI(14);
	//-------------------------------------------------------------------//
		jLabel2.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07\u0E04\u0E33\u0E19\u0E27\u0E19\u0E04\u0E48\u0E32 Money Flow Index");
		double tmp;
		// Find Money Flow.
		for (int i=0; i<numberDayTrade; i++) {
		    // 1.Average Price = Day High + Day Low + Day Close / 3
		    tmp = ( dailyHigh[i] + dailyLow[i] + dailyClose[i] ) / 3;

		    // 2.Money Flow = Volume x Average Price
		    memory_MoneyFlow[i] = dailyVolume[i] * tmp;
		}

		for (int i=0; i<numberDayTrade; i++) {
		    memory_MFI[day_-1] = MFI(14, day_); // calculate Money Flow Index
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//
/*		// Stochastic Oscilator //
		day_ = 1;
		System.out.println("     Stochastic Oscilator - %K");
		for (int i=0; i<numberDayTrade; i++) {
		    StochasticOscilator_percentK(14, day_);
		    day_++;
		}
		day_=1;
		System.out.println("     Stochastic Oscilator - %D");
		for (int i=0; i<numberDayTrade; i++) {
		    StochasticOscilator_percentD(3, day_);
		    day_++;
		}
*/	//-------------------------------------------------------------------//

	        //(2.2) Insert these data into table "daily_Technical_Analysis"
                int column = 1;

		jLabel3.setText(" \u0E01\u0E33\u0E25\u0E31\u0E07 Insert \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E02\u0E49\u0E32\u0E10\u0E32\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25");
		for (int i=0; i<numberDayTrade; i++) {
		    insert_Data.setInt(column++,ID);             // ID (Primary Key)

		    insert_Data.setString(column++,currentCompany); // Company
		    insert_Data.setDouble(column++,dailyHigh[i]);   // daily High
		    insert_Data.setDouble(column++,dailyLow[i]);    // daily Low
		    insert_Data.setDouble(column++,dailyClose[i]);  // daily Close
		    insert_Data.setDouble(column++,dailyVolume[i]); // daily Volume
		    insert_Data.setString(column++,checkUpLow(i));  // close price Up-Down

                    // Exponential Moving Average
		    insert_Data.setDouble(column++,memory_EMA5[i]);
		    insert_Data.setDouble(column++,memory_EMA12[i]);
		    insert_Data.setDouble(column++,memory_EMA20[i]);
		    insert_Data.setDouble(column++,memory_EMA26[i]);
                    insert_Data.setDouble(column++,memory_EMA30[i]);
		    insert_Data.setString(column++,checkEMA(i));

                    // Simple Moving Average
		    insert_Data.setDouble(column++,memory_SMA[i]);

                    // Bollinger Bands
		    insert_Data.setDouble(column++,memory_StandardDeviation[i]);
		    insert_Data.setString(column++,checkBollinger(i));

                    // MACD
		    insert_Data.setString(column++,checkMACD(i));
                    insert_Data.setDouble(column++,EMA9OfDifferenceEMA12_26[i]);
		    insert_Data.setString(column++,checkMACD2(i));

                    // RSI
		    insert_Data.setDouble(column++,memory_RSI[i]);
		    insert_Data.setString(column++,checkRSI(i));
		    insert_Data.setString(column++,checkRSI_OBOS(i));

		    // MFI
		    insert_Data.setDouble(column++,memory_MFI[i]);
		    insert_Data.setString(column++,checkMFI(i));

                    // Stochastic Oscillator
//		    insert_Data.setDouble(column++,memory_percentK[i]);
//		    insert_Data.setDouble(column++,memory_percentD[i]);
//		    insert_Data.setString(column++,checkStochastic(i));

		    insert_Data.executeUpdate();
		    ID++;
                    column = 1;
		    jLabel3.setText("");
		}

		numberDayTrade=0;
		} // until all company
		jLabel1.setText("\u0E17\u0E33\u0E01\u0E32\u0E23\u0E04\u0E33\u0E19\u0E27\u0E13\u0E04\u0E48\u0E32 Technical Analysis \u0E40\u0E2A\u0E23\u0E47\u0E08\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22");
		jLabel2.setText("Insert \u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 "+ID+" rows");
		jLabel3.setText("");
	}
	catch (java.lang.ClassNotFoundException e) {
	    JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A JDBC Driver : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	    System.exit(0);
	}
	catch (SQLException e) {
	      JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A MS SQL Server : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	      System.exit(0);
	}
    } // end constructure
//=====================================================================================//
    public void queryCompanyName() {
	// sql is used for find all n_security (company name)
	String sql = "SELECT MIN(n_security) "+
		     "FROM daily_stock "+
		     "GROUP BY n_security "+
		     "ORDER BY n_security;";
	try {
	    DBconnection = DriverManager.getConnection(url,"","");
	    selectCompany = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
	    resultSet_CompanyName = selectCompany.executeQuery(sql);
	    resultSet_CompanyName.first();

	    insert_Data = DBconnection.prepareStatement(SQL_Insert);
	} catch (SQLException e) {
	    JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A MS SQL Server : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	    System.exit(0);
	}
    }
//=====================================================================================//
    public void queryDailyData() {
	String sql_closePrice = "SELECT z_high, z_low, z_close, m_value_main "+
				 "FROM daily_stock "+
				 "WHERE n_security ='"+currentCompany+"' "+
				 "ORDER BY d_trade;";
	try {
	    selectDailyData = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
	    resultSet_EverydayData = selectDailyData.executeQuery(sql_closePrice);
	    resultSet_EverydayData.first();

	    while (!resultSet_EverydayData.isAfterLast()) {
		dailyHigh[numberDayTrade]  = resultSet_EverydayData.getDouble(1);
		dailyLow[numberDayTrade]   = resultSet_EverydayData.getDouble(2);
		dailyClose[numberDayTrade] = resultSet_EverydayData.getDouble(3);
		dailyVolume[numberDayTrade] = resultSet_EverydayData.getDouble(4);
		resultSet_EverydayData.next();
		numberDayTrade++;
	    }
	    resultSet_EverydayData.first();
	} catch (SQLException e) {
	    JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A MS SQL Server : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	    System.exit(0);
	}
    }
//=====================================================================================//
    public double EMA(int periods, int day) {
	double SUM = 0.0;
	if (day < periods) {
            SUM = dailyClose[day-1];
            return SUM;
	}
	else if (day == periods) { // first EMA is equal SMA
		for (int i=0; i<periods; i++) {
                    SUM = SUM + dailyClose[i];
                }
		SUM = SUM / periods; // find mean.

	    prev_EMA = SUM;
	    return SUM;
	}
	else {
	    int p=0;
	    double tmp=0.0;

	    switch (periods) {
		case 5   : p=0; break;
		case 9   : p=1; break;
		case 12  : p=2; break;
		case 20  : p=3; break;
		case 26  : p=4; break;
                case 30  : p=4; break;
		case 40  : p=5; break;
                case 100 : p=4; break;
		case 120 : p=6; break;
	    }
                double closePrice = dailyClose[day-1];
		tmp = (((closePrice - prev_EMA) * multiplier[p]) + prev_EMA);
		prev_EMA = tmp; // save last value
	    return tmp;
	}
    }
//=====================================================================================//
    public double EMA2(int periods, int day) { // EMA for MACD Signal Line
        double SUM = 0.0;
        if (day < periods) {
            SUM = differenceEMA12_26[day-1];
            return SUM;
        }
        else if (day == periods) { // first EMA is equal SMA
                for (int i=0; i<periods; i++) {
                    SUM = SUM + differenceEMA12_26[i];
                }
                SUM = SUM / periods; // find mean.

            prev_EMA = SUM;
            return SUM;
        }
        else {
            int p=0;
            double tmp=0.0;

            switch (periods) {
                case 5   : p=0; break;
                case 9   : p=1; break;
                case 12  : p=2; break;
                case 20  : p=3; break;
                case 26  : p=4; break;
                case 30  : p=4; break;
                case 40  : p=5; break;
                case 100 : p=4; break;
                case 120 : p=6; break;
            }
                double closePrice = differenceEMA12_26[day-1];
                tmp = (((closePrice - prev_EMA) * multiplier[p]) + prev_EMA);
                prev_EMA = tmp; // save last value
            return tmp;
        }
    }
//=====================================================================================//
    public double SMA(int periods, int day) {
	double SUM = 0.0;
	if (day < periods) {
            SUM = dailyClose[day-1];
	    return SUM;
	} else {
            for (int i=(day-periods); i<day; i++) {
                SUM = SUM + dailyClose[i];
	    }
	    SUM = SUM / periods; // find mean.

	return SUM;
	}
    }
//=====================================================================================//
    public double BollingerBands(int periods, int day) { // return Standard Deviation value //
	double SUM = 0.0;
	if (day < periods) {
	    return 4.0; // random Standard Deviation //
	} else {
	    // (1) Find Sum of (deviation values)^2 => E(close price - SMA20)^2
            for (int i=(day-periods); i<day; i++) {
                SUM = SUM + Math.pow((dailyClose[i] - memory_SMA[day-1]),2);
	    }
	    // (2) Devide by periods
	    SUM = SUM / periods;
	    // (3) Find square root
	    SUM = Math.sqrt(SUM);
	return SUM;
	}
    }
//=====================================================================================//
    public void RSI(int periods) {
	int day___ = 1;
	double today_closePrice, yesterday_closePrice;
	double change_Increase[] = new double[MAX_DAY];
	double change_Decrease[] = new double[MAX_DAY];
	double average_Gain=0.0, average_Loss=0.0;
	double firstRS=0.0;
	double memory_smoothRS[] = new double[MAX_DAY];

	try {
	    // (1) Find increase price => average gain
	    //     Find decrease price => average loss
	    change_Increase[0] = 0.0;
	    change_Decrease[0] = 0.0; // 1st day close price dont change.

	    resultSet_EverydayData.first();
	    yesterday_closePrice = resultSet_EverydayData.getDouble(3);
	    resultSet_EverydayData.next();

	    while (!resultSet_EverydayData.isAfterLast()) {
		today_closePrice = resultSet_EverydayData.getDouble(3); // get today close price
		resultSet_EverydayData.next();

		if (today_closePrice == yesterday_closePrice) {
		    change_Increase[day___] = 0.0;
		    change_Decrease[day___] = 0.0;
		}
		else if (today_closePrice > yesterday_closePrice) {
		    change_Increase[day___] = today_closePrice - yesterday_closePrice;
		    change_Decrease[day___] = 0.0;
		} else {
		    change_Increase[day___] = 0.0;
		    change_Decrease[day___] = yesterday_closePrice - today_closePrice;
		}
		yesterday_closePrice = today_closePrice;
		day___++;
	    }

	    // (2) Find First RS
	    for (int i=1; i<15; i++) {  // day 1-14
		average_Gain = average_Gain + change_Increase[i]; // sum change increase
		average_Loss = average_Loss + change_Decrease[i]; // sum change decrease
	    }
	    average_Gain = average_Gain / 14;
	    average_Loss = average_Loss / 14;
	    firstRS = average_Gain / average_Loss;

	    // (3) Afterthat find Smooth RS, start at day 15
	    memory_smoothRS[0] = ((average_Gain * 13) + change_Increase[15]) /
			         ((average_Loss * 13) + change_Decrease[15]);

 	    for (int j=15; j<(day___+1); j++) {
		 // find new average gain & loss
		 average_Gain = 0.0;
		 average_Loss = 0.0;
		 for (int i=(j-13); i<(j+1); i++) {
		     average_Gain = average_Gain + change_Increase[i]; // sum change increase
		     average_Loss = average_Loss + change_Decrease[i]; // sum change decrease
		 }
		 average_Gain = average_Gain / 14;
		 average_Loss = average_Loss / 14;
		 // day 16 until last.
		memory_smoothRS[j-14] = ((average_Gain * 13) + change_Increase[j]) /
				        ((average_Loss * 13) + change_Decrease[j]);
	    }

	    // (4) Calculate RSI
	    for (int i=0; i<14; i++) {
		memory_RSI[i] = 50.0; // day 0 - day 13 , no RSI so random RSI for them
	    }
	    memory_RSI[14] = 100 - (100/(1 + firstRS));  // First RSI so use first RS

	    for (int i=15; i<(day___+1); i++) {
		memory_RSI[i] = 100 - (100/(1 + memory_smoothRS[i-15]));
	    }
	} catch (SQLException e) {
	    JOptionPane.showMessageDialog(null, "Calculate RSI Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	}
    }
//=====================================================================================//
    public double MFI(int period, int day) {
	double sumPosMoneyFlow, sumNegMoneyFlow, moneyRatio;

	if (day < period) {
	    return 50.0;
	} else {
	    // 3.Find Positive Money Flow & Find Negative Money Flow
	    if (day == 14) {
		sumPosMoneyFlow = memory_MoneyFlow[0];
		sumNegMoneyFlow = memory_MoneyFlow[0];

		for (int i=1; i<14; i++) {
		    if (dailyClose[i] > dailyClose[i-1]) {
			sumPosMoneyFlow = sumPosMoneyFlow + memory_MoneyFlow[i];
		    } else if (dailyClose[i] == dailyClose[i]) {
			sumPosMoneyFlow = sumPosMoneyFlow + memory_MoneyFlow[i];
			sumNegMoneyFlow = sumNegMoneyFlow + memory_MoneyFlow[i];
		    } else {
			sumNegMoneyFlow = sumNegMoneyFlow + memory_MoneyFlow[i];
		    }
		}
	    } else {
		sumPosMoneyFlow = 0.0;
		sumNegMoneyFlow = 0.0;

		for (int i=(day - period); i<day; i++) {
		    if (dailyClose[i] > dailyClose[i-1]) {
			sumPosMoneyFlow = sumPosMoneyFlow + memory_MoneyFlow[i];
		    } else if (dailyClose[i] == dailyClose[i-1]) {
			sumPosMoneyFlow = sumPosMoneyFlow + memory_MoneyFlow[i];
			sumNegMoneyFlow = sumNegMoneyFlow + memory_MoneyFlow[i];
		    } else {
			sumNegMoneyFlow = sumNegMoneyFlow + memory_MoneyFlow[i];
		    }
		}
	    }

	    // 4.Find Money Ratio = Sum( Positive Money Flow ) / Sum( Negative Money Flow )
	    moneyRatio = sumPosMoneyFlow / sumNegMoneyFlow;

	    // 5.Find Money Flow Index (MFI) = 100 - ( 100 / (1 + Money Ratio) )
	    return 100 - ( 100 / (1 + moneyRatio) );
	}
    }
//=====================================================================================//
/*
    public void StochasticOscilator_percentK(int period, int day) {
	// %K = 100 x ( RecentClose - Lowest(period) ) / ( Highest(period) - Lowest(period) )
	double highestHigh = 0.0, lowestLow = 0.0;
	double tmp[] = new double[period];
	int index = 0;

	if (day < period) {
	    memory_percentK[day-1] = 100*( (dailyClose[day-1]-dailyLow[day-1]) /
		                           (dailyHigh[day-1]-dailyLow[day-1]) );
	} else {

	    // 1.Find Highest High price in period
	    for (int i=(day-period); i<day; i++) {
		tmp[index] = dailyHigh[i];
		index++;
	    }

	    highestHigh = tmp[0];
	    for (int i=0; i<(index-1); i++) {
		if (highestHigh < tmp[i+1]) highestHigh = tmp[i+1];
	    }

	    // 2.Find Lowest Low price in period
	    index=0;
	    for (int i=(day-period); i<day; i++) {
		tmp[index] = dailyLow[i];
		index++;
	    }

            lowestLow = tmp[0];
	    for (int i=0; i<(index-1); i++) {
		if (tmp[i+1] < lowestLow) lowestLow = tmp[i+1];
	    }

	    // 3.Find %K
	    memory_percentK[day-1] = 100*( (dailyClose[day-1] - lowestLow) /
		                           (highestHigh - lowestLow) );
	}
    }
//=====================================================================================//
    public void StochasticOscilator_percentD(int period, int day) {
	// %D = 3 day simple moving average of %K
	double SUM = 0.0;
	if (day < period) {
	    memory_percentD[day-1] = memory_percentK[day-1];
	} else {
	    for (int i=(day-period); i<day; i++) {
		SUM = SUM + memory_percentK[i];
	    }
	    SUM = SUM / period; // find mean.
	    memory_percentD[day-1] = SUM;
	}
    }
*/
//=====================================================================================//
    public String checkUpLow(int day) {
	if (dailyClose[day+1] == dailyClose[day]) return "Tomorrow Stable";
	else if (dailyClose[day+1] > dailyClose[day]) return "Tomorrow Increase";
	else return "Tomorrow Decrease";
    }

//=====================================================================================//
//        Start to Predict using Technical Analysis                                    //
//=====================================================================================//
    public String checkEMA(int day) { // EMA will tell Buy, Sell point
	if (memory_EMA5[day] == memory_EMA30[day] ||
	    memory_EMA5[day] >  memory_EMA30[day]) return "Buy Signal";
	else return "Sell Signal";
    }
//=====================================================================================//
    public String checkBollinger(int day) {
        // Price line rise over upper bands
	if (dailyClose[day] > (memory_SMA[day]+(2*memory_StandardDeviation[day])) &&
            ((day+2)<numberDayTrade))
        {
            if (dailyClose[day+1] > (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] > (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
                return "Bullish Trend";
            }
            else
            if (dailyClose[day+1] > (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] < (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
                return "Bearish Trend";
            }
            else
            if (dailyClose[day+1] < (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] < (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
                return "Bearish Trend";
            }
            else
            if (dailyClose[day+1] < (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] > (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
                return "Bullish Trend";
            }
            else
            if (dailyClose[day+1] == (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] == (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
                return "Sideway Trend";
            }
            else return "Sideway Trend";
        }

        // Price line drop under lower bands
        else
            if (dailyClose[day] < (memory_SMA[day]-(2*memory_StandardDeviation[day])) &&
            ((day+2)<numberDayTrade))
        {
            if (dailyClose[day+1] < (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] < (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
                return "Bearish Trend";
            }
            else
            if (dailyClose[day+1] < (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] > (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
                return "Bullish Trend";
            }
            else
            if (dailyClose[day+1] > (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] > (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
                return "Bullish Trend";
            }
            else
            if (dailyClose[day+1] > (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] < (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
                return "Bearish Trend";
            }
            else
            if (dailyClose[day+1] == (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
               (dailyClose[day+2] == (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
                return "Sideway Trend";
            }
            else return "Sideway Trend";
        }
        // Price line swing within upper bands and lower bands,
        // so determine the Price line and middle bands instead.
        else
        {
            if ((dailyClose[day] == memory_SMA[day]) && ((day+2)<numberDayTrade) )
            {
                if (day>1                                  &&
                   (dailyClose[day-1] < memory_SMA[day-1]) &&
                   ((dailyClose[day+1] > memory_SMA[day+1])||
                    (dailyClose[day+2] > memory_SMA[day+2])))
                {
                    return "Bullish Trend";
                }
                else
                    if (day>1                                  &&
                       (dailyClose[day-1] > memory_SMA[day-1]) &&
                       ((dailyClose[day+1] < memory_SMA[day+1])||
                        (dailyClose[day+2] < memory_SMA[day+2])))
                    {
                        return "Bearish Trend";
                    }
                else return "Sideway Trend";
            }
            else
                // Price line rise over SMA20 line (Middle bands)
                if ((dailyClose[day] > memory_SMA[day]) && ((day+2)<numberDayTrade) )
                {
                    if ((dailyClose[day+1] > memory_SMA[day+1]) &&
                        (dailyClose[day+2] > memory_SMA[day+2]))
                    {
                        return "Bullish Trend";
                    }
                    else
                        if ((dailyClose[day+1] > memory_SMA[day+1]) &&
                            (dailyClose[day+2] < memory_SMA[day+2]))
                        {
                            return "Bearish Trend";
                        }
                    else
                        if ((dailyClose[day+1] < memory_SMA[day+1]) &&
                            (dailyClose[day+2] < memory_SMA[day+2]))
                        {
                            return "Bearish Trend";
                        }
                    else return "Sideway Trend";
                }
                else
                    // Price line drop under SMA20 line (Middle bands)
                    if ((dailyClose[day] < memory_SMA[day]) && ((day+2)<numberDayTrade) )
                    {
                        if ((dailyClose[day+1] < memory_SMA[day+1]) &&
                            (dailyClose[day+2] < memory_SMA[day+2]))
                        {
                            return "Bearish Trend";
                        }
                        else
                            if ((dailyClose[day+1] < memory_SMA[day+1]) &&
                                (dailyClose[day+2] > memory_SMA[day+2]))
                            {
                                return "Bullish Trend";
                            }
                        else
                            if ((dailyClose[day+1] > memory_SMA[day+1]) &&
                                (dailyClose[day+2] > memory_SMA[day+2]))
                            {
                                return "Bullish Trend";
                            }
                        else return "Sideway Trend";
                    }
                else return "Sideway Trend";
        }
    }
//=====================================================================================//
    public String checkMACD(int day) {
	if ((memory_EMA12[day] - memory_EMA26[day]) > 0) return "Bullish Trend";
	else if ((memory_EMA12[day] - memory_EMA26[day]) < 0) return "Bearish Trend";
	else return "Sideway Trend";
    }
//=====================================================================================//
    public String checkMACD2(int day) {
        if ((memory_EMA12[day] - memory_EMA26[day]) > EMA9OfDifferenceEMA12_26[day]) return "Buy Signal";
        else return "Sell Signal";
    }
//=====================================================================================//
    public String checkRSI(int day) {
	if ( (memory_RSI[day] > 70) && (day+5 < numberDayTrade) &&
	     ( (memory_RSI[day+1] < 70) ||
	       (memory_RSI[day+2] < 70) ||
	       (memory_RSI[day+3] < 70) ||
	       (memory_RSI[day+4] < 70) ||
	       (memory_RSI[day+5] < 70) ))
	{
	    return "Sell Signal";
	}
	else
	if ( (memory_RSI[day] < 30) && (day+5 < numberDayTrade) &&
	    ( (memory_RSI[day+1] > 30) ||
	      (memory_RSI[day+2] > 30) ||
	      (memory_RSI[day+3] > 30) ||
	      (memory_RSI[day+4] > 30) ||
	      (memory_RSI[day+5] > 30) ))
	{
	    return "Buy Signal";
	}
	else
	if ( (memory_RSI[day] < 50) && (day+5 < numberDayTrade) &&
	    ( (memory_RSI[day+1] > 50) ||
	      (memory_RSI[day+2] > 50) ||
	      (memory_RSI[day+3] > 50) ||
	      (memory_RSI[day+4] > 50) ||
	      (memory_RSI[day+5] > 50) ))
	{
	    return "Buy Signal";
	}
	else
	if ( (memory_RSI[day] > 50) && (day+5 < numberDayTrade) &&
	    ( (memory_RSI[day+1] < 50) ||
	      (memory_RSI[day+2] < 50) ||
	      (memory_RSI[day+3] < 50) ||
	      (memory_RSI[day+4] < 50) ||
	      (memory_RSI[day+5] < 50) ))
	{
	    return "Sell Signal";
	}
	else return "Sideway Trend";
    }
//=====================================================================================//
    public String checkRSI_OBOS(int day) {
	if (memory_RSI[day] < 30) {
	    return "Oversold";
	} else if (memory_RSI[day] > 70) {
	    return "Overbought";
	}
	else return "Sideway Trend";
    }
//=====================================================================================//
    public String checkMFI(int day) {
	if (memory_MFI[day] < 20) {
	    return "Buy Signal";
	} else if (memory_MFI[day] > 80) {
	    return "Sell Signal";
	}
	else return "Nothing";
    }
//=====================================================================================//
/*
    public String checkStochastic(int day) {
	if ( (memory_percentK[day] < 20) && (day+3 < numberDayTrade) &&
	     ( (memory_percentK[day+1] > 20) ||
	       (memory_percentK[day+2] > 20) ||
	       (memory_percentK[day+3] > 20) ))
	{
	    return "Bullish Trend";
	}
	else
	    if ( (memory_percentK[day] > 80) && (day+3 < numberDayTrade) &&
		 ( (memory_percentK[day+1] < 80) ||
		   (memory_percentK[day+2] < 80) ||
		   (memory_percentK[day+3] < 80) ))
	    {
		return "Bearish Trend";
	    }
	else
	    if ( memory_percentK[day] < memory_percentD[day] )
	    {
		return "Bearish Trend";
	    }
	else
	    if ( memory_percentK[day] > memory_percentD[day] )
	    {
		return "Bullish Trend";
	    }
	else return "Stable Trend";
    }
*/
//=====================================================================================//
}