package realtimedata;

import java.io.*;
import java.sql.*;
import java.util.*;

public class insertData2DB {
    public static void main(String[] args) {
	String url = "jdbc:odbc:DataMining";
	Connection con;

	Random r = new Random();
//	String insertData = "INSERT INTO test_Tree2 VALUES (?,?,?,?,?,?,?,?,?,?,?);";
	String insertData = "INSERT INTO Table2 VALUES (?,?,?,?,?,?,?);";

	PreparedStatement pstmt;

//	int number_att = 7;

//	boolean value[] = new boolean[10];
	for (int i=0; i<10; i++) {
//	    value[i] = r.nextBoolean();
//	    System.out.println(value[i]);
	    System.out.println(r.nextInt(10000)%5);
	}
//System.exit(0);
	try {
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	} catch (java.lang.ClassNotFoundException e) {System.out.println("Driver Error");}

	try {
	    con = DriverManager.getConnection(url,"","");

	    //insertData = "UPDATE daily_stock02.ID = (?) WHERE ID = 1";
	    pstmt = con.prepareStatement(insertData);

	    for (int i=1; i<5000; i++) { // insert 10000 row
//		System.out.println("Start insert data");
		pstmt.setInt(1,(i));  // Example
		if (i%100 == 0) System.out.println(i);

/*		for (int j=0; j<9; j++) {
		    if (value[j])  pstmt.setString(j+2,"T");   // MA - ROC
		    else  pstmt.setString(j+2,"F");
		}

		if (value[9]) pstmt.setString(11,"B");  // set Buy/Sell
		else pstmt.setString(11,"S");

		pstmt.executeUpdate();

		for (int ii=0; ii<10; ii++) {
		    value[ii] = r.nextBoolean();
		}
*/
//====================================================//
		// Moving average
		switch (r.nextInt(19999) % 5) {
		    case 0 : pstmt.setString(2,"MA5 < MA40 < MA120"); // sell
		    case 1 : pstmt.setString(2,"MA5 < MA40 > MA120"); // sell
		    case 2 : pstmt.setString(2,"MA5 > MA40 < MA120"); //buy
		    case 3 : pstmt.setString(2,"MA5 > MA40 > MA120"); //buy
		    case 4 : pstmt.setString(2,"Others"); // no change
		}
		// Moving average
/*		switch (r.nextInt(10000) % 5) {
		    case 0 : pstmt.setString(2,"MA5 < MA40 < MA120"); break;
		    case 1 : pstmt.setString(2,"MA5 < MA40 > MA120"); break;
		    case 2 : pstmt.setString(2,"MA5 > MA40 < MA120"); break;
		    case 3 : pstmt.setString(2,"MA5 > MA40 > MA120"); break;
		    case 4 : pstmt.setString(2,"Others"); break;
		}
		// Bollinger Bands
		switch (r.nextInt(10000) % 5) {
		    case 0 : pstmt.setString(3,"MA20 > Upper Bands"); break;
		    case 1 : pstmt.setString(3,"MA20 < Lower Bands"); break;
		    case 2 : pstmt.setString(3,"ClosePrice > MA20"); break;
		    case 3 : pstmt.setString(3,"ClosePrice < MA20"); break;
		    case 4 : pstmt.setString(3,"Others"); break;
		}
		// MACD
		switch (r.nextInt(10000) % 5) {
		    case 0 : pstmt.setString(4,"MACD > 0"); break;
		    case 1 : pstmt.setString(4,"MACD < 0"); break;
		    case 2 : pstmt.setString(4,"MACD > MA9"); break;
		    case 3 : pstmt.setString(4,"MACD < MA9"); break;
		    case 4 : pstmt.setString(4,"Others"); break;
		}
		// RSI
		switch (r.nextInt(10000) % 3) {
		    case 0 : pstmt.setString(5,"Down parabola"); break;
		    case 1 : pstmt.setString(5,"Up parabola"); break;
		    case 2 : pstmt.setString(5,"Others"); break;
		}
		// Stochastic
		switch (r.nextInt(10000) % 5) {
		    case 0 : pstmt.setString(6,"Up parabola"); break;
		    case 1 : pstmt.setString(6,"Down parabola"); break;
		    case 2 : pstmt.setString(6,"%K > %D"); break;
		    case 3 : pstmt.setString(6,"%K < %D"); break;
		    case 4 : pstmt.setString(6,"Others"); break;
		}
		// Price
		switch (r.nextInt(10000) % 3) {
		    case 0 : pstmt.setString(7,"Up"); break;
		    case 1 : pstmt.setString(7,"Down"); break;
		    case 2 : pstmt.setString(7,"Not Change"); break;
		}
*/
		pstmt.executeUpdate();
	    }

	} catch (SQLException e) {System.out.println("SQL Error :" + e);}
    }
}