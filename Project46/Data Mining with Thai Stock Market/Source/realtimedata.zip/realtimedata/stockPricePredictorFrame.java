package realtimedata;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.sql.*;

public class stockPricePredictorFrame extends JFrame {
    private JPanel contentPane;
    private JPanel jPanel1 = new JPanel();
    private BorderLayout borderLayout1 = new BorderLayout();
    private XYLayout xYLayout1 = new XYLayout();

    private String ema[]  = {"     ", "Buy Signal", "Sell Signal"};
    private String boll[] = {"     ", "Bullish Trend", "Bearish Trend", "Sideway Trend"};
    private String macd[] = {"     ", "Bullish Trend", "Bearish Trend", "Sideway Trend"};
    private String mac2[] = {"     ", "Buy Signal", "Sell Signal"};
    private String rsi[]  = {"     ", "Buy Signal", "Sell Signal"};
    private String rsi2[] = {"     ", "Overbought", "Oversold", "Sideway Trend"};
    private String mfi[]  = {"     ", "Buy Signal", "Sell Signal", "Sideway"};

    private JComboBox jComboBox_Boll = new JComboBox(boll);
    private JComboBox jComboBox_EMA = new JComboBox(ema);
    private JComboBox jComboBox_RSI = new JComboBox(rsi);
    private JComboBox jComboBox_RSI2 = new JComboBox(rsi2);
    private JComboBox jComboBox_MACD = new JComboBox(macd);
    private JComboBox jComboBox_MFI = new JComboBox(mfi);
    private JComboBox jComboBox_MACD2 = new JComboBox(mac2);
    private JLabel jLabel1 = new JLabel();
    private JLabel jLabel2 = new JLabel();
    private JLabel jLabel3 = new JLabel();
    private JLabel jLabel4 = new JLabel();
    private JLabel jLabel5 = new JLabel();
    private JLabel jLabel6 = new JLabel();
    private JLabel jLabel7 = new JLabel();
    private JButton jButton1 = new JButton();

    private String EMA="     ", BOLL="     ", MACD1="     ", MACD2="     ", RSI1="     ", RSI2="     ", MFI="     ";

    private String url = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
    private Connection DBconnection;
    private Statement selectPredict;
    private ResultSet resultSet_PricePredict;  // Every company. = { n_security }

//---------------------------------------------------------------------------//
    //Construct the frame
    public stockPricePredictorFrame() {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
       }
       catch (java.lang.ClassNotFoundException e) {
	   JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A JDBC Driver : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	   System.exit(0);
       }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
//---------------------------------------------------------------------------//

    //Component initialization
    private void jbInit() throws Exception  {
	setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("logo.jpg")));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(borderLayout1);
        this.setSize(new Dimension(291, 283));
        this.setTitle(":: Predict tomorrow Price ::");
        jPanel1.setLayout(xYLayout1);
        jLabel1.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel1.setText("EMA Signal");
        jLabel2.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel2.setText("Bollinger Bands Trend");
        jLabel3.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel3.setText("MACD Trend");
        jLabel4.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel4.setText("MACD Signal");
        jLabel5.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel5.setText("RSI Signal");
        jLabel6.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel6.setText("RSI OB/OS");
        jLabel7.setFont(new java.awt.Font("Dialog", 0, 13));
        jLabel7.setText("MFI Signal");
        jButton1.setFont(new java.awt.Font("Dialog", 0, 14));
        jButton1.setText("Predict now");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jButton1_actionPerformed(e);
            }
        });
        jComboBox_EMA.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_EMA.setSelectedItem("     ");
        jComboBox_EMA.setPreferredSize(new Dimension(90, 21));
        jComboBox_EMA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_EMA_actionPerformed(e);
            }
        });
        jComboBox_MACD2.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_MACD2.setSelectedItem("     ");
        jComboBox_MACD2.setPreferredSize(new Dimension(90, 21));
        jComboBox_MACD2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_MACD2_actionPerformed(e);
            }
        });
        jComboBox_RSI.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_RSI.setSelectedItem("     ");
        jComboBox_RSI.setPreferredSize(new Dimension(90, 21));
        jComboBox_RSI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_RSI_actionPerformed(e);
            }
        });
        jComboBox_MFI.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_MFI.setSelectedItem("     ");
        jComboBox_MFI.setPreferredSize(new Dimension(90, 21));
        jComboBox_MFI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_MFI_actionPerformed(e);
            }
        });
        jComboBox_Boll.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_Boll.setSelectedItem("     ");
        jComboBox_Boll.setPreferredSize(new Dimension(90, 21));
        jComboBox_Boll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_Boll_actionPerformed(e);
            }
        });
        jComboBox_MACD.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_MACD.setSelectedItem("     ");
        jComboBox_MACD.setPreferredSize(new Dimension(90, 21));
        jComboBox_MACD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_MACD_actionPerformed(e);
            }
        });
        jComboBox_RSI2.setFont(new java.awt.Font("SansSerif", 0, 13));
	jComboBox_RSI2.setSelectedItem("     ");
        jComboBox_RSI2.setPreferredSize(new Dimension(90, 21));
        jComboBox_RSI2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jComboBox_RSI2_actionPerformed(e);
            }
        });
        contentPane.add(jPanel1, BorderLayout.CENTER);
        jPanel1.add(jLabel1,   new XYConstraints(31, 25,  -1, -1));
        jPanel1.add(jLabel2,   new XYConstraints(31, 50,  -1, -1));
        jPanel1.add(jLabel3,   new XYConstraints(31, 75,  -1, -1));
        jPanel1.add(jLabel4,   new XYConstraints(31, 100, -1, -1));
        jPanel1.add(jLabel5,   new XYConstraints(31, 125, -1, -1));
        jPanel1.add(jLabel6,   new XYConstraints(31, 150, -1, -1));
        jPanel1.add(jLabel7,   new XYConstraints(31, 175, -1, -1));
        jPanel1.add(jComboBox_RSI,   new XYConstraints(161, 125, -1, -1));
        jPanel1.add(jComboBox_EMA,   new XYConstraints(161, 25,  -1, -1));
        jPanel1.add(jComboBox_Boll,  new XYConstraints(161, 50,  -1, -1));
        jPanel1.add(jComboBox_MACD,  new XYConstraints(161, 75,  -1, -1));
        jPanel1.add(jComboBox_MACD2, new XYConstraints(161, 100, -1, -1));
        jPanel1.add(jComboBox_RSI2,  new XYConstraints(161, 150, -1, -1));
        jPanel1.add(jComboBox_MFI,   new XYConstraints(161, 175, -1, -1));
        jPanel1.add(jButton1,        new XYConstraints(129, 213, -1, -1));
    }

//---------------------------------------------------------------------------//
    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            System.exit(0);
        }
    }
//---------------------------------------------------------------------------//
    // Click!!
    void jButton1_actionPerformed(ActionEvent e) {
	if (EMA.equals("     ")&&BOLL.equals("     ")&&MACD1.equals("     ")&&
	    MACD2.equals("     ")&&RSI1.equals("     ")&&RSI2.equals("     ")&&MFI.equals("     ")) {
	    JOptionPane.showMessageDialog(null, "PLEASE SELECT ANY INPUT","PLEASE SELECT INPUT",JOptionPane.WARNING_MESSAGE);
	}
	else
        if (EMA.equals("<NULL>")&&BOLL.equals("<NULL>")&&MACD1.equals("<NULL>")&&
	    MACD2.equals("<NULL>")&&RSI1.equals("<NULL>")&&RSI2.equals("<NULL>")&&MFI.equals("<NULL>")) {
	    JOptionPane.showMessageDialog(null, "PLEASE SELECT ANY INPUT","PLEASE SELECT INPUT",JOptionPane.WARNING_MESSAGE);
	} else
	{
	    if (EMA.equals("     "))   EMA="<NULL>";
	    if (BOLL.equals("     "))  BOLL="<NULL>";
	    if (MACD1.equals("     ")) MACD1="<NULL>";
	    if (RSI1.equals("     "))  RSI1="<NULL>";
	    if (RSI2.equals("     "))  RSI2="<NULL>";
	    if (MFI.equals("     "))   MFI="<NULL>";
	    if (MACD2.equals("     ")) MACD2="<NULL>";

	    queryPredict();
	    try {
		JOptionPane.showMessageDialog(null, "Tomorrow price will "+resultSet_PricePredict.getString(1)+" = "+(resultSet_PricePredict.getDouble(2)*100)+" %","Predict Output",JOptionPane.INFORMATION_MESSAGE);
	    }
	    catch (SQLException ee) {
		JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A MS SQL Server : "+ee.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
		System.exit(0);
	    }
	} // end big else
    }
//---------------------------------------------------------------------------//

    void jComboBox_EMA_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    EMA = "<NULL>";
	}
	else if (select == "Buy Signal") {
	    EMA = select;
	}
	else if (select == "Sell Signal") {
	    EMA = select;
	}
    }

    void jComboBox_Boll_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    BOLL = "<NULL>";
	}
	else {
	    BOLL = select;
	}
    }

    void jComboBox_MACD_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    MACD1 = "<NULL>";
	}
	else {
	    MACD1 = select;
	}
    }

    void jComboBox_MACD2_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    MACD2 = "<NULL>";
	}
	else {
	    MACD2 = select;
	}

    }

    void jComboBox_RSI_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    RSI1 = "<NULL>";
	}
	else {
	    RSI1 = select;
	}
    }

    void jComboBox_RSI2_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    RSI2 = "<NULL>";
	}
	else {
	    RSI2 = select;
	}
    }

    void jComboBox_MFI_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
	String select = (String)cb.getSelectedItem();

	if (select == "     ") {
	    MFI = "<NULL>";
	}
	else if (select == "Sideway") {
	    MFI = "Nothing";
	}
	else {
	    MFI = select;
	}
    }
//---------------------------------------------------------------------------//
    public void queryPredict() {
	// sql is used for find all n_security (company name)
	String sql = "SELECT ClosePriceUpDown, ProbPredict "+
		     "FROM predictTable "+
		     "WHERE EmaResult       ='"+EMA+"'   AND "+
		     "      BollingerResult ='"+BOLL+"'  AND "+
		     "      RsiResult       ='"+RSI1+"'  AND "+
		     "      RsiResult2      ='"+RSI2+"'  AND "+
 	             "      MfiResult       ='"+MFI+"'   AND "+
	             "      MacdResult      ='"+MACD1+"' AND "+
	             "      MacdResult2     ='"+MACD2+"'";

	try {
	    DBconnection = DriverManager.getConnection(url,"","");
	    selectPredict = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
	    resultSet_PricePredict = selectPredict.executeQuery(sql);
	    resultSet_PricePredict.first();

	} catch (SQLException e) {
	    JOptionPane.showMessageDialog(null, "\u0E21\u0E35\u0E1B\u0E31\u0E0D\u0E2B\u0E32\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A MS SQL Server : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
	}
    }
//---------------------------------------------------------------------------//

} // end class