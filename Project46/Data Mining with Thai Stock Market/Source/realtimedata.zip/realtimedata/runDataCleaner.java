package realtimedata;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;

public class runDataCleaner {
    private boolean packFrame = false;
    private Timer timer;
    private dataCleaner frame;
    private int delay = 1;
    private int count = 1;
    private boolean start = true;

    //Construct the application
    public runDataCleaner() {
	frame = new dataCleaner();

	//Validate frames that have preset sizes
	//Pack frames that have useful preferred size info, e.g. from their layout
	if (packFrame) {
	    frame.pack();
	}
	else {
	    frame.validate();
	}
	//Center the window
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	Dimension frameSize = frame.getSize();
	if (frameSize.height > screenSize.height) {
	    frameSize.height = screenSize.height;
	}
	if (frameSize.width > screenSize.width) {
	    frameSize.width = screenSize.width;
	}
	frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
	frame.setVisible(true);
    }

    //Main method
    public static void main(String[] args) {
	try {
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	}
	catch(Exception e) {
	    e.printStackTrace();
	}

       runDataCleaner yy = new runDataCleaner();
       yy.frame.cleanData();
    }
}