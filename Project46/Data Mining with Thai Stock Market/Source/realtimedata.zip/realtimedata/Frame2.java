package realtimedata;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.net.*;
import java.io.*;
import com.borland.jbcl.layout.*;

public class Frame2 extends JFrame {// implements HyperlinkListener{
    private JPanel contentPane;
    private BorderLayout borderLayout1 = new BorderLayout();

    ///////////////////////
    private JPanel topPanel = new JPanel();// = new JScrollPane();
    private JLabel autoRefreshLabel = new JLabel();
    private XYLayout xYLayout1 = new XYLayout();// = new JEditorPane();

    private String timeRefreshBox[] = {"1 Min", "5 Min", "10 Min"};
    private JComboBox selectTimeBox;// = new JComboBox(timeRefresh);
    private JTabbedPane jTabbedPane1 = new JTabbedPane();
    private JScrollPane scrollHtmlPane = new JScrollPane();
    private JPanel selectStockPane = new JPanel();
    private XYLayout xYLayout2 = new XYLayout();


    private JTextField inputCompany1 = new JTextField(5);
    private JTextField inputCompany2 = new JTextField(5);
    private JTextField inputCompany3 = new JTextField(5);
    private JTextField inputCompany4 = new JTextField(5);
    private JTextField inputCompany5 = new JTextField(5);
    private JTextField inputCompany6 = new JTextField(5);
    private JTextField inputCompany7 = new JTextField(5);
    private JTextField inputCompany8 = new JTextField(5);
    private JTextField inputCompany9 = new JTextField(5);
    private JTextField inputCompany10 = new JTextField(5);

    private JLabel labelLast = new JLabel();
    private JLabel labelChange = new JLabel();
    private JLabel labelPerChange = new JLabel();
    private JLabel labelBid = new JLabel();
    private JLabel labelOffer = new JLabel();
    private JLabel labelVolume = new JLabel();
    private JLabel labelValue = new JLabel();


    /////////////////////
    private myDelay2 delay = new myDelay2(1); // default 1 Min //
    private JButton okButton = new JButton();
//    private connectWeb readFile = new connectWeb();

    //Construct the frame
    public Frame2() {
	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    //Component initialization
    private void jbInit() throws Exception  {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("logo.jpg")));
        this.setResizable(false);
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(borderLayout1);
        this.setSize(new Dimension(600, 500));
        this.setTitle("\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 Realtime \u0E08\u0E32\u0E01\u0E15\u0E25\u0E32\u0E14\u0E2B\u0E25\u0E31\u0E01\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C\u0E41\u0E2B\u0E48\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28\u0E44\u0E17\u0E22");

	JComboBox selectTimeBox = new JComboBox(timeRefreshBox);
	autoRefreshLabel.setFont(new java.awt.Font("Dialog", 1, 14));
        autoRefreshLabel.setText("Auto refresh: ");
        topPanel.setLayout(xYLayout1);

        topPanel.setBorder(BorderFactory.createEtchedBorder());
        selectStockPane.setLayout(xYLayout2);
        scrollHtmlPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        labelLast.setBackground(Color.lightGray);
        labelLast.setFont(new java.awt.Font("Dialog", 1, 14));
        labelLast.setText("Last");
        labelChange.setBackground(Color.lightGray);
        labelChange.setFont(new java.awt.Font("Dialog", 1, 14));
        labelChange.setText("Change");
        labelPerChange.setBackground(Color.lightGray);
        labelPerChange.setFont(new java.awt.Font("Dialog", 1, 14));
        labelPerChange.setText("% Change");
        labelBid.setBackground(Color.lightGray);
        labelBid.setFont(new java.awt.Font("Dialog", 1, 14));
        labelBid.setText("Bid");
        labelOffer.setBackground(Color.lightGray);
        labelOffer.setFont(new java.awt.Font("Dialog", 1, 14));
        labelOffer.setText("Offer");
        labelVolume.setBackground(Color.lightGray);
        labelVolume.setFont(new java.awt.Font("Dialog", 1, 14));
        labelVolume.setText("Volume");
        labelValue.setBackground(Color.lightGray);
        labelValue.setFont(new java.awt.Font("Dialog", 1, 14));
        labelValue.setText("Value");

        selectTimeBox.setEditable(true);
        selectTimeBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectTimeBox_actionPerformed(e);
            }
        });

        okButton.setText("OK");
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                okButton_actionPerformed(e);
            }
        });
        contentPane.add(topPanel, BorderLayout.NORTH);
        topPanel.add(autoRefreshLabel, new XYConstraints(389, 4, -1, -1));
        topPanel.add(selectTimeBox,       new XYConstraints(485, 3, 90, -1));

        contentPane.add(jTabbedPane1,  BorderLayout.CENTER);
        jTabbedPane1.add(scrollHtmlPane,   "View all Data");
        jTabbedPane1.add(selectStockPane,  "Select Data");

        selectStockPane.add(labelLast,      new XYConstraints(110, 11, -1, -1));
        selectStockPane.add(labelChange,    new XYConstraints(170, 11, -1, -1));
        selectStockPane.add(labelPerChange, new XYConstraints(237, 11, -1, -1));
	selectStockPane.add(labelBid,       new XYConstraints(330, 11, -1, -1));
        selectStockPane.add(labelOffer,     new XYConstraints(385, 11, -1, -1));
        selectStockPane.add(labelVolume,    new XYConstraints(445, 11, -1, -1));
        selectStockPane.add(labelValue,     new XYConstraints(525, 11, -1, -1));

        selectStockPane.add(delay.settrade.jTable1,        new XYConstraints(87, 40, 493, 252));

        selectStockPane.add(inputCompany3, new XYConstraints(14, 93,  61, -1));
        selectStockPane.add(inputCompany1, new XYConstraints(14, 40,  61, -1));
        selectStockPane.add(inputCompany10,new XYConstraints(14, 267, 61, -1));
        selectStockPane.add(inputCompany5, new XYConstraints(14, 142, 61, -1));
        selectStockPane.add(inputCompany8, new XYConstraints(14, 216, 61, -1));
        selectStockPane.add(inputCompany4, new XYConstraints(14, 118, 61, -1));
        selectStockPane.add(inputCompany2, new XYConstraints(14, 65,  61, -1));
        selectStockPane.add(inputCompany7, new XYConstraints(14, 191, 61, -1));
        selectStockPane.add(inputCompany9, new XYConstraints(14, 241, 61, -1));
        selectStockPane.add(inputCompany6, new XYConstraints(14, 167, 61, -1));

        selectStockPane.add(okButton,  new XYConstraints(456, 323, -1, -1));

	scrollHtmlPane.getViewport().add(delay.settrade.htmlPane, null);
    }

    //Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            System.exit(0);
        }
    }


//////////////////// Start Action ///////////////////////////
    void selectTimeBox_actionPerformed(ActionEvent e) {
	JComboBox cb = (JComboBox)e.getSource();
        String selectTime = (String)cb.getSelectedItem();

	if (selectTime == "1 Min") {
	    delay.setNewDelay(1);
	}
	else if (selectTime == "5 Min") {
	    delay.setNewDelay(5);
	}
	else if (selectTime == "10 Min") {
	    delay.setNewDelay(10);
	}
    }

    void okButton_actionPerformed(ActionEvent e) {
	String[] tmp = new String[10];
	tmp[0] = inputCompany1.getText().toUpperCase();
	tmp[1] = inputCompany2.getText().toUpperCase();
	tmp[2] = inputCompany3.getText().toUpperCase();
	tmp[3] = inputCompany4.getText().toUpperCase();
	tmp[4] = inputCompany5.getText().toUpperCase();
	tmp[5] = inputCompany6.getText().toUpperCase();
	tmp[6] = inputCompany7.getText().toUpperCase();
	tmp[7] = inputCompany8.getText().toUpperCase();
	tmp[8] = inputCompany9.getText().toUpperCase();
	tmp[9] = inputCompany10.getText().toUpperCase();

	for (int i=0; i<10; i++) delay.settrade.company[i] = tmp[i]; // send company name to find data

	delay.settrade.fillData2Table();
    } // end okButton action

} // end class Frame2
//=======================================================================//
class myDelay2 extends JPanel implements ActionListener {
    private int frameNumber = -1;
    private Timer timer;
    private int Minute; // refresh rate

    public connectWeb settrade = new connectWeb();

    public myDelay2(int min) {
	this.Minute = min; // set default refresh rate
	timer = new Timer(1000, this);  // Start timer run every 1 sec
	timer.setInitialDelay(0);
	timer.setCoalesce(true);
	timer.start();
    }

    public void setNewDelay(int newDelay) {
	Minute = newDelay;
    }

    public void actionPerformed(ActionEvent e) {
	frameNumber++;
	System.out.println(frameNumber);
	if (frameNumber == (Minute*60)) {
	    frameNumber=0;
	    System.out.println("Time Up, Restart time & Copy Data from settrade");
	    settrade.GET_HTTP(); // order connectWeb to copy data from web
	    settrade.fillData2Table();
	}
    }
}