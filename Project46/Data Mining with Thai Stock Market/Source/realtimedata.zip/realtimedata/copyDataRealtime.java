package realtimedata;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;

public class copyDataRealtime {
    private boolean packFrame = false;
    private Timer timer;
    private copyDataRealtimeFrame frame;
    private int delay = 1;
    private int count = 1;
    private int TIME;
    private boolean iKnow=true, start=true, atNoon=false;
    private String dot;

    //Construct the application
    public copyDataRealtime(int seconds) {
	frame = new copyDataRealtimeFrame();
	delay = seconds;
	timer = new Timer();
	timer.schedule(new RemindTask(),
		       0,            //initial delay
		       delay*1000);  //subsequent rate

        //Validate frames that have preset sizes
        //Pack frames that have useful preferred size info, e.g. from their layout
        if (packFrame) {
            frame.pack();
        }
        else {
            frame.validate();
        }
        //Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);
    }
//------------------------------------------------------------------------------------//
    class RemindTask extends TimerTask {
	public void run() {
	    try {
		Date date = new Date();
		frame.jLabel1.setText(date.toString());

		TIME = 1000*((int)date.toString().charAt(11)-48) +
	                100*((int)date.toString().charAt(12)-48) +
	                 10*((int)date.toString().charAt(14)-48) +
	                    ((int)date.toString().charAt(15)-48);
		count++;
		if (1230<TIME && TIME<1430 && iKnow) {
		    atNoon = true;
		    JOptionPane.showMessageDialog(null, "\u0E02\u0E13\u0E30\u0E19\u0E35\u0E49\u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E0A\u0E48\u0E27\u0E07\u0E1E\u0E31\u0E01\u0E01\u0E32\u0E23\u0E0B\u0E37\u0E49\u0E2D\u0E02\u0E32\u0E22\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E27\u0E31\u0E19\u0E04\u0E48\u0E30\n\u0E42\u0E1B\u0E23\u0E41\u0E01\u0E23\u0E21\u0E08\u0E30\u0E17\u0E33\u0E01\u0E32\u0E23\u0E14\u0E36\u0E07\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E42\u0E14\u0E22\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E40\u0E27\u0E25\u0E32 14:30 \u0E19.",":: Copy Realtime Data Error ::",JOptionPane.WARNING_MESSAGE);
		    iKnow = false;
		    frame.jLabel1.setText("\u0E1E\u0E31\u0E01\u0E01\u0E32\u0E23\u0E0B\u0E37\u0E49\u0E2D\u0E22\u0E32\u0E22\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E27\u0E31\u0E19\u0E04\u0E48\u0E30");
		    frame.jLabel2.setText("");
		} else if (1430<TIME) {
		    atNoon = false;
		}

		if (1631==TIME) {
		    JOptionPane.showMessageDialog(null, "\u0E15\u0E25\u0E32\u0E14\u0E1B\u0E34\u0E14\u0E17\u0E33\u0E01\u0E32\u0E23\u0E41\u0E25\u0E49\u0E27\u0E04\u0E48\u0E30","",JOptionPane.WARNING_MESSAGE);
		    System.exit(0);
		}
		else if (TIME<1000 || 1630<TIME) {
		    JOptionPane.showMessageDialog(null, "\u0E40\u0E27\u0E25\u0E32\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E43\u0E0A\u0E48\u0E40\u0E27\u0E25\u0E32\u0E17\u0E33\u0E01\u0E32\u0E23\u0E02\u0E2D\u0E07\u0E15\u0E25\u0E32\u0E14\u0E2B\u0E25\u0E31\u0E01\u0E17\u0E23\u0E31\u0E1E\u0E22\u0E4C\u0E04\u0E48\u0E30",":: Copy Realtime Data Error ::",JOptionPane.WARNING_MESSAGE);
		    System.exit(0);
		}

		for (int i=0; i<count; i++) {
		    dot = dot + ".";
		}

		if (!start) frame.jLabel2.setText(" Wait "+dot);
		dot="";

		if (!atNoon && start || count>59 &&
		    ( (1000<TIME&&TIME<1230) || (1430<TIME&&TIME<1630) ) &&
		     !date.toString().substring(0, 3).equals("Sat") &&
		     !date.toString().substring(0, 3).equals("Sun"))
		{
		    start = false;
		    frame.GET_HTTP(date.toString()); // copy data from set.or.th every 1 min
		    count=1;
		    dot = "";
		}
	    } catch(NullPointerException e) {
		JOptionPane.showMessageDialog(null, "Error : "+e.getMessage(),"Error",JOptionPane.WARNING_MESSAGE);
		System.exit(0);
	    }
	}
    }
//------------------------------------------------------------------------------------//
    //Main method
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
       new copyDataRealtime(1);
    }
}