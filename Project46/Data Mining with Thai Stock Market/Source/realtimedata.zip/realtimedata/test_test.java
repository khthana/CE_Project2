package realtimedata;

import java.sql.*;

public class test_test {


    public static void main(String[] args) {
	 String url = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
	 Connection DBconnection;
	 PreparedStatement insert_Data;
	 String SQL_Insert = "INSERT INTO daily_stock2(ID#, EMA_Result, Bollinger_Result, MACD_Result, MACD_Result2, RSI_Result, RSI_Result2, MFI_Result)"+
				    "VALUES(?,?,?,?,?,?,?,?)";

	 String ema[] = {"<NULL>", "Buy Signal", "Sell Signal"};
	 String macd2[] = {"<NULL>", "Buy Signal", "Sell Signal"};
	 String rsi[] = {"<NULL>", "Buy Signal", "Sell Signal"};
	 String mfi[] = {"<NULL>", "Buy Signal", "Sell Signal", "Nothing"};

	 String bollinger[] = {"<NULL>", "Bullish Trend", "Bearish Trend", "Sideway Trend"};
	 String macd[] = {"<NULL>", "Bullish Trend", "Bearish Trend", "Sideway Trend"};
	 String rsi2[] = {"<NULL>", "Overbought", "Oversold", "Sideway Trend"};

	 int ID = 1;
	 int column = 1;
	try {
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

	    DBconnection = DriverManager.getConnection(url,"","");
	    insert_Data = DBconnection.prepareStatement(SQL_Insert);

	    for (int Ema=0; Ema<3; Ema++) {
		for (int Boll=0; Boll<4; Boll++) {
		    for (int MA1=0; MA1<4; MA1++) {
			for (int MA2=0; MA2<3; MA2++) {
			    for (int Rsi1=0; Rsi1<3; Rsi1++) {
				for (int Rsi2=0; Rsi2<4; Rsi2++) {
				    for (int Mfi=0; Mfi<4; Mfi++) {

					column = 1;

					    insert_Data.setInt(column++,ID);             // ID (Primary Key)

					    insert_Data.setString(column++,ema[Ema]);
					    insert_Data.setString(column++,bollinger[Boll]);
					    insert_Data.setString(column++,macd[MA1]);
					    insert_Data.setString(column++,macd2[MA2]);
					    insert_Data.setString(column++,rsi[Rsi1]);
					    insert_Data.setString(column++,rsi2[Rsi2]);
					    insert_Data.setString(column++,mfi[Mfi]);

					    insert_Data.executeUpdate();
					    ID++;

				    }
				}
			    }
			}
		    }
		}
	    }
	}
	catch (SQLException e) {
	    System.out.println("Fuck SQL");
	    System.exit(0);
	}
	catch (java.lang.ClassNotFoundException e) {
	    System.out.println("Fuck Class");
	    System.exit(0);
	}
    } // end main
} // end class
