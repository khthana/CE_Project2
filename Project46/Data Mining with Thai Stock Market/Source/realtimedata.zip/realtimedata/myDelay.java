package realtimedata;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class myDelay extends JPanel
                     implements ActionListener {

    public int frameNumber = -1;
    Timer timer;
    public int Minute; // refresh rate

    public connectWeb settrade = new connectWeb();

    myDelay(int min) {
	this.Minute = min; // set default refresh rate
	timer = new Timer(1000, this);  // Start timer run every 1 sec
	timer.setInitialDelay(0);
        timer.setCoalesce(true);
	timer.start();
    }


    public void actionPerformed(ActionEvent e) {
	frameNumber++;
	System.out.println(frameNumber);
	if (frameNumber == (Minute*60)) {
	    frameNumber=0;
	    System.out.println("Time Up, Restart time & Copy Data from settrade");
	    settrade.GET_HTTP();
	}
    }

    public static void main(String[] args) {
	myDelay tt = new myDelay(1);
	JFrame fr = new JFrame("test");
	Container c = fr.getContentPane();
	c.setLayout(new BorderLayout());
	c.add(tt);
	fr.setSize(1,1);
	fr.setDefaultCloseOperation(3);
	fr.setVisible(true);
    }
}