package realtimedata;

import java.util.*;
public class myTime {
    public Date day = new Date();
    public myTime() {
    }
}