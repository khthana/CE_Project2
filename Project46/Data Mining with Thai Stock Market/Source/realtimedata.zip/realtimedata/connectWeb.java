package realtimedata;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class connectWeb implements HyperlinkListener {
    public JEditorPane htmlPane = new JEditorPane();

    private String tmp, text;
    private StringBuffer text2 = new StringBuffer(500000);
    public String lastPrice, change, percentChange, bid, offer, volume, value;

    private BufferedReader inputFile;
    private PrintWriter outputFile; 	// Buffer for write file
    private String outfile = "realTimeData.html";
    private URL url;

    Object[] colName = {"last Price", "change", "% change", "bid", "offer", "volume", "value"};
    Object[][] data = {
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""},
	{"", "", "", "", "", "", ""}
    };
    private TableColumn column = null;
    public JTable jTable1 = new JTable(data, colName);

    public String[] company = new String[10];

//==============================//
    public connectWeb() {
	column = jTable1.getColumnModel().getColumn(0);
	column.setPreferredWidth(70);
	column = jTable1.getColumnModel().getColumn(1);
	column.setPreferredWidth(60);
	column = jTable1.getColumnModel().getColumn(2);
	column.setPreferredWidth(70);
	column = jTable1.getColumnModel().getColumn(3);
	column.setPreferredWidth(55);
	column = jTable1.getColumnModel().getColumn(4);
	column.setPreferredWidth(55);
	column = jTable1.getColumnModel().getColumn(5);
	column.setPreferredWidth(70);
	column = jTable1.getColumnModel().getColumn(6);
	column.setPreferredWidth(70);

	jTable1.setBorder(BorderFactory.createEtchedBorder());
	jTable1.setRowHeight(25);
	htmlPane.setFont(new java.awt.Font("Dialog", 1, 14));

	GET_HTTP();
    }
//==============================//
    // use this method for get request HTTP
     public void GET_HTTP() {
	 // 1. Update Web page
	 try {
	     url = new URL("http://www.settrade.com/actions/customization/IPO/set/SET_StockQuotes.jsp?sym=all");
//	     url = new URL("http://www.ce.kmitl.ac.th");
	     htmlPane.setPage(url); // show realtime data //
	     htmlPane.setEditable(false);
	     htmlPane.addHyperlinkListener(this);

	 } catch(IOException e) {}

	 // 2. Start Copy Data to file
	 System.out.println("Start to copy file");
	     try {
		 outputFile = new PrintWriter(new FileWriter(outfile));

		 InputStream html = url.openStream();

		 int c  = 0;
		 c = html.read();

		 for (int i=0; i<500000; i++) {
		     if (c!=-1) {
			 outputFile.print((char)c);
		     }
		     c = html.read();
		 }
	      } catch (MalformedURLException e) {} catch (IOException e) {}
	System.out.println("Copy Finish");

	System.out.println("Start to read File");
	      try {
		  inputFile = new BufferedReader(new FileReader(outfile));
		  tmp = "";
		  tmp = inputFile.readLine();	// Readline
		  while (tmp != null) {
		  //    text = text + tmp;
		      text2.append(tmp);
		      tmp  = inputFile.readLine(); // Readline
		  }
		  text = text2.substring(0, text2.length());
		  } catch (IOException e) {}
	System.out.println("Read File Finish");
     } // end method

     public void fillData2Table() {
	 System.out.println("Update data to Table");
	  for (int i=0; i<10; i++) {
	      if (company[i] != null) {
		 find(company[i]);  // Find data from file that was copied
		 jTable1.setValueAt(lastPrice,i,0);
		 jTable1.setValueAt(change,   i,1);
		 jTable1.setValueAt(percentChange,i,2);
		 jTable1.setValueAt(bid,   i,3);
		 jTable1.setValueAt(offer, i,4);
		 jTable1.setValueAt(volume,i,5);
		 jTable1.setValueAt(value, i,6);
		 lastPrice = "";
		 change = "";
		 percentChange = "";
		 bid = "";
		 offer = "";
		 volume = "";
		 value = "";
	      }
	  }
     } // end fill data

     public void find(String companyName) {
	     //// Start to find String ////
	     int pt = text.lastIndexOf(companyName);  // if indexOf == -1 , not found
		     if (pt == -1) {
			     lastPrice = "";
			     change = "";
			     percentChange = "";
			     bid = "";
			     offer = "";
			     volume = "";
			     value = "";
			     JOptionPane.showMessageDialog(null, "Company Not Found","Error",JOptionPane.WARNING_MESSAGE);
		     } else { // start to find
	     try {
		     tmp = text.substring(pt, pt+350); // Select last price

       // 62 = >  , 60 = <
	       //=== last price =========================
		     int cl = text.indexOf(62, pt+15);
		     int op = text.indexOf(60, cl);

		     lastPrice = text.substring(cl+1, op);

	       //=== change =============================
		      cl = text.indexOf(62, pt+90);
		      op = text.indexOf(60, cl);

		     change = text.substring(cl+1, op);

	       //=== % change =============================
		      cl = text.indexOf(62, pt+160);
		      op = text.indexOf(60, cl);

		     percentChange = text.substring(cl+1, op);

	       //=== bid =============================
		      cl = text.indexOf(62, pt+206);
		      op = text.indexOf(60, cl);

		     bid = text.substring(cl+1, op);

	       //=== offer =============================
		      cl = text.indexOf(62, pt+245);
		      op = text.indexOf(60, cl);

		     offer = text.substring(cl+1, op);

	       //=== volume =============================
		      cl = text.indexOf(62, pt+285);
		      op = text.indexOf(60, cl);

		     volume = text.substring(cl+1, op);
		     System.out.println(volume);

	       //=== value =============================
		      cl = text.indexOf(62, pt+325);
		      op = text.indexOf(60, cl);

		     value = text.substring(cl+1, op);
	     } catch (StringIndexOutOfBoundsException e) {}
		     } // end else
     } // end find

     public void hyperlinkUpdate(HyperlinkEvent event) {
	   if (event.getEventType()==HyperlinkEvent.EventType.ACTIVATED) {
		   try {
			   htmlPane.setPage(event.getURL());
		   } catch(IOException e) {}
	   }
     }
} // end class