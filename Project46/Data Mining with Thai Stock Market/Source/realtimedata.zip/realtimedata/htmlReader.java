package realtimedata;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

public class htmlReader {
//	private BufferedReader inputFile;  		// Buffer for read file
	private String tmp, text;
	public	String lastPrice, change, percentChange, bid, offer, volume, value;

	private connectWeb settrade = new connectWeb();

	public htmlReader() {
		//// Open File ////
//		try {
//			inputFile     = new BufferedReader(new FileReader("data_.html"));
//			tmp = "";
//			tmp = inputFile.readLine();	// Readline
//			while (tmp != null) {
//				text = text + tmp;
//				tmp  = inputFile.readLine(); // Readline
//			}
//		} catch (IOException e) {}
	//    text = settrade.outputFile;
	} // end constructor

	public void refreahData() {
//		try {
//			inputFile     = new BufferedReader(new FileReader("data_.html"));
//			tmp = "";
//			tmp = inputFile.readLine();	// Readline
//			while (tmp != null) {
//				text = text + tmp;
//				tmp  = inputFile.readLine(); // Readline
//			}
//		} catch (IOException e) {}
	//    text = settrade.outputFile;
	}

	public void find(String companyName) {
		//// Start to find String ////
		int pt = text.lastIndexOf(companyName);  // if indexOf == -1 , not found
			if (pt == -1) {
				lastPrice = "-";
				change = "-";
				percentChange = "-";
				bid = "-";
				offer = "-";
				volume = "-";
				value = "-";
				JOptionPane.showMessageDialog(null, "Company Not Found","Error",JOptionPane.WARNING_MESSAGE);
			} else { // start to find
		try {
			tmp = text.substring(pt, pt+350); // Select last price

	  // 62 = >  , 60 = <
		  //=== last price =========================
			int cl = text.indexOf(62, pt+15);
			int op = text.indexOf(60, cl);

			lastPrice = text.substring(cl+1, op);

		  //=== change =============================
			 cl = text.indexOf(62, pt+90);
			 op = text.indexOf(60, cl);

			change = text.substring(cl+1, op);

		  //=== % change =============================
			 cl = text.indexOf(62, pt+160);
			 op = text.indexOf(60, cl);

			percentChange = text.substring(cl+1, op);

		  //=== bid =============================
			 cl = text.indexOf(62, pt+206);
			 op = text.indexOf(60, cl);

			bid = text.substring(cl+1, op);

		  //=== offer =============================
			 cl = text.indexOf(62, pt+245);
			 op = text.indexOf(60, cl);

			offer = text.substring(cl+1, op);

		  //=== volume =============================
			 cl = text.indexOf(62, pt+285);
			 op = text.indexOf(60, cl);

			volume = text.substring(cl+1, op);
			System.out.println(volume);

		  //=== value =============================
			 cl = text.indexOf(62, pt+325);
			 op = text.indexOf(60, cl);

			value = text.substring(cl+1, op);
		} catch (StringIndexOutOfBoundsException e) {}
			} // end else
	}
//===============================================//
	public static void main(String[] args) {
		htmlReader tmpp = new htmlReader();

		tmpp.find("PTT");
		System.out.println();
		tmpp.find("SHIN");
		System.out.println();
		tmpp.find("GRAMMY");
		System.out.println();
		tmpp.find("SCB");
		System.out.println();
		tmpp.find("ITV");
		System.out.println();
		tmpp.find("CP7-11");
		System.out.println();
	}
} // end class