package realtimedata;

public class Test {
    Shit tt = new Shit();
    public Test() {
    }
    public static void main(String[] args) {
        Test test1 = new Test();
    }
}