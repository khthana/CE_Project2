package realtimedata;

import java.net.*;
import java.io.*;
import java.util.*;

public class copyRealTimeData {
      private PrintWriter outputFile; 	// Buffer for write file
      private char output;
      private String outfile = "realTimeData.html";

    // use this method for get request HTTP
    public void GET_HTTP() {
	    try {	// Open File
		    outputFile = new PrintWriter(new FileWriter(outfile));
	    }
	    catch (IOException e) {System.out.println("File error " + e);}

	    try {
		URL url = new URL("http://www.settrade.com/actions/customization/IPO/set/SET_StockQuotes.jsp?sym=all");
		InputStream html = url.openStream();

		  int c  = 0;
	       c = html.read();

		     for (double i=0; i<500000; i++) {
				    output = (char)c;
				    if (c==10) outputFile.println();  // new line
			    if (c!=-1) outputFile.print(output);
				    c = html.read();
		   }
   } catch (MalformedURLException e) {System.out.println("HTTP error "+e);}
     catch (IOException e) {}

	    outputFile.close();
	} // end method
}