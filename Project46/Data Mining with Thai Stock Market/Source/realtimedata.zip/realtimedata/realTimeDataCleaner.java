package realtimedata;


//1. import SQL lib
import java.sql.*;
import javax.swing.JOptionPane;

public class realTimeDataCleaner {

    //2. Defind variables
    private String url = "jdbc:odbc:DataMining"; // DataMining is create by admintool/ODBC
    private Connection DBconnection;
    private Statement selectCompany, selectDailyData;
    private PreparedStatement insert_Data;
    private String SQL_Insert = "INSERT INTO realTime_Technical_Analysis(ID#, Company, Price, Volume, PriceUpDown, VolumeUpDown, EMA5, EMA20, EMA_Result, SMA20, StdDev, Bollinger_Result) "+
				" VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

    private ResultSet resultSet_CompanyName;  // Every company. = { symbol }
    private ResultSet resultSet_EverydayData; // Everyday data. = { dateTime, price, volume, value }
    private String currentCompany;

    private int MAX_DAY = 900; // max rows of record for each commpany.

    private double dailyPrice[]  = new double[MAX_DAY];
    private double dailyVolume[] = new double[MAX_DAY];
    private double dailyAccVolume[] = new double[MAX_DAY]; // total volume @ any time

    private double multiplier[] = {0.333, 0.200, 0.154, 0.095, 0.074,0.065, 0.049, 0.0198, 0.017};// use in EMA
    private double prev_EMA = 0.0;

    private double memory_EMA5[]  = new double[MAX_DAY];
    private double memory_EMA20[] = new double[MAX_DAY];
    private double memory_SMA[]   = new double[MAX_DAY];
    private double memory_StandardDeviation[] = new double[MAX_DAY];

    private int numberDayTrade = 0;


//======================================================================//
//             Start :: Constructure                                    //
//======================================================================//
    public realTimeDataCleaner() {
	int day_=1;  // munber of row per company
	int ID=1; // total row calculate ( ID# )

	//3. Load driver
	try {
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

	    // (1) Query all company name
	    queryCompanyName();

	    // (2) Start calculate technical analysis
	    while (!resultSet_CompanyName.isAfterLast()) {

		currentCompany = resultSet_CompanyName.getString(1);
		resultSet_CompanyName.next();
		System.out.println();
		System.out.println("Company : " + currentCompany);

		// (2.1) Find each company data
		queryDailyData();

		// Find Volume @ period

		dailyVolume[0] = dailyAccVolume[0];
		for (int i=1; i<numberDayTrade; i++) {
		    dailyVolume[i] = dailyAccVolume[i] - dailyAccVolume[i-1];
		}

		/* Start to find all values by Technical Analysis
		(2.1.2) call EMA()
		(2.1.3) call Trin()
		*/
		System.out.println(" :: Technical Analysis ::");
		System.out.println("     EMA 5");
		day_=1;
		for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA5[day_-1]=EMA(5,day_);
		    day_++;
		}
		day_=1;

		System.out.println("     EMA 20");
		for (int i=0; i<numberDayTrade; i++) {
		    memory_EMA20[day_-1]=EMA(20,day_);
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//
		System.out.println("     SMA 20");
		for (int i=0; i<numberDayTrade; i++) {
		    memory_SMA[day_-1]=SMA(20,day_);  // save SMA20 for Bollinger Bands
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//
		System.out.println("     Bollinger Bands");
		for (int i=0; i<numberDayTrade; i++) {
		    memory_StandardDeviation[day_-1] = BollingerBands(20, day_); // calculate Bollinger Bands
		    day_++;
		}
		day_=1;
	//-------------------------------------------------------------------//

		//(2.2) Insert these data into table "daily_Technical_Analysis"
		int column = 1;

		for (int i=0; i<numberDayTrade; i++) {
		    insert_Data.setInt(column++,ID);             // ID (Primary Key)

		    insert_Data.setString(column++,currentCompany); // Company

		    insert_Data.setDouble(column++,dailyPrice[i]);
		    insert_Data.setDouble(column++,dailyAccVolume[i]);
		    insert_Data.setString(column++,checkUpLow(i));
		    insert_Data.setString(column++,checkVolumeUpLow(i));

		    // Exponential Moving Average
		    insert_Data.setDouble(column++,memory_EMA5[i]);
		    insert_Data.setDouble(column++,memory_EMA20[i]);
		    insert_Data.setString(column++,checkEMA(i));

		    // Simple Moving Average
		    insert_Data.setDouble(column++,memory_SMA[i]);

		    // Bollinger Bands
		    insert_Data.setDouble(column++,memory_StandardDeviation[i]);
		    insert_Data.setString(column++,checkBollinger(i));

		    insert_Data.executeUpdate();
		    ID++;
		    column = 1;
		}
//*/
		numberDayTrade=0;
		} // until all company
	} catch (java.lang.ClassNotFoundException e) {System.out.println("Driver Error :" + e);}
	  catch (SQLException e) {System.out.println("SQL Error :" + e);}
    } // end constructure

//=====================================================================================//
    public void queryCompanyName() {
	// sql is used for find all n_security (company name)
	System.out.println("Query all companies' name");
	String sql = "SELECT MIN(symbol) "+
		     "FROM realTimeData "+
		     "GROUP BY symbol "+
		     "ORDER BY symbol;";
	try {
	    DBconnection = DriverManager.getConnection(url,"","");
	    selectCompany = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
	    resultSet_CompanyName = selectCompany.executeQuery(sql);
	    resultSet_CompanyName.first();

	    insert_Data = DBconnection.prepareStatement(SQL_Insert);
	} catch (SQLException e) {}
    }
//=====================================================================================//
    public void queryDailyData() {
	System.out.println(" Query company " + currentCompany + " data");
	String sql_closePrice = "SELECT nowPrice, volume "+
				 "FROM realTimeData "+
				 "WHERE symbol ='"+currentCompany+"' "+
				 "ORDER BY dateTime;";
	try {
	    selectDailyData = DBconnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
		    ResultSet.CONCUR_READ_ONLY);
	    resultSet_EverydayData = selectDailyData.executeQuery(sql_closePrice);
	    resultSet_EverydayData.first();

	    while (!resultSet_EverydayData.isAfterLast()) {
		dailyPrice[numberDayTrade]     = resultSet_EverydayData.getDouble(1);
		dailyAccVolume[numberDayTrade] = resultSet_EverydayData.getDouble(2);
		resultSet_EverydayData.next();
		numberDayTrade++;
	    }
	    resultSet_EverydayData.first();
	} catch (SQLException e) {System.out.println(e.getMessage());}
    }
//=====================================================================================//
    public double EMA(int periods, int day) {
	double SUM = 0.0;
	if (day < periods) {
	    SUM = dailyPrice[day-1];
	    return SUM;
	}
	else if (day == periods) { // first EMA is equal SMA
		for (int i=0; i<periods; i++) {
		    SUM = SUM + dailyPrice[i];
		}
		SUM = SUM / periods; // find mean.

	    prev_EMA = SUM;
	    return SUM;
	}
	else {
	    int p=0;
	    double tmp=0.0;

	    switch (periods) {
		case 5   : p=0; break;
		case 9   : p=1; break;
		case 12  : p=2; break;
		case 20  : p=3; break;
		case 26  : p=4; break;
		case 30  : p=4; break;
		case 40  : p=5; break;
		case 100 : p=4; break;
		case 120 : p=6; break;
	    }
		double closePrice = dailyPrice[day-1];
		tmp = (((closePrice - prev_EMA) * multiplier[p]) + prev_EMA);
		prev_EMA = tmp; // save last value
	    return tmp;
	}
    }
//=====================================================================================//
    public double SMA(int periods, int day) {
	double SUM = 0.0;
	if (day < periods) {
	    SUM = dailyPrice[day-1];
	    return SUM;
	} else {
	    for (int i=(day-periods); i<day; i++) {
		SUM = SUM + dailyPrice[i];
	    }
	    SUM = SUM / periods; // find mean.

	return SUM;
	}
    }
//=====================================================================================//
    public double BollingerBands(int periods, int day) { // return Standard Deviation value //
	double SUM = 0.0;
	if (day < periods) {
	    return 4.0; // random Standard Deviation //
	} else {
	    // (1) Find Sum of (deviation values)^2 => E(close price - SMA20)^2
	    for (int i=(day-periods); i<day; i++) {
		SUM = SUM + Math.pow((dailyPrice[i] - memory_SMA[day-1]),2);
	    }
	    // (2) Devide by periods
	    SUM = SUM / periods;
	    // (3) Find square root
	    SUM = Math.sqrt(SUM);
	return SUM;
	}
    }
//=====================================================================================//
    public String checkUpLow(int day) {
	if (dailyPrice[day+1] == dailyPrice[day]) return "Price Stable";
	else if (dailyPrice[day+1] > dailyPrice[day]) return "Price Increase";
	else return "Price Decrease";
    }
//=====================================================================================//
    public String checkVolumeUpLow(int day) {
	if (dailyVolume[day+1] == dailyVolume[day]) return "Volume Stable";
	else if (dailyVolume[day+1] > dailyVolume[day]) return "Volume Increase";
	else return "Volume Decrease";
    }

//=====================================================================================//
//        Start to Predict using Technical Analysis                                    //
//=====================================================================================//
    public String checkEMA(int day) {
	if (memory_EMA5[day] == memory_EMA20[day] ||
	    memory_EMA5[day] >  memory_EMA20[day]) return "Buy Signal";
	else return "Sell Signal";
    }
//=====================================================================================//
    public String checkBollinger(int day) {
	  // Price line rise over upper bands
	  if (dailyPrice[day] > (memory_SMA[day]+(2*memory_StandardDeviation[day])) &&
	      ((day+2)<numberDayTrade))
	  {
	      if (dailyPrice[day+1] > (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] > (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
		  return "Bullish Trend";
	      }
	      else
	      if (dailyPrice[day+1] > (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] < (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
		  return "Bearish Trend";
	      }
	      else
	      if (dailyPrice[day+1] < (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] < (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
		  return "Bearish Trend";
	      }
	      else
	      if (dailyPrice[day+1] < (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] > (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
		  return "Bullish Trend";
	      }
	      else
	      if (dailyPrice[day+1] == (memory_SMA[day+1]+(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] == (memory_SMA[day+2]+(2*memory_StandardDeviation[day+2])))) {
		  return "Sideway Trend";
	      }
	      else return "Sideway Trend";
	  }

	  // Price line drop under lower bands
	  else
	      if (dailyPrice[day] < (memory_SMA[day]-(2*memory_StandardDeviation[day])) &&
	      ((day+2)<numberDayTrade))
	  {
	      if (dailyPrice[day+1] < (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] < (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
		  return "Bearish Trend";
	      }
	      else
	      if (dailyPrice[day+1] < (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] > (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
		  return "Bullish Trend";
	      }
	      else
	      if (dailyPrice[day+1] > (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] > (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
		  return "Bullish Trend";
	      }
	      else
	      if (dailyPrice[day+1] > (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] < (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
		  return "Bearish Trend";
	      }
	      else
	      if (dailyPrice[day+1] == (memory_SMA[day+1]-(2*memory_StandardDeviation[day+1])) &&
		 (dailyPrice[day+2] == (memory_SMA[day+2]-(2*memory_StandardDeviation[day+2])))) {
		  return "Sideway Trend";
	      }
	      else return "Sideway Trend";
	  }
	  // Price line swing within upper bands and lower bands,
	  // so determine the Price line and middle bands instead.
	  else
	  {
	      if ((dailyPrice[day] == memory_SMA[day]) && ((day+2)<numberDayTrade) )
	      {
		  if (day>1                                  &&
		     (dailyPrice[day-1] < memory_SMA[day-1]) &&
		     ((dailyPrice[day+1] > memory_SMA[day+1])||
		      (dailyPrice[day+2] > memory_SMA[day+2])))
		  {
		      return "Bullish Trend";
		  }
		  else
		      if (day>1                                  &&
			 (dailyPrice[day-1] > memory_SMA[day-1]) &&
			 ((dailyPrice[day+1] < memory_SMA[day+1])||
			  (dailyPrice[day+2] < memory_SMA[day+2])))
		      {
			  return "Bearish Trend";
		      }
		  else return "Sideway Trend";
	      }
	      else
		  // Price line rise over SMA20 line (Middle bands)
		  if ((dailyPrice[day] > memory_SMA[day]) && ((day+2)<numberDayTrade) )
		  {
		      if ((dailyPrice[day+1] > memory_SMA[day+1]) &&
			  (dailyPrice[day+2] > memory_SMA[day+2]))
		      {
			  return "Bullish Trend";
		      }
		      else
			  if ((dailyPrice[day+1] > memory_SMA[day+1]) &&
			      (dailyPrice[day+2] < memory_SMA[day+2]))
			  {
			      return "Bearish Trend";
			  }
		      else
			  if ((dailyPrice[day+1] < memory_SMA[day+1]) &&
			      (dailyPrice[day+2] < memory_SMA[day+2]))
			  {
			      return "Bearish Trend";
			  }
		      else return "Sideway Trend";
		  }
		  else
		      // Price line drop under SMA20 line (Middle bands)
		      if ((dailyPrice[day] < memory_SMA[day]) && ((day+2)<numberDayTrade) )
		      {
			  if ((dailyPrice[day+1] < memory_SMA[day+1]) &&
			      (dailyPrice[day+2] < memory_SMA[day+2]))
			  {
			      return "Bearish Trend";
			  }
			  else
			      if ((dailyPrice[day+1] < memory_SMA[day+1]) &&
				  (dailyPrice[day+2] > memory_SMA[day+2]))
			      {
				  return "Bullish Trend";
			      }
			  else
			      if ((dailyPrice[day+1] > memory_SMA[day+1]) &&
				  (dailyPrice[day+2] > memory_SMA[day+2]))
			      {
				  return "Bullish Trend";
			      }
			  else return "Sideway Trend";
		      }
		  else return "Sideway Trend";
	  }
      }
//=====================================================================================//

    public static void main(String[] args) {
        realTimeDataCleaner realTimeDataCleaner1 = new realTimeDataCleaner();
    }
}