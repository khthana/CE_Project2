package realtimedata;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.*;
import java.io.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame1 extends JFrame implements HyperlinkListener {
                                              //ActionListener{
  private JPanel contentPane;
  private BorderLayout borderLayout1 = new BorderLayout();
  private JTabbedPane mainPane = new JTabbedPane();
  private JPanel selectDataPanel = new JPanel();
    private JEditorPane htmlPane;
    private JScrollPane scrollPane1 = new JScrollPane();
    private BorderLayout borderLayout2 = new BorderLayout();// = new JEditorPane();

  //Construct the frame
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
        htmlPane = new JEditorPane("http://www.settrade.com/actions/customization/IPO/set/SET_StockQuotes.jsp?sym=all");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	htmlPane.addHyperlinkListener(this);
    setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("logo.jpg")));
    this.setResizable(false);
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(700, 600));         ////// Size ///////
    this.setTitle("Realtime Data from Set.or.th"); //////////// Title /////////////


    selectDataPanel.setLayout(borderLayout2);
        htmlPane.setEditable(false);
        htmlPane.addHyperlinkListener(this);
        htmlPane.setEditable(false);
        htmlPane.addHyperlinkListener(this);
        contentPane.add(mainPane,  BorderLayout.CENTER);
    mainPane.add(selectDataPanel,   "Selected Data");
        mainPane.add(scrollPane1,  "scrollPane1");
        scrollPane1.add(htmlPane, null);

  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  public void hyperlinkUpdate(HyperlinkEvent event) {
	  if (event.getEventType()==HyperlinkEvent.EventType.ACTIVATED) {
		  try {
			  htmlPane.setPage(event.getURL());
		  }
		  catch(IOException e) {}
	  }
  } // end hyperlinkUpdate

} // end class