// PSNR_v_1_1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "PSNR_v_1_1.h"
#include "PSNR_v_1_1Dlg.h"
#include "atlimage.h"
#include "afxstr.h"
#include <math.h> 
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
BYTE or[256][256];
BYTE wm[256][256];

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CPSNR_v_1_1Dlg dialog



CPSNR_v_1_1Dlg::CPSNR_v_1_1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPSNR_v_1_1Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPSNR_v_1_1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX,IDC_psnr,str1);
	DDX_Text(pDX,IDC_MSE,str2);
}

BEGIN_MESSAGE_MAP(CPSNR_v_1_1Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
END_MESSAGE_MAP()


// CPSNR_v_1_1Dlg message handlers

BOOL CPSNR_v_1_1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPSNR_v_1_1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPSNR_v_1_1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPSNR_v_1_1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CPSNR_v_1_1Dlg::OnBnClickedButton1()
{
CString strFileName;
	CFileDialog fd(TRUE, NULL, NULL, NULL, "BMP File (*.bmp) |*.bmp|All File (*.*)|*.*||");
	if(fd.DoModal() == IDCANCEL)
		return;	
	strFileName = fd.GetPathName();
	if(fd.GetFileExt() == "")
		strFileName += ".bmp";
	
		
	CImage imageIN;
	imageIN.Create(256,256,24);
	imageIN.Destroy();
	HRESULT hresult = imageIN.Load(strFileName);
	BYTE *PointerIM;
	for (int u = 0;u<256;u++){
			for(int x = 0;x<256;x++){
				PointerIM =(BYTE*)imageIN.GetPixelAddress(u,x);
				or[x][u] = PointerIM[0];
				
			}
		}
}

void CPSNR_v_1_1Dlg::OnBnClickedButton2()
{

	CString strFileName;
	CFileDialog fd(TRUE, NULL, NULL, NULL, "BMP File (*.bmp) |*.bmp|All File (*.*)|*.*||");
	if(fd.DoModal() == IDCANCEL)
		return;	
	strFileName = fd.GetPathName();
	if(fd.GetFileExt() == "")
		strFileName += ".bmp";
	
		
	CImage imageIN;
	imageIN.Create(256,256,24);
	imageIN.Destroy();
	HRESULT hresult = imageIN.Load(strFileName);
	BYTE *PointerIM;
	for (int u = 0;u<256;u++){
			for(int x = 0;x<256;x++){
				PointerIM =(BYTE*)imageIN.GetPixelAddress(u,x);
				wm[x][u] = PointerIM[0];
				
			}
		}}

void CPSNR_v_1_1Dlg::OnBnClickedButton3()
{
	double buff=0;
	for(int i =0;i<256;i++){
		for(int j =0;j<256;j++){
			buff = buff+pow((or[i][j]-wm[i][j]),2);
		}
	}
	buff = buff/65536;	
	CString mse;
	mse.Format(" %f",buff);
	str2 = mse;
	UpdateData(FALSE);
	buff = 10*log10((65025/buff));
	
	
	
	
	CString psnr;
	psnr.Format(" %f",buff);
	str1 = psnr;
	UpdateData(FALSE);}
