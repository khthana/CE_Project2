// watermark_version_1_1.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "watermark_version_1_1.h"
#include "watermark_version_1_1Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cwatermark_version_1_1App

BEGIN_MESSAGE_MAP(Cwatermark_version_1_1App, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


// Cwatermark_version_1_1App construction

Cwatermark_version_1_1App::Cwatermark_version_1_1App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only Cwatermark_version_1_1App object

Cwatermark_version_1_1App theApp;


// Cwatermark_version_1_1App initialization

BOOL Cwatermark_version_1_1App::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();


	Cwatermark_version_1_1Dlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
