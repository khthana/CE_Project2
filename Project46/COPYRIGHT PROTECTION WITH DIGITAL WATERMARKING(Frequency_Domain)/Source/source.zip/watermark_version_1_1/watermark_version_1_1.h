// watermark_version_1_1.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// Cwatermark_version_1_1App:
// See watermark_version_1_1.cpp for the implementation of this class
//

class Cwatermark_version_1_1App : public CWinApp
{
public:
	Cwatermark_version_1_1App();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Cwatermark_version_1_1App theApp;