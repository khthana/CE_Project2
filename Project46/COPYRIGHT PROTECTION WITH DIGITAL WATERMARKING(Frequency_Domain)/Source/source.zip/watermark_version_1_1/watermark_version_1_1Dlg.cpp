// watermark_version_1_1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "watermark_version_1_1.h"
#include "watermark_version_1_1Dlg.h"
#include "atlimage.h"
#include "afxstr.h"
#include <math.h>
#define Pi 3.141592653589 
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
CString strKEY;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// Cwatermark_version_1_1Dlg dialog



Cwatermark_version_1_1Dlg::Cwatermark_version_1_1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(Cwatermark_version_1_1Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Cwatermark_version_1_1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(Cwatermark_version_1_1Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
END_MESSAGE_MAP()


// Cwatermark_version_1_1Dlg message handlers

BOOL Cwatermark_version_1_1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void Cwatermark_version_1_1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Cwatermark_version_1_1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Cwatermark_version_1_1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void Cwatermark_version_1_1Dlg::OnBnClickedButton1()
{
//CString strFileName;
		CDC mem_bg;
		HBITMAP H_bg;

	CFileDialog fd(TRUE, NULL, NULL, NULL, "BMP File (*.bmp) |*.bmp|All File (*.*)|*.*||");
	if(fd.DoModal() == IDCANCEL)
		return;	
	strKEY = fd.GetPathName();
	if(fd.GetFileExt() == "")
		strKEY += ".bmp";
	
	HWND hwndStill = NULL;
	GetDlgItem(IDC_SK,&hwndStill);
	RECT rc;
	::GetWindowRect(hwndStill, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	H_bg = (HBITMAP)LoadImage(NULL,strKEY,
					IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);

	CWnd *hwnd = GetDlgItem(IDC_SK);
	CDC *pdc;
	pdc = GetDC();
	mem_bg.CreateCompatibleDC(pdc);
	mem_bg.SelectObject(H_bg);
	ReleaseDC(pdc);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_bg,0,0,SRCCOPY);
}

void Cwatermark_version_1_1Dlg::OnBnClickedButton2()
{
CString strFileName;
	CDC mem_bg;
	HBITMAP H_bg;
	CFileDialog fd(TRUE, NULL, NULL, NULL, "BMP File (*.bmp) |*.bmp|All File (*.*)|*.*||");
	if(fd.DoModal() == IDCANCEL)
		return;	
	strFileName = fd.GetPathName();
	if(fd.GetFileExt() == "")
		strFileName += ".bmp";
	HWND hwndStill = NULL;
	GetDlgItem(SHOW_IN,&hwndStill);
	RECT rc;
	::GetWindowRect(hwndStill, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	H_bg = (HBITMAP)LoadImage(NULL,strFileName,
	IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	CWnd *hwnd = GetDlgItem(SHOW_IN);
	CDC *pdc;
	pdc = GetDC();
	mem_bg.CreateCompatibleDC(pdc);
	mem_bg.SelectObject(H_bg);
	ReleaseDC(pdc);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_bg,0,0,SRCCOPY);
//=========================== END SHOW IMAGE =====================//
//=========================== LOAD KEY ===========================//
	CImage KEY;
	KEY.Create(64,64,8);
	KEY.Destroy();
	//CString strKEY = "k96.bmp";
	CString strKEY1 = "k96re.bmp";
	HRESULT hresultkey = KEY.Load(strKEY);
	BYTE KEYX[64][64];
	BYTE *PointerIM;
	double alpha = 0.8;
	for (int ii = 0; ii < 64; ii++) {
		for (int jj = 0; jj < 64; jj++) {
			PointerIM =(BYTE*)KEY.GetPixelAddress(ii,jj);
			KEYX[ii][jj] = PointerIM[0];
			PointerIM[0] = KEYX[ii][jj];
		}
	}
	HRESULT hresultS = KEY.Save(strKEY1);
/*====================================Zig zag    =============================*/
	BYTE z[4096];
	/*int count =0;
	for(int i =0;i<64;i++){
		for(int j = 0;j<64;j++){
		z[count]=KEYX[i][j];
		count = count+1;
		}
	}*/
	int count = 0;
	for (int i = 0;i<64;i++){
          for (int j = 0;j<i+1;j++){
			   if ((i%2) != 0){
                    z[count] = KEYX[j][i-j];
                    count = count + 1;
               }
			   else{
                    
                    z[count] = KEYX[i-j][j];
                    count = count + 1;
			   }
		   }
	}
     int run;
	 for(int i = 1;i < 64;i++){
           run = 63;
           for(int j = i;j<64;j++){
			   if ((i%2) != 0){
                    z[count] = KEYX[run][j];
                    run = run - 1;
                   
                    count = count + 1;
			   }
				else{
                    z[count] = KEYX[j][run];
                    run = run -1;
                   
                    count = count +1;
				}
		   }
	 }
/*====================================Zig zag end=============================*/
//int i =0;
/*===============================invers zigzag=======================*/
/* 
	// function y = izig(z)
//n = length(z);
//y = zeros(n^0.5,n^0.5);
	//double y[4096];
	count = 4095;
	for(int i = 0;i < 64;i++){
          
		for(int j = 0;j<i;j++){
			if ((i%2)!=0){
                     dct[j][i-j] = z[count] ;
                    count = count - 1;
			}
			else{
                    
                    dct[i-j][j] = z[count]  ;
                    count = count -1;
                    
			 }
		}
	}
       
        
//==========================================
 
	for(int i = 1;i < 64;i++){
           run = 63;
           for(int j = i;j < 64;j++){
			   if ((i%2) != 0){
                    dct[run][j] = z[count];
                    run = run -1;
                   
                    count = count - 1;
			   } 
			   else{
                   dct[j][run] = z[count];
                    run = run -1;
                   
                    count = count -1;
			   }  
		   }
	}	     
  */     
 /*==================================END invers zigzag=================*/


//=========================== END LOAD KEY =======================//
//=========================== LOAD IMAGE =========================//
	CImage imageIN;
	imageIN.Create(256,256,24);
	imageIN.Destroy();
	HRESULT hresult = imageIN.Load(strFileName);
	CString str = "WaterMarked.bmp";
	//BYTE *PointerIM;
	float data[256][256];
	double dct[256][256];
//=========================== END LOAD IMAGE =====================//
	for (int ii = 0; ii < 256; ii++) {
		for (int jj = 0; jj < 256; jj++) {
			PointerIM =(BYTE*)imageIN.GetPixelAddress(ii,jj);
			data[ii][jj] = PointerIM[0];
		}
	}
//=========================== DCT 8X8 ============================//
	double cu,cv,temp1=0,temp2=0,temp3=0,temp4=0,temp5=0,temp6=0,temp7=0,temp8=0;
	int pointy = 0;
	for (int i=0;i<32;i++){
		for (int j=0;j<4;j++){
			pointy=64*j;
			for (int u=0;u<8;u++){
				for (int v=0;v<8;v++){
					for (int x=0;x<8;x++){
						for (int y=0;y<8;y++){
							
							temp1 = temp1+((data[i*8+x][pointy+y])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp2 = temp2+((data[i*8+x][pointy+y+8])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp3 = temp3+((data[i*8+x][pointy+y+16])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp4 = temp4+((data[i*8+x][pointy+y+24])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp5 = temp5+((data[i*8+x][pointy+y+32])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp6 = temp6+((data[i*8+x][pointy+y+40])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp7 = temp7+((data[i*8+x][pointy+y+48])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp8 = temp8+((data[i*8+x][pointy+y+56])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
						}
					}

					if (u==0){cu=0.35355339;}else{cu=0.5;}
					if (v==0){cv=0.35355339;}else{cv=0.5;}
					dct[i*8+u][pointy+v] = temp1*cu*cv;
					dct[i*8+u][pointy+v+8] = temp2*cu*cv;
					dct[i*8+u][pointy+v+16] = temp3*cu*cv;
					dct[i*8+u][pointy+v+24] = temp4*cu*cv;
					dct[i*8+u][pointy+v+32] = temp5*cu*cv;
					dct[i*8+u][pointy+v+40] = temp6*cu*cv;
					dct[i*8+u][pointy+v+48] = temp7*cu*cv;
					dct[i*8+u][pointy+v+56] = temp8*cu*cv;
					temp1 = 0;
					temp2 = 0;
					temp3 = 0;
					temp4 = 0;
					temp5 = 0;
					temp6 = 0;
					temp7 = 0;
					temp8 = 0;
				}
			}
			
		
		}
	}
//============================ END DCT 8X8 =======================//
//============================ MARK IMAGE ========================//
		count = 0;
/*		
		dct[0][3] = dct[0][4]*(1+alpha*z[count]);count++;);
		dct[1][2] = dct[1][3]*(1+alpha*z[count]);count++;);
		dct[2][1] = dct[2][3]*(1+alpha*z[count]);count++;);
		dct[3][0] = dct[2][2]*(1+alpha*z[count]);count++;);
		
		dct[4][0] = dct[3][1]*(1+alpha*z[count]);count++;);
		
		dct[3][1] = dct[4][0]*(1+alpha*z[count]);count++;);
		dct[2][2] = dct[3][2]*(1+alpha*z[count]);count++;);
		dct[1][3] = dct[1][4]*(1+alpha*z[count]);count++;);
		dct[0][4] = dct[0][5]*(1+alpha*z[count]);count++;);
*/
	
//============================variance===========================//

alpha = 0.05;
//============================varaince===========================//
	for (int i=0;i<32;i++){
		for (int j=0;j<32;j++){
		dct[i*8+4][j*8+7] = (dct[i*8+4][j*8+7])+((dct[i*8+4][j*8+7]))*(alpha*z[count]);count++;
		dct[i*8+5][j*8+6] = (dct[i*8+5][j*8+6])+((dct[i*8+5][j*8+6]))*(alpha*z[count]);count++;
		dct[i*8+6][j*8+5] = (dct[i*8+6][j*8+5])+((dct[i*8+6][j*8+5]))*(alpha*z[count]);count++;
		dct[i*8+7][j*8+4] = (dct[i*8+7][j*8+4])+((dct[i*8+7][j*8+4]))*(alpha*z[count]);count++;
		/*
		dct[i*8+4][j*8+7] = (dct[i*8+4][j*8+7])+abs((dct[i*8+4][j*8+7]))*(alpha*z[count]);count++;
		dct[i*8+5][j*8+6] = (dct[i*8+5][j*8+6])+abs((dct[i*8+5][j*8+6]))*(alpha*z[count]);count++;
		dct[i*8+6][j*8+5] = (dct[i*8+6][j*8+5])+abs((dct[i*8+6][j*8+5]))*(alpha*z[count]);count++;
		dct[i*8+7][j*8+4] = (dct[i*8+7][j*8+4])+abs((dct[i*8+7][j*8+4]))*(alpha*z[count]);count++;
		
		dct[i*8][j*8+3] = (dct[i*8][j*8+3])*(1+alpha*z[count]);count++;
		dct[i*8+1][j*8+2] = (dct[i*8+1][j*8+2])*(1+alpha*z[count]);count++;
		dct[i*8+2][j*8+1] = (dct[i*8+2][j*8+1])*(1+alpha*z[count]);count++;
		dct[i*8+3][j*8] = (dct[i*8+3][j*8])*(1+alpha*z[count]);count++;
		*/
		//dct[i*8+4][j*8] = (dct[i*8+4][j*8])*(1+alpha*z[count]);count++;
		
		//dct[i*8+3][j*8+1] = (dct[i*8+3][j*8+1])*(1+alpha*z[count]);count++;
		//dct[i*8+2][j*8+2] = (dct[i*8+2][j*8+2])*(1+alpha*z[count]);count++;
		//dct[i*8+1][j*8+3] = (dct[i*8+1][j*8+3])*(1+alpha*z[count]);count++;
		//dct[i*8][j*8+4] = (dct[i*8][j*8+4])*(1+alpha*z[count]);count++;
		}
	}

//============================ END MARK ==========================//
//============================ IDCT 8X8 ==========================//
for (int i=0;i<32;i++){
		for (int j=0;j<4;j++){
			pointy=64*j;
			for (int u=0;u<8;u++){
				for (int v=0;v<8;v++){
					for (int x=0;x<8;x++){
						for (int y=0;y<8;y++){
							if (x==0){cu=0.35355339;}else{cu=0.5;}
							if (y==0){cv=0.35355339;}else{cv=0.5;}
							temp1 = temp1+((dct[i*8+x][pointy+y])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp2 = temp2+((dct[i*8+x][pointy+y+8])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp3 = temp3+((dct[i*8+x][pointy+y+16])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp4 = temp4+((dct[i*8+x][pointy+y+24])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp5 = temp5+((dct[i*8+x][pointy+y+32])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp6 = temp6+((dct[i*8+x][pointy+y+40])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp7 = temp7+((dct[i*8+x][pointy+y+48])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
							temp8 = temp8+((dct[i*8+x][pointy+y+56])*cu*cv*((cos(((2*u+1)*Pi*x)/(16)))*(cos(((2*v+1)*Pi*y)/(16)))));
						}
					}
					data[i*8+u][pointy+v] = (BYTE)floor(temp1);
					data[i*8+u][pointy+v+8] = (BYTE)floor(temp2);
					data[i*8+u][pointy+v+16] = (BYTE)floor(temp3);
					data[i*8+u][pointy+v+24] = (BYTE)floor(temp4);
					data[i*8+u][pointy+v+32] = (BYTE)floor(temp5);
					data[i*8+u][pointy+v+40] = (BYTE)floor(temp6);
					data[i*8+u][pointy+v+48] = (BYTE)floor(temp7);
					data[i*8+u][pointy+v+56] = (BYTE)floor(temp8);
					temp1 = 0;
					temp2 = 0;
					temp3 = 0;
					temp4 = 0;
					temp5 = 0;
					temp6 = 0;
					temp7 = 0;
					temp8 = 0;
				}
			}
		}
	}

//============================ END IDCT ==========================//




	for (int ii = 0; ii < 256; ii++) {
		for (int jj = 0; jj < 256; jj++) {
			PointerIM =(BYTE*)imageIN.GetPixelAddress(ii,jj);
			PointerIM[0] = (BYTE)data[ii][jj];
		}
	}
	HRESULT hresultSAVE = imageIN.Save(str);



}

void Cwatermark_version_1_1Dlg::OnBnClickedButton3()
{
CString strFileName;
	CDC mem_bg;
	HBITMAP H_bg;
	CFileDialog fd(TRUE, NULL, NULL, NULL, "BMP File (*.bmp) |*.bmp|All File (*.*)|*.*||");
	if(fd.DoModal() == IDCANCEL)
		return;	
	strFileName = fd.GetPathName();
	if(fd.GetFileExt() == "")
		strFileName += ".bmp";
	HWND hwndStill = NULL;
	GetDlgItem(SHOW_IN,&hwndStill);
	RECT rc;
	::GetWindowRect(hwndStill, &rc);
	long ldisplayWidth = rc.right - rc.left;
	long ldisplayHeight = rc.bottom - rc.top;
	H_bg = (HBITMAP)LoadImage(NULL,strFileName,
	IMAGE_BITMAP,ldisplayWidth,ldisplayHeight,LR_LOADFROMFILE);
	CWnd *hwnd = GetDlgItem(SHOW_IN);
	CDC *pdc;
	pdc = GetDC();
	mem_bg.CreateCompatibleDC(pdc);
	mem_bg.SelectObject(H_bg);
	ReleaseDC(pdc);
	CClientDC dc(hwnd);
	dc.BitBlt(0,0,ldisplayWidth,ldisplayHeight,&mem_bg,0,0,SRCCOPY);
//=========================== END SHOW IMAGE =====================//
//=========================== LOAD WATERMARK IMAGE ===============//
	CImage imageIN;
	imageIN.Create(256,256,24);
	imageIN.Destroy();
	HRESULT hresult = imageIN.Load(strFileName);
	CString str = "RKEY.bmp";
	BYTE *PointerIM;
	float data[256][256];
	double dct[256][256];
	for (int ii = 0; ii < 256; ii++) {
		for (int jj = 0; jj < 256; jj++) {
			PointerIM =(BYTE*)imageIN.GetPixelAddress(ii,jj);
			data[ii][jj] = PointerIM[0];
		}
	}
//=========================== END LOAD WATERMARK IMAGE ===========//
//=========================== WATERMARK DCT 8X8 ==================//
	double cu,cv,temp1=0,temp2=0,temp3=0,temp4=0,temp5=0,temp6=0,temp7=0,temp8=0;
	int pointy = 0;
	for (int i=0;i<32;i++){
		for (int j=0;j<4;j++){
			pointy=64*j;
			for (int u=0;u<8;u++){
				for (int v=0;v<8;v++){
					for (int x=0;x<8;x++){
						for (int y=0;y<8;y++){
							
							temp1 = temp1+((data[i*8+x][pointy+y])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp2 = temp2+((data[i*8+x][pointy+y+8])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp3 = temp3+((data[i*8+x][pointy+y+16])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp4 = temp4+((data[i*8+x][pointy+y+24])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp5 = temp5+((data[i*8+x][pointy+y+32])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp6 = temp6+((data[i*8+x][pointy+y+40])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp7 = temp7+((data[i*8+x][pointy+y+48])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp8 = temp8+((data[i*8+x][pointy+y+56])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
						}
					}

					if (u==0){cu=0.35355339;}else{cu=0.5;}
					if (v==0){cv=0.35355339;}else{cv=0.5;}
					dct[i*8+u][pointy+v] = temp1*cu*cv;
					dct[i*8+u][pointy+v+8] = temp2*cu*cv;
					dct[i*8+u][pointy+v+16] = temp3*cu*cv;
					dct[i*8+u][pointy+v+24] = temp4*cu*cv;
					dct[i*8+u][pointy+v+32] = temp5*cu*cv;
					dct[i*8+u][pointy+v+40] = temp6*cu*cv;
					dct[i*8+u][pointy+v+48] = temp7*cu*cv;
					dct[i*8+u][pointy+v+56] = temp8*cu*cv;
					temp1 = 0;
					temp2 = 0;
					temp3 = 0;
					temp4 = 0;
					temp5 = 0;
					temp6 = 0;
					temp7 = 0;
					temp8 = 0;
				}
			}
			
		
		}
	}
//============================ END DCT 8X8 =======================//
	double z[4096];
	int count = 0;
//============================ GET KEY ===========================//
for (int i=0;i<32;i++){
		for (int j=0;j<32;j++){

		z[count] = dct[i*8+4][j*8+7];count++;
		z[count] = dct[i*8+5][j*8+6];count++;
		z[count] = dct[i*8+6][j*8+5];count++;
		z[count] = dct[i*8+7][j*8+4];count++;
		
		//z[count] = dct[i*8+4][j*8];count++;
		
		//z[count] = dct[i*8+3][j*8+1];count++;
		//z[count] = dct[i*8+2][j*8+2];count++;
		//z[count] = dct[i*8+1][j*8+3];count++;
		//z[count] = dct[i*8][j*8+4];count++;
		}
	}
//============================ END GET KEY =======================//
//============================ LOAD WATERMARK IMAGE ==============//
	CImage imageOUT;
	imageOUT.Create(256,256,24);
	imageOUT.Destroy();
	CString load = "watermarked.bmp";
	HRESULT hresult1 = imageOUT.Load(load);
	//CString str = "RKEY.bmp";
	//BYTE *PointerIM;
//	float data[256][256];
//	double dct[256][256];
	for (int ii = 0; ii < 256; ii++) {
		for (int jj = 0; jj < 256; jj++) {
			PointerIM =(BYTE*)imageOUT.GetPixelAddress(ii,jj);
			data[ii][jj] = PointerIM[0];
		}
	}

//=========================== WATERMARK DCT 8X8 ==================//
	//double cu,cv,temp1=0,temp2=0,temp3=0,temp4=0,temp5=0,temp6=0,temp7=0,temp8=0;
	//int pointy = 0;
	for (int i=0;i<32;i++){
		for (int j=0;j<4;j++){
			pointy=64*j;
			for (int u=0;u<8;u++){
				for (int v=0;v<8;v++){
					for (int x=0;x<8;x++){
						for (int y=0;y<8;y++){
							
							temp1 = temp1+((data[i*8+x][pointy+y])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp2 = temp2+((data[i*8+x][pointy+y+8])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp3 = temp3+((data[i*8+x][pointy+y+16])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp4 = temp4+((data[i*8+x][pointy+y+24])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp5 = temp5+((data[i*8+x][pointy+y+32])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp6 = temp6+((data[i*8+x][pointy+y+40])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp7 = temp7+((data[i*8+x][pointy+y+48])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
							temp8 = temp8+((data[i*8+x][pointy+y+56])*((cos(((2*x+1)*Pi*u)/(16)))*(cos(((2*y+1)*Pi*v)/(16)))));
						}
					}

					if (u==0){cu=0.35355339;}else{cu=0.5;}
					if (v==0){cv=0.35355339;}else{cv=0.5;}
					dct[i*8+u][pointy+v] = temp1*cu*cv;
					dct[i*8+u][pointy+v+8] = temp2*cu*cv;
					dct[i*8+u][pointy+v+16] = temp3*cu*cv;
					dct[i*8+u][pointy+v+24] = temp4*cu*cv;
					dct[i*8+u][pointy+v+32] = temp5*cu*cv;
					dct[i*8+u][pointy+v+40] = temp6*cu*cv;
					dct[i*8+u][pointy+v+48] = temp7*cu*cv;
					dct[i*8+u][pointy+v+56] = temp8*cu*cv;
					temp1 = 0;
					temp2 = 0;
					temp3 = 0;
					temp4 = 0;
					temp5 = 0;
					temp6 = 0;
					temp7 = 0;
					temp8 = 0;
				}
			}
			
		
		}
	}
//========================== END LOAD WATERMARK IMAGE ============//
	double x[4096];
	count = 0;
//============================ GET KEY ===========================//
for (int i=0;i<32;i++){
		for (int j=0;j<32;j++){

		x[count] = dct[i*8+4][j*8+7];count++;
		x[count] = dct[i*8+5][j*8+6];count++;
		x[count] = dct[i*8+6][j*8+5];count++;
		x[count] = dct[i*8+7][j*8+4];count++;
		
		//x[count] = dct[i*8+4][j*8];count++;
		
		//x[count] = dct[i*8+3][j*8+1];count++;
		//x[count] = dct[i*8+2][j*8+2];count++;
		//x[count] = dct[i*8+1][j*8+3];count++;
		//x[count] = dct[i*8][j*8+4];count++;
		}
	}
//============================ END GET KEY =======================//
//z=original 
//x=watermark 
for (int i=0;i<4096;i++){
		//x[i] = x[i]-1;//
	    x[i] = ((x[i]/z[i])-1.1);//increat sinal
		x[i] = pow(x[i]/255,0.01)*255;//gramma
		//x[i] = x[i]-2;
		//x[i] =pow(x[i]/255,0.03)*255;
		//if(z[i]>200 ){z[i] = 245;}else
		//if(z[i]<100 )
		//{z[i] = 7;}
}

/*===============================invers zigzag=======================*/

	// function y = izig(z)
//n = length(z);
//y = zeros(n^0.5,n^0.5);
	//double y[4096];
	char y[64][64];
	 count = 0;
	for (int i = 0;i<64;i++){
          for (int j = 0;j<i+1;j++){
			   if ((i%2) != 0){
                    y[j][i-j]=x[count];
                    count = count + 1;
               }
			   else{
                    
                    y[i-j][j]=x[count];
                    count = count + 1;
			   }
		   }
	}
     int run;
	 for(int i = 1;i < 64;i++){
           run = 63;
           for(int j = i;j<64;j++){
			   if ((i%2) != 0){
                     y[run][j]=x[count];
                    run = run - 1;
                   
                    count = count + 1;
			   }
				else{
                    y[j][run] = x[count];
                    run = run -1;
                   
                    count = count +1;
				}
		   }
	 }
	
	
	
	
	
	
	
	
	
	
	
	/////////////////////////////////////////////////
	
 /* count = 0;
  count = 0;
	//BYTE z[3969];
	char y[64][64];
	 count =0;
	for(int i =0;i<64;i++){
		for(int j = 0;j<64;j++){
		y[i][j]=x[count];
		count = count+1;
		}
	}*/
 /*==================================END invers zigzag=================*/
	CImage KEY;
	KEY.Create(64,64,8);
	KEY.Destroy();
	//CString strKEY = "KEY256.bmp";
	CString strKEY1 = "KEY2561.bmp";
	HRESULT hresultkey = KEY.Load(strKEY1);
for (int ii = 0; ii < 64; ii++) {
		for (int jj = 0; jj < 64; jj++) {
			PointerIM =(BYTE*)KEY.GetPixelAddress(ii,jj);
			PointerIM[0] = (BYTE)y[ii][jj];
		}
	}
	HRESULT hresultSAVE = KEY.Save(strKEY1);}
