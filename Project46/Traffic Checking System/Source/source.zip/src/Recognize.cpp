// Recognize.cpp : implementation file
//
/*
#include "stdafx.h"
#include "StillCap.h"
#include "Recognize.h"


// CRecognize

CRecognize::CRecognize()
{
//	pOwner = NULL;
}

CRecognize::~CRecognize()
{
}


// CRecognize member functions

BOOL CRecognize::DisplayGrabBits(BYTE * pBuffer)
{
	        // put bits into the preview window with StretchDIBits
        //
//        HWND hwndStill = NULL;
//        pOwner->GetDlgItem( IDC_STILL, &hwndStill );
/*
        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
        long lStillWidth = rc.right - rc.left;
        long lStillHeight = rc.bottom - rc.top;
        
        HDC hdcStill = GetDC( hwndStill );
        PAINTSTRUCT ps;
        BeginPaint(hwndStill, &ps);

        SetStretchBltMode(hdcStill, COLORONCOLOR);
        StretchDIBits( 
            hdcStill, 0, 0, 
            lStillWidth, lStillHeight, 
            0, 0, lWidth, lHeight, 
            pBuffer, 
            (BITMAPINFO*) pbih, 
            DIB_RGB_COLORS, 
            SRCCOPY );

        EndPaint(hwndStill, &ps);
        ReleaseDC( hwndStill, hdcStill );    
*/
/*	return TRUE;
}
*/