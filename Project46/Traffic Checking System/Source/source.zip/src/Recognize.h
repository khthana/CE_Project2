/*#pragma once



// CRecognize command target

class CRecognize : public CObject
{
public:
	CRecognize();
	virtual ~CRecognize();
public:
	long lWidth;
    long lHeight;
//    CStillCapDlg * pOwner;

	BOOL DisplayGrabBits(BYTE * pBuffer);
};

*/
