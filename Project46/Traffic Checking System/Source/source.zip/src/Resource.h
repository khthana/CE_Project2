//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StillCap.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STILLCAP_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_CAPDIR                      1000
#define IDC_CAPOBJ                      1001
#define IDC_SNAP                        1002
#define IDC_PREVIEW                     1003
#define IDC_STILL                       1004
#define IDC_SNAPNAME                    1005
#define IDC_CAPSTILLS                   1006
#define IDC_CAPVID                      1007
#define IDC_AUTOBUMP                    1008
#define IDC_BUTTON_RESET                1009
#define IDC_PLAYSOUND                   1010
#define IDC_STATUS                      1011
#define IDC_BUTTON_VIEWSTILL            1012
#define IDC_Browse_avi                  1013
#define IDC_From_avi                    1014
#define IDC_From_camera                 1015
#define IDC_Group_input                 1016
#define IDC_play                        1017
#define IDC_BUTTON1                     1018
#define IDC_test                        1018
#define IDC_EDIT1                       1019
#define IDC_show                        1019
#define IDC_BUTTON2                     1020
#define IDC_stop                        1020
#define IDC_sele_config                 1021
#define IDC_check_config                1022
#define IDC_in_threshold                1023
#define IDC_BUTTON3                     1024
#define IDC_threshold                   1024
#define IDC_Dis_Thres                   1025
#define IDC_dis_thres_inter             1026
#define IDC_dis_thres_edge              1027
#define IDC_dis_frame                   1028
#define IDC_speed                       1029
#define IDC_Config_next                 1030
#define IDC_Config_back                 1031
#define IDC_Config_default              1032
#define IDC_dis_frame1                  1034
#define IDC_dis_inter1                  1035
#define IDC_dis_edge1                   1036
#define IDC_tresthold2                  1037
#define IDC_spintreshold                1038
#define IDC_SPIN_frame                  1040
#define IDC_SPIN_interframe             1041
#define IDC_SPIN_edge1                  1042
#define IDC_expain                      1043
#define IDC_BUTTON4                     1044
#define IDC_reset                       1044
#define IDC_From_avi1                   1047
#define IDC_RADIO4                      1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
