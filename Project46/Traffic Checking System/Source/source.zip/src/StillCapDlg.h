//------------------------------------------------------------------------------
// File: StillCapDlg.h
//
// Desc: DirectShow sample code - definition of callback and dialog
//       classes for StillCap application.
//
// Copyright (c) 1999-2001 Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


#include "afxwin.h"
#include "afxcmn.h"
#include "atltypes.h"
#if !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
#define AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

class CSampleGrabberCB;
class CRecognize;

class CStillCapDlg : public CDialog
{
    friend class CSampleGrabberCB;
    friend class CRecognize;
protected:

    // either the capture live graph, or the capture still graph
    CComPtr< IGraphBuilder > m_pGraph;

//	CComPtr< IBaseFilter >pCap;
    // the playback graph when capturing video
    CComPtr< IGraphBuilder > m_pPlayGraph;

    // the sample grabber for grabbing stills
    CComPtr< ISampleGrabber > m_pGrabber;
//	CComPtr< IMediaEventEx  > pEvent;


    // if you're in still mode or capturing video mode
    bool m_bCapStills;

    // when in video mode, whether capturing or playing back
    int m_nCapState;

    // how many times you've captured
    int m_nCapTimes;

    void GetDefaultCapDevice( IBaseFilter ** ppCap );
	HRESULT InitStillGraphAVI(void);
    HRESULT InitStillGraph( );
    HRESULT InitCaptureGraph( TCHAR * pFilename );
    HRESULT InitPlaybackGraph( TCHAR * pFilename ); 
    void ClearGraphs( );
    void UpdateStatus(TCHAR *szStatus);
    void Error( TCHAR * pText );

// Construction
public:
	CStillCapDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CStillCapDlg)
	enum { IDD = IDD_STILLCAP_DIALOG };
	CStatic	m_StrStatus;
	CStatic	m_StillScreen;
	CStatic	m_PreviewScreen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStillCapDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CStillCapDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSnap();
	afx_msg void OnCapstills();
	afx_msg void OnCapvid();
	afx_msg void OnButtonReset();
	afx_msg void OnButtonViewstill();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBrowseavi();
	LPCWSTR wstrMediaFile;
	CString	m_strMediaFile; 
	afx_msg void OnBnClickedFromavi();
	bool m_sele_avi ;
	bool m_sele_camera;
	afx_msg void OnBnClickedplay();
//	afx_msg void OnBnClickedFromcamera();
	afx_msg void OnBnClickedtest();
	void thread_grab(void);
	static UINT thread_grab(LPVOID p);
	BYTE* frame_st, *frame_nd, *frame_rd, *frame_BW ,*frame_count;

	bool Frame_Sequence();
	int m_cap;
	UINT m_show;
	bool running ;
	afx_msg void OnBnClickedstop();
	void run(void);
	static UINT run(LPVOID p);
	void auto_control(void);
	void Auto_Recognize(void);
	void run_auto_recognize(void);
	static UINT run_auto_recognize(LPVOID p);
	CWinThread *Thread_autorun;
	CWinThread *Thread_cap;
	bool stop;
	int number;
	CComboBox m_sele_config;
	afx_msg void OnBnClickedcheckconfig();
//	afx_msg void OnCbnSelchangeseleconfig();
	int m_type_config;
	afx_msg void OnStnClickedPreview();
	int m_currentx,m_currenty;
	int m_theshold;
	afx_msg void OnBnClickedthreshold();
	afx_msg void OnStnClickedSnapname();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	int m_dis_thres_inter;
	int m_dis_thres_edge;
	int m_dis_frame;
	int m_speed;
	CSpinButtonCtrl m_spintreshold;
	CSpinButtonCtrl m_spin_frame;
	CSpinButtonCtrl m_spin_interframe;
	CSpinButtonCtrl m_spin_edge;
	CFont m_fontShow;
	CRect m_rectStatic;
	afx_msg void OnBnClickedConfignext();
	afx_msg void OnBnClickedConfigback();
	CButton m_config_next;
	CButton m_config_back;
	afx_msg void OnCbnSelchangeseleconfig();
	CEdit m_tresthold_control;
	void refesh_dis(int tmp, CString str, bool spin, bool edit);
	CButton m_config_default;
	afx_msg void OnBnClickedConfigdefault();
	afx_msg void OnBnClickedreset();
	afx_msg void OnBnClickedFromavi1();
	afx_msg void OnBnClickedFromcamera();
	CButton m_check_config;
	BOOL m_sele_config_value;
	CButton m_repleace_config;
	CButton m_button_play;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
