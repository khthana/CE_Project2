//------------------------------------------------------------------------------
// File: StillCapDlg.cpp
//
// Desc: DirectShow sample code - implementation of callback and dialog
//       objects for StillCap application.
//
// Copyright (c) 1999-2001 Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


#include "stdafx.h"
#include "StillCap.h"
#include "StillCapDlg.h"
#include <sys/timeb.h>
#include <time.h>
#include "..\..\common\dshowutil.cpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

	const int W_SIZE = 3;

#ifdef DEBUG
#define REGISTER_FILTERGRAPH
#endif

// Constants
#define WM_CAPTURE_BITMAP   WM_APP + 1
#define WM_RECOGNIZE	WM_APP+2
#define WM_GRAPHNOTIFY  WM_APP+3

// Global data
BOOL g_bOneShot = FALSE;
BOOL g_bCaptured = TRUE;
BOOL m_running = false;

 
DWORD g_dwGraphRegister=0;  // For running object table
HWND g_hwnd;
BYTE * frame_tmp;
int point;
BYTE *frame_Inter , *frame_Edge,*frame_region,*frame_dis;
BYTE* frame_Inter_Edge ,*frame_Label,*frame_Fillter ;
UINT number_car = 0;
int number_car_speed = 0;
int number_car_check = 0;
bool m_car = false;
bool m_carspeed = false;
bool m_carcheck = false;
bool m_car_syn = false;
int theshold_inter = 16;
int theshold_edge = 53;
int m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;
int m_regionX3=0,m_regionX4=1,m_regionY3=0,m_regionY4=1;

int m_linecountX1=0,m_linecountY1=1,m_linecountX2=0,m_linecountY2=1;

int m_linecheckX1=0,m_linecheckY1=1,m_linecheckX2=0,m_linecheckY2=1; 
int m_linecheckX3=0,m_linecheckY3=1,m_linecheckX4=0,m_linecheckY4=1; 

bool region1=false ,region2=false;
bool region3=false ,region4=false;
bool region_click = false;
long frame_delay  = 125;
struct __timeb64 tstruct;
int speed = 0;
int car_count = 0;
bool config = false;
int speed_tail = 1;
int avg,num_avg;

int show_debug,show_debug1;
bool reset_cap=false;
int m_range = 15;
int test_debug = 0;
int test_debug1 = 0;
int test_debug2 = 0;
// Structures
typedef struct _callbackinfo 
{
    double dblSampleTime;
    long lBufferSize;
    BYTE *pBuffer;
    BITMAPINFOHEADER bih;

} CALLBACKINFO;

CALLBACKINFO cb={0};

typedef struct _regionCar
{
	UINT milis;
	long time;
	int pointX1,pointY1;
	int pointX2,pointY2;
	int pointX3,pointY3;
	int pointX4,pointY4;
	bool have;
	bool show_speed;
	int num_show;
	int speed;
}regionCar;
regionCar car[50];

typedef struct _pointCar
{
	int x1,x2;
	bool have;
}pointCar;
pointCar car_q[10];

class CSampleGrabberCB : public ISampleGrabberCB 
{
public:
    // these will get set by the main thread below. We need to
    // know this in order to write out the bmp
    long lWidth;
    long lHeight;
    CStillCapDlg * pOwner;
    TCHAR m_szCapDir[MAX_PATH]; // the directory we want to capture to
    TCHAR m_szSnappedName[MAX_PATH];
    BOOL bFileWritten;
  
    CSampleGrabberCB( )
    {
        pOwner = NULL;
        m_szCapDir[0] = 0;
        bFileWritten = FALSE;
    }   

    // fake out any COM ref counting
    //
    STDMETHODIMP_(ULONG) AddRef() { return 2; }
    STDMETHODIMP_(ULONG) Release() { return 1; }

    // fake out any COM QI'ing
    //
    STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
    {
        if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
        {
            *ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
            return NOERROR;
        }    
        return E_NOINTERFACE;
    }

    // we don't implement this interface for this example
    //
    STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
    {
        return 0;
    }

    // The sample grabber is calling us back on its deliver thread.
    // This is NOT the main app thread!
    //
    //           !!!!! WARNING WARNING WARNING !!!!!
    //
    // On Windows 9x systems, you are not allowed to call most of the 
    // Windows API functions in this callback.  Why not?  Because the
    // video renderer might hold the global Win16 lock so that the video
    // surface can be locked while you copy its data.  This is not an
    // issue on Windows 2000, but is a limitation on Win95,98,98SE, and ME.
    // Calling a 16-bit legacy function could lock the system, because 
    // it would wait forever for the Win16 lock, which would be forever
    // held by the video renderer.
    //
    // As a workaround, copy the bitmap data during the callback,
    // post a message to our app, and write the data later.
    //
    STDMETHODIMP BufferCB( double dblSampleTime, BYTE * pBuffer, long lBufferSize )
    {
        // this flag will get set to true in order to take a picture
        //
        if( !g_bOneShot )
            return 0;

        // Since we can't access Windows API functions in this callback, just
        // copy the bitmap data to a global structure for later reference.
        cb.dblSampleTime = dblSampleTime;
        cb.lBufferSize   = lBufferSize;

        // If we haven't yet allocated the data buffer, do it now.
        // Just allocate what we need to store the new bitmap.
        if (!cb.pBuffer)
            cb.pBuffer = new BYTE[lBufferSize];

        // Copy the bitmap data into our global buffer
        if (cb.pBuffer)
            memcpy(cb.pBuffer, pBuffer, lBufferSize);

        // Post a message to our application, telling it to come back
        // and write the saved data to a bitmap file on the user's disk.
        PostMessage(g_hwnd, WM_CAPTURE_BITMAP, 0, 0L);
        return 0;
    }

    // This function will be called whenever a captured still needs to be
    // displayed in the preview window.  It is called initially within
    // CopyBitmap() to display the captured still, but it is also called
    // whenever the main dialog needs to repaint and when we transition
    // from video capture mode back into still capture mode.
    //
    BOOL DisplayCapturedBits(BYTE *pBuffer, BITMAPINFOHEADER *pbih)
    {
        // If we haven't yet snapped a still, return
        if (!bFileWritten || !pOwner || !pBuffer)
            return FALSE;

        // put bits into the preview window with StretchDIBits
        //
        HWND hwndStill = NULL;
        pOwner->GetDlgItem( IDC_STILL, &hwndStill );
		
        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
        long lStillWidth = rc.right - rc.left;
        long lStillHeight = rc.bottom - rc.top;
        
        HDC hdcStill = GetDC( hwndStill );
        PAINTSTRUCT ps;
        BeginPaint(hwndStill, &ps);
        SetStretchBltMode(hdcStill, COLORONCOLOR);
        StretchDIBits( 
            hdcStill, 0, 0, 
            lStillWidth, lStillHeight, 
            0, 0, lWidth, lHeight, 
            pBuffer, 
            (BITMAPINFO*) pbih, 
            DIB_RGB_COLORS, 
            SRCCOPY );

        EndPaint(hwndStill, &ps);
        ReleaseDC( hwndStill, hdcStill );    

        return TRUE;
    }

    // This is the implementation function that writes the captured video
    // data onto a bitmap on the user's disk.
    //
    BOOL CopyBitmap( double dblSampleTime, BYTE * pBuffer, long lBufferSize )
    {
        if( !g_bOneShot )
            return 0;

        // we only take one at a time
        //
        g_bOneShot = FALSE;

        // figure out where to capture to
        //
        TCHAR m_ShortName[MAX_PATH];
        wsprintf( m_szSnappedName, TEXT("%sStillCap%4.4ld.bmp"), 
                  m_szCapDir, pOwner->m_nCapTimes );
        wsprintf( m_ShortName, TEXT("StillCap%4.4ld.bmp"), 
                  pOwner->m_nCapTimes );

        // increment bitmap number if user requested it
        // otherwise, we'll reuse the filename next time
        if( pOwner->IsDlgButtonChecked( IDC_AUTOBUMP ) )
            pOwner->m_nCapTimes++;

        // write out a BMP file
        //
        HANDLE hf = CreateFile(
            m_szSnappedName, GENERIC_WRITE, 0, NULL,
            CREATE_ALWAYS, NULL, NULL );

        if( hf == INVALID_HANDLE_VALUE )
            return 0;

        // write out the file header
        //
        BITMAPFILEHEADER bfh;
        memset( &bfh, 0, sizeof( bfh ) );
        bfh.bfType = 'MB';
        bfh.bfSize = sizeof( bfh ) + lBufferSize + sizeof( BITMAPINFOHEADER );
        bfh.bfOffBits = sizeof( BITMAPINFOHEADER ) + sizeof( BITMAPFILEHEADER );

        DWORD dwWritten = 0;
        WriteFile( hf, &bfh, sizeof( bfh ), &dwWritten, NULL );

        // and the bitmap format
        //
        BITMAPINFOHEADER bih;
        memset( &bih, 0, sizeof( bih ) );
        bih.biSize = sizeof( bih );
        bih.biWidth = lWidth;
        bih.biHeight = lHeight;
        bih.biPlanes = 1;
        bih.biBitCount = 24;

        dwWritten = 0;
        WriteFile( hf, &bih, sizeof( bih ), &dwWritten, NULL );

        // and the bits themselves
        //
        dwWritten = 0;
        WriteFile( hf, pBuffer, lBufferSize, &dwWritten, NULL );
        CloseHandle( hf );
        bFileWritten = TRUE;

        // Display the bitmap bits on the dialog's preview window
        DisplayCapturedBits(pBuffer, &bih);

        // Save bitmap header for later use when repainting the window
        memcpy(&(cb.bih), &bih, sizeof(bih));        

        // show where it captured
        //
        pOwner->SetDlgItemText( IDC_SNAPNAME, m_ShortName );

        // Enable the 'View Still' button
        HWND hwndButton = NULL;
        pOwner->GetDlgItem( IDC_BUTTON_VIEWSTILL, &hwndButton );
        ::EnableWindow(hwndButton, TRUE);

        // play a snap sound
        if (pOwner->IsDlgButtonChecked(IDC_PLAYSOUND))
        {
            TCHAR szSound[128];
            GetWindowsDirectory(szSound, 128);
            _tcscat(szSound, TEXT("\\media\\click.wav\0"));
            sndPlaySound(szSound, SND_ASYNC);
        }

        return 0;
    }

};

// this semi-COM object will receive sample callbacks for us
//

class CRecognize : public CObject
{
public:
	long lWidth;
    long lHeight;
	CStillCapDlg *pOwner;
	long buffersize ;
	int label_index[240000]; 

	CRecognize()
	{
		pOwner = NULL;
    }
//	~CRecognize();
	
//    CStillCapDlg * pOwner;

	BOOL DisplayGrabBits(BYTE * pBuffer)
	{
        // put bits into the preview window with StretchDIBits
        //
	    BITMAPINFOHEADER bih;
		BITMAPINFOHEADER *pbih;
        memset( &bih, 0, sizeof( bih ) );
        bih.biSize = sizeof( bih );
        bih.biWidth = lWidth;
        bih.biHeight = lHeight;
        bih.biPlanes = 1;
        bih.biBitCount = 24;
		pbih =	&bih;
		HWND hwndStill = NULL;
        pOwner->GetDlgItem( IDC_STILL, &hwndStill );

        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
        long lStillWidth = rc.right - rc.left;
        long lStillHeight = rc.bottom - rc.top;
       
        HDC hdcStill = GetDC( hwndStill );
        PAINTSTRUCT ps;
        BeginPaint(hwndStill, &ps);
		
        SetStretchBltMode(hdcStill, COLORONCOLOR);
        StretchDIBits( 
            hdcStill, 0, 0, 								 
            lStillWidth, lStillHeight, 
            0, 0, lWidth, lHeight, 
            pBuffer, 
            (BITMAPINFO*) pbih, 
			DIB_RGB_COLORS, 
            SRCCOPY );

        EndPaint(hwndStill, &ps);

    ReleaseDC( hwndStill, hdcStill );    
	return TRUE;
	}

	BOOL DisplayGrabBits(int x,int y,int speed)
	{
///////show speed//////
		HWND hwndStill = NULL;
        pOwner->GetDlgItem( IDC_STILL, &hwndStill );

        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
		CString str;
		str.Format("%d",_T(speed));
	CDC *pdc;
	pdc =  pOwner->GetDC();
	pdc->TextOut(266+(int)(x*0.56)-8,267-(int)(y*0.6)-15,str);
	pOwner->ReleaseDC(pdc);
					/////////////
	return TRUE;
	 
	}

	BYTE * ConvertBW(BYTE * pBuffer)
	{	int r,g,b;
		double color;
		for(int j=0; j<(lHeight-W_SIZE+3); j++)//j+=W_SIZE) 
		for(int i=0; i<(lWidth-W_SIZE+3); i++){//i+=W_SIZE){
			r = pBuffer[(j*lWidth*3)+(i*3)] 	 ;
			g = pBuffer[(j*lWidth*3)+(i*3)+1]	 ;
			b = pBuffer[(j*lWidth*3)+(i*3)+2]	 ;
//			int tt = (j*lWidth*3)+(i*3);			
			color = ((r*0.299)+(g* 0.587)+(b* 0.114));
			pBuffer[(j*lWidth*3)+(i*3)]   = (int)color;
			pBuffer[(j*lWidth*3)+(i*3)+1] = (int)color;
			pBuffer[(j*lWidth*3)+(i*3)+2] = (int)color;
			if((j<=1)||(i<=1)||(j>=(lHeight-W_SIZE))||(i>=(lWidth-W_SIZE))){
				pBuffer[(j*lWidth*3)+(i*3)]   = 0;
				pBuffer[(j*lWidth*3)+(i*3)+1] = 0;
				pBuffer[(j*lWidth*3)+(i*3)+2] = 0;

			}
		}
	return pBuffer;
	}

	BYTE * Edge_Detection(BYTE * pBuffer ,BYTE * frame_tmp)
	{
		int Gx,Gy,G,Tg;
		BYTE z1,z2,z3,z4,z5,z6,z7,z8,z9;
		for(int j=0; j<(lHeight-W_SIZE+3); j++)//j+=W_SIZE) 
		for(int i=0; i<(lWidth-W_SIZE+3); i++){//i+=W_SIZE)
			z1 = pBuffer[((j-1)*lWidth*3)+((i-1)*3)] 	 ;
			z2 = pBuffer[((j-1)*lWidth*3)+((i)*3)] 		 ;
			z3 = pBuffer[((j-1)*lWidth*3)+((i+1)*3)] 	 ;
			z4 = pBuffer[((j)*lWidth*3)+((i-1)*3)] 		 ;
			z5 = pBuffer[(j*lWidth*3)+(i*3)]	 		 ;
			z6 = pBuffer[((j)*lWidth*3)+((i+1)*3)] 		 ; 
			z7 = pBuffer[((j+1)*lWidth*3)+((i-1)*3)] 	 ;
			z8 = pBuffer[((j+1)*lWidth*3)+((i)*3)] 		 ;
			z9 = pBuffer[((j+1)*lWidth*3)+((i+1)*3)] 	 ;
	
			Gx = (z7+(2*z8)+z9)-(z1+(2*z2)+z3);
			Gy = (z3+(2*z6)+z9)-(z1+(2*z4)+z7);
			G = abs(Gx)+abs(Gy);
	
			Tg = theshold_edge;//133;
			if (G >= Tg)
			{ // black
				frame_tmp[(j*lWidth*3)+(i*3)] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 0;
			}
			else 
			{ // white
				frame_tmp[(j*lWidth*3)+(i*3)] = 255;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 255;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 255;
			}
		}  
		return frame_tmp;
	}

	BYTE * InterFrame(BYTE * frame_st, BYTE * frame_nd, BYTE * frame_rd ,BYTE *frame_tmp)
{		BYTE st,nd,rd;
		for(int j=0; j<(lHeight-W_SIZE+3); j++)//j+=W_SIZE) 
		for(int i=0; i<(lWidth-W_SIZE+3); i++)
		if(frame_region[(j*lWidth*3)+(i*3)]==0){//i+=W_SIZE)
			st = frame_st[(j*lWidth*3)+(i*3)];
			nd = frame_nd[(j*lWidth*3)+(i*3)];
			rd = frame_rd[(j*lWidth*3)+(i*3)];
		int t = theshold_inter;//16
			if (((abs(st - nd)) > t )&&((abs(nd - rd)) > t )){  // <- adapt thresho
					frame_tmp[(j*lWidth*3)+(i*3)] = 0;
					frame_tmp[(j*lWidth*3)+(i*3)+1] = 0;
					frame_tmp[(j*lWidth*3)+(i*3)+2] = 0;
				}else{  // <- adapt thresho
					frame_tmp[(j*lWidth*3)+(i*3)] =   255;
					frame_tmp[(j*lWidth*3)+(i*3)+1] = 255;
					frame_tmp[(j*lWidth*3)+(i*3)+2] = 255;
				}
		}
		else
		{
					frame_tmp[(j*lWidth*3)+(i*3)] =   255;
					frame_tmp[(j*lWidth*3)+(i*3)+1] = 255;
					frame_tmp[(j*lWidth*3)+(i*3)+2] = 255;
			
		}
		return frame_tmp;
	}

BYTE * Inter_Edge(BYTE * frame_inter, BYTE * frame_edge, BYTE * frame_tmp)
	{
		BYTE z1,z2,z3,z4,z5,z6,z7,z8,z9;

		for(int j=1; j<(lHeight-W_SIZE); j++)//j+=W_SIZE) 
		for(int i=1; i<(lWidth-W_SIZE); i++){//i+=W_SIZE)
			i--;
			z1 = frame_inter[((j-1)*lWidth*3)+((i-1)*3)] 	 ;
			z2 = frame_inter[((j-1)*lWidth*3)+((i)*3)] 		 ;
			z3 = frame_inter[((j-1)*lWidth*3)+((i+1)*3)] 	 ;
			z4 = frame_inter[((j)*lWidth*3)+((i-1)*3)] 		 ;
			z5 = frame_inter[(j*lWidth*3)+(i*3)]	 		 ;
			z6 = frame_inter[((j)*lWidth*3)+((i+1)*3)] 		 ; 
			z7 = frame_inter[((j+1)*lWidth*3)+((i-1)*3)] 	 ;
			z8 = frame_inter[((j+1)*lWidth*3)+((i)*3)] 		 ;
			z9 = frame_inter[((j+1)*lWidth*3)+((i+1)*3)] 	 ;
			i++;
			if ((z5 ==0)||(frame_edge[(j*lWidth*3)+(i*3)]==0)&&
				((z1==0 || z2==0 || z3==0 || z4==0  
				||z6==0 || z7==0 || z8==0 || z9==0)))
			{	
				frame_tmp[(j*lWidth*3)+(i*3)] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 0;

			}else{
				frame_tmp[(j*lWidth*3)+(i*3)] =  255;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 255;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 255;
			
			}

		}
		for(int j=(lHeight-W_SIZE); j>2; j--)//j+=W_SIZE) 
		for(int i=(lWidth-W_SIZE); i>2; i--){//i+=W_SIZE)
			i++;
			z1 = frame_inter[((j-1)*lWidth*3)+((i-1)*3)] 	 ;
			z2 = frame_inter[((j-1)*lWidth*3)+((i)*3)] 		 ;
			z3 = frame_inter[((j-1)*lWidth*3)+((i+1)*3)] 	 ;
			z4 = frame_inter[((j)*lWidth*3)+((i-1)*3)] 		 ;
			z5 = frame_inter[(j*lWidth*3)+(i*3)]	 		 ;
			z6 = frame_inter[((j)*lWidth*3)+((i+1)*3)] 		 ; 
			z7 = frame_inter[((j+1)*lWidth*3)+((i-1)*3)] 	 ;
			z8 = frame_inter[((j+1)*lWidth*3)+((i)*3)] 		 ;
			z9 = frame_inter[((j+1)*lWidth*3)+((i+1)*3)] 	 ;
			i--;
			if ((z5 ==0)||(frame_edge[(j*lWidth*3)+(i*3)]==0)&&
				((z1==0 || z2==0 || z3==0 || z4==0  
				||z6==0 || z7==0 || z8==0 || z9==0)))
			{	
				frame_tmp[(j*lWidth*3)+(i*3)] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 0;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 0;

			}else{
				frame_tmp[(j*lWidth*3)+(i*3)] =  255;
				frame_tmp[(j*lWidth*3)+(i*3)+1] = 255;
				frame_tmp[(j*lWidth*3)+(i*3)+2] = 255;
			
			}
		}
		return frame_tmp;
	}

	void Make_Information(long buffersize)
	{
		this->buffersize = buffersize;
	}

	BYTE * Fillter(BYTE * pBuffer,BYTE * frame_tmp)
	{
		int z[9],ans = 0;
		int regionX1,regionX2;
		if(m_regionX1>m_regionX2)regionX1 = m_regionX1; else regionX1 = m_regionX2;
		if(m_regionX3>m_regionX4)regionX2 = m_regionX3; else regionX2 = m_regionX4;

		for(int j=1; j<(lHeight-W_SIZE); j++)//j+=W_SIZE) 
		for(int i=regionX1; i<regionX2; i++){//i+=W_SIZE)
			if(pBuffer[((j)*lWidth*3)+((i)*3)] == 255){
			ans = 0;
			z[0] = pBuffer[((j-1)*lWidth*3)+((i-1)*3)] 	 ;
			z[1] = pBuffer[((j-1)*lWidth*3)+((i)*3)] 		 ;
			z[2] = pBuffer[((j-1)*lWidth*3)+((i+1)*3)] 	 ;
			z[3] = pBuffer[((j)*lWidth*3)+((i-1)*3)] 		 ;
			//z[3] = pBuffer[(j*lWidth*3)+(i*3)]	 		 ;
			z[4] = pBuffer[((j)*lWidth*3)+((i+1)*3)] 		 ; 
			z[5] = pBuffer[((j+1)*lWidth*3)+((i-1)*3)] 	 ;
			z[6] = pBuffer[((j+1)*lWidth*3)+((i)*3)] 		 ;
			z[7] = pBuffer[((j+1)*lWidth*3)+((i+1)*3)] 	 ;
				for(int ii=0;ii<8;ii++)
					if(z[ii]==0)ans++;
				if(ans>3) {
					frame_tmp[((j)*lWidth*3)+((i)*3)] = 0;
					frame_tmp[((j)*lWidth*3)+((i)*3)+1] = 0;
					frame_tmp[((j)*lWidth*3)+((i)*3)+2] = 0;
				}
			}else{ 
					frame_tmp[((j)*lWidth*3)+((i)*3)] = 0;
					frame_tmp[((j)*lWidth*3)+((i)*3)+1] = 0;
					frame_tmp[((j)*lWidth*3)+((i)*3)+2] = 0;
			}
		}
		return frame_tmp;
	}

BYTE * Label(BYTE * frame_inter_edge, BYTE * frame_tmp ,BYTE * frame_count,BYTE *frame_dis)
	{
		int label_seq = 1,ii;
		int label[9],i,j;
		int tmp_label = 0;
		int regionX1,regionX2;
		if(m_regionX1>m_regionX2)regionX1 = m_regionX1; else regionX1 = m_regionX2;
		if(m_regionX3>m_regionX4)regionX2 = m_regionX3; else regionX2 = m_regionX4;
		
		for(j=(lHeight-W_SIZE); j>2; j--)//j+=W_SIZE)   // initial 
		for(i=regionX1; i<regionX2; i++){//i+=W_SIZE)
			label_index[(j*lWidth*3)+(i*3)] = 0;
			frame_count[(j*lWidth*3)+(i*3)] = 255;	
			frame_count[(j*lWidth*3)+(i*3)+1] = 255;
			frame_count[(j*lWidth*3)+(i*3)+2] = 255;
		}

		//for(j=(lHeight-W_SIZE)-30; j>60; j--)//j+=W_SIZE) 
		for(j=(lHeight-W_SIZE); j>2; j--)//j+=W_SIZE) 
		for(i=regionX1; i<regionX2; i++){//i+=W_SIZE)
			if (frame_inter_edge[(j*lWidth*3)+(i*3)] == 0)
			{
			label[1] = label_index[((j+1)*lWidth*3)+((i-1)*3)] 		;
			label[2] = label_index[((j+1)*lWidth*3)+((i)*3)] 		 ;
			label[3] = label_index[((j+1)*lWidth*3)+((i+1)*3)] 		 ;
			label[4] = label_index[((j)*lWidth*3)+((i-1)*3)] 		 ;
//			label[5] = label_index[(j*lWidth*3)+(i*3)]	 			;
			label[5] = label_index[((j)*lWidth*3)+((i+1)*3)] 		 ; 
			label[6] = label_index[((j-1)*lWidth*3)+((i-1)*3)] 		;
			label[7] = label_index[((j-1)*lWidth*3)+((i)*3)] 		 ;
			label[8] = label_index[((j-1)*lWidth*3)+((i+1)*3)] 		;
			tmp_label = 0;
				if((label[1]==0)&&(label[2]==0)&&(label[3]==0)&&(label[4]==0)
					&&(label[5]==0)&&(label[6]==0)&&(label[7]==0)&&(label[8]==0))
					{
						label_index[(j*lWidth*3)+(i*3)] = label_seq;
						label_seq++;
					}
				else
					{
	for(ii=1;ii<=8;ii++)
	{
		if(label[ii] != 0)
		{	
			if(tmp_label == 0)	 //255
				tmp_label = label[ii];
			else if(tmp_label != label[ii]) 
			{
				relabel(tmp_label,label[ii],i,j);
				tmp_label = label[ii];
				label[1] = label_index[((j+1)*lWidth*3)+((i-1)*3)];
				label[2] = label_index[((j+1)*lWidth*3)+(i*3)];
				label[3] = label_index[((j+1)*lWidth*3)+((i+1)*3)];
				label[4] = label_index[((j)*lWidth*3)+((i-1)*3)];
				label[5] = label_index[((j)*lWidth*3)+((i+1)*3)] 		 ; 
				label[6] = label_index[((j-1)*lWidth*3)+((i-1)*3)] 		;
				label[7] = label_index[((j-1)*lWidth*3)+((i)*3)] 		 ;
				label[8] = label_index[((j-1)*lWidth*3)+((i+1)*3)] 		;
			}
		}	  // if
	}		  // for
					label_index[(j*lWidth*3)+(i*3)] = tmp_label;
					}   // else
			}	// equal 1 
		}	
	

	//////////// BOUNDARY
//		m_number = 0;
		//for(j=60; j<(lHeight-W_SIZE)-30; j++)//j+=W_SIZE) 
		for(j=2; j<(lHeight-W_SIZE); j++)//j+=W_SIZE) 
		for(i=regionX1; i<regionX2; i++){//i+=W_SIZE)
			//label_index[(j*lWidth*3)+(i*3)] = 0;
			if(label_index[(j*lWidth*3)+(i*3)] > 0)
			{
				//m_number++;
				frame_tmp = label_boundary(i,j,frame_tmp,frame_count,frame_dis);
			}
		} // last
		return frame_tmp;
	}

int relabel(int old_value, int new_value, int i, int j)
{
	int ii,jj,j1,j2;
	int regionX1,regionX2;
	if(m_regionX1>m_regionX2)regionX1 = m_regionX1; else regionX1 = m_regionX2;
	if(m_regionX3>m_regionX4)regionX2 = m_regionX3; else regionX2 = m_regionX4;
	if((j+100) >= (lHeight-W_SIZE))j1 = (lHeight-W_SIZE); else j1 = j+100;
	if((j-50)<=2) j2 = 2; else j2 = j-50; 

	for(jj=j1;jj>j2;jj--){	//hight
	for(ii=regionX1;ii<regionX2;ii++){
		if(label_index[(jj*lWidth*3)+(ii*3)] == old_value)
			label_index[(jj*lWidth*3)+(ii*3)] = new_value;
	}}
	return 0;
}


BYTE* label_boundary(int i,int j,BYTE * frame_tmp,BYTE * frame_count,BYTE * frame_dis)
	{
	int x1,x2,y1,y2,jj,ii,j1,j2; 
	int regionX1,regionX2;
	if(m_regionX1>m_regionX2)regionX1 = m_regionX1; else regionX1 = m_regionX2;
	if(m_regionX3>m_regionX4)regionX2 = m_regionX3; else regionX2 = m_regionX4;
	int index = label_index[(j*lWidth*3)+(i*3)];
	y1 = y2 = j;
	x1 = x2 = i;
	if((j+100) >= (lHeight-W_SIZE))j1 = (lHeight-W_SIZE); else j1 = j+100;
	if((j-50)<=2) j2 = 2; else j2 = j-50; 

	for(jj=j2; jj<j1/*(lHeight-W_SIZE)*/; jj++)//j+=W_SIZE) 
	for(ii=regionX1; ii<regionX2; ii++)//i+=W_SIZE)
		if(label_index[(jj*lWidth*3)+(ii*3)]==index){
			if(ii<x1)
				x1 = ii;
			if(ii>x2)
				x2 = ii;
			if(jj<y2)
				y2 = jj;
			if(jj>y1)
				y1 = jj;
		}
	
//y2--;
//x2++;
	if(((abs(x2-x1))>7)||((abs(y2-y1))>10))
	{
		//m_number++;
	for(jj=y1;jj>=y2;jj--){
	for(ii=x1;ii<=x2;ii++){
		if((ii==x1+1)||(ii==x2-1)||(jj==y1-1)||(jj==y2+1)||
			(ii==x1)||(ii==x2)||(jj==y1)||(jj==y2)){
		frame_tmp[(jj*lWidth*3)+(ii*3)] =	0;	
		frame_tmp[(jj*lWidth*3)+(ii*3)+1] = 0;	
		frame_tmp[(jj*lWidth*3)+(ii*3)+2] = 255;
//		frame_dis[(jj*lWidth*3)+(ii*3)] =	0;	
//		frame_dis[(jj*lWidth*3)+(ii*3)+1] = 0;	
//		frame_dis[(jj*lWidth*3)+(ii*3)+2] = 255;
		}
		else{
		//frame_tmp[(jj*lWidth*3)+(ii*3)] =	255;	
		//frame_tmp[(jj*lWidth*3)+(ii*3)+1] = 0;	
		//frame_tmp[(jj*lWidth*3)+(ii*3)+2] = 0;	
		}
		label_index[(jj*lWidth*3)+(ii*3)] = 0;
		
		frame_count[(jj*lWidth*3)+(ii*3)] = 0;	
		frame_count[(jj*lWidth*3)+(ii*3)+1] = 0;	
		frame_count[(jj*lWidth*3)+(ii*3)+2] = 0;	
		//label_tmp[ii][jj] = index;
	}}
	}
	return (frame_tmp);
	}

	BYTE * Counting(BYTE * pBuffer)
	{	int x1,x2;
		int ans = 0;
		bool had_car = false;
		for(int i=0;i<car_count;i++) car_q[i].have = false;

		for(i=m_linecountX1;i<m_linecountX2;i++){
			if((pBuffer[(m_linecountY1*lWidth*3)+(i*3)]==0)/*&&(!m_car)*/){
	//			m_car = true;
				x1 = i;
				for(int ii=i;((pBuffer[(m_linecountY1*lWidth*3)+(ii*3)]==0)&&(ii<m_linecountX2));ii++);
				x2 = ii;
				i = x2;
				for(ii=0;((ii<car_count)&&(!had_car));ii++){
					ans = ((abs(car_q[ii].x1-x1))+(abs(car_q[ii].x2-x2)));
					if(ans<30) {		//
						had_car = true;
						car_q[ii].have=true;
					}
				}
				if(!had_car){
//					show_debug1 = ans;
						car_q[car_count].x1 = x1;
						car_q[car_count].x2 = x2;
						car_q[car_count].have = true;
						car_count++;
						had_car = false;
					if((ans<1000)&&(ans!=0))
						number_car++;
				}
			}
		}
		for(i=0;i<car_count;i++)
			if(car_q[i].have == false){
				car_q[i].x1 = 0;
				car_q[i].x2 = 0;
			}
			if(car_count >= 9)car_count = 0;
	return NULL;
	}

	BYTE* Checking_Speed(BYTE* pBuffer)
	{
	bool had_car=true,tmp_had=false;
	int x1,y1,x2,y2,x3,y3,x4,y4;
	int centerX,ans=0;
	int xx1,yy1,xx2,yy3;
	num_avg = 0;
	avg = 0;

	for(int i=m_linecheckX3;i<m_linecheckX4;i++){
		tmp_had = false;	
		if((pBuffer[(m_linecheckY3*lWidth*3)+(i*3)]==0)/*&&(!m_car)*/){
	//			m_car = true;
				x3 = i;
				x1 = x3;
				for(int ii=i;((pBuffer[(m_linecheckY3*lWidth*3)+(ii*3)]==0)
					&&(ii<m_linecheckX4));ii++);
				x4 = ii;
				x2 = x4;
				
				for(ii=m_linecheckY3;pBuffer[(ii*lWidth*3)+(i*3)]==0;ii--);
				y1 = ii;
				y2 = ii;
				
				for(ii=m_linecheckY3;pBuffer[(ii*lWidth*3)+(i*3)]==0;ii++);
				y3 = ii;
				y4 = y3;
				
				i = x4;
				
			for(ii=0;ii<=49;ii++){
				ans = ((abs(car[ii].pointX1-x1))+(abs(car[ii].pointX2-x2)));
				if(((ans<30)&&(car[ii].pointY1>=y1)&&(car[ii].pointY1<=y3))||(tmp_had)){
				//////////  unpush position in Q,it alive 
					had_car = true;
					tmp_had = true;
				}else{ // push position in Q 
					had_car = false;
				}
			}
				if(!had_car){ // push position in Q  // had new car on system
	//				test_debug = ans;
					test_debug = speed_tail;
					car[speed_tail].pointX1 = x1+1;
					car[speed_tail].pointY1 = y1+1;
					car[speed_tail].pointX2 = x2-1;
					car[speed_tail].pointY2 = y2+1;
					car[speed_tail].pointX3 = x3+1;
					car[speed_tail].pointY3 = y3-1;
					car[speed_tail].pointX4 = x4-1;
					car[speed_tail].pointY4 = y4-1;
					car[speed_tail].have = false;
					car[speed_tail].show_speed = false;
					car[speed_tail].num_show = 0;
	
					show_debug = speed_tail;
					_ftime64( &tstruct );
					car[speed_tail].milis = tstruct.millitm;
					car[speed_tail].time = (long)tstruct.time;
					speed_tail++;
					car[speed_tail].have = true;
					had_car = true;
				}
			}}  	

			for(i=0;i<49;i++){ //update position of except line check
				if((car[i].have == false)||(car[i].show_speed)){
				int width = abs(car[i].pointX2-car[i].pointX1);
				int hight = abs(car[i].pointY3-car[i].pointY1);
				centerX = (car[i].pointX2+car[i].pointX1)/2;
				for(xx1=centerX;((xx1>=(centerX-width))&&(xx1>1)&&
					(pBuffer[(car[i].pointY1*lWidth*3)+(xx1*3)]==0));xx1--);

				for(xx2=centerX;((xx2<=(centerX+width))&&(xx2<lWidth)&&
					(pBuffer[(car[i].pointY1*lWidth*3)+(xx2*3)]==0));xx2++);

				for(yy1=car[i].pointY1;((yy1>=(car[i].pointY1-hight))&&(yy1>1)&&
					(pBuffer[(yy1*lWidth*3)+((xx1+1)*3)]==0));yy1--);
					yy1++;

				for(yy3=car[i].pointY1;((yy3<=(car[i].pointY1+hight+9))&&(yy3<lHeight)&&
					(pBuffer[(yy3*lWidth*3)+((xx1+1)*3)]==0));yy3++);
					yy3--;
                
				if((xx1<1)||(xx2>lWidth)||(yy1<1)||(yy3>lHeight)){
					car[i].have = true;// to check line 12;
					car[i].pointX1 = 0;
					car[i].pointX2 = 0;
					car[i].pointX3 = 0;
					car[i].pointX4 = 0;
					car[i].pointY1 = 0;
					car[i].pointY2 = 0;
					car[i].pointY3 = 0;
					car[i].pointY4 = 0;
				}
				else{
					car[i].pointX1 = xx1;
					car[i].pointX2 = xx2;
					car[i].pointX3 = xx1;
					car[i].pointX4 = xx2;
					car[i].pointY1 = yy1;
					car[i].pointY2 = yy1;
					car[i].pointY3 = yy3;
					car[i].pointY4 = yy3;
				}
				
				if((yy1<m_linecheckY1)&&(!car[i].have)){
				car[i].have = true;// to check line 12;
				car[i].num_show = 0;
				car[i].show_speed = true;
					_ftime64( &tstruct );
					UINT mili = tstruct.millitm;
					double s = (long)tstruct.time;
					if(mili<car[i].milis){
						mili += 1000;
						s--;
                    }
					double tmp = ((double)mili/1000);
					s = (double)((double)(s - car[i].time)+tmp);
					int m = m_range+5;
					speed = (int)((3.6*m)/s);   //  15 m 
					car[i].speed = speed;
					show_debug1 = i;
				}
				if((car[i].show_speed)&&(car[i].num_show<=3)){
					car[i].num_show++;
					DisplayGrabBits((car[i].pointX1+car[i].pointX2)/2,car[i].pointY1,speed);
				if((car[i].num_show==3)){
					car[i].pointX1 = 0;
					car[i].pointX2 = 0;
					car[i].pointX3 = 0;
					car[i].pointX4 = 0;
					car[i].pointY1 = 0;
					car[i].pointY2 = 0;
					car[i].pointY3 = 0;
					car[i].pointY4 = 0;
					car[i].show_speed = false;
					car[i].num_show = 0;
					//car[i].speed = 0;
				}							 
				}
				}
           		if(car[i].speed>0){
					avg += car[i].speed;
					num_avg++;  }
				if(speed_tail == 49) speed_tail = 1;
			}
				
	return NULL;
	}

	void CopyBitmap(BYTE * pBuffer, long lBufferSize,int number)
	{	
		TCHAR m_szSnappedName[MAX_PATH];
        wsprintf( m_szSnappedName, TEXT("D:\\1\\test%4.4ld.bmp"),number );

        // increment bitmap number if user requested it
        // otherwise, we'll reuse the filename next time
//        if( pOwner->IsDlgButtonChecked( IDC_AUTOBUMP ) )
//          pOwner->m_nCapTimes++;

        // write out a BMP file
        //
        HANDLE hf = CreateFile(
			m_szSnappedName/*"c:/test.bmp"*/, GENERIC_WRITE, 0, NULL,
            CREATE_ALWAYS, NULL, NULL );

        if( hf == INVALID_HANDLE_VALUE )
            return ;

        // write out the file header
        //
        BITMAPFILEHEADER bfh;
        memset( &bfh, 0, sizeof( bfh ) );
        bfh.bfType = 'MB';
        bfh.bfSize = sizeof( bfh ) + lBufferSize + sizeof( BITMAPINFOHEADER );
        bfh.bfOffBits = sizeof( BITMAPINFOHEADER ) + sizeof( BITMAPFILEHEADER );

        DWORD dwWritten = 0;
        WriteFile( hf, &bfh, sizeof( bfh ), &dwWritten, NULL );

        // and the bitmap format
        //
        BITMAPINFOHEADER bih;
        memset( &bih, 0, sizeof( bih ) );
        bih.biSize = sizeof( bih );
        bih.biWidth = lWidth;
        bih.biHeight = lHeight;
        bih.biPlanes = 1;
        bih.biBitCount = 24;

        dwWritten = 0;
        WriteFile( hf, &bih, sizeof( bih ), &dwWritten, NULL );

        // and the bits themselves
        //
        dwWritten = 0;
        WriteFile( hf, pBuffer, lBufferSize, &dwWritten, NULL );
        CloseHandle( hf );
     //   bFileWritten = TRUE;

        // Display the bitmap bits on the dialog's preview window
    //    DisplayCapturedBits(pBuffer, &bih);

        // Save bitmap header for later use when repainting the window
    //    memcpy(&(cb.bih), &bih, sizeof(bih));        

        // show where it captured
        //
     //   pOwner->SetDlgItemText( IDC_SNAPNAME, m_ShortName );

        // Enable the 'View Still' button
    //    HWND hwndButton = NULL;
    //    pOwner->GetDlgItem( IDC_BUTTON_VIEWSTILL, &hwndButton );
    //    ::EnableWindow(hwndButton, TRUE);

        // play a snap sound
   /*     if (pOwner->IsDlgButtonChecked(IDC_PLAYSOUND))
        {
            TCHAR szSound[128];
            GetWindowsDirectory(szSound, 128);
            _tcscat(szSound, TEXT("\\media\\click.wav\0"));
            sndPlaySound(szSound, SND_ASYNC);
        }
	*/
	}
};

CSampleGrabberCB mCB;
CRecognize mRG;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

CStillCapDlg::CStillCapDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStillCapDlg::IDD, pParent)
	, m_cap(0)
	, m_show(0)
	, m_theshold(0)
	, m_dis_thres_inter(0)
	, m_dis_thres_edge(0)
	, m_dis_frame(0)
	, m_speed(0)
	, m_sele_config_value(FALSE)
{
	//{{AFX_DATA_INIT(CStillCapDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStillCapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStillCapDlg)
	DDX_Control(pDX, IDC_STATUS, m_StrStatus);
	DDX_Control(pDX, IDC_STILL, m_StillScreen);
	DDX_Control(pDX, IDC_PREVIEW, m_PreviewScreen);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_SNAPNAME, m_cap);
	DDX_Text(pDX, IDC_show, m_show);
	DDX_Control(pDX, IDC_sele_config, m_sele_config);
	DDX_Text(pDX, IDC_in_threshold, m_theshold);
	DDX_Text(pDX, IDC_dis_thres_inter, m_dis_thres_inter);
	DDX_Text(pDX, IDC_dis_thres_edge, m_dis_thres_edge);
	DDX_Text(pDX, IDC_dis_frame, m_dis_frame);
	DDX_Text(pDX, IDC_speed, m_speed);
	DDX_Control(pDX, IDC_spintreshold, m_spintreshold);
	DDX_Control(pDX, IDC_SPIN_frame, m_spin_frame);
	DDX_Control(pDX, IDC_SPIN_interframe, m_spin_interframe);
	DDX_Control(pDX, IDC_SPIN_edge1, m_spin_edge);
	DDX_Control(pDX, IDC_Config_next, m_config_next);
	DDX_Control(pDX, IDC_Config_back, m_config_back);
	DDX_Control(pDX, IDC_tresthold2, m_tresthold_control);
	DDX_Control(pDX, IDC_Config_default, m_config_default);
	DDX_Control(pDX, IDC_check_config, m_check_config);
	//	DDX_Check(pDX, IDC_check_config, m_sele_config_value);
	DDX_Control(pDX, IDC_threshold, m_repleace_config);
	DDX_Control(pDX, IDC_play, m_button_play);
}

BEGIN_MESSAGE_MAP(CStillCapDlg, CDialog)
	//{{AFX_MSG_MAP(CStillCapDlg)
	ON_WM_PAINT()
	ON_WM_SYSCOMMAND()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SNAP, OnSnap)
	ON_BN_CLICKED(IDC_CAPSTILLS, OnCapstills)
	ON_BN_CLICKED(IDC_CAPVID, OnCapvid)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_VIEWSTILL, OnButtonViewstill)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_Browse_avi, OnBnClickedBrowseavi)
	ON_BN_CLICKED(IDC_From_avi, OnBnClickedFromavi)
	ON_BN_CLICKED(IDC_play, OnBnClickedplay)
//	ON_BN_CLICKED(IDC_From_camera, OnBnClickedFromcamera)
	ON_BN_CLICKED(IDC_test, OnBnClickedtest)
	ON_BN_CLICKED(IDC_stop, OnBnClickedstop)
	ON_BN_CLICKED(IDC_check_config, OnBnClickedcheckconfig)
	ON_CBN_SELCHANGE(IDC_sele_config, OnCbnSelchangeseleconfig)
	ON_STN_CLICKED(IDC_PREVIEW, OnStnClickedPreview)
	ON_BN_CLICKED(IDC_threshold, OnBnClickedthreshold)
	ON_WM_VSCROLL() 
	ON_STN_CLICKED(IDC_SNAPNAME, OnStnClickedSnapname)
	ON_BN_CLICKED(IDC_Config_next, OnBnClickedConfignext)
	ON_BN_CLICKED(IDC_Config_back, OnBnClickedConfigback)
//	ON_CBN_SELCHANGE(IDC_sele_config, OnCbnSelchangeseleconfig)
ON_BN_CLICKED(IDC_Config_default, OnBnClickedConfigdefault)
ON_BN_CLICKED(IDC_reset, OnBnClickedreset)
ON_BN_CLICKED(IDC_From_avi1, OnBnClickedFromavi1)
ON_BN_CLICKED(IDC_From_camera, OnBnClickedFromcamera)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg message handlers

void CStillCapDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CStillCapDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

        // Update the bitmap preview window, if we have
        // already captured bitmap data
        mCB.DisplayCapturedBits(cb.pBuffer, &(cb.bih));
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStillCapDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CStillCapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
    // StillCap-specific initialization
    CoInitialize( NULL );

    // default to this capture directory
    //
    SetDlgItemText( IDC_CAPDIR, TEXT("c:\\") );

    // default to capturing stills
    //
    CheckDlgButton( IDC_CAPSTILLS, 1 );
    m_bCapStills = true;
    m_nCapState = 0;
    m_nCapTimes = 0;
    g_hwnd = GetSafeHwnd();

	frame_st = NULL;
	frame_nd = NULL;
	frame_rd = NULL;
	frame_tmp = NULL;
	frame_count = NULL;
	frame_region = NULL;

	running = false;
	number = 0;

	m_sele_config.AddString("Region");
	m_sele_config.AddString("Line Counting");
	m_sele_config.AddString("Line Checking Speed");
	m_sele_config.AddString("Inter Frame");
	m_sele_config.AddString("Edge Detection");
	m_sele_config.AddString("And");
	m_sele_config.AddString("Fillter");
	m_sele_config.AddString("Labeling");

	m_type_config = 0;
	m_currentx = 1;
	m_currenty = 1;
//	UpdateData(false);

	m_spintreshold.SetBuddy((CWnd *)GetDlgItem(IDC_tresthold2)); 
	m_spintreshold.SetRange(1,500);
	m_spintreshold.SetPos(0);

	m_spin_frame.SetBuddy((CWnd *)GetDlgItem(IDC_dis_frame1)); 
	m_spin_frame.SetRange(1,500);
	m_spin_frame.SetPos(0);

	m_spin_interframe.SetBuddy((CWnd *)GetDlgItem(IDC_dis_inter1));
	m_spin_interframe.SetRange(1,500);
	m_spin_interframe.SetPos(0);

	m_spin_edge.SetBuddy((CWnd *)GetDlgItem(IDC_dis_edge1));
	m_spin_edge.SetRange(1,500);
	m_spin_edge.SetPos(0);

	CString str;
	m_dis_frame = (int)1000/frame_delay;
	str.Format(_T("%d"),m_dis_frame);
	SetDlgItemText(IDC_dis_frame1,str);
	SetDlgItemText(IDC_tresthold2,str);

	str.Format(_T("%d"),theshold_inter);
	SetDlgItemText(IDC_dis_inter1,(LPCTSTR)str);

	str.Format(_T("%d"),theshold_edge);
	SetDlgItemText(IDC_dis_edge1,(LPCTSTR)str);

	m_sele_config.SetWindowText("Region");

	GetDlgItem(IDC_speed)->GetWindowRect(&m_rectStatic);
	ScreenToClient(&m_rectStatic);

	m_fontShow.CreateFont(25,0,0,0,FW_BOLD,FALSE,FALSE,0,
		DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,"MS Sans Serif");
	CStatic* fontBig_speed = (CStatic*)GetDlgItem(IDC_speed);
	CStatic* fontBig_count = (CStatic*)GetDlgItem(IDC_show);
	CStatic* fontBig_avg = (CStatic*)GetDlgItem(IDC_SNAPNAME);
	fontBig_speed->SetFont(&m_fontShow);
	fontBig_count->SetFont(&m_fontShow);
	fontBig_avg->SetFont(&m_fontShow);

	int tmp = (int)1000/frame_delay;
	refesh_dis(tmp,"Frame/Sec",true,true);
	OnBnClickedcheckconfig();
//	m_sele_config_value = true;
//	UpdateData(false);
//	m_sele_config_value = false;
	// Modify the window style of the capture and still windows
    // to prevent excessive repainting
    m_PreviewScreen.ModifyStyle(0, WS_CLIPCHILDREN);
    m_StillScreen.ModifyStyle(0, WS_CLIPCHILDREN);
	m_type_config = 0;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStillCapDlg::ClearGraphs( )
{		
    // Destroy capture graph
    if( m_pGraph )
    {
        // have to wait for the graphs to stop first
        //
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
        if( pControl ) 
            pControl->Stop( );

        // make the window go away before we release graph
        // or we'll leak memory/resources
        // 
        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }

#ifdef REGISTER_FILTERGRAPH
        // Remove filter graph from the running object table   
        if (g_dwGraphRegister)
            RemoveGraphFromRot(g_dwGraphRegister);
#endif

        m_pGraph.Release( );
        m_pGrabber.Release( );
//		pCap.Release();
		
    }

    // Destroy playback graph, if it exists
    if( m_pPlayGraph )
    {
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pPlayGraph;
        if( pControl ) 
            pControl->Stop( );

        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }
        m_pPlayGraph.Release( );
    }
//	AfxEndThread(1000);
}

HRESULT CStillCapDlg::InitStillGraph( )
{
    HRESULT hr;

    // create a filter graph
    //
    hr = m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error( TEXT("Could not create filter graph") );
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return E_FAIL;
    }

    // create a sample grabber
    //
    hr = m_pGrabber.CoCreateInstance( CLSID_SampleGrabber );
    if( !m_pGrabber )
    {
        Error( TEXT("Could not create SampleGrabber (is qedit.dll registered?)"));
        return hr;
    }
    CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabBase( m_pGrabber );

    // force it to connect to video, 24 bit
    //
    CMediaType VideoType;
    VideoType.SetType( &MEDIATYPE_Video );
    VideoType.SetSubtype( &MEDIASUBTYPE_RGB24 );
    hr = m_pGrabber->SetMediaType( &VideoType ); // shouldn't fail
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set media type"));
        return hr;
    }

    // add the grabber to the graph
    //
    hr = m_pGraph->AddFilter( pGrabBase, L"Grabber" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put sample grabber in graph"));
        return hr;
    }

    // find the two pins and connect them
    //
    IPin * pCapOut = GetOutPin( pCap, 0 );
    IPin * pGrabIn = GetInPin( pGrabBase, 0 );
    hr = m_pGraph->Connect( pCapOut, pGrabIn );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin #0 to grabber.\r\n")
               TEXT("Is the capture device being used by another application?"));
        return hr;
    }

    // render the sample grabber output pin, so we get a preview window
    //
    IPin * pGrabOut = GetOutPin( pGrabBase, 0 );
//	hr = m_pGraph->RenderFile(L"C:\\example.avi", NULL); 
	hr = m_pGraph->Render( pGrabOut );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render sample grabber output pin"));
        return hr;
    }

    // ask for the connection media type so we know how big
    // it is, so we can write out bitmaps
    //
    AM_MEDIA_TYPE mt;
    hr = m_pGrabber->GetConnectedMediaType( &mt );
    if ( FAILED( hr) )
    {
        Error( TEXT("Could not read the connected media type"));
        return hr;
    }
    
    VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mt.pbFormat;
    mCB.pOwner = this;
    mCB.lWidth  = vih->bmiHeader.biWidth;
    mCB.lHeight = vih->bmiHeader.biHeight;
	mRG.pOwner  = this;
	mRG.lWidth  = vih->bmiHeader.biWidth;
	mRG.lHeight = vih->bmiHeader.biHeight;

    FreeMediaType( mt );
	
    // don't buffer the samples as they pass through
    //
    m_pGrabber->SetBufferSamples( FALSE );

    // only grab one at a time, stop stream after
    // grabbing one sample
    //
    m_pGrabber->SetOneShot( FALSE );

    // set the callback, so we can grab the one sample
    //
    m_pGrabber->SetCallback( &mCB, 1 );

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_PREVIEW, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // Add our graph to the running object table, which will allow
    // the GraphEdit application to "spy" on our graph
#ifdef REGISTER_FILTERGRAPH
    hr = AddGraphToRot(m_pGraph, &g_dwGraphRegister);
    if (FAILED(hr))
    {
        Error(TEXT("Failed to register filter graph with ROT!"));
        g_dwGraphRegister = 0;
    }
#endif

    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

    UpdateStatus(_T("Previewing Live Video"));
    return 0;
}

HRESULT CStillCapDlg::InitCaptureGraph( TCHAR * pFilename )
{
    HRESULT hr;

    // make a filter graph
    //
    m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error(TEXT("Could not create filter graph"));
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return hr;
    }

    // make a capture builder graph (for connecting help)
    //
    CComPtr< ICaptureGraphBuilder2 > pBuilder;
    hr = pBuilder.CoCreateInstance( CLSID_CaptureGraphBuilder2 );
    if( !pBuilder )
    {
        Error( TEXT("Could not create capture graph builder2"));
        return hr;
    }

    hr = pBuilder->SetFiltergraph( m_pGraph );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set filtergraph on graphbuilder2"));
        return hr;
    }

    CComPtr< IBaseFilter > pMux;
    CComPtr< IFileSinkFilter > pSink;
    USES_CONVERSION;

    hr = pBuilder->SetOutputFileName( &MEDIASUBTYPE_Avi,
        T2W( pFilename ),
        &pMux,
        &pSink );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not create/hookup mux and writer"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_CAPTURE,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        pMux );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_PREVIEW,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        NULL );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render capture pin"));
        return hr;
    }
    if( hr == VFW_S_NOPREVIEWPIN )
    {
        // preview was faked up using the capture pin, so we can't
        // turn capture on and off at will.
        hr = 0;
    }

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return hr;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_PREVIEW, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

    UpdateStatus(_T("Capturing Video To Disk"));
    return 0;
}

HRESULT CStillCapDlg::InitPlaybackGraph( TCHAR * pFilename )
{
    m_pPlayGraph.CoCreateInstance( CLSID_FilterGraph );
    USES_CONVERSION;

    HRESULT hr = m_pPlayGraph->RenderFile( T2W( pFilename ), NULL );
    if (FAILED(hr))
        return hr;

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_STILL, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );

    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl;
    pControl = m_pPlayGraph;

    // Play back the recorded video
    pControl->Run( );
    UpdateStatus(_T("Playing Back Recorded Video"));
    return 0;
}

void CStillCapDlg::GetDefaultCapDevice( IBaseFilter ** ppCap )
{
    HRESULT hr;

    *ppCap = NULL;

    // create an enumerator
    //
    CComPtr< ICreateDevEnum > pCreateDevEnum;
    pCreateDevEnum.CoCreateInstance( CLSID_SystemDeviceEnum );
    if( !pCreateDevEnum )
        return;

    // enumerate video capture devices
    //
    CComPtr< IEnumMoniker > pEm;
    pCreateDevEnum->CreateClassEnumerator( CLSID_VideoInputDeviceCategory, &pEm, 0 );
    if( !pEm )
        return;

    pEm->Reset( );
 
    // go through and find first video capture device
    //
    while( 1 )
    {
        ULONG ulFetched = 0;
        CComPtr< IMoniker > pM;
        hr = pEm->Next( 1, &pM, &ulFetched );
        if( hr != S_OK )
            break;

        // get the property bag interface from the moniker
        //
        CComPtr< IPropertyBag > pBag;
        hr = pM->BindToStorage( 0, 0, IID_IPropertyBag, (void**) &pBag );
        if( hr != S_OK )
            continue;

        // ask for the english-readable name
        //
        CComVariant var;
        var.vt = VT_BSTR;
        hr = pBag->Read( L"FriendlyName", &var, NULL );
        if( hr != S_OK )
            continue;

        // set it in our UI
        //
        USES_CONVERSION;
        SetDlgItemText( IDC_CAPOBJ, W2T( var.bstrVal ) );

        // ask for the actual filter
        //
        hr = pM->BindToObject( 0, 0, IID_IBaseFilter, (void**) ppCap );
        if( *ppCap )
            break;
    }

    return;
}

void CStillCapDlg::OnSnap() 
{
    CString CapDir;
    GetDlgItemText( IDC_CAPDIR, CapDir );

    // Snap a still picture?
    if( m_bCapStills )
    {
        _tcscpy( mCB.m_szCapDir, CapDir );
        g_bOneShot = TRUE;
    }

    // Start capturing video
    else
    {
        if( m_nCapState == 0 )
        {
            if( IsDlgButtonChecked( IDC_AUTOBUMP ) )
                m_nCapTimes++;
        }

        // Determine AVI filename
        TCHAR szFilename[MAX_PATH], szFile[MAX_PATH];
        wsprintf( szFilename, TEXT("%sStillCap%04d.avi"), CapDir, m_nCapTimes );
        wsprintf( szFile, TEXT("StillCap%04d.avi"), m_nCapTimes );

        // start capturing, show playing button
        //
        if( m_nCapState == 0 )
        {
            ClearGraphs( );
            InitCaptureGraph( szFilename );
            SetDlgItemText( IDC_SNAP, TEXT("&Start Playback"));
            m_nCapState = 1;
        }
        else if( m_nCapState == 1 )
        {
            // show us where it captured to
            //
            SetDlgItemText( IDC_SNAPNAME, szFile );

            ClearGraphs( );
            InitPlaybackGraph( szFilename );
            SetDlgItemText( IDC_SNAP, TEXT("&Start Capture"));
            m_nCapState = 0;
        }
    }
}

BOOL CStillCapDlg::DestroyWindow() 
{
    ClearGraphs( );

    return CDialog::DestroyWindow();
}

void CStillCapDlg::Error( TCHAR * pText )
{
    GetDlgItem( IDC_SNAP )->EnableWindow( FALSE );
    ::MessageBox( NULL, pText, TEXT("Error!"), MB_OK | MB_TASKMODAL | MB_SETFOREGROUND );
}

void CStillCapDlg::OnCapstills() 
{
    if( m_bCapStills )
        return;

    SetDlgItemText( IDC_SNAP, TEXT("&Snap Still"));
    m_bCapStills = true;

    ClearGraphs( );
    InitStillGraph( );

    // Update the bitmap preview window, if we have
    // already captured bitmap data
    mCB.DisplayCapturedBits(cb.pBuffer, &(cb.bih));
}

void CStillCapDlg::OnCapvid() 
{
    if( !m_bCapStills )
        return;

    ClearGraphs( );
    m_bCapStills = false;
    m_nCapState = 0;

    // use OnSnap to set the UI state and the graphs
    //
    OnSnap( );
}

void CStillCapDlg::OnButtonReset() 
{
    // Reset bitmap counter to reset at zero
	for(int i=0;i<50;i++)car[i].speed = 0;
    m_nCapTimes = 0;
	number_car = 0;
	m_show = 0;
	m_speed = 0;
	speed = 0;
	UpdateData(false);
}

void CStillCapDlg::OnButtonViewstill() 
{
    // Open the bitmap with the system-default application
    ShellExecute(this->GetSafeHwnd(), TEXT("open\0"), mCB.m_szSnappedName, 
                 NULL, NULL, SW_SHOWNORMAL);
}

void CStillCapDlg::UpdateStatus(TCHAR *szStatus)
{
    m_StrStatus.SetWindowText(szStatus);
}	

LRESULT CStillCapDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{	
    // Field the message posted by our SampleGrabber callback function.
	if (message == WM_CAPTURE_BITMAP){
		g_bOneShot = false;
		//Frame_Sequence();
		Auto_Recognize();
		g_bCaptured = true;
	}
	if(message == WM_RECOGNIZE)
		Frame_Sequence();

	if(message == WM_LBUTTONDOWN   ){
		int currentX = LOWORD(lParam);
		int currentY = HIWORD(lParam);
		if ((currentX >= 266)&&(currentX<=445)&&(currentY>=122)&&(currentY<=267))
		{	
		  m_currentx = (int)((currentX-265)*16)/9;
		  m_currenty = (int)((145-(currentY-121))*8)/5;
		region_click = true;
		}
		}

	return CDialog::WindowProc(message, wParam, lParam);
}

void CStillCapDlg::OnClose() 
{
    // Free the memory allocated for our bitmap data buffer
    if (cb.pBuffer != 0)
    {
        delete cb.pBuffer;
        cb.pBuffer = 0;
    }
	if (frame_region != 0) delete frame_region;	
	CDialog::OnClose();
}

HRESULT CStillCapDlg::InitStillGraphAVI(void)
{
  HRESULT hr;

    // create a filter graph
    //
  ::CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, 
								    IID_IGraphBuilder, (void**)&m_pGraph);
   // hr = m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error( TEXT("Could not create filter graph") );
        return E_FAIL;
    }
		ASSERT(m_pGraph != NULL);

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    //GetDefaultCapDevice( &pCap );
	::CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC_SERVER, 
		    IID_IBaseFilter, (LPVOID *)&pCap);
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }
	pCap->QueryInterface(IID_ISampleGrabber, (void**)&m_pGrabber);

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return E_FAIL;
    }

    // create a sample grabber
    //
/*    hr = m_pGrabber.CoCreateInstance( CLSID_SampleGrabber );
    if( !m_pGrabber )
    {
        Error( TEXT("Could not create SampleGrabber (is qedit.dll registered?)"));
        return hr;
    }
    CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabBase( m_pGrabber );
*/
    // force it to connect to video, 24 bit
    //
    CMediaType VideoType;
    VideoType.SetType( &MEDIATYPE_Video );
    VideoType.SetSubtype( &MEDIASUBTYPE_RGB24 );
    hr = m_pGrabber->SetMediaType( &VideoType ); // shouldn't fail
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set media type"));
        return hr;
    }
	  
    // add the grabber to the graph
    //
/*    hr = m_pGraph->AddFilter( pGrabBase, L"Grabber" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put sample grabber in graph"));
        return hr;
    }
*/
    // find the two pins and connect them
    //
/*   IPin * pCapOut = GetOutPin( pCap, 0 );
    IPin * pGrabIn = GetInPin( pGrabBase, 0 );
    hr = m_pGraph->Connect( pCapOut, pGrabIn );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin #0 to grabber.\r\n")
               TEXT("Is the capture device being used by another application?"));
        return hr;
    }

    // render the sample grabber output pin, so we get a preview window
    //
    IPin * pGrabOut = GetOutPin( pGrabBase, 0 );
*/	
	
//	hr = m_pGraph->RenderFile(L"C:\\example.avi", NULL); 
	hr = m_pGraph->RenderFile(wstrMediaFile, NULL);
		//	hr = m_pGraph->Render( pGrabOut );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render sample grabber output pin"));
        return hr;
    }
//	   pEvent->SetNotifyWindow(NULL, 0, 0);
    // ask for the connection media type so we know how big
    // it is, so we can write out bitmaps
    //
    AM_MEDIA_TYPE mt;
    hr = m_pGrabber->GetConnectedMediaType( &mt );
    if ( FAILED( hr) )
    {
        Error( TEXT("Could not read the connected media type"));
        return hr;
    }
    
    VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mt.pbFormat;
    mCB.pOwner  = this;
    mCB.lWidth  = vih->bmiHeader.biWidth;
    mCB.lHeight = vih->bmiHeader.biHeight;
	mRG.pOwner  = this;
	mRG.lWidth  = vih->bmiHeader.biWidth;
	mRG.lHeight = vih->bmiHeader.biHeight;

    FreeMediaType( mt );

    // don't buffer the samples as they pass through
    //
    m_pGrabber->SetBufferSamples( FALSE );

    // only grab one at a time, stop stream after
    // grabbing one sample
    //
    m_pGrabber->SetOneShot( FALSE );

    // set the callback, so we can grab the one sample
    //
    m_pGrabber->SetCallback( &mCB, 1 );

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_PREVIEW, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
   
    // Add our graph to the running object table, which will allow
    // the GraphEdit application to "spy" on our graph
#ifdef REGISTER_FILTERGRAPH
    hr = AddGraphToRot(m_pGraph, &g_dwGraphRegister);
    if (FAILED(hr))
    {
        Error(TEXT("Failed to register filter graph with ROT!"));
        g_dwGraphRegister = 0;
    }
#endif

    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

    UpdateStatus(_T("Previewing Live Video"));
    return 0;
}

void CStillCapDlg::OnBnClickedBrowseavi()
{
 	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Movie Files (*.avi;*.mpg;*.mpeg)|*.avi;*.mpg;*.mpeg|Audio Files (*.wav;*mp3;*.mpa;*.mpu;*.au)|*.wav;*.mp3;*.mpa;*.mpu;*.au|Midi Files (*.mid;*.midi;*.rmi)|*.mid;*.midi;*.rmi||", this);

	if(dlgFile.DoModal() == IDOK)
	{
		m_strMediaFile  = dlgFile.GetPathName();
	}
	else
		return ;
}

void CStillCapDlg::OnBnClickedFromavi()
{
	m_sele_avi = true;
	m_sele_camera = false;
}

//void CStillCapDlg::OnBnClickedFromcamera()
//{
//	m_sele_avi = false;
//	m_sele_camera = true;
//}

void CStillCapDlg::OnBnClickedplay()
{	 ClearGraphs();
	running = true;
//if (Thread_autorun != NULL)Thread_autorun->Delete();
	if (m_sele_avi)
	{	USES_CONVERSION;
		wstrMediaFile = A2W(m_strMediaFile);
		HRESULT hr = InitStillGraphAVI( );
		  if (FAILED(hr))
			Error( TEXT("Failed to initialize StillGraph!"));
	}else if(m_sele_camera)
	{	 HRESULT hr = InitStillGraph( );
		  if (FAILED(hr))
			Error( TEXT("Failed to initialize StillGraph!"));
	}
	stop = false;
	OnBnClickedtest();
}


void CStillCapDlg::OnBnClickedtest()
{
//    CString CapDir;
    
//	GetDlgItemText( IDC_CAPDIR, CapDir );

//	_tcscpy( mCB.m_szCapDir,CapDir);
   // AfxBeginThread(thread_grab, this);
	running = true;  
	Thread_cap = AfxBeginThread(run,this);
	//thread_grap();
	//        g_bOneShot = TRUE;
}

UINT CStillCapDlg::run(LPVOID p)
{
	CStillCapDlg * me = (CStillCapDlg *)p;
     me->run();
	return 0;
}

void CStillCapDlg::run()
{
	while (running){
		g_bOneShot = true;
		g_bCaptured = false;
		int	remain_delay = frame_delay;
		while((g_bCaptured != TRUE)&&(remain_delay> -1000)){
			Sleep(20);
			remain_delay -= 20;
		}
		if(remain_delay > 0 ) 
			Sleep(remain_delay);	
		if(reset_cap){
			reset_cap = false;
//			m_button_play.EnableWindow();
			AfxEndThread(0);
		}

	}
//	g_bCaptured = false;
}

void CStillCapDlg::thread_grab()
{
/*while(running){

	g_bOneShot = TRUE;
	Sleep(10);
	g_bOneShot = FALSE;
	Sleep(15);
}
*/}

UINT CStillCapDlg::thread_grab(LPVOID p)
{	     
/*	CStillCapDlg * me = (CStillCapDlg *)p;
     me->thread_grab();
*/    return 0;
}

void CStillCapDlg::OnBnClickedstop()
{
	DestroyWindow();
}

void CStillCapDlg::Auto_Recognize(void)
{
	if(m_running)return;
	m_running = true;
	Thread_autorun = AfxBeginThread(run_auto_recognize,this);
}

UINT CStillCapDlg::run_auto_recognize(LPVOID p)
{
	CStillCapDlg* me= (CStillCapDlg*) p;
	me->run_auto_recognize();
	return 0;
}

void CStillCapDlg::run_auto_recognize()
{
	PostMessage(WM_RECOGNIZE,0,0L);
	m_running = false;
}

void CStillCapDlg::auto_control(void)
{
	//AfxBeginThread();
}


void CStillCapDlg::OnBnClickedcheckconfig()
{
	if(IsDlgButtonChecked(IDC_check_config)) {
		config = true;
		m_config_back.EnableWindow();
		m_config_next.EnableWindow();
		m_config_default.EnableWindow();
		m_repleace_config.EnableWindow();
		m_sele_config.EnableWindow();
//		m_sele_config_value = true;
	}
	else {
		config = false;
		m_config_back.EnableWindow(false);
		m_config_next.EnableWindow(false);
		m_config_default.EnableWindow(false);
		m_repleace_config.EnableWindow(false);
		m_sele_config.EnableWindow(false);
		m_type_config = 7;
//		m_sele_config_value = false;
	}
	
}

void CStillCapDlg::OnCbnSelchangeseleconfig()
{
	CString Str;
	int tmp;
	int nCurrentSelected = m_sele_config.GetCurSel();
//
	if(nCurrentSelected == LB_ERR)
		MessageBox("no");
	else
	{
		m_sele_config.GetLBText(nCurrentSelected,Str);
		if(StrCmp(Str,"Region")==0){
			m_type_config = 0;
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;
 m_regionX3=0,m_regionX4=1,m_regionY3=0,m_regionY4=1;

 			tmp = (int)1000/frame_delay;
			refesh_dis(tmp,"Frame/Sec",true,true);	

		}
		else if(StrCmp(Str,"Line Counting")==0){
			m_type_config = 1;
			region1 = false;
			region2 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;

			refesh_dis(0,"",false,false);	
		}
		else if(StrCmp(Str,"Line Checking Speed")==0){
			m_type_config = 2;
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;
			tmp = m_range;
			refesh_dis(tmp,"Range",true,true);	
		}
		else if(StrCmp(Str,"Inter Frame")==0){
			m_type_config = 3;
			tmp = theshold_inter;
			refesh_dis(tmp,"Treshold",true,true);	
		}
		else if(StrCmp(Str,"Edge Detection")==0){
			m_type_config = 4;
			tmp = theshold_edge;
			refesh_dis(tmp,"Treshold",true,true);	
		}
		else if(StrCmp(Str,"And")==0){
			m_type_config = 5;
			refesh_dis(0,"",false,false);	
		}
		else if(StrCmp(Str,"Fillter")==0){
			m_type_config = 6;
			refesh_dis(0,"",false,false);	
		}
		else if(StrCmp(Str,"Labeling")==0){
			m_type_config = 7;
			refesh_dis(0,"",false,false);	
		}
	}
}

bool CStillCapDlg::Frame_Sequence()
{
	mRG.Make_Information(cb.lBufferSize);
	if (frame_st == NULL) {
		frame_st = new BYTE[cb.lBufferSize];
		memcpy(frame_st, cb.pBuffer , cb.lBufferSize);
	}
	if (frame_nd == NULL) {
		frame_nd = new BYTE[cb.lBufferSize];
		memcpy(frame_nd, cb.pBuffer , cb.lBufferSize);
	}
	if (frame_rd == NULL) frame_rd = new BYTE[cb.lBufferSize];

	memcpy(frame_rd, frame_nd , cb.lBufferSize);
	memcpy(frame_nd, frame_st , cb.lBufferSize);
	memcpy(frame_st, cb.pBuffer, cb.lBufferSize);
	
	frame_st = mRG.ConvertBW(frame_st);
	frame_nd = mRG.ConvertBW(frame_nd);
	frame_rd = mRG.ConvertBW(frame_rd);

	frame_Inter = new BYTE[cb.lBufferSize];
	frame_Edge = new BYTE[cb.lBufferSize];
	frame_Inter_Edge = new BYTE[cb.lBufferSize];
	frame_tmp = new BYTE[cb.lBufferSize];
	frame_Fillter = new BYTE[cb.lBufferSize];
	frame_Label = new BYTE[cb.lBufferSize];
	frame_count = new BYTE[cb.lBufferSize];
	frame_dis = new BYTE[cb.lBufferSize];

	if (frame_region == NULL)	frame_region = new BYTE[cb.lBufferSize];

/*
		0 = Region
		1 = Line Counting
		2 = Line Checking Speed		
		3 = Inter Frame
		4 = Edge Frame
		5 = And
		6 = Fillter
		7 = Label
*/
	switch(m_type_config){			
		case 0:{				// Region
			if(region_click){
			if((!region1)&&(!region2)&&(!region3)&&(!region4)){
				m_regionX1 = m_currentx;
				m_regionY1 = m_currenty;
				region1 = true;
				m_show = 1;
				UpdateData(false);
			}else if((region1)&&(!region2)&&(!region3)&&(!region4)){
				m_regionX3 = m_currentx;
				m_regionY3 = m_regionY1;
				region2 = true;
			for(int j=0; j<(mRG.lHeight-W_SIZE); j++)//j+=W_SIZE) 
			for(int i=0; i<(mRG.lWidth-W_SIZE); i++){//i+=W_SIZE){
			frame_region[(j*mRG.lWidth*3)+(i*3)] = 255;
			frame_region[(j*mRG.lWidth*3)+(i*3)+1] = 255;
			frame_region[(j*mRG.lWidth*3)+(i*3)+2] = 255;
		}
				m_show = 2;
				UpdateData(false);
			}else if((region1)&&(region2)&&(!region3)&&(!region4)){
				m_regionX2 = m_currentx;
				m_regionY2 = m_currenty;
				region3 = true;
				m_show = 3;
				UpdateData(false);
			}else if((region1)&&(region2)&&(region3)&&(!region4)){
				m_regionX4 = m_currentx;
				m_regionY4 = m_regionY2;
				region4 = true;
				m_show = 4;
				UpdateData(false);
			}
			else if((region1)&&(region2)&&(region3)&&(region4)){
				m_regionX1 = m_currentx;
				m_regionY1 = m_currenty;
				region1 = true;
				region2 = false;
				region3 = false;
				region4 = false;
				m_show = 1;
				UpdateData(false);
			}
			region_click = false;
			}
		if((region1)&&(region2)&&(region3)&&(region4)){
			double m1 = (double)(m_regionY2 - m_regionY1)/(m_regionX2 - m_regionX1);
			double m2 = (double)(m_regionY4 - m_regionY3)/(m_regionX4 - m_regionX3);
			for(int j=1;j<=mRG.lHeight;j++)
				if((j>=m_regionY1)&&(j<=m_regionY2)){
					int x1 = (int)(m_regionX2 - ((m_regionY2-j)/m1));
					int x2 = (int)(m_regionX4 - ((m_regionY4-j)/m2));
					for(int i=x1;i<=x2;i++){
					//if((j==m_regionY1)||(j==m_regionY2)||(i==x1)||(i==x2)){
						cb.pBuffer[(j*mRG.lWidth*3)+(i*3)] = 0;
						cb.pBuffer[(j*mRG.lWidth*3)+(i*3)+1] = 0;
						cb.pBuffer[(j*mRG.lWidth*3)+(i*3)+2] = 255;

						frame_region[(j*mRG.lWidth*3)+(i*3)]=0;
						frame_region[(j*mRG.lWidth*3)+(i*3)+1]=0;
						frame_region[(j*mRG.lWidth*3)+(i*3)+2]=0;
				}}}
//				mRG.CopyBitmap(cb.pBuffer,cb.lBufferSize,number);
				mRG.DisplayGrabBits(cb.pBuffer);
				break;
			   }

		case 1:{			// Line Counting
			if(region_click){
			if((!region1)&&(!region2)){
				m_linecountX1 = m_currentx;
				m_linecountY1 = m_currenty;
				region1 = true;
				m_show = 1;
				UpdateData(false);

			}else if((region1)&&(!region2)){
				m_linecountX2 = m_currentx;
				m_linecountY2 = m_linecountY1;
				region2 = true;
				m_show = 2;
				UpdateData(false);
			}
			else if((region1)&&(region2)){
				m_linecountX1 = m_currentx;
				m_linecountY1 = m_currenty;
				region1 = true;
				region2 = false;
				m_show = 1;
				UpdateData(false);
			}
			region_click = false;
			}
			if((region1)&&(region2))
				for(int ij=m_linecountX1;ij<=m_linecountX2;ij++){
					cb.pBuffer[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)] = 0;
					cb.pBuffer[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)+2] = 255;
					cb.pBuffer[(m_linecountY1*mRG.lWidth*3)+(ij*3)] = 0;
					cb.pBuffer[(m_linecountY1*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[(m_linecountY1*mRG.lWidth*3)+(ij*3)+2] = 255;
					cb.pBuffer[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)] = 0;
					cb.pBuffer[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)+2] = 255;
			}  
//			mRG.CopyBitmap(cb.pBuffer,cb.lBufferSize,number);
			mRG.DisplayGrabBits(cb.pBuffer);
			break;			   
			   }

		case 2:{			// Line Checking
			if(region_click){
			if((!region1)&&(!region2)&&(!region3)&&(!region4)){
				m_linecheckX1 = m_currentx;
				m_linecheckY1 = m_currenty;
				m_show = 1;
				UpdateData(false);
				region1 = true;
			}else if((region1)&&(!region2)&&(!region3)&&(!region4)){
				m_linecheckX2 = m_currentx;
				m_linecheckY2 = m_linecheckY1;
				m_show = 2;
				UpdateData(false);
				region2 = true;
			}else if((region1)&&(region2)&&(!region3)&&(!region4)){
				m_linecheckX3 = m_currentx;
				m_linecheckY3 = m_currenty;
				m_show = 3;
				UpdateData(false);
				region3 = true;
			}else if((region1)&&(region2)&&(region3)&&(!region4)){
				m_linecheckX4 = m_currentx;
				m_linecheckY4 = m_linecheckY3;
				m_show = 4;
				UpdateData(false);
				region4 = true;
			}
			else if((region1)&&(region2)&&(region3)&&(region4)){
				m_linecheckX1 = m_currentx;
				m_linecheckY1 = m_currenty;
				region1 = true;
				region2 = false;
				region3 = false;
				region4 = false;
				m_show = 1;
				UpdateData(false);
			}
			region_click = false;
			}

			if((region1)&&(region2))
				for(int ij=m_linecheckX1;ij<=m_linecheckX2;ij++){
					cb.pBuffer[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)+1] = 255;
					cb.pBuffer[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)+2] = 0;
					cb.pBuffer[(m_linecheckY1*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[(m_linecheckY1*mRG.lWidth*3)+(ij*3)+1] = 255;
					cb.pBuffer[(m_linecheckY1*mRG.lWidth*3)+(ij*3)+2] = 0;
					cb.pBuffer[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)+1] = 255;
					cb.pBuffer[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)+2] = 0;
			}
			if((region3)&&(region4))
				for(int ij=m_linecheckX3;ij<=m_linecheckX4;ij++){
					cb.pBuffer[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)+2] = 0;
					cb.pBuffer[(m_linecheckY3*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[(m_linecheckY3*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[(m_linecheckY3*mRG.lWidth*3)+(ij*3)+2] = 0;
					cb.pBuffer[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)] = 255;
					cb.pBuffer[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					cb.pBuffer[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)+2] = 0;
			}  
//			mRG.CopyBitmap(cb.pBuffer,cb.lBufferSize,number);
			mRG.DisplayGrabBits(cb.pBuffer);

				break;			   
			   }

		case 3:{			// Interframe
			if(region_click){
			if((!region1)&&(!region2)&&(!region3)&&(!region4)){
				m_regionX1 = m_currentx;
				m_regionY1 = m_currenty;
				region1 = true;
			}else if((region1)&&(!region2)&&(!region3)&&(!region4)){
				m_regionX2 = m_currentx;
				m_regionY2 = m_currenty;
				region2 = true;
			}else if((region1)&&(region2)&&(!region3)&&(!region4)){
				m_regionX3 = m_currentx;
				m_regionY3 = m_regionY1;
				region3 = true;
			}else if((region1)&&(region2)&&(region3)&&(!region4)){
				m_regionX4 = m_currentx;
				m_regionY4 = m_regionY2;
				region4 = true;
			}
			else if((region1)&&(region2)&&(region3)&&(region4)){
				m_regionX1 = m_currentx;
				m_regionY1 = m_currenty;
				region1 = true;
				region2 = false;
				region3 = false;
				region4 = false;
			}
			region_click = false;
			}
  
			frame_tmp = mRG.InterFrame(frame_st,frame_nd,frame_rd,frame_tmp);
			memcpy(frame_Inter, frame_tmp, cb.lBufferSize);

//			mRG.CopyBitmap(frame_Inter,cb.lBufferSize,number);
			mRG.DisplayGrabBits(frame_Inter);
			break;}

		case 4:{			// Edge Detection
			frame_tmp = mRG.Edge_Detection(frame_nd,frame_tmp);
			memcpy(frame_Edge, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_Edge,cb.lBufferSize,number);
			mRG.DisplayGrabBits(frame_Edge);
			break;}

		case 5:{			// And
			frame_tmp = mRG.InterFrame(frame_st,frame_nd,frame_rd,frame_tmp);
			memcpy(frame_Inter, frame_tmp, cb.lBufferSize);

			frame_tmp = mRG.Edge_Detection(frame_nd,frame_tmp);
			memcpy(frame_Edge, frame_tmp, cb.lBufferSize);

			frame_tmp =	mRG.Inter_Edge(frame_Inter,frame_Edge,frame_tmp);
			memcpy(frame_Inter_Edge, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_Inter_Edge,cb.lBufferSize,number);
			mRG.DisplayGrabBits(frame_Inter_Edge);
			break;}

		case 6:{			// Filling
			frame_tmp = mRG.InterFrame(frame_st,frame_nd,frame_rd,frame_tmp);
			memcpy(frame_Inter, frame_tmp, cb.lBufferSize);

			frame_tmp = mRG.Edge_Detection(frame_nd,frame_tmp);
			memcpy(frame_Edge, frame_tmp, cb.lBufferSize);

			frame_tmp =	mRG.Inter_Edge(frame_Inter,frame_Edge,frame_tmp);
			memcpy(frame_Inter_Edge, frame_tmp, cb.lBufferSize);
 
			frame_tmp = mRG.Fillter(frame_Inter_Edge,frame_tmp);
			memcpy(frame_Fillter, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_Fillter,cb.lBufferSize,number);
			mRG.DisplayGrabBits(frame_Fillter);
			break;}

		case 7:{			// Label
			frame_tmp = mRG.InterFrame(frame_st,frame_nd,frame_rd,frame_tmp);
			memcpy(frame_Inter, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_tmp,cb.lBufferSize,number);
//			number++;

			frame_tmp = mRG.Edge_Detection(frame_nd,frame_tmp);
			memcpy(frame_Edge, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_tmp,cb.lBufferSize,number);
//			number++;

			frame_tmp =	mRG.Inter_Edge(frame_Inter,frame_Edge,frame_tmp);
			memcpy(frame_Inter_Edge, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_tmp,cb.lBufferSize,number);
//			number++;
 
			frame_tmp = mRG.Fillter(frame_Inter_Edge,frame_tmp);
			memcpy(frame_Fillter, frame_tmp, cb.lBufferSize);
//			mRG.CopyBitmap(frame_tmp,cb.lBufferSize,number);
//			number++;
	
			memcpy(frame_dis,cb.pBuffer,cb.lBufferSize);
			frame_tmp = mRG.Label(frame_Fillter,frame_tmp,frame_count,frame_dis);
//			mRG.CopyBitmap(frame_count,cb.lBufferSize,number);
//			number++;
	
			memcpy(frame_Label, frame_tmp, cb.lBufferSize);
			if(config)	memcpy(frame_tmp, frame_Label, cb.lBufferSize);
			else 		memcpy(frame_tmp,frame_dis, cb.lBufferSize);

			for(int ij=m_linecountX1;ij<=m_linecountX2;ij++){
					frame_tmp[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)] = 0;
					frame_tmp[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[((m_linecountY1-1)*mRG.lWidth*3)+(ij*3)+2] = 255;
					frame_tmp[(m_linecountY1*mRG.lWidth*3)+(ij*3)] = 0;
					frame_tmp[(m_linecountY1*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[(m_linecountY1*mRG.lWidth*3)+(ij*3)+2] = 255;
					frame_tmp[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)] = 0;
					frame_tmp[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[((m_linecountY1+1)*mRG.lWidth*3)+(ij*3)+2] = 255;
			}
			for(int ij=m_linecheckX1;ij<=m_linecheckX2;ij++){
					frame_tmp[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)+1] = 255;
					frame_tmp[((m_linecheckY1-1)*mRG.lWidth*3)+(ij*3)+2] = 0;
					frame_tmp[(m_linecheckY1*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[(m_linecheckY1*mRG.lWidth*3)+(ij*3)+1] = 255;
					frame_tmp[(m_linecheckY1*mRG.lWidth*3)+(ij*3)+2] = 0;
					frame_tmp[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)+1] = 255;
					frame_tmp[((m_linecheckY1+1)*mRG.lWidth*3)+(ij*3)+2] = 0;
			}
			for(int ij=m_linecheckX3;ij<=m_linecheckX4;ij++){
					frame_tmp[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[((m_linecheckY3-1)*mRG.lWidth*3)+(ij*3)+2] = 0;
					frame_tmp[(m_linecheckY3*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[(m_linecheckY3*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[(m_linecheckY3*mRG.lWidth*3)+(ij*3)+2] = 0;
					frame_tmp[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)] = 255;
					frame_tmp[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)+1] = 0;
					frame_tmp[((m_linecheckY3+1)*mRG.lWidth*3)+(ij*3)+2] = 0;
			}  
//			mRG.CopyBitmap(frame_tmp,cb.lBufferSize,number);
			mRG.DisplayGrabBits(frame_tmp);
			mRG.Counting(frame_count);
			mRG.Checking_Speed(frame_count);
			
			m_show = number_car;

			if(num_avg==0)m_cap = 0;
			else m_cap = avg/num_avg;//show_debug;
			
			if(show_debug == show_debug1 )	m_speed = speed;
			
			/***** test debug ******/
//				m_cap = test_debug;
				m_theshold = show_debug1;
			/***********************/
			UpdateData(FALSE);

			break;
			   }
	  }
	delete frame_tmp;
	delete frame_Inter;
	delete frame_Edge;
	delete frame_Inter_Edge;
	delete frame_Fillter;
	delete frame_Label;
	delete frame_count;
	delete frame_dis;

	number++;
	return TRUE;
}

void CStillCapDlg::OnStnClickedPreview()
{

}

void CStillCapDlg::OnBnClickedthreshold()
{	
	OnBnClickedConfigdefault();
}

void CStillCapDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{	CString str = "";
	if(m_spintreshold.m_hWnd==pScrollBar->m_hWnd){
		if(m_type_config==0){
			frame_delay = (int)1000/nPos;
			str.Format(_T("%d"),nPos);
			SetDlgItemText(IDC_dis_frame1,(LPCTSTR)str);
		}
		else if(m_type_config==2){
			m_range = nPos;
			str.Format(_T("%d"),m_range);
			//SetDlgItemText(IDC_dis_inter1,(LPCTSTR)str);
//			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);

		}
		else if(m_type_config==3){
			theshold_inter = nPos;
			str.Format(_T("%d"),theshold_inter);
			SetDlgItemText(IDC_dis_inter1,(LPCTSTR)str);
		}
		else if(m_type_config==4){
			theshold_edge = nPos;
			str.Format(_T("%d"),theshold_edge);
			SetDlgItemText(IDC_dis_edge1,(LPCTSTR)str);
		}
	}
	if(m_spin_frame.m_hWnd==pScrollBar->m_hWnd)			frame_delay = (int)1000/nPos;
	if(m_spin_interframe.m_hWnd==pScrollBar->m_hWnd)	theshold_inter = nPos;
	if(m_spin_edge.m_hWnd==pScrollBar->m_hWnd)			theshold_edge = nPos;

}

void CStillCapDlg::OnStnClickedSnapname()
{
	// TODO: Add your control notification handler code here
}

void CStillCapDlg::refesh_dis(int tmp, CString str1, bool spin, bool edit)
{
			CString str;
			str.Format(_T("%d"),tmp);
			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);
									
			SetDlgItemText(IDC_expain,(LPCSTR)str1);
			m_spintreshold.EnableWindow(spin);
			m_tresthold_control.EnableWindow(edit);
}

void CStillCapDlg::OnBnClickedConfignext()
{  	/*
		0 = Region
		1 = Line Counting
		2 = Line Checking Speed		
		3 = Inter Frame
		4 = Edge Frame
		5 = And
		6 = Fillter
		7 = Label
*/
	CString str;
	int tmp;
	if(m_type_config==7){
		m_type_config = 7;
		m_config_next.EnableWindow(false);
	}
	else{ m_type_config++;
		m_config_next.EnableWindow();
		m_config_back.EnableWindow();
	}
	switch (m_type_config){
		case 0:{
			m_sele_config.SetWindowText("Region");
			tmp = (int)1000/frame_delay;
			refesh_dis(tmp,"Frame/Sec",true,true);
			
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;
 m_regionX3=0,m_regionX4=1,m_regionY3=0,m_regionY4=1;
			break;}
		case 1:{
			m_sele_config.SetWindowText("Line Counting");
			refesh_dis(0,"",false,false);

			region1 = false;
			region2 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;
			break;}
		case 2:{
			m_sele_config.SetWindowText("Line Checking Speed");
			tmp = m_range;
			refesh_dis(tmp,"Range",true,true);			
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;

			break;}
		case 3:{
			m_sele_config.SetWindowText("Inter Frame");
			tmp = theshold_inter;
			refesh_dis(tmp,"Treshold",true,true);			
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;

			break;}
		case 4:{
			m_sele_config.SetWindowText("Edge Frame");
			tmp = theshold_edge;
			refesh_dis(tmp,"Treshold",true,true);			
			break;}
		case 5:{
			m_sele_config.SetWindowText("And");
			refesh_dis(0,"",false,false);			
			break;}
		case 6:{
			m_sele_config.SetWindowText("Fillter");
			refesh_dis(0,"",false,false);			
			break;}
		case 7:{
			m_sele_config.SetWindowText("Label");
			refesh_dis(0,"",false,false);			
			break;}
	}
}

void CStillCapDlg::OnBnClickedConfigback()
{	CString str;
	int tmp;

	if(m_type_config==0){
		m_type_config = 0;
		m_config_back.EnableWindow(false);
	}
	else{
		m_type_config--;
		m_config_next.EnableWindow();
		m_config_back.EnableWindow();
	}
	switch (m_type_config){
		case 0:{
			m_sele_config.SetWindowText("Region");
			tmp = (int)1000/frame_delay;
			refesh_dis(tmp,"Frame/Sec",true,true);	
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;
 m_regionX3=0,m_regionX4=1,m_regionY3=0,m_regionY4=1;

			break;}
		case 1:{
			m_sele_config.SetWindowText("Line Counting");
			refesh_dis(0,"",false,false);	
			region1 = false;
			region2 = false;
 m_regionX1=0,m_regionX2=1,m_regionY1=0,m_regionY2=1;

			break;}
		case 2:{
			m_sele_config.SetWindowText("Line Checking Speed");
			region1 = false;
			region2 = false;
			region3 = false;
			region4 = false;
			tmp = m_range;
			refesh_dis(tmp,"Range",true,true);	
			break;}
		case 3:{
			m_sele_config.SetWindowText("Inter Frame");
			tmp = theshold_inter;
			refesh_dis(tmp,"Treshold",true,true);	
			break;}
		case 4:{
			m_sele_config.SetWindowText("Edge Frame");
			tmp = theshold_edge;
			refesh_dis(tmp,"Theshold",true,true);	
			break;}
		case 5:{
			m_sele_config.SetWindowText("And");
			refesh_dis(0,"",false,false);	
			break;}
		case 6:{
			m_sele_config.SetWindowText("Fillter");
			refesh_dis(0,"",false,false);	
			break;}
		case 7:{
			m_sele_config.SetWindowText("Label");
			refesh_dis(0,"",false,false);	
			break;}
	}		
}

void CStillCapDlg::OnBnClickedConfigdefault()
{		CString str;
	  	switch (m_type_config){
		case 0:{
			frame_delay = (int)1000/8;
			str.Format(_T("%d"),8);
			SetDlgItemText(IDC_dis_frame1,(LPCTSTR)str);
			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);
			break;
			   }
		case 1:{
			break;
			   }
		case 2:{
			str.Format(_T("%d"),15);
			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);

			m_range = 15;
			break;
			   }
		case 3:{
			theshold_inter = 16;
			str.Format(_T("%d"),theshold_inter);
			SetDlgItemText(IDC_dis_inter1,(LPCTSTR)str);
			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);
			break;
			   }
		case 4:{
			theshold_edge = 53;
			str.Format(_T("%d"),theshold_edge);
			SetDlgItemText(IDC_dis_edge1,(LPCTSTR)str);
			SetDlgItemText(IDC_tresthold2,(LPCTSTR)str);
			break;
			   }
		}
}

void CStillCapDlg::OnBnClickedreset()
{
	reset_cap = true;
//	m_button_play.EnableWindow(false);
}

void CStillCapDlg::OnBnClickedFromavi1()
{
	m_sele_avi = true;
	m_sele_camera = false;
}

void CStillCapDlg::OnBnClickedFromcamera()
{
	m_sele_avi = false;
	m_sele_camera = true;
}
