#ifndef RPCOBJ
#define RPCOBJ


class RPCObj
{
	protected:
		char *protocol_name;
		RPCParam *param;
		RPCParam *result;
		void* p_taskobj;
	public:
		RPCObj(){}
		~RPCObj(){}
		void setProtocolName(char *p_name){
			protocol_name = p_name;
		}
		char* getProtocolName(){
			return protocol_name;
		}
		void setRPCParam(RPCParam *p_param){
			param = p_param;
		}
		RPCParam* getRPCParam(){
			return param;
		}
		void setRPCResult(RPCParam *p_result){
			result = p_result;
		}
		RPCParam* getRPCResult(){
			return result;
		}
		void setTaskObj(void *tobj){
			p_taskobj = tobj;
		}
		void* getTaskObj(){
			return p_taskobj;
		}
		virtual int execute()=0;
};

#endif