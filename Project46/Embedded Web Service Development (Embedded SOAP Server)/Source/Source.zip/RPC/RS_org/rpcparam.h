#ifndef RPCPARAM
#define RPCPARAM

class RPCParam
{
	protected:
		RPCNode* start_node;
		RPCNode* current_node;
		RPCNode* state_node;
		int count_node;
		void addNode(RPCNode *node){
			current_node->setNextNode(node);
			current_node = node;
			count_node++;
		}
	public:
		RPCParam(){};
		~RPCParam(){};
		virtual char* valueOf(char *property_name) =0;
		virtual char* typeOf(char *property_name) =0;

		void addParam(const char *pname,const char *pvalue){
			addNode(new RPCNode(pname ,pvalue,0));
		}
		void addParam(const char *pname,const char *ptype,const char *pvalue){
			addNode(new RPCNode(pname , ptype,pvalue,0));
		}
		void addParam(const char *pname,const char *ptype,const char *pvalue,int pcount){
			addNode(new RPCNode(pname , ptype,pvalue,pcount));
//			printf("xxxxxxxxx checkpoint addParam xxxxxxxxxx\n");
		}
		void setPointToStart(){
			state_node = start_node;
		}
		void next(){
			state_node = state_node->getNextNode();
		}
		RPCNode* getStartNode(){
			return start_node;
		}
		RPCNode* getStatePoint(){
			return state_node;
		}
};

#endif