#ifndef TASKOBJ
#define TASKOBJ

#include "rpcobj.h"
#include "rpcsock.h"

class TaskObj
{
	private:
		char *req_msg;
		char *res_msg;
		RPCObj *rpc_obj;
		RPCSocket *tsocket;
		int task_num;
		void *msg_PQ_in;
		void *msg_PQ_out;
		void *data_mbox;
	public:
		TaskObj(RPCSocket *p_socket){
			tsocket = p_socket;
			req_msg = 0;
			res_msg = 0;
		}
		~TaskObj(){
			if(req_msg != 0)
				delete[] req_msg;
			if(res_msg != 0)
				delete[] res_msg;
		}
		void setReqMsg(char *msg){
			req_msg = new char[strlen(msg)+1];
			strcpy(req_msg , msg);
		}
		char* getReqMsg(){
			return req_msg;
		}
		void setResMsg(char *msg){
			res_msg = new char[strlen(msg)+1];
			strcpy(res_msg , msg);
		}
		char* getResMsg(){
			return res_msg;
		}
		void setRPCObj(RPCObj *p_rpc_obj){
			rpc_obj = p_rpc_obj;
		}
		RPCObj* getRPCObj(){
			return rpc_obj;
		}
		void setTaskNumber(int tnum){
			task_num = tnum;
		}
		int getTaskNumber(){
			return task_num;
		}
		void setMsgProtocolFactoryQ_In(void *p_in){
			msg_PQ_in = p_in;
		}
		void* getMsgProtocolFactoryQ_In(){
			return msg_PQ_in;
		}
		void setMsgProtocolFactoryQ_Out(void *p_out){
			msg_PQ_out = p_out;
		}
		void* getMsgProtocolFactoryQ_Out(){
			return msg_PQ_out;
		}
		void setDataMbox(void *p_data_mbox){
			data_mbox = p_data_mbox;
		}
		void* getDataMbox(){
			return data_mbox;
		}
		RPCSocket* getRPCSocket(){
			return tsocket;
		}
		int execute(){
			int temp = 1;
			rpc_obj->setTaskObj(this);
			temp = rpc_obj->execute();
			printf("task->execute()\n");
			return temp;
		}
};

#endif