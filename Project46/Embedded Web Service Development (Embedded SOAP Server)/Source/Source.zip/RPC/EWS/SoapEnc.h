// SoapEnc.h

#ifndef __SOAPENC_H
#define __SOAPENC_H
#include "Owen.h"

class SoapEncoding
{
	public:
	SoapEncoding()	{}
	~SoapEncoding()	{}
	
	char* typeToSoap();
};
#endif