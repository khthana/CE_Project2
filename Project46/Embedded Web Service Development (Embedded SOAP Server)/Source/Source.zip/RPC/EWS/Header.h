//Header.h


#ifndef __HEADER_H
#define __HEADER_H
#include "Str.h"
#include "Const.h"
#include "AttrHand.h"
#include "Xml.h"
#include "Qname.h"
#include "Parser.h"
#include "ParseE.h"
#include "Owen.h"

class Header
{
	private:
	Str headerEntries;
	AttributeHandler attrHandler;

	public:
	Header()	{}
	
	Header(const char* headerEn)	{
		headerEntries=headerEn;	}

	Header(const char* headerEn,const AttributeHandler attr)	{
		headerEntries=headerEn;
		attrHandler=attr;	}

	~Header()	{}

	Header& operator=(const Header& that)	{
		headerEntries=that.getHeaderEntries();
		attrHandler=that.getAttributeHandler();
		return *this;}

	void setAttribute(const char* attrQName, int value) {
		attrHandler.setAttribute(attrQName, value); }

	const char* getAttribute(QName attrQName) const	{
		return attrHandler.getAttribute(attrQName);	}

	char* getAttribute() const	{
		return attrHandler.getAttribute();	}

	const AttributeHandler getAttributeHandler() const	{
		return attrHandler;	}

	void setHeaderEntries(const char* headerEn)	{
		headerEntries=headerEn;	}

	const char* getHeaderEntries() const {
		return headerEntries.getStr();	}

	int getLength() const	{
		return headerEntries.getSize()+attrHandler.getLength();	}
	
	char* marshall();

	static Header* unmarshall(Parser* pr,ParseEvent *pe);
};
#endif