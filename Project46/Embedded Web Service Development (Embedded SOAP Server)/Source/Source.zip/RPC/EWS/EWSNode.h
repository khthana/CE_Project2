#ifndef EWSNODE
#define EWSNODE
#include <string.h>
class EWSNode
{
private:
	EWSNode* nextNode;
	char *property_name;
	char *property_type;
	char *property_value;
	int property_count;
public:
	EWSNode(const char* pname,const char* pvalue);
	EWSNode(const char* pname,const char* ptype,const char* pvalue);
	EWSNode(const char* pname,const char* ptype,const char* pvalue,int pcount);
	~EWSNode();
	EWSNode* getNextNode();
	void setNextNode(EWSNode* next_node);
	int isMatchProperty(char* pname);
	char* getValue();
	char* getType();
	char* getName();
	int getCount();
	void setName(char* property_name);
	void setType(char* property_type);
	void setValue(char* property_value);
	void setCount(int property_count);
};

#endif