#include "Param.h"

void Parameter::setSOAPObj(SOAPObj *soapobj) {
	Parser *pr=new Parser();
	ParseEvent *pe;
	pr->setXMLReader(params.getStr());
	pe=pr->read();
	char *temp;
	while (pr->isRead())	{
		if (pe->getType()==Xml::TEXT)	{
			temp=pe->toString();
			soapobj->getRPCParam()->addParam(pr->startTag.getName(),pr->startTag.getAttribute(0),pr->textEvent.getText());
			if (temp!=NULL)
				delete temp;
		}
		pe=pr->read();
	}
}
