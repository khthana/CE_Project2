// package de.embeddedXML.io
// import de.kxml.*;
// file name: Xmlwriter.cpp

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "XmlW.h"
#include "Owen.h"
//#include "Prefix.h"
XMLWriter::XMLWriter()
{
	my_strcpy(writer,NULL);
	pending=0;
	size=0;
}
XMLWriter::XMLWriter(const char *w)
{
	my_strcpy(writer,w);
	pending=0;size=0;
}
void XMLWriter::checkPending () // throws IOException protected 
{
	if (pending==1)	{
		my_strcat(writer,Xml::GT_S);
		my_strcat(writer,Xml::ENTER_S);
		pending=0;
	}
}
void XMLWriter::closeAll()
{
	char *st=" />";
	char *et="</";
	while (size>0)	{
		size--;
		if (nameTag[size]!=NULL)	{
			if (pending==1) {
				my_strncat(writer,st,3);
				pending=0;
			}
			else {
				my_strncat(writer,et,2);
				my_strcat(writer,nameTag[size].getStr());
				nameTag[size]=NULL;
				my_strncat(writer,Xml::GT_S,1);
				my_strcat(writer,Xml::ENTER_S);
			}
		} else {
			char *e="can't write unname(NULL) endtag";
			error=e;
			printf("\n%s\n",error.getStr());
			break;
		}
	}
}
void XMLWriter::write (char c) // throws IOException
{
	checkPending();
	switch (c) {
	case '<': my_strncat(writer,Xml::LT,4); break;
	case '>': my_strncat(writer,Xml::GT,4); break;
	case '&': my_strncat(writer,Xml::AMP,5); break;
	default: char*s; s=&c; my_strncat(writer,s,1); 
	}
}
void XMLWriter::write (char* buf, int start, int len) // throws IOException
{
	checkPending();
	int end=start+len;
	char *ptr;
	char *s;
	s="<>&";
	do	{
		int i=start;
		while (i<end)	{
			ptr=strchr(s,buf[i]);
			if (my_strcmp(ptr,NULL)==0)
				++i;
			else
				break;
		}
		int j=i;
		int index=start;
		while (j>start )	{
			s=&buf[index++];
			my_strncat(writer,s,1);
			j--;
		}
		if (i==end)
			break;
		write(buf[i]);
		start=i+1;
	}
	while (start<end);
}
void XMLWriter::writeAttribute (const char* attr)// throws IOException
{
	if (pending==0)	{
		char *e="can write attr only immediately after a startTag";
		error=e;
		printf("\n%s\n",error.getStr());
		//throw new RuntimeException("can write attr only immediately after a startTag");
	} else {
		if (my_strcmp(attr,NULL)!=0)	{
			my_strncat(writer,Xml::SP_S,1);
			my_strcat(writer,attr);
			my_strncat(writer,NULL,1);
		}
	}
}
void XMLWriter::writeAttribute (const char* pf,const char* n,const char* ns)// throws IOException
{
	if (my_strcmp(pf,NULL)==0)	{
		writeAttribute(n,ns);
	}
	else	{
		Attribute *attr=new Attribute(pf,n,ns);
		char *temp=attr->toPrefix_Name();
		writeAttribute(temp,ns);
		delete attr;
		delete temp;
	}
}
void XMLWriter::writeAttribute (const char* n,const char* v) // throws IOException
{
	if (pending==0)	{
		char *e="can write attr only immediately after a startTag";
		error=e;
		printf("\n%s\n",error.getStr());
		//throw new RuntimeException("can write attr only immediately after a startTag");
	}else	{
		if ((my_strcmp(n,NULL)!=0)&&(my_strcmp(v,NULL)!=0))	{
			char *s;
			my_strncat(writer,Xml::SP_S,1);
			my_strcat(writer,n);
			s="=\"";
			my_strncat(writer,s,2);
			char *temp;
			temp=Xml::encode(v,Xml::ENCODE_QUOT);
			my_strcat(writer,temp);
			delete temp;
			my_strncat(writer,Xml::QU_S,1);
			my_strncat(writer,NULL,1);
		}
	}
}
void XMLWriter::writeStartTag (const char* pf,const char* n) // throws IOException
{
	char tag[200];
	if (my_strlen(pf)==0)
		my_strcpy(tag,n);
	else{
		my_strcpy(tag,pf);
		my_strncat(tag,Xml::CL_S,1);
		my_strcat(tag,n);
	}		
	writeStartTag(tag);
}
void XMLWriter::writeStartTag (const char* t) // throws IOException  protected
{
	if (my_strcmp(t,NULL)!=0)	{
		checkPending();
		my_strncat(writer,Xml::LT_S,1);
		my_strcat(writer,t);
		nameTag[size++]=t;
		pending=1;
	}
}
void XMLWriter::writeEmptyTag (const char *pf,const char *n,const char *attr) // throws IOException
{
	char *temp;
	temp=new char[my_strlen(pf)+my_strlen(n)+2];
	my_strcpy(temp,pf);
	if (my_strcmp(pf,NULL)!=0)
		my_strncat(temp,Xml::CL_S,1);
	my_strcat(temp,n);
	writeEmptyTag(temp,attr);
	delete temp;
}
void XMLWriter::writeEmptyTag (const char *tag,const char *attr) // throws IOException
{
	if (my_strcmp(tag,NULL)!=0)	{
		checkPending();
		my_strncat(writer,Xml::LT_S,1);
		my_strcat(writer,tag);
		pending=1;
		writeAttribute(attr);
		my_strncat(writer,Xml::SL_S,1);
		my_strncat(writer,Xml::GT_S,1);
		pending=0;
	}
}
void XMLWriter::writeEndTag (const char *tag) // throws IOException
{
	char *s;
	if (nameTag[size-1]==tag)	{
		nameTag[--size]==NULL;
		s="</";
		my_strncat(writer,s,2);
		my_strcat(writer,tag);
		my_strncat(writer,Xml::GT_S,1);
		my_strcat(writer,Xml::ENTER_S);
	}
	else {
		char *e="tagname mismath with endtag";//error tagname mismatch
		error=e;
		printf("\n%s\n",error.getStr());
	}
}
void XMLWriter::writeEndTag()
{
	char *s;
	if (size>0)	{
		size--;
		if (nameTag[size]!=NULL)	{
			s="</";
			my_strncat(writer,s,2);
			my_strcat(writer,nameTag[size].getStr());
			nameTag[size]=NULL;
			my_strncat(writer,Xml::GT_S,1);
			my_strcat(writer,Xml::ENTER_S);
		}
	}
	else	{
		char *e="can't write endtag without starttag";
		error=e;
		printf("\n%s\n",error.getStr());
	}	
}
void XMLWriter::writeTag(const char* tag, const char* attr, const char* value)
{
	if ((my_strcmp(tag,NULL)!=0) && (my_strcmp(value,NULL)!=0))	{
		checkPending();
		my_strcat(writer,Xml::LT_S);
		my_strcat(writer,tag);
		if (my_strcmp(attr,NULL)!=0)	{
			my_strcat(writer,Xml::SP_S);
			my_strcat(writer,attr);
		}
		my_strcat(writer,Xml::GT_S);
		my_strcat(writer,value);
		my_strcat(writer,Xml::LT_S);
		my_strcat(writer,Xml::SL_S);
		my_strcat(writer,tag);
		my_strcat(writer,Xml::GT_S);
		my_strcat(writer,Xml::ENTER_S);
	}
}
void XMLWriter::writeLegacy (int type,const char* content) // throws IOException
{
	checkPending ();
	char *s;
	switch (type) {
	case '-':
		s="<!--";
		my_strncat(writer,s,4);
		my_strcat(writer,content);
		s="-->";
		my_strncat(writer,s,3);
		break;
	case '!':
		s="<!DOCTYPE";
		my_strncat(writer,s,9);
		my_strcat(writer,content);
		s=">";
		my_strncat(writer,s,1);
		break;
	case '?':
		s="<?";
		my_strncat(writer,s,2);
		my_strcat(writer,content);
		s="?>";
		my_strncat(writer,s,2);
		break;
	}
}
void XMLWriter::writeRaw (const char* s) // throws IOException
{
	checkPending ();
	my_strcat(writer,s);
}