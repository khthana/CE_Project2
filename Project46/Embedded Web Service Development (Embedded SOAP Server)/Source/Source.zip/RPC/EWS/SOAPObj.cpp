#include "EWSParam.h"
#include "SOAPObj.h"
#include "AttrHand.h"
#include <string.h>
#include <includes.h>
#include "taskobj.h"

static char HTTP_HEADER[] = "HTTP/1.0 200 Ok\n";
static char HTTP_CONTYPE[] = "Content-Type: text/xml; charset=\"utf-8\"\n";
static char HTTP_ENDLINE[] = "\n";

SOAPObj::SOAPObj(){}
/*
SOAPObj::SOAPObj(const char* sname, const char* smethod){
//SOAPObj::SOAPObj(const char* mname){
//	printf("SOAPIN>new SOAPObj :begin\n");//debug 006
	service_name = new char[strlen(sname)+1];
	strcpy(service_name,sname);
	param = new EWSParam((char*)smethod);
	result = new EWSParam((char*)smethod);
	service_method = new char[strlen(smethod)+1];
	strcpy(service_method,smethod);
	env_length=0;
//	printf("SOAPIN>new SOAPObj :end\n");//debug 007
}
*/
void SOAPObj::init(const char* sname, const char* smethod){
//SOAPObj::SOAPObj(const char* mname){
//	printf("SOAPIN>new SOAPObj :begin\n");//debug 006
	service_name = new char[strlen(sname)+1];
	strcpy(service_name,sname);
	param = new EWSParam((char*)smethod);
	result = new EWSParam((char*)smethod);
//	printf("Hey!!! result is instantiated.\n");
	service_method = new char[strlen(smethod)+1];
	strcpy(service_method,smethod);
	env_length=0;
//	printf("SOAPIN>new SOAPObj :end\n");//debug 007
}
SOAPObj::~SOAPObj(){
	delete param;
	delete[] service_method;
	delete[] service_name;
	delete[] encoding_style;
//	delete attrHandler;
	delete[] attr;
}
/*
void SOAPObj::setServiceName(const char* sname){
	if(service_name!=NULL)
		delete[] service_name;
	service_name = new char[strlen(sname)+1];
	strcpy(service_name,sname);
}
*/
void SOAPObj::setServiceMethod(const char* smethod){
	if(service_method!=NULL)
		delete[] service_method;
	service_method = new char[strlen(smethod)+1];
	strcpy(service_method,smethod);
}
void SOAPObj::setEncodingStyle(const char* estyle){
	if(encoding_style!=NULL)
		delete[] encoding_style;
	encoding_style = new char[strlen(estyle)+1];
	strcpy(encoding_style , estyle);
}
void SOAPObj::setEnvLength(int elength){
	env_length = elength;
}
void SOAPObj::setAttribute(char* attribute){
	attr = new char[strlen(attribute)+1];
	strcpy(attr,attribute);
	
}

int SOAPObj::execute(){
	printf("task->execute() : rpcobj <soapobj> ->execute()\n");

	INT8U err;
	char *msg;
	void *p_tmp;
	TaskObj *taskobj = (TaskObj *)p_taskobj;
	OS_EVENT *soapinQ = (OS_EVENT *)taskobj->getMsgProtocolFactoryQ_In();
	OS_EVENT *soapoutQ = (OS_EVENT *)taskobj->getMsgProtocolFactoryQ_Out();
	OS_EVENT *dataMbox = (OS_EVENT *)taskobj->getDataMbox();
	OS_EVENT *service_dispatcherQ = (OS_EVENT *)taskobj->getServiceDispatcherQ();
	RPCSocket *tsocket = taskobj->getRPCSocket();
	int task_number = taskobj->getTaskNumber();
	printf("checkpoint 3\n");

		/*read data from tcp stack*/
	/*	-read header*/
//	msg = tsocket->readSocket();
	msg = tsocket->readSocket();
//	printf("Msg1 read %s\n",msg);//debug
//	msg = tsocket->readSocket();
//	printf("Msg2 read %s\n",msg);//debug
//	return 0;
	if(strncmp(msg,"POST",4)!=0){//if not "POST"
		/*Header not OK*/
		/*-print Error*/
		/*-close connection*/
		printf("HTTP Header Error\n");
		tsocket->closeSocket();
		delete[] msg;
		return 1;//exit execution;
	}
	delete[] msg;
	/*	-read request message*/
	char *t_msg;
	t_msg = tsocket->readSocket();
	if(strncmp(t_msg,"<?",2)!=0){
		/*message not ok*/
		/*-print Error*/
		/*-close connection*/
		printf("HTTP Message Error\n");
		tsocket->closeSocket();
		delete[] t_msg;
		return 1;
	}
	msg = new char[strlen(t_msg)];
	int msg_index = 0;
	int t_msg_index = 0;
	int t_msg_len = strlen(t_msg);
	for(int i=0;i<t_msg_len;i++){
		if(t_msg[t_msg_index]=='\r' || t_msg[t_msg_index]=='\n'){
			t_msg_index++;
			continue;
		}
		msg[msg_index++]=t_msg[t_msg_index++];
	}
	delete[] t_msg;

	taskobj->setReqMsg(msg);

	printf("checkpoint 4\n");

	OSQPost(soapinQ,(void *)taskobj);

	printf("checkpoint 5\n");

	p_tmp = OSMboxPend(dataMbox,0,&err);
	delete[] msg;
	printf("checkpoint 6\n");
	printf("RWSTask No.%d has a message from SOAPIN\n",task_number);
//	return 0;
	/*create service obj*/
	//OSQueuePost(ServiceFactoryQueue,(void *)rpcobj);
	//servobj = (ServiceObj *)OSMboxPend(dataMbox,0,&err);
	/*run service obj*/
	//servobj.run();
	/*return result*/
	//servobj.setResult(rpcobj);
	/*pack result by SOAPOUT*/

//##################### Calling service by Service Dispatcher ########################
	//message to Service Dispatcher
	OSQPost(service_dispatcherQ,(void *)taskobj);
	p_tmp=OSMboxPend(dataMbox,0,&err);
	printf("Return result from ServiceTask\n");
//##################### Calling service by Service Dispatcher ########################

	//	OSQueuePost(SOAPOUTQueue,(void *)rpcobj);
	OSQPost(soapoutQ,(void *)taskobj);
	p_tmp = OSMboxPend(dataMbox , 0 , &err);

	printf("checkpoint 10\n");

	printf("RWSTask No.%d has a message from SOAPOUT\n",task_number);
//	printf("Respond Message :\n%s",taskobj->getResMsg());
	/*write back to requester*/

//  sock_puts(mysock, "HTTP/1.0 200 Ok\n")  ;
//  sock_puts(mysock, "Content-Type: text/xml; charset=\"utf-8\"\n") ;
//  sock_puts(mysock, "\n") ;
//  sock_puts(mysock, strin) ;
//	char *str_tmp;
//	str_tmp= new char[100];
//	str_tmp =  "HTTP/1.0 200 Ok\n\0";
//	tsocket->writeSocket(str_tmp);
//	str_tmp = "Content-Type: text/xml; charset=\"utf-8\"\n\0";
//	tsocket->writeSocket(str_tmp);
//	str_tmp = "\n\0";
//	tsocket->writeSocket(str_tmp);
//	delete[] str_tmp;

	tsocket->writeSocket(taskobj->getResMsg());

	/*close connection*/
	tsocket->closeSocket();
	printf("finishing execution\n");
	return 0;
}
