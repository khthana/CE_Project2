#include "httpsock.h"
#include <includes.h>


HTTPSocket::HTTPSocket(struct socketobj *p_httpsock){
	sock_obj = p_httpsock;
	sock_obj->read_status = 0;
	sock_obj->write_status = 0;
	sock_obj->close_status = 0;
	state = 0;
}
HTTPSocket::~HTTPSocket(){}

char* HTTPSocket::readSocket(){
	INT8U err;
//	sock_obj->read_status = 1;
	p_tmp = OSQPend((OS_EVENT *)sock_obj->buf_q , 0 , &err);
/*
	//POST
	if(state == 0){
		strcpy(sock_obj->data_buf,msg1);
		state++;
	}else if(state == 1){
		strcpy(sock_obj->data_buf,msg2);
	}
*/
//	printf("##################### Received Message #########################\n");
//	printf("Messages from %s = \n%s\n",(char *)p_tmp,sock_obj->data_buf);
//	printf("Messages (%dth) = \n%s\n",sock_obj->read_status,(char *)p_tmp);//registry :reg_
	printf("Messages from HTTPSocket\n");
//	printf("##################### Received Message #########################\n");

//	return sock_obj->data_buf;
	return (char *)p_tmp;
}
int HTTPSocket::writeSocket(char *data){
	INT8U err;
	strncpy(sock_obj->data_buf,data,strlen(data));
	sock_obj->write_status = 1;
	p_tmp = OSMboxPend((OS_EVENT *)sock_obj->data_mbox,0,&err);
	//sock_obj->write_status = 0;
	return 0;
}
int HTTPSocket::closeSocket(){
	sock_obj->close_status = 1;
	return 0;
}




/*

#include "sock_obj.h"

HTTPSocket::HTTPSocket(struct socketobj *p_rwssock){
	sock_obj = p_rwssock;
}
HTTPSocket::~HTTPSocket(){}
void HTTPSocket::setDesMbox(OS_EVENT *p_mbox){
	sock_obj->dataMbox=p_mbox;
}
char* HTTPSocket::readSocket(){
	INT8U err;
	sock_obj->read_status = 1;
	p_tmp=OSMboxPend(sock_obj->dataMbox,0,&err);
	//sock_obj->read_status = 0;
	return sock_obj->data_buf;
}
int HTTPSocket::writeSocket(char *data){
	INT8U err;
	strncpy(sock_obj->data_buf,data,strlen(data));
	sock_obj->write_status = 1;
	p_tmp = OSMboxPend(sock_obj->dataMbox,0,&err);
	//sock_obj->write_status = 0;
	return 0;
}
int HTTPSocket::closeSocket(){
	sock_obj->close_status = 0;
	return 0;
}


*/