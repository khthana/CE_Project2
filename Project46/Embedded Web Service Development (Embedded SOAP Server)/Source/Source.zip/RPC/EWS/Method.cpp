//Method.cpp

#include "Method.h"
#include "Owen.h"

char* Method::marshall()
{
	char *temp;
	temp=new char[getLength()];
	my_strcpy(temp,Xml::LT_S);
	my_strcat(temp,Constants::NS);
	const char* s1="1";
	my_strcat(temp,s1);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,name.getStr());
	
	//append response
	my_strcat(temp,Constants::RESPONSE);

	my_strcat(temp,Xml::SP_S);
	my_strcat(temp,Constants::XMLNS);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::NS);
	my_strcat(temp,s1);
	my_strcat(temp,Xml::EQ_S);
	my_strcat(temp,Xml::QU_S);
	my_strcat(temp,url.getStr());
	my_strcat(temp,Xml::QU_S);
	my_strcat(temp,Xml::SP_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::ENCODING_STYLE);
	my_strcat(temp,Xml::EQ_S);
	my_strcat(temp,Xml::QU_S);
	my_strcat(temp,encoding.getStr());
	my_strcat(temp,Xml::QU_S);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	
	///Parameter
	char *t;
	t=parameter.marshall();
	my_strcat(temp,t);
	delete t;

	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::NS);
	my_strcat(temp,s1);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,name.getStr());
	my_strcat(temp,Xml::GT_S);
	return temp;
}
Method* Method::unmarshall(Parser* pr,ParseEvent *pe)
{
	Method *m;
	m=new Method();
	char *temp;
	int count;
	pe=pr->read();
	Str attr,name,param;
	name=pe->getName();
	m->setMethodName(name.getStr());	
	attr=pe->getAttribute();
	attr.deleteTo('"');
	temp=attr.cut('"');
	m->setMethodURL(temp);
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;	
	}
	attr.deleteTo('=');
	attr.deleteTo('"');
	temp=attr.cut('"');
	m->setMethodEnc(temp);
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;	
	}
	while (pr->isRead()) {
		pe=pr->read();
		temp=pe->toString();
		if ((pe->getType()==Xml::END_TAG)&&(my_strcmp(pe->getName(),name.getStr())==0))
			break;		
		param+=temp;
		if (temp!=NULL)	{
			delete temp;
			temp=NULL;
		}
	}
	param+=Xml::ENTER_S;
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;
	}
	m->setParameter(param.getStr());
	return m;
}
