//Body.h

#ifndef __BODY_H
#define __BODY_H
#include "Str.h"
#include "Const.h"
#include "AttrHand.h"
#include "Qname.h"
#include "Parser.h"
#include "ParseE.h"
#include "Method.h"
#include "Owen.h"

class Body
{
	private:
	Method method;
	Str bodyEntries;
	Str error;
	//AttributeHandler attrHandler;

	public:
	Body()	{  }
	Body(const char* bEntries)	{
		bodyEntries=bEntries;	}
	Body& operator=(const Body& that)	{
		method=that.getMethod();
		bodyEntries=that.getBodyEntries();
		error=that.getError();
		//attrHandler=that.getAttributeHandler();
		return *this;	}
	
	/*void setAttribute(const char* attrQName, int value) {
		attrHandler.setAttribute(attrQName, value); }

	const char* getAttribute(QName attrQName)	{
		return attrHandler.getAttribute(attrQName);	}

	const AttributeHandler getAttributeHandler() const	{
		return attrHandler;	}
	
	char* getAttribute() const 	{
		return attrHandler.getAttribute();	}*/

	void setBodyEntries(const char* bEntries)  {
		bodyEntries=bEntries;  }

	const char* getBodyEntries() const  {
		return bodyEntries.getStr();  }

	int getLength() const {
		return bodyEntries.getSize()+method.getLength();	}//+attrHandler.getLength()

	void setMethod(const Method m1) {
		method=m1;	}
	
	const Method getMethod() const{
		return method;	}
		
	void setError(const char* e) {
		error=e;	}
	
	const char* getError() const{
		return error.getStr();	}

	char* marshall();
	static Body* unmarshall(Parser* pr,ParseEvent *pe);
};
#endif;
