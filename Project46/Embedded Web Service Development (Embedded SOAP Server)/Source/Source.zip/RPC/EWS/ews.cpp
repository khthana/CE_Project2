#define  EWS_GLOBALS

#ifndef OS_GLOBALS
#include "includes.h"
#endif

#define EWS_MASTER_FILE
#include "\software\ucos-ii\ex1_x86l\source\ews\attr.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\attrhand.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\body.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\const.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\endtag.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\envelope.cpp"
//#include "\software\ucos-ii\ex1_x86l\source\ews\ewsnode.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\ewsparam.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\fault.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\header.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\method.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\owen.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\param.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\parser.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\prefix.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\qname.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapdes.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapobj.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\soappar.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\starttag.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\str.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\texte.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\xml.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\xmlr.cpp"
#include "\software\ucos-ii\ex1_x86l\source\ews\xmlw.cpp"

#include "\software\ucos-ii\ex1_x86l\source\ews\httpsock.cpp"

//#include "\software\ucos-ii\ex1_x86l\source\ews\ewsparam.cpp"
//#include "\software\ucos-ii\ex1_x86l\source\ews\ewsnode.cpp"

