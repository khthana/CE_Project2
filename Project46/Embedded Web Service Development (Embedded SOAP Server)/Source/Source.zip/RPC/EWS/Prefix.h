// package de.embeddedXML 
// file name: Prefix.h
#ifndef __PRIFIX_H
#define __PRIFIX_H
#define SIZE 20
#define LEN 100

#include "Owen.h"

class PrefixMap
{
	private:
	int size;						// save size of prefixMap & namespaceMap
	char prefixMap[SIZE][LEN];		// save namespace
    char namespaceMap[SIZE][LEN];	// save prefix	

	public:
	PrefixMap();
	PrefixMap(PrefixMap base,const char* pf,const char* ns);
	//void clone();
	PrefixMap& operator= (const PrefixMap& value);
	int add(const char* ns,const char* pf);
	int add(const char* st);
	int remove(const char* ns,const char* pf);
    const char* getNamespace (const char* pf) const;
    const char* getPrefix (const char* ns) const;
	const char* getprefixMap(int i) const
	{
		return prefixMap[i];
	}
	const char* getnsMap (int i) const
	{
		return namespaceMap[i];
	}
	int getSize() const
	{
		return size;
	}
};
#endif
