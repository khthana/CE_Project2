// package embeddedXML.parser
// import de.kxml.*;
// file name: TextE.cpp

#include <string.h>
#include "TextE.h"
#include "Owen.h"
int TextEvent::endCheck (ParseEvent* start) // 0=false 1=true
{
	int i=text.getSize();
	while (i-- > 0)
	{
		if (text.getStr()[i] > ' ')
		{
			//throw new RuntimeException ("unexpected text: '"+text+"'");
			char *s1="unexpected text: '";
			char *c="'";
			char *s;
			s=new char[text.getSize()+21];
			my_strcpy(s,NULL);
			my_strcpy(s,s1);
			my_strcat(s,text.getStr());
			my_strncat(s,c,1);
			my_strncat(s,NULL,1);
			setError(s);
			delete s;
		}
	}
	return 0; //false
}