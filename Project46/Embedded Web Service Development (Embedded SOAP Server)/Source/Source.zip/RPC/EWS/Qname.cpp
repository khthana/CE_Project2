// package embeddedXML
// file name : Attr.cpp

#include <string.h>
#include "Qname.h"
#include "Owen.h"

QName& QName::operator=(const QName& that)
{
	namespaceURI=that.getNamespaceURI();
	localPart=that.getLocalPart();
	return *this;
}
QName& QName::operator=(const char *name)
{
	int len=my_strlen(name);
	char *ptr;
	char *temp=new char[len+1];
	ptr=strchr(temp,':');
	if (ptr==NULL)
	{
		namespaceURI.set(name);
		localPart.set(NULL);
	}else {
		int d=ptr-temp,i,j=0;
		char *t=new char[len-d+1];
		for (i=0;i<d ;i++ )
			t[j++]=temp[i];
		t[j]='\0';
		namespaceURI=t;
		my_strcpy(t,NULL);
		for (i=d+1;i<len ; i++)
			t[j++]=temp[i];
		t[j]='\0';
		localPart=t;
		delete t;
	}
	delete temp;
	return *this;
}
char* QName::toString()
{
	char *temp;
	temp=new char[namespaceURI.getSize()+localPart.getSize()+2];
	my_strcpy(temp,namespaceURI.getStr());
	if (localPart.getSize()>0)
	{
		char*s=":";
		my_strncat(temp,s,1);
		my_strcat(temp,localPart.getStr());
	}
	my_strncat(temp,NULL,1);
	return temp;
}
