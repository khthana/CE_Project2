//#include<iostream.h>
#include "Owen.h"
#include <string.h>

void  my_strcpy(char *des, const char *source){
//	cout<<"hello my_my_strcpy<<endl;
	if(source==NULL){
		des[0]='\0';
	}else{
		strcpy(des,source);
	}
}
//void  my_strncpy(char *des, const char *source ,int size_t){
//}
void  my_strcat(char *des, const char *source){
	if(source==NULL){
//		des[0]='\0';
	}else{
		strcat(des,source);
	}
}
void  my_strncat(char *des, const char *source ,int size_t){
	if(source==NULL){
//		des[0]='\0';
	}else{
		strncat(des,source,size_t);
	}
}
int my_strcmp(const char *des, const char *source){
	int temp=-1;
	if(source==NULL && des==NULL){
		temp = 0;
	}else if(source==NULL){
		if(des[0]==NULL)
			temp=0;
	}else if(des==NULL){
		if(source[0]==NULL)
			temp=0;
	}else{
		temp = strcmp(des,source);
	}
	return temp;

}
int my_strlen(const char *str){
	int temp=0;
	if(str==NULL){
		
	}else{
		temp=strlen(str);
	}
	return temp;
}