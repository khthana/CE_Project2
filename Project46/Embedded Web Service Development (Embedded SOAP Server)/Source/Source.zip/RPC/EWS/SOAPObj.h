#ifndef SOAPOBJ
#define SOAPOBJ

#include "EWSParam.h"
#include "RPCObj.h"
//#include "AttrHand.h"
//#include <string.h>
//#include <stdio.h>
class SOAPObj :public RPCObj
{
private:
	char* service_method;
//	char* service_name;
	char* encoding_style;
	int env_length;
	char* attr;
public:
	SOAPObj();
	~SOAPObj();
	void init(const char* service_name,const char* service_method);
//	void setRPCParam(RPCParam* p_param);
//	void setRPCResult(RPCParam* p_result);
//	RPCParam* getRPCParam();
//	RPCParam* getRPCResult();
//	void setProtocolName(char *p_name);
//	char* getProtocolName();
//	void setTaskObj(void *);
//	TaskObj* getTaskObj();
	int execute();

	int getEnvLength(){
		return env_length;
	}
	char* getAttribute(){
		return attr;
	}
/*
	char* getServiceName(){
		return service_name;
	}
*/
	char* getServiceMethod(){
		return service_method;
	}
	char* getEncodingStyle(){
		return encoding_style;
	}
//	void setServiceName(const char* service_name);
	void setServiceMethod(const char* service_method);
	void setEncodingStyle(const char* estyle);
	void setEnvLength(int elength);
	void setAttribute(char* attribute);
};

#endif