//SoapPar.h

#ifndef __SOAPPARSER_H
#define __SOAPPARSER_H

//#include "Parser.h"
//#include "ParseE.h"
#include "Envelope.h"
//#include "Header.h"
//#include "Body.h"
//#include "Xml.h"
//#include "SoapDes.h"
//#include "Owen.h"

class SOAPParser 
{
	public:
	SOAPParser() {}

	static Envelope* parse(const char* message);
	static char* getServiceName(const char *n);
//	static int checkServiceName(const char *n);
//	static int checkMethodName(const char* n,const char* fileName);
};
#endif