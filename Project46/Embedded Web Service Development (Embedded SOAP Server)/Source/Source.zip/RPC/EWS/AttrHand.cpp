// AttrHandler.cpp
#include <string.h>
#include "AttrHand.h"
#include "Owen.h"
AttributeHandler& AttributeHandler::operator=(const AttributeHandler& that)
{
	size=that.getSize();
	for(int i=0;i<size;i++)
		attributes[i]=that.getAttribute(i);
	return *this;
}
void AttributeHandler::setAttribute(const char* a,int sizeA)
{
	size=sizeA;
	int len=0,start=0,i=0;
	char *temp, *attr,*s;
	attr=new char[my_strlen(a)+1];
	my_strcpy(attr,a);
	my_strncat(attr,NULL,1);
	do
	{
		start=len+1;
		for (int j=start;attr[j]!=' ' && attr[j]!='\0' ;j++ )
			len++;
		len++;
		if (len-start>0)
		{
			temp=new char[len-start+2];
			my_strcpy(temp,NULL);
			for (j=start;j<len ;j++ )
			{
				s=&attr[j];
				my_strncat(temp,s,1);
			}
			attributes[i++]=temp;
			delete temp;
		}
		if (attr[len]=='\0')	break;
	}while (i<size);
	delete attr;
	while (i<4)
		attributes[i++]=NULL;
}
QName* AttributeHandler::attrToQName(int index) const
{
	char temp[200];
	QName *q=new QName();
	my_strcpy(temp,attributes[index].getStr());
	int i=0,j;
	while (temp[i]!=':' && temp[i]!='\0') i++;
	if (temp[++i]!=':')	
		i=0;
	char s[200];
	my_strcpy(s,NULL);
	j=0;
	while (temp[i]!='=')
		s[j++]=temp[i++];
	q->setLocalPart(s);
		i+=2;j=0;
	my_strcpy(s,NULL);
	while (temp[i]!='"')
		s[j++]=temp[i++];
	q->setNamespaceURI(s);
	return q;
}
const char* AttributeHandler::getAttribute(QName attrQName) const
{
	int i=0,index=-1;
	QName *q;
	while (i<size)
	{
		q=attrToQName(i++);
		if (attrQName==*q)
		{
			index=i;break;
		}
		else
			delete q;
	}
	delete q;
	if (index!=-1)
		return attributes[index].getStr();		
	else
		return NULL;
}

/*
private:
char* getPrefixFromURI(const char* namespaceURI)
{
	if (my_strcmp(namespaceURI,NULL)==0) return NULL ;
	char* nsPrefix;
	nsPrefix=new char[150];
	//my_strcpy(nsPrefix,NULL);
	my_strcpy(nsPrefix,namespaceURIs2Prefixes.getPrefix(namespaceURI));
	if (my_strcmp(nsPrefix,NULL)==0)
	{
		char c[10];
		char* s="ns";
		my_strncat(nsPrefix,s,2);
		itoa(nsPrefixIndex++,c,10);
		my_strncat(nsPrefix,c);
		setAttribute(QName(Constants.NS_URI_XMLNS, nsPrefix), namespaceURI);
	}
	return nsPrefix;
}*/
//function that save namespaceURI & prefix into NSStack coming soon======
char* AttributeHandler::getAttribute() const
{
//	printf("SOAPIN>ENVELOPE>soapobj->setAttribute(this.getAttribute()>attrHandler->getAttribute()):begin\n");
//	printf("getLength()= %d\n",getLength());
	int i;
	char* temp;
	temp=new char[getLength()+10];
	my_strcpy(temp,NULL);
	for (i=0;i<size ; i++)
	{
		//if (i!=0)
		my_strcat(temp,Xml::SP_S);
		my_strcat(temp,attributes[i].getStr());
	}
//	printf("SOAPIN>ENVELOPE>soapobj->setAttribute(this.getAttribute()>attrHandler->getAttribute()):end\n");
	return temp;
}
char* AttributeHandler::marshall()
{
	int i;
	char* temp;
	temp=new char[getLength()+10];
	my_strcpy(temp,NULL);
	for (i=0;i<size ; i++)
	{
		if (i!=0)
			my_strcat(temp,Xml::SP_S);
		my_strcat(temp,attributes[i].getStr());
	}
	return temp;
}
AttributeHandler* AttributeHandler::unmarshall(const char* src,int s)
{
	AttributeHandler* a;
	a=new AttributeHandler(src,s);
	return a;
}	

char* AttributeHandler::getValue(const char* attrName) const	{
	char *temp,*t;
	Attribute *a;
	for (int i=0; i<4;i++ )
	{
		a=new Attribute(attributes[0].getStr());
		t=new char[my_strlen(a->getNamespace())+my_strlen(a->getName())+2];
		my_strcpy(t,NULL);
		if (my_strcmp(a->getNamespace(),NULL)!=0)
		{
			my_strcat(t,a->getNamespace());
			my_strcat(t,Xml::CL_S);
		}
		my_strcat(t,a->getName());
		my_strncat(t,NULL,1);
		if (my_strcmp(attrName,t)==0)
		{
			delete t;
			temp=new char[my_strlen(a->getValue())+1];
			my_strcpy(temp,a->getValue());
			delete a;
			my_strncat(temp,NULL,1);
			return temp;
		}
		delete a;
		delete t;
	}
	return NULL;
}
