#ifndef __OWEN_H
#define __OWEN_H

//#include<iostream.h>
/*
void sample_SOAPIN(char* a);
void sample_LISTS(char* a);//SoapPar.h :	- getServiceName()
						   //				- checkServiceName()
						   //				- checkMethodName()
											
void sample_CALTXT(char* a);//SoapDes.cpp :readServiceMap(const char* filename)
void sample_OUTTXT(char* a);//SoapDes.cpp :serialOutput(a);
*/

void my_strcpy(char *des, const char *source);
void my_strncpy(char *des, const char *source ,int size_t);
void my_strcat(char *des, const char *source);
void my_strncat(char *des, const char *source ,int size_t);
int my_strcmp(const char *des, const char *source);
int my_strlen(const char *str);


#endif