// package
// file name : Str.h
#ifndef __STR_H
#define __STR_H
#include <string.h>
#include "Owen.h"
class Str
{
	private:
    int size;
	char *str;	

	public:
	Str ()						{ str=NULL;size=0; }
	Str (const char *string)	{ str=NULL;set(string);	}
	Str (const Str& value)		{ str=NULL;set(value.getStr()); }
	~Str()						{ toDelete(); }
	Str& operator=(const Str& value)
	{ 
		set(value.getStr());
		return *this;
	}
	Str& operator=(const char *string)
	{ 
		set(string); 
		return *this;
	}
	int operator==(const Str& value);
	int operator==(const char *string);
	int operator!=(const Str& value);
	int operator!=(const char *string);
	Str& operator+=(const Str& value)
	{
		append (value.getStr());
		return *this;
	}
	Str& operator+=(const char *string)
	{
		append (string);
		return *this;
	}
	int getSize() const					{ return size; }
	void set (const char *string);
	void set (const Str& value)			{ set(value.getStr()); }
	void append (const char *string);
	void append (const Str& value)		{ append(value.getStr()); }
	void toDelete ();
	const char* getStr () const			{ return str; }
	//char getChar (int i) const			{ return str[i]; }
	int isEmpty () const;
	int isEqual (const Str& value) const;
	int isEqual (const char *string) const;
	void replaceAfter(const char *s,char c);
	void replaceBefore (const char *s, char c);
	char* cut (char c);
	char* cut2(char c);





	void deleteTo(char c);
	char endString() ;
};
#endif