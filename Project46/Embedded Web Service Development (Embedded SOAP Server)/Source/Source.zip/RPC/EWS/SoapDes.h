//Deserial.h

#ifndef ____SOAPDESERIALIZE_H
#define ____SOAPDESERIALIZE_H
#include "Str.h"
#include "Attr.h"
#include "Xml.h"
#include "Const.h"
#include "Parser.h"
#include "ParseE.h"
#include "XmlW.h"
#include "Owen.h"
#include "EWSParam.h"


class SOAPDeserialize
{
	private:
	Str serviceName;
	Str serviceMethod;
	Str serviceEncoding;
	Str serviceOutput;
	Str serviceQname;
	Str serviceQnameNS;
	Str serviceParameter;
	Str serviceMap;
	Str error;

	public:
	static const char* SERVICE;
	static const char* NAMESPACEID;
	static const char* INPUT;
	static const char* OUTPUT;
	static const char* PROVIDER;
	static const char* MAPPING;
	static const char* MAP;
	static const char* XMLNS_X;
	static const char* QNAME_A;
	static const char* HEADERFILE;
	static const char* XSI_TYPE;
	static const char* INT_S;
	static const char* DOUBLE_S;
	static const char* LONG_S;
	static const char* FLOAT_S;
	static const char* STRING_S;
	//const char* CHAR__S="char* ";
	static const char* CHAR_S;
	//const char* UNSIGNED_S="unsigned";
	//const char* STATIC_S="static";
	//const char* CONST_S="const";

	SOAPDeserialize(){}

	//void setObjectToDeserialize();
	//void buildSOAPFault();
	
	void readServiceMap(const char* fileName);
	int isNative(const char* s);
	char* serialOutput(EWSParam *results);
	static int checkOrder(const char* fileName,const char* params);

	void setServiceMethod(const char* mname) {
		serviceMethod=mname;	}

	const char* getServiceMethod()	const {
		return serviceMethod.getStr();	}
	
	void setServiceName(const char* n)	{
		serviceName=n;	}

	const char* getServiceName() const {
		return serviceName.getStr(); }

	void setServiceParameter(const char* p) {
		serviceParameter=p; }

	const char* getServiceParameter() const {
		return serviceParameter.getStr();}

	void setError(const char* e)	{
		error=e;	}

	const char* getError() const {
		return error.getStr();	}

	int checkDetail(const char* name,const char* method,const char* encode,const char* qname,const char* qnameNS) {
		if ((my_strcmp(name,serviceName.getStr())==0)&&(my_strcmp(method,serviceMethod.getStr())==0)&&(my_strcmp(encode,serviceEncoding.getStr())
			&&(my_strcmp(qname,serviceQname.getStr())==0)&&(my_strcmp(qnameNS,serviceQnameNS.getStr())==0)))
			return 1;
		else
			return 0; }

	//void checkError();
};
#endif