//Header.cpp

#include "Header.h"
#include "Owen.h"
char* Header::marshall()
{
	char* temp;
	if (my_strcmp(headerEntries.getStr(),NULL)!=0)	{
		int s=30+headerEntries.getSize()+attrHandler.getLength();
		temp=new char[s];
		my_strcpy(temp,NULL);
		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Constants::SOAP_ENV);
		my_strcat(temp,Xml::CL_S);
		my_strcat(temp,Constants::HEADER);

		//Attribute marshall()
		char *t;
		t=attrHandler.marshall();
		my_strcat(temp,t);
		delete t;

		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,Xml::ENTER_S);

		//Header Entries  must include;
		my_strcat(temp,headerEntries.getStr());
		my_strcat(temp,Xml::ENTER_S);

		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Xml::SL_S);
		my_strcat(temp,Constants::SOAP_ENV);
		my_strcat(temp,Xml::CL_S);
		my_strcat(temp,Constants::HEADER);
		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,Xml::ENTER_S);
		my_strncat(temp,NULL,1);
		return temp;
	}
	return NULL;
}
Header* Header::unmarshall(Parser* pr,ParseEvent *pe)
{
	Header *h;
	char *temp;
	int count;

	char headerTag[16];
	my_strcpy(headerTag,Constants::SOAP_ENV);
	my_strcat(headerTag,Xml::CL_S);
	my_strcat(headerTag,Constants::HEADER);
	my_strcat(headerTag,NULL);

	pe=pr->read();
	Str param;
	return h;
}