#ifndef EWSPARAM
#define EWSPARAM

#include "RPCNode.h"
#include "XMLW.h"
#include "RPCParam.h"
//#include <iostream.h>

class EWSParam :public RPCParam
{
//protected:
//	int count_node;
//	RPCNode *start_node;
//	RPCNode *current_node;
//	void addNode(RPCNode *node);
//	RPCNode *state_node;
public:
	EWSParam(const char *service_method);
	~EWSParam();
	char* valueOf(char *property_name);
	char* typeOf(char *property_name);
	void* extraPointerOf(char *property_name);
//	void addParam(const char* pname ,const char* pvalue);
//	void addParam(const char* pname ,const char* ptype,const char* pvalue);
//	void addParam(const char* pname ,const char* ptype,const char* pvalue,int pcount);
//	RPCNode* getStartNode();
//	void setPointToStart();
//	RPCNode* getStatePoint();
//	void next();

	static void recurParam(EWSParam *param,XMLWriter *writer);
};
#endif