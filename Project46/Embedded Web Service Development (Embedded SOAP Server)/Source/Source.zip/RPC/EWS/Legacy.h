// package embeddedXML.parser
// import
// file name: Legacy.h
/** Class for ProcessingInstructions and Comments */
#ifndef __LEGACY_H
#define __LEGACY_H
#include <string.h>
#include "ParseE.h"
#include "Owen.h"
class LegacyEvent : public ParseEvent
{
	private:
	int type;
	Str text;
	Str error;
	
	/** creates a new LegacyEvent with the given type and string content */
	public:
	LegacyEvent()			{ type=0; }
	LegacyEvent(int type1,const char* text1)
	{
		type=type1;
		text.set(text1);
	}
	~LegacyEvent()			{ }
	LegacyEvent& operator= (const LegacyEvent& value)
	{
		type=value.getType();
		text.set(value.getText());
		error.set(value.getError());
		return *this;
	}
	/** returns the type of the sgml-legacy event,

        PROCESSING_INSTRUCTION, ENTITY_DECLARATION, or COMMENT */
	int getType()  const	{ return type; }

	//pure function;
	char* getAttribute() const { return NULL; }
	const char* getName() const { return NULL; }
	const char* getNamespace () const { return NULL; }
	char* getValue (const char* attrname) const { return NULL; }
	const char* getText () const { return text.getStr(); }
	int getCountAttr() const { return 0; }
	const char* getAttribute (int index) const { return NULL; }
	char* toString ()	{ 
		char *temp;
		temp=new char[text.getSize()+1];
		my_strcpy(temp,text.getStr());
		my_strncat(temp,NULL,1);
		return temp; }

	/** returns always false.  */
	int endCheck(ParseEvent* start)	{ return 0; }// 0=false 1=true
	void setError(const char* e)	{ error.set(e); }
	const char* getError()const		{ return error.getStr(); }
	
};
#endif