//
//
#include <string.h>
#include "EndTag.h"
#include "Owen.h"

char* EndTag::toString()
{
	char *temp;
	
	/*if (temp!=NULL)
		delete temp;*/
	
	if (my_strcmp(endTag.getStr(),NULL)!=0)
	{
		temp=new char[my_strlen(endTag.getStr())+4];
		/*my_strcpy(temp,NULL);
		s="</";
		my_strncat(temp,s,2);*/
		my_strcpy(temp,Xml::LT_S);
		my_strncat(temp,Xml::SL_S,1);
		my_strcat(temp,endTag.getStr());
		my_strncat(temp,Xml::GT_S,1);
		my_strncat(temp,NULL,1);
	}
	else
		temp=NULL;
	return temp; //  "</"+startTag.name + ">";
}
