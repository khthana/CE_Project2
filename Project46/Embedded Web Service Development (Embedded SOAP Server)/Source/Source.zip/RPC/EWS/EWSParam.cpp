#include "EWSParam.h"
#include "RPCNode.h"
#include "XMLW.h"
#include "const.h"
#include <string.h>	

EWSParam::EWSParam(const char *service_method){
	char temp[] = "service method";
	start_node = new RPCNode(&temp[0] , service_method);
//	printf("ssssssss start_node->getName() = %s sssssssssss\n",start_node->getName());
	current_node = start_node;
	count_node = 1; //include start_node
}
EWSParam::~EWSParam(){
	delete start_node; //recursive delete
}
char* EWSParam::typeOf(char *pname){
	char* ptype = NULL;
	RPCNode * temp1 , *temp2;
	temp1 = start_node;
	while(temp1->getNextNode()!= NULL){
		temp2 = temp1->getNextNode();
		if(temp2->isMatchProperty(pname) == 0){
			ptype = temp2->getType();
			break;
		}
		temp1 = temp2;
	}
	return ptype;
}
char* EWSParam::valueOf(char *pname){
	char* pvalue = NULL;
	RPCNode * temp1 , *temp2;
	temp1 = start_node;
	while(temp1->getNextNode()!= NULL){
		temp2 = temp1->getNextNode();
		if(temp2->isMatchProperty(pname) == 0){
			pvalue = temp2->getValue();
			break;
		}
		temp1 = temp2;
	}
	return pvalue;
}
void* EWSParam::extraPointerOf(char *pname){
	void* ep = NULL;
	RPCNode * temp1 , *temp2;
	temp1 = start_node;
	while(temp1->getNextNode()!= NULL){
		temp2 = temp1->getNextNode();
		if(temp2->isMatchProperty(pname) == 0){
			ep = temp2->getExtraPointer();
			break;
		}
		temp1 = temp2;
	}
	return ep;
}
void EWSParam::recurParam(EWSParam *param,XMLWriter *writer){
	RPCNode *temp;
	temp=param->getStatePoint();
	writer->writeStartTag(temp->getName());
	writer->writeAttribute(Constants::XSI,Constants::TYPE,temp->getType());
	if(temp->getCount()>0){
		for(int i=0;i<temp->getCount();i++){
			param->next();
			recurParam(param,writer);
		}
	}
	else{
		writer->writeRaw(temp->getValue());
	}
	writer->writeEndTag(temp->getName());
}
