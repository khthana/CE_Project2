// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: Dparser.cpp
#include <string.h>
#include <stdio.h>
#include <iostream.h>
#include "Parser.h"
#include "Owen.h"
const char* Parser::ER_TEXT="Illegal StartTag in readText: ";
/** amp is already consumed, consume incl. comma */
Parser::Parser()
{
	processNamespaces=0;
	immediateClose=0;
	for (int i=0;i<30 ;i++ )
	{
		qNames[i]=NULL;
	}
	size=0;
	next=NULL;
}
Parser::Parser (const char* r)   // throws IOException
{
	XMLReader r1(r);
	reader=r1;
	processNamespaces=0;
	immediateClose=0;
	for (int i=0;i<30 ;i++ )
	{
		qNames[i]=NULL;
	}
	size=0;
	next=NULL;
	res=NULL;
	read();
}

const char Parser::parseCharacterEntity ()// throws IOException
{
	char *temp;
	temp=reader.readTo(';');
	char code[10];
	my_strcpy(code,temp);
	delete temp;
	//char* result;
	reader.read();
	if (code[0]=='#' && code[1]=='x')
	{
		int i=0,j,k;
		int c=0;
		for (j=2;code[j]!='\0' ;j++ )
		{
			i++;
		}
		for (j=2;j<i+2 ;j++ )
		{
			c+=((int)code[j]);
			for (k=i;k>0 ;k-- )
			{
				c*=16;
			}
			i--;
		}
		char ch=(char)c;
		return ch;
	}
	else if (code[0]=='#')
	{
		int i=0,j,k;
		int c=0;
		for (j=2;code[j]!='\0' ;j++ )
		{
			i++;
		}
		for (j=2;j<i+2 ;j++ )
		{
			c+=((int)code[j]);
			for (k=i;k>0 ;k-- )
			{
				c*=10;
			}
			i--;
		}
		char ch=(char)c;
		return ch;
	}
	else if (code[0]=='l' && code[1]=='t')
		return '<';
	else if (code[0]=='g' && code[1]=='t')
		return '>';
	else if (code[0]=='a' && code[1]=='p' && code[2]=='o' && code[3]=='s')
		return '>';
	else if (code[0]=='q' && code[1]=='u' && code[2]=='o' && code[3]=='t')
		return '"';
	else if (code[0]=='a' && code[1]=='m' && code[2]=='p')
		return '&';
	return '$';
	//else throw exception;
}
/* precondition: &lt;!- consumed */
LegacyEvent Parser::parseComment ()// throws IOException
{
	//char buf[300];
	if (reader.read()!='-')
	{
		//throw new ParseException("'-' expected", reader);
	}
	int cnt;
	int lst;
	char temp[100];
	char *s;
	while (1==1)
	{
		char *t;
		t=reader.readTo('-');
		my_strcpy(temp,t);
		delete t;
		//my_strcpy(temp,temp);
		if (reader.read()==-1)
		{
			//throw new ParseException ("Unexpected end of file while reading commnent",reader);
		}
		cnt=0;
		do
		{
			lst=reader.read();
			cnt++;
		}
		while (lst=='-');
		if (lst=='>' && cnt>=2)
			break;
		while (cnt-- >0)
		{
			my_strncat(temp,Xml::CM_S,1);
		}
		char c=(char)lst;
		s=&c;
		my_strncat(temp,s,1);
	}
	while (cnt-- >2)
	{
		my_strncat(temp,Xml::CM_S,1);
	}
	LegacyEvent l1(Xml::COMMENT,temp);
	leg=l1;
	return leg;
}
/* precondition: &lt! consumed */
LegacyEvent Parser::parseDoctype ()// throws IOException
{
	char temp[200];
	char c;
	char *s;
	my_strcpy(temp,NULL);
	int nesting=1;
	while (1==1)
	{
		int i=reader.read();
		switch (i)
		{
			case -1 : break;//throw new ParseException("unexpected eof",reader);
			case '<': nesting++;break;
			case '>': if ((--nesting)==0)
					  {
						  LegacyEvent l1(Xml::DOCTYPE,temp);
						  leg=l1;
						  return leg;
					  }
					  break;				
		}
		c=(char)i;
		s=&c;
		my_strncat(temp,s,1);
	}
	char *err="error";
	LegacyEvent l1(Xml::DOCTYPE,err);
	leg=l1;
	return leg;
}
TextEvent Parser::parseCData ()// throws IOException
{
	char *s;
	char c;
	char temp[300];
	int cmp;
	char *te;
	te=reader.readTo('[');
	my_strcpy(temp,te);
	delete te;
	if(my_strcmp(temp,Xml::CDATA)!=0)
		//trow new ParseException("Invalid CDATA start!", reader);
	reader.read();//skop '['
	int c0=reader.read();
	int c1=reader.read();
	my_strcpy(temp,NULL);
	while (1==1)
	{
		int c2=reader.read();
		if (c2== -1)
			//throw new ParseException ("unexpected eof", reader);
		if (c0 == ']' && c1 == ']' && c2 == '>')
			break;
		c=c0;
		s=&c;
		my_strncat(temp,s,1);
		c0=c1;
		c1=c2;
	}
	TextEvent t(temp);
	textEvent=t;
	return textEvent;
}
/* precondition: &lt;/ consumed */
EndTag Parser::parseEndTag ()// throws IOException
{
	char *name;
	name=reader.readTo('>');
	reader.read(); //skip >
	char qName[200];
	my_strcpy(qName,qNames[--size].getStr());
	if (my_strcmp(qName,name)==0)
		qName[size]=NULL;
	else
	{
	/*	throw new ParseException
		("StartTag <"+qName+"> does not match end tag </" + name + ">", reader);*/
	}
	EndTag res(name);
	endTag=res;
	delete name;
	//startTag=startTag.previous;
	return endTag;
}
/** precondition: <? consumed */
LegacyEvent Parser::parsePI ()// throws IOException
{
//	printf("\tParser::parsePI() is reached\n");
	char buf[300];
	char *s;
	char c;
	char *t;
	t=reader.readTo('?');
	my_strcpy(buf,t);
	delete t;
	reader.read(); // ?
	while (reader.peek()!='>')
	{
		my_strncat(buf,Xml::PI_S,1);
		int r=reader.read();
		if (r==-1) 
		{
			//throw new PareException("Unexpected eof while reading PI", reader);
		}
		c=(char)r;
		s=&c;
		my_strncat(buf,s,1);
		t=reader.readTo('?');
		my_strcat(buf,t);
		delete t;
		reader.read();
	}
	reader.read(); // consume >
	LegacyEvent l(Xml::PROCESSING_INSTRUCTION, buf);
	leg=l;
	return leg;
}
/*void Parser::fixPrefixMap()
{
	
}*/
StartTag Parser::parseStartTag ()// throws IOException
{
	StartTag s1(reader);
	startTag=s1;
	char *qName;
	qName=new char[my_strlen(startTag.getName())+1];
	my_strcpy(qName,startTag.getName());
	my_strncat(qName,NULL,1);
	immediateClose=startTag.getDegenerated();
	if (immediateClose==0)
	{
		qNames[size++]=qName;
	}
	delete qName;
	reader.skipTo(Xml::GT_S);
	reader.read();
	return startTag;
}
TextEvent Parser::parseText ()// throws IOException
{
	char buf[200];
	char *s;
	char c;
	my_strcpy(buf,NULL);
	int nextChar;
	do
	{
		nextChar=reader.read();
		if (nextChar=='&')
		{
			c=parseCharacterEntity();
			s=&c;
			my_strncat(buf,s,1);				
		}
		else
		{
			c=(char) nextChar;
			s=&c;
			my_strncat(buf,s,1);
		}
		nextChar=reader.peek();
	}
	while (nextChar != '<' && nextChar != -1 && nextChar != 10 && nextChar != -9 && nextChar < 128 && nextChar !=0);
	TextEvent t1(buf);
	textEvent=t1;
	return textEvent;
}
/** precondition: &lt; consumed */
void Parser::parseSpecial ()// throws IOException
{
	switch (reader.peek())
	{
	case -1://throw new ParseException ("Unexpected end of file after reading <", reader);
	case '!': 
		reader.read();
		switch (reader.peek())
		{
		case '-':
			reader.read();
			parseComment();
			next=&leg;
			break;
		case '[':
			reader.read();
			parseCData();
			next=&textEvent;
			break;
		default:
			parseDoctype();
			next=&leg;
			break;			
		}
		break;
	case '?':
		reader.read();
		parsePI();
		next=&leg;
		break;
	case '/':
		reader.read();
		parseEndTag();
		next=&endTag;
		break;
	default:
		parseStartTag();
		next=&startTag;
		
	}
}
ParseEvent* Parser::read ()// throws IOException
{
	res=next;
		switch (reader.peek())
		{
		case '<':
//			printf("\tParser::read() is reached\n");
			reader.read();
			parseSpecial();
			break;
		case -1:
			if (my_strcmp(startTag.getName(),NULL)!=0)
			{
				//throw new ParseException ("End tag missing for: "+startTag,reader);
			}
			next=&endDoc;
			break;
		default:
			parseText();
			next=&textEvent;
		}
	return next;
}
char* Parser::readText ()
{
	char *temp;
	temp=new char[200];
	my_strcpy(temp,NULL);
	while (1==1) 
	{
		ParseEvent* event=read();
		switch (event->getType()) 
		{
			case '<'://throw new RuntimeException
			//("Illegal StartTag in readText: "+event);
				my_strcpy(temp,ER_TEXT);
				my_strcat(temp,event->getText());
				return temp;
				break;
			case 't':
				my_strcat(temp,event->getText());
				break;
			case '/':
			case '.':
				return temp;
		}
	}
	return temp;
}
