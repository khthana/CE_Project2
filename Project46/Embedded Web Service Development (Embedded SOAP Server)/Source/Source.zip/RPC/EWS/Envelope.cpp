//Envelope.cpp

#include <string.h>
#include "Envelope.h"
#include "Owen.h"

char* Envelope::marshall()
{
	char *temp;
	temp=new char[300+getLength()];

	//<SOAP-ENV:ENVELOPE
	my_strcpy(temp,Xml::LT_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::ENVELOPE);

	//attribute's Envelope
	char *t;
	if (attrHandler.getLength() > 0)
	{
		t=attrHandler.marshall();
		my_strcat(temp,t);
		delete t;
	}
	//>\n
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);

	if (header.getLength() > 0)
	{
		t=header.marshall();
		my_strcat(temp,t);
		delete t;
	}
	t=body.marshall();
	my_strcat(temp,t);
	delete t;

	//</SOAP-ENV:ENVLOPE>\n
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::ENVELOPE);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	return temp;
}
Envelope* Envelope::unmarshall(Parser *pr,ParseEvent *pe)
{
	Envelope *env;
	env=new Envelope();
	char *temp;
	temp=pe->getAttribute();
//	printf("Envelope>unmarshall>pe->getCountAttr() = %d\n",pe->getCountAttr());
	env->setAttribute(temp,pe->getCountAttr());
	if (temp!=NULL)
		delete temp;
	pe=pr->read();
	
	///may be improve for header part
	int count;
	char bodyTag[14];
	my_strcpy(bodyTag,Constants::SOAP_ENV);
	my_strcat(bodyTag,Xml::CL_S);
	my_strcat(bodyTag,Constants::BODY);
	my_strcat(bodyTag,NULL);
	Body *b;
	if ((my_strcmp(pe->getName(),bodyTag)==0) && (pe->getType()==Xml::START_TAG))
	{
		b=Body::unmarshall(pr,pe);
		env->setBody(*b);
		delete b;
	} else {
		env->setError(Constants::BODY);
	}		
	return env;
}
void Envelope::setSOAPObj(SOAPObj *soapobj){
//	printf("SOAPIN>ENV::setSOAPObj :begin\n");//debug 007
	soapobj->setEnvLength(this->getLength());
//	printf("SOAPIN>ENV::setSOAPObj :after getLength()\n");//debug 007
//	soapobj->setEnvAttrHandler(&attrHandler);
	soapobj->setAttribute(this->getAttribute());
//	printf("SOAPIN>ENV::setSOAPObj :end\n");//debug 008
}
