//Body.cpp
#include <stdio.h>
#include "Body.h"
#include "Owen.h"

char* Body::marshall()
{
	char* temp;
	temp=new char[getLength()+50];
	//<SOAP-ENV:Body
	my_strcpy(temp,Xml::LT_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::BODY);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	char *t;
	//marshall Methods
	t=method.marshall();
	my_strcat(temp,t);
	delete t;

	//marshall bodyEntries
	if (bodyEntries.getSize() > 0)
	{
		my_strcat(temp,bodyEntries.getStr());
	}
	//</SOAP-ENV:Body>
	//my_strcat(temp,Xml::ENTER_S);
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::BODY);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	return temp;
}
Body* Body::unmarshall(Parser* pr,ParseEvent *pe)
{
	Body *b;
	b=new Body();
	char *temp;
	int count;
	char bodyTag[14];
	my_strcpy(bodyTag,Constants::SOAP_ENV);
	my_strcat(bodyTag,Xml::CL_S);
	my_strcat(bodyTag,Constants::BODY);
	my_strcat(bodyTag,NULL);
	Method *m;
	m=Method::unmarshall(pr,pe);
	b->setMethod(*m);
	delete m;
	pe=pr->read();
	if ((pe->getType()!=Xml::END_TAG)&&(my_strcmp(pe->getName(),bodyTag)!=0))
	{
		b->setError(Constants::BODY);
	}
	return b;
}