// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: StartTag.h
#ifndef __STARTTAG_H
#define __STARTTAG_H
#include "ParseE.h"
#include "xmlr.h"
#include "Str.h"
#include "AttrHand.h"
#include "Owen.h"

class StartTag :public ParseEvent 
{
    private:
	Str name;
    Str name_space;
	//char attributes[200];//*attributes;
	AttributeHandler attrHandler;
	//int sizeAttr;
    int degenerated; //0=false 1=true
	Str error;
	//local variable to save data for return;
	//char *temp;

	public:
	StartTag();
	StartTag (const char * ns,const char * n,int degen);
	StartTag (XMLReader reader);
	~StartTag()
	{
		/*if (temp!=NULL)
			delete temp;*/
		/*if (attributes!=NULL)
			delete attributes;*/
	}
	StartTag& operator= (const StartTag& v);
	/** returns the attribute at the given index position */
	const AttributeHandler getAttributeHandler() const
	{	return attrHandler;	}

	char* getAttribute () const
	{ return attrHandler.getAttribute(); }//marshall()

	int getCountAttr() const
	{return attrHandler.getSize(); }//sizeAttr; }

	const char* getAttribute (int index) const	{
		return attrHandler.getAttribute(index);	}

	//char* getAttribute (const char* attrName)	{
	  //	return attrHandler.getAttribute(attrName);}

	/** retrurns if the element is degenerated */
	int getDegenerated () const			{ return degenerated; }
	/** returns the (local) name of the element started */
	const char* getName () const		{ return name.getStr(); }
	/** returns namespace */
	const char* getNamespace () const	{ return name_space.getStr(); }	
	/** returns the integer constant assigned to this event type
     	(Xml.START_TAG).  */
	int getType () const				{ return Xml::START_TAG; }
	/** returns the value of the attribute with the given name,
	or null, if not existiong */

	char* getValue (const char * attrname) const {
	return attrHandler.getValue(attrname); }

	const char* getText () const { return NULL; }
	int endCheck (ParseEvent* start)
	{
		//throw new RuntimeException ("unexpected element: "+this);
		return 0;// have to improve
	}
	void setError (const char* e)		{ error.set(e); }
	const char* getError () const		{ return error.getStr(); }
	/** Simplified (!) toString method for debugging
	purposes only */
	char* toString ();
	//void setStart(const XMLReader reader);
};
#endif