//SOAPRes.h

#ifndef ____SOAPRESPONSE_H
#define ____SOAPRESPONSE_H

#include "Parser.h"
#include "ParseE.h"
#include "Envelope.h"
#include "Header.h"
#include "Body.h"
#include "Xml.h"
#include "SoapDes.h"
#include "Owen.h"

class SOAPResponse
{
	public:
	SOAPResponse() {}

//	static char* buildResponse(Envelope *env,const char* param)
	static char* buildResponse(SOAPObj *soapobj,const char* param)
	{
		char *temp;
//	temp=new char[800+env->getLength()];
	temp=new char[800+soapobj->getEnvLength()];

	//<SOAP-ENV:ENVELOPE
	my_strcpy(temp,Xml::LT_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::ENVELOPE);

	//attribute's Envelope
	char *t;
//	AttributeHandler attrHandler=env->getAttributeHandler();
	///////if (attrHandler.getLength() > 0)
	///////{
		/////t=attrHandler.marshall();
//		t=env->getAttribute();
		t=soapobj->getAttribute();
		my_strcat(temp,t);
		my_strcat(temp,NULL);
		delete t;
	///////}
	//>\n
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	/*Header header=env->getHeader();
	if (header.getLength() > 0)
	{
		t=header.marshall();
		my_strcat(temp,t);
		delete t;
	}*/
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::BODY);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);

	my_strcat(temp,param);
//	my_strcat(temp,Xml::ENTER_S);

	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::BODY);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);


	//</SOAP-ENV:ENVLOPE>\n
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::ENVELOPE);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	my_strcat(temp,NULL);
	return temp;		
	}
};
#endif