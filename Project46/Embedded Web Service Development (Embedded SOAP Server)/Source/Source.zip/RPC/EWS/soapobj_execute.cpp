int SOAPObj::execute(){
	INT8U err;
	char *msg;
	void *p_tmp;
	TaskObj *taskobj = (TaskObj *)p_taskobj;
	OS_EVENT *soapinQ = (OS_EVENT *)taskobj->getMsgProtocolFactoryQ_In();
	OS_EVENT *soapoutQ = (OS_EVENT *)taskobj->getMsgProtocolFactoryQ_Out();
	OS_EVENT *dataMbox = (OS_EVENT *)taskobj->getDataMbox();
	RPCSocket *tsocket = taskobj->getRPCSocket();
	int task_number = taskobj->getTaskNumber();

	/*read data from tcp stack*/
	/*	-read header*/
	msg = tsocket->readSocket();
//	printf("Msg1 read %s\n",msg);//debug
//	msg = tsocket->readSocket();
//	printf("Msg2 read %s\n",msg);//debug
//	return 0;
	if(strncmp(msg,"POST",4)!=0){//if not "POST"
		/*Header not OK*/
		/*-print Error*/
		/*-close connection*/
		printf("HTTP Header Error\n");
		tsocket->closeSocket();
		return 1;//exit execution;
	}
	/*	-read request message*/
	msg = tsocket->readSocket();
	if(strncmp(msg,"<?",2)!=0){
		/*message not ok*/
		/*-print Error*/
		/*-close connection*/
		printf("HTTP Message Error\n");
		tsocket->closeSocket();
		return 1;
	}
	taskobj->setReqMsg(msg);

	/*parse by SOAPIN ->soapobj*/
	OSQPost(soapinQ,(void *)taskobj);
//	rpcobj = (RPCObj)OSMboxPend(dataMbox,0,&err);
	p_tmp = OSMboxPend(dataMbox,0,&err);
	printf("RWSTask No.%d has a message from SOAPIN\n",task_number);
//	return 0;
	/*create service obj*/
	//OSQueuePost(ServiceFactoryQueue,(void *)rpcobj);
	//servobj = (ServiceObj *)OSMboxPend(dataMbox,0,&err);
	/*run service obj*/
	//servobj.run();
	/*return result*/
	//servobj.setResult(rpcobj);
	/*pack result by SOAPOUT*/
//	OSQueuePost(SOAPOUTQueue,(void *)rpcobj);
	OSQPost(soapoutQ,(void *)taskobj);
	p_tmp = OSMboxPend(dataMbox , 0 , &err);
	printf("RWSTask No.%d has a message from SOAPOUT\n",task_number);
	printf("Respond Message :\n%s",taskobj->getResMsg());
	/*write back to requester*/
	tsocket->writeSocket(taskobj->getResMsg());
	/*close connection*/
	tsocket->closeSocket();
	return 0;
}
