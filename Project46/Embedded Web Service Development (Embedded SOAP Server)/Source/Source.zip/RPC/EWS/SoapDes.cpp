#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <conio.h>
#include "SoapDes.h"
#include "Owen.h"
#include "EWSParam.h"


const char* SOAPDeserialize::SERVICE="service";
const char* SOAPDeserialize::NAMESPACEID="namespaceid";
const char* SOAPDeserialize::INPUT="input";
const char* SOAPDeserialize::OUTPUT="output";
const char* SOAPDeserialize::PROVIDER="provider";
const char* SOAPDeserialize::MAPPING="mapping";
const char* SOAPDeserialize::MAP="map";
const char* SOAPDeserialize::XMLNS_X="xmlns:x";
const char* SOAPDeserialize::QNAME_A="qname";
const char* SOAPDeserialize::HEADERFILE="headerFile";
const char* SOAPDeserialize::XSI_TYPE="xsi:type";

const char* SOAPDeserialize::INT_S="xsd:int";
const char* SOAPDeserialize::DOUBLE_S="xsd:double";
const char* SOAPDeserialize::LONG_S="xsd:long";
const char* SOAPDeserialize::FLOAT_S="xsd:float";
const char* SOAPDeserialize::STRING_S="xsd:string";
//const char* CHAR__S="char* ";
const char* SOAPDeserialize::CHAR_S="xsd:char";
//const char* UNSIGNED_S="unsigned";
//const char* STATIC_S="static";
//const char* CONST_S="const";


void SOAPDeserialize::readServiceMap(const char* service_name)
{
//	printf("XXXXXXXXX readServiceMap passed XXXXXXXXX\n");

	serviceName="urn:xml-soap-demo-calculator";
//	serviceMethod="plus";
	serviceEncoding="http://schemas.xmlsoap.org/soap/encoding/";
//	serviceOutput="return=xsd:double ";
//	serviceQname="x:argument";
//	serviceQnameNS="urn:xml-soap-demo-calculator";
	//serviceMap=NULL

}
int SOAPDeserialize::isNative(const char* s)
{
	if ((my_strcmp(s,SOAPDeserialize::INT_S)==0)||(my_strcmp(s,SOAPDeserialize::DOUBLE_S)==0)||(my_strcmp(s,SOAPDeserialize::LONG_S)==0)
		||(my_strcmp(s,SOAPDeserialize::FLOAT_S)==0)||(my_strcmp(s,SOAPDeserialize::STRING_S)==0)||(my_strcmp(s,SOAPDeserialize::CHAR_S)==0))
		return 1;
	else
		return 0;
}
char* SOAPDeserialize::serialOutput(EWSParam *results)
{
	XMLWriter x1;
	char *temp;int nscount=0;
	Str prefix=Constants::NS;
	temp=new char[30];
	my_strcpy(temp,NULL);
	itoa(++nscount,temp,10);
	prefix+=temp;
	delete temp;
//	printf("prefix=%s\n",prefix.getStr());
	Str name=serviceMethod;
	name+=Constants::RESPONSE;
	x1.writeStartTag(prefix.getStr(),name.getStr());
	temp=Xml::encode(serviceName.getStr());///m_ns);
	//delete m_ns;
	x1.writeAttribute(Constants::XMLNS,prefix.getStr(),temp);
	delete temp;
	Attribute *attr;
	char *a,ch;
	a=new char[200];
	char *ptr1;
	Str classMap;
	
//owen
/*
	
	FILE *value;
	value= fopen("out1.txt", "r+");
	fseek(value,0,SEEK_SET);
	int i=0;	
	ch=fgetc(value);
	i=0;	
	while (ch!=EOF)	{
		if (i>200)
			break;
		if (ch!=-0 && ch!='\n')
			a[i++]=ch;
		if (ch=='\n')
			a[i++]=';';
		ch=fgetc(value);
	}
	a[i++]=';';
	a[i]='\0';
	fclose(value);
*/
//owen


//owen
//	sample_OUTTXT(a);
//owen


	Str As=a;
	delete a;
	x1.writeAttribute(Constants::SOAP_ENV,Constants::ENCODING_STYLE,serviceEncoding.getStr());
	results->setPointToStart();
	results->next();
//	results = results->getStatePoint();
	EWSParam::recurParam(results,&x1);
/*	
	x1.writeStartTag(Constants::RETURN);
	if (serviceOutput.getSize()>2)
	{
		char *hitt=serviceOutput.cut('=');
		delete hitt;
		hitt=serviceOutput.cut(' ');
		x1.writeAttribute(Constants::XSI,Constants::TYPE,hitt);
		a=As.cut(';');
		x1.writeRaw(a);
		delete a;
		delete hitt;
	}
*/	

	x1.closeAll();
	//cout<<x1.getWriter()<<endl;
	/////getch();
	temp=new char[my_strlen(x1.getWriter())+1];
	my_strcpy(temp,x1.getWriter());
	my_strcat(temp,NULL);
	return temp;	
}

int SOAPDeserialize::checkOrder(const char* fileName,const char* params)
{
	/*int i=0;
	char ch,*a;
	a=new char[1500];
	FILE *stream;
	stream=fopen(fileName,"r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>1500)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	a[i]='\0';
	fclose(stream);
	Attribute *attr;
	Str name,name1,type,type1;
	Parser *pr,*pr1;
	ParseEvent *pe,*pe1;
	pr=new Parser();
	pr->setXMLReader(a);
	delete a;
	pr1=new Parser();
	pr1->setXMLReader(params);
	while (pr->isRead())
	{
		pe1=pr1->read();
		pe=pr->read();
		name=pe->getName();
		name1=pe1->getName();
		type=pe->getValue();
		type1=pe->getValue();
		if (my_strcmp(name.getStr(),name1.getStr())!=0)
			return 0;
		else if (my_strcmp(type.getStr(),type1.getStr())!=0)
			return 0;
		else if ()
		{
		}
	}*/
	return 0;
	

}
