//SoapReq.h

#ifndef __SOAPREQUEST_H
#define __SOAPREQUEST_H

#include<stdlib.h>
#include<stdio.h>
#include<iostream.h>
#include<conio.h>
#include"Parser.h"
#include"ParseE.h"
#include"Soappar.h"
#include"SoapDes.h"
#include"SoapRes.h"
#include "Owen.h"
class SOAPRequest
{
	public:
	SOAPRequest() {}
	char far *buildEnv() ;
/*	
	 char far *buildEnv() {
	clrscr();
	const max=2000;
	char a[max];
	char ch;
	int i=0;
	
    
	FILE *stream;
	stream=fopen("test1.txt","r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>max)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	//close service description file
	fclose(stream);  //	break;
	a[i]='\0';
	Envelope *env;
	env=SOAPParser::parse(a);

	char* fileN="sd1.txt\0";
	char* met="getAddressFromName\0";
	if (SOAPParser::checkMethodName(met,fileN))
	{
		printf("right");
	}
	else
		printf("false");
	clrscr();
	SOAPDeserialize d;
	char *m="getAddressFromName\0";
	d.setServiceMethod(m);
	char *f="sd1.txt\0";
	d.readServiceMap(f);
	char* soap=d.serialOutput();
	printf("soap=\n%s",soap);
	char* final=SOAPResponse::buildResponse(env,soap);
	delete soap;
	printf("hello\n%s",final);
	delete final;
	delete env;
	}
*/
};
#endif