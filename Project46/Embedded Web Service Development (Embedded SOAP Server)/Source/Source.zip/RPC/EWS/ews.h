#include "\software\ucos-ii\ex1_x86l\source\ews\str.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\const.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\owen.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\qname.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\attr.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\attrhand.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\param.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\xml.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\xmlw.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\xmlr.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\parsee.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\starttag.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\prefix.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\endtag.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\texte.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\enddoc.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\legacy.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\parser.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\fault.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\header.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\method.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\body.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\envelope.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\soapdes.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapenc.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\soappar.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapreq.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapres.h"

//#include "\software\ucos-ii\ex1_x86l\source\ews\ewsnode.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\ewsparam.h"
#include "\software\ucos-ii\ex1_x86l\source\ews\soapobj.h"

#include "\software\ucos-ii\ex1_x86l\source\ews\httpsock.h"
