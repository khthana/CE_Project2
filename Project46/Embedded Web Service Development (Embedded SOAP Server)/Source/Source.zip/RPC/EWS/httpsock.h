
#ifndef HTTPSOCKET
#define HTTPSOCKET

//#include "includes.h"
//#include "myinit.h"
//#include "socketobj.h"
#include "rpcsock.h"

static const char msg1[]="POST \0";
static const char msg2[]="<?xml version='1.0' encoding='UTF-8'?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\"><SOAP-ENV:Body><ns1:minus xmlns:ns1=\"urn:xml-soap-demo-calculator\" SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><arg1 xsi:type=\"xsd:double\">7.0</arg1><arg2 xsi:type=\"xsd:double\">3.0</arg2></ns1:minus></SOAP-ENV:Body></SOAP-ENV:Envelope>\0";
//static const char msg2[]="<?xml version='1.0' \0";

class HTTPSocket :public RPCSocket{
public:
	HTTPSocket(struct socketobj *);
	~HTTPSocket();
	void setDesMbox(void *);

	char* readSocket();
	int writeSocket(char *);
	int closeSocket();
};

#endif