// AttrHandler.h

#ifndef __ATTRIBUTEHANDLER_H
#define __ATTRIBUTEHANDLER_H
#include <iostream.h>
#include <stdio.h>
#include "Xml.h"
#include "Attr.h"
#include "Str.h"
#include "QName.h"
#include "Owen.h"
class AttributeHandler
{
	private:
	Str attributes[4];
	int size;

	public:
	//Constructor
	AttributeHandler()	{ size=0;	}

	AttributeHandler(const char* attr,int s)
	{	setAttribute(attr,s);	}

	~AttributeHandler(){}

	AttributeHandler& operator=(const AttributeHandler& that);
	
	//Function
	void setAttribute(const char* a,int sizeA);

	int getSize() const
	{	return size;	}

	char* getAttribute() const;

	const char* getAttribute(QName attrQName) const;
	char* getValue(const char* attrName) const	;
	const char* getAttribute(int index) const
	{	return attributes[index].getStr();	}

	int getLength() const
	{	return attributes[0].getSize()+attributes[1].getSize()+attributes[2].getSize()+attributes[3].getSize(); }

	QName* attrToQName(int index) const;
	
	//May be Add soon
	//function that save namespaceURI & prefix into NSStack coming soon======
	//populateNSStack

	char* marshall();

	static AttributeHandler* unmarshall(const char* src,int s);	
};
#endif