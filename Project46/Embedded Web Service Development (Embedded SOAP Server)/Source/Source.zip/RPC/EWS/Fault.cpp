// Fault.cpp
//
#include <string.h>
#include "Fault.h"
#include "Owen.h"
char* Fault::marshall()	{
	char *temp=new char[getLength()+200];
	//Determine the prefix
	//fault body
	my_strcpy(temp,Xml::LT_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::FAULT);
	//Attribute marshall()
	char *t;
	if (attrHandler.getLength() > 0)
	{
		t=attrHandler.marshall();
		my_strcat(temp,t);
		delete t;
	}
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
		//fault code
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Constants::FAULT_CODE);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,faultCode.getStr());
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::FAULT_CODE);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
		//fault string
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Constants::FAULT_STRING);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,faultString.getStr());
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::FAULT_STRING);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
		//Generate faultactor element if value is not null
	if (my_strcmp(faultActorURI.getStr(),NULL)!=0)		{
		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Constants::FAULT_ACTOR);
		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,faultActorURI.getStr());
		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Xml::SL_S);
		my_strcat(temp,Constants::FAULT_ACTOR);
		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,Xml::ENTER_S);
	}
		//If there are detail entries, generate the <detail> element,
	// and serialize the detail entries.
/******MUST improve this filed*****************/
	if (my_strcmp(detailEntries.getStr(),NULL)!=0)	{
		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Constants::DETAIL);
		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,detailEntries.getStr());
		my_strcat(temp,Xml::LT_S);
		my_strcat(temp,Xml::SL_S);
		my_strcat(temp,Constants::DETAIL);
		my_strcat(temp,Xml::GT_S);
		my_strcat(temp,Xml::ENTER_S);			
	}
	// Serialize any fault entries (in addition to <faultcode>, <faultstring>,
	// <faultactor>, and <detail>).
/******MUST improve this filed*****************/	
	if (my_strcmp(faultEntries.getStr(),NULL)!=0)
	{}
	
	my_strcat(temp,Xml::LT_S);
	my_strcat(temp,Xml::SL_S);
	my_strcat(temp,Constants::SOAP_ENV);
	my_strcat(temp,Xml::CL_S);
	my_strcat(temp,Constants::FAULT);
	my_strcat(temp,Xml::GT_S);
	my_strcat(temp,Xml::ENTER_S);
	return temp;
}