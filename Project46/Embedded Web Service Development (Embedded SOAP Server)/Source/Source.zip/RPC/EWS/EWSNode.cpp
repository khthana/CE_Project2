#include "EWSParam.h"
#include <string.h>

EWSNode::EWSNode(const char* pname,const char* pvalue){
	property_name = new char[strlen(pname)+1];
	property_value = new char[strlen(pvalue)+1];
	strcpy(property_name , pname);
	strcpy(property_value , pvalue);
	nextNode=NULL;
	property_type = NULL;
	property_count=0;
}
EWSNode::EWSNode(const char* pname,const char* ptype,const char* pvalue){
	EWSNode(pname,ptype,pvalue,0);
}
EWSNode::EWSNode(const char* pname,const char* ptype,const char* pvalue,int pcount){
	property_name = new char[strlen(pname)+1];
	property_type = new char[strlen(ptype)+1];
	property_value = new char[strlen(pvalue)+1];
	strcpy(property_name , pname);
	strcpy(property_type , ptype);
	strcpy(property_value , pvalue);
	nextNode=NULL;
	property_count = pcount;
}
EWSNode::~EWSNode(){
	delete property_name;
	delete property_value;
	delete property_type;
	if(nextNode!=NULL)
		delete nextNode;
}
EWSNode* EWSNode::getNextNode(){
	return nextNode;
}
void EWSNode::setNextNode(EWSNode* node){
	nextNode = node;
}
int EWSNode::isMatchProperty(char* pname){
	return strcmp(property_name , pname);
}
char* EWSNode::getName(){
	return property_name;
}
char* EWSNode::getType(){
	return property_type;
}
char* EWSNode::getValue(){
	return property_value;
}
int EWSNode::getCount(){
	return property_count;
}
void EWSNode::setName(char* pname){
	delete property_name;
	property_name = new char[strlen(pname)+1];
	strcpy(property_name , pname);
}
void EWSNode::setType(char* ptype){
	delete property_type;
	property_type = new char[strlen(ptype)+1];
	strcpy(property_type , ptype);
}
void EWSNode::setValue(char* pvalue){
	delete property_value;
	property_value = new char[strlen(pvalue)+1];
	strcpy(property_value , pvalue);
}
void EWSNode::setCount(int pcount){
	property_count = pcount;
}