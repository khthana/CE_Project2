//#include<fstream.h>
#include<string.h>
//#include<conio.h>
//#include<stdlib.h>
#include<stdio.h>
//#include<iostream.h>
#include"Parser.h"
#include"ParseE.h"
//#include "Owen.h"
#include "Soappar.h"
#include "registry.h"
#include "fileutil.h"
#include "xml2reg.h"
#include "s_const.h"

Envelope* SOAPParser::parse(const char* message)
{
	Envelope *env;
	env=NULL;
//owen
//		cout<<"Ed....1"<<endl;
	Parser *pr=0;
	pr =new Parser();
//		if(pr==0)printf("pr not alive\n");
//		cout<<"Ed....2"<<endl;
//owen
	pr->setXMLReader(message);
	ParseEvent *pe;
	Str error;
	char envTag[18];
	my_strcpy(envTag,Constants::SOAP_ENV);
	my_strcat(envTag,Xml::CL_S);
	my_strcat(envTag,Constants::ENVELOPE);
	my_strcat(envTag,NULL);
		//read to skip PI
	pe=pr->read();
//		printf("Soappar:parse()>pe->getType() = %d\n",pe->getType());
	pe=pr->read();
//		printf("Soappar:parse()>pe->getType() = %d\n",pe->getType());
//		printf("Soappar:parse()>my_strcmp(pe->getName(),envTag) = %d\n",my_strcmp(pe->getName(),envTag));
	if ((pe->getType()==Xml::START_TAG) && (my_strcmp(pe->getName(),envTag)==0 ))	{
//			printf("\tBefore Envelope::unmarshall\n");
		env=Envelope::unmarshall(pr,pe);
			/*if (my_strcmp(env->getError(),NULL)!=0)	{
				error=env->getError();	}
			else {
				if (my_strcmp(env->getBody()->getError(),NULL)!=0)	{
					error=env->getBody()->getError();	}
				//else method parameter header
			}*/
	}
	else
//			printf("\terror\n");
		error=Constants::ENVELOPE;
	return env;
}

char* SOAPParser::getServiceName(const char *n)
{
	//get from registry
	char *reg_filename=readFile("s_match.xml");
	Registry *reg_temp=xmlToRegistry(reg_filename);
	delete[] reg_filename;
	
	return reg_temp->queryValueOfKeyValues(n,ServiceConsts::SERVICE_CALL_NAME);
}
