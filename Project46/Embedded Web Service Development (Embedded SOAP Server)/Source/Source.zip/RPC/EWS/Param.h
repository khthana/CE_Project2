//Parameter.h

#ifndef __PARAMETER_H
#define __PARAMETER_H
#include <stdio.h>
#include "Str.h"
#include "Const.h"
#include "AttrHand.h"
#include "Qname.h"
#include "Parser.h"
#include "ParseE.h"
#include "SOAPObj.h"
#include "EWSParam.h"
#include "Owen.h"

class Parameter
{
	private:
	Str params;
	Str error;
	
	public:
	Parameter()	{  }

	Parameter(const char* pa) {
		params=pa;	}

	Parameter& operator=(const Parameter& that)	{
		error=that.getError();
		params=that.getParameter();
		return *this;	}

	int getLength() const {
		return params.getSize();	}

	void setParameter(const char* p) {
		params=p;	}
	
	const char* getParameter() const{
		return params.getStr();	}
	void setSOAPObj(SOAPObj *soapobj) ;

	void setError(const char* e) {
		error=e;	}
	
	const char* getError() const	{
		return error.getStr();	}
	char* marshall() {
		char* temp;
		temp=new char[getLength()+1];
		my_strcpy(temp,params.getStr());
		my_strcat(temp,NULL);
		return temp; }
};
#endif