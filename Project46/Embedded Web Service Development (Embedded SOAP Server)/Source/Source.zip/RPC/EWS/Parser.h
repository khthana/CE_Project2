// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: Dparser.h
#ifndef __PARSER_H
#define __PARSER_H

#include<iostream.h>

#include "xml.h"
#include "prefix.h"
#include "attr.h"
#include "ParseE.h"
#include "xmlr.h"
#include "StartTag.h"
#include "Legacy.h"
#include "EndDoc.h"
#include "EndTag.h"
#include "TextE.h"
#include "Owen.h"
//#include "PException.h"

class Parser {

    private:
	int size;
    int immediateClose;	// 0=false 1= true//boolean
	int processNamespaces;  //0=false 1=true;
	ParseEvent* next;
	ParseEvent* res;
    XMLReader reader;
    // *********waitforminute Vector qNames = new Vector ();
	Str qNames[30];//char qNames[10][100];
	EndDocument endDoc;
	LegacyEvent leg;
	char rootElement[40];
	//char temp[200];

	public:
//owen : org is in private scope
    StartTag startTag;
	EndTag endTag;
	TextEvent textEvent;
	PrefixMap prefixMap;
//owen
	static const char* ER_TEXT;

    /** creates a new Parser based on the give reader */
	Parser();
	Parser (const char* r);   // throws IOException
	void setProcessNamespaces (int processNs) //Boolean
	{
		processNamespaces=processNs;
	}
	void setXMLReader(const char* r)
	{
		reader.setContent(r);
		//read();
	}
	/** Convenience method for reading text content. Reads text until
        an EndTag or EndDocument is reached.  The EndTag is consumed, too.
        The concatenated text String is returned. If the
	method reaches an StartTag, an Exception is thrown */
	char* readText ();
	/** amp is already consumed, consume incl. comma */
    const char parseCharacterEntity ();  // throws IOException

	/* precondition: &lt;!- consumed */
	LegacyEvent parseComment ();   // throws IOException

	/* precondition: &lt! consumed */ 
	LegacyEvent parseDoctype ();   // throws IOException

	TextEvent parseCData ();       // throws IOException
		
	/* precondition: &lt;/ consumed */
	EndTag parseEndTag ();		   // throws IOException

	/** precondition: <? consumed */
	LegacyEvent parsePI ();		   // throws IOException    

	StartTag parseStartTag ();	   // throws IOException

	TextEvent parseText ();		   // throws IOException

	/** precondition: &lt; consumed */
	void parseSpecial ();		   // throws IOException

    /** returns the next parse event without consuming it */
    ParseEvent* peek () const
	{
		return next;
    }
	int isRead()
	{ return reader.peek()!='\n' ? 1 : 0; }
	
	
	ParseEvent* read ();			   // throws IOException
	
    int getLineNumber () const
	{
		return reader.getLineNumber ();
    }
};
#endif