#ifndef RPCPARAM
#define RPCPARAM
#include "RPCNode.h"

class RPCParam
{
	protected:
		RPCNode* start_node;
		RPCNode* current_node;
		RPCNode* state_node;
		int count_node;
		RPCNode* addNode(RPCNode *node){
			current_node->setNextNode(node);
			current_node = node;
			count_node++;
			return current_node;
		}
	public:
		RPCParam(){};
		~RPCParam(){};
		virtual char* valueOf(char *property_name) =0;
		virtual char* typeOf(char *property_name) =0;
		virtual void* extraPointerOf(char *property_name) =0;

		RPCNode* addParam(const char *pname,const char *pvalue){
			return addNode(new RPCNode(pname ,pvalue));
		}
		RPCNode* addParam(const char *pname,const char *ptype,const char *pvalue){
			return addNode(new RPCNode(pname , ptype,pvalue,0));
		}
		RPCNode* addParam(const char *pname,const char *ptype,const char *pvalue,int pcount){
			return addNode(new RPCNode(pname , ptype,pvalue,pcount));
//			printf("xxxxxxxxx checkpoint addParam xxxxxxxxxx\n");
		}
		void setPointToStart(){
			state_node = start_node;
		}
		void next(){
			state_node = state_node->getNextNode();
		}
		RPCNode* getStartNode(){
			return start_node;
		}
		RPCNode* getStatePoint(){
			return state_node;
		}
		//append code for registry :reg_
		void updateValue(const char *pname,const char *pvalue){
			//search for pname = value name
			RPCNode *found_node;
			found_node=searchNode(pname);
			//if not found,addParam
			if(found_node==NULL){
				found_node=addParam(pname,pvalue);
			}else{
				//"set" (update value) found or new created node
				found_node->setValue(pvalue);
			}
		}
		void updateType(const char *pname,const char *ptype){
			//search for pname = value name
			RPCNode *found_node;
			found_node=searchNode(pname);
			//if not found,addParam
			if(found_node==NULL){
//				found_node=addParam(pname,pvalue);
			}else{
				//"set" (update value) found or new created node
				found_node->setType(ptype);
			}
		}
		void updateExtraPointer(const char *pname,void *ep){
			RPCNode *found_node;
			found_node=searchNode(pname);
			if(found_node==NULL){}
			else{
				found_node->setExtraPointer(ep);
			}
		}
		RPCNode* searchNode(const char *pname){
			//char* ptype = NULL;
			RPCNode * temp1 , *temp2;
			RPCNode *result_node=NULL;
			temp1 = start_node;
			while(temp1->getNextNode()!= NULL){
				temp2 = temp1->getNextNode();
				if(temp2->isMatchProperty(pname) == 0){
					result_node = temp2;
					break;
				}
				temp1 = temp2;
			}
			return result_node;
		}
		void deleteValue(const char *pname){
			RPCNode * temp1 , *temp2;
			RPCNode *result_node=NULL;
			temp1 = start_node;
			while(temp1->getNextNode()!= NULL){
				temp2 = temp1->getNextNode();
				if(temp2->isMatchProperty(pname) == 0){
					temp1->setNextNode(temp2->getNextNode());
					temp2->setEnd();
					delete temp2;
//					result_node = temp2;
					break;
				}
				temp1 = temp2;
			}
//			return result_node;
		}			
};

#endif