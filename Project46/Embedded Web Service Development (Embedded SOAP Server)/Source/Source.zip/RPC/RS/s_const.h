#ifndef SERVICE_CONST
#define SERVICE_CONST

class ServiceConsts
{
public:
	static const char* TYPE_STRING;
	static const char* SERVICE_STATUS;
	static const char* SERVICE_STATUS_ON;
	static const char* SERVICE_STATUS_OFF;
	static const char* SERVICE_NAME;
	static const char* SERVICE_FULLNAME;

	static const char* SERVICE_OBJ_POINTER;

	static const char* FAULT_SERVICE;

	static const char* SERVICE_CALL_NAME;
	static const char* SERVICE_CALL_TYPE;
};

#endif