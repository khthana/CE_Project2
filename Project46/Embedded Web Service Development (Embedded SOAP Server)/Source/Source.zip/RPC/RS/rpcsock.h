#ifndef RPCSOCK
#define RPCSOCK

#include <string.h>
#include "sockobj.h"

class RPCSocket{
protected:
	struct socketobj *sock_obj;
	void *p_tmp;
	int state;
public:
	RPCSocket(){};
/*
	RPCSocket(struct socketobj *p_rpcsock){
		sock_obj = p_rpcsock;
		state = 0;
	}
*/
	~RPCSocket(){};

	virtual char* readSocket() =0;
	virtual int writeSocket(char *data) =0;
	virtual int closeSocket() =0;

	void setDesMbox(void *p_data_mbox){
		sock_obj->data_mbox=p_data_mbox;
	}
};

#endif