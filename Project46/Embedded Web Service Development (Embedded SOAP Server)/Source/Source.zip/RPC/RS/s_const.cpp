#include "s_const.h"

const char* ServiceConsts::TYPE_STRING="string";
const char* ServiceConsts::SERVICE_STATUS="Status";
const char* ServiceConsts::SERVICE_STATUS_ON="on";
const char* ServiceConsts::SERVICE_STATUS_OFF="off";
const char* ServiceConsts::SERVICE_NAME="Name";
const char* ServiceConsts::SERVICE_FULLNAME="FullName";

const char* ServiceConsts::SERVICE_OBJ_POINTER="service_obj_pointer";
const char* ServiceConsts::FAULT_SERVICE="Fault_service";

const char* ServiceConsts::SERVICE_CALL_NAME="ServiceCallName";
const char* ServiceConsts::SERVICE_CALL_TYPE="ServiceCallType";