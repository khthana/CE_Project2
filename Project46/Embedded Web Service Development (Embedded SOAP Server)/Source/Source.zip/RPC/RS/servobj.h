#ifndef SERVICE_OBJ
#define SERVICE_OBJ

#include "Registry.h"
#include "s_const.h"
#include <string.h>
#include <stdio.h>

class ServiceObj{
private:
	char *service_name;

protected:
	RPCParam *param,*result;
	
	void *ServiceDataQ,*ServiceTaskMbox;
	
public:
	ServiceObj(const char *serv_name){
		setServiceName(serv_name);
	}
	~ServiceObj(){
		if(service_name!=NULL)
			delete[] service_name;
	};

	void setServiceName(const char *serv_name){
		if(service_name!=NULL){
			delete[] service_name;
		}
		service_name=new char[strlen(serv_name)+1];
		strcpy(service_name,serv_name);
	}

	char* getServiceName(){
		return service_name;
	}

	void setServiceDataQ(void *serv_data_q){
		ServiceDataQ=serv_data_q;
	}
	void *getServiceDataQ(){
		return ServiceDataQ;
	}

	void setServiceTaskMbox(void *serv_task_mbox){
		ServiceTaskMbox=serv_task_mbox;
	}
	void *getServiceTaskMbox(){
		return ServiceTaskMbox;
	}

	void activate(Registry *registry){
		registry->updateKeyValue(service_name,ServiceConsts::SERVICE_STATUS,ServiceConsts::TYPE_STRING,ServiceConsts::SERVICE_STATUS_ON);
	}
	void deactivate(Registry *registry){
		registry->updateKeyValue(service_name,ServiceConsts::SERVICE_STATUS,ServiceConsts::TYPE_STRING,ServiceConsts::SERVICE_STATUS_OFF);
	}
	void regist(Registry *registry){
//		registry->updateKeyValue(service_name,ServiceConsts::SERVICE_OBJ_POINTER,ServiceConsts::TYPE_STRING,"",ServiceDataQ);
		registry->updateKeyValue(service_name,ServiceConsts::SERVICE_OBJ_POINTER,ServiceConsts::TYPE_STRING,"",this);
		printf("Service is registed\n");
	}
	int isActivated(Registry *registry){
		return strcmp(ServiceConsts::SERVICE_STATUS_ON,registry->queryValueOfKeyValues(service_name,ServiceConsts::SERVICE_STATUS));
	}
	virtual void init(RPCParam *p_param,RPCParam *p_result)=0;
	virtual void run()=0;
};

#endif