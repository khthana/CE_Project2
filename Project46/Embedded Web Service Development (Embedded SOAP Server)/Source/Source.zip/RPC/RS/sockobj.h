#include "lwip/sockets.h"

struct socketobj 
{
    struct socketobj *next;
    int socket;
    struct sockaddr_in cliaddr;
    socklen_t clilen;
	int port_num;

	int read_status;
	int write_status;
	int close_status;

	void *data_mbox;
	void *buf_q;

	char data_buf[500];
};
