#ifndef	RPCNODE
#define RPCNODE

#include "s_const.h"
#include <stdio.h>
#include <string.h>

class RPCNode
{
	private:
		RPCNode* nextNode;
		char *property_name;
		char *property_type;
		char *property_value;
		void *extra_pointer;
		int property_count;
	public:
		RPCNode(const char* pname,const char* pvalue){
			property_name = new char[strlen(pname)+1];
			property_value = new char[strlen(pvalue)+1];
			strcpy(property_name , pname);
			strcpy(property_value , pvalue);
			nextNode=NULL;
			property_type = NULL;
			extra_pointer=NULL;
			property_count=0;
		}
		RPCNode(const char* pname,const char* ptype,const char* pvalue){
			RPCNode(pname,ptype,pvalue,0);
		}
		RPCNode(const char* pname,const char* ptype,const char* pvalue,int pcount){
//			printf("ttttttttttttttttttttt RPCNode ttttttttttttttttttttttt\n");
			property_name = new char[strlen(pname)+1];
			property_type = new char[strlen(ptype)+1];
			property_value = new char[strlen(pvalue)+1];
			strcpy(property_name , pname);
			strcpy(property_type , ptype);
			strcpy(property_value , pvalue);
			nextNode=NULL;
			extra_pointer=NULL;
			property_count = pcount;
//			printf("ppppppp property_name pppppppppp = %s\n",property_name);
//			printf("ppppppp property_type pppppppppp = %s\n",property_type);
//			printf("ppppppp property_value pppppppppp = %s\n",property_value);
		}
		~RPCNode(){
			delete[] property_name;
			if(property_value!=NULL)
				delete[] property_value;
			if(property_type!=NULL)
				delete[] property_type;
			if(nextNode!=NULL)
				delete nextNode;
		}
		RPCNode* getNextNode(){
			return nextNode;
		}
		int isMatchProperty(const char* pname){
			return strcmp(property_name , pname);
		}
		char* getValue(){
			return property_value;
		}
		char* getType(){
			return property_type;
		}
		char* getName(){
			return property_name;
		}
		int getCount(){
			return property_count;
		}
		void *getExtraPointer(){
			return extra_pointer;
		}
		void setNextNode(RPCNode* node){
			nextNode = node;
		}
		void setName(const char* pname){
			if(property_name!=NULL)
				delete[] property_name;
			property_name = new char[strlen(pname)+1];
			strcpy(property_name , pname);
		}
		void setType(const char* ptype){
			if(property_type!=NULL)
				delete[] property_type;
			property_type = new char[strlen(ptype)+1];
			strcpy(property_type , ptype);
		}
		void setValue(const char* pvalue){
//			if(strcmp(property_type,ServiceConsts::TYPE_STRING)==0){
				if(property_value!=NULL)
					delete[] property_value;
				property_value = new char[strlen(pvalue)+1];
				strcpy(property_value , pvalue);
//			}else{
//				property_value=(char *)pvalue;
//				printf("^^^^Oh!,pointer is not \"string\"^^^^\n");
//			}
		}
		void setCount(int pcount){
			property_count = pcount;
		}
		void setExtraPointer(void *ep){
			extra_pointer=ep;
		}
		void setEnd(){
			nextNode=NULL;
		}
};

#endif