#ifndef REGKEY
#define REGKEY

//#include "RPCParam.h"
#include "EWSParam.h"
#include <string.h>

class RegKey{

private:
	char *key_name;
	RPCParam *p_KeyValues;
	RegKey *next;

public:
	RegKey(const char *kname){
		p_KeyValues=NULL;
		next=NULL;
		key_name=NULL;
		setKeyName(kname);
		//create RPCParam
		p_KeyValues=new EWSParam(kname);
	}
	~RegKey(){
		delete[] key_name;
		if(next!=NULL)
			delete next;
	//	if(p_KeyValues!=NULL)
	//		delete p_KeyValues
		delete p_KeyValues;
	}

	char* getKeyName(){
		return key_name;
	}
	void setKeyName(const char *kname){
		if(key_name!=NULL)
			delete[] key_name;
		key_name = new char[strlen(kname)+1];
		strcpy(key_name,kname);	
	}
		
	RPCParam* getP_KeyValues(){
		return p_KeyValues;
	}
	void setP_KeyValues(RPCParam *p_KeyValues){
		this->p_KeyValues = p_KeyValues;
	}

	RegKey* getNextKey(){
		return next;
	}
	void setNextKey(RegKey *reg_key){
		next=reg_key;
	}
	char* queryValueOfValues(const char *value_name){
		return p_KeyValues->valueOf((char *)value_name);
	}
	char* queryTypeOfValues(const char *value_name){
		return p_KeyValues->typeOf((char *)value_name);
	}
	void* queryExtraPointerOfValues(const char *value_name){
		return p_KeyValues->extraPointerOf((char *)value_name);
	}
	void updateValueOfValues(const char *value_name,const char *value){
		p_KeyValues->updateValue(value_name,value);
	}
	void updateTypeOfValues(const char *value_name,const char *type){
		p_KeyValues->updateType(value_name,type);
	}
	void updateExtraPointerOfValues(const char *value_name,void* ep){
		p_KeyValues->updateExtraPointer(value_name,ep);
	}
	void deleteValue(char *value_name){
		p_KeyValues->deleteValue(value_name);
	}
};


#endif