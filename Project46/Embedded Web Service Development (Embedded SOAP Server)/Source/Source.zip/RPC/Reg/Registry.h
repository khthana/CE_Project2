#ifndef REGISTRY
#define REGISTRY

#include "RegKey.h"

class Registry{
private:
	char* registry_name;
	RegKey *start_key;
	RegKey *current_key;
	int key_count;

	RegKey* addKey(const char *key_name);

public:
	Registry(char *rname);
	~Registry();

	char* getRegistryName();
	void setRegistryName(char *rname);
	
	char *queryValueOfKeyValues(const char *key_name,const char *value_name);
	char *queryTypeOfKeyValues(const char *key_name,const char *value_name);
	void *queryExtraPointerOfKeyValues(const char *key_name,const char *value_name);

	void updateKeyValue(const char *key_name,const char *value_name,const char *value_type,const char *value);
	void updateKeyValue(const char *key_name,const char *value_name,const char *value_type,const char *value,void *ep);

	void deleteKeyValue(char *kname,char *value_name);

	void deleteKey(char *key_name);

	RegKey* searchKey(const char *key_name);
};

#endif