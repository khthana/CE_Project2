#include "Registry.h"
#include <string.h>
#include <stdio.h>


RegKey* Registry::addKey(const char *key_name){
	if(start_key==NULL){
		start_key=new RegKey(key_name);
		current_key=start_key;
	}else{
		current_key->setNextKey(new RegKey(key_name));
		current_key=current_key->getNextKey();
	}
	key_count++;
	printf("Key:%s is added\n",key_name);
	return current_key;
}
Registry::Registry(char *rname){
	registry_name=NULL;
	start_key=NULL;
	current_key=NULL;
	key_count=0;
	setRegistryName(rname);
}
Registry::~Registry(){
	if(registry_name!=NULL)
		delete[] registry_name;
	delete start_key;
}

char* Registry::getRegistryName(){
	return registry_name;
}
void Registry::setRegistryName(char *rname){
	if(registry_name!=NULL)
		delete[] registry_name;
	registry_name=new char[strlen(rname)+1];
	strcpy(registry_name,rname);
}
	
char *Registry::queryValueOfKeyValues(const char *key_name,const char *value_name){
	char *value_of_value=NULL;
	RegKey *found_key=searchKey(key_name);
	if(found_key!=NULL){
		value_of_value=found_key->queryValueOfValues(value_name);
	}
	return value_of_value;
}
char *Registry::queryTypeOfKeyValues(const char *key_name,const char *value_name){
	char *type_of_value=NULL;
	RegKey *found_key=searchKey(key_name);
	if(found_key!=NULL){
		type_of_value=found_key->queryTypeOfValues(value_name);
	}
	return type_of_value;
}
void *Registry::queryExtraPointerOfKeyValues(const char *key_name,const char *value_name){
	void *ep=NULL;
	RegKey *found_key=searchKey(key_name);
	if(found_key!=NULL){
		ep=found_key->queryExtraPointerOfValues(value_name);
	}
	return ep;
}
void Registry::updateKeyValue(const char *key_name,const char *value_name,const char *value_type,const char *value){
/*
	//if not found key , then create new key
	RegKey *found_key=searchKey(key_name);
	if(found_key==NULL){
		//addKey
		found_key=addKey(key_name);
	}
	//update key value
	found_key->updateValueOfValues(value_name,value);
	found_key->updateTypeOfValues(value_name,value_type);		
*/
	updateKeyValue(key_name,value_name,value_type,value,NULL);
}
void Registry::updateKeyValue(const char *key_name,const char *value_name,const char *value_type,const char *value,void *ep){
	//if not found key , then create new key
	RegKey *found_key=searchKey(key_name);
	if(found_key==NULL){
		//addKey
		found_key=addKey(key_name);
	}
	//update key value
	found_key->updateValueOfValues(value_name,value);
	found_key->updateTypeOfValues(value_name,value_type);	
	found_key->updateExtraPointerOfValues(value_name,ep);
}

void Registry::deleteKeyValue(char *kname,char *value_name){
	RegKey *found_key=NULL;
	found_key=searchKey(kname);
	if(found_key!=NULL){
		found_key->deleteValue(value_name);
	}
}

void Registry::deleteKey(char *key_name){
	RegKey *regkey_temp=NULL;
	RegKey *regkey_prev=NULL;
//		RegKey *result_key=NULL;
	regkey_temp = start_key;
	for(int i=0;i<key_count;i++){
		if(strcmp(regkey_temp->getKeyName(),key_name)==0){
			if(regkey_prev!=NULL){
				regkey_prev->setNextKey(regkey_temp->getNextKey());
			}else{
				start_key->setNextKey(regkey_temp->getNextKey());
			}
			delete regkey_temp;
//				result_key=regkey_temp;
			if(key_count>0)
				key_count--;
			break;
		}
		regkey_prev=regkey_temp;
		regkey_temp=regkey_temp->getNextKey();
	}
//		return result_key;
/*
		RegKey *found_key=NULL;
		found_key=searchKey(kname);
		if(found_key!=NULL){
			delete found_key;
		}
*/
}

RegKey* Registry::searchKey(const char *key_name){
	RegKey *regkey_temp=NULL;
	RegKey *result_key=NULL;
	regkey_temp = start_key;
	for(int i=0;i<key_count;i++){
		if(strcmp(regkey_temp->getKeyName(),key_name)==0){
			result_key=regkey_temp;
			break;
		}
		regkey_temp=regkey_temp->getNextKey();
	}
	return result_key;
}

