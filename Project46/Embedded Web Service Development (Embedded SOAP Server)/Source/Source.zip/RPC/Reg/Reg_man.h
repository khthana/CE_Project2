#ifndef REGISTRY_MANAGER
#define REGISTRY_MANAGER

class RegistryManager{
	RegistryManager();
	~RegistryManager();
	addRegistry(Registry
	char *searchRegistry(char *reg_name,char *key_name,char *value_name);
};

#endif