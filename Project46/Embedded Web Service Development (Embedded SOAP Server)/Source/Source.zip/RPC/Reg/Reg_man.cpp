#include "Reg_man.h"
#include <string.h>

char *searchRegistry(char *reg_name,char *key_name,char *value_name){
	
}
