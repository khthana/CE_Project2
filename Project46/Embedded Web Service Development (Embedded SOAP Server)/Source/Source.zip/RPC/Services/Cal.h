#ifndef CALCULATOR
#define CALCULATOR

#include "servobj.h"

class Calculator:public ServiceObj{
public:
	Calculator(const char* serv_name):ServiceObj(serv_name){};
	~Calculator(){};

	void init(RPCParam *p_param,RPCParam *p_result);
	void run();
};

#endif