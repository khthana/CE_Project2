#include "Cal.h"
#include "Math.h"


void Calculator::init(RPCParam *p_param,RPCParam *p_result){
	param=p_param;
	result=p_result;
}

void Calculator::run(){
//	char return_string[]="return";
//	char double_type[]="xsd:double";
//	char return_value[]="4.0";

	result->addParam("return","xsd:double","4.0",0);
}
