#include <stdio.h>
#include "fileutil.h"
//#include "alloc.h"

char* readFile(char *filename){
	int max=2000;
	char *a=new char[max];
	char ch;
	int i=0;

	FILE *stream;

	stream=fopen(filename,"r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>max)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	//close service description file
	fclose(stream);  //	break;
	a[i++]='\n';
	a[i]='\0';

	return a;
}