#include <stdio.h>
//#include <iostream.h>
#include "Parser.h"
#include "ParseE.h"
#include "Xml.h"
#include "Registry.h"
#include "xml2reg.h"

Registry* xmlToRegistry(char *xml_message){
	Registry* my_registry;
	Parser *pr;
	pr =new Parser();
	pr->setXMLReader(xml_message);
//	ParseEvent *registry_pe,*key_pe,*node_pe,*current_pe;
	ParseEvent *current_pe;
	char registry_name[50],key_name[50],node_name[50],node_type[50];

	current_pe=pr->read();
	if(my_strcmp(myAttribute(current_pe->getAttribute()),"registry")==0){
		my_strcpy(registry_name,current_pe->getName());
//		registry_pe=current_pe;
//		printf("Registry Name : %s\n",registry_name);
		my_registry=new Registry(registry_name);//registry :reg_1 create registry object
		current_pe=pr->read();
		do{
			if(my_strcmp(myAttribute(current_pe->getAttribute()),"key")==0){
//				key_pe=current_pe;
				my_strcpy(key_name,current_pe->getName());
//				printf("Key Name : %s\n",key_name);
				current_pe=pr->read();
				do{
//					node_pe=current_pe;
					my_strcpy(node_name,current_pe->getName());
					my_strcpy(node_type,myAttribute(current_pe->getAttribute()));
//					printf("Name = %s ,Type = %s",current_pe->getName(),myAttribute(current_pe->getAttribute()));
					current_pe=pr->read();
					if(current_pe->getType()=='t'){
//						printf(" ,Value = %s\n",current_pe->toString());
//						cout<<"Registry Name = "<<registry_name<<endl;
//						cout<<"Key Name = "<<key_name<<endl;
//						cout<<"Value Name = "<<node_name<<endl;
//						cout<<"Value Type = "<<node_type<<endl;
//						cout<<"Value = "<<current_pe->toString()<<endl;
						my_registry->updateKeyValue(key_name,node_name,node_type,current_pe->toString());//registry :reg_2
						current_pe=pr->read();
					}
					if(!(my_strcmp(node_name,current_pe->getName())==0&&current_pe->endCheck(current_pe)==1)){};
//					current_pe=pr->read();//end of tag
					
					current_pe=pr->read();
//					cout<<"Next = "<<current_pe->getName()<<" key_name = "<<key_name<<" registry_pe = "<<registry_name<<endl;
//					if(current_pe->endCheck(current_pe)==1){
//						cout<<"endCheck() = 1"<<endl;
//					}
				}while(!(my_strcmp(key_name,current_pe->getName())==0&&current_pe->endCheck(current_pe)==1));
				current_pe=pr->read();
			}

		}while(!(my_strcmp(registry_name,current_pe->getName())==0&&current_pe->endCheck(current_pe)==1));
	}
	return my_registry;
}

char* myAttribute(char *attr_Str){
	Str attr = attr_Str;
	attr.deleteTo('"');
	return attr.cut('"');
}
