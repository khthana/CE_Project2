#ifndef FILE_UTIL
#define FILE_UTIL

char* readFile(char *filename);

#endif