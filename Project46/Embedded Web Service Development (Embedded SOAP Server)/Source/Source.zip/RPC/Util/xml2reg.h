#ifndef XML2REG
#define XML2REG

Registry* xmlToRegistry(char *xml_message);
char* myAttribute(char *);

#endif
