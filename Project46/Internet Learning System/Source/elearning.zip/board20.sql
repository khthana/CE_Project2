# phpMyAdmin SQL Dump
# version 2.5.3-rc2
# http://www.phpmyadmin.net
#
# ��ʵ�: localhost
# ����㹡�����ҧ: 23 ��.�. 2004  �.
# ��蹢ͧ���������: 3.23.58
# ��蹢ͧ PHP: 4.3.2
# 
# �ҹ������ : `board20`
# 

# --------------------------------------------------------

#
# �ç���ҧ���ҧ `webboard_ans`
#

CREATE TABLE `webboard_ans` (
  `No` int(5) NOT NULL auto_increment,
  `QuestionNo` int(5) NOT NULL default '0',
  `Name` varchar(50) NOT NULL default '',
  `Member` tinyint(1) NOT NULL default '0',
  `IP` varchar(15) NOT NULL default '',
  `Email` varchar(50) NOT NULL default '',
  `Msg` text NOT NULL,
  `Date` varchar(20) NOT NULL default '',
  `Image` text,
  PRIMARY KEY  (`No`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

#
# dump ���ҧ `webboard_ans`
#

INSERT INTO `webboard_ans` (`No`, `QuestionNo`, `Name`, `Member`, `IP`, `Email`, `Msg`, `Date`, `Image`) VALUES (1, 1, 'test', 0, '161.246.5.129', '', 'test test <img src="pic/lol.gif">', '11 Mar 2004 16:03', '');
INSERT INTO `webboard_ans` (`No`, `QuestionNo`, `Name`, `Member`, `IP`, `Email`, `Msg`, `Date`, `Image`) VALUES (2, 1, 'again', 0, '161.246.5.129', '', 'again  <img src="pic/devil.gif">', '11 Mar 2004 16:04', '');

# --------------------------------------------------------

#
# �ç���ҧ���ҧ `webboard_data`
#

CREATE TABLE `webboard_data` (
  `No` int(5) NOT NULL auto_increment,
  `Category` varchar(50) NOT NULL default '',
  `Question` varchar(100) NOT NULL default '',
  `Note` text NOT NULL,
  `Name` varchar(50) NOT NULL default '',
  `Member` tinyint(1) NOT NULL default '0',
  `IP` varchar(15) NOT NULL default '',
  `Email` varchar(50) NOT NULL default '',
  `Date` varchar(20) NOT NULL default '',
  `Reply` int(5) NOT NULL default '0',
  `ReplyDate` varchar(20) NOT NULL default '',
  `Image` text,
  PRIMARY KEY  (`No`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

#
# dump ���ҧ `webboard_data`
#

INSERT INTO `webboard_data` (`No`, `Category`, `Question`, `Note`, `Name`, `Member`, `IP`, `Email`, `Date`, `Reply`, `ReplyDate`, `Image`) VALUES (1, '', 'test', 'test <img src="pic/devil.gif">', 'nguang', 0, '161.246.4.252', '', '10 Feb 2004 11:24', 2, '11 Mar 2004 16:04', '');
INSERT INTO `webboard_data` (`No`, `Category`, `Question`, `Note`, `Name`, `Member`, `IP`, `Email`, `Date`, `Reply`, `ReplyDate`, `Image`) VALUES (4, '', 'test', '&lt;p&gt;test&lt;/p&gt;<br>\n&lt;a href=&quot;index.php&quot;&gt;index&lt;/a&gt; <img src="pic/devil.gif">', 'testman', 0, '127.0.0.1', '', '22 Mar 2004 20:37', 0, '', '');
