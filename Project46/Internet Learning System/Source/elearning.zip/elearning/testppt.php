<object data="subject/6.ppt" type="application/vnd.ms-powerpoint">
    Ask your system administrator to install the required application to view this file
</object>