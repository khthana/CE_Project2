<?php
session_start();
//print session_id();
?>
<html>
<head>
<title>�Է������ǡѺẺ���ͺ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<link rel='stylesheet' type='text/css' href='style.css' />
<body>
<?php
if (isset($_SESSION['user']))
{
	include "connectdb.php";
	mysql_query("use elearning;");
	$sql = "select * from userid where user='$user';";
	$result=mysql_query($sql);
	$rstatus=mysql_result($result,0,"status");
	$ruid1=mysql_result($result,0,"uid");
}
if(isset($_SESSION['user']) && ($rstatus==1 || $rstatus==0))
{
?>
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="28" height="28" align="right"><div align="right"><img src="menu/tlangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
    <td width="544" bgcolor="#FF9900" class="headmenu"><font size="2">&nbsp;�Է������ǡѺẺ���ͺ</font></td>
    <td width="28" height="28" align="left"><div align="left"><img src="menu/trangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
  </tr>
  <tr> 
    <td colspan="3"><table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
        <tr> 
          <td colspan="2"><table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="30">&nbsp;</td>
                <td>&nbsp;</td>
                <td width="30">&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">� menu ���Ẻ���ͺ ��鹺ؤ�ҡè�����ö���� 
                  ź �������¹�ŧ�����ŵ�ҧ � �����Ԫҷ�赹�ͧ�������������������� 
                </td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td class="defaultfont">����ٹ����պ͡�֧�ӹǹ��ͧ͢Ẻ���ͺ ������Ԫҷ��������</td>
                    </tr>
                    <tr> 
                      <td><img src="logo/teacher5-1.jpg" width="482" height="46"></td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher5-2.jpg" width="67" height="21"></div></td>
                      <td width="50%" class="defaultfont">��ԡ��� choice ��Ԫҷ���ͧ�������¹�ŧ</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td class="defaultfont">˹�ҹ����ʴ��Ӷ��������дѺ�����ҡ�ҡ level 1-5 <br>
                        ������ create ����͵�ͧ������ҧ�Ӷ������<br>
                        ������ edit ����͵�ͧ�������¹�ŧ�Ӷ����������� <br>
                        ������ delete ����͵�ͧ���ź�Ӷ�����</td>
                    </tr>
                    <tr> 
                      <td><p><img src="logo/teacher5-3.jpg" width="482" height="100"></p></td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">㹡������¹�ŧ�Ӷ���Ẻ���ͺ��鹨��բ�����������ѧ���</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher5-4.jpg" width="161" height="160"></div></td>
                      <td width="50%" class="defaultfont">�Ӷ����е�����͡ 5 choice</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher5-5.jpg" width="229" height="20"></div></td>
                      <td width="50%" class="defaultfont">�ӵͺ���١��ͧ</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher5-6.jpg" width="214" height="36"></div></td>
                      <td width="50%" class="defaultfont">�дѺ�����ҡ�ͧ�Ӷ��</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td class="defaultfont">�ٻ�Ҿ��Сͺ</td>
                    </tr>
                    <tr> 
                      <td><div align="center"><img src="logo/teacher5-7.jpg" width="379" height="23"></div></td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">�ӡ������¹�ŧ �����ѹ����</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="28" height="28" align="right"><img src="menu/dlangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
    <td bgcolor="#FF9900">&nbsp;</td>
    <td width="28" height="28" align="left"><img src="menu/drangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
  </tr>
</table>
<?php
}
?>
</body>
</html>
