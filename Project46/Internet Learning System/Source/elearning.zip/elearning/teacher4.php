<?php
session_start();
//print session_id();
?>
<html>
<head>
<title>�Է������ǡѺ����Ԫ�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<link rel='stylesheet' type='text/css' href='style.css' />
<body>
<?php
if (isset($_SESSION['user']))
{
	include "connectdb.php";
	mysql_query("use elearning;");
	$sql = "select * from userid where user='$user';";
	$result=mysql_query($sql);
	$rstatus=mysql_result($result,0,"status");
	$ruid1=mysql_result($result,0,"uid");
}
if(isset($_SESSION['user']) && $rstatus==1)
{
?>
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="28" height="28" align="right"><div align="right"><img src="menu/tlangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
    <td width="544" bgcolor="#FF9900" class="headmenu"><font size="2">&nbsp;�Է������ǡѺ����Ԫ�</font></td>
    <td width="28" height="28" align="left"><div align="left"><img src="menu/trangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
  </tr>
  <tr> 
    <td colspan="3"><table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
        <tr> 
          <td colspan="2"><table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="30">&nbsp;</td>
                <td>&nbsp;</td>
                <td width="30">&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">� menu �������Ԫ� ��鹺ؤ�ҡè�����ö����¹�ŧ�����ŵ�ҧ 
                  � �����Ԫҷ�赹�ͧ�������������������� ��</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><img src="logo/teacher4-1.jpg" width="232" height="23"></td>
                      <td width="50%" class="defaultfont">˹ѧ��ͷ���� (������������¹�鹤����������)</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><img src="logo/teacher4-2.jpg" width="223" height="22"></td>
                      <td width="50%" class="defaultfont">ࡳ���ü�ҹ�ͧ�Ԫҹ��</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><img src="logo/teacher4-3.jpg" width="215" height="23"></td>
                      <td width="50%" class="defaultfont">���Ẻ���¹������������¹���֡��</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">�Ẻ���¹���������١ zip �����ǫ������� zip �����������ҡ����ŧ��� 
                  Power point �� html �Ըա�÷��մѧ���</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher4-4.jpg" width="226" height="60"></div></td>
                      <td width="50%" class="defaultfont">��Ẻ���¹��ٻ�ͧ��� Power point </td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher4-5.jpg" width="130" height="167"></div></td>
                      <td width="50%" class="defaultfont">�ӡ�� save �� web page</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher4-6.jpg" width="152" height="66"></div></td>
                      <td width="50%" class="defaultfont">��駪��������ʢͧ�Ԫҹ��</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher4-7.jpg" width="76" height="68"></div></td>
                      <td width="50%" class="defaultfont">�ӡ�� zip �������ҡ����ŧ������</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellspacing="2" cellpadding="1">
                    <tr> 
                      <td colspan="2"><img src="logo/teacher4-8.jpg" width="443" height="26"></td>
                    </tr>
                    <tr> 
                      <td width="50%"><div align="center"><img src="logo/teacher4-9.jpg" width="137" height="117"></div></td>
                      <td width="50%" class="defaultfont">��ԡ���͡Ẻ���¹��� 
                        zip �ҷӡ�� upload ������ </td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td class="defaultfont">��§��ҹ�������ö upload Ẻ���¹����������</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="28" height="28" align="right"><img src="menu/dlangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
    <td bgcolor="#FF9900">&nbsp;</td>
    <td width="28" height="28" align="left"><img src="menu/drangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
  </tr>
</table>
<?php
}
?>
</body>
</html>
