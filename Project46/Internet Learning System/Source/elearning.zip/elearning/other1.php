<?php
session_start();
//print session_id();
?>
<html>
<head>
<title>����ҹ��纹�������ҧ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<link rel='stylesheet' type='text/css' href='style.css' />
<body>
<?php
if (!isset($_SESSION['user']))
{
?>
<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="28" height="28" align="right"><div align="right"><img src="menu/tlangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
    <td width="544" bgcolor="#FF9900" class="headmenu"><font size="2">&nbsp;����ҹ��纹�������ҧ��</font></td>
    <td width="28" height="28" align="left"><div align="left"><img src="menu/trangle.gif" width="28" height="28" hspace="0" vspace="0"></div></td>
  </tr>
  <tr> 
    <td colspan="3"><table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
        <tr> 
          <td colspan="2"><table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="30">&nbsp;</td>
                <td>&nbsp;</td>
                <td width="30">&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td class="defaultfont">��纹������纷��������¹��� ���ͺ ��ж��-�ͺ 
                  �ѭ������ǡѺ�ԪҢͧ�Ҥ�ԪҤ��������� ������ǡ�����ʵ�� �����ʹ�㹡�������ҹ 
                  ���繵�ͧ ŧ����¹����Ҫԡ��͹�֧�������ҹ��</td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellpadding="1" cellspacing="1">
                    <tr> 
                      <td width="50%"><img src="logo/other1-1.jpg" width="191" height="37"></td>
                      <td width="50%" class="defaultfont">�������������Ѻŧ����¹</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellpadding="1" cellspacing="1">
                    <tr> 
                      <td width="50%"><img src="logo/other1-2.jpg" width="239" height="29"></td>
                      <td width="50%" class="defaultfont">��͡��������ǹ���</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellpadding="1" cellspacing="1">
                    <tr> 
                      <td width="50%"><img src="logo/other1-3.jpg" width="236" height="29"></td>
                      <td width="50%" class="defaultfont">��� e-mail �����㹡�õԴ���</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellpadding="1" cellspacing="1">
                    <tr> 
                      <td width="50%"><img src="logo/other1-4.jpg" width="236" height="71"></td>
                      <td width="50%" class="defaultfont">��� UserID, Password 
                        ����׹�ѹ Password</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td><table width="100%" border="0" cellpadding="1" cellspacing="1">
                    <tr>
                      <td width="50%"><img src="logo/other1-5.jpg" width="123" height="38"></td>
                      <td width="50%" class="defaultfont">�ӡ�� register �¡�����</td>
                    </tr>
                  </table></td>
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="28" height="28" align="right"><img src="menu/dlangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
    <td bgcolor="#FF9900">&nbsp;</td>
    <td width="28" height="28" align="left"><img src="menu/drangle.gif" width="28" height="28" hspace="0" vspace="0"></td>
  </tr>
</table>
<?php
}
?>
</body>
</html>
