<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<SCRIPT LANGUAGE="JavaScript">
	function tab(list){
		if(list!=0){
		parent.location.href("supplier.php?id="+list );
		}
	}

</SCRIPT>
</HEAD>
<?php
	include("fn_mysql.php");
	$update=$HTTP_GET_VARS[update];
	$add_new_id=$HTTP_GET_VARS[add_new_id];
	$add_new=$HTTP_GET_VARS[add_new];
	$supplier_id=$HTTP_GET_VARS[id];
	$name=$HTTP_GET_VARS[add_new];
	if($add_new==1){
		$supplier_id=$add_new_id;
	}
	else if($update!=null){
		$supplier_id=$update;
	}
?>
<BODY bgcolor="#99CCCC" >
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#99CCCC">
<tr  height="1" bgcolor="#9999CC">

<td>
	<center><font color="#FFFFFF">����</font></center>
</td>
<td>
	<center><font color="#FFFFFF">���ͼ��Ѵ��˹���</font></center>
</td>
<td>
	<center><font color="#FFFFFF">�����Թ���</font></center>
</td>
</tr >
<?
	connect_mysql("db_admin");//function
	$sql="SELECT * FROM supplier ORDER BY supplier_id;";
	$result=mysql_query($sql);
while($dbarr=mysql_fetch_array($result)){?>

<tr  height="1" 
<?
	if($dbarr["supplier_id"]==$supplier_id){	
		 if($dbarr["supplier_id"]==1){	
				echo "bgcolor=\"#FF6600\"";	
		}
		else{
				echo "bgcolor=\"#FFFF00\"";$yello=$dbarr["supplier_id"];	
		}
	}
	else{echo "bgcolor=\"#FFFFFF\"";
	}
?>
onclick="tab(<?
if($dbarr["supplier_id"]!=$yello){
$data=$dbarr["supplier_id"];
echo "'".$data."'";}
else{
	$data="0";
	echo "'".$data."'";
 }
?>)
">

<td>
	<center><?echo $dbarr['supplier_id'];?></center>
</td>
<td>
	<center><?echo $dbarr['supplier_name'];?></center>
</td>
<td>
	<center><??></center>
</td>
<?}?>
</tr >
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>
</BODY>
</HTML>
