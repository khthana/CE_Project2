<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<?
	include("fn_mysql.php");
	$hotkey=$HTTP_GET_VARS[hotkey];
	if($hotkey=="F8") $name=getconfig("config","3:F8");
	else if($hotkey=="F9")	 $name=getconfig("config","4:F9");
	else if($hotkey=="F10")	$name=getconfig("config","5:F10");
	else if($hotkey=="F11")	$name=getconfig("config","6:F11");
	else if($hotkey=="F12")	$name=getconfig("config","7:F12");
?>
<TITLE><?echo "".$hotkey." : ".$name."";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;</TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
var count=0;
var status=0;
function init(list) {	
		count=list;
		document.onkeydown= showKeyDown;	
}
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;
		if(i==27)   window.close();
		else if(i==38){//up
			var s;
			if(status==0){s=count-1;}
			else if(status==count-1){s=count-2;}
			else{s=status-1;}
			status=s;
			over(s,count);
			out(s);
		}
		else if(i==40){//down
			var s;
			if(status==0){s=1;}
			else if(status==count-1){s=0;}
			else{s=status+1;}
			status=s;
			over(s,count);
			out(s);
		}
		else if(i==13){//enter
		 if(count!=0){
		     var id="cid"+status;
		     var code=gE(id).value;
				dclick(code);
			 }
		}
}
//--------------------------------------------------------------------------
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc(code);
}
window.onbeforeunload = verifyClose

function over(list,i){
	status=list;
	for(var j=0;j<i;j++){
			var id1="id"+j;
			gE(id1).style.backgroundColor = "#eeeeee";
	}
	var id2="id"+list;
	gE(id2).style.backgroundColor = "#FFFF00";
}
function out(list){
	status=list;
	var id="id"+list;
	gE(id).style.backgroundColor = "#FFFF00";
}
var code;
function dclick(list){
	code=list;
	window.close();
}
</SCRIPT>

</HEAD>
<?php
$find_done=array();	
if($hotkey!=null){
	$result=select_record("goods","hot_key",$hotkey);
				$i=0;
		while($dbarr=mysql_fetch_array($result)){				
					$find_done[$i]=$dbarr["goods_name"];	
					$i++;				
		}
}
?>
<BODY bgcolor="#FFFFFF" onload="init(<? echo $i;?>);">
<form action="_self"  name="main_form" id="main_form" method="post">
<center>
<table border="0" width="105%" height="10%" bgcolor="" cellspacing="1">
						<tr bgcolor="9999cc">
						<td width="25%">
								<center>����</center>
						</td>
						<td>
								<center>�����Թ���</center>
						</td>
						<td width="25%">
								<center>�Ҥ�</center>
						</td>
						</tr>
<?
if(count($find_done)){
		for($k=0;$k<$i;$k++){ 
			  $result=select_record("goods","goods_name",$find_done[$k]);
			  $code=mysql_result($result,0,"goods_id");
			  ?><input type="hidden" value="<?echo $code;?>" id="<?echo "cid".$k?>"/><?
				?>
						<tr <?if($k==0){echo "bgcolor=#FFFF00";} else {echo "bgcolor=#eeeeee";}?> id="<?echo "id".$k;?>" onmouseover="over(<?echo $k;?>,<?echo $i;?>)" onmouseout="out(<?echo $k;?>)" ondblclick="dclick(<?echo $code;?>)">	
						<td>
						<center>
							<?
							echo $code; 
							?>
						</center>
						</td>
						<td>
						<center>
							<?echo $find_done[$k];?>
						</center>
						</td>
						<td>
						<center>
							<?
							echo mysql_result($result,0,"retail_price");
							?>
						</center>
						</td>
						</tr>
				<?
		}
}
?>
						<tr >
						<td colspan=3 >	
						<center>�鹾��Թ��� <?echo $i;?> ��¡��</center>
						</td>
						</tr>

</table>
</center>		
</form>
</BODY>
</HTML>
