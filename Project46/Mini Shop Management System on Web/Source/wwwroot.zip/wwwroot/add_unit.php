<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>����˹����Թ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		document.onkeydown= showKeyDown;	
}
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;
		if(i==27)   window.close();
		else if(i==13){//enter
		    check_data();
		}
}
//--------------------------------------------------------------------------
function verifyClose() {
	var code=gE("data").value;
	var returnFunc = window.dialogArguments
	returnFunc(code);
	window.close();
}
//--------------------------------------------------------------------------
function check_data() {
	if(gE("data").value!=''){
		verifyClose();
	}
	else {alert('�ѧ������͡˹����Թ���');}
}
</SCRIPT>

</HEAD>
<BODY bgcolor="#77bbff"onload="init();">
<center>
<table border="0" width="108%" height="55%" bgcolor="" cellspacing="1">
						<tr bgcolor="#FFFF99" height="40%">
						<td>	
								<input type="text" name="data" id="data" maxlength="16"/>&nbsp;	
								<button onclick="check_data();">&nbsp;&nbsp;��ŧ&nbsp;&nbsp;</button>
								</td>
						</tr>
</table>
</center>		
</BODY>
</HTML>
