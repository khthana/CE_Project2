<!---------------------- ˹������¹���ʼ�ҹ post form "changepass.html"-------------------------->
<?php
		include("fn_mysql.php");
				if($newpassword1!=null&&$newpassword2!=null){
						if($newpassword1==$newpassword2){//��Ǩ�ͺ����׹�ѹ
								echo $newpassword1;
								$sql="UPDATE employee SET password='$newpassword1' WHERE username=$username;";
								$result=mysql_query($sql);
								if($result){								
									$worn="ok";					
								}
						}
						else{
								    $worn="ne";
						}
				}
				else{
					 $worn="nc";
				 }
?>