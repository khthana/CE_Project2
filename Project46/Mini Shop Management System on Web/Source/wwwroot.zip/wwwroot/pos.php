<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> ˹�Ң��˹����ҹ</title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<script type="text/javascript">
	//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		
//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
//---------------Gobal variable-------------------------
	var total=0;
	var temp=0;
	var status;
	var code="";
	var recive_money="";
	var check=0;
	var check2=0;
	var section=0;
	var delete1="";
	var update="";
	var num=0;
	var change="";
	
//-----------------------------------------------------------
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//----------------------------------------------------------------------
function cut_float(list){
		var i=0;
		var j=0;
		list=list+"";
		for (i = 0; i < list.length; i++) {					
				var oneChar = list.substring(i, i+1);
				if (oneChar==".") {
						list=list+"0";
						j=1;
						break;	
				}
		}
		if(j==0){
				list=list+".00";
		}
		list=list+"";
		if(j==1){
				list=list.substring(0,i+3);
		}
				return list;
}
//----------------------------------------------------------------------
function send_to_iframe(){
	location.href("pos.php?code1="+code+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
		code="";
		gE("code").value=code;
		check=0;
}
//-----------------------------------------------------------------
var customs_id;
function init(m,n,o,p,q,r,s) {	
		Now();
		document.onkeydown= showKeyDown;
		document.onkeypress = showKeyPress;
		gE("sale").value=o;
		num1(m);
		del(n);
		not_find(p);
		num=q
		temp_num=num;
		if(r!=99){
				num=r;
		}
		customs_id=s;		
		if(isNumber(s)){
			//alert(s);
			document.getElementById("color_sum").background  ="cust1.jpg";		
		}
		else{
			document.getElementById("color_sum").background  ="def.jpg";
		}
		if(gE("check_c").value!=0 && gE("check_c").value!="no"){
			customs_id="c"+gE("check_c").value;
			parent.iframe7.location.href("iframe7.php?c_id="+customs_id);
			gE("sale").value=gE("discount").value;
			document.getElementById("color_sum").background  ="cust1.jpg";		
		}
		else if(gE("check_c").value=="no"){
			cust_c(1);
		}
}
//------------------------------------------Print----------------------------------------------------------
function print1(list1,list2){	
		var prefsDlogP;		
		if (!prefsDlogP || prefsDlogP.closed) {
			prefsDlogP = showModelessDialog("bill.php?recive="+list1+"&&change="+list2, setPrefsP, "dialogWidth:200%; dialogHeight:340%;dialogLeft:100% ; dialogTop:100%;status=0")
		}	
}
function setPrefsP(list){
		//alert(list);
	    if(list==1){
			location.href("pos.php?complete=1&&print_complete=1");
		}
}
//----------------------------------------------------------------------------------------------------------	

function num1(m){
		total=m;
		temp=total;	
		if(gE("sale").value!=0){
				total=total-(total*(gE("sale").value/100));
		}
		if(total!=0){
				total=cut_float(total);
				document.getElementById("number").innerHTML = total;
		}
		else{
				document.getElementById("number").innerHTML = "0.00";
		}
}
//-----------------------------------------------------------------
function del(n){
		if(n==1){
				alert('�������¡�÷���ź');
		}
}
function not_find(p){
		if(p==1){
				alert('�������¡���Թ���');
		}
}
function isNumber(inputStr) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar=="c" || oneChar=="C" ) {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return true;
		}
	}
			return false;
}
function find_dot(inputStr) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar==".") {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return true;
		}
	}
			return false;
}

function cust_c(list){
		var prefsDlogC;					
		if (!prefsDlogC || prefsDlogC.closed) {
				prefsDlogC = showModelessDialog("sale_cust.php?find="+list, setPrefsC, "dialogWidth:280%; dialogHeight:80%;dialogLeft:360% ; dialogTop:210%; status=0")
		}		
		function setPrefsC(list){
				if(list!=""){
					location.href("pos.php?check_c="+list);
				}
		}
}
var select1;
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event;
		var i=evt.keyCode;

				if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116) || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
					var temp=event.keyCode;
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
					if(temp==112){
						cal();
					}
					if(temp==114){
						cust_c(0);
					}
					
        	 	}//end main

				select1=0;
				if(i>96 && i<106){
						i=i-96;
						select1=1;
						var len2=code.length;
						 if(len2<16){
							code=code+i;
							gE("code").value=code;
						 }
				}
				else if(i==113){
						find();	
				}
				else if(i==38){
						if(num>1){
						num=num-1;
						parent.iframe7.location.href("iframe7.php?arrow="+num);
						}						
				}
				else if(i==40){
						if(num<temp_num){
						num=num+1;
						parent.iframe7.location.href("iframe7.php?arrow="+num);
						}						
				}
				else if(i==119){
						var prefsDlog3;					
						if (!prefsDlog3 || prefsDlog3.closed) {
							prefsDlog3 = showModelessDialog("hotkey.php?hotkey=F8", setPrefs3, "dialogWidth:280%; dialogHeight:430%;dialogLeft:280% ; dialogTop:54%; status=0")
						}		
						function setPrefs3(list){
							if(list!=null){
		location.href("pos.php?code1="+list+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
							}
						}
				}
				else if(i==120){
						var prefsDlog4;					
						if (!prefsDlog4 || prefsDlog4.closed) {
							prefsDlog4 = showModelessDialog("hotkey.php?hotkey=F9", setPrefs4, "dialogWidth:280%; dialogHeight:430%;dialogLeft:280% ; dialogTop:54%; status=0")
						}		
						function setPrefs4(list){
							if(list!=null){
	location.href("pos.php?code1="+list+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
							}
						}
				}
				else if(i==121){
						var prefsDlog5;					
						if (!prefsDlog5 || prefsDlog5.closed) {
							prefsDlog5 = showModelessDialog("hotkey.php?hotkey=F10", setPrefs5, "dialogWidth:280%; dialogHeight:430%;dialogLeft:280% ; dialogTop:54%; status=0")
						}		
						function setPrefs5(list){
							if(list!=null){
	location.href("pos.php?code1="+list+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
							}
						}
				}
				else if(i==122){
						var prefsDlog6;					
						if (!prefsDlog6 || prefsDlog6.closed) {
							prefsDlog6 = showModelessDialog("hotkey.php?hotkey=F11", setPrefs6, "dialogWidth:280%; dialogHeight:430%;dialogLeft:280% ; dialogTop:54%; status=0")
						}		
						function setPrefs6(list){
							if(list!=null){
	location.href("pos.php?code1="+list+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
							}
						}
				}
				else if(i==123){
						var prefsDlog7;					
						if (!prefsDlog7 || prefsDlog7.closed) {
							prefsDlog7 = showModelessDialog("hotkey.php?hotkey=F12", setPrefs7, "dialogWidth:280%; dialogHeight:430%;dialogLeft:280% ; dialogTop:54%; status=0")
						}		
						function setPrefs7(list){
							if(list!=null){
	location.href("pos.php?code1="+list+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
							}
						}
				}
}
var count1=0;  
var count3=0;  var cust3=0;
var count4=0;  var cust=2;
var count5=0;
var show_recive;
var show_sum;
var show_change;
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event;
		var i=evt.keyCode;
		if(section==0){			
				if((i>47&&i<58) && select1==0){
						if(i>47&&i<58)		    
						j=String.fromCharCode(i);
						var len2=code.length;
						 if(len2<16){
							code=code+j;
							gE("code").value=code;
						 }
				}
				else if(i==113){
					    var result=confirm('�׹�ѹ��ҧ��¡���Թ���?');
						if(result){		
						clear1();	
						}
				}			
				else if(i==27&&gE("sale").value!="0"){
						gE("sale").value="0";	
						document.getElementById("color_sum").background  ="def.jpg";
						customs_id="";
						total=cut_float(temp);
						document.getElementById("number").innerHTML = total;
				}				
				else if(i==46){
						len=code.length;
						code=code.substring(0,len-1);
						gE("code").value=code;
				}
				else if(i==45){
						document.getElementById("total").innerHTML = "ź";
						document.getElementById("number").innerHTML = delete1;
						section=3;
				}
				else if(i==47){
						document.getElementById("total").innerHTML = "Ŵ";
						document.getElementById("number").innerHTML = "";
						section=4;
				}
				else if(i==42){
						document.getElementById("total").innerHTML = "�ӹǹ";
						document.getElementById("number").innerHTML = "";
						section=5;
				}
				else if(i==13){
						if(code==""){
							gE("code").value=code;
							document.getElementById("total").innerHTML = "�Ѻ�Թ";
							document.getElementById("number").innerHTML = "";
							section=1;
						}
						else{
						send_to_iframe();
						}
				}	 
				else if(i==43){	
						code="";
						gE("code").value=code;
						document.getElementById("total").innerHTML = "����";
						document.getElementById("number").innerHTML = "";
						section=6;
				}	  
				
		}//end recive=0
		else if(section==1){
				if((check!=99&&(i>47&&i<58))&&recive_money.length<7){
					if(!find_dot(recive_money)){
						j=String.fromCharCode(i);
						recive_money=recive_money+j;
						document.getElementById("number").innerHTML = recive_money;
					}
					else if(count1<2){
						count1++;
						j=String.fromCharCode(i);
						recive_money=recive_money+j;
						document.getElementById("number").innerHTML = recive_money;
					}
				}
				else if(i==46&&check2!=1){
						j="."
						recive_money=recive_money+j;
						document.getElementById("number").innerHTML = recive_money;
						check2=1;
				}
				else if(i==27){						
					    if(recive_money==""){
								document.getElementById("total").innerHTML = "���";
								if(total!=0){
										document.getElementById("number").innerHTML = total;
								}
								else{
										document.getElementById("number").innerHTML ="0.00";
								}
								section=0;
								recive_money="";
								check2=0;
								count1=0;
						}
						else{
							    document.getElementById("total").innerHTML = "�Ѻ�Թ";
								document.getElementById("number").innerHTML = "";
								recive_money="";
								check2=0;
								count1=0;
						}
				}
				else if(i==13){	
						if(recive_money!=""){
								j=recive_money*1.00;
						}
						else{j=0;}
						var test=j-total;
						if(test>=0){
							if(total!=0&&total!=""){
									change=j-total;
									change=cut_float(change);
									if(change==".00"){change="0.00";}
									document.getElementById("total").innerHTML = "�͹";
									document.getElementById("number").innerHTML = change;
									show_change=cut_float(change);
							}
							else{
									recive_money=cut_float(recive_money);
									if(recive_money==".00"){recive_money="0.00";}
									document.getElementById("total").innerHTML = "�͹";
									document.getElementById("number").innerHTML = recive_money;	
									show_change=cut_float(recive_money);
							}	
							count1=0;
							section=2;
							check2=0;
							show_recive=cut_float(recive_money);
							if(show_recive==".00"){show_recive="0.00";}
							show_sum=cut_float(total);
							if(show_change==".00"){show_change="0.00";}
							var prefsDlog8;
							var width=screen.availWidth;
							if(width==800){
								if (!prefsDlog8 || prefsDlog8.closed) {
								prefsDlog8 =   showModelessDialog("show_sum.php?recive="+show_recive+"&&sum=" +show_sum+"&&change="+show_change+"&&cust_id="+customs_id, setPrefs8, "dialogWidth:250%; dialogHeight:170%;dialogLeft:380% ; dialogTop:200%; status=0; scrollbar=0");
								}	
							}
							else if(width==1024){
								if (!prefsDlog8 || prefsDlog8.closed) {
								prefsDlog8 = showModelessDialog("show_sum.php?recive="+show_recive+"&&sum=" +show_sum+"&&change="+show_change+"&&cust_id="+customs_id, setPrefs8, "dialogWidth:250%; dialogHeight:170%;dialogLeft:380% ; dialogTop:200%; status=0;scrollbar=0");
								}	
							}
							function setPrefs8(list){
								if(list!=null){
									if(list=="no"){
										//alert("no");
					location.href("pos.php?complete=1&&change="+show_change+"&&recive="+show_recive);
									}
									else{
                                        //alert(list);
 					location.href("pos.php?complete=1&&clear_point_id="+list+"&&change="+show_change+"&&recive="+show_recive);
									}
								}
								else{//-------------------clear----id---------------
										
										//---------------------------------------------
										document.getElementById("total").innerHTML = "�Ѻ�Թ";
										document.getElementById("number").innerHTML = "";
										section=1;
										recive_money="";
										check2=0;
										count1=0;
								}//------------
							}

						}
						else{
							alert("�Ѻ�Թ�ҹ��¡����ʹ���");
							document.getElementById("total").innerHTML = "�Ѻ�Թ";
							document.getElementById("number").innerHTML = "";
							recive_money="";
							check2=0;
							count1=0;
						}

						
				}
	}//end if money=1
	else if(section==2){
			if(i==27){
					document.getElementById("total").innerHTML = "�Ѻ�Թ";
					document.getElementById("number").innerHTML = "";
					section=1;
					recive_money="";
					check2=0;
					count1=0;
			}
			else if(i==13){
					section=0;
					recive_money="";
					change="";
					total=0;
					check=0;				
					location.href("pos.php?complete=1");
			}
	}
	else if(section==3){//delete section
			if((i>47&&i<58)&&cust3<3){
					cust3++;
					j=String.fromCharCode(i);
					delete1=delete1+j;
					document.getElementById("total").innerHTML = "ź";
					document.getElementById("number").innerHTML = delete1;
			 }
			 else if(i==13){
	                      location.href("pos.php?delete1="+parseInt(delete1)+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);				
					section=0;
					cust3=0;
					delete1='';
			 }
			 else if(i==27){
					section=0;
					delete1='';
					cust3=0;
					if(total!=0){
						total=cut_float(total);
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = total;
					}
					else{
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = "0.00";
					}
			 }
	}
	else if(section==4){//sale section
			if((i>47&&i<58 )&&(count4<cust)){
					count4++;// limit keypress=2
					j=String.fromCharCode(i);
					update=update+j;
					document.getElementById("total").innerHTML = "Ŵ";
					document.getElementById("number").innerHTML = update;
			 }
			 else if(i==13){
					document.getElementById("color_sum").background  ="def.jpg";
					customs_id=""
					gE("sale").value=update;
					total=total*((100-parseInt(update))/100);
					total=cut_float(total);
					document.getElementById("total").innerHTML = "���";
					if(total!=0){
							document.getElementById("number").innerHTML = total;
					}
					else{
							document.getElementById("number").innerHTML = "0.00";
					}
					section=0;
					count4=0; cust=2;
					update="";

			}
			else if(i==27){
				if(customs_id==""){
					document.getElementById("color_sum").background  ="def.jpg";
				}
				else{
					document.getElementById("color_sum").background  ="cust1.jpg";	
				}
					update='';
					count4=0; cust=2;
					section=0;
					if(total!=0){
						total=cut_float(total);
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = total;
					}
					else{
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = "0.00";
					}
			}
	}
	else if(section==5){
			if((i>47&&i<58) && count5<3){
					count5++;
					j=String.fromCharCode(i);
					update=update+j;
					document.getElementById("total").innerHTML = "�ӹǹ";
					document.getElementById("number").innerHTML = update;
			 }
			 else if(i==13){
					 location.href("pos.php?alot="+update+"&&position="+num+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
					 section=0;
					 count5=0;
					 update='';
			 }
			else if(i==27){				
					section=0;
					count5=0;
					update='';
					if(total!=0){
						total=cut_float(total);
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = total;
					}
					else{
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = "0.00";
					}
			}
	}
	else if(section==6){
			if((i>47&&i<58) && count5<3){
					count5++;
					j=String.fromCharCode(i);
					update=update+j;
					document.getElementById("total").innerHTML = "����";
					document.getElementById("number").innerHTML = update;
			 }
			 else if(i==13){
				location.href("pos.php?alot2="+update+"&&position2="+num+"&&sale="+gE("sale").value+"&&customs_id="+customs_id);
					 section=0;
					 count5=0;
					 update='';
			 }
			else if(i==27){				
					section=0;
					count5=0;
					update='';
					if(total!=0){
						total=cut_float(total);
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = total;
					}
					else{
						document.getElementById("total").innerHTML = "���";
						document.getElementById("number").innerHTML = "0.00";
					}
			}
	}
}//end function
//----------------------------------------------------Show day-----------------------------------------------
                       var day,date,month,year,hour,minute,second,today;  //���ҧ�������������ʵ���Ţ�ͧ�ѹ����
                              var dayString=new Array();
                              dayString[0]="�ҷԵ��";dayString[1]="�ѹ���";dayString[2]="�ѧ���";dayString[3]="�ظ";
                              dayString[4]="����ʺ��";dayString[5]="�ء��";dayString[6]="�����";
                              var monthString=new Array();
                              monthString[0]="1"; monthString[1]="2"; monthString[2]="3"; monthString[3]="4";
                              monthString[4]="5"; monthString[5]="6"; monthString[6]="7"; monthString[7]="8";
                              monthString[8]="9"; monthString[9]="10"; monthString[10]="11"; monthString[11]="12";      
                     //����ŧ�����Ǩ�ͺ�Թ�硫�����������˹��¤����Ӣͧ�к��ҡ��� ����¹���������鹡��ҡ�������͹� if ���� case
                      var DateTime;
                      function Now() 
                         {    DateTime=new Date(); //���ҧ�ѵ�� (object) �Դ��͡Ѻ�ѹ���Ңͧ�к���Ժѵԡ�� (OS)
                              day=DateTime.getDay(); 
                              date=DateTime.getDate(); 
                              month=DateTime.getMonth();
                              year=DateTime.getYear();
                              hour=DateTime.getHours();
                              minute=DateTime.getMinutes();
                              second=DateTime.getSeconds();    
                         today=" "+date+"/"+monthString[month]+"/"+(year+543);
							 var today2=hour+":"+minute+":"+second;
                             document.title=today; //�ʴ��͡�ҧ����ź���
                             window.status=today;//�ʴ��͡�ҧᶺʶҹ�
                            gE("FNT2").innerText=today2; gE("FNT").innerText=today;//�ʴ��͡�ҧ���ྨ�ç���˹� ID=TXT ੾�� IE
                             setTimeout("Now()",1*1000); //��˹�����Ѿഷ���ҷء 1 �Թҷ�
                         }                
//--------------------------------------Closed window-------------------------------------------
var prefsDlog;
function find() {
			if (!prefsDlog || prefsDlog.closed) {
			prefsDlog = showModelessDialog("find_pos.php", setPrefs, "dialogWidth:280%; dialogHeight:10%;dialogLeft:210% ; dialogTop:54% ; status=0")
			}
}
var prefsDlog1;
function setPrefs(list){
			if(list!=null && list!='closed'){
				if (!prefsDlog1 || prefsDlog1.closed) {
				prefsDlog1 = showModelessDialog("find.php?data="+list, setPrefs1, "dialogWidth:360%; dialogHeight:220%;dialogLeft:210% ; dialogTop:54%; status=0")
				}
			}
}
function setPrefs1(list){
	if(list!=null){
		location.href("pos.php?code1="+list);
	}
}
//----------------------------------------------Calculater--------------------------------------------
var prefsDlog2;
function cal() {
				if (!prefsDlog2 || prefsDlog2.closed) {
				prefsDlog2 = showModelessDialog("cal.html", setPrefs2, "dialogWidth:226%; dialogHeight:210%;dialogLeft:280% ; dialogTop:54%; status=0")
				}		
}
function setPrefs2(){
}
function clear1() {
	location.href("pos.php?clear1=1");
}
function logout() {
	location.href("menu.php?back=99");
}

//----------------------------------------------------------------------
</script>
</head>
<?php
	include("fn_mysql.php");
	$code1=$HTTP_GET_VARS[code1];
	$sale=$HTTP_GET_VARS[sale];
	$customs_id=$HTTP_GET_VARS[customs_id];
	$complete=$HTTP_GET_VARS[complete];
	$delete1=$HTTP_GET_VARS[delete1];
	$alot=$HTTP_GET_VARS[alot];
	$alot2=$HTTP_GET_VARS[alot2];
	$arrow=$HTTP_GET_VARS[arrow];
	$position=$HTTP_GET_VARS[position];
	$position2=$HTTP_GET_VARS[position2];
	$tab=$HTTP_GET_VARS[tab];
	$test=$HTTP_GET_VARS[test];	
	$user=$HTTP_SESSION_VARS["user"];
connect_mysql("db_admin");//function
//-----------------------------------------Discount-------------------------------------
	$discount=getconfig("config","1:discount");
?><input type="hidden" value="<?echo $discount;?>" name="discount" id="discount" />
<?
//-----------------------------------------Clear------------------------------------------
	$clear1=$HTTP_GET_VARS[clear1];	
	if($clear1==1){
			$sql="DROP TABLE $user";
			$result=mysql_query($sql);
			$sql="CREATE TABLE  $user (				
				order_id int( 16  )  NOT  NULL ,
				goods_id VARCHAR( 16  )  NOT  NULL ,
				goods_name VARCHAR( 45  )  NOT  NULL ,
				unit VARCHAR( 16  )  NOT  NULL ,
				amount int( 16  )  NOT  NULL ,
				total_price float( 16  )  NOT  NULL ,
				sale_percent int( 16  )  NOT  NULL ,				
				PRIMARY KEY(order_id));";
				mysql_query($sql);	
	}
	//------------------------------------Add status page--------------------------------
	$find=find_2record("login","page","pos","status","1");
	if(!$find){ 
			update_2record("login","username",$user,"status","1","page","pos");		
			$result=getdate();
			$year=$result["year"]+543;
			$date=$result["mday"]."/".$result["mon"]."/".$year;
			$login_time=$result["hours"].":".$result["minutes"];
			update_2record("login","username",$user,"status","1","login_date",$date);
			update_2record("login","username",$user,"status","1","login_time",$login_time);
	}	
//------------------------------Create temp table--------------------------
				$sql="CREATE TABLE  $user (				
				order_id int( 16  )  NOT  NULL ,
				goods_id VARCHAR( 16  )  NOT  NULL ,
				goods_name VARCHAR( 45  )  NOT  NULL ,
				unit VARCHAR( 16  )  NOT  NULL ,
				amount int( 16  )  NOT  NULL ,
				total_price float( 16  )  NOT  NULL ,
				sale_percent int( 16  )  NOT  NULL ,				
				PRIMARY KEY(order_id));";
				mysql_query($sql);	
//------------------------------insert to temp-------------------------------
	$not_find=0;
	if($sale==null)$sale="0";
	if($code1!=null){
			$find=find_record("goods","goods_id",$code1);
			if($find){
				$result=select_record("goods","goods_id",$code1);
				$goods_name=mysql_result($result,0,"goods_name");
				$unit=mysql_result($result,0,"unit");
				$price=mysql_result($result,0,"retail_price");
				$sale2=mysql_result($result,0,"sale_percent");
				insert_to_temp($user,$code1,$goods_name,$unit,"1",$price,$sale2);
			}
			else{
				$not_find=1;
			}
		}
//--------------------------------Change alot-------------------------------
	if(($alot!=null&&$alot!=0)&&$position!=0){	
		    $result=select_record_max($user,"order_id");
			$max=mysql_result($result,0,"MAX(order_id)");
		    $sql="UPDATE $user SET amount=$alot WHERE order_id=$position;";
			$result=mysql_query($sql);
			
			$result=select_record($user,"order_id",$position);
			$id=mysql_result($result,0,"goods_id");
			$find=find_record("goods","goods_id",$id);
			if($find){
				$result=select_record("goods","goods_id",$id);
				$price=mysql_result($result,0,"retail_price");
			}
			$temp=$alot*$price;
			$sql="UPDATE $user SET total_price=$temp WHERE order_id=$position;";
			$result=mysql_query($sql);
	}	
//--------------------------------Add +alot-------------------------------
	if(($alot2!=null&&$alot2!=0)&&$position2!=0){	
		    $result=select_record_max($user,"order_id");
			$max=mysql_result($result,0,"MAX(order_id)");
			$result=select_record($user,"order_id",$position2);
			$old_alot=mysql_result($result,0,"amount");
			$alot2=$old_alot+$alot2;
		    $sql="UPDATE $user SET amount=$alot2 WHERE order_id=$position2;";
			$result=mysql_query($sql);
			
			$result=select_record($user,"order_id",$position2);
			$id=mysql_result($result,0,"goods_id");
			$find=find_record("goods","goods_id",$id);
			if($find){
				$result=select_record("goods","goods_id",$id);
				$price=mysql_result($result,0,"retail_price");
			}
			$temp=$alot2*$price;
			$sql="UPDATE $user SET total_price=$temp WHERE order_id=$position2;";
			$result=mysql_query($sql);
	}	
//------------------------------Delete------------------------------------
	$notdel=99;
	if($delete1!=null){
		$result=find_record($user,"order_id",$delete1);
		if($result){
			delete_record($user,"order_id",$delete1);
			$notdel=0;
		}
		else{
			$notdel=1;
		}
	}
		$total=0;	
		$total2=0;
	if($complete!=null){
//--------------------------------Check_clear point of customer-------------
		$clear_point_id=$HTTP_GET_VARS[clear_point_id];
			if($clear_point_id!=null){
				update_record_where("customer","cust_id",$clear_point_id,"point","0");
			}
//-------------------------------Print------------------------------------------------
		$print_complete=$HTTP_GET_VARS[print_complete];
	    if($print_complete!=1){
		$recive=$HTTP_GET_VARS[recive];
		$change=$HTTP_GET_VARS[change];
		echo "<body onload=\"print1('$recive','$change')\">";
		}
//--------------------------------Print section-------------------------------------	
		if($print_complete==1){
//-------------------------------1.copy to tx---------------------------------------	
				$result=select_record_max("tx","group_id");
				$max=mysql_result($result,0,"MAX(group_id)");
				if($max==null){$max=1;}
				else{$max=$max+1;}
				$sql="SELECT * FROM $user;";
				$result=mysql_query($sql);
					while($dbarr=mysql_fetch_array($result)){
						$goods_id=$dbarr["goods_id"];
						$amount=$dbarr["amount"];
						$total_price=$dbarr["total_price"];
						$sale_percent=$dbarr["sale_percent"];
						$result99=select_record("goods","goods_id",$goods_id);
						$temp=mysql_result($result99,0,"total_remain");
						$data_update=$temp-$amount;
						update_record_where("goods","goods_id",$goods_id,"total_remain",$data_update);
						insert_to_tx($max,$goods_id,$amount,$total_price,$sale_percent);
					}
		//----------------------------2.copy to tx2----------------------------------------
				$sql="SELECT sum(total_price) AS total FROM $user;";
				$result=mysql_query($sql);
				$total2=mysql_result($result,0,'total');
				$today=getdate();
				$year=$today["year"]+543;
				$date=$today["mday"]."/".$today["mon"]."/".$year;
				$time=$today["hours"].":".$today["minutes"];
				$y=$year-2500;
				$weight=$today["mday"]+$today["mon"]*40+$y*600;
				if($total2!=0){
					insert_to_tx2($max,"",$total2,$date,$weight,$time,$user);	
				}
		//-------------------------------Set point discount-----------------------
				$file="config\\".$user.".txt";
				$c_id=getconfig_file($file,"temp","1:c_id");
				if($c_id!=null){
					$c_id=substr($c_id,1);
					$find=find_record("customer","cust_id",$c_id);
					if($find){
						$result2=select_record("customer","cust_id",$c_id);
						$old_point=mysql_result($result2,0,"point");
						$add=getconfig("config","2:add_point");
						if($add!=0){$add=$total2/$add; $add=(integer)$add;}
						$add;
						$point=$old_point+$add;
						update_record_where("customer","cust_id",$c_id,"point",$point);
					}
				}
				$file="config\\".$user.".txt";
				setconfig_file($file,"temp","1:c_id","");//function
		//-------------------------------update to store----------------------------------
				$sql="DROP TABLE $user";
				$result=mysql_query($sql);
		//---------���ҧ table Temp_tx -------------------  
				$sql="CREATE TABLE  $user (				
						order_id int( 16  )  NOT  NULL ,
						goods_id VARCHAR( 16  )  NOT  NULL ,
						goods_name VARCHAR( 45  )  NOT  NULL ,
						unit VARCHAR( 16  )  NOT  NULL ,
						amount int( 16  )  NOT  NULL ,
						total_price float( 16  )  NOT  NULL ,
						sale_percent int( 16  )  NOT  NULL ,				
						PRIMARY KEY(order_id));";
						mysql_query($sql);	
			}//end main print
	}//end main complete
	else{
		$sql="SELECT count(*) AS num FROM $user;";
		$result=mysql_query($sql);
		$num=mysql_result($result,0,'num');
			if($num>0){
				$sql="SELECT sum(total_price) AS total FROM $user;";
				$result=mysql_query($sql);
				$total=mysql_result($result,0,'total');
			}
	}
//---------------------------------------------------------------------------
		$result=select_all_record("order_id",$user);
		$num2=mysql_num_rows($result);
			if($tab==null){$tab=$num2;}
//-----------------------Check c-------------------------------------------
$check_c=$HTTP_GET_VARS[check_c];
$find=0;
if($check_c!=""){
$bool=find_record("customer","cust_id",$check_c);
		if($bool){
			$find=$check_c;
		}
		else{
			$find="no";
		}
}
?>
<body scroll="no" background="image\bg_pos\bg.jpg" onload="init(<?echo $total;?>,<?echo $notdel;?>,<?echo $sale;?>,<?echo $not_find;?>,<?echo $num2;?>,<?echo $tab;?>,'<?echo $customs_id;?>')" >
<form action="pos.php" method="post" name="form1">
<center>
<input type="hidden" id="check_c" value="<?echo $find;?>" />
<table width="757" height="535" border="0"  cellspacing="0" cellpadding="2" background="image\bg_pos\bg.jpg">
	<tr height="40" >
		<td>
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
		<tr><td>
		<button onclick="clear1();"><center><img src="image\clear\clear.jpg" height="22" align="left" hspace="0" />¡��ԡ</center></button>
		<button onclick="find();"><center><img src="image\find\find.jpg" height="22" align="left" hspace="0"/>����</center></button>
		<button onclick="cal();"><center><img src="image\cal\cal.jpg" height="22"align="left" hspace="0"/>�ӹǹ</center></button>
		</td><td align="right">
			<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'"
	
		   onclick="logout();" /> 
			</td></tr>
		</table>
		</td>
	</tr>
	
	
	<tr height="5%" background="image\bg_pos\bg.jpg">
		<td>
		<?
			$result=select_record_max("tx","group_id");
			$max=mysql_result($result,0,"MAX(group_id)");
		?>
			<font color="#FFFFFF"><b>�Ţ���㺡ӡѺ�Թ��� : </b></font>
			<font color="#FFFF00"><?echo $max+1;?></font> 
			&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#FFFFFF"><b>���ʾ�ѡ�ҹ : </b></font> 
			</font><font color="#FFFF00"><?echo $user?></font> 
			&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#FFFFFF"><b>�ѹ��� : </b></font> 
			</font><font color="#FFFF00" id="FNT"><b></b></font> 
			&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#FFFFFF"><b>���� : </b></font>
			</font><font color="#FFFF00" id="FNT2"><b></b></font>
		</td>
	</tr>

	<tr height="95%" bgcolor="#9999CC">
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#9999CC">
			<tr>
			<td>
				<iframe src="iframe7.php?code1=<?echo $code1;?>&&arrow=<?echo $tab;?>" id="iframe7" width="100%" height="100%" >
				
				</iframe>
			</td>
			</tr>
		</table>
		 
	</td>
	</tr>
	<tr height="60" valign="middle">
		<td >
			<table width="100%" height="90%" border="0" cellspacing="0" cellpadding="0" >
				<tr >
					<td width="50%">					
						<font color="#FFFFFF"><b>�����Թ���</b></font> <input type="text" name="code" id="code" size="17" maxlength=16 readonly/>
						<font color="#FFFFFF"><b>��ǹŴ</b></font> <input type="text" size="6" id="sale" value="<?echo $sale;?>" readonly/><font color="#FFFFFF"><b>%</b></font>				
					</td>
					<td bgcolor="" width="50%" align="right">
					<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="">
						<tr>
						<td align="center" width="40%">
							<font color="#FFFF00" size="+10"><b id="total">���</b></font>
						</td>
						<td align="center" width="60%" background="<?if($customs_id==null){echo "def.jpg";}else{echo "cust1.jpg";}?>" id="color_sum">				
						<font color="#FFFF00" size="+10"><b id="number"></b></font>
						</td>
						</tr>
					</table>
				</tr>
			</table>	
		</td>
	</tr>
</table>
</form>
</center>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
