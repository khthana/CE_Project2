<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="th" lang="th" dir="ltr">

<head>
<title>query</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620" />
<base href="http://localhost/phpmyadmin/" />
<link rel="stylesheet" type="text/css" href="./css/phpmyadmin.css.php?lang=th-tis-620&amp;js_frame=right" />
<SCRIPT LANGUAGE="JavaScript">
	 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
	function init(){
		top.location.href("pos.php");
	}
	function tab(i,count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#eeeeee";
		}
		var id="id"+i;
		gE(id).style.backgroundColor = "#FFFF00";
		top.location.href("pos.php?tab="+i);
	}
	function set_tab(count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#eeeeee";
		}
	}
function print1(){
	window.print();
}	
</SCRIPT>
</HEAD>
<?
include("fn_mysql.php");
connect_mysql("db_admin");//function
		$q=$HTTP_GET_VARS[q];
		$q2=$HTTP_GET_VARS[q2];
		
if($q==1){
		$bday=$HTTP_GET_VARS[bday];
		$bmonth=$HTTP_GET_VARS[bmonth];	
		$byear=$HTTP_GET_VARS[byear];
		$eday=$HTTP_GET_VARS[eday];
		$emonth=$HTTP_GET_VARS[emonth];
		$eyear=$HTTP_GET_VARS[eyear];
        $by=$byear-2500;
		$ey=$eyear-2500;
		$bdate=$bday+$bmonth*40+$by*600;
		$edate=$eday+$emonth*40+$ey*600;
?>
<BODY bgcolor="undefined">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
<caption align="right"><font size="2">��§ҹ������ѹ��� <?echo $bday."/".$bmonth."/".$byear." ";?>�֧�ѹ���  <?echo $eday."/".$emonth."/".$eyear." ";?> </font></caption>

	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>�����źѭ�շ����</u></font></center>
	</th>
	</tr >
   
	<tr  height="1">
	<td>
		<?
			$sql="SELECT group_id FROM tx2 WHERE tx_weight>=".$bdate." AND tx_weight<=".$edate.";";
			$result=mysql_query($sql);
				$sum=0;
				$sum_money=0;
				$sum_fund=0;
				while($dbarr=mysql_fetch_array($result)){
					//echo $dbarr["group_id"];
					$sql="SELECT SUM(amount) FROM tx WHERE group_id = ".$dbarr["group_id"].";";
					$result2=mysql_query($sql);
					$list=mysql_result($result2,0,"SUM(amount)");
					$sum=$sum+$list;

					$sql="SELECT SUM(total_price) FROM tx WHERE group_id = ".$dbarr["group_id"].";";
					$result3=mysql_query($sql);
					$list=mysql_result($result3,0,"SUM(total_price)");
					$sum_money=$sum_money+$list;

					$sql="SELECT goods_id FROM tx WHERE group_id = ".$dbarr["group_id"].";";
					$result4=mysql_query($sql);
					while($dbarr=mysql_fetch_array($result4)){
						$sql="SELECT fund_price FROM goods WHERE goods_id = ".$dbarr["goods_id"].";";
						$result5=mysql_query($sql);
						$fund=mysql_result($result5,0,"fund_price");
						$sum_fund=$sum_fund+$fund;
					}

				}
		?>
		&nbsp;
		����Թ��ҷѧ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	  <?echo $sum;?>&nbsp;&nbsp;&nbsp; &nbsp;��¡��
	</td>
	</tr >

	<tr  height="1">
	<td>
		&nbsp;
		������Թ������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?echo $sum_money;?>&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>	
	</tr >

	<tr >
	<td>
		&nbsp;	�鹷ع���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; <?echo $sum_fund;?>&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>
	</tr >

	<tr >
	<td>
		&nbsp;
	    <font color="#FF6600"><b>�����ط�Ԥ��</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font color="#FF6600"><b><?echo $sum_money-$sum_fund;?></b></font>&nbsp;&nbsp;&nbsp; &nbsp;<font color="#FF6600"><b>�ҷ</b></font>
	</td>
	</tr >

	<tr >
	<td>
		&nbsp;
	    ���õ��˹����Թ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<? $s=0; if($sum!=0){$s=($sum_money-$sum_fund)/$sum;} echo $s;?>&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>
	</tr >
	</table>
</BODY>

<?//end if q
}
else if($q2==1){//null form
?>
<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
<caption align="right"><font size="2">��§ҹ������ѹ���   �֧�ѹ���   </font></caption>

	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>�����źѭ�շ����</u></font></center>
	</th>
	</tr >
   
	<tr  height="1">
	<td>
		&nbsp;
		����Թ��ҷѧ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	  0&nbsp;&nbsp;&nbsp; &nbsp;��¡��
	</td>
	</tr >

	<tr  height="1">
	<td>
		&nbsp;
		������Թ������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>	
	</tr >

	<tr >
	<td>
		&nbsp;	�鹷ع���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 0&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>
	</tr >

	<tr >
	<td>
		&nbsp;
	    <font color="#FF6600"><b>�����ط�Ԥ��</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font color="#FF6600"><b>0</b></font>&nbsp;&nbsp;&nbsp; &nbsp;<font color="#FF6600"><b>�ҷ</b></font>
	</td>
	</tr >

	<tr >
	<td>
		&nbsp;
	    ���õ��˹����Թ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;0&nbsp;&nbsp;&nbsp; &nbsp;�ҷ
	</td>
	</tr >
	</table>
</BODY>
<?
}





//************************************��§ҹ�Թ��ҷ������͹��·���ش㹤�ѧ*********************************
if($q==2){
	$order=$HTTP_GET_VARS[order];
	$sql="SELECT goods_id,goods_name,total_remain FROM goods ORDER BY total_remain ;";
	$result=mysql_query($sql);
    $num=mysql_num_rows($result);
	if($order>$num){$temp=$order;$order=$num;}
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��ҷ������͹��·���ش <?echo $order;?> �ѹ�Ѻ</u></font></center>
	</th>
	</tr >

	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�������</td>
	</tr>
	
<?$i=0;
	while($i<$order){ $o=$i+1;?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$o."</td>";
			echo "<td>".mysql_result($result,$i,"goods_id")."</td>";
			echo "<td>".mysql_result($result,$i,"goods_name")."</td>";
			echo "<td>".mysql_result($result,$i,"total_remain")."</td>";
			$i++;			
		?>	
	</tr>
<?}?>

<tr><td colspan="4">
<center><?if($temp>$num) echo "�Թ���㹤�ѧ����  ".$num."  ��¡��";?></center>
</td></tr>
</table>
</BODY>
<?
}
else if($q2==2){//null form

?>
<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��ҷ������͹��·���ش n �ѹ�Ѻ</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�������</td>
	</tr>

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}



//*********************************��§ҹ�Թ��ҷ��������ҡ����ش㹤�ѧ**********************************
if($q==3){
	$order=$HTTP_GET_VARS[order];
	$sql="SELECT goods_id,goods_name,total_remain FROM goods ORDER BY total_remain DESC;";
	$result=mysql_query($sql);
    $num=mysql_num_rows($result);
	if($order>$num){$temp=$order;$order=$num;}
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��ҷ��������ҡ����ش <?echo $order;?> �ѹ�Ѻ</u></font></center>
	</th>
	</tr >

	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�������</td>
	</tr>
	
<?$i=0;
	while($i<$order){ $o=$i+1;?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$o."</td>";
			echo "<td>".mysql_result($result,$i,"goods_id")."</td>";
			echo "<td>".mysql_result($result,$i,"goods_name")."</td>";
			echo "<td>".mysql_result($result,$i,"total_remain")."</td>";
			$i++;			
		?>	
	</tr>
<?}?>
<tr><td colspan="4">
<center><?if($temp>$num)echo "�Թ���㹤�ѧ����  ".$num."  ��¡��";?></center>
</td></tr>
</table>
</BODY>
<?//end if q
}
else if($q2==3){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��ҷ��������ҡ����ش n �ѹ�Ѻ</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�������</td>
	</tr>

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}


//*********************************��§ҹ�Թ��� n �ѹ�Ѻ��´�**********************************
if($q==4){
	$order=$HTTP_GET_VARS[order];
	$sql="SELECT goods_id, SUM( amount )FROM tx GROUP  BY goods_id ORDER  BY 2 DESC;";
	$result=mysql_query($sql);
    $num=mysql_num_rows($result);
	if($order>$num){$temp=$order;$order=$num;}
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��� <?echo $order;?> �ѹ�Ѻ��´�</u></font></center>
	</th>
	</tr >
	
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�ӹǹ</td>
	</tr>

<?$i=0;
	while($i<$order){ $o=$i+1;?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$o."</td>";
			echo "<td>".mysql_result($result,$i,"goods_id")."</td>";
			$sql="SELECT goods_name FROM goods WHERE goods_id=".mysql_result($result,$i,"goods_id").";";
			$result2=mysql_query($sql);
			echo "<td>".mysql_result($result2,0,"goods_name")."</td>";
			echo "<td>".mysql_result($result,$i,"SUM( amount )")."</td>";
			$i++;			
		?>	
	</tr>
<?}?>
<tr><td colspan="4">
<center><?if($temp>$num)echo "�Թ���㹤�ѧ����  ".$num."  ��¡��";?></center>
</td></tr>
</table>
</BODY>

<?//end if q
}
else if($q2==4){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��� n �ѹ�Ѻ��´�</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�ӹǹ</td>
	</tr>	

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}



//*********************************��§ҹ�Թ��� n �ѹ�Ѻ�ʹ���**********************************
if($q==5){
	$order=$HTTP_GET_VARS[order];
	$sql="SELECT goods_id, SUM( amount )FROM tx GROUP  BY goods_id ORDER  BY 2 ;";
	$result=mysql_query($sql);
    $num=mysql_num_rows($result);
	if($order>$num){$temp=$order;$order=$num;}
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��� <?echo $order;?> �ѹ�Ѻ�ʹ���</u></font></center>
	</th>
	</tr >
	
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�ӹǹ</td>
	</tr>	

<?$i=0;
	while($i<$order){ $o=$i+1;?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$o."</td>";
			echo "<td>".mysql_result($result,$i,"goods_id")."</td>";
			$sql="SELECT goods_name FROM goods WHERE goods_id=".mysql_result($result,$i,"goods_id").";";
			$result2=mysql_query($sql);
			echo "<td>".mysql_result($result2,0,"goods_name")."</td>";
			echo "<td>".mysql_result($result,$i,"SUM( amount )")."</td>";
			$i++;			
		?>	
	</tr>
<?}?>
<tr><td colspan="4">
<center><?if($temp>$num)echo "�Թ���㹤�ѧ����  ".$num."  ��¡��";?></center>
</td></tr>
</table>
</BODY>

<?//end if q
}
else if($q2==5){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="4">
		<center><font size=""><u>�Թ��� n �ѹ�Ѻ�ʹ���</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	<td>�ӹǹ</td>
	</tr>

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}




//*********************************��§ҹ�Թ��ҷ������������**********************************
if($q==6){
	$sql="SELECT goods_id,goods_name FROM goods GROUP  BY goods_id;";
	$result2=mysql_query($sql);
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>�Թ��ҷ������������</u></font></center>
	</th>
	</tr >
	
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	</tr>

<?
	$i=1;
	$c=0;
	while($dbarr2=mysql_fetch_array($result2)){
		$check=0;
		$sql="SELECT goods_id FROM tx GROUP  BY goods_id;";
		$result=mysql_query($sql);
		while($dbarr=mysql_fetch_array($result)){
			if($dbarr2["goods_id"]==$dbarr["goods_id"]){
				$check=1;
			}
		}
	if($check==0){
		$c++;
	?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$i."</td>";
			echo "<td>".$dbarr2["goods_id"]."</td>";
			echo "<td>".$dbarr2["goods_name"]."</td>";
			$i++;			
		?>	
	</tr>
<?}
			}?>
<tr><td colspan="3">
<center><?if($c==0)echo "������Թ��ҷ���������";?></center>
</td></tr>
</table>
</BODY>

<?//end if q
}
else if($q2==6){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>�Թ��ҷ������������</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	</tr>

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}




//*********************************���繤�����Թ��ҡ������¡�ù��**********************************
if($q==7){
	$order=$HTTP_GET_VARS[order];
	$sql="SELECT employee FROM tx2 WHERE group_id=".$order.";";
	$result=mysql_query($sql);
	$num=mysql_num_rows($result);
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>���繤�����Թ��ҡ������¡�ù��</u></font></center>
	</th>
	</tr >
	
<?if($num>0){
	$sql="SELECT goods_id FROM tx WHERE group_id=".$order.";";
	$result2=mysql_query($sql);
	
?>
	<tr  height="1">	
		<? 							
			echo "<td colspan=3>���ʼ���¤��  <font color=#FF6600><b>".mysql_result($result,0,"employee")."</b></font></td>";	
		?>	
	</tr>
	<tr  height="1">	
		<? 							
			echo "<td colspan=3><font color=#FF6600><b>��¡���Թ��ҷ�����</b></font></td>";	
		?>	
	</tr>
	<tr>
	<td>�ӴѺ</td>
	<td>�����Թ���</td>
	<td>�����Թ���</td>
	</tr>
	<?
	$i=1;
	while($dbarr=mysql_fetch_array($result2)){
		$sql="SELECT goods_id,goods_name FROM goods WHERE goods_id=".$dbarr["goods_id"].";";
		$result3=mysql_query($sql);
	?>
		<tr  height="1">	
			<? 
				echo "<td>".$i."</td>";
				echo "<td>".mysql_result($result3,0,"goods_id")."</td>";
				echo "<td>".mysql_result($result3,0,"goods_name")."</td>";	
			?>	
		</tr>
	<?
				$i++;
	}
	?>
<?}?>
<tr><td>
<center><?if($num==0)echo "����ա�â���Թ��ҡ������¡�ù��";?></center>
</td></tr>
</table>
</BODY>

<?//end if q
}
else if($q2==7){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="3">
		<center><font size=""><u>���繤�����Թ��ҡ������¡�ù��</u></font></center>
	</th>
	</tr >
   
	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}



//*********************************��Ǩ�ͺ���������к�**********************************
if($q==8){
	    $bday=$HTTP_GET_VARS[bday];
		$bmonth=$HTTP_GET_VARS[bmonth];	
		$byear=$HTTP_GET_VARS[byear];
		$bdate=$bday."/".$bmonth."/".$byear;
		$sql="SELECT * FROM login WHERE login_date='$bdate';";
		$result=mysql_query($sql);
		$num=mysql_num_rows($result);
		
?>
<BODY bgcolor="#FFFFFF">
<button onclick="print1();"><center>�����&nbsp;</center></button>
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
<caption align="right"><font size="2">��§ҹ�ѹ��� <?echo $bday."/".$bmonth."/".$byear." ";?></font></caption>
	<tr  height="1">
	<th colspan="5">
		<center><font size=""><u>��Ǩ�ͺ���������к�</u></font></center>
	</th>
	</tr >

	<tr>
	<td>�ӴѺ</td>
	<td>��������</td>
	<td>�������</td>
	<td>�����͡</td>
	<td>�к�</td>
	</tr>
	
<?if($num!=0){
	$i=1;
	while($dbarr=mysql_fetch_array($result)){?>   
	<tr  height="1">	
		<? 					
			echo "<td>".$i."</td>";
			echo "<td>".$dbarr["username"]."</td>";
			echo "<td>".$dbarr["login_time"]."</td>";
			echo "<td>".$dbarr["logout_time"]."</td>";
			echo "<td>".$dbarr["page"]."</td>";
			$i++;			
		?>	
	</tr>
<?}
}		
?>
<tr><td colspan="5">
<center><?if($num==0)echo "����ա��������к�";?></center>
</td></tr>
</table>
</BODY>

<?//end if q
}
else if($q2==8){//null form

?>
	<BODY bgcolor="#FFFFFF">
<table width="340" height="1" border="1" bordercolor="#660000" style="border-collapse: collapse; background-color: white"  frame="box" >
	<tr  height="1">
	<th colspan="5">
		<center><font size=""><u>��Ǩ�ͺ���������к�</u></font></center>
	</th>
	</tr >
   
	<tr>
	<td>�ӴѺ</td>
	<td>��������</td>
	<td>�������</td>
	<td>�����͡</td>
	<td>�к�</td>
	</tr>

	<tr  height="1">
	<td>
		
	</td>
	</tr>
	</table>
</BODY>
<?
}
?>
</HTML>