<?php
//-------------------------------Connect Database-----------------------------------
function  connect_mysql($dbname){
	if($dbname==" "){
			$host=getconfig("mysql","1:host");
			$user=getconfig("mysql","2:username");
			$password=getconfig("mysql","3:password");
			$link=mysql_pconnect($host,$user,$password);
			if($link){
				return 1;
			//echo "number in connect<b>" . $link . "</b><br>";			
			}
			else{
				return 0;
			}
	}
		else{$host=getconfig("mysql","1:host");
				$user=getconfig("mysql","2:username");
				$password=getconfig("mysql","3:password");
				$link=mysql_pconnect($host,$user,$password);
				if($link){
					$result=mysql_select_db($dbname);
					 if($result){ return 1;}
					 else return 0;
				//echo "number in connect<b>" . $link . "</b><br>";
				}
				else{
					return 0;
				}
			}
}
//--------------------------------------------------------------------------------
 function getconfig($group,$key)
	  {
		    if($group&&$key){
					$filenum=fopen("config.ini", "r");
					$data=fread($filenum,2000);
					fclose($filenum);
					//echo $data . "<br />--------------";
					
					$pos1=strpos($data,$group); //Select group config
					//echo $pos1 . "<br />";
					$end_group="end_" . $group;
					$pos2=strpos($data,$end_group);
					//echo $pos2 . "<br />";
					$form1=substr($data,$pos1,$pos2);
					//echo $form1 . "<br>";
									
					$pos1=strpos($form1,$key);
					//echo $pos1. "<br />";
					$form2=substr($form1,$pos1);
					//echo $form2 . "<br />";
					$pos2=strpos($form2,";");
					$form3=substr($form2,0,$pos2+1);
					//echo $form3 . "<br />";

					$pos1=strpos($form3,"\"");
					$form4=substr($form3,$pos1+1);
					$pos2=strpos($form4,";");
					$form5=substr($form4,0,$pos2-1);
					return $form5;
			}
			else{
					echo"��͹��������ú";
			}
	  }
//--------------------------------------------------------------------------------
 function setconfig($group,$key,$keyset)
	  {
		    if($group&&$key){
					$filenum=fopen("config.ini", "r");
					$data=fread($filenum,2000);
					fclose($filenum);
					//echo $data . "<br />--------------";
					
					$pos1=strpos($data,$group); //Select group config
					//echo $pos1 . "<br />";
					$string1=$string1+$pos1;
					$end_group="end_" . $group;
					$pos2=strpos($data,$end_group);
					//echo $pos2 . "<br />";
					$form1=substr($data,$pos1,$pos2);
					//echo $form1 . "<br>";
									
					$pos1=strpos($form1,$key);
					//echo $pos1. "<br />";
					$string1=$string1+$pos1;
					$form2=substr($form1,$pos1);
					//echo $form2 . "<br />";
					$pos2=strpos($form2,";");
					//echo $pos2. "<br />";
					$form3=substr($form2,0,$pos2+1);
					//echo $form3 . "<br />";

					$pos1=strpos($form3,"\"");
					//echo $pos1 . "<br />";
					$string1=$string1+$pos1;
					$form4=substr($form3,$pos1+1);
					//echo $form4 . "<br />";
					$pos2=strpos($form4,";");
					//echo $pos2 . "<br />";
					$string2=$string1+$pos2;
					$form5=substr($form4,0,$pos2-1);

					$str1=substr($data,0,$string1+1);
					$string3=strlen($data);
					$str2=substr($data,$string2,$string3);
					$outstring=$str1 . $keyset . $str2;
					//echo $outstring;
						$filenum=fopen("config.ini", "w");
						fwrite($filenum,$outstring);
						fclose($filenum);
			}
			else{
					echo"��͹��������ú";
			}
	  }
//--------------------------------------------------------------------------------
 function getconfig_file($file,$group,$key)
	  {
		    if($group&&$key){
					$filenum=fopen($file, "r");
					$data=fread($filenum,2000);
					fclose($filenum);
					//echo $data . "<br />--------------";
					
					$pos1=strpos($data,$group); //Select group config
					//echo $pos1 . "<br />";
					$end_group="end_" . $group;
					$pos2=strpos($data,$end_group);
					//echo $pos2 . "<br />";
					$form1=substr($data,$pos1,$pos2);
					//echo $form1 . "<br>";
									
					$pos1=strpos($form1,$key);
					//echo $pos1. "<br />";
					$form2=substr($form1,$pos1);
					//echo $form2 . "<br />";
					$pos2=strpos($form2,";");
					$form3=substr($form2,0,$pos2+1);
					//echo $form3 . "<br />";

					$pos1=strpos($form3,"\"");
					$form4=substr($form3,$pos1+1);
					$pos2=strpos($form4,";");
					$form5=substr($form4,0,$pos2-1);
					return $form5;
			}
			else{
					echo"��͹��������ú";
			}
	  }
//--------------------------------------------------------------------------------
 function setconfig_file($file,$group,$key,$keyset)
	  {
		    if($group&&$key){
					$filenum=fopen($file, "r");
					$data=fread($filenum,2000);
					fclose($filenum);
					//echo $data . "<br />--------------";
					
					$pos1=strpos($data,$group); //Select group config
					//echo $pos1 . "<br />";
					$string1=$string1+$pos1;
					$end_group="end_" . $group;
					$pos2=strpos($data,$end_group);
					//echo $pos2 . "<br />";
					$form1=substr($data,$pos1,$pos2);
					//echo $form1 . "<br>";
									
					$pos1=strpos($form1,$key);
					//echo $pos1. "<br />";
					$string1=$string1+$pos1;
					$form2=substr($form1,$pos1);
					//echo $form2 . "<br />";
					$pos2=strpos($form2,";");
					//echo $pos2. "<br />";
					$form3=substr($form2,0,$pos2+1);
					//echo $form3 . "<br />";

					$pos1=strpos($form3,"\"");
					//echo $pos1 . "<br />";
					$string1=$string1+$pos1;
					$form4=substr($form3,$pos1+1);
					//echo $form4 . "<br />";
					$pos2=strpos($form4,";");
					//echo $pos2 . "<br />";
					$string2=$string1+$pos2;
					$form5=substr($form4,0,$pos2-1);

					$str1=substr($data,0,$string1+1);
					$string3=strlen($data);
					$str2=substr($data,$string2,$string3);
					$outstring=$str1 . $keyset . $str2;
					//echo $outstring;
						$filenum=fopen($file, "w");
						fwrite($filenum,$outstring);
						fclose($filenum);
			}
			else{
					echo"��͹��������ú";
			}
	  }
//--------------------------------------------------------------------------------
function compare($table,$field1,$data1,$field2,$data2)
{	 
			connect_mysql("db_admin");//function
			$find=find_record($table,$field1,$data1);
			if($find){
				$result=select_record($table,$field1,$data1);
				$pass=mysql_result($result,0,"password");
				if($data2==$pass){
					return 1;
				}
			}
			      return 0;
}

//------------------------------------------------------------------------------------------
function return_sort($num)
	{
						connect_mysql("db_admin");//function
						$name="\" ". "case" . $num . "\"";	
						$test_empty= "case" . $num;
						$sql="select id, name0, type, size from data where word_case=$name;";
						$result=mysql_query($sql);
						$find=find_data_record($test_empty,"word_case","data");
						//echo $find;
						if($find!=0){
						$array=array();
						$i=0;
						while($dbarr=mysql_fetch_array($result)){
										  $array[$i]=trim($dbarr["name0"]);
							for($j=0; $j<=strlen($array[$i]); $j++){
										   $test=strtolower($array[$i]{$j});				   
									   if((ord($test) >= 161)&&(ord($test) <= 206)){
											$temp=$array[$i];
											$order[]=array($test);
										   break;
									   }
									   else if((ord($test) >= 97)&&(ord($test) <= 112)){
											$order[]=array($test);
											break;
									   }
								 }
							$i++;
						}
						   asort($order);	
									$oder_str=array();
									while($element=each($order)){
										 $oder_str[]=$array[$element["key"]];
										$test=each($element["value"]);										
									}
									
					return $oder_str;
			}
	}
	//-------------------------------------------------------------------------------------------------------------------------------
	function cut_space($word_cut)
		{
					connect_mysql("db_admin");//function
					$word_sort=array();
					$word_cut=explode(" ",$word_cut);
					for( $j=0; $j<count($word_cut); $j++){
							if($word_cut[$j]!=null){	
								$word_sort[]=$word_cut[$j];
								$word_string=$word_string . " " . $word_cut[$j];
							}
					}
					$word_string=ltrim($word_string);
					return explode(" ",$word_string);
	}

//------------------------------------------------------------------------------------------------------------------------------
function select_all_record($field,$table)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT $field FROM $table;";
			$result=mysql_query($sql);
		return $result;
		}	
//---------------------------------------------------------------------------------------------
	function select_record_max($table,$field)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT MAX($field) FROM $table;";
			$result=mysql_query($sql);
		return $result;
	}
//---------------------------------------------------------------------------------------------
	function select_record_sum($table,$field)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT SUM($field) FROM $table;";
			$result=mysql_query($sql);
			$sum=mysql_result($result,0,"SUM($field)");
		return $sum;
		}
//------------------------------------------------------------------------------------------------------------------------------
function select_all_record_order($field,$table,$order)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT $field FROM $table ORDER BY $order;";
			$result=mysql_query($sql);
		return $result;
		}	
	//------------------------------------------------------------------------------------------------------------------------------
function select_record($table,$field,$data)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT * FROM ".$table." WHERE ".$field."='".$data."';";
			$result=mysql_query($sql);
		return $result;
		}
//------------------------------------------------------------------------------------------------------------------------------
function select_record_2where($table,$field1,$data1,$field2,$data2)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT * FROM ".$table." WHERE ".$field1."='".$data1."' AND ".$field2."='".$data2."';";
			$result=mysql_query($sql);		
		return $result;
		}
//------------------------------------------------------------------------------------------------------------------------------
function select_record_oder($table,$field,$data,$order)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT * FROM ".$table." WHERE ".$field."='".$data."' ORDER BY $order;";
			$result=mysql_query($sql);
		return $result;
		}
	//------------------------------------------------------------------------------------------------------------------------------
function find_record($table,$field,$data)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT count(*) AS num FROM ".$table." WHERE ".$field."='".$data."';";
			$result=mysql_query($sql);
			$find=mysql_result($result,0,"num");
		return $find;
		}
function find_2record($table,$field1,$data1,$field2,$data2)
		{	 
			connect_mysql("db_admin");//function
			$sql="SELECT count(*) AS num FROM ".$table." WHERE ".$field1."='".$data1."' AND ".$field2."='".$data2."';";
			$result=mysql_query($sql);
			$find=mysql_result($result,0,"num");
		return $find;
		}
//------------------------------------------------------------------------------------------------------------------------------	
function update_2record($table,$field1,$data1,$field2,$data2,$field_update,$data_update)
		{	 
			connect_mysql("db_admin");//function
			$find=find_2record($table,$field1,$data1,$field2,$data2);
			if($find){
$sql="UPDATE $table SET $field_update='$data_update' WHERE ".$field1."='".$data1."' AND ".$field2."='".$data2."';";
			$result=mysql_query($sql);
				return $find;
			}
			else{
				return 0;
			}
		}
	//------------------------------------------------------------------------------------------------------------------------------
function delete_record($table,$field,$data)
		{	 
			connect_mysql("db_admin");//function
			$find=find_record($table,$field,$data);
			if($find){
			$sql="delete from ".$table." where ".$field."  like '$data' ";
			$result=mysql_query($sql);
			}
			else{
				return 0;
			}
		}
	//------------------------------------------------------------------------------------------------------------------------------	
function update_record($table,$field,$olddata,$newdata)
		{	 
			connect_mysql("db_admin");//function
			$find=find_record($table,$field,$olddata);
			if($find){
			$sql="UPDATE $table SET $field='$newdata' WHERE $field='$olddata';";
			$result=mysql_query($sql);
				return $find;
			}
			else{
				return 0;
			}
		}
	//------------------------------------------------------------------------------------------------------------------------------	
function update_record_where($table,$field_where,$data_where,$field_update,$data_update)
		{	 
			connect_mysql("db_admin");//function
			$find=find_record($table,$field_where,$data_where);
			if($find){
			$sql="UPDATE $table SET $field_update='$data_update' WHERE $field_where='$data_where';";
			$result=mysql_query($sql);
				return $find;
			}
			else{
				return 0;
			}
		}
	//------------------------------------------------------------------------------------------------------------------------------	
function insert_to_employee($data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9,$data10, $data11,$data12,$data13,$data14)
		{	 
			connect_mysql("db_admin");//function			
			$sql="INSERT INTO employee (username,password,name,lastname,sex,address,post,tel1,tel2,email,position,saraly,picture) values('". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "','". $data8 . "','". $data9 . "','". $data10 . "','". $data11 . "','". $data12 . "','". $data13 . "','". $data14 . "');";
			$result=mysql_query($sql);				
		}
function update_to_employee($emp_id,$data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9,	$data10, $data11,$data12,$data13,$data14)
		{	 
			connect_mysql("db_admin");//function			
			$sql="UPDATE employee SET username='$data2',password='$data3',name='$data4',lastname='$data5',sex='$data6', address='$data7',post='$data8',tel1='$data9',tel2='$data10',email='$data11',position='$data12',saraly='$data13',picture='$data14' WHERE emp_id='$emp_id';";
			$result=mysql_query($sql);				
		}
function insert_to_goods($data1,$data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9,$data10, $data11,$data12)
		{	 
			connect_mysql("db_admin");//function			
			$sql="INSERT INTO goods (goods_id,type_id,supplier_id,goods_name,unit,retail_price,fund_price,sale_percent,total_remain,min_remain,zone,hot_key) values('". $data1 . "','". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "','". $data8 . "','". $data9 . "','". $data10 . "','". $data11 . "','". $data12 . "');";
			$result=mysql_query($sql);				
		}
function insert_to_expire($data2,$data3)
		{	
			connect_mysql("db_admin");//function
	$sql="INSERT INTO expire (goods_id,goods_expire) values('". $data2 . "','". $data3 . "');";
			$result=mysql_query($sql);			
		}
function insert_to_memexpire($data2,$data3)
		{	
			connect_mysql("db_admin");//function
			$sql="INSERT INTO memexpire (goods_id,day) values('". $data2 . "','". $data3 . "');";
			$result=mysql_query($sql);			
		}

function insert_to_customer($data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9)
		{	 
			connect_mysql("db_admin");//function			
			$sql="INSERT INTO customer (name,lastname,sex,address,post,tel1,tel2,email) values('". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "','". $data8 . "','". $data9 . "');";
			$result=mysql_query($sql);				
		}
function update_to_customer($cust_id,$data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9)
		{	 
			connect_mysql("db_admin");//function			
			$sql="UPDATE customer SET name='$data2',lastname='$data3',sex='$data4',address='$data5',post='$data6', tel1='$data7',tel2='$data8',email='$data9' WHERE cust_id='$cust_id';";
			$result=mysql_query($sql);				
		}
function insert_to_supplier($data2,$data3,$data4,$data5,$data6,$data7)
		{	 
			connect_mysql("db_admin");//function			
			$sql="INSERT INTO supplier (supplier_name,address,post,tel1,tel2,email) values('". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "');";
			$result=mysql_query($sql);				
		}
function update_to_supplier($supplier_id,$data2,$data3,$data4,$data5,$data6,$data7)
		{	 
			connect_mysql("db_admin");//function			
			$sql="UPDATE supplier SET supplier_name='$data2',address='$data3',post='$data4', tel1='$data5',tel2='$data6',email='$data7' WHERE supplier_id='$supplier_id';";
			$result=mysql_query($sql);				
		}
function insert_to_temp($table,$data2,$data3,$data4,$data5,$data6,$data7)
		{	
			connect_mysql("db_admin");//function
			id_oder($table,"order_id");
			$result=select_all_record("order_id",$table);
			$data1=mysql_num_rows($result);
			$data1=$data1+1;		
			$sql="INSERT INTO $table (order_id,goods_id,goods_name,unit,amount,total_price,sale_percent) values('". $data1 . "','". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "');";
			$result=mysql_query($sql);			
		}
function insert_to_login($table,$data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9)
		{	
			connect_mysql("db_admin");//function
			id_oder($table,"login_id");
			$result=select_all_record("login_id",$table);
			$data1=mysql_num_rows($result);
			$data1=$data1+1;		
			$sql="INSERT INTO $table (login_id,username,login_date,login_time,logout_date,logout_time,page,status,session_number) values('". $data1 . "','". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "','". $data8 . "','". $data9 . "');";
			$result=mysql_query($sql);			
		}
function insert_to_tx($data1,$data2,$data3,$data4,$data5)
		{	
			connect_mysql("db_admin");//function
			$sql="INSERT INTO tx (group_id,goods_id,amount,total_price,sale_percent) values('". $data1 . "','". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "');";
			$result=mysql_query($sql);			
		}
function insert_to_tx2($data2,$data3,$data4,$data5,$data6,$data7,$data8)
		{	
			connect_mysql("db_admin");//function
			$sql="INSERT INTO tx2 (group_id,cust_id,total_price_all,tx_date,tx_weight,tx_time,employee) values('". $data2 . "','". $data3 . "','". $data4 . "','". $data5 . "','". $data6 . "','". $data7 . "','". $data8 . "');";
			$result=mysql_query($sql);			
		}
function insert_to_goodstype($data2)
		{	 
			connect_mysql("db_admin");//function	
			id_oder("goodstype","type_id");
			$result=select_all_record("type_id","goodstype");
			$data1=mysql_num_rows($result);
			$data1=$data1+1;
			$result=find_record("goodstype","type_name",$data2);
				if(!$result){
					//echo "asdfa";
				$sql="INSERT INTO goodstype (type_id,type_name) values('". $data1 . "','". $data2 . "');";
				$result=mysql_query($sql);
				return 0;		
			    }
				else{return $result;}
		}
function insert_to_zone($data2)
		{	 
			connect_mysql("db_admin");//function	
			id_oder("zone","zone_id");
			$result=select_all_record("zone_id","zone");
			$data1=mysql_num_rows($result);
			$data1=$data1+1;
			$result=find_record("zone","zone_name",$data2);
				if(!$result){
					//echo "asdfa";
				$sql="INSERT INTO zone (zone_id,zone_name) values('". $data1 . "','". $data2 . "');";
				$result=mysql_query($sql);
				return 0;
				
			    }
				else{return $result;}
		}
function insert_to_unit($data2)
		{	 
			connect_mysql("db_admin");//function	
			id_oder("unit","unit_id");
			$result=select_all_record("unit_id","unit");
			$data1=mysql_num_rows($result);
			$data1=$data1+1;
			$result=find_record("unit","unit_name",$data2);
				if(!$result){
					//echo "asdfa";
				$sql="INSERT INTO unit (unit_id,unit_name) values('". $data1 . "','". $data2 . "');";
				$result=mysql_query($sql);
				return 0;
				
			    }
				else{return $result;}
		}
 //------------------------------------------------------------------------------------------------------------------------------
 function id_oder($table,$field)
	{
			connect_mysql("db_admin");//function
				$result=select_all_record($field,$table);
					$i=1;
				while($dbarr=mysql_fetch_array($result)){
						update_record($table,$field,$dbarr[$field],$i);
						$i++;
				}		
	}
 //------------------------------------------------------------------------------------------------------------------------------
?>