<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>���Ѿ��ͧ��ä���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
var count=0;
var status=0;
function init(list) {	
		count=list;
		document.onkeydown= showKeyDown;	
}
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;
		if(i==27)   window.close();
		else if(i==38){//up
			var s;
			if(status==0){s=count-1;}
			else if(status==count-1){s=count-2;}
			else{s=status-1;}
			status=s;
			over(s,count);
			out(s);
		}
		else if(i==40){//down
			var s;
			if(status==0){s=1;}
			else if(status==count-1){s=0;}
			else{s=status+1;}
			status=s;
			over(s,count);
			out(s);
		}
		else if(i==13){//enter
		 if(count!=0){
		     var id="cid"+status;
		     var code=gE(id).value;
				dclick(code);
			 }
		}
}

//--------------------------------------------------------------------------
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc(code);
}
window.onbeforeunload = verifyClose

function over(list,i){
	status=list;
	for(var j=0;j<i;j++){
			var id1="id"+j;
			gE(id1).style.backgroundColor = "#eeeeee";
	}
	var id2="id"+list;
	gE(id2).style.backgroundColor = "#FFFF00";
}
function out(list){
	status=list;
	var id="id"+list;
	gE(id).style.backgroundColor = "#FFFF00";
}
var code;
function dclick(list){
	code=list;
	window.close();
}
</SCRIPT>

</HEAD>
<?php
$search=$HTTP_GET_VARS[data];
$field=$HTTP_GET_VARS[field];
if($field=="cust_id"){$field_thai="������";}
else if($field=="name"){$field_thai="�鹪���";}
else if($field=="lastname"){$field_thai="�鹹��ʡ��";}
else if($field=="address"){$field_thai="�鹷������";}
else if($field=="email"){$field_thai="��Email"; }
$find_done=array();	
$id=array();	
if($search!=null){
	$result=select_all_record("*","customer");
				$i=0;
		while($dbarr=mysql_fetch_array($result)){
				$bool=stristr($dbarr[$field],$search);
				if($bool){
					$id[$i]=$dbarr["cust_id"];	
					$find_done[$i]=$dbarr[$field];	
					$i++;
				}		
		}
}
?>
<BODY bgcolor="#FFFFFF" onload="init(<? echo $i;?>);">
<form action="_self"  name="main_form" id="main_form" method="post">
<center>
<table border="0" width="105%" height="10%" bgcolor="" cellspacing="1">
						<tr bgcolor="9999cc">
						<td width="25%">
								<center>����</center>
						</td>
						<td>
								<center>���� ���ʡ��</center>
						</td>
						<td width="25%">
								<center><?echo $field_thai;?></center>
						</td>
						</tr>
<?
if(count($find_done)){
		for($k=0;$k<$i;$k++){ 
			 $result=select_record("customer","cust_id",$id[$k]);
			 $code=mysql_result($result,0,"cust_id");
			 $n=mysql_result($result,0,"name");
			 $ln=mysql_result($result,0,"lastname");
			 $name=$n." ".$ln;
			  ?><input type="hidden" value="<?echo $code;?>" id="<?echo "cid".$k?>"/><?
				?>
						<tr <?if($k==0){echo "bgcolor=#FFFF00";} else {echo "bgcolor=#eeeeee";}?> id="<?echo "id".$k;?>" onmouseover="over(<?echo $k;?>,<?echo $i;?>)" onmouseout="out(<?echo $k;?>)" ondblclick="dclick(<?echo $code;?>)">	
						<td>
						<center>
							<?
							echo $code; 
							?>
						</center>
						</td>
						<td>
						<center>
							<?echo $name;?>
						</center>
						</td>
						<td>
						<center>				
							<?echo $find_done[$k];?>
						</center>
						</td>
						</tr>
				<?
		}
}
?>
						<tr >
						<td colspan=3 >	
						<center>�鹾��Թ��� <?echo $i;?> ��¡��</center>
						</td>
						</tr>

</table>
</center>		
</form>
</BODY>
</HTML>
