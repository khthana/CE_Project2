<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Admin </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<script type="text/javascript">
//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
//-------------------------------------------------------------------
function init() {	
		gE("name").focus();
		gE("name").select();
}
function init(){
		document.onkeypress = showKeyPress;
	}
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27){
			var result=confirm('�س��㨷����͡˹�Ҽ��Ѵ��˹���');
				if(result){	
					logout();
				}
		}
}
//-------------------------------------------------------------------
	function isNumber(inputStr) {
		for (var i = 0; i < inputStr.length; i++) {
			//var i=inputStr.length;
			var oneChar = inputStr.substring(i, i+1);
			if (oneChar < "0" || oneChar > "9") {
				alert("��سҡ�͡����Ţ��ҹ��");	
				return false;
			}
		}
				return true;
	}
	function check_post() {
		inputStr = gE("post").value;
		if (isNumber(inputStr)) {
			//done
		} else {
			gE("name").focus();
			gE("name").select();
			gE("post").focus();
			gE("post").select();
		}
	}
	function check_email() {
		var inputStr=gE("email").value;
		for (var i = 0; i < inputStr.length; i++) {
			//var i=inputStr.length;
			var oneChar = inputStr.substring(i, i+1);
			if (oneChar=="@") {	
				return true;
			}
		}
				return false;
	}
	function check_alldata(list){	
		if(gE("name").value==""){
			alert('��سҡ�͡���ͼ�����͹');
		}
		else if(gE("address").value==""){
			alert('��سҡ�͡������������͹');
		}
		else if(gE("email").value!=""){
			if(!check_email()){
			alert("�����ŷ���͡����� Email");	
			}
			else{
				if(list==2){
				var result=confirm('�׹�ѹ��û�Ѻ��ا������ ?');
				if(result){		
					form2.submit();
				}								
				}
				else 
				{
					form1.submit();
				}
			}
		}
		else{
			if(list==2){
				var result=confirm('�׹�ѹ��û�Ѻ��ا������ ?');
				if(result){		
					form2.submit();
				}								
			}
			else 
			{
				form1.submit();
			}
		}
	}
//-------------------------------------------
function send_to_iframe(list){	
		parent.iframe5.location.href("iframe5.php?add_new_id="+list+"&&add_new=1" );		
}
function send_to_iframe6(list){	
		parent.iframe6.location.href("iframe6.php?id="+list);	
}
function add_user(){	
		location.href("supplier.php?supplier_id="+null);		
}
function delete_user(list){
	if(list==1){
		alert('�������öź���Ѵ��˹��µ�駵���!')
	}
	else{
	var result=confirm('�س��ͧ���ź '+list+' �͡�ҡ�ҹ������������� ?');
			if(result){		
				location.href("supplier.php?delete_user="+list);	
			}	
	}
}
function delete_complete(list){
			alert('���ź����������ó�');
			send_to_iframe(list);
	}
function update_complete(){
			alert('��û�Ѻ��ا����������ó�');
	}
function notsame(r1,r2,r3,r4,r5){
		alert('���ͼ���˹��«�ӡѹ');
		gE("address").value=r1;
		gE("post").value=r2;
		gE("tel1").value=r3;
		gE("tel2").value=r4;
		gE("email").value=r5;
		gE("name").focus();

	}
function notsame2(r1,r2,r3,r4,r5,r6){
		alert('���ͼ���˹��«�ӡѹ');
		gE("address").value=r2;
		gE("post").value=r3;
		gE("tel1").value=r4;
		gE("tel2").value=r4;
		gE("email").value=r6;
		gE("name").value=r1;
		gE("name").focus();

	}
//-----------------------------------------------------
function logout() {
	location.href("menu.php?back=1");
}
</script>
</head>

<?php
include("fn_mysql.php");
//------------------------------------add status page--------------------------------
	$user=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","supplier","status","1");
		if(!$find){ 
		update_2record("login","username",$user,"status","1","page","supplier");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user,"status","1","login_date",$date);
		update_2record("login","username",$user,"status","1","login_time",$login_time);
	}
//------------------------------------------------------------------------------------------
//--------------------------Recive other variable---------------------------
$supplier_id=$HTTP_GET_VARS[id];
$supplier_id_form2=$HTTP_POST_VARS[form2_send_id];
if($supplier_id!=null){
	?><body onload="send_to_iframe(<?echo $supplier_id;?>),send_to_iframe6(<?echo $supplier_id;?>),init();"></body><?
}
$form1or2=$HTTP_POST_VARS[form1or2];
//--------------------------Add new supplier--------------------------------
$name=$HTTP_POST_VARS[name];
$address=$HTTP_POST_VARS[address];
$post=$HTTP_POST_VARS[post];
$tel1=$HTTP_POST_VARS[tel1];
$tel2=$HTTP_POST_VARS[tel2];
$email=$HTTP_POST_VARS[email];
if($address!=null){ 
	$bool1=find_record("supplier","supplier_name",$name);
	if($form1or2==1){
			if(!$bool1){
					insert_to_supplier($name,$address,$post,$tel1,$tel2,$email);
					$result=select_record_max("supplier","supplier_id");
					$supplier_id=mysql_result($result,0,"max(supplier_id)");
			}
			else{
					?><body onload="notsame('<?echo $address;?>','<?echo $post;?>','<?echo $tel1;?>','<?echo $tel2;?>','<?echo $email;?>');,init();"></body><?
			}
	}
	else if($form1or2==2){
		    $result=select_record("supplier","supplier_id",$supplier_id_form2);
			$name2=mysql_result($result,0,"supplier_name");	
			$bool2=find_record("supplier","supplier_name",$name);
			if($name2==$name){$bool2=0;}
			if(!$bool2){			
					update_to_supplier($supplier_id_form2,$name,$address,$post,$tel1,$tel2,$email);
				   if($supplier_id_form2!=null){
						$supplier_id=$supplier_id_form2;
						?><body onload="send_to_iframe(<?echo $supplier_id;?>),send_to_iframe6(<?echo $supplier_id;?>),init();"></body><?
					}
			}
			else{		
					 if($supplier_id_form2!=null){
						$supplier_id=$supplier_id_form2;
					 }
					?><body onload="notsame2('<?echo $name2;?>','<?echo $address;?>','<?echo $post;?>','<?echo $tel1;?>','<?echo $tel2;?>','<?echo $email;?>'),send_to_iframe6(<?echo $supplier_id_form2;?>),send_to_iframe(<?echo $supplier_id_form2;?>),init();"></body><?
			}
	}
}
//------------------------------Delete user-----------------------------------
$delete_user=$HTTP_GET_VARS[delete_user];
if($delete_user!=null){
	delete_record("supplier","supplier_id",$delete_user);
	$result=select_record_max("supplier","supplier_id");
	$supplier_id=mysql_result($result,0,"max(supplier_id)");
	?><body onload="delete_complete(<?echo $supplier_id;?>),send_to_iframe6(<?echo $supplier_id;?>),init();"></body><?
	
}
//---------------------------------------------------------------------------------
?>
<body scroll="no" bgcolor="#6699CC" onload="init();">
<?php
//----------------------------show old user--------------------------------
if(!$supplier_id){
?>
<center>
<form name="form1" method="post" action="supplier.php">
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">	
	<tr height="40" >
		<td>
		<button onclick="check_alldata();"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>	
		<button ><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>��������˹���</center></button>	
		<button ><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>	
			<input type="hidden" name="form1or2" value="1"/>
		</td>
		<td align="right">
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="100%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>�����ż��Ѵ��˹���</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ͼ��Ѵ��˹��� :
						</td>
						<td>
						<input type="text" name="name" value="" maxlength="45" size="" id="name"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<input type="text" name="address" value="" maxlength="200" size="33" id="address" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<input type="text" name="post" value="" maxlength="16" size="" id="post" onchange="check_post();"/>
						</td>
					</tr>


					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel1" value="" maxlength="16" size="" id="tel1"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel2" value="" maxlength="16" size="" id="tel2" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<input type="text" name="email" value="" maxlength="100" size="" id="email"/>
						</td>
					</tr>
				</table>
			</td>	
			</tr>

			<tr height="50%">
			<td width="50%">
				<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
					<tr height="100%">
					<td >
					<iframe height="100%" width="100%" src="iframe5.php?id=<?echo $supplier_id;?>" name="iframe5" id="iframe5">
					</iframe>
					</td>
					</tr>	
				</table>
			</td>
			</tr>

		</table>
		</td>
			<td width="50%">
				<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
					<tr height="100%">
					<td >
						<iframe height="100%" width="100%" src="iframe6.php" name="iframe6">

						</iframe>
					</td>
					</tr>
				</table>
			</td>
			</tr>
</form>
</table>
</center>
<?}
//-----------------------------------------------form2----------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------
else if($supplier_id){
	$result=select_record("supplier","supplier_id",$supplier_id);
	//mysql_result($result,0,"");
?>
<center>
<form name="form2" method="post" action="supplier.php">
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">
	<tr height="40" >
		<td>
			<button onclick="check_alldata(2);"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>	
			<button onclick="add_user();"><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>��������˹���</center></button>	
			<button onclick="delete_user(<? echo $supplier_id;?>);"><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>	
			<input type="hidden" name="form1or2" value="2"/>
			<input type="hidden" name="form2_send_id" value="<? echo $supplier_id;?>"/>
		</td>
		<td align="right">
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="100%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>�����ż��Ѵ��˹���</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ͼ��Ѵ��˹��� :
						</td>
						<td>
						<input type="text" name="name" value="<?echo mysql_result($result,0,"supplier_name");?>" maxlength="45" size="" id="name"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<input type="text" name="address" value="<?echo mysql_result($result,0,"address");?>" maxlength="200" size="33" id="address" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<input type="text" name="post" value="<?echo mysql_result($result,0,"post");?>" maxlength="16" size="" id="post" onchange="check_post();"/>
						</td>
					</tr>


					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel1" value="<?echo mysql_result($result,0,"tel1");?>" maxlength="16" size="" id="tel1"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel2" value="<?echo mysql_result($result,0,"tel2");?>" maxlength="16" size="" id="tel2" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<input type="text" name="email" value="<?echo mysql_result($result,0,"email");?>" maxlength="100" size="" id="email"/>
						</td>
					</tr>
				</table>
			</td>	
			</tr>


		<tr height="50%">
			<td width="50%">
				<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
					<tr height="100%">
					<td >

					<iframe height="100%" width="100%" src="iframe5.php?id=<?echo $supplier_id;?>" name="iframe5" id="iframe5">
					</iframe>
					</td>
					</tr>	
				</table>
			</td>
			</tr>

		</table>
		</td>
			<td width="50%">
				<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
					<tr height="100%">
					<td >
						<iframe height="100%" width="100%" src="iframe6.php" name="iframe6">

						</iframe>
					</td>
					</tr>
				</table>
			</td>
			</tr>
</form>
</table>
</center>
<?}?>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
