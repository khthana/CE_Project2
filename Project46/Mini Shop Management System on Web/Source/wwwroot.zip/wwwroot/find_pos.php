<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>��͡�����Ť���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		gE('data').focus();
		document.onkeydown= showKeyDown;	
}
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;
		if(i==27)   verifyClose2();
		if(i==13)   check_data();
}
//--------------------------------------------------------------------------
function verifyClose2() {
	window.close();
	var returnFunc = window.dialogArguments
	returnFunc('closed');
}
window.onbeforeunload = verifyClose2

var code;
function check_data(){
	if(gE("data").value==''){
		alert('��سҡ�͡�ӷ��Ф�');
	}
	else{
	code=gE("data").value;
	var returnFunc = window.dialogArguments
	returnFunc(code);
	window.close();
	}
	
}
</SCRIPT>
</HEAD>
<BODY bgcolor="#77bbff"onload="init();">
<form action="" target="_top" name="form2" id="form2" method="post">
<center>
<table border="0" width="106%" height="55%" bgcolor="" cellspacing="1">
						<tr bgcolor="#FFFF99" height="40%">
						<td width="30%">
								<center>�Ӥ���:</center>
						</td>
						<td>	
								<input type="text" name="data" id="data" maxlength="45"/>&nbsp;	
								<button onclick="check_data();">&nbsp;&nbsp;��&nbsp;&nbsp;</button>
								</td>
						</tr>
</table>
</center>		
</form>
</BODY>
</HTML>
