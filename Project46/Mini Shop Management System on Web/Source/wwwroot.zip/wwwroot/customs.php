<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>˹�Ң������١���</title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<script type="text/javascript">
//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
			else if(event.keyCode==113){ find();}	
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
//-------------------------------------------------------------------
function init() {	
		//document.onkeydown= showKeyDown;	
		document.onkeypress = showKeyPress;
		gE("name").focus();
		gE("name").select();
}

function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27){
			var result=confirm('�س��㨷����͡˹�Ң������١���');
				if(result){	
					logout();
				}
		}
}

	function isNumber(inputStr) {
		for (var i = 0; i < inputStr.length; i++) {
			//var i=inputStr.length;
			var oneChar = inputStr.substring(i, i+1);
			if (oneChar < "0" || oneChar > "9") {
				alert("��سҡ�͡����Ţ��ҹ��");	
				return false;
			}
		}
				return true;
	}
	function check_post() {
		inputStr = gE("post").value;
		if (isNumber(inputStr)) {
			//done
		} else {
			gE("name").focus();
			gE("name").select();
			gE("post").focus();
			gE("post").select();
		}
	}
	function check_email() {
		var inputStr=gE("email").value;
		for (var i = 0; i < inputStr.length; i++) {
			//var i=inputStr.length;
			var oneChar = inputStr.substring(i, i+1);
			if (oneChar=="@") {	
				return true;
			}
		}
				return false;
	}
	function check_alldata(list){	
		if(gE("name").value==""){
			alert('��سҡ�͡���ͼ�����͹');
		}
		else if(gE("lastname").value==""){
			alert('��سҡ�͡���ʡ�ż�����͹');
		}
		else if(gE("address").value==""){
			alert('��سҡ�͡������������͹');
		}
		else if(gE("email").value!=""){
			if(!check_email()){
			alert("�����ŷ���͡����� Email");	
			}
			else{
				if(list==2){
				var result=confirm('�׹�ѹ��û�Ѻ��ا������ ?');
				if(result){		
					form2.submit();
				}								
				}
				else 
				{
					form1.submit();
				}
			}
		}
		else{
			if(list==2){
				var result=confirm('�׹�ѹ��û�Ѻ��ا������ ?');
				if(result){		
					form2.submit();
				}								
			}
			else 
			{
				form1.submit();
			}
		}
	}
//-------------------------------------------
function send_to_iframe(list){	
		parent.iframe4.location.href("iframe4.php?add_new_id="+list+"&&add_new=1" );		
}
function add_user(){	
		location.href("customs.php?cust_id="+null);		
}
function delete_user(list){
	var result=confirm('�س��ͧ���ź '+list+' �͡�ҡ�ҹ������������� ?');
			if(result){		
				location.href("customs.php?delete_user="+list);	
			}							
}
function delete_complete(list){
			alert('���ź����������ó�');
			send_to_iframe(list);
	}
function update_complete(list){
			alert('��û�Ѻ��ا����������ó�');
	}
//---------------------------------------Find customs--------------------------------------
var prefsDlog;
function find() {
			
			if (!prefsDlog || prefsDlog.closed) {
			prefsDlog = showModelessDialog("find_customs.php", setPrefs, "dialogWidth:280%; dialogHeight:80%;dialogLeft:386% ; dialogTop:50% ; status=0")
			}
}
var prefsDlog2;
function setPrefs(list){
	if(list!=null && list!='closed'){
		if (!prefsDlog2 || prefsDlog2.closed) {
			prefsDlog2 = showModelessDialog("find_result.php?field="+list[0]+"&&data="+list[1], setPrefs2, "dialogWidth:360%; dialogHeight:220%;dialogLeft:386% ; dialogTop:50% ; status=0")
		}
	}
}
function setPrefs2(list){
	if(list!=null){
			location.href("customs.php?id="+list );
	}
}
//------------------------------------------End find------------------------------------------
function logout() {
	location.href("menu.php?back=1");
}
</script>
</head>
<?php
include("fn_mysql.php");
//------------------------------------add status page-------------------------------------
	$user=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","customer","status","1");
		if(!$find){ 
		update_2record("login","username",$user,"status","1","page","customer");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user,"status","1","login_date",$date);
		update_2record("login","username",$user,"status","1","login_time",$login_time);
	}
//------------------------------------------------------------------------------------------
//--------------------------Recive other variable---------------------------
$cust_id=$HTTP_GET_VARS[id];
$from1or2=$HTTP_POST_VARS[from1or2];
//--------------------------Add new customs--------------------------------
$name=$HTTP_POST_VARS[name];
$lastname=$HTTP_POST_VARS[lastname];
$sex=$HTTP_POST_VARS[sex]; 
$address=$HTTP_POST_VARS[address];
$post=$HTTP_POST_VARS[post];
$tel1=$HTTP_POST_VARS[tel1];
$tel2=$HTTP_POST_VARS[tel2];
$email=$HTTP_POST_VARS[email];
if($address!=null){ 
	if($from1or2==1){
	insert_to_customer($name,$lastname,$sex,$address,$post,$tel1,$tel2,$email);
	$result=select_record_max("customer","cust_id");
	$cust_id=mysql_result($result,0,"max(cust_id)");
	?><body onload="send_to_iframe(<?echo $cust_id;?>);"></body><?
	}
	if($from1or2==2){
	$cust_id=$HTTP_POST_VARS[from2_send_id];
	update_to_customer($cust_id,$name,$lastname,$sex,$address,$post,$tel1,$tel2,$email);	
	}
	?><body onload="update_complete(<?echo $cust_id;?>);"></body><?
}
//------------------------------Delete user-----------------------------------
$delete_user=$HTTP_GET_VARS[delete_user];
if($delete_user!=null){
	delete_record("customer","cust_id",$delete_user);
	$result=select_record_max("customer","cust_id");
	$cust_id=mysql_result($result,0,"max(cust_id)");
	?><body onload="delete_complete(<?echo $cust_id;?>);"></body><?
	
}
//---------------------------------------------------------------------------------
?>
<body scroll="no" bgcolor="#6699CC" onload="init();">
<?php
//----------------------------show old user--------------------------------
if(!$cust_id){
?>
<center>
<form name="form1" method="post" action="customs.php">
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">
	<tr height="40" >
		<td>
	<button onclick="check_alldata();"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>
	<button ><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>�����ء���</center></button>
	<button ><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>
	<button onclick="find();"><center><img src="image/find/find.jpg" height="22"align="left" hspace="0"/>&nbsp;����&nbsp;&nbsp;</center></button>
			<input type="hidden" name="from1or2" value="1"/>			
		</td>
		<td align="right">
			<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="66%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>�������١���</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���� :
						</td>
						<td>
						<input type="text" name="name" value="" maxlength="20" size="" id="name"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ʡ�� :
						</td>
						<td>
						<input type="text" name="lastname" value="" maxlength="20" size="" id="lastname"/>
						</td>
					</tr>
										
					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;�� :
						</td>
						<td>
						���
						<input type="radio"  name="sex" value="man" id="man" checked/>
						˭ԧ
						<input type="radio" name="sex" value="women" id="women"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<input type="text" name="address" value="" maxlength="200" size="33" id="address" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<input type="text" name="post" value="" maxlength="16" size="" id="post" onchange="check_post();"/>
						</td>
					</tr>


					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel1" value="" maxlength="16" size="" id="tel1"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel2" value="" maxlength="16" size="" id="tel2" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<input type="text" name="email" value="" maxlength="100" size="" id="email"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC" height="1">
						<td>
					
						</td>
						<td>
						
						</td>
					</tr>

				</table>
			</td>	
			</tr>

			<!--<tr height="80">
			<td valign="top">
				
			</td>
			</tr>-->

		</table>
</form>
	</td>
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
			<tr height="100%">
			<td >
				<iframe height="100%" width="100%" src="iframe4.php?id=<?echo $cust_id;?>" name="iframe4" id="iframe4">

				</iframe>
			</td>
			</tr>
			
		</table>
	</td>
	</tr>
</table>
</center>
<?}
//-----------------------------------------------from2----------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------
else if($cust_id){
	$result=select_record("customer","cust_id",$cust_id);
	//mysql_result($result,0,"");
?>
<center>
<form name="form2" method="post" action="customs.php">
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">
	<tr height="40" >
		<td>
	<button onclick="check_alldata(2);"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>
	<button onclick="add_user();"><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>�����١��� </center></button>
	<button onclick="delete_user(<? echo $cust_id;?>);"><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>
	<button onclick="find();"><center><img src="image/find/find.jpg" height="22"align="left" hspace="0"/>&nbsp;����&nbsp;&nbsp;</center></button>

			<input type="hidden" name="from1or2" value="2"/>
			<input type="hidden" name="from2_send_id" value="<? echo $cust_id;?>"/>
		</td>
		<td align="right">
			<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="66%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>�������١���</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���� :
						</td>
						<td>
						<input type="text" name="name" value="<?echo mysql_result($result,0,"name");?>" maxlength="20" size="" id="name"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ʡ�� :
						</td>
						<td>
						<input type="text" name="lastname" value="<?echo mysql_result($result,0,"lastname");?>" maxlength="20" size="" id="lastname"/>
						</td>
					</tr>									
					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;�� :
						</td>
						<td>
						���
						<?$data=mysql_result($result,0,"sex")?>
						<input type="radio"  name="sex" value="man" id="man" <?if($data=="man"){echo "checked";}?>/>
						˭ԧ
						<input type="radio" name="sex" value="women" id="women" <?if($data=="women"){echo "checked";}?>/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<input type="text" name="address" value="<?echo mysql_result($result,0,"address");?>" maxlength="200" size="33" id="address" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<input type="text" name="post" value="<?echo mysql_result($result,0,"post");?>" maxlength="16" size="" id="post" onchange="check_post();"/>
						</td>
					</tr>


					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel1" value="<?echo mysql_result($result,0,"tel1");?>" maxlength="16" size="" id="tel1"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel2" value="<?echo mysql_result($result,0,"tel2");?>" maxlength="16" size="" id="tel2" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<input type="text" name="email" value="<?echo mysql_result($result,0,"email");?>" maxlength="100" size="" id="email"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFFF" height="1">
						<td>
					
						</td>
						<td>
						
						</td>
					</tr>

				</table>
			</td>	
			</tr>

			<!--<tr height="80">
			<td valign="top">
				
			</td>
			</tr>-->

		</table>
</form>
	</td>
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
			<tr height="50%">
			<td >
				<iframe height="100%" width="100%" src="iframe4.php?id=<?echo $cust_id;?>" name="iframe4" id="iframe4">

				</iframe>
			</td>
			</tr>

			
		</table>
	</td>
	</tr>
</table>
</center>
<?}?>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
