<?php
$enc=$HTTP_GET_VARS[index1];
$log=$HTTP_POST_VARS[check_log];
if($enc==65414514156416242151543113 || session_is_registered("user") || $log==1){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>������� </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<script type="text/javascript">
//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 

//----------------------------------------------------Show day-----------------------------------------------
                       var day,date,month,year,hour,minute,second,today;  //���ҧ�������������ʵ���Ţ�ͧ�ѹ����
                              var dayString=new Array();
                              dayString[0]="�ҷԵ��";dayString[1]="�ѹ���";dayString[2]="�ѧ���";dayString[3]="�ظ";
                              dayString[4]="����ʺ��";dayString[5]="�ء��";dayString[6]="�����";
                              var monthString=new Array();
                              monthString[0]="���Ҥ�"; monthString[1]="����Ҿѹ��"; monthString[2]="�չҤ�"; monthString[3]="����¹";
                              monthString[4]="����Ҥ�"; monthString[5]="�Զع�¹"; monthString[6]="�á�Ҥ�"; monthString[7]="�ԧ�Ҥ�";
                              monthString[8]="�ѹ��¹"; monthString[9]="���Ҥ�"; monthString[10]="��Ȩԡ�¹"; monthString[11]="�ѹ�Ҥ�";      
                     //����ŧ�����Ǩ�ͺ�Թ�硫�����������˹��¤����Ӣͧ�к��ҡ��� ����¹���������鹡��ҡ�������͹� if ���� case
                      var DateTime;
                      function Now() 
                         {    DateTime=new Date(); //���ҧ�ѵ�� (object) �Դ��͡Ѻ�ѹ���Ңͧ�к���Ժѵԡ�� (OS)
                              day=DateTime.getDay(); 
                              date=DateTime.getDate(); 
                              month=DateTime.getMonth();
                              year=DateTime.getYear();
                              hour=DateTime.getHours();
                              minute=DateTime.getMinutes();
                              second=DateTime.getSeconds();    
                         today=dayString[day]+" "+date+" "+monthString[month]+" "+(year+543);
							 var today2=hour+":"+minute+":"+second;
                             document.title=today; //�ʴ��͡�ҧ����ź���
                             window.status=today;//�ʴ��͡�ҧᶺʶҹ�
                            gE("FNT2").innerText=today2; gE("FNT").innerText=today;//�ʴ��͡�ҧ���ྨ�ç���˹� ID=TXT ੾�� IE
                             setTimeout("Now()",1*1000); //��˹�����Ѿഷ���ҷء 1 �Թҷ�
                         }                
//--------------------------------------Closed window-------------------------------------------
function close_win(){
	var result=confirm('�͡�ҡ�к���ѡ ?');
	if(result){	
	self.close();
	}
}
function init(){
	Now();	
	document.getElementById("u11").background  ="tab.jpg";
	document.getElementById("u12").background  ="tab.jpg";
	document.getElementById("u21").background  ="";
	document.getElementById("u22").background  ="";
	gE("user").focus()
}
//--------------------------------------------Effect menu--------------------------------------
function over_user() {
		document.getElementById("u11").background  ="tab.jpg";
		document.getElementById("u12").background  ="tab.jpg";
		document.getElementById("u21").background  ="";
		document.getElementById("u22").background  ="";
    }
function over_pass() {
		document.getElementById("u21").background  ="tab.jpg";
		document.getElementById("u22").background  ="tab.jpg";
		document.getElementById("u11").background  ="";
		document.getElementById("u12").background  ="";
    }
function link_menu(list) {
			//setTimeout("",20*60);
			location.href("menu.php?pass="+list);
		}
</script>
</head>
<!--************************************Check password*************************************************--->
<!---------------------- ˹�ҵ�Ǩ�ͺ ���ʼ�ҹ post form "login.html"-------------------------->
<?php
		include("fn_mysql.php");
		$send=$HTTP_POST_VARS[send];
		$back=$HTTP_GET_VARS[back];
if($send!=null || $back!=null){	
		$user=$HTTP_POST_VARS[user];
		$pass=$HTTP_POST_VARS[pass];
		$changepass=$HTTP_POST_VARS[changepass];
		$user2=$HTTP_SESSION_VARS["user"];
		$logout=0;
		$link=0;
		$notcorrect=0;
		//-------------------------------------------Catch session-----------------------------------------------------
		$count_repass=$HTTP_POST_VARS[count_repass];
		$bool=compare("employee","username",$user,"password",md5($pass));//function 		
			if($bool && $count_repass==2){	
				$result=select_record_2where("login","username",$user,"status","1");					
				$s_id=mysql_result($result,0,"session_number");
				//-------------------------Change user operation----------------
				$file="C:/PHP/sessiondata/sess_".$s_id;
				$filenum=fopen($file, "w");
				fwrite($filenum,"catch|s:5:\"catch\";");
				fclose($filenum);
				update_2record("login","username",$user,"status","1","logout_date","catch");
				update_2record("login","username",$user,"status","1","logout_time","catch");
				update_2record("login","username",$user,"status","1","session_number","");
				update_2record("login","username",$user,"status","1","status","0");				
			}		
	//-------------------------------------------record logout time------------------------------------------------------
			if($back!=null){
				$user=$user2; 		
				$logout=1;		
				$result=getdate();
				$year=$result["year"]+543;
				$date=$result["mday"]."/".$result["mon"]."/".$year;
				$logout_time=$result["hours"].":".$result["minutes"];
				update_2record("login","username",$user,"status","1","logout_date",$date);
				update_2record("login","username",$user,"status","1","logout_time",$logout_time);
				update_2record("login","username",$user,"status","1","session_number","");
				update_2record("login","username",$user,"status","1","status","0");			
			}
	        //-----------------------------------------------check user login-----------------------------------
			$find=find_2record("login","username",$user,"status","1");
			if($find){ $check_s=1; }
			$bool=compare("employee","username",$user,"password",md5($pass));//function 				
				if($bool && $check_s==0 && $logout!=1){
					session_register("user");
					//---------------------------add login table------------------------
					$result=getdate();
					$year=$result["year"]+543;
					$date=$result["mday"]."/".$result["mon"]."/".$year;
					$login_time=$result["hours"].":".$result["minutes"];
					insert_to_login("login",$user,$date,$login_time,"","","","1",session_id());
					//-----------------------------------------------------------------------
					if($changepass=="done"){
						require("changepass.php");
						$link=1;
					}
					else{										
						require("menu.php");
						$link=1;
					}
				}
				else if(!$bool && $logout!=1){										
						 $notcorrect=1;	
						 $count_repass="";				
				}
				else if($check_s==1 && $bool){										
						 $notcorrect=2;
				}				
}//end send	
?>
<body onload="init()" scroll="no" background="xp4.jpg" >
<?if($link!=1){
	session_unregister("user");
	session_destroy();
?>
<center>
<form method="post" action="login.php">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"  >
	<tr height="35%"><td>&nbsp;</td></tr>
    <tr>
	<td align="center" background="xp4.jpg">
		<table width="50%" height="20%" border="0" cellspacing="0" cellpadding="0" frame="box" 2rules="none"  style="border-collapse: collapse;">
		<tr width="60%">
		<td>
			&nbsp;
		</td>
		<td >
			&nbsp;
		</td>
		<td >
			&nbsp;
		</td>
		</tr>
		<tr>
		<td rowspan="2" width="48%">
			<?
			if($notcorrect==0){
			?>
			<center>
			<!----------------------------------------Fill left----------------------------------->	
			<font size="+3" color="#FFFF99" ><b>Welcome to</b></font>
			<br />
			 </center>
			 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
             <font size="+2" color="#FFFFFF"><I>Ce-soft </I></font>
			  
			  <?
			  }
			  else{
				  if($notcorrect==1){
				   ?>
				<center>
				<font size="+2"color="#FFFF99" ><b>! �������١��ͧ </b> </font>
				<br />
				</center>
				   <?
				  }
				  else if($notcorrect==2){
				 ?>
				<center>
				<font size="+2"color="#FFFF99" ><b>! �������١��ͧ </b> </font>
				<br />
				<?
					 if($count_repass==null){
						$count_repass++;	
					 }
					 else{ $count_repass++;}				  
				 ?>
				</center>
				   <?
				  }
			  }
			  ?>
			
		</td>
	<!----------------------------------U11-U12---------------------------------->
		<td width="1" id="u11" >
		<img src="image\username\user.gif" width="41" height="42" alt="���ʼ����"/>		
		</td>
		<td onmouseover="over_user()"  id="u12">
			<input type="text" name="user" value="" size="20" maxlength="16" id="user" >	
		</td>
		</tr>

		<tr>
	<!----------------------------------U21-U22---------------------------------->
		<td width="1" id="u21">
			<img src="image\password\pass.gif" width="36" alt="���ʼ�ҹ"/>&nbsp;
		</td>
		<td onmouseover="over_pass()"  id="u22">
			<input type="password" value="" id="pass" name="pass" size="20" maxlength="16" >
		</td>
		</tr>

		<tr>
		<td>
			<center><font ID=FNT size=3 color="#FFFFFF"></font></center>
		</td>
		<td>
			&nbsp;
		</td>
		<td >
			<input type="checkbox" name="changepass" value="done"><font color="#FFFFFF">�������¹���ʼ�ҹ</font>
		</td>
		</tr>

		<tr height="1">
		<td >
			<table>
			<tr>
			<td>
				<img border="0" src="image/close/1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/close/2.gif'" onmouseout="this.src='image/close/1.gif'"
	
		    onclick="close_win();"/>
			</td>
			<td>
				<font ID=FNT2 size=4 color="#FFFFFF"></font>
			</td>
			</tr>
			</table>
		</td>
		<td>
			&nbsp;
		</td>
		<td align="center">	
			<input type="hidden" name="check_log" value="1"/>
			<input type="hidden" name="count_repass" value="<?echo $count_repass;?>"/>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="send" value=" ��ŧ " />		
		</td>
		</tr>
		</table>
	</td>
	</tr>
    <tr height="45%"><td>&nbsp</td></tr>
</table>
</form>
</center>
<?}?>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
