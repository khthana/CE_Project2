<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</HEAD>

<BODY bgcolor="#99CCCC">
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#99CCCC">

</tr height="90%">
<tr  height="1" bgcolor="#9999CC">

<td>
	<center><font color="#FFFFFF">�����Թ���</font></center>
</td>
<td>
	<center><font color="#FFFFFF">�����Թ���</font></center>
</td>
</tr >

<?
	include("fn_mysql.php");
	connect_mysql("db_admin");//function
	$supplier_id=$HTTP_GET_VARS[id];
if($supplier_id!=null){
	$sql="SELECT * FROM goods WHERE supplier_id=$supplier_id;";
	$result=mysql_query($sql);
while($dbarr=mysql_fetch_array($result)){?>
<tr  height="1" bgcolor="#FFFFFF">
<td>
	<center><? echo $dbarr["goods_id"];?></center>
</td>
<td>
	<center><? echo $dbarr["goods_name"];?></center>
</td>
</tr >
<?}
}?>
<tr >
<td>

</td>
<td>
	
</td>
<td>
	
</td>
</tr >



</table>
</BODY>
</HTML>
