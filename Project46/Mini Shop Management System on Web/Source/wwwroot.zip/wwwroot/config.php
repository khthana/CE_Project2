<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>����������Թ���</TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init(list) {	
		gE('ok').disabled= true;
		gE('cancle').disabled= true;
		if(list){
		gE('edit2').disabled= false;
		}
		else{gE('edit2').disabled= true;
		}
		gE('addpoint1').disabled= true;
		gE('discount1').disabled= true;
		gE('pro_enable').disabled= true;
		gE('pro_point').disabled= true;
		gE('alot_auto').disabled= true;
		gE('expire_auto').disabled= true;
		gE('alert').disabled= true;
		gE('F8').disabled= true;
		gE('F9').disabled= true;
		gE('F10').disabled= true;
		gE('F11').disabled= true;
		gE('F12').disabled= true;
		gE('shop_name').disabled= true;
		gE('ufile').disabled= true;
		document.onkeypress = showKeyPress;
}

function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27){
			var result=confirm('�س��㨷����͡˹�ҡ�˹����');
				if(result){	
					logout();
				}
		}
}

function logout() {
	location.href("menu.php?back=1");
}

function edit() {		
		gE('ok').disabled= false;
		gE('cancle').disabled= false;
		gE('edit2').disabled= true;
		gE('addpoint1').disabled= false;
		gE('discount1').disabled= false;
		gE('pro_enable').disabled= false;
		gE('pro_point').disabled= false;
		gE('alot_auto').disabled= false;
		gE('expire_auto').disabled= false;
		gE('alert').disabled= false;
		gE('F8').disabled= false;
		gE('F9').disabled= false;
		gE('F10').disabled= false;
		gE('F11').disabled= false;
		gE('F12').disabled= false;
		gE('shop_name').disabled= false;
		gE('ufile').disabled= false;
		
}

function check_num(list) {
	inputStr = list;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}

function send(){
		if(gE('discount1').value<0 || gE('discount1').value>99){
			alert('��سҡ�͡ 0 - 99 %');
		}
		else if(!check_num(gE('discount1').value)){
			alert("��سҡ�͡��ǹŴ��Ҫԡ�繵���Ţ��ҹ��");	
			gE('addpoint1').select();
			gE('addpoint1').focus();
			gE('discount1').select();
			gE('discount1').focus();
		}
		else if(!check_num(gE('addpoint1').value)){
			alert("��سҡ�͡��ǹŴ��Ҫԡ�繵���Ţ��ҹ��");	
			gE('discount1').select();
			gE('discount1').focus();
			gE('addpoint1').select();
			gE('addpoint1').focus();
		}
		else if(!check_num(gE('alert').value)){
			alert("��سҡ�͡�ӹǹ����͹�Թ����������繵���Ţ��ҹ��");	
			gE('discount1').select();
			gE('discount1').focus();
			gE('alert').select();
			gE('alert').focus();
		}
		else if(!check_num(gE('pro_point').value)){
			alert("��سҡ�͡�ӹǹ����͹�Թ����������繵���Ţ��ҹ��");	
			gE('discount1').select();
			gE('discount1').focus();
			gE('pro_point').select();
			gE('pro_point').focus();
		}
		else{
		document.form1.submit();
		}
}
</SCRIPT>
</HEAD>
<?php
	//------------------------------------add status page----------------------------------------
	$edit1=$HTTP_POST_VARS["edit1"];
	$user=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","config","status","1");
		if(!$find){ 
		update_2record("login","username",$user,"status","1","page","config");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user,"status","1","login_date",$date);
		update_2record("login","username",$user,"status","1","login_time",$login_time);
	}
	//---------------------------------------Update config---------------------------------------
	if($edit1==1){
		$dis=$HTTP_POST_VARS["discount1"];
		$add=$HTTP_POST_VARS["addpoint1"];
		$pro_enable=$HTTP_POST_VARS["pro_enable"];
		$pro_point=$HTTP_POST_VARS["pro_point"];
		$alot_auto=$HTTP_POST_VARS["alot_auto"];
		$expire_auto=$HTTP_POST_VARS["expire_auto"];
		$shop_name=$HTTP_POST_VARS["shop_name"];
		if($dis==""){$dis=0;}
		if($add==""){$add=100;}
		if($pro_point==""){$pro_point=100;}		
		$F8_R=$HTTP_POST_VARS["F8"];
		$F9_R=$HTTP_POST_VARS["F9"];
		$F10_R=$HTTP_POST_VARS["F10"];
		$F11_R=$HTTP_POST_VARS["F11"];
		$F12_R=$HTTP_POST_VARS["F12"];
		$alert=$HTTP_POST_VARS["alert"];

		$filename=$HTTP_POST_FILES['ufile']['name'];
		$path=$HTTP_POST_FILES['ufile']['tmp_name'];
			if($filename!=""){//--------------��Ǩ�ͺ������͡����ѧ		
					$filename=strtolower($filename);
					if(strstr($filename,".gif")){
						$fp=fopen($path, "r");
						$data=fread($fp, filesize($path));
						fclose($fp);
						//unlink("logo.gif");
						//unlink("logo.jpg");
						$path="logo.gif";		
						setconfig("config","14:logotype","gif");
						$fp=fopen($path, "w");
						fwrite($fp,$data);
						fclose($fp);
					}
					else if(strstr($filename,".jpg")){
						$fp=fopen($path, "r");
						$data=fread($fp, filesize($path));
						fclose($fp);
						//unlink("logo.gif");
						//unlink("logo.jpg");
						$path="logo.jpg";		
						setconfig("config","14:logotype","jpg");
						$fp=fopen($path, "w");
						fwrite($fp,$data);
						fclose($fp);
					}
					else {
							echo "<body onload=\"alert('��س����͡�����ʡ�� .jpg .gif ��ҹ��')\";>";
					}			
			}
		if($alert==""){$alert=0;}		
		setconfig("config","1:discount",$dis);
		setconfig("config","2:add_point",$add);
		setconfig("config","3:F8",$F8_R);
		setconfig("config","4:F9",$F9_R);
		setconfig("config","5:F10",$F10_R);
		setconfig("config","6:F11",$F11_R);
		setconfig("config","7:F12",$F12_R);
		setconfig("config","8:alert",$alert);
		setconfig("config","9:alot_auto",$alot_auto);
		setconfig("config","10:expire_auto",$expire_auto);
		setconfig("config","11:pro_enable",$pro_enable);
		setconfig("config","12:pro_point",$pro_point);
		setconfig("config","13:shop_name",$shop_name);
	}
	//---------------------------------------Get config--------------------------------------------
	$discount1=getconfig("config","1:discount");
	$addpoint1=getconfig("config","2:add_point");
	$F8=getconfig("config","3:F8");
	$F9=getconfig("config","4:F9");
	$F10=getconfig("config","5:F10");
	$F11=getconfig("config","6:F11");
	$F12=getconfig("config","7:F12");
	$alert=getconfig("config","8:alert");
	$alot_auto=getconfig("config","9:alot_auto");
	$expire_auto=getconfig("config","10:expire_auto");
	$pro_enable=getconfig("config","11:pro_enable");
	$pro_point=getconfig("config","12:pro_point");
	$shop_name=getconfig("config","13:shop_name");
	$type=getconfig("config","14:logotype");
	//------------------------------------Check position-----------------------------------------
	$find=find_record("employee","username",$user);
	if($find){
		$result=select_record("employee","username",$user);
		$pos=mysql_result($result,0,"position");
		if($pos{4}==1 || $pos{5}==1) $check=1;
		else $check=0;
	}

?>
<BODY  background="image\bg_pos\bg.jpg" onload="init(<?echo $check;?>);" scroll="no" >
<center>
<!-------------------------------------------------------Edit page--------------------------------------------------------------->
<form action="config.php" method="post" name="form1" enctype="multipart/form-data">
<input type="hidden" name="edit1" value="1"/>
<table border="0" width="60%" height="1" bgcolor="" cellspacing="1" >
	<tr>
	    <td>
			<button onclick="send();" id="ok"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;&nbsp;</center></button>
			<button onclick="init(1);" id="cancle"><center><img src="image\delete\delete.gif"height="22"align="left" hspace="0"/>&nbsp;¡��ԡ&nbsp;</center></button>
			<button id="edit2" onclick="edit();" <? if(!$check)echo "disabled";?>><center><img src="image\edit\edit2.gif" height="22"align="left" hspace="0"/>&nbsp;���&nbsp;&nbsp;</center></button>
		</td>
		<td align="right">
			<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr>
		<td colspan="2">	
					
				<fieldset>
					<legend>
						<center><font color="#FFFFFF"><b>��˹���ǹŴ</b></font></center>
					</legend>
						<br />		
						&nbsp;&nbsp;������ҹ: <input type="text" value="<?echo $shop_name;?>" name="shop_name" maxlength="20" size="20"/>
						&nbsp;&nbsp;���� <input type="file"  name="ufile" maxlength="20" size="20"/>
						<img src="<?echo "logo.".$type;?>" width="45" height="45"/>
						<br /><br />	
				</fieldset>

				<fieldset>
					<legend>
						<center><font color="#FFFFFF"><b>��˹���ǹŴ</b></font></center>
					</legend>
						<br />		
						&nbsp;&nbsp;&nbsp;��ǹŴ��Ҫԡ&nbsp;<input type="text" value="<?echo $discount1;?>" name="discount1" maxlength="2" size="5" id="discount1"/> ������
						&nbsp;&nbsp;&nbsp;���� 1 ��ṹ����ͫ��ͤú&nbsp;<input type="text" value="<?echo $addpoint1;?>" id="addpoint1"  name="addpoint1" maxlength="5" size="10" /> �ҷ
						<br /><br />		
						&nbsp;&nbsp;<input type="checkbox" id="pro_enable" name="pro_enable" <?if($pro_enable){echo "checked";}?>/> ��������������������ṹ�ú <input type="text" value="<?echo $pro_point;?>" name="pro_point" maxlength="5" size="10"/> ��ṹ<br /><br />	
				</fieldset>
				
				<fieldset>
					<legend>
						<center><font color="#FFFFFF"><b>��˹���Ҩӹǹ����͹</b></font></center>
					</legend>
						<br />
						&nbsp;&nbsp;&nbsp;����͹������Թ������������&nbsp;<input type="text" value="<?echo $alert;?>"  maxlength="5" size="10" name="alert" id="alert"/> ˹���
						<br /><br />
						&nbsp;&nbsp;<input type="checkbox" name="alot_auto" id="alot_auto" <?if($alot_auto){echo "checked";}?>/> ����͹�Թ����������ѵ��ѵ�
						&nbsp;&nbsp;<input type="checkbox" name="expire_auto" id="expire_auto" <?if($expire_auto){echo "checked";}?>/> ����͹�Թ�����������ѵ��ѵ�
						<br /><br />
				</fieldset>

				<fieldset>
					<legend>
						<center><font color="#FFFFFF"><b>��˹����͡�����Թ�����觴�ǹ</b></font></center>
					</legend>
						<br />
						
						<table  border="0">
							<tr>
								<td>&nbsp;&nbsp;F8</td>
								<td><input type="text" value="<?echo $F8;?>"  maxlength="20"  name="F8"/></td>
								<td>&nbsp;&nbsp;F11</td>
								<td><input type="text" value="<?echo $F11;?>"  maxlength="20"  name="F11"/></td>
							</tr>
							<tr>
								<td>&nbsp;&nbsp;F9</td>
								<td><input type="text" value="<?echo $F9;?>"  maxlength="20"  name="F9"></td>
								<td>&nbsp;&nbsp;F12</td>
								<td><input type="text" value="<?echo $F12;?>"  maxlength="20"  name="F12"/></td>
							</tr>
							<tr>
								<td>&nbsp;&nbsp;F10</td>
								<td><input type="text" value="<?echo $F10;?>"  maxlength="20" name="F10" /></td>					
							</tr>
						</table>
						
						<br />
				</fieldset>

		</td>
	</tr>

	<tr>
		<td align="center">
			
		</td>
	</tr>
</table>
</form>
</center>		
</BODY>
</HTML>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
