<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>˹����§ҹ������</title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<STYLE TYPE="text/css">
TD, TH {text-align:center}
</STYLE>
<script type="text/javascript">
//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
/*******************
  UTILITY FUNCTIONS
********************/
// day of week of month's first day
function getFirstDay(theYear, theMonth){
	var firstDate = new Date(theYear,theMonth,1)
	return firstDate.getDay()
}
// number of days in the month
function getMonthLen(theYear, theMonth) {
	var oneDay = 1000 * 60 * 60 * 24
	var thisMonth = new Date(theYear, theMonth, 1)
	var nextMonth = new Date(theYear, theMonth + 1, 1)
	var len = Math.ceil((nextMonth.getTime() - 
		thisMonth.getTime())/oneDay)
	return len
}
// create array of English month names
var theMonths = ["���Ҥ�","����Ҿѹ��","�չҤ�","����¹","����Ҥ�","�Զع�¹","�ѹ��¹","�ԧ�Ҥ�",
"��Ȩԡ�¹","���Ҥ�","��Ȩԡ�¹","�ѹ�Ҥ�"]
// return IE4+ or W3C DOM reference for an ID
function getObject(obj) {
	var theObj
	if (document.all) {
		if (typeof obj == "string") {
			return document.all(obj)
		} else {
			return obj.style
		}
	}
	if (document.getElementById) {
		if (typeof obj == "string") {
			return document.getElementById(obj)
		} else {
			return obj.style
		}
	}
	return null
}
function init(list){
if(list==2){
	tab1();
	populateTable() 
}
document.onkeypress = showKeyPress;
}

function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27){
			var result=confirm('�س��㨷����͡˹����§ҹ');
				if(result){	
					logout();
				}
	}
	else if(i==13){
		var send_q=gE("check_q").value;
		
		if(send_q==2){
			send2();
		}
		else if(send_q==3){
			send2();
		}
		else if(send_q==4){
			send2();
		}
		else if(send_q==5){
			send2();
		}
		else if(send_q==6){
			send3();
		}
		else if(send_q==7){
			send4();
		}
		else if(send_q==8){
			send5();
		}
		else if(send_q==1){
			send();
		}
	}
}
/************************
  DRAW CALENDAR CONTENTS
*************************/
// clear and re-populate table based on form's selections

function populateTable() {
	var theMonth = parseInt(gE("month").value);
	var theYear = gE("year").value-543;
	// initialize date-dependent variables
	var firstDay = getFirstDay(theYear, theMonth)
	var howMany = getMonthLen(theYear, theMonth)
	attr[1]=theMonth;
	attr[2]=theYear+543;
	// initialize vars for table creation
	var dayCounter = 1
	var TBody = getObject("tableBody")
	// clear any existing rows
	while (TBody.rows.length > 0) {
		TBody.deleteRow(0)
	}
	var newR, newC
	var done=false
	while (!done) {
		// create new row at end
		newR = TBody.insertRow(TBody.rows.length)
		for (var i = 0; i < 7; i++) {
			// create new cell at end of row
			newC = newR.insertCell(newR.cells.length)
			if (TBody.rows.length == 1 && i < firstDay) {
				// no content for boxes before first day
				newC.innerHTML = ""
				newC.style.backgroundColor = "#FFFF99";
				continue
			}
			if (dayCounter == howMany) {
				// no more rows after this one
				done = true
			}
			// plug in date (or empty for boxes after last day)
			if(dayCounter <= howMany){
			var m=dayCounter++;
			newC.innerHTML = "<center id='id"+m+"' onmouseover='over("+m+");' onmouseout='out("+m+");' ondblclick='tab("+m+");'><b>"+m+"</b></center>";
			}
			else newC.innerHTML = "";
			newC.style.backgroundColor = "#FFFF99";
		}
		
	}
}
function out(list){
		list="id"+list;
		gE(list).style.backgroundColor = "#FFFF99";
}
function over(list){
		list="id"+list;
		gE(list).style.backgroundColor = "#FF6600";
}
var battr=new Array();
var eattr=new Array();
var attr=new Array();
function tab(list){
	if(t==0){
			battr[0]=list;
			battr[1]=attr[1];
			battr[2]=attr[2];
			gE("begin").value = battr[0]+" "+theMonths[battr[1]]+" "+battr[2];
	}
	else if(t==1){
			eattr[0]=list;
			eattr[1]=attr[1];
			eattr[2]=attr[2];
			gE("end").value = eattr[0]+" "+theMonths[eattr[1]]+" "+eattr[2];
	}
	
}
//--------------------------------------Section 2--------------------------------
	 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		} 
var t=0;
function tab1(){
		t=0;
		gE("begin").style.backgroundColor = "#FFFF00";
		gE("end").style.backgroundColor = "#FFFFFF";
}
function tab2(){
		t=1;
		gE("end").style.backgroundColor = "#FFFF00";
		gE("begin").style.backgroundColor = "#FFFFFF";
}
function send(){
	var check=0;
	var bm=battr[1]+1;
	var em=eattr[1]+1;
    if(battr[2]<eattr[2]){	
		check=1;
	}
	else if(battr[2]==eattr[2]){
			if(battr[1]<eattr[1]){	
			check=1;
			}
			else if(battr[1]==eattr[1]){
					if(battr[0]<eattr[0]){	
						check=1;
					}
					else if(battr[0]==eattr[0]){
						check=1;
					}
			}
	}

if(check==1){
//---------------------------------------------
if(gE("begin").value!='' && gE("end").value!=''){	
	var q=gE("question").value;				parent.iframe_business.location.href("iframe_business.php?bday="+battr[0]+"&&bmonth="+bm+"&&byear="+battr[2]+"&&eday="+eattr[0]+"&&emonth="+em+"&eyear="+eattr[2]+"&&q="+q);	
}
else{
alert("�ѧ����͡�ѹ�����§ҹ");
}
//----------------------------------------------
}
else{
alert("�س��͡�ѹ�����§ҹ��͹��ѧ");
}
}//end
//----------------------------------------------send2----------------------------------------
function send2(){
	var order=gE("order").value;
	if(order==null){
		alert("�ѧ����͡�ӹǹ�ӴѺ������§ҹ");		
	}
	else if(!check_num(order)){
		alert("��سҡ�͡����Ţ��ҹ��");	
	}
	else{
		var q=gE("question").value;		
		parent.iframe_business.location.href("iframe_business.php?order="+order+"&&q="+q);
	}
}
function send3(){	
		var q=gE("question").value;		
		parent.iframe_business.location.href("iframe_business.php?q="+q);
}
function check_num(list) {
	inputStr = list;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
function send4(){
	var order=gE("order").value;
	if(order==''){
		alert("�ѧ����͡�Ţ���㺡ӡѺ�Թ���");		
	}
	else if(!check_num(order)){
		alert("��سҡ�͡����Ţ��ҹ��");	
	}
	else{
		var q=gE("question").value;		
		parent.iframe_business.location.href("iframe_business.php?order="+order+"&&q="+q);
	}
}
function send5(){
//---------------------------------------------
	var bm=battr[1]+1;
	if(gE("begin").value!=''){	
		var q=gE("question").value;				parent.iframe_business.location.href("iframe_business.php?bday="+battr[0]+"&&bmonth="+bm+"&&byear="+battr[2]+"&&q="+q);	
	}
	else{
	alert("�ѧ����͡�ѹ�����§ҹ");
	}
}//end
function q_change(){
	var q2=gE("question").value;			
	location.href("business.php?q2="+q2);

}
function print1(){
	iframe_business.print();
}
function logout() {
	location.href("menu.php?back=1");
}
</script>
</head>
<?
include("fn_mysql.php");
//------------------------------------add status page--------------------------------
	$q2=$HTTP_GET_VARS[q2];
	if($q2==null)$q2=1;
	$user=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","mis","status","1");
		if(!$find){ 
		update_2record("login","username",$user,"status","1","page","mis");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user,"status","1","login_date",$date);
		update_2record("login","username",$user,"status","1","login_time",$login_time);
	}
//------------------------------------------------------------------------------------------
?>
<body scroll="no" bgcolor="#6699CC" <? if($q2==1||$q2==8){?>onload="init(2);"<?}else{?>onload="init(1);"<?}?>>
<center>
<input type="hidden" name="check_q" id="check_q" value="<?echo $q2;?>"/>
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC"  bordercolor="#660000" style="border-collapse: collapse;">
	<tr  height="40" >
		<td>
		<div align="left">
			<font color="#FFFFFF"><b>�Ӷ��</b></font>
						<select id="question" onchange="q_change();">
							<option value="1" <?if($q2==1){echo "selected";}?>>�ѭ�ա�â��(����-�Ҵ�ع)</option>
							<option value="2" <?if($q2==2){echo "selected";}?>>�Թ��ҷ������͹��·���ش㹤�ѧ�Թ��� n ��¡��</option>
							<option value="3" <?if($q2==3){echo "selected";}?>>�Թ��ҷ��������ҡ����ش㹤�ѧ�Թ��� n ��¡��</option>
							<option value="4" <?if($q2==4){echo "selected";}?>>�Թ��� n �ӴѺ��´�</option>
							<option value="5" <?if($q2==5){echo "selected";}?>>�Թ��� n �ӴѺ�ʹ���</option>
							<option value="6" <?if($q2==6){echo "selected";}?>>�Թ��ҷ������������</option>
							<option value="7" <?if($q2==7){echo "selected";}?>>�â���Թ��Ҫ�鹹��</option>	
							<option value="8" <?if($q2==8){echo "selected";}?>>��Ǩ�ͺ���������к�</option>
						</select>
			<div>
		</td>
		<td align="right">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'"  onclick="logout();" /> 
		</td>
	</tr>
	<tr height="95%" >
	<td width="50%">
		<table width="100%" height="40%" border="2" cellspacing="0" cellpadding="1"   frame="box" rules="cols">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>��͡������</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
	 <table width="100%" height="100%" border="1" cellspacing="0" cellpadding="0"bgcolor="#99CCCC" bordercolor="#6699CC" frame="void" rules="rows" style="border-collapse: collapse;">
					<tr bgcolor="#FFFFCC" height="30">
						<td align="center">
						
						</td>
						<td>
							
						</td>
					</tr>
					
<?if($q2==2){?>
<!--------------------------------------------22222222222222222222222-------------------------------------------->
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  bordercolor="#FFFFFF" style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�Թ��ҷ������͹��·���ش <input type="text" size="4" maxlength="3" name="order" id=order/> ��¡��</font>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send2();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==3){?>
<!--------------------------------------------3333333333333333333333333------------------------------------------>
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  bordercolor="#FFFFFF" style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�Թ��ҷ��������ҡ����ش <input type="text" size="4" maxlength="3" name="order" id=order/> ��¡��</font> 
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send2();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==4){?>
<!--------------------------------------------444444444444444444444444------------------------------------------>
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�ӹǹ�ӴѺ����ͧ���</font> <input type="text" size="4" maxlength="3" name="order" id=order/>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send2();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==5){?>
<!--------------------------------------------555555555555555555555555------------------------------------------>
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�ӹǹ�ӴѺ����ͧ���</font> <input type="text" size="4" maxlength="3" name="order" id=order/>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send2();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==6){?>
<!--------------------------------------------66666666666666666666666------------------------------------------>
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�ʴ���¡�÷�����</font>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send3();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==7){?>
<!--------------------------------------------77777777777777777777777------------------------------------------>
		<tr height="80%">
		<td width="100%">
		<table BORDER=0  style="border-collapse: collapse;" frame="box">
		<tr >
		<td >
		<font color="#6633CC"><b>�Ţ���㺡ӡѺ�Թ���</font> <input type="text" size="10" maxlength="10" name="order" id=order/>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr  height="10%">
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send4();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>			
<?}
else if($q2==8){?>
	<!------------------------------------------8888888888888888888888888------------------------------------>
<tr>
<td>
<TABLE ID="calendarTable" BORDER=1  bordercolor="#6699CC" style="border-collapse: collapse;" frame="rhs">
<TR>
	<TH bgcolor="#FF6600">��.</TH>
	<TH bgcolor="#FFFF00">�.</TH>
	<TH bgcolor="#6699FF">�.</TH>
	<TH bgcolor="#FF66CC">�.</TH>
	<TH bgcolor="#CC00CC">��.</TH>
	<TH bgcolor="#FFCC00">�.</TH>
	<TH bgcolor="#669900">�.</TH>
</TR>
<TBODY ID="tableBody"></TBODY>
<TR>
	<TD COLSPAN=7 bgcolor="#00CCCC">
	<P>
	<?
		$result=getdate();
		$year=$result["year"];
		$year=$year+543;
		//$date=$result["mday"];
		$month=$result["mon"];
	?>
	<FORM NAME="dateChooser">
		<SELECT NAME="chooseMonth"  id="month"
		onChange="populateTable()">
			<option value="0" <?if($month==1)echo "selected";?>>���Ҥ�</option>
			<option value="1" <?if($month==2)echo "selected";?>>����Ҿѹ��</option>
			<option value="2" <?if($month==3)echo "selected";?>>�չҤ�</option>
			<option value="3" <?if($month==4)echo "selected";?>>����¹</option>
			<option value="4" <?if($month==5)echo "selected";?>>����Ҥ�</option>
			<option value="5" <?if($month==6)echo "selected";?>>�Զع�¹</option>
			<option value="6" <?if($month==7)echo "selected";?>>�á�Ҥ�</option>
			<option value="7" <?if($month==8)echo "selected";?>>�ԧ�Ҥ�</option>
			<option  value="8" <?if($month==9)echo "selected";?>>�ѹ��¹</option>
			<option value="9" <?if($month==10)echo "selected";?>>���Ҥ�</option>
			<option value="10" <?if($month==11)echo "selected";?>>��Ȩԡ�¹</option>
			<option value="11" <?if($month==12)echo "selected";?>>�ѹ�Ҥ�</option>		
	</SELECT>
	<select name="chooseYear" id="year" onChange="populateTable()">
			
			<option value="<?echo $year;?>"> <?echo $year;?></option>
			<option value="<?echo $year+1;?>" ><?echo $year+1;?></option>
			<option value="<?echo $year+2;?>" ><?echo $year+2;?></option>
			<option value="<?echo $year+3;?>" ><?echo $year+3;?></option>
	</select>
	</FORM>
	</P></TD>
</TR>
</TABLE>
</td>
		<td width="100%">
		<table BORDER=0 bordercolor="#FFFFFF" style="border-collapse: collapse;" frame="box">
		<tr >
		<td width="400" onclick="tab1();">
		�ѹ���: <input type="text" id="begin" readonly/>
		<input type="hidden" id="end" />
		</td>
		</tr>
		<tr>
		<td width="400" >
				
			</td>
		</table>
	</td>
	</tr>

	<tr >
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send5();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>					
<?}
else if($q2==1){?>
	<!------------------------------------------11111111111111111111111111------------------------------------>
<tr>
<td>
<TABLE ID="calendarTable" BORDER=1  bordercolor="#6699CC" style="border-collapse: collapse;" frame="rhs">
<TR>
	<TH bgcolor="#FF6600">��.</TH>
	<TH bgcolor="#FFFF00">�.</TH>
	<TH bgcolor="#6699FF">�.</TH>
	<TH bgcolor="#FF66CC">�.</TH>
	<TH bgcolor="#CC00CC">��.</TH>
	<TH bgcolor="#FFCC00">�.</TH>
	<TH bgcolor="#669900">�.</TH>
</TR>
<TBODY ID="tableBody"></TBODY>
<TR>
	<TD COLSPAN=7 bgcolor="#00CCCC">
	<P>
	<?
		$result=getdate();
		$year=$result["year"];
		$year=$year+543;
		//$date=$result["mday"];
		$month=$result["mon"];
	?>
	<FORM NAME="dateChooser">
		<SELECT NAME="chooseMonth"  id="month"
		onChange="populateTable()">
			<option value="0" <?if($month==1)echo "selected";?>>���Ҥ�</option>
			<option value="1" <?if($month==2)echo "selected";?>>����Ҿѹ��</option>
			<option value="2" <?if($month==3)echo "selected";?>>�չҤ�</option>
			<option value="3" <?if($month==4)echo "selected";?>>����¹</option>
			<option value="4" <?if($month==5)echo "selected";?>>����Ҥ�</option>
			<option value="5" <?if($month==6)echo "selected";?>>�Զع�¹</option>
			<option value="6" <?if($month==7)echo "selected";?>>�á�Ҥ�</option>
			<option value="7" <?if($month==8)echo "selected";?>>�ԧ�Ҥ�</option>
			<option  value="8" <?if($month==9)echo "selected";?>>�ѹ��¹</option>
			<option value="9" <?if($month==10)echo "selected";?>>���Ҥ�</option>
			<option value="10" <?if($month==11)echo "selected";?>>��Ȩԡ�¹</option>
			<option value="11" <?if($month==12)echo "selected";?>>�ѹ�Ҥ�</option>		
	</SELECT>
	<select name="chooseYear" id="year" onChange="populateTable()">
			<option value="<?echo $year;?>"> <?echo $year;?></option>
			<option value="<?echo $year+1;?>" ><?echo $year+1;?></option>
			<option value="<?echo $year+2;?>" ><?echo $year+2;?></option>
			<option value="<?echo $year+3;?>" ><?echo $year+3;?></option>
	</select>
	</FORM>
	</P></TD>
</TR>
</TABLE>
</td>
		<td width="100%">
		<table BORDER=0 bordercolor="#FFFFFF" style="border-collapse: collapse;" frame="box">
		<tr >
		<td width="400" onclick="tab1();">
		�����: <input type="text" id="begin" readonly/>
		</td>
		</tr>
		<tr>
			<td width="400" >
				
			</td>
		</tr>
		<tr >
		<td width="400" onclick="tab2();">
			&nbsp;�֧: <input type="text" id="end" readonly/>
		</td>
		</tr>
		</table>
	</td>
	</tr>

	<tr >
		<td>				
		</td>
		<td >
			<div align="right">
				<button id="send" onclick="send();">&nbsp;��§ҹ&nbsp;</button>
			</div>
		</td>
	</tr>					
	
<!------------------------------------------------------------------------------------------------------->
<?}?>
			</table>
			</td>	
			</tr>
			<!--<tr height="80">
			<td valign="top">
				
			</td>
			</tr>-->

		</table>
	</td>
	<td width="50%" >
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="2">
			<tr height="100%">
			<td >
				<iframe height="100%" width="100%" src="iframe_business.php?q2=<?echo $q2;?>" name="iframe_business" border="2">

				</iframe>
			</td>
			</tr>

			<tr height="50%">
			<td >
				<table width="100%" height="100%" border="0" cellspacing="5" cellpadding="5">
					<tr height="20" >
					<td>
					</td>
					</tr>
				</table>
			</td>
			</tr>
		</table>
	</td>
	</tr>
</table>
</center>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
