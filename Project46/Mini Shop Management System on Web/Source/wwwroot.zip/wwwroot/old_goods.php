<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>  ��͡�ӹǹ�Թ��ҷ������㹤�ѧ�Թ��� &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
function init() {	
		document.onkeypress = showKeyPress;
	}
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27) verifyClose2();
	else if(i==13){
		var x=gE("code2").value;
		main_send(x);
	}
}
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc(goods);
	window.close();
}
function verifyClose2() {
	var returnFunc = window.dialogArguments
	returnFunc("close");
	window.close();
}
window.onbeforeunload = verifyClose2
function isNumber(inputStr,form) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}

function check_sale(form) {
	inputStr = form.sale.value;
	if (isNumber(inputStr,form)) {
		var s=parseInt(gE("sale").value);
		if(s>100){
			alert("��Ңͧ����Ţ��ͧ����Թ 100 ");	
			form.year.focus();
			form.year.select();
			form.sale.focus();
			form.sale.select();
		}
	} else {
		form.year.focus();
		form.year.select();
		form.sale.focus();
		form.sale.select();
	}
}
function check_day(form) {
	inputStr = form.day.value;
	var date_in_month=gE("date_in_month").value;
	if (isNumber(inputStr,form)) {
		var s=parseInt(gE("day").value);
		if(s>date_in_month){
			alert("��Ңͧ�ѹ��ͧ����Թ "+date_in_month);	
			form.year.focus();
			form.year.select();
			form.day.focus();
			form.day.select();
		}
	} else {
		form.year.focus();
		form.year.select();
		form.day.focus();
		form.day.select();
	}
}
function check_month(form) {
	inputStr = form.month.value;
	if (isNumber(inputStr,form)) {
		var s=parseInt(gE("month").value);
		if(s>12){
			alert("��Ңͧ��͹��ͧ����Թ 12 ");	
			form.year.focus();
			form.year.select();
			form.month.focus();
			form.month.select();
		}
	} else {
		form.year.focus();
		form.year.select();
		form.month.focus();
		form.month.select();
	}
}
var DateTime;
function check_year(form) {
	  inputStr = form.year.value;
	  DateTime=new Date();
	  year=DateTime.getYear();
	  year=year+543;
	  var n=year-1;
	  year=year+'';	 
	  var y = year.substring(2,4);

	if (isNumber(inputStr,form)) {
		var s=gE("year").value;
		if(s<y){
			alert("��Ңͧ�յ�ͧ�ҡ���� "+n);	
			form.total_remain.focus();
			form.total_remain.select();
			form.year.focus();
			form.year.select();
		}
	} else {
		form.total_remain.focus();
		form.total_remain.select();
		form.year.focus();
		form.year.select();
	}
}
function check_remain(form) {
	inputStr = form.total_remain.value;
	if (isNumber(inputStr,form)) {
		return true;
	} else {
		form.year.focus();
		form.year.select();
		form.total_remain.focus();
		form.total_remain.select();
		return false;
	}
}
function check_remain2(list) {
	inputStr = list;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
	var goods=new Array();
function main_send(code1){	
	goods[0]=code1;
	goods[1]=gE("total_remain").value;
	goods[2]=gE("day").value;
	goods[3]=gE("month").value;
	goods[4]=gE("year").value;
	var date_in_month=gE("date_in_month").value;

	if(goods[0]==""){
		alert('��سҡ�͡�����Թ��ҡ�͹');
	}
	else if(goods[1]==""){
		alert('��سҡ�͡�ӹǹ�Թ��ҡ�͹');
	}
	else if(goods[1]<1){
		alert('��͡�ӹǹ�Թ����ҡ���� 0');
	}
	else if(!check_remain2(goods[1])){
		
	}
	else if(goods[2]>date_in_month || goods[2]<0){
		alert("�ѹ��� 1 - "+date_in_month);
	}
	else if(!check_remain2(goods[2])){
		
	}
	else if(goods[3]>12 || goods[3]<0){
		alert('��͹ 1 - 12');
	}
	else if(!check_remain2(goods[3])){	
	}
	else{
	var returnFunc = window.dialogArguments
	returnFunc(goods);
	window.close();
	}
}
</SCRIPT>

</HEAD>
<?php
	//--------------------------variable-----------------------------
	$code1=$HTTP_GET_VARS[code1];
	$find=find_record("memexpire","goods_id",$code1);
	if($find){
	$result=select_record("memexpire","goods_id",$code1);
	$mem=mysql_result($result,0,"day");
	$date_in_month=date("t");
	$result=getdate();
	$year=$result["year"]+543;
	$year=substr($year,2,4);
	$month=$result["mon"];
	$day=$result["mday"]+$mem;
		if($day>$date_in_month){
			$day=$day-$date_in_month;		
			if($month==12) $month=1;
			else $month=$month+1;
		}
	
	}
	//echo $code1;
?>
<BODY bgcolor="#EEEEEE" onload="init();">
<form action="_self"  name="main_form" id="main_form" method="post">
<center>
<input type="hidden" value="<?echo $date_in_month;?>" name="date_in_month" id="date_in_month"/>
<table border="0" width="100%">
	   <tr>	
			<td>
			<font color="#6633CC">&nbsp;&nbsp;&nbsp;&nbsp;�Թ���: </font>
			<? $result=select_record("goods","goods_id",$code1);
				 $result=mysql_result($result,0,"goods_name");
				 echo $result;
			?>
			</td>
		</tr>

		<tr>	
			<td>
			<font color="#6633CC">&nbsp;&nbsp;&nbsp;�ӹǹ: </font><input type="text" id="total_remain" name="total_remain" size="16" maxlength="8" onChange="check_remain(this.form);"/>
			</td>
		</tr>

		<tr>
		<td >
			<font color="#6633CC">�������:</font>
			<input type="text" id="day" maxLength="2" size="1" name="day" value="<?echo $day;?>" onChange="check_day(this.form);"/>
			<input type="text" id="month" maxLength="2" size="1" name="month" value="<?echo $month;?>" onChange="check_month(this.form);"/>
			25 <input type="text" id="year" maxLength="2" size="1" name="year" value="<?echo $year;?>" onChange="check_year(this.form);"/>
		</td>
		</tr>

	</table>
	</center>
			<input type="hidden" value="<?echo $code1;?>" name="code2" id="code2"/>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button onclick="main_send(<?echo $code1;?>);">&nbsp;&nbsp;��ŧ&nbsp;&nbsp;</button>&nbsp;
			<button onclick="verifyClose2();">&nbsp;&nbsp;¡��ԡ&nbsp;&nbsp;</button>
</form>
</BODY>
</HTML>
