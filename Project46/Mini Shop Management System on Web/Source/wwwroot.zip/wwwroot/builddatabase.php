<!---------------------- ˹�����ҧ database+table require "firstpage.php"-------------------------->
<?php
		//--------------------���ҧ database------------------- 
		$sql="CREATE DATABASE db_admin;";
		mysql_query($sql);
		mysql_select_db("db_admin");
				//---------���ҧ table Zone ------------------- 
				$sql="CREATE TABLE  login (
				login_id int(4) DEFAULT '0' NOT NULL  ,
				username VARCHAR(16) NOT NULL ,	
				login_date VARCHAR(16) NOT NULL ,
				login_time VARCHAR(16) NOT NULL ,
				logout_date VARCHAR(16) NOT NULL ,
				logout_time VARCHAR(16) NOT NULL ,	
				page VARCHAR(16) NOT NULL ,	
				status int(4)  NOT  NULL ,
				session_number VARCHAR(35) NOT NULL ,	
				PRIMARY KEY(login_id));";
				mysql_query($sql);	

				//---------���ҧ table Employee -------------------  
				$sql="CREATE TABLE  employee (
				emp_id int(4) DEFAULT '0' NOT NULL  AUTO_INCREMENT  , 
				username VARCHAR(16) NOT NULL ,
				password VARCHAR(45) NOT NULL ,
				name VARCHAR(20) NOT NULL ,
				lastname VARCHAR(20) NOT NULL ,
				sex VARCHAR(16) NOT NULL ,
				address VARCHAR( 200  )  NOT  NULL ,
				post VARCHAR( 16  )  NOT  NULL ,
				tel1 VARCHAR( 16  )  NOT  NULL ,
				tel2 VARCHAR( 16  )  NOT  NULL ,
				email VARCHAR( 100  )  NOT  NULL ,
				position VARCHAR( 16  )  NOT  NULL ,
				saraly float(16) NOT NULL ,
				picture VARCHAR( 100  )  NOT  NULL ,
				PRIMARY KEY(emp_id));";
				mysql_query($sql);	

				//---------���ҧ table Goods -------------------  
				$sql="CREATE TABLE  goods (
				goods_id VARCHAR(16) NOT NULL , 
				type_id VARCHAR(16) NOT NULL ,
				supplier_id VARCHAR(16) NOT NULL ,
				goods_name VARCHAR(45) NOT NULL ,
				unit VARCHAR(16) NOT NULL ,
				retail_price float(16) NOT NULL ,
				fund_price float(16) NOT NULL ,
				sale_percent float(16) NOT NULL ,
				total_remain int( 16  )  NOT  NULL ,
				min_remain int( 16  )  NOT  NULL ,
				zone VARCHAR( 20  )  NOT  NULL ,
				hot_key VARCHAR( 16  )  NOT  NULL ,
				PRIMARY KEY(goods_id));";
				mysql_query($sql);	

				//---------���ҧ table expire ------------------- 
				$sql="CREATE TABLE  expire (
				ex_id int(4) DEFAULT '0' NOT NULL AUTO_INCREMENT  , 
				goods_id VARCHAR(16) NOT NULL ,
				goods_expire VARCHAR( 45  )  NOT  NULL ,			
				PRIMARY KEY(ex_id));";
				mysql_query($sql);	

				//---------���ҧ table expire2 ------------------- 
				$sql="CREATE TABLE  memexpire (	
				goods_id VARCHAR(16) NOT NULL , 
				day VARCHAR( 45  )  NOT  NULL ,			
				PRIMARY KEY(goods_id));";
				mysql_query($sql);

				//---------���ҧ table Customer -------------------  
				$sql="CREATE TABLE  customer (
				cust_id int(4) DEFAULT '0' NOT NULL  AUTO_INCREMENT  , 
				name VARCHAR(20) NOT NULL ,
				lastname VARCHAR(20) NOT NULL ,
				sex VARCHAR(16) NOT NULL ,
				address VARCHAR( 200  )  NOT  NULL ,
				post VARCHAR( 16  )  NOT  NULL ,
				tel1 VARCHAR( 16  )  ,
				tel2 VARCHAR( 16  )  ,
				email VARCHAR( 100  )  NOT  NULL ,
				discount VARCHAR(16) NOT NULL ,
				point int(16) DEFAULT '0' NOT NULL ,
				PRIMARY KEY(cust_id));";
				mysql_query($sql);	

				//---------���ҧ table Goodtype -------------------  
				$sql="CREATE TABLE  goodstype (
				type_id int(4) DEFAULT '0' NOT NULL , 
				type_name VARCHAR(20) NOT NULL ,				
				PRIMARY KEY(type_id));";
				mysql_query($sql);	

				//---------���ҧ table Zone ------------------- 
				$sql="CREATE TABLE  zone (
				zone_id int(4) DEFAULT '0' NOT NULL , 
				zone_name VARCHAR(45) NOT NULL ,				
				PRIMARY KEY(zone_id));";
				mysql_query($sql);	

				//---------���ҧ table unit ------------------- 
				$sql="CREATE TABLE  unit (
				unit_id int(4) DEFAULT '0' NOT NULL , 
				unit_name VARCHAR(45) NOT NULL ,				
				PRIMARY KEY(unit_id));";
				mysql_query($sql);	

				//---------���ҧ table Supplier -------------------  
				$sql="CREATE TABLE  supplier (
				supplier_id int(4) DEFAULT '0' NOT NULL  AUTO_INCREMENT  , 
				supplier_name VARCHAR(45) NOT NULL ,
				address VARCHAR( 200  )  NOT  NULL ,
				post VARCHAR( 16  )  NOT  NULL ,
				tel1 VARCHAR( 16  )  NOT  NULL ,
				tel2 VARCHAR( 16  )  NOT  NULL ,
				email VARCHAR( 100  )  NOT  NULL ,
				PRIMARY KEY(supplier_id));";
				mysql_query($sql);

				//---------���ҧ table Transection -------------------  
				$sql="CREATE TABLE  tx (
				tx_id int(10) DEFAULT '0' NOT NULL AUTO_INCREMENT , 
				group_id int( 10  )  NOT  NULL , 
				goods_id VARCHAR( 16  )  NOT  NULL ,
				amount int( 16  )  NOT  NULL ,
				total_price float( 16  )  NOT  NULL ,
				sale_percent int( 16  )  NOT  NULL ,					
				PRIMARY KEY(tx_id));";
				mysql_query($sql);				

				//---------���ҧ table Temp_tx2 -------------------//`
				$sql="CREATE TABLE  tx2 (
				tx2_id int(10) DEFAULT '0' NOT NULL AUTO_INCREMENT ,
				group_id int( 10  )  NOT  NULL , 
				cust_id VARCHAR( 16  )  NOT  NULL ,
				total_price_all float( 16  )  NOT  NULL ,
				tx_date VARCHAR(16) NOT NULL ,
				tx_weight int(10) UNSIGNED NOT NULL ,
				tx_time VARCHAR(16) NOT NULL ,	
				employee VARCHAR(16) NOT NULL ,
				PRIMARY KEY(tx2_id));";  
				mysql_query($sql);	
				
?>
	
	