<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Admin </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<script type="text/javascript">
	//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		
//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
	 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  

	//function goods_case(list) {
		//var value= (list.options[list.selectedIndex].value);
		//location.href("store.php");
	//}
	
	function goods_case(list){
		    //navigator.plugins.refresh();
			var case_value = (list.options[list.selectedIndex].value);
			parent.iframe3.location.href("iframe3.php?case1="+case_value+"");
			init();
	}
	function goods_case2(list,list2){		
			parent.iframe3.location.href("iframe3.php?case1="+list+"&&code1="+list2);
			init();
	}
//--------------------------------------------------Add type--------------------------------------
var prefsDlog7;
function add_type(){	
		if (!prefsDlog7 || prefsDlog7.closed) {
		prefsDlog7 = showModelessDialog("add_type.php", setPrefs7, "dialogWidth:220%; dialogHeight:10%;dialogLeft:135% ; dialogTop:84%;status=no")
		}		
}
function setPrefs7(list){	
		if(list!=null){
		location.href("store.php?data_type="+list);
		}
}
	function delete_type() {
			var value=gE("type").value;
			if(value=="�Թ��ҷ����"){
				
			}
			else{
				var result=confirm('���ź������Թ����͡�����������Թ������Ǵ \"'+value+'\" ��·�����');
				if(result){	
					location.href("store.php?delete1="+value+"");
				}
			}
	}	
//------------------------------------------------Add zone--------------------------------------------------------
var prefsDlog6;
	function add_zone(){	
			 if (!prefsDlog6 || prefsDlog6.closed) {
			prefsDlog6 = showModelessDialog("add_zone.php", setPrefs6, "dialogWidth:220%; dialogHeight:10%;dialogLeft:354% ; dialogTop:84%;status=no")
			}		
	}
function setPrefs6(list){	
			if(list!=null){
			location.href("store.php?data_zone="+list);
			}
}

	function delete_zone() {
			var value=gE("zone").value;
			if(value=="nozone"){
				
			}
			else{
				var result=confirm('�س��㨷���ź�����ŷ�����Թ��� \"'+value+'\" �͡�ҡ�ҹ������');
				if(result){	
					location.href("store.php?delete_zone="+value+"");
				}
			}
	}	
//---------------------------------------------------Add unit--------------------------------------------
	var prefsDlog5;
	function add_unit(){	
			 if (!prefsDlog5 || prefsDlog5.closed) {
			prefsDlog5 = showModelessDialog("add_unit.php", setPrefs5, "dialogWidth:220%; dialogHeight:10%;dialogLeft:533% ; dialogTop:84%;status=no")
			}		
	}
function setPrefs5(list){	
			if(list!=''){
				location.href("store.php?data_unit="+list);
			}
}
	function delete_unit() {
			var value=gE("unit").value;
			if(value=="unit"){
				
			}
			else{
				var result=confirm('�س��㨷���ź˹����Թ��� \"'+value+'\" �͡�ҡ�ҹ������');
				if(result){	
					location.href("store.php?delete_unit="+value+"");
				}
			}
	}	
	function init() {	
	document.onkeypress = showKeyPress;
	document.onkeydown = showKeyDown
	}
	function send(){
		if(gE("code").value!="")
		document.form2.submit();
	}		
		var code="";
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;

		if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116) || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}

	    if(i==113){
			    find();
		  }	  
}
function showKeyPress(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;	
		  if(i>47&&i<58){
			   if(i>47&&i<58)		
				j=String.fromCharCode(i);
			   var len2=code.length;
			   if(len2<16){
				code=code+j;
			    gE("code").value=code;
			   }
		    }
		  else if(i==46){
				len=code.length;
				code=code.substring(0,len-1);
				gE("code").value=code;
		  }
		  else if(i==13){
				if(code!="")
				document.form2.submit();
		  }	  
		
	}
	var prefsDlog
function add_new_goods(code,list) {	
	parent.iframe3.location.href("iframe3.php?case1="+list+"");
	if (!prefsDlog || prefsDlog.closed) {
		var value=code;
		var type=list;
		prefsDlog = showModelessDialog("new_goods.php?code1="+value+"&&type="+type, setPrefs, "dialogWidth:370%; dialogHeight:390%;dialogLeft:320% ; dialogTop:130%;status=no")
	}
}
function setPrefs(list) {	
	if(list!="close"){	location.href("store.php?code_return="+list[0]+"&&type_return="+list[1]+"&&name_return="+list[2]+"&&supplier_return="+list[3]+"&&unit_return="+list[4]+"&&zone_return="+list[5]+"&&fund_return="+list[6]+"&&cost_return="+list[7]+"&&alot_return="+list[8]+"&&warnalot_return="+list[9]+"&&sale_return="+list[10]+"&&day_return="+list[11]+"&&month_return="+list[12]+"&&year_return="+list[13]+ "&&key_return="+list[14]+"&&day2="+list[15]+"&&member="+list[16]);
	}
	else{
      init();
	}
}
var prefsDlog2
function add_old_goods(code) {
	if (!prefsDlog2 || prefsDlog2.closed) {
		var value=code;
		prefsDlog2 = showModelessDialog("old_goods.php?code1="+value, setPrefs2, "dialogWidth:220%; dialogHeight:160%;status=no")
	}
}
function setPrefs2(list) {
	if(list!="close"){	location.href("store.php?code_return_old="+list[0]+"&&alot_return_old="+list[1]+"&&day_return_old="+list[2]+"&&month_return_old="+list[3]+"&&year_return_old="+list[4]);
	}
	else{
      init();
	}
}
//------------------------------------------Find goods----------------------------------------------------
var prefsDlog3;
function find() {
			if (!prefsDlog3 || prefsDlog3.closed) {
			prefsDlog3 = showModelessDialog("find_pos.php", setPrefs3, "dialogWidth:280%; dialogHeight:10%;dialogLeft:344% ; dialogTop:54% ; status=0")
			}
}
var prefsDlog4;
function setPrefs3(list){
			if(list!=null && list!='closed'){
				if (!prefsDlog4 || prefsDlog4.closed) {
				prefsDlog1 = showModelessDialog("find.php?data="+list, setPrefs4, "dialogWidth:360%; dialogHeight:220%;dialogLeft:344% ; dialogTop:54% ; status=0")
				}
			}
}
function setPrefs4(list){
	if(list!=null){
	location.href("store.php?find_code="+list);
	}
}
//-----------------------------------------------Show expire date--------------------------------------
var ex=new Array();
function check_ex(list){
	var i=0;
	var id;
	var string="";
	for(var k=1;k<list;k++){
		 id="id"+i;
	     ex[i]=gE(id).value;  
		 i++;  id="id"+i;
		 ex[i]=gE(id).value;  
		  i++;  id="id"+i;
		 ex[i]=gE(id).value;
		 string=string+" �Թ�����͵ "+ex[i-2]+" ���� "+ex[i-1]+" ������� "+ex[i]+"\n";
		  i++; 
	}	
	if(string==""){
		//alert("������Թ����������");
	}
	else{
		alert(string);
	}
}
//-----------------------------------------------Show goods alert--------------------------------------
var ex2=new Array();
function goods_alert(list){
	var i=0;
	var id;
	var string="";
	for(var k=1;k<list;k++){
		 id="ida"+i;
	     ex2[i]=gE(id).value;  
		 i++;  id="ida"+i;
		 ex2[i]=gE(id).value;  
		  i++;  id="ida"+i;
		 ex2[i]=gE(id).value;
		  i++;  id="ida"+i;
		 ex2[i]=gE(id).value;
		 string=string+"����͹�Թ��������� : "+" �ӴѺ "+ex2[i-3]+" ���� "+ex2[i-2]+" ���� "+ex2[i-1]+" ������Թ��� "+ex2[i]+" ˹��� \n";
		  i++; 
	}	
	if(string==""){
		//alert("������Թ���������");
	}
	else{
		alert(string);
	}
}
//-------------------------------------------------------------------------------------------------------------
function logout() {
	location.href("menu.php?back=store");
}
</script>
</head>
<?php
	include("fn_mysql.php");
	//------------------------------------add status page------------------------------------------------
	$user=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","store","status","1");
		if(!$find){ 
		update_2record("login","username",$user,"status","1","page","store");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user,"status","1","login_date",$date);
		update_2record("login","username",$user,"status","1","login_time",$login_time);
	}
	//--------------------------variable-----------------------------
	$data_type=$HTTP_GET_VARS[data_type];
	$delete1=$HTTP_GET_VARS[delete1];
	$data_zone=$HTTP_GET_VARS[data_zone];
	$delete_zone=$HTTP_GET_VARS[delete_zone];
	$data_unit=$HTTP_GET_VARS[data_unit];
	$delete_unit=$HTTP_GET_VARS[delete_unit];
	$code=$HTTP_POST_VARS[code];
	$type=$HTTP_POST_VARS[type];
	//-------------------Add new goods return------------------
	$code_return=$HTTP_GET_VARS[code_return];
	$type_return=$HTTP_GET_VARS[type_return];
	$name_return=$HTTP_GET_VARS[name_return];
	$supplier_return=$HTTP_GET_VARS[supplier_return];
	$unit_return=$HTTP_GET_VARS[unit_return];
	$zone_return=$HTTP_GET_VARS[zone_return];
	$fund_return=$HTTP_GET_VARS[fund_return];
	$cost_return=$HTTP_GET_VARS[cost_return];
	$alot_return=$HTTP_GET_VARS[alot_return];
	$warn_return=$HTTP_GET_VARS[warnalot_return];
	$sale_return=$HTTP_GET_VARS[sale_return];
	$day_return=$HTTP_GET_VARS[day_return];
	$month_return=$HTTP_GET_VARS[month_return];
	$year_return=$HTTP_GET_VARS[year_return];
	$day=$day_return."/".$month_return."/".$year_return;
	$key_return=$HTTP_GET_VARS[key_return];
	//-------------------Editing goods return------------------
	$code_return2=$HTTP_GET_VARS[code_return2];
	$type_return2=$HTTP_GET_VARS[type_return2];
	$name_return2=$HTTP_GET_VARS[name_return2];
	$supplier_return2=$HTTP_GET_VARS[supplier_return2];
	$unit_return2=$HTTP_GET_VARS[unit_return2];
	$zone_return2=$HTTP_GET_VARS[zone_return2];
	$fund_return2=$HTTP_GET_VARS[fund_return2];
	$cost_return2=$HTTP_GET_VARS[cost_return2];
	$alot_return2=$HTTP_GET_VARS[alot_return2];
	$warn_return2=$HTTP_GET_VARS[warnalot_return2];
	$sale_return2=$HTTP_GET_VARS[sale_return2];
	$key_return2=$HTTP_GET_VARS[key_return2];
	//-------------------Add old goods return--------------------
	$code_return_old=$HTTP_GET_VARS[code_return_old];
	$alot_return_old=$HTTP_GET_VARS[alot_return_old];
	$day_return_old=$HTTP_GET_VARS[day_return_old];
	$month_return_old=$HTTP_GET_VARS[month_return_old];
	$year_return_old=$HTTP_GET_VARS[year_return_old];
	$day_old=$day_return_old."/".$month_return_old."/".$year_return_old;
	//-------------------Edit and Delete form frame 3-----------
	$delete_from_frame3=$HTTP_GET_VARS[delete_from_frame3];
	//--------------------------������Դ�Թ���--------------------------
		if($data_type!=null){	
			 $result=insert_to_goodstype($data_type);
			 if($result){echo "<body onload=\"alert('��Դ�Թ��ҫ�ӡѹ')\">";}
		}
   //----------------------------ź��Դ�Թ���---------------------------
	if($delete1!=null){
		$result=select_record("goodstype","type_name",$delete1);
		$type_id=mysql_result($result,0,"type_id");
		delete_record("goods","type_id",$type_id);
		delete_record("goodstype","type_name",$delete1);		
	}
	//--------------------------����������Թ���--------------------------
		if($data_zone!=null){	
			 $result=insert_to_zone($data_zone);
			 if($result){echo "<body onload=\"alert('������Թ��ҫ�ӡѹ')\">";}
		}
   //----------------------------ź������Թ���---------------------------
	if($delete_zone!=null){
		delete_record("zone","zone_name",$delete_zone);
	}
	//--------------------------����˹����Թ���--------------------------
		if($data_unit!=null){	
			 $result=insert_to_unit($data_unit);
			 if($result){echo "<body onload=\"alert('˹����Թ��ҫ�ӡѹ')\">";}
		}
   //----------------------------ź˹����Թ���---------------------------
	if($delete_unit!=null){
		delete_record("unit","unit_name",$delete_unit);
	}
   //----------------------------�����Թ���------------------------------
   if($code!=null){
		$result=find_record("goods","goods_id",$code);
		if(!$result){echo "<body onload=\"add_new_goods('".$code."','".$type."');\">";}
		else{
			echo "<body onload=\"add_old_goods('$code');\">";
		}
   }
 //----------------------------�����Թ���------------------------------
  $find_code=$HTTP_GET_VARS[find_code];
   if($find_code!=null){
			$result=select_record("goods","goods_id",$find_code);
			$type_id=mysql_result($result,0,"type_id");
			$result=select_record("goodstype","type_id",$type_id);
			$type_name=mysql_result($result,0,"type_name");
			?><body onload="goods_case2('<?echo $type_name;?>','<?echo $find_code;?>');"></body><?
			$type=$type_name;
   }
   //----------------------------�����Թ�������㹰ҹ������------------------------------
    if($code_return!=""&&$code_return!="undefined"){
		$result=select_record("goodstype","type_name",$type_return);
		$type_return99=mysql_result($result,0,"type_id");
		$result=select_record("supplier","supplier_name",$supplier_return);
		$supplier_id99=mysql_result($result,0,"supplier_id");
insert_to_goods($code_return,$type_return99,$supplier_id99,$name_return,$unit_return, $cost_return,$fund_return,$sale_return,$alot_return,$warn_return,$zone_return,$key_return);
 //----------------------------------------insert to Expire table--------------------------
		$member=$HTTP_GET_VARS[member];
		$day2=$HTTP_GET_VARS[day2];
		if($member=="on" && $day2!=""){		
			insert_to_memexpire($code_return,$day2);
			//--------------------
			$result=getdate();
			$year=$result["year"]+543;
			$year=substr($year,0,2);
			$day2=$result["mday"]+$day2;
			$day=$day2."/".$result["mon"]."/".$year;
			insert_to_expire($code_return,$day);
			id_oder("expire","ex_id");
		}
		else if($member=="" && $year_return!=null){
			insert_to_expire($code_return,$day);
			id_oder("expire","ex_id");
		}	
	?><body onload="goods_case2('<?echo $type_return;?>','<?echo $code_return;?>');"></body><?
   }
  //----------------------------����Թ���㹰ҹ������------------------------------
   if($code_return2!=""&&$code_return2!="undefined"){
	   delete_record("goods","goods_id",$code_return2);
	$result=select_record("goodstype","type_name",$type_return2);
	$type_return99=mysql_result($result,0,"type_id");
	$result=select_record("supplier","supplier_name",$supplier_return2);
	$supplier_id99=mysql_result($result,0,"supplier_id");
insert_to_goods($code_return2,$type_return99,$supplier_id99,$name_return2,$unit_return2, $cost_return2,$fund_return2,$sale_return2,$alot_return2,$warn_return2,$zone_return2, $key_return2);
		//----------------------------------------insert to Expire table--------------------------
		$day3=$HTTP_GET_VARS[day3];
		if($day3!=""){		
			 $find=find_record("memexpire","goods_id",$code_return2);
			 if(!$find){
				insert_to_memexpire($code_return2,$day3);
			 }
			 else{
				update_record_where("memexpire","goods_id",$code_return2,"day",$day3);
			 }
		}
	?><body onload="goods_case2('<?echo $type_return2;?>','<?echo $code_return2;?>');"></body><?
   }
  //----------------------------�����ӹǹ�Թ���㹰ҹ���������------------------------
   if($code_return_old!=""&&$code_return_old!="undefined"){	
		 $result=select_record("goods","goods_id",$code_return_old);
		 $alot_old=mysql_result($result,0,"total_remain");
		 $type_id=mysql_result($result,0,"type_id");
		 $total=$alot_old+$alot_return_old;
	     update_record_where("goods","goods_id",$code_return_old,"total_remain",$total);
		 //----------------------------------------insert to Expire table--------------------------
		 if($year_return_old!=null){
		 $find=find_2record("expire","goods_id",$code_return_old,"goods_expire",$day_old);
		 if(!$find){
		 insert_to_expire($code_return_old,$day_old);
		 id_oder("expire","ex_id");
		 }
		 }
		 //---------------------------------------------------------------------------------------------
	     $result=select_record("goodstype","type_id",$type_id);
	     $type_return=mysql_result($result,0,"type_name");
	     ?><body onload="goods_case2('<?echo $type_return;?>','<?echo $code_return_old;?>');"></body><?
   }
  //-------------------------------------ź�Թ����͡�ҡ�ҹ������-------------------------------
	if($delete_from_frame3!=null){
		$bool=find_record("goods","goods_id",$delete_from_frame3);
		if($bool){
			$result=select_record("goods","goods_id",$delete_from_frame3);
			$type_id=mysql_result($result,0,"type_id");
			$result=select_record("goodstype","type_id",$type_id);
			$type_del=mysql_result($result,0,"type_name");
			delete_record("goods","goods_id",$delete_from_frame3);
			$bool=find_record("goods","type_id",$type_id);
			if($bool){
				$result=select_record_oder("goods","type_id",$type_id,"goods_id");
				$code_one=mysql_result($result,0,"goods_id");
				?><body onload="goods_case2('<?echo $type_del;?>','<?echo $code_one;?>');"></body><?
			}
			$type=$type_del;
		}
		//--------------------------------ź��͵�ѹ������ش���----------------------------------------
			delete_record("memexpire","goods_id",$delete_from_frame3);
			delete_record("expire","goods_id",$delete_from_frame3);
			id_oder("expire","ex_id");		
	}//end if
	//---------------------------------Check expire day------------------------------------------
		$result=getdate();
		$year=$result["year"];
		$year=$year+543;
		$year=substr($year,2);
		$day=$result["mday"];
		$month=$result["mon"];
		$date_now=$day+$month*40+$year*600;
			$result=select_all_record("*","expire");
			$i=0;
			while($dbarr=mysql_fetch_array($result)){
				$weight=explode("/",$dbarr["goods_expire"]);
				$date_old=$weight[0]+$weight[1]*40+$weight[2]*600;
				if($date_now>$date_old){
					$test=$dbarr["ex_id"];
					connect_mysql("db_admin");//function
		$sql="SELECT * FROM expire WHERE goods_id=".$dbarr[goods_id]." ORDER BY ex_id;";
		$result2=mysql_query($sql);
					$j=1;
					while($dbarr2=mysql_fetch_array($result2)){
						if($test==$dbarr2["ex_id"]){$lot=$j;}			
					}
					echo "<input type=hidden id=id".$i."  value=".$lot.">";
					$i++;
					echo "<input type=hidden id=id".$i."  value=".$dbarr["goods_id"].">";
					$i++;
					echo "<input type=hidden id=id".$i."  value=".$dbarr["goods_expire"].">";
					$i++;
					$j++;
				}	
					
			}
		//---------------------------------Check alert goods------------------------------------------
		
			$sql="SELECT * FROM goods;";
			$result=mysql_query($sql);
			$k=1; $m=0;
					while($dbarr=mysql_fetch_array($result)){
						if($dbarr["total_remain"]<$dbarr["min_remain"]){					
							echo "<input type=hidden id=ida".$m."  value=".$k.">";
							$m++;
							echo "<input type=hidden id=ida".$m."  value=".$dbarr["goods_id"].">";
							$m++;
							echo "<input type=hidden id=ida".$m."  value=".$dbarr["goods_name"].">";
							$m++;
							echo "<input type=hidden id=ida".$m."  value=".$dbarr["total_remain"].">";
							$m++;
							$k++;
						}
					
					}
	$menu=$HTTP_GET_VARS[menu];
if($menu==1){	
	if(getconfig("config","9:alot_auto")=="on" && getconfig("config","10:expire_auto")=="on"){
		     ?><body onload="goods_alert(<?echo $k;?>),check_ex(<?echo $j;?>),init()"></body><?		
	}
	else if(getconfig("config","9:alot_auto")=="on" && getconfig("config","10:expire_auto")==""){
				?><body onload="goods_alert(<?echo $k;?>),init()"></body><?				
	}
	else if(getconfig("config","9:alot_auto")=="" && getconfig("config","10:expire_auto")=="on"){
				?><body onload="check_ex(<?echo $j;?>),init()"></body><?			
	}
}
?>
<body scroll="no" background="image\bg_pos\bg.jpg" onload="init();">
<center>
<table width="757" height="535" border="0" cellspacing="0" cellpadding="2" background="image\bg_pos\bg.jpg">

	<tr height="10%" >
		<td>	
		<table border=0 width="100%">
		<tr>
		<td>
		<form name="form2" method="post" action="store.php">
		<input type="text" id="code" name="code"  readonly maxlength="14"/>
		<button onclick="send();" name="ok2"><center><img src="image\adddata\adddata.gif" height="22" align="left" hspace="0"/>����</center></button>
		<button onclick="find();"><center><img src="image\find\find.jpg" height="22" align="left" hspace="0"/>����</center></button>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<button onclick="check_ex(<?echo $j;?>);">�Թ����������</button> 
		<button onclick="goods_alert(<?echo $k;?>);">�Թ���������</button>
		</td>	
		<td align="right">
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
		</tr>
		</table>
		</td>
	</tr>

	<tr height="5%"  >
		<td>		
			<select id="type" onchange="goods_case(this);" name="type">				 
			<?
				$result=select_all_record_order("type_name","goodstype","type_id");
				while($dbarr=mysql_fetch_array($result)){
					?><option <?if($type_return==$dbarr['type_name']||$type==$dbarr['type_name']||$type_return2==$dbarr['type_name']){echo "selected";}?> value="<?echo $dbarr['type_name'];?>"><?echo $dbarr["type_name"];?>
					</option>
					<?
				}
			?>
			</select>
			 <button onclick="add_type();" >����������Թ���</button>
			 <button onclick="delete_type();" >&nbsp;ź&nbsp;</button>
			 &nbsp;
			 <!----------------------------------------------------------------------------------->
				<select id="zone">
				        <option value="nozone">���������</option>
					<?
						$result=select_all_record_order("zone_name","zone","zone_id");
						while($dbarr=mysql_fetch_array($result)){
							echo "<option value=\"".$dbarr["zone_name"]."\">".$dbarr["zone_name"]."</option>";
						}
					?>
			</select>
				 <button onclick="add_zone();" >���������</button>
				 <button onclick="delete_zone();" >&nbsp;ź&nbsp;</button>
			<!----------------------------------------------------------------------------------->
			 &nbsp;
				<select id="unit">
					 <option value="unit">˹���</option>
					<?
						$result=select_all_record_order("unit_name","unit","unit_id");
						while($dbarr=mysql_fetch_array($result)){
							echo "<option value=\"".$dbarr["unit_name"]."\">".$dbarr["unit_name"]."</option>";
						}
					?>
			</select>
				 <button onclick="add_unit();">����˹���</button>
				 <button onclick="delete_unit();">&nbsp;ź&nbsp;</button>
				 &nbsp;
				 
		</td>
		</form>	
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" background="image\bg_pos\bg.jpg">
			<tr>
			<td>
				<iframe src="iframe3.php" width="100%" height="100%" border="0" id="iframe3">
				
				</iframe>
			</td>
			</tr>
		</table>
		 
	</td>
	</tr>
	<tr height="60" valign="middle">
		<td >
			<table width="100%" height="90%" border="0" cellspacing="0" cellpadding="0" >
				<tr >
					<td width="70%" align="center">
					
					</td>
				</tr>
			</table>
		
		</td>
	</tr>
</table>
</center>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>


