<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>�ٻ��ѡ�ҹ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		document.onkeypress = showKeyPress;
}	
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27) verifyClose();
}
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc('closed');
	window,close();
}
window.onbeforeunload = verifyClose

</SCRIPT>

</HEAD>
<?php

		$id=$HTTP_GET_VARS[id];
		$result=select_record("employee","emp_id",$id);
		if($id!=null){
			$file=mysql_result($result,0,"picture");
			$name=mysql_result($result,0,"name");
		}
?>
<BODY bgcolor="#FFFFFF" onload="init();">
<center>
<table border="0" width="100%" height="100%" cellspacing="0">
						<tr>
						<td>
						<center><img src="picture\<?echo $file;?>" width="120" height="110" /></center>
						</td>
						</tr>

						<tr>
						<td>
						<center>���� : <?echo $name;?></center>
						</td>
						</tr>

</table>
</form>
</center>		
</BODY>
</HTML>
