<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>����������ͧ�Թ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		document.onkeypress = showKeyPress;
	}
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27) verifyClose();
}
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc('close');
	window.close();
}
window.onbeforeunload = verifyClose

var data=new Array();
function delete_confirm(type,id,goods,lot,date){
		//document.write(name);
		var i=confirm('�س��㨷���ź�Թ��� '+goods+' ��͵��� '+lot+' �ѹ������� '+date);
		if(i){			
			data[0]=type;
			data[1]=id;
			var returnFunc = window.dialogArguments
			returnFunc(data);
			window.close();
		}
}
</SCRIPT>

</HEAD>
<?php
include("fn_mysql.php");
$code1=$HTTP_GET_VARS[code1];
$result=select_record("goods","goods_id",$code1);
$goods_id=mysql_result($result,0,"goods_id");
$goods_name=mysql_result($result,0,"goods_name");
$supplier_id=mysql_result($result,0,"supplier_id");
$min_remain=mysql_result($result,0,"min_remain");
$zone=mysql_result($result,0,"zone");
$key=mysql_result($result,0,"hot_key");
$type_id=mysql_result($result,0,"type_id");

$result=select_record("supplier","supplier_id",$supplier_id);
$supplier_name=mysql_result($result,0,"supplier_name");

$result=select_record("goodstype","type_id",$type_id);
$type_name=mysql_result($result,0,"type_name");

?>
<BODY  onload="init();" bgcolor="#FFFFFF">
<form action="view.php"  name="main_form" id="main_form" method="post">
<center>
<table border="0" width="106%" height="10%" bgcolor="" cellspacing="1">
		<tr>
				<td width="60%" bgcolor="9999cc">
						<center><font color="#FFFF00"><b>�����Թ���: <?echo $goods_id;?></b></font></center>
				</td>
				
		</tr>				
		<tr>
				<td width="60%">
						<font color="">���Ѵ��˹���  : </font><font color=""><?echo $supplier_name;?></font>
				</td>
				
		</tr>
		<tr>			
				<td  width="60%">
						<font color="">�ӹǹ����͹ : </font><font color=""><?echo $min_remain;?></font>
				</td>
				
		</tr>
		<tr>				
				<td width="60%">
						<font color="">����� : </font><font color=""><?echo $zone;?></font>
				</td>
		</tr>
		<tr>				
				<td width="60%">
						<font color="">�����Ѵ�Թ��� : </font><font color=""><?echo $key;?></font>
				</td>
		</tr>
		<tr>				
				<td width="60%">
				<?
						$bool=find_record("memexpire","goods_id",$code1);
						if($bool){
							$result=select_record("memexpire","goods_id",$code1);
							$day=mysql_result($result,0,"day");
						}
				?>
						<font color="">������عѺ��ա : </font><font color=""><?if($day!="")echo $day." �ѹ";else echo "no";?></font>
				</td>
		</tr>
		<?
			connect_mysql("db_admin");//function
			$sql="SELECT * FROM expire WHERE goods_id=$goods_id ORDER BY ex_id;";
			$result=mysql_query($sql);
			$i=1;
		while($dbarr=mysql_fetch_array($result)){
		?>
		<tr>	
				<td width="60%">
						<font color="">��͵ </font><font color=""><?echo $i;?></font>
						<font color="">�������: </font><font color=""><?echo $dbarr["goods_expire"];?></font>
						<img src="image\delete\delete2.gif" alt="ź�Թ���"  onclick="delete_confirm('<?echo $type_name;?>','<?echo $dbarr["ex_id"];?>','<?echo $goods_name;?>','<?echo $i;?>','<?echo $dbarr["goods_expire"];?>');"/>
				</td>
		
		</tr>
		<?
			$i++;
		}
		?>
		
</table>
</center>		
</form>
</BODY>
</HTML>
