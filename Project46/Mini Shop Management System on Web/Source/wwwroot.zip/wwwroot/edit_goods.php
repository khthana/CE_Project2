<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE> ��䢢������Թ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		} 
function init() {	
		document.onkeypress = showKeyPress;
}	
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27) verifyClose2();
	else if(i==13){
		var x=gE("code2").value;
		main_send(x);
	}
}
function verifyClose2() {
	var returnFunc = window.dialogArguments
	returnFunc("close");
	window.close();
}
window.onbeforeunload = verifyClose2
function isNumber(inputStr,form) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
function isNumber_float(inputStr,form) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if ((oneChar < "0" || oneChar > "9") && oneChar != ".") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
function check_fund(form) {
	inputStr = form.fund.value;
	if (isNumber_float(inputStr,form)) {
		// statements if true
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.fund.focus();
		form.fund.select();
	}
}
function check_cost(form) {
	inputStr = form.cost.value;
	if (isNumber_float(inputStr,form)) {
		var c=parseInt(gE("cost").value);
		var f=parseInt(gE("fund").value);
		if(c<f){
			alert("�ҤҢ�µ�ӡ��ҵ鹷ع");	
			gE("goods_name").focus();
			gE("goods_name").select();
			form.cost.focus();
			form.cost.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.cost.focus();
		form.cost.select();
	}
}
function check_alot(form) {
	inputStr = form.alot.value;
	if (isNumber(inputStr,form)) {
		// statements if true
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.alot.focus();
		form.alot.select();
	}
}
function check_warnalot(form) {
	inputStr = form.warnalot.value;
	if (isNumber(inputStr,form)) {
		var a=parseInt(gE("alot").value);
		var w=parseInt(gE("warnalot").value);
		if(a<w){
			alert("����͹�Թ�ӹǹ�Թ��Ҥ������");	
			gE("goods_name").focus();
			gE("goods_name").select();
			form.warnalot.focus();
			form.warnalot.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.warnalot.focus();
		form.warnalot.select();
	}
}
function check_sale(form) {
	inputStr = form.sale.value;
	if (isNumber(inputStr,form)) {
		var s=parseInt(gE("sale").value);
		if(s>100){
			alert("��Ңͧ����Ţ��ͧ����Թ 100 ");	
			gE("goods_name").focus();
			gE("goods_name").select();
			form.sale.focus();
			form.sale.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.sale.focus();
		form.sale.select();
	}
}
function check_cost2() {
		var c=parseInt(gE("cost").value);
		var f=parseInt(gE("fund").value);
		if(c<f){
			alert("�ҤҢ�µ�ӡ��ҵ鹷ع");	
			gE("goods_name").focus();
			gE("goods_name").select();
			gE("cost").focus();
			gE("cost").select();
			return false;
		}
			return true;
}
function check_warnalot2() {	
		var a=parseInt(gE("alot").value);
		var w=parseInt(gE("warnalot").value);
		if(a<w){
			alert("����͹�Թ�ӹǹ�Թ��Ҥ������");	
			gE("goods_name").focus();
			gE("goods_name").select();
			gE("warnalot").focus();
			gE("warnalot").select();
			return false;
		}
			return true;
}
function check_remain2(list) {
	inputStr = list;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if ((oneChar < "0" || oneChar > "9" ) && oneChar != ".") {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}


	var goods=new Array();
function main_send(code1){	
	goods[0]=code1;
	goods[1]=gE("type").value;
	goods[2]=gE("goods_name").value;
	goods[3]=gE("supplier").value;
	goods[4]=gE("unit").value;
	goods[5]=gE("zone").value;
	goods[6]=gE("fund").value;
	goods[7]=gE("cost").value;
	goods[8]=gE("alot").value;
	goods[9]=gE("warnalot").value;
	goods[10]=gE("sale").value;	
	goods[11]=gE("hotkey").value;
	goods[12]=gE("day2").value;
	if(goods[0]==""){
		alert('��سҡ�͡�����Թ��ҡ�͹');
	}
	else if(goods[1]==""){
		alert('��س����͡������Թ��ҡ�͹');
	}
	else if(goods[2]==""){
		alert('��سҡ�͡�����Թ��ҡ�͹');
	}
	else if(goods[3]==""){
		alert('��س����͡���Ѵ��˹��¡�͹');
	}
	else if(goods[4]==""){
		alert('��سҡ�͡˹����Թ��ҡ�͹');
	}
	else if(goods[5]==""){
		alert('��سҡ�͡������Թ��ҡ�͹');
	}
	else if(goods[6]==""){
		alert('��سҡ�͡�鹷ع�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[6])){
		//check number
		alert("��سҡ�͡�鹷ع�繵���Ţ��ҹ��");	
	}
	else if(goods[7]==""){
		alert('��سҡ�͡�ҤҢ���Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[7])){
		//check number
		alert("��سҡ�͡�ҤҢ���繵���Ţ��ҹ��");
	}
	else if(goods[8]==""){
		alert('��سҡ�͡�ӹǹ�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[8])){
		//check number
		alert("��سҡ�͡�ӹǹ�Թ����繵���Ţ��ҹ��");
	}
	else if(goods[9]==""){
		alert('��سҡ�͡�ӹǹ����͹�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[9])){
		//check number
		alert("��سҡ�͡�ӹǹ����͹�繵���Ţ��ҹ��");
	}
	else if(goods[10]==""){
		alert('��سҡ�͡��ǹŴ�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[10])){
		//check number
		alert("��سҡ�͡��ǹŴ�繵���Ţ��ҹ��");
	}	
	else if(!check_remain2(goods[12]) && goods[12]!=""){
		//check number
		alert("��سҡ�͡�ѹ�繵���Ţ��ҹ��");
	}
	else if(!check_warnalot2()){
		//compare alert
	}
	else if(!check_cost2()){
		//compare cost
	}	
	else{
	var returnFunc = window.dialogArguments
	returnFunc(goods);
	window.close();
	}
}
</SCRIPT>

</HEAD>
<?php
	//--------------------------variable-----------------------------
	$code1=$HTTP_GET_VARS[code1];
	$result=select_record("goods","goods_id",$code1);
	$type=mysql_result($result,0,"type_id");
	$supplier=mysql_result($result,0,"supplier_id");
	$name=mysql_result($result,0,"goods_name");
	$unit=mysql_result($result,0,"unit");
	$retail_price=mysql_result($result,0,"retail_price");
	$fund_price=mysql_result($result,0,"fund_price");
	$sale_percent=mysql_result($result,0,"sale_percent");
	$total_remain=mysql_result($result,0,"total_remain");
	$min_remain=mysql_result($result,0,"min_remain");
	$zone=mysql_result($result,0,"zone");
	

?>
<BODY bgcolor="#EEEEEE" onload="init();">
<form action="_self"  name="main_form" id="main_form" method="post">
<center>
<table border="0" width="100%">
		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<?
			$result=select_record("goods","goods_id",$code1);
			$hotkey=mysql_result($result,0,"hot_key");
			?>
			 <font color="#6633CC"><b>�Թ�����觴�ǹ:</b></font>
			 <select id="hotkey">
			<option value="no" <?if($hotkey=="no") echo "selected";?> >����� </option>
			<option value="F8" <?if($hotkey=="F8") echo "selected";?> >F8 <?echo getconfig("config","3:F8");?></option>
			<option value="F9" <?if($hotkey=="F9") echo "selected";?> >F9 <?echo getconfig("config","4:F9");?></option>
			<option value="F10" <?if($hotkey=="F10") echo "selected";?> >F10 <?echo getconfig("config","5:F10");?></option>
			<option value="F11" <?if($hotkey=="F11") echo "selected";?> >F11 <?echo getconfig("config","6:F11");?></option>
			<option value="F12" <?if($hotkey=="F12") echo "selected";?> >F12 <?echo getconfig("config","7:F12");?></option>
			</select>
			</td>
			<td>
			
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			&nbsp;<font color="#6633CC">�����Թ���:</font><?echo $code1;?>
			</td>
			<td>
			
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">������Թ���:</font><select id="type"> 
			
			<?
				$result=select_all_record_order("*","goodstype","type_id");
				while($dbarr=mysql_fetch_array($result)){
					if($type==$dbarr["type_id"])
					{
					echo "<option selected=\"selected\" value=\"".$dbarr["type_name"]."\">".$dbarr["type_name"]."</option>";
					}
					else{
					echo "<option value=\"".$dbarr["type_name"]."\">".$dbarr["type_name"]."</option>";
					}
				}
			?>
			</select>
			</td>
			<td>		
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">&nbsp;&nbsp;�����Թ���:</font><input type="text" id="goods_name" value="<?echo $name;?>" name="goods_name" maxlength="45"/>
			</td>
			<td>	
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">&nbsp;����˹���:</font><select id="supplier"> 
			
			<?
				$result=select_all_record_order("*","supplier","supplier_id");
				while($dbarr=mysql_fetch_array($result)){		
			if($supplier==$dbarr["supplier_id"]){
			echo "<option selected=\"selected\" value=\"".$dbarr["supplier_name"]."\">".$dbarr["supplier_name"]."</option>";
			}
			else{
			echo "<option value=\"".$dbarr["supplier_name"]."\">".$dbarr["supplier_name"]."</option>";
			}
				}
			?>
			</select>
			</td>
			<td>		
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#6633CC">˹���:</font><select id="unit"> <option value="˹���">˹���</option>
					<?
						$result=select_all_record_order("unit_name","unit","unit_id");
						while($dbarr=mysql_fetch_array($result)){
							if($unit==$dbarr["unit_name"]){
							echo "<option selected=\"selected\" value=\"".$dbarr["unit_name"]."\">".$dbarr["unit_name"]."</option>";
							}
							else{
							echo "<option value=\"".$dbarr["unit_name"]."\">".$dbarr["unit_name"]."</option>";
							}
						}
					?>
			</select>
			</td>
			<td >
			<font color="#6633CC">�����:</font><select id="zone"><option value="nozone">���������</option>
					<?
					$result=select_all_record_order("zone_name","zone","zone_id");
					while($dbarr=mysql_fetch_array($result)){
						if($zone==$dbarr["zone_name"]){
						echo "<option selected=\"selected\" value=\"".$dbarr["zone_name"]."\">".$dbarr["zone_name"]."</option>";
						}
						else{
						echo "<option value=\"".$dbarr["zone_name"]."\">".$dbarr["zone_name"]."</option>";
						}
					}
					?>
			</select>
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td >
				&nbsp;&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">�鹷ع:</font><input type="text" value="<?echo $fund_price;?>" id="fund" name="fund" size="10"  onChange="check_fund(this.form);" maxlength="16"/>
			</td>
			</form>

			<form>
			<td >
				<font color="#6633CC">�ҤҢ��:</font><input type="text" value="<?echo $retail_price;?>" id="cost" name="cost" size="10" onChange="check_cost(this.form);" maxlength="16"/>
			</td>
			</form>

			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td >
				&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">�ӹǹ:</font><input type="text" value="<?echo $total_remain;?>" id="alot" name="alot"  size="10" onChange="check_alot(this.form);" value="1" maxlength="16"/>
			</td>
			</form>
			
			<form>
			<td >
			<font color="#6633CC">����͹:</font><input type="text" value="<?echo $min_remain;?>" id="warnalot" name="warnalot" size="10" onChange="check_warnalot(this.form);" value="1" maxlength="16"/>
			</td>
			</form>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td width="40%">
				&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">��ǹŴ:</font><input type="text" value="<?echo $sale_percent;?>" id="sale" name="sale" maxLength="3" size="3" value="0" onChange="check_sale(this.form);"/>%
			</td>
			</form>
			</tr>
		</table>	
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td align="right">
				&nbsp;&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">���ѹ�������</font>			
			</td>
			</form>

			<form>			
			<td>
			<font
			<?
			$find=find_record("memexpire","goods_id",$code1);
			 if($find){
				$result=select_record("memexpire","goods_id",$code1);
				$day=mysql_result($result,0,"day");
			 }
			?>
			color="#6633CC">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp�Ѻ��ա <input type="text" id="day2" maxLength="4" size="3" name="day2" value="<?echo $day;?>" /> �ѹ</font>
			</td>
			</form>
			</tr>

	</table>
	</center>
			<center>
			<input type="hidden" value="<?echo $code1;?>" name="code2" id="code2"/>
			<button onclick="main_send(<?echo $code1;?>);">&nbsp;&nbsp;��ŧ&nbsp;&nbsp;</button>&nbsp;
			<button onclick="verifyClose2();">&nbsp;&nbsp;¡��ԡ&nbsp;&nbsp;</button>
			</center>
</form>
</BODY>
</HTML>
