<?php
//echo "xxxxxxxxxxxxxxxxx";
//echo $user_session=$HTTP_SESSION_VARS["user"];
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Admin </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
 <script type="text/javascript">
	//---------------------------Disable hotkey F1,F3,F4,F5,Backspace----------------------------
		document.onkeydown = function() {
    	 	if ( (event.altKey) || ((event.keyCode == 8) && 
    	 			(event.srcElement.type != "text" &&
    	 			event.srcElement.type != "textarea" &&
    	 			event.srcElement.type != "password")) || 
    	 			((event.ctrlKey) && ((event.keyCode == 78) || (event.keyCode == 82)) ) || (event.keyCode == 116)  || (event.keyCode == 117) || (event.keyCode == 118) || (event.keyCode == 115) || (event.keyCode == 114) || (event.keyCode == 112)) {
        	 		event.keyCode = 0;
        	 		event.returnValue = false;
        	 	}
         }

//----------------------------------------------------------------------------------------------------------
//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Function Disabled!";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("return false")
//-----------------------------------------------------------
function dsble_Help(){
//replace this -alert- with your help scripts
//alert('confirmation that event will trigger the F1 command')
return false;
}
document.onhelp=dsble_Help;
//-------------------------------------------End Disable key------------------------------------------------------
    <!--
	 var in_out;
          function begin()
             {  
			    if(in_out==0){
				 left();
			     in_out==1;	
				 }
				 else{ 
				 left2();
			     in_out==0;
				 left();
				 }
             }
			
           function left()//�ҹ����͹�Ҿ价ҧ����
               {    var done=0;
			   PICTURE.style.posLeft-=10;//ŧ����˹�觾ԡ�� ��ҡ�˹���úǡ�����ҡ� ��������㹡������͹�����Ǣ�鹵����ǹ
                      if(PICTURE.style.posLeft<=-350) //�������͹�Ҿ������ç��ͧ���ҧ����ҧ���ʹ�
                            { 
                              done=1;
							
                             }
                      else {  delay=1;} //�͡��鹷���繡������͹���˹�ǧ������§��硹��� �Ţ�ҡ����������͹���ŧ
                        if(done==0){ setTimeout("left();",delay); }
						
						
					  
               }

			  function left2()//�ҹ����͹�Ҿ价ҧ����
               {    var done=0;
			   PICTURE.style.posLeft+=10;//ŧ����˹�觾ԡ�� ��ҡ�˹���úǡ�����ҡ� ��������㹡������͹�����Ǣ�鹵����ǹ
                      if(PICTURE.style.posLeft>=0) //�������͹�Ҿ������ç��ͧ���ҧ����ҧ���ʹ�
                            { 
                              done=1; 
							
                             }
                      else {  delay=1;} //�͡��鹷���繡������͹���˹�ǧ������§��硹��� �Ţ�ҡ����������͹���ŧ
                        if(done==0){ setTimeout("left2();",delay); }								  
               }
	function init(){
		gE("user").focus();
		gE("user").select();
		document.onkeypress = showKeyPress;
	}
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27){
			var result=confirm('�س��㨷����͡˹�ҡ�˹��Է���');
				if(result){	
					logout();
				}
		}
}
	function link(list) {
				var case1 = (list.options[list.selectedIndex].value);
				hide_all();
				switch(case1){
					 case "000100" :				gE("pos_id").style.display = 'block';
										break;
					 case "000010" :				gE("store_id").style.display = 'block';
										break;
					 case "111111" :				gE("manager_id").style.display = 'block';
										break;
					 case "011000" :				gE("customs_id").style.display = 'block';
										break;
					 case "other" :					gE("other_id").style.display = 'block';
										break;
				}
	}
	function link2() {		
				hide_all();
				var case1=gE("position").value;
				switch(case1){
					 case "000100" :				gE("pos_id").style.display = 'block';
										break;
					 case "000010" :				gE("store_id").style.display = 'block';
										break;
					 case "111111" :				gE("manager_id").style.display = 'block';
										break;
					 case "011000" :				gE("customs_id").style.display = 'block';
										break;
					 case "other" :					gE("other_id").style.display = 'block';
										break;
				}
	}
	function add_user(){
			location.href("key.php");
	}
	function delete1(list){
			if(list!="1"){
			var result=confirm('�س��ͧ���ź '+list+' �͡�ҡ�ҹ������������� ?');
			if(result){		
				location.href("key.php?id="+list+"&&delete_check=1" );	
				}			
			}
			else{alert('�������öź���ʼ������к��� !');}
	}
	function delete_complete(){
			link2();
			alert('���ź����������ó�');
	}
	function update_confirm(){
			var result=confirm('�׹�ѹ��û�Ѻ��ا������ ?');
			if(result){
				check_alldata();
			}		
	}
	function update_complete(list){
			link2();
			if(list==0){
				alert('��û�Ѻ��ا����������ó�');
			}
			else if(list==1){
				file_check();
			}
	}
    /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
    
    function hide_all() {
        gE("pos_id").style.display = 'none';
        gE("store_id").style.display = 'none';
		gE("manager_id").style.display = 'none';
        gE("customs_id").style.display = 'none';
		gE("other_id").style.display = 'none';
    }
	 function begin1() {
				hide_all();
				gE("other_id").style.display = 'block';
				}
	 function begin2() {
				var case1 = document.form1.position.value;
				hide_all();
				switch(case1){
					 case "000100" :				gE("pos_id").style.display = 'block';
										break;
					 case "000010" :				gE("store_id").style.display = 'block';
										break;
					 case "111111" :		gE("manager_id").style.display = 'block';
										break;
					 case "011000" :			gE("customs_id").style.display = 'block';
										break;
					 case "other" :				gE("other_id").style.display = 'block';
										break;
				}
	 }
    //---------------------------data catch----------------------->\
		
	function check_alldata(){	
		if(gE("user").value==""){
			alert('��سҡ�͡���ʼ�����͹');
		}
		else if(gE("pass1").value==""){
			alert('��سҡ�͡���ʼ�ҹ��͹');
		}
		else if(gE("pass2").value==""){
			alert('��سҡ�͡���ʼ�ҹ��͹');
		}
		else if(!check_pass1()){
			//alert('��سҡ�͡���ʼ�ҹ 6-16 ����ѡ��');
		}
		else if(!check_pass2()){
			//alert("����׹�ѹ���ʼ�ҹ���ç�ѹ");
		}
		else if(gE("name").value==""){
			alert('��سҡ�͡���ͼ�����͹');
		}
		else if(gE("lastname").value==""){
			alert('��سҡ�͡���ʡ�ż�����͹');
		}
		else if(gE("address").value==""){
			alert('��سҡ�͡������������͹');
		}
		else if(gE("email").value!=""){
			if(!check_email()){
			alert("�����ŷ���͡����� Email");	
			}
			else{
				document.form1.submit();
			}
		}
		else{
		document.form1.submit();
		}
	}
function isNumber(inputStr) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
function check_pass1(){
	var pass1 = gE("pass1").value;
	if (pass1.length>5) {
		//done 
		return true;
	} else {
		alert("��سҡ�͡���ʼ�ҹ 6-16 ����ѡ��");
		gE("pass2").focus();
		gE("pass2").select();
		gE("pass1").focus();
		gE("pass1").select();
		return false;
	}
}
function check_pass2(){
	var pass1 = gE("pass1").value;
	var pass2 = gE("pass2").value;
	if (pass1==pass2) {
		//done
		return true;
	} else {
		alert("����׹�ѹ���ʼ�ҹ���ç�ѹ");
		gE("pass1").focus();
		gE("pass1").select();
		gE("pass2").focus();
		gE("pass2").select();
		return false;
	}
}
function check_post() {
	inputStr = gE("post").value;
	if (isNumber(inputStr)) {
		//done
	} else {
		gE("pass1").focus();
		gE("pass1").select();
		gE("post").focus();
		gE("post").select();
	}
}
function check_email() {
	var inputStr=gE("email").value;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar=="@") {	
			return true;

		}
	}
			return false;
}
function check_saraly() {
	inputStr = gE("saraly").value;
	if (isNumber(inputStr)) {
		//done
	} else {
		gE("pass1").focus();
		gE("pass1").select();
		gE("saraly").focus();
		gE("saraly").select();
	}
}
function user_repeated(){ 
		link2();
    	alert("���ʼ�����ӡѹ ��سҡ�͡��������");	
		gE("user").select();
    	//form_repeat.submit();
		gE("pass1").value=gE("pass1_repeat").value;
		gE("pass2").value=gE("pass2_repeat").value;
		gE("name").value=gE("name_repeat").value;
		gE("lastname").value=gE("lastname_repeat").value;
		gE("sex").value=gE("sex_repeat").value;
		gE("address").value=gE("address_repeat").value;
		gE("post").value=gE("post_repeat").value;
		gE("tel1").value=gE("tel1_repeat").value;
		gE("tel2").value=gE("tel2_repeat").value;
		gE("email").value=gE("email_repeat").value;
		gE("position").value=gE("position_repeat").value;
		gE("saraly").value=gE("saraly_repeat").value;
		
}
function file_check(){	
		alert("�к�ʹѺʹع���ʡ����� .GIF ��� .JPG ��ҹ�� ��ҵ�ͧ����Ѻ��Ŵ�ٻ��������Ѻ��ا������ !");	
}
function logout() {
	location.href("menu.php?back=1");
}
    </script>
</head>
<body scroll="no" bgcolor="#6699CC">
   
<?php 
include("fn_mysql.php");
//------------------------------------add status page--------------------------------
	$user_session=$HTTP_SESSION_VARS["user"];
	$find=find_2record("login","page","key","status","1");
		if(!$find){ 
		update_2record("login","username",$user_session,"status","1","page","key");	
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$login_time=$result["hours"].":".$result["minutes"];
		update_2record("login","username",$user_session,"status","1","login_date",$date);
		update_2record("login","username",$user_session,"status","1","login_time",$login_time);
	}
//------------------------------------------------------------------------------------------
$case_form=$HTTP_POST_VARS[case_form];
$position=$HTTP_POST_VARS[position];
$delete_check=$HTTP_GET_VARS[delete_check];
//echo $position;
$emp_id=$HTTP_GET_VARS[id];
//echo $emp_id;
$emp_id2=$HTTP_POST_VARS[id2];
//echo $emp_id2;
//echo $position ; echo "<br />";
$key1=$HTTP_POST_VARS[key1];
//echo $key1;echo "<br />";
$customs1=$HTTP_POST_VARS[customs1];
//echo $customs1;echo "<br />";
$pos1=$HTTP_POST_VARS[pos1];
//echo $pos1;echo "<br />";
$store1=$HTTP_POST_VARS[store1];
//echo $store1;echo "<br />";
$business1=$HTTP_POST_VARS[business1];
//echo $business1;echo "<br />";
$supplier1=$HTTP_POST_VARS[supplier1];
//echo $supplier1;echo "<br />";

$form_send=$HTTP_POST_VARS[form_send];
//echo $form_send;
$user=$HTTP_POST_VARS[user];
$pass1=$HTTP_POST_VARS[pass1];
$pass2=$HTTP_POST_VARS[pass2];
$name=$HTTP_POST_VARS[name];
$lastname=$HTTP_POST_VARS[lastname];
$sex=$HTTP_POST_VARS[sex];
$address=$HTTP_POST_VARS[address];
$post=$HTTP_POST_VARS[post];
$tel1=$HTTP_POST_VARS[tel1];
$tel2=$HTTP_POST_VARS[tel2];
$email=$HTTP_POST_VARS[email];
$saraly=$HTTP_POST_VARS[saraly];
//----------------------------------File upload-------------------------------
$filename=$HTTP_POST_FILES['ufile']['name'];
$path=$HTTP_POST_FILES['ufile']['tmp_name'];
$notype=0;
	if($filename!=""){//--------------��Ǩ�ͺ������͡����ѧ		
			$fp=fopen($path, "r");
			$data=fread($fp, filesize($path));
			fclose($fp);
			$filename=strtolower($filename);
			if(strstr($filename,".gif")){
				$path="picture/".$user.".gif";
				$file=$user.".gif";
				$fp=fopen($path, "w");
				fwrite($fp,$data);
				fclose($fp);
			}
			else if(strstr($filename,".jpg")){
				$path="picture/".$user.".jpg";
				$file=$user.".jpg";
				$fp=fopen($path, "w");
				fwrite($fp,$data);
				fclose($fp);
			}
			else {
					$notype=1;
			}			
	}
//-----------------------------------form repeat-----------------------------
$form_repeat=$HTTP_POST_VARS[form_repeat];
$user_repeat=$HTTP_POST_VARS[user_repeat];
$pass1_repeat=$HTTP_POST_VARS[pass1_repeat];
$pass2_repeat=$HTTP_POST_VARS[pass2_repeat];
$name_repeat=$HTTP_POST_VARS[name_repeat];
$lastname_repeat=$HTTP_POST_VARS[lastname_repeat];
$sex_repeat=$HTTP_POST_VARS[sex_repeat];
$address_repeat=$HTTP_POST_VARS[address_repeat];
$post_repeat=$HTTP_POST_VARS[post_repeat];
$tel1_repeat=$HTTP_POST_VARS[tel1_repeat];
$tel2_repeat=$HTTP_POST_VARS[tel2_repeat];
$email_repeat=$HTTP_POST_VARS[email_repeat];
$position_repeat=$HTTP_POST_VARS[position_repeat];
$saraly_repeat=$HTTP_POST_VARS[saraly_repeat];
if($form_send=="1"){	
		if($position=="other"){ 
			if($key1!="1"){$key1="0";}
			if($customs1!="1"){$customs1="0";}
			if($pos1!="1"){$pos1="0";}
			if($store1!="1"){$store1="0";}
			if($business1!="1"){$business1="0";}		
			if($supplier1!="1"){$supplier1="0";}
			$position=$key1 . $customs1 . $supplier1 . $pos1 . $store1 . $business1 ;		
		}
		$result=find_record("employee","username",$user);
		if(!$result){
		$pass1=md5($pass1);
		insert_to_employee($user,$pass1,$name,$lastname,$sex,$address,$post,$tel1,$tel2,$email,  $position,$saraly,$file);
//-----------------------------Creat file user.txt for member config----------------------
		$fp=fopen("pattern.ini", "r");
		$data=fread($fp, filesize("pattern.ini"));
		fclose($fp);
		$fp=fopen("config\\".$user.".txt", "w");
		fwrite($fp,$data);
		fclose($fp);
//---------------------------------------------------------------------------------------------------
			$result=select_all_record("emp_id","employee");
			$num=mysql_num_rows($result);
			//echo $num;
			$emp_id=mysql_result($result,$num-1,"emp_id");
			$emp_id2=$emp_id;
//----------------------------------------------------Notype worning----------------------------------------------
			if($notype==1){
					?><body onload="update_complete(<?echo $notype;?>);"></body><?
			}
		}
		else{
				?>			
				<form name="form_repeat" action="key.php" method="post">
				<input type="hidden" name="form_repeat" name="form_repeat"value="done" />
				<input type="hidden" name="pass1_repeat" id="pass1_repeat" value="<?echo $pass1;?>"/>
				<input type="hidden" name="pass2_repeat" id="pass2_repeat"  value="<?echo $pass2;?>"/>
				<input type="hidden" name="name_repeat" id="name_repeat" value="<?echo $name;?>"/>
				<input type="hidden" name="lastname_repeat" id="lastname_repeat" value="<?echo $lastname;?>"/>
				<input type="hidden" name="sex_repeat" id="sex_repeat"value="<?echo $sex;?>"/>
				<input type="hidden" name="address_repeat" id="address_repeat"value="<?echo $address;?>"/>
				<input type="hidden" name="post_repeat" id="post_repeat"value="<?echo $post;?>"/>
				<input type="hidden" name="tel1_repeat" id="tel1_repeat"value="<?echo $tel1;?>"/>
				<input type="hidden" name="tel2_repeat" id="tel2_repeat"value="<?echo $tel2;?>"/>
				<input type="hidden" name="email_repeat" id="email_repeat"value="<?echo $email;?>"/>
				<input type="hidden" name="position_repeat" id="position_repeat"value="<?echo $position;?>"/>
				<input type="hidden" name="saraly_repeat" id="saraly_repeat" value="<?echo $saraly;?>"/>
				<body onload="user_repeated();"></body>
				</form>				
				<?
		}
}
else if($form_send=="2"){
		if($position=="other"){ 
			if($key1!="1"){$key1="0";}
			if($customs1!="1"){$customs1="0";}
			if($pos1!="1"){$pos1="0";}
			if($store1!="1"){$store1="0";}
			if($business1!="1"){$business1="0";}	
			if($supplier1!="1"){$supplier1="0";}
			$position=$key1 . $customs1. $supplier1 . $pos1 . $store1 . $business1 ;
		}
		//-------------------------Change var session--------------------------
		$result=select_record("employee","emp_id",$emp_id2);
		$test_user=mysql_result($result,0,"username");
		if($test_user==$user_session){
			$HTTP_SESSION_VARS["user"]=$user;
		}
		if($file==null){
		//---------------------get old name file picture----------------------
		$result=select_record("employee","emp_id",$emp_id2);
		$old_user=mysql_result($result,0,"username");
		$old_file=mysql_result($result,0,"picture");
			if($user!=$old_user && $old_file!=null){
				$path="picture/".$old_file;
				$fp=fopen($path, "r");
				$data=fread($fp, filesize($path));
				fclose($fp);
				//------------------Delete old picture--------------------------------
				unlink($path);
				//----------------------Write new--------------------------------------
				$filename=strtolower($old_file);
				if(strstr($filename,".gif")){
					$path="picture/".$user.".gif";		
					$file=$user.".gif";
					$fp=fopen($path, "w");
					fwrite($fp,$data);
					fclose($fp);
				}
				else if(strstr($filename,".jpg")){
					$path="picture/".$user.".jpg";
					$file=$user.".jpg";
					$fp=fopen($path, "w");
					fwrite($fp,$data);
					fclose($fp);
				}
				else {
						$notype=1;
				}	
				//-----------------------------Creat file user.txt for member config----------------------	
				$fp=fopen("config\\".$old_user.".txt", "r");
				$data=fread($fp, filesize("config\\".$old_user.".txt"));
				fclose($fp);
				$fp=fopen("config\\".$user.".txt", "w");
				fwrite($fp,$data);
				fclose($fp);
				unlink("config\\".$old_user.".txt");
				//---------------------------------------------------------------------------------------------------
			}
			else if($user!=$old_user && $old_file==null){
				$file="";
				//-----------------------------Creat file user.txt for member config----------------------	
				$fp=fopen("config\\".$old_user.".txt", "r");
				$data=fread($fp, filesize("config\\".$old_user.".txt"));
				fclose($fp);
				$fp=fopen("config\\".$user.".txt", "w");
				fwrite($fp,$data);
				fclose($fp);
				unlink("config\\".$old_user.".txt");
				//---------------------------------------------------------------------------------------------------
			}
			else{//if user=old_user
				$result=select_record("employee","username",$user);
				$file=mysql_result($result,0,"picture");
			}
			if(strlen($pass1)==32){
			update_to_employee($emp_id2,$user,$pass1,$name,$lastname,$sex,$address,$post, $tel1, $tel2,$email, $position,$saraly,$file);
			}
			else if(strlen($pass1)<17){
			update_to_employee($emp_id2,$user,md5($pass1),$name,$lastname,$sex,$address,$post, $tel1, $tel2,$email, $position,$saraly,$file);
			}
		}
		else{
			if(strlen($pass1)==32){
			update_to_employee($emp_id2,$user,$pass1,$name,$lastname,$sex,$address,$post, $tel1, $tel2,$email, $position,$saraly,$file);
			}
			else if(strlen($pass1)<17){
			update_to_employee($emp_id2,$user,md5($pass1),$name,$lastname,$sex,$address,$post, $tel1, $tel2,$email, $position,$saraly,$file);
			}
		}
		?><body onload="update_complete(<?echo $notype;?>);"></body><?
		$emp_id=$emp_id2;
}

if($delete_check=="1"){
		if($emp_id!="1"){
//-------------------------------------delete file config----------------------------------------------
		$result=select_record("employee","emp_id",$emp_id);
		$file_name=mysql_result($result,0,"username");
		unlink("config\\".$file_name.".txt");
//--------------------------------------------------------------------------------------------------------
			delete_record("employee","emp_id",$emp_id);
			$sql="DROP TABLE ".$file_name.";";
			$result=mysql_query($sql);
			?><body onload="delete_complete();"></body><?
			$result=select_all_record("emp_id","employee");
			$num=mysql_num_rows($result);
			//echo $num;
			$emp_id=mysql_result($result,$num-1,"emp_id");
			//echo $emp_id;
			$emp_id2=$emp_id;			
		}
		
}
//-----------------------------------------------------------------------------------------
if(!$emp_id){
?>
<!-------------------------------------------form 1------------------------------------>
<form action="key.php" method="post" name="form1" enctype="multipart/form-data">
<center>
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">
	<tr height="40" >
		<td>	
	<input type="hidden" name="form_send" value="1"/>
	<button onclick="check_alldata();"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>
	<button ><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>��������� </center></button>
	<button ><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>
		</td>
		<td align="right">
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="100%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>��������´��ѡ�ҹ</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">
					<tr bgcolor="#FFFFCC">
						<td width="30%">
							&nbsp;���ʼ���� :
						</td>
						<td>
							<input type="text" name="user" value="" maxlength="16" size="" id="user" />
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ʼ�ҹ :
						</td>
						<td>
						<input type="password" name="pass1" value="<?if($form_repeat=="done"){echo $pass1_repeat;}?>" maxlength="16" size="" id="pass1" onchange="check_pass1();"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;�׹�ѹ���� :
						</td>
						<td>
						<input type="password" name="pass2" value="<?if($form_repeat=="done"){echo $pass2_repeat;}?>" maxlength="16" size="" id="pass2" onchange="check_pass2();"/>
						</td>
					</tr>

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���� :
						</td>
						<td>
						<input type="text" name="name" value="<?if($form_repeat=="done"){echo $name_repeat;}?>" maxlength="20" size="" id="name"/>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���ʡ�� :
						</td>
						<td>
						<input type="text" name="lastname" value="<?if($form_repeat=="done"){echo $lastname_repeat;}?>" maxlength="20" size="" id="lastname"/>
						</td>
					</tr>
										
					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;�� :
						</td>
						<td>
						���
						<input type="radio" name="sex" value="man" id="sex1" <?if($form_repeat=="done"&&$sex_repeat=="man"){echo "checked";}else if($form_repeat!="done"){echo "checked";}?>/>
						˭ԧ
						<input type="radio" name="sex" value="women" id="sex2" <?if($form_repeat=="done"&&$sex_repeat=="women"){echo "checked";}?>/>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<input type="text" name="address" value="<?if($form_repeat=="done"){echo $address_repeat;}?>" maxlength="200" size="33" id="address"/>
						</td>
					</tr>
					
					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<input type="text" name="post" value="<?if($form_repeat=="done"){echo $post_repeat;}?>" maxlength="16" size="" id="post" onchange="check_post();"/>
						</td>
					</tr>


					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel1" value="<?if($form_repeat=="done"){echo $tel1_repeat;}?>" maxlength="16" size="" id="tel1"/>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���Ѿ�� :
						</td>
						<td>
							<input type="text" name="tel2" value="<?if($form_repeat=="done"){echo $tel2_repeat;}?>" maxlength="16" size="" id="tel2"/>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<input type="text" name="email" value="<?if($form_repeat=="done"){echo $email_repeat;}?>" maxlength="100" size="" id="email" />
						</td>
					</tr>

					<tr bgcolor="#FFFFFF" height="1">
						<td>
					
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#00CCCC">
						<td>
							&nbsp;���˹� :
						</td>
						<td>
							
							<select name="position" onchange="link(this);" id="position"> 
								<option value="other">��˹��ͧ</option>
								<option value="000100" <?if($form_repeat=="done"&&$position_repeat=="000100"){echo "selected";}?>>��ѡ�ҹ���˹����ҹ
								</option>
								<option value="000010" <?if($form_repeat=="done"&&$position_repeat=="000010"){echo "selected";}?>>��ѡ�ҹ���Ť�ѧ�Թ���
								</option>
								<option value="111111" <?if($form_repeat=="done"&&$position_repeat=="111111"){echo "selected";}?>>���Ѵ�����ҹ
								</option>
								<option value="011000" <?if($form_repeat=="done"&&$position_repeat=="011000"){echo "selected";}?>>��ѡ�ҹ�����١���
								</option>					
							</select>
						</td>
					</tr>
					
					<tr bgcolor="#00CCCC">
						<td>
							&nbsp;�Թ��͹:
						</td>
						<td>
							<input type="text" name="saraly" value="<?if($form_repeat=="done"){echo $saraly_repeat;}?>" maxlength="16" size="" id="saraly" onchange="check_saraly();"/>
						</td>
					</tr>
					
					<tr bgcolor="#00CCCC">
						<td>
						 &nbsp;�ٻ����:
						</td>
						<td>
						<input type="file" name="ufile"  size="25" />
						</td>
					</tr>
				</table>
			</td>	
			</tr>
		</table>

</td>
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
			<tr height="80%">
			<td >
				<iframe height="100%" width="100%" src="iframe1.php" name="iframe1">
				</iframe>
			</td>
			</tr>
			<tr height="20%">
			<td >		
					<fieldset id="pos_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ���˹����ҹ</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"checked  disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1"  disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"   disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"   disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1" disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>

					<fieldset id="store_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ���Ť�ѧ�Թ���</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1" disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1"  disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"   disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"   disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>

					<fieldset id="manager_id">
					<legend>
						<center><font color="#FFFFFF"><b>���Ѵ�����ҹ</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1" checked disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"checked  disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1" checked disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"  checked disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>

					<fieldset id="customs_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ�����١���</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"  disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1" checked disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"   disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"   disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>

					<fieldset id="other_id">
					<legend>
						<center><font color="#FFFFFF"><b>�Է�������Ҷ֧Ẻ��˹��ͧ</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"  />�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1"  />�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"  />�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1" />�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
			</td>
			</tr>
		</table>
	</td>
	</tr>
</table>
</center>
<body onload="begin1(),init()"></body>
</form>
<!-------------------------------------------end form 1------------------------------------>
<?}?>

<?php 
if($emp_id){
?>
<!-------------------------------------------form 2------------------------------------>
<form action="key.php" method="post" name="form1" enctype="multipart/form-data">
<center >
<table width="757" height="535" border="0" cellspacing="0" cellpadding="4" bgcolor="#6699CC">
	<tr height="40" >
		<td>
	<button onclick="update_confirm();"><center><img src="image/ok/ok.gif" height="22"align="left" hspace="0"/>��ŧ&nbsp;</center></button>
	<button onclick="add_user();"><center><img src="image/adduser/adduser.gif" height="22"align="left" hspace="0"/>��������� </center></button>
	<button onclick="delete1(<?echo $emp_id;?>);"><center><img src="image/delete/delete.gif" height="22"align="left" hspace="0"/>&nbsp;ź&nbsp;&nbsp;</center></button>

	<input type="hidden" name="form_send" value="2"/>
	<input type="hidden" name="id2" value="<?echo $emp_id; ?>"/>		
		</td>
		<td align="right">
		<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'" onclick="logout();" /> 
		</td>
	</tr>

	<tr height="95%">
	<td width="50%">
		<table width="100%" height="100%" border="1" cellspacing="0" cellpadding="1">
			<tr height="20" bgcolor="#6699CC">
			<td>
				<center><font color="#FFFFFF"><b>��������´��ѡ�ҹ</b></font></center>
			</td>
			
			</tr>
			<tr>
			<td>
			
				 <table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">
					<tr bgcolor="#FFFFCC">
						<td width="30%">
							&nbsp;���ʼ���� :
						</td>
						<td>
						<?
							$result=select_record("employee","emp_id",$emp_id);
							$data=mysql_result($result,0,"username");
							echo "<input type=\"text\" name=\"user\" value=\"".$data."\" id=user maxlength=16/>";
						?>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;���ʼ�ҹ :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"password");
							echo "<input type=\"password\" name=\"pass1\" value=\"".$data."\" id=pass1 maxlength=16/>";
						?>
						</td>
					</tr>

					<tr bgcolor="#FFFFCC">
						<td>
							&nbsp;�׹�ѹ���� :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"password");
							echo "<input type=\"password\" name=\"pass2\" value=\"".$data."\" id=pass2 maxlength=16/>";
						?>
						</td>
					</tr>

					<tr bgcolor="#FFFFFF" height="1">
						<td>
							
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���� :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"name");
							echo "<input type=\"text\" name=\"name\" value=\"".$data."\" id=name maxlength=20/>";
						?>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���ʡ�� :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"lastname");
							echo "<input type=\"text\" name=\"lastname\" value=\"".$data."\" id=lastname maxlength=20/>";
						?>
						</td>
					</tr>
										
					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;�� :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"sex");	
					        if($data=="man"){
								?>
							���
							<input type="radio" name="sex" value="man" checked id="sex1"/>
							˭ԧ
							<input type="radio" name="sex" value="women" id="sex2"/>
								<?
							}
							else if($data=="women"){
								?>
							���
							<input type="radio" name="sex" value="man" id="sex1"/>
							˭ԧ
							<input type="radio" name="sex" value="women" checked id="sex2"/>
								<?
							}
								else{
								?>
							���
							<input type="radio" name="sex" value="man" id="sex1"/>
							˭ԧ
							<input type="radio" name="sex" value="women" id="sex2"/>
								<?
							}
						?>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;������� :
						</td>
						<td>
						<?
							$data=mysql_result($result,0,"address");
							echo "<input type=\"text\" name=\"address\" value=\"".$data."\" size=\"33\" id=address maxlength=200/>";
						?>
						</td>
					</tr>
					
					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;������ɳ���:
						</td>
						<td>
							<?
							$data=mysql_result($result,0,"post");
							echo "<input type=\"text\" name=\"post\" value=\"".$data."\" id=post maxlength=16/>";
							?>
						</td>
					</tr>


					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���Ѿ��1:
						</td>
						<td>
							<?
							$data=mysql_result($result,0,"tel1");
							echo "<input type=\"text\" name=\"tel1\" value=\"".$data."\" id=tel1 maxlength=16/>";
							?>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;���Ѿ��2:
						</td>
						<td>
							<?
							$data=mysql_result($result,0,"tel2");
							echo "<input type=\"text\" name=\"tel2\" value=\"".$data."\" id=tel2 maxlength=16/>";
							?>
						</td>
					</tr>

					<tr bgcolor="#99CCFF">
						<td>
							&nbsp;Email :
						</td>
						<td>
							<?
							$data=mysql_result($result,0,"email");
							echo "<input type=\"text\" name=\"email\" value=\"".$data."\" id=email maxlength=100/>";
							?>
						</td>
					</tr>

					<tr bgcolor="#FFFFFF" height="1">
						<td>
					
						</td>
						<td>
						
						</td>
					</tr>

					<tr bgcolor="#00CCCC">
						<td>
							&nbsp;���˹� :
						</td>
						<td>
								<?
							$data=mysql_result($result,0,"position");
							
								if($emp_id=="1"){
									?>
									<select name="position" id="position"> 
									<option value="000100">��ѡ�ҹ���˹����ҹ</option>
									<option value="000010">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111" selected="selected">���Ѵ�����ҹ</option>
									<option value="011000">��ѡ�ҹ�����١���</option>
									<option value="other">��˹��ͧ</option>
									</select>
									<?
								}
								else if($data=="111111"){
									?>
									<select name="position" onchange="link(this);" id="position"> 
									<option value="000100">��ѡ�ҹ���˹����ҹ</option>
									<option value="000010">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111" selected="selected">���Ѵ�����ҹ</option>
									<option value="011000">��ѡ�ҹ�����١���</option>
									<option value="other">��˹��ͧ</option>
									</select>
									<?
								}
								else if($data=="011000"){
									?>
									<select name="position" onchange="link(this);" id="position"> 
									<option value="000100">��ѡ�ҹ���˹����ҹ</option>
									<option value="000010">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111">���Ѵ�����ҹ</option>
									<option value="011000" selected="selected">��ѡ�ҹ�����١���</option>
									<option value="other">��˹��ͧ</option>
									</select>
									<?
								}
								else if($data=="000100"){
									?>
									<select name="position" onchange="link(this);" id="position"> 
									<option value="000100" selected="selected">��ѡ�ҹ˹����ҹ</option>
									<option value="000010">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111">���Ѵ�����ҹ</option>
									<option value="011000" >��ѡ�ҹ�����١���</option>
									<option value="other">��˹��ͧ</option>
									</select>
									<?
								}
								else if($data=="000010"){
									?>
									<select name="position" onchange="link(this);" id="position"> 
									<option value="000100">��ѡ�ҹ˹����ҹ</option>
									<option value="000010" selected="selected">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111">���Ѵ�����ҹ</option>
									<option value="011000" >��ѡ�ҹ�����١���</option>
									<option value="other">��˹��ͧ</option>
									</select>
									<?
								}
								else {
									?>
									<select name="position" onchange="link(this);" id="position"> 
									<option value="000100">��ѡ�ҹ˹����ҹ</option>
									<option value="000010">��ѡ�ҹ���Ť�ѧ�Թ���</option>
									<option value="111111">���Ѵ�����ҹ</option>
									<option value="011000">��ѡ�ҹ�����١���</option>
									<option value="other" selected="selected">��˹��ͧ</option>
									</select>
									<?
								}						
								?>
						</td>
					</tr>

					<tr bgcolor="#00CCCC">
						<td>
							&nbsp;�Թ��͹:
						</td>
						<td>
							<?
							$data2=mysql_result($result,0,"saraly");
							echo "<input type=\"text\" name=\"saraly\" value=\"".$data2."\" id=saraly maxlength=16/>";
							?>
						</td>
					</tr>
					<tr bgcolor="#00CCCC">
						<td>
						 &nbsp;�ٻ����:
						</td>
						<td>
						<?
							$result=select_record("employee","emp_id",$emp_id);
							$pic=mysql_result($result,0,"picture");	
						?>
						<input type="file" name="ufile"  id="ufile"  size="25" />
						<?if($pic!=null){?>
						<input type="text" name="ufile_show" value="C:\wwwroot\picture\<?echo $pic;?>" id="ufile_show"  size="25" disabled /> <font color="#408080">�ٻ���</font>
						<?}else{?>
						<input type="text" name="ufile_show" value="No picture" id="ufile_show"  size="25" disabled /> <font color="#408080">�ٻ���</font>
						<?}?>
						</td>
					</tr>
				</table>
			</td>	
			</tr>
		</table>

	</td>
	<td width="50%">
		<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
			<tr height="80%">
			<td >
				<iframe height="100%" width="100%" src="iframe1.php?id=<?echo $emp_id;?>" name="iframe1">
				</iframe>
			</td>
			</tr>
			<tr height="20%">
			<td >
					<fieldset id="pos_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ���˹����ҹ</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"  checked disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1"  disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="supplier1" value="1"   disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"   disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
				
					<fieldset id="store_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ���Ť�ѧ�Թ���</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"   disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1"  disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="store1" value="1"  checked disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"   disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
				
					<fieldset id="manager_id">
					<legend>
						<center><font color="#FFFFFF"><b>���Ѵ�����ҹ</b></font></center>
					</legend>
					<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1" checked disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"  checked disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1" checked disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="store1" value="1"  checked disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"  checked disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
				
					<fieldset id="customs_id">
					<legend>
						<center><font color="#FFFFFF"><b>��ѡ�ҹ�����١���</b></font></center>
					</legend>
						<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1"  disabled/>�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"   disabled/>�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1" checked disabled/>�������١���
						</td>
						<td>
						<input type="checkbox" name="store1" value="1"   disabled/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  checked disabled/>�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1" disabled/>�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
				
					<fieldset id="other_id">
					<legend>
						<center><font color="#FFFFFF"><b>�Է�������Ҷ֧Ẻ��˹��ͧ</b></font></center>
					</legend>
					<table>
					 <tr>
						<td>
						<input type="checkbox" name="key1"  value="1" <? if($data{0}==1){echo " checked";}?> />�к���˹��Է�������Ҷ֧
						</td>
						<td>
						<input type="checkbox" name="pos1" value="1"  <? if($data{3}==1){echo " checked";}?> />�к����˹����ҹ<br />   
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="customs1"  value="1" <? if($data{1}==1){echo " checked";}?> />�������١���
						</td>
						<td>
						<input type="checkbox" name="store1" value="1"  <? if($data{4}==1){echo " checked";}?>/>�к���ѧ�Թ���
						</td>
					 </tr>
					 <tr>
						<td>
						<input type="checkbox" name="supplier1" value="1"  <? if($data{2}==1){echo " checked";}?> />�����ż��Ѵ��˹���
						</td>
						<td>
						<input type="checkbox" name="business1" value="1"  <? if($data{5}==1){echo " checked";}?> />�к���������
						</td>
					 </tr>
					</table>
					</fieldset>
				
			</td>
			</tr>
		</table>
	</td>
	</tr>
</table>
</center>
<body onload="begin2(),init()"></body>
</form>
<!-------------------------------------------end form 2------------------------------------>
<?}?>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
