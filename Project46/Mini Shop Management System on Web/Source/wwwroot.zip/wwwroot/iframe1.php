<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<SCRIPT LANGUAGE="JavaScript">
	function tab(list){
		if(list!=0&&check_see==0){
		parent.location.href("key.php?id="+list );
		}
	}
var prefsDlog;
var check_see=0;
function see(list) {
		check_see=1;
		if (!prefsDlog || prefsDlog.closed) {
				prefsDlog = showModelessDialog("picture.php?id="+list, setPrefs, "dialogWidth:210%; dialogHeight:210%;dialogLeft:590% ; dialogTop:160%;status=no")
		}
}
function setPrefs(list){
	if(list=='closed'){
		check_see=0;
	}
}

</SCRIPT>
</HEAD>

<BODY bgcolor="#99CCCC">
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#FFFFFF">
<tr  height="1" bgcolor="#9999CC">
<td>
	<center><font color="#FFFFFF">�ӴѺ</font></center>
</td>
<td>
	<center><font color="#FFFFFF">���ʼ����</font></center>
</td>
<td>
	<center><font color="#FFFFFF">����-���ʡ��</font></center>
</td>
<td>
	<center><font color="#FFFFFF">�ٻ</font></center>
</td>
</tr >
<!-------------------------------begin-------------------------------------->
<?php
	include("fn_mysql.php");
	connect_mysql("db_admin");//function
	$sql="SELECT * FROM employee;";
	$result=mysql_query($sql);
	$emp_id=$HTTP_GET_VARS[id];
	//echo $emp_id;
 while($dbarr=mysql_fetch_array($result)){
?>
<tr  height="1" <? if($dbarr["emp_id"]==$emp_id){if($dbarr["emp_id"]=="1"){echo "bgcolor=\"#FF6600\"";$yello=$dbarr["emp_id"];}else{echo "bgcolor=\"#FFFF00\"";$yello=$dbarr["emp_id"];}}else{echo "bgcolor=\"#eeeeee\"";}?>
onclick="tab(<?
if($dbarr["emp_id"]!=$yello){
$data=$dbarr["emp_id"];
echo "'".$data."'";}
else{
	$data="0";
	echo "'".$data."'";
 }
?>)
">
<td>
	<center>
	  <?echo $dbarr["emp_id"];?>
	</center>
</td>
<td>
	<center>
	<?echo $dbarr["username"];?>
	</center>
</td>
<td>
	<center>
	<?echo $dbarr["name"];
		echo " ";
		echo $dbarr["lastname"];
	?>
	</center>
</td>
<td>
	<center>
     <img border="0" src="image/picture/picture1.gif" alt="�͡�ҡ�к�" width="16" height="18" onmouseover="this.src='image/picture/picture2.gif'" onmouseout="this.src='image/picture/picture1.gif'" 	onclick="see(<?echo $dbarr["emp_id"];?>);" /> 
	</center>
</td>
</tr >
<?}?>
<!-------------------------------end------------------------------------>
<tr >
<td>
	
</td>
<td>
	
</td>
<td>
	
</td>
</tr >


</table>
</BODY>
</HTML>
