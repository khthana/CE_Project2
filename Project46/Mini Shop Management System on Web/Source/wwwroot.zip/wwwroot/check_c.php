<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE> </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
function init(list) {	
		var returnFunc = window.dialogArguments
		returnFunc(list);
		window.close();
}

</SCRIPT>
</HEAD>
<?
	$c_id=$HTTP_GET_VARS[c_id];
	$bool=find_record("customer","cust_id",$c_id);
		if($bool){
			$find=1;
		}
		else{
			$find=0;
		}
?>
<BODY onload="init(<?echo $find;?>);">

</BODY>
</HTML>
