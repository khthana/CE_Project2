<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Login page </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<TITLE>Keyboard Event Handler Lab</TITLE>
</head>
<html>
<body onload="init()" scroll="no" background="xp4.jpg" >
<?php							
			$back=$HTTP_GET_VARS[back];									
			if($back!=null){
			$user=$HTTP_SESSION_VARS["user"];
			include("fn_mysql.php");
			//---------------------------Delete temp table from POS--------------------------
			if($back==99){
				connect_mysql("db_admin");//function
				$sql="DROP TABLE $user";
				$result=mysql_query($sql);
			}
			//---------------------------record logout time----------------------------------------	
			$result=getdate();
			$year=$result["year"]+543;
			$date=$result["mday"]."/".$result["mon"]."/".$year;
			$logout_time=$result["hours"].":".$result["minutes"];
			update_2record("login","username",$user,"status","1","logout_date",$date);
			update_2record("login","username",$user,"status","1","logout_time",$logout_time);
			update_2record("login","username",$user,"status","1","session_number","");
			update_2record("login","username",$user,"status","1","status","0");

				//---------------------------add login table------------------------
			$result=getdate();
			$year=$result["year"]+543;
			$date=$result["mday"]."/".$result["mon"]."/".$year;
			$login_time=$result["hours"].":".$result["minutes"];
			insert_to_login("login",$user,$date,$login_time,"","","","1",session_id());
										
										$result=select_record("employee","username",$user);
										$pos1=mysql_result($result,0,"position");
									}
									else{
										//update_2record("login","username",$user,"status","0","status","1");
										$result=select_record("employee","username",$user);
										$pos1=mysql_result($result,0,"position");
									}
									
									$count=0;
										for($i=0;$i<=5;$i++){
											if($pos1{$i}==1){$count++; $done[$i]="1";}
										}
			                            //echo $done[0];
										echo "<form name=\"mm\">";
										echo "<input type=\"hidden\" name=\"num_count\" value=$count>";
										echo "<input type=\"hidden\" name=\"pos1\" value=$done[0] >";
										echo "<input type=\"hidden\" name=\"pos2\" value=$done[1] >";
										echo "<input type=\"hidden\" name=\"pos3\" value=$done[2]>";
										echo "<input type=\"hidden\" name=\"pos4\" value=$done[3]>";
										echo "<input type=\"hidden\" name=\"pos5\" value=$done[4].>";
										echo "<input type=\"hidden\" name=\"pos6\" value=$done[5]>";
										echo "</form>"	;
	//------------------------------------add status page--------------------------------	
	update_2record("login","username",$user,"status","1","page","menu");
	//------------------------------------------------------------------------------------------
														
?>		
<script type="text/javascript">
function init(){
	 delaymenu();
	 Now();
	 init2();
}
//-----------------------------------------------------------
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 

//----------------------------------------------------Show day-----------------------------------------------
                       var day,date,month,year,hour,minute,second,today;  //���ҧ�������������ʵ���Ţ�ͧ�ѹ����
                              var dayString=new Array();
                              dayString[0]="�ҷԵ��";dayString[1]="�ѹ���";dayString[2]="�ѧ���";dayString[3]="�ظ";
                              dayString[4]="����ʺ��";dayString[5]="�ء��";dayString[6]="�����";
                              var monthString=new Array();
                              monthString[0]="���Ҥ�"; monthString[1]="����Ҿѹ��"; monthString[2]="�չҤ�"; monthString[3]="����¹";
                              monthString[4]="����Ҥ�"; monthString[5]="�Զع�¹"; monthString[6]="�á�Ҥ�"; monthString[7]="�ԧ�Ҥ�";
                              monthString[8]="�ѹ��¹"; monthString[9]="���Ҥ�"; monthString[10]="��Ȩԡ�¹"; monthString[11]="�ѹ�Ҥ�";      
                     //����ŧ�����Ǩ�ͺ�Թ�硫�����������˹��¤����Ӣͧ�к��ҡ��� ����¹���������鹡��ҡ�������͹� if ���� case
                      var DateTime;
                      function Now() 
                         {    DateTime=new Date(); //���ҧ�ѵ�� (object) �Դ��͡Ѻ�ѹ���Ңͧ�к���Ժѵԡ�� (OS)
                              day=DateTime.getDay(); 
                              date=DateTime.getDate(); 
                              month=DateTime.getMonth();
                              year=DateTime.getYear();
                              hour=DateTime.getHours();
                              minute=DateTime.getMinutes();
                              second=DateTime.getSeconds();    
                         today=dayString[day]+" "+date+" "+monthString[month]+" "+(year+543);
							 var today2=hour+":"+minute+":"+second;
                             document.title=today; //�ʴ��͡�ҧ����ź���
                             window.status=today;//�ʴ��͡�ҧᶺʶҹ�
                            gE("FNT2").innerText=today2; gE("FNT").innerText=today;//�ʴ��͡�ҧ���ྨ�ç���˹� ID=TXT ੾�� IE
                             setTimeout("Now()",1*1000); //��˹�����Ѿഷ���ҷء 1 �Թҷ�
                         }                
//--------------------------------------Closed window----------------------------------------------------------
//------------------------------------------Section menu---------------------------------------------------------
var count=1;
var num_count=document.mm.num_count.value;
num_count++;
num_count++;
var pos1=document.mm.pos1.value;
var pos2=document.mm.pos2.value;
var pos3=document.mm.pos3.value;
var pos4=document.mm.pos4.value;
var pos5=document.mm.pos5.value;
var pos6=document.mm.pos6.value;
var pos7=1;
var tpos1=pos1;
var tpos2=pos2;
var tpos3=pos3;
var tpos4=pos4;
var tpos5=pos5;
var tpos6=pos6;
var tpos7=1;
function show_tab1(){gE('tab1').style.display = 'block';gE('tab12').style.display = 'block';}
function show_tab2(){gE('tab2').style.display = 'block';gE('tab22').style.display = 'block';}
function show_tab3(){gE('tab3').style.display = 'block';gE('tab32').style.display = 'block';}
function show_tab4(){gE('tab4').style.display = 'block';gE('tab42').style.display = 'block';}
function show_tab5(){gE('tab5').style.display = 'block';gE('tab52').style.display = 'block';}
function show_tab6(){gE('tab6').style.display = 'block';gE('tab62').style.display = 'block';}
function show_tab7(){gE('tab7').style.display = 'block';gE('tab72').style.display = 'block';}
function delaymenu(){
	if(pos1==1){gE("tab1").style.display = 'none';gE("tab12").style.display = 'none';}
	if(pos2==1){gE("tab2").style.display = 'none';gE("tab22").style.display = 'none';}
	if(pos3==1){gE("tab3").style.display = 'none';gE("tab32").style.display = 'none';}
	if(pos4==1){gE("tab4").style.display = 'none';gE("tab42").style.display = 'none';}
	if(pos5==1){gE("tab5").style.display = 'none';gE("tab52").style.display = 'none';}
	if(pos6==1){gE("tab6").style.display = 'none';gE("tab62").style.display = 'none';}
	if(pos7==1){gE("tab7").style.display = 'none';gE("tab72").style.display = 'none';}

		var begin=1;
		var add=100;
	    if(pos4==1){setTimeout("show_tab4();",begin);begin=begin+add;}
		if(pos3==1){setTimeout("show_tab3();",begin);begin=begin+add;}
		if(pos5==1){setTimeout("show_tab5();",begin);begin=begin+add;}
		if(pos2==1){setTimeout("show_tab2();",begin);begin=begin+add;}
		if(pos6==1){setTimeout("show_tab6();",begin);begin=begin+add;}
		if(pos1==1){setTimeout("show_tab1();",begin);begin=begin+add;}	
		if(pos7==1){setTimeout("show_tab7();",begin);begin=begin+add;}
}
function init2() {	
		document.onkeyup = showKeyUp
		var n=11;
		while(n<18){
						if(pos1==1){pos1=n;}
				else if(pos2==1){ pos2=n;}
				else if(pos3==1){ pos3=n;}
				else if(pos4==1){ pos4=n;}
				else if(pos5==1){ pos5=n;}
				else if(pos6==1){ pos6=n;}
				else if(pos7==1){ pos7=n;}
				n++;
		}
		write_tab();
}
function clear_font(){
	if(tpos1==1){ document.getElementById("ftab1").style.color = "#FFFFFF"; }
	if(tpos2==1){ document.getElementById("ftab2").style.color = "#FFFFFF"; }
	if(tpos3==1){ document.getElementById("ftab3").style.color = "#FFFFFF"; }
	if(tpos4==1){ document.getElementById("ftab4").style.color = "#FFFFFF"; }
	if(tpos5==1){ document.getElementById("ftab5").style.color = "#FFFFFF"; }
	if(tpos6==1){ document.getElementById("ftab6").style.color = "#FFFFFF"; }
	if(tpos7==1){ document.getElementById("ftab7").style.color = "#FFFFFF"; }
}
function write_tab(){
	m=count+10;
						if(pos1==m){clear_tab();clear_font();
						document.getElementById("tab1").background  ="tab.jpg";
						document.getElementById("tab12").background  ="tab.jpg";
						document.getElementById("ftab1").style.color = "#FFFF00";
						}
				else if(pos2==m){ clear_tab();clear_font();
						document.getElementById("tab2").background  ="tab.jpg";
						document.getElementById("tab22").background  ="tab.jpg";
						document.getElementById("ftab2").style.color = "#FFFF00";
						}
				else if(pos3==m){ clear_tab();clear_font();
						document.getElementById("tab3").background  ="tab.jpg";
						document.getElementById("tab32").background  ="tab.jpg";
						document.getElementById("ftab3").style.color = "#FFFF00";
				}
				else if(pos4==m){ clear_tab();clear_font();
						document.getElementById("tab4").background  ="tab.jpg";
						document.getElementById("tab42").background  ="tab.jpg";
						document.getElementById("ftab4").style.color = "#FFFF00";
						}
				else if(pos5==m){ clear_tab();clear_font();
						document.getElementById("tab5").background  ="tab.jpg";
						document.getElementById("tab52").background  ="tab.jpg";
						document.getElementById("ftab5").style.color = "#FFFF00";
						}
				else if(pos6==m){ clear_tab();clear_font();
						document.getElementById("tab6").background  ="tab.jpg";
						document.getElementById("tab62").background  ="tab.jpg";
						document.getElementById("ftab6").style.color = "#FFFF00";
						}
				else if(pos7==m){ clear_tab();clear_font();
						document.getElementById("tab7").background  ="tab.jpg";
						document.getElementById("tab72").background  ="tab.jpg";
						document.getElementById("ftab7").style.color = "#FFFF00";
						}
}

function link(){
		if(pos1==count+10){location.href("key.php");}
		else if(pos2==count+10){location.href("customs.php");}
		else if(pos3==count+10){location.href("supplier.php");}
		else if(pos4==count+10){location.href("pos.php");}
		else if(pos5==count+10){location.href("store.php?menu=1");}
		else if(pos6==count+10){location.href("business.php");}
		else if(pos7==count+10){location.href("config.php");}		
}
function showKeyUp(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
		if(i==27){
			var result=confirm('�س��㨷����͡�ҡ�к�');
				if(result){	
					logout();
				}
		}
		if(i==13){
			switch(count){
				case 1: link();
					break;
				case 2: link();
					break;
				case 3:link();
					break;
				case 4: link();
					break;
				case 5: link();
					break;
				case 6: link();
					break;
				case 7: link();
					break;
			}
		}
	if(i==98 || i==40){
				count++;		
				if(count==num_count){count=1;}
	}
		
	if(i==104 || i==38){
				count--;
				if(count==0){count=num_count-1;}
	}
	write_tab();
	
}//end
	
	function clear_tab(){
		if(tpos1==1){
		document.getElementById("tab1").background  ="";
		document.getElementById("tab12").background  ="";
		}
		if(tpos2==1){
		document.getElementById("tab2").background  ="";
		document.getElementById("tab22").background  ="";
		}
		if(tpos3==1){
		document.getElementById("tab3").background  ="";
		document.getElementById("tab32").background  ="";
		}
		if(tpos4==1){
		document.getElementById("tab4").background  ="";
		document.getElementById("tab42").background  ="";
		}
		if(tpos5==1){
		document.getElementById("tab5").background  ="";
		document.getElementById("tab52").background  ="";
		}
		if(tpos6==1){
		document.getElementById("tab6").background  ="";
		document.getElementById("tab62").background  ="";
		}
		if(tpos7==1){
		document.getElementById("tab7").background  ="";
		document.getElementById("tab72").background  ="";
		}
	}
	function tab1(){
		clear_tab(); 
		clear_font();
		if(pos1==11){count=1;}
		else if(pos1==12){count=2;}
		else if(pos1==13){count=3;}
		else if(pos1==14){count=4;}
		else if(pos1==15){count=5;}
		else if(pos1==16){count=6;}
		else if(pos1==17){count=7;}
		document.getElementById("tab1").background  ="tab.jpg";
		document.getElementById("tab12").background  ="tab.jpg";
		document.getElementById("ftab1").style.color = "#FFFF00";
	}
	function tab2(){
		clear_tab(); 
		clear_font();
		if(pos2==11){count=1;}
		else if(pos2==12){count=2;}
		else if(pos2==13){count=3;}
		else if(pos2==14){count=4;}
		else if(pos2==15){count=5;}
		else if(pos2==16){count=6;}
		else if(pos2==17){count=7;}
		document.getElementById("tab2").background  ="tab.jpg";
		document.getElementById("tab22").background  ="tab.jpg";
		document.getElementById("ftab2").style.color = "#FFFF00";
	}
	function tab3(){
		clear_tab();
		clear_font();
		if(pos3==11){count=1;}
		else if(pos3==12){count=2;}
		else if(pos3==13){count=3;}
		else if(pos3==14){count=4;}
		else if(pos3==15){count=5;}
		else if(pos3==16){count=6;}
		else if(pos3==17){count=7;}
		document.getElementById("tab3").background  ="tab.jpg";
		document.getElementById("tab32").background  ="tab.jpg";
		document.getElementById("ftab3").style.color = "#FFFF00";
	}
	function tab4(){
		clear_tab();
		clear_font();
		if(pos4==11){count=1;}
		else if(pos4==12){count=2;}
		else if(pos4==13){count=3;}
		else if(pos4==14){count=4;}
		else if(pos4==15){count=5;}
		else if(pos4==16){count=6;}
		else if(pos4==17){count=7;}
		document.getElementById("tab4").background  ="tab.jpg";
		document.getElementById("tab42").background  ="tab.jpg";
		document.getElementById("ftab4").style.color = "#FFFF00";
	}
	function tab5(){
		clear_tab(); 
		clear_font();
		if(pos2==11){count=1;}
		else if(pos5==12){count=2;}
		else if(pos5==13){count=3;}
		else if(pos5==14){count=4;}
		else if(pos5==15){count=5;}
		else if(pos5==16){count=6;}
		else if(pos5==17){count=7;}
		document.getElementById("tab5").background  ="tab.jpg";
		document.getElementById("tab52").background  ="tab.jpg";
		document.getElementById("ftab5").style.color = "#FFFF00";
	}
	function tab6(){
		clear_tab();
		clear_font();
		if(pos2==11){count=1;}
		else if(pos6==12){count=2;}
		else if(pos6==13){count=3;}
		else if(pos6==14){count=4;}
		else if(pos6==15){count=5;}
		else if(pos6==16){count=6;}
		else if(pos6==17){count=7;}
		document.getElementById("tab6").background  ="tab.jpg";
		document.getElementById("tab62").background  ="tab.jpg";
		document.getElementById("ftab6").style.color = "#FFFF00";
	}
	function tab7(){
		clear_tab();
		clear_font();
		if(pos7==11){count=1;}
		else if(pos7==12){count=2;}
		else if(pos7==13){count=3;}
		else if(pos7==14){count=4;}
		else if(pos7==15){count=5;}
		else if(pos7==16){count=6;}
		else if(pos7==17){count=7;}
		document.getElementById("tab7").background  ="tab.jpg";
		document.getElementById("tab72").background  ="tab.jpg";
		document.getElementById("ftab7").style.color = "#FFFF00";
	}
//---------------------------------------------------------------------------------------------------
	function tab1d(){
		location.href("key.php");
	}
	function tab2d(){
		location.href("customs.php");
	}
	function tab3d(){
		location.href("supplier.php");
	}
	function tab4d(){
		location.href("pos.php");
	}
	function tab5d(){
		location.href("store.php?menu=1");
	}
	function tab6d(){
		location.href("business.php");
	}
	function tab7d(){
		location.href("config.php");
	}
//---------------------------------------Logout--------------------------------
function logout() {
	location.href("login.php?back=menu");
}
</script>

<center>
<form method="post" action="login.php">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"  >
	<tr height="40%"><td>&nbsp;</td></tr>
    <tr>
	<td align="center" background="xp4.jpg">
		<table width="50%" height="20%" border="0" cellspacing="0" cellpadding="0" frame="box" 2rules="none"  style="border-collapse: collapse;">
		<tr width="60%">
		<td>
			&nbsp;
		</td>
		<td >
			&nbsp;
		</td>
		</tr>

		<tr>
		<td width="48%">								 			
			 <?$type=getconfig("config","14:logotype");
			 $shop_name=getconfig("config","13:shop_name");?>
			<img src="<?echo "logo.".$type;?>" width="34" height="34"/>
			  <font size="+3" color="#FFFF00" ><b>��ҹ<b></font>
			  <font size="+3" color="#FFFFFF" ><?echo $shop_name;?></font>
			  <br /><br /> 
			 
			  &nbsp;&nbsp;&nbsp;&nbsp;
			  <font size="+2" color="#FFFF99" >���ʴդس </font>
			  <?
					$result=select_record("employee","username",$user);
					$name=mysql_result($result,0,"name");
					$lastname=mysql_result($result,0,"lastname");
			  ?>
			  <font size="+2" color="#FFFFFF" ><?echo $name;?>&nbsp;&nbsp;</font>			   		
		</td>
		<td rowspan="3" >
<!----------------menu begin--------------------->
		<table width="100%" height="1" border="0" cellspacing="0" cellpadding="2" >
						<tbody>
				<tr height="1">
						<td >
							&nbsp;
						</td>
				</tr>
					<?if($done[0]=="1"){?>
						<tr height="1" onmouseover="tab1();" ondblclick="tab1d();">
							<td height="1"  id="tab1">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr height="1">
										<td height="1">										
										<center><img  src="image\key\key.jpg" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>

							<td width="80%"  id="tab12">
							&nbsp;<font color="#FFFFFF" size="+1"   id="ftab1">��˹��Է���</font>
							</td>
						</tr>
					<?}?>

					<?if($done[1]=="1"){?>
						<tr height="1" onmouseover="tab2();" ondblclick="tab2d();">
							<td height="1" id="tab2">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr height="1">
										<td height="1">
										<center><img  src="image\user\users.gif" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%"  id="tab22">
							&nbsp;<font color="#FFFFFF" size="+1"  id="ftab2">�������١���</font>
							</td>
						</tr>
					<?}?>

					<?if($done[2]=="1"){?>
						<tr height="1" onmouseover="tab3();" ondblclick="tab3d();">
							<td height="1"  id="tab3">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr height="1">
										<td height="1">
										<center><img  src="image\supplier\supplier.gif" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%" id="tab32">
							&nbsp;<font color="#FFFFFF" size="+1" id="ftab3">�����ż��Ѵ��˹���</font>
							</td>
						</tr>
					<?}?>

					<?if($done[3]=="1"){?>
						<tr height="1" onmouseover="tab4();" ondblclick="tab4d();">
							<td height="1"  id="tab4">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr height="1">
										<td height="1">
										<center><img  src="image\pos\pos.gif"width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%"  id="tab42">
							&nbsp;<font color="#FFFFFF" size="+1"  id="ftab4">�к����˹����ҹ</font>
							</td>
						</tr>
					<?}?>

					<?if($done[4]=="1"){?>
						<tr height="1"  onmouseover="tab5();" ondblclick="tab5d();">
							<td height="1" id="tab5">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr height="1">
										<td  height="1">
										<center><img  src="image\store\store.gif" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%" id="tab52">
							&nbsp;<font color="#FFFFFF" size="+1"  id="ftab5">�к���ѧ�Թ���</font>
							</td>
						</tr>
					<?}?>

					<?if($done[5]=="1"){?>
						<tr height="1" onmouseover="tab6();" ondblclick="tab6d();">
							<td  height="1" id="tab6" >
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr  height="1">
										<td  height="1">
										<center><img  src="image\mis\mis.gif" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%" id="tab62" >
							&nbsp;<font color="#FFFFFF" size="+1" id="ftab6">�к���������</font>
							</td>
						</tr>
					<?}?>

						<tr height="1"  onmouseover="tab7();" ondblclick="tab7d();">
							<td  height="1" id="tab7">
								<table height="1" border="1" cellpadding="2" bordercolor="#66CCFF" style="border-collapse: collapse;">
									<tr  height="1">
										<td  height="1">
										<center><img  src="image\config\config.gif" width="30" height="30"/></center>
										</td>
								    </tr>
								</table>
								</td>
							<td width="80%" id="tab72">
							&nbsp;<font color="#FFFFFF" size="+1" id="ftab7">��Ѻ���к�</font>
						</td>
				</tr>
				<tr height="1">
							<td >
							&nbsp;
						</td>
				</tr>
				<tr height="1">
							<td >
							&nbsp;
						</td>
				</tr>

		</td>
</table>
<!----------------menu end--------------------->
		</td>
		</tr>

		<tr>
		<td >
			<center><font ID=FNT size=3 color="#FFFFFF"></font></center>
		</td>
		</tr>

		<tr>
		<td>
			<table>
			<tr>
			<td>
				<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'"
	
		    onclick="logout();"/> 
			</td>
			<td>
				&nbsp;<font ID=FNT2 size=4 color="#FFFFFF"></font>
			</td>
			</tr>
			</table>
		</td>
		</tr>
      </table>
	</td>
	</tr>
  <tr height="50%"><td>&nbsp</td></tr>
</table>
</form>
</center>
</body>
</html>
<?
}
else
{ 
	echo "<center><b>��س�������ʡ�͹2 <font color=\"#FF6600\"><a href=\"login.php\">LOGIN !</a></font></b></center>";
}
?>