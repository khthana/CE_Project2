<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>  ��͡�������Թ�������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
function init() {	
		document.onkeypress = showKeyPress;
		gE("expire1").style.display = 'block';
		gE("expire2").style.display = 'none';	
	}
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==27) verifyClose2();
	else if(i==13){
		var x=gE("code1").value;
		main_send(x);
	}
}
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc(goods);
	window.close();
}
function verifyClose2() {
	var returnFunc = window.dialogArguments
	returnFunc("close");
	window.close();
}
window.onbeforeunload = verifyClose2
function isNumber(inputStr,form) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if (oneChar < "0" || oneChar > "9") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
function isNumber_float(inputStr,form) {
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if ((oneChar < "0" || oneChar > "9") && oneChar != ".") {
			alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}

function check_fund(form) {
	inputStr = form.fund.value;
	if (isNumber_float(inputStr,form)) {
		// statements if true
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.fund.focus();
		form.fund.select();
	}
}
function check_cost(form) {
	inputStr = form.cost.value;
	if (isNumber_float(inputStr,form)) {
		var c=parseInt(gE("cost").value);
		var f=parseInt(gE("fund").value);
		if(c<f){
			alert("�ҤҢ�µ�ӡ��ҵ鹷ع");	
			gE("goods_name").focus();
			gE("goods_name").select();
			form.cost.focus();
			form.cost.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.cost.focus();
		form.cost.select();
	}
}
function check_cost2() {
		var c=parseInt(gE("cost").value);
		var f=parseInt(gE("fund").value);
		if(c<f){
			alert("�ҤҢ�µ�ӡ��ҵ鹷ع");	
			gE("goods_name").focus();
			gE("goods_name").select();
			gE("cost").focus();
			gE("cost").select();
			return false;
		}
			return true;
}
function check_alot(form) {
	inputStr = form.alot.value;
	if (isNumber(inputStr,form)) {
		// statements if true
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.alot.focus();
		form.alot.select();
	}
}
function check_warnalot(form) {
	inputStr = form.warnalot.value;
	if (isNumber(inputStr,form)) {
		var a=parseInt(gE("alot").value);
		var w=parseInt(gE("warnalot").value);
		if(a<w){
			alert("����͹�Թ�ӹǹ�Թ��Ҥ������");	
			gE("goods_name").focus();
		gE("goods_name").select();
			form.warnalot.focus();
			form.warnalot.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.warnalot.focus();
		form.warnalot.select();
	}
}
function check_warnalot2() {	
		var a=parseInt(gE("alot").value);
		var w=parseInt(gE("warnalot").value);
		if(a<w){
			alert("����͹�Թ�ӹǹ�Թ��Ҥ������");	
			gE("goods_name").focus();
			gE("goods_name").select();
			gE("warnalot").focus();
			gE("warnalot").select();
			return false;
		}
			return true;
}
function check_sale(form) {
	inputStr = form.sale.value;
	if (isNumber(inputStr,form)) {
		var s=parseInt(gE("sale").value);
		if(s>100){
			alert("��Ңͧ����Ţ��ͧ����Թ 100 ");	
			gE("goods_name").focus();
		gE("goods_name").select();
			form.sale.focus();
			form.sale.select();
		}
	} else {
		gE("goods_name").focus();
		gE("goods_name").select();
		form.sale.focus();
		form.sale.select();
	}
}
function check_day(form) {
	inputStr = form.day.value;
	var date_in_month=gE("date_in_month").value;
	if(inputStr!=null){
		if (isNumber(inputStr,form)) {
			var s=parseInt(gE("day").value);
			if(s>date_in_month){
				alert("��Ңͧ�ѹ��ͧ����Թ "+date_in_month);	
				gE("goods_name").focus();
			gE("goods_name").select();
				form.day.focus();
				form.day.select();
			}
		} else {
			gE("goods_name").focus();
			gE("goods_name").select();
			form.day.focus();
			form.day.select();
		}
	}
}
function check_month(form) {
	inputStr = form.month.value;
	if(inputStr!=null){
		if (isNumber(inputStr,form)) {
			var s=parseInt(gE("month").value);
			if(s>12){
				alert("��Ңͧ��͹��ͧ����Թ 12 ");	
				gE("goods_name").focus();
				gE("goods_name").select();
				form.month.focus();
				form.month.select();
			}
		} else {
			gE("goods_name").focus();
			gE("goods_name").select();
			form.month.focus();
			form.month.select();
		}
	}
}
 var DateTime;
function check_year(form) {
	  inputStr = form.year.value;
	  if(inputStr!=null){
		  DateTime=new Date();
		  year=DateTime.getYear();
		  year=year+543;
		  var n=year-1;
		  year=year+'';	 
		  var y = year.substring(2,4);

		if (isNumber(inputStr,form)) {
			var s=gE("year").value;
			if(s<y){
				alert("��Ңͧ�յ�ͧ�ҡ���� "+n);	
				gE("goods_name").focus();
				gE("goods_name").select();
				form.year.focus();
				form.year.select();
			}
		} else {
			gE("goods_name").focus();
			gE("goods_name").select();
			form.year.focus();
			form.year.select();
		}
	 }
}
function expire_check(){
	//alert(gE("member").value);
	if(gE("xx").value==1){
		gE("expire1").style.display = 'block';
		gE("expire2").style.display = 'none';		
		//alert(gE("member").value)
		gE("xx").value=0;
	}
	else if(gE("member").value=="on"){
		gE("expire1").style.display = 'none';
		gE("expire2").style.display = 'block';
		gE("xx").value=1;
		//alert(gE("member").value)
	}
}
function check_remain2(list) {
	inputStr = list;
	for (var i = 0; i < inputStr.length; i++) {
		//var i=inputStr.length;
		var oneChar = inputStr.substring(i, i+1);
		if ((oneChar < "0" || oneChar > "9" ) && oneChar != ".") {
			//alert("��سҡ�͡����Ţ��ҹ��");	
			return false;
		}
	}
			return true;
}
	var goods=new Array();
function main_send(code1){	
	goods[0]=code1;
	goods[1]=gE("type").value;
	goods[2]=gE("goods_name").value;
	goods[3]=gE("supplier").value;
	goods[4]=gE("unit").value;
	goods[5]=gE("zone").value;
	goods[6]=gE("fund").value;
	goods[7]=gE("cost").value;
	goods[8]=gE("alot").value;
	goods[9]=gE("warnalot").value;
	goods[10]=gE("sale").value;
	goods[11]=gE("day").value;
	goods[12]=gE("month").value;
	goods[13]=gE("year").value;
	goods[14]=gE("hotkey").value;
	goods[15]=gE("day2").value;
	goods[16]=gE("member").value;
	var date_in_month=gE("date_in_month").value;

	if(goods[0]==""){
		alert('��سҡ�͡�����Թ��ҡ�͹');
	}
	else if(goods[1]==""){
		alert('��س����͡������Թ��ҡ�͹');
	}
	else if(goods[2]==""){
		alert('��سҡ�͡�����Թ��ҡ�͹');
	}
	else if(goods[3]==""){
		alert('��س����͡���Ѵ��˹��¡�͹');
	}
	else if(goods[4]==""){
		alert('��سҡ�͡˹����Թ��ҡ�͹');
	}
	else if(goods[5]==""){
		alert('��سҡ�͡������Թ��ҡ�͹');
	}
	else if(goods[6]==""){
		alert('��سҡ�͡�鹷ع�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[6])){
		//check number
		alert("��سҡ�͡�鹷ع�繵���Ţ��ҹ��");	
	}
	else if(goods[7]==""){
		alert('��سҡ�͡�ҤҢ���Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[7])){
		//check number
		alert("��سҡ�͡�ҤҢ���繵���Ţ��ҹ��");
	}
	else if(goods[8]==""){
		alert('��سҡ�͡�ӹǹ�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[8])){
		//check number
		alert("��سҡ�͡�ӹǹ�Թ����繵���Ţ��ҹ��");
	}
	else if(goods[9]==""){
		alert('��سҡ�͡�ӹǹ����͹�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[9])){
		//check number
		alert("��سҡ�͡�ӹǹ����͹�繵���Ţ��ҹ��");
	}
	else if(goods[10]==""){
		alert('��سҡ�͡��ǹŴ�Թ��ҡ�͹');
	}
	else if(!check_remain2(goods[10])){
		//check number
		alert("��سҡ�͡��ǹŴ�繵���Ţ��ҹ��");
	}
	else if(goods[11]>date_in_month || goods[11]<0){
		alert("�ѹ��� 1 - "+date_in_month);
	}
	else if(!check_remain2(goods[11])){
		//check number
		alert("��سҡ�͡�ѹ����繵���Ţ��ҹ��");
	}
	else if(goods[12]>12 || goods[12]<0){
		alert('��͹ 1 - 12');
	}
	else if(!check_remain2(goods[12])){
		//check number
		alert("��سҡ�͡��͹�繵���Ţ��ҹ��");
	}
	else if(!check_remain2(goods[12])){
		//check number
		alert("��سҡ�͡��͹�繵���Ţ��ҹ��");
	}
	else if(!check_remain2(goods[13])){
		//check number
		alert("��سҡ�͡���繵���Ţ��ҹ��");
	}
	else if(!check_remain2(goods[15]) && goods[15]!=""){
		//check number
		alert("��سҡ�͡�ѹ�繵���Ţ��ҹ��");
	}
	else if(!check_warnalot2()){
		//compare alert
	}
	else if(!check_cost2()){
		//compare cost
	}
	
	else{
	var returnFunc = window.dialogArguments
	returnFunc(goods);
	window.close();
	}
}

</SCRIPT>

</HEAD>
<?php
	//--------------------------variable-----------------------------
	$code1=$HTTP_GET_VARS[code1];
	$type=$HTTP_GET_VARS[type];
	//echo $code1;
?>
<BODY bgcolor="#EEEEEE" onload="init();">
<form action="_self"  name="main_form" id="main_form" method="post">
<center>
<table border="0" width="100%">
		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			 <font color="#6633CC"><b>�Թ�����觴�ǹ:</b></font>
			 <select id="hotkey">
			<option value="no">�����</option>
			<option value="F8">F8 <?echo getconfig("config","3:F8");?></option>
			<option value="F9">F9 <?echo getconfig("config","4:F9");?></option>
			<option value="F10">F10 <?echo getconfig("config","5:F10");?></option>
			<option value="F11">F11 <?echo getconfig("config","6:F11");?></option>
			<option value="F12">F12 <?echo getconfig("config","7:F12");?></option>
			</select>
			</td>
			<td>
			
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			&nbsp;<font color="#6633CC">�����Թ���:</font><?echo $code1;?>
			</td>
			<td>
			
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">������Թ���:</font><select id="type"> 
			
			<?
				$result=select_all_record_order("*","goodstype","type_id");
				while($dbarr=mysql_fetch_array($result)){
					if($type==$dbarr["type_name"])
					{
					echo "<option selected=\"selected\" value=\"".$dbarr["type_name"]."\">".$dbarr["type_name"]."</option>";
					}
					else{
					echo "<option value=\"".$dbarr["type_name"]."\">".$dbarr["type_name"]."</option>";
					}
				}
			?>
			</select>
			</td>
			<td>		
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">&nbsp;&nbsp;�����Թ���:</font><input type="text" id="goods_name" name="goods_name" maxlength="45"/>
			</td>
			<td>	
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			<font color="#6633CC">&nbsp;����˹���:</font><select id="supplier"> 
			
			<?
				$result=select_all_record_order("supplier_name","supplier","supplier_id");
				while($dbarr=mysql_fetch_array($result)){				
			echo "<option value=\"".$dbarr["supplier_name"]."\">".$dbarr["supplier_name"]."</option>";
				}
			?>
			</select>
			</td>
			<td>		
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td>
		<table  border="0" width="100%">
			<tr>
			<td>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#6633CC">˹���:</font><select id="unit"> <option value="˹���">˹���</option>
					<?
						$result=select_all_record_order("unit_name","unit","unit_id");
						while($dbarr=mysql_fetch_array($result)){
							echo "<option value=\"".$dbarr["unit_name"]."\">".$dbarr["unit_name"]."</option>";
						}
					?>
			</select>
			</td>
			<td >
			<font color="#6633CC">�����:</font><select id="zone"><option value="nozone">���������</option>
					<?
						$result=select_all_record_order("zone_name","zone","zone_id");
						while($dbarr=mysql_fetch_array($result)){
							echo "<option value=\"".$dbarr["zone_name"]."\">".$dbarr["zone_name"]."</option>";
						}
					?>
			</select>
			</td>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td >
				&nbsp;&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">�鹷ع:</font><input type="text" id="fund" name="fund" size="10"  onChange="check_fund(this.form);" maxlength="16"/>
			</td>
			</form>

			<form>
			<td >
				<font color="#6633CC">�ҤҢ��:</font><input type="text" id="cost" name="cost" size="10" onChange="check_cost(this.form);" maxlength="16"/>
			</td>
			</form>

			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td >
				&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">�ӹǹ:</font><input type="text" id="alot" name="alot"  size="10" onChange="check_alot(this.form);" value="1" maxlength="16"/>
			</td>
			</form>
			
			<form>
			<td >
				<?$alert=getconfig("config","8:alert");?>
				<font color="#6633CC">����͹:</font><input type="text" id="warnalot" name="warnalot" size="10" onChange="check_warnalot(this.form);" value="<?echo $alert;?>" maxlength="16"/>
			</td>
			</form>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td colspan="2">
		<table  border="0" width="100%">
			<tr>
			<form>
			<td width="40%">
				&nbsp;&nbsp;&nbsp;
				<font color="#6633CC">��ǹŴ:</font><input type="text" id="sale" name="sale" maxLength="3" size="3" value="0" onChange="check_sale(this.form);"/>%
			</td>
			</form>
			</tr>
		</table>
		</td>
		</tr>

		<tr>
		<td >
		<table  border="0" width="100%">
			<tr>
			<form>
			<td align="right">
				&nbsp;&nbsp;
				<input type="checkbox" id="member" name="member" maxLength="3" size="3"  onclick="expire_check()"/><font color="#6633CC">���ѹ�������</font>
				<input type="hidden" id="xx" value="0"/>
			</td>
			</form>

			<form>
			<td id="expire1">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<font color="#6633CC">�������:</font><input type="text" id="day" maxLength="2" size="1" name="day" onChange="check_day(this.form);"/>
			<input type="text" id="month" maxLength="2" size="1" name="month" onChange="check_month(this.form);"/>
			<input type="text" id="year" maxLength="2" size="1" name="year" onChange="check_year(this.form);"/>
			</td>
			<td id="expire2">
			<font color="#6633CC">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp�Ѻ��ա <input type="text" id="day2" maxLength="4" size="3" name="day2" /> �ѹ</font>
			</td>
			</form>
			</tr>

	</table>
	</center>
			<center>
			<input type="hidden" value="<?echo $code1;?>" name="code1" id="code1"/>
			<?$date_in_month=date("t");?>
			<input type="hidden" value="<?echo $date_in_month;?>" name="date_in_month" id="date_in_month"/>
			<button onclick="main_send('<?echo $code1;?>');">&nbsp;&nbsp;��ŧ&nbsp;&nbsp;</button>&nbsp;
			<button onclick="verifyClose2();">&nbsp;&nbsp;¡��ԡ&nbsp;&nbsp;</button>
			</center>
</form>
</BODY>
</HTML>
