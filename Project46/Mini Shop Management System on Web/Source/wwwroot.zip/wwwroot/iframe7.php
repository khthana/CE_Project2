<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<SCRIPT LANGUAGE="JavaScript">
	 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
	function init(){
		top.location.href("pos.php");
	}
	function tab(i,count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#FFFFFF";
		}
		var id="id"+i;
		gE(id).style.backgroundColor = "#FFFF00";
		top.location.href("pos.php?tab="+i);
	}
	function set_tab(count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#FFFFFF";
		}
	}
	function goNextAnchor(where) {	
		where=where*10;
		window.scroll(0,where);
    } 
</SCRIPT>
</HEAD>
<?
		include("fn_mysql.php");
		$code1=$HTTP_GET_VARS[code1];	
		$arrow=$HTTP_GET_VARS[arrow];
		$user=$HTTP_SESSION_VARS["user"];
		$c_id=$HTTP_GET_VARS[c_id];
		if($c_id!=null){
		$file="config\\".$user.".txt";
		setconfig_file($file,"temp","1:c_id",$c_id);//function
		}
?>
<BODY name="body1" bgcolor="#00CCCC">
<FORM NAME="fixed">
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0" bgcolor="#00CCCC" rules="cols" style="border-collapse: collapse;">
					<tr  height="1" bgcolor="#9999CC">
					<td>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�ӴѺ</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�����Թ���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�����Թ���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�ӹǹ</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>˹���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�Ҥ�</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>��ǹŴ</b></font></center>
					</td>
					<td>
						<center><font color=""></font></center>
					</td>
					</tr >

		<?	
		connect_mysql("db_admin");//function
		 id_oder($user,"order_id");
		$sql="SELECT * FROM $user ORDER BY order_id;";
		$result=mysql_query($sql);	
				$i=1;
				$result2=select_all_record("order_id",$user);
				$count=mysql_num_rows($result2);
				if($arrow!=null){
						$count=$arrow;
				}
				?><BODY onload="goNextAnchor(<?echo $count;?>)"><?
			while($dbarr=mysql_fetch_array($result)){
				 $id="id".$i;
			?>
			<tr  height="1" <?if($i!=$count){echo "bgcolor='#FFFFFF'";}else{echo "bgcolor='#FFFF00'";}?>" id="<?echo $id;?>" onclick="tab('<? echo $i;?>','<? echo $count;?>');">
					<td>
					<center>
						<a href="pos.php?delete1=<?echo $i;?> "target="_top">ź</a>
					</center>
					</td>
					<td>
						<center><?echo $dbarr["order_id"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["goods_id"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["goods_name"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["amount"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["unit"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["total_price"];?></center>
					</td>
					<td>
						<center><A NAME="<?echo "h".$id;?>"><?echo $dbarr["sale_percent"];?>%</A></center>
					</td>
					</tr >
			<?$i++;}
			?>		
					<tr >
					<td>
					</td>
					</tr >
					</table>
</form>
</BODY>
</HTML>