<?php
if(session_is_registered("user")){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> ����¹���ʼ�ҹ </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

</head>
<html>
<body onload="init()" scroll="no" background="xp4.jpg" >
<?		
//------------------------------------add status page--------------------------------
		//echo $user;
		if($user!=null){
			//include("fn_mysql.php");
			update_2record("login","username",$user,"status","1","page","changepass");	
			$result=getdate();
			$year=$result["year"]+543;
			$date=$result["mday"]."/".$result["mon"]."/".$year;
			$login_time=$result["hours"].":".$result["minutes"];
			update_2record("login","username",$user,"status","1","login_date",$date);
			update_2record("login","username",$user,"status","1","login_time",$login_time);
		}
//-------------------------------------------------------------------------------------------------------
        $send_change=$HTTP_POST_VARS[send_change];
		$newpassword1=$HTTP_POST_VARS[newpassword1];
		$newpassword2=$HTTP_POST_VARS[newpassword2];
		$worn="����¹���ʼ�ҹ";	
if($send_change!=null){
		if($newpassword1!=null&&$newpassword2!=null){
				if($newpassword1==$newpassword2){//��Ǩ�ͺ����׹�ѹ
	$user=$HTTP_SESSION_VARS["user"];
	include("fn_mysql.php");
	$newpassword1=md5($newpassword1);
	$result=update_record_where("employee","username",$user,"password",$newpassword1);
							if($result){								
									$worn="����¹��������ó� !";					
							}
				}
				else{  $worn="�׹�ѹ�������ç�ѹ !";}
		}
		else{
			    $worn="��͡���������ú !";
		}
}

?>
<script type="text/javascript">
function init(){
	 Now();
}
//-----------------------------------------------------------
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 

//----------------------------------------------------Show day-----------------------------------------------
                       var day,date,month,year,hour,minute,second,today;  //���ҧ�������������ʵ���Ţ�ͧ�ѹ����
                              var dayString=new Array();
                              dayString[0]="�ҷԵ��";dayString[1]="�ѹ���";dayString[2]="�ѧ���";dayString[3]="�ظ";
                              dayString[4]="����ʺ��";dayString[5]="�ء��";dayString[6]="�����";
                              var monthString=new Array();
                              monthString[0]="���Ҥ�"; monthString[1]="����Ҿѹ��"; monthString[2]="�չҤ�"; monthString[3]="����¹";
                              monthString[4]="����Ҥ�"; monthString[5]="�Զع�¹"; monthString[6]="�á�Ҥ�"; monthString[7]="�ԧ�Ҥ�";
                              monthString[8]="�ѹ��¹"; monthString[9]="���Ҥ�"; monthString[10]="��Ȩԡ�¹"; monthString[11]="�ѹ�Ҥ�";      
                     //����ŧ�����Ǩ�ͺ�Թ�硫�����������˹��¤����Ӣͧ�к��ҡ��� ����¹���������鹡��ҡ�������͹� if ���� case
                      var DateTime;
                      function Now() 
                         {    DateTime=new Date(); //���ҧ�ѵ�� (object) �Դ��͡Ѻ�ѹ���Ңͧ�к���Ժѵԡ�� (OS)
                              day=DateTime.getDay(); 
                              date=DateTime.getDate(); 
                              month=DateTime.getMonth();
                              year=DateTime.getYear();
                              hour=DateTime.getHours();
                              minute=DateTime.getMinutes();
                              second=DateTime.getSeconds();    
                         today=dayString[day]+" "+date+" "+monthString[month]+" "+(year+543);
							 var today2=hour+":"+minute+":"+second;
                             document.title=today; //�ʴ��͡�ҧ����ź���
                             window.status=today;//�ʴ��͡�ҧᶺʶҹ�
                            gE("FNT2").innerText=today2; gE("FNT").innerText=today;//�ʴ��͡�ҧ���ྨ�ç���˹� ID=TXT ੾�� IE
                             setTimeout("Now()",1*1000); //��˹�����Ѿഷ���ҷء 1 �Թҷ�
                         }                
 //---------------------------------------Tab-----------------------------------
 function tab1(){	    
		gE("tab11").background  ="tab.jpg";
		gE("tab12").background  ="tab.jpg";
		gE("ftab1").style.color = "#FFFF00";
}
 function tab2(){	    
		gE("tab21").background  ="tab.jpg";
		gE("tab22").background  ="tab.jpg";
		gE("ftab2").style.color = "#FFFF00";
}
 function clear_tab(){	    
		gE("tab11").background  ="";
		gE("tab12").background  ="";
		gE("tab21").background  ="";
		gE("tab22").background  ="";
		gE("ftab1").style.color = "#FFFFFF";
		gE("ftab2").style.color = "#FFFFFF";
}

//----------------------------------------------------Logout------------------------------------------------------
function logout() {
	location.href("login.php?back=1");
}
</script>

<center>
<form method="post" action="changepass.php" >
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0"  >
	<tr height="35%"><td>&nbsp;</td></tr>
    <tr>
	<td align="center" background="xp4.jpg">
		<table width="50%" height="20%" border="0" cellspacing="0" cellpadding="0" frame="box" 2rules="none"  style="border-collapse: collapse;">
		<tr width="60%">
		<td>
			&nbsp;
		</td>
		<td >
			&nbsp;
		</td>
		</tr>

		<tr>
		<td width="48%">			
			<center>
			<!----------------------------------------Fill left----------------------------------->	
			<font size="+2" color="#FFFF99" ><b><?echo $worn;?></b></font>
			<br />
			  <font size="+3" color="#FFFFFF" face="Ms Sans Serif"><I>C</I></font>
			  <font size="+2" color="#FFFFFF" face="Ms Sans Serif"><I>e-soft </I></font>
			</center>	
		</td>
		<td rowspan="3" >
<!----------------menu begin--------------------->
		<table width="100%" height="1" border="0" cellspacing="0" cellpadding="2" >
						<tbody>
				<tr height="1">
						<td >
							<font color="#FFFFFF" ><b>���ʼ����</b></font>
						</td>
						<td  >
							<font color="#FFFFFF" ><b><?echo $user;?></b></font>
						</td>
				</tr>
				<tr height="1">
						<td id="tab11" onmouseover="tab1();" onmouseout="clear_tab();">
							<font id="ftab1" color="#FFFFFF" ><b>��������</b></font>					
						</td>
						<td id="tab12" onmouseover="tab1();" onmouseout="clear_tab();">
							<input type="password" name="newpassword1" maxlength="16"/> 
						</td>
				</tr>
				<tr height="1">
						<td  id="tab21" onmouseover="tab2();" onmouseout="clear_tab();">
							<font id="ftab2" color="#FFFFFF" ><b>�׹�ѹ����</b></font>					
						</td>
						<td  id="tab22" onmouseover="tab2();" onmouseout="clear_tab();">
							<input type="password" name="newpassword2" maxlength="16"/> 
						</td>
				</tr>
				<tr height="1" >
						<td >
										
						</td>
							<td align="right">
							<input type="submit" name="send_change" value=" ��ŧ " />		
							&nbsp;&nbsp;&nbsp;&nbsp;
						</td>
				</tr>
				<tr height="10" >
						<td >									
						</td>
						<td >							
						</td>	
				</tr>

		</td>
</table>
<!----------------menu end--------------------->
		</td>
		</tr>

		<tr>
		<td >
			<center><font ID=FNT size=3 color="#FFFFFF"></font></center>
		</td>
		</tr>

		<tr>
		<td>
			<table>
			<tr>
			<td>
				<img border="0" src="image/logout/logout1.gif" alt="�͡�ҡ�к�"  onmouseover="this.src='image/logout/logout2.gif'" onmouseout="this.src='image/logout/logout1.gif'"
	
		    onclick="logout();"/> 
			</td>
			<td>
				&nbsp;<font ID=FNT2 size=4 color="#FFFFFF"></font>
			</td>
			</tr>
			</table>
		</td>
		</tr>
      </table>
	</td>
	</tr>
  <tr height="45%"><td>&nbsp</td></tr>
</table>
</form>
</center>
</body>
</html>
<?
}
else if(session_is_registered("catch")){
		session_unregister("catch");
		session_destroy();
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>���ʹ��١��ͤ�Թ���������!</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
else{
		?>
		<body scroll="no" background="xp4.jpg">
		<table border=0 width="100%" height="100%">
			<tr height="20%"><td>&nbsp;</td></tr>
			<tr background="xp4.jpg"><td><center>
			<font color="#FFFF00" size="+3" face="MS Sans serif"><b>��س���͡�Թ�����к�</b></font>
			</center></td></tr>
			<tr height="60%"><td>&nbsp;</td></tr>
		</table>
		</body>
		<?
}
?>
