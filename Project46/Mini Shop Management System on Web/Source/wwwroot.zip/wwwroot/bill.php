<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		document.onkeydown= showKeyDown;			
		 window.print();
		setTimeout("verifyClose();",50*100)	
}
function showKeyDown(evt) {
		evt = (evt) ? evt : window.event
		var i=evt.keyCode;
		
}
function verifyClose() {
	var returnFunc = window.dialogArguments
	returnFunc(1);
}
//window.onafterprint = verifyClose
//--------------------------------------------------------------------------
</SCRIPT>

</HEAD>
<?php
		$user=$HTTP_SESSION_VARS["user"];
		$recive=$HTTP_GET_VARS[recive];
		$change=$HTTP_GET_VARS[change];
		$result=getdate();
		$year=$result["year"]+543;
		$date=$result["mday"]."/".$result["mon"]."/".$year;
		$time=$result["hours"].":".$result["minutes"];
		$result=select_record_max("tx","group_id");
		$max=mysql_result($result,0,"MAX(group_id)");
		if($max==null){$max=1;}
		else{$max=$max+1;}
		$sql="SELECT sum(total_price) AS total FROM $user;";
		$result=mysql_query($sql);
		$total=mysql_result($result,0,'total');
		$pos=strpos($total,".");
		if($pos===false){
		
		}
		else{
				$total=substr($total,0,$pos+3);
		}
		$shop_name=getconfig("config","13:shop_name");
?>
<BODY bgcolor="#FFFFFF" onload="init();" scroll=no>
<table border="0" width="200" height="50" id="printCopyright"  name= "printCopyright" cellspacing="1" style="border-collapse: collapse;">
	<tr height="1">
	<td colspan="2"><center>
	<?$type=getconfig("config","14:logotype");?>
	<img src="<?echo "logo.".$type;?>" width="10" height="10"/>
	<font size="-1">��ҹ&nbsp;<?echo $shop_name;?><font>
	</center>
	</td>	
</tr>
<tr height="1">
	<td><font size="-1">�ѹ���: <?echo $date;?><font></td>
	<td align="right"><font size="-1">����: <?echo $time;?><font>&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
<tr height="1">
	<td colspan="2"><font size="-1">������Ţ���: <?echo $max?><font></td>
</tr>
<tr height="1">
	<td colspan="2"><font size="-1">���ʾ�ѡ�ҹ: <?echo $user;?><font>
	<br />
	<hr>
	</td>
</tr>
<?
	connect_mysql("db_admin");//function
	id_oder($user,"order_id");
	$sql="SELECT * FROM $user ORDER BY order_id;";
	$result=mysql_query($sql);	
	while($dbarr=mysql_fetch_array($result)){
?>
<tr height="1">
	<td><font size="-1"><?echo $dbarr["goods_name"];?><font></td>
	<td align="right"><font size="-1"><?echo $dbarr["amount"];?><font>&nbsp;&nbsp;
	<font size="-1"><?echo $dbarr["unit"];?><font>
	&nbsp;&nbsp;
	</td>
</tr>
<?}?>
<tr height="1">
	<td><font size="-1"><b>xxx���</b><font></td>
	<td align="right"><font size="-1"><?echo $total;?><font>&nbsp;&nbsp;
	<font size="-1">�ҷ<font>
	&nbsp;&nbsp;
	</td>
</tr>
<tr height="1">
	<td><font size="-1"><b>�Ѻ��</b><font></td>
	<td align="right"><font size="-1"><?echo $recive;?><font>&nbsp;&nbsp;
	<font size="-1">�ҷ<font>
	&nbsp;&nbsp;
	</td>
</tr>
<tr height="1">
	<td><font size="-1"><b>�͹</b><font>
	<hr>
	</td>
	<td align="right"><font size="-1"><?echo $change;?><font>&nbsp;&nbsp;
	<font size="-1">�ҷ<font>
	&nbsp;&nbsp;
	<hr>
	</td>
</tr>
<tr height="1">
	<td colspan="2"><center><font size="-1">�ͺ�س��������ԡ��....<font></center></td>
</tr>
</table>

</BODY>
</HTML>
