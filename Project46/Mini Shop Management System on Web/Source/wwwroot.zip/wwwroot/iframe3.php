<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<SCRIPT LANGUAGE="JavaScript">
	 /* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
	
    /* Get Element    */    
	function gE(e,f){
		if(l){
			f=(f)?f:self;
			V=f.document.layers;
			if(V[e])
			return V[e];
			for(W=0;i<W.length;W++)
			return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
			return d.getElementById(e);
		}  
	function tab(i,count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#FFFFFF";
		}
		var id="id"+i;
		gE(id).style.backgroundColor = "#FFFF00";
	}
	function set_tab(count){
		for(var j=1;j<=count;j++){
		var id_hide="id"+j;
		gE(id_hide).style.backgroundColor = "#FFFFFF";
		}
	}
	function delete_confirm(name,id){
		//document.write(name);
		var i=confirm('�س��㨷���ź�Թ��� '+name+'�͡�ҡ�ҹ������');
		if(i){
		top.location.href("store.php?delete_from_frame3="+id);
		}
	}
var prefsDlog
function edit_confirm(name,id){
	//document.write(name);
	var i=confirm('�س��㨷����䢢������Թ��� '+name+'�ҡ�ҹ������');
	if(i){
			if (!prefsDlog || prefsDlog.closed) {
				prefsDlog = showModelessDialog("edit_goods.php?code1="+id, setPrefs, "dialogWidth:370%; dialogHeight:390%;dialogLeft:320% ; dialogTop:130%;status=no")
			}
	}
}
function setPrefs(list) {
	if(list!="close"){	top.location.href("store.php?code_return2="+list[0]+"&&type_return2="+list[1]+"&&name_return2="+list[2]+"&&supplier_return2="+list[3]+"&&unit_return2="+list[4]+"&&zone_return2="+list[5]+"&&fund_return2="+list[6]+"&&cost_return2="+list[7]+"&&alot_return2="+list[8]+"&&warnalot_return2="+list[9]+"&&sale_return2="+list[10]+ "&&key_return2="+list[11]+"&&day3="+list[12]);
	}
	else{
   
	}
}
var prefsDlog2;
function other(list){
	if (!prefsDlog2 || prefsDlog2.closed) {
				prefsDlog2 = showModelessDialog("view.php?code1="+list, setPrefs2, "dialogWidth:224%; dialogHeight:210%;dialogLeft:660% ; dialogTop:190%;status=no")
	}		
}
function setPrefs2(list) {
	if(list!="close"){
		location.href("iframe3.php?case1="+list[0]+"&&id="+list[1]);
	}
}
</SCRIPT>
</HEAD>
<?
		include("fn_mysql.php");
		$case1=$HTTP_GET_VARS[case1];
		$code1=$HTTP_GET_VARS[code1];
		$id=$HTTP_GET_VARS[id];
		if($id!=null){
			$result=select_record("expire","ex_id",$id);
			$code1=mysql_result($result,0,"goods_id");
			delete_record("expire","ex_id",$id);
			id_oder("expire","ex_id");
			echo "<body onload=\"other('$code1');\">";
		}
?>
<BODY bgcolor="#99CCCC">
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0" rules="cols">
					<tr  height="1" bgcolor="#9090CC">
					<td >
						<center><font color="#FFFFFF"></font></center>
					</td>
					<td >
						<center><font color="#FFFFFF"></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�ӴѺ</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�����Թ���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�����Թ���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>˹���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�鹷ع</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�ҤҢ��:˹���</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>�ӹǹ�������</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF"><b>��ǹŴ</b></font></center>
					</td>
					<td>
						<center><font color="#FFFFFF">����</font></center>
					</td>
					</tr >

		<?
		//echo $code1;
		if(1){
			if($case1==null || $case1=="undefined"){$case1="�Թ��ҷ����";}
			$result=select_record("goodstype","type_name",$case1);
			$type_id=mysql_result($result,0,"type_id");
			$find=find_record("goods","type_id",$type_id);
			if($find){
			$result=select_record("goods","type_id",$type_id);
			$count=mysql_num_rows($result);
			$i=1;
			
			while($dbarr=mysql_fetch_array($result)){
				   $id="id".$i;
			?>
			<tr  height="1" <?if($code1!=$dbarr['goods_id']){echo "bgcolor='#FFFFFF'";}else{echo "bgcolor='#FFFF00'";}?>" id="<?echo $id;?>" onclick="tab('<? echo $i;?>','<? echo $count;?>');">
					<td>
						<center><img src="image\delete\delete2.gif" alt="ź�Թ���"  onclick="delete_confirm('<?echo $dbarr['goods_name'];?>','<?echo $dbarr['goods_id'];?>');"/></center>
					</td>
					<td>
						<center><img src="image\edit\edit2.gif" width="18" height="18" alt="��䢢������Թ���"  onclick="edit_confirm('<?echo $dbarr['goods_name'];?>','<?echo $dbarr['goods_id'];?>');"/></center>
					</td>
					<td>
						<center><?echo $i;?></center>
					</td>
					<td>
						<center><?echo $dbarr["goods_id"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["goods_name"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["unit"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["fund_price"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["retail_price"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["total_remain"];?></center>
					</td>
					<td>
						<center><?echo $dbarr["sale_percent"];?>%</center>
					</td>
					<td>
						<center><img src="image\viewdata\viewdata.gif" alt="�آ���������" width="18" height="18" onclick="other(<?echo $dbarr["goods_id"];?>);"/></center>
					</td>
					</tr >
			<?$i++;}
					}//end if inline
					 else{
					?>
					<tr >
					<td>
					</td>
					</tr >
					<?
			   }
		       }
			   else{
					?>
					<tr >
					<td>
					</td>
					</tr >
					<?
			   }	   
			   ?>	
					
					<tr >
					<td>
					</td>
					</tr >
					</table>
</BODY>
</HTML>
