<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE></TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<SCRIPT LANGUAGE="JavaScript">
	function tab(list){
		if(list!=0){
		parent.location.href("customs.php?id="+list );
		}
	}

</SCRIPT>
</HEAD>
<?php
	include("fn_mysql.php");
	$add_new_id=$HTTP_GET_VARS[add_new_id];
	$add_new=$HTTP_GET_VARS[add_new];
	$cust_id=$HTTP_GET_VARS[id];
	$name=$HTTP_GET_VARS[add_new];
	if($add_new==1){
	$cust_id=$add_new_id;
	}
?>
<BODY bgcolor="#99CCCC">
<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#99CCCC">
<tr  height="1" bgcolor="#9999CC">

<td width="1">
	<center><font color="#FFFFFF">�����١���</font></center>
</td>
<td>
	<center><font color="#FFFFFF">����-���ʡ��</font></center>
</td>
<td width="1">
	<center><font color="#FFFFFF">��ǹŴ</font></center>
</td>
<td width="1">
	<center><font color="#FFFFFF">��ṹ����</font></center>
</td>
</tr >
<?
	connect_mysql("db_admin");//function
	$sql="SELECT * FROM customer ORDER BY cust_id;";
	$result=mysql_query($sql);
while($dbarr=mysql_fetch_array($result)){?>

<tr  height="1" 
<? if($dbarr["cust_id"]==$cust_id){	
			echo "bgcolor=\"#FFFF00\"";$yello=$dbarr["cust_id"];	
	}
	else{echo "bgcolor=\"#FFFFFF\"";
	}?>
onclick="tab(<?
if($dbarr["cust_id"]!=$yello){
$data=$dbarr["cust_id"];
echo "'".$data."'";}
else{
	$data="0";
	echo "'".$data."'";
 }
?>)
">

<td>
	<center><?echo $dbarr['cust_id'];?></center>
</td>
<td>
	<center><?echo $dbarr['name'] ." ".$dbarr['lastname'];?></center>
</td>
<td>
<?
$discount=getconfig("config","1:discount");	
?>
	<center><?echo $discount;?></center>
</td>
<td>
	<center><?echo $dbarr['point'];?></center>
</td>
<?}?>
</tr >
<tr>
<td></td>
<td></td>
<td></td>
</tr>
</table>
</BODY>
</HTML>
