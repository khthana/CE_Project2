<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Register page </title>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>
<body valign="center">
<center>
<br /><br /><br /><br /><br /><br />
<form method="post" action="reg2.php">
<table width="400" height="100" border="1" cellspacing="5" cellpadding="2" bgcolor="#99CCCC">
<tbody>
 <tr height="60">
     <tr bgcolor="#F2F2F2" >
		<center><font color="#6600FF"> &nbsp;&nbsp;&nbsp;��س������ͼ������к� ������ʼ�ҹ����Թ 16 ����ѡ��</font></center>
	
	 </tr>	 
 </tr>

<tr height="1%">
	<td width="120" bgcolor="#FFFFCC">
	<center><font color="#6600FF">���ͼ������к�:</font></center>
	<td>
	<td bgcolor="#FFFFCC">
		  <center><input type="text" name="username" value="admin"  readonly maxlength="16" size="20" /></center>  
	</td>
</tr>

<tr height="1%">
	<td width="120" bgcolor="#00CCFF">
	<center><font color="#6600FF">���ʼ�ҹ:</font></center>
	<td>
	<td bgcolor="#00CCFF">
		  <center><input type="password" name="password" maxlength="16" size="20" /></center>  
	</td>
</tr>

<tr height="1%">
	<td bgcolor="#F2F2F2">
		<center><input type="submit" name="send" value=" ��ŧ  "/>
		<input type="reset" name="send" value="  ¡��ԡ "/></center>
	</td>	
		
</tr>
<table/>
</center>
</form>
</body>
</html>

