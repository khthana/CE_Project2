<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<TITLE>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </TITLE>
<meta http-equiv="Content-Language" content="th">
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<?php include("fn_mysql.php");?>
<SCRIPT LANGUAGE="JavaScript">
/* DHTML functions */
    d=document;
	l=(d.layers)?1:0;
/* Get Element    */    
function gE(e,f){
		if(l){
				f=(f)?f:self;
				V=f.document.layers;
				if(V[e])
				return V[e];
				for(W=0;i<W.length;W++)
				return(gE(e,V[W]));
		}
		if(d.all) return d.all[e];
				return d.getElementById(e);
} 
//--------------------------------------------------------------------------
function init() {	
		document.onkeypress = showKeyPress;
}	
var check=0;
function showKeyPress(evt) {
	evt = (evt) ? evt : window.event
	var i=evt.keyCode;
	if(i==13) {
		var cust_id=gE("cust_id").value;
		var point=gE("point").value;
		var name=gE("name").value;
		if(point!=""){
			//alert("�س "+name+" ��ṹ�� "+point+" �ú���������� ");
			//check print?		
		}
		verifyClose(cust_id);
	}
	else if(i==27) {	
		verifyClose();
	}
}
function verifyClose(list) {
	var returnFunc = window.dialogArguments
	returnFunc(list);
	window,close();
}
window.onbeforeunload = verifyClose

</SCRIPT>

</HEAD>
<?php

		$recive=$HTTP_GET_VARS[recive];
		$sum=$HTTP_GET_VARS[sum];
		$change=$HTTP_GET_VARS[change];
		$cus_id=$HTTP_GET_VARS[cust_id];
		if($cus_id!=null) {
			$cust_id=substr($cus_id,1);
			$find=find_record("customer","cust_id",$cust_id);
		}
		$add_point=getconfig("config","2:add_point");
		$pro_enable=getconfig("config","11:pro_enable");
		$pro_point=getconfig("config","12:pro_point");
		$alert_pro=0;
		if($pro_enable && $find){
			$result=select_record("customer","cust_id",$cust_id);
			$point=mysql_result($result,0,"point");
			$name=mysql_result($result,0,"name");
			$lastname=mysql_result($result,0,"lastname");
			//echo "xxxxxxx";
			$point=$point+(int)($sum/$add_point);
			if($point>=$pro_point){
				echo "<input type=\"hidden\" id=\"cust_id\" value=\"$cust_id\" />";
				echo "<input type=\"hidden\" id=\"point\" value=\"$point\" />";
				echo "<input type=\"hidden\" id=\"name\" value=\"$name\" />";
				$alert_pro=1;
			}
			else{
				echo "<input type=\"hidden\" id=\"cust_id\" value=\"no\" />";
				echo "<input type=\"hidden\" id=\"point\"  />";
				echo "<input type=\"hidden\" id=\"name\"  />";
			}
		}
		else{
			   echo "<input type=\"hidden\" id=\"cust_id\" value=\"no\" />";
			   echo "<input type=\"hidden\" id=\"point\"/>";
			   echo "<input type=\"hidden\" id=\"name\"  />";
		}
		
?>
<BODY bgcolor="#FFFFFF" onload="init();" scroll=no>
<center>
<table border="0" width="100%" height="100%" cellspacing="0">
						
						<tr bgcolor="#FFFFaa">
						<td>
						<b>&nbsp;&nbsp;&nbsp;&nbsp;<font size="+2" color="#660099">�Ѻ��</font>&nbsp;&nbsp;</b>
						</td>
						<td>
						<b><font size="+2" color="#660099"><?echo $recive;?></font></b>
						</td>
						</tr>

						<tr bgcolor="#FFFFaa">
						<td>
						<b>&nbsp;&nbsp;&nbsp;&nbsp;<font size="+2" color="#660099">���</font>&nbsp;&nbsp;</b>
						</td>
						<td>
						<b><font size="+2" color="#660099"><?echo $sum;?></font></b>
						</td>
						</tr>

						<tr bgcolor="#77bbff">
						<td>
						<b>&nbsp;&nbsp;&nbsp;&nbsp;<font size="+2" color="#660099">�͹</font>&nbsp;&nbsp;</b>
						</td>
						<td>
						<b><font size="+2" color="#660099"><?echo $change;?></font></b>
						</td>
						</tr>
						<?if($alert_pro==1){?>
						<tr bgcolor="#FF6600">
						<td>
						<b>&nbsp;&nbsp;&nbsp;&nbsp;<font color="#660099">�س <?echo $name;?> </font>&nbsp;&nbsp;</b>
						</td>
						<td>
						<b><font color="#660099">���Ѻ������� ! </font></b>
						</td>
						</tr>
						<?}?>

						

</table>
</form>
</center>		
</BODY>
</HTML>
