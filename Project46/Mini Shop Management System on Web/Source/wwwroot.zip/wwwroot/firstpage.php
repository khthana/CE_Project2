<!---------------------- ˹�� firstpage -------------------------->

<script type="text/javascript">
		function full_win() {	
			var bloodythief = 5;
			 window.setTimeout("window.close()",bloodythief*100);
			 window.opener = top;		
			window.open('login.php?index1=65414514156416242151543113','name','fullscreen=1');			
		}			
</script>
<?php
		include("fn_mysql.php");
		$result=connect_mysql("db_admin");

		//---------step1: Initial=>��� database �ѧ���١���ҧ set status=no
				if(!$result){
					 setconfig("createdb","1:status","no");//function
				}

		//---------step2: Select page------------------
				$result=getconfig("createdb","1:status");
				if($result=="no"){
						require("builddatabase.php");
						setconfig("createdb","1:status","yes");//function
						require("reg.php");
				}
				else{
						?><body onload="full_win();"></body><?
				}

?>