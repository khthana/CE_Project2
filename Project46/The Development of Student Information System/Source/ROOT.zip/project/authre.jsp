<%@ page contentType="text/html; charset=tis-620" language="java" pageEncoding="tis-620" %>
<jsp:useBean id="authen" class="auth.user" />
	<jsp:setProperty name="authen" property="*" />
<%
	if( session.isNew() )  {  session.setAttribute("auth","0"); response.sendRedirect("auth.jsp");  }
	else {
		if( !(authen.Auth()) ) { response.sendRedirect("auth.jsp");  session.setAttribute("auth", "1"); } 
		else {  session.setAttribute("user", authen.getUser()); session.setAttribute("name", authen.getName()); session.setAttribute("auth", "1");  
			if( authen.getGroup().equals("b") )  response.sendRedirect("std.jsp"); 
		}
	}
%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>ʶҺѹ෤����վ�Ш������� �Ҵ��кѧ</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
<LINK href="css/sitestyle.css"  type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2800.1400" name=GENERATOR>
</HEAD>
<BODY leftMargin=0 topMargin=0 off autocompleted marginwidth="0"  marginheight="0">
<table width="100%"  height="100%" border=0   cellspacing="0" cellpadding="0"  background="pic/shadow.JPG">
  <tr valign="top" >
    <td height="35"><IMG  height="100%"alt="ʶҺѹ෤����վ�Ш������� �Ҵ��кѧ" src="pic/header.gif" /></td>
    <td width="100%" background="pic/pad.gif">&nbsp;</td>
  </tr>
  <tr valign="top">
    <td colspan="2">
		<table width="100%"  border="0" cellspacing="0" cellpadding="0" >
  <tr valign="top">
    <td><jsp:include page="popup.jsp" flush="false"></jsp:include></td>
  </tr>
  <tr>
    <td>�͵�͹�Ѻ����к�����¹�ѡ�֡��ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ 
	 </td>
  </tr>
</table>
	</td>
  </tr>
  <tr valign="bottom">
    <td height="10%" colspan="2" align="right">
	<SPAN class=copyright>
		Copyrighted by Division of System&nbsp;&amp;&nbsp;Programming. CRSC, KMITL. 2003<BR>
		&copy; Division of System&nbsp;&amp;&nbsp;Programming. CRSC, KMITL. All rights reserved.
	</SPAN>
	</td>
  </tr>
</table>
</BODY>
</HTML>
