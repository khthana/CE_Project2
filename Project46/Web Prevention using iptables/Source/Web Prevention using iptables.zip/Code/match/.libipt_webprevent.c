#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include <ctype.h>

#include <iptables.h>
//#include <linux/netfilter_ipv4/ipt_string.h>

#include <linux/netfilter_ipv4/ipt_webprevent.h>

static struct option opts[] = {
	{.name = 0}
};
/* Function which prints out usage message. */
static void
help(void)
{
	printf("WEBPREVENT match \n",IPTABLES_VERSION);
}

/* Initialize the match. */
static void
init(struct ipt_entry_match *m, unsigned int *nfcache)
{
	*nfcache |= NFC_UNKNOWN;
}


/* Function which parses command options; returns true if it
   ate an option */

static int parse(int c,char **argv,int invert,unsigned int *flags,const struct ipt_entry *entry,unsigned int *nfcache,struct ipt_entry_match **match)
{
	//if(c) {
	//	exit_error(PARAMETER_PROBLEM,"you can't option");
	//	return 0;
	//}
	return 0;
}
/* Final check; must have specified --string. */
static void final_check(unsigned int flags)
{
}


/* Prints out the matchinfo. */
static void print(const struct ipt_ip *ip,const struct ipt_entry_match *match,int numeric)
{
	//const struct webprevent_info *info = (const struct webprevent_info*) match->data;

	//printf("WEBPREVENT match");
}


/* Saves the union ipt_matchinfo in parseable form to stdout. */
static void save(const struct ipt_ip *ip, const struct ipt_entry_match *match)
{
	//const struct webprevent_info *info = (const struct webprevent_info*) match->data;

	//printf("webprevent ");
}


static struct iptables_match webprevent = {
    .next	   = NULL,
    .name          = "webprevent",
    .version       = IPTABLES_VERSION,
    .size          = IPT_ALIGN(sizeof(struct webprevent_info)),
    .userspacesize = IPT_ALIGN(sizeof(struct webprevent_info)),
    .help          = &help,
    .init          = &init,
    .parse         = &parse,
    .final_check   = &final_check,
    .print         = &print,
    .save          = &save,
    .extra_opts    = opts
};


void _init(void)
{
	register_match(&webprevent);
}
