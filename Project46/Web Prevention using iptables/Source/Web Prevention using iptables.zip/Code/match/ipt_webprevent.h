#ifndef _IPT_WEBPREVENT_H
#define _IPT_WEBPREVENT_H

/* *** PERFORMANCE TWEAK ***
 * Packet size and search string threshold,
 * above which sublinear searches is used. */
#define FILENAME_LENGTH 32
#define HAYSTACK_THRESH	20
#define NEEDLE_THRESH	13

#define BM_NLEN 256
#define BM_HLEN 1024
#define ROW 10
#define COLUMN 50
#define MAX_LENGTH 4096

typedef char *(*proc_ipt_search) (char *, char *, int, int);

struct content_message {
	char message[MAX_LENGTH]; // used to keep rule list
	char rule[ROW][COLUMN]; //used to create rule list array
	int first_time; //used to check entrance to create rule first
	int check; // loop check rule
	int wrote; // check entrance for write file
};

struct webprevent_info {
    char string[FILENAME_LENGTH];  // in the fulture, it 's name's file
    //u_int16_t invert;
    //u_int16_t len;
};

#endif /* _IPT_WEBPREVENT_H */
