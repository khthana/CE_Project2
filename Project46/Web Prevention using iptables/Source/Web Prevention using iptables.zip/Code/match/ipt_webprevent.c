#include <linux/module.h>
#include <linux/skbuff.h>
#include <linux/file.h>
#include <net/sock.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/string.h>
#include <asm/uaccess.h>
#include <linux/spinlock.h>

#include <linux/netfilter_ipv4/ip_tables.h>
#include "ipt_webprevent.h"

#define MAX_LENGTH 4096
#define RULE_LEN 256

#ifndef CONFIG_PROC_FS
#error "Proc file system support is required for this module"
#endif

#define DEBUGP printk

MODULE_LICENSE("GPL");

//typedef content_message content_m;

static struct content_message content_m;
static struct proc_dir_entry *proc_net_rulelist = NULL;
static struct proc_dir_entry *net_rule_file = NULL;

static int data_read(char *page,char **start,off_t offset,int count,int *eof,void *data)
{
	int len;
	struct content_message *content_m = (struct content_message *)data;
	len = sprintf(page,"%s",content_m->message);

	return len;
}

static int data_write(struct file *file,const char *page,unsigned long count,void *data)
{
	//DEBUGP("write data\n");
	int len = 0;
	struct content_message *content_m = (struct content_message *)data;

	if(count < RULE_LEN)
		len = RULE_LEN;
	else
		len = count;

	if(content_m->wrote == 0) {
		content_m->wrote = 1;
		DEBUGP("len = %d\n",len);
		if(copy_from_user(content_m->message,page,len))
			return -EFAULT;

		content_m->message[len] = '\0';
	}

	return len;
}

/* Boyer Moore Sublinear string search - VERY FAST */
char *search_sublinear (char *needle, char *haystack, int needle_len, int haystack_len) 
{
	//DEBUGP("in search sublinear\n");
	int M1, right_end, sk, sh;  
	int ended, j, i;

	int skip[BM_HLEN], shift[needle_len], len[needle_len];
	
	/* Setup skip/shift tables */
	M1 = right_end = needle_len-1;
	for (i = 0; i < BM_HLEN; i++) skip[i] = needle_len;  
	for (i = 0; needle[i]; i++) skip[needle[i]] = M1 - i;  

	for (i = 1; i < needle_len; i++) {   
		for (j = 0; j < needle_len && needle[M1 - j] == needle[M1 - i - j]; j++);  
		len[i] = j;  
	}  

	shift[0] = 1;  
	for (i = 1; i < needle_len; i++) shift[i] = needle_len;  
	for (i = M1; i > 0; i--) shift[len[i]] = i;  
	ended = 0;  
	
	for (i = 0; i < needle_len; i++) {  
		if (len[i] == M1 - i) ended = i;  
		if (ended) shift[i] = ended;  
	}  

	/* Do the search*/  
	while (right_end < haystack_len)
	{
		for (i = 0; i < needle_len && haystack[right_end - i] == needle[M1 - i]; i++);  
		if (i == needle_len) {
			//DEBUGP("in search sublinear return is : %s :end data\n\n\n ",haystack+(right_end - M1));
			return haystack+(right_end - M1);
		}
		
		sk = skip[haystack[right_end - i]];  
		sh = shift[i];
		right_end = max(right_end - i + sk, right_end + sh);  
	}

	return NULL;
}  

/* Linear string search based on memcmp() */
char *search_linear (char *needle, char *haystack, int needle_len, int haystack_len) 
{
	char *k = haystack + (haystack_len-needle_len);
	char *t = haystack;
	
	while ( t <= k ) {
		if (memcmp(t, needle, needle_len) == 0) {
			//DEBUGP("in search linear is ==> %s ==> end data\n\n",t);
			return t;
		}
		t++;
	}

	return NULL;
}

static int match(const struct sk_buff *skb,const struct net_device *in,const struct net_device *out,const void *matchinfo,int offset,const void *hdr,u_int16_t datalen,int *hotdrop)
{
	//DEBUGP("\nentrance match\n");
	if(content_m.check >= 10) {
		//content_m.check = 0;
		content_m.check = 0;
	}
	//const struct ipt_string_info *info = matchinfo;
	//int i;
		
	//DEBUGP("message==>: %s\n",content_m.message);
	//DEBUGP("struct ip.........\n");
	struct iphdr *ip = skb->nh.iph;
	//DEBUGP("int hlen,nlen........\n");
	int hlen, nlen;
	//DEBUGP("char needle....\n");
	char *needle, *haystack;
	//DEBUGP("proc_ip_search......\n");
	proc_ipt_search search=search_linear;

	//DEBUGP("return ip .....\n");
	if ( !ip ) return 0;

	//char rule[3][50];

	//DEBUGP("if content.....\n");
	if(content_m.first_time == 0) {
		content_m.first_time = 1;
		int i,j,l,cnt=0;
		//char rule[33][50];
		j = 0;
		//if(strcmp(content_m.message,)) return 0;
		//DEBUGP("while loop ....\n");
		while(cnt < 10){
			i=j;l=0;char buf[50] = {'\0'};
			for(;content_m.message[i] != '\n';i++){
				if(content_m.message[i] == '\n') break;
				buf[l++] = content_m.message[i];
				j++;
			}
			strcpy(content_m.rule[cnt],buf);
			content_m.rule[cnt][j] = '\0';
			//DEBUGP("rule ===> %s\n",content_m.rule[cnt]);
			cnt++;
			j += 1;
		}
	}
	/* get lenghts, and validate them */
	//nlen=info->len;
	//int chec k = 0;
	//while(check < 3) {
	//nlen=strlen(rule[check]);
	hlen=ntohs(ip->tot_len)-(ip->ihl*4);
	//if ( nlen > hlen ) return 0;
	haystack=(char *)ip+(ip->ihl*4);
	//DEBUGP("hay before while : %s\n",haystack);

	//int check = 0;
	//DEBUGP("check before while(m_check) : %d\n",content_m.check);

	
	while(content_m.check <= 9) {
		
		nlen=strlen(content_m.rule[content_m.check]);
		//DEBUGP("check in while : %d\n",content_m.check);
		if ( nlen > hlen ){
			content_m.check = 0;
			return 0;
		}

	//needle=(char *)&info->string;
		needle=content_m.rule[content_m.check];
	//haystack=(char *)ip+(ip->ihl*4);
	
		//DEBUGP("needle : %s\n",needle);
		//DEBUGP("haystack : %s\n",haystack);
		//DEBUGP("nlen : %d\n",nlen);
		//DEBUGP("hlen : %d\n",hlen);
		//DEBUGP("before sublinear\n");
	/* The sublinear search comes in to its own
	 * on the larger packets */
		if ( (hlen>HAYSTACK_THRESH) && (nlen>NEEDLE_THRESH) ) {
			if ( hlen < BM_HLEN ) {
				//DEBUGP("search sublinear\n\n\n");
				search=search_sublinear;
			}else{
				if (net_ratelimit())
					printk(KERN_INFO "Packet too big (%d bytes)\n", hlen );
			}
		}
		//DEBUGP("check :==> %d\n",content_m.check);
		content_m.check += 1;
		if((search(needle,haystack,nlen,hlen)!=NULL))
			return 2;
		
	}
	return 0;
    //return ((search(needle, haystack, nlen, hlen)!=NULL));// ^ info->invert);
}

static int checkentry(const char *tablename,const struct ipt_ip *ip,void *matchinfo,unsigned int matchsize,unsigned int hook_mask)
{
	//DEBUGP("\nentrance checkentry\n");
	struct webprevent_info *info = (struct webprevent_info *)matchinfo;
	if (matchsize != IPT_ALIGN(sizeof(struct webprevent_info)))
                return 0;

	content_m.first_time = 0;
	content_m.check = 0;
	//comtent_m.message = {'\0'};
	//strcpy(content_m.message,"/%00\n/%0a.pl\n/%20%20%20%20%20.htr\n/test.txt\n/cmd.exe\n/cgi-bin///\n/cgi-bin/Count.cgi\n/cgi-bin/calendar\nGET / HTTP /1.0\n../../etc/passwd\n");

	//int i;
        //i = strlen(content_m.message);
	//DEBUGP("len of messge : %d\n",i);
	//content_m.message[i] = '\0';

	net_rule_file = create_proc_entry(info->string,0666,proc_net_rulelist);
	if(net_rule_file == NULL)
		return -ENOMEM;

	net_rule_file->data = &content_m;
	net_rule_file->read_proc = &data_read;
	net_rule_file->write_proc = &data_write;
	net_rule_file->owner = THIS_MODULE;

	//DEBUGP("filename = %s\n",info->string);
	//DEBUGP("initialized module\n");
	return 1;
}

/*static struct ipt_match webprevent_match = {
	.list = {NULL,NULL},
	.name = "webprevent",
	.match = &match,
	.checkentry = &checkentry,
	.destroy =NULL,
	.me = THIS_MODULE
};*/
 
static struct ipt_match webprevent_match
= { { NULL, NULL }, "webprevent", &match, &checkentry, NULL, THIS_MODULE };

static int __init init(void)
{
	int errorcode;
	proc_net_rulelist = proc_mkdir("ipt_rulelist",proc_net);
	if(proc_net_rulelist){
		errorcode = ipt_register_match(&webprevent_match);

		if(errorcode)
			remove_proc_entry("ipt_rulelist",proc_net);
	}
	else
		errorcode = -EACCES;

	return errorcode;
	//return ipt_register_match(&webprevent_match);
}

static void __exit fini(void)
{
	ipt_unregister_match(&webprevent_match);
	remove_proc_entry("ipt_rulelist",proc_net);
}

module_init(init);
module_exit(fini);
