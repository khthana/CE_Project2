/* Copyright (c) 2002, Nokia Mobile Phones. All rights reserved */

//#include "MessageClient.h"
#include "camtimer.h"
_LIT16(Kb, "hello");
_LIT8(KMessage, "Hello world");
//const TInt len = 5;
//static const TDisplayMode KDeviceColourDepth = EColor4K;
//const TInt KJpgSavingQualityFactor = 55;
//static const TInt KJpegFrameIndex = 0;
CMessageClient* CMessageClient::NewL()
    {
    CMessageClient* self = NewLC();
    CleanupStack::Pop(self);
    return self;
    }

CMessageClient* CMessageClient::NewLC()
    {
    CMessageClient* self = new (ELeave) CMessageClient();
    CleanupStack::PushL(self);
    self->ConstructL(KMessage);
    return self;
    }

CMessageClient::CMessageClient()
: CActive(CActive::EPriorityStandard),
  iState(EWaitingToGetDevice)
 // iLog()
    {
    CActiveScheduler::Add(this);
    }

CMessageClient::~CMessageClient()
    {
    Cancel();
 //   delete iConverter;
    iSendingSocket.Close();
    iSocketServer.Close();
    delete iMessage;
    iMessage = NULL;

    delete iServiceSearcher;
    iServiceSearcher = NULL;
    }

void CMessageClient::ConstructL(const TDesC8& aMessage)
    {
    iServiceSearcher = CMessageServiceSearcher::NewL();
  //  iConverter = CMdaImageDescToBitmapUtility::NewL(*this);
    iMessage = aMessage.AllocL();
    iFlag = EFalse;
    }

void CMessageClient::DoCancel()
    {
    // no implementation required
    }

void CMessageClient::RunL()
    {
    if (iStatus != KErrNone)
        {
        switch (iState)
            {
            case EGettingDevice:
                if (iStatus = KErrCancel)
                    {
                    NEikonEnvironment::MessageBox(_L("No device selected"));
                //  iLog.LogL(_L("No device selected"));
                    }
                break;
            case EGettingService:
            case EGettingConnection:
            case EDisconnecting:
                //  iLog.LogL(_L("Connection error "), iStatus.Int());
                 NEikonEnvironment::MessageBox(_L("Connect Error"));
                 iState = EWaitingToGetDevice;
                 break;
            case EWaitingToSend:
            {
              iForm->OpenBuff();
             // 8 to 16
         //    len =  ConvertTDes8ToTDes16(iBuffer,iBuf);
        //      NEikonEnvironment::MessageBox(iBuf);
             ///  string to int
        //     len = StringToInt(iBuf);
        //     TBuf8<5> i;

            }
            break;
            default:
                Panic(EBTPointToPointInvalidLogicState);
                break;
            }
        }
    else
        {
        switch (iState)
            {
            case EGettingDevice:
                // found a device now search for a suitable service
            //    iLog.LogL(iServiceSearcher->ResponseParams().DeviceName());
                iState = EGettingService;
                iStatus = KRequestPending; // this means that the RunL can not be called until
                                           // this program does something to iStatus
                iServiceSearcher->FindServiceL(iStatus);
                SetActive();
                break;
            case EGettingService:
            //    iLog.LogL(_L("Found Service"));
                iState = EGettingConnection;
                ConnectToServerL();
                break;
            case EGettingConnection:
            //    iLog.LogL(_L("Connected"));
                 iState = EWaitingToSend;
                NEikonEnvironment::MessageBox(_L("Wait for data"));
                RequestData();
                break;
            case EWaitingToSend:
              {
               iForm->OpenBuff();
                // 8 to 16
    //         len =  ConvertTDes8ToTDes16(iBuffer,iBuf);
    //          NEikonEnvironment::MessageBox(iBuf);
             ///  string to int
    //         len = StringToInt(iBuf);

    //       const  TInt lengh = len;
    //       do segmented buffer tests
             //  NEikonEnvironment::MessageBox(_L("Read Success"));
              /* --------------
                HBufC* text = HBufC::NewLC(iBuffer.Length());
                text->Des().Copy(iBuffer);
                iLog.LogL(*text);
                CleanupStack::PopAndDestroy(text);
                RequestData(); //  Get more data
                iLog.LogL(_L("Sent message"));
               */
               }
                break;
            case EDisconnecting:
            //    iLog.LogL(_L("Disconnected"));
                iState = EWaitingToGetDevice;
                break;
            default:
                Panic(EBTPointToPointInvalidLogicState);
                break;
            };
        }
    }

void CMessageClient::ConnectL()
    {

    if (iState == EWaitingToGetDevice && !IsActive())
        {
        iState = EGettingDevice;
        iServiceSearcher->SelectDeviceByDiscoveryL(iStatus);


       SetActive();
        }
    else
        {
         NEikonEnvironment::MessageBox(_L("Server Busy"));
    //    iLog.LogL(_L("Client busy"));
    //    User::Leave(KErrInUse);
        }
    }

void CMessageClient::ConnectToServerL()
    {
  //  iLog.LogL(_L("Connecting to Service"));

    User::LeaveIfError(iSocketServer.Connect());

    User::LeaveIfError(iSendingSocket.Open(iSocketServer, _L("RFCOMM")));

    TBTSockAddr address;
    address.SetBTAddr(iServiceSearcher->BTDevAddr());
    address.SetPort(iServiceSearcher->Port());

    iSendingSocket.Connect(address, iStatus);

    SetActive();
    }
/*
-------------------------------------------------------------------------------

    MiuoOpenComplete();

    Description: From MMdaImageUtilObserver, implement this if you use this
                 observer to open a imagefile.

    Return value: N/A

-------------------------------------------------------------------------------
*/

void CMessageClient::SendMessageL(const TDesC8& aMessage)
    {
    if (iState != EWaitingToSend)
        {
        NEikonEnvironment::MessageBox(_L("can't send 1"));
        User::Leave(KErrDisconnected);
        }
    else if (IsActive())
        {
        NEikonEnvironment::MessageBox(_L("can't send 2"));
        User::Leave(KErrInUse);
        }
    else{
       iLen = aMessage.Length();
       iMessage = aMessage.AllocL();
   //    iSendingSocket.Write(*iMessage, iStatus);
       iSendingSocket.Send(*iMessage, 0, iStatus, iLen);
       SetActive();
       }
 //     NEikonEnvironment::MessageBox(_L("sended"));
    }

void CMessageClient::RequestData()
    {
      iFlag = ETrue;
   //   iSendingSocket.RecvOneOrMore(iBuffer, 0, iStatus, iLen);
        iSendingSocket.Recv(iBuffer, 0, iStatus, iLen);
         SetActive();
    //  NEikonEnvironment::MessageBox(_L("Wait for data"));
   //   User::InfoPrint(
      ////////////-----loop wait 10 s
                TTime begin;
		TTime end;
		TTimeIntervalMicroSeconds fromBeginToEndMicroseconds ;
		fromBeginToEndMicroseconds =0;
		begin.HomeTime();
		TTimeIntervalMicroSeconds maxtime;
		maxtime = 600000;
		// Loop preview pictures unti given time has reached.
		while (fromBeginToEndMicroseconds <maxtime)
			{
                      //  iForm->TakePictureL(ERCLow) to take a low quality image
			end.HomeTime();
		    fromBeginToEndMicroseconds  = end.MicroSecondsFrom(begin);
			}
      iSendingSocket.CancelRecv();

    }

TBool CMessageClient::IsBusy()
    {
    return IsActive();
    }

TBool CMessageClient::IsConnected()
    {
    return iState == EWaitingToSend;
    }

TDes8& CMessageClient::GetBuffer()
    {
    return iBuffer;
    }

TBool CMessageClient::GetFlag()
{
     return iFlag;
}

TInt CMessageClient::StringToInt(const TDesC& aStr)
{
TInt aValue;
TLex(aStr).Val(aValue);
return aValue;
}

TInt CMessageClient::ConvertTDes8ToTDes16(const TDesC8& aFrom, TDes16& aTo)
{
 return(CnvUtfConverter::ConvertToUnicodeFromUtf8(aTo,aFrom));
}

TInt CMessageClient::ConvertTDes16ToTDes8(const TDesC16& aFrom, TDes8& aTo)
{
 return(CnvUtfConverter::ConvertFromUnicodeToUtf8(aTo,aFrom));
}

void CMessageClient::SetView(CCamTimerFormView& aFormView)
{
 iForm = &aFormView;
}
