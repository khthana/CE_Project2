/* Copyright (c) 2002, Nokia Mobile Phones. All rights reserved */

#include "MessageServer.h"
#include "MessageProtocolConstants.h"
#include "MessageServiceAdvertiser.h"
#include "Log.h"
#include "BtPointToPoint.pan"
#include "EikonEnvironment.h"
 _LIT8(KMessage, "Hello world");
static const TInt KListeningQueSize = 1;

CMessageServer* CMessageServer::NewL()
    {
    CMessageServer* self = NewLC();
    CleanupStack::Pop(self);
    return self;
    }

CMessageServer* CMessageServer::NewLC()
    {
    CMessageServer* self = new (ELeave) CMessageServer();
    CleanupStack::PushL(self);
   self->ConstructL(KMessage);
    return self;
    }

CMessageServer::CMessageServer()
: CActive(CActive::EPriorityStandard),
  iState(EDisconnected)
    {
    CActiveScheduler::Add(this);
    }

CMessageServer::~CMessageServer()
    {
    TRAPD(err,StopL());
    if (err != KErrNone)
        {
        Panic(EBTPointToPointServerStop);
        }
    delete iAdvertiser;
    iAdvertiser = NULL;
    Cancel();
    }
 void CMessageServer::ConstructL(const TDesC8& aMessage)
    {
    iAdvertiser = CMessageServiceAdvertiser::NewL();
    iMessage = aMessage.AllocL();
    iLoop = EFalse;
    }

void CMessageServer::DoCancel()
    {
    }

void CMessageServer::RunL()
    {
    if (iStatus == KErrDisconnected)
        {
        NEikonEnvironment::MessageBox(_L("Disconnected"));
        // Disconnected so go back to listening
        StopL();
        return;
        }
    else if (iStatus == KErrAbort)
        {
        NEikonEnvironment::MessageBox(_L("Disconnected"));
        StopL();
        return;
        }

    switch (iState)
        {
        case EConnecting:
            // iLog.LogL(_L("Connected"));

            // do not accept any more connections
            iAdvertiser->UpdateAvailabilityL(EFalse);
            iState = EWaitingForMessage;
         
            iLoop = ETrue;
            break;

        case EWaitingForMessage:
            {
            }
            break;

        default:
            Panic(EBTPointToPointReceiverInvalidState);
            break;
        }
    }

void CMessageServer::SendMessageL(const TDes8& aMessage)
    {
    if (iState != EWaitingForMessage)
        {
        NEikonEnvironment::MessageBox(_L("Not Ready "));
        User::Leave(KErrDisconnected);
        }
    else if (IsActive())
        {
        NEikonEnvironment::MessageBox(_L("Not Active"));
        User::Leave(KErrInUse);
        }
    else{
     //  iLen = 60000;
     /*
       TBuf8<10> len;
       len.Num(aMessage.Length());
  //     iLen = aMessage.Length();
       iMessage = len.AllocL();

       */
       Len = aMessage.Length();
    //   for(TInt i=0;i< (30000-Len);i++)
       while(aMessage.Length() < 5000)
       {
       aMessage.Append('0');
       }
       iMessage = aMessage.AllocL();
       iAcceptedSocket.Write(*iMessage, iStatus);
    //   iAcceptedSocket.Send(*iMessage, 0, iStatus, iLen);
       SetActive();
       }
 //     NEikonEnvironment::MessageBox(_L("sended"));
    }


void CMessageServer::StartL()
    {
    if (iState != EDisconnected)
        {
     //   User::Leave(KErrInUse);
        NEikonEnvironment::MessageBox(_L("Can't Recieve"));
        }
        else
        {
    User::LeaveIfError(iSocketServer.Connect());
    User::LeaveIfError(iListeningSocket.Open(iSocketServer, KServerTransportName));

    //  Get a channel to listen on - same as the socket's port number
    TInt channel;
    User::LeaveIfError(
        iListeningSocket.GetOpt(KRFCOMMGetAvailableServerChannel, KSolBtRFCOMM, channel)
    );

    TBTSockAddr listeningAddress;
    listeningAddress.SetPort(channel);
    // iLog.LogL(_L("Get port = "), channel);

    User::LeaveIfError(iListeningSocket.Bind(listeningAddress));
    User::LeaveIfError(iListeningSocket.Listen(KListeningQueSize));

    iAcceptedSocket.Close();    // close old connection - if any
    User::LeaveIfError(iAcceptedSocket.Open(iSocketServer));  // Open abstract socket

    iState = EConnecting;
    iListeningSocket.Accept(iAcceptedSocket, iStatus);
    SetActive();

 //   iLog.LogL(_L("Accept next Connection"));

    SetSecurityOnChannelL(EFalse, EFalse, ETrue, channel);

    iAdvertiser->StartAdvertisingL(channel);
    iAdvertiser->UpdateAvailabilityL(ETrue);
                }/////////// end if
    }

void CMessageServer::SetSecurityOnChannelL(TBool aAuthentication,
                                           TBool aEncryption,
                                           TBool aAuthorisation,
                                           TInt aChannel)
    {
    // a connection to the security manager
    RBTMan secManager;

    // a security session
    RBTSecuritySettings secSettingsSession;

    // define the security on this port
    User::LeaveIfError(secManager.Connect());
    CleanupClosePushL(secManager);
    User::LeaveIfError(secSettingsSession.Open(secManager));
    CleanupClosePushL(secSettingsSession);

    // the security settings
    TBTServiceSecurity serviceSecurity(KUidBTPointToPointApp, KSolBtRFCOMM, 0);

    //Define security requirements
    serviceSecurity.SetAuthentication(aAuthentication);
    serviceSecurity.SetEncryption(aEncryption);
    serviceSecurity.SetAuthorisation(aAuthorisation);

    serviceSecurity.SetChannelID(aChannel);
    TRequestStatus status;
    secSettingsSession.RegisterService(serviceSecurity, status);

    User::WaitForRequest(status); // wait until the security settings are set
    User::LeaveIfError(status.Int());

    CleanupStack::PopAndDestroy();  //  secManager
    CleanupStack::PopAndDestroy();  //  secSettingsSession
    }

void CMessageServer::StopL()
    {
    if (iState != EDisconnected)
        {
        if (iAdvertiser->IsAdvertising())
            {
            iAdvertiser->StopAdvertisingL();
            }
        iAcceptedSocket.Close();
        iListeningSocket.Close();
        iSocketServer.Close();
        }
        iState = EDisconnected;
    }

void CMessageServer::RequestData()
    {
   //  iAcceptedSocket.RecvOneOrMore(iBuffer, 0, iStatus, iLen);
       NEikonEnvironment::MessageBox(_L("Wait for data"));
       iAcceptedSocket.Recv(iBuffer, 0, iStatus, iLen);
       SetActive();
       ////////////-----loop wait 10 s
                TTime begin;
		TTime end;
		TTimeIntervalMicroSeconds fromBeginToEndMicroseconds ;
		fromBeginToEndMicroseconds =0;
		begin.HomeTime();
		TTimeIntervalMicroSeconds maxtime;
		maxtime = 800000;
		// Loop preview pictures unti given time has reached.
		while (fromBeginToEndMicroseconds <maxtime)
			{
			// Call TakePictureL() to take a low quality image
			end.HomeTime();
		        fromBeginToEndMicroseconds  = end.MicroSecondsFrom(begin);
			}
       iAcceptedSocket.CancelRecv();
    }

TDes8& CMessageServer::GetBuffer()
    {
    return iBuffer;
    }

TBool CMessageServer::IsConnected()
    {
    return !(iState == EDisconnected);
    }

void CMessageServer::SetZero()
{
    iBuffer.Delete(0,60000);
}
TBool CMessageServer::GetFlag()
{
    return iLoop;
}
