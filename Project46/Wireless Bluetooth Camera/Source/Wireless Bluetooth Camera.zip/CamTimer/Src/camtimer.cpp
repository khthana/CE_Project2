/*

        CamTimer.CPP - source file for CamTimer application, Series 60
        C++ implementation

History:
Version 1.10, October 17th 2002
Added features: Snap sound, Launching Photo album from menu for 
				further use of the picture 
				and an updated pkg file for Series 60

Version 1.0, December 1st 2001
CamTimer Released in Forum Nokia

*/

#include "CamTimer.h"


// Constants
// CamTimer application UID
const TUid KUidCamTimerApp = { 0x101F5462 };
// UID of CamTimer view
const TUid KCamTimerViewId = { 1 };
// Quality factor for JPG saving
const TInt KJpgSavingQualityFactor = 55;
// Initial value for waiting time.
const TInt KInitialValue=1;
// UID of Photo album application
const TUid KPhotoAlbumUid = { 0x101F4CD1 };
static const TDisplayMode KDeviceColourDepth = EColor4K;
static const TInt KJpegFrameIndex = 0;

_LIT(KWelcomeText,"Welcome");
_LIT(KWelcomeText1,"to");
_LIT(KWelcomeText2,"Video on Mobile");
_LIT(KThumbnailFilename, "C:\\Nokia\\Images_tn\\CamTimerPicture.jpg");
//_LIT(KThumbnailFilename, "E:\\Wi_an\\a_tn\\CamTimerPicture.jpg");
_LIT (KMultiBitmapFilename,"c:\\System\\Apps\\CamTimer\\images.mbm");
_LIT(KJpegFileName, "C:\\Nokia\\Images\\CamTimerPicture.jpg");
_LIT(KCamTimerFilename, "C:\\Nokia\\Images\\Picture");
//_LIT(KCamTimerFilename, "E:\\Wi_an\\a\\CamTimerPicture.jpg");
_LIT8(KBuff, "hello");
_LIT8(KMessage, "Hello world");
_LIT16(Kb, "hello");
// Definitions
#define KSnapSoundId 2

//
// CCamTimerContainer
// This container does not have any controls in it, it is only used
// to draw an image.
//

/*
-------------------------------------------------------------------------------

    ConstructL();

    Description: 2nd phase Constructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerContainer::ConstructL(CCamTimerFormView& aFormView)
    {
    iBmp = new (ELeave) CFbsBitmap;
	// take a handle to the object owninf this container
    iFormView = &aFormView;
	// flag: image ready to be drawn or not
    iImageReady = EFalse;
    Flag        = EFalse;
	// Construct self
    ConstructContainerControlL();
    iBackgroundImage = NBitmapMethods::CreateBitmapL(KMultiBitmapFilename,0);
    }


/*
-------------------------------------------------------------------------------

    ~CCamTimerContainer();

    Description: Destructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/
CCamTimerContainer::~CCamTimerContainer()
    {
    delete iBmp;
    iFormView = NULL;

      delete iBackgroundImage;
     iBackgroundImage = NULL;
    }


/*
-------------------------------------------------------------------------------

    ConstructContainerControlL();

    Description: Constructing container control

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerContainer::ConstructContainerControlL()
    {
	// Makes the control window owning
    CreateWindowL(); 
    }


/*
-------------------------------------------------------------------------------

    Draw();

    Description: This function draws the application view on the screen.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerContainer::Draw(const TRect& /*aRect*/) const
    {
	// Get the graphics context in which to draw.
    CGraphicsContext& gc=SystemGc();
    CWindowGc& gc2 = SystemGc();
    if(iImageReady)
        {
		// draw our picture
        gc.DrawBitmap( Rect(), iBmp);
		// Draw a rectangle.
        gc.DrawRect(Rect());
        }
    else
        {
         gc2.BitBlt(Rect().iTl,iBackgroundImage);
        // no image to draw, draw a text saying "Welcome to CamTimer"
		// to inform user on behaviour of the directional button
     /*
        // Draw white background
        gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
        gc.SetBrushColor(KRgbWhite);
        gc.DrawRect(Rect());

        // Draw black outline
        gc.SetBrushStyle(CGraphicsContext::ENullBrush);
        gc.SetBrushColor(KRgbBlack);
        gc.DrawRect(Rect());

        // Draw text "Welcome to CamTimer"
        gc.SetPenColor(KRgbBlack);
        const CFont* fontUsed = iEikonEnv->TitleFont();
        gc.UseFont(fontUsed);

		// set text position on screen
        TInt baseline = Rect().Height() - fontUsed->AscentInPixels()*3;
		// margin is zero so that the text will be cenetred
        TInt margin=0;

        gc.DrawText(KWelcomeText2,Rect(),baseline,CGraphicsContext::ECenter,
																		margin);
		// set text position on screen
		baseline = Rect().Height() - fontUsed->AscentInPixels()*5;
		margin=0;
        gc.DrawText(KWelcomeText1,Rect(),baseline,CGraphicsContext::ECenter,
																		margin);
		// set text position on screen
		baseline = Rect().Height() - fontUsed->AscentInPixels()*7;
		margin=0;
        gc.DrawText(KWelcomeText,Rect(),baseline,CGraphicsContext::ECenter,
       															   margin);
     */
        }
    }


/*
-------------------------------------------------------------------------------

    GetBmp();

    Description: This function returns a pointer to the bitmap.

    Return value: N/A

-------------------------------------------------------------------------------
*/
CFbsBitmap* CCamTimerContainer::GetBmp()
    {
    // this function is used to get the bitmap to take a new picture
    // so reseting the bmp first
    iImageReady = EFalse;
    iBmp->Reset();
    return iBmp;
    }

/*
-------------------------------------------------------------------------------

    GetBmpForSaving();

    Description: This function returns a pointer to the bitmap.

    Return value: N/A

-------------------------------------------------------------------------------
*/
CFbsBitmap* CCamTimerContainer::GetBmpForSaving()
    {
    // this fuction is used to get the current image for saving
    // so no reseting this time
    return iBmp;
    }



//
// CCamTimerFormView
//

/*
-------------------------------------------------------------------------------

    ConstructL();

    Description: Default C++ Constructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/
CCamTimerFormView::CCamTimerFormView(TInt* aValue)	// C++ constructor
    : iWaitingTime(aValue)                          // Initialise data
    {
    }


/*
-------------------------------------------------------------------------------

    ConstructL();

    Description: 2nd phase Constructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::ConstructL()
    {
    // Current image index starts from zero (could used when saving images
	// (not used at the moment))
    iCurrentImage = 0;
	// flag to tell when the app is saving the image asynchronously
	// (can't take a new pict when saving)
    iSavingImage = EFalse;
    iSaving      = EFalse;
    iSaved       = EFalse;
    // Initialise a client to the camera server
    iCamserv = new(ELeave) RCameraServ;

    /// init iServer and iClient
     iServer = CMessageServer::NewL();
     iClient = CMessageClient::NewL();
     iClient->SetView(*this);
    // Init a file saver utility
    // iFileSaver = CMdaImageBitmapToFileUtility::NewL(*this);
     iFileSaver = CMdaImageBitmapToDescUtility::NewL(*this);
     iSaveFile  = CMdaImageBitmapToFileUtility::NewL(*this);
     iFormat = new (ELeave) TMdaJfifClipFormat;
  //   iConverter = CMdaImageFileToBitmapUtility::NewL(*this);
       iConverter = CMdaImageDescToBitmapUtility::NewL(*this);
       iPeriodicTimer = CPeriodic::NewL(CActive::EPriorityStandard);

    // Create player for snap sound
    iSoundPlayer = (STATIC_CAST(CAknAppUi*,CEikonEnv::Static()->AppUi()))->KeySounds();
    TRAPD(error, iSoundPlayer->AddAppSoundInfoListL( R_CAMERA_SNAP_SOUND ));
    if ( ( error != KErrAlreadyExists ) && ( error != KErrNone) )
        {
        User::LeaveIfError(error);
        }

    }


/*
-------------------------------------------------------------------------------

    ~CCamTimerFormView();

    Description: Destructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/
CCamTimerFormView::~CCamTimerFormView()
    {
    if (iPeriodicTimer)
    {
	 // Stop the periodic timer
	 iPeriodicTimer->Cancel();
     }

     delete iPeriodicTimer;
     iPeriodicTimer = NULL;
    if(iContainer)
    AppUi()->RemoveFromStack(iContainer);
    delete iServer;
    iServer = NULL;
    delete iClient;
    iClient = NULL;
    delete iCamserv;
    delete iFileSaver;
    delete iFormat;
    delete iConverter;
    delete iBitmap;
    delete iSaveFile;
    }

/*
-------------------------------------------------------------------------------

    Id();

    Description: Returns the id of the view object.

    Return value: N/A

-------------------------------------------------------------------------------
*/
TUid CCamTimerFormView::Id() const
    {
    return KCamTimerViewId;
    }


/*
-------------------------------------------------------------------------------

    DoActivateL();

    Description: Activate this view.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
	 TUid /*aCustomMessageId*/, const TDesC8& /*aCustomMessage*/ )
    {
    // Connect to Camera Server
    User::LeaveIfError(iCamserv->Connect());

    if (!iContainer) // if container hasn't been created yet, let's create it
        {
        // Then construct the UI components
        iContainer = new(ELeave) CCamTimerContainer;
        // Construct a view control with a ref. to this CCamTimerFormView
        iContainer->ConstructL(*this);
        // Sets view control's extent to the space available
        iContainer->SetRect(ClientRect());
        }

	// Activate the view control
    iContainer->ActivateL();
    }


/*
-------------------------------------------------------------------------------

    DoDeactivate();

    Description: Deactivate this view.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::DoDeactivate()
    {
    if (iContainer)
        {
        delete iContainer;
        iContainer = NULL;
        }

    // Disconnect from Camera server
    if(iCamserv)
        {
        iCamserv->Close();
        }

    }

// ---------------------------------------------------------------------------
// CCamTimerFormView::HandleForegroundEventL(TBool aForeground)
// Can be used to open and close the camera depending on the foreground event
// ---------------------------------------------------------------------------
void CCamTimerFormView::HandleForegroundEventL(TBool /*aForeground*/)
    {

    }

/*
-------------------------------------------------------------------------------

    TimerL();

    Description: Do timing showing a series of preview pictures.
				 Take picture and save it.
    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::TimerL()
     {
     if(!iSavingImage)
        {

        // turn on camera
   //      TurnCameraOnL();

		// For timing
		TTime begin;
		TTime end;
		TTimeIntervalMicroSeconds fromBeginToEndMicroseconds ;
		fromBeginToEndMicroseconds =0;
		begin.HomeTime();
		TTimeIntervalMicroSeconds maxtime;
		maxtime = *iWaitingTime;
		// Loop preview pictures unti given time has reached.
		while (fromBeginToEndMicroseconds <maxtime)
			{
			// Call TakePictureL() to take a low quality image
			TakePictureL(ERCLow);
			end.HomeTime();
		        fromBeginToEndMicroseconds  = end.MicroSecondsFrom(begin);
			}

		// Finally, take the picture
	   	TakePictureL(ERCLow);

		// Play the camera snap -sound

		// Save the final picture
                if(iSaved)
                {
                iSaving = ETrue;
                iSaved  = EFalse;
                SavePicture();
                }else{
                iSaving = EFalse;
		SaveImageL();
                }
      }
		// turn off camera
    //    TurnCameraOffL();
    }

/*
-------------------------------------------------------------------------------

    TurnCameraOnL();

    Description: Turn on the camera. Turning on the camera takes some time
                 and you can do something meaningful between turning on and
                 taking a picture.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::TurnCameraOnL()
    {
    // Status variable for async function calls
    TRequestStatus status( KErrNone );

    // Turn camera ON
    iCamserv->TurnCameraOn(status);
    User::WaitForRequest(status);
    if( status.Int() != KErrNone )
        {
        // error while turning ON, closing connection to server
        iCamserv->Close();
        User::Leave(status.Int());
        }
    }

/*
-------------------------------------------------------------------------------

    TurnCameraOffL();

    Description: Turn off the camera. A separate method to ease using
                 TurnCameraOnL() from a location other than from where the
                 actual picture is taken.
                 You can also turn camera off straight after taking the picture.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::TurnCameraOffL()
    {
    // Turn camera OFF
    User::LeaveIfError(iCamserv->TurnCameraOff());
    }

/*
-------------------------------------------------------------------------------

    TakePictureL();

    Description: Take a picture and show it on screen. This function sets up,
                 image quality and lighting settings and then gets one image
                 from the camera server.

    Note:        The camera has been turned ON earlier and it will be turned OFF
                 after returning from this function.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::TakePictureL(TCamTimerImageQuality aQuality)
    {
    // Check the given image quality and set up quality for camera server
    RCameraServ::TImageQuality imageQuality = RCameraServ::EQualityLow;

    if(aQuality == ERCHigh)     // taking a real picture (no snapshot)
        imageQuality = RCameraServ::EQualityHigh;

    // Get a bmp handle from our container
    CFbsBitmap* bmp = iContainer->GetBmp();
	CleanupStack::PushL(bmp);

    // Set image quality (High = 640x480 16M colors, Low = 160x120 4096 colors)
    User::LeaveIfError(iCamserv->SetImageQuality(imageQuality));

    // Status variable for async function calls
    TRequestStatus status( KErrNone );

    // Get an image
    iCamserv->GetImage( status, *bmp );
    User::WaitForRequest(status);
    if( status.Int() != KErrNone )
        {
        iCamserv->TurnCameraOff();
        iCamserv->Close();
        User::Leave(status.Int());
        }

    // Show the image on screen
    iContainer->iImageReady = ETrue;
    iContainer->DrawNow();

    // clear stack
    CleanupStack::Pop();  // bmp

    // clear local pointer
    bmp = NULL;
    }

/*
-------------------------------------------------------------------------------

    SaveImageL();

    Description: Save an image. This function starts an asynchronous series of
                 functions to save the image into a file.

    Return value: N/A

-------------------------------------------------------------------------------
*/

void CCamTimerFormView::SaveImageL()
    {
	// Delete old thumb nail-file
	RFs fsSession;
	User::LeaveIfError(fsSession.Connect());

	CFileMan* fileMan = CFileMan::NewL(fsSession);
        CleanupStack::PushL(fileMan);

	fileMan->Delete(KThumbnailFilename,0);

	CleanupStack::PopAndDestroy(); // FileMan
        fsSession.Close();

    // Be sure that we have an image to be saved
    if(iContainer->iImageReady)
        {
        // gets path where to save the image
        // TFileName newFilePathAndName(KCamTimerFilename);
        // Create Format and Codec
        // quality factor from 0 to 100 (55 used here)
        iFormat->iSettings.iQualityFactor = KJpgSavingQualityFactor;
        iFormat->iSettings.iSampleScheme =
        TMdaJpgSettings::TColorSampling(TMdaJpgSettings::EColor420);

        TMdaPackage* codec = NULL;
        CleanupStack::PushL(codec);
        iBuff.Copy(KBuff);
        iFileSaver->CreateL(iBuff, iFormat, codec, NULL );
		// set flag, can't take new pictures when saving
        iSavingImage = ETrue;
        iContainer->iImageReady = ETrue;
        iContainer->DrawNow();
		// codec
        CleanupStack::PopAndDestroy(1);

		// increase the "index" by one (not used for anything at the moment)
        iCurrentImage++;
        }
    }
void CCamTimerFormView::OpenBuff()
{
       TMdaPackage* codec = NULL;
       CleanupStack::PushL(codec);
       iConverter->OpenL(iClient->GetBuffer(), iFormat, codec, NULL );
//     iConverter->OpenL(KCamTimerFilename, iFormat, codec, NULL );
       CleanupStack::PopAndDestroy(1);
}
void CCamTimerFormView::StartRecieve()
{
   //   NEikonEnvironment::MessageBox(_L("Wait Connection"));
        TurnCameraOnL();
        iServer->StartL();
}

void CCamTimerFormView::StopRecieve()
{
   //   NEikonEnvironment::MessageBox(_L("Stop Recieve"));
        iPeriodicTimer->Cancel();
        TurnCameraOffL();
        iServer->StopL();
}

void CCamTimerFormView::OpenBuffer()
{
        OpenBuff();
}

void CCamTimerFormView::Connect()
{
       iClient->ConnectL();
}

void CCamTimerFormView::SetSave()
{
       if(GetStatusClient())
       {
       SavePicture();
       }else{
       iSaved = ETrue;
       }
}

void CCamTimerFormView::SendMessage()
{
       iServer->SendMessageL(iBuff);

}

void CCamTimerFormView::SavePicture()
{

        iSaved = EFalse;
      	// Delete old thumb nail-file
     	RFs fsSession;
	User::LeaveIfError(fsSession.Connect());

	CFileMan* fileMan = CFileMan::NewL(fsSession);
        CleanupStack::PushL(fileMan);

	fileMan->Delete(KThumbnailFilename,0);

	CleanupStack::PopAndDestroy(); // FileMan
        fsSession.Close();

         if(iContainer->iImageReady)
        {
    // Be sure that we have an image to be saved
        // gets path where to save the image
         TFileName newFilePathAndName(KCamTimerFilename);




              // query what the current time is
	TTime currentTime;
	currentTime.HomeTime();
        // gets path where to save the image
        // format the time into a descriptor, and handle any errors
	TBuf<32> timeAsText;
	_LIT (KTimeFormat, "#%H-%T-%S.jpg");
	_LIT (KTimeError, "Error formatting the time!");
	TRAPD (err,
		   currentTime.FormatL(timeAsText, KTimeFormat););
	if (err != KErrNone)
		{
		timeAsText = KTimeError;
		}
        timeAsText.Trim();
        newFilePathAndName.Append(timeAsText);




        // Create Format and Codec
        // quality factor from 0 to 100 (55 used here)
        iFormat->iSettings.iQualityFactor = KJpgSavingQualityFactor;
        iFormat->iSettings.iSampleScheme =
        TMdaJpgSettings::TColorSampling(TMdaJpgSettings::EColor420);

        TMdaPackage* codec = NULL;
        CleanupStack::PushL(codec);
        iSaveFile->CreateL( newFilePathAndName, iFormat, codec, NULL );

        // set flag, can't take new pictures when saving
        iSavingImage = ETrue;
        iContainer->iImageReady = ETrue;
        CleanupStack::PopAndDestroy(1);
        }
}

void CCamTimerFormView::Capture()
{
        TimerL();
        StartTimer();
}

TBool CCamTimerFormView::GetStatusClient()
{
        return iClient->IsConnected();
}
TBool CCamTimerFormView::GetStatusServer()
{
        return iServer->IsConnected();
}

/*
-------------------------------------------------------------------------------

    MiuoCreateComplete();

    Description: This function is called when the asynch. function
                 iFileSaver->CreateL() completes. The error value tells if the
                 creation was successful. If it was, we have created a file
                 into which we can now save the image.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::MiuoCreateComplete(TInt aError)
    {
      TakePictureL(ERCLow);
      if (iSaving)
      {
         TRAP( aError, iSaveFile->ConvertL(*(iContainer->GetBmpForSaving()),
   			TRect(0,0,0,0), 0));
      }else if (( aError == KErrNone) && iFileSaver)
        {
         iContainer->iImageReady = EFalse;
         TRAP( aError, iFileSaver->ConvertL(*(iContainer->GetBmpForSaving()),
   			TRect(0,0,0,0), 0));
        }
    else
        {
        iSaving = EFalse;
         NEikonEnvironment::MessageBox(_L("Create Error"));
        }


    }

/*
-------------------------------------------------------------------------------

    MiuoConvertComplete();

    Description: This function is called when the asynch. function
                 iFileSaver->ConvertL() completes. Now the image saving has
                 completed.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::MiuoConvertComplete(TInt aError)
    {
    if( iSaving )
    {
        NEikonEnvironment::MessageBox(_L("Saved"));
        iSavingImage = EFalse;
        iSaving = EFalse;
    }else if ( aError == KErrNone)
    {
	// set flag, can take new pictures
        iSavingImage = EFalse;
        iSaving = EFalse;
        if(iClient->GetFlag())
        {
              iContainer->DrawNow();
              iClient->RequestData();
        } else {
              TakePictureL(ERCLow);
              SendMessage();
        }
    }else
    {
        iSaving = EFalse;
        if(iClient->GetFlag())
        {
              iClient->RequestData();
        } else {
              TakePictureL(ERCLow);
              NEikonEnvironment::MessageBox(_L("Convert Error"));
          //    SendMessage();
        }

    }
 }
/*
-------------------------------------------------------------------------------

    MiuoOpenComplete();

    Description: From MMdaImageUtilObserver, implement this if you use this
                 observer to open a imagefile.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerFormView::MiuoOpenComplete(TInt aError)
    {

	if (aError == KErrNone)
		{
                // Get a bmp handle from our container
                CFbsBitmap* bmp = iContainer->GetBmp();
	        //CleanupStack::PushL(bmp);
		TFrameInfo frameInfo;
		//Get the frame info
		iConverter->FrameInfo(KJpegFrameIndex,frameInfo);
		//Create a bitmap based on the size of the jpeg
                TInt err = bmp->Create(frameInfo.iOverallSizeInPixels,KDeviceColourDepth);
		//Convert the Jpeg into a bitmap
                iContainer->iImageReady = ETrue;
                //iContainer->DrawNow();
	        TRAPD(convertErr,iConverter->ConvertL(*bmp,KJpegFrameIndex));
                } else
                {
             //    NEikonEnvironment::MessageBox(_L("Open Error"));
                 iClient->RequestData();
                }

}

void CCamTimerFormView::StartTimer()
	{
	//If the timer is not already running, start it
	if (!iPeriodicTimer->IsActive())
		{
		iPeriodicTimer->Start(1,500000,TCallBack(CCamTimerFormView::Period,this));
		}
	}

void CCamTimerFormView::DoPeriodTask()
        {
              TakePictureL(ERCLow);
              TimerL();
	}


// This function is called by the periodic timer
TInt CCamTimerFormView::Period(TAny * aPtr)
	{
        // TakePictureL(ERCLow);
        ((CCamTimerFormView*)aPtr)->DoPeriodTask();
        //returning a value of TRUE indicates the callback should be done again
	return TRUE;
	}

//
// CCamTimerDialog class
//

/*
-------------------------------------------------------------------------------

    CCamTimerDialog(TInt& aValue)

    Description: C++ Constructor.

    Return value: N/A

-------------------------------------------------------------------------------
*/

// C++ constructor, initialize data
CCamTimerDialog::CCamTimerDialog(TInt& aValue)
    : iEditorValue(&aValue)
    {
    }

/*
-------------------------------------------------------------------------------

    PreLayoutDynInitL()

    Description: Function for doing pre layout events.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerDialog::PreLayoutDynInitL()
	{
	// Make sure that editor's value is inside valid range
    CheckEditorValue();
	}

/*
-------------------------------------------------------------------------------

    OkToExitL(TInt aButtonId)

    Description: Function for doing on exit events

    Return value: N/A

-------------------------------------------------------------------------------
*/

TBool CCamTimerDialog::OkToExitL(TInt aButtonId)
    {
    switch (aButtonId)
		{
		// If cancel is hit
		case EAknSoftkeyCancel:
                // Return ETrue and kill the dialog window
                return ETrue;
                break;
		// If ok button is hit
        case EAknSoftkeyOk:
                // Get editor's value and set it to external variable
            *iEditorValue=((CEikNumberEditor*)Control(ECamTimerNumberEditor))->Number();
            return ETrue;
            break;
		// If any other key is hit
        default:
                // Return EFalse and do nothing else
            return EFalse;
            break;
        }
    }

/*
-------------------------------------------------------------------------------

    CheckEditorValue()

    Description: Checks that the editor value is within given minimum and maximum

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerDialog::CheckEditorValue()
    {
    TInt min=1;
    TInt max=20;
	// Get the editor
    CEikNumberEditor* editor=static_cast<CEikNumberEditor*>(Control(ECamTimerNumberEditor));
	// Check if value to be set to editor is too high.
	if(*iEditorValue<min)
        // Set value to the editor's maximum value.
        *iEditorValue=min;
	// Check if value to be set to editor is too low.
	if(*iEditorValue>max)
        // Set value to the editor's minimum value.
        *iEditorValue=max;
	// Set value to editor.
    editor->SetNumber(*iEditorValue);
    }


//
//  CCamTimerAppUi class
//

/*
-------------------------------------------------------------------------------

    CCamTimerAppUi(TInt& aValue)

    Description: C++ constructor

    Return value: N/A

-------------------------------------------------------------------------------
*/

CCamTimerAppUi::CCamTimerAppUi(TInt& aValue)
    : iWaitingTime(&aValue)
    {
    }

/*
-------------------------------------------------------------------------------

    ConstructL();

    Description: 2nd phase Constructor. Setting up attributes, construction
                 continues in CompleteConstructL() below.

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerAppUi::ConstructL()
    {
    BaseConstructL();

    // Averell view launching
    view=new(ELeave)CCamTimerFormView(iWaitingTime);
    CleanupStack::PushL(view);
    view->ConstructL();

	// add created view to this AppUi
    AddViewL(view);

	// view
    CleanupStack::Pop();

	// activate view
    ActivateLocalViewL( view->Id() );
    }

/*
-------------------------------------------------------------------------------

    ~CCamTimerAppUi

    Description: Destructor

    Return value: N/A

-------------------------------------------------------------------------------
*/
CCamTimerAppUi::~CCamTimerAppUi()
    {

    }

/*
-------------------------------------------------------------
     Dymamic Menu
-------------------------------------------------------------
*/
void CCamTimerAppUi::DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane)
    {

  //  if (aResourceId == R_BTPOINTTOPOINT_MENU)r_camtimer_options_menu
      if (aResourceId == R_CAMTIMER_OPTIONS_MENU)
        {
                if (!view->GetStatusClient() && !view->GetStatusServer())
                {
                aMenuPane->SetItemDimmed(EBTPointToPointStartReceiver, EFalse);
                aMenuPane->SetItemDimmed(EBTPointToPointStopReceiver, ETrue);
          //      aMenuPane->SetItemDimmed(EBTPointToPointOpen, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointSave, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointConnect, EFalse);
         //       aMenuPane->SetItemDimmed(EBTPointToPointSendMessage, ETrue);
                aMenuPane->SetItemDimmed(ECamTimerStartTiming, ETrue);
         //       aMenuPane->SetItemDimmed(ECamTimerSetTime, ETrue);
                aMenuPane->SetItemDimmed(ECamTimerLaunchPhotoAlbum, EFalse);
                aMenuPane->SetItemDimmed(EClose, EFalse);
                 }else if(view->GetStatusClient())
                {
                aMenuPane->SetItemDimmed(EBTPointToPointStartReceiver, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointStopReceiver, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointSave, ETrue);
          //      aMenuPane->SetItemDimmed(EBTPointToPointOpen, EFalse);
                aMenuPane->SetItemDimmed(EBTPointToPointConnect, ETrue);
         //       aMenuPane->SetItemDimmed(EBTPointToPointSendMessage, ETrue);
                aMenuPane->SetItemDimmed(ECamTimerStartTiming, ETrue);
        //        aMenuPane->SetItemDimmed(ECamTimerSetTime, ETrue);
                aMenuPane->SetItemDimmed(ECamTimerLaunchPhotoAlbum, ETrue);
                aMenuPane->SetItemDimmed(EClose, EFalse);
                }else if(view->GetStatusServer())
                {
                aMenuPane->SetItemDimmed(EBTPointToPointStartReceiver, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointStopReceiver, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointSave, EFalse);
          //      aMenuPane->SetItemDimmed(EBTPointToPointOpen, ETrue);
                aMenuPane->SetItemDimmed(EBTPointToPointConnect, ETrue);
           //     aMenuPane->SetItemDimmed(EBTPointToPointSendMessage, ETrue);
                aMenuPane->SetItemDimmed(ECamTimerStartTiming, EFalse);
          //      aMenuPane->SetItemDimmed(ECamTimerSetTime, EFalse);
                aMenuPane->SetItemDimmed(ECamTimerLaunchPhotoAlbum, EFalse);
                aMenuPane->SetItemDimmed(EClose, EFalse);
                }
          }
      }
/*
-------------------------------------------------------------------------------

    HandleKeyEventL

    Description: Handles a key event (we are monitoring for the navibutton)

    Return value: N/A

-------------------------------------------------------------------------------
*/
TKeyResponse CCamTimerAppUi::HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
    {
    TInt code = aKeyEvent.iCode;
    switch(code)
        {
		// navigator button is pressed
    	case EKeyOK:
			TInt temp;
			temp=*iWaitingTime;
			// Convert time to microseconds
			*iWaitingTime*=1000000;

            // Start the timing with preview pictures, take a picture and save it.
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->TimerL();
			// Return the original waiting time in seconds
			*iWaitingTime=temp;
            return (EKeyWasConsumed);
            break;
        case '2':static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->OpenBuffer();
            break;
        case '1':CBaActiveScheduler::Exit();
            break;
        default:
            break;
        }

	// default return value
    return(EKeyWasNotConsumed);
    }


/*
-------------------------------------------------------------------------------

    HandleCommandL

    Description: Handles a given command

    Return value: N/A

-------------------------------------------------------------------------------
*/
void CCamTimerAppUi::HandleCommandL(TInt aCommand)
    {
	// A switch statement that will be controlled by the command id get from
	// the OfferKayEvent
    switch (aCommand)
		{
		// If the exit command is selected from the softkeys
        case EAknSoftkeyExit:

		// If the exit command is given by the framework
		case EEikCmdExit:

		// If the exit command is selected from the menu
        case EClose:
		// Call the CBaActiveScheduler's Exit function that stops
		// the application's thread and destroys it.
               	CBaActiveScheduler::Exit();
		break;

                // "Start timing" was selected from the Options menu
        case ECamTimerStartTiming:
			TInt temp1;
			temp1=*iWaitingTime;
			// Convert time to microseconds
			*iWaitingTime*=1000000;
			// Start timing the picturetaking
        static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->Capture();
			// Return the waiting time value in seconds
			*iWaitingTime=temp1;
            break;

        // "Set time" was selected from the Options menu
        case ECamTimerSetTime:
			// Start the dialog to ask the number of seconds desired for
			// the timing.
			// Call CmdDlgL function with the selection's resource id as argument.
			// This will execute the dialog
			CmdDlgL(R_CAMTIMER_DIALOG);
            break;

        case ECamTimerLaunchPhotoAlbum:
        // Start the photo album application to rename and send your picture
            CCoeAppUi::ActivateViewL(TVwsViewId(KPhotoAlbumUid, TUid::Uid(1)));
            break;

        case EBTPointToPointStartReceiver:
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->StartRecieve();
            break;

        case EBTPointToPointSave:
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->SetSave();
            break;

        case EBTPointToPointOpen:
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->OpenBuffer();
            break;

         case EBTPointToPointConnect:
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->Connect();
            break;

        case EBTPointToPointSendMessage:
            static_cast<CCamTimerFormView*>(View(KCamTimerViewId))->SendMessage();
            break;

        // If the menu command is none of the above do nothing
        default:
            break;
		}

    }



// This function creates the dialog for settings.
void CCamTimerAppUi::CmdDlgL(TInt aResourceId)
	{
	// If the resource id of the dialog to be executed is R_CAMTIMER_DIALOG 
	// do the following.
	if(aResourceId == R_CAMTIMER_DIALOG)
		// There can be multiple id comparisons here like this causing 
		// launching of different dialogs.
		{		
		// Allocate memory for a new dialog of class CCamTimerDialog
        CCamTimerDialog* dialog=new(ELeave)CCamTimerDialog(*iWaitingTime);
		// Set the dialog to execution by calling its ExecuteLD function. 
		// The dialog will be deleted on return
		dialog->ExecuteLD(R_CAMTIMER_DIALOG);                  
        }
	}

//
//  CCamTimerDocument class
//

/*
-----------------------------------------------------------------------------

    CCamTimerDocument

    Creates new CamTimer document.

    Return Values:  N/A

-----------------------------------------------------------------------------
*/
CCamTimerDocument::CCamTimerDocument(CAknApplication& aApp)
    : CAknDocument(aApp)
    {
	}



/*
-----------------------------------------------------------------------------

    CreateAppUiL

    Creates new CCamTimerAppUi and returns a pointer to it.

    Return Values:  pointer to CCamTimerAppUi

-----------------------------------------------------------------------------
*/
CEikAppUi* CCamTimerDocument::CreateAppUiL()
    {	 
    // Initialise the waiting time
    iWaitingTime=KInitialValue;

    CCamTimerAppUi* appui = new (ELeave) CCamTimerAppUi(iWaitingTime);
	// Return the application ui that has been created
    return appui;

    }	



//
//  CCamTimerApplication class
//

/*
-----------------------------------------------------------------------------

    CreateDocumentL()

    Description: Creates new CamTimer document.

    Return Values:  pointer to new CCamTimerDocument object

-----------------------------------------------------------------------------
*/
CApaDocument* CCamTimerApplication::CreateDocumentL()
    {
    return new (ELeave) CCamTimerDocument(*this);
    }


/*
-----------------------------------------------------------------------------

    AppDllUid()

    Return the UID of CamTimer application.

    Return Values:  UID

-----------------------------------------------------------------------------
*/
TUid CCamTimerApplication::AppDllUid() const
    {
    return KUidCamTimerApp;
    }




//  OTHER EXPORTED FUNCTIONS
//=============================================================================


/*
-----------------------------------------------------------------------------

    NewApplication

    Creates new CCamTimerApplication application and returns a pointer to it.

    Return Values:  pointer to CApaApplication

-----------------------------------------------------------------------------
*/
EXPORT_C CApaApplication* NewApplication()
    {
    return new CCamTimerApplication;
    }



/*
-----------------------------------------------------------------------------

    E32Dll

    Called when the DLL is loaded.

    Return Values:  KErrNone

-----------------------------------------------------------------------------
*/
GLDEF_C TInt E32Dll(TDllReason /*aReason*/)
    {
    return KErrNone;
    }




//  End of File  

