/* Copyright (c) 2002, Nokia Mobile Phones. All rights reserved */

#ifndef __MESSAGECLIENT_H__
#define __MESSAGECLIENT_H__
#include <e32base.h>
#include <es_sock.h>
#include <MdaImageConverter.h>
#include <bt_sock.h>
#include <BTextNotifiers.h>
#include <BtSdp.h>
#include <utf.h>
#include "camtimer.h"
#include "MessageServiceSearcher.h"
#include "BTPointToPoint.pan"
#include "Log.h"
#include "EikonEnvironment.h"

class CMessageServiceSearcher;
class MLog;

/*!
  @class CMessageClient

  @discussion Connects and sends messages to a remote machine using bluetooth
  */
class CMessageClient : public CActive//, public MMdaImageUtilObserver
    {
public:

        enum TCamTimerImageQuality
        {
        ERCHigh,
        ERCLow
        };
/*!
  @function NewL

  @discussion Construct a CMessageClient
  @param aLog the log to send output to
  @result a pointer to the created instance of CMessageClient
  */
    static CMessageClient* NewL();

/*!
  @function NewLC
  
  @discussion Construct a CMessageClient
  @param aLog the log to send output to
  @result a pointer to the created instance of CMessageClient
  */
    static CMessageClient* NewLC();
/*!
  @function ~CMessageClient
  
  @discussion Destroy the object and release all memory objects. Close any open sockets
  */
    ~CMessageClient();

/*!
  @function IsConnected
  
  @result ETrue if the client is connected.
  */
    TBool IsConnected();

/*!
  @function IsBusy
  
  @result ETrue if the client is performing some operation.
  */
    TBool IsBusy();

/*!
  @function ConnectL

  @discussion Connect to an available service on a remote machine
  */
    void ConnectL();

/*!
  @function SendMessageL

  @discussion Sends a message to a service on a remote machine.
  */
    void SendMessageL(const TDesC8& aMessage);
   // void SendMessageL();

    void   RequestData();
    TDes8& GetBuffer();
    TBool  GetFlag();
    void OpenBuff();
    virtual void MiuoOpenComplete(TInt aError);
    virtual void MiuoConvertComplete(TInt aError);
    TBool  iFlag;
    TInt StringToInt(const TDesC& aStr);
    TInt ConvertTDes8ToTDes16(const TDesC8& aFrom, TDes16& aTo);
    TInt ConvertTDes16ToTDes8(const TDesC16& aFrom, TDes8& aTo);
protected:    // from CActive
/*!
  @function DoCancel
  
  @discussion Cancel any outstanding requests
  */
    void DoCancel();

/*!
  @function RunL
  
  @discussion Respond to an event
  */
    void RunL();

private:
/*!
  @function ConnectToServerL

  @discussion Connects to the service
  */    
    void ConnectToServerL();

/*!
  @function CMessageClient

  @discussion Constructs this object
  */
    CMessageClient();

/*!
  @function ConstructL

  @discussion Performs second phase construction of this object
  @param aMessage the message to be sent to the remote machine
  */
    void ConstructL(const TDesC8& aMessage);

private:

    /*!
      @enum TState
  
      @discussion The state of the active object, determines behaviour within
      the RunL method.
      @value EWaitingToGetDevice waiting for the user to select a device
      @value EGettingDevice searching for a device
      @value EGettingService searching for a service
      @value EGettingConnection connecting to a service on a remote machine
      @value EWaitingToSend sending a message to the remote machine
      @value EDisconnecting disconnecting from the remote machine
      */
    enum TState 
        {
        EWaitingToGetDevice,
        EGettingDevice,
        EGettingService,
        EGettingConnection,
        EWaitingToSend,
        EDisconnecting
        };
    friend class CCamTimerFormView;
    /*! @var iState the current state of the client */
    TState iState;

    /*! @var iServiceSearcher searches for service this client can connect to */
    CMessageServiceSearcher* iServiceSearcher;

    /*! @var iLog the log to send output to */
    //  MLog& iLog;
    CMdaImageDescToBitmapUtility* iConverter;
    /*! @var iSocketServer a connection to the socket server */
    RSocketServ iSocketServer;

    /*! @var iSendingSocket a socket to connect with */
    RSocket iSendingSocket;

    /*! @var iLen length of data read */
    TSockXfrLength iLen;

    /*! @var iBuffer the buffer to read data to */
    TMdaJfifClipFormat* iFormat;
    TBuf8<30000> iBuffer;
    TBuf16<10> iBuf;
    //   TBuf8<5000> iBuffer;

    /*! @var iServiceClass the service class UUID to search for */
    TUUID iServiceClass;

  //  const TInt len;
    TInt bufSize;
public:
    /*! @var iMessage a copy of the message to send */
    CCamTimerFormView* iForm;
    HBufC8* iMessage;
    };

#endif // __MESSAGECLIENT_H__

