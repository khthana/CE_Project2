/*
        CamTimer.H - header file for CamTimer application, Series 60
        C++ implementation
*/


//#if !defined __CamTimer_H__
#ifndef __CamTimer_H__
#define __CamTimer_H__

//  Include Files
#include <eikmenup.h>
#include <e32base.h>			// for the CleanupStack
#include <aknapp.h>             // for CAknApplication
#include <akndoc.h>             // for CAknDocument
#include <aknviewappui.h>		// for CAknViewAppUi
#include <aknview.h>            // for CAknView
#include <eikenv.h>				// for CEikonEnv - "Eikon Environment"
#include <akndialog.h>			// for the dialog
#include <eikmfne.h>			// for CEikNumberEditor
#include <CameraServ.h>			// for RCameraServ
#include <MdaImageConverter.h>  // for MMdaImageUtilObserver
#include <f32file.h>			// for handling files
#include <aknsoundsystem.h>		// for playing keysounds - snap
#include <CamTimer.rsg>                  	// own resources
#include "CamTimer.hrh"			// own enumerations
#include "MessageServer.h"
//#include "MessageClient.h"
#include "bitmapmethods.h"
#include "EikonEnvironment.h"

/////////
//#include <e32base.h>
#include <es_sock.h>
//#include <MdaImageConverter.h>
#include <bt_sock.h>
#include <BTextNotifiers.h>
#include <BtSdp.h>
#include <utf.h>
//#include "camtimer.h"
#include "MessageServiceSearcher.h"
#include "BTPointToPoint.pan"
#include "Log.h"
#include "EikonEnvironment.h"

class CMessageServiceSearcher;
class MLog;
// FORWARD DECLARATIONS
class CFbsBitmap;
class CCamTimerFormView;
class CMessageClient;
class CMessageServer;

// CLASS DEFINITIONS

//
//  CCamTimerContainer
//
class CCamTimerContainer : public CCoeControl
    {
public:
    ~CCamTimerContainer();
    void ConstructL(CCamTimerFormView& aFormView);
    CFbsBitmap* GetBmp();
    CFbsBitmap* GetBmpForSaving();

private:
	// Construct the container control
    void ConstructContainerControlL();
	// Method for drawing the control area
    void Draw(const TRect& aRect) const;

public:
    TBool iImageReady;
    TBool Flag;

private:
    CFbsBitmap* iBmp;
    CFbsBitmap* iBackgroundImage;
    // handle to the FormView object owning this container
    CCamTimerFormView* iFormView;
    };

//
// CCamTimerFormView
//
// image util is used to save or open images in async. calls
class CCamTimerFormView : public CAknView, public MMdaImageUtilObserver
    {
    enum TCamTimerImageQuality
        {
        ERCHigh,
        ERCLow
        };

public:
	// C++ constructor
	CCamTimerFormView(TInt* aValue);
    void ConstructL();
    ~CCamTimerFormView();

public:
    TUid Id() const;
    void TurnCameraOnL();
    void TurnCameraOffL();
    void TimerL();
    void HandleForegroundEventL(TBool);
    void OpenBuff();
    void OpenBuffer();
    void SavePicture();
    void SetSave();
	// default image quality = High
    void TakePictureL(TCamTimerImageQuality aQuality = ERCHigh);
    void SaveImageL();
    TBool CCamTimerFormView::GetStatusClient();
    TBool CCamTimerFormView::GetStatusServer();
    void CCamTimerFormView::StartRecieve();
    void CCamTimerFormView::StopRecieve();
    void CCamTimerFormView::Connect();
    void CCamTimerFormView::SendMessage();
    void Capture();

public:	 // from MMdaImageUtilObserver
    virtual void MiuoOpenComplete(TInt aError);
    virtual void MiuoConvertComplete(TInt aError);
    virtual void MiuoCreateComplete(TInt aError);

private:
    friend class MessageClient;
    void DoActivateL(const TVwsViewId& /*aPrevViewId*/, TUid /*aCustomMessageId*/,
			const TDesC8& /*aCustomMessage*/);
    void DoDeactivate();

    /*!
  @function DoPeriodTask

  @discussion Called by period task static function
  */
    void DoPeriodTask();

/*!
  @function Period

  @discussion Call back function for a periodic timer
  @param aPtr a parameter passed to the timer when the timer is started
  */
	static TInt Period(TAny* aPtr);

/*!
  @function StartTimer

  @discussion Starts the timer
  */
	void StartTimer();

private:
	// client to the camera server
    RCameraServ* iCamserv;

    CCamTimerContainer* iContainer;
    TInt iCurrentImage;
	// flag that tells when saving is taking place
    TBool iSavingImage;
	// Saves an image to a file
    TBool iSaving;
    TBool iSaved;
    CMdaImageBitmapToFileUtility*  iSaveFile;
    CMdaImageBitmapToDescUtility*  iFileSaver;

    /*! @var iServer the message receiving engine */
    CMessageServer* iServer;
    /*! @var iClient the message sending engine */
    CMessageClient* iClient;

        // Converts the gif file to a bitmap */
    CMdaImageDescToBitmapUtility* iConverter;
 //       CMdaImageFileToBitmapUtility* iConverter;
	// for saving
    TMdaJfifClipFormat* iFormat;
    /** The bitmap being displayed */
    CFbsBitmap*  iBitmap;
    // buffer  for picture
    TBuf8<5000> iBuff;
	// pointer to waiting time, which is located in the document class
    TInt*  iWaitingTime;
	// For player
    CAknKeySoundSystem* iSoundPlayer;
    CPeriodic* iPeriodicTimer;

    };


/////////////////////////////////////////////////////////////////////
//
// CCamTimerDialog class
// An one-control dialog.
// 
/////////////////////////////////////////////////////////////////////
	// CCamTimerDialog is derived from CAknDialog
class CCamTimerDialog : public CAknDialog
	{
	public:
		// Constructor that enables getting number editor's value
        CCamTimerDialog(TInt& aValue);
	private:
		// Function for doing events that have to be done before setting layout
        void PreLayoutDynInitL();
		// Function for handling exiting
		TBool OkToExitL(TInt aButtonId);
		// Function for checking editors value
        void CheckEditorValue();
    private:
		// Pointer to externally owned variable for editor value
        TInt* iEditorValue;
	};

//
//  CCamTimerAppUi
// /----------------------------------------------------------
class CCamTimerAppUi : public CAknViewAppUi
    {
public:
	// C++ constructor
    CCamTimerAppUi(TInt& aValue);
    void ConstructL();
    ~CCamTimerAppUi();

public: 
    TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
    void DynInitMenuPaneL(TInt aResourceId, CEikMenuPane* aMenuPane);
protected:        // from CEikAppui 
    void HandleCommandL(TInt aCommand); 

private:      
	// The function that is the actual backbone of the application
	void CmdDlgL(TInt aResourceId);
	// Pointer to value
    TInt* iWaitingTime;
    CCamTimerFormView* view;
 
private:
    void CompleteConstructL();
    };	


//
//  CCamTimerDocument
//
class CCamTimerDocument : public CAknDocument 
    {
public:
    CCamTimerDocument(CAknApplication& aApp);
protected:	
    CEikAppUi* CreateAppUiL();
private:
	// Value used for the timer.
    TInt iWaitingTime;

    };

//
//  CCamTimerApplication
//
class CCamTimerApplication : public CAknApplication
    {
private:        //From CEikApplication
    CApaDocument* CreateDocumentL();
    TUid AppDllUid() const;
    };

 /////////////////

 class CMessageClient : public CActive//, public MMdaImageUtilObserver
    {
    friend class CCamTimerFormView;
public:

        enum TCamTimerImageQuality
        {
        ERCHigh,
        ERCLow
        };
/*!
  @function NewL

  @discussion Construct a CMessageClient
  @param aLog the log to send output to
  @result a pointer to the created instance of CMessageClient
  */
    static CMessageClient* NewL();

/*!
  @function NewLC
  
  @discussion Construct a CMessageClient
  @param aLog the log to send output to
  @result a pointer to the created instance of CMessageClient
  */
    static CMessageClient* NewLC();
/*!
  @function ~CMessageClient
  
  @discussion Destroy the object and release all memory objects. Close any open sockets
  */
    ~CMessageClient();

/*!
  @function IsConnected
  
  @result ETrue if the client is connected.
  */
    TBool IsConnected();

/*!
  @function IsBusy
  
  @result ETrue if the client is performing some operation.
  */
    TBool IsBusy();

/*!
  @function ConnectL

  @discussion Connect to an available service on a remote machine
  */
    void ConnectL();

/*!
  @function SendMessageL

  @discussion Sends a message to a service on a remote machine.
  */
    void SendMessageL(const TDesC8& aMessage);
   // void SendMessageL();
    void   SetView(CCamTimerFormView& aFormView);
    void   RequestData();
    TDes8& GetBuffer();
    TBool  GetFlag();
    TBool  iFlag;
    TInt StringToInt(const TDesC& aStr);
    TInt ConvertTDes8ToTDes16(const TDesC8& aFrom, TDes16& aTo);
    TInt ConvertTDes16ToTDes8(const TDesC16& aFrom, TDes8& aTo);
protected:    // from CActive
/*!
  @function DoCancel
  
  @discussion Cancel any outstanding requests
  */
    void DoCancel();

/*!
  @function RunL
  
  @discussion Respond to an event
  */
    void RunL();

private:
/*!
  @function ConnectToServerL

  @discussion Connects to the service
  */    
    void ConnectToServerL();

/*!
  @function CMessageClient

  @discussion Constructs this object
  */
    CMessageClient();

/*!
  @function ConstructL

  @discussion Performs second phase construction of this object
  @param aMessage the message to be sent to the remote machine
  */
    void ConstructL(const TDesC8& aMessage);

private:

    /*!
      @enum TState
  
      @discussion The state of the active object, determines behaviour within
      the RunL method.
      @value EWaitingToGetDevice waiting for the user to select a device
      @value EGettingDevice searching for a device
      @value EGettingService searching for a service
      @value EGettingConnection connecting to a service on a remote machine
      @value EWaitingToSend sending a message to the remote machine
      @value EDisconnecting disconnecting from the remote machine
      */
    enum TState
        {
        EWaitingToGetDevice,
        EGettingDevice,
        EGettingService,
        EGettingConnection,
        EWaitingToSend,
        EDisconnecting
        };

    /*! @var iState the current state of the client */
    TState iState;

    /*! @var iServiceSearcher searches for service this client can connect to */
    CMessageServiceSearcher* iServiceSearcher;

    /*! @var iLog the log to send output to */
    //  MLog& iLog;
    CMdaImageDescToBitmapUtility* iConverter;
    /*! @var iSocketServer a connection to the socket server */
    RSocketServ iSocketServer;

    /*! @var iSendingSocket a socket to connect with */
    RSocket iSendingSocket;

    /*! @var iLen length of data read */
    TSockXfrLength iLen;

    /*! @var iBuffer the buffer to read data to */
    TMdaJfifClipFormat* iFormat;
    TBuf8<30000> iBuffer;
    TBuf16<10> iBuf;
    //   TBuf8<5000> iBuffer;

    /*! @var iServiceClass the service class UUID to search for */
    TUUID iServiceClass;
    TInt len;
    TInt bufSize;
public:
    /*! @var iMessage a copy of the message to send */
    CCamTimerFormView* iForm;
    HBufC8* iMessage;
    };



#endif  //__CamTimer_H__
//End of File
