package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.net.*;

public class ServerConnect {
  LogonPage logonpage;
  private boolean status = true;
  protected Packet packetforsend;
  private String server2connect;
  private ServerListenner thread;
  protected ClientToServerCMD clientCMD;
  private Socket sock;
  private short lastseq;
  private InetAddress serverAddr;
  private int port;
  private String servername;
  private DataOutputStream remoteOut;
  private String serverBosIP;
  String updatetype;
//----------------------------------------------------------------
  public ServerListenner getServerListenner() {
    return this.thread;
  }

//----------------------------------------------------------------------------
  public void setServerBosIP(String serverBos) {
    this.serverBosIP = serverBos;
  }

//----------------------------------------------------------------------------
  public String getServerBosIP() {
    return this.serverBosIP;
  }

//----------------------------------------------------------------------------
//synchronized public void setReceivePacket(Packet_abstract packet_recieve){
  // this.packet_receive = packet_receive ;
//	}
//----------------------------------------------------------------------------
  public int getPort() {
    return this.port;
  }

//----------------------------------------------------------------------------
  public String getServername() {
    return this.servername;
  }

//----------------------------------------------------------------------------
  public boolean getStatus() {
    return this.status;
  }

//----------------------------------------------------------------------------
  public void setServer2connect(String name) {
    this.server2connect = name;
  }

//----------------------------------------------------------------------------
  public String getServer2connect() {
    return this.server2connect;
  }

//----------------------------------------------------------------------------
  public Socket getSocket() {
    return sock;
  }

//---------------------------------------------------------------
  public void Login(String server, int port) {
    try {
      serverAddr = InetAddress.getByName(server);
      System.out.println(serverAddr.getHostName());
      InetAddress me = InetAddress.getLocalHost();
      String dot = me.getHostAddress();
      OwnerDataInfo.setmyIPaddress(dot);
      sock = new Socket(serverAddr, port);
      System.out.println("login successful");
      //sock.setSoTimeout(60000);
      this.thread = new ServerListenner(this);
      this.thread.start();
      this.remoteOut = new DataOutputStream(this.sock.getOutputStream());
      if (this.server2connect.equals("icqserver")) {
	while (this.status) {
	  if (this.thread.getStatus() == false) {
	    //this.thread.stop() ;
	    this.status = false;
	  }
	}
      }
      System.out.println("end login");
    }
    catch (IOException e) {
      System.out.println(e.getMessage());
      System.out.println("error");
    }
  }

//----------------------------------------------------------------------------
  public ServerConnect() {

  }

//----------------------------------------------------------------------------
  public ServerConnect(int port, String servername, String server2connect,
		       LogonPage p) throws IOException {
    this.clientCMD = new ClientToServerCMD();
    this.port = port;
    this.servername = servername;
    this.setServer2connect(server2connect);
    this.logonpage = p;
  }

//----------------------------------------------------------------------------
  public ServerConnect(int port, String servername, String uin, String password,
		       String server2connect, LogonPage p) throws IOException {
    OwnerDataInfo own = new OwnerDataInfo();
    own.setUin(uin);
    own.setPassword(password);
    this.clientCMD = new ClientToServerCMD();
    this.port = port;
    this.servername = servername;
    this.setServer2connect(server2connect);
    this.logonpage = p;
  }

//----------------------------------------------------------------------------
  public void sendPacket(byte[] packet) {
    try {
      this.remoteOut.write(packet);
      this.remoteOut.flush();
    }
    catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }
//----------------------------------------------------------------------------
}