package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.net.*;
import java.util.*;

public class QMessageThread extends Thread{
  QMessagePage qMessagePage;
  public QMessageThread(Socket qcon, Vector u, String myname, boolean keygen) {
    qMessagePage = new QMessagePage(qcon, u, myname, keygen);
  }

  public void run() {
    qMessagePage.startresponce();
  }


}