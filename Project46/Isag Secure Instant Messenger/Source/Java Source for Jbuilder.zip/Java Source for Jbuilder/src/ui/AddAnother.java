package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import javax.net.ssl.*;
import java.security.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

//server trust certificate password at line 268

public class AddAnother
    extends JFrame {
  private ServerConnect sconnect;
  LogonPage logonPage;
  AddAnotherFail addAnotherFail;
  AddAnotherConfirm addAnotherConfirm;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JPasswordField jPasswordField2 = new JPasswordField();
  JCheckBox jCheckBox1 = new JCheckBox();
  JCheckBox jCheckBox2 = new JCheckBox();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  boolean useICQ=true;
  boolean useIsagQ=true;
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JButton jButton3 = new JButton();
  JFileChooser jFileChooser1;
  File file;
  SSLContext ctx;
  JLabel jLabel10 = new JLabel();
  JTextField jTextField5 = new JTextField();

  //Construct the frame
  public AddAnother() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(AddAnother.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(595, 285));
    this.setTitle("Add another registered user");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("UIN :");
    jLabel1.setBounds(new Rectangle(45, 65, 65, 20));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Password :");
    jLabel2.setBounds(new Rectangle(45, 92, 65, 20));
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(115, 92, 120, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Please enter UIN and password.");
    jLabel3.setBounds(new Rectangle(5, 5, 185, 20));
    jButton1.setBounds(new Rectangle(207, 213, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(291, 213, 75, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    jTextField1.setBounds(new Rectangle(115, 65, 120, 20));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("IsagQ :");
    jLabel4.setBounds(new Rectangle(287, 96, 48, 15));
    jLabel5.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel5.setText("Password :");
    jLabel5.setBounds(new Rectangle(286, 123, 73, 15));
    jTextField2.setEditable(false);
    jTextField2.setText("");
    jTextField2.setBounds(new Rectangle(356, 92, 126, 21));
    jPasswordField2.setText("");
    jPasswordField2.setBounds(new Rectangle(356, 119, 126, 21));
    jCheckBox1.setFont(new java.awt.Font("Dialog", 1, 12));
    jCheckBox1.setText("Use ICQ");
    jCheckBox1.setBounds(new Rectangle(97, 29, 83, 23));
    jCheckBox1.setSelected(true);
    jCheckBox2.setFont(new java.awt.Font("Dialog", 1, 12));
    jCheckBox2.setText("Use IsagQ");
    jCheckBox2.setBounds(new Rectangle(345, 29, 83, 23));
    jCheckBox2.setSelected(true);
    jLabel6.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel6.setText("Server IP :");
    jLabel6.setBounds(new Rectangle(286, 150, 68, 15));
    jLabel7.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel7.setText("Port :");
    jLabel7.setBounds(new Rectangle(285, 174, 34, 15));
    jTextField3.setText("");
    jTextField3.setBounds(new Rectangle(356, 146, 127, 21));
    jTextField4.setText("");
    jTextField4.setBounds(new Rectangle(356, 173, 128, 21));
    jLabel8.setBorder(BorderFactory.createEtchedBorder());
    jLabel8.setText("");
    jLabel8.setBounds(new Rectangle(32, 26, 215, 151));
    jLabel9.setBorder(BorderFactory.createEtchedBorder());
    jLabel9.setBounds(new Rectangle(277, 25, 305, 180));
    jButton3.setBounds(new Rectangle(501, 92, 73, 22));
    jButton3.setText("Browse");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jLabel10.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel10.setText("Name :");
    jLabel10.setBounds(new Rectangle(286, 69, 40, 15));
    jTextField5.setText("");
    jTextField5.setBounds(new Rectangle(356, 65, 125, 21));
    contentPane.add(jLabel3, null);
    contentPane.add(jCheckBox1, null);
    contentPane.add(jCheckBox2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jPasswordField2, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel9, null);
    jCheckBox1.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e) {
        jCheckBox1_actionPerformed(e);
      }
    });
    jCheckBox2.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e) {
        jCheckBox2_actionPerformed(e);
      }
    });
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }
//-----------------------------------------------------------------------------
  void jCheckBox1_actionPerformed(ActionEvent e){
    if(jCheckBox1.isSelected()==true){
      useICQ=true;
      jTextField1.setEnabled(true);
      jPasswordField1.setEnabled(true);
    }else{
      useICQ=false;
      jTextField1.setEnabled(false);
      jPasswordField1.setEnabled(false);
    }
  }

  //-----------------------------------------------------------------------------
  void jCheckBox2_actionPerformed(ActionEvent e){
    if(jCheckBox2.isSelected()==true){
      useIsagQ=true;
      jTextField2.setEnabled(true);
      jPasswordField2.setEnabled(true);
      jTextField3.setEnabled(true);
      jTextField4.setEnabled(true);
   }else{
     useIsagQ=false;
     jTextField2.setEnabled(false);
     jPasswordField2.setEnabled(false);
     jTextField3.setEnabled(false);
     jTextField4.setEnabled(false);
   }
  }

//------------------------------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }

//---------------------------------------------------------
  public void reqOwnInfo() {
    int i = 0;
    short lastseq;
    byte[] data;
    try {
      this.sconnect = this.logonPage.getServerConnect();
      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setSearchByUin(OwnerDataInfo.getUin());
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.searchbyuin, lastseq, data));
      try {
	Thread.sleep(1000);
      }
      catch (Exception t) {}
    }
    catch (IOException e) {}
  }

//------------------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    String password="";
    String uin="";
    String serverIP=jTextField3.getText();
    int port=Integer.parseInt(jTextField4.getText());
    char[] pass;
    char[] pwd1;
    String nickname="";
    this.dispose();
    this.logonPage = new LogonPage();
    this.logonPage.useICQ=useICQ;
    this.logonPage.useIsagQ=useIsagQ;
    try{
      if (useICQ) {
        uin = jTextField1.getText();
        pass = jPasswordField1.getPassword();
        password = new String(pass);
      }
      if (useIsagQ) {
        pwd1 = jPasswordField2.getPassword();
        ctx = SSLContext.getInstance("SSLv3");
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new FileInputStream(file), pwd1);
        kmf.init(ks, "654321".toCharArray());

        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
        KeyStore ts = KeyStore.getInstance(KeyStore.getDefaultType());
        char[] pswd = "654321".toCharArray(); //server trust certificate password
        ts.load(null,null);
        java.security.cert.Certificate cert=Certificate.importCertificate(new File("./cert/ca.pem"));
        ts.setCertificateEntry("mqtrust",cert);
        tmf.init(ts);

        ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

        nickname=jTextField5.getText();
        FileInputStream fi=new FileInputStream("./activeuser/isagquser");
        Properties isagquser = new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,file.getPath());
        this.outPropertiesTofile(isagquser, "./activeuser/isagquser");

        fi=new FileInputStream("./activeuser/isagserver");
        isagquser=new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,serverIP);
        this.outPropertiesTofile(isagquser,"./activeuser/isagserver");

        fi=new FileInputStream("./activeuser/isagport");
        isagquser=new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,String.valueOf(port));
        this.outPropertiesTofile(isagquser,"./activeuser/isagport");


      }
      if(useIsagQ&&useICQ){
        this.logonPage.login(uin, password,serverIP,port,ctx,nickname);
      }else if(useICQ){
        this.logonPage.login(uin,password);
      }else if(useIsagQ){
        this.logonPage.login(serverIP,port,ctx,nickname);
      }

      this.reqOwnInfo();
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null,ex.toString(),"Error warning",JOptionPane.ERROR_MESSAGE);
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    if(jTextField2.getText().length()==0){
      jFileChooser1 = new JFileChooser();
    }else{
      jFileChooser1 = new JFileChooser(file.getParent());
    }
    jFileChooser1.setFileSelectionMode(JFileChooser.FILES_ONLY);
    int result=jFileChooser1.showOpenDialog(this);
    if(result==JFileChooser.CANCEL_OPTION){
    }else{
    file=jFileChooser1.getSelectedFile();
    jTextField2.setText(file.getPath());
    }

  }

  public void outPropertiesTofile(Properties a, String filename) {
    try {
      FileOutputStream fo;
      fo = new FileOutputStream(filename);
      a.store(fo, filename);
      fo.close();
    }
    catch (IOException rt) {}
  }

//------------------------------------------------------------------------------
}