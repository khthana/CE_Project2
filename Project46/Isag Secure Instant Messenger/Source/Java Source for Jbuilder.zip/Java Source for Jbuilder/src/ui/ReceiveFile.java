package ui;

import java.net.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ReceiveFile
    extends Thread {
  private int porttoreceive;
  private DesEncrypter des;
  private UserData user;
  private String filename;
  private int filesize;
  public ReceiveFile(int port, String filename, UserData user, int filesize) {
    this.porttoreceive = port;
    des = new DesEncrypter();
    this.user = user;
    this.filename = filename;
    this.filesize = filesize;
  }

  //--------------------------------------
  public void run() {
    while (true) {
      Socket client = null;
      ServerSocket serversock;
      try {
	int c;
	serversock = new ServerSocket(porttoreceive);
	client = serversock.accept();
	DataInputStream in = new DataInputStream(client.getInputStream());
	FileOutputStream out = new FileOutputStream("./Myreceivefile/" +
	    filename);
	des.setSecretKey(this.user.getSecretKey(), "File");
	//FileTransfer f = new FileTransfer() ;
	//f.FileProcess(this.filename,this.filesize);
	//f.show();
	des.decrypt(in, out);
	client.close();
	this.stop();
      }
      catch (Exception e) {}
    }
    //-------------------------------------------------------------
  }
}