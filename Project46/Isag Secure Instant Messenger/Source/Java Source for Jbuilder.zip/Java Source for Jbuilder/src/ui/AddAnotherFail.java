package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AddAnotherFail
    extends JFrame {
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();

  //Construct the frame
  public AddAnotherFail(int i) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit(i);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit(int i) throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(AddAnotherFail.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    this.setResizable(false);
    this.setSize(new Dimension(235, 95));
    this.setTitle("Add Another User Fail");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    if (i == 1) {
      jLabel1.setText("Please enter your UIN as Number.");
    }
    else if (i == 2) {
      jLabel1.setText("Your password is wrong.");
    }
    else {
      jLabel1.setText("Please enter your UIN and password.");
    }
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    contentPane.add(jLabel1, new XYConstraints(5, 5, -1, 20));
    contentPane.add(jButton1, new XYConstraints(75, 35, 70, 25));
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }

  public AddAnotherFail() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    contentPane.setLayout(null);
    this.setResizable(false);
    this.getContentPane().setLayout(null);
  }
}