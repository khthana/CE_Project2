package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AddAnotherConfirm
    extends JFrame {
  ServerConnect sconn;
  LogonPage logonPage;
  MainPage mainPage;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();

  //Construct the frame
  public AddAnotherConfirm() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(AddAnotherConfirm.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    String uin = "17278025";
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("Do you want to add UIN " + uin + " ?");
    jLabel1.setBounds(new Rectangle(10, 10, 198, 20));
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(285, 105));
    this.setTitle("Add UIN " + uin + " to this computer");
    jButton1.setBounds(new Rectangle(150, 45, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Yes");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(220, 45, 50, 25));
    jButton2.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton2.setText("No");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    mainPage = new MainPage(this.sconn);
    mainPage.show();
    dispose();
  }
}