package ui;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.net.*;
import javax.net.ssl.*;
import java.security.*;
import java.util.*;
import java.security.cert.*;
//import COM.claymoresystems.ptls.*;
//import COM.claymoresystems.sslg.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

//server trust certificate password at line291

public class MQRegister
    extends JFrame {
  LogonPage logonPage;
  JPanel contentPane;
  MQRegisterSuccess mqRegisterSuccess;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JTextField jTextField5 = new JTextField();
  JLabel jLabel11 = new JLabel();
  JTextField jTextField6 = new JTextField();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JTextField jTextField7 = new JTextField();
  public final static String algorithm ="SSLv3";
  JFileChooser jFileChooser1 = new JFileChooser();
  JTextField jTextField8 = new JTextField();
  JButton jButton4 = new JButton();
  File file;

  //Construct the frame
  public MQRegister() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.logonPage = new LogonPage();
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(RegisterPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(400, 458));
    this.setTitle("Register a new user");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setBounds(new Rectangle(5, 11, 380, 403));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Enter details about yourself");
    jLabel2.setBounds(new Rectangle(15, 85, 155, 20));
    jLabel3.setBorder(BorderFactory.createEtchedBorder());
    jLabel3.setDebugGraphicsOptions(0);
    jLabel3.setBounds(new Rectangle(14, 113, 359, 137));
    jLabel4.setText("First Name");
    jLabel4.setBounds(new Rectangle(25, 125, 65, 20));
    jLabel5.setText("Last Name");
    jLabel5.setBounds(new Rectangle(200, 125, 65, 20));
    jLabel7.setText("Gender");
    jLabel7.setBounds(new Rectangle(20, 184, 65, 20));
    jComboBox1.addItem("Male");
    jComboBox1.addItem("Female");
    jComboBox1.setSelectedItem("Not Specified");
    jComboBox1.setBounds(new Rectangle(90, 184, 100, 20));
    jLabel8.setText("E-mail address");
    jLabel8.setBounds(new Rectangle(23, 216, 90, 20));
    jLabel15.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel15.setText("Key file manager");
    jLabel15.setBounds(new Rectangle(14, 261, 120, 20));
    jLabel17.setBorder(BorderFactory.createEtchedBorder());
    jLabel17.setBounds(new Rectangle(13, 280, 360, 80));
    jLabel18.setText("key File :");
    jLabel18.setBounds(new Rectangle(41, 293, 76, 20));
    jLabel19.setText("Key Password :");
    jLabel19.setBounds(new Rectangle(41, 323, 110, 20));
    jButton1.setBounds(new Rectangle(53, 377, 100, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(163, 377, 80, 25));
    jButton2.setText("Clear");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(253, 377, 80, 25));
    jButton3.setText("Cancel");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });

    jPasswordField1.setBounds(new Rectangle(130, 323, 140, 20));
    jTextField4.setBounds(new Rectangle(113, 216, 200, 20));
    jTextField2.setBounds(new Rectangle(265, 125, 100, 20));
    jTextField1.setMinimumSize(new Dimension(6, 21));
    jTextField1.setVerifyInputWhenFocusTarget(true);
    jTextField1.setScrollOffset(0);
    jTextField1.setBounds(new Rectangle(90, 125, 100, 20));
    contentPane.setPreferredSize(new Dimension(400, 415));
    jLabel6.setText("Age");
    jLabel6.setBounds(new Rectangle(198, 186, 34, 15));
    jTextField3.setText("");
    jTextField3.setBounds(new Rectangle(264, 184, 101, 21));
    jLabel9.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel9.setText("Register to");
    jLabel9.setBounds(new Rectangle(15, 18, 73, 15));
    jLabel10.setText("Server IP");
    jLabel10.setBounds(new Rectangle(24, 52, 56, 15));
    jTextField5.setText("");
    jTextField5.setBounds(new Rectangle(89, 50, 102, 21));
    jLabel11.setText("Port");
    jLabel11.setBounds(new Rectangle(229, 53, 28, 15));
    jTextField6.setText("");
    jTextField6.setBounds(new Rectangle(265, 51, 80, 21));
    jLabel12.setBorder(BorderFactory.createEtchedBorder());
    jLabel12.setText("");
    jLabel12.setBounds(new Rectangle(14, 39, 358, 46));
    jLabel13.setText("Nickname");
    jLabel13.setBounds(new Rectangle(23, 157, 53, 15));
    jTextField7.setText("");
    jTextField7.setBounds(new Rectangle(89, 153, 278, 21));
    jTextField8.setEditable(false);
    jTextField8.setText("");
    jTextField8.setBounds(new Rectangle(130, 292, 140, 21));
    jButton4.setBounds(new Rectangle(277, 291, 78, 25));
    jButton4.setText("Browse");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jButton4, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jLabel18, null);
    contentPane.add(jLabel19, null);
    contentPane.add(jLabel17, null);
    contentPane.add(jLabel1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jPasswordField1.setText("");
    jComboBox1.setSelectedItem("Male");

  }



  void jButton1_actionPerformed(ActionEvent e) {
    char[] pwd1 = jPasswordField1.getPassword();
    String result;
    String title;
    String filename = new String(jTextField8.getText());
    String passwd1 = new String(pwd1);
    //if ((!passwd1.equals(""))&&(!jTextField6.getText().equals(""))&&(!filename.equals(""))&&(!jTextField5.getText().equals(""))) {
    if(true){
      //-------------------------------------------------------------------
      int port = Integer.parseInt(jTextField6.getText());
      String firstname = jTextField1.getText();
      String lastname = jTextField2.getText();
      String nickname = jTextField7.getText();
      String email = jTextField4.getText();
      String age = jTextField3.getText();
      String gender;
      if(jComboBox1.getSelectedItem().toString().equals("Male")){
        gender=new String("M");
      }else{
        gender=new String("F");
      }

      //-----------------------------------------------------------------
      String message;
      message=firstname+"$"+lastname+"$"+nickname+"$"+gender+"$"+age+"$"+email+"$";
      byte[] cmdpatn={0x01,0x00,0x01,0x00,0x07,0x10,(byte)0xff};


      //-----------------------------------------------------------------
      try{
        //Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        //Security.addProvider(new com.sun.rsajca.Provider());

        SSLContext context = SSLContext.getInstance("SSLv3");
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new FileInputStream(filename),pwd1);
        //ks.load(null,pwd1);
        //java.security.cert.Certificate clicert=Certificate.importCertificate(new File(filename));
        //FileInputStream prikey=new FileInputStream("c:/cert/client.key");
        //byte[] keybyte=new byte[prikey.available()];
        //prikey.read(keybyte);
        //ks.setCertificateEntry("clientkey",clicert);
        //java.security.cert.Certificate[] certchain = new java.security.cert.Certificate[1];
        //certchain[0]=clicert;
        //ks.setKeyEntry("clientkey",keybyte,certchain);
        //System.out.println(ks.size());
        kmf.init(ks,"654321".toCharArray());

        TrustManagerFactory tmf=TrustManagerFactory.getInstance("SunX509");
        KeyStore ts = KeyStore.getInstance(KeyStore.getDefaultType());
        //KeyStore ts = KeyStore.getInstance("JKS");
        char[] pswd="654321".toCharArray();
        //ts.load(new FileInputStream("./cert/server.pem"),pswd);
        ts.load(null,null);
        java.security.cert.Certificate cert=Certificate.importCertificate(new File("./cert/ca.pem"));
        ts.setCertificateEntry("mqtrust",cert);
        tmf.init(ts);
        //System.out.println(ks.getCertificateChain("clientkey"));



        context.init(kmf.getKeyManagers(),tmf.getTrustManagers(),null);
        //context.init(kmf.getKeyManagers(),null,null);
        SSLSocketFactory sockfac=context.getSocketFactory();
        SSLSocket socket=(SSLSocket)sockfac.createSocket(jTextField5.getText(),port);

        //String[] cryptoAlgo={"SSL_RSA_EXPORT_WITH_RC4_40_MD5","SSL_RSA_WITH_NULL_MD5","SSL_RSA_WITH_3DES_EDE_CBC_SHA"};
        //String[] cryptoAlgo=socket.getEnabledCipherSuites();
        //System.out.println(cryptoAlgo);
        //socket.setEnabledCipherSuites(cryptoAlgo);
        //String[] cryptoProtocol=socket.getEnabledProtocols();
        //System.out.println(cryptoProtocol);
        //socket.setEnabledProtocols(cryptoProtocol);

        //socket.setUseClientMode(true);
        //socket.setNeedClientAuth(true);
        socket.startHandshake();
        /*socket.addHandshakeCompletedListener(new javax.net.ssl.HandshakeCompletedListener(){
          public void actionPerformed(javax.net.ssl.HandshakeCompletedEvent e){

          }
        });*/
        DataOutputStream output=new DataOutputStream(socket.getOutputStream());
        DataInputStream input=new DataInputStream(socket.getInputStream());
        byte[] recieve=new byte[512];
        input.read(recieve);
        int len=message.length();
        System.out.println((int)cmdpatn[0]+" "+(int)cmdpatn[5]);
        byte[] sendbyte=new byte[512];
        System.arraycopy(cmdpatn,0,sendbyte,0,cmdpatn.length);
        output.write(sendbyte); //send request to server
        output.flush();
        byte[] temp=new byte[7];
        recieve=new byte[512];
        input.read(recieve); //recieve ack from server
        for(int i=0;i<7;i++){
          System.out.print((int)recieve[i]+" ");
        }
        //int len3=((int)recieve[3])+((int)recieve[4]);
        System.out.println();
        System.out.println();
        System.out.println(new String(recieve));
        System.out.println();
        System.out.println();
        byte[] sendpatn=new byte[7 + len];
        for(int i=0;i<=6;i++){
          sendpatn[i]=cmdpatn[i];
        }
        sendpatn[5]=(byte)0x12;
        byte[] messagebyte=message.getBytes();
        System.arraycopy(messagebyte,0,sendpatn,7,messagebyte.length);
        //for(int i=7;i<(7+len);i++){
        //  sendpatn[i]=(byte)message.charAt(i-7);
        //}
        sendpatn[4]=(byte)(sendpatn.length);
        sendbyte=new byte[512];
        System.arraycopy(sendpatn,0,sendbyte,0,sendpatn.length);
        output.write(sendbyte); //send information to server
        output.flush();
        recieve=new byte[512];
        input.read(recieve); //recieve ID from server
        for(int i=0;i<7;i++){
          temp[i]=recieve[i];
        }
        for(int i=0;i<7;i++){
          System.out.print((int)temp[i]+" ");
        }
        System.out.println();
        System.out.println();
        System.out.println(new String(recieve));
        System.out.println();
        System.out.println();
        int len2=((int)temp[3])+((int)temp[4]);
        byte[] idtemp=new byte[9];
        for(int i=0;i<9;i++){
          idtemp[i]=recieve[i+7];
        }
        System.out.println(len2);
        System.out.println(new String(idtemp));
        //title="Register A New User Complete";
        //result="Your IsagQ ID is "+new String(idtemp);
        //this.logonPage.messageBox=new MessageBox(title,result);
        //this.logonPage.messageBox.show();
        this.dispose();

        output.close();
        input.close();
        socket.close();
        mqRegisterSuccess=new MQRegisterSuccess(new String(idtemp));
        mqRegisterSuccess.show();
        FileInputStream fi = new FileInputStream("./activeuser/isagquser");
        Properties isagquser = new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,file.getPath());
        this.outPropertiesTofile(isagquser, "./activeuser/isagquser");

        fi = new FileInputStream("./activeuser/isagserver");
        isagquser=new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,jTextField5.getText());
        this.outPropertiesTofile(isagquser,"./activeuser/isagserver");

        fi = new FileInputStream("./activeuser/isagport");
        isagquser=new Properties();
        isagquser.load(fi);
        fi.close();
        isagquser.put(nickname,String.valueOf(port));
        this.outPropertiesTofile(isagquser,"./activeuser/isagport");


      }catch(Exception ex){
        JOptionPane.showMessageDialog(this,ex.toString(),"Error warning",JOptionPane.ERROR_MESSAGE);
        //this.logonPage.messageBox=new MessageBox("Error",ex.toString());
        //this.logonPage.messageBox.show();
      }
      this.logonPage.messageBox=new MessageBox("error","error");
      //-------------------------------------------------------
    }
    else {
      if(jTextField5.getText().equals("")){
        title="Register A New User Fail";
        result="Please enter server IP";
      }
      else if (passwd1.equals("")) {
        jPasswordField1.setText("");
        title = "Register A New User Fail";
        result = "Please enter Certificate Password.";
      }
      else if(jTextField6.getText().equals("")){
        title="Register A New User Fail";
        result="Please enter server Port";
      }
      else if(filename.equals("")){
        title="Register A New User Fail";
        result="Please select your certificate file";
      }
      this.logonPage.messageBox = new MessageBox(title, result);
      this.logonPage.messageBox.show();
    }
  }

  void jButton4_actionPerformed(ActionEvent e) {
    if(jTextField8.getText().length()==0){
      jFileChooser1 = new JFileChooser();
    }else{
      jFileChooser1 = new JFileChooser(file.getParent());
    }
    jFileChooser1.setFileSelectionMode(JFileChooser.FILES_ONLY);
    int result=jFileChooser1.showOpenDialog(this);
    if(result==JFileChooser.CANCEL_OPTION){
    }else{
      file=jFileChooser1.getSelectedFile();
      jTextField8.setText(file.getPath());
    }
  }

  public void outPropertiesTofile(Properties a, String filename) {
    try {
      FileOutputStream fo;
      fo = new FileOutputStream(filename);
      a.store(fo, filename);
      fo.close();
    }
    catch (IOException rt) {}
  }

}
