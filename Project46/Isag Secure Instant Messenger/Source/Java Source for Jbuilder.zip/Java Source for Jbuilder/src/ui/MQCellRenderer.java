package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;

public class MQCellRenderer
    extends JLabel
    implements ListCellRenderer {
  private Icon ic[];
  private int secureindex;
  private int onlineindex;
  private int offlineindex;
  private int selectindex;
  private int posinlist;
  private UserData user;
  private String statuslist;
  public Component getListCellRendererComponent(JList j1, Object o, int i,
                                                boolean s, boolean f) {
    try {
      int status = 3;
      this.setText(o.toString());
      if (o.toString().equals("	------------- Online --------------")) {
        status = 0;
        onlineindex = i;
        this.setIcon(ic[9]);
        this.setForeground(Color.black);
        this.setText("");
      }
      else if (o.toString().equals("	------------- Offline -------------")) {
        status = 0;
        offlineindex = i;
        this.setForeground(Color.black);
        this.setIcon(ic[10]);
        this.setText("");
      }
      else {
        if (i > onlineindex && i < offlineindex) { //check for online
          this.setForeground(Color.blue);
          this.setText(o.toString());
          i = 0;
        }
        else if (i > offlineindex) { //check for offline
          this.setForeground(Color.red);
          this.setText(o.toString());
          i = 1;
        }
        this.setIcon(ic[i]);
      }
      //-----------------------------------------------
      if (s) {
        if (status == 3) {
          this.setBackground(j1.getSelectionBackground());
          // this.setForeground(this.getForeground());
        }
      }
      else {
        this.setBackground(j1.getBackground());
        // this.setForeground(this.getForeground()) ;
      }
    }
    catch (Exception e) {
      System.out.println(e.getMessage() + "list error");
    }
    return this;
  }

//-----------------------------------------------------------
  public MQCellRenderer(Icon ic[]) {
    this.ic = ic;
    this.setOpaque(true);
  }

//------------------------------------------------------------
  public int getSelectindex(int i) {
    if (i > onlineindex && i < offlineindex) { //check for online
      this.selectindex = i - onlineindex - 1;
      this.statuslist = "online";
    }
    else if (i > offlineindex) { //check for offline
      this.selectindex = i - offlineindex - 1;
      this.statuslist = "offline";
    }
    return this.selectindex;
  }

//-----------------------------------------------------------
  public String getStatuslist() {
    return this.statuslist;
  }
//-----------------------------------------------------------
}
