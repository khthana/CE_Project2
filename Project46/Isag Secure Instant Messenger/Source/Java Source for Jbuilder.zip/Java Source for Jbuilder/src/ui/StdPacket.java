package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class StdPacket
    extends Packet {
  private Util util;
  private Constant constant;
  private ClientToServerCMD cmd;
  private ServerToClientCMD srv_cmd;
  private byte[] cookie;
//--------------------------------------------------------------------------
  public byte[] getCookie() {
    return this.cookie;
  }

//------------------------------------------------------------------------------
      /*-------------------------not complete---------------------------------------*/
  public byte[] setPacket(int cmd, short seq, byte[] data) {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    byte channel = 0x00;
    this.setData(data);
    //-----------------------------------------------------
    while (seq == -1) { // if seq	is inittial,it will be random
      Random r = new Random();
      seq = (short) r.nextInt();
    }
    //-----------------------------------------------------
    seq++;
    try { //---------------------------------------------------------------------------------
      if (cmd == this.cmd.ident) {
	channel = 0x01;
      }
      //-------------------------------------------------------------------------------
      if (cmd == this.cmd.goodbye) {
	channel = 0x04;
      }
      //--------------------------------------------------------------------------------
      if (cmd == this.cmd.cookie) {
	channel = 0x01;
      }
      //--------------------------------------------------------------------------------
      short length = 0;
      if (this.data == null) {
	length = 0;
      }
      else {
	length = (short)this.data.length;
      }
      this.setHeader(this.constant.id, channel, seq, length, cmd);
      dataOut.write(this.header.getAllByte()); //put header
      if (this.data == null) {
      }
      else {
	dataOut.write(this.data);
      }
      ; //put data
      return byteOut.toByteArray();
    }
    catch (IOException e) {}
    return null;
  }

//--------------------------------------------------
  public void setHeader(byte id, byte chn, short seq, short length, int command) {
    //set header for cmdPacket
    this.header.setId(id);
    this.header.setChannel(chn);
    this.header.setSequence(seq);
    this.header.setLength(length);
    this.header.setCommand(command);
  }

//-----------------------------------------------
  public void setData(byte[] data) {
    //set data for stdpacket
    this.data = data;
  }

//-----------------------------------------------
  public void analytePacket(byte[] packet) {
    byte[] temp = new byte[7];
    short tmpshort;
    int tmpint;
    long tmplong;
    byte[] cookies;
    String tmpstring;
    temp = new byte[7];
    this.header.setCommand(this.srv_cmd.srv_hello);
    int posdata = 6;
    // chn_login = new Channel_LoginHeader() ;
    this.header.setId(packet[0]);
    this.header.setChannel(packet[1]);
    // chn_login.setId(packet[0]);
    // chn_login.setChannel(packet[1]);
    temp[0] = packet[2];
    temp[1] = packet[3];
    tmpshort = util.bytes2Short(temp);
    this.header.setSequence(tmpshort);
    //chn_login.setSequence(tmpshort) ;
    temp[0] = packet[4];
    temp[1] = packet[5];
    tmpshort = util.bytes2Short(temp);
    this.header.setLength(tmpshort);
    //chn_login.setLength(tmpshort);
    data = new byte[this.header.getLength()];
    for (tmpint = 0; tmpint != this.header.getLength(); tmpint++) {
      this.data[tmpint] = packet[posdata];
      posdata++;
    }
    //-----------------------get cookies---------------------------------------------
    if (this.header.getChannel() == 0x04) {
      this.header.setCommand(this.srv_cmd.srv_goodbye);
      int length;
      short lengthtlv1;
      short lengthtlv5;
      if (data.length != 0) {
	temp = new byte[7];
	temp[0] = data[2];
	temp[1] = data[3];
	lengthtlv1 = util.bytes2Short(temp);
	temp[0] = data[lengthtlv1 + 6];
	temp[1] = data[lengthtlv1 + 7];
	lengthtlv5 = util.bytes2Short(temp);
	posdata = lengthtlv1 + lengthtlv5 + 8;
	length = this.header.getLength() - posdata;
	cookies = new byte[length];
	for (tmpint = 0; tmpint != length; tmpint++) {
	  cookies[tmpint] = data[posdata];
	  posdata++;
	}
	this.cookie = cookies;
	this.data = data;
      }
    }
  }

//-----------------------------------------------
  public StdPacket() {
    this.header = new HeadPacket();
    this.data = null;
    this.cmd = new ClientToServerCMD();
    this.srv_cmd = new ServerToClientCMD();
    this.constant = new Constant();
    this.cookie = null;
  }
}