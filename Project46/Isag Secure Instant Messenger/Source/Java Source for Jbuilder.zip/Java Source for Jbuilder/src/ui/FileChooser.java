package ui;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FileChooser
    extends JFrame {
  private ServerConnect sconnect;
  private File file;
  //private TCPconnect tcpconnect;
  private UserData user;
  JPanel jPanel1 = new JPanel();
  JFileChooser jFileChooser1 = new JFileChooser();

  public FileChooser(ServerConnect sconnect, UserData user) {
    try {
      this.sconnect = sconnect;
      this.user = user;
      //this.tcpconnect = new TCPconnect(this.sconnect);
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setSize(new Dimension(479, 386));
    this.getContentPane().setLayout(null);
    jPanel1.setBorder(BorderFactory.createLineBorder(Color.black));
    jPanel1.setBounds(new Rectangle(3, 3, 462, 336));
    jPanel1.setLayout(null);
    jFileChooser1.setBounds(new Rectangle(5, 5, 449, 318));
    jFileChooser1.addActionListener(new FileChooser_jFileChooser1_actionAdapter(this));
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jFileChooser1, null);
  }

//-------------------------------------------------------------
  public File getFile() {
    return this.file;
  }

//-------------------------------------------------------------
  void jFileChooser1_actionPerformed(ActionEvent e) {
    this.file = this.jFileChooser1.getSelectedFile();
    System.out.println(file);
    System.out.println(file.getName());
    //this.tcpconnect.sendReqSendFile(this.user, this.file);
    this.dispose();
  }
//-----------------------------------------------------------
}

class FileChooser_jFileChooser1_actionAdapter
    implements java.awt.event.ActionListener {
  FileChooser adaptee;

  FileChooser_jFileChooser1_actionAdapter(FileChooser adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jFileChooser1_actionPerformed(e);
  }
}