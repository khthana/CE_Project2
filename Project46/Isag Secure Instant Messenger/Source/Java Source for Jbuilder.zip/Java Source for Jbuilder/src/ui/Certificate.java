package ui;

import java.io.*;
import java.util.*;
import java.security.cert.*;
import java.lang.*;
import java.nio.charset.Charset;
import java.security.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Certificate {
  public Certificate() {
  }

//---------------------------------------------------------------------------------
  // This method reads a certificate to a file. The certificate can be either
  // binary or base64 encoded.
  public static java.security.cert.Certificate importCertificate(File file) {
    try {
      FileInputStream is = new FileInputStream(file);
      BufferedInputStream bis = new BufferedInputStream(is);

      CertificateFactory cf = CertificateFactory.getInstance("X.509");
      java.security.cert.Certificate cert = cf.generateCertificate(bis);
      return cert;
    }
    catch (CertificateException e) {
    }
    catch (IOException e) {
    }
    return null;
  }

//-------------------------------------------------------------------------------
  // This method writes a certificate to a file. If binary is false, the
  // certificate is base64 encoded.
  public static void export(java.security.cert.Certificate cert, File file,
			    boolean binary) {
    try {
      // Get the encoded form which is suitable for exporting
      byte[] buf = cert.getEncoded();

      FileOutputStream os = new FileOutputStream(file);
      if (binary) {
	// Write in binary form
	os.write(buf);
      }
      else {
	// Write in text form
	Writer wr = new OutputStreamWriter(os, Charset.forName("UTF-8"));
	wr.write("-----BEGIN CERTIFICATE-----\n");
	wr.write(new sun.misc.BASE64Encoder().encode(buf));
	wr.write("\n-----END CERTIFICATE-----\n");
	wr.flush();
      }
      os.close();
    }
    catch (CertificateEncodingException e) {
    }
    catch (IOException e) {
    }
  }

//-------------------------------------------------------------------------------
  // This method adds a certificate with the specified alias to the specified keystore file.
  public static void addToKeyStore(File keystoreFile, char[] keystorePassword,
				   String alias,
				   java.security.cert.Certificate cert) {
    try {
      // Create an empty keystore object
      KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());

      // Load the keystore contents
      FileInputStream in = new FileInputStream(keystoreFile);
      keystore.load(in, keystorePassword);
      in.close();

      // Add the certificate
      keystore.setCertificateEntry(alias, cert);

      // Save the new keystore contents
      FileOutputStream out = new FileOutputStream(keystoreFile);
      keystore.store(out, keystorePassword);
      out.close();
    }
    catch (java.security.cert.CertificateException e) {
    }
    catch (NoSuchAlgorithmException e) {
    }
    catch (FileNotFoundException e) {
      // Keystore does not exist
    }
    catch (KeyStoreException e) {
    }
    catch (IOException e) {
    }
  }

//-------------------------------------------------------------------------------
  // This method adds a certificate with the specified alias to the specified new keystore file.
  public static void addToNewKeyStore(File keystoreFile, char[] keystorePassword,
                                   String alias,
                                   java.security.cert.Certificate cert) {
    try {
      // Create an empty keystore object
      KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());

      // New the keystore contents
      //FileInputStream in = new FileInputStream(keystoreFile);
      keystore.load(null, keystorePassword);
      //in.close();

      // Add the certificate
      keystore.setCertificateEntry(alias, cert);

      // Save the new keystore contents
      FileOutputStream out = new FileOutputStream(keystoreFile);
      keystore.store(out, keystorePassword);
      out.close();
    }
    catch (java.security.cert.CertificateException e) {
    }
    catch (NoSuchAlgorithmException e) {
    }
    catch (FileNotFoundException e) {
      // Keystore does not exist
    }
    catch (KeyStoreException e) {
    }
    catch (IOException e) {
    }
  }


//------------------------------------------------------------------------------
  public java.security.cert.Certificate receiveCerFromKeystore() {
    try {

      // Load the keystore in the user's home directory
      FileInputStream is = new FileInputStream(System.getProperty("user.home")
					       + File.separatorChar +
					       ".keystore");

      KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
      keystore.load(is, "my-keystore-password".toCharArray());

      // Get certificate
      java.security.cert.Certificate cert = keystore.getCertificate("myalias");
      return cert;
    }
    catch (KeyStoreException e) {
    }
    catch (java.security.cert.CertificateException e) {
    }
    catch (NoSuchAlgorithmException e) {
    }
    catch (java.io.IOException e) {
    }
    return null;
  }

//-------------------------------------------------------------------------------
  public static CertPath createCertPath(java.security.cert.Certificate[] certs) {
    try {
      CertificateFactory certFact = CertificateFactory.getInstance("X.509");
      CertPath path = certFact.generateCertPath(Arrays.asList(certs));
      return path;
    }
    catch (java.security.cert.CertificateEncodingException e) {
    }
    catch (CertificateException e) {
    }
    return null;
  }

//-------------------------------------------------------------------------------
  public void validationcheckcerPath(CertPath certPath) {
    try {
      // Load the JDK's cacerts keystore file
      String filename = System.getProperty("java.home")
	  + "/lib/security/cacerts".replace('/', File.separatorChar);
      FileInputStream is = new FileInputStream(filename);
      KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
      String password = "changeit";
      keystore.load(is, password.toCharArray());

      // Create the parameters for the validator
      PKIXParameters params = new PKIXParameters(keystore);

      // Disable CRL checking since we are not supplying any CRLs
      params.setRevocationEnabled(false);

      // Create the validator and validate the path
      // To create a path, see e229 Creating a Certification Path
      System.out.println(CertPathValidator.getDefaultType());
      CertPathValidator certPathValidator = CertPathValidator.getInstance(
	  CertPathValidator.getDefaultType());
      CertPathValidatorResult result;
      result = certPathValidator.validate(certPath, params);

      // Get the CA used to validate this path
      PKIXCertPathValidatorResult pkixResult = (PKIXCertPathValidatorResult)
	  result;
      TrustAnchor ta = pkixResult.getTrustAnchor();
      X509Certificate cert = ta.getTrustedCert();

      System.out.println("Validation success");
    }
    catch (CertificateException e) {
    }
    catch (KeyStoreException e) {
    }
    catch (NoSuchAlgorithmException e) {
    }
    catch (InvalidAlgorithmParameterException e) {
    }
    catch (CertPathValidatorException e) {
    }
    catch (IOException e) {}
    // Validation failed
    System.out.println("Validation failed");
  }

//---------------------------------------------------------------------------------
  public java.security.cert.Certificate[] listTrustca(java.security.cert.
      Certificate cer) {
    try {
      java.security.cert.Certificate[] certs;
      // Load the JDK's cacerts keystore file
      String filename = System.getProperty("java.home")
	  + "/lib/security/cacerts".replace('/', File.separatorChar);
      FileInputStream is = new FileInputStream(filename);
      KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
      String password = "changeit";
      keystore.load(is, password.toCharArray());

      // This class retrieves the most-trusted CAs from the keystore
      PKIXParameters params = new PKIXParameters(keystore);

      // Get the set of trust anchors, which contain the most-trusted CA certificates
      Iterator it = params.getTrustAnchors().iterator();
      certs = new java.security.cert.Certificate[30];
      int i = 0;
      for (; it.hasNext(); ) {
	TrustAnchor ta = (TrustAnchor) it.next();

	// Get certificate
	X509Certificate cert = ta.getTrustedCert();
	System.out.println(
	    "-----------------------------------------------------------------"); ;
	certs[i] = cert;
	System.out.println(cert.toString());
	System.out.println(
	    "-----------------------------------------------------------------");
	i++;
      }
      //certs[i] = cer ;
      System.out.println(
	  "-----------------------------------------------------------------"); ;
      System.out.println(cer.toString());
      System.out.println(
	  "-----------------------------------------------------------------");
      return certs;
    }
    catch (CertificateException e) {
    }
    catch (KeyStoreException e) {
    }
    catch (NoSuchAlgorithmException e) {
    }
    catch (InvalidAlgorithmParameterException e) {
    }
    catch (IOException e) {
    }
    return null;
  }
//-------------------------------------------------------------------------------
}