package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class UserDetail
    extends JFrame {
  private ServerConnect sconnect;
  private String uin;
  JPanel contentPane;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JTextField jTextField5 = new JTextField();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JTextField jTextField6 = new JTextField();
  JLabel jLabel15 = new JLabel();
  JTextField jTextField7 = new JTextField();
  JLabel jLabel16 = new JLabel();
  JTextField jTextField8 = new JTextField();
  JLabel jLabel17 = new JLabel();
  JTextField jTextField9 = new JTextField();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JComboBox jCombo1 = new JComboBox();
  JLabel jLabel21 = new JLabel();
  JTextField jTextField10 = new JTextField();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JComboBox jCombo3 = new JComboBox();
  JLabel jLabel25 = new JLabel();
  JComboBox jCombo4 = new JComboBox();
  JLabel jLabel26 = new JLabel();
  JComboBox jCombo5 = new JComboBox();
  JButton jButton1 = new JButton();

  //Construct the frame
  public UserDetail(ServerConnect sconnect) {
    this.sconnect = sconnect;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(UserDetail.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);

    this.setResizable(false);
    this.setSize(new Dimension(390, 385));

    jTabbedPane1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setBounds(new Rectangle(10, 10, 360, 305));
    jPanel1.setLayout(null);
    jPanel2.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("User Identification Number");
    jLabel1.setBounds(new Rectangle(10, 10, 160, 20));
    jLabel2.setBorder(BorderFactory.createEtchedBorder());
    jLabel2.setBounds(new Rectangle(10, 35, 335, 35));
    jLabel3.setText("UIN # :");
    jLabel3.setBounds(new Rectangle(100, 43, 45, 20));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("Names");
    jLabel4.setBounds(new Rectangle(10, 80, 147, 20));
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(10, 105, 335, 85));
    jLabel6.setText("First Name :");
    jLabel6.setBounds(new Rectangle(65, 113, 70, 20));
    jLabel7.setText("Last Name :");
    jLabel7.setBounds(new Rectangle(65, 138, 70, 20));
    jLabel8.setText("Nickname	:");
    jLabel8.setBounds(new Rectangle(65, 163, 70, 20));
    jTextField1.setBackground(new Color(212, 208, 200));
    jTextField1.setEnabled(false);
    jTextField1.setDisabledTextColor(Color.black);
    jTextField1.setEditable(false);
    jTextField1.setBounds(new Rectangle(155, 43, 100, 20));
    jTextField2.setBackground(new Color(212, 208, 200));
    jTextField2.setEnabled(false);
    jTextField2.setDisabledTextColor(Color.black);
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(140, 113, 140, 20));
    jTextField3.setBackground(new Color(212, 208, 200));
    jTextField3.setEnabled(false);
    jTextField3.setDisabledTextColor(Color.black);
    jTextField3.setEditable(false);
    jTextField3.setBounds(new Rectangle(140, 138, 140, 20));
    jTextField4.setBackground(new Color(212, 208, 200));
    jTextField4.setEnabled(false);
    jTextField4.setDisabledTextColor(Color.black);
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(140, 163, 140, 20));
    jTextField5.setBackground(new Color(212, 208, 200));
    jTextField5.setEnabled(false);
    jTextField5.setDisabledTextColor(Color.black);
    jTextField5.setEditable(false);
    jTextField5.setBounds(new Rectangle(140, 233, 140, 20));
    jTextField6.setBackground(new Color(212, 208, 200));
    jTextField6.setEnabled(false);
    jTextField6.setDisabledTextColor(Color.black);
    jTextField6.setEditable(false);
    jTextField6.setBounds(new Rectangle(60, 45, 100, 20));
    jTextField7.setBackground(new Color(212, 208, 200));
    jTextField7.setEnabled(false);
    jTextField7.setDisabledTextColor(Color.black);
    jTextField7.setEditable(false);
    jTextField7.setBounds(new Rectangle(60, 70, 100, 20));
    jTextField8.setBackground(new Color(212, 208, 200));
    jTextField8.setEnabled(false);
    jTextField8.setDisabledTextColor(Color.black);
    jTextField8.setEditable(false);
    jTextField8.setBounds(new Rectangle(235, 45, 100, 20));
    jTextField9.setBackground(new Color(212, 208, 200));
    jCombo1.setBackground(new Color(212, 208, 200));
    jCombo1.setEnabled(false);
    jCombo1.setBounds(new Rectangle(120, 145, 65, 20));
    jTextField10.setBackground(new Color(212, 208, 200));
    jTextField10.setEnabled(false);
    jTextField10.setDisabledTextColor(Color.black);
    jTextField10.setEditable(false);
    jTextField10.setBounds(new Rectangle(245, 145, 40, 20));
    jCombo3.setBackground(new Color(212, 208, 200));
    jCombo3.setEnabled(false);
    jCombo3.setBounds(new Rectangle(55, 220, 40, 20));
    jCombo4.setBackground(new Color(212, 208, 200));
    jCombo4.setEnabled(false);
    jCombo4.setBounds(new Rectangle(150, 220, 85, 20));
    jCombo5.setBackground(new Color(212, 208, 200));
    jCombo5.setEnabled(false);
    jCombo5.setBounds(new Rectangle(285, 220, 50, 20));
    jLabel9.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel9.setText("E-mail Address");
    jLabel9.setBounds(new Rectangle(10, 200, 100, 20));
    jLabel10.setBorder(BorderFactory.createEtchedBorder());
    jLabel10.setBounds(new Rectangle(10, 225, 335, 35));
    jLabel11.setText("E-mail				:");
    jLabel11.setBounds(new Rectangle(65, 233, 70, 20));
    jLabel12.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel12.setText("Address");
    jLabel12.setBounds(new Rectangle(10, 10, 65, 20));
    jLabel13.setBorder(BorderFactory.createEtchedBorder());
    jLabel13.setBounds(new Rectangle(10, 35, 335, 65));
    jLabel14.setText("City		 :");
    jLabel14.setBounds(new Rectangle(20, 45, 40, 20));
    jLabel15.setText("State	:");
    jLabel15.setBounds(new Rectangle(20, 70, 40, 20));
    jLabel16.setText("Zip Code :");
    jLabel16.setBounds(new Rectangle(175, 45, 60, 20));
    jLabel17.setText("Country		:");
    jLabel17.setBounds(new Rectangle(175, 70, 60, 20));
    jLabel18.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel18.setText("Additional Details");
    jLabel18.setBounds(new Rectangle(10, 110, 100, 20));
    jLabel19.setBorder(BorderFactory.createEtchedBorder());
    jLabel19.setBounds(new Rectangle(10, 135, 335, 40));
    jLabel20.setText("Gender	 :");
    jLabel20.setBounds(new Rectangle(60, 145, 60, 20));
    jLabel21.setText("Age	 :");
    jLabel21.setBounds(new Rectangle(205, 145, 40, 20));
    jTextField9.setBackground(new Color(212, 208, 200));
    jTextField9.setEnabled(false);
    jTextField9.setDisabledTextColor(Color.black);
    jTextField9.setEditable(false);
    jTextField9.setBounds(new Rectangle(235, 70, 100, 20));
    jLabel22.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel22.setText("Birthdate");
    jLabel22.setBounds(new Rectangle(10, 185, 100, 20));
    jLabel23.setBorder(BorderFactory.createEtchedBorder());
    jLabel23.setBounds(new Rectangle(10, 210, 335, 40));
    jLabel24.setText("Day	:");
    jLabel24.setBounds(new Rectangle(20, 220, 35, 20));
    jLabel25.setText("Month	:");
    jLabel25.setBounds(new Rectangle(105, 220, 45, 20));
    jLabel26.setText("Year	:");
    jLabel26.setBounds(new Rectangle(245, 220, 40, 20));
    jButton1.setBounds(new Rectangle(150, 325, 80, 25));
    jButton1.setText("Close");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jCombo1.addItem("Not Specified");
    jCombo1.addItem("Male");
    jCombo1.addItem("Female");

    jCombo3.addItem("");
    jCombo3.addItem("01");
    jCombo3.addItem("02");
    jCombo3.addItem("03");
    jCombo3.addItem("04");
    jCombo3.addItem("05");
    jCombo3.addItem("06");
    jCombo3.addItem("07");
    jCombo3.addItem("08");
    jCombo3.addItem("09");
    jCombo3.addItem("10");
    jCombo3.addItem("11");
    jCombo3.addItem("12");
    jCombo3.addItem("13");
    jCombo3.addItem("14");
    jCombo3.addItem("15");
    jCombo3.addItem("16");
    jCombo3.addItem("17");
    jCombo3.addItem("18");
    jCombo3.addItem("19");
    jCombo3.addItem("20");
    jCombo3.addItem("21");
    jCombo3.addItem("22");
    jCombo3.addItem("23");
    jCombo3.addItem("24");
    jCombo3.addItem("25");
    jCombo3.addItem("26");
    jCombo3.addItem("27");
    jCombo3.addItem("28");
    jCombo3.addItem("29");
    jCombo3.addItem("30");
    jCombo3.addItem("31");

    jCombo4.addItem("");
    jCombo4.addItem("January");
    jCombo4.addItem("February");
    jCombo4.addItem("March");
    jCombo4.addItem("April");
    jCombo4.addItem("May");
    jCombo4.addItem("June");
    jCombo4.addItem("July");
    jCombo4.addItem("August");
    jCombo4.addItem("September");
    jCombo4.addItem("October");
    jCombo4.addItem("November");
    jCombo4.addItem("December");

    jCombo5.addItem("");
    jCombo5.addItem("1900");
    jCombo5.addItem("1901");
    jCombo5.addItem("1902");
    jCombo5.addItem("1903");
    jCombo5.addItem("1904");
    jCombo5.addItem("1905");
    jCombo5.addItem("1906");
    jCombo5.addItem("1907");
    jCombo5.addItem("1908");
    jCombo5.addItem("1909");
    jCombo5.addItem("1910");
    jCombo5.addItem("1911");
    jCombo5.addItem("1912");
    jCombo5.addItem("1913");
    jCombo5.addItem("1914");
    jCombo5.addItem("1915");
    jCombo5.addItem("1916");
    jCombo5.addItem("1917");
    jCombo5.addItem("1918");
    jCombo5.addItem("1919");
    jCombo5.addItem("1920");
    jCombo5.addItem("1921");
    jCombo5.addItem("1922");
    jCombo5.addItem("1923");
    jCombo5.addItem("1924");
    jCombo5.addItem("1925");
    jCombo5.addItem("1926");
    jCombo5.addItem("1927");
    jCombo5.addItem("1928");
    jCombo5.addItem("1929");
    jCombo5.addItem("1930");
    jCombo5.addItem("1931");
    jCombo5.addItem("1932");
    jCombo5.addItem("1933");
    jCombo5.addItem("1934");
    jCombo5.addItem("1935");
    jCombo5.addItem("1936");
    jCombo5.addItem("1937");
    jCombo5.addItem("1938");
    jCombo5.addItem("1939");
    jCombo5.addItem("1940");
    jCombo5.addItem("1941");
    jCombo5.addItem("1942");
    jCombo5.addItem("1943");
    jCombo5.addItem("1944");
    jCombo5.addItem("1945");
    jCombo5.addItem("1946");
    jCombo5.addItem("1947");
    jCombo5.addItem("1948");
    jCombo5.addItem("1949");
    jCombo5.addItem("1950");
    jCombo5.addItem("1951");
    jCombo5.addItem("1952");
    jCombo5.addItem("1953");
    jCombo5.addItem("1954");
    jCombo5.addItem("1955");
    jCombo5.addItem("1956");
    jCombo5.addItem("1957");
    jCombo5.addItem("1958");
    jCombo5.addItem("1959");
    jCombo5.addItem("1960");
    jCombo5.addItem("1961");
    jCombo5.addItem("1962");
    jCombo5.addItem("1963");
    jCombo5.addItem("1964");
    jCombo5.addItem("1965");
    jCombo5.addItem("1966");
    jCombo5.addItem("1967");
    jCombo5.addItem("1968");
    jCombo5.addItem("1969");
    jCombo5.addItem("1970");
    jCombo5.addItem("1971");
    jCombo5.addItem("1972");
    jCombo5.addItem("1973");
    jCombo5.addItem("1974");
    jCombo5.addItem("1975");
    jCombo5.addItem("1976");
    jCombo5.addItem("1977");
    jCombo5.addItem("1978");
    jCombo5.addItem("1979");
    jCombo5.addItem("1980");
    jCombo5.addItem("1981");
    jCombo5.addItem("1982");
    jCombo5.addItem("1983");
    jCombo5.addItem("1984");
    jCombo5.addItem("1985");
    jCombo5.addItem("1986");
    jCombo5.addItem("1987");
    jCombo5.addItem("1988");
    jCombo5.addItem("1989");
    jCombo5.addItem("1990");
    jCombo5.addItem("1991");
    jCombo5.addItem("1992");
    jCombo5.addItem("1993");
    jCombo5.addItem("1994");
    jCombo5.addItem("1995");
    jCombo5.addItem("1996");
    jCombo5.addItem("1997");
    jCombo5.addItem("1998");
    jCombo5.addItem("1999");
    jCombo5.addItem("2000");
    jCombo5.addItem("2001");
    jCombo5.addItem("2002");

    jPanel1.setForeground(Color.black);
    contentPane.add(jTabbedPane1, null);
    jTabbedPane1.add(jPanel1, "	User Details	");
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(jTextField2, null);
    jPanel1.add(jLabel7, null);
    jPanel1.add(jTextField3, null);
    jPanel1.add(jLabel8, null);
    jPanel1.add(jTextField4, null);
    jPanel1.add(jLabel9, null);
    jPanel1.add(jLabel10, null);
    jPanel1.add(jLabel11, null);
    jPanel1.add(jTextField5, null);
    jTabbedPane1.add(jPanel2, " Personal Info ");
    jPanel2.add(jLabel12, null);
    jPanel2.add(jLabel13, null);
    jPanel2.add(jLabel14, null);
    jPanel2.add(jTextField6, null);
    jPanel2.add(jLabel15, null);
    jPanel2.add(jTextField7, null);
    jPanel2.add(jLabel16, null);
    jPanel2.add(jTextField8, null);
    jPanel2.add(jLabel17, null);
    jPanel2.add(jTextField9, null);
    jPanel2.add(jLabel18, null);
    jPanel2.add(jLabel19, null);
    jPanel2.add(jLabel20, null);
    jPanel2.add(jCombo1, null);
    jPanel2.add(jLabel21, null);
    jPanel2.add(jTextField10, null);
    jPanel2.add(jLabel22, null);
    jPanel2.add(jLabel23, null);
    jPanel2.add(jLabel24, null);
    jPanel2.add(jCombo3, null);
    jPanel2.add(jLabel25, null);
    jPanel2.add(jCombo4, null);
    jPanel2.add(jLabel26, null);
    jPanel2.add(jCombo5, null);
    contentPane.add(jButton1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

//----------------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }

//----------------------------------------------------------------------------
  public void setUin(String uin) {
    this.uin = uin;
    this.jTextField1.setText(uin);
    this.setTitle("View Details UIN " + uin);
  }

//----------------------------------------------------------------------------
  public void setData(UserData user) {
    if (uin.equals(OwnerDataInfo.getUin())) {
      MyDetailPage my = new MyDetailPage(this.sconnect);
      my.setData(user, OwnerDataInfo.getUin());
      my.show();
    }
    else {
      this.jTextField2.setText(user.getFirstname());
      this.jTextField3.setText(user.getLastname());
      this.jTextField4.setText(user.getNickname());
      this.jTextField5.setText(user.getEmail());
      this.jTextField6.setText(user.getCity());
      this.jTextField7.setText(user.getState());
      this.jTextField8.setText(user.getZipcode());
      this.jTextField9.setText(user.getCountry());
      if (user.getGender().equals("Male")) {
	this.jCombo1.setSelectedIndex(1);
      }
      else if (user.getGender().equals("Female")) {
	this.jCombo1.setSelectedIndex(2);
      }
      else if (user.getGender().equals(" ")) {
	this.jCombo1.setSelectedIndex(0);
      }

      this.jTextField10.setText(Integer.toString(user.getAge()));

      if (Integer.parseInt(user.getDay()) != 0) {
	this.jCombo3.setSelectedIndex(Integer.parseInt(user.getDay()));
      }
      if (Integer.parseInt(user.getMonth()) != 0) {
	this.jCombo4.setSelectedIndex(Integer.parseInt(user.getMonth()));
      }
      if (Integer.parseInt(user.getYear()) != 0) {
	this.jCombo5.setSelectedIndex( (Integer.parseInt(user.getYear()) - 1900) +
				      1);
      }

      this.show();
    }
  }
//----------------------------------------------------------------------------
}