package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MQRegisterSuccess
    extends JFrame {
  private ServerConnect sconn;
  private String uin;
  LogonPage logonPage;
  MainPage mainPage;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel4 = new JLabel();
  JButton jButton1 = new JButton();

  //Construct the frame
  public MQRegisterSuccess(String uin) {
    this.uin = uin;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(RegisterSuccess.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setBounds(new Rectangle(9, 13, 300, 180));
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(320, 215));
    this.setTitle("Register Success");
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Your registration is completed successfully");
    jLabel2.setBounds(new Rectangle(15, 20, 260, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Your IsagQ ID # is");
    jLabel3.setBounds(new Rectangle(49, 55, 107, 20));
    jLabel4.setText("Click \"Finish\" to start IsagQ with your new IsagQ ID #.");
    jLabel4.setBounds(new Rectangle(15, 105, 267, 20));
    jTextField1.setBackground(new Color(192, 255, 255));
    jButton1.setBounds(new Rectangle(115, 140, 80, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Finish");
    jButton1.addActionListener(new ActionListener2(this));
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jTextField1.setText(uin);
    jTextField1.setBounds(new Rectangle(153, 55, 100, 20));
    jTextField1.setEnabled(false);
    jTextField1.setDisabledTextColor(Color.blue);
    jTextField1.setEditable(false);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jButton1, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    String password;
    String uin = jTextField1.getText();
    password = OwnerDataInfo.getStringPassword();
    this.dispose();
    logonPage = new LogonPage();
    logonPage.show();
  }
}

class ActionListener2
    implements java.awt.event.ActionListener {
  MQRegisterSuccess adaptee;

  ActionListener2(MQRegisterSuccess adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}
