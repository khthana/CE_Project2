package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class PeerInit {
  //---------------------------init1-----------------------------
  private byte cmd;
  private short tcpver = 0x0800;
  private short length = 0x2b00;
  private int desuin;
  private short unknown0 = 0x0000;
  private int ourport;
  private int ouruin;
  private int ourremip;
  private int ourintip;
  private byte tcpflags = 0x04;
  private int ourport2;
  private int cookie;
  private int unknown1 = 0x50000000;
  private int unknown2 = 0x03000000;
  private int unknown3 = 0x00000000;
  //---------------------------init2-----------------------------
  private int unknown4 = 0x0a000000;
  private int unknown5 = 0x01000000;
  private int unknown6;
  private int unknown7 = 0x00000000;
  private int unknown8 = 0x00000000;
  private int unknown9;
  private int unknown10 = 0x00000000;
  private int unknown11;
//------------------------------------------------------
  public PeerInit(int desuin, int ourport, int ouruin, int ourremip,
		  int ourintip, int ourport2, int cookie) {
    this.desuin = desuin;
    this.ourport = ourport;
    this.ouruin = ouruin;
    this.ourremip = ourremip;
    this.ourintip = ourintip;
    this.ourport2 = ourport2;
    this.cookie = cookie;
  }

//------------------------------------------------------
  public PeerInit() {

  }

//------------------------------------------------------
  public byte[] setAllbyteinit1() {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    try {
      cmd = (byte) 0xff;
      dataOut.writeByte(cmd);
      dataOut.writeShort(tcpver);
      dataOut.writeShort(length);
      dataOut.writeInt(desuin);
      dataOut.writeShort(unknown0);

      dataOut.writeShort(ourport);
      dataOut.writeShort(0);

      dataOut.writeInt(ouruin);
      dataOut.writeInt(ourremip);
      dataOut.writeInt(ourintip);
      dataOut.writeByte(tcpflags);

      dataOut.writeShort(ourport2);
      dataOut.writeShort(0);

      dataOut.writeInt(cookie);
      dataOut.writeInt(unknown1);
      dataOut.writeInt(unknown2);
      dataOut.writeInt(unknown3);
    }
    catch (IOException u) {
      System.out.println(u.getMessage());
    }
    return byteOut.toByteArray();
  }

//-----------------------------------------------------------------------
  public byte[] setAllbyteInit2(String status) {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    try {
      cmd = (byte) 0x03;
      if (status.equals("outgoing")) {
	unknown6 = 0x00000000;
	unknown9 = 0x00000000;
	unknown11 = 0x01000400;
      }
      else if (status.equals("incomming")) {
	unknown6 = 0x01000000;
	unknown9 = 0x01000400;
	unknown11 = 0x00000000;
      }
      dataOut.writeByte(cmd);
      dataOut.writeInt(unknown4);
      dataOut.writeInt(unknown5);
      dataOut.writeInt(unknown6);
      dataOut.writeInt(unknown7);
      dataOut.writeInt(unknown8);
      dataOut.writeInt(unknown9);
      dataOut.writeInt(unknown10);
      dataOut.writeInt(unknown11);
    }
    catch (IOException u) {
      System.out.println(u.getMessage());
    }
    return byteOut.toByteArray();
  }
//-----------------------------------------------------------------------
}