package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;
import javax.net.ssl.*;
import java.security.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

//server trust certificate password at line 485

public class LogonPage
    extends JFrame {
  private ServerConnect sconnect;
  private boolean statuslogin;
  private FileInputStream fi;
  private FileOutputStream fo;
  private Properties activeuser;
  private Properties isagquser;
  private Properties usernotinlist;
  public boolean useICQ=true;
  public boolean useIsagQ=true;
  MessageBox messageBox;
  RequestFilePage reqsendfile;
  LogonFail logonFail;
  MainPage mainPage;
  AddAnother addAnother;
  RegisterPage registerPage;
  MQRegister mqRegister;
  MQDeleteUser mqDeleteUser;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JPasswordField jPasswordF1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JComboBox jComboBox1 = new JComboBox();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JCheckBox jCheckBox1 = new JCheckBox();
  JPasswordField jPasswordField1 = new JPasswordField();
  JComboBox jComboBox2 = new JComboBox();
  JCheckBox jCheckBox2 = new JCheckBox();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JButton jButton6 = new JButton();
  SSLContext ctx;
  MQServerConnect mqsocket;

  //Construct the frame
  public LogonPage() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    //dh = new DiffieHellman();
    this.usernotinlist = new Properties();
    this.sconnect = new ServerConnect();
    try {
      jbInit();
      this.setComboBoxNickname();
      this.setComboBox2Nickname();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(LogonPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(524, 303));
    this.setTitle("Login to server");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("ICQ User :");
    jLabel1.setBounds(new Rectangle(45, 70, 65, 20));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Password :");
    jLabel2.setBounds(new Rectangle(45, 97, 65, 20));
    jPasswordF1.setText("");
    jPasswordF1.setBounds(new Rectangle(115, 97, 120, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Please enter user's password.");
    jLabel3.setBounds(new Rectangle(5, 5, 180, 20));
    //-------------------- may be omit-----------------------------
    // jComboBox1.addItem("Nol");
    // jComboBox1.addItem("Nut");
    // jComboBox1.addItem("Pee");
    // jComboBox1.addItem("Poon");
    // jComboBox1.setSelectedIndex(0);
    //-------------------------------------------------------------
    jButton1.setBounds(new Rectangle(169, 221, 71, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(255, 221, 83, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(169, 195, 169, 18));
    jButton3.setText("Add Another User");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton3_actionPerformed(e);
      }
    });
    jButton4.setBounds(new Rectangle(50, 132, 169, 18));
    jButton4.setText("Register A New ICQ User");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton4_actionPerformed(e);
      }
    });
    jComboBox1.setEnabled(true);
    jComboBox1.setBounds(new Rectangle(115, 70, 120, 20));
    contentPane.setDebugGraphicsOptions(0);
    jButton5.setBounds(new Rectangle(289, 132, 169, 18));
    jButton5.setText("Register A New IsagQ User");
    jButton5.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e){
        jButton5_actionPerformed(e);
      }
    });
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("IsagQ User :");
    jLabel4.setBounds(new Rectangle(274, 74, 76, 15));
    jLabel5.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel5.setText("Password :");
    jLabel5.setBounds(new Rectangle(273, 100, 70, 15));
    jCheckBox1.setFont(new java.awt.Font("Dialog", 1, 12));
    jCheckBox1.setText("ICQ");
    jCheckBox1.setBounds(new Rectangle(43, 41, 57, 23));
    jCheckBox1.setSelected(true);
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(357, 97, 118, 21));
    jComboBox2.setBounds(new Rectangle(357, 71, 119, 21));
    jCheckBox2.setFont(new java.awt.Font("Dialog", 1, 12));
    jCheckBox2.setText("IsagQ");
    jCheckBox2.setBounds(new Rectangle(272, 40, 71, 23));
    jCheckBox2.setSelected(true);
    jLabel6.setBorder(BorderFactory.createEtchedBorder());
    jLabel6.setText("");
    jLabel6.setBounds(new Rectangle(34, 35, 210, 148));
    jLabel7.setBorder(BorderFactory.createEtchedBorder());
    jLabel7.setText("");
    jLabel7.setBounds(new Rectangle(266, 34, 220, 150));
    jButton6.setBounds(new Rectangle(289, 155, 169, 18));
    jButton6.setText("Delete IsagQ ID");
    jButton6.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e){
        jButton6_actionPerformed(e);
      }
    });
    contentPane.add(jLabel3, null);
    contentPane.add(jPasswordF1, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jComboBox2, null);
    contentPane.add(jCheckBox1, null);
    contentPane.add(jCheckBox2, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    jCheckBox1.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e) {
        jCheckBox1_actionPerformed(e);
      }
    });
    jCheckBox2.addActionListener(new java.awt.event.ActionListener(){
      public void actionPerformed(ActionEvent e) {
        jCheckBox2_actionPerformed(e);
      }
    });
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

//----------------------------------------------------------
  public Properties getUserNotInGroupList() {
    return this.usernotinlist;
  }

//-----------------------------------------------------------------------------
  void jCheckBox1_actionPerformed(ActionEvent e){
    if(jCheckBox1.isSelected()==true){
      useICQ=true;
      jComboBox1.setEnabled(true);
      jPasswordF1.setEnabled(true);
      jButton4.setEnabled(true);
    }else{
      useICQ=false;
      jComboBox1.setEnabled(false);
      jPasswordF1.setEnabled(false);
      jButton4.setEnabled(false);
    }
  }

  //-----------------------------------------------------------------------------
  void jCheckBox2_actionPerformed(ActionEvent e){
    if(jCheckBox2.isSelected()==true){
      useIsagQ=true;
      jComboBox2.setEnabled(true);
      jPasswordField1.setEnabled(true);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
   }else{
     useIsagQ=false;
     jComboBox2.setEnabled(false);
     jPasswordField1.setEnabled(false);
     jButton5.setEnabled(false);
     jButton5.setEnabled(false);
   }
  }

//---------------------------------------------------------
  public void setServerConnect(ServerConnect sconnect) {
    this.sconnect = sconnect;
  }

//---------------------------------------------------------
  public ServerConnect getServerConnect() {
    return this.sconnect;
  }

//---------------------------------------------------------
  public void setComboBoxNickname() {
    try {
      this.fi = new FileInputStream("./activeuser/activeuser");
      this.activeuser = new Properties();
      this.activeuser.load(fi);
      fi.close();
      if (!this.activeuser.isEmpty()) {
	Enumeration e = this.activeuser.propertyNames();
	while (e.hasMoreElements()) {
	  this.jComboBox1.addItem(e.nextElement());
	}
	this.jComboBox1.setSelectedIndex(0);
      }
    }
    catch (IOException e) {}
  }

//---------------------------------------------------------
  public void setComboBox2Nickname(){
    try{
      this.fi=new FileInputStream("./activeuser/isagquser");
      this.isagquser=new Properties();
      this.isagquser.load(fi);
      fi.close();
      if(!this.isagquser.isEmpty()){
        Enumeration isag=this.isagquser.propertyNames();
        while(isag.hasMoreElements()){
          this.jComboBox2.addItem(isag.nextElement());
        }
        this.jComboBox2.setSelectedIndex(0);
      }
    }
    catch(IOException e){}
  }

//---------------------------------------------------------
  public void outPropertiesTofile(Properties a, String filename) {
    try {
      this.fo = new FileOutputStream(filename);
      a.store(this.fo, filename);
      this.fo.close();
    }
    catch (IOException rt) {}
  }

//---------------------------------------------------------
  public void getOwnInfo(SearchInfo sinfo) {
    try {
      this.fi = new FileInputStream("./activeuser/activeuserdetail");
      Properties activeuserdetail = new Properties();
      activeuserdetail.load(fi);
      fi.close();

      OwnerDataInfo.setAge(sinfo.getAge());
      OwnerDataInfo.setFirstname(sinfo.getFirstname());
      OwnerDataInfo.setAuthorize(sinfo.getAuthorize());
      OwnerDataInfo.setEmail(sinfo.getEmail());
      OwnerDataInfo.setGender(sinfo.getGender());
      OwnerDataInfo.setLastname(sinfo.getLastname());
      OwnerDataInfo.setNickname(sinfo.getNickname());
      OwnerDataInfo.setStatus(sinfo.getStatus());
      OwnerDataInfo.setUin(Integer.toString(sinfo.getUin()));
      activeuser.put(OwnerDataInfo.getNickname(), OwnerDataInfo.getUin());
      this.outPropertiesTofile(this.activeuser, "./activeuser/activeuser");
      String passwd = new String(OwnerDataInfo.getencryptPassword());
      activeuserdetail.put(OwnerDataInfo.getUin(), passwd);
      this.outPropertiesTofile(activeuserdetail,"./activeuser/activeuserdetail");
    }
    catch (Exception e) {}
  }

//-----------------------------------------------------------------------------
  public void collectuserdata() throws IOException {
    int i = 0, len;
    UserData user;
    byte[] data;
    short lastseq;
    len = OwnerDataInfo.getMyContactlist().size();
    for (i = 0; i < len; i++) {
      user = (UserData) OwnerDataInfo.getMyContactlist().elementAt(i);
      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setSearchByUin(user.getUin());
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.searchbyuin, lastseq, data));
      try {
	//			Thread.sleep(2000) ;
	if (i % 3 == 0 && i != 0) {
	  Thread.sleep(2000);
	}
      }
      catch (Exception t) {}
    }
  }

//---------------------------------------------------------
  public void login(String uin, String password,String mqIP,int mqport,SSLContext qctx,String myname) {
    try {

      this.dispose();
      ServerConnect bosServerconnc;
      //System.out.println(password);
      this.setStatusLogin(false);
      //----------------------------------------------------------------------------------------------

      //		sconnect = new ServerConnect(5190,"login.icq.com","221210738","123","icqserver",this) ;
      //		sconnect = new ServerConnect(5190,"login.icq.com","17278025","2gpwcBG6","icqserver",this) ;
      this.sconnect = new ServerConnect(5190, "login.icq.com", uin, password,
                                        "icqserver", this);

      this.sconnect.Login(this.sconnect.getServername(),
                          this.sconnect.getPort());
      if (sconnect.getStatus() == false) {
        String ip = sconnect.getServerBosIP();
        bosServerconnc = new ServerConnect(5190, ip, "icqserver", this);
        bosServerconnc.setServer2connect("bosserver");
        bosServerconnc.Login(bosServerconnc.getServername(),
                             bosServerconnc.getPort());
        this.sconnect = bosServerconnc;
        this.setVisible(false);
        mqsocket=new MQServerConnect(mqIP,mqport,qctx,this);
        mainPage = new MainPage(this.sconnect,mqsocket,myname);

        //-------------------------------------
        while (this.statuslogin == false) {}
        //Thread.sleep(5000);
      }
      mainPage.show();
      mainPage.startisagqServer();
    }
    catch (Exception ex) {}
  }

  public void login(String mqIP,int mqport,SSLContext qctx,String myname) {
    try {
      mqsocket=new MQServerConnect(mqIP,mqport,qctx,this);
      mainPage = new MainPage(mqsocket,myname);
      mainPage.show();
      mainPage.startisagqServer();
    }
    catch (Exception ex) {}
  }


  public void login(String uin, String password) {
    try {
      this.dispose();
      ServerConnect bosServerconnc;
      //System.out.println(password);
      this.setStatusLogin(false);
      //----------------------------------------------------------------------------------------------

      //    sconnect = new ServerConnect(5190,"login.icq.com","221210738","123","icqserver",this) ;
      //    sconnect = new ServerConnect(5190,"login.icq.com","17278025","2gpwcBG6","icqserver",this) ;
      this.sconnect = new ServerConnect(5190, "login.icq.com", uin, password,
                                        "icqserver", this);

      this.sconnect.Login(this.sconnect.getServername(), this.sconnect.getPort());
      if (sconnect.getStatus() == false) {
        String ip = sconnect.getServerBosIP();
        bosServerconnc = new ServerConnect(5190, ip, "icqserver", this);
        bosServerconnc.setServer2connect("bosserver");
        bosServerconnc.Login(bosServerconnc.getServername(),
                             bosServerconnc.getPort());
        this.sconnect = bosServerconnc;
        this.setVisible(false);
        mainPage = new MainPage(this.sconnect);
        //-------------------------------------
        while (this.statuslogin == false) {}
        mainPage.show();
      }
    }
    catch (Exception ex) {}
  }


//---------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    String nickname2="";
    String isagQid;
    String serverIP="";
    String filecert="";
    int isagport;
    String filename=""; //user's key file
    int port=0;
    String nickname;
    String password="";
    char[] pass;
    String uin = "";

    if(useIsagQ){
      nickname2=jComboBox2.getSelectedItem().toString();
      char[] pwd1=jPasswordField1.getPassword();
      try{
        if(!activeuser.isEmpty()){
          filename=(String)isagquser.get(nickname2);
        }
        this.fi = new FileInputStream("./activeuser/isagserver");
        this.isagquser = new Properties();
        this.isagquser.load(fi);
        fi.close();
        serverIP=(String)isagquser.get(nickname2);
        this.fi = new FileInputStream("./activeuser/isagport");
        this.isagquser = new Properties();
        this.isagquser.load(fi);
        fi.close();
        port=Integer.parseInt((String)isagquser.get(nickname2));

        ctx = SSLContext.getInstance("SSLv3");
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new FileInputStream(filename),pwd1);
        //ks.load(null,pwd1);
        //java.security.cert.Certificate clicert=Certificate.importCertificate(new File(filename));
        //ks.setCertificateEntry("clientkey",clicert);
        kmf.init(ks,"654321".toCharArray());

        TrustManagerFactory tmf=TrustManagerFactory.getInstance("SunX509");
        KeyStore ts = KeyStore.getInstance(KeyStore.getDefaultType());
        char[] pswd="654321".toCharArray(); //server trust certificate password
        //ts.load(new FileInputStream("./cert/ca.pem"),pswd);
        ts.load(null,null);
        java.security.cert.Certificate servercert=Certificate.importCertificate(new File("./cert/ca.pem"));
        ts.setCertificateEntry("mqtrust",servercert);
        tmf.init(ts);


        ctx.init(kmf.getKeyManagers(),tmf.getTrustManagers(),null);

      }catch(Exception exc){
        JOptionPane.showMessageDialog(null,exc.toString(),"Error warning",JOptionPane.ERROR_MESSAGE);
      }
    }
    if(useICQ){
      nickname = jComboBox1.getSelectedItem().toString();
      //System.out.println(nickname);
      pass = this.jPasswordF1.getPassword();
      password = new String(pass);
      //------------------- change nickname to uin ------------------------------
      try {

        if (!activeuser.isEmpty()) {
          uin = (String) activeuser.get(nickname);
        }
      }
      catch (Exception exc) {}
      //-------------------------------------------------------------------------
    }

    if(useIsagQ&&useICQ){
      dispose();
      this.login(uin, password,serverIP,port,ctx,nickname2);
    }else if(useICQ){
      dispose();
      this.login(uin,password);
    }else if(useIsagQ){
      dispose();
      this.login(serverIP,port,ctx,nickname2);
    }
    else if((!useIsagQ)&&(!useICQ)){
      JOptionPane.showMessageDialog(null,"Please select ICQ or IsagQ that you want to use","Please select one or two",JOptionPane.ERROR_MESSAGE);
    }
  }

//--------------------------------------------------------
  public void setStatusLogin(boolean status) {
    this.statuslogin = status;
  }

//--------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    jPasswordF1.setText("");
    jPasswordField1.setText("");
  }

//------------------------- add anathor user -----------------------------------
  void jButton3_actionPerformed(ActionEvent e) {
    addAnother = new AddAnother();
    addAnother.show();
    dispose();
  }

//------------------------------------------------------------------------------
  void jButton4_actionPerformed(ActionEvent e) {
    registerPage = new RegisterPage();
    registerPage.show();
    dispose();
  }
//------------------------------------------------------------------------------
  void jButton5_actionPerformed(ActionEvent e) {
    mqRegister = new MQRegister();
    mqRegister.show();
    dispose();
  }
//------------------------------------------------------------------------------
  void jButton6_actionPerformed(ActionEvent e){
    mqDeleteUser = new MQDeleteUser();
    mqDeleteUser.show();
    dispose();
  }
}