package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.net.*;
import java.util.*;

public class QServerThread extends Thread {
  MainPage mainPage;
  public QServerThread(MainPage m) {
    this.mainPage=m;
  }
  public void run(){
    if(this.mainPage.mqcon.isconnect()){
      try {
        ServerSocket server = new ServerSocket(17000);
        QMessageThread[] qMessageThread=new QMessageThread[30];
        for(int j=0;j<30;j++){
          while (true) {
            if (this.mainPage.mqcon.isconnect()) {
              Socket connection;
              connection = server.accept();
              String con_ip = connection.getInetAddress().toString();
              int size = this.mainPage.mqcontact_list_on.size();
              int i = 0;
              boolean check = false;
              while (!check && (i < size)) {
                check = con_ip.equals( (String) ( (Vector) this.mainPage.mqcontact_list_on.
                                                 get(
                    i)).get(2));
                i++;
              }
              if (check) {
                qMessageThread[j] = new QMessageThread(connection,
                                                (Vector)
                                                this.mainPage.mqcontact_list_on.get(i - 1),
                                                this.mainPage.myname, true);
                qMessageThread[j].start();
              }
              else {
                this.mainPage.setList2();
                size = this.mainPage.mqcontact_list_on.size();
                i = 0;
                while (!check && (i < size)) {
                  check = con_ip.equals( (String) ( (Vector) this.mainPage.mqcontact_list_on.
                      get(
                      i)).get(2));
                  i++;
                }
                if (check) {
                  qMessageThread[j] = new QMessageThread(connection,
                                                  (Vector) this.mainPage.mqcontact_list_on.
                                                  get(
                      i - 1), this.mainPage.myname, true);
                  qMessageThread[j].start();
                }
                else {
                  connection.close();
                }
              }
            }
          }
        }
      }
      catch (Exception ex) {
      }
    }

  }

}