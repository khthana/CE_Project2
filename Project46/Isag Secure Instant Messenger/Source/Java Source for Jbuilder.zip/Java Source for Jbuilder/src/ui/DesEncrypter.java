package ui;

import javax.crypto.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.net.*;

public class DesEncrypter {
  private MessageBox msgbox;
  private Cipher ecipher;
  private Cipher dcipher;
  private Socket socket;
//------------------------------------------------------------
  public DesEncrypter(Socket sock) {
    this.socket = sock;
  }

//-----------------------------------------------------------
  public DesEncrypter() {
  }

//-----------------------------------------------------------
  public void setSecretKey(SecretKey key, String type) {
    // Create an 8-byte initialization vector
    byte[] iv = new byte[] {
	(byte) 0x8E, 0x12, 0x39, (byte) 0x9C,
	0x07, 0x72, 0x6F, 0x5A
    };
    AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv);
    try {
      if (type.equals("File")) { //---------------File----------------
	ecipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
	dcipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
	// CBC requires an initialization vector
	ecipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
	dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);

      }
      else { //--------------String -------------------
	ecipher = Cipher.getInstance("DES");
	dcipher = Cipher.getInstance("DES");
	ecipher.init(Cipher.ENCRYPT_MODE, key);
	dcipher.init(Cipher.DECRYPT_MODE, key);
      }

    }
    catch (java.security.InvalidAlgorithmParameterException e) {
      System.out.println(e.getMessage());
    }
    catch (javax.crypto.NoSuchPaddingException e) {
      System.out.println(e.getMessage());
    }
    catch (java.security.NoSuchAlgorithmException e) {
      System.out.println(e.getMessage());
    }
    catch (java.security.InvalidKeyException e) {
      System.out.println(e.getMessage());
    }
  }

//-----------------------------------------------------------------------
  // Buffer used to transport the bytes from one stream to another
  byte[] buf = new byte[1024];
  public void encrypt(InputStream in, OutputStream out) {
    try {
      // Bytes written to out will be encrypted
      out = new CipherOutputStream(out, ecipher);

      // Read in the cleartext bytes and write to out to encrypt
      int numRead = 0;
      while ( (numRead = in.read(buf)) >= 0) {
	System.out.println(numRead);
	out.write(buf, 0, numRead);
      }
      out.close();

      String title = "Send File";
      String msg = "Send File Complete.";
      this.msgbox = new MessageBox(title, msg);
      this.msgbox.show();
      //this.socket.close() ;
    }
    catch (java.io.IOException e) {
      System.out.println(e.getMessage());
    }
  }

//--------------------------------------------------------------------------
  public void decrypt(InputStream in, OutputStream out) {
    try {
      // Bytes read from in will be decrypted
      in = new CipherInputStream(in, dcipher);

      // Read in the decrypted bytes and write the cleartext to out
      int numRead = 0;
      while ( (numRead = in.read(buf)) >= 0) {
	out.write(buf, 0, numRead);
      }
      out.close();
      String title = "Receive File";
      String msg = "Receive File Complete.";
      this.msgbox = new MessageBox(title, msg);
      this.msgbox.show();
    }
    catch (java.io.IOException e) {
    }
  }

//------------------------------------------------------------------------------
  public String encryptStr(String str) {
    try {
      // Encode the string into bytes using utf-8
      byte[] utf8 = str.getBytes("UTF8");

      // Encrypt
      byte[] enc = ecipher.doFinal(utf8);

      // Encode bytes to base64 to get a string
      return new sun.misc.BASE64Encoder().encode(enc);
    }
    catch (javax.crypto.BadPaddingException e) {
    }
    catch (IllegalBlockSizeException e) {
    }
    catch (UnsupportedEncodingException e) {
    }
    catch (java.io.IOException e) {
    }
    return null;
  }

//------------------------------------------------------------------------------
  public String decryptStr(String str) {
    try {
      // Decode base64 to get bytes
      byte[] dec = new sun.misc.BASE64Decoder().decodeBuffer(str);

      // Decrypt
      byte[] utf8 = dcipher.doFinal(dec);

      // Decode using utf-8
      return new String(utf8, "UTF8");
    }
    catch (javax.crypto.BadPaddingException e) {
    }
    catch (IllegalBlockSizeException e) {
    }
    catch (UnsupportedEncodingException e) {
    }
    catch (java.io.IOException e) {
    }
    return null;
  }
//------------------------------------------------------------------------------
}