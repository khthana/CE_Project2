package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.math.*;
import java.io.*;

public class TestThread
    extends Thread {
  private DataInputStream in;
  private RSA rsa;
  private OwnerDataInfo own;
  public TestThread(DataInputStream in, OwnerDataInfo own) {
    this.in = in;
    rsa = new RSA();
    this.own = own;
  }

//-------------------------------------------------
  public void run() {
    int c;
    byte[] temp;
    byte[] data;
    String uin;
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    while (true) {
      try {
	while ( (c = in.read()) != -1) {
	  dataOut.writeByte(c);
	}
	data = byteOut.toByteArray();
	temp = Util.copyBytes(data, 0, 2);
	if (Util.bytes2Short(temp) == -21845) {
	  int sizecontact, uinlen, keylen;
	  uinlen = (int) data[2];
	  temp = Util.copyBytes(data, 3, uinlen);
	  uin = Util.bytes2Str(temp);
	  // sizecontact = this.sconnect.ownerdata.getMyContactlist().size() ;
	  UserData user = new UserData();
	  //	for(c = 0 ; c < sizecontact ; c++){
	  //user = (UserData) this.sconnect.ownerdata.getMyContactlist().elementAt(c) ;
	  user.setUin("166825010");
	  if (user.getUin().equals(uin)) {
	    //---------------------------------------------
	    //	temp = Util.copyBytes(data,3+uinlen,2) ;
	    //	keylen = Util.bytes2Short(temp) ;
	    //	temp = Util.copyBytes(data,5+uinlen,keylen) ;
	    //	BigInteger keydesbyte = new BigInteger(temp) ;
	    //	BigInteger keydes = rsa.Decrypt(own.getKey_D(),own.getKey_N(),keydesbyte) ;
	    //	user.setDes(keydes.toByteArray()) ;
	  }
	  // }
	  // }
	}
      }
      catch (Exception e) {
	System.out.println(e.getMessage());
      }
    }
  }
//------------------------------------------------
}