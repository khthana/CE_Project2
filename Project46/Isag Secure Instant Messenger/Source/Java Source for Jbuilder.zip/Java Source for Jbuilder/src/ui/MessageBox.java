package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MessageBox
    extends JFrame {
  private String title;
  private String result;
  JPanel contentPane;
  JButton jButton1 = new JButton();
  JLabel jLabel1 = new JLabel();

  //Construct the frame
  public MessageBox(String title, String result) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      this.title = title;
      this.result = result;
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(RegisterFail.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(278, 95));
    this.setTitle(title);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));

    jLabel1.setText(result);
    jLabel1.setBounds(new Rectangle(5, 5, 283, 25));

    jButton1.setBounds(new Rectangle(104, 35, 70, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }
}