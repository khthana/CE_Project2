package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MyDetailPage
    extends JFrame {
  private String uin;
  private ServerConnect sconnect;
  JPanel contentPane;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JTextField jTextField5 = new JTextField();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JTextField jTextField6 = new JTextField();
  JLabel jLabel15 = new JLabel();
  JTextField jTextField7 = new JTextField();
  JLabel jLabel16 = new JLabel();
  JTextField jTextField8 = new JTextField();
  JLabel jLabel17 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JComboBox jComboBox2 = new JComboBox();
  JLabel jLabel21 = new JLabel();
  JTextField jTextField9 = new JTextField();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel23 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JComboBox jComboBox3 = new JComboBox();
  JLabel jLabel25 = new JLabel();
  JComboBox jComboBox4 = new JComboBox();
  JLabel jLabel26 = new JLabel();
  JComboBox jComboBox5 = new JComboBox();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();

  //Construct the frame
  public MyDetailPage(ServerConnect sconnect) {
    this.sconnect = sconnect;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MyDetailPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(390, 385));
    jTabbedPane1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setBounds(new Rectangle(10, 10, 360, 305));
    jPanel1.setLayout(null);
    jPanel2.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("User Identification Number");
    jLabel1.setBounds(new Rectangle(10, 10, 160, 20));
    jLabel2.setBorder(BorderFactory.createEtchedBorder());
    jLabel2.setBounds(new Rectangle(10, 35, 335, 35));
    jLabel3.setText("UIN # :");
    jLabel3.setBounds(new Rectangle(100, 43, 45, 20));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("Names");
    jLabel4.setBounds(new Rectangle(10, 80, 147, 20));
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(10, 105, 335, 85));
    jLabel6.setText("First Name :");
    jLabel6.setBounds(new Rectangle(65, 113, 70, 20));
    jLabel7.setText("Last Name :");
    jLabel7.setBounds(new Rectangle(65, 138, 70, 20));
    jLabel8.setText("Nickname	:");
    jLabel8.setBounds(new Rectangle(65, 163, 70, 20));
    jTextField1.setBackground(new Color(212, 208, 200));
    jTextField1.setBounds(new Rectangle(155, 43, 100, 20));
    jLabel9.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel9.setText("E-mail Address");
    jLabel9.setBounds(new Rectangle(10, 200, 100, 20));
    jLabel10.setBorder(BorderFactory.createEtchedBorder());
    jLabel10.setBounds(new Rectangle(10, 225, 335, 35));
    jLabel11.setText("E-mail				:");
    jLabel11.setBounds(new Rectangle(65, 233, 70, 20));
    jLabel12.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel12.setText("Address");
    jLabel12.setBounds(new Rectangle(10, 10, 65, 20));
    jLabel13.setBorder(BorderFactory.createEtchedBorder());
    jLabel13.setBounds(new Rectangle(10, 35, 335, 65));
    jLabel14.setText("City		 :");
    jLabel14.setBounds(new Rectangle(20, 45, 40, 20));
    jLabel15.setText("State	:");
    jLabel15.setBounds(new Rectangle(20, 70, 40, 20));
    jLabel16.setText("Zip Code :");
    jLabel16.setBounds(new Rectangle(175, 45, 60, 20));
    jLabel17.setText("Country		:");
    jLabel17.setBounds(new Rectangle(175, 70, 60, 20));
    jComboBox1.addItem("");
    jComboBox1.addItem("Thailand");
    jLabel18.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel18.setText("Additional Details");
    jLabel18.setBounds(new Rectangle(10, 110, 100, 20));
    jLabel19.setBorder(BorderFactory.createEtchedBorder());
    jLabel19.setBounds(new Rectangle(10, 135, 335, 40));
    jLabel20.setText("Gender	 :");
    jLabel20.setBounds(new Rectangle(42, 145, 61, 20));
    jLabel21.setText("Age	 :");
    jLabel21.setBounds(new Rectangle(205, 145, 40, 20));
    jLabel22.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel22.setText("Birthdate");
    jLabel22.setBounds(new Rectangle(10, 185, 100, 20));
    jLabel23.setBorder(BorderFactory.createEtchedBorder());
    jLabel23.setBounds(new Rectangle(10, 210, 335, 40));
    jLabel24.setText("Day	:");
    jLabel24.setBounds(new Rectangle(20, 220, 35, 20));
    jLabel25.setText("Month	:");
    jLabel25.setBounds(new Rectangle(105, 220, 45, 20));
    jLabel26.setText("Year	:");
    jLabel26.setBounds(new Rectangle(245, 220, 40, 20));

    jComboBox2.addItem("Not Specified");
    jComboBox2.addItem("Male");
    jComboBox2.addItem("Female");

    jComboBox3.addItem("");
    jComboBox3.addItem("01");
    jComboBox3.addItem("02");
    jComboBox3.addItem("03");
    jComboBox3.addItem("04");
    jComboBox3.addItem("05");
    jComboBox3.addItem("06");
    jComboBox3.addItem("07");
    jComboBox3.addItem("08");
    jComboBox3.addItem("09");
    jComboBox3.addItem("10");
    jComboBox3.addItem("11");
    jComboBox3.addItem("12");
    jComboBox3.addItem("13");
    jComboBox3.addItem("14");
    jComboBox3.addItem("15");
    jComboBox3.addItem("16");
    jComboBox3.addItem("17");
    jComboBox3.addItem("18");
    jComboBox3.addItem("19");
    jComboBox3.addItem("20");
    jComboBox3.addItem("21");
    jComboBox3.addItem("22");
    jComboBox3.addItem("23");
    jComboBox3.addItem("24");
    jComboBox3.addItem("25");
    jComboBox3.addItem("26");
    jComboBox3.addItem("27");
    jComboBox3.addItem("28");
    jComboBox3.addItem("29");
    jComboBox3.addItem("30");
    jComboBox3.addItem("31");

    jComboBox4.addItem("");
    jComboBox4.addItem("January");
    jComboBox4.addItem("February");
    jComboBox4.addItem("March");
    jComboBox4.addItem("April");
    jComboBox4.addItem("May");
    jComboBox4.addItem("June");
    jComboBox4.addItem("July");
    jComboBox4.addItem("August");
    jComboBox4.addItem("September");
    jComboBox4.addItem("October");
    jComboBox4.addItem("November");
    jComboBox4.addItem("December");

    jComboBox5.addItem("");
    jComboBox5.addItem("1900");
    jComboBox5.addItem("1901");
    jComboBox5.addItem("1902");
    jComboBox5.addItem("1903");
    jComboBox5.addItem("1904");
    jComboBox5.addItem("1905");
    jComboBox5.addItem("1906");
    jComboBox5.addItem("1907");
    jComboBox5.addItem("1908");
    jComboBox5.addItem("1909");
    jComboBox5.addItem("1910");
    jComboBox5.addItem("1911");
    jComboBox5.addItem("1912");
    jComboBox5.addItem("1913");
    jComboBox5.addItem("1914");
    jComboBox5.addItem("1915");
    jComboBox5.addItem("1916");
    jComboBox5.addItem("1917");
    jComboBox5.addItem("1918");
    jComboBox5.addItem("1919");
    jComboBox5.addItem("1920");
    jComboBox5.addItem("1921");
    jComboBox5.addItem("1922");
    jComboBox5.addItem("1923");
    jComboBox5.addItem("1924");
    jComboBox5.addItem("1925");
    jComboBox5.addItem("1926");
    jComboBox5.addItem("1927");
    jComboBox5.addItem("1928");
    jComboBox5.addItem("1929");
    jComboBox5.addItem("1930");
    jComboBox5.addItem("1931");
    jComboBox5.addItem("1932");
    jComboBox5.addItem("1933");
    jComboBox5.addItem("1934");
    jComboBox5.addItem("1935");
    jComboBox5.addItem("1936");
    jComboBox5.addItem("1937");
    jComboBox5.addItem("1938");
    jComboBox5.addItem("1939");
    jComboBox5.addItem("1940");
    jComboBox5.addItem("1941");
    jComboBox5.addItem("1942");
    jComboBox5.addItem("1943");
    jComboBox5.addItem("1944");
    jComboBox5.addItem("1945");
    jComboBox5.addItem("1946");
    jComboBox5.addItem("1947");
    jComboBox5.addItem("1948");
    jComboBox5.addItem("1949");
    jComboBox5.addItem("1950");
    jComboBox5.addItem("1951");
    jComboBox5.addItem("1952");
    jComboBox5.addItem("1953");
    jComboBox5.addItem("1954");
    jComboBox5.addItem("1955");
    jComboBox5.addItem("1956");
    jComboBox5.addItem("1957");
    jComboBox5.addItem("1958");
    jComboBox5.addItem("1959");
    jComboBox5.addItem("1960");
    jComboBox5.addItem("1961");
    jComboBox5.addItem("1962");
    jComboBox5.addItem("1963");
    jComboBox5.addItem("1964");
    jComboBox5.addItem("1965");
    jComboBox5.addItem("1966");
    jComboBox5.addItem("1967");
    jComboBox5.addItem("1968");
    jComboBox5.addItem("1969");
    jComboBox5.addItem("1970");
    jComboBox5.addItem("1971");
    jComboBox5.addItem("1972");
    jComboBox5.addItem("1973");
    jComboBox5.addItem("1974");
    jComboBox5.addItem("1975");
    jComboBox5.addItem("1976");
    jComboBox5.addItem("1977");
    jComboBox5.addItem("1978");
    jComboBox5.addItem("1979");
    jComboBox5.addItem("1980");
    jComboBox5.addItem("1981");
    jComboBox5.addItem("1982");
    jComboBox5.addItem("1983");
    jComboBox5.addItem("1984");
    jComboBox5.addItem("1985");
    jComboBox5.addItem("1986");
    jComboBox5.addItem("1987");
    jComboBox5.addItem("1988");
    jComboBox5.addItem("1989");
    jComboBox5.addItem("1990");
    jComboBox5.addItem("1991");
    jComboBox5.addItem("1992");
    jComboBox5.addItem("1993");
    jComboBox5.addItem("1994");
    jComboBox5.addItem("1995");
    jComboBox5.addItem("1996");
    jComboBox5.addItem("1997");
    jComboBox5.addItem("1998");
    jComboBox5.addItem("1999");
    jComboBox5.addItem("2000");
    jComboBox5.addItem("2001");
    jComboBox5.addItem("2002");

    jButton1.setBounds(new Rectangle(65, 325, 80, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(155, 325, 75, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(240, 325, 75, 25));
    jButton3.setText("Apply");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton3_actionPerformed(e);
      }
    });
    jComboBox2.setEditable(true);
    jComboBox2.setBounds(new Rectangle(102, 145, 88, 20));
    jComboBox3.setEditable(true);
    jComboBox3.setBounds(new Rectangle(55, 220, 40, 20));
    jComboBox4.setEditable(true);
    jComboBox4.setBounds(new Rectangle(150, 220, 85, 20));
    jComboBox5.setEditable(true);
    jComboBox5.setBounds(new Rectangle(285, 220, 50, 20));
    jComboBox1.setEditable(true);
    jComboBox1.setBounds(new Rectangle(235, 70, 100, 20));
    jTextField5.setBounds(new Rectangle(140, 233, 140, 20));
    jTextField4.setBounds(new Rectangle(140, 163, 140, 20));
    jTextField3.setBounds(new Rectangle(140, 138, 140, 20));
    jTextField2.setBounds(new Rectangle(140, 113, 140, 20));
    jTextField9.setBounds(new Rectangle(245, 145, 40, 20));
    jTextField7.setBounds(new Rectangle(60, 70, 100, 20));
    jTextField8.setBounds(new Rectangle(235, 45, 100, 20));
    jTextField6.setBounds(new Rectangle(60, 45, 100, 20));
    contentPane.add(jTabbedPane1, null);
    jTabbedPane1.add(jPanel1, "	User Details	");
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(jTextField2, null);
    jPanel1.add(jLabel7, null);
    jPanel1.add(jTextField3, null);
    jPanel1.add(jLabel8, null);
    jPanel1.add(jTextField4, null);
    jPanel1.add(jLabel9, null);
    jPanel1.add(jLabel10, null);
    jPanel1.add(jLabel11, null);
    jPanel1.add(jTextField5, null);
    jTabbedPane1.add(jPanel2, " Personal Info ");
    jPanel2.add(jLabel12, null);
    jPanel2.add(jLabel13, null);
    jPanel2.add(jLabel14, null);
    jPanel2.add(jTextField6, null);
    jPanel2.add(jLabel15, null);
    jPanel2.add(jTextField7, null);
    jPanel2.add(jLabel16, null);
    jPanel2.add(jTextField8, null);
    jPanel2.add(jLabel17, null);
    jPanel2.add(jComboBox1, null);
    jPanel2.add(jLabel18, null);
    jPanel2.add(jLabel19, null);
    jPanel2.add(jLabel20, null);
    jPanel2.add(jComboBox2, null);
    jPanel2.add(jLabel21, null);
    jPanel2.add(jTextField9, null);
    jPanel2.add(jLabel22, null);
    jPanel2.add(jLabel23, null);
    jPanel2.add(jLabel24, null);
    jPanel2.add(jComboBox3, null);
    jPanel2.add(jLabel25, null);
    jPanel2.add(jComboBox4, null);
    jPanel2.add(jLabel26, null);
    jPanel2.add(jComboBox5, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

//----------------------------------------------------------------------------
  public void setData(UserData user, String uin) {
    this.uin = uin;
    this.setTitle("View / Change My Details UIN " + uin);
    this.jTextField1.setText(uin);
    this.jTextField2.setText(user.getFirstname());
    this.jTextField3.setText(user.getLastname());
    this.jTextField4.setText(user.getNickname());
    this.jTextField5.setText(user.getEmail());
    this.jTextField6.setText(user.getCity());
    this.jTextField7.setText(user.getState());
    this.jTextField8.setText(user.getZipcode());
    this.jComboBox1.addItem(user.getCountry());

    if (user.getGender().equals("Male")) {
      this.jComboBox2.setSelectedIndex(1);
    }
    else if (user.getGender().equals("Female")) {
      this.jComboBox2.setSelectedIndex(2);
    }
    else if (user.getGender().equals(" ")) {
      this.jComboBox2.setSelectedIndex(0);
    }

    this.jTextField9.setText(Integer.toString(user.getAge()));
    if (Integer.parseInt(user.getDay()) != 0) {
      this.jComboBox3.setSelectedIndex(Integer.parseInt(user.getDay()));
    }
    if (Integer.parseInt(user.getMonth()) != 0) {
      this.jComboBox4.setSelectedIndex(Integer.parseInt(user.getMonth()));
    }
    if (Integer.parseInt(user.getYear()) != 0) {
      this.jComboBox5.setSelectedIndex( (Integer.parseInt(user.getYear()) -
					 1900) + 1);
    }
  }

//---------------------------------------------------
  void jButton3_actionPerformed(ActionEvent e) {
    byte[] data;
    short lastseq;
    UserData user;
    user = new UserData();
    user.setFirstname(this.jTextField2.getText());
    user.setLastname(this.jTextField3.getText());
    user.setNickname(this.jTextField4.getText());
    user.setEmail(this.jTextField5.getText());
    user.setCity(this.jTextField6.getText());
    user.setState(this.jTextField7.getText());
    user.setZipcode(this.jTextField8.getText());
    user.setAge(Integer.parseInt(this.jTextField9.getText()));
    user.setCountry(this.jComboBox1.getSelectedItem().toString());
    user.setGender(this.jComboBox2.getSelectedItem().toString());
    user.setDay(this.jComboBox3.getSelectedItem().toString());
    user.setMonth(this.jComboBox4.getSelectedItem().toString());
    user.setYear(this.jComboBox5.getSelectedItem().toString());

    try {
      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setMetaSetGeneral(user.getNickname(),
	  user.getFirstname(), user.getLastname(), user.getEmail(),
	  user.getCity(), user.getState(), "", "", "", "", user.getZipcode(),
	  user.getCountry());
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.metasetgeneral, lastseq, data));
      System.out.println("metageneral");

      //Thread.sleep(1000);
      /*
	lastseq = this.sconnect.packetforsend.header.getSequence();
	this.sconnect.packetforsend = new CmdPacket();
	data = this.sconnect.clientCMD.setMetaSetMore(user.getGender(),Integer.toString(user.getAge()),user.getDay(),user.getMonth(),user.getYear()) ;
	this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.metasetmore, lastseq, data));
	System.out.println("metamore");
       */

      dispose();
    }
    catch (Exception ex) {}
  }

//------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }

//---------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    dispose();
  }
//-----------------------------------------------------------
}