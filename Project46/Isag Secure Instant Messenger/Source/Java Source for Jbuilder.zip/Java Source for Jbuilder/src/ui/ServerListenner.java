package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

import com.borland.jbcl.layout.*;

public class ServerListenner
    extends Thread {
  private boolean status = true;
  private byte[] data;
  private ServerConnect sconnect;
  private ServerToClientCMD srvCmd;
  private Packet receivePacket;
  private Util u;
  private short lastseq = -1;
  private DataInputStream remoteIn;
  private Vector searchresult = new Vector();
  private Vector myContactlist = new Vector();
  private FileOutputStream fout;
  private UserData userdata;
//------------------------------------------------------------------------------
  public void setStatus(boolean status) {
    this.status = status;
  }

//----------------------------------------------------------------------------
  public boolean getStatus() {
    return status;
  }

//----------------------------------------------------------------------
  public void RegistnewUser(byte[] data) {
    //------Register new user--------------------------
    try {
      this.sconnect.packetforsend = new StdPacket();
      data = this.sconnect.clientCMD.setHelloPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ident, lastseq, data));
      System.out.println("Hello");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setRegisteruserPacket(OwnerDataInfo.
	  getStringPassword());
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.registeruser, lastseq, data));
      System.out.println("RegisternewUser");
    }
    catch (IOException w) {}
  }

//----------------------------------------------------------------------
  public void getGoodbye(byte[] data) {
    byte[] temp = Util.copyBytes(data, 2, 2);
    short uinlen = Util.bytes2Short(temp);
    temp = Util.copyBytes(data, 6 + uinlen, 2);
    short iplen = Util.bytes2Short(temp);
    temp = Util.copyBytes(data, 8 + uinlen, iplen);
    String ip = new String(temp);
    ip = ip.substring(0, ip.length() - 5);
    this.sconnect.setServerBosIP(ip);
    OwnerDataInfo.setCookies(this.receivePacket.getCookie());
  }

//-----------------------------------------------------------------------
  public void getRegisterNewUserGoodbye(byte[] data) {
    try {
      this.sconnect.packetforsend = new StdPacket();
      data = this.sconnect.clientCMD.setGoodbyePacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.goodbye, lastseq, data));
      System.out.println("goodbye");
      status = false;
      this.lastseq = -1;
      this.stop();
    }
    catch (Exception w) {
    }
  }

//-----------------------------------------------------------------------
  public void getnewUIN(byte[] data) {
    byte[] tempdata = Util.copyBytes(data, 46, 4);
    tempdata = Util.swap4Bytes(tempdata);
    int uin = Util.bytes2Int(tempdata);
    System.out.println("uin is = " + uin);
    this.sconnect.logonpage.registerPage.registerSuccess = new RegisterSuccess(
	Integer.toString(uin));
    this.sconnect.logonpage.registerPage.registerSuccess.show();
  }

//-----------------------------------------------------------------------------
  public void getUserOnline(byte[] data) {
    UserOnlineInfo user = new UserOnlineInfo();
    int i, lenuin, tempip;
    int initbyte = 1;
    String uin;
    String ip = "";
    short userstatus = 0;
    byte[] temp;
//--------------get uin---------------------------------
    lenuin = (int) data[0];
    temp = new byte[lenuin];
    for (i = 0; i < lenuin; i++) {
      temp[i] = data[initbyte];
      initbyte++;
    }
    uin = new String(temp);
    user.setUin(uin);
//---------------get	internal ip-------------------------------
    initbyte = initbyte + 14;
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip);
    user.setInternal_Ip(ip);
//----------------get port-----------------------------------
    initbyte = initbyte + 2;
    temp = new byte[2];
    temp[0] = data[initbyte];
    initbyte++;
    temp[1] = data[initbyte];
    initbyte++;
    user.setport(u.bytes2Short(temp));
//-----------------get direct cookie--------------------------------------------
    initbyte = initbyte + 3;
    temp = new byte[4];
    temp[0] = data[initbyte];
    initbyte++;
    temp[1] = data[initbyte];
    initbyte++;
    temp[2] = data[initbyte];
    initbyte++;
    temp[3] = data[initbyte];
    initbyte++;
    user.setCookie(temp);
//-----------------get external ip---------------------------------------
    ip = new String();
    initbyte = initbyte + 26;
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip) + ".";
    tempip = (int) data[initbyte];
    tempip = (int) Util.chnbyteHectoDec(Integer.toHexString(tempip));
    initbyte++;
    ip = ip + Integer.toString(tempip);
    user.setExternal_Ip(ip);
//------------------get status---------------------------------------------
//initbyte = initbyte	;
    temp[0] = data[initbyte];
    initbyte++;
    temp[1] = data[initbyte];
    initbyte++;
    temp[2] = data[initbyte];
    initbyte++;
    temp[3] = data[initbyte];
    initbyte++;
    int tempint;
    tempint = u.bytes2Int(temp);
    if (tempint != 0x00060004) {
      initbyte = initbyte + 8;
    }
    else {
      initbyte = initbyte + 2;
    }
    temp[0] = data[initbyte];
    initbyte++;
    temp[1] = data[initbyte];
    userstatus = u.bytes2Short(temp);

    if (userstatus == 0x0000) {
      user.setDisplaystatus("Online");
    }
    else if (userstatus == 0x0001) {
      user.setDisplaystatus("Away");
    }
    else if (userstatus == 0x0005) {
      user.setDisplaystatus("NA");
    }
    else if (userstatus == 0x0011) {
      user.setDisplaystatus("Occupied");
    }
    else if (userstatus == 0x0013) {
      user.setDisplaystatus("DND");
    }
    else if (userstatus == 0x0020) {
      user.setDisplaystatus("Free for chat");
    }
//---------------Is there uin in contactlists ---------------------------------
    UserData userdata;
    int size, count;
    userdata = this.finduserincontactlist(user.getUin());
    if (userdata != null) {
      userdata.setDisplaystatus(user.getDisplaystatus());
      if (!userdata.getStatus().equals("secure")) {
	userdata.setStatus("online");
      }
      userdata.setCookiep2p(user.getCookies());
      userdata.setInternal_ip(user.getInternal_Ip());
      userdata.setExternal_ip(user.getExternal_Ip());
      userdata.setTcpconnectport(user.getPort());
    }
    OwnerDataInfo.setMyContactlist(this.myContactlist);
    this.sconnect.logonpage.mainPage.setList();
    System.out.println("user online");
  }

//---------------------------------------------------------------------
  public void getMetaLast(byte[] data) {
    int j, size, i;
    byte[] temp;
    temp = new byte[4];
    SearchInfo sinfo = new SearchInfo();
    temp[3] = data[0];
    temp[2] = data[1];
    temp[1] = data[2];
    temp[0] = data[3];
    sinfo.setUin(u.bytes2Int(temp));
    //------------------ set nickname ---------------------
    temp = new byte[4];
    temp[3] = data[4];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    int startbit = 6;
    for (i = 0; i != size; i++) {
      temp[i] = data[startbit];
      startbit++;
    }
    i = 6 + size;
    String nick = new String(temp);
    sinfo.setNickname(nick);
    System.out.println("Nick = " + nick);
    //--------------------set firstname--------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String first = new String(temp);
    sinfo.setFirstname(first);
    System.out.println("first = " + first);
    //-------------------set lastname----------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String last = new String(temp);
    sinfo.setLastname(last);
    System.out.println("last = " + last);
    //----------------set email----------------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String email = new String(temp);
    sinfo.setEmail(email);
    System.out.println("email = " + email);
    //------------------set flag------------------------
    temp = new byte[4];
    temp[2] = data[i];
    temp[3] = data[i + 1];
    if (u.bytes2Int(temp) == 1) {
      sinfo.setAuthorize("No");
    }
    else if (u.bytes2Int(temp) == 0) {
      sinfo.setAuthorize("Yes");
    }
    i = i + 2;
    //-----------------set status------------------------
    temp = new byte[4];
    temp[3] = data[i];
    temp[2] = data[i + 1];
    if (u.bytes2Int(temp) == 0) {
      sinfo.setStatus("offline");
    }
    else if (u.bytes2Int(temp) == 1) {
      sinfo.setStatus("online");
    }
    else if (u.bytes2Int(temp) == 2) {
      sinfo.setStatus("");
    }
    i = i + 2;
    //-------------------set gender -----------------------
    temp = new byte[4];
    temp[3] = data[i];
    if (u.bytes2Int(temp) == 0) {
      sinfo.setGender("");
    }
    else if (u.bytes2Int(temp) == 1) {
      sinfo.setGender("Female");
    }
    else if (u.bytes2Int(temp) == 2) {
      sinfo.setGender("Male");
    }
    i = i + 1;
    //-----------------set age--------------------
    temp = new byte[4];
    temp[3] = data[i];
    sinfo.setAge(u.bytes2Int(temp));
    searchresult.addElement(sinfo);
    //-------------------get owner infomation-----------------------------------
    if (Integer.toString(sinfo.getUin()).equals(OwnerDataInfo.getUin())) {
      this.sconnect.logonpage.getOwnInfo(sinfo);
      //this.sconnect.logonpage.outPropertiesTofile();
    }
    else {
      //------- Is there uin in contactlists --------------
      UserData user;
      user = new UserData();
      user = this.finduserincontactlist( (Integer.toString(sinfo.getUin())));
      if (user != null) { //-------- yes there is uin in contactlist ----------------------
	user.setAge(sinfo.getAge());
	user.setAuthorize(sinfo.getAuthorize());
	user.setEmail(sinfo.getEmail());
	user.setFirstname(sinfo.getFirstname());
	user.setGender(sinfo.getGender());
	user.setLastname(sinfo.getLastname());
	if (user.getNickname().equals(" ")) {
	  user.setNickname(sinfo.getNickname());
	}
      }
    }
    //-----------------------------------------------------
    this.add2Table();
  }

//----------------------------------------------------------------------
  public void getMetaGeneral(byte[] data) {
    byte[] tempdata;
    this.userdata = new UserData();
    int posinit = 0; // position to get data from packet
    int len, inti;
    String str;
    for (inti = 0; inti < 11; inti++) {
      //------------------- get length ---------------------
      tempdata = Util.copyBytes(data, posinit, 1);
      len = (int) tempdata[0];
      posinit = posinit + 2;
      //-------------------- get data----------------------------
      if (len != 1) {
	tempdata = Util.copyBytes(data, posinit, len - 1);
	str = new String(tempdata);
	switch (inti) {
	  case 0:
	    this.userdata.setNickname(str);
	    break;
	  case 1:
	    this.userdata.setFirstname(str);
	    break;
	  case 2:
	    this.userdata.setLastname(str);
	    break;
	  case 3:
	    this.userdata.setEmail(str);
	    break;
	  case 4:
	    this.userdata.setCity(str);
	    break;
	  case 5:
	    this.userdata.setState(str);
	    break;
	  case 6:
	    this.userdata.setPhone(str);
	    break;
	  case 7:
	    this.userdata.setFax(str);
	    break;
	  case 8:
	    this.userdata.setStreet(str);
	    break;
	  case 9:
	    this.userdata.setCellular(str);
	    break;
	  case 10:
	    this.userdata.setZipcode(str);
	    break;
	  default:
	    System.out.println("Invalid");
	} //end switch
      } // end if
      else {
	switch (inti) {
	  case 0:
	    this.userdata.setNickname(" ");
	    break;
	  case 1:
	    this.userdata.setFirstname(" ");
	    break;
	  case 2:
	    this.userdata.setLastname(" ");
	    break;
	  case 3:
	    this.userdata.setEmail(" ");
	    break;
	  case 4:
	    this.userdata.setCity(" ");
	    break;
	  case 5:
	    this.userdata.setState(" ");
	    break;
	  case 6:
	    this.userdata.setPhone(" ");
	    break;
	  case 7:
	    this.userdata.setFax(" ");
	    break;
	  case 8:
	    this.userdata.setStreet(" ");
	    break;
	  case 9:
	    this.userdata.setCellular(" ");
	    break;
	  case 10:
	    this.userdata.setZipcode(" ");
	    break;
	  default:
	    System.out.println("Invalid");
	} // end switch
	//posinit = posinit + len ;
      } //end else
      //---------------------------------------------------------------
      posinit = posinit + len;
    } //end for
    //---------------------get country-------------------------------
    tempdata = Util.copyBytes(data, posinit, 2);
    int countrycode = Util.bytes2Short(Util.swap2Bytes(tempdata));
    String countryname;
    try {
      FileInputStream fi = new FileInputStream("./activeuser/countrycode");
      Properties p = new Properties();
      p.load(fi);
      countryname = (String) p.get(Integer.toString(countrycode));
      this.userdata.setCountry(countryname);
    }
    catch (Exception w) {}
    //---------------------------------------------------------------
  }

//---------------------------------------------------------------------
  public void getMetaMore(byte[] data) {
    byte[] tempdata;
    int posinit = 0; // position to get data from packet
    int tempint, inti, len;
    //-------------------- get age------------------------
    tempdata = Util.copyBytes(data, posinit, 1);
    tempint = (int) tempdata[0];
    if (tempint == 0 || tempint == -1) {
      this.userdata.setAge(0);
    }
    else {
      this.userdata.setAge(tempint);
    }
    posinit = posinit + 2;
    //--------------------- get sex-----------------------
    tempdata = Util.copyBytes(data, posinit, 1);
    tempint = (int) tempdata[0];
    if (tempint == 1) {
      this.userdata.setGender("Female");
    }
    else if (tempint == 2) {
      this.userdata.setGender("Male");
    }
    else if (tempint == 0) {
      this.userdata.setGender(" ");
    }
    posinit = posinit + 1;
    //--------------------- get homepage -----------------
    tempdata = Util.copyBytes(data, posinit, 1);
    len = (int) tempdata[0];
    String datahomepage;
    posinit = posinit + 2;
    if (len == -1) {
      tempdata = Util.copyBytes(data, posinit, len - 1);
      datahomepage = new String(tempdata);
      posinit = posinit + len - 1;
    }
    else {
      this.userdata.setHomepage(" ");
      posinit = posinit + len;
    }
    //-------------------- get year-----------------------
    short year;
    tempdata = Util.copyBytes(data, posinit, 2);
    tempdata = Util.swap2Bytes(tempdata);
    year = Util.bytes2Short(tempdata);
    this.userdata.setYear(Short.toString(year));
    posinit = posinit + 2;
    //-------------------- get month ---------------------
    tempdata = Util.copyBytes(data, posinit, 1);
    tempint = (int) tempdata[0];
    this.userdata.setMonth(Integer.toString(tempint));
    posinit = posinit + 1;
    //------------------- get day ------------------------
    tempdata = Util.copyBytes(data, posinit, 1);
    tempint = (int) tempdata[0];
    this.userdata.setDay(Integer.toString(tempint));
    //----------------------------------------------------
    //---------------------- add to user detail panel--------------------
    this.sconnect.logonpage.mainPage.userDetail.setData(this.userdata);
    //this.sconnect.logonpage.mainPage.userDetail.show() ;
    //-------------------------------------------------------------------

  }

//----------------------------------------------------------------------
  public void getDoneOfflinemsg(byte[] data) {
    try {
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setAckofflinemsgs();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ackofflinemsgs, lastseq, data));
      System.out.println("Ackofflinemsgs");
    }
    catch (IOException w) {}
  }

//---------------------------------------------------------------------
  public void getUserOffline(byte[] data) {
    int uinlen, i;
    int startbit = 1; //begin bit to start retreive data from the packet
    byte[] temp;
    String uin;
    uinlen = (int) data[0];
    temp = new byte[uinlen];
    for (i = 0; i != uinlen; i++) {
      temp[i] = data[startbit];
      startbit++;
    }
    uin = new String(temp);
    //------------------------------------------------
    UserData userdata;
    userdata = this.finduserincontactlist(uin);
    if (userdata != null) {
      userdata.setStatus("offline");
    }
    OwnerDataInfo.setMyContactlist(this.myContactlist);
    this.sconnect.logonpage.mainPage.setList();
  }

//---------------------------------------------------------------------
  public void getSrv_Families(byte[] data) {
    try {
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setFamiliesPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.families, lastseq, data));
    }
    catch (IOException w) {}
  }

//---------------------------------------------------------------------
  public void getSrv_motd(byte[] data) {
    try {
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setRateReqPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ratesrequest, lastseq, data));
      System.out.println("ratesrequest");
    }
    catch (Exception w) {}
  }

//---------------------------------------------------------------------
  public void getSrv_Rates(byte[] data) {
    try {
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setAckRatePacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ackrates, lastseq, data));
      System.out.println("ackrate");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqInfoPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqinfo, lastseq, data));
      System.out.println("reqinfo");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqListsPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqlists, lastseq, data));
      System.out.println("reqlist");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqRosterPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqroster, lastseq, data));
      System.out.println("reqroster");

      /* lastseq = this.sconnect.packetforsend.header.getSequence() ;
		  this.sconnect.packetforsend = new CmdPacket() ;
		  data = this.sconnect.clientCMD.setCheckRosterPacket() ;
		  this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.checkroster,lastseq,data)) ;
		  System.out.println("checkroster");*/

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqLocationPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqlocation, lastseq, data));
      System.out.println("reqlocation");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqBuddyPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqbuddy, lastseq, data));
      System.out.println("reqbuddy");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqIcbmPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqicbm, lastseq, data));
      System.out.println("reqicbm");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqBosPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqbos, lastseq, data));
      System.out.println("reqbos");
    }
    catch (IOException w) {}
  }

//----------------------------------------------------------------------
  public void registerNewUserRefused(byte[] data) {
    String title;
    String result;
    title = "Register new user not complete";
    result = "Register new user not complete Please try again.";
    this.sconnect.logonpage.messageBox = new MessageBox(title, result);
    this.sconnect.logonpage.messageBox.show();
  }

//---------------------------------------------------------------------
  public void getReplyBos(byte[] data) {
    try {
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setRosterAckPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.rosterack, lastseq, data));
      System.out.println("rosterack");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setUserInfoPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.setuserinfo, lastseq, data));
      System.out.println("setuserinfo");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setIcbmPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.seticbm, lastseq, data));
      System.out.println("seticbm");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setStatusPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.setstatus, lastseq, data));
      System.out.println("setstatus");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReadyPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ready, lastseq, data));
      System.out.println("setready");

      lastseq = this.sconnect.packetforsend.header.getSequence();
      this.sconnect.packetforsend = new CmdPacket();
      data = this.sconnect.clientCMD.setReqOfflineMsgsPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.reqofflinemsgs, lastseq, data));
      System.out.println("reqofflinemsg");
    }
    catch (IOException e) {}
  }

//---------------------------------------------------------------------
  public void getReplyRoster(byte[] data) {
    //--------------not complete remebmer that not handle for block uin
    byte[] temp;
    short size;
    int time, i;
    short len, groupnum, ids, type, followingbyte;
    int pos = 1;
    int pos2;
    int flagabnormal = 0;
    String tempstr = "";
    ContactListinfo cl = new ContactListinfo();
    UserData user = new UserData();
    //--------------- set size ------------
    temp = new byte[2];
    temp[0] = data[pos];
    pos++;
    temp[1] = data[pos];
    pos++;
    cl.setSize(temp);
    //--------------find to begin-----------------------
    pos = pos + 8;
    temp = new byte[2];
    temp[0] = data[pos];
    pos++;
    temp[1] = data[pos];
    pos++;
    len = u.bytes2Short(temp);
    pos = pos + len;
    System.out.println(pos);
    System.out.println(len);
    System.out.println(data.length);
    while ((pos != data.length)) {
      //-----------------check for string--------------------
      temp = new byte[2];
      temp[0] = data[pos];
      pos++;
      temp[1] = data[pos];
      pos++;
      len = u.bytes2Short(temp);
      temp = new byte[len];
      //-----------check authurization-----------------
      if (len == 102) {
	pos = pos + 2;
	temp = new byte[2];
	temp[0] = data[pos];
	pos++;
	temp[1] = data[pos];
	pos++;
	len = u.bytes2Short(temp);
	temp = new byte[len];
      }
      //------------------------------------------------
      if (len != 0) {
        System.out.println("pos "+pos);
	for (i = 0; i < len; i++) {
	  temp[i] = data[pos];
	  pos++;
	}
	tempstr = new String(temp);
      }
      //----------------check for group number---------------------------
      temp = new byte[2];
      temp[0] = data[pos];
      pos++;
      temp[1] = data[pos];
      pos++;
      groupnum = u.bytes2Short(temp);
      cl.setGroupunm(groupnum);
      //----------------check for ids------------------------------------
      temp = new byte[2];
      temp[0] = data[pos];
      pos++;
      temp[1] = data[pos];
      pos++;
      ids = u.bytes2Short(temp);
      cl.setId(ids);
      //-----------------check for type ----------------------------------
      temp = new byte[2];
      temp[0] = data[pos];
      pos++;
      temp[1] = data[pos];
      pos++;
      type = u.bytes2Short(temp);
      cl.setType(groupnum);
      //-----------------check for followingbyte--------------------------
      temp = new byte[2];
      temp[0] = data[pos];
      //temp[0]=0x00;
      pos++;
      temp[1] = data[pos];
      pos++;
      followingbyte = u.bytes2Short(temp);
      pos2=pos;
      System.out.println(((int)temp[0])+" "+((int)temp[1]));
      //-----------------check for add------------------------------------
      if (type == 1) { //----------add group header---
	cl.setGroupname(tempstr);
	temp = new byte[followingbyte];
	for (i = 0; i < followingbyte; i++) {
	  temp[i] = data[pos];
	  pos++;
	}
	cl.setListofid(temp);
	if (tempstr.equals("General")) {
	  this.sconnect.clientCMD.setGroupid(cl.getGroupnum());
	  this.sconnect.clientCMD.setListofids(temp);
	}
        System.out.println("type 1");
      }
      //--------------------------------------------
      else if (type == 0) { //-------add uin ----------
        System.out.println("type 0");
	user.setUin(tempstr);
	user.setIdInGroup(ids);
	if (followingbyte > 0) { //Told me that it has nickname follow
	  temp = new byte[2];
	  temp[0] = data[pos];
	  pos++;
	  temp[1] = data[pos];
	  pos++;
	  len = u.bytes2Short(temp);
	  //-------------check for tlv 305--------------------
	  if (len == 305) { //-------add nickname------
	    //----------------retrive length of tlv-------
	    temp = new byte[2];
	    temp[0] = data[pos];
	    pos++;
	    temp[1] = data[pos];
	    pos++;
	    len = u.bytes2Short(temp);
	    temp = new byte[len];
	    //for (i = 0; i < len; i++) { //-----retrive nickname----
	    //  temp[i] = data[pos];
	    //  pos++;
	    //}
            System.arraycopy(data,pos,temp,0,len);
            pos=pos+len;
            System.out.println("len "+len);
            System.out.println(new String(temp));
	    tempstr = new String(temp);
	    user.setNickname(tempstr);
	  }
	}
	else { //--------------no nickname following --------------
	  //no action
	}
	this.myContactlist.addElement(user);
      } //end add uin and nickname
      //--------------------------------------------
      else {
        System.out.println("type "+type);
	pos = pos + followingbyte;
      }
      //----------------set time---------------------------------
      pos=pos2+followingbyte;
      if (this.receivePacket.data.length - pos == 4) {
	temp = new byte[4];
	temp[0] = data[pos];
	pos++;
	temp[1] = data[pos];
	pos++;
	temp[2] = data[pos];
	pos++;
	temp[3] = data[pos];
	pos++;
	cl.setTime(temp);
      }
      user = new UserData();
    }
    OwnerDataInfo.setMyContactlist(this.myContactlist);
    //-----------set all user in contactlist to properties-------------------------
    OwnerDataInfo.setProperties();
    //-------------------------------------------------
    this.sconnect.logonpage.mainPage.setList();
    try {
      this.addContactlist2file();
    }
    catch (IOException e) {
    }
    //----------------login complete------------------
    this.sconnect.logonpage.setStatusLogin(true);
    //------------------------------------------------
  }

//---------------------------------------------------------------------
  public void connect2BOSServer(byte[] data) {
    try {
      //-------sent data to bos -------------------------
      this.sconnect.packetforsend = new StdPacket();
      data = this.sconnect.clientCMD.setCookiePacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.cookie, lastseq, data));
      System.out.println("cookies");
      this.lastseq = 0;
    }
    catch (IOException w) {}
  }

//---------------------------------------------------------------------
  public void connect2ICQServer(byte[] data) {
    try {
      //------send data to icq --------------------------
      this.sconnect.packetforsend = new StdPacket();
      data = this.sconnect.clientCMD.setIdentPacket();
      this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.
	  sconnect.clientCMD.ident, lastseq, data));
      System.out.println("ident");
      this.lastseq = 0;
    }
    catch (IOException w) {}
  }

//---------------------------------------------------------------------
  public void getUpdateACK(byte[] data) {
    if (this.receivePacket.data[data.length - 1] == 0) {
      if (this.sconnect.updatetype.equals("Add")) {
	this.sconnect.logonpage.mainPage.searchPage.updateAddGroup();
	this.sconnect.updatetype = " ";
      }
      else if (this.sconnect.updatetype.equals("Remove")) {
	this.sconnect.logonpage.mainPage.deleteUser.updategroupRemove();
	;
	this.sconnect.updatetype = " ";
      }
      else {
	System.out.println("---------------add or remove finish---------------");
      }
    }
    else {
      String title;
      String result;
      if (this.sconnect.updatetype.equals("Add")) {
	title = "Add other to your contactlist Fail";
	result = "Add Fail Please try again.";
      }
      else {
	title = "Remove other from your contactlist Fail";
	result = "Remove Fail Please try again.";
      }
      this.sconnect.logonpage.messageBox = new MessageBox(title, result);
      this.sconnect.logonpage.messageBox.show();
    }
  }

//---------------------------------------------------------------------
  public void getMetaFound(byte[] data) {
    int j, size, i;
    byte[] temp;
    temp = new byte[4];
    SearchInfo sinfo = new SearchInfo();
    temp[3] = data[0];
    temp[2] = data[1];
    temp[1] = data[2];
    temp[0] = data[3];
    sinfo.setUin(u.bytes2Int(temp));
    //------------------ set nickname ---------------------
    temp = new byte[4];
    temp[3] = data[4];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    int startbit = 6;
    for (i = 0; i != size; i++) {
      temp[i] = data[startbit];
      startbit++;
    }
    i = 6 + size;
    String nick = new String(temp);
    sinfo.setNickname(nick);
    System.out.println("Nick = " + nick);
    //--------------------set firstname--------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String first = new String(temp);
    sinfo.setFirstname(first);
    System.out.println("first = " + first);
    //-------------------set lastname----------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String last = new String(temp);
    sinfo.setLastname(last);
    System.out.println("last = " + last);
    //----------------set email----------------------------
    temp = new byte[4];
    temp[3] = data[i + 1];
    size = u.bytes2Int(temp) - 1;
    temp = new byte[size];
    startbit = i + 3;
    for (j = 0; j != size; j++) {
      temp[j] = data[startbit];
      startbit++;
    }
    i = i + j + 3;
    String email = new String(temp);
    sinfo.setEmail(email);
    System.out.println("email = " + email);
    //------------------set flag------------------------
    temp = new byte[4];
    temp[2] = data[i];
    temp[3] = data[i + 1];
    if (u.bytes2Int(temp) == 1) {
      sinfo.setAuthorize("No");
    }
    else if (u.bytes2Int(temp) == 0) {
      sinfo.setAuthorize("Yes");
    }
    i = i + 2;
    //-----------------set status------------------------
    temp = new byte[4];
    temp[3] = data[i];
    temp[2] = data[i + 1];
    if (u.bytes2Int(temp) == 0) {
      sinfo.setStatus("offline");
    }
    else if (u.bytes2Int(temp) == 1) {
      sinfo.setStatus("online");
    }
    else if (u.bytes2Int(temp) == 2) {
      sinfo.setStatus("");
    }
    i = i + 2;
    //-------------------set gender -----------------------
    temp = new byte[4];
    temp[3] = data[i];
    if (u.bytes2Int(temp) == 0) {
      sinfo.setGender("");
    }
    else if (u.bytes2Int(temp) == 1) {
      sinfo.setGender("Female");
    }
    else if (u.bytes2Int(temp) == 2) {
      sinfo.setGender("Male");
    }
    i = i + 1;
    //-----------------set age--------------------
    temp = new byte[4];
    temp[3] = data[i];
    sinfo.setAge(u.bytes2Int(temp));
    searchresult.addElement(sinfo);
  }

//---------------------------------------------------------------------
  public String analystMessage(String rtfmsg) {
    int i = 0, j = 0;
    String realmsg = "";
    String tempstr = "";
    String fontsize;
    while (i < rtfmsg.length()) {
      while (rtfmsg.charAt(i) != '\\') {
	tempstr = tempstr + rtfmsg.charAt(i);
	i++;
      }
      tempstr = tempstr + rtfmsg.charAt(i);
      fontsize = tempstr.substring(0, 2);
      if (fontsize.equals("fs")) {
	j = 2;
	while (tempstr.charAt(j) != ' ') {
	  j++;
	}
	j++;
	while (tempstr.charAt(j) != '\\') {
	  realmsg = realmsg + tempstr.charAt(j);
	  j++;
	}
	i = rtfmsg.length() + 10;
      }
      else {
	i++;
	tempstr = "";
      }
    }
    return realmsg;
  }

//---------------------------------------------------------------------
  public void receiveOfflineMessage(byte[] data) {
    int uin;
    byte[] tempdata;
    int msglen;
    String msg;
    tempdata = Util.copyBytes(data, 15, 4);
    tempdata = Util.swap4Bytes(tempdata);
    uin = Util.bytes2Short(tempdata);
    tempdata = Util.copyBytes(data, 3, 2);
    msglen = Util.bytes2Short(tempdata);
    tempdata = Util.copyBytes(data, 29, msglen - 25);
    msg = new String(tempdata);
    //---------------- set message for only one message----------------------------------------------------------------------------------------------
    UserData userdata = new UserData();
    userdata = this.finduserincontactlist(Integer.toString(uin));

    if (userdata != null) {
      this.sconnect.logonpage.mainPage.messagePage = new MessagePage(this.
	  sconnect, userdata);
      this.sconnect.logonpage.mainPage.messagePage.jTextArea1.setText(msg);
      this.sconnect.logonpage.mainPage.messagePage.show();
    }
  }

//---------------------------------------------------------------------
  public void receiveMessage(byte[] data) {
    String uin;
    String realmsg = "";
    short type;
    int position;
    byte[] tempdata;
    int uinlen;
    try {
      tempdata = Util.copyBytes(data, 8, 2);
      type = Util.bytes2Short(tempdata);
      tempdata = Util.copyBytes(data, 10, 1);
      uinlen = (int) tempdata[0];
      tempdata = Util.copyBytes(data, 11, uinlen);
      uin = new String(tempdata);
      position = 11 + uinlen;
      if (type == 2) {
	while (position < data.length) { //check for rtf message
	  if (data[position] == 114) { //r
	    if (data[position + 1] == 116) { //t
	      if (data[position + 2] == 102) { //f
		tempdata = Util.copyBytes(data, position,
					  data.length - position);
		position = data.length + 10;
	      }
	    }
	  }
	  position++;
	}
	String rtfmsg = new String(tempdata);
	realmsg = this.analystMessage(rtfmsg);
      }
      else if (type == 1) {
	position = 11 + uinlen + 45;
	short msglen;
	tempdata = Util.copyBytes(data, position, 1);
	msglen = Util.bytes2Short(tempdata);
	tempdata = Util.copyBytes(data, position + 2, msglen - 1);
	realmsg = new String(tempdata);
	realmsg = realmsg.substring(4, realmsg.length() - 6);
      }
      //---------------- set message ----------------------------------------------------------------------------------------------
      UserData userdata = new UserData();
      userdata = this.finduserincontactlist(uin);

      if (userdata != null) {
	this.sconnect.logonpage.mainPage.messagePage = new MessagePage(this.
	    sconnect, userdata);
	this.sconnect.logonpage.mainPage.messagePage.jTextArea1.setText(realmsg);
	this.sconnect.logonpage.mainPage.messagePage.show();
      }
    }
    catch (Exception e) { /* System.out.println(e.getMessage());*/}
  }

//---------------------------------------------------------------------
  public UserData finduserincontactlist(String uin) {
    UserData user;

    user = new UserData();
    Properties p;
    p = new Properties();
    p = OwnerDataInfo.getProperties();
    System.out.println(uin);
    user = (UserData) p.get(uin);
    if (user != null) {
      return user;
    }
    return null;
  }

//------------------------------------------------------------------------
  public void addContactlist2file() throws IOException {
    int size;
    int i = 0;
    UserData cinfo;
    fout = new FileOutputStream("c:/" + OwnerDataInfo.getUin() + ".ctl");
    size = myContactlist.size();
    for (i = 0; i < size; i++) {
      cinfo = (UserData)this.myContactlist.elementAt(i);
      fout.write(cinfo.getUin().getBytes());
      if (cinfo.getNickname() != null) {
	fout.write(cinfo.getNickname().getBytes());
      }
      else {
	fout.write(cinfo.getUin().getBytes());
      }
    }
    fout.close();
  }

//------------------------------------------------------------------------
  public void add2Table() {
    if (this.sconnect.logonpage.mainPage.searchPage != null) {
      this.sconnect.logonpage.mainPage.searchPage.setSearchresult(this.
	  searchresult);
      this.sconnect.logonpage.mainPage.searchPage.setTable();
      //------------clear search result -------------------
      searchresult = new Vector();
    }
    else {
      searchresult = new Vector();
    }
  }

//----------------------------------------------------------------------------
  public ServerListenner(ServerConnect sconnect) {
    this.sconnect = sconnect;
    try {
      remoteIn = new DataInputStream(this.sconnect.getSocket().getInputStream());
      srvCmd = new ServerToClientCMD();
    }
    catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

//---------------------------------------------------------------------------
  /*
   This Function is Run Method for Thread in order to capture the package from
   the the internet( ICQ Server )
   */
  public void run() {
    while (status) {
      try {
	byte id;
	byte chn;
	short seq;
	short length;
	int i;

	while (true) {
	  //-------------- receive packet from the internet -------
	  this.receivePacket = null;
	  ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
	  DataOutputStream dataOut = new DataOutputStream(byteOut);
	  id = remoteIn.readByte();
	  chn = remoteIn.readByte();
	  seq = remoteIn.readShort();
	  length = remoteIn.readShort();
	  dataOut.write(id);
	  dataOut.write(chn);
	  dataOut.writeShort(seq);
	  dataOut.writeShort(length);
	  for (i = 0; i != length; i++) {
	    dataOut.write(remoteIn.read());
	  }
	  //--------------------------------------------------------
	  if (chn == 1 || chn == 4 || chn == 5) {
	    this.receivePacket = new StdPacket();
	  }
	  else {
	    this.receivePacket = new CmdPacket();
	  }
	  //----------------------------------------------------------------
	  if (lastseq != -1) {
	    lastseq = this.sconnect.packetforsend.header.getSequence();
	  }
	  //--------------------------------------------------------
	  this.receivePacket.analytePacket(byteOut.toByteArray());
	  //-------------automatic checking in order to communicate with ICQserver -------
	  if (this.receivePacket.header.getcommand() == this.srvCmd.srv_hello) {
	    if (this.sconnect.getServer2connect().equals("RegisterNewUser")) {
	      this.RegistnewUser(this.receivePacket.data);
	    }
	    //----connect to icqserver -------------------------
	    else if (this.sconnect.getServer2connect().equals("icqserver")) {
	      this.connect2ICQServer(this.receivePacket.data);
	    }
	    //----connect to bosserver -------------------------
	    else if (this.sconnect.getServer2connect().equals("bosserver")) {
	      this.connect2BOSServer(this.receivePacket.data);
	    }
	  }
	  //---------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_goodbye) {
	    if (!this.sconnect.getServer2connect().equals("RegisterNewUser")) {
	      this.getGoodbye(this.receivePacket.data);
	    }
	    this.getRegisterNewUserGoodbye(this.receivePacket.data);
	  }
	  //---------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_families) {
	    this.getSrv_Families(this.receivePacket.data);
	  }
	  //------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_motd) {
	    this.getSrv_motd(this.receivePacket.data);
	  }
	  //------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_rates) {
	    this.getSrv_Rates(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_replybos) {
	    this.getReplyBos(this.receivePacket.data);
	  }
	  //------------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_replyroster) {
	    this.getReplyRoster(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_metafound) {
	    this.getMetaFound(this.receivePacket.data);
	  }
	  //-----------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_useonline) {
	    this.getUserOnline(this.receivePacket.data);
	  }
	  //----------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_metalast) {
	    this.getMetaLast(this.receivePacket.data);
	  }
	  //--------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_offlinemsg) {
	    this.receiveOfflineMessage(this.receivePacket.data);
	  }
	  //---------------- receive user data detail from server---------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_metageneral) {
	    this.getMetaGeneral(this.receivePacket.data);
	  }
	  //---------------------------- receive more detial about user detail ----------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_metamore) {
	    this.getMetaMore(this.receivePacket.data);
	  }
	  //--------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_useroffline) {
	    this.getUserOffline(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_recvmsg
	      /* || this.receivePacket.header.getcommand() == this.srvCmd.srv_snac4_12 */) {
	    this.receiveMessage(this.receivePacket.data);
	  }
	  //--------------------------------------------------------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_updateack) {
	    this.getUpdateACK(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_doneofflinemsgs) {
	    this.getDoneOfflinemsg(this.receivePacket.data);
	  }
	  //--------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_newuin) {
	    this.getnewUIN(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------------
	  else if (this.receivePacket.header.getcommand() ==
		   this.srvCmd.srv_recrefused) {
	    this.registerNewUserRefused(this.receivePacket.data);
	  }
	  //-------------------------------------------------------------------------------------------------
	}
      }
      catch (IOException e) {
	System.out.println(e.getMessage());
      }
      finally {
	try {
	  if (sconnect.getSocket() != null) {
	    sconnect.getSocket().close();
	  }
	}
	catch (IOException x) {
	  System.out.println(x.getMessage());
	}
      }
    }
//---------------------------------------------------------------------------
  }
}