package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MessagePage
    extends JFrame {
  JPanel contentPane;
  private UserData user;
  private ServerConnect sconn;
  //private TCPconnect tcp;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextArea jTextArea1 = new JTextArea();
  JTextArea jTextArea2 = new JTextArea();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel4 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JScrollPane jScrollPane1 = new JScrollPane(jTextArea1);
  JLabel jLabel5 = new JLabel();
  JScrollPane jScrollPane2 = new JScrollPane(jTextArea2);
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();


  //Construct the frame
  public MessagePage(ServerConnect s, UserData u) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.sconn = s;
    this.user = u;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MessagePage.class.getResource("[Your Icon]")));
    String uin = user.getUin();
    String nick = user.getNickname();
    String email = user.getEmail();
    if (uin == null) {
      uin = "";
    }
    if (nick == null) {
      nick = "";
    }
    if (email == null) {
      email = "";
    }
    contentPane = (JPanel)this.getContentPane();
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setBounds(new Rectangle(5, 5, 430, 210));
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(449, 371));
    this.setTitle("Message page : Chat with \""+nick+"\"");
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("To :	 UIN#");
    jLabel2.setBounds(new Rectangle(15, 15, 55, 20));
    jTextField1.setText(uin);
    jTextField1.setBounds(new Rectangle(75, 15, 70, 20));
    jTextField1.setEnabled(false);
    jTextField1.setDisabledTextColor(Color.blue);
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Nick :");
    jLabel3.setBounds(new Rectangle(155, 15, 35, 20));
    jTextField2.setText(nick);
    jTextField2.setBounds(new Rectangle(190, 15, 60, 20));
    jTextField2.setEnabled(false);
    jTextField2.setDisabledTextColor(Color.blue);
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("E-mail :");
    jLabel4.setBounds(new Rectangle(260, 15, 45, 20));
    jTextField3.setText(email);
    jTextField3.setBounds(new Rectangle(305, 15, 120, 20));
    jTextField3.setEnabled(false);
    jTextField3.setDisabledTextColor(Color.blue);
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.
					      HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane1.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane1.setBounds(new Rectangle(15, 45, 410, 160));
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(5, 220, 430, 120));
    jScrollPane2.setHorizontalScrollBarPolicy(JScrollPane.
					      HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane2.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane2.setBounds(new Rectangle(15, 230, 410, 60));
    jButton1.setBounds(new Rectangle(105, 305, 90, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Send");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	try {
	  jButton1_actionPerformed(e);
	}
	catch (Exception ea) {
	  System.out.println(ea.getMessage());
	}
      }
    });
    jButton2.setBounds(new Rectangle(215, 305, 90, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    jTextArea1.setBorder(BorderFactory.createLoweredBevelBorder());
    jTextArea1.setDisabledTextColor(Color.red);
    jTextArea1.setEditable(false);
    jTextArea1.setText("");
    jTextArea2.setText("");
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(jTextArea1, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jScrollPane2, null);
    jScrollPane2.getViewport().add(jTextArea2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    //contentPane.add(jTextArea2,	new XYConstraints(141, 260, 32, 14));
    //contentPane.add(jTextArea1,	new XYConstraints(20, 63, 403, 154));
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    dispose();
  }

//----------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) throws IOException {
    String message;
    short lastseq;
    byte[] data;
    message = this.jTextArea2.getText();
    if (user.getStatus().equals("online")) {
      lastseq = this.sconn.packetforsend.header.getSequence();
      this.sconn.packetforsend = new CmdPacket();
      data = this.sconn.clientCMD.setSendmsgonline(this.user.getUin(), message);
      this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.
	  clientCMD.sendmsg, lastseq, data));
    }
    else if (user.getStatus().equals("offline")) {
      lastseq = this.sconn.packetforsend.header.getSequence();
      this.sconn.packetforsend = new CmdPacket();
      data = this.sconn.clientCMD.setSendmsg2serverPacket(this.user.getUin(),
	  message);
      this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.
	  clientCMD.sendsmg2server, lastseq, data));
    }
    else if (user.getStatus().equals("secure")) {
      //tcp = new TCPconnect(this.sconn);
      //tcp.sendEncryptmsg(message, user);
    }
    //this.dispose();
  }
//-----------------------------------------------------
}