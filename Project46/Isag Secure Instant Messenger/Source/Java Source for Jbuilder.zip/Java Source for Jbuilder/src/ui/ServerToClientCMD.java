package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class ServerToClientCMD {
  final int srv_hello = 0x00000001;
  final int srv_goodbye = 0x00000002;
  final int srv_families = 0x00010003;
  final int srv_rates = 0x00010007;
  final int unknown = 0x000b0002;
  final int srv_replyinfo = 0x0001000f;
  final int srv_motd = 0x00010013;
  final int srv_families2 = 0x00010018;
  final int srv_replylocation = 0x00020003;
  final int srv_snac3_1 = 0x00030001;
  final int srv_replybuddy = 0x00030003;
  final int srv_useonline = 0x0003000b;
  final int srv_useroffline = 0x0003000c;
  final int srv_snac4_1 = 0x00040001;
  final int srv_replyicbm = 0x00040005;
  final int srv_recvmsg = 0x00040007;
  final int srv_snac4_12 = 0x0004000c;
  final int srv_replybos = 0x00090003;
  final int srv_replylists = 0x00130003;
  final int srv_replyroster = 0x00130006;
  final int srv_updateack = 0x0013000e;
  final int srv_replyrosterok = 0x0013000f;
  final int srv_auth_req = 0x00130019;
  final int srv_authgranted = 0x0013001b;
  final int srv_addedyou = 0x0013001c;
  final int srv_toicqerr = 0x00150001;
  final int srv_fromicqsrv = 0x00150003;
  final int srv_offlinemsg = 0x00150004;
  final int srv_doneofflinemsgs = 0x00150005;
//	final int srv_meta
//	final int srv_metageneraldone
//	final int srv_metamoredone
//	final int srv_metaaboutdone
//	final int srv_metapassdone
//	final int srv_metawork
//	final int srv_metaabout
//	final int srv_metamoreemail
//	final int srv_metainterest
//	final int srv_metabackground
//	final int srv_metainfo
//	final int srv_meta270
  final int srv_metafound = 0x000000aa;
  final int srv_metalast = 0x000000ab;
  final int srv_metageneral = 0x000000ac;
  final int srv_metamore = 0x000000ad;
//	final int srv_metarandom
//	final int srv_metarandomdone
  final int srv_recrefused = 0x00170001;
  final int srv_newuin = 0x00170005;
  //---------------------------------------------------------------------
  public ServerToClientCMD() {
  }
  //--------------------------------------------------------------------
}