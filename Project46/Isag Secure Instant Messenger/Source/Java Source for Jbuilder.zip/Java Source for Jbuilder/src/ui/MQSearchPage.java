package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MQSearchPage
    extends JFrame {
  MQServerConnect mqcon;
  JPanel contentPane;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel1 = new JLabel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JTextField jTextField5 = new JTextField();
  private Vector searchresult;

  //Construct the frame
  public MQSearchPage(MQServerConnect mqcon) {
    this.mqcon=mqcon;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(SearchPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(460, 222));
    this.setTitle("IsagQ Search Engine");
    jPanel1.setLayout(null);
    jPanel3.setLayout(null);
    jLabel1.setBorder(titledBorder2);
    jLabel1.setText("");
    jLabel1.setBounds(new Rectangle(340, 33, 100, 120));
    jButton1.setBounds(new Rectangle(350, 55, 80, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Add");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(350, 100, 80, 25));
    jButton2.setText("Close");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Add for a user by E-mail Address");
    jLabel2.setBounds(new Rectangle(15, 35, 204, 16));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("Search for a user by ID");
    jLabel4.setBounds(new Rectangle(15, 35, 137, 16));
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(15, 65, 285, 45));
    jLabel6.setText("E-mail Address");
    jLabel6.setBounds(new Rectangle(20, 80, 90, 15));
    jLabel11.setBorder(BorderFactory.createEtchedBorder());
    jLabel11.setBounds(new Rectangle(15, 65, 285, 45));
    jLabel12.setText("ID #");
    jLabel12.setBounds(new Rectangle(75, 80, 35, 15));
    jPanel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jPanel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setBounds(new Rectangle(10, 10, 320, 200));
    jTextField1.setBounds(new Rectangle(115, 78, 175, 20));
    jTextField5.setBounds(new Rectangle(115, 78, 120, 20));
    contentPane.add(jTabbedPane1, null);
    jTabbedPane1.add(jPanel1, " E-mail ");
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(jTextField1, null);
    jPanel3.add(jLabel4, null);
    jPanel3.add(jLabel11, null);
    jPanel3.add(jLabel12, null);
    jPanel3.add(jTextField5, null);
    jTabbedPane1.add(jPanel3, "	 ID	 ");
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }

//--------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    if (jTabbedPane1.getSelectedIndex() == 0) { //search by email
      short lastseq;
      byte[] data;
      try {
        String email=jTextField1.getText();

        mqcon.send(mqcon.req_add,"");
        data=mqcon.recieve();
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0x00;

        if((data[0]==0x03)&&(data[5]==0x34)){
          mqcon.send(mqcon.send_mail,email+"$");
          data=mqcon.recieve();
          data[1] = 0x00;
          data[2] = 0x00;
          data[3] = 0x00;
          data[4] = 0x00;

          if((data[0]==0x03)&&(data[5]==0x38)){
            JOptionPane.showMessageDialog(null,"Add contact list by E-Mail successfully","Add contact list",JOptionPane.INFORMATION_MESSAGE);
          }
        }
      }
      catch (Exception ex) {
        JOptionPane.showMessageDialog(null,ex.toString(),"Error warning",JOptionPane.ERROR_MESSAGE);
      }
    }
    //-------------------------------------------------------------
    else if (jTabbedPane1.getSelectedIndex() == 1) { //search by id
      short lastseq;
      byte[] data;
      try {
        String id=jTextField5.getText();

        mqcon.send(mqcon.req_add_id, "");
        data=mqcon.recieve();
        data[1]=0x00;
        data[2]=0x00;
        data[3]=0x00;
        data[4]=0x00;
        if ((data[0]==0x03)&&(data[5]==0x33)) {//public byte[] res_add_id={0x03,0x00,0x00,0x00,0x00,0x33,0x00};
          mqcon.send(mqcon.send_id, id + "$");
          data=mqcon.recieve();
          data[1]=0x00;
          data[2]=0x00;
          data[3]=0x00;
          data[4]=0x00;
          if ((data[0]==0x03)&&(data[5]==0x37)) {//public byte[] res_id={0x03,0x00,0x00,0x00,0x00,0x37,0x00};
            JOptionPane.showMessageDialog(null,"Add contact list by ID successfully","Add contact list",JOptionPane.INFORMATION_MESSAGE);
          }
        }
      }
      catch (Exception ex) {
        JOptionPane.showMessageDialog(null,ex.toString(),"Error warning",JOptionPane.ERROR_MESSAGE);
      }
    }
    //-------------------------------------------------------------
  }

  void jButton2_actionPerformed(ActionEvent e) {
    this.dispose();
    this.mqcon.logonpage.mainPage.setList2();
  }

//--------------------------------------------------------
}
