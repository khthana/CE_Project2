package ui;

import javax.net.ssl.*;
import java.net.*;
import java.io.*;
import java.awt.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MQServerConnect {
  public LogonPage logonpage;
  public String serverIP;
  public int port;
  public DataOutputStream output;
  public DataInputStream input;
  public SSLSocketFactory sockfac;
  public SSLSocket socket;
  public SSLContext qctx;

  //register command
  public byte[] req_regis={0x01,0x00,0x00,0x00,0x00,0x10,0x00}; //client cmd
  public byte[] res_regis={0x01,0x00,0x00,0x00,0x00,0x11,0x00}; //server cmd
  public byte[] send_regis={0x01,0x00,0x00,0x00,0x00,0x12,0x00}; //client cmd
  public byte[] get_regis_id={0x01,0x00,0x00,0x00,0x00,0x13,0x00}; //server cmd

  //login command
  public byte[] req_login={0x02,0x00,0x00,0x00,0x00,0x21,0x00}; //client cmd
  public byte[] res_login={0x02,0x00,0x00,0x00,0x00,0x22,0x00}; //server cmd
  public byte[] vrf_login={0x02,0x00,0x00,0x00,0x00,0x23,0x00}; //client cmd, verify login
  public byte[] get_contact={0x02,0x00,0x00,0x00,0x00,0x24,0x00}; //server cmd, get contact list from server

  //add contact list by email
  public byte[] req_add={0x03,0x00,0x00,0x00,0x00,0x32,0x00};
  public byte[] res_add={0x03,0x00,0x00,0x00,0x00,0x34,0x00};
  public byte[] send_mail={0x03,0x00,0x00,0x00,0x00,0x36,0x00};
  public byte[] res_mail={0x03,0x00,0x00,0x00,0x00,0x38,0x00};

  //add contact list by id
  public byte[] req_add_id={0x03,0x00,0x00,0x00,0x00,0x31,0x00};
  public byte[] res_add_id={0x03,0x00,0x00,0x00,0x00,0x33,0x00};
  public byte[] send_id={0x03,0x00,0x00,0x00,0x00,0x35,0x00};
  public byte[] res_id={0x03,0x00,0x00,0x00,0x00,0x37,0x00};


  //ping status and get contact list for find new online user
  public byte[] req_status={0x05,0x00,0x00,0x00,0x00,0x51,0x00};
  public byte[] res_status={0x05,0x00,0x00,0x00,0x00,0x52,0x00};

  //log out
  public byte[] req_logout={0x07,0x00,0x00,0x00,0x00,0x71,0x00};
  //delete admin
  public byte[] req_del_id={(byte)0x0a,0x00,0x00,0x00,0x00,(byte)0xa1,0x00};
  public byte[] res_del_id={(byte)0x0a,0x00,0x00,0x00,0x00,(byte)0xa2,0x00};

  //delete contact
  public byte[] req_del={(byte)0x0b,0x00,0x00,0x00,0x00,(byte)0xb1,0x00};
  public byte[] res_del={(byte)0x0b,0x00,0x00,0x00,0x00,(byte)0xb2,0x00};

  //change nickname
  public byte[] req_nick={0x04,0x00,0x00,0x00,0x00,0x41,0x00};
  public byte[] res_nick={0x04,0x00,0x00,0x00,0x00,0x42,0x00};


  public MQServerConnect(String IPtmp,int porttmp,SSLContext ctx,LogonPage p) {
    try{
      this.serverIP = IPtmp;
      this.port = porttmp;
      //this.qctx=ctx;
      this.sockfac = ctx.getSocketFactory();
      this.logonpage=p;

    }catch(Exception e){
      e.printStackTrace();
    }
  }

  public void connect(){
    try{
      //sockfac = this.qctx.getSocketFactory();
      this.socket = (SSLSocket) this.sockfac.createSocket(this.serverIP, this.port);
      this.socket.startHandshake();
      output=new DataOutputStream(this.socket.getOutputStream());
      input=new DataInputStream(this.socket.getInputStream());
      byte[] recieve=new byte[512];
      input.read(recieve);
    }catch(Exception e){
      e.printStackTrace();
    }
  }

  public void close(){
    try{
      socket.close();
    }catch(Exception e){
    }
  }

  public boolean isconnect(){
    return socket.isConnected();
  }

  public void send(byte[] cmdpatn,String message){
    int len=message.length()+7;
    byte[] sendpatn=new byte[len];
    for(int i=0;i<=6;i++){
      sendpatn[i]=cmdpatn[i];
    }
    for(int i=7;i<len;i++){
      sendpatn[i]=(byte)message.charAt(i-7);
    }
    sendpatn[3]=(byte)(len/256); //set data lenght to header
    sendpatn[4]=(byte)(len%256);
    byte[] sendbyte=new byte[512];
    System.arraycopy(sendpatn,0,sendbyte,0,sendpatn.length);
    try{
      output.write(sendbyte); //send information to server
      output.flush();
    }catch(Exception e){
    }
  }

  public byte[] recieve(){
    try{
      byte[] data=new byte[512];
      byte[] data2;
      input.read(data);
      int len1,len2;
      len1=(int)data[3];
      len2=(int)data[4];
      if(len1<0)len1=len1+128;
      if(len2<0)len2=len2+128;
      System.out.println(len1);
      System.out.println(len2);
      int i=(256*len1)+(len2); //find data lenght
      if(i<7)i=7;
      data2=new byte[i];
      System.arraycopy(data,0,data2,0,i);
      System.out.println("data2 length "+data2.length);
      System.out.println("data length "+data.length);
      for(int j=0;j<7;j++){
        System.out.print((int)data[j]+" ");
      }
      System.out.println();
      return data2;
    }catch(Exception e){
      return null;
    }
  }

}