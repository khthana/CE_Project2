package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.net.ssl.*;
import java.security.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

//server trust certificate password at line 143

public class MQDeleteUser extends JFrame {
  JComboBox jComboBox1 = new JComboBox();
  JPasswordField jPasswordField1 = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  FileInputStream fi;
  Properties isagquser;
  JPasswordField jPasswordField2 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  LogonPage logonPage;

  public MQDeleteUser() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    contentPane=(JPanel)this.getContentPane();
    jComboBox1.setDoubleBuffered(false);
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(250, 220));
    this.setTitle("Delete IsagQ user");
    jComboBox1.setBounds(new Rectangle(121, 28, 109, 21));
    jPasswordField1.setBounds(new Rectangle(121, 61, 109, 21));
    jButton1.setBounds(new Rectangle(39, 147, 73, 25));
    jButton1.setVerifyInputWhenFocusTarget(true);
    jButton1.setText("Delete");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });

    jButton2.setBounds(new Rectangle(142, 147, 73, 25));
    jButton2.setText("Close");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    try {
      this.fi = new FileInputStream("./activeuser/isagquser");
      this.isagquser = new Properties();
      this.isagquser.load(fi);
      fi.close();
      if (!this.isagquser.isEmpty()) {
        Enumeration e = this.isagquser.propertyNames();
        while (e.hasMoreElements()) {
          this.jComboBox1.addItem(e.nextElement());
        }
        this.jComboBox1.setSelectedIndex(0);
      }
    }
    catch (IOException e) {}

    jLabel1.setText("ID");
    jLabel1.setBounds(new Rectangle(56, 33, 22, 15));
    jLabel2.setText("Password");
    jLabel2.setBounds(new Rectangle(57, 65, 54, 15));
    jPasswordField2.setText("");
    jPasswordField2.setBounds(new Rectangle(121, 91, 109, 21));
    jLabel3.setText("Confirm password");
    jLabel3.setBounds(new Rectangle(20, 94, 92, 15));
    contentPane.add(jPasswordField2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton1, null);
  }
  //-----------------------------------------------------
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }


  void jButton1_actionPerformed(ActionEvent e){
    char[] passwd1;
    char[] passwd2;
    passwd1=jPasswordField1.getPassword();
    passwd2=jPasswordField2.getPassword();
    String passst1=new String(passwd1);
    if(passst1.equals(new String(passwd2))){
      try {
        String nickname = jComboBox1.getSelectedItem().toString();
        this.fi = new FileInputStream("./activeuser/isagquser");
        this.isagquser = new Properties();
        this.isagquser.load(fi);
        fi.close();
        String filename = (String) isagquser.get(nickname);
        this.fi = new FileInputStream("./activeuser/isagserver");
        this.isagquser = new Properties();
        this.isagquser.load(fi);
        fi.close();
        String serverIP = (String) isagquser.get(nickname);
        this.fi = new FileInputStream("./activeuser/isagport");
        this.isagquser = new Properties();
        this.isagquser.load(fi);
        fi.close();
        int port = Integer.parseInt( (String) isagquser.get(nickname));
        char[] pwd1=jPasswordField1.getPassword();

        SSLContext ctx = SSLContext.getInstance("SSLv3");
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new FileInputStream(filename),pwd1);
        //ks.load(null, pwd1);
        //java.security.cert.Certificate clicert=Certificate.importCertificate(new File(filename));
        //ks.setCertificateEntry("clientkey",clicert);
        kmf.init(ks, "654321".toCharArray());

        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
        KeyStore ts = KeyStore.getInstance(KeyStore.getDefaultType());
        char[] pswd = "654321".toCharArray(); //server trust certificate password
        //ts.load(new FileInputStream("./cert/server.key"),pswd);
        ts.load(null, pswd);
        java.security.cert.Certificate cert=Certificate.importCertificate(new File("./cert/ca.pem"));
        ts.setCertificateEntry("mqtrust",cert);
        tmf.init(ts);

        ctx.init(kmf.getKeyManagers(),tmf.getTrustManagers(),null);
        MQServerConnect mqcon=new MQServerConnect(serverIP,port,ctx,null);
        mqcon.connect();
        mqcon.send(mqcon.req_del_id,"");
        byte[] data=mqcon.recieve();
        data[3]=0x00;
        data[4]=0x00;
        for(int i=0;i<data.length;i++){
          System.out.print((int)data[i]+" ");
        }
        System.out.println();
        if((data[0]==(byte)0x0a)&&(data[5]==(byte)0xa2)){
          FileInputStream fi = new FileInputStream("./activeuser/isagquser");
          Properties isagquser = new Properties();
          isagquser.load(fi);
          fi.close();
          isagquser.remove(nickname);
          this.outPropertiesTofile(isagquser, "./activeuser/isagquser");

          fi = new FileInputStream("./activeuser/isagserver");
          isagquser = new Properties();
          isagquser.load(fi);
          fi.close();
          isagquser.remove(nickname);
          this.outPropertiesTofile(isagquser, "./activeuser/isagserver");

          fi = new FileInputStream("./activeuser/isagport");
          isagquser = new Properties();
          isagquser.load(fi);
          fi.close();
          isagquser.remove(nickname);
          this.outPropertiesTofile(isagquser, "./activeuser/isagport");

          JOptionPane.showMessageDialog(null,"Delete user id successfully","Delete user",JOptionPane.INFORMATION_MESSAGE);
        }
        else{
          JOptionPane.showMessageDialog(null,"Delete user error","Delete user",JOptionPane.INFORMATION_MESSAGE);
        }
        mqcon.close();

      }catch(Exception ex){
        ex.printStackTrace();
      }

    }else{
      JOptionPane.showMessageDialog(null,"Password not match","Error warning",JOptionPane.ERROR_MESSAGE);
    }

  }
  //------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e){
    logonPage = new LogonPage();
    logonPage.show();
    this.dispose();
  }

  public void outPropertiesTofile(Properties a, String filename) {
  try {
    FileOutputStream fo;
    fo = new FileOutputStream(filename);
    a.store(fo, filename);
    fo.close();
  }
  catch (IOException rt) {}
}

}