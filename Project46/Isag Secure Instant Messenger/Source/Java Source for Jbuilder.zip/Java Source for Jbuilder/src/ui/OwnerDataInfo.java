package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.math.*;
import java.security.*;
import javax.crypto.spec.*;
import java.math.*;
import java.security.spec.*;
import javax.crypto.*;

public class OwnerDataInfo {
  private static Properties p;
  private static String myIPaddress;
  private static Vector myContactlist;
  private static Vector onlinelist;
  private static Vector offlinelist;
  private static Vector securelist;
  private static String password;
  private static String language;
  private static String icqversion;
  private static byte[] cookies;
  private static PrivateKey privatekey;
  private static short idInGroup;
  private static String uin;
  private static String nickname;
  private static byte[] cookiep2p;
  private static String internal_ip;
  private static String external_ip;
  private static String status;
  private static String lastname;
  private static String firstname;
  private static String email;
  private static String gender;
  private static int age;
  private static String authorize;
  private static short tcpconnectport;
  private static PublicKey publickey;
  private static SecretKey secretkey;
  private static String city;
  private static String state;
  private static String country;
  private static String zipcode;
  private static String phone;
  private static String fax;
  private static String street;
  private static String cellular;
  private static String homepage;
  private static String year;
  private static String month;
  private static String day;
  private static String dhPublicValue;

  public OwnerDataInfo() {
    this.status = "offline";
    this.nickname = " ";
    this.language = "en";
    this.setCountry("us");
    this.icqversion = "icq2002a";
    p = new Properties();
  }

//------------------------------------------------------------
  public static void setdhPublicValue(String dhvalue) {
    dhPublicValue = dhvalue;
  }

//------------------------------------------------------------
  public static String getdhPublicValue() {
    return dhPublicValue;
  }

//------------------------------------------------------------
  public static void removeProperties() {

  }

//------------------------------------------------------------
  public static void addProperties(UserData user) {
    p.put(user.getUin(), user);
  }

//------------add all user in contactlist to properties ------------------------
  public static void setProperties() {
    UserData user;
    user = new UserData();
    int sizecontact;
    int c;
    sizecontact = OwnerDataInfo.getMyContactlist().size();
    for (c = 0; c < sizecontact; c++) { //-------------- add other user in contactlist to properties------------------
      user = (UserData) OwnerDataInfo.getMyContactlist().elementAt(c);
      p.put(user.getUin(), user);
    }
  }

//------------------------------------------------------------
  public static Properties getProperties() {
    return p;
  }

//------------------------------------------------------------
  public static void setPrivateKey(PrivateKey prikey) {
    privatekey = prikey;
  }

//-----------------------------------------------------------
  public static PrivateKey getPrivatekey() {
    return privatekey;
  }

//-----------------------------------------------------------
  public static String getMyIPaddress() {
    return myIPaddress;
  }

//-----------------------------------------------------------
  public static void setmyIPaddress(String ip) {
    myIPaddress = ip;
  }

//-------------------------------------------------------
  public static Vector getSecurelist() {
    return securelist;
  }

//-------------------------------------------------------
  public static Vector getOfflinelist() {
    return offlinelist;
  }

//-------------------------------------------------------
  public static Vector getOnlinelist() {
    return onlinelist;
  }

//-----------------------------------------------------
  public static void setSecurelist(Vector secure) {
    securelist = secure;
  }

//-----------------------------------------------------
  public static void setOfflinelist(Vector offline) {
    offlinelist = offline;
  }

//-----------------------------------------------------
  public static void setOnlinelist(Vector online) {
    onlinelist = online;
  }

//-----------------------------------------------------
  public static Vector getMyContactlist() {
    return myContactlist;
  }

//-----------------------------------------------------
  public static void setMyContactlist(Vector contactlist) {
    myContactlist = contactlist;
  }

//-----------------------------------------------------
  public static void setPassword(String passwd) {
    password = passwd;
  }

//---------------------------------------------------
  public static byte[] getencryptPassword() throws IOException {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    int temp = 0, i;
    for (i = 0; i < password.length(); i++) {
      temp = password.charAt(i);

      if (i == 0) {
	temp = temp ^ (int) 0xf3;
      }
      else if (i == 1) {
	temp = temp ^ (int) 0x26;
      }
      else if (i == 2) {
	temp = temp ^ (int) 0x81;
      }
      else if (i == 3) {
	temp = temp ^ (int) 0xc4;
      }
      else if (i == 4) {
	temp = temp ^ (int) 0x39;
      }
      else if (i == 5) {
	temp = temp ^ (int) 0x86;
      }
      else if (i == 6) {
	temp = temp ^ (int) 0xdb;
      }
      else if (i == 7) {
	temp = temp ^ (int) 0x92;
      }
      else if (i == 8) {
	temp = temp ^ (int) 0x71;
      }
      else if (i == 9) {
	temp = temp ^ (int) 0xa3;
      }
      else if (i == 10) {
	temp = temp ^ (int) 0xb9;
      }
      else if (i == 13) {
	temp = temp ^ (int) 0xe6;
      }
      else if (i == 14) {
	temp = temp ^ (int) 0x53;
      }
      else if (i == 15) {
	temp = temp ^ (int) 0x7a;
      }
      else if (i == 16) {
	temp = temp ^ (int) 0x95;
      }
      else if (i == 17) {
	temp = temp ^ (int) 0x7c;
      }
      dataOut.writeByte(temp);
    }
    return byteOut.toByteArray();
  }

//-------------------------------------------------------
  public static String getStringPassword() {
    return password;
  }

//-----------------------------------------------------------
  public static byte[] getCookies() {
    return cookies;
  }

//-----------------------------------------------------------
  public static void setCookies(byte[] cook) {
    cookies = new byte[cook.length];
    cookies = cook;
  }

//-----------------------------------------------------------
  public static String getLanguage() {
    return language;
  }

//------------------------------------------------------------
  public static String icqversion() {
    return icqversion;
  }

//-----------------------------------------------------------
  //----------------------------------------------------------
  public static void setPublicKey(PublicKey pubkey) {
    publickey = pubkey;
  }

//----------------------------------------------------------
  public static void setDay(String day1) {
    day = day1;
  }

//----------------------------------------------------------
  public static String getDay() {
    return day;
  }

//----------------------------------------------------------
  public static void setMonth(String month1) {
    month = month1;
  }

//----------------------------------------------------------
  public static String getMonth() {
    return month;
  }

//----------------------------------------------------------
  public static void setYear(String year1) {
    year = year1;
  }

//----------------------------------------------------------
  public static String getYear() {
    return year;
  }

//----------------------------------------------------------
  public static void setHomepage(String homepage1) {
    homepage = homepage1;
  }

//----------------------------------------------------------
  public static String getHomepage() {
    return homepage;
  }

//----------------------------------------------------------
  public static void setCellular(String cellular1) {
    cellular = cellular1;
  }

//----------------------------------------------------------
  public static String getCellular() {
    return cellular;
  }

//----------------------------------------------------------
  public static void setStreet(String street1) {
    street = street1;
  }

//----------------------------------------------------------
  public static String getStreet() {
    return street;
  }

//----------------------------------------------------------
  public static void setFax(String fax1) {
    fax = fax1;
  }

//----------------------------------------------------------
  public static String getFax() {
    return fax;
  }

//----------------------------------------------------------
  public static void setPhone(String phone1) {
    phone = phone1;
  }

//----------------------------------------------------------
  public static String getPhone() {
    return phone;
  }

//----------------------------------------------------------
  public static void setCity(String city1) {
    city = city1;
  }

//----------------------------------------------------------
  public static String getCity() {
    return city;
  }

//----------------------------------------------------------
  public static void setZipcode(String zipcode1) {
    zipcode = zipcode1;
  }

//----------------------------------------------------------
  public static String getZipcode() {
    return zipcode;
  }

//----------------------------------------------------------
  public static void setState(String state1) {
    state = state1;
  }

//----------------------------------------------------------
  public static String getState() {
    return state;
  }

//----------------------------------------------------------
  public static void setCountry(String country1) {
    country = country1;
  }

//----------------------------------------------------------
  public static String getCountry() {
    return country;
  }

//------------------------------------------------------------
  public static byte[] getPublickeyBytes() {
    byte[] publicKeyBytes = publickey.getEncoded();
    return publicKeyBytes;
  }

//----------------------------------------------------------------------

  public static void setSecretKey(SecretKey seckey) {
    secretkey = seckey;
  }

//----------------------------------------------------------
  public static PublicKey getPublickey() {
    return publickey;
  }

//----------------------------------------------------------
  public static SecretKey getSecretKey() {
    return secretkey;
  }

//----------------------------------------------------------
  public static short getIdInGroup() {
    return idInGroup;
  }

//----------------------------------------------------------
  public static void setIdInGroup(short id) {
    idInGroup = id;
  }

//----------------------------------------------------------
  public static String getNickname() {
    return nickname;
  }

//-----------------------------------------------------------
  public static void setNickname(String nickname1) {
    nickname = nickname1;
  }

//-----------------------------------------------------------
  public static short getTcpconnectport() {
    return tcpconnectport;
  }

//-----------------------------------------------------------
  public static void setTcpconnectport(short port) {
    tcpconnectport = port;
  }

//-----------------------------------------------------------
  public static byte[] getCookiep2p() {
    return cookiep2p;
  }

//-----------------------------------------------------------
  public static void setCookiep2p(byte[] cookie) {
    cookiep2p = cookie;
  }

//-----------------------------------------------------------
  public static void setStatus(String status1) {
    status = status1;
  }

//-----------------------------------------------------------
  public static String getStatus() {
    return status;
  }

//-----------------------------------------------------------
  public static String getExternal_ip() {
    return external_ip;
  }

//-----------------------------------------------------------
  public static void setExternal_ip(String ip) {
    external_ip = ip;
  }

//-----------------------------------------------------------
  public static void setInternal_ip(String ip) {
    internal_ip = ip;
  }

//-----------------------------------------------------------
  public static void setUin(String uin1) {
    uin = uin1;
  }

//------------------------------------------------------------
  public static String getInternal_ip() {
    return internal_ip;
  }

//-----------------------------------------------------------
  public static String getUin() {
    return uin;
  }

//-------------------------------------------------------------
  public static String getLastname() {
    return lastname;
  }

//---------------------------------------------------------------
  public static String getFirstname() {
    return firstname;
  }

//---------------------------------------------------------------
  public static String getEmail() {
    return email;
  }

//---------------------------------------------------------------
  public static String getGender() {
    return gender;
  }

//---------------------------------------------------------------
  public static int getAge() {
    return age;
  }

//---------------------------------------------------------------
  public static String getAuthorize() {
    return authorize;
  }

//-------------------------------------------------------
  public static void setLastname(String lastname1) {
    lastname = lastname1;
  }

//----------------------------------------------------------
  public static void setFirstname(String firstname1) {
    firstname = firstname1;
  }

//-----------------------------------------------------------
  public static void setEmail(String email1) {
    email = email1;
  }

//------------------------------------------------------------
  public static void setGender(String gender1) {
    gender = gender1;
  }

//------------------------------------------------------------
  public static void setAge(int age1) {
    age = age1;
  }

//------------------------------------------------------------
  public static void setAuthorize(String authorize1) {
    authorize = authorize1;
  }
//---------------------------------------------------------------
}