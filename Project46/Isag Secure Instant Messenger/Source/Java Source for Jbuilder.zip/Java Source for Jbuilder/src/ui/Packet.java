package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

abstract class Packet {
  protected HeadPacket header;
  protected byte[] data;
  abstract byte[] setPacket(int cmd, short seq, byte[] data);

  abstract byte[] getCookie();

  abstract void analytePacket(byte[] packet);

  public Packet() {
  }
}