package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SearchInfo {
  private int uin;
  private String status;
  private String nickname;
  private String lastname;
  private String firstname;
  private String email;
  private String gender;
  private int age;
  private String authorize;
  public SearchInfo() {
  }

//-------------------------------------------------------
  public void setStatus(String status) {
    this.status = status;
  }

//-------------------------------------------------------
  public void setUin(int uin) {
    this.uin = uin;
  }

//-------------------------------------------------------
  public void setNickname(String nickname) {
    this.nickname = nickname;
  }

//-------------------------------------------------------
  public void setLastname(String lastname) {
    this.lastname = lastname;
  }

//----------------------------------------------------------
  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

//-----------------------------------------------------------
  public void setEmail(String email) {
    this.email = email;
  }

//------------------------------------------------------------
  public void setGender(String gender) {
    this.gender = gender;
  }

//------------------------------------------------------------
  public void setAge(int age) {
    this.age = age;
  }

//------------------------------------------------------------
  public void setAuthorize(String authorize) {
    this.authorize = authorize;
  }

//-------------------------------------------------------------
  public String getNickname() {
    return this.nickname;
  }

//----------------------------------------------------------------
  public int getUin() {
    return this.uin;
  }

//-------------------------------------------------------------
  public String getLastname() {
    return this.lastname;
  }

//---------------------------------------------------------------
  public String getFirstname() {
    return this.firstname;
  }

//---------------------------------------------------------------
  public String getEmail() {
    return this.email;
  }

//---------------------------------------------------------------
  public String getGender() {
    return this.gender;
  }

//---------------------------------------------------------------
  public int getAge() {
    return this.age;
  }

//---------------------------------------------------------------
  public String getAuthorize() {
    return this.authorize;
  }

//---------------------------------------------------------------
  public String getStatus() {
    return this.status;
  }
//---------------------------------------------------------------
}