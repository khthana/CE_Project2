package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class RemoveUser
    extends JFrame {
  RemoveConfirm removeConfirm;
  RemoveFail removeFail;
  LogonPage logonPage;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JComboBox jComboBox1 = new JComboBox();

  //Construct the frame
  public RemoveUser() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    logonPage = new LogonPage();
    this.setComboBoxNickname();
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //--------------------------------------------------------------------------
  public void setComboBoxNickname() {
    try {
      FileInputStream fi = new FileInputStream("./activeuser/activeuser");
      Properties activeuser = new Properties();
      activeuser.load(fi);
      fi.close();
      if (!activeuser.isEmpty()) {
	Enumeration e = activeuser.propertyNames();
	while (e.hasMoreElements()) {
	  this.jComboBox1.addItem(e.nextElement());
	}
	this.jComboBox1.setSelectedIndex(0);
      }
    }
    catch (IOException e) {}
  }

  //--------------------------------------------------------------------------
  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(RemoveUser.class.getResource("[Your Icon]")));
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(290, 160));
    this.setTitle("Remove user from this computer");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("User :");
    jLabel1.setBounds(new Rectangle(45, 38, 65, 20));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Password :");
    jLabel2.setBounds(new Rectangle(45, 65, 65, 20));
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(115, 65, 120, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Please enter user's password.");
    jLabel3.setBounds(new Rectangle(5, 5, 180, 20));
    /*jComboBox1.addItem("Nol");
       jComboBox1.addItem("Nut");
       jComboBox1.addItem("Pee");
       jComboBox1.addItem("Poon");*/
    //jComboBox1.setSelectedIndex(0);
    jButton1.setBounds(new Rectangle(65, 100, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(140, 100, 75, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
	jButton2_actionPerformed(e);
      }
    });
    jComboBox1.setBounds(new Rectangle(115, 38, 120, 20));
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jComboBox1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }

//-----------------------------------------------------------------------------
  public byte[] getencryptPassword(String password) throws IOException {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    DataOutputStream dataOut = new DataOutputStream(byteOut);
    int temp = 0, i;
    for (i = 0; i < password.length(); i++) {
      temp = password.charAt(i);

      if (i == 0) {
	temp = temp ^ (int) 0xf3;
      }
      else if (i == 1) {
	temp = temp ^ (int) 0x26;
      }
      else if (i == 2) {
	temp = temp ^ (int) 0x81;
      }
      else if (i == 3) {
	temp = temp ^ (int) 0xc4;
      }
      else if (i == 4) {
	temp = temp ^ (int) 0x39;
      }
      else if (i == 5) {
	temp = temp ^ (int) 0x86;
      }
      else if (i == 6) {
	temp = temp ^ (int) 0xdb;
      }
      else if (i == 7) {
	temp = temp ^ (int) 0x92;
      }
      else if (i == 8) {
	temp = temp ^ (int) 0x71;
      }
      else if (i == 9) {
	temp = temp ^ (int) 0xa3;
      }
      else if (i == 10) {
	temp = temp ^ (int) 0xb9;
      }
      else if (i == 13) {
	temp = temp ^ (int) 0xe6;
      }
      else if (i == 14) {
	temp = temp ^ (int) 0x53;
      }
      else if (i == 15) {
	temp = temp ^ (int) 0x7a;
      }
      else if (i == 16) {
	temp = temp ^ (int) 0x95;
      }
      else if (i == 17) {
	temp = temp ^ (int) 0x7c;
      }
      dataOut.writeByte(temp);
    }
    return byteOut.toByteArray();
  }

//---------------------------------------------------------------------------
  public Properties InputfileToproperties(String filename) {
    try {
      FileInputStream fi = new FileInputStream(filename);
      Properties a = new Properties();
      a.load(fi);
      fi.close();
      return a;
    }
    catch (IOException rt) {}
    return null;
  }

//-----------------------------------------------------------------------------
  public void outPropertiesTofile(Properties a, String filename) {
    try {
      FileOutputStream fo = new FileOutputStream(filename);
      a.store(fo, "My Properties File");
      fo.close();
    }
    catch (IOException rt) {}
  }

//-----------------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    System.out.println("Remove User");
    char[] pwd = jPasswordField1.getPassword();
    String password = new String(pwd);
    byte[] passwdbyte;
    String realpasswd;
    String uin;
    String nick = this.jComboBox1.getSelectedItem().toString();
    try {

      Properties activeuser = new Properties();
      activeuser = this.InputfileToproperties("./activeuser/activeuser");

      uin = (String) activeuser.get(nick);

      Properties activeuserdetail = new Properties();
      activeuserdetail = this.InputfileToproperties(
	  "./activeuser/activeuserdetail");

      realpasswd = (String) activeuserdetail.get(uin);
      password = new String(this.getencryptPassword(password));
//-----------------------------------------------------------------
      if (realpasswd.equals(password)) {
	activeuser.remove(nick);
	activeuserdetail.remove(uin);
	this.outPropertiesTofile(activeuser, "./activeuser/activeuser");
	this.outPropertiesTofile(activeuserdetail,
				 "./activeuser/activeuserdetail");
	this.setComboBoxNickname();
	this.dispose();
	logonPage = new LogonPage();
	logonPage.show();
	dispose();
//------------------------------------------------------------
      }
      else {
	String title = "Remove user Fail";
	String result = "Password Error Please try again";
	this.logonPage.messageBox = new MessageBox(title, result);
	this.logonPage.messageBox.show();
      }
    }
    catch (Exception ez) {}
  }

  void jButton2_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }
}