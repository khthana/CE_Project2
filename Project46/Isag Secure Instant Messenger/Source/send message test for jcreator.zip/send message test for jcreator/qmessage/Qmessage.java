package myprojects.qmessage;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import com.borland.jbcl.layout.*;
import java.io.*;
import java.util.*;
import java.net.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Qmessage
    extends JFrame {
  JPanel contentPane;
  private Vector user;
  DiffieHellman dh;
  Socket qcon;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JTextArea jTextArea1 = new JTextArea();
  JTextArea jTextArea2 = new JTextArea();
  JScrollPane jScrollPane1 = new JScrollPane(jTextArea1);
  JLabel jLabel5 = new JLabel();
  JScrollPane jScrollPane2 = new JScrollPane(jTextArea2);
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private int seq=0;
  private int ack=0;
  private SecretKey secretKey;
  boolean encrypt=false;
  private DataInputStream input;
  private DataOutputStream output;
  private String myname;
  private String dhParam2;
  private boolean check=true;

  private byte[] key_req={0x10,0x00,0x00,0x00,0x00,(byte)0xc1,0x00};
  private byte[] key_getpub={0x10,0x00,0x00,0x00,0x00,(byte)0xc2,0x00};
  private byte[] key_res={0x10,0x00,0x00,0x00,0x00,(byte)0xc3,0x00};
  private byte[] msg_send={0x11,0x00,0x00,0x00,0x00,(byte)0xd1,0x00};
  private byte[] window_close={0x11,0x00,0x00,0x00,0x00,(byte)0xd2,0x00};


  //Construct the frame
  public Qmessage(Socket qcon,Vector u,String myname,boolean keymake) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.qcon=qcon;
    this.user = u;
    this.myname= myname;
    try{
      output=new DataOutputStream(qcon.getOutputStream());
      input=new DataInputStream(qcon.getInputStream());
    }catch(Exception e1){
    }
    try {
      jbInit();
      if(keymake){
        this.keygen_req();
      }
    }catch(ConnectException con){
      try{
        input.close();
        output.close();
        qcon.close();
        JOptionPane.showMessageDialog(null,"Another user close connection, if you press button, this window will close","Connection close",JOptionPane.ERROR_MESSAGE);
        dispose();
      }catch(Exception ex){}
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MessagePage.class.getResource("[Your Icon]")));
    String uin = (String)user.get(0);
    String nick = (String)user.get(1);
    if (uin == null) {
      uin = "";
    }
    if (nick == null) {
      nick = "";
    }
    contentPane = (JPanel)this.getContentPane();
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setBounds(new Rectangle(5, 6, 430, 210));
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(449, 371));
    this.setTitle("Message page : Chat with \""+nick+"\"");
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("To :	 UIN#");
    jLabel2.setBounds(new Rectangle(15, 15, 55, 20));
    jTextField1.setText(uin);
    jTextField1.setBounds(new Rectangle(75, 15, 106, 20));
    jTextField1.setEnabled(false);
    jTextField1.setDisabledTextColor(Color.blue);
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Nick :");
    jLabel3.setBounds(new Rectangle(195, 15, 35, 20));
    jTextField2.setText(nick);
    jTextField2.setBounds(new Rectangle(230, 15, 195, 20));
    jTextField2.setEnabled(false);
    jTextField2.setDisabledTextColor(Color.blue);
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.
                                              HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane1.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane1.setBounds(new Rectangle(15, 45, 410, 160));
    jScrollPane1.setAutoscrolls(true);
    jTextArea1.setBorder(BorderFactory.createLoweredBevelBorder());
    jTextArea1.setDisabledTextColor(Color.red);
    jTextArea1.setEditable(false);
    jTextArea1.setText("");
    jScrollPane1.add(jTextArea1);
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(5, 220, 430, 120));
    jScrollPane2.setHorizontalScrollBarPolicy(JScrollPane.
                                              HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane2.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane2.setBounds(new Rectangle(15, 230, 410, 60));
    jScrollPane2.setAutoscrolls(true);
    jTextArea2.setText("");
    jScrollPane2.add(jTextArea2);
    jButton1.setBounds(new Rectangle(105, 305, 90, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Send");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        try {
          jButton1_actionPerformed(e);
        }
        catch (Exception ea) {
          System.out.println(ea.getMessage());
        }
      }
    });
    jButton2.setBounds(new Rectangle(215, 305, 90, 25));
    jButton2.setText("Gen key");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jScrollPane1.getViewport().add(jTextArea1, null);
    jScrollPane2.getViewport().add(jTextArea2, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel1, null);
    
    dh=new DiffieHellman();
    //contentPane.add(jTextArea2,	new XYConstraints(141, 260, 32, 14));
    //contentPane.add(jTextArea1,	new XYConstraints(20, 63, 403, 154));
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      try{
        byte[] data = window_close;
        data = packet_gen(data, "");
        if (encrypt) {
          data=doencrypt(data);
        }
        //output.write(data);
        send(data);
        input.close();
        output.close();
        qcon.close();
      }
      catch (Exception ex) {
      }
      dispose();
    }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    /*try {
      byte[] data = window_close;
      data = packet_gen(data, "");
      if (encrypt) {
        data=doencrypt(data);
      }
      //output.write(data);
      send(data);
      input.close();
      output.close();
      qcon.close();
    }
    catch (Exception ex) {
    }
    dispose();*/
    this.keygen_req();
  }

//----------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) throws IOException {
    String message;
    short lastseq;
    byte[] data;
    message = this.jTextArea2.getText();
    jTextArea1.append(this.myname+" say :\n"+message+"\n\n");
    jTextArea2.setText("");
    data=msg_send;
    data=packet_gen(data,message);
    if(encrypt){
      data=doencrypt(data);
	}
    //output.write(data);
    send(data);
  }
//-----------------------------------------------------
  void keygen_res(byte[] publicKey){//responce of other's key gen request , state 4
    try{
    	String sendtmp="";
      if (encrypt) {
        byte[] header=key_res;
        //header=packet_gen(header,sendtmp);
        header=packet_gen(header,publicKey);
        header=doencrypt(header);
        //output.write(header);
        send(header);
      }
      else {
        byte[] header=key_res;
        //header=packet_gen(header,sendtmp);
        header=packet_gen(header,publicKey);
        //output.write(header);
        send(header);
        System.out.println("send publicKey");
      }
    }catch(Exception ex){}
  }

  void keygen_recieve(byte[] publicKey){//other request to gen key ,state 5
    secretKey=dh.generateSecretKey(publicKey);
    encrypt=true;
  }

  void keygen_req(){//request to gen key , state 1
    System.out.println("gen dh");
  	dh=new DiffieHellman();
    String dhParams=dh.genDhParams();
    dh.generateKeypair(dhParams);
    System.out.println("gen keypair");
    try{
      if (encrypt) {
        byte[] header=key_req;
        header=packet_gen(header,dhParams);
        header=doencrypt(header);
        //output.write(header);
        send(header);
        header=key_getpub;
        byte[] bytetmp=dh.getPublicKey().getEncoded();
        //String sendtmp="";
    	//System.out.println(new String(bytetmp));
    	//System.out.println(sendtmp);
        //header=packet_gen(header,sendtmp);
        header=packet_gen(header,bytetmp);
        header=doencrypt(header);
        //output.write(header);
        send(header);

      }
      else {
        byte[] header=key_req;
        header=packet_gen(header,dhParams);
        //output.write(header);
        send(header);
        System.out.println("send dhParams "+dhParams);
        header=key_getpub;
        byte[] bytetmp=dh.getPublicKey().getEncoded();
        //String sendtmp="";
    	//System.out.println("integer "+Integer.toHexString((int)bytetmp[0]));
    	//System.out.println("integer "+Integer.toHexString((int)bytetmp[1]));
    	//System.out.println("integer "+(int)bytetmp[0]);
    	//System.out.println("integer "+(int)bytetmp[1]);
    	//System.out.println("integer "+(int)bytetmp[2]);
    	//System.out.println(new String(bytetmp));
    	//System.out.println(sendtmp);
        //header=packet_gen(header,sendtmp);
        header=packet_gen(header,bytetmp);
        System.out.println("send publickey"+dh.getPublicKey().toString());
        //output.write(header);
        send(header);
      }
    }catch(Exception ex){
    	ex.printStackTrace();}
  }

  void keygen_reqres(String dhParams2){//responce of keygen_req ,state 2
  	System.out.println("recieve dhParam");
    this.dhParam2=dhParam2;
    //System.out.println(dhParams2);
    dh.generateKeypair(dhParams2);
  }

  void keygen_getpub(byte[] publicKeyOther){//state 3
    System.out.println("recieve publickey");
    System.out.println(new String(publicKeyOther));
    keygen_res(dh.getPublicKey().getEncoded());
    secretKey=dh.generateSecretKey(publicKeyOther);
    System.out.println("gen secretkey finish");
    encrypt=true;
  }

  byte[] packet_gen(byte[] header,String packet){
    int len=header.length+packet.length();
    int i=len;
    if((len%16)!=0){
            i=i+(16-(len%16));
    }
    //byte[] tmp=new byte[i];
    byte[] tmp=new byte[1024];
    System.arraycopy(header,0,tmp,0,7);
    for(int j=0;j<len-7;j++){
      tmp[j+7]=(byte)packet.charAt(j);
    }
    for(int j=len;j<1024;j++){
            tmp[j]=(byte)(Math.round(Math.random())%256);
    }

    tmp[3]=(byte)(len/256);
    tmp[4]=(byte)(len%256);
    tmp[1]=(byte)(seq/256);
    tmp[2]=(byte)(seq%256);
    seq++;
    if(seq==65536){
      seq=0;
    }
    return tmp;
  }

  byte[] packet_gen(byte[] header,byte[] packet){
    int len=header.length+packet.length;
    int i=len;
    if((len%16)!=0){
            i=i+(16-(len%16));
    }
    //byte[] tmp=new byte[i];
    byte[] tmp=new byte[1024];
    System.arraycopy(header,0,tmp,0,7);
    System.arraycopy(packet,0,tmp,7,len-7);
    for(int j=len;j<1024;j++){
            tmp[j]=(byte)(Math.round(Math.random())%256);
    }
    tmp[3]=(byte)(len/256);
    tmp[4] = (byte) (len % 256);
    tmp[1] = (byte) (seq / 256);
    tmp[2] = (byte) (seq % 256);
    seq++;
    if(seq==65536){
      seq=0;
    }
    return tmp;
  }

  byte[] doencrypt(byte[] text){
    try{
      byte[] raw = secretKey.getEncoded();
      SecretKeySpec skeySpec = new SecretKeySpec(raw, "DES");
      Cipher cipher = Cipher.getInstance("DES");

      cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
      text=cipher.doFinal(text);
      return text;
    }catch(Exception e){return null;}

  }

  byte[] dodecrypt(byte[] text){
    try{
      byte[] raw = secretKey.getEncoded();
      SecretKeySpec skeySpec = new SecretKeySpec(raw, "DES");
      Cipher cipher = Cipher.getInstance("DES");

      cipher.init(Cipher.DECRYPT_MODE, skeySpec);
      System.out.println("decrypt");
      text=cipher.doFinal(text);
      System.out.println();
      System.out.println(new String(text));
      return text;
    }catch(Exception e){return null;}

  }

  void startresponce(){
    byte[] data=new byte[16];
    byte[] data2=new byte[7];
    byte[] data3;
    int len;
    int ack2;
    int channel;
    byte command;
    int canread;
    byte[] datatmp;
    int[] tmp=new int[4];
    try{
      while (check) {
      	if(encrypt){
      		data=new byte[1032];
      	}else{
      		data=new byte[1024];
      	}
      	data2=new byte[7];
      	try{
      		/*int pos=0;
        	while((canread=input.read())!=-1){
        		data[pos]=(byte)canread;
        		pos++;
        	}*/
        	input.read(data);
        	System.out.println("test");
        	//datatmp=new byte[pos];
        	//System.arraycopy(data,0,datatmp,0,pos);
        	//data=datatmp;
        	//input.read(data);
        }catch(InterruptedIOException interrupted){
        	continue;
        }catch(IOException io){
        	break;
        }
        if(data!=null){
	        System.out.println(new String(data));
	        if(encrypt){
	          data=dodecrypt(data);
	        }
	        for(int i=0;i<4;i++){
	        	tmp[i]=(int)data[i+1];
	        	if(tmp[i]<0)tmp[i]=tmp[i]+256;
	        }
	        ack2=(tmp[0]*256)+tmp[1];
	        len=(tmp[2]*256)+tmp[3];
	        System.out.println("recieve");
	        System.out.println(ack2+" "+len);
	        if(ack!=ack2){
	          input.close();
	          output.close();
	          qcon.close();
	          JOptionPane.showMessageDialog(this,"Found packet replay,\nConnection to "+user.get(1)+" close","Packet replay",JOptionPane.ERROR_MESSAGE);
	          check=false;
	        }else{
	          ack++;
	          data3=new byte[len-7];
	          System.arraycopy(data,0,data2,0,7);
	          System.arraycopy(data,7,data3,0,len-7);
	          /*if(len>16){
	            System.arraycopy(data,7,data3,0,9);
	            int len2=len-16;
	            if((len2%16)!=0){
	              len2=len2+(16-(len2%16));
	            }
	            data=new byte[len2];
	            input.read(data);
	            if(encrypt){
	              data=dodecrypt(data);
	            }
	            System.arraycopy(data,0,data3,9,len-16);
	          }else{
	            System.arraycopy(data,7,data3,0,len-7);
	          }*/
	          data2[1]=0x00;
	          data2[2]=0x00;
	          data2[3]=0x00;
	          data2[4]=0x00;
	          channel=(int)data2[0];
	          command=data2[5];
	          if((channel==16)&&(command==(byte)0xc1)){//key_req
	            keygen_reqres(new String(data3));
	          }else if((channel==16)&&(command==(byte)0xc2)){//key_getpub
	            keygen_getpub(data3);
	          }else if((channel==16)&&(command==(byte)0xc3)){//key_res
	            keygen_recieve(data3);
	          }else if((channel==17)&&(command==(byte)0xd1)){//msg_send
	            if(!this.isShowing()){this.show();}
	            jTextArea1.append(((String)user.get(1))+" says :\n");
	            jTextArea1.append(new String(data3));
	            jTextArea1.append("\n\n");
	          }else if((channel==17)&&(command==(byte)0xd2)){
	            jTextArea1.append("Another user close connection.\nIf you want to talk more, please close this window and reopen again.");
	                check=false;
	          }else{
	            input.close();
	            output.close();
	            qcon.close();
	            jTextArea1.append("Found error in packet, connection close.\nIf you want to talk more, please close this window and reopen again.");
	            //dispose();
	          }
        	}
        }
      }
    }catch(Exception e){}
  }

//-----------------------------------------------------

	private void send(byte[] input){
		try{
			output.write(input);
			//output.close();
			//output=new DataOutputStream(qcon.getOutputStream());
		}catch(Exception e){}
	}
}
