package myprojects.qmessage;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.UIManager;
class start {
	
	/**
	 * Method main
	 *
	 *
	 * @param args
	 *
	 */
	public static void main(String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			serverthread[] server1=new serverthread[30];
			Thread thread1;
			
			ServerSocket serversocket=new ServerSocket(17001);
	  		Vector user=new Vector();
	  		user.add("123456789");
	  		user.add("ob the air");
	  		String myname="other2";
	  		for(int i=0;i<30;i++){
		  		//while(true){ 
		  			//thread1=new Thread(new server(socket,user,myname));
		  			//thread1.run();
		  			server1[i]=new serverthread(serversocket.accept(),user,myname,false);
		  			server1[i].start();
		  			System.out.println("window close");
		  			//server1.makeInputStream();
		  			//server1.startresponce();
		  			//server1.show();
		  		//}
		  	}
		}
		catch(Exception e){
		}
	}	
}
