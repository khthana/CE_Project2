package myprojects.qmessage;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.UIManager;
class startclient {
	
	/**
	 * Method main
	 *
	 *
	 * @param args
	 *
	 */
	public static void main(String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			Socket socket=new Socket("localhost",17001);
	  		Vector user=new Vector();
	  		user.add("777777777");
	  		user.add("other2");
	  		String myname="ob the air";
	  		Qmessage client1;
	  		client1=new Qmessage(socket,user,myname,true);
	  		client1.show();
	  		//client1.keygen_req();
	  		System.out.println("show");
	  		client1.startresponce();
		}
		catch(Exception e){
		}
	}	
}
