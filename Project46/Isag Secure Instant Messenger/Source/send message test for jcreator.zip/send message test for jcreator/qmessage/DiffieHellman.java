package myprojects.qmessage;

import java.security.*;
import javax.crypto.spec.*;
import java.math.*;
import java.security.spec.*;
import javax.crypto.*;
import java.net.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class DiffieHellman {
  private PrivateKey privateKey;
  private PublicKey publicKey;
  public DiffieHellman() {
  }

//----------------------------------------------------------------------
  public PublicKey getPublicKey() {
    return this.publicKey;
  }

//----------------------------------------------------------------------
  public PrivateKey getPrivateKey() {
    return this.privateKey;
  }

//----------------------------------------------------------------------
  public String genDhParams() {
    try {
      // Create the parameter generator for a 1024-bit DH key pair
      AlgorithmParameterGenerator paramGen = AlgorithmParameterGenerator.
	  getInstance("DH");
      paramGen.init(512);

      // Generate the parameters
      AlgorithmParameters params = paramGen.generateParameters();
      DHParameterSpec dhSpec = (DHParameterSpec) params.getParameterSpec(
	  DHParameterSpec.class);
      // Return the three values in a string
      return "" + dhSpec.getP() + "," + dhSpec.getG() + "," + dhSpec.getL();
    }
    catch (NoSuchAlgorithmException e) {
      System.out.println(e.getMessage());
    }
    catch (InvalidParameterSpecException e) {
      System.out.println(e.getMessage());
    }
    return null;
  }

//----------------------------------------------------------------------------
  public void generateKeypair(String valuesInStr) {
    //String valuesInStr = this.genDhParams() ;
    String[] values = valuesInStr.split(",");
    BigInteger p = new BigInteger(values[0]);
    BigInteger g = new BigInteger(values[1]);
    int l = Integer.parseInt(values[2]);
    try {
      // Use the values to generate a key pair
      KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DH");
      DHParameterSpec dhSpec = new DHParameterSpec(p, g, l);
      keyGen.initialize(dhSpec);
      KeyPair keypair = keyGen.generateKeyPair();

      // Get the generated public and private keys
      this.privateKey = keypair.getPrivate();
      this.publicKey = keypair.getPublic();
    }
    catch (java.security.InvalidAlgorithmParameterException e) {}
    catch (java.security.NoSuchAlgorithmException e) {}
  }

//--------------------------------------------------------------------------
 public SecretKey generateSecretKey(byte[] publicKeyBytesother){
   try{
      PublicKey publicKeyother ;

      //Convert the public key bytes into a PublicKey object
      X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKeyBytesother);
      KeyFactory keyFact = KeyFactory.getInstance("DH");
      publicKeyother = keyFact.generatePublic(x509KeySpec);
      //------------------------------------------------
      System.out.println(publicKeyother.toString());
      //------------------------------------------------

      // Prepare to generate the secret key with the private key and public key of the other party
      KeyAgreement ka = KeyAgreement.getInstance("DH");
      ka.init(privateKey);
      ka.doPhase(publicKeyother,true);
      //Specify the type of key to generate;
      //see e458 Listing All Available Symmetric Key Generators
      String algorithm = "DES";

      // Generate the secret key
      SecretKey secretKey = ka.generateSecret(algorithm);
      System.out.println(secretKey.toString());
      System.out.println("keygen");
      return secretKey ;
   }
   catch (java.security.InvalidKeyException e) {System.out.println(e.getMessage());}
   catch (java.security.spec.InvalidKeySpecException e) {System.out.println(e.getMessage());}
   catch (java.security.NoSuchAlgorithmException e) {System.out.println(e.getMessage());}
   return null ;
 }

//--------------------------------------------------------------------------
  public SecretKey generateSecretKey(String valuesInStr,
				     byte[] publicKeyFromOther, Qmessage mpage) {
	String value=valuesInStr;
	System.out.println(value);
    String[] values = valuesInStr.split(",");
    System.out.println("test key");
    BigInteger p = new BigInteger(values[0]);
    System.out.println("test key");
    BigInteger g = new BigInteger(values[1]);
    System.out.println("test key");
    int l = Integer.parseInt(values[2]);
    try {
      // Use the values to generate a key pair
      KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DH");
      DHParameterSpec dhSpec = new DHParameterSpec(p, g, l);
      keyGen.initialize(dhSpec);
      KeyPair keypair = keyGen.generateKeyPair();

      // Get the generated public and private keys
      PrivateKey privateKey = keypair.getPrivate();
      PublicKey publicKey = keypair.getPublic();

      // Send the public key bytes to the other party...
      byte[] publicKeyBytes = publicKey.getEncoded();

      /*Socket remoteOut = other;
      DataOutputStream out = new DataOutputStream(remoteOut.getOutputStream());*/
      byte[] packetbyte;
      //mpage.keygen_req(publicKeyBytes);
      //remoteOut.close();

      // Retrieve the public key bytes of the other party

      //-------------------comment-----------------------------
      publicKeyBytes = publicKeyFromOther;
      //--------------------------------------------------------
      // Convert the public key bytes into a PublicKey object
      X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKeyBytes);
      KeyFactory keyFact = KeyFactory.getInstance("DH");
      publicKey = keyFact.generatePublic(x509KeySpec);

      // Prepare to generate the secret key with the private key and public key of the other party
      KeyAgreement ka = KeyAgreement.getInstance("DH");
      ka.init(privateKey);
      ka.doPhase(publicKey, true);

      // Specify the type of key to generate;
      // see e458 Listing All Available Symmetric Key Generators
      String algorithm = "DES";

      // Generate the secret key
      SecretKey secretKey = ka.generateSecret(algorithm);
      return secretKey;
      // Use the secret key to encrypt/decrypt data;
      // see e462 Encrypting a String with DES
    }
    catch (java.security.InvalidKeyException e) {}
    catch (java.security.spec.InvalidKeySpecException e) {}
    catch (java.security.InvalidAlgorithmParameterException e) {}
    catch (java.security.NoSuchAlgorithmException e) {}
    catch(Exception e){}
    //catch (IOException e) {}
    return null;
  }
//-------------------------------------------------------------------------

}