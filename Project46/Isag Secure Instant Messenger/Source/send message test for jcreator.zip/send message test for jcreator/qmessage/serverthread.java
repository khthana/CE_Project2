package myprojects.qmessage;

import java.net.*;
import java.util.*;

public class serverthread extends Thread {
	Qmessage server1;
	public serverthread(Socket qcon,Vector u,String myname,boolean keygen){
		server1=new Qmessage(qcon,u,myname,keygen);
	}
	public void run(){
		server1.startresponce();
	}
}
