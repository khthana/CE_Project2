package netsimulator;

class Switch2950 extends Switch{

  public Switch2950(String swName){
    SwitchName = chkAndsetSwitchName(swName);

    createPort(0,12,0);
    switchMacAddress = IntEthernet.genMacAddress();
    Switch.setBridgeID(switchMacAddress);
    bridgeID = priority+"."+switchMacAddress;
    vlan.setDefault();
    vlan.initVlanMember(this.getEport());
    vVlan.add(vlan);
    addressLearning = new AddressLearning(this);
    addressLearning.start();
    cdp.start();

  }// end Switch(string)

}//End Switch2950