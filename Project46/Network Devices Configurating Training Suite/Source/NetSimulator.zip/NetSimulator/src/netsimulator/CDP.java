package netsimulator;

import java.util.*;

class CDP extends Thread{

  private Router rt = null;
  private Switch sw = null;

  private int cdp_timer = 900;
  private int cdp_hold = 180;

  private Vector vRouterNeightbor = new Vector();
  private Vector vSwitchNeightbor = new Vector();

//constructor ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  public CDP(String str){
    super(str);
  }
  public CDP(Router routerIn){
    rt = routerIn;
  }
  public CDP(Switch switchIn){
    sw = switchIn;
  }

  public void run(){
    try {
      while (true){
        update();
        Thread.sleep(cdp_timer);
      }
    }catch (InterruptedException interrupt) {}
  }

  public void update(){
    this.vRouterNeightbor.removeAllElements();
    this.vSwitchNeightbor.removeAllElements();

    if (rt != null){
      for (int index_sport = 0; index_sport < rt.getSport().size(); index_sport++){
        IntSerial int_S = (IntSerial)rt.getSport().elementAt(index_sport);
        String connectwith = int_S.getConnectionWith();
        if (!(connectwith.equalsIgnoreCase(""))){
          if (connectwith.charAt(0)=='R'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Router rt_temp = Frame1.getClassRouter(r_name);
            this.vRouterNeightbor.add(rt_temp);
          }else if(connectwith.charAt(0)=='S'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Switch sw_temp = Frame1.getClassSwitch(r_name);
            this.vSwitchNeightbor.add(sw_temp);
          }//end device
        }//end connected
      }//end for serial port

      for (int index_eport = 0; index_eport < rt.getEport().size(); index_eport++){
        IntEthernet int_E = (IntEthernet)rt.getEport().elementAt(index_eport);
        String connectwith = int_E.getConnectionWith();
        if (!(connectwith.equalsIgnoreCase(""))){
          if (connectwith.charAt(0)=='R'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Router rt_temp = Frame1.getClassRouter(r_name);
            this.vRouterNeightbor.add(rt_temp);
          }else if(connectwith.charAt(0)=='S'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Switch sw_temp = Frame1.getClassSwitch(r_name);
            this.vSwitchNeightbor.add(sw_temp);
          }//end device
        }//end connected
      }//end for ethernet port
    }//end router

    if(sw != null){
      this.vRouterNeightbor.removeAllElements();
      this.vSwitchNeightbor.removeAllElements();

      for (int index_eport = 0; index_eport < sw.getEport().size(); index_eport++){
        IntEthernet int_E = (IntEthernet)sw.getEport().elementAt(index_eport);
        String connectwith = int_E.getConnectionWith();
        if (!(connectwith.equalsIgnoreCase(""))){
          if (connectwith.charAt(0)=='R'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Router rt_temp = Frame1.getClassRouter(r_name);
            this.vRouterNeightbor.add(rt_temp);
          }else if(connectwith.charAt(0)=='S'){
            String r_name = RouterConsole.cutInput(connectwith,0);
            Switch sw_temp = Frame1.getClassSwitch(r_name);
            this.vSwitchNeightbor.add(sw_temp);
          }//end device
        }//end connected
      }//end for ethernet port
    }//end switch

//    sw.setVectorRouterNB(this.vRouterNeightbor);
//    sw.setVectorSwitchNB(this.vSwitchNeightbor);

  }//end update()

  public void stopCDP(){
    Thread.interrupted();
  }

  public void setCdpTimer(int time){
    cdp_timer = time;
  }
  public int getCdpTimer(){
    return cdp_timer;
  }

  public void setCdpHold(int time){
    cdp_hold = time;
  }
  public int getCdpHold(){
    return cdp_hold;
  }

  public Vector getRouterNB(){
    return vRouterNeightbor;
  }

  public Vector getSwitchNB(){
    return vSwitchNeightbor;
  }

}//end class