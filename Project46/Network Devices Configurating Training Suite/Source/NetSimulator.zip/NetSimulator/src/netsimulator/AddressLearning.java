package netsimulator;

import java.util.*;

class AddressLearning extends Thread{

  private Switch sw;

  static  Vector vChkAlready = new Vector();
  private Vector vRouterNeightbor = new Vector();
  private Vector vSwitchNeightbor = new Vector();

  private int time_sleep = 24*1000; //(Sec) default 120 sec but test in 12

  private Vector vMac_Address_Table = new Vector();
  private Vector vVlan_per_interface = new Vector();

//constructor ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  public AddressLearning(String str){
    super(str);
  }

  public AddressLearning(Switch switchIn){
    sw = switchIn;
  }

//Method ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  public Vector getMacAddressTable(){
    return vMac_Address_Table;
  }

  public Vector getVlan_per_interface(){
    return vVlan_per_interface;
  }

  public void run(){
    try {
      while (true){
        update();
        Thread.sleep(time_sleep);
      }
    }catch (InterruptedException interrupt) {}
  }

  public void update(){
    vMac_Address_Table.removeAllElements();
    vVlan_per_interface.removeAllElements();

    //chkAlready?
    for (int swIndex = 0; swIndex < AddressLearning.vChkAlready.size(); swIndex++){
      String sw_uniname = AddressLearning.vChkAlready.elementAt(swIndex).toString();
      if (!(sw.getSwitchUniName().equalsIgnoreCase(sw_uniname))){
        AddressLearning.vChkAlready.add(sw.getSwitchUniName());  //S0, S1, S2,...
      }//end if
    }//end for

    //own interface
    for (int portIndex = 0; portIndex < sw.getEport().size(); portIndex++){
      IntEthernet intE = (IntEthernet)sw.getEport().elementAt(portIndex);

      if (!(intE.getConnectInformation().equalsIgnoreCase(""))){
        vMac_Address_Table.add(intE.getConnectInformation()); //mac address
        vVlan_per_interface.add(""+intE.getVLAN()); //keep vlan num to string
      }//end chk connection
    }//end for

  }//end update()

  public void stopLearning(){
    Thread.interrupted();
  }

  //-------- LOOKUP TABLE --------------------------------
  public boolean lookupTable(String ip){
    boolean found_dest = false;
    String macaddress = arp(ip);

    for (int indexMac = 0; indexMac < this.vMac_Address_Table.size(); indexMac++){
      String mac_chk = this.vMac_Address_Table.elementAt(indexMac).toString();
      if (macaddress.equalsIgnoreCase(mac_chk)){
        found_dest = true;
      }//end if
    }//end for (found in own switch)

    if(found_dest){
      //if true chk vlan
    }else {
      int rtnb_size = sw.getVectorRouterNB().size();
      int swnb_size = sw.getVectorSwitchNB().size();

      for (int rt_nb = 0; rt_nb < rtnb_size; rt_nb++){
        Router rt_temp = (Router)sw.getVectorRouterNB().elementAt(rt_nb);
        String uni = rt_temp.getRouterUniName();
        if (!(chkAlready(uni))){
          AddressLearning.vChkAlready.add(uni);
          //find destination of router here
        }//end if
      }//end for search router

      for (int sw_nb = 0; sw_nb < sw.getVectorSwitchNB().size(); sw_nb++){
        Switch sw_temp = (Switch)sw.getVectorSwitchNB().elementAt(sw_nb);
        String uni = sw_temp.getSwitchUniName();
        if (!(chkAlready(uni))){
          AddressLearning.vChkAlready.add(uni);
          found_dest = sw_temp.findDestination(ip);
        }//end if
      }
    }

  return found_dest;
}//end lookup table

public boolean chkAlready(String uni){
  boolean chk = false;
  for (int index = 0; index < AddressLearning.vChkAlready.size(); index++){
    String chk_uni = AddressLearning.vChkAlready.elementAt(index).toString();
    if (chk_uni.equalsIgnoreCase(uni)){
      chk = true;
    }//end if
  }//end chk
  return chk;
}


//-------- ARP IP TO MAC ADDRESS -----------------------
static String arp(String ip){
  String mac = "ffff.ffff.ffff";

  for (int count = 0; count < Frame1.vHost.size(); count++){
    Host ho = (Host)Frame1.vHost.elementAt(count);
    String ip_chk = ho.getHostIPAddress();
    if (ip_chk.equalsIgnoreCase(ip)){
      mac = ho.hostMacAddress;
    }//end if
  }//end for

  for (int count = 0; count < Frame1.vSwitch.size(); count++){
    Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
    for (int index = 0; index < sw.getEport().size(); index++){
      IntEthernet et = (IntEthernet)sw.getEport().elementAt(index);
      String ip_chk = et.getIPAddress();
      if (ip_chk.equalsIgnoreCase(ip)){
        mac = sw.getSwitchMacAddress();
      }//end if
    }//end for
  }//end for

  for (int count = 0; count < Frame1.vRouter.size(); count++){
    Router rt = (Router)Frame1.vRouter.elementAt(count);
    for (int index = 0; index < rt.getEport().size(); index++){
      IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
      String ip_chk = et.getIPAddress();
      if (ip_chk.equalsIgnoreCase(ip)){
        mac = rt.getRouterMacAddress();
      }//end if
    }//end for
    for (int index = 0; index < rt.getSport().size(); index++){
      IntSerial se = (IntSerial)rt.getSport().elementAt(index);
      String ip_chk = se.getIPAddress();
      if (ip_chk.equalsIgnoreCase(ip)){
        mac = rt.getRouterMacAddress();
      }//end if
    }//end for
  }//end for
  return mac;
}//end arp

/*  public String rarp(String mac){
    String ip = "0.0.0.0";

    for (int count = 0; count < Frame1.vHost.size(); count++){
      Host ho = (Host)Frame1.vHost.elementAt(count);
      String mac_chk = ho.getHostMacAddress();
      if (mac_chk.equalsIgnoreCase(mac)){
        ip = ho.getHostIPAddress();
      }//end if
    }//end for

    for (int count = 0; count < Frame1.vSwitch.size(); count++){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
      String mac_chk = sw.getSwitchMacAddress();
      if (mac_chk.equalsIgnoreCase(mac)){
        ip = sw.getMacAddress();
      }//end if

    }//end for

    for (int count = 0; count < Frame1.vRouter.size(); count++){
      Router rt = (Router)Frame1.vRouter.elementAt(count);
      for (int index = 0; index < rt.getEport().size(); index++){
        IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
        String ip_chk = et.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = et.getMacAddress();
        }//end if
      }//end for
      for (int index = 0; index < rt.getSport().size(); index++){
        IntSerial se = (IntSerial)rt.getSport().elementAt(index);
        String ip_chk = se.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = rt.getRouterMacAddress();
        }//end if
      }//end for
    }//end for
    return mac;
  }//end arp*/


}//end class