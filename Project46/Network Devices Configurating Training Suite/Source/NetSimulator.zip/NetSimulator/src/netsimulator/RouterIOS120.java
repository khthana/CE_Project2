package netsimulator;

import java.lang.*;
import java.util.*;
import java.util.Date;
import java.util.Timer;

class RouterIOS120 {

  private Router router;
  private RouterConsole Rconsole;
  private String flagConfig = "";
  private String error = "";
  private final String cmdError = "% Invalid input detected at '^' marker.";
  private final String ambigous = "% Ambiguous Command :";
  //used command
  public final String[] userMode = new String[]{"?","help","enable","exit","ping arg_ip_name","show cdp","show cdp entry *","show cdp entry arg_name","show cdp interface","show cdp neighbors","tracerouter arg_ip_name"};
  public final String[] privMode = new String[]{"?","help","clock set arg_time arg_date arg_month arg_year","configure terminal","copy running_config startup_config","copy startup-config running-config","debug ip rip","disable","erase startup-config","ping arg_ip_name","show history","show cdp","show cdp entry arg_name","show cdp entry *","show cdp interface","show cdp neighbors","show ip route","show ip rip database","show ip ospf database","show ip route arg_routetype","show running config","show startup config","show version","show interface","show interface arg_typeint","show ip protocol","show ip ospf neighbors","show ip ospf interface arg_intname","terminal editing","terminal no editing","undebug ip rip"};
  public final String[] configMode = new String[] {"?","help","cdp timer arg_time","enable secret arg_string","exit","hostname arg_string","interface arg_intname","ip route arg_ip arg_ip arg_ip","ip classless","ip host arg_name arg_ip","ip ospf cost arg_name arg_num","line vty 0 4","line auxilary 0","line console 0","no enable secret","no banner login","no ip route arg_ip arg_ip arg_ip","no ip classless","no router arg_protocol","router arg_protocol arg_num","router arg_protocol"};
  public final String[] interfaceMode = new String[] {"?","help","bandwidth arg_num","cdp","clock rate arg_num","description","end","exit","interface arg_intname","ip address arg_ip arg_ip","no shutdown","ring-speed arg_num","shutdown"};
  public final String[] routerMode = new String[] {"?","help","exit","network arg_ip","passive-interface arg_intname","no passive-interface arg_intname","no network arg_ip","no distribute-list arg_gateway"};
  public final String[] lineMode = new String[] {"?","help","exit","login","password arg_string","no login"};

  private Vector commandArgu = new Vector();
  private int arguSize = 0;

  private Vector cmdListArgu = new Vector();
  private int listSize = 0;

  private Vector ipRoute = new Vector();
  private Vector ipRouteDetail = new Vector();

  private String cmdList[] = null;

  public RouterIOS120() {}  // default Constructor()

  public void runCommand(Router router_tmp, String fullRoutercmd,RouterConsole console) {
    router = router_tmp;
    Rconsole = console;

    switch (router.getMode()){
      case 1 : cmdList = userMode;break;
      case 2 : cmdList = privMode;break;
      case 3 : cmdList = configMode;break;
      case 4 : cmdList = interfaceMode;break;
      case 5 : cmdList = routerMode;break;
      case 6 : cmdList = lineMode;break;
      default :cmdList = userMode;break;
    }//end switch

    splitCommand(fullRoutercmd);

//-+-+-+-+-+-+-+-+-+-+- RUN -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

//    if (true){//foundcmd) {//for optimize
    try{
      switch (router.getMode()) {

//User Mode +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 1:
          if (chkShortCmd(0,"?") && moreArgu(1)){
            showCmd1(Rconsole);
          } //end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router>help
            showHelp1(Rconsole);
          }//end help
          else if (chkShortCmd(0,"enable","en") && moreArgu(1)){

//Router>enable
            if (router.getPassWordEnable()){
              router.setMode(10);
            }else {
              router.setMode(2);
            }
          } //end enable
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {
            Rconsole.reset();
          } //end exit
          else if (chkShortCmd(0,"ping") && moreArgu(2)) {

//Router>ping <ip>
              ping(commandArgu.elementAt(1).toString());
          } //end ping
          else if (chkShortCmd(0,"show","sh") && moreArgu(4)) {
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"cdp")) {

//Router>show cdp
                  showCDP();
                }else {
                  Rconsole.append(cmdError);
                }//end if
                break;
              case 2:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"interface","int")) {
//Router>show cdp interface
                    showCDP_Interface();
                  }
                  else if (chkShortCmd(2,"neighbors","nb")) {
//Router>show cdp neighbor
                    showCDP_Neighbor();
                  }else {Rconsole.append(cmdError);}
                }else {Rconsole.append(cmdError);}
                break;
              case 3:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"entry","en")) {
                    if (chkShortCmd(3,"*")) {

//Router>show cdp entry *
                      showCDP_Entry_all();
                    }else {

//Router>show cdp entry <deviceName>
                      showCDP_Entry_Name(commandArgu.elementAt(3).toString());
                    }//end if
                  }else {Rconsole.append(cmdError);}
                }else {Rconsole.append(cmdError);}
                break;
            } //end switch
          } //end show
          else if (chkShortCmd(0,"traceroute","trace") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {

//Router>traceroute <ip>
              //router traceroute protocol
            }else {Rconsole.append("Incorrect Destination");}
          }//end traceroute
          else {Rconsole.append(cmdError);
            break;
          }//end if
          break;
// end Mode 1: UserMode ">"

//Privilage Mode +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 2:
          if (chkShortCmd(0,"?") && moreArgu(1)) {
            Rconsole.append("?");
          }//end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router#help
            showHelp2(Rconsole);
          }//end help
          else if (chkShortCmd(0,"clock") && moreArgu(6)){

//Router#clock set <time> <date> <month> <year>
            if (chkShortCmd(1,"set")){
            }
          }
          else if (chkShortCmd(0,"configure","config") && moreArgu(2)) {

//Router#configure terminal
            if (chkShortCmd(1,"terminal","t")){
              router.setMode(3);
              Rconsole.append("Enter Configuration commands, one per line. End with Ctrl-Z");
            }else {
              Rconsole.append(cmdError);
            }
          }//end configure
          else if (chkShortCmd(0,"copy") && moreArgu(3)){
            if (chkShortCmd(1,"running-config","r") && chkShortCmd(2,"startup-config","s")){

//Router#copy running-config startup-config
              Rconsole.append("Building Configuration\n...\n\n[OK]");
            }else if (chkShortCmd(1,"startup-config","s") && chkShortCmd(2,"running-config","r")){

//Router#copy startup-config running-config
              Rconsole.append("Building Configuration\n...\n\n[OK]");
            }else {
              Rconsole.append(cmdError);
            }
          }//end copy
          else if (chkShortCmd(0,"debug") && moreArgu(3)){
            if (chkShortCmd(1,"ip") && chkShortCmd(2,"rip")){

//Router#debug ip rip
              System.out.println("Debug ip rip");
            }else {
              Rconsole.append(cmdError);
            }
          }//end debug
          else if (chkShortCmd(0,"disable","dis") && moreArgu(1)){

//Router#disable
            router.setMode(1);
          }//end disable
          else if (chkShortCmd(0,"erase") && moreArgu(2)){
            if (chkShortCmd(1,"startup-config","s")) {

//Router#erase startup-config
              //erase startup-config
            }else {
              Rconsole.append(cmdError);
            }
          }//end erase
          else if (chkShortCmd(0,"ping") && moreArgu(2)) {

//Router#ping <ip address|hostname>
            if (isIp(commandArgu.elementAt(1).toString())) {
              ping(commandArgu.elementAt(1).toString());
            }else {
             Rconsole.append("Incorrect Destination");
            }
          } //end ping
          else if (chkShortCmd(0,"show","sh") && moreArgu(5)){
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"cdp")) {

//Router#show cdp
                  showCDP();
                }else if (chkShortCmd(1,"history","his")) {

//Router#show history
                  Rconsole.showHistory();
                }else if (chkShortCmd(1,"interface","int")){

//Router#show interface
                  showInterface();
                }else if (chkShortCmd(1,"running-config","run")){

//Router#show running-config
                  showRunningConfig();
                }else if (chkShortCmd(1,"startup-config","start")){

//Router#show startup-config
                  showStartupConfig();
                }else if (chkShortCmd(1,"version","ver")){

//Router#show version
                  showVersion();
                }
                else {
                  Rconsole.append(cmdError);
                }
                break;
              case 2:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"interface","int")) {

//Router#show cdp interface
                    showCDP_Interface();
                  }
                  else if (chkShortCmd(2,"neighbors","nb")) {

//Router#show cdp neighbors
                    showCDP_Neighbor();
                  }
                  else {
                    Rconsole.append(cmdError);
                  }
                }else if (chkShortCmd(1,"interface","int")) {

//Router#show interface
                  showInterface();
                }else if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"protocol","pro")){

//Router#show ip protocol
                    showIP_Protocol();
                  }else if (chkShortCmd(2,"route")){

//Router#show ip route
                    showIP_Route();
                  }
                  else (Rconsole.append(cmdError));
                }
                else {
                  Rconsole.append(cmdError);
                }
                break;
              case 3:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"entry","en")) {
                    if (chkShortCmd(3,"*")) {

//Router#show cdp entry *
                      showCDP_Entry_all();
                    }else {

//Router#show cdp entry <name>
                      showCDP_Entry_Name(commandArgu.elementAt(3).toString());
                    }
                  }else if(chkShortCmd(2,"neighbors","nb")){

//Router#show cdp neighbors
                    showCDP_Neighbor();
                  }else Rconsole.append(cmdError);
                }else if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"ospf")){
                    if (chkShortCmd(3,"database","db")){
//                      Rconsole.append("show ip ospf database");
                    }else if (chkShortCmd(3,"neighbors","nb")){
//                      Rconsole.append("show ip ospf neighbors");
                    }else (Rconsole.append(cmdError));
                  }else if (chkShortCmd(2,"rip")){
                    if (chkShortCmd(3,"database")){
//                      Rconsole.append("show ip rip database");
                    }else (Rconsole.append(cmdError));
                  }else if (chkShortCmd(2,"route")) {

//Router#show ip route
                    showIP_Route();
                  }
                }else Rconsole.append(cmdError);
                break;
              case 4:
                if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"ospf")){
                    if (chkShortCmd(3,"interface","int")){
//                      Rconsole.append("show ip ospf interface "+commandArgu.elementAt(4).toString());
                    }else Rconsole.append(cmdError);
                  }else Rconsole.append(cmdError);
                }else Rconsole.append(cmdError);
                break;
            } //end switch*/
          } //end show
          else if (chkShortCmd(0,"terminal","ter") && moreArgu(3)){
            if (chkShortCmd(1,"editing","edit")){
//              System.out.println("Terminal editing");
            }else if (chkShortCmd(1,"no") && chkShortCmd(2,"editing","edit")) {
//              System.out.println("Terminal no editing");
            }else {
              Rconsole.append(cmdError);
            }
          }//end terminal
          else if (chkShortCmd(0,"traceroute","trace") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {
//              //router traceroute protocol
              System.out.println("traceroute by ip:" +
                                 commandArgu.elementAt(1).toString());
            }
            else { Rconsole.append("Incorrect Destination"); }
          } //end traceroute
          else if (chkShortCmd(0,"undebug","unde") && moreArgu(3)){
            if (chkShortCmd(1,"ip") && chkShortCmd(2,"rip")){
//              System.out.println("Undebug ip rip");
            }else {
              Rconsole.append(cmdError);
            }
          }//end undebug
          else {
            Rconsole.append(cmdError);
            break;
          }//end if
          break;
// end Mode 2: Privilage Mode "#"

//Config Mode ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 3:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router(config)#help
            showHelp3(Rconsole);
          }//end help
          else if (chkShortCmd(0,"cdp","cdp") && moreArgu(3)){

//Router(config)#cdp timer <5-900>
            if (chkShortCmd(1,"timer")){
              try{
                int time = Integer.parseInt(commandArgu.elementAt(2).toString());
                if ((time <= 900)&&(time >= 5)){
                  router.setCdpTimer(time);
                }else{
                  Rconsole.append(cmdError);
                }//end if
              }catch (Exception e) {Rconsole.append(cmdError);}
            }else Rconsole.append(cmdError);
          }//end cdp timer
          else if (chkShortCmd(0,"enable","en") && moreArgu(3)){
            if (chkShortCmd(1,"secret","sec")){

//Router(config)#enable secret <password>
              router.setPassWordEnable(true);
              router.setPassWord(commandArgu.elementAt(2).toString());
            }else Rconsole.append(cmdError);
          }//end enable
          else if (chkShortCmd(0,"exit") && moreArgu(1)){

//Router(config)#exit
            Rconsole.append("%SYS-5-CONFIG_I: Configure from console by console");
            router.setMode(2);
          }//end exit
          else if (chkShortCmd(0,"hostname","hn") && moreArgu(2)){

//Router(config)#hostname <name>
            router.setRouterName(commandArgu.elementAt(1).toString());
            Rconsole.setTitle(" - = "+router.getRouterName()+" Console = - ");
          }//end hostname
          else if (chkShortCmd(0,"interface","int") && moreArgu(2)){

//router(config)#interface xx
            String interfac = commandArgu.elementAt(1).toString();
            String interfaceName = "S0/0";
            char interfaceArray[] = interfac.toCharArray();
            int len = interfac.length();

            if (len > 3 && (interfac.charAt(2)=='/')){
              if (interfac.length() == 3){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3];
              }else if(interfac.length() == 4){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3]+interfaceArray[4];
              }else{}
            }else {
              if (interfac.length() == 2) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1];
              }else if (interfac.length() == 3) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1]+interfaceArray[2];
              }else {}
            }

            if (interfaceName.charAt(0)=='e'){
              interfaceName = "f"+interfaceName;
            }

            if (router.hasInterface(interfaceName)){
              flagConfig = interfaceName;
              router.setMode(4);
            }else{
              Rconsole.append("Interface limited");
            }
          }//end interface
          else if (chkShortCmd(0,"line") && moreArgu(4)){
            if (chkShortCmd(1,"auxilary","aux")){

//router(config)#line auxilary x
              if (chkShortCmd(2,"0")){
                Rconsole.append("line auxilary 0");
                router.setMode(6);
              }else Rconsole.append(cmdError);

//router(config)#line console 0
            }else if (chkShortCmd(1,"console","con")){
              if (chkShortCmd(2,"0")){
                Rconsole.append("line console 0");
                router.setMode(6);
              }else Rconsole.append(cmdError);

//router(config)#line vty 0 4
            }else if (chkShortCmd(1,"vty")){
              if (chkShortCmd(2,"0")){
                if (chkShortCmd(3,"4")){
                  Rconsole.append("line vty 0 4");
                  router.setMode(6);
                }else Rconsole.append(cmdError);
              }else Rconsole.append(cmdError);
            }else Rconsole.append(cmdError);
          }//end line
          else if (chkShortCmd(0,"ip") && moreArgu(5)){

//router(config)#ip classless
            if (chkShortCmd(1,"classless","cl")) {
//              Rconsole.append("ip classless");
            }
            else if (chkShortCmd(1,"host") && moreArgu(4)){
//              Rconsole.append("ip host arg_name arg_ip");
            }
            else if (chkShortCmd(1,"ospf") && moreArgu(5)){
//              Rconsole.append("ip ospf cost arg_name arg_cost");
            }
            else if (chkShortCmd(1,"route") && moreArgu(5)){

//Router(config)#ip route <network> <subnet> <interface>
              if (isIp(commandArgu.elementAt(2).toString())&&
                  isIp(commandArgu.elementAt(3).toString())&&
                  isIp(commandArgu.elementAt(4).toString())){
                String iproute = commandArgu.elementAt(2).toString()+" "+
                    commandArgu.elementAt(3).toString()+" "+
                    commandArgu.elementAt(4).toString();
                this.ipRoute.add(iproute);

                String int_name = "";
                for (int find = 0; find < router.getSport().size(); find++){
                  IntSerial intS = (IntSerial)router.getSport().elementAt(find);
                  if (intS.getIPAddress().equalsIgnoreCase(commandArgu.elementAt(4).toString())){
                    int_name = intS.getS_FullName();
                  }//end if
                }//end for
                for (int find = 0; find < router.getEport().size(); find++){
                  IntEthernet intE = (IntEthernet)router.getEport().elementAt(find);
                  if (intE.getIPAddress().equalsIgnoreCase(commandArgu.elementAt(4).toString())){
                    int_name = intE.getE_FullName();
                  }//end if
                }//end for

                String iproutedetail = " s "+commandArgu.elementAt(2).toString()+" is via[0/"+(this.ipRoute.size()-1)+"] connected, "+int_name+" "+commandArgu.elementAt(3).toString();
                this.ipRouteDetail.add(iproutedetail);
              }else {
                Rconsole.append("ip address invalid");
              }//end chk isIp

            }else Rconsole.append(cmdError);
          }//end ip
          else if (chkShortCmd(0,"no") && moreArgu(6)){
            if (chkShortCmd(1,"banner")){
              if (chkShortCmd(2,"login")) {
//                Rconsole.append("no banner login");
              }else Rconsole.append(cmdError);
            }else if (chkShortCmd(1,"enable","en")){
              if (chkShortCmd(2,"secret","sec")){

//Router(config)#no enable secret
                router.setPassWordEnable(false);

              }else Rconsole.append(cmdError);
            }else if (chkShortCmd(1,"router")){

//Router(config)#no router <protocol>
              if (router.getprotocolInUse().equalsIgnoreCase(commandArgu.elementAt(2).toString())){
                router.setProtocolInUse("");
              }else {}
            }else if (chkShortCmd(1,"ip")){
              switch(arguSize-1){
                  case 2 : if (chkShortCmd(2,"classless","cl")){
//                      Rconsole.append("no ip classless");
                    }else Rconsole.append(cmdError);
                    break;
                  case 5 : if (chkShortCmd(2,"route")){

//Router(config)#no ip route <network> <subnet> <interface>
                      if (isIp(commandArgu.elementAt(3).toString())&&
                          isIp(commandArgu.elementAt(4).toString())&&
                          isIp(commandArgu.elementAt(5).toString())){
                        String iproute_remove  = commandArgu.elementAt(3).toString()+" "+
                            commandArgu.elementAt(4).toString()+" "+
                            commandArgu.elementAt(5).toString();
                        //remove ip from routing table
                        for (int find = 0; find < this.ipRoute.size(); find++){
                          if (iproute_remove.equalsIgnoreCase(ipRoute.elementAt(find).toString())){
                            this.ipRoute.removeElementAt(find);
                            this.ipRouteDetail.removeElementAt(find);
                          }
                        }

                      }else {
                        Rconsole.append("ip address invalid");
                      }//end chk isIp

                    }else Rconsole.append(cmdError);
                    break;
                  }//end switch
            }else Rconsole.append(cmdError);
          }//end no
          else if (chkShortCmd(0,"router") && moreArgu(3)){
            switch(arguSize-1){
              case 1 :

//Router(config)#router <protocol>
                if (router.getprotocolInUse().equalsIgnoreCase("")||
                    router.getprotocolInUse().equalsIgnoreCase(commandArgu.elementAt(1).toString())){
                  if (commandArgu.elementAt(1).toString().equalsIgnoreCase("rip")||
                      commandArgu.elementAt(1).toString().equalsIgnoreCase("ospf")||
                      commandArgu.elementAt(1).toString().equalsIgnoreCase("bgp")||
                      commandArgu.elementAt(1).toString().equalsIgnoreCase("igrp")){
                    router.setProtocolInUse(commandArgu.elementAt(1).toString());
                    router.setMode(5);
                  }else {
                    Rconsole.append("This IOS not support protocol "+commandArgu.elementAt(1).toString());
                  }
                }else {
                  Rconsole.append("Other protocol in use.");
                }
                break;
              case 2 : Rconsole.append("router arg_protocol arg_num");
                router.setMode(5);
                break;
            }//end switch
          }//end router
          else Rconsole.append(cmdError);
          break;
// end Mode 3: Config Mode "(config)#"

// Interface Mode +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 4:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router(config-if)#help
            showHelp4(Rconsole);
          }//end help

//router(config-if)#bandwidth xx
          else if (chkShortCmd(0,"bandwidth","bw") && moreArgu(2)){
            String flag = ""+flagConfig.charAt(0);
            try {
              int bd = Integer.parseInt(commandArgu.elementAt(1).toString());
              if (flag.equalsIgnoreCase("S")){
                IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
                configInterface.setBandwidth(bd);
                Frame1.setTextProperty(router);
              }else {
                Rconsole.append(cmdError); //only for serial
              }
            }catch (Exception e) {Rconsole.append(cmdError);}
          }//end bandwidth

//router(config-if)#cdp
          else if (chkShortCmd(0,"cdp") && moreArgu(1)){
            Rconsole.append("set cdp");
          }//end cdp

//router(config-if)#clock rate
          else if (chkShortCmd(0,"clock","clk") && moreArgu(3)){
            if (chkShortCmd(1,"rate")){
              String flag = ""+flagConfig.charAt(0);
              try {
                int cr = Integer.parseInt(commandArgu.elementAt(2).toString());
                if (flag.equalsIgnoreCase("S")){
                  IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
                  configInterface.setClockRate(cr);
                  Frame1.setTextProperty(router);
                }else {
                  Rconsole.append(cmdError); //only for serial
                }
              }catch (Exception e) {Rconsole.append(cmdError);}
            }else Rconsole.append(cmdError);
          }//end clock
          else if (chkShortCmd(0,"description","desc") && moreArgu(2)){

//Router(config-if)#description <message>
            String flag = ""+flagConfig.charAt(0);
            if (flag.equalsIgnoreCase("S")){
              IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
              configInterface.setDescription(commandArgu.elementAt(1).toString());
              Frame1.setTextProperty(router);
            }else {
              IntEthernet configInterface = (IntEthernet)router.getClassEthernet(flagConfig);
              configInterface.setDescription(commandArgu.elementAt(1).toString());
              Frame1.setTextProperty(router);
            }//end if

          }//end description

//router(config-if)#end
          else if (chkShortCmd(0,"end") && moreArgu(1)){
            router.setMode(3);
          }//end end

//router(config-if)#exit
          else if (chkShortCmd(0,"exit") && moreArgu(1)){
            router.setMode(2);
          }//end exit

//router(config-if)#interface xx
          else if (chkShortCmd(0,"interface","int") && moreArgu(2)){
            String interfac = commandArgu.elementAt(1).toString();
            String interfaceName = "S0/0";
            char interfaceArray[] = interfac.toCharArray();
            int len = interfac.length();

            if (len > 3 && (interfac.charAt(2)=='/')){
              if (interfac.length() == 3){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3];
              }else if(interfac.length() == 4){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3]+interfaceArray[4];
              }else{}
            }else {
              if (interfac.length() == 2) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1];
              }else if (interfac.length() == 3) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1]+interfaceArray[2];
              }else {}
            }

            if (interfaceName.charAt(0)=='e'){
              interfaceName = "f"+interfaceName;
            }

            if (router.hasInterface(interfaceName)){
              flagConfig = interfaceName;
              router.setMode(4);
            }else{
              Rconsole.append("Interface limited");
            }
          }//end interface

//router(config-if)#ip adderss <ip address> <subnet>
          else if (chkShortCmd(0,"ip") && moreArgu(4)){
            if (chkShortCmd(1,"address")){
              if (isIp(commandArgu.elementAt(2).toString()) &&
                  isIp(commandArgu.elementAt(3).toString())) {

                String flag = ""+flagConfig.charAt(0);
                if (flag.equalsIgnoreCase("S")){
                  IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
                  configInterface.setIPAddress(commandArgu.elementAt(2).toString());
                  configInterface.setIPSubnet(commandArgu.elementAt(3).toString());
                  Frame1.setTextProperty(router);
                }else {
                  IntEthernet configInterface = (IntEthernet)router.getClassEthernet(flagConfig);
                  configInterface.setIPAddress(commandArgu.elementAt(2).toString());
                  configInterface.setIPSubnet(commandArgu.elementAt(3).toString());
                  Frame1.setTextProperty(router);
                }
              }else Rconsole.append(cmdError);
            }else Rconsole.append(cmdError);
          }//end ip
          else if (chkShortCmd(0,"no") && moreArgu(2)){

//router(config-if)#no shutdown
            if (chkShortCmd(1,"shutdown")){
              String flag = ""+flagConfig.charAt(0);
                if (flag.equalsIgnoreCase("S")){
                  IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
                  configInterface.setMyStatus(true);
                  Rconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getSname()+", changed state to up\n"+
                                  "%LINK-3-UPDOWN: Interface "+configInterface.getSname()+", changed steate to up");
                  String connectWith = configInterface.getConnectionWith();
                  String connectDevice = RouterConsole.cutInput(connectWith,0);
                  String connectPort = RouterConsole.cutInput(connectWith,1);
                  Router rt = Frame1.getClassRouter(connectDevice);
                  IntSerial rt_serial = rt.getClassSerial(connectPort);
                  rt_serial.setOpStatus(true);

                  if (!(configInterface.getMyStatus()&&configInterface.getOpStatus())){
                    Rconsole.append("\n%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getSname()+", changed state to down\n"+
                                    "%LINK-3-UPDOWN: Interface "+configInterface.getSname()+", changed steate to down");
                  }
                  Frame1.setTextProperty(router);
                }else{
                  IntEthernet configInterface = (IntEthernet)router.getClassEthernet(flagConfig);
                  configInterface.setMyStatus(true);
                  Rconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getEname()+", changed state to up\n"+
                                  "%LINK-3-UPDOWN: Interface "+configInterface.getEname()+", changed steate to up");
                  Frame1.setTextProperty(router);
                }//end chk interface

            }else {
              Rconsole.append(cmdError);
            }//end shutdown

          }//end no
          else if (chkShortCmd(0,"ring-speed") && moreArgu(2)){
            Rconsole.append("set ring-speed "+commandArgu.elementAt(1).toString());
          }//end ring-speed

//router(config-if)#shutdown
          else if (chkShortCmd(0,"shutdown") && moreArgu(1)){
            String flag = ""+flagConfig.charAt(0);
            if (flag.equalsIgnoreCase("S")){
              IntSerial configInterface = (IntSerial)router.getClassSerial(flagConfig);
              configInterface.setMyStatus(false);
              Rconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getSname()+", changed state to down\n"+
                              "%LINK-3-UPDOWN: Interface "+configInterface.getSname()+", changed steate to down");
              String connectWith = configInterface.getConnectionWith();
              String connectDevice = RouterConsole.cutInput(connectWith,0);
              String connectPort = RouterConsole.cutInput(connectWith,1);
              Router rt = Frame1.getClassRouter(connectDevice);
              IntSerial rt_serial = rt.getClassSerial(connectPort);
              rt_serial.setOpStatus(false);

              Frame1.setTextProperty(router);
            }else{
              IntEthernet configInterface = (IntEthernet)router.getClassEthernet(flagConfig);
              configInterface.setMyStatus(false);
              Rconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getEname()+", changed state to down\n"+
                              "%LINK-3-UPDOWN: Interface "+configInterface.getEname()+", changed steate to down");
              Frame1.setTextProperty(router);
            }//end chk interface
          }//end shutdown
          else Rconsole.append(cmdError);
          break;
// end Mode 4 : Interface Mode "(config-if)#"

// Router Mode ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 5:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router(config-router)#help
            showHelp5(Rconsole);
          }//end help
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {

//Router(config-router)#exit
            router.setMode(3);
          }//end exit
          else if (chkShortCmd(0,"network") && moreArgu(2)){
            if (isIp(commandArgu.elementAt(1).toString())){

//Router(config-router)#network <ip>
              router.setProtocolNetworkAddress(commandArgu.elementAt(1).toString());
              String network = commandArgu.elementAt(1).toString();
              if (router.getprotocolInUse().equalsIgnoreCase("rip")){
                String iproutedetail = " r "+"connected, network "+network;
                this.ipRoute.add(network);
                this.ipRouteDetail.add(iproutedetail);
              }else if (router.getprotocolInUse().equalsIgnoreCase("ospf")){
                String iproutedetail = " o " + "connected, network " + network;
                this.ipRoute.add(network);
                this.ipRouteDetail.add(iproutedetail);
              }else if (router.getprotocolInUse().equalsIgnoreCase("bgp")){
                String iproutedetail = " b " + "connected, network" + network;
                this.ipRoute.add(network);
                this.ipRouteDetail.add(iproutedetail);
              }else if (router.getprotocolInUse().equalsIgnoreCase("igrp")){
                String iproutedetail = " i " + "connected, network" + network;
                this.ipRoute.add(network);
                this.ipRouteDetail.add(iproutedetail);
              }else {
                Rconsole.append("ip address invalid");
              }//end chk isIp
            }else Rconsole.append(cmdError);
          }//end network
          else if (chkShortCmd(0,"passive-interface","passint") && moreArgu(2)){

//            Rconsole.append("passive-interface "+commandArgu.elementAt(1).toString());
          }//end passive-interface
          else if (chkShortCmd(0,"no") && moreArgu(3)){
            if (chkShortCmd(1,"distribute-list","dist")){

//              Rconsole.append("no distribute-list");
            }else if (chkShortCmd(1,"network")){

//Router(config-router)#no network <ip>
              String noip = commandArgu.elementAt(2).toString();
              if (router.getProtocolNetworkAddress().equalsIgnoreCase(noip)){
                router.setProtocolNetworkAddress("");
              }
              String network = commandArgu.elementAt(2).toString();
              if (router.getprotocolInUse().equalsIgnoreCase("rip")){
                for (int find = 0; find < this.ipRoute.size(); find++){
                  if (ipRoute.elementAt(find).toString().equalsIgnoreCase(network)){
                    this.ipRoute.removeElementAt(find);
                    this.ipRouteDetail.removeElementAt(find);
                    router.setProtocolInUse("");
                  }
                }
              }else {
                Rconsole.append("ip address invalid");
              }//end chk isIp
            }else if (chkShortCmd(1,"passive-interface","passint")){
//              Rconsole.append("no passive-interface "+commandArgu.elementAt(2).toString());
            }else Rconsole.append(cmdError);
          }//end no
          else Rconsole.append(cmdError);
          break;
// end Mode 5 : Router Mode "(config-router)#"

// Line Mode
        case 6:
          if (chkShortCmd(0,"?") && moreArgu(1)) {
          }//end ?
          else if (chkShortCmd(0,"help") && moreArgu(1)){

//Router(config-line)#help
            showHelp6(Rconsole);
          }//end help
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {

//Router(config-line)#exit
            router.setMode(3);
          }//end exit
          else if (chkShortCmd(0,"login") && moreArgu(1)) {
//            Rconsole.append("loging in...");
          }//end login
          else if (chkShortCmd(0,"password","pwd") && moreArgu(2)) {
//            Rconsole.append("Password ****");
          }//end password
          else if (chkShortCmd(0,"no") && moreArgu(2)) {
            if (chkShortCmd(1,"login")){
//              Rconsole.append("no login");
            }else Rconsole.append(cmdError);
          }//end no
          else Rconsole.append(cmdError);
          break;
// end Mode 6 : Line Mode "(config-Line)#"

// Password Mode (Enable to Privilage)
        case 10:
          if (router.getPassWord().equals(commandArgu.elementAt(0).toString())){
            router.setMode(2);
          }else {
            Rconsole.append("password not correct");
            router.setMode(1);
          }
          break;
// end Mode 10 : Password Mode "password:"

      } //end switch router.getmode
      }catch (Exception over) {}
  }//end runCommand


//CALL FUNCTION +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  private boolean chkShortCmd(int element,String cmd1) {
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1));
  }//end chkShortCmd(str)
  private boolean chkShortCmd(int element,String cmd1,String cmd2){
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1) ||
        commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd2));
  }//end chkShortCmd(str1,str2)

  private void splitCommand(String CMD) {
    commandArgu.removeAllElements();
    StringTokenizer subStr = new StringTokenizer(CMD," ");
    while (subStr.hasMoreTokens()){
      String str = subStr.nextToken();
      commandArgu.addElement(str);
    }//end while
    arguSize = commandArgu.size();
  }//end splitCommand

  private boolean moreArgu(int maxListArgu){
    return (commandArgu.size() <= maxListArgu);
  }//end splitList

  static boolean isIp(String s){
    boolean chk_ip = true;
    StringTokenizer st = new StringTokenizer(s, ".");
    for (int i = 0; i < 4; i++) {
      if (st.hasMoreTokens()) {
        String tmp = st.nextToken();
        try {
          int ip = Integer.parseInt(tmp);
          if ( (ip < 0) || (ip > 255)) {
            chk_ip = false;
          }
        }catch (NumberFormatException exp) {chk_ip = false;}
      }//end if
      else {
        chk_ip = false;
      }//end else
    }//end for
    return chk_ip;
  }//end chk isIp


//Call Method Agent+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  //Ping -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
  public void ping(String ip){
    if (isIp(commandArgu.elementAt(1).toString())) {
      boolean found_ip = false;
      boolean route_pass = false;
      String network = "";

      for (int indexR = 0; indexR < Frame1.vRouter.size(); indexR++){
        Router rt_int = (Router)Frame1.vRouter.elementAt(indexR);
        //chk interface serial
        for (int index_int = 0; index_int < rt_int.getSport().size(); index_int++){
          IntSerial intS = (IntSerial)rt_int.getSport().elementAt(index_int);
          if (intS.getIPAddress().equalsIgnoreCase(commandArgu.elementAt(1).toString())){
            if (intS.getMyStatus()){
              found_ip = true;
              network = intS.getNetworkAddress();
            }//end interface up
          }//end found ip
        }//end loop chk

        //chk interface ethernet
        for (int index_int = 0; index_int < rt_int.getEport().size(); index_int++){
          IntEthernet intE = (IntEthernet)rt_int.getEport().elementAt(index_int);
          if (intE.getIPAddress().equalsIgnoreCase(commandArgu.elementAt(1).toString())){
            if (intE.getMyStatus()){
              found_ip = true;
              network = intE.getNetworkAddress();
            }//end interface up
          }//end found ip
        }//end loop chk
      }//end router

      if (router.getprotocolInUse().equalsIgnoreCase("")){ //use static
        for (int index = 0; index <  ipRoute.size(); index++){
          String ipr = ipRoute.elementAt(index).toString();
          String ipr_network = Rconsole.cutInput(ipr,0);
          if (ipr_network.equalsIgnoreCase(network)){
            route_pass = true;
          }//end if
        }//end for
      }else if (router.getprotocolInUse().equalsIgnoreCase("rip")){ //use static
        route_pass = true;
      }else if (router.getprotocolInUse().equalsIgnoreCase("ospf")){ //use static
        route_pass = true;
      }else if (router.getprotocolInUse().equalsIgnoreCase("bgp")){ //use static
        route_pass = true;
      }else if (router.getprotocolInUse().equalsIgnoreCase("igrp")){ //use static
        route_pass = true;
      }

      //if (found ip destination){
      if (found_ip && route_pass){
        Rconsole.append("\nType escape sequence to abort."+
                        "\nSending 5, 100-byte ICMP Echos to "+commandArgu.elementAt(1).toString()+" timeout is 2 seconds:"+
                        "\n!!!!!"+
                        "\nSuccess rate is 100 persent (5/5), round-trip min/avg/max = 4/4/4 ms");
      }else {
        Rconsole.append("Incorrect destination");
      }//end output
    }//end if is ip
    else {
      Rconsole.append("Incorrect destination");
    }//end if
  }//end ping

  //Help -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
  public void showCmd1(RouterConsole Rconsole){
     Rconsole.append("Exex Commands:\n"+
     "enable           \t\tTurn on privileged commands\n"+
     "exit             \t\tExit from the EXEC\n"+
     "help             \t\tShow command list\n"+
     "ping             \t\tSend echo messages\n"+
     "show             \t\tShow running system information\n"+
     "traceroute       \t\tTrace route to destination\n\n");
   }

   public void showHelp1(RouterConsole Rconsole){
     Rconsole.append("Exex commands list:\n"+
     "enable"+"\n"+
     "exit"+"\n"+
     "ping <ip>"+"\n"+
     "show cdp entry"+"\n"+
     "show cdp entry <name>"+"\n"+
     "show cdp interface"+"\n"+
     "show cdp neighbors"+"\n"+
     "tracerouter <ip>\n"+
     "");
   }

   public void showCmd2(RouterConsole Rconsole){
     Rconsole.append("Exex Commands:\n"+
     "config           \t\tEnter configuration mode\n"+
     "copy             \t\tCopy configuration or image data\n"+
     "debug            \t\tDebugging functions\n"+
     "disable          \t\tTurn off privileged commands\n"+
     "erase            \t\tErase flash or configuration memory\n"+
     "help             \t\tShow command list\n"+
     "ping             \t\tSend echo messages\n"+
     "show             \t\tShow running system information\n"+
     "terminal         \t\tShow running system information\n"+
     "traceroute       \t\tTrace route to destination\n"+
     "undebug          \t\tDisable debugging functions\n\n");
   }

   public void showHelp2(RouterConsole Rconsole){
     Rconsole.append("Exex commands list:\n"+
     "clock set <time> <data> <month> <year>"+"\n"+
     "configure terminal"+"\n"+
     "copy running_config startup_config"+"\n"+
     "copy startup-config running-config"+"\n"+
     "debug ip rip"+"\n"+
     "disable"+"\n"+
     "erase startup-config"+"\n"+
     "ping <ip>"+"\n"+
     "show cdp entry"+"\n"+
     "show cdp entry <name>"+"\n"+
     "show cdp interface"+"\n"+
     "show cdp neighbors"+"\n"+
     "show history"+"\n"+
     "show interface <name>"+"\n"+
     "show ip ospf database"+"\n"+
     "show ip ospf interface <name>"+"\n"+
     "show ip ospf neighbors"+"\n"+
     "show ip protocol"+"\n"+
     "show ip rip database"+"\n"+
     "show ip route <protocol>"+"\n"+
     "show running config"+"\n"+
     "show startup config"+"\n"+
     "show version"+"\n"+
     "terminal editing"+"\n"+
     "terminal no editing"+"\n"+
     "undebug ip rip"+"\n"+
     "");
   }

   public void showCmd3(RouterConsole Rconsole){
     Rconsole.append("Configure commands:\n"+
     "access-list      \t\tAdd an access list entry\n"+
     "enable           \t\tModify enable password parameter\n"+
     "exit             \t\tExit from configure mode\n"+
     "help             \t\tShow command list\n"+
     "hostname         \t\tSet system's network name\n"+
     "interface        \t\tSelect an interface to configure\n"+
     "ip               \t\tGlobal IP configuration subcommands\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "router           \t\tSet protocol\n\n");
   }

   public void showHelp3(RouterConsole Rconsole){
     Rconsole.append("Configure commands list:\n" +
     "cdp timer <time>"+"\n"+
     "enable secret <password>"+"\n"+
     "exit"+"\n"+
     "hostname <name>"+"\n"+
     "interface <name>"+"\n"+
     "ip classless"+"\n"+
     "ip host <name> <ip address>"+"\n"+
     "ip ospf cost <number> <cost>"+"\n"+
     "ip route <network> <ip subnet> <ip>"+"\n"+
     "line auxilary 0"+"\n"+
     "line console 0"+"\n"+
     "line vty 0 4"+"\n"+
     "no enable secret"+"\n"+
     "no banner login"+"\n"+
     "no ip route <network> <ip subnet> <ip>"+"\n"+
     "no ip classless"+"\n"+
     "no router <protocol>"+"\n"+
     "router <protocol>"+"\n"+
     "router <protocol> <number>"+"\n"+
     "");
   }

   public void showCmd4(RouterConsole Rconsole){
     Rconsole.append("Interface configuration commands:\n"+
     "bandwidth        \t\tSet bandwidth informational parameter\n"+
     "cdp              \t\tCDP interface subcommands\n"+
     "clock            \t\tConfigure serial interface clock\n"+
     "end              \t\tExit from configure mode\n"+
     "exit             \t\tExit from interface configuration mode\n"+
     "help             \t\tShow command list\n"+
     "interface        \t\tSelect an interface to configure\n"+
     "ip               \t\tInterface Internet Protocol config commands\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "ring-speed       \t\tSet ring speed of token ring\n"+
     "shutdown         \t\tShutdown the selected interface\n\n");
   }

   public void showHelp4(RouterConsole Rconsole){
     Rconsole.append("Interface configure commands list:\n" +
     "bandwidth <num>"+"\n"+
     "cdp"+"\n"+
     "clock rate <num>"+"\n"+
     "description <string>"+"\n"+
     "end"+"\n"+
     "exit"+"\n"+
     "interface <name>"+"\n"+
     "ip address <ip address> <ip subnet>"+"\n"+
     "no shutdown"+"\n"+
     "ring-speed <num>"+"\n"+
     "shutdown"+"\n"+
     "");
   }

   public void showCmd5(RouterConsole Rconsole){
     Rconsole.append("Router configuration commands:\n"+
     "help             \t\tShow command list\n"+
     "network          \t\tEnable routing on an IP network\n"+
     "passive-interface\tSuppress routing updates on an interface\n"+
     "no               \t\tNegate a command or set its defaults\n\n");
    }

    public void showHelp5(RouterConsole Rconsole){
      Rconsole.append("Router configure commands list:\n" +
      "exit"+"\n"+
      "network <ip>"+"\n"+
      "passive-interface <name>"+"\n"+
      "no passive-interface <name>"+"\n"+
      "no network <ip>"+"\n"+
      "no distribute-list <gateway>"+"\n"+
      "");
    }

   public void showCmd6(RouterConsole Rconsole){
     Rconsole.append("Line configuration commands:\n"+
     "help             \t\tShow command list\n"+
     "login            \t\tEnable password checking\n"+
     "password         \t\tSet a password\n"+
     "no               \t\tNegate a command or set its defaults\n");
   }

   public void showHelp6(RouterConsole Rconsole){
     Rconsole.append("Line configure commands list:\n" +
     "exit"+"\n"+
     "login"+"\n"+
     "password arg_string"+"\n"+
     "no login"+"\n"+
     "");
   }

   //end Help

   //Show Method -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

   public void showCDP(){
     String s = "";
     s += "Global CDP information:\n";
     s += "\tSending CDP packets every " + router.getCdpTimer() + " seconds\n";
     s += "\tSending a holdtime value of "+ router.getCdpHold() +" seconds\n";
     Rconsole.append(s);
   }//end showCDP

   public void showCDP_Entry_all(){
     String s = "";
     String name = "";
     String mac = "";

     for (int indexS = 0; indexS < router.getSport().size(); indexS++){
       IntSerial intS = (IntSerial)router.getSport().elementAt(indexS);
       String connectWith = intS.getConnectionWith();
       if (!connectWith.equalsIgnoreCase("")){
         if (connectWith.charAt(0)=='R'){
           Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
           name = rt.getRouterName();
           mac = rt.getRouterMacAddress();
         }else {
           Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
           name = sw.getSwitchName();
           mac = sw.getSwitchMacAddress();
         }//end if

         String intType = Rconsole.cutInput(connectWith,1);

         s += "---------------------------"+"\n";
         s += "Device ID: "+name+"\n";
         s += "Entry Address(es):"+"\n";
         s += "ip address: "+intS.getIPAddress()+"\n";
         s += "Novell Address:"+mac+"\n";
         s += "Interface: "+ intType + ", Port ID (outgoint port):"+intS.getS_FullName()+"\n";
         s += "Holdtime: "+router.getCdpHold()+"sec"+"\n";
       }//end if
     }//end for

     for (int indexE = 0; indexE < router.getEport().size(); indexE++){
       IntEthernet intE = (IntEthernet)router.getEport().elementAt(indexE);
       String connectWith = intE.getConnectionWith();
       if (!connectWith.equalsIgnoreCase("")){
         if (connectWith.charAt(0)=='R'){
           Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
           name = rt.getRouterName();
           mac = rt.getRouterMacAddress();
         }else {
           Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
           name = sw.getSwitchName();
           mac = sw.getSwitchMacAddress();
         }//end if

         String intType = Rconsole.cutInput(connectWith,1);

         s += "---------------------------"+"\n";
         s += "Device ID: "+name+"\n";
         s += "Entry Address(es):"+"\n";
         s += "ip address: "+intE.getIPAddress()+"\n";
         s += "Novell Address:"+mac+"\n";
         s += "Interface: "+ intType + ", Port ID (outgoint port):"+intE.getE_FullName()+"\n";
         s += "Holdtime: "+router.getCdpHold()+"sec"+"\n";
       }//end if
     }//end for

     Rconsole.append(s);
   }//end showCDP entry *

   public void showCDP_Entry_Name(String devName){
     boolean found = false;
     String devID = "";
     String s = "";
     String name = "";
     String mac = "";

     for (int countR = 0; countR < Frame1.vRouter.size(); countR++){
       Router rt = (Router)Frame1.vRouter.elementAt(countR);
       if (rt.getRouterName().equalsIgnoreCase(devName)){
         found = true;
         devID = "R"+rt.getRouterID();
       }//end if
     }//end for
     for (int countS = 0; countS < Frame1.vSwitch.size(); countS++){
       Switch sw = (Switch)Frame1.vSwitch.elementAt(countS);
       if (sw.getSwitchName().equalsIgnoreCase(devName)){
         found = true;
         devID = "S"+sw.getSwitchID();
       }
     }//end for

     if (found){
       for (int indexS = 0; indexS < router.getSport().size(); indexS++){
         IntSerial intS = (IntSerial)router.getSport().elementAt(indexS);
         String connectWith = intS.getConnectionWith();
         String connect = "";

         if (connectWith.equalsIgnoreCase("")){
           continue;
         }else {
           connect = Rconsole.cutInput(connectWith, 0);
         }

         if (connect.equalsIgnoreCase(devID)){
           if (connectWith.charAt(0)=='R'){
             Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
             name = rt.getRouterName();
             mac = rt.getRouterMacAddress();
           }else {
             Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
             name = sw.getSwitchName();
             mac = sw.getSwitchMacAddress();
           }//end if

           String intType = Rconsole.cutInput(connectWith,1);

           s += "---------------------------"+"\n";
           s += "Device ID: "+name+"\n";
           s += "Entry Address(es):"+"\n";
           s += "ip address: "+intS.getIPAddress()+"\n";
           s += "Novell Address:"+mac+"\n";
           s += "Interface: "+ intType + ", Port ID (outgoint port):"+intS.getS_FullName()+"\n";
           s += "Holdtime: "+router.getCdpHold()+"sec"+"\n";
         }//end if
       }//end for

       for (int indexE = 0; indexE < router.getEport().size(); indexE++){
         IntEthernet intE = (IntEthernet)router.getEport().elementAt(indexE);
         String connectWith = intE.getConnectionWith();
         String connect = "";

         if (connectWith.equalsIgnoreCase("")){
           continue;
         }else {
           connect = Rconsole.cutInput(connectWith, 0);
         }

         if (connect.equalsIgnoreCase(devID)){
           if (connectWith.charAt(0)=='R'){
             Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
             name = rt.getRouterName();
             mac = rt.getRouterMacAddress();
           }else {
             Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
             name = sw.getSwitchName();
             mac = sw.getSwitchMacAddress();
           }//end if

           String intType = Rconsole.cutInput(connectWith,1);

           s += "---------------------------"+"\n";
           s += "Device ID: "+name+"\n";
           s += "Entry Address(es):"+"\n";
           s += "ip address: "+intE.getIPAddress()+"\n";
           s += "Novell Address:"+mac+"\n";
           s += "Interface: "+ intType + ", Port ID (outgoint port):"+intE.getE_FullName()+"\n";
           s += "Holdtime: "+router.getCdpHold()+"sec"+"\n";
         }//end if
       }//end for

       Rconsole.append(s);

     }else {Rconsole.append(cmdError);}

   }//end show CDP entry <deviceName>

   public void showCDP_Interface(){

   }//end show CDP Interface

   public void showCDP_Neighbor(){
     String s = "";
     s += "Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridges,\n";
     s += "S - Switch, H - Host, I - IGMP, r - Repeater\n";
     s += "Device ID\tLocal Interface\tHoldtime\tCapability\tPlatform\tPort ID\n";

     String name = "";
     String type = "";
     String mac = "";

     for (int indexS = 0; indexS < router.getSport().size(); indexS++){
       IntSerial intS = (IntSerial)router.getSport().elementAt(indexS);
       String connectWith = intS.getConnectionWith();
       if (!connectWith.equalsIgnoreCase("")){
         if (connectWith.charAt(0)=='R'){
           Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
           name = rt.getRouterName();
           type = "R";
           mac = rt.getRouterMacAddress();
         }else {
           Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
           name = sw.getSwitchName();
           type = "S";
           mac = sw.getSwitchMacAddress();
         }//end if

         String intType = Rconsole.cutInput(connectWith,1);

         s += name+"\t"+
             intType+"\t"+
             router.getCdpHold()+"\t"+
             type+"\t"+
             "2501"+"\t"+
             intS.getS_FullName()+"\t"+
             "\n";

       }//end if
     }//end for

     for (int indexE = 0; indexE < router.getEport().size(); indexE++){
       IntEthernet intE = (IntEthernet)router.getEport().elementAt(indexE);
       String connectWith = intE.getConnectionWith();
       if (!connectWith.equalsIgnoreCase("")){
         if (connectWith.charAt(0)=='R'){
           Router rt = Frame1.getClassRouter(Rconsole.cutInput(connectWith,0));
           name = rt.getRouterName();
           type = "R";
           mac = rt.getRouterMacAddress();
         }else {
           Switch sw = Frame1.getClassSwitch(Rconsole.cutInput(connectWith,0));
           name = sw.getSwitchName();
           type = "S";
           mac = sw.getSwitchMacAddress();
         }//end if

         String intType = Rconsole.cutInput(connectWith,1);

         s += name+"\t"+
             intType+"\t"+
             router.getCdpHold()+"\t"+
             type+"\t"+
             "2501"+"\t"+
             intE.getE_FullName()+"\t"+
             "\n";

       }//end if
     }//end for

     Rconsole.append(s);
   }//end show CDP neighbor

   public void showInterface(){
     String s = "";
     String output = "";//detail
     s += "Type\tName\tIP\tSubnet\tStatus\n";

     for(int indexSe = 0; indexSe < router.getSport().size(); indexSe++){
       IntSerial intS = (IntSerial)router.getSport().elementAt(indexSe);
       if (!(intS.getIPAddress().toString().equalsIgnoreCase(""))){
         s += "Serial" + "\t" +
             intS.getSname() + "\t" +
             intS.getIPAddress() + "\t" +
             intS.getIPSubnet() + "\t" +
             intS.getMyStatusString() +
             "\n";

         String lineStatus = "down";
         if (intS.getMyStatus()&&intS.getOpStatus()){
           lineStatus = "up";
         }else { lineStatus = "down"; }

         output += intS.getS_FullName() + " is "+intS.getMyStatusString()+" ,line protocol is " + lineStatus + "\n";
         output += "Hardware is HD64570\n";
         output += "Internet address is " + intS.getIPAddress() + " " + intS.getIPSubnet() + "\n";
         output += "MTU 1500 bytes, BW 1544 Kbit, DLY 20000 usec, rely 255/255, load 1/255\n";
         output += "Encapsulation HDLC, loopback not set, keepalive set (10 sec)\n";
         output += "Last input 0:00:03, output 0:00:02, output hang never\n";
         output += "Last clearing o f\"show interface\" counters never\n";
         output += "Output queue 0/40, 0 drops; input queue 0/75, 0 drops\n";
         output += "5 minute input rate 0 bit/sec, 0 packets/sec\n";
         output += "5 minute output rate 0 bit/sec, 0 packets/sec\n";
         output += "  6000 packets input, 424701 bytes, 0 no buffer\n";
         output += "  Received 3177 broadcasets, 0 runts, 0 giants\n";
         output += "  0 input errors, 0 CRC, o frame, 0 overrun, 0 ignored, 0 abort\n";
         output += "  6185 packets output, 1400825 bytes, 0 underruns\n";
         output += "  0 output errors, o collisions, 2 interface resets, 0 restarts\n";
         output += "  0 output buffer failures, 0 output buffers swapped out\n";
         output += "  0 carrier transitions\n";
         output += "  DCD=up DSR=up DTR=up RTS=up CTS=up\n\n";
       }
     }
     for(int indexEt = 0; indexEt < router.getEport().size(); indexEt++){
       IntEthernet intE = (IntEthernet)router.getEport().elementAt(indexEt);
       if (!(intE.getIPAddress().toString().equalsIgnoreCase(""))){
         s += "FastEthernet" + "\t" +
             intE.getEname() + "\t" +
             intE.getIPAddress() + "\t" +
             intE.getIPSubnet() + "\t" +
             intE.getMyStatusString() +
             "\n";

         output += intE.getE_FullName() + " is "+intE.getMyStatusString()+" ,line protocol is up\n";
         output += "Hardware is HD64570\n";
         output += "Internet address is " + intE.getIPAddress() + " " + intE.getIPSubnet() + "\n";
         output += "MTU 1500 bytes, BW 1544 Kbit, DLY 20000 usec, rely 255/255, load 1/255\n";
         output += "Encapsulation HDLC, loopback not set, keepalive set (10 sec)\n";
         output += "Last input 0:00:03, output 0:00:02, output hang never\n";
         output += "Last clearing o f\"show interface\" counters never\n";
         output += "Output queue 0/40, 0 drops; input queue 0/75, 0 drops\n";
         output += "5 minute input rate 0 bit/sec, 0 packets/sec\n";
         output += "5 minute output rate 0 bit/sec, 0 packets/sec\n";
         output += "  6000 packets input, 424701 bytes, 0 no buffer\n";
         output += "  Received 3177 broadcasets, 0 runts, 0 giants\n";
         output += "  0 input errors, 0 CRC, o frame, 0 overrun, 0 ignored, 0 abort\n";
         output += "  6185 packets output, 1400825 bytes, 0 underruns\n";
         output += "  0 output errors, o collisions, 2 interface resets, 0 restarts\n";
         output += "  0 output buffer failures, 0 output buffers swapped out\n";
         output += "  0 carrier transitions\n";
         output += "  DCD=up DSR=up DTR=up RTS=up CTS=up\n\n";

       }
     }

     Rconsole.append(s);
     Rconsole.append(output);
   }//end show Interface

   public void showRunningConfig(){
     String newstr = "";
     newstr += "version 12.0\n";
     newstr += "service timestamps debug uptime\n";
     newstr += "service timestamps log uptiom\n";
     newstr += "no service password-encryption\n";
     newstr += "!\n";

     // Set Hostname
     newstr += "hostname " + router.getRouterName()+ "\n";
     newstr += "!\n";

     // Enable Password
         if (router.getPassWordEnable()){
           newstr += "enable password " + router.getPassWord() + "\n";
         }else {
           newstr += "!\n";
         }
         newstr += "!\n";

         //Serial
         for (int se = 0; se < router.getSport().size(); se++){
           IntSerial intS = (IntSerial)router.getSport().elementAt(se);

           if (!(intS.getIPAddress().equalsIgnoreCase(""))){
             newstr +="!\n";
             newstr += "interface " + intS.getSname()+"\n";
             newstr += "ip address " + intS.getIPAddress() + " " + intS.getIPSubnet() + "\n";

             if (intS.getMyStatus()){
               newstr += "shutdown\n";
             }else{
               newstr += "no shutdown\n";
             }//end if mystatus
           }//end if chk show
         }//end for
         //Ethernet
         for (int et = 0; et < router.getEport().size(); et++){
           IntEthernet intE = (IntEthernet)router.getEport().elementAt(et);

           if (!(intE.getIPAddress().equalsIgnoreCase(""))){
             newstr +="!\n";
             newstr += "interface " + intE.getEname()+"\n";
             newstr += "ip address " + intE.getIPAddress() + " " + intE.getIPSubnet() + "\n";
             if (intE.getMyStatus()){
               newstr += "shutdown\n";
             }else{
               newstr += "no shutdown\n";
             }//end if mystatus
           }//end if chk show
         }//end for

         newstr += "!\n";
         newstr += "no ip classless\n";
         newstr += "!\n";
         newstr += "line con 0\n";
         newstr += "line aux 0\n";
         newstr += "line vty 0 4\n";
         newstr += "!\nend\n";

         Rconsole.append(newstr);
   }//end show running-config

   public void showStartupConfig(){
     showRunningConfig();
   }//end show startup-config

   public void showVersion(){
     String s = "";
     s += "Cisco Internetwork Operating System Software\n";
     s += "IOS(tm) 2500 Software (C3640-J-M), Version 11.0(6)P, SHARED PLATFORM,RELEASE SOFTWARE (fc1)\n";
     s += "Copy right(c) 1986-1977 by cisco Systems,Inc.\n";
     s += "Compiled Mon 12-May-97 15:07 by tej\n";
     s += "Image text-base:0x600088A0, data-base: 0x6075C000\n\n";
     s += "ROM: System Bootstrap, Version 12.0(7)AX SOFTWARE\n";
     s += "ROM: System Bootstrap, Version 5.2(8a), RELEASE SOFTWARE\n";
     s += "BOOTFLASH: 3000 Bootstrap Software (IGS-RXBOOT), Version 10.2(8a), RELEASE SOFTW\n";
     s += "ARE (fc1)\n\n";
     s += router.getRouterName()+ " uptime is 11 minutes\n";
     s += "System restarted by power-on\n";
     s += "System image file is \"flash:c2500-d-l_113-5.bin\", booted via flash\n\n";
     s += "Bridging software.\n";
     s += "X.25 software, Version 3.0.0.\n";
     s += router.getEport().size()+" Ethernet/IEEE 802.3 interface(s)\n";
     s += router.getSport().size()+" Serial network interface(s)\n";
     s += "32K bytes of non-volatile configuration memory.\n";
     s += "8192K bytes of processor board System flash (Read ONLY)\n\n";
     s += "Configuration register is 0x2102\n";

     Rconsole.append(s);
   }

   public void showIP_Protocol(){
     String output = "";
     if (router.getprotocolInUse().equalsIgnoreCase("")){
       output += "Not Have any protocol\n";
     }else{
       output += "Routing Protocol is \""+router.getprotocolInUse()+"\"\nSending updates every ";
       output += "10000" + " seconds, hold down 180, flushed after 240\n";
       output += "Outgoing update filter list for all interfaces is not set\n";
       output += "Incoming update filter list for all interdaces is not set\n";
       output += "Redistributing : rip\n";
       output += "Routing for Networks :\n";
       output += router.getProtocolNetworkAddress()+"\n";
       output += "Routing Information Sources :\n";
       output += "Gateway      Distance    Last Update\n";
       output += router.getProtocolNetworkAddress()+"      120         0:00:00\n";
       output += "Distance: (default is 120)\n";
     }

     Rconsole.append(output);
   }//end showIP_Protocol

   public void showIP_Route(){
     String show_ip_route ="Show IP Route \n"+"Codes: \t C - connected, S - static, I - IGRP, R - RIP, M - mobile, B - BGP \n"
         +"\t D - EIGRP, EX - EIGRP external, O - OSPF, IA - OSPF inter area \n"
         +"\t N1 - OSPF NSSA external type 1, N2 - OSPF NSSA external type 2 \n"
         +"\t E1 - OSPF external type 1, E2 - OSPF external type 2, E - EGP \n"
         +"\t i - IS-IS, L1 - IS-IS level-1, L2 - IS-IS level-2, * - candidate default \n"
         +"\t U - per-user static route, o - ODR \n\n Gateway of last resort is not set ";
     Rconsole.append(show_ip_route);

     String connected = "";
     for (int index = 0; index < router.getSport().size(); index++){
       IntSerial int_S = (IntSerial)router.getSport().elementAt(index);
       if (int_S.getNetworkAddress() != ""){
         connected += "\n c "+int_S.getNetworkAddress()+" is directly connected, "+
             int_S.getS_FullName()+" "+int_S.getIPSubnet();
       }
     }//end for serial
     for (int index = 0; index < router.getEport().size(); index++){
       IntEthernet int_E = (IntEthernet)router.getEport().elementAt(index);
       if (int_E.getNetworkAddress() != ""){
         connected += "\n c "+int_E.getNetworkAddress()+" is directly connected, "+
             int_E.getE_FullName()+" "+int_E.getIPSubnet();
       }
     }//end for ethernet

     for (int count = 0; count < this.ipRouteDetail.size(); count++){
       connected += "\n"+this.ipRouteDetail.elementAt(count).toString();
     }

     Rconsole.append(connected);

   }//end showIP_Route

}//end class fullRoutercmd
