package netsimulator;

import java.util.*;

class VLAN {

  private int vlan_id = 1;               //default 1       range[1-1005]
  private int vlan_mtu = 1500;           //default 1500    range[1500-18190]
  private String vlan_name = "default";  //default default range[32 charactor]
  private String vlan_status = "active";
  private String vlan_type = "enet";
  private String vlan_said = "100001";
  private Vector vlan_member = new Vector();

//Constructor ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  public VLAN() {
  }
  public VLAN(int id, int mtu, String name){
    vlan_id = id;
    vlan_mtu = mtu;
    vlan_name = name;
  }

//Method +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  static VLAN getDefaultVLAN(Switch sw){
    VLAN vlan = null;
    for (int vlan_def = 0; vlan_def < sw.vVlan.size(); vlan_def++) {
      VLAN vlan_temp = (VLAN) sw.vVlan.elementAt(vlan_def);
      if (vlan_temp.getID() == 1) {
        vlan = vlan_temp;
      }//end if
    }//end for find
    return vlan;
  }

  public VLAN getClassVlan(int vlan_id){
    VLAN vlan = null;
    for (int index = 0; index < vlan_member.size(); index++){
      VLAN vlan_tmp = (VLAN)vlan_member.elementAt(index);
      if (vlan_id == vlan_tmp.getID()){
        vlan = vlan_tmp;
      }
    }
    return vlan;
  }

  public void setDefault(){
    vlan_id = 1;
    vlan_mtu = 1500;
    vlan_name = "default";
  }

  public void initVlanMember(Vector e_port){
    vlan_member.removeAllElements();

    for (int indexE = 0; indexE < e_port.size(); indexE++){
      IntEthernet intE = (IntEthernet) e_port.elementAt(indexE);
      vlan_member.add(intE);
    }
  }

  public void addVlanMember(IntEthernet et){
    vlan_member.add(et);
  }

  public void removeVlanMember (IntEthernet et){
    for (int index = 0; index < vlan_member.size(); index++){
      IntEthernet intE = (IntEthernet)vlan_member.elementAt(index);
      if (intE.equals(et)){
        vlan_member.removeElementAt(index);
      }
    }
  }

  public void setID(int num_id){
    vlan_id = num_id;
  }
  public int getID(){
    return vlan_id;
  }

  public void setMTU(int num_mtu){
    vlan_mtu = num_mtu;
  }
  public int getMTU(){
    return vlan_mtu;
  }

  public void setName(String in_name){
    vlan_name = in_name;
  }
  public String getName(){
    return vlan_name;
  }

  public void setStatus(String in_status){
    vlan_status = in_status;
  }
  public String getStatus(){
    return vlan_status;
  }

  public void setType(String type){
    vlan_type = type;
  }
  public String getType(){
    return vlan_type;
  }

  public void setSaid(String said){
    vlan_said = said;
  }
  public String getSaid(){
    return vlan_said;
  }
  public Vector getVlanMember(){
    return vlan_member;
  }

  static boolean chkVLAN(String src_ip,String des_ip){
    boolean vlan_match = false;
    String src_mac = AddressLearning.arp(src_ip);
    String des_mac = AddressLearning.arp(des_ip);
    int src_vlan = 1;
    int des_vlan = 1;

    if (!(src_mac.equalsIgnoreCase(des_mac))){
      //find source
      //chk router
      for (int index_rt = 0; index_rt < Frame1.vRouter.size(); index_rt++) {
        Router rt = (Router) Frame1.vRouter.elementAt(index_rt);
        if (src_mac.equalsIgnoreCase(rt.getRouterMacAddress())) {
          src_vlan = 1;
        }
        else if (des_mac.equalsIgnoreCase(rt.getRouterMacAddress())) {
          des_vlan = 1;
        }
        //chk ethernet (serial no vlan)
        for (int index_e = 0; index_e < rt.getEport().size(); index_e++) {
          IntEthernet intE = (IntEthernet) rt.getEport().elementAt(index_e);
          if (src_mac.equalsIgnoreCase(intE.getMacAddress())) {
            src_vlan = intE.getVLAN();
          }
          else if (des_mac.equalsIgnoreCase(intE.getMacAddress())) {
            des_vlan = intE.getVLAN();
          }
        } //end chk ethernet
      } //end chk router

      //chk switch
      for (int index_sw = 0; index_sw < Frame1.vSwitch.size(); index_sw++) {
        Switch sw = (Switch) Frame1.vSwitch.elementAt(index_sw);
        if (src_mac.equalsIgnoreCase(sw.getSwitchMacAddress())) {
          src_vlan = 1;
        }
        else if (des_mac.equalsIgnoreCase(sw.getSwitchMacAddress())) {
          des_vlan = 1;
        }
        //chk ethernet
        for (int index_e = 0; index_e < sw.getEport().size(); index_e++) {
          IntEthernet intE = (IntEthernet) sw.getEport().elementAt(index_e);
          if (src_mac.equalsIgnoreCase(intE.getMacAddress())) {
            src_vlan = intE.getVLAN();
          }
          else if (des_mac.equalsIgnoreCase(intE.getMacAddress())) {
            des_vlan = intE.getVLAN();
          }
        } //end chk ethernet
      } //end chk switch

      //chk host
      for (int index_ho = 0; index_ho < Frame1.vHost.size(); index_ho++) {
        Host ho = (Host) Frame1.vHost.elementAt(index_ho);
        //chk ethernet
        for (int index_e = 0; index_e < ho.getEport().size(); index_e++) {
          IntEthernet intE = (IntEthernet) ho.getEport().elementAt(index_e);
          if (src_mac.equalsIgnoreCase(intE.getMacAddress())) {
            src_vlan = intE.getVLAN();
          }
          else if (des_mac.equalsIgnoreCase(intE.getMacAddress())) {
            des_vlan = intE.getVLAN();
          }
        } //end chk ethernet
      } //end chk switch
    }//end if same interface

    if (src_vlan == des_vlan){
      vlan_match = true;
    }else {
      vlan_match = false;
    }

    return vlan_match;
  }
}