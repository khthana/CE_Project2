package netsimulator;

public class MainWindow {
  public static void main(String[] args) {
    new Frame1();
  }
}