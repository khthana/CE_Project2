package netsimulator;

import java.util.*;
import java.lang.*;
import java.lang.Object;
import java.lang.String;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.KeyAdapter.*;
import javax.swing.*;

class RouterConsole extends JFrame{

  RouterIOS120 RIOS121 = new RouterIOS120();

  private boolean firstEnter = true;//flag

  private Router router1 = null;

  private String output;

  public static Vector vRouterConsole = new Vector();
  public static Vector history = new Vector();
  public static Vector tmpCmd = new Vector();
  private String StrRetBuffer = "";
  private Vector arguList = new Vector();
  private int historySize = 20;
  private int chkLength = 0;
  private int newLength = 0;
  private int historyReference = -1;
  private String fullRoutercmd;

  private JPanel contentPane = new JPanel();
  private JScrollPane jScrollPane = new JScrollPane();
  private JTextArea jTextArea = new JTextArea();
  private String initStr = "Router con0 is now available\n\nPress return to get start\n\n\n";
  private String consoleName;
  private String prompt = ">";

  //cmd for show Tab
  private final String[] userMode = new String[]{"enable","exit","help","ping ip|name","show cdp entry *","show cdp entry","show cdp interface","show cdp neighbors","show cdp","traceroute"};
  private final String[] privMode = new String[]{"configure terminal","copy running-config startup-config","copy startup-config running-config","debug ip rip","disable","help","ping","show ip ospf interface","show ip ospf neighbors","show ospf database","show rip database","show ip route","show ip protocol","show cdp neighbors","show cdp entry","show cdp interface","show history","show cdp","show running-config","show startup-config","show version","show interface"};
  private final String[] confMode = new String[]{"enable secret","exit","help","hostname","interface","ip ospf cost","ip host","ip classless","ip route","line vty","line auxilary","line console","no enable secret","no banner login","no ip route","ip classless","no rouer","router"};
  private final String[] intfMode = new String[]{"bandwidth","cdp","clock rate","end","exit","help","interface","ip address","no shutdown","ring-speed","shutdown"};
  private final String[] routMode = new String[]{"help","network","passive-interface","no passive-interface","no network","no distribute-list"};
  private final String[] lineMode = new String[]{"help","login","password","no"};


  public RouterConsole(Router router,String name) {
      try {
        jbInit(router,name);
      }
      catch (Exception e) { e.printStackTrace(); }
  }//end Constructor RouterConsole()


//------ jbInit(Router,String) ---------------------------------
  private void jbInit(Router router,String routername) {
    //super.setDefaultCloseOperation(EXIT_ON_CLOSE); //-- close operation
    super.setSize(new Dimension(600,500));
    super.setResizable(false);

    router1 = router;
    consoleName = router1.getRouterName();

    super.setTitle(" - = "+router1.getRouterName()+" Console = - ");
    super.setVisible(false);

    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(null);
    contentPane.setSize(600,500);
    contentPane.setBackground(Color.DARK_GRAY);
    contentPane.setEnabled(true);

    contentPane.add(jScrollPane);

    jScrollPane.setBorder(null);
    jScrollPane.setBounds(5,5,585,465);
    jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane.getViewport().add(jTextArea,null);

    jTextArea.setBackground(Color.DARK_GRAY);
    jTextArea.setForeground(Color.WHITE);
    jTextArea.setLineWrap(true);
    jTextArea.setWrapStyleWord(true);
    jTextArea.setText(initStr);
    jTextArea.setEditable(false);
    jTextArea.addKeyListener(new java.awt.event.KeyAdapter(){
      public void keyPressed(KeyEvent e) {
        jTextArea_keyPressed(e);
      }
    });//end call jTextArea KeyListener

  }//end jbInit(Router,String)


//----------- Function ----------------------------------

  void jTextArea_keyPressed(KeyEvent e) {
   int keycode = e.getKeyCode();
   newLength = jTextArea.getText().length();//for refresh
   jTextArea.setCaretPosition(newLength);//for write continous
//   System.out.println("just press = "+newLength);

    //Enter Key
    if (keycode==e.VK_ENTER){
      tmpCmd.removeAllElements();
      e.consume();
      chkmodeRouter(router1.getMode());
      if (firstEnter) {
        firstEnter = false;
        jTextArea.setEditable(true);
        jTextArea.repaint();
        jTextArea.append("\n");
        jTextArea.append(consoleName + prompt);
        chkLength = jTextArea.getText().length();  //init prompt
        newLength = chkLength;                     //init prompt con't
      }//end firstEnter = true
      else { //do input
        try {
          fullRoutercmd = jTextArea.getText(chkLength, newLength - chkLength);
          if (fullRoutercmd.length() != 0) {
            if (history.size() <= historySize) {
              history.addElement(fullRoutercmd);
            }
            else {
              history.removeElementAt(0);
              history.addElement(fullRoutercmd);
            } //remove first and add last cmd

            fullRoutercmd = fullRoutercmd+" "; //for use convert to full cmd input
            RIOS121.runCommand(router1,fullRoutercmd,this);

            consoleName = router1.getRouterName();

            if(firstEnter){ //for reset by command
            }else {
              ready();
            }
          } //end if chk null cmd
          else { // if fullRoutercmd = 0
            jTextArea.append("\n");
            jTextArea.append(consoleName + prompt);
          }
        }//end try
        catch (Exception exception) {
          exception.printStackTrace();
        }//end try and catch

        chkLength = jTextArea.getText().length(); //new chk
        newLength = chkLength; //update chk

        historyReference = history.size()-1;  //actual last Reference
      }//end else chk firstEnter
    }//end chk Enter key

    //Backspace key
    else if (keycode==e.VK_BACK_SPACE) {
      if (newLength <= chkLength) {
        jTextArea.append(" ");
      }
    }

    //Left key
    else if (keycode==e.VK_LEFT){
      e.consume(); //use backspace only
    }

    //Up key --> call history privious
    else if (keycode==e.VK_UP) {
      e.consume();
      try{
        if (historyReference <= history.size() - 1) {
          if (historyReference - 1 >= 0) {
            jTextArea.replaceRange(history.elementAt(historyReference).toString(),
                                   chkLength, newLength); //replace string
            historyReference--; //prepare privious command --> lowest = 1
          }
          else {
            jTextArea.replaceRange(history.elementAt(historyReference).toString(),
                                   chkLength, newLength);
            historyReference = history.size() - 1; //circular list 0 --> max
          } //end if hisref-1 >= 0
        }
        else {
          historyReference = history.size() - 1;
          jTextArea.replaceRange(history.elementAt(historyReference).toString(),
                                 chkLength, newLength);
        } //end if hisref <= hisSize
      }catch (Exception exception) {}
    }

    //Down key --> call history next
    else if (keycode==e.VK_DOWN) {
      e.consume();
      if (historyReference+1 <= history.size()-1) {
        historyReference++;
        jTextArea.replaceRange(history.elementAt(historyReference).toString(),
                               chkLength,newLength); //replace string
      }
      else {
        jTextArea.replaceRange("",chkLength,newLength); //replace string
      }//end if hisref+1 <= hisSize
    }

    //Tab key
    else if (keycode==e.VK_TAB) {
      e.consume();
      showTab();
    }

    //? key
    else if (e.getKeyChar()==('?')) {
      e.consume();
      jTextArea.append("?");
      switch (router1.getMode()){
          case 1 : RIOS121.showCmd1(this);break;
          case 2 : RIOS121.showCmd2(this);break;
          case 3 : RIOS121.showCmd3(this);break;
          case 4 : RIOS121.showCmd4(this);break;
          case 5 : RIOS121.showCmd5(this);break;
          case 6 : RIOS121.showCmd6(this);break;
      }
      ready();
    }
    else {
      try {
        //newLength = jTextArea.getText().length();
//        fullRoutercmd = jTextArea.getText(chkLength, newLength - chkLength);
//        System.out.println("fullRoutercmd = "+fullRoutercmd);
      }catch (Exception noText) {System.out.println("no text");}
    }

  }//end jTextArea KeyEvent

  //Extends Function

  public void closeConsole() {
      this.dispose();
    }//end close Console

  public void reset() {
    firstEnter = true;
    jTextArea.setText("");
    jTextArea.setLineWrap(true);
    jTextArea.setWrapStyleWord(true);
    jTextArea.setText(initStr);
    jTextArea.setEditable(false);
  }//end reset

  public void ready() {
    jTextArea.append("\n");
    prompt = chkmodeRouter(router1.getMode());
    jTextArea.append(consoleName + prompt);
    chkLength = jTextArea.getText().length();  //init prompt
    newLength = chkLength;
  }//end ready

  public void append(String str) {
    jTextArea.append("\n");
    jTextArea.append(str);
  }

  private String chkmodeRouter(int mode){
    switch(mode){
        case 1 : prompt = ">";break;
        case 2 : prompt = "#";break;
        case 3 : prompt = "(config)#";break;
        case 4 : prompt = "(config-if)#";break;
        case 5 : prompt = "(config-router)#";break;
        case 6 : prompt = "(config-line)#";break;
//        case 10 : prompt = "password:";break;
//        case 11 : prompt = "password:";break;
//        case 12 : prompt = "password:";break;
//        case 20 : prompt = "Configuring from terminal, memory, or network[terminal]?";break;
        default : prompt = ">";break;
    }//end switch
    return prompt;
  }//end chkmodeRouter

  private void showQuestion() {
    String tmp = fullRoutercmd;
  }

  private void showTab() {
    try {
      newLength = jTextArea.getText().length();
      String[] cmdRef = null;

      String full = "";
      String getCmd = "";

      String command = jTextArea.getText(chkLength, (newLength-chkLength));
      char[] cmdChar = command.toCharArray();
      char[] lstChar = null;

      StringTokenizer cutcommand = new StringTokenizer(command," ");
      int countArgu = cutcommand.countTokens();

      switch(router1.getMode()) {
        case 1 : cmdRef = userMode; break;
        case 2 : cmdRef = privMode; break;
        case 3 : cmdRef = confMode; break;
        case 4 : cmdRef = intfMode; break;
        case 5 : cmdRef = routMode; break;
        case 6 : cmdRef = lineMode; break;
      }//end switch getMode --- no default

      System.out.println("chkLength = "+chkLength);
      System.out.println("newLength = "+newLength);
      System.out.println(jTextArea.getText(chkLength,(newLength-chkLength)));

      int element = 0;
      int charAt = 0;

      StrRetBuffer = "";
      for (int i = 0; i <= countArgu - 1; i++) {
        getCmd = findCmd(cmdRef, element, cmdChar, charAt,i);
        System.out.println("getCmd =" +getCmd);
        full += getCmd+" ";
        System.out.println("full = "+full);
      }

      jTextArea.replaceRange(full,chkLength,newLength);

    }catch (Exception nulltext) {}

  }//end showTab

  public void showHistory(){
    String his = "";
    for (int count = 0; count < history.size(); count++){
      his += history.elementAt(count).toString()+"\n";
    }
    append(his);
  }//end showHistory

  private String findCmd(String[] cmdRef,int element,char[] cmdChar,int charAt,int Argu) {
    char[] lstChar = cmdRef[element].toCharArray();
      if (cmdChar[charAt] == lstChar[charAt]) {
        try {
          if ((charAt + 1 <= cmdChar.length - 1)  && (charAt+1 != ' ')) {
              findCmd(cmdRef, element, cmdChar, charAt + 1,Argu);
          }
          else {//got command here
            StrRetBuffer = cutInput(cmdRef[element],Argu);
            return StrRetBuffer;
          }
          }catch (Exception overArgu) {
            StrRetBuffer = cutInput(cmdRef[element],Argu);
          return "";
        }//end try
      }else {
        if (element <= cmdRef.length){
          findCmd(cmdRef, element + 1, cmdChar, 0,Argu);
        }else {
          jTextArea.append(" ");
        }
      }//end if
      return StrRetBuffer;
  }//end findCmd

  static String cutInput(String CMD,int index) {
    Vector cutStr = new Vector();
      cutStr.removeAllElements();
      StringTokenizer subStr = new StringTokenizer(CMD," ");
      while (subStr.hasMoreTokens()){
        String str = subStr.nextToken();
        cutStr.addElement(str);
      }//end while
      return cutStr.elementAt(index).toString();
    }//end cutInput

    static String cutInput(String CMD,int index,String symbol) {
      Vector cutStr = new Vector();
      cutStr.removeAllElements();
      StringTokenizer subStr = new StringTokenizer(CMD,symbol);
      while (subStr.hasMoreTokens()){
        String str = subStr.nextToken();
        cutStr.addElement(str);
      }//end while
      return cutStr.elementAt(index).toString();
    }//end cutInput

  private Vector selectArgu(String[] cmdRef,int index) {
    arguList.removeAllElements();
    Vector selArgu = new Vector();
    for (int argu = 0; argu <= cmdRef.length-1; argu++){
      selArgu.removeAllElements();
      StringTokenizer subStr = new StringTokenizer(cmdRef[argu]," ");
      while (subStr.hasMoreTokens()){
        String str = subStr.nextToken();
        selArgu.addElement(str);
      }//end while
      arguList.addElement(selArgu.elementAt(index));
    }//end for
    return arguList;
  }//end selectArgu

}//END Class RouterConsole