package netsimulator;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.String;

import javax.swing.*;
import javax.swing.border.*;

public class NetDesignPanel extends JPanel {

  public static Vector vRouterImg = new Vector();
  public static Vector vSwitchImg = new Vector();
  public static Vector vHostImg = new Vector();

  public static Vector vWireImg = new Vector();

  public static Vector vFlagImgStart = new Vector();
  public static Vector vFlagImgEnd = new Vector();
  public static Vector vStartImg = new Vector();
  public static Vector vEndImg = new Vector();
  public static Vector vStartPortName = new Vector();
  public static Vector vEndPortName = new Vector();

  public static Vector vLineType = new Vector();
  public static Vector vNetAddress = new Vector();

  RouterImg rimg = null;
  SwitchImg simg = null;
  HostImg   himg = null;
  WireImage wimg = null;

  int dx,dy;             //position of mouse
  int diffx,diffy = 0;   //position current click

  boolean pressRouter = false;
  boolean pressSwitch = false;
  boolean pressHost = false;
//  boolean pressWire = false;

  int doubleClickMode = 0;//(0=Default:None, 1=Router, 2=Switch, 3=Wire, 4=Host)
  int popupMode = 0; //(0=Default:None, 1=Router, 2=Switch, 3=Wire, 4=Host)
  JPopupMenu jPopupMenu1 = new JPopupMenu(); //RightClick On Router
  JPopupMenu jPopupMenu2 = new JPopupMenu(); //RightClick On Switch
  JPopupMenu jPopupMenu3 = new JPopupMenu(); //RightClick on Wire

  //Router MenuItem
  JMenuItem connectRouter = new JMenuItem("Connect");
  JMenuItem consoleRouter = new JMenuItem("Console");
  JMenuItem deleteRouter  = new JMenuItem("Delete");

  //Switch MenuItem
  JMenuItem connectSwitch = new JMenuItem("Connect");
  JMenuItem consoleSwitch = new JMenuItem("Console");
  JMenuItem deleteSwitch  = new JMenuItem("Delete");

  //Host MenuItem
  JMenuItem connectHost = new JMenuItem("Connect");
  JMenuItem consoleHost = new JMenuItem("Console");
  JMenuItem deleteHost = new JMenuItem("Delete");

  //Wire MenuItem
  JMenuItem connect = new JMenuItem("Connect");
  JMenuItem deleteWire = new JMenuItem("Delete");

  //-------------------- Constructor --------------------------------------------------------//
  public NetDesignPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setSize(800,600);
    this.setLayout(null);
    this.setBackground(new Color(195, 222, 251));

    jPopupMenu1.add(connectRouter);
    jPopupMenu1.addSeparator();
    jPopupMenu1.add(consoleRouter);
    jPopupMenu1.add(deleteRouter);

    jPopupMenu2.add(connectSwitch);
    jPopupMenu2.addSeparator();
    jPopupMenu2.add(consoleSwitch);
    jPopupMenu2.add(deleteSwitch);

    jPopupMenu3.add(connectHost);
    jPopupMenu3.addSeparator();
    jPopupMenu3.add(consoleHost);
    jPopupMenu3.add(deleteHost);

/*    jPopupMenu3.add(connect);
    jPopupMenu3.add(deleteWire);
*/
    //---------------------------------------Add Listener ---------------------------------------//
    this.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        this_mouseDragged(e);
      }
    });

    this.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        this_mouseReleased(e);
      }
      public void mousePressed(MouseEvent e) {
        this_mousePressed(e);
      }
    });
    //---------------------------------------Add Menu Listener---------------------------------//
    //Router Menu Listener
    connectRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connectRouter_actionPerformed(e);
      }
    });
    consoleRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        consoleRouter_actionPerformed(e);
      }
    });
    deleteRouter.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteRouter_actionPerformed(e);
      }
    });

    //Switch Menu Listener
    connectSwitch.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connectSwitch_actionPerformed(e);
      }
    });
    consoleSwitch.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        consoleSwitch_actionPerformed(e);
      }
    });
    deleteSwitch.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteSwitch_actionPerformed(e);
      }
    });

    //Host Menu Listener
    connectHost.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connectHost_actionPerformed(e);
      }
    });
    consoleHost.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        consoleHost_actionPerformed(e);
      }
    });
    deleteHost.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteHost_actionPerformed(e);
      }
    });

    //Wire Menu Listener
/*    connect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        connect_actionPerformed(e);
      }
    });
    deleteWire.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteWire_actionPerformed(e);
      }
    });
*/

  }//end jbInit()

  //--------------------------PaintComponent-------------------------//
  public void paintComponent(Graphics g){
    super.paintComponent(g);

    // draw line
    try {

      for (int count = 0; count < vFlagImgStart.size(); count++) {
        int sX, sY, eX, eY;
        String flagS = vFlagImgStart.elementAt(count).toString();
        String flagE = vFlagImgEnd.elementAt(count).toString();
        String lineC = vLineType.elementAt(count).toString();
        String netAddress = vNetAddress.elementAt(count).toString();
        String strS = vStartPortName.elementAt(count).toString();
        String strE = vEndPortName.elementAt(count).toString();

        if (flagS.equalsIgnoreCase("R")) {
          RouterImg rtImg = (RouterImg) NetDesignPanel.vStartImg.elementAt(
              count);
          sX = rtImg.getXPos()+rtImg.getWide()/2;
          sY = rtImg.getYPos()+rtImg.getHigh()/2;
        }
        else if (flagS.equalsIgnoreCase("S")) {
          SwitchImg swImg = (SwitchImg) NetDesignPanel.vStartImg.elementAt(
              count);
          sX = swImg.getXPos()+swImg.getWide()/2;
          sY = swImg.getYPos()+swImg.getHigh()/2;
        } //end if flag "S" & "R"
        else { // flagS = "H"
          HostImg hoImg = (HostImg) NetDesignPanel.vStartImg.elementAt(
              count);
          sX = hoImg.getXPos()+hoImg.getWide()/2;
          sY = hoImg.getYPos()+hoImg.getHigh()/2;
        } //end if flag "S" & "R"

        if (flagE.equalsIgnoreCase("R")) {
          RouterImg rtImg = (RouterImg) NetDesignPanel.vEndImg.elementAt(count);
          eX = rtImg.getXPos()+rtImg.getWide()/2;
          eY = rtImg.getYPos()+rtImg.getHigh()/2;
        }
        else { // flagE = "S"
          SwitchImg swImg = (SwitchImg) NetDesignPanel.vEndImg.elementAt(count);
          eX = swImg.getXPos()+swImg.getWide()/2;
          eY = swImg.getYPos()+swImg.getHigh()/2;
        } //end if flag "S" & "R"

        if (lineC.equalsIgnoreCase("S")){
          g.setColor(Color.MAGENTA);
          g.drawLine(sX,sY,eX,eY);
          g.setColor(Color.BLACK);
          g.drawString(""+netAddress,(sX+eX)/2,(sY+eY)/2);
        }else if (lineC.equalsIgnoreCase("E")){
          g.setColor(Color.BLUE);
          g.drawLine(sX,sY,eX,eY);
          g.setColor(Color.BLACK);
          g.drawString(""+netAddress,(sX+eX)/2-(netAddress.length()/2),(sY+eY)/2);
        }else {}

        int posSX = 0,posSY = 0;
        int posEX = 0,posEY = 0;

        if (sX < eX){
          posSX = sX+30;
          posEX = eX-30;
        }else {
          posSX = sX-30;
          posEX = eX+30;
        }
        if (sY < eY){
          posSY = sY+40;
          posEY = eY-30;
        }
        else {
          posSY = sY-30;
          posEY = eY+40;
        }

        g.drawString(""+strS,posSX,posSY);
        g.drawString(""+strE,posEX,posEY);

      }//end for loop
    }catch (Exception exc) {exc.printStackTrace();
    }

    //draw Host
    for (int i = 0; i <= vHostImg.size()-1 ; i++){
      Host host = (Host)Frame1.vHost.elementAt(i);
      HostImg hostImg = (HostImg)vHostImg.elementAt(i);
      g.drawImage(hostImg.getImage(),hostImg.getXPos(),hostImg.getYPos(),this);
      g.drawString(host.getHostIPAddress(),
                   (hostImg.getXPos()+(hostImg.getWide())/2)-(host.getHostIPAddress().length()*7/2),
                   (hostImg.getYPos()+hostImg.getHigh()+7));

    }//end draw Host

/*    // draw Wire
    for (int i = 0; i <= vWireImg.size()-1 ; i++){
      Wire wire = (Wire)Frame1.vWire.elementAt(i);
      WireImage wireImg = (WireImage)vWireImg.elementAt(i);
      g.drawImage(wireImg.getImage(),wireImg.getXPos(),wireImg.getYPos(),this);
      g.drawString(wire.getNetworkAddress(),
                   (wireImg.getXPos()+(wireImg.getWide())/2)-(wire.getNetworkAddress().length()*7/2),
                   (wireImg.getYPos()+wireImg.getHigh()));
    }//end draw Wire
*/
    // draw Router
    if (vRouterImg.size() > 0){
      for (int i = 0; i <= vRouterImg.size()-1 ; i++){
        Router router1 = (Router)Frame1.vRouter.elementAt(i);
        RouterImg rimg1 = (RouterImg)vRouterImg.elementAt(i);
        g.drawImage(rimg1.getImage(),rimg1.getXPos(),rimg1.getYPos(),this);
        g.drawString(router1.getRouterName(),
                     (rimg1.getXPos()+(rimg1.getWide())/2)-(router1.getRouterName().length()*7/2),
                     (rimg1.getYPos()+rimg1.getHigh()));
      }//end for (paint)
    }//end if (vRouterImg.size() > 0)
    else ;//end draw Router

    // draw Switch
    if (vSwitchImg.size() > 0){
      for (int i = 0; i <= vSwitchImg.size()-1 ; i++){
        Switch switch1 = (Switch)Frame1.vSwitch.elementAt(i);
        SwitchImg simg1 = (SwitchImg)vSwitchImg.elementAt(i);
        g.drawImage(simg1.getImage(),simg1.getXPos(),simg1.getYPos(),this);
        g.drawString(switch1.getSwitchName(),
                     (simg1.getXPos()+(simg1.getWide())/2)-(switch1.getSwitchName().length()*7/2),
                     (simg1.getYPos()+simg1.getHigh()));
      }//end for (paint)
    }//end if (vRouterImg.size() > 0)
    else ;//end draw Router

  }//end paintComponent(Graphic g)

//-------------------Mouse Dragged--------------------------//
  void this_mouseDragged(MouseEvent e) {
    if (pressRouter){
      dx = e.getX();
      dy = e.getY();
      if ((dx < this.getWidth()) && (dx >= 0) &&
          (dy < this.getHeight()) && (dy >= 0))
      {
        rimg.setXPos(e.getX()- diffx);
        rimg.setYPos(e.getY()- diffy);
        repaint();
      }
    }//end press pressR

    else if (pressSwitch) {
      dx = e.getX();
      dy = e.getY();
      if ((dx < this.getWidth()) && (dx >= 0) &&
          (dy < this.getHeight()) && (dy >= 0))
      {
        simg.setXPos(e.getX()- diffx);
        simg.setYPos(e.getY()- diffy);
        repaint();
      }
    }//end press pressR

    else if (pressHost){
      dx = e.getX();
      dy = e.getY();
      if ((dx < this.getWidth()) && (dx >= 0) &&
          (dy < this.getHeight()) && (dy >= 0))
      {
        himg.setXPos(e.getX()- diffx);
        himg.setYPos(e.getY()- diffy);
        repaint();
      }
    }//end press Host

/*    else if (pressWire){
      dx = e.getX();
      dy = e.getY();
      if ((dx < this.getWidth()-60) && (dx >= 0)&&
          (dy < this.getHeight()-69) && (dy >= 0))
      {
        wimg.setXPos(e.getX()- diffx);
        wimg.setYPos(e.getY()- diffy);
        repaint();
      }//end if
    }//end press pressW*/
  }//end mouseDrag Event

//-----------------Mouse Released--------------------//
  void this_mouseReleased(MouseEvent e) {
    pressRouter = false;
    pressSwitch = false;
    pressHost = false;
//    pressWire = false;

    if (e.isPopupTrigger() && ((Frame1.vRouter.size()>=1)||(Frame1.vSwitch.size()>=1)||(Frame1.vHost.size()>=1))) {
      if (popupMode == 1) {
        jPopupMenu1.show(e.getComponent(), e.getX(), e.getY());
      }else if (popupMode == 2){
        jPopupMenu2.show(e.getComponent(), e.getX(), e.getY());
      }else if (popupMode == 3){
        jPopupMenu3.show(e.getComponent(), e.getX(), e.getY());
      }
    }

  }//end mouseReleased Event

//-------------------Mouse Pressed----------------------//
  void this_mousePressed(MouseEvent e) {
    //Left Click
    if (e.getModifiers()==16){
      int counterR = 0;
      int counterS = 0;
      int counterH = 0;
//      int counterW = 0;
      int lastrouter = vRouterImg.size() - 1;
      int lastswitch = vSwitchImg.size() - 1;
      int lasthost = vHostImg.size() - 1;
//      int lastwire = vWireImg.size() - 1;

      pressRouter = false;
      pressSwitch = false;
      pressHost = false;
//      pressWire = false;

      //check click router
      while ( (counterR < vRouterImg.size()) && (!pressRouter)) {
        rimg = (RouterImg) vRouterImg.elementAt(lastrouter);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > rimg.getXPos()) && (dx < rimg.getXPos() + rimg.getWide()) &&
            (dy > rimg.getYPos()) && (dy < rimg.getYPos() + rimg.getHigh())) {
          pressRouter = true;
          doubleClickMode = 1;
          diffx = e.getX() - rimg.getXPos();
          diffy = e.getY() - rimg.getYPos();
          selectActiveRouter(lastrouter);
        }
        counterR++;
        lastrouter--;
      } //end while

      //check click switch
      while ( (counterS < vSwitchImg.size()) && (!pressSwitch)) {
        simg = (SwitchImg) vSwitchImg.elementAt(lastswitch);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > simg.getXPos()) && (dx < simg.getXPos() + simg.getWide()) &&
            (dy > simg.getYPos()) && (dy < simg.getYPos() + simg.getHigh())) {
          pressSwitch = true;
          doubleClickMode = 2;
          diffx = e.getX() - simg.getXPos();
          diffy = e.getY() - simg.getYPos();
          selectActiveSwitch(lastswitch);
        }
        counterS++;
        lastswitch--;
      } //end while

      //check click Host
      while ( (counterH < vHostImg.size()) && (!pressHost)) {
        himg = (HostImg) vHostImg.elementAt(lasthost);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > himg.getXPos()) && (dx < himg.getXPos() + himg.getWide()) &&
            (dy > himg.getYPos()) && (dy < himg.getYPos() + himg.getHigh())) {
          pressHost = true;
          doubleClickMode = 3;
          diffx = e.getX() - himg.getXPos();
          diffy = e.getY() - himg.getYPos();
          selectActiveHost(lasthost);
        }
        counterH++;
        lasthost--;
      } //end while

/*      //check click wire
      while ( (counterW < vWireImg.size()) && (!pressWire)) {
        wimg = (WireImage) vWireImg.elementAt(lastwire);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > wimg.getXPos()) && (dx < wimg.getXPos() + wimg.getWide()) &&
            (dy > wimg.getYPos()) && (dy < wimg.getYPos() + wimg.getHigh())) {
          pressWire = true;
          doubleClickMode = 3;
          diffx = e.getX() - wimg.getXPos();
          diffy = e.getY() - wimg.getYPos();
          selectActiveWire(lastwire);
        }
        counterW++;
        lastwire--;
      } //end while*/
    }//end if chk (mouseModifier ==16)

    //Right Click
    else {
      System.out.println("Show Menu");
      int counterR = 0;
      int counterS = 0;
      int counterH = 0;
//      int counterW = 0;
      int lastrouter = vRouterImg.size() - 1;
      int lastswitch = vSwitchImg.size() - 1;
      int lasthost = vHostImg.size() - 1;
//      int lastwire = vWireImg.size() - 1;
      boolean onImage = false;


      //check click router
      while ( (counterR < vRouterImg.size()) && (!pressRouter)) {
        rimg = (RouterImg) vRouterImg.elementAt(lastrouter);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > rimg.getXPos()) && (dx < rimg.getXPos() + rimg.getWide()) &&
             (dy > rimg.getYPos()) && (dy < rimg.getYPos() + rimg.getHigh())) {
          popupMode = 1;
          onImage = true;
          diffx = e.getX() - rimg.getXPos();
          diffy = e.getY() - rimg.getYPos();
          selectActiveRouter(lastrouter);
        }
        counterR++;
        lastrouter--;
      } //end while

      //check click switch
      while ( (counterS < vSwitchImg.size()) && (!pressSwitch)) {
        simg = (SwitchImg) vSwitchImg.elementAt(lastswitch);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > simg.getXPos()) && (dx < simg.getXPos() + simg.getWide()) &&
             (dy > simg.getYPos()) && (dy < simg.getYPos() + simg.getHigh())) {
          popupMode = 2;
          onImage = true;
          diffx = e.getX() - simg.getXPos();
          diffy = e.getY() - simg.getYPos();
          selectActiveSwitch(lastswitch);
        }
        counterS++;
        lastswitch--;
      } //end while

      //check click host
      while ( (counterH < vHostImg.size()) && (!pressHost)) {
        himg = (HostImg) vHostImg.elementAt(lasthost);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > himg.getXPos()) && (dx < himg.getXPos() + himg.getWide()) &&
             (dy > himg.getYPos()) && (dy < himg.getYPos() + himg.getHigh())) {
          popupMode = 3;
          onImage = true;
          diffx = e.getX() - himg.getXPos();
          diffy = e.getY() - himg.getYPos();
          selectActiveHost(lasthost);
        }
        counterH++;
        lasthost--;
      } //end while*/

      if (!onImage){
        popupMode = 0;
      }

/*      //check click wire
      while ( (counterW < vWireImg.size()) && (!pressWire)) {
        wimg = (WireImage) vWireImg.elementAt(lastwire);
        dx = e.getX();
        dy = e.getY();
        if ( (dx > wimg.getXPos()) && (dx < wimg.getXPos() + wimg.getWide()) &&
             (dy > wimg.getYPos()) && (dy < wimg.getYPos() + wimg.getHigh())) {
          popupMode = 3;
          diffx = e.getX() - wimg.getXPos();
          diffy = e.getY() - wimg.getYPos();
          selectActiveWire(lastwire);
        }else {
          popupMode = 0;
        }
        counterW++;
        lastwire--;
      } //end while*/

    }//end Right Click

    //Double Click
    if (e.getClickCount()==2) {
      switch(doubleClickMode){
          case 1 : int lastrouter = Frame1.vRouter.size()-1;
            RouterConsole rcon_temp = (RouterConsole)RouterConsole.vRouterConsole.elementAt(lastrouter);
            rcon_temp.setVisible(true);
            break;
          case 2 : int lastswitch = Frame1.vSwitch.size()-1;
            SwitchConsole scon_temp = (SwitchConsole)SwitchConsole.vSwitchConsole.elementAt(lastswitch);
            scon_temp.setVisible(true);
            break;
//          case 3 : int lastwire = Frame1.vWire.size()-1;
            //dialog box connection create
          case 3 : int lasthost = Frame1.vHost.size()-1;
            //new console host
            break;
          default: break;
      }//end switch case
    }//end Double Click

  }//end mousePressed Event

//------------------Popup Event ------------------------------------------------------//
  //Router
  void deleteRouter_actionPerformed(ActionEvent e) {
    Delete_RouterConsole();
    Delete_Router();
  }
  void consoleRouter_actionPerformed(ActionEvent e) {
    int lastrouter = Frame1.vRouter.size()-1;
    RouterConsole rcon = (RouterConsole)RouterConsole.vRouterConsole.elementAt(lastrouter);
    rcon.setVisible(true);
  }
  void connectRouter_actionPerformed(ActionEvent e) {
    Router rt = (Router)Frame1.vRouter.lastElement();
    Connections connections = new Connections(rt);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = connections.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    connections.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    connections.setVisible(true);
  }

  //Switch
  void deleteSwitch_actionPerformed(ActionEvent e) {
    Delete_SwitchConsole();
    Delete_Switch();
  }
  void consoleSwitch_actionPerformed(ActionEvent e) {
    int lastswitch = Frame1.vSwitch.size()-1;
    SwitchConsole scon = (SwitchConsole)SwitchConsole.vSwitchConsole.elementAt(lastswitch);
    scon.setVisible(true);
  }
  void connectSwitch_actionPerformed(ActionEvent e) {
    Switch sw = (Switch)Frame1.vSwitch.lastElement();
    Connections connections = new Connections(sw);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = connections.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    connections.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    connections.setVisible(true);
  }

  //Host
  void consoleHost_actionPerformed(ActionEvent e){
    Host ho = (Host)Frame1.vHost.lastElement();
    HostConsole hostConsole = new HostConsole(ho);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = hostConsole.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    hostConsole.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    hostConsole.setVisible(true);
  }
  void deleteHost_actionPerformed(ActionEvent e) {
    Delete_Host();
  }

  void connectHost_actionPerformed(ActionEvent e) {
    Host ho = (Host)Frame1.vHost.lastElement();
    Connections connections = new Connections(ho);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = connections.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    connections.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    connections.setVisible(true);
  }


/*
  //Wire
    void deleteWire_actionPerformed(ActionEvent e) {
    Delete_Wire();
  }

  void connect_actionPerformed(ActionEvent e) {
/*    Connections connections = new Connections();
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = connections.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    connections.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    connections.setVisible(true);

  }
*/

//------------------Method-------------------------------
  void selectActiveRouter(int select){
    Router r1 = (Router)Frame1.vRouter.elementAt(select); //temp r1
    RouterImg rimg1 = (RouterImg)NetDesignPanel.vRouterImg.elementAt(select);//temp rimg
    RouterConsole rc = (RouterConsole)RouterConsole.vRouterConsole.elementAt(select);//temp RC

//    System.out.println("select router name ="+r1.getRouterName());
//    System.out.println("select router id ="+r1.getRouterID());
//    System.out.println("select router uniname ="+r1.getRouterUniName());
    Frame1.vRouter.removeElementAt(select); //del router
    NetDesignPanel.vRouterImg.removeElementAt(select);//del rimg
    RouterConsole.vRouterConsole.removeElementAt(select);//del console

    Frame1.vRouter.addElement(r1); //add router last index
    Frame1.setTextProperty(r1); //add text properties router
    NetDesignPanel.vRouterImg.addElement(rimg1);//add img
    RouterConsole.vRouterConsole.addElement(rc);//add RouterConsole
    repaint();
  }//end selectActive

  void selectActiveSwitch(int select){
    Switch s1 = (Switch)Frame1.vSwitch.elementAt(select); //temp r1
//    System.out.println("select switch name = "+s1.getSwitchName());
//    System.out.println("select switch id = "+s1.getSwitchID());
//    System.out.println("select switch uniid ="+s1.getSwitchUniName());
    SwitchImg simg1 = (SwitchImg)NetDesignPanel.vSwitchImg.elementAt(select);//temp rimg
    SwitchConsole sc = (SwitchConsole)SwitchConsole.vSwitchConsole.elementAt(select);//temp SC

    Frame1.vSwitch.removeElementAt(select); //del router
    Frame1.setTextProperty(s1); //add text properties switch
    NetDesignPanel.vSwitchImg.removeElementAt(select);//del simg
    SwitchConsole.vSwitchConsole.removeElementAt(select);//del console

    Frame1.vSwitch.addElement(s1); //add router last index
    NetDesignPanel.vSwitchImg.addElement(simg1);//add img
    SwitchConsole.vSwitchConsole.addElement(sc);//add SwitchConsole
    repaint();
  }//end selectActive

  void selectActiveHost(int select){
    Host h1 = (Host)Frame1.vHost.elementAt(select); //temp h1
//    System.out.println("select Host name ="+h1.getHostID());
//    System.out.println("select Host id ="+h1.getHostUniName());

    HostImg himg1 = (HostImg)NetDesignPanel.vHostImg.elementAt(select);//temp himg

    Frame1.vHost.removeElementAt(select); //del router
    NetDesignPanel.vHostImg.removeElementAt(select);
    Frame1.vHost.addElement(h1); //add router last index
    NetDesignPanel.vHostImg.addElement(himg1);
    repaint();
  }//end selectActive


/*  void selectActiveWire(int select){
    Wire w1 = (Wire)Frame1.vWire.elementAt(select); //temp r1
    System.out.println("select Wire ="+w1.getRouterName());
    WireImage wimg1 = (WireImage)NetDesignPanel.vWireImg.elementAt(select);//temp rimg
    Frame1.vWire.removeElementAt(select); //del router
    NetDesignPanel.vWireImg.removeElementAt(select);
    Frame1.vWire.addElement(w1); //add router last index
    NetDesignPanel.vWireImg.addElement(wimg1);
    repaint();
  }//end selectActive*/

  void Delete_Router() {
    int lastrouter = Frame1.vRouter.size()-1;

    Router r_temp = (Router)Frame1.vRouter.elementAt(lastrouter);
    int r_del_index = r_temp.getRouterID();

    for (int count = vStartImg.size()-1; count >= 0; count--){
      String flagStart = vFlagImgStart.elementAt(count).toString();
      String flagEnd = vFlagImgEnd.elementAt(count).toString();
      RouterImg rimg_tempS = new RouterImg(), rimg_tempE = new RouterImg();
      SwitchImg simg_tempS = new SwitchImg(), simg_tempE = new SwitchImg();
      HostImg himg_tempS = new HostImg(), himg_tempE = new HostImg();

      try {
        if (flagStart.equalsIgnoreCase("R")){
          rimg_tempS = (RouterImg) vStartImg.elementAt(count);
        }else if (flagStart.equalsIgnoreCase("S")) {
          simg_tempS = (SwitchImg) vStartImg.elementAt(count);
        }else {
          himg_tempS = (HostImg) vStartImg.elementAt(count);
        }

        if (flagEnd.equalsIgnoreCase("R")){
          rimg_tempE = (RouterImg) vEndImg.elementAt(count);
        }else if (flagEnd.equalsIgnoreCase("S")) {
          simg_tempE = (SwitchImg) vEndImg.elementAt(count);
        }else {
          himg_tempE = (HostImg)vEndImg.elementAt(count);
        }

        if ( ((r_del_index == rimg_tempS.getIdRouterImg()) && flagStart.equalsIgnoreCase("R")) ||
             ((r_del_index == rimg_tempE.getIdRouterImg()) && flagEnd.equalsIgnoreCase("R")) ||
             ((r_del_index == simg_tempE.getIdSwitchImg()) && flagEnd.equalsIgnoreCase("R")) ||
             ((r_del_index == himg_tempE.getIdHostImg()) && flagEnd.equalsIgnoreCase("R")) ){
          vStartImg.removeElementAt(count);
          vEndImg.removeElementAt(count);
          vFlagImgStart.removeElementAt(count);
          vFlagImgEnd.removeElementAt(count);
          vLineType.removeElementAt(count);
          vNetAddress.removeElementAt(count);
          vStartPortName.removeElementAt(count);
          vEndPortName.removeElementAt(count);
          Connections.vConnectionBegin.removeElementAt(count);
          Connections.vConnectionEnd.removeElementAt(count);
        }else {} //end if
      }catch (Exception ex) {
      }
    }//end for loop del flag and img

    //reset string in other device
    Router router_last = (Router)Frame1.vRouter.lastElement();
    String r_name = router_last.getRouterUniName();

    for (int indexS = 0; indexS < Port.vTemp_PortS.size(); indexS++){
      IntSerial intS = (IntSerial)Port.vTemp_PortS.elementAt(indexS);
      String s_connectwith = intS.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (r_name.equalsIgnoreCase(uniname)){
        intS.setConnectionWith("");
        intS.setNetworkAddress("");
        intS.setOpStatus(false);
      }//end if
    }//end for

    for (int indexE = 0; indexE < Port.vTemp_PortE.size(); indexE++){
      IntEthernet intE = (IntEthernet)Port.vTemp_PortE.elementAt(indexE);
      String s_connectwith = intE.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (r_name.equalsIgnoreCase(uniname)){
        intE.setConnectionWith("");
        intE.setNetworkAddress("");
        intE.setOpStatus(false);
      }//end if
    }//end for

    Frame1.vRouter.removeElementAt(lastrouter);
    vRouterImg.removeElementAt(lastrouter);

    repaint();
  }//end Delete_Router

  void Delete_RouterConsole() {
    int lastrouter = Frame1.vRouter.size()-1;
    RouterConsole rc_temp = (RouterConsole)RouterConsole.vRouterConsole.elementAt(lastrouter);
    rc_temp.closeConsole();
    RouterConsole.vRouterConsole.removeElementAt(lastrouter);
  }//end Delete_RouterConsole

  void Delete_Switch() {
    int lastswitch = Frame1.vSwitch.size()-1;

    Switch s_temp = (Switch)Frame1.vSwitch.elementAt(lastswitch);
    int s_del_index = s_temp.getSwitchID();

    for (int count = vStartImg.size()-1; count >= 0; count--){
      String flagStart = vFlagImgStart.elementAt(count).toString();
      String flagEnd = vFlagImgEnd.elementAt(count).toString();
      RouterImg rimg_tempS = new RouterImg(), rimg_tempE = new RouterImg();
      SwitchImg simg_tempS = new SwitchImg(), simg_tempE = new SwitchImg();
      HostImg himg_tempS = new HostImg(), himg_tempE = new HostImg();

      try {
        if (flagStart.equalsIgnoreCase("R")){
          rimg_tempS = (RouterImg) vStartImg.elementAt(count);
        }else if (flagStart.equalsIgnoreCase("S")) {
          simg_tempS = (SwitchImg) vStartImg.elementAt(count);
        }else {
          himg_tempS = (HostImg) vStartImg.elementAt(count);
        }

        if (flagEnd.equalsIgnoreCase("R")){
          rimg_tempE = (RouterImg) vEndImg.elementAt(count);
        }else if (flagEnd.equalsIgnoreCase("S")){
          simg_tempE = (SwitchImg) vEndImg.elementAt(count);
        }else {
          himg_tempE = (HostImg) vEndImg.elementAt(count);
        }

        if ( ((s_del_index == simg_tempS.getIdSwitchImg()) && flagStart.equalsIgnoreCase("S")) ||
             ((s_del_index == rimg_tempS.getIdRouterImg()) && flagEnd.equalsIgnoreCase("S")) ||
             ((s_del_index == simg_tempE.getIdSwitchImg()) && flagEnd.equalsIgnoreCase("S")) ||
             ((s_del_index == himg_tempE.getIdHostImg()) && flagEnd.equalsIgnoreCase("S")) ){
          vStartImg.removeElementAt(count);
          vEndImg.removeElementAt(count);
          vFlagImgStart.removeElementAt(count);
          vFlagImgEnd.removeElementAt(count);
          vLineType.removeElementAt(count);
          vNetAddress.removeElementAt(count);
          vStartPortName.removeElementAt(count);
          vEndPortName.removeElementAt(count);
          Connections.vConnectionBegin.removeElementAt(count);
          Connections.vConnectionEnd.removeElementAt(count);
        }else {} //end if
      }catch (Exception ex) {
      }
    }//end for loop del flag and img

    //reset string in other device
    Switch sw_last = (Switch)Frame1.vSwitch.lastElement();
    String s_name = sw_last.getSwitchUniName();

    for (int indexS = 0; indexS < Port.vTemp_PortS.size(); indexS++){
      IntSerial intS = (IntSerial)Port.vTemp_PortS.elementAt(indexS);
      String s_connectwith = intS.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (s_name.equalsIgnoreCase(uniname)){
        intS.setConnectionWith("");
        intS.setNetworkAddress("");
        intS.setOpStatus(false);
      }//end if
    }//end for

    for (int indexE = 0; indexE < Port.vTemp_PortE.size(); indexE++){
      IntEthernet intE = (IntEthernet)Port.vTemp_PortE.elementAt(indexE);
      String s_connectwith = intE.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (s_name.equalsIgnoreCase(uniname)){
        intE.setConnectionWith("");
        intE.setNetworkAddress("");
        intE.setOpStatus(false);
      }//end if
    }//end for

    Frame1.vSwitch.removeElementAt(lastswitch);
    vSwitchImg.removeElementAt(lastswitch);

    repaint();
  }//end Delete_Router

  void Delete_SwitchConsole() {
    int lastswitch = Frame1.vSwitch.size()-1;
    SwitchConsole sc_temp = (SwitchConsole)SwitchConsole.vSwitchConsole.elementAt(lastswitch);
    sc_temp.closeConsole();
    SwitchConsole.vSwitchConsole.removeElementAt(lastswitch);
  }//end Delete_RouterConsole

  void Delete_Host() {
    int lasthost = Frame1.vHost.size()-1;

    Host h_temp = (Host)Frame1.vHost.elementAt(lasthost);
    int h_del_index = h_temp.getHostID();

    for (int count = vStartImg.size()-1; count >= 0; count--){
      String flagStart = vFlagImgStart.elementAt(count).toString();
      HostImg himg_tempS = new HostImg(), himg_tempE = new HostImg();

      try {
        himg_tempS = (HostImg) vStartImg.elementAt(count);

        if ((flagStart.equalsIgnoreCase("H")) && (himg_tempS.getIdHostImg() == h_del_index) ){
          vStartImg.removeElementAt(count);
          vEndImg.removeElementAt(count);
          vFlagImgStart.removeElementAt(count);
          vFlagImgEnd.removeElementAt(count);
          vLineType.removeElementAt(count);
          vNetAddress.removeElementAt(count);
          vStartPortName.removeElementAt(count);
          vEndPortName.removeElementAt(count);
          Connections.vConnectionBegin.removeElementAt(count);
          Connections.vConnectionEnd.removeElementAt(count);
        }else {}
      }//end try
      catch (Exception ex) {}
    }//end for

//reset string in other device
    Host host_last = (Host)Frame1.vHost.lastElement();
    String h_name = host_last.getHostUniName();

    for (int indexS = 0; indexS < Port.vTemp_PortS.size(); indexS++){
      IntSerial intS = (IntSerial)Port.vTemp_PortS.elementAt(indexS);
      String s_connectwith = intS.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (h_name.equalsIgnoreCase(uniname)){
        intS.setConnectionWith("");
        intS.setNetworkAddress("");
        intS.setOpStatus(false);
      }//end if
    }//end for

    for (int indexE = 0; indexE < Port.vTemp_PortE.size(); indexE++){
      IntEthernet intE = (IntEthernet)Port.vTemp_PortE.elementAt(indexE);
      String s_connectwith = intE.getConnectionWith();
      String uniname = "";
      if (!(s_connectwith.equalsIgnoreCase(""))){
        uniname = RouterConsole.cutInput(s_connectwith,0);
      }
      if (h_name.equalsIgnoreCase(uniname)){
        intE.setConnectionWith("");
        intE.setNetworkAddress("");
        intE.setOpStatus(false);
      }//end if
    }//end for

    Frame1.vHost.removeElementAt(lasthost);
    vHostImg.removeElementAt(lasthost);

    repaint();
  }//end Delete_Host

}//end this class