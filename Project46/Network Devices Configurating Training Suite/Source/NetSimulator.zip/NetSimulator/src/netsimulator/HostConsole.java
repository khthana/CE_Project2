package netsimulator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;


public class HostConsole extends JDialog {

  private Host host;
  private Router rt = null;
  private Switch sw = null;
  private String cmd[] = {"ping"};
  private String argument = "";

  private EtchedBorder etchedBorder  = new EtchedBorder();

  JPanel panel1 = new JPanel();
  JLabel jLabelSelectCmd = new JLabel();
  JComboBox jComboBoxCmd;
  JLabel jLabelInput = new JLabel();
  JTextField jTextFieldParameter = new JTextField();
  JButton jButtonCancle = new JButton();
  JButton jButtonRun = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea jTextAreaOutput = new JTextArea();

  public HostConsole(Frame frame, String title, boolean modal,Host ho) {
    super(frame, title, modal);
    try {
      host = ho;
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public HostConsole(Host ho) {
    this(null, "", true,ho);
  }

  private void jbInit() throws Exception {
    this.setTitle("- = Device Connections = -");
    this.setResizable(false);
    this.setFocusableWindowState(true);

    panel1.setLayout(null);
    panel1.setBorder(etchedBorder);
    panel1.setPreferredSize(new Dimension(400,400));

    jLabelSelectCmd.setText("Select command :");
    jLabelSelectCmd.setBounds(new Rectangle(20, 13, 119, 22));

    jComboBoxCmd = new JComboBox(cmd);
    jComboBoxCmd.setBounds(new Rectangle(193, 13, 132, 22));
    jComboBoxCmd.setBackground(Color.white);

    jLabelInput.setText("Input parameter :");
    jLabelInput.setBounds(new Rectangle(20, 45, 119, 22));

    jTextFieldParameter.setText("");
    jTextFieldParameter.setBounds(new Rectangle(193, 45, 181, 22));

    jButtonCancle.setBounds(new Rectangle(208, 329, 76, 37));
    jButtonCancle.setText("Cancle");
    jButtonCancle.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancle_actionPerformed(e);
      }
    });//end listen

    jButtonRun.setBounds(new Rectangle(300, 329, 76, 37));
    jButtonRun.setText("RUN");
    jButtonRun.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonRun_actionPerformed(e);
      }
    });//end listen

    jScrollPane1.setBounds(new Rectangle(20, 93, 356, 215));
    jTextAreaOutput.setText("Output");
    jTextAreaOutput.setEditable(false);

    getContentPane().add(panel1);

    panel1.add(jLabelSelectCmd, null);
    panel1.add(jLabelInput, null);
    panel1.add(jScrollPane1, null);
    panel1.add(jTextFieldParameter, null);
    panel1.add(jComboBoxCmd, null);
    panel1.add(jButtonRun, null);
    panel1.add(jButtonCancle, null);
    jScrollPane1.getViewport().add(jTextAreaOutput, null);
  }////end jbInit()

  public void jButtonRun_actionPerformed(ActionEvent e) {
    String argu = jTextFieldParameter.getText();
    String hostIP = host.getHostIPAddress();
    String output_result = "";
    boolean ping_found = false;
    boolean vlan_pass = false;

    try {

    if (RouterIOS120.isIp(argu)){
      argument = jTextFieldParameter.getText();

      Host HO = (Host)Frame1.vHost.lastElement();

      String host_connect_with = HO.getHostConnectionWith();
      String device_Dest = Connections.cutString(host_connect_with,0," ");
      if (device_Dest.charAt(0) == 'S'){
        for (int find_index = 0; find_index < Frame1.vSwitch.size(); find_index++){
          Switch sw = (Switch)Frame1.vSwitch.elementAt(find_index);
          String name_sw = sw.getSwitchUniName();
          if (device_Dest.equalsIgnoreCase(name_sw)){
            AddressLearning.vChkAlready.removeAllElements();
            ping_found = sw.findDestination(argument);
            vlan_pass = VLAN.chkVLAN(HO.getHostIPAddress(),argument);
          }
        }
      }

      if (ping_found && vlan_pass){
        output_result = "Pinging "+argument+" with 32 bytes of data:\n\n"+
            "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
            "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
            "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
            "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n\n"+
            "Ping statistics for "+argument+":\n"+
            "    Packets: Sent = 4, Received = 4, Lost = 0 <0% loss>,\n"+
            "Approximate round trip times in milli-seconds:\n"+
            "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
      }else {
        output_result = "Pinging "+argument+" with 32 bytes of data:\n\n"+
            "Request time out.\n"+
            "Request time out.\n"+
            "Request time out.\n"+
            "Request time out.\n\n"+
            "Ping statistics for "+argument+":\n"+
            "    Packets: Sent = 4, Received = 0, Lost = 4 <100% loss>,\n"+
            "Approximate round trip times in milli-seconds:\n"+
            "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";

      }
      jTextAreaOutput.setText(output_result);
    }else{
      JOptionPane.showMessageDialog(null,"Invalid IP Address","Warning",JOptionPane.WARNING_MESSAGE);
    }

    }catch (Exception nullex){nullex.printStackTrace();
      output_result = "Pinging "+argument+" with 32 bytes of data:\n\n"+
          "Request time out.\n"+
          "Request time out.\n"+
          "Request time out.\n"+
          "Request time out.\n\n"+
          "Ping statistics for "+argument+":\n"+
          "    Packets: Sent = 4, Received = 0, Lost = 4 <100% loss>,\n"+
          "Approximate round trip times in milli-seconds:\n"+
          "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
        jTextAreaOutput.setText(output_result);
    }
  }//end Button Run

  public void jButtonCancle_actionPerformed(ActionEvent e) {
    this.dispose();
  }/////end Button Cancle



}