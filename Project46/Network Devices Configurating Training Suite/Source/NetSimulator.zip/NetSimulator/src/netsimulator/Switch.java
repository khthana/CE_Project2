package netsimulator;

import java.util.*;


class Switch {

  static String root_bridge_id = "";
  static int root_id = 32768;

  protected String priority = "32768";
  protected String bridgeID;
  protected String switchMacAddress;
  protected String SwitchName = "Switch1";

  protected AddressLearning addressLearning;
  protected CDP cdp = new CDP(this);

  protected VLAN vlan = new VLAN();
  protected Vector vVlan = new Vector();

  protected int ID; //Switch ID (fix)

  protected boolean activeSelS = false;
  protected int swMode = 1;
  protected Port swPort;
  protected SwitchImg simg;
  protected Vector ethernetName;

  protected boolean SPTStatus = false;

  protected int spt_priority = 128; //default   range[0-65535]
  protected int mac_address_aging_time = 100;// range[10-1000000]
  protected int spt_fw_time = 15; //default     range[4-30]
  protected int spt_hello_time = 2; //default   range[1-10]
  protected int spt_max_age = 20; //default     range[6-40]

//Constructor ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  public Switch() {
    SwitchName = "";
    switchMacAddress = IntEthernet.genMacAddress();
    Switch.setBridgeID(switchMacAddress);
    bridgeID = priority+"."+switchMacAddress;
  }//end Constructor

  public Switch(String swName){
    SwitchName = chkAndsetSwitchName(swName);
    switchMacAddress = IntEthernet.genMacAddress();
    Switch.setBridgeID(switchMacAddress);
    bridgeID = priority+"."+switchMacAddress;
    vlan.setDefault();
    vlan.initVlanMember(this.getEport());
    vVlan.add(vlan);
    addressLearning = new AddressLearning(this);
    addressLearning.start();
    cdp.start();
  }//end Switch(string)

  public Switch(String swName,int serialPort,int ethernetPort,int tokenringPort){
    SwitchName = chkAndsetSwitchName(swName);
    createPort(serialPort,ethernetPort,tokenringPort);
    switchMacAddress = IntEthernet.genMacAddress();
    Switch.setBridgeID(switchMacAddress);
    bridgeID = priority+"."+switchMacAddress;
    vlan.setDefault();
    vlan.initVlanMember(this.getEport());
    vVlan.add(vlan);
    addressLearning = new AddressLearning(this);
    addressLearning.start();
    cdp.start();
  }// end Switch(string,port,port,port)

  //---------------------Switch Method------------------------
  public String getSwitchMacAddress(){
    return switchMacAddress;
  }//end get switch macaddress

  public String getSwitchBridgeID(){
    return bridgeID;
  }

  public void createPort(int serial,int ethernet,int tokenring){
    swPort = new Port(serial,ethernet,tokenring);
    ethernetName = swPort.getEname();
  }//end createPort

  public void getSport(){

  }
  public Vector getEport(){
    return swPort.getEport();
  }
  public void getTport(){

  }

  public Vector getEname(){
    return ethernetName;
  }//end get Ethernet name

  public String getSwitchName(){
    return SwitchName;
  }//end getSwitchName
  public void setSwitchName(String swName){
    SwitchName = swName;
  }//end setSwitchName

  public int getMode(){
    return swMode;
  }//end getMode
  public void setMode(int mode){
    swMode = mode;
  }//end setMode

  public String getPriority(){
    return priority;
  }

  public void setSPTStatus(boolean sptStatus){
    SPTStatus = sptStatus;
  }
  public boolean getSPTStatus(){
    return SPTStatus;
  }

  public void setSwitchImg(SwitchImg swImg){
    simg = swImg;
  }
  public SwitchImg getSwitchImg(){
    return simg;
  }

  public Vector getVectorRouterNB(){
    return cdp.getRouterNB();
  }

  public Vector getVectorSwitchNB(){
    return cdp.getSwitchNB();
  }

  public boolean isSelected(){
    return activeSelS;
  }//end isSelected

  public void resetSelected(){
    activeSelS = false;
  }//end resetSelected

  public String getSwitchUniName(){
    return "S"+ID;
  }//end getSwitchUniName

  public int getSwitchID(){
    return ID;
  }//end getSwitchID

  public String chkAndsetSwitchName(String name){
      String sName = "Switch";
      int sNumber = 0;

      boolean found = false;
      boolean dup = true;
      boolean flag = true; //for optimize

      while(dup) {
        ++sNumber;
        flag = true;
        found = false;
        for (int i=0; (i < Frame1.vSwitch.size())&&flag ; i++) {
          String alreadyName = ((Switch)Frame1.vSwitch.elementAt(i)).getSwitchName();
          if (alreadyName.equalsIgnoreCase(sName + sNumber)){
            System.out.println(sName+sNumber);
            found = true;
            flag = false;
          }//end if
        }//end for
        dup = found;
      }//end while(dup)

      System.out.println("sName+sNumber = "+sName+sNumber);
      System.out.println("Switch ID = "+sNumber);
      ID = sNumber;
      return sName+sNumber;
  }//end constructor switch(String)

//-------- SWITCH OPERATION -----------------------------

  public boolean findDestination(String ip){
    return addressLearning.lookupTable(ip);
  }

//*************  OTHER METHOD *******************************************************//
  public boolean hasInterface(String intName){
    boolean found = false;
    for (int index = 0; index < ethernetName.size(); index++){
      String indexName = ethernetName.elementAt(index).toString();
      if (indexName.equalsIgnoreCase(intName)){
        found = true;
      }
    }//end for ethernet
    return found;
  }//end hasInterface

  public Vector getMacAddressTable(){
    return addressLearning.getMacAddressTable();
  }

  public Vector getVlan_per_interface(){
    return addressLearning.getVlan_per_interface();
  }

  public void setMac_address_aging_time(int agtime){
    mac_address_aging_time = agtime;
  }
  public int getMac_address_aging_time(){
    return mac_address_aging_time;
  }

  public void setSPT_fw_time(int fwtime){
    spt_fw_time = fwtime;
  }
  public int getSPT_fw_time(){
    return spt_fw_time;
  }

  public void setSPT_priority(int priority){
    spt_priority = priority;
  }
  public int getSPT_priority(){
    return spt_priority;
  }

  public void setSPT_hello_time(int hellotime){
    spt_hello_time = hellotime;
  }
  public int getSPT_hello_time(){
    return spt_hello_time;
  }

  public void setSPT_max_age(int age){
    spt_max_age = age;
  }
  public int getSPT_max_age(){
    return spt_max_age;
  }

  public IntEthernet getClassEthernet(String intName){
    IntEthernet returnE = new IntEthernet();
    for (int index = 0; index < getEport().size(); index++){
      IntEthernet intE = (IntEthernet)getEport().elementAt(index);
      String indexName = intE.getEname().toString();
      if (indexName.equalsIgnoreCase(intName)){
        returnE = intE;
      }
    }//end for ethernet
    return returnE;
  }

  static void setBridgeID(String mac_in){
    String makeID = RouterConsole.cutInput(mac_in,0,".");
    int id = 1;
    try {
      id = Integer.parseInt(makeID.charAt(0)+"");
    }catch (Exception e) { id = 10 ;}

    if (id < Switch.root_id){
      Switch.root_id = id;
      Switch.root_bridge_id = mac_in;
    }

  }

}//End Switch
