package netsimulator;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Port {

  static Vector vMacAddress = new Vector();
  static Vector vIPAddress = new Vector();

  private Vector vPortS = new Vector();
  private Vector vPortE = new Vector();
  private Vector vPortT = new Vector();

  static Vector vTemp_PortS = new Vector();
  static Vector vTemp_PortE = new Vector();

  private Vector vNameS = new Vector();
  private Vector vNameE = new Vector();
  private Vector vNameT = new Vector();

  public Port(){

  }//end Constructor

  public Port(int serialInt, int ethernetInt, int tokenringInt){

    for(int countS = 0; ((countS < serialInt)&&(serialInt > 0)); countS++) {
      IntSerial sTemp = new IntSerial();//new S_port
      sTemp.setS_FullName("Serial"+countS);
      sTemp.setS_ID(countS);
      sTemp.setSname("S0/"+countS);
      System.out.println("Serial port"+sTemp.getSname());
      vPortS.add(countS,sTemp);
      vNameS.add(countS,sTemp.getSname());
      vTemp_PortS.add(sTemp);
    }//end make serialPort

    for(int countE = 0; ((countE < ethernetInt)&&(ethernetInt > 0)); countE++) {
      IntEthernet eTemp = new IntEthernet();//new & gen MAC
      eTemp.setE_FullName("FastEthernet"+countE);
      eTemp.setE_ID(countE);
      eTemp.setEname("Fe0/"+countE);
      String macin = IntEthernet.genMacAddress();
      eTemp.setMacAddress(macin);
      System.out.println("MacAddress port"+eTemp.getEname()+" = "+eTemp.getMacAddress());
      vPortE.add(countE,eTemp);
      vNameE.add(countE,eTemp.getEname());
      vTemp_PortE.add(eTemp);
    }//end make ethernetPort

      System.out.println("vMacAddress.size = "+this.vMacAddress.size());
      System.out.println("vPortE.size = "+vPortE.size());
      System.out.println("vPortS.size = "+vPortS.size());
      System.out.println("vPortS.size = "+vNameS.size());

  }//end constructor(s,e,t)

//------------------ Method ------------------------------///////////////
  public Vector getSport(){
    return vPortS;
  }//end get Serial port
  public Vector getEport(){
    return vPortE;
  }//end get Ethernet port
  public Vector getTport(){
    return vPortT;
  }//end get Tokenring port

  public Vector getSname(){
    return vNameS;
  }//end get Serial port
  public Vector getEname(){
    return vNameE;
  }//end get Ehternet port
  public Vector getTname(){
    return vNameT;
  }//end get Tokenring port

}