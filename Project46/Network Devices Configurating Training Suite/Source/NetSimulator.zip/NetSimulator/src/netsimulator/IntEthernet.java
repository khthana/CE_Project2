package netsimulator;

import java.util.*;

class IntEthernet {

  private String E_FullName = "";
  private int E_id = 0;

  private String Ename = "";
  private String macAddress = "";
  private String ipAddress = "";
  private String ipSubnet = "";
  private String connectedWith = "";
  private String connectInformation = "";  //mac_address
  private String networkAddress = "";
  private String description = "";
  //  private String subnet;
  private boolean myStatus = false;
  private String myStatusString;

  private boolean used = false;

  private String type;

  private String opIP = "";
  private boolean opStatus = false;

  private int vlanNum = 1;//default   range[1-1005]
  private int vlanAccessNum = 1;

  private Vector trunk_obtain_vlan = new Vector();

  private String switch_port_mode = "";

  IntEthernet(){

//    macAddress = genMacAddress();

  }//end Constructor

//----------- Method ---------------------------------------------------
  public void setVLAN(int vlan){
    vlanNum = vlan;
  }//end setVLAN

  public int getVLAN(){
    return vlanNum;
  }//end getVLAN

  public void setVLAN_Access(int vlanAccess){
    vlanAccessNum = vlanAccess;
  }//end set vlan access <num>
  public int getVLAN_Access(){
    return vlanAccessNum;
  }//end get vlan access

  public void setE_FullName(String e_fullname){
    E_FullName = e_fullname;
  }
  public String getE_FullName(){
    return E_FullName;
  }
  public void setE_ID(int e_id){
    E_id = e_id;
  }
  public int getE_ID(){
    return E_id;
  }

  public void setEname(String eName){
    Ename = eName;
  }//end setEname

  public String getEname(){
    return Ename;
  }//end getEname

  public void setMacAddress(String macIn){
    macAddress = macIn;
  }//end setMacAddress

  public String getMacAddress() {
    return macAddress;
  }//end getMacAddress

  public void setIPAddress(String ip){
    ipAddress = ip;
  }

  public String getIPAddress(){
    return ipAddress;
  }

  public void setIPSubnet(String ip){
    ipSubnet = ip;
  }
  public String getIPSubnet(){
    return ipSubnet;
  }

  public String getConnectInformation(){
    return connectInformation;
  }

  public void setDescription(String message){
    description = message;
  }
  public String getDescription(){
    return description;
  }

  public void setConnectionWith(String connectWith){
    connectedWith = connectWith;

    String dev = Connections.cutString(connectWith,0," ");
    if (dev.charAt(0) == 'R'){
      for (int count = 0; count < Frame1.vRouter.size(); count++){
	Router rt = (Router)Frame1.vRouter.elementAt(count);
	if (dev.equalsIgnoreCase(rt.getRouterUniName())){
	  connectInformation = rt.getRouterMacAddress();
	}
      }
    }else if (dev.charAt(0) == 'S'){
      for (int count = 0; count < Frame1.vSwitch.size(); count++){
	Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
	if (dev.equalsIgnoreCase(sw.getSwitchUniName())){
	  connectInformation = sw.getSwitchMacAddress();
	}
      }
    }else if (dev.charAt(0) == 'H'){
      for (int count = 0; count < Frame1.vHost.size(); count++){
	Host ho = (Host)Frame1.vHost.elementAt(count);
	if (dev.equalsIgnoreCase(ho.getHostUniName())){
	  connectInformation = ho.getHostMacAddress();
	}
      }
    }

  }//end setConnectWith

  public String getConnectionWith(){
    return connectedWith;
  }//end getConnectWith

  public void setNetworkAddress(String netAddress){
    networkAddress = netAddress;
  }//end set networkAddress for each interface

  public String getNetworkAddress(){
    return networkAddress;
  }//end get networkAddress for each interface

  public void setSwitch_portMode(String mode){
    switch_port_mode = mode;
  }
  public String getSwitch_portMode(){
    return switch_port_mode;
  }

  public void addVLAN_to_Trunk(String vlan_id){
    trunk_obtain_vlan.addElement(vlan_id);
  }
  public void removeVLAN_to_Trunk(String vlan_id){
    for (int index = 0; index < trunk_obtain_vlan.size(); index++){
      if (trunk_obtain_vlan.elementAt(index).toString().equalsIgnoreCase(vlan_id)){
        trunk_obtain_vlan.removeElementAt(index);
      }//end if
    }//end for
  }
  public void removeALLVLAN_to_Trunk(){
    trunk_obtain_vlan.removeAllElements();
  }

  public void setMyStatus(boolean status){
    myStatus = status;
  }
  public boolean getMyStatus(){
    return myStatus;
  }

  public String getMyStatusString(){
//    String status = "";
    if (myStatus == true){
      myStatusString = "up";
    }else {
      myStatusString = "down";
    }
    return myStatusString;
  }
  public void setMyStatusString(String s){
    this.myStatusString = s;
  }
  public void setOpStatus(boolean bl){
    opStatus = bl;
  }
  public boolean getOpStatus(){
    return opStatus;
  }

  public String getOpIP(){
    return opIP;
  }


  static String genMacAddress() {
    Random r = new Random();
    String mac = new String();
    int tmp;

    do {
      mac = "";
      for (int i=0; i<3; i++) {
	if (i!=0) {
	  mac=mac+".";
	}//end if
	tmp=r.nextInt(65536);
	for (int j=Integer.toHexString(tmp).length(); j<4; j++){
	  mac = mac + "0";
	}//end for
	mac=mac+Integer.toHexString(tmp);
      }//end for
    }while (isExist(mac));

    Port.vMacAddress.addElement(mac);

    return mac;
  }//end genMacAddress()

  public boolean isMacAddress(String mac) {
    mac = mac.toLowerCase();
    if (mac.length()==14) {
      for (int i=0; i<14; i++) {
	if ((i==4) || (i==9)) {
	  if (mac.charAt(i)!='.') {
	    System.out.println(mac.charAt(i));
	    return false;
	  }//end if
	}//end if
	else {
	  if ((mac.charAt(i)!='a') && (mac.charAt(i)!='b') && (mac.charAt(i)!='c') &&
	      (mac.charAt(i)!='d') && (mac.charAt(i)!='e') && (mac.charAt(i)!='f') &&
	      (!Character.isDigit(mac.charAt(i)))) {
	    System.out.println(mac.charAt(i));
	    return false;
	  }//end if
	}//end else
      }//end for(i<14)
    }//end if(length==14)
    else return false;
    return true;
  }//end IsMacAddress

  static boolean isExist(String mac) {
    for (int i=0; i < Port.vMacAddress.size(); i++) {
      if (mac.equals((String)Port.vMacAddress.elementAt(i))) {
	return true;
      }//end if
    }//end for
    return false;
  }//end isExist

  public String cHexToBin(String hex) {
    String bin="";
    char[] hexc = new char[12];
    int p=0;
    for (int i=0; i<14; i++) {
      if (hex.charAt(i)!='.') {
	hexc[p]=hex.charAt(i);
	p++;
      }//end if
    }//end for
    for (int i=0; i<12; i++) {
      switch (hexc[i]) {
	  case '1' : bin = bin+"0001"; break;
	  case '2' : bin = bin+"0010"; break;
	  case '3' : bin = bin+"0011"; break;
	  case '4' : bin = bin+"0100"; break;
	  case '5' : bin = bin+"0101"; break;
	  case '6' : bin = bin+"0110"; break;
	  case '7' : bin = bin+"0111"; break;
	  case '8' : bin = bin+"1000"; break;
	  case '9' : bin = bin+"1001"; break;
	  case 'a' : bin = bin+"1010"; break;
	  case 'b' : bin = bin+"1011"; break;
	  case 'c' : bin = bin+"1100"; break;
	  case 'd' : bin = bin+"1101"; break;
	  case 'e' : bin = bin+"1110"; break;
	  case 'f' : bin = bin+"1111"; break;
	  case 'A' : bin = bin+"1010"; break;
	  case 'B' : bin = bin+"1011"; break;
	  case 'C' : bin = bin+"1100"; break;
	  case 'D' : bin = bin+"1101"; break;
	  case 'E' : bin = bin+"1110"; break;
	  case 'F' : bin = bin+"1111"; break;
	  default  : bin = bin+"0000";
	}//end switch
      }//end for
      return bin;
    }//end cHextoBin

    public String cBinToHex(String bin) {
      String hex="";
      String tmp="";
      for (int i=0; i<48; i++) {
	tmp=tmp+bin.charAt(i);
	if (i%4==3) {
	  if (tmp.equals("0001")) { hex=hex+1; tmp="";}
	  else if (tmp.equals("0010")) { hex=hex+"2"; tmp=""; }
	  else if (tmp.equals("0011")) { hex=hex+"3"; tmp=""; }
	  else if (tmp.equals("0100")) { hex=hex+"4"; tmp=""; }
	  else if (tmp.equals("0101")) { hex=hex+"5"; tmp=""; }
	  else if (tmp.equals("0110")) { hex=hex+"6"; tmp=""; }
	  else if (tmp.equals("0111")) { hex=hex+"7"; tmp=""; }
	  else if (tmp.equals("1000")) { hex=hex+"8"; tmp=""; }
	  else if (tmp.equals("1001")) { hex=hex+"9"; tmp=""; }
	  else if (tmp.equals("1010")) { hex=hex+"a"; tmp=""; }
	  else if (tmp.equals("1011")) { hex=hex+"b"; tmp=""; }
	  else if (tmp.equals("1100")) { hex=hex+"c"; tmp=""; }
	  else if (tmp.equals("1101")) { hex=hex+"d"; tmp=""; }
	  else if (tmp.equals("1110")) { hex=hex+"e"; tmp=""; }
	  else if (tmp.equals("1111")) { hex=hex+"f"; tmp=""; }
	  else { hex=hex+"0"; tmp=""; }
	}
	if ((i%16==0) && (i!=0)) {
	  hex=hex+".";
	}//end for
      }//end for
      return hex;
    }//end cBinToHex
    //---------------Set Subnet------------------------//
/*    public void setSubnet(String s){
      subnet = s;
    }
    public String getSubnet(){
      return subnet;
    }*/
    //------------------Set Type------------------------//
    public void setType(String s){
      type = s;
    }
    public String getType(){
      return type;
    }


}//end class IntEthernet

