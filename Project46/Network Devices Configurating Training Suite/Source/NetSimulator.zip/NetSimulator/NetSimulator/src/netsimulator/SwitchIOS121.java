package netsimulator;

import java.lang.*;
import java.util.*;

class SwitchIOS121 {

  private Switch sw;
  private SwitchConsole Sconsole;
  private String flagConfig = "";

  private String error = "";
  private final String cmdError = "% Invalid input detected at '^' marker.";
  private final String ambigous = "% Ambiguous Command :";
  //used command
  public final String[] userMode = new String[]{"?","enable","exit","show version","show mac-address-table","show vlan","show vlan brief"};
  public final String[] privMode = new String[]{"?","configure terminal","disable","show version","show history","show interface","show mac-address-table","show spanning-tree","show vlan","vlan database","show interface <name>","show vlan brief","show spanning-tree brief","show spanning-tree summary","show interface <name> switchport","show spanning-tree vlan <vlannum>","show spanning-tree interface <name>","show interface <name> switchport allowed-vlan"};
  public final String[] configMode = new String[] {"?","end","exit","spanning-tree","hostname <name>","interface <name>","no spanning-tree","no vlan <vlannum>","no spanning-tree priority","no spanning-tree forward-time","no spanning-tree hello-time","no spanning-tree max-age","mac-address-table aging-time <num>","no spanning-tree vlan <vlannum>"};
  public final String[] interfaceMode = new String[] {"?","end","exit","shutdown","no shutdown","no switchport mode","switchport mode access","switchport mode trunk","switchport access vlan <vlannum>","switchport trunk allowed vlan all","switchport trunk allowed vlan add <name>","switchport trunk allowed vlan remove <name>"};
  public final String[] vlanMode = new String[] {"?","exit","no vlan <vlannum>","vlan <vlannum> mtu <mutsize>","vlan <vlannum> name <name>"};

//  private boolean foundcmd = false;

  private Vector commandArgu = new Vector();
  private int arguSize = 0;

  private Vector cmdListArgu = new Vector();
  private int listSize = 0;

  private String cmdList[] = null;

  public SwitchIOS121() {}  // default Constructor()

  public void runCommand(Switch sw_in, String fullSwitchcmd,SwitchConsole console) {
    sw = sw_in;
    Sconsole = console;

    switch (sw.getMode()){
      case 1 : cmdList = userMode;break;
      case 2 : cmdList = privMode;break;
      case 3 : cmdList = configMode;break;
      case 4 : cmdList = interfaceMode;break;
      case 5 : cmdList = vlanMode;break;
      default :cmdList = userMode;break;
    }//end switch

    splitCommand(fullSwitchcmd);

//-+-+-+-+-+-+-+-+-+-+- RUN -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

//    if (true){//foundcmd) {//for optimize
    try{
      switch (sw.getMode()) {

//User Mode ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 1:
          if (chkShortCmd(0,"?") && moreArgu(1)){
            showCmd1(Sconsole);
          } //end ?
          else if (chkShortCmd(0,"enable","en") && moreArgu(1)){

//Switch>enable
            sw.setMode(2);
          } //end enable
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {

//Switch>exit
            Sconsole.reset();
          } //end exit
          else if (chkShortCmd(0,"show","sh") && moreArgu(3)) {
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"version","ver")) {

//Switch>show version
                  showVersion();
                }else if (chkShortCmd(1,"mac-address-table","mac")){

//Switch>show mac-address-table
                  showMacAddressTable();
                }else if (chkShortCmd(1,"vlan")){

//Switch>show vlan
                  showVLAN();
                }
                else { Sconsole.append(cmdError); }
                break;
              case 2:
                if (chkShortCmd(1,"vlan")) {
                  if (chkShortCmd(2,"brief")) {

//Switch>show vlan brief
                    showVlan_Brief();
                  }else { Sconsole.append(cmdError); }
                }else { Sconsole.append(cmdError); }
                break;
            }//end switch
          } //end show
          else {
            Sconsole.append(cmdError);
            break;
          }//end if
          break;
// end Mode 1: UserMode ">"

//Privilage Mode ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 2:
          if (chkShortCmd(0,"?") && moreArgu(1)) {
            Sconsole.append("?");
          }//end ?
          else if (chkShortCmd(0,"configure","config") && moreArgu(2)) {

//Switch#configure terminal
            if (chkShortCmd(1,"terminal","t")){
              sw.setMode(3);
              Sconsole.append("Enter Configuration commands, one per line. End with Ctrl-Z");
            }else { Sconsole.append(cmdError); }
          }//end configure
          else if (chkShortCmd(0,"disable","dis") && moreArgu(1)){

//Switch#disable
            sw.setMode(1);
          }//end disable
          else if (chkShortCmd(0,"show","sh") && moreArgu(5)){
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"version","ver")) {

//Switch#show version
                  showVersion();
                }else if (chkShortCmd(1,"history","his")) {

//Switch#show history
                  Sconsole.showHistory();
                }else if (chkShortCmd(1,"interface","int")){

//Switch#show interface
                  showInterface();
                }else if (chkShortCmd(1,"spanning-tree","spt")){

//Switch#show spanning-tree
                  showSPT();
                }else if (chkShortCmd(1,"mac-address-table","mac")){

//Switch#show mac-address-table
                  showMacAddressTable();
                }else if (chkShortCmd(1,"vlan")){

//Switch#show vlan
                  showVLAN();
                }
                else { Sconsole.append(cmdError); }
                break;
              case 2:
                if (chkShortCmd(1,"interface","int")) {

//Switch#show interface <int name>
                  showInterface_Name(commandArgu.elementAt(2).toString());
                }else if (chkShortCmd(1,"spanning-tree","spt")) {
                  if (chkShortCmd(2,"brief")){

//Switch#show spanning-tree brief
                    showSPT_Brief();
                  }else if (chkShortCmd(2,"summary","sum")){

//Switch#show spanning-tree summary
                    showSPT_Summary();
                  }else { Sconsole.append(cmdError); }

                }else if (chkShortCmd(1,"vlan")){
                  if (chkShortCmd(2,"brief")){

//Switch#show vlan brief
                    showVlan_Brief();
                  }else { Sconsole.append(cmdError); }
                }else { Sconsole.append(cmdError); }
                break;
              case 3:
                if (chkShortCmd(1,"interface","int")) {
                  if (chkShortCmd(3,"switchport","sp")){

//Switch#show interface <intname> switchport
                    showInterface_SwPort();
                  }else Sconsole.append(cmdError);
                }else if (chkShortCmd(1,"spanning-tree","spt")){
                  if (chkShortCmd(2,"vlan")) {

//Switch#show spanning-tree vlan <vlannum>
                    showSPT_vlan(commandArgu.elementAt(3).toString());
                  }else if (chkShortCmd(2,"interface","int")){

//Switch#show spanning-tree interface <name>
                    showSPT_int(commandArgu.elementAt(3).toString());
                  }else Sconsole.append(cmdError);

                }else Sconsole.append(cmdError);
                break;
              case 4:
                if (chkShortCmd(1,"interface","int")){
                  if (chkShortCmd(3,"switchport","sp")){
                    if (chkShortCmd(4,"allowed-vlan","allow")){

//Switch#show interface <int name> switchport allowed-vlan
                      showInterface_SwPort_allow(commandArgu.elementAt(2).toString());
                    }else Sconsole.append(cmdError);
                  }else Sconsole.append(cmdError);
                }else Sconsole.append(cmdError);
                break;
            } //end switch
          } //end show
          else if (chkShortCmd(0,"vlan") && moreArgu(2)){
            if (chkShortCmd(1,"database","db")){

//Switch#vlan database
              sw.setMode(5);
            }else Sconsole.append(cmdError);
          }else {
            Sconsole.append(cmdError);
            break;
          }//end if
          break;
// end Mode 2: Privilage Mode "#"

//Config Mode +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 3:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"end") && moreArgu(1)){

//Switch(Config)#end
            sw.setMode(2);
          }//end end
          else if (chkShortCmd(0,"exit") && moreArgu(1)){

//Switch(Config)#exit
            sw.setMode(2);
            Sconsole.append("%SYS-5-CONFIG_I: Configure from console by console");
          }//end exit
          else if (chkShortCmd(0,"hostname","hn") && moreArgu(2)){

//Switch(config)#hostname <name>
            sw.setSwitchName(commandArgu.elementAt(1).toString());
            Sconsole.setTitle(" - = "+sw.getSwitchName()+" Console = - ");
          }//end hostname <name>

          else if (chkShortCmd(0,"interface","int") && moreArgu(2)){

//router(config)#interface xx
            String interfac = commandArgu.elementAt(1).toString();
            String interfaceName = "fe0/0";
            char interfaceArray[] = interfac.toCharArray();
            int len = interfac.length();

            if (len > 3 && (interfac.charAt(2)=='/')){
              if (interfac.length() == 3){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3];
              }else if(interfac.length() == 4){
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[3]+interfaceArray[4];
              }else{}
            }else {
              if (interfac.length() == 2) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1];
              }else if (interfac.length() == 3) {
                interfaceName = interfaceArray[0] + "0/" + interfaceArray[1]+interfaceArray[2];
              }else {}
            }

            if (interfaceName.charAt(0)=='e'){
              interfaceName = "f"+interfaceName;
            }

            if (sw.hasInterface(interfaceName)){
              flagConfig = interfaceName;
              sw.setMode(4);
            }else{
              Sconsole.append("Interface limited");
            }
          }//end interface

          else if (chkShortCmd(0,"mac-address-table","mac") && moreArgu(3)){
            if (chkShortCmd(1,"aging-time","aging")) {

//Switch(config)#mac-address-table aging-time <time interval>
              String settime = commandArgu.elementAt(2).toString();
              try {
                int time = Integer.parseInt(settime);
                sw.setMac_address_aging_time(time);
              }catch (Exception e) { Sconsole.append(cmdError); }
            }
          }//end mac-address-table aging-time <time>

          else if (chkShortCmd(0,"no") && moreArgu(4)){
            if (chkShortCmd(1,"vlan") && moreArgu(3)){
//             no vlan <num>
            }else if (chkShortCmd(1,"spanning-tree","spt") && moreArgu(2)){

//Switch(Config)#no spanning-tree
              sw.setSPTStatus(false);
            }else if (chkShortCmd(1,"spanning-tree","spt") && moreArgu(3)){
              if (chkShortCmd(2,"priority","pri")){

//Switch(config)#no spanning-tree priority
                sw.setSPT_priority(128);
              }else if(chkShortCmd(2,"forward-time","fw")){

//Switch(config)#no spanning-tree forward-time
                sw.setSPT_fw_time(15);
              }else if(chkShortCmd(2,"hello-time","hello")){

//Switch(config)#no spanning-tree hello-time
                sw.setSPT_hello_time(2);
              }else if(chkShortCmd(2,"max-age","max")){

//Switch(config)#no spanning-tree max-age
                sw.setSPT_max_age(20);
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"spanning-tree","spt") && moreArgu(4)){
              if (chkShortCmd(2,"vlan")) {
//
              }else Sconsole.append(cmdError);
            }else Sconsole.append(cmdError);

          }//end no
          else if (chkShortCmd(0,"spanning-tree","spt") && moreArgu(1)){

//Switch(Config)#spanning-tree
            sw.setSPTStatus(true);
          }
          else Sconsole.append(cmdError);
          break;
// end Mode 3: Config Mode "(config)#"

// Interface Mode +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        case 4:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"end") && moreArgu(1)){

//Switch(config-if)#end
            sw.setMode(3);
          }//end end
          else if (chkShortCmd(0,"exit") && moreArgu(1)){

//Switch(config-if)#exit
            sw.setMode(2);
          }//end exit
          else if (chkShortCmd(0,"no") && moreArgu(3)){
            if (chkShortCmd(1,"shutdown") && moreArgu(2)){

//Switch(config-if)#no shutdown
              IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
              configInterface.setMyStatus(true);
              Sconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getEname()+", changed state to up\n"+
                              "%LINK-3-UPDOWN: Interface "+configInterface.getEname()+", changed steate to up");
             Frame1.setTextProperty(sw);
            }else if (chkShortCmd(1,"switchport","sp")){
              if (chkShortCmd(2,"mode")){

//Switch(config-if)#no switchport mode
                IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                configInterface.setSwitch_portMode("");
              }else Sconsole.append(cmdError);
            }else Sconsole.append(cmdError);
          }//end no
          else if (chkShortCmd(0,"shutdown") && moreArgu(1)){

//Switch(config-if)#shutdown
            IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
            configInterface.setMyStatus(false);
            Sconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface "+configInterface.getEname()+", changed state to down\n"+
                            "%LINK-3-UPDOWN: Interface "+configInterface.getEname()+", changed steate to downp");
            Frame1.setTextProperty(sw);
          }
          else if (chkShortCmd(0,"switchport","sp") && moreArgu(6)){
            if (chkShortCmd(1,"mode") && moreArgu(3)){
              if (chkShortCmd(2,"access")){

//Switch(config-if)#switchport mode access
                IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                configInterface.setSwitch_portMode("access");
              }else if (chkShortCmd(2,"trunk")){

//Switch(config-if)#switchport mode trunk
                IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                configInterface.setSwitch_portMode("trunk");
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"access") && moreArgu(4)){
              if (chkShortCmd(2,"vlan")){

//Switch(config-if#switchport access vlan <vlan number>
                IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                int vlanAccess = 1;
                try{
                  vlanAccess = Integer.parseInt(commandArgu.elementAt(4).toString());
                }catch (Exception e) { Sconsole.append(cmdError); }

                configInterface.setVLAN_Access(vlanAccess);
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"trunk") && moreArgu(6)){
              if (chkShortCmd(2,"allowed","allow") && moreArgu(5)){
                if (chkShortCmd(3,"vlan")){
                  if (chkShortCmd(4,"all")){

//Switch(config-if)#switchport trunk allowed vlan all
                     IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                     configInterface.removeALLVLAN_to_Trunk();
                     for (int index = 0; index < sw.getEport().size(); index++){
                       IntEthernet intE = (IntEthernet)sw.getEport().elementAt(index);
                       String vlan_str = ""+intE.getVLAN();
                       configInterface.addVLAN_to_Trunk(vlan_str);
                     }//end for
                  }else Sconsole.append(cmdError);
                }else Sconsole.append(cmdError);
              }else if (chkShortCmd(2,"allowed","allow") && moreArgu(6)){
                if (chkShortCmd(3,"vlan")){
                  if (chkShortCmd(4,"add")){

//Switch(config-if)#switchport trunk allowed vlan add <vlan num>
                     IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                     configInterface.addVLAN_to_Trunk(commandArgu.elementAt(5).toString());
                  }else if (chkShortCmd(5,"remove")){

//Switch(config-if)#switchport trunk allowed vlan remove <vlan num>
                     IntEthernet configInterface = (IntEthernet)sw.getClassEthernet(flagConfig);
                     configInterface.removeVLAN_to_Trunk(commandArgu.elementAt(5).toString());
                  }else Sconsole.append(cmdError);
                }else Sconsole.append(cmdError);
              }else Sconsole.append(cmdError);
            }else Sconsole.append(cmdError);
          }else Sconsole.append(cmdError);
          break;
// end Mode 4 : Interface Mode "(config-if)#"

// vlan Mode
        case 5:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {

//Switch(vlan)#exit
            sw.setMode(3);
          }//end exit
          else if (chkShortCmd(0,"no") && moreArgu(3)){
            if (chkShortCmd(1,"vlan")){

//Switch(vlan)#no vlan <vlanid>
              String vlan_id = ""+commandArgu.elementAt(2);
              for (int index = 0; index < sw.vVLAN_id.size(); index++){
                if (sw.vVLAN_id.elementAt(index).toString().equalsIgnoreCase(vlan_id)){
                  sw.vVLAN_id.removeElementAt(index);
                  sw.vVLAN_mtu.removeElementAt(index);
                  sw.vVLAN_name.removeElementAt(index);
                }//end if
              }//end for
            }else Sconsole.append(cmdError);
          }else if (chkShortCmd(0,"vlan") && moreArgu(4)){
            if (chkShortCmd(2,"mtu")){

//Switch(vlan)#vlan <vlan> mtu <mtusize>
              String vlan_id = ""+commandArgu.elementAt(1);
              for (int index = 0; index < sw.vVLAN_id.size(); index++){
                if (sw.vVLAN_id.elementAt(index).toString().equalsIgnoreCase(vlan_id)){
                  sw.vVLAN_mtu.add(index,commandArgu.elementAt(3).toString());
                }//end if
              }//end for
            }else if (chkShortCmd(2,"name")) {

//Switch(vlan)#vlan <vlan> name <name>
              sw.vVLAN_id.addElement(commandArgu.elementAt(1).toString());
              sw.vVLAN_mtu.addElement("1500");
              sw.vVLAN_name.addElement(commandArgu.elementAt(3).toString());
            }else Sconsole.append(cmdError);
          }
          else Sconsole.append(cmdError);
          break;
// end Mode 5 : vlan Mode "(config)#"

      } //end switch sw.getmode
//*/
      }catch (Exception over) {}
  }//end runCommand


//CALL FUNCTION +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  private boolean chkShortCmd(int element,String cmd1) {
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1));
  }//end chkShortCmd(str)
  private boolean chkShortCmd(int element,String cmd1,String cmd2){
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1) ||
        commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd2));
  }//end chkShortCmd(str1,str2)

  private void splitCommand(String CMD) {
    commandArgu.removeAllElements();
    StringTokenizer subStr = new StringTokenizer(CMD," ");
    while (subStr.hasMoreTokens()){
      String str = subStr.nextToken();
      commandArgu.addElement(str);
    }//end while
    arguSize = commandArgu.size();
  }//end splitCommand

  private boolean moreArgu(int maxListArgu){
    return (commandArgu.size() <= maxListArgu);
  }//end splitList

  private boolean isIp(String s){
    boolean chk_ip = true;
    StringTokenizer st = new StringTokenizer(s, ".");
    for (int i = 0; i < 4; i++) {
      if (st.hasMoreTokens()) {
        String tmp = st.nextToken();
        try {
          int ip = Integer.parseInt(tmp);
          if ( (ip < 0) || (ip > 255)) {
            chk_ip = false;
          }
        }catch (NumberFormatException exp) {chk_ip = false;}
      }//end if
      else {
        chk_ip = false;
      }//end else
    }//end for
    return chk_ip;
  }//end chk isIp


//Call Method Agent+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  //Help -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
  public void showCmd1(SwitchConsole Sconsole){
     Sconsole.append("Exex Commands:\n"+
     "enable           \t\tTurn on privileged commands\n"+
     "exit             \t\tExit from the EXEC\n"+
     "show             \t\tShow running system information\n");
   }
   public void showCmd2(SwitchConsole Sconsole){
     Sconsole.append("Exex Commands:\n"+
     "config           \t\tEnter configuration mode\n"+
     "disable          \t\tTurn off privileged commands\n"+
     "show             \t\tShow running system information\n"+
     "vlan database    \tConfigure VLAN database\n");
   }
   public void showCmd3(SwitchConsole Sconsole){
     Sconsole.append("Configure commands:\n"+
     "end              \t\tExit from configure Mode\n"+
     "exit             \t\tExit from configure mode\n"+
     "hostname         \t\tSet system's network name\n"+
     "interface        \t\tSelect an interface to configure\n"+
     "mac-address-table\t\tSet MAC address table\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "spanning-tree    \t\tSpanning Tree Subsystem\n");
   }
   public void showCmd4(SwitchConsole Sconsole){
     Sconsole.append("Interface configuration commands:\n"+
     "end              \t\tExit from configure mode\n"+
     "exit             \t\tExit from interface configuration mode\n"+
//     "interface        \t\tSelect an interface to configure\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "shutdown         \t\tShutdown the selected interface\n"+
     "switchport       \t\tSet switching mode characteristics\n");
   }
   public void showCmd5(SwitchConsole Sconsole){
     Sconsole.append("VLAN database editing buffer manipulation commands:\n"+
     "exit             \t\tApply changes, bump revision number, and exit mode\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "vlan             \t\tAdd, delete or modify values associated with a single VLAN\n");
    }
   //end Help

   //Show Method -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

   public void showSPT(){
     String show_spt = "";
     show_spt += "\n";

     if (sw.getSPTStatus()) {
       show_spt += "Spanning tree enabled " + "\n";
       show_spt += "Spanning tree is executing the IEEE compatible Spanning Tree Protocol" + "\n";
       show_spt += "   Bridge Identifier has priority   " + sw.getPriority()   + "\n";
       show_spt += "                         address    " + sw.getSwitchMacAddress() + "\n";
       show_spt += "   Configured hello time " + "2" + ", max age " + "20" + ", forward delay " + "15" + "\n";
       show_spt += "   Current root has priority        " + sw.getPriority() + "\n";
       show_spt += "                    address         " + sw.getSwitchMacAddress() + "\n";
       show_spt += "   Root port is " + "0" + ", cost of root path is 100" + "\n";
       show_spt += "" + "\n";

       for (int i = 0; i < sw.getEport().size(); i++) {
         IntEthernet int_E = (IntEthernet)sw.getEport().elementAt(i);

         show_spt += "Interface " + int_E.getEname() + " (port " + i + ") in Spanning tree 1 is " + "forwarding" + "\n";
         show_spt += "   Port path cost 19, Port Priority " + "128" + "\n";
         show_spt += "   Designated root has priority "+ sw.getPriority() + ", address " + sw.getSwitchMacAddress() + "\n";
         show_spt += "   Designated bridge has priority " + sw.getPriority() + ", address " + sw.getSwitchMacAddress() + "\n";
         show_spt += "   Designated port is " + i + ", path cost " + "104" + "\n";
         show_spt += "" + "\n";
       }//end for
     }else {
       Sconsole.append("Spanning-Tree Disable");
     }//end if

     Sconsole.append(show_spt);

   }//end showSPT()

   public void showSPT_Brief(){
     if (chkShortCmd(2,"brief","b")){
       String show_spt_brief = "";
       show_spt_brief += "VLAN1" + "\n";
       show_spt_brief += "   Spanning tree enabled protocol IEEE" + "\n";
       show_spt_brief += "   ROOT ID     Priority " + sw.getSwitchBridgeID() + "\n";
       show_spt_brief += "               Address " + sw.getSwitchMacAddress() + "\n";
       show_spt_brief += "               Hello time  " + "2" + " sec    Max Age  " + "20" + " sec    Forward Delay  " + "15" + " sec\n";
       show_spt_brief += "   Bridge ID   Priority " + sw.getPriority() + "\n";
       show_spt_brief += "               Address " + sw.getSwitchMacAddress() + "\n";
       show_spt_brief += "               Hello time  " + "2" + " sec    Max Age  " + "20" + " sec    Forward Delay  " + "15" + " sec\n";
       show_spt_brief += "Port \n";
       show_spt_brief += "Name\tPort ID\tPrior    Cost    Port State\tBridge ID\t   Port ID \n";
       show_spt_brief += "----\t-------\t-----    ----    ----------\t---------\t   --------\n";

       for (int index = 0; index < sw.getEport().size(); index++){
         String state = "";
         if (index<2){
           state = "forwarding";
         }else {
           state = "blocking";
         }

         IntEthernet int_E = (IntEthernet)sw.getEport().elementAt(index);
         show_spt_brief += int_E.getEname()+"\t"+"128."+index+"1"+"\t"+"128"+"    "+"104"+"    "+state+"\t"+sw.getSwitchMacAddress()+"\t"+"   "+"128."+index+"1"+"\n";
       }
       Sconsole.append(show_spt_brief);

     }else {
       Sconsole.append(cmdError);
     }
   }//end showSPT Brief

   public void showSPT_Summary(){

   }//end show SPT summary

   public void showSPT_vlan(String vnum){

   }//end show SPT vlan number

   public void showSPT_int(String intf){

   }//end show SPT interface <int name>

   public void showInterface(){

   }//end show interface

   public void showInterface_Name(String name){

   }//end show interface <name>

   public void showInterface_SwPort(){

   }//end show interface <name> switchport

   public void showInterface_SwPort_allow(String intName){

   }//end show interface <int name> switchport allowed-vlan

   public void showVLAN(){

   }//end show vlan

   public void showVlan_Brief(){

   }//end show vlan brief

   public void showVersion(){

   }//end show version

   public void showMacAddressTable(){

   }//end show mac-address-table
}//end class fullswcmd
