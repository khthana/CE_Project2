package netsimulator;

import java.util.*;

class IntSerial {

  private String S_FullName = "";
  private int S_id = 0;

  private String S_myName = "";
  private String ipAddress = "";
  private String ipSubnet = "";

  private int costOspf=16;

  private boolean myStatus = false;

  private String myStatusString;
  private String type;

  private String connectionWith = ""; //keep IP address
  private String connectInformation = "";
  private String opIP = "";
  private boolean opStatus = false;

  private String networkAddress = "";
  private String description = "";
//  private String subnet;

//other parameter
  private int bandWidth = 1;
  private int clockRate = 1;

//Constructor
  IntSerial(){}// default Constructor

//Method
  public void setS_FullName(String s_fullname){
    S_FullName = s_fullname;
  }
  public String getS_FullName(){
    return S_FullName;
  }

  public void setS_ID(int s_id){
    S_id = s_id;
  }
  public int getS_ID(){
    return S_id;
  }

  public void setSname(String sname){
    S_myName = sname;
  }
  public String getSname(){
    return S_myName;
  }

  public void setIPAddress(String ip){
    ipAddress = ip;
  }
  public String getIPAddress(){
    return ipAddress;
  }

  public void setIPSubnet(String ip){
    ipSubnet = ip;
  }
  public String getIPSubnet(){
    return ipSubnet;
  }

  public void setDescription(String message){
    description = message;
  }
  public String getDescription(){
    return description;
  }

  public void setMyStatus(boolean status){
    myStatus = status;
  }
  public boolean getMyStatus(){
    return myStatus;
  }

  public String getMyStatusString(){
//    String status = "";
    if (myStatus == true){
      myStatusString = "up";
    }else {
      myStatusString = "down";
    }
    return myStatusString;
  }
  public void setMyStatusString(String s){
    this.myStatusString = s;
  }

  public void setOpStatus(boolean bl){
    opStatus = bl;
  }
  public boolean getOpStatus(){
    return opStatus;
  }

  public String getOpIP(){
    return opIP;
  }

  public void setConnectionWith(String connection){
    connectionWith = connection;

/*    String dev = Connections.cutString(connection,0," ");
    if (dev.charAt(0) == 'R'){
      for (int count = 0; count < Frame1.vRouter.size(); count++){
	Router rt = (Router)Frame1.vRouter.elementAt(count);
	if (dev.equalsIgnoreCase(rt.getRouterUniName())){
	  connectInformation = rt.getRouterMacAddress();
	}
      }
    }else if (dev.charAt(0) == 'S'){
      for (int count = 0; count < Frame1.vSwitch.size(); count++){
	Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
	if (dev.equalsIgnoreCase(sw.getSwitchUniName())){
	  connectInformation = sw.gets.getSwitchMacAddress();
	}
      }
    }else if (dev.charAt(0) == 'H'){
      for (int count = 0; count < Frame1.vHost.size(); count++){
	Host ho = (Host)Frame1.vHost.elementAt(count);
	if (dev.equalsIgnoreCase(ho.getHostUniName())){
	  connectInformation = ho.getHostIPAddress();
	}
      }
    }
*/
  }
  public String getConnectionWith(){
    return connectionWith;
  }


  public void setNetworkAddress(String netAddress){
    networkAddress = netAddress;
  }//end set networkAddress for each interface

  public String getNetworkAddress(){
    return networkAddress;
  }//end get networkAddress for each interface

  public void setBandwidth(int bd){
    bandWidth = bd;
  }

  public void setClockRate(int cr){
    clockRate = cr;
  }

  //---------------Set Subnet------------------------//
/*  public void setSubnet(String s){
    subnet = s;
  }
  public String getSubnet(){
    return subnet;
  }*/
  //------------------Set Type------------------------//
  public void setType(String s){
    type = s;
  }
  public String getType(){
    return type;
  }
/*
//------------------Set Cost Ospf------------------//
  public void setCostOspf(int s_index,Router d_index,int cost){

    this.costOspf = cost;
  }
  public int getCostOspf(){
    return costOspf;
  }
*/
}//end class IntSerial

