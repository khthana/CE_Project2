package netsimulator;

import java.util.*;


class Switch {

  protected String priority = "32768";
  protected String bridgeID;
  protected String switchMacAddress;
  protected String SwitchName = "Switch1";

  static Vector vSwitchAddressTable = new Vector();
  static Vector vVLAN_id = new Vector();  //default 1    range[1-1005]
  static Vector vVLAN_mtu = new Vector(); //default 1500 range[1500-18190]
  static Vector vVLAN_name = new Vector();//default default

//  protected Vector vSwitchNeighbor = new Vector();
  private int ID; //Switch ID (fix)

  private boolean activeSelS = false;
  private int swMode = 1;
  private Port swPort;
  private SwitchImg simg;
  private Vector ethernetName;

  private boolean SPTStatus = false;

  private int spt_priority = 128; //default   range[0-65535]
  private int mac_address_aging_time = 100;// range[10-1000000]
  private int spt_fw_time = 15; //default     range[4-30]
  private int spt_hello_time = 2; //default   range[1-10]
  private int spt_max_age = 20; //default     range[6-40]


  public Switch() {
    SwitchName = "";
    switchMacAddress = IntEthernet.genMacAddress();
    bridgeID = priority+"."+switchMacAddress;
    this.vVLAN_id.addElement("1");
    this.vVLAN_mtu.addElement("1500");
    this.vVLAN_name.addElement("default");
  }//end Constructor

  public Switch(String swName){
    SwitchName = chkAndsetSwitchName(swName);
    switchMacAddress = IntEthernet.genMacAddress();
    bridgeID = priority+"."+switchMacAddress;
    this.vVLAN_id.addElement("1");
    this.vVLAN_mtu.addElement("1500");
    this.vVLAN_name.addElement("default");
  }//end Switch(string)

  public Switch(String swName,int serialPort,int ethernetPort,int tokenringPort){
    SwitchName = chkAndsetSwitchName(swName);
    createPort(serialPort,ethernetPort,tokenringPort);
    switchMacAddress = IntEthernet.genMacAddress();
    bridgeID = priority+"."+switchMacAddress;
    this.vVLAN_id.addElement("1");
    this.vVLAN_mtu.addElement("1500");
    this.vVLAN_name.addElement("default");
  }// end Switch(string,port,port,port)

  //---------------------Switch Method------------------------
  public String getSwitchMacAddress(){
    return switchMacAddress;
  }//end get switch macaddress

  public String getSwitchBridgeID(){
    return bridgeID;
  }

  public void createPort(int serial,int ethernet,int tokenring){
    swPort = new Port(serial,ethernet,tokenring);
    ethernetName = swPort.getEname();
  }//end createPort

  public void getSport(){

  }
  public Vector getEport(){
    return swPort.getEport();
  }
  public void getTport(){

  }

  public Vector getEname(){
    return ethernetName;
  }//end get Ethernet name

  public String getSwitchName(){
    return SwitchName;
  }//end getSwitchName
  public void setSwitchName(String swName){
    SwitchName = swName;
  }//end setSwitchName

  public int getMode(){
    return swMode;
  }//end getMode
  public void setMode(int mode){
    swMode = mode;
  }//end setMode

  public String getPriority(){
    return priority;
  }

  public void setSPTStatus(boolean sptStatus){
    SPTStatus = sptStatus;
  }
  public boolean getSPTStatus(){
    return SPTStatus;
  }

  public void setSwitchImg(SwitchImg swImg){
    simg = swImg;
  }
  public SwitchImg getSwitchImg(){
    return simg;
  }


  public boolean isSelected(){
    return activeSelS;
  }//end isSelected

  public void resetSelected(){
    activeSelS = false;
  }//end resetSelected

  public String getSwitchUniName(){
    return "S"+ID;
  }//end getSwitchUniName

  public int getSwitchID(){
    return ID;
  }//end getSwitchID

  public String chkAndsetSwitchName(String name){
      String sName = "Switch";
      int sNumber = 0;

      boolean found = false;
      boolean dup = true;
      boolean flag = true; //for optimize

      while(dup) {
        ++sNumber;
        flag = true;
        found = false;
        for (int i=0; (i < Frame1.vSwitch.size())&&flag ; i++) {
          String alreadyName = ((Switch)Frame1.vSwitch.elementAt(i)).getSwitchName();
          if (alreadyName.equalsIgnoreCase(sName + sNumber)){
            System.out.println(sName+sNumber);
            found = true;
            flag = false;
          }//end if
        }//end for
        dup = found;
      }//end while(dup)

      System.out.println("sName+sNumber = "+sName+sNumber);
      System.out.println("Switch ID = "+sNumber);
      ID = sNumber;
      return sName+sNumber;
  }//end constructor switch(String)

//-------- SWITCH OPERATION -----------------------------

  //-------- LOOKUP TABLE --------------------------------
  public boolean lookupTable(String device_inName, String ipSource,String ipDest){
    boolean found_macSource = false;
    boolean found_macDest = false;

    String macSource = arp(ipSource);
    String macDest = arp(ipDest);

    for (int find = 0; find < vSwitchAddressTable.size(); find++) {
      String chk_mac = vSwitchAddressTable.elementAt(find).toString();
      //search mac source
      if (macSource.equalsIgnoreCase(chk_mac)){
        found_macSource = true;
      }//end if
    } //end for
    if (!found_macSource){
      vSwitchAddressTable.addElement(macSource);
    }//end address learning

    //search mac dest
    for (int find = 0; find < vSwitchAddressTable.size(); find++) {
      String chk_mac = vSwitchAddressTable.elementAt(find).toString();
      if (macDest.equalsIgnoreCase(chk_mac)) {
        found_macDest = true;
      } //end if
    } //end for
    if (!found_macDest){
//      found_macDest = flooding(device_inName, ipSource, ipDest);
    }
    return found_macDest;
  }//end lookup table

  //-------- Flooding Packet ---------------------------
  public boolean flooding(String device_in, String ipAddressSource, String ipAddressDest) { //,String macAddressDest){
    boolean found_dest = false;
    String macSource = arp(ipAddressSource);
    String macDest = arp(ipAddressDest);

    try {
    for (int count = 0; count < getEport().size(); count++) {
      IntEthernet et = (IntEthernet)getEport().elementAt(count);
      String connectionwith = et.getConnectionWith();
      String connect_device = Connections.cutString(connectionwith,0," ");

      if (connect_device.charAt(0) == 'H'){
        String mac_end = et.getConnectInformation();
        if (mac_end.equalsIgnoreCase(macDest)) {
          vSwitchAddressTable.addElement(macDest);
          found_dest = true;
        }//end if host
      }else if (connect_device.charAt(0) == 'R'){
        for (int index = 0; index < Frame1.vRouter.size(); index++){
          Router rt = (Router)Frame1.vRouter.elementAt(index);
          String rt_uniName = rt.getRouterUniName();
          if (rt_uniName.equalsIgnoreCase(connect_device)){
            found_dest = rt.lookupIPTable(ipAddressDest);
          }//end if
        }//end for router
      }else if (connect_device.charAt(0) == 'S'){
        for (int index = 0; index < Frame1.vSwitch.size(); index++){
          Switch sw = (Switch)Frame1.vSwitch.elementAt(index);
          String sw_uniName = sw.getSwitchUniName();
          if (sw_uniName.equalsIgnoreCase(connect_device)){

            found_dest = sw.lookupTable(connect_device, ipAddressSource,ipAddressDest);
          }//end if
        }//end for switch*/
      }//end if
    }
    }catch (Exception ex) {found_dest = false;}





/* OK -----------------------------------------
      for (int count = 0; count < this.getEport().size(); count++) {
        IntEthernet et = (IntEthernet)this.getEport().elementAt(count);
        String mac_end = et.getConnectInformation();
        if (mac_end.equalsIgnoreCase(macAddressDest)) {
          vSwitchAddressTable.addElement(macAddressDest);
          found_dest = true;
        }//end if compare
      }//end for search in Ethernet port
//    ---------------------------------------------
*/
      return found_dest;
  }//end operation switchFlooding

//-------- ARP IP TO MAC ADDRESS -----------------------
  public String arp(String ip){
    String mac = "ffff.ffff.ffff";

    for (int count = 0; count < Frame1.vHost.size(); count++){
      Host ho = (Host)Frame1.vHost.elementAt(count);
      String ip_chk = ho.getHostIPAddress();
      if (ip_chk.equalsIgnoreCase(ip)){
        mac = ho.hostMacAddress;
      }//end if
    }//end for

    for (int count = 0; count < Frame1.vSwitch.size(); count++){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
      for (int index = 0; index < sw.getEport().size(); index++){
        IntEthernet et = (IntEthernet)sw.getEport().elementAt(index);
        String ip_chk = et.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = et.getMacAddress();
        }//end if
      }//end for
    }//end for

    for (int count = 0; count < Frame1.vRouter.size(); count++){
      Router rt = (Router)Frame1.vRouter.elementAt(count);
      for (int index = 0; index < rt.getEport().size(); index++){
        IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
        String ip_chk = et.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = et.getMacAddress();
        }//end if
      }//end for
      for (int index = 0; index < rt.getSport().size(); index++){
        IntSerial se = (IntSerial)rt.getSport().elementAt(index);
        String ip_chk = se.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = rt.getRouterMacAddress();
        }//end if
      }//end for
    }//end for
    return mac;
  }//end arp

/*  public String rarp(String mac){
      String ip = "0.0.0.0";

      for (int count = 0; count < Frame1.vHost.size(); count++){
        Host ho = (Host)Frame1.vHost.elementAt(count);
        String mac_chk = ho.getHostMacAddress();
        if (mac_chk.equalsIgnoreCase(mac)){
          ip = ho.getHostIPAddress();
        }//end if
      }//end for

      for (int count = 0; count < Frame1.vSwitch.size(); count++){
        Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
        String mac_chk = sw.getSwitchMacAddress();
        if (mac_chk.equalsIgnoreCase(mac)){
          ip = sw.getMacAddress();
        }//end if

      }//end for

      for (int count = 0; count < Frame1.vRouter.size(); count++){
        Router rt = (Router)Frame1.vRouter.elementAt(count);
        for (int index = 0; index < rt.getEport().size(); index++){
          IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
          String ip_chk = et.getIPAddress();
          if (ip_chk.equalsIgnoreCase(ip)){
            mac = et.getMacAddress();
          }//end if
        }//end for
        for (int index = 0; index < rt.getSport().size(); index++){
          IntSerial se = (IntSerial)rt.getSport().elementAt(index);
          String ip_chk = se.getIPAddress();
          if (ip_chk.equalsIgnoreCase(ip)){
            mac = rt.getRouterMacAddress();
          }//end if
        }//end for
      }//end for
      return mac;
    }//end arp*/


//*************  OTHER METHOD *******************************************************//
  public boolean hasInterface(String intName){
    boolean found = false;
    for (int index = 0; index < ethernetName.size(); index++){
      String indexName = ethernetName.elementAt(index).toString();
      if (indexName.equalsIgnoreCase(intName)){
        found = true;
      }
    }//end for ethernet
    return found;
  }//end hasInterface

  public void setMac_address_aging_time(int agtime){
    mac_address_aging_time = agtime;
  }
  public int getMac_address_aging_time(){
    return mac_address_aging_time;
  }

  public void setSPT_fw_time(int fwtime){
    spt_fw_time = fwtime;
  }
  public int getSPT_fw_time(){
    return spt_fw_time;
  }

  public void setSPT_priority(int priority){
    spt_priority = priority;
  }
  public int getSPT_priority(){
    return spt_priority;
  }

  public void setSPT_hello_time(int hellotime){
    spt_hello_time = hellotime;
  }
  public int getSPT_hello_time(){
    return spt_hello_time;
  }

  public void setSPT_max_age(int age){
    spt_max_age = age;
  }
  public int getSPT_max_age(){
    return spt_max_age;
  }

  public IntEthernet getClassEthernet(String intName){
    IntEthernet returnE = new IntEthernet();
    for (int index = 0; index < getEport().size(); index++){
      IntEthernet intE = (IntEthernet)getEport().elementAt(index);
      String indexName = intE.getEname().toString();
      if (indexName.equalsIgnoreCase(intName)){
        returnE = intE;
      }
    }//end for ethernet
    return returnE;
  }

}//End Switch
