package netsimulator;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.lang.*;
import java.util.*;

public class RouterImg {
  private int rimgID = 0; //out of range

  private int xpos,ypos;
  private int width,height;
  private Image img;
  private String color;
  private int RouterSeries;
  private Vector link = new Vector();
//  static Vector routerImg = new Vector();

  public RouterImg() {
    width = 50;
    height = 40;
    xpos = 120;
    ypos = 115;
    color="none";
  }//end Constructor RouterImg()

  public RouterImg(int routerseries) {
    switch (routerseries){
      case 1760 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("router01.gif"));color="red";break;
      case 0000 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("router02.gif"));color="pupil";break;
//      case 3 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("greenrouter.gif"));color="green";break;
//      case 4 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("pupilrouter.gif"));color="gray";break;
//      case 5 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("redrouter.gif"));color="pink";break;
//      case 6 : img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("pinkrouter.gif"));color="blue";break;
      default :img = Toolkit.getDefaultToolkit().getImage(RouterImg.class.getResource("pinkrouter.gif"));color="blue";break;
    }

    width = 50;
    height = 40;
    xpos = 120;
    ypos = 115;
    RouterSeries = routerseries;

  }//end Constructor RouterImg(int)

//---------------- Method ------------------------------------------------------
  public int getRouterSeries(){
    return RouterSeries;
  }

  public String getColors(){
    return color;
  }

  public Image getImage(){
    return img;
  }

  //------ get&set Position
  public int getXPos(){
    return xpos;
  }
  public int getYPos(){
    return ypos;
  }
  public void setXPos(int n){
    xpos = n;
  }
  public void setYPos(int n){
    ypos = n;
  }

  //------ get&set Size
  public int getWide(){
    return width;
  }
  public int getHigh(){
    return height;
  }
  public void setWide(int n){
    width = n;
  }
  public void setHigh(int n){
    height = n;
  }

  //------ get&set ID
  public String getRouterImgUniName(){
    return "R"+rimgID;
  }//end getRouterImgUniName

  public int getIdRouterImg(){
    return rimgID;
  }
  public void setIdRouterImg(int id){
    rimgID = id;
  }

}//end class RouerImg