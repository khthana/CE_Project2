package netsimulator;

import java.util.*;

public class Igrp extends Thread implements java.io.Serializable{
  Router r;
  boolean recieve;
  static String output="";
  Vector vIgrp;
   int tos=0,k1=1,k2=0,k3=1,k4=0,k5=0;

  Igrp (Router r){
    this.r = r;
    vIgrp = new Vector();
    recieve = false;
  }
  public void setRecieve(boolean b){
    recieve = b;
  }
  public boolean getRecieve(){
    return recieve;
  }
  public void run(){

    System.out.println(r.getRouterName()+" : "+ this.r.getRouterName()+" is start thread");

         System.out.println("sending routing table\n");
         r.sendRoutingTable();
      try{
//	sleep(13000);
        sleep(this.r.getTime());
      }
      catch (Exception e){
      }
      this.run();
    }
//    else{
//      this.suspend();
//      System.out.println(this.r.getName()+" : " +this.r.getName()+" is suspend");
//    }

//  }

  public boolean inVector(){
    boolean found=false;
    int a=0;
    while ((!found)&&(a < vIgrp.size())&&(vIgrp.size() > 0)){
      Router r2 = (Router)vIgrp.elementAt(a);
      if(this.r.getRouterName().equals(r2.getRouterName())){
        found = true;
        return found;
      }
      a++;
    }
    return found;
  }
    //-------------Send Table--------------------//
  public void sendRoutingTable(){
    sendRoutingTableEthernet();
    sendRoutingTableSerial();
  }
  public void sendRoutingTableEthernet(){
    Frame1 fr = new Frame1();
  if (vIgrp.size() > this.r.getEport().size() + this.r.getSport().size()){
      vIgrp.removeAllElements();
    }//remove all vector

//    for(int a=0; a < NewRouter.vRouter.size(); a++){
    for(int a=0; a < fr.vRouter.size(); a++){
//      Router r = (Router)NewRouter.vRouter.elementAt(a);
      Router r = (Router)fr.vRouter.elementAt(a);
//    System.out.println("*********vrip of "+ this.r.getName()+" *****************");
    }
//    System.out.println("----------step----------------");
    for(int a=0; a < Frame1.vRouter.size(); a++){
      Router r = (Router)Frame1.vRouter.elementAt(a);
      //not send to itself

      if ((!r.getRouterName().equalsIgnoreCase(this.getName()))&&(r.getFlag() == 'r')){

          for(int x=0; x < r.getEport().size(); x++){
            IntEthernet inte1 = (IntEthernet)r.getEport().elementAt(x);
            for(int y=0; y < this.r.getEport().size(); y++){
              IntEthernet inte2 = (IntEthernet)this.r.getEport().elementAt(y);
              if ((inte1.getNetworkAddress().equalsIgnoreCase(inte2.getNetworkAddress()))&&(!inte1.getMyStatusString().equalsIgnoreCase("down"))&&(!inte2.getMyStatusString().equalsIgnoreCase("down"))){
                vIgrp.addElement(r);
                System.out.println(this.r.getRouterName()+" : "+ r.getRouterName()+" receive1 from "+this.r.getRouterName());

                recieveRoutingTable(r,this.r,inte1,inte2);
              }//end if
            }//end for
          }//just send
//-----------
/*          for(int x=0; x < r.getSport().size(); x++){
            IntSerial ints1 = (IntSerial)r.getSport().elementAt(x);
            for(int y=0; y < this.r.getSport().size(); y++){
              IntSerial ints2 = (IntSerial)this.r.getSport().elementAt(y);
              if ((ints1.getNetworkAddress().equalsIgnoreCase(ints2.getNetworkAddress()))&&(!ints1.getMyStatusString().equalsIgnoreCase("down"))&&(!ints2.getMyStatusString().equalsIgnoreCase("down"))){
                vrip.addElement(r);
                System.out.println(this.r.getRouterName()+" : "+ r.getRouterName()+" receive1 from "+this.r.getRouterName());

                recieveRoutingTable(r,this.r,inte1,inte2);
              }//end if
            }//end for
          }//just send
*/
      }//end if same router
    }//end for

 }

  public void sendRoutingTableSerial(){
    Frame1 fr = new Frame1();
  if (vIgrp.size() > this.r.getEport().size() + this.r.getSport().size()){
      vIgrp.removeAllElements();
    }//remove all vector

//    for(int a=0; a < NewRouter.vRouter.size(); a++){
    for(int a=0; a < fr.vRouter.size(); a++){
//      Router r = (Router)NewRouter.vRouter.elementAt(a);
      Router r = (Router)fr.vRouter.elementAt(a);
//    System.out.println("*********vrip of "+ this.r.getName()+" *****************");
    }
//    System.out.println("----------step----------------");
    for(int a=0; a < Frame1.vRouter.size(); a++){
      Router r = (Router)Frame1.vRouter.elementAt(a);
      //not send to itself

      if ((!r.getRouterName().equalsIgnoreCase(this.getName()))&&(r.getFlag() == 'r')){
/*
          for(int x=0; x < r.getEport().size(); x++){
            IntEthernet inte1 = (IntEthernet)r.getEport().elementAt(x);
            for(int y=0; y < this.r.getEport().size(); y++){
              IntEthernet inte2 = (IntEthernet)this.r.getEport().elementAt(y);
              if ((inte1.getNetworkAddress().equalsIgnoreCase(inte2.getNetworkAddress()))&&(!inte1.getMyStatusString().equalsIgnoreCase("down"))&&(!inte2.getMyStatusString().equalsIgnoreCase("down"))){
                vrip.addElement(r);
                System.out.println(this.r.getRouterName()+" : "+ r.getRouterName()+" receive1 from "+this.r.getRouterName());

                recieveRoutingTable(r,this.r,inte1,inte2);
              }//end if
            }//end for
          }//just send*/
//-----------
          for(int x=0; x < r.getSport().size(); x++){
            IntSerial ints1 = (IntSerial)r.getSport().elementAt(x);
            for(int y=0; y < this.r.getSport().size(); y++){
              IntSerial ints2 = (IntSerial)this.r.getSport().elementAt(y);
              if ((ints1.getNetworkAddress().equalsIgnoreCase(ints2.getNetworkAddress()))&&(!ints1.getMyStatusString().equalsIgnoreCase("down"))&&(!ints2.getMyStatusString().equalsIgnoreCase("down"))){
                vIgrp.addElement(r);
                System.out.println(this.r.getRouterName()+" : "+ r.getRouterName()+" receive1 from "+this.r.getRouterName());

                recieveRoutingTable(r,this.r,ints1,ints2);
              }//end if
            }//end for
          }//just send

      }//end if same router
    }//end for

  }

  //-------------Recieve Table------------------//
  public void recieveRoutingTable(Router reciever,Router sender,IntEthernet irecieve,IntEthernet isend){

      //-------------Find Destination that not have in router-----------------//
      for (int i=0; i < sender.getVrt().size(); i++){
        //Routing table of router that send routing to ...
        RoutingTable rt1 = (RoutingTable)sender.getVrt().elementAt(i);
        //Routing table of router that recieve from ...
        RoutingTable rt2 =null;
        boolean found = false;
        for(int j=0; j < reciever.getVrt().size(); j++){
          rt2 = (RoutingTable)reciever.getVrt().elementAt(j);
          if (rt1.getIpDestination().equalsIgnoreCase(rt2.getIpDestination())){
            found = true;
            //if gw is router that send routing table
            if(rt2.getIntEthernet().equals(isend)){
  //            this.getVrt().removeElementAt(j);
              if(rt1.getMatriceWeight() < 200000000){
                rt2.setMatriceWeight(tos,k1,k2,k3,k4,k5);
              }
/*              else {
                rt2.setMatrice(16);
              }
            }
            else if((((rt1.getMatrice() + 1) < rt2.getMatrice())&&((!rt2.getGateway().equalsIgnoreCase("0.0.0.0"))))||(rt2.getMatrice() == 16)){
  //            rt2 = (RoutingTable)this.getVrt().elementAt(j);
  //            this.getVrt().removeElementAt(j);
              if (rt1.getMatrice() < 15){
                rt2.setMatrice(rt1.getMatrice()+1);
              }
              else {
                rt2.setMatrice(16);
              }
*/
//              rt2.setMatriceWeight(0,1,0,1,0,0);
              rt2.setGateway(isend.getIPAddress());
              rt2.setIntEthernet(isend);
            }
          }//end if
        }//end for
        if (!found){
          rt1.addRouting(reciever,isend);
        }
      }//end for
//    }//recieve
  }//end recieveRoutingTable
  //-------------Recieve Table------------------//
  public void recieveRoutingTable(Router reciever,Router sender,IntSerial irecieve,IntSerial isend){

      //-------------Find Destination that not have in router-----------------//
      for (int i=0; i < sender.getVrt().size(); i++){
        //Routing table of router that send routing to ...
        RoutingTable rt1 = (RoutingTable)sender.getVrt().elementAt(i);
        //Routing table of router that recieve from ...
        RoutingTable rt2 =null;
        boolean found = false;
        for(int j=0; j < reciever.getVrt().size(); j++){
          rt2 = (RoutingTable)reciever.getVrt().elementAt(j);
          if (rt1.getIpDestination().equalsIgnoreCase(rt2.getIpDestination())){
            found = true;
            //if gw is router that send routing table
            if(rt2.getIntSerial().equals(isend)){
  //            this.getVrt().removeElementAt(j);
              if(rt1.getMatriceWeight() < 200000000){
                rt2.setMatriceWeight(tos,k1,k2,k3,k4,k5);
              }
/*              else {
                rt2.setMatrice(16);
              }
            }
            else if((((rt1.getMatrice() + 1) < rt2.getMatrice())&&((!rt2.getGateway().equalsIgnoreCase("0.0.0.0"))))||(rt2.getMatrice() == 16)){
  //            rt2 = (RoutingTable)this.getVrt().elementAt(j);
  //            this.getVrt().removeElementAt(j);
              if (rt1.getMatrice() < 15){
                rt2.setMatrice(rt1.getMatrice()+1);
              }
              else {
                rt2.setMatrice(16);
              }
*/
//              rt2.setMatriceWeight(0,1,0,1,0,0);
              rt2.setGateway(isend.getIPAddress());
              rt2.setIntSerial(isend);
            }
          }//end if
        }//end for
        if (!found){
          rt1.addRouting(reciever,isend);
        }
      }//end for
//    }//recieve
  }//end recieveRoutingTable
  public void setDefault_var(int t,int k1,int k2,int k3,int k4,int k5){
      tos = t;
      k1 = this.k1;
      k2 = this.k2;
      k3 = this.k3;
      k4 = this.k4;
      k5 = this.k5;
  }
/*
  //-------------Recieve Table------------------//
  public void recieveRoutingTable(Router reciever,Router sender,Interface irecieve,Interface isend){

      //-------------Find Destination that not have in router-----------------//
      for (int i=0; i < sender.getVrt().size(); i++){
        //Routing table of router that send routing to ...
        RoutingTable rt1 = (RoutingTable)sender.getVrt().elementAt(i);
        //Routing table of router that recieve from ...
        RoutingTable rt2 =null;
        boolean found = false;
        for(int j=0; j < reciever.getVrt().size(); j++){
          rt2 = (RoutingTable)reciever.getVrt().elementAt(j);
          if (rt1.getIpDestination().equalsIgnoreCase(rt2.getIpDestination())){
            found = true;
            //if gw is router that send routing table
            if(rt2.getInterface().equals(isend)){
  //            this.getVrt().removeElementAt(j);
              if(rt1.getMatrice() < 15){
                rt2.setMatrice(rt1.getMatrice()+1);
              }
              else {
                rt2.setMatrice(16);
              }
            }
            else if((((rt1.getMatrice() + 1) < rt2.getMatrice())&&((!rt2.getGateway().equalsIgnoreCase("0.0.0.0"))))||(rt2.getMatrice() == 16)){
  //            rt2 = (RoutingTable)this.getVrt().elementAt(j);
  //            this.getVrt().removeElementAt(j);
              if (rt1.getMatrice() < 15){
                rt2.setMatrice(rt1.getMatrice()+1);
              }
              else {
                rt2.setMatrice(16);
              }
              rt2.setGateway(isend.getIpAddress());
              rt2.setInterface(isend);
            }
          }//end if
        }//end for
        if (!found){
          rt1.addRouting(reciever,isend);
        }
      }//end for
//    }//recieve
  }//end recieveRoutingTable
*/
}
