package netsimulator;

class Switch2950 extends Switch{

  public Switch2950(String swName){
    SwitchName = chkAndsetSwitchName(swName);

    createPort(0,12,0);
    switchMacAddress = IntEthernet.genMacAddress();

  }// end Switch(string)

}//End Switch2950