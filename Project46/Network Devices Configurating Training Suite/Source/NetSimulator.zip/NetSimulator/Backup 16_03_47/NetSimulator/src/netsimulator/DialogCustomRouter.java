package netsimulator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.JOptionPane;
import java.util.*;

public class DialogCustomRouter extends JDialog {
  private JPanel contentPane = new JPanel();
  private EtchedBorder etchedBorder  = new EtchedBorder();

  private JLabel jLabelSerial = new JLabel();
  private JLabel jLabelEthernet = new JLabel();
  private JLabel jLabelIOS = new JLabel();

  private JButton jButtonOK = new JButton();
  private JButton jButtonCancle = new JButton();

  private JTextField jTextFieldInputSerial = new JTextField();
  private JTextField jTextFieldInputEthernet = new JTextField();

  private JComboBox jComboBoxIOS = new JComboBox();

  private Vector vIOS = new Vector();
  private int numSerial = 0;
  private int numEthernet = 0;

  //Constructor
  public DialogCustomRouter(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }//end super constructor

  public DialogCustomRouter() {
    this(null, "", true);
  }//end default Constructor

  private void jbInit() throws Exception {
    this.setTitle("- = Custom Router Dialog = -");
    this.setResizable(false);
    this.setFocusableWindowState(true);

    contentPane.setLayout(null);
    contentPane.setBorder(etchedBorder);
    contentPane.setPreferredSize(new Dimension(240,200));

    contentPane.add(jLabelSerial, BorderLayout.NORTH);
    contentPane.add(jLabelEthernet, BorderLayout.WEST);
    contentPane.add(jLabelIOS, null);
    contentPane.add(jTextFieldInputSerial, null);
    contentPane.add(jTextFieldInputEthernet, null);
    contentPane.add(jComboBoxIOS, null);
    contentPane.add(jButtonOK, null);
    contentPane.add(jButtonCancle, null);

    jLabelSerial.setText("#Serial Port :");
    jLabelSerial.setBounds(new Rectangle(21, 28, 88, 21));

    jLabelEthernet.setText("#Ethernet Port :");
    jLabelEthernet.setBounds(new Rectangle(21, 67, 88, 21));

    jLabelIOS.setText("IOS version :");
    jLabelIOS.setBounds(new Rectangle(21, 106, 88, 21));

    jButtonOK.setBounds(new Rectangle(15, 151, 94, 28));
    jButtonOK.setText("Accept");
    jButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonOK_actionPerformed(e);
      }
    });//end listen

    jButtonCancle.setBounds(new Rectangle(123, 151, 94, 28));
    jButtonCancle.setText("Cancle");
    jButtonCancle.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonCancle_actionPerformed(e);
      }
    });//end listen

    jTextFieldInputSerial.setText("0");
    jTextFieldInputSerial.setBounds(new Rectangle(126, 28, 94, 21));

    jTextFieldInputEthernet.setText("0");
    jTextFieldInputEthernet.setBounds(new Rectangle(126, 67, 94, 21));

    jComboBoxIOS.setBounds(new Rectangle(126, 106, 94, 21));
    jComboBoxIOS.addItem(new String("Cisco IOS v12.0"));
    jComboBoxIOS.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jComboBoxIOS_actionPerformed(e);
      }
    });//end listen

    this.getContentPane().add(contentPane, null);
  }//------------- end jbInit() ------------------------------------

//------------- Listenning ---------------------------------------
  void jComboBoxIOS_actionPerformed(ActionEvent e) {
    //add function IOS here.
  }//end comboboxIOS

  void jButtonOK_actionPerformed(ActionEvent e) {
    try {
      String inputSerial = jTextFieldInputSerial.getText();
      String inputEthernet = jTextFieldInputEthernet.getText();
      int serial = Integer.parseInt(inputSerial);
      int ethernet = Integer.parseInt(inputEthernet);

      if (serial >= 0 || ethernet >=0){
        numSerial = Integer.parseInt(inputSerial);
        numEthernet = Integer.parseInt(inputEthernet);
        this.dispose();
      }else {
        JOptionPane.showMessageDialog(null,"#Port error","Error",JOptionPane.ERROR_MESSAGE);
      }

    }catch (Exception exception){
      JOptionPane.showMessageDialog(null,"#Port error","Error",JOptionPane.ERROR_MESSAGE);
//      exception.printStackTrace();
    }
  }//end ButtonOK

  void jButtonCancle_actionPerformed(ActionEvent e) {
    this.dispose();
  }//end ButtonCancle
//---------------End Listenning ------------------------------------

//--------------- Method --------------------------------------------
  public int getNumSerial(){
    return numSerial;
  }//end getNumSerial

  public int getNumEthernet(){
    return numEthernet;
  }//end getNumEthernet

}