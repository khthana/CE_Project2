package netsimulator;

import java.util.*;


class Switch {

  protected String switchMacAddress;
  protected String SwitchName = "Switch1";
  protected Vector vSwitchAddressTable = new Vector();
//  protected Vector vSwitchNeighbor = new Vector();
  private int ID; //Switch ID (fix)

  private boolean activeSelS = false;
  private int swMode = 1;
  private Port swPort;
  private SwitchImg simg;
  private Vector ethernetName;

  public Switch() {
    SwitchName = "";
    switchMacAddress = IntEthernet.genMacAddress();
  }//end Constructor

  public Switch(String swName){
    SwitchName = chkAndsetSwitchName(swName);
    switchMacAddress = IntEthernet.genMacAddress();
  }//end Switch(string)

  public Switch(String swName,int serialPort,int ethernetPort,int tokenringPort){
    SwitchName = chkAndsetSwitchName(swName);
    createPort(serialPort,ethernetPort,tokenringPort);
    switchMacAddress = IntEthernet.genMacAddress();
  }// end Switch(string,port,port,port)

  //---------------------Switch Method------------------------
  public String getSwitchMacAddress(){
    return switchMacAddress;
  }//end get switch macaddress

  public void createPort(int serial,int ethernet,int tokenring){
    swPort = new Port(serial,ethernet,tokenring);
    ethernetName = swPort.getEname();
  }//end createPort

  public void getSport(){

  }
  public Vector getEport(){
    return swPort.getEport();
  }
  public void getTport(){

  }

  public Vector getEname(){
    return ethernetName;
  }//end get Ethernet name

  public String getSwitchName(){
    return SwitchName;
  }//end getSwitchName
  public void setSwitchName(String swName){
    SwitchName = swName;
  }//end setSwitchName

  public int getMode(){
    return swMode;
  }//end getMode
  public void setMode(int mode){
    swMode = mode;
  }//end setMode

  public void setSwitchImg(SwitchImg swImg){
    simg = swImg;
  }
  public SwitchImg getSwitchImg(){
    return simg;
  }


  public boolean isSelected(){
    return activeSelS;
  }//end isSelected

  public void resetSelected(){
    activeSelS = false;
  }//end resetSelected

  public String getSwitchUniName(){
    return "S"+ID;
  }//end getSwitchUniName

  public int getSwitchID(){
    return ID;
  }//end getSwitchID

  public String chkAndsetSwitchName(String name){
      String sName = "Switch";
      int sNumber = 0;

      boolean found = false;
      boolean dup = true;
      boolean flag = true; //for optimize

      while(dup) {
        ++sNumber;
        flag = true;
        found = false;
        for (int i=0; (i < Frame1.vSwitch.size())&&flag ; i++) {
          String alreadyName = ((Switch)Frame1.vSwitch.elementAt(i)).getSwitchName();
          if (alreadyName.equalsIgnoreCase(sName + sNumber)){
            System.out.println(sName+sNumber);
            found = true;
            flag = false;
          }//end if
        }//end for
        dup = found;
      }//end while(dup)

      System.out.println("sName+sNumber = "+sName+sNumber);
      System.out.println("Switch ID = "+sNumber);
      ID = sNumber;
      return sName+sNumber;
  }//end constructor switch(String)

//-------- SWITCH OPERATION -----------------------------

  //-------- LOOKUP TABLE --------------------------------
  public boolean lookupTable(String device_inName, String ipSource,String ipDest){
    boolean found_macSource = false;
    boolean found_macDest = false;

    String macSource = arp(ipSource);
    String macDest = arp(ipDest);

    for (int find = 0; find < vSwitchAddressTable.size(); find++) {
      String chk_mac = vSwitchAddressTable.elementAt(find).toString();
      //search mac source
      if (macSource.equalsIgnoreCase(chk_mac)){
        found_macSource = true;
      }//end if
    } //end for
    if (!found_macSource){
      vSwitchAddressTable.addElement(macSource);
    }//end address learning

    //search mac dest
    for (int find = 0; find < vSwitchAddressTable.size(); find++) {
      String chk_mac = vSwitchAddressTable.elementAt(find).toString();
      if (macDest.equalsIgnoreCase(chk_mac)) {
        found_macDest = true;
      } //end if
    } //end for
    if (!found_macDest){
//      found_macDest = flooding(device_inName, ipSource, ipDest);
    }
    return found_macDest;
  }//end lookup table

  //-------- Flooding Packet ---------------------------
  public boolean flooding(String device_in, String ipAddressSource, String ipAddressDest) { //,String macAddressDest){
    boolean found_dest = false;
    String macSource = arp(ipAddressSource);
    String macDest = arp(ipAddressDest);

    try {
    for (int count = 0; count < getEport().size(); count++) {
      IntEthernet et = (IntEthernet)getEport().elementAt(count);
      String connectionwith = et.getConnectionWith();
      String connect_device = Connections.cutString(connectionwith,0," ");

      if (connect_device.charAt(0) == 'H'){
        String mac_end = et.getConnectInformation();
        if (mac_end.equalsIgnoreCase(macDest)) {
          vSwitchAddressTable.addElement(macDest);
          found_dest = true;
        }//end if host
      }else if (connect_device.charAt(0) == 'R'){
        for (int index = 0; index < Frame1.vRouter.size(); index++){
          Router rt = (Router)Frame1.vRouter.elementAt(index);
          String rt_uniName = rt.getRouterUniName();
          if (rt_uniName.equalsIgnoreCase(connect_device)){
            found_dest = rt.lookupIPTable(ipAddressDest);
          }//end if
        }//end for router
      }else if (connect_device.charAt(0) == 'S'){
        for (int index = 0; index < Frame1.vSwitch.size(); index++){
          Switch sw = (Switch)Frame1.vSwitch.elementAt(index);
          String sw_uniName = sw.getSwitchUniName();
          if (sw_uniName.equalsIgnoreCase(connect_device)){

            found_dest = sw.lookupTable(connect_device, ipAddressSource,ipAddressDest);
          }//end if
        }//end for switch*/
      }//end if
    }
    }catch (Exception ex) {found_dest = false;}





/* OK -----------------------------------------
      for (int count = 0; count < this.getEport().size(); count++) {
        IntEthernet et = (IntEthernet)this.getEport().elementAt(count);
        String mac_end = et.getConnectInformation();
        if (mac_end.equalsIgnoreCase(macAddressDest)) {
          vSwitchAddressTable.addElement(macAddressDest);
          found_dest = true;
        }//end if compare
      }//end for search in Ethernet port
//    ---------------------------------------------
*/
      return found_dest;
  }//end operation switchFlooding

//-------- ARP IP TO MAC ADDRESS -----------------------
  public String arp(String ip){
    String mac = "ffff.ffff.ffff";

    for (int count = 0; count < Frame1.vHost.size(); count++){
      Host ho = (Host)Frame1.vHost.elementAt(count);
      String ip_chk = ho.getHostIPAddress();
      if (ip_chk.equalsIgnoreCase(ip)){
        mac = ho.hostMacAddress;
      }//end if
    }//end for

    for (int count = 0; count < Frame1.vSwitch.size(); count++){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
      for (int index = 0; index < sw.getEport().size(); index++){
        IntEthernet et = (IntEthernet)sw.getEport().elementAt(index);
        String ip_chk = et.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = et.getMacAddress();
        }//end if
      }//end for
    }//end for

    for (int count = 0; count < Frame1.vRouter.size(); count++){
      Router rt = (Router)Frame1.vRouter.elementAt(count);
      for (int index = 0; index < rt.getEport().size(); index++){
        IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
        String ip_chk = et.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = et.getMacAddress();
        }//end if
      }//end for
      for (int index = 0; index < rt.getSport().size(); index++){
        IntSerial se = (IntSerial)rt.getSport().elementAt(index);
        String ip_chk = se.getIPAddress();
        if (ip_chk.equalsIgnoreCase(ip)){
          mac = rt.getRouterMacAddress();
        }//end if
      }//end for
    }//end for
    return mac;
  }//end arp

/*  public String rarp(String mac){
      String ip = "0.0.0.0";

      for (int count = 0; count < Frame1.vHost.size(); count++){
        Host ho = (Host)Frame1.vHost.elementAt(count);
        String mac_chk = ho.getHostMacAddress();
        if (mac_chk.equalsIgnoreCase(mac)){
          ip = ho.getHostIPAddress();
        }//end if
      }//end for

      for (int count = 0; count < Frame1.vSwitch.size(); count++){
        Switch sw = (Switch)Frame1.vSwitch.elementAt(count);
        String mac_chk = sw.getSwitchMacAddress();
        if (mac_chk.equalsIgnoreCase(mac)){
          ip = sw.getMacAddress();
        }//end if

      }//end for

      for (int count = 0; count < Frame1.vRouter.size(); count++){
        Router rt = (Router)Frame1.vRouter.elementAt(count);
        for (int index = 0; index < rt.getEport().size(); index++){
          IntEthernet et = (IntEthernet)rt.getEport().elementAt(index);
          String ip_chk = et.getIPAddress();
          if (ip_chk.equalsIgnoreCase(ip)){
            mac = et.getMacAddress();
          }//end if
        }//end for
        for (int index = 0; index < rt.getSport().size(); index++){
          IntSerial se = (IntSerial)rt.getSport().elementAt(index);
          String ip_chk = se.getIPAddress();
          if (ip_chk.equalsIgnoreCase(ip)){
            mac = rt.getRouterMacAddress();
          }//end if
        }//end for
      }//end for
      return mac;
    }//end arp*/


//*************  OTHER METHOD *******************************************************//



}//End Switch
