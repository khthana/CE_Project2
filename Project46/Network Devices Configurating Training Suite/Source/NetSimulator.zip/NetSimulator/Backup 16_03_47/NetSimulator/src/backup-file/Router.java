package netsimulator;

import java.util.*;
import java.lang.*;

public class Router {

  private Vector vIpTable = new Vector();

  protected String routerMacAddress;
  private int ID; //router ID (fix);

  private Port rtPort;
  private Vector serialName;

  private int RouterSeries;
  private boolean activeSelR = false; //use for connections

  static int num = 0;
  protected String routerName;
  private String Label;
  private String status;
  static String status_detail;
  private int mode;  //mode config
  private String s1="";// add 4/11/45
  private char flag;// c is static or no protocol & r is rip & o is ospf
  private String Protocol;
  private int sequence=0;
  private int Maxseq=0;
  private int maxEth;
  private boolean telnet ;
  private int maxSerial;
  private int maxToken;
  private int Maxr;
  private int maxHistory;
  private int eth;
  private int serial;
  private int token;
  private String clock;
  private String network_address;
  private String password;
  private String vtyPasswd;
  private String auxPasswd;
  private String consolePasswd;
  private boolean enablepasswd;
  private boolean enabletelnet;
  private boolean enableconsole;
  private boolean ipclassless;
  private boolean terminalEdit;
//  private Rip rip=null;
//  private Ospf ospf=null;
  private int time = 10000;//time to sleep
  private int holdtime = 18000;
  private Vector vInt = new Vector();
  private Vector vrt = new Vector();
  private Vector hello = new Vector();
  private Vector vHello = new Vector();
  private Vector history = new Vector();
  private Vector dnsTable = new Vector();
  private Vector vIntTemp = new Vector();
  private Vector vIntTemp_S = new Vector();
  private Vector vIntTemp_T = new Vector();
  private Vector vAccessList = new Vector();

//  private RouterCdp cdp = new RouterCdp();
//  private RouterConsole rconsole;
  private int oldMode;

  private Vector vDns= new Vector();
  private boolean enabledns;
  private int lineMode = -1;
  private int cost = 10;
  private boolean debugrip = false;
  static String output="";
  private String oldname;

  //----------//
//por comment here
  public void initialInterface(){ //-- initial interface ( vIntTemp )
/*
   String name = "" ;
   RouterInterface defaultInterface ;
   int e=0,s=0,t=0;

   //-- Ethernet
   while ( e < maxEth ) {
     name = "E" + e; // set interface name
     defaultInterface = new RouterInterface( name , "Ethernet" );

     vIntTemp.addElement( defaultInterface ); //-- add elements
     e++;
   }

    //-- Serial
   while ( s < maxSerial ) {
     name =  "S" + s;
     defaultInterface = new RouterInterface( name , "Serial" ); //-- add elements
     vIntTemp.addElement( defaultInterface );
     s++;
   }

   //-- Token Ring
   while ( t < maxToken ) {
     name = "T" + t;
     defaultInterface = new RouterInterface( name , "Token Ring" ); //-- add elements
     vIntTemp.addElement( defaultInterface );
     t++;
   }//*/
 }
//-- called by WireDialog for delete selected interface
  public void deleteInt( int index , String intName ) {
/*
    Router defaultRouter = (Router)Frame1.vRouter.elementAt( index ); //-- Get router by index
    Vector vTemp = defaultRouter.getVIntTemp();    //-- Get interface vector

    int i = -1;
    boolean sign = false;

    while( !sign ){

      i++;
      RouterInterface in = (RouterInterface)vTemp.elementAt(i) ;

      if( intName.equalsIgnoreCase( in.getNameInt() ) )
        sign = true;
    }

    defaultRouter.vIntTemp.removeElementAt(i); //-- remove at element i*/
  }

  //-- add interface back when wire was delete
/*  public void addIntBack( int index1 , int index2 , String int1 , String int2 , String type ){

    Router defaultRouter1 = (Router)Frame1.vRouter.elementAt( index1 ); //-- Get router1 by index
    Router defaultRouter2 = (Router)Frame1.vRouter.elementAt( index2 ); //-- Get router2 by index

    RouterInterface interface1 = new RouterInterface( int1 , type );
    defaultRouter1.vIntTemp.addElement( interface1 );

    RouterInterface interface2 = new RouterInterface( int2 , type );
    defaultRouter2.vIntTemp.addElement( interface2 );
  }*/
 public Vector getVIntTemp(){
   return vIntTemp;
  }
 public Vector getVIntTemp_S(){
   return vIntTemp_S;
  }
  public Vector getVIntTemp_T(){
   return vIntTemp_T;
  }
  public void setRouterSeries(int i){
    RouterSeries = i;
  }
  public void setMaxr(int max){
    Maxr=max;
  }
  public int getMaxr(){
    return Maxr;
  }
  public int getRouterSeries(){
    return RouterSeries;
  }
  public void setTerminalEdit(boolean b){
    terminalEdit = b;
  }
  public boolean getTerminalEdit(){
    return terminalEdit;
  }
  public void setHoldTime(int i){
    holdtime = i;
  }
  public int getHoldTime(){
    return holdtime;
  }
  public void setIpClassless(boolean b){
    ipclassless = b;
  }
  public boolean getIpClassless(){
    return ipclassless;
  }
  public void setConsolePasswd(String s){
    consolePasswd = s;
  }
  public String getConsolePasswd(){
    return consolePasswd;
  }
  public void setLineMode(int i){
    lineMode = i;
  }
  public void setSeq(int seq)
{
  sequence = seq;
}
public int getSeq()
{
  return sequence;
}
public void setMaxseq(int max)
{
  Maxseq = max;
}
public int getMaxseq()
{
return Maxseq;
  }

  public int getLineMode(){
    return lineMode;
  }
  public Vector getDns(){
    return vDns;
  }
  public void setEnableDns(boolean b){
    enabledns = b;
  }
  public boolean getEnableDns(){
    return enabledns;
  }
  public void setVtyPasswd(String s){
    vtyPasswd = s;
  }
  public String getVtyPasswd(){
    return vtyPasswd;
  }
  public void setAuxPasswd(String s){
    auxPasswd = s;
  }
  public String getAuxPasswd(){
    return auxPasswd;
  }
  public void setEnableTelnet(boolean b){
    enabletelnet = b;

  }
  public boolean getEnableTelnet(){
    return enabletelnet;
  }
  public boolean getEnableConsole(){
    return enableconsole;
  }
  public void setEnableConsole(boolean b){
    enableconsole = b;
  }
  public void setOldMode(int i){
    oldMode = i;
  }
  public int getOldMode(){
    return oldMode;
  }
  public void setEnablePasswd(boolean b){
    enablepasswd = b;
  }
  public boolean getEnablePasswd(){
    return enablepasswd;
  }
  public String getClock(){
    return clock;
  }
  public void setClock(String s){
    clock = s;
  }
/*  public RouterCdp getCdp(){
    return cdp;
  }*/
  //-----//
//  public RouterConsole getRouterConsole(){
//    return rconsole;
//  }
  public String getPasswd(){
    return password;
  }
  public void setPasswd(String s){
    password = s;
  }
  public void setLabel(String mark)
  {
    Label = mark;
  }
  public String getLabel()
  {
    return Label;
  }
/*  //-----------Get Protocol-------------//
  public Rip getRIP(){
    return rip;
  }
  public Ospf getOSPF(){
    return ospf;
  }//*/
  //-----------debug ip rip------------//
//por comment here 2
/*
  public void setdebugrip(boolean t)
  {
    debugrip = t;
  }
  public boolean getdebugrip()
  {
    return debugrip;
  }
  //----------------Set Max History----------------//
  public void setMaxHistory(int i){
    maxHistory = i;
  }
  public int getMaxHistory(){
    return maxHistory;
  }
  //--------------get Hello-------------------------//
  public Vector getVHello(){
    return vHello;
  }
  public Vector getHello(){
    return hello;
  }//*/
  //------------------Set Name---------------------//
  public void setRouterName(String s){
    routerName = s;
  }
  public String getRouterName(){
    return routerName;
  }
  //------------------Set network_address---------------------//
/*  public void setNetwork_address(String s){
    if(s.equalsIgnoreCase(network_address))
    {
      network_address="161.246.0.0";
    }
    else
    {
      network_address = s;
    }
  }
  public String getNetwork_address(){
    return network_address;
  }
  //---------------Set Status------------------------//
  public void setStatus(String s){
    status = s;
  }
  public String getStatus(){
    return status;
  }
  //---------------Set Status_detail------------------------//
  static void setStatus_detail(String s){
    status_detail = s;
  }
  static String getStatus_detail(){
    return status_detail;
  }
  //---------------Set s1 kept interface------------------------//
  public void sets1(String s){
    s1 = s;
  }
  public String gets1(){
    return s1;
  }*/
  //-----------------Set Mode------------------------//
  public void setMode(int i){
    mode = i;
  }
  public int getMode(){
    return mode;
  }

/*  public void setCost( int w ) {
    cost = w;
  }

  public int getCost(){
    return cost;
  }

  public void setProtocol(String p){
      Protocol = p;

}
public String getProtocol(){
 return Protocol;
  }

  //-------------------Set Time----------------------//
  public void setTime(int t){
    time = t;
  }
  public int getTime(){
    return time;
  }
  //--------------------Set Table--------------------//
  public Vector getVrt(){
    return vrt;
  }
  public Vector getVInt(){
    return vInt;
  }
  //-------------Set Flag---------------//
  public void setFlag(char c){
    flag = c;
  }
  public char getFlag(){
    return flag;
  }
  public void setOldname(String name)
  {
    oldname=name;
  }
  public String getOldname()
  {
    return oldname;
  }*/
  //---------------Set Ethernet-----------//
  public void setEth(int n){
    eth = n;
  }
  public int getEth(){
    return eth;
  }
  public void setMaxEth(int n){
    maxEth = n;
  }
  public int getMaxEth(){
    return maxEth;
  }
  //---------------Set Serial-----------//
  public void setSerial(int n){
    serial = n;
  }
  public int getSerial(){
    return serial;
  }
  public void setMaxSerial(int n){
    maxSerial = n;
  }
  public int getMaxSerial(){
    return maxSerial;
  }
  public void setTelnet(boolean t)
  {
    telnet = t;
  }
  public boolean getTelnet()
  {
    return telnet;
  }
/*  //---------------Set Token Ring-----------//
  public void setToken(int n){
    token = n;
  }
  public int getToken(){
    return token;
  }
  public void setMaxToken(int n){
    maxToken = n;
  }
  public int getMaxToken(){
    return maxToken;
  }
  //----------------Get History-----------------------//
  public Vector getHistory(){
    return history;
  }//*/

  //constructor
  public Router() {
    routerMacAddress = IntEthernet.genMacAddress();
    routerName = "Router";
    sequence=0;
    Maxseq=0;
    oldname="";
    telnet = false;
    s1 ="";// add 4/11/45
    status = "down";
    status_detail = "";
    mode = 1;
    flag = 'c';
    Protocol="Not have any";
    network_address="161.246.0.0";
    cost =10;
    eth = 0;
    maxEth = 10;
    token = 0;
    maxToken=10;
    serial = 0;
    maxSerial =10;
    maxHistory=10;
    num++;
    password = null;
    vtyPasswd = null;
    consolePasswd = null;
    auxPasswd = null;
    // Interface intf = new Interface();// add 1/11/2545
    /*  rip = new Rip(this);
       debugrip = false;
       ospf = new Ospf(this);//
    enablepasswd = false;
    enabledns = false;
    enabletelnet = false;
    ipclassless = false;
    terminalEdit = true;
    oldMode = -1;*/
  }

public Router(String s){
  routerName = chkAndsetRouterName(s);
  routerMacAddress = IntEthernet.genMacAddress();
}

public Router(String s,int serialPort,int ethernetPort,int tokenringPort){
  String rtName = chkAndsetRouterName(s);
  setRouterName(rtName);

  createPort(serialPort,ethernetPort,tokenringPort);
  routerMacAddress = IntEthernet.genMacAddress();

  sequence =0;
  Maxseq=0;
  oldname="";
  telnet = false;
  s1 ="";// add 4/11/45
  status = "down";
  mode = 1;
  flag = 'c';
  Protocol="Not have any";
  network_address="161.246.0.0";
  cost =10;
  eth = 0;
  maxEth=10;
  serial = 0;
  maxSerial=10;
  token = 0;
  maxToken=10;
  maxHistory=10;
  num++;
  password = null;
  vtyPasswd = null;
  consolePasswd = null;
  auxPasswd = null;
 // Interface intf = new Interface();// add 1/11/2545
/*  rip = new Rip(this);
  debugrip = false;
  ospf = new Ospf(this);//
  enablepasswd = false;
  enabledns = false;
  enabletelnet = false;
  ipclassless = false;
  terminalEdit = true;
  oldMode = -1;
  for (int a=this.getVrt().size();a > 0; a--){
    RoutingTable rt = (RoutingTable)this.getVrt().elementAt(a);
    if (rt.getRouteType() == 'r'){
      this.getVrt().removeElementAt(a);
    }//end if
  }//end for*/
  }//Router(String s)

  public String getRouterUniName(){
    return "R"+ID;
  }//end getRouterUniName

  public int getRouterID(){
    return ID;
  }//end getRouterID

  public String getRouterMacAddress(){
    return routerMacAddress;
  }//end get router macaddress


  public String chkAndsetRouterName(String name){
    String rName = "Router";
    int rNumber = 0;

    boolean found = false;
    boolean dup = true;
    boolean flag = true; //for optimize

    while(dup) {
      ++rNumber;
      flag = true;
      found = false;
      for (int i=0; (i < Frame1.vRouter.size())&&flag ; i++) {
        String alreadyName = ((Router)Frame1.vRouter.elementAt(i)).getRouterName();
        if (alreadyName.equalsIgnoreCase(rName + rNumber)){
          System.out.println(rName+rNumber);
          found = true;
          flag = false;
        }//end if
      }//end for
      dup = found;
    }//end while(dup)

    System.out.println("rName+rNumber = "+rName+rNumber);
    System.out.println("Router ID = "+rNumber);

    ID = rNumber;
    return rName+rNumber;
  }//end chkAndSetRouterName

  public boolean isSelected(){
    return activeSelR;
  }//end isSelected

  public void resetSelected(){
    activeSelR = false;
  }//end resetSelected

//-------- Port -------------------------------------------------------
  public void createPort(int serial,int ethernet,int tokenring){
    rtPort = new Port(serial,ethernet,tokenring);
    serialName = rtPort.getSname();
  }//end createPort

  public Vector getSport(){
    return rtPort.getSport();
  }
  public Vector getEport(){
    return rtPort.getEport();
  }

  public Vector getSname(){
    return serialName;
  }//end get Ethernet name

  //---------Lookup ip table ----------------------------------------
  public boolean lookupIPTable(String ip){
    boolean found_ip = false;

    for (int count = 0; count < vIpTable.size(); count++){
      String ip_chk = vIpTable.elementAt(count).toString();
      if (ip_chk.equalsIgnoreCase(ip)){
        found_ip = true;
      }//end if
    }//end for
    return found_ip;
  }//end lookupIPTable

}//end Class Router
