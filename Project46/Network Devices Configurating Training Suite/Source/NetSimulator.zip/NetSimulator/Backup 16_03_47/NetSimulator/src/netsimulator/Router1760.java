package netsimulator;

import java.util.Vector;
import java.lang.*;

class Router1760 extends Router{

  public Router1760(String rName) {

    setRouterSeries(1760);

    routerName = chkAndsetRouterName(rName);
    createPort(2,3,0);
    routerMacAddress = IntEthernet.genMacAddress();

  }//end Constructor Router1760(String rName);

//---------------------Router Method Extend --------------------

}//End Class Router1760