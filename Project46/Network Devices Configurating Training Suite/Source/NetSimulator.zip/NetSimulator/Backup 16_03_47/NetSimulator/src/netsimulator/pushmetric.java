package netsimulator;

public  class pushmetric {
  static private String sre;
  static public String pushme(String m){
    int intm;
//    String mm = new String(m);
try{
//      intm = m;
    intm = Integer.parseInt(m);
      intm += 1;

    sre = Integer.toString(intm);
//      sre = m.toString().trim();
      System.out.println("print from pushmetric new metric is " + sre);
    }catch(Exception e){
     System.out.println("Can not push metric");
    }
    return sre;
  }
}