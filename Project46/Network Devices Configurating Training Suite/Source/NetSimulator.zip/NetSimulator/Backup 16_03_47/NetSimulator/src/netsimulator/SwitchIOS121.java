package netsimulator;

import java.lang.*;
import java.util.*;

class SwitchIOS121 {

  private String error = "";
  private final String cmdError = "% Invalid input detected at '^' marker.";
  private final String ambigous = "% Ambiguous Command :";
  //used command
  public final String[] userMode = new String[]{"?","enable","exit","ping arg_ip_name","show cdp","show cdp entry *","show cdp entry arg_name","show cdp interface","show cdp neighbors","tracerouter arg_ip_name"};
  public final String[] privMode = new String[]{"?","configure terminal","copy running_config startup_config","copy startup-config running-config","debug ip rip","disable","erase startup-config","ping arg_ip_name","show history","show cdp","show cdp entry arg_name","show cdp entry *","show cdp interface","show cdp neighbors","show ip route","show ip rip database","show ip ospf database","show ip route arg_routetype","show running config","show startup config","show version","show interface","show interface arg_typeint","show ip protocol","show ip ospf neighbors","show ip ospf interface arg_intname","terminal editing","terminal no editing","undebug ip rip"};
  public final String[] configMode = new String[] {"?","enable secret arg_string","exit","hostname arg_string","interface arg_intname","ip route arg_ip arg_ip arg_ip","ip classless","ip host arg_name arg_ip","ip ospf cost arg_name arg_num","line vty 0 4","line auxilary 0","line console 0","no enable secret","no banner login","no ip route arg_ip arg_ip arg_ip","no ip classless","no router arg_protocol","router arg_protocol arg_num","router arg_protocol"};
  public final String[] interfaceMode = new String[] {"?","bandwidth arg_num","cdp","clock rate arg_num","end","exit","interface arg_intname","ip address arg_ip arg_ip","no shutdown","ring-speed arg_num","shutdown"};
  public final String[] routerMode = new String[] {"?","exit","network arg_ip","passive-interface arg_intname","no passive-interface arg_intname","no network arg_ip","no distribute-list arg_gateway"};
  public final String[] lineMode = new String[] {"?","exit","login","password arg_string","no login"};

//  private boolean foundcmd = false;

  private Vector commandArgu = new Vector();
  private int arguSize = 0;

  private Vector cmdListArgu = new Vector();
  private int listSize = 0;

  private String cmdList[] = null;

  public SwitchIOS121() {}  // default Constructor()

  public void runCommand(Switch sw, String fullSwitchcmd,SwitchConsole Sconsole) {

    switch (sw.getMode()){
      case 1 : cmdList = userMode;break;
      case 2 : cmdList = privMode;break;
      case 3 : cmdList = configMode;break;
      case 4 : cmdList = interfaceMode;break;
      case 5 : cmdList = routerMode;break;
      case 6 : cmdList = lineMode;break;
      default :cmdList = userMode;break;
    }//end switch

    splitCommand(fullSwitchcmd);

//-+-+-+-+-+-+-+-+-+-+- RUN -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

//    if (true){//foundcmd) {//for optimize
    try{
      switch (sw.getMode()) {

//User Mode
        case 1:
          if (chkShortCmd(0,"?") && moreArgu(1)){
//            Sconsole.append("?");
            showCmd1(Sconsole);
          } //end ?
          else if (chkShortCmd(0,"enable","en") && moreArgu(1)){
            sw.setMode(2);
          } //end enable
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {
            Sconsole.reset();
          } //end exit
          else if (chkShortCmd(0,"ping") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {
              String output_result = "";
              String argument = commandArgu.elementAt(1).toString();

              if (sw.lookupTable(sw.getSwitchUniName(), sw.getSwitchMacAddress(),commandArgu.elementAt(1).toString())){
                output_result = "\n"+
                    "Pinging "+argument+" with 32 bytes of data:\n\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n\n"+
                    "Ping statistics for "+argument+":\n"+
                    "    Packets: Sent = 4, Received = 4, Lost = 0 <0% loss>,\n"+
                    "Approximate round trip times in milli-seconds:\n"+
                    "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
              }else {
                output_result = "\n"+
                    "Pinging "+argument+" with 32 bytes of data:\n\n"+
                    "Request time out.\n"+
                    "Request time out.\n"+
                    "Request time out.\n"+
                    "Request time out.\n\n"+
                    "Ping statistics for "+argument+":\n"+
                    "    Packets: Sent = 4, Received = 0, Lost = 4 <100% loss>,\n"+
                    "Approximate round trip times in milli-seconds:\n"+
                    "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
              }
              Sconsole.append(output_result);
            }
            else {}
          } //end ping

          else if (chkShortCmd(0,"show","sh") && moreArgu(3)) {
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"cdp")) {
                  System.out.println("Show cdp");
                  //show cdp//
                  showCDP(sw,Sconsole);
                }
                else {
                  Sconsole.append(cmdError);
                }
                break;
              case 2:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"interface","int")) {
                    Sconsole.append("Show cdp interface");
                  }
                  else if (chkShortCmd(2,"neighbors","nb")) {
                    Sconsole.append("Show cdp neighbors");
                  }
                  else {
                    Sconsole.append(cmdError);
                  }
                }
                else {
                  Sconsole.append(cmdError);
                }
                break;
              case 3:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"entry","en")) {
                    if (chkShortCmd(3,"*")) {
                      Sconsole.append("Show cdp entry *");
                    }
                    else {
                      Sconsole.append("Show cdp entry " +
                                      commandArgu.elementAt(3).toString());
                    }
                  }
                  else if (chkShortCmd(2,"neighbors","nb")) {
                      Sconsole.append("Show cdp neighbors");
                  }else Sconsole.append(cmdError);
                }//end if case 3
                else {
                  Sconsole.append(cmdError);
                }
                break;
            } //end switch
          } //end show
          else if (chkShortCmd(0,"traceroute","trace") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {
              //sw traceroute protocol
              System.out.println("traceroute by ip:" +
                                 commandArgu.elementAt(1).toString());
            }
            else {
              //sw traceroute protocol
              System.out.println("traceroute by host:" +
                                 commandArgu.elementAt(1).toString());
            }
          } //end traceroute
          else {
            Sconsole.append(cmdError);//TrueCMD);
            break;
          }//end if
          break;
// end Mode 1: UserMode ">"

//Privilage Mode
        case 2:
          if (chkShortCmd(0,"?") && moreArgu(1)) {
            Sconsole.append("?");
          }//end ?
          else if (chkShortCmd(0,"configure","config") && moreArgu(2)) {
            if (chkShortCmd(1,"terminal","t")){
              sw.setMode(3);
            }else {
              Sconsole.append(cmdError);
            }
          }//end configure
          else if (chkShortCmd(0,"copy") && moreArgu(3)){
            if (chkShortCmd(1,"running-config","r") && chkShortCmd(2,"startup-config","s")){
              System.out.println("Copy running-config -> startup-config");
            }else if (chkShortCmd(1,"startup-config","s") && chkShortCmd(2,"running-config","r")){
              System.out.println("Copy startup-config -> running-config");
            }else {
              Sconsole.append(cmdError);
            }
          }//end copy
          else if (chkShortCmd(0,"debug") && moreArgu(3)){
            if (chkShortCmd(1,"ip") && chkShortCmd(2,"rip")){
              System.out.println("Debug ip rip");
            }else {
              Sconsole.append(cmdError);
            }
          }//end debug
          else if (chkShortCmd(0,"disable","dis") && moreArgu(1)){
            sw.setMode(1);
          }//end disable
          else if (chkShortCmd(0,"erase") && moreArgu(2)){
            if (chkShortCmd(1,"startup-config","s")) {
                System.out.println("Erase startup-config");
            }else {
              Sconsole.append(cmdError);
            }
          }//end erase
          else if (chkShortCmd(0,"ping") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {
              String output_result = "";
              String argument = commandArgu.elementAt(1).toString();

              if (sw.lookupTable(sw.getSwitchUniName(), sw.getSwitchMacAddress(),commandArgu.elementAt(1).toString())){
                output_result = "\n"+
                    "Pinging "+argument+" with 32 bytes of data:\n\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n"+
                    "Reply from "+argument+": bytes = 32 time<10ms TTL=128\n\n"+
                    "Ping statistics for "+argument+":\n"+
                    "    Packets: Sent = 4, Received = 4, Lost = 0 <0% loss>,\n"+
                    "Approximate round trip times in milli-seconds:\n"+
                    "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
              }else {
                output_result = "\n"+
                    "Pinging "+argument+" with 32 bytes of data:\n\n"+
                    "Request time out.\n"+
                    "Request time out.\n"+
                    "Request time out.\n"+
                    "Request time out.\n\n"+
                    "Ping statistics for "+argument+":\n"+
                    "    Packets: Sent = 4, Received = 0, Lost = 4 <100% loss>,\n"+
                    "Approximate round trip times in milli-seconds:\n"+
                    "    Minimum = 0ms, Maximum = 0ms, Average = 0ms";
              }
              Sconsole.append(output_result);
            }
            else {}
          } //end ping

          else if (chkShortCmd(0,"show","sh") && moreArgu(5)){
            switch (arguSize-1) {
              case 1:
                if (chkShortCmd(1,"cdp")) {
                  Sconsole.append("Show cdp"); //show cdp//
                }else if (chkShortCmd(1,"history","his")) {
                  for (int i=0; i <= Sconsole.history.size()-1; i++){
                    Sconsole.append("History "+i+" : "+Sconsole.history.elementAt(i).toString());
                  }
                }else if (chkShortCmd(1,"interface","int")){
                  Sconsole.append("Show Interface");
                }else if (chkShortCmd(1,"running-config","r")){
                  Sconsole.append("show running-config");
                }else if (chkShortCmd(1,"startup-config","s")){
                  Sconsole.append("show startup-config");
                }else if (chkShortCmd(1,"version","ver")){
                  Sconsole.append("IOS Version 12.1");
                }
                else {
                  Sconsole.append(cmdError);
                }
                break;
              case 2:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"interface","int")) {
                    Sconsole.append("Show cdp interface");
                  }
                  else if (chkShortCmd(2,"neighbors","nb")) {
                    Sconsole.append("Show cdp neighbors");
                  }
                  else {
                    Sconsole.append(cmdError);
                  }
                }else if (chkShortCmd(1,"interface","int")) {
                  Sconsole.append("show interface "+commandArgu.elementAt(2).toString());
                }else if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"protocol","pro")){
                    Sconsole.append("show ip protocol");
                  }else if (chkShortCmd(2,"route")){
                    Sconsole.append("show ip route");
                  }
                  else (Sconsole.append(cmdError));
                }
                else {
                  Sconsole.append(cmdError);
                }
                break;
              case 3:
                if (chkShortCmd(1,"cdp")) {
                  if (chkShortCmd(2,"entry","en")) {
                    if (chkShortCmd(3,"*")) {
                      Sconsole.append("Show cdp entry *");
                    }else {
                      Sconsole.append("Show cdp entry "+commandArgu.elementAt(3).toString());
                    }
                  }else if(chkShortCmd(2,"neighbors","nb")){
                    Sconsole.append("Show cdp neighbors");
                  }else Sconsole.append(cmdError);
                }else if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"ospf")){
                    if (chkShortCmd(3,"database","db")){
                      Sconsole.append("show ip ospf database");
                    }else if (chkShortCmd(3,"neighbors","nb")){
                      Sconsole.append("show ip ospf neighbors");
                    }else (Sconsole.append(cmdError));
                  }else if (chkShortCmd(2,"rip")){
                    if (chkShortCmd(3,"database")){
                      Sconsole.append("show ip rip database");
                    }else (Sconsole.append(cmdError));
                  }else if (chkShortCmd(2,"route")) {
                    Sconsole.append("show ip route "+commandArgu.elementAt(3).toString());
                  }
                }else Sconsole.append(cmdError);
                break;
              case 4:
                if (chkShortCmd(1,"ip")){
                  if (chkShortCmd(2,"ospf")){
                    if (chkShortCmd(3,"interface","int")){
                      Sconsole.append("show ip ospf interface "+commandArgu.elementAt(4).toString());
                    }else Sconsole.append(cmdError);
                  }else Sconsole.append(cmdError);
                }else Sconsole.append(cmdError);
                break;
            } //end switch
          } //end show
          else if (chkShortCmd(0,"terminal","ter") && moreArgu(3)){
            if (chkShortCmd(1,"editing","edit")){
              System.out.println("Terminal editing");
            }else if (chkShortCmd(1,"no") && chkShortCmd(2,"editing","edit")) {
              System.out.println("Terminal no editing");
            }else {
              Sconsole.append(cmdError);
            }
          }//end terminal
          else if (chkShortCmd(0,"traceroute","trace") && moreArgu(2)) {
            if (isIp(commandArgu.elementAt(1).toString())) {
              //sw traceroute protocol
              System.out.println("traceroute by ip:" +
                                 commandArgu.elementAt(1).toString());
            }
            else {
              //sw traceroute protocol
              System.out.println("traceroute by host:" +
                                 commandArgu.elementAt(1).toString());
            }
          } //end traceroute
          else if (chkShortCmd(0,"undebug","unde") && moreArgu(3)){
            if (chkShortCmd(1,"ip") && chkShortCmd(2,"rip")){
              System.out.println("Undebug ip rip");
            }else {
              Sconsole.append(cmdError);
            }
          }//end undebug
          else {
            Sconsole.append(cmdError);
            break;
          }//end if
          break;
// end Mode 2: Privilage Mode "#"

//Config Mode
        case 3:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"enable","en") && moreArgu(3)){
            if (chkShortCmd(1,"secret","sec")){
              Sconsole.append("enable secret "+commandArgu.elementAt(2).toString());
            }else Sconsole.append(cmdError);
          }//end enable
          else if (chkShortCmd(0,"exit") && moreArgu(1)){
            sw.setMode(2);
          }//end exit
          else if (chkShortCmd(0,"hostname","hn") && moreArgu(2)){
            sw.setSwitchName(commandArgu.elementAt(1).toString());
            Sconsole.setTitle(" - = "+sw.getSwitchName()+" Console = - ");
          }//end hostname
          else if (chkShortCmd(0,"interface","int") && moreArgu(2)){
            sw.setMode(4);
          }//end interface
          else if (chkShortCmd(0,"line") && moreArgu(4)){
            if (chkShortCmd(1,"auxilary","aux")){
              if (chkShortCmd(2,"0")){
                Sconsole.append("line auxilary 0");
                sw.setMode(6);
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"console","con")){
              if (chkShortCmd(2,"0")){
                Sconsole.append("line console 0");
                sw.setMode(6);
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"vty")){
              if (chkShortCmd(2,"0")){
                if (chkShortCmd(3,"4")){
                Sconsole.append("line vty 0 4");
                sw.setMode(6);
                }else Sconsole.append(cmdError);
              }else Sconsole.append(cmdError);
            }else Sconsole.append(cmdError);
          }//end line
          else if (chkShortCmd(0,"ip") && moreArgu(5)){
            if (chkShortCmd(1,"classless","cl")) {
              Sconsole.append("ip classless");
            }
            else if (chkShortCmd(1,"host")){
              Sconsole.append("ip host arg_name arg_ip");
            }
            else if (chkShortCmd(1,"ospf")){
              Sconsole.append("ip ospf cost arg_name arg_num");
            }
            else if (chkShortCmd(1,"route")){
              Sconsole.append("ip route network subnet interface");
            }else Sconsole.append(cmdError);
          }//end ip
          else if (chkShortCmd(0,"no") && moreArgu(6)){
            if (chkShortCmd(1,"banner")){
              if (chkShortCmd(2,"login")) {
                Sconsole.append("no banner login");
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"enable","en")){
              if (chkShortCmd(2,"secret","sec")){
                Sconsole.append("no enable secret");
              }else Sconsole.append(cmdError);
            }else if (chkShortCmd(1,"router")){
              Sconsole.append("no router protocol");
            }else if (chkShortCmd(1,"ip")){
              switch(arguSize-1){
                  case 2 : if (chkShortCmd(2,"classless","cl")){
                      Sconsole.append("no ip classless");
                    }else Sconsole.append(cmdError);
                    break;
                  case 5 : if (chkShortCmd(2,"route")){
                      Sconsole.append("no ip route network subnet interface");
                    }else Sconsole.append(cmdError);
                    break;
                  }//end switch
            }else Sconsole.append(cmdError);
          }//end no
          else if (chkShortCmd(0,"router") && moreArgu(3)){
            switch(arguSize-1){
              case 1 : Sconsole.append("router arg_protocol");
                sw.setMode(5);break;
              case 2 : Sconsole.append("router arg_protocol arg_num");
                sw.setMode(5);break;
            }//end switch
          }//end sw
          else Sconsole.append(cmdError);
          break;
// end Mode 3: Config Mode "(config)#"

// Interface Mode
        case 4:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"bandwidth","bw") && moreArgu(2)){
            Sconsole.append("set bandwidth = "+commandArgu.elementAt(1).toString());
          }//end bandwidth
          else if (chkShortCmd(0,"cdp") && moreArgu(1)){
            Sconsole.append("set cdp");
          }//end cdp
          else if (chkShortCmd(0,"clock","clk") && moreArgu(3)){
            if (chkShortCmd(1,"rate")){
              Sconsole.append("set clock rate ="+commandArgu.elementAt(2).toString());
            }else Sconsole.append(cmdError);
          }//end clock
          else if (chkShortCmd(0,"end") && moreArgu(1)){
            sw.setMode(3);
          }//end end
          else if (chkShortCmd(0,"exit") && moreArgu(1)){
            sw.setMode(2);
          }//end exit
          else if (chkShortCmd(0,"interface","int") && moreArgu(2)){
            Sconsole.append("Change Interface -> "+commandArgu.elementAt(1));
          }//end interface
          else if (chkShortCmd(0,"ip") && moreArgu(4)){
            if (chkShortCmd(1,"address")){
              if (isIp(commandArgu.elementAt(2).toString()) &&
                  isIp(commandArgu.elementAt(3).toString())) {
                Sconsole.append("set ip address = "+commandArgu.elementAt(2).toString()+
                                "subnet = "+commandArgu.elementAt(3).toString());
              }else Sconsole.append(cmdError);
            }else Sconsole.append(cmdError);
          }//end ip
          else if (chkShortCmd(0,"no") && moreArgu(2)){
            Sconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface Ethernet0, changed state to up\n"+
                            "%LINK-3-UPDOWN: Interface Ethernet0, changed steate to up");
          }//end no
          else if (chkShortCmd(0,"ring-speed") && moreArgu(2)){
            Sconsole.append("set ring-speed "+commandArgu.elementAt(1).toString());
          }//end ring-speed
          else if (chkShortCmd(0,"shutdown") && moreArgu(1)){
            Sconsole.append("%LINEPROTO-5-UPDOWN:Line protocol on interface Ethernet0, changed state to down\n"+
                            "%LINK-3-UPDOWN: Interface Ethernet0, changed steate to down");
          }//end shutdown
          else Sconsole.append(cmdError);
          break;
// end Mode 4 : Interface Mode "(config-if)#"

// sw Mode
        case 5:
          if (chkShortCmd(0,"?") && moreArgu(1)){
          }//end ?
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {
            sw.setMode(3);
          }//end exit
          else if (chkShortCmd(0,"network") && moreArgu(2)){
            if (isIp(commandArgu.elementAt(1).toString())){
              Sconsole.append("network " + commandArgu.elementAt(1).toString());
            }else Sconsole.append(cmdError);
          }//end network
          else if (chkShortCmd(0,"passive-interface","passint") && moreArgu(2)){
            Sconsole.append("passive-interface "+commandArgu.elementAt(1).toString());
          }//end passive-interface
          else if (chkShortCmd(0,"no") && moreArgu(3)){
            if (chkShortCmd(1,"distribute-list","distl")){
              Sconsole.append("no distribute-list");
            }else if (chkShortCmd(1,"network")){
              Sconsole.append("no network "+commandArgu.elementAt(2).toString());
            }else if (chkShortCmd(1,"passive-interface","passint")){
              Sconsole.append("no passive-interface "+commandArgu.elementAt(2).toString());
            }else Sconsole.append(cmdError);
          }//end no
          else Sconsole.append(cmdError);
          break;
// end Mode 5 : sw Mode "(config-sw)#"

// Line Mode
        case 6:
          if (chkShortCmd(0,"?") && moreArgu(1)) {
          }//end ?
          else if (chkShortCmd(0,"exit") && moreArgu(1)) {
            sw.setMode(3);
          }//end exit
          else if (chkShortCmd(0,"login") && moreArgu(1)) {
            Sconsole.append("loging in...");
          }//end login
          else if (chkShortCmd(0,"password","pwd") && moreArgu(2)) {
            Sconsole.append("Password ****");
          }//end password
          else if (chkShortCmd(0,"no") && moreArgu(2)) {
            if (chkShortCmd(1,"login")){
              Sconsole.append("no login");
            }else Sconsole.append(cmdError);
          }//end no
          else Sconsole.append(cmdError);
          break;
// end Mode 6 : Line Mode "(config-Line)#"
      } //end switch sw.getmode
//*/
      }catch (Exception over) {}
  }//end runCommand


//CALL FUNCTION +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  private boolean chkShortCmd(int element,String cmd1) {
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1));
  }//end chkShortCmd(str)
  private boolean chkShortCmd(int element,String cmd1,String cmd2){
    return (commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd1) ||
        commandArgu.elementAt(element).toString().equalsIgnoreCase(cmd2));
  }//end chkShortCmd(str1,str2)

  private void splitCommand(String CMD) {
    commandArgu.removeAllElements();
    StringTokenizer subStr = new StringTokenizer(CMD," ");
    while (subStr.hasMoreTokens()){
      String str = subStr.nextToken();
      commandArgu.addElement(str);
    }//end while
    arguSize = commandArgu.size();
  }//end splitCommand

  private boolean moreArgu(int maxListArgu){
    return (commandArgu.size() <= maxListArgu);
  }//end splitList

  private boolean isIp(String s){
    boolean chk_ip = true;
    StringTokenizer st = new StringTokenizer(s, ".");
    for (int i = 0; i < 4; i++) {
      if (st.hasMoreTokens()) {
        String tmp = st.nextToken();
        try {
          int ip = Integer.parseInt(tmp);
          if ( (ip < 0) || (ip > 255)) {
            chk_ip = false;
          }
        }catch (NumberFormatException exp) {chk_ip = false;}
      }//end if
      else {
        chk_ip = false;
      }//end else
    }//end for
    return chk_ip;
  }//end chk isIp


//Call Method Agent+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  //Help -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
  public void showCmd1(SwitchConsole Sconsole){
     Sconsole.append("Exex Commands:\n"+
     "enable           \t\tTurn on privileged commands\n"+
     "exit             \t\tExit from the EXEC\n"+
     "ping             \t\tSend echo messages\n"+
     "show             \t\tShow running system information\n"+
     "traceroute       \t\tTrace route to destination\n\n");
   }
   public void showCmd2(SwitchConsole Sconsole){
     Sconsole.append("Exex Commands:\n"+
     "config           \t\tEnter configuration mode\n"+
     "copy             \t\tCopy configuration or image data\n"+
     "debug            \t\tDebugging functions\n"+
     "disable          \t\tTurn off privileged commands\n"+
     "erase            \t\tErase flash or configuration memory\n"+
     "ping             \t\tSend echo messages\n"+
     "show             \t\tShow running system information\n"+
     "terminal         \t\tShow running system information\n"+
     "traceroute       \t\tTrace route to destination\n"+
     "undebug          \t\tDisable debugging functions\n\n");
   }
   public void showCmd3(SwitchConsole Sconsole){
     Sconsole.append("Configure commands:\n"+
     "access-list      \t\tAdd an access list entry\n"+
     "enable           \t\tModify enable password parameter\n"+
     "exit             \t\tExit from configure mode\n"+
     "hostname         \t\tSet system's network name\n"+
     "interface        \t\tSelect an interface to configure\n"+
     "ip               \t\tGlobal IP configuration subcommands\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "router           \t\tSet protocol\n\n");
   }
   public void showCmd4(SwitchConsole Sconsole){
     Sconsole.append("Interface configuration commands:\n"+
     "bandwidth        \t\tSet bandwidth informational parameter\n"+
     "cdp              \t\tCDP interface subcommands\n"+
     "clock            \t\tConfigure serial interface clock\n"+
     "end              \t\tExit from configure mode\n"+
     "exit             \t\tExit from interface configuration mode\n"+
     "interface        \t\tSelect an interface to configure\n"+
     "ip               \t\tInterface Internet Protocol config commands\n"+
     "no               \t\tNegate a command or set its defaults\n"+
     "ring-speed       \t\tSet ring speed of token ring\n"+
     "shutdown         \t\tShutdown the selected interface\n\n");
   }
   public void showCmd5(SwitchConsole Sconsole){
     Sconsole.append("sw configuration commands:\n"+
     "network          \t\tEnable routing on an IP network\n"+
     "passive-interface\tSuppress routing updates on an interface\n"+
     "no               \t\tNegate a command or set its defaults\n\n");
    }
   public void showCmd6(SwitchConsole Sconsole){
     Sconsole.append("Line configuration commands:\n"+
     "login            \t\tEnable password checking\n"+
     "password         \t\tSet a password\n"+
     "no               \t\tNegate a command or set its defaults\n");
   }
   //end Help

   //Show Method -+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

   public void showCDP(Switch s,SwitchConsole sconsole){
/*       String str =  "Global CDP information:\n";
              str += "\tSending CDP packets every " + s.getCdp().getTimer() + " seconds\n";
              str += "\tSending a holdtime value of "+ s.getCdp().getHoldTime() +" seconds\n";
       sconsole.append(str);*/
   }//end showCDP








}//end class fullswcmd
