package netsimulator;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
//import javax.swing.*;
import java.lang.*;
import java.util.*;

public class SwitchImg {

  private int simgID = 0;

  private int xpos,ypos;
  private int width,height;
  private String color;
  private Image img;
  private int Type;
//  private Vector slink = new Vector();
//  static Vector switchImg = new Vector();

  public SwitchImg() {
    width = 58;
    height = 36;
    xpos = 120;
    ypos = 115;
    color="none";
//    xpos = 60*(Panel2.vImgSwitch.size()+1);
//    ypos = 30*(Panel2.vImgSwitch.size()+1);
  }//end Constructor SwitchImg

  public SwitchImg(int type) {
    switch (type) {
        case 2950 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("switch01.gif"));color="blue";break;
        case 0000 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("switch02.gif"));color="gray";break;
//        case 3 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("greenSwitch.gif"));color="green";break;
//        case 4 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("pinkSwitch.gif"));color="pink";break;
//        case 5 : img = Toolkit.getDefaultToolkit().getImage(SwitchImg.class.getResource("purpleSwitch.gif"));color="purple";break;
        default : color="none";break;
    }

    width = 58;
    height = 36;
    xpos = 120;
    ypos = 115;
//    xpos = 60*(Panel2.vImgSwitch.size()+1);
//    ypos = 30*(Panel2.vImgSwitch.size()+1);
  }

  public String getColors(){
    return color;
  }
  public int getXPos(){
    return xpos;
  }
  public int getType(){
    return Type;
  }
  public int getYPos(){
    return ypos;
  }
  public int getWide(){
    return width;
  }
  public int getHigh(){
    return height;
  }
  public Image getImage(){
    return img;
  }
  public void setXPos(int n){
    xpos = n;
  }
  public void setYPos(int n){
    ypos = n;
  }
  public void setWide(int n){
    width = n;
  }
  public void setHigh(int n){
    height = n;
  }

  //------ get&set ID
  public String getSwitchImgUniName(){
    return "S"+simgID;
  }//end getSwitchImgUniName

  public int getIdSwitchImg(){
    return simgID;
  }
  public void setIdSwitchImg(int id){
    simgID = id;
}

}
