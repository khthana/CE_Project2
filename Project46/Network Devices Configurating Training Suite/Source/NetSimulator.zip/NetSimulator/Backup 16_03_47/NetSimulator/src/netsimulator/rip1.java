package netsimulator;

import java.io.*;
import java.lang.*;
import java.util.*;

 public class rip1 extends Thread {
  static private long timesleep;
  static private String ifile;
  static private String Fname1,Fname2,Fname3,Fname4;
  static private File my_table;
  static private Vector vtmp1 = new Vector();
  static private Vector vtmp2 = new Vector();
  static private Vector vsubs = new Vector();
  static private int nfriend;
  static private String newstring;
//  static private boolean r;

 public rip1 (String I,int t) {
    ifile = I+".rip1";
    timesleep = t;
    String xs = "127.0.0.1 1";     // It's IP of Network Destination and metric
    File fi = new File(ifile);
    ifile=fi.toString();
try{
      FileWriter fileWriter = new FileWriter(fi);//fi is a file name.
      BufferedWriter bfw = new BufferedWriter(fileWriter);
      PrintWriter pw =  new PrintWriter(bfw);
      pw.println(xs);//xs is a string will to write.
      pw.close();
    }catch(IOException io){
     System.out.println("ERROR Can't write File");
    }
//    run();
 }
 public void  LearnDevice(String dn1){
   Fname1 = dn1+".rip1";
   nfriend = 2;
//   run();
 }
 public void LearnDevice(String dn1,String dn2){
   Fname1 = dn1+".rip1";
   Fname2 = dn2+".rip1";
   nfriend = 3;
//   run();
 }
 public void LearnDevice(String dn1,String dn2,String dn3){
   Fname1 = dn1+".rip1";
   Fname2 = dn2+".rip1";
   Fname3 = dn3+".rip1";
   nfriend = 4;
//   run();
 }
 public void LearnDevice(String dn1,String dn2,String dn3,String dn4){
   Fname1 = dn1+".rip1";
   Fname2 = dn2+".rip1";
   Fname3 = dn3+".rip1";
   Fname4 = dn4+".rip1";
   nfriend = 5;
//   run();
 }

public void run(){
try{
     Thread.sleep(timesleep);
     if (nfriend == 2) {
       System.out.println("I have one friend : " + ifile + " , " + Fname1);
       if (alive() == "yes") {
         receive(2);
//      System.out.println(alive());
       }
     }
     else if (nfriend == 3) {
       System.out.println("I have two friend");
       if (alive() == "yes") {
         receive(3);
       }
     }
     else if (nfriend == 4) {
       System.out.println("I have three friend");
       if (alive() == "yes") {
         receive(4);
       }
     }
     else if (nfriend == 5) {
       if (alive() == "yes") {
         receive(5);
       }
     }
   }catch(Exception e){

 }
  }//end of run

 public void receive(int n){

   switch(n){
     case 2 :
                    try{
                      File fin1 = new File(ifile);
                      File fin2 = new File(Fname1);

                      FileReader rfin1 = new FileReader(fin1.getName());
                      BufferedReader bfin1 = new BufferedReader(rfin1);

                      FileReader rfin2 = new FileReader(fin2);
                      BufferedReader bfin2 = new BufferedReader(rfin2);

                      String t1;
                      while((t1 = bfin1.readLine()) != null){
                        vtmp1.addElement(t1);
//                        System.out.println(t1+"Yes!");
                        System.out.println(vtmp1);
                      }
                      while((t1 = bfin2.readLine()) != null){
                        vtmp2.addElement(t1);
                        System.out.println(vtmp2);
                      }
                      rfin1.close();
                      rfin2.close();
////////////////////// compare data in table /////////////////////////
                      int lenvt2 = vtmp2.size();
                      int lenvt1 = vtmp1.size();
                      String tmpE1,tmpE2;
//                      byte ipme[] = new  byte[80];
                      System.out.println(lenvt2);
                      System.out.println(lenvt1);

                      for(int i=0;i<lenvt2;i++){
                        tmpE2 = vtmp2.get(i).toString();
                        System.out.println("tmpE2 : "+tmpE2);
                        for(int j=0;j<lenvt1;j++){
                          tmpE1 = vtmp1.get(j).toString();
                          System.out.println("tmpE1 : "+tmpE1);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                          String n0 = tmpE2.substring(4,tmpE2.length());
                          System.out.println(tmpE2.substring(0,3));
//////////////////////////////////   if it have in neighbor but not not have own   '///////////////////////////////////////////
                          if(!tmpE1.equals(tmpE2) &&  (tmpE2.charAt(0)!='0') && (tmpE2.substring(0,3).compareTo("127")!=0)){
                           System.out.println("in tmpE2, is data not have in my table : "+tmpE2);
                           StringTokenizer stz = new StringTokenizer(tmpE2);

                           vsubs.removeAllElements();

                           while(stz.hasMoreTokens()){
                             vsubs.addElement(stz.nextToken());
                           }
                             vsubs.trimToSize();
                           System.out.println("vsubs is "+vsubs);
                           String ss0 = new String(vsubs.get(0).toString());//////////////////get(vsubs.size
                           String ss = new String(vsubs.get(1).toString());
//                           vsubs.removeElementAt(1);
                           System.out.println("word is metric type String "+ss);
                            String newss = pushmetric.pushme(ss);
                           vsubs.removeAllElements();
                           vsubs.addElement(ss0.concat(" "+newss));
                           System.out.println("before get to tmpE2 "+vsubs);
                           for(int k=0;k<vsubs.size();k++){
                             tmpE2 = vsubs.get(k).toString();
                           }
/////////////////////////////////////////
//                           tmpE2=vsubs.get(0)+" "+vsubs.get(1).toString();
                            vtmp1.addElement(tmpE2);//add it to me.
//                            lenvt1 = vtmp1.size();
//                            System.out.println("size of vtmp1 "+lenvt1);
                            System.out.println("vtmp1 : "+vtmp1);
//---------------------------------------------------------------------------------------
                            System.out.println(ifile);
                            FileWriter fileWriter = new FileWriter(ifile);
                          BufferedWriter bfw = new BufferedWriter(fileWriter);
                            PrintWriter pw = new PrintWriter(bfw);
                          for(int ni=0;ni<vtmp1.size();ni++){
                            newstring = vtmp1.get(ni).toString();
                            pw.println(newstring);
                          }
//                      System.out.println(pw.toString());
                          pw.close();

                          }//end  if(tmpE1 != tmpE2)
/////////////////////////////////////////////////// push metric///////////////////////////////////////  if same IP, not same metric

//                          else if((tmpE1.equals(tmpE2) && (tmpE2.charAt(0)!='0') && (tmpE2.substring(4,tmpE2.length()).compareTo("127") != 0))) {
                          else if(((tmpE2.charAt(0)!='0') && (tmpE2.substring(0,3).compareTo("127") != 0))) {
                            System.out.println("tmpE1 is :) "+tmpE1+"tmpE2 is :) "+tmpE2);

                            Vector vsubs2 = new Vector();
                            StringTokenizer stz2 = new StringTokenizer(tmpE2);          //neighbor        ??????????
                            StringTokenizer stz1 = new StringTokenizer(tmpE1);          //me                   ??????????

                            System.out.println("stz2 is "+stz2.toString()+"stz1 is "+stz1.toString());

                            while(stz2.hasMoreTokens()){
                              vsubs2.addElement(stz2.nextToken().trim());
                              System.out.println("vsubs2 is : "+vsubs2.toString());
                            }
                            while(stz1.hasMoreTokens()){
                              vsubs.addElement(stz1.nextToken().trim());
                              System.out.println("vsubs is : "+vsubs.toString());
                            }
                            String ss1 = new String(vsubs.get(vsubs.size()).toString());
                            String ss2 = new String(vsubs2.get(1).toString());
                            ss2 = pushmetric.pushme(ss2);
                            System.out.println("ss1 is:"+ss1+" ss2 is:"+ss2);

                            int ssx = ss1.compareTo(ss2);
                            System.out.println("output "+ssx);
//                            String sx = new String();

                            if(ssx > 0 ){
                              System.out.println("ssx > 0 This's vtmp1 old."+vtmp1);
//                              tmpE2 = vsubs2.get(0).toString().concat(" "+ss2);
//                              vtmp1.removeAllElements();
//                              vtmp1.addElement(tmpE2);
                              vtmp1.setElementAt(ss2,vtmp1.size());
//--------------------------------------------------------------------------------
                              System.out.println(ifile);
                              FileWriter fileWriter = new FileWriter(ifile);
                            BufferedWriter bfw = new BufferedWriter(fileWriter);
                              PrintWriter pw = new PrintWriter(bfw);
                            for(int ni=0;ni<vtmp1.size();ni++){
                              newstring = vtmp1.get(ni).toString();
                              pw.println(newstring);
                            }/////// for(int ni=0;ni<vtmp1.size();ni++)
//                      System.out.println(pw.toString());
                            pw.close();

                            }else if(ssx < 0){
/*                              System.out.println("ssx < 0 This's vtmp1 old "+vtmp1);
//                              tmpE1 = vsubs.get(0).toString().concat(" "+ss2);
//                              vtmp1.removeAllElements();
//                              vtmp1.addElement(tmpE1);
//                              vtmp1.setElementAt(ss2,vtmp1.size());
//--------------------------------------------------------------------------------
                                          System.out.println(ifile);
                                          FileWriter fileWriter = new FileWriter(ifile);
                                        BufferedWriter bfw = new BufferedWriter(fileWriter);
                                          PrintWriter pw = new PrintWriter(bfw);
                                        for(int ni=0;ni<vtmp1.size();ni++){
                                          newstring = vtmp1.get(ni).toString();
                                          pw.println(newstring);
                                        }/////// for(int ni=0;ni<vtmp1.size();ni++)
//                      System.out.println(pw.toString());
                                        pw.close();
*/

                            }else if(ssx == 0){
/*                              System.out.println("ssx = 0 This's vtmp1 old "+vtmp1);
//                              tmpE1 = vsubs.get(0).toString().concat(" "+ss2);
//                              vtmp1.removeAllElements();
//                              vtmp1.addElement(tmpE1);
//--------------------------------------------------------------------------------
                                          System.out.println(ifile);
                                          FileWriter fileWriter = new FileWriter(ifile);
                                        BufferedWriter bfw = new BufferedWriter(fileWriter);
                                          PrintWriter pw = new PrintWriter(bfw);
                                        for(int ni=0;ni<vtmp1.size();ni++){
                                          newstring = vtmp1.get(ni).toString();
                                          pw.println(newstring);
                                        }/////// for(int ni=0;ni<vtmp1.size();ni++)
//                      System.out.println(pw.toString());
                                        pw.close();
*/
                            }
/*                            if(ssx ==1){
                              sx = pushmetric.pushme(ss1);
                              vsubs.addElement(tmpE2);

//                              tmpE2=vsubs.get(0)+" "+vsubs.get(1).toString();
                              vtmp1.removeAllElements();
                              vtmp1.addElement(tmpE2);

                            }else if(ssx < 0){
                              vtmp1.removeAllElements();
                              vtmp1.addElement(tmpE1);
                              System.out.println("metric me less than neigthbor "+vtmp1);

                            }else if(ssx==0){
                              vtmp1.removeAllElements();
                              vtmp1.addElement(tmpE1);
                              System.out.println("metric me equals neigthbor"+vtmp1);
                              System.out.println("Return 0");
                              System.out.println(ifile);
                              FileWriter fileWriter = new FileWriter(ifile);
                              BufferedWriter bfw = new BufferedWriter(fileWriter);
                              PrintWriter pw = new PrintWriter(bfw);
                              for(int ni=0;ni<vtmp1.size();ni++){
                                newstring = vtmp1.get(ni).toString();
                                pw.println(newstring);
                              }
//                      System.out.println(pw.toString());
                              pw.close();

                            }
*/
                            System.out.println("vtmp1 : "+vtmp1);
                          }
//                          vtmp1.addElement(tmpE1);
                        }//end for(int j=0;j<lenvt1;j++){
                      }//end  for(int i=0;i<lenvt2;i++){
/*                        System.out.println(ifile);
                        FileWriter fileWriter = new FileWriter(ifile);
                      BufferedWriter bfw = new BufferedWriter(fileWriter);
                        PrintWriter pw = new PrintWriter(bfw);
                      for(int ni=0;ni<vtmp1.size();ni++){
                        newstring = vtmp1.get(ni).toString();
                        pw.println(newstring);
                      }
//                      System.out.println(pw.toString());
                      pw.close();
*/
                    }catch(Exception e) {
                      System.out.println("Can not Add Element OR Can not Open File");
                    }break;
    case 3 :
                    try{

                    }catch( Exception e){

                    }break;
    case 4 :

    default : System.out.println("Can't work");
   }

 }
 public String alive(){
   String al="no";
      try{
     switch (this.nfriend) {
       case 2:
         File If = new  File(this.ifile);
         File f1 = new File(this.Fname1);
         if ( (If.canRead()) && (f1.canRead()) == true) {
           al = "yes";
         }else {
           System.out.println( "You don't have your file or You don't have neighbor1");
           System.out.println("I file can read : "+If.canRead());
           System.out.println("Nieghbor file can read : "+f1.canRead());
         }
         break;
/*       case 3:
         File If = new  File(this.ifile);
         File f1 = new File(this.Fname1);
          File f2 = new File(this.Fname2);

         if ( (If.canRead()) && (f1.canRead()) && (f2.canRead()) == true) {
           al = "yes";
         }else System.out.println("You don't have your file or You don't have neighbor1or neighbor2");
         break;
       case 4:
         if ( (If.canRead()) && (f1.canRead()) && (f2.canRead() && (f3.canRead())) == true) {
           al = "yes";
         }else System.out.println("You don't have your file or You don't have neighbor1or neighbor2 or neighbor3");
         break;
       case 5:
         if ( (If.canRead()) && (f1.canRead()) &&
             (f2.canRead() && (f3.canRead()) && (f4.canRead())) == true) {
           al = "yes";
         }else System.out.println("You don't have your file or You don't have neighbor1or neighbor2 or neighbor3 or neighbor4");
        break;
*/
       default:
         System.out.println("Can not read some devices.");
     }
//     return al;
   }catch(Exception e){
     System.out.println("banana you !");
   }
     return al;
 }

public static void deleteTable(String fn){

 }

  public static void main(String[] args)  {
/*    File f = new File("test");
    System.out.println("File path: "+f.getPath());
    System.out.println("File Parent: "+f.getParent());
*/
//    rip1 Device1 = new rip1("Device1",1000);
    rip1 Device2 = new rip1("Device2",1000);

//    Device1.LearnDevice("Device2");
//    Device1.start();
    Device2.LearnDevice("Device1");
//    Device2.start();
//    Device2.sleep(timesleep);
    Device2.run();

  }


}