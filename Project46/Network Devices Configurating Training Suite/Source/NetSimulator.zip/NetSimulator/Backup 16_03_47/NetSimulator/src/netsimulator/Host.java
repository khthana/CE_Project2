package netsimulator;

import java.util.*;

class Host {
  private int ID; //Host ID (fix)

  private Port hostPort;
  private HostImg himg;
  private Vector ethernetName;

  protected String hostIPAddress;
  protected String hostMacAddress;

  private String hostConnectionWith = "";

//////////////////////////////////////////////
  public Host(){
    ID = 0;
    hostMacAddress = IntEthernet.genMacAddress();
  }//end constructor

  public Host(int id){
    ID = chkAndsetHostID(id);
    createPort(0,1,0);
    hostMacAddress = IntEthernet.genMacAddress();
  }//end Host(id)

  //----------- Host Method ------------------------------------
  public void createPort(int serial,int ethernet,int tokenring){
    hostPort = new Port(serial,ethernet,tokenring);
  }

  public String getHostConnectionWith(){
    IntEthernet int_Ethernet = (IntEthernet)hostPort.getEport().lastElement();
    hostConnectionWith = int_Ethernet.getConnectionWith();
    return hostConnectionWith;
  }

  public String getHostIPAddress(){
    return hostIPAddress;
  }
  public void setHostIPAddress(String ip){
    hostIPAddress = ip;
  }

  public String getHostMacAddress(){
    return hostMacAddress;
  }//end get host macaddress

  public String getHostUniName(){
    return "H"+ID;
  }//end getHostUniName

  public int getHostID(){
    return ID;
  }//end getHostID

  public Vector getEport(){
    return hostPort.getEport();
  }//end getEport

  public Vector getEname(){
    return ethernetName;
  }//end get Ethernet name

  public HostImg getHostImg(){
    return himg;
  }//end getHostImg

  public int chkAndsetHostID(int id){
    int hostNumber = 0;
    String hostName = "H"+hostNumber;

    boolean found = false;
    boolean dup = true;
    boolean flag = true; //for optimize

      while(dup) {
        ++hostNumber;
        flag = true;
        found = false;
        for (int i=0; (i < Frame1.vHost.size())&&flag ; i++) {
          int alreadyName = ((Host)Frame1.vHost.elementAt(i)).getHostID();
          if (alreadyName == hostNumber){
            System.out.println(hostNumber);
            found = true;
            flag = false;
          }//end if
        }//end for
        dup = found;
      }//end while(dup)

      System.out.println("Host ID = "+hostNumber);
      return hostNumber;
  }//end chkAndsetHost(id)

//--------------- HOST OPERATION ---------------------------------

}//end class host