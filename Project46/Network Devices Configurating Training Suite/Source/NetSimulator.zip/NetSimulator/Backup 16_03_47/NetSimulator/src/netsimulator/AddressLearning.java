package netsimulator;

import java.util.*;

class AddressLearning extends Thread{

  public void AddressLearning(Switch sw){

  }

}//end class