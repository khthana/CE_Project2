package netsimulator;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.lang.*;
import java.util.*;

class HostImg {
     private int himgID = 0;

     private int xpos,ypos;
     private int width,height;
     private String color;
     private int Type;

     final Image img = Toolkit.getDefaultToolkit().getImage(HostImg.class.getResource("host.gif"));

     public HostImg(){
       width = 58;
       height = 36;
       xpos = 120;
       ypos = 115;
       color="none";

     }//end constructor HostImg

     public String getColors(){
       return color;
     }
     public int getXPos(){
       return xpos;
     }
     public int getType(){
       return Type;
     }
     public int getYPos(){
       return ypos;
     }
     public int getWide(){
       return width;
     }
     public int getHigh(){
       return height;
     }
     public Image getImage(){
       return img;
     }
     public void setXPos(int n){
       xpos = n;
     }
     public void setYPos(int n){
       ypos = n;
     }
     public void setWide(int n){
       width = n;
     }
     public void setHigh(int n){
       height = n;
     }

     //------ get&set ID
     public String getHostImgUniName(){
       return "H"+himgID;
     }//end getHostImgUniName

     public int getIdHostImg(){
       return himgID;
     }
     public void setIdHostImg(int id){
       himgID = id;
     }

}//end HostImg