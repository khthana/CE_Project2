package netsimulator;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Port {

  static Vector vMacAddress = new Vector();
  static Vector vIPAddress = new Vector();

  private Vector vPortS = new Vector();
  private Vector vPortE = new Vector();
  private Vector vPortT = new Vector();

  private Vector vNameS = new Vector();
  private Vector vNameE = new Vector();
  private Vector vNameT = new Vector();

  public Port(){

  }//end Constructor

  public Port(int serialInt, int ethernetInt, int tokenringInt){

    for(int countS = 0; ((countS < serialInt)&&(serialInt > 0)); countS++) {
      IntSerial sTemp = new IntSerial();//new S_port
      sTemp.setSname("S0/"+countS);
      System.out.println("Serial port"+sTemp.getSname());
      vPortS.add(countS,sTemp);
      vNameS.add(countS,sTemp.getSname());
    }//end make serialPort

    for(int countE = 0; ((countE < ethernetInt)&&(ethernetInt > 0)); countE++) {
      IntEthernet eTemp = new IntEthernet();//new & gen MAC
      eTemp.setEname("Fe0/"+countE);
      System.out.println("MacAddress port"+eTemp.getEname()+" = "+eTemp.getMacAddress());
      vPortE.add(countE,eTemp);
      vNameE.add(countE,eTemp.getEname());

    }//end make ethernetPort

      System.out.println("vMacAddress.size = "+this.vMacAddress.size());
      System.out.println("vPortE.size = "+vPortE.size());
      System.out.println("vPortS.size = "+vPortS.size());
      System.out.println("vPortS.size = "+vNameS.size());

  }//end constructor(s,e,t)

//------------------ Method ------------------------------///////////////
  public Vector getSport(){
    return vPortS;
  }//end get Serial port
  public Vector getEport(){
    return vPortE;
  }//end get Ethernet port
  public Vector getTport(){
    return vPortT;
  }//end get Tokenring port

  public Vector getSname(){
    return vNameS;
  }//end get Serial port
  public Vector getEname(){
    return vNameE;
  }//end get Ehternet port
  public Vector getTname(){
    return vNameT;
  }//end get Tokenring port


/*//------------------ Main for test -------------------------------////////////////
  public static void main(String argu[]){
    Port p1 = new Port(5,4,0);
    Port p2 = new Port(3,6,0);

/*    for (int count = 0 ; count < p1.vPortE.size(); count++){
      IntEthernet inte = (IntEthernet) p1.vPortE.elementAt(count);
      System.out.println("Switch1 MacAddress["+count+"] = " + inte.getMacAddress());
    }

    for (int count = 0 ; count < p2.vPortE.size(); count++){
      IntEthernet inte = (IntEthernet) p2.vPortE.elementAt(count);
      System.out.println("Switch2 MacAddress["+count+"] = " + inte.getMacAddress());
    }

//    System.out.println((IntEthernet)p.vPortE.elementAt(1));
  }*/

}