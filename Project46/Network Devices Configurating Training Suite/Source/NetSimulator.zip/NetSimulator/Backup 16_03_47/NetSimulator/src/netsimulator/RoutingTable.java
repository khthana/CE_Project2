package netsimulator;
import java.util.StringTokenizer;
import java.lang.*;

public class RoutingTable implements java.io.Serializable{// extends Thread{
  private String ipDestination;
  private String subnet;
//  private Interface intf;
  private IntEthernet inte;
  private IntSerial ints;
  private String gateway;
//  static String output="";
  static String outpute="";
  static String outputs="";
  private int matric;//hop count
  private  int matricweight;
  private char routeType;
  private int bandwidth = 1000,load = 100,delay = 100,reliability = 250,mtu = 1500;
  private String Asnumber;
    //---------------Check is ip----------------------//
    // true if ip correct
    //argument must be pass by value
    static public boolean isIp(String s){
      boolean f = true;
      StringTokenizer st = new StringTokenizer(s,".");
      for(int i=0; i<4; i++){
	if (st.hasMoreTokens()){
	  String tmp = st.nextToken();
	  try{
	    int ip = Integer.parseInt(tmp);
	    if ((ip < 0) || (ip > 255)){
	      f = false;
	    }
	  }
	  catch (NumberFormatException exp){
	    f = false;
	  }
	}
	else{
	  f = false;
	}
      }
      return f;
    }

  //----------------------Set Interface------------------//
  public void setIntEthernet(IntEthernet e){
    inte = e;
  }
  public IntEthernet getIntEthernet(){
    return inte;
  }
  static String getOutputEthernet()
  {
    return outpute;
  }
//***********
  public void setIntSerial(IntSerial s){
  ints = s;
}
  public IntSerial getIntSerial(){
  return ints;
}
static String getOutputSerial()
{
  return outputs;
}

  //---------------------Set Destination---------------//
  public void setIpDestination(String s){
    if (this.isIp(s)){
      ipDestination = s;
    }
    else {
//      System.out.println("% invalid input detected at '^' marker. \n");
    }
  }
  public String getIpDestination(){
    return ipDestination;
  }

  //-------------------Set Subnet-------------------//
  public void setSubnet(String s){
    if (this.isIp(s)){
      subnet = s;
    }
    else {
//      System.out.println("% invalid input detected at '^' marker. \n");
    }
  }
  public String getSubnet(){
    return subnet;
  }
  //------------------Set Gateway-------------------//
  public void setGateway(String s){
    if (this.isIp(s)){
      gateway = s;
    }
    else {
//      System.out.println("% invalid input detected at '^' marker. \n");
    }
  }
  public String getGateway(){
    return gateway;
  }
  //-------------------Set Matrice--------------------//
  public void setMatrice(int i){
    matric = i;
  }
  public int getMatrice(){
    return matric;
  }
//-------------------Set Matrice weight-----------//
  public void setMatriceWeight(int tos,int k1,int k2,int k3,int k4,int k5){
    matricweight = ((k1 * bandwidth) + (k2 * bandwidth) / (256 - load) + k3 + delay) * (k5 / (reliability + k4));
  }
  public int getMatriceWeight(){
    return matricweight;
  }
//--------------------Set default-matric (Igrp)-------//
  public void setDefaultMatric(int bandwidth,int delay,int load,int reliability,int mtu){
    this.bandwidth = bandwidth;
    this.delay = delay;
    this.load = load;
    this.reliability = reliability;
    this.mtu = mtu;
  }
//---------------------- AS number-----------------------
  public void setAsnumber(String asn){
    this.Asnumber = asn;
  }
  public String getAsnumber(){
    return this.Asnumber;
  }

/*
  //------------------Set Flag-----------------------//
  public void setFlag(String s){
    flag = s;
  }
  public String getFlag(){
    return flag;
  }
*/
  //----------------Set Route Type-----------------//
  public void setRouteType(char c){
    routeType = c;
  }
  public char getRouteType(){
    return routeType;
  }
  //-------------Static Route---------------//
  public void ipRoute(Router r,String des,String subnet,String gw){
    boolean found = false;
    int index=0;
//    Interface intf=null;
    IntEthernet inte=null;
    for(int i=0;i < r.getVrt().size(); i++){
      RoutingTable rt= (RoutingTable)r.getVrt().elementAt(i);
      if (rt.getIpDestination().equalsIgnoreCase(des)){
	found = true;
	index = i;
      }
    }
    boolean con = false;
    //find Interface of ip destination
    for (int a=0; a < Frame1.vRouter.size(); a++){
      Router r1 = (Router)Frame1.vRouter.elementAt(a);
      for (int b=0; b < r1.getEport().size(); b++){
	IntEthernet int_e1 = (IntEthernet)r1.getEport().elementAt(b);
//        System.out.println(i1.getIpAddress()+"&"+gw);
	if (int_e1.getIPAddress().equalsIgnoreCase(gw)){
	  inte = int_e1;
//	  con = true;
	}
      }//end for Eth
      for (int b=0; b < r1.getSport().size(); b++){
	IntSerial int_s1 = (IntSerial)r1.getSport().elementAt(b);
//        System.out.println(i1.getIpAddress()+"&"+gw);
	if (int_s1.getIPAddress().equalsIgnoreCase(gw)){
	  ints = int_s1;
	  con = true;
	}
      }//end for Seri
//***
    }//end for
    if (con){
      r.setFlag('s');
      this.setIpDestination(des);
      this.setGateway(gw);
      this.setSubnet(subnet);
      this.setRouteType('s');
//      this.setInterface(intf);
      this.setIntEthernet(inte);
      this.setIntSerial(ints);
      this.setMatrice(1);
      if (found){
	r.getVrt().removeElementAt(index);
      }//end if
      r.getVrt().addElement(this);
    }//end if
    else {
//      System.out.println("Wrong Gateway");
    }//end else
  }
//****

  public void setIpRoute(Router r,String des,String subnet,String gw,String intip,String nameint,String netAdd,String status,String intsubnet,String inttype){
    r.setFlag('s');
/*
    Interface intface = new Interface();
    intface.setIpAddress(intip);
    intface.setNameInt(nameint);
    intface.setNetAddress(netAdd);
    intface.setSubnet(intsubnet);
    intface.setStatus(status);
    intface.setType(inttype);

    this.setIpDestination(des);
    this.setGateway(gw);
    this.setSubnet(subnet);
    this.setRouteType('s');
    this.setInterface(intface);
    this.setMatrice(1);
    r.getVrt().addElement(this);
*/
    if(nameint.equalsIgnoreCase("e")||(nameint.equalsIgnoreCase("ethernet"))){
    IntEthernet intE = new IntEthernet();
    intE.setIPAddress(intip);
    intE.setEname(nameint);
    intE.setNetworkAddress(netAdd);
    intE.setSubnet(intsubnet);
//    intE.setMyStatus(true);
    intE.setMyStatusString(status);
    intE.setType(inttype);
    this.setIpDestination(des);
    this.setGateway(gw);
    this.setSubnet(subnet);
    this.setIntEthernet(intE);
    this.setMatrice(1);
    r.getVrt().addElement(this);
    }else if(nameint.equalsIgnoreCase("s")||(nameint.equalsIgnoreCase("serial"))){
	IntSerial intS = new IntSerial();
	intS.setIPAddress(intip);
	intS.setSname(nameint);
	intS.setNetworkAddress(netAdd);
	intS.setSubnet(intsubnet);
//    intS.setMyStatus(true);
	intS.setMyStatusString(status);
	intS.setType(inttype);
	this.setIpDestination(des);
	this.setGateway(gw);
	this.setSubnet(subnet);
	this.setIntSerial(intS);
	this.setMatrice(1);
	r.getVrt().addElement(this);
    }

  }
  //--------------Routing Table with direct connected----------//
  public void ipRoute(Router r,String ip,String subnet,int hop){
//    RoutingTable rt = new RoutingTable();
    int i=0;
//    Interface intf = (Interface)r.getVInt().elementAt(i);
    IntEthernet inte = (IntEthernet)r.getEport().elementAt(i);
    while (!inte.getIPAddress().equalsIgnoreCase(ip)){
      i++;
      if(i < r.getEport().size()){
	inte = (IntEthernet)r.getEport().elementAt(i);
      }
    }//end while
    int j=0;
    IntSerial ints = (IntSerial)r.getSport().elementAt(j);
    while(!ints.getIPAddress().equalsIgnoreCase(ip)){
      j++;
      if(j < r.getSport().size()){
	ints = (IntSerial)r.getSport().elementAt(j);
      }
    }

    inte = (IntEthernet)r.getEport().elementAt(i);
    ints = (IntSerial)r.getSport().elementAt(j);
    this.setIpDestination(inte.getNetworkAddress());
    this.setIpDestination(ints.getNetworkAddress());
    this.setGateway("0.0.0.0");
    this.setMatrice(hop);
    this.setSubnet(subnet);
    this.setIntEthernet(inte);
    this.setIntSerial(ints);
    r.getVrt().addElement(this);
  }
  //--------Add Routing Table From RIP ---------//
  public void addRouting(Router r,IntEthernet iadj){
    RoutingTable rt = new RoutingTable();
    rt.setGateway(iadj.getIPAddress());
    rt.setIntEthernet(iadj);
    rt.setIpDestination(this.getIpDestination());
    if (this.getMatrice() < 15){
      rt.setMatrice(this.getMatrice()+1);
    }
    else{
      rt.setMatrice(16);
    }
    rt.setRouteType('r');
    rt.setSubnet(this.getSubnet());
    r.getVrt().addElement(rt);
  }
//****
  public void addRouting(Router r,IntSerial iadj){
    RoutingTable rt = new RoutingTable();
    rt.setGateway(iadj.getIPAddress());
    rt.setIntSerial(iadj);
    rt.setIpDestination(this.getIpDestination());
    if (this.getMatrice() < 15){
      rt.setMatrice(this.getMatrice()+1);
    }
    else{
      rt.setMatrice(16);
    }
    rt.setRouteType('r');
    rt.setSubnet(this.getSubnet());
    r.getVrt().addElement(rt);
  }

  //constructor
  public RoutingTable() {
    ipDestination = "";
    gateway = "";
    subnet = "";
    routeType = 'c';
    matric = 16;
  }
  //-------Delete Routing Table--------------------//
  public void noIpRoute(Router r,String des,String subnet,String gw){
    int i = 0;
    RoutingTable rt = null;
    if (r.getVrt().size() > 0){
      rt = (RoutingTable)r.getVrt().elementAt(i);
    }//end if
    boolean found = rt.getIpDestination().equalsIgnoreCase(des) && rt.getSubnet().equalsIgnoreCase(subnet) && rt.getGateway().equalsIgnoreCase(gw);
    while((!found)&&(i < r.getVrt().size())){
      rt = (RoutingTable)r.getVrt().elementAt(i);
      found = rt.getIpDestination().equalsIgnoreCase(des) && rt.getSubnet().equalsIgnoreCase(subnet) && rt.getGateway().equalsIgnoreCase(gw);
      i++;
    }//end while
    if (found){
      r.getVrt().removeElementAt(i-1);
    }//end if
    else {
      outpute += "Wrong Delete\n";
      outputs += "Wrong Delete\n";
    }
  }
}
