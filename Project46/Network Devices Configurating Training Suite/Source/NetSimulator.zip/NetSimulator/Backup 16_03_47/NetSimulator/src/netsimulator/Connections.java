package netsimulator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.JOptionPane;
import java.util.*;

public class Connections extends JDialog {

  static Vector vConnectionBegin = new Vector();
  static Vector vConnectionEnd = new Vector();

  private Router RT;
  private Switch SW;
  private Host   HO;

  private IntSerial beginS = null, endS = null;    //for flag paint()
  private IntEthernet beginE = null, endE = null;

  private RouterImg rimgS = null,rimgE = null;     //for flag paint()
  private SwitchImg simgS = null,simgE = null;
  private HostImg   himgS = null,himgE = null;

  private String networkAddress = "";
  private String startPortName = "";
  private String endPortName = "";

  private EtchedBorder etchedBorder  = new EtchedBorder();

  private JPanel jPanel = new JPanel();

  private JLabel jLabelDeviceName = new JLabel();
  private JLabel jLabelPort1 = new JLabel();
  private JLabel jLabelPort2 = new JLabel();

  private JLabel jLabelDevice1 = new JLabel();
  private JLabel jLabelDevice2 = new JLabel();

  private String labelDev = "";
  private String devName = "";

  private String devType = "";
  private String type[] = {"Router","Switch"};
  private Vector device1 = new Vector();

  private JComboBox jComboBoxPort = new JComboBox();
  private JComboBox jComboBoxPort1 = new JComboBox();

  private JComboBox jComboBoxType1 = new JComboBox();
  private JComboBox jComboBoxDevice1 = new JComboBox();

  private JButton jButtonConnect = new JButton();
  private JButton jButtonCancle = new JButton();

  private JLabel jLabelType1 = new JLabel();
  private JLabel jLabelNetAddress = new JLabel();

  private JTextArea jTextAreaNetAddress = new JTextArea();

//  private int routerSID = 0, routerEID = 0; //for edit port
//  private int switchSID = 0, switchEID = 0;
//  private int hostSID = 0, hostEID = 0;

  //Class Constructor

  public Connections(Frame frame, String title, boolean modal,Router rt,Switch sw,Host ho) {
    super(frame, title, modal);
    try {
      RT = rt;
      SW = sw;
      HO = ho;
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }//end Constructor(argu)*/

  public Connections(Router rt) {
    this(null, "", true, rt, null, null);
  }//end Constructor(Router)

  public Connections(Switch sw) {
    this(null, "", true, null, sw, null);
  }//end Constructor(Switch)

  public Connections(Host hs) {
    this(null, "", true, null, null, hs);
  }//end Constructor(Host)


  private void jbInit() throws Exception {

//-------------- Init ------------------------------
    if (RT != null){
      devName = RT.getRouterName();
      labelDev = "R";

      for (int count = 0 ; count < RT.getSport().size(); count++){
        IntSerial ints = (IntSerial) RT.getSport().elementAt(count);
        if (ints.getOpIP() == ""){
          jComboBoxPort.addItem(ints.getSname());
        }else {}
      }//end for

      for (int count = 0 ; count < RT.getEport().size(); count++){
        IntEthernet inte = (IntEthernet) RT.getEport().elementAt(count);
        if (inte.getConnectionWith() == ""){
          jComboBoxPort.addItem(inte.getEname());
        }else {}
      }//end for
    }//end init router

    if (SW != null){
      devName = SW.getSwitchName();
      labelDev = "S";

      for (int count = 0 ; count < SW.getEport().size(); count++){
        IntEthernet inte = (IntEthernet) SW.getEport().elementAt(count);
        if (inte.getConnectionWith() == ""){
          jComboBoxPort.addItem(inte.getEname());
        }else {}
      }//end for
    }//end init switch

    if (HO != null){
      devName = "Host"+HO.getHostID();
      labelDev = "H";

      for (int count = 0 ; count < HO.getEport().size(); count++){
        IntEthernet inte = (IntEthernet) HO.getEport().elementAt(count);
        if (inte.getConnectionWith() == ""){
          jComboBoxPort.addItem(inte.getEname());
        }else {}
      }//end for
    }//end init switch

//------------ Add component ------------------------------
    this.setTitle("- = Device Connections = -");
    this.setResizable(false);
    this.setFocusableWindowState(true);

    jPanel.setLayout(null);
    jPanel.setBorder(etchedBorder);
    jPanel.setPreferredSize(new Dimension(325,380));

    jLabelDevice1.setText("DEVICE  :");
    jLabelDevice1.setBounds(new Rectangle(33, 16, 52, 21));

    jLabelDevice2.setText("Connect With :");
    jLabelDevice2.setBounds(new Rectangle(33, 91, 100, 21));

    jComboBoxType1 = new JComboBox(type);
    jComboBoxType1.setBounds(new Rectangle(90, 121, 157, 21));
    jComboBoxType1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jComboBoxType1_actionPerformed(e);
      }
    });//end listen

    jComboBoxDevice1.setBounds(new Rectangle(90, 163, 157, 21));
    jComboBoxDevice1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jComboBoxDevice1_actionPerformed(e);
      }
    });//end listen

    jButtonConnect.setBounds(new Rectangle(43, 317, 100, 27));
    jButtonConnect.setText("Connect");
    jButtonConnect.setEnabled(true);
    jButtonConnect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButtonConnect_actionPerformed(e);
      }
    });//end listen

    jButtonCancle.setBounds(new Rectangle(174, 319, 100, 27));
    jButtonCancle.setText("Cancle");
    jButtonCancle.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jButtonCancle_actionPerformed(e);
          }
        });//end listen

    //add container

    jLabelDeviceName.setText(devName);
    jLabelDeviceName.setBounds(new Rectangle(90, 16, 61, 21));
    jLabelDevice2.setText("DEVICE :");
    jLabelDevice2.setBounds(new Rectangle(33, 163, 52, 21));

    jLabelPort1.setText("PORT :");
    jLabelPort1.setBounds(new Rectangle(33, 46, 52, 21));
    jLabelPort2.setText("PORT :");
    jLabelPort2.setBounds(new Rectangle(33, 205, 52, 21));

    jComboBoxPort.setBounds(new Rectangle(90, 46, 157, 21));
    jComboBoxPort1.setBounds(new Rectangle(90, 205, 157, 21));

    jLabelType1.setText("TYPE :");
    jLabelType1.setBounds(new Rectangle(33, 121, 52, 21));
    jLabelNetAddress.setText("NETWORK ADDRESS :");
    jLabelNetAddress.setBounds(new Rectangle(33, 272, 124, 30));

    jTextAreaNetAddress.setBorder(BorderFactory.createLoweredBevelBorder());
    jTextAreaNetAddress.setBounds(new Rectangle(156, 276, 148, 22));
    jTextAreaNetAddress.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        jTextArea_keyPressed(e);
      }
    });//end call jTextArea KeyListener

    jPanel.add(jLabelDeviceName, null);
    jPanel.add(jLabelDevice1, null);

    jPanel.add(jLabelPort1, null);
    jPanel.add(jLabelPort2, null);

    jPanel.add(jComboBoxPort, null);
    jPanel.add(jComboBoxPort1, null);

    jPanel.add(jLabelDevice2, null);
    jPanel.add(jLabelDevice2, null);

    jPanel.add(jLabelType1, null);
    jPanel.add(jComboBoxType1, null);
    jPanel.add(jComboBoxDevice1, null);


    jPanel.add(jLabelNetAddress, null);
    jPanel.add(jTextAreaNetAddress, null);

    jPanel.add(jButtonConnect, null);
    jPanel.add(jButtonCancle, null);

    this.getContentPane().add(jPanel, BorderLayout.CENTER);

    //set default function
    for (int resetR = 0; resetR < Frame1.vRouter.size(); resetR++){
      Router r_resetSel = (Router)Frame1.vRouter.elementAt(resetR);
      r_resetSel.resetSelected();
    }//resetR
    for (int resetS = 0; resetS < Frame1.vSwitch.size(); resetS++){
      Switch s_resetSel = (Switch)Frame1.vSwitch.elementAt(resetS);
      s_resetSel.resetSelected();
    }//resetS

  }///////////end jbInit()

//----------- Listener --------------------------------------------//
  void jComboBoxType1_actionPerformed(ActionEvent e) {
    JComboBox jc = (JComboBox)e.getSource();
    int ID = jc.getSelectedIndex();

    jComboBoxDevice1.removeAllItems();
    jComboBoxPort1.removeAllItems();

    if (ID == 0){
      devType = "R";
      for(int countR = 0; countR < Frame1.vRouter.size(); countR++){
        Router r_temp = (Router)Frame1.vRouter.elementAt(countR);
        if (devName != r_temp.getRouterName()){
          jComboBoxDevice1.addItem(r_temp.getRouterName());
        }else {}
      }//end add router
      System.out.println("Router");

    }else if(ID == 1){
      devType = "S";
      for(int countS = 0; countS < Frame1.vSwitch.size(); countS++){
        Switch s_temp = (Switch)Frame1.vSwitch.elementAt(countS);
        if (devName != s_temp.getSwitchName()){
          jComboBoxDevice1.addItem(s_temp.getSwitchName());
        }else {}
      }//end add switch
      System.out.println("Switch");

    }else if(ID == 2){
      devType = "H";
/*      for (int countH = 0; countH < Frame1.vHost.size(); countH++) {
        Host h_temp = (Host) Frame1.vHost.elementAt(countH);
        if (devName != "Device"+h_temp.getHostID()) {
          jComboBoxDevice1.addItem(h_temp.getSwitchName());
        }
        else {}
      }//end add host*/
      System.out.println("Host");
    }//end if

  }//end CBType1

  void jComboBoxDevice1_actionPerformed(ActionEvent e) {
    jComboBoxPort1.removeAllItems();

    JComboBox jc = (JComboBox)e.getSource();
    int Index = jc.getSelectedIndex();

    if (devType == "R"){
      Router rt = (Router)Frame1.vRouter.elementAt(Index);
      System.out.println("device1 rt.name = "+rt.getRouterName());

      for (int count = 0 ; count < rt.getSport().size(); count++){
        IntSerial ints = (IntSerial) rt.getSport().elementAt(count);
//        if (ints.getOpIP() == ""){
          jComboBoxPort1.addItem(ints.getSname());
//        }else {}
      }//end for

      for (int count = 0 ; count < rt.getEport().size(); count++){
        IntEthernet inte = (IntEthernet) rt.getEport().elementAt(count);
//        if (inte.getConnectionWith() == ""){
          jComboBoxPort1.addItem(inte.getEname());
//        }else {}
      }//end for

    }else if(devType == "S"){
      Switch sw = (Switch)Frame1.vSwitch.elementAt(Index);

      for (int count = 0 ; count < sw.getEport().size(); count++){
        IntEthernet inte = (IntEthernet) sw.getEport().elementAt(count);
//        if (inte.getConnectionWith() == ""){
          jComboBoxPort1.addItem(inte.getEname());
//        }else {}
      }//end for

//    }else if(devType == "H"){

    }//end if

  }//end CBDevice1

//------------- key event ------------------
  void jTextArea_keyPressed(KeyEvent e) {
    int keycode = e.getKeyCode();
    if (keycode == e.VK_ENTER){
      e.consume();
      jButtonConnect.doClick();
    }//end override key enter
  }//end key adapter function

//----------- Button Connect & Cancle ---------------------------------
  void jButtonConnect_actionPerformed(ActionEvent e) {
    IntSerial sourceS,destS;
    IntEthernet sourceE,destE;
    Router rt_destTemp;
    Switch sw_destTemp;
    Host   ho_destTemp;

    String netAddress = jTextAreaNetAddress.getText();
    String portSource,portDest;

    portSource = (String)jComboBoxPort.getSelectedItem();
    portDest   = (String)jComboBoxPort1.getSelectedItem();

    if ( ((portSource.charAt(0) == 'S') && (portDest.charAt(0) == 'F')) ||
         ((portSource.charAt(0) == 'F') && (portDest.charAt(0) == 'S')) ) {
      JOptionPane.showMessageDialog(null,"Cannot connect Serial port with Fast Ethernet port","Warning",JOptionPane.WARNING_MESSAGE);
    }else {

      if (!isIp(netAddress)){
        JOptionPane.showMessageDialog(null,"Network Address invalid\n < 0.0.0.0 > - < 255.255.255.255 >","Warning",JOptionPane.WARNING_MESSAGE);
      }else {    // here can be connected correctly

        try {
//------------- find source port -----------------------------------------
          if (RT != null) {

            for (int count = 0 ; count < RT.getSport().size(); count++){
              IntSerial find_intS = (IntSerial) RT.getSport().elementAt(count);
              if (find_intS.getSname() == portSource){
                sourceS = find_intS;
                beginS = find_intS;
                startPortName = find_intS.getSname();
                NetDesignPanel.vLineType.addElement(new String("S"));


              }else {}
            }//end for

            for (int count = 0 ; count < RT.getEport().size(); count++){
              IntEthernet find_intE = (IntEthernet) RT.getEport().elementAt(count);
              if (find_intE.getEname() == portSource){
                sourceE = find_intE;
                beginE = find_intE;
                startPortName = find_intE.getEname();
                NetDesignPanel.vLineType.addElement(new String("E"));
              }else {}
            }//end for

            rimgS = (RouterImg)NetDesignPanel.vRouterImg.lastElement();

          }else if (SW != null) {
//      switchSID = SW.getSwitchID();

            for (int count = 0 ; count < SW.getEport().size(); count++){
              IntEthernet find_intE = (IntEthernet) SW.getEport().elementAt(count);
              if (find_intE.getEname() == portSource){
                sourceE = find_intE;
                beginE = find_intE;
                startPortName = find_intE.getEname();
                NetDesignPanel.vLineType.addElement(new String("E"));
              }else {}
            }//end for

            simgS = (SwitchImg)NetDesignPanel.vSwitchImg.lastElement();

          }else if (HO != null) {
//      hostSID = HO.getHostID();

            for (int count = 0 ; count < HO.getEport().size(); count++){
              IntEthernet find_intE = (IntEthernet) HO.getEport().elementAt(count);
              if (find_intE.getEname() == portSource){
                sourceE = find_intE;
                beginE = find_intE;
                startPortName = find_intE.getEname();
                NetDesignPanel.vLineType.addElement(new String("E"));
              }else {}
            }//end for

            himgS = (HostImg)NetDesignPanel.vHostImg.lastElement();
          }//end find source port

//-------------- find Dest port -----------------------------------------

          if (devType == "R") {
            int index = jComboBoxDevice1.getSelectedIndex();
            Router rt_dest_temp = (Router)Frame1.vRouter.elementAt(index);
//      routerEID = rt_dest_temp.getRouterID();

            for (int count = 0 ; count < rt_dest_temp.getSport().size(); count++){
              IntSerial find_intS = (IntSerial) rt_dest_temp.getSport().elementAt(count);
              if (portDest.equalsIgnoreCase(find_intS.getSname())){
                destS = find_intS;
                endS = find_intS;
                endPortName = find_intS.getSname();
              }
            }//end for

            for (int count = 0 ; count < rt_dest_temp.getEport().size(); count++){
              IntEthernet find_intE = (IntEthernet) rt_dest_temp.getEport().elementAt(count);
              if (portDest.equalsIgnoreCase(find_intE.getEname())){
                destE = find_intE;
                endE = find_intE;
                endPortName = find_intE.getEname();
              }
            }//end for

            rimgE = (RouterImg)NetDesignPanel.vRouterImg.elementAt(index);

          }else if (devType == "S") {
            int index = jComboBoxDevice1.getSelectedIndex();
            Switch sw_dest_temp = (Switch)Frame1.vSwitch.elementAt(index);
//      switchEID = sw_dest_temp.getSwitchID();

            for (int count = 0 ; count < sw_dest_temp.getEport().size(); count++){
              IntEthernet find_intE = (IntEthernet) sw_dest_temp.getEport().elementAt(count);
              if (portDest.equalsIgnoreCase(find_intE.getEname())){
                destE = find_intE;
                endE = find_intE;
                endPortName = find_intE.getEname();
              }else {}
            }//end for

            simgE = (SwitchImg)NetDesignPanel.vSwitchImg.elementAt(index);

          }//end find dest port

          //--------------- Connect Image here ---------------------------------
          System.out.println("source = "+portSource.substring(0) + " Connected with dest = " + portDest.substring(0));

          boolean found_dup = false;
          int replace_index = 0;
          String startDeviceName = "";
          String startInterfaceName = "";
          String endDeviceName = "";
          String endInterfaceName = "";

          //Begin Image

          // Router
          if (rimgS != null){ // rimgS has been set
            startDeviceName = RT.getRouterUniName();

            int own_ImgID = rimgS.getIdRouterImg();
            int chk_ImgID;
            int end_ImgID = 0;
            String chk_PortName;

            //Check same router & same port at start
            for (int count = 0; count < NetDesignPanel.vFlagImgStart.size(); count++){
              String flagStartImg = NetDesignPanel.vFlagImgStart.elementAt(count).toString();
              if (flagStartImg.equalsIgnoreCase("R")){
                RouterImg r_imgS = (RouterImg)NetDesignPanel.vStartImg.elementAt(count);
                chk_ImgID = r_imgS.getIdRouterImg();
                chk_PortName = NetDesignPanel.vStartPortName.elementAt(count).toString();
                if ((own_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(rimgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("R"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);
                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_router start

            //Check same router & same port at End
            for (int count = 0; count < NetDesignPanel.vFlagImgEnd.size(); count++){
              String flagEndImg = NetDesignPanel.vFlagImgEnd.elementAt(count).toString();
              if (flagEndImg.equalsIgnoreCase("R")){
                RouterImg r_imgE = (RouterImg)NetDesignPanel.vEndImg.elementAt(count);

                if (rimgE != null){
                  end_ImgID = rimgE.getIdRouterImg();
                }else if (simgE != null){
                  end_ImgID = simgE.getIdSwitchImg();
                }else if (himgE != null){
                  end_ImgID = himgE.getIdHostImg();
                }

                chk_ImgID = r_imgE.getIdRouterImg();
                chk_PortName = NetDesignPanel.vEndPortName.elementAt(count).toString();

                if ((end_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(rimgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("R"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);

                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_router start

            if (!found_dup){
              NetDesignPanel.vStartImg.addElement(rimgS);
              NetDesignPanel.vFlagImgStart.addElement(new String("R"));
              NetDesignPanel.vStartPortName.addElement(new String(startPortName));
              startInterfaceName = startPortName;
            }//end if

            // Switch
          }else if (simgS != null){ //simgS has been set
            startDeviceName = SW.getSwitchUniName();

            int own_ImgID = simgS.getIdSwitchImg();
            int chk_ImgID;
            int end_ImgID = 0;
            String chk_PortName;

            //Check same switch & same port at start
            for (int count = 0; count < NetDesignPanel.vFlagImgStart.size(); count++){
              String flagStartImg = NetDesignPanel.vFlagImgStart.elementAt(count).toString();
              if (flagStartImg.equalsIgnoreCase("S")){
                SwitchImg s_imgS = (SwitchImg)NetDesignPanel.vStartImg.elementAt(count);
                chk_ImgID = s_imgS.getIdSwitchImg();
                chk_PortName = NetDesignPanel.vStartPortName.elementAt(count).toString();
                if ((own_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(simgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("S"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);

                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_router start

            //Check same router & same port at End
            for (int count = 0; count < NetDesignPanel.vFlagImgEnd.size(); count++){
              String flagEndImg = NetDesignPanel.vFlagImgEnd.elementAt(count).toString();
              if (flagEndImg.equalsIgnoreCase("S")){
                SwitchImg s_imgE = (SwitchImg)NetDesignPanel.vEndImg.elementAt(count);

                if (rimgE != null){
                  end_ImgID = rimgE.getIdRouterImg();
                }else if (simgE != null){
                  end_ImgID = simgE.getIdSwitchImg();
                }else if (himgE != null){
                  end_ImgID = himgE.getIdHostImg();
                }

                chk_ImgID = s_imgE.getIdSwitchImg();
                chk_PortName = NetDesignPanel.vEndPortName.elementAt(count).toString();
                if ((end_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(simgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("S"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);

                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_router start

            if (!found_dup){
              NetDesignPanel.vStartImg.addElement(simgS);
              NetDesignPanel.vFlagImgStart.addElement(new String("S"));
              NetDesignPanel.vStartPortName.addElement(new String(startPortName));

              startInterfaceName = startPortName;
            }//end if

            // Host
          }else if (himgS != null){ //himgS has been set
            startDeviceName = HO.getHostUniName();

            int own_ImgID = himgS.getIdHostImg();
            int chk_ImgID;
            int end_ImgID = 0;
            String chk_PortName;

            //Check same host & same port at start
            for (int count = 0; count < NetDesignPanel.vFlagImgStart.size(); count++){
              String flagStartImg = NetDesignPanel.vFlagImgStart.elementAt(count).toString();
              if (flagStartImg.equalsIgnoreCase("H")){
                HostImg h_imgS = (HostImg)NetDesignPanel.vStartImg.elementAt(count);
                chk_ImgID = h_imgS.getIdHostImg();
                chk_PortName = NetDesignPanel.vStartPortName.elementAt(count).toString();
                if ((own_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(himgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("H"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);

                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_host start

            //Check same host & same port at End
            for (int count = 0; count < NetDesignPanel.vFlagImgEnd.size(); count++){
              String flagEndImg = NetDesignPanel.vFlagImgEnd.elementAt(count).toString();
              if (flagEndImg.equalsIgnoreCase("H")){
                HostImg h_imgE = (HostImg)NetDesignPanel.vEndImg.elementAt(count);

                if (rimgE != null){
                  end_ImgID = rimgE.getIdRouterImg();
                }else if (simgE != null){
                  end_ImgID = simgE.getIdSwitchImg();
                }else if (himgE != null){
                  end_ImgID = himgE.getIdHostImg();
                }

                chk_ImgID = h_imgE.getIdHostImg();
                chk_PortName = NetDesignPanel.vEndPortName.elementAt(count).toString();
                if ((end_ImgID == chk_ImgID)&&(startPortName.equalsIgnoreCase(chk_PortName))){
                  found_dup = true;
                  replace_index = count;

                  NetDesignPanel.vStartImg.setElementAt(himgS,count);
                  NetDesignPanel.vFlagImgStart.setElementAt(new String("H"),count);
                  NetDesignPanel.vStartPortName.setElementAt(new String(startPortName),count);

                  startInterfaceName = startPortName;
                }else {}
              }else {}
            }//end for find dup_router start

            if (!found_dup){
              NetDesignPanel.vStartImg.addElement(himgS);
              NetDesignPanel.vFlagImgStart.addElement(new String("H"));
              NetDesignPanel.vStartPortName.addElement(new String(startPortName));

              startInterfaceName = startPortName;
            }//end if
          }//end if begin image


          //End Image
          if (rimgE != null){ // rimgE has been set
            endDeviceName = rimgE.getRouterImgUniName();
            if (found_dup){
              NetDesignPanel.vEndImg.setElementAt(rimgE,replace_index);
              NetDesignPanel.vFlagImgEnd.setElementAt(new String("R"),replace_index);
              NetDesignPanel.vEndPortName.setElementAt(new String(endPortName),replace_index);

              endInterfaceName = endPortName;
            }else {
              NetDesignPanel.vEndImg.addElement(rimgE);
              NetDesignPanel.vFlagImgEnd.addElement(new String("R"));
              NetDesignPanel.vEndPortName.addElement(new String(endPortName));

              endInterfaceName = endPortName;
            }
          }else if (simgE != null){ //simgE has been set
            endDeviceName = simgE.getSwitchImgUniName();
            if (found_dup){
              NetDesignPanel.vEndImg.setElementAt(simgE,replace_index);
              NetDesignPanel.vFlagImgEnd.setElementAt(new String("S"),replace_index);
              NetDesignPanel.vEndPortName.setElementAt(new String(endPortName),replace_index);

              endInterfaceName = endPortName;
            }else {
              NetDesignPanel.vEndImg.addElement(simgE);
              NetDesignPanel.vFlagImgEnd.addElement(new String("S"));
              NetDesignPanel.vEndPortName.addElement(new String(endPortName));

              endInterfaceName = endPortName;
            }
          }else if (himgE != null){ //himgE has been set
            endDeviceName = himgE.getHostImgUniName();
            if (found_dup){
              NetDesignPanel.vEndImg.setElementAt(himgE,replace_index);
              NetDesignPanel.vFlagImgEnd.setElementAt(new String("H"),replace_index);
              NetDesignPanel.vEndPortName.setElementAt(new String(endPortName),replace_index);

              endInterfaceName = endPortName;
            }else {
              NetDesignPanel.vEndImg.addElement(himgE);
              NetDesignPanel.vFlagImgEnd.addElement(new String("H"));
              NetDesignPanel.vEndPortName.addElement(new String(endPortName));

              endInterfaceName = endPortName;
            }//end if
          }//end if end image


          //**************************** set connection ************************
          //begin interface
          if (beginS != null){
            if (found_dup){
              beginS.setNetworkAddress(netAddress);
              beginS.setConnectionWith(endDeviceName+" "+endInterfaceName);
              NetDesignPanel.vNetAddress.setElementAt(new String(netAddress),replace_index);
            }else {
              beginS.setNetworkAddress(netAddress);
              beginS.setConnectionWith(endDeviceName+" "+endInterfaceName);
              NetDesignPanel.vNetAddress.addElement(new String(netAddress));
            }
          }else {// beginE was enable
            if (found_dup){
              beginE.setNetworkAddress(netAddress);
              beginE.setConnectionWith(endDeviceName+" "+endInterfaceName);
              NetDesignPanel.vNetAddress.setElementAt(new String(netAddress),replace_index);
            }else {
              beginE.setNetworkAddress(netAddress);
              beginE.setConnectionWith(endDeviceName+" "+endInterfaceName);
              NetDesignPanel.vNetAddress.addElement(new String(netAddress));
            }
          }
          //end interface
          if (endS != null){
            endS.setNetworkAddress(netAddress);
            endS.setConnectionWith(startDeviceName+" "+startInterfaceName);
          }else {// endE was enable
            endE.setNetworkAddress(netAddress);
            endE.setConnectionWith(startDeviceName+" "+startInterfaceName);
          }

//************** Device Connection here ******************************************

       System.out.println("StartDeviceName = "+startDeviceName);
       System.out.println("StartInterfaceName = "+startInterfaceName);
       System.out.println("EndDeviceName = "+endDeviceName);
       System.out.println("EndInterfaceName = "+endInterfaceName);

       if (found_dup){
         this.vConnectionBegin.setElementAt(new String(startDeviceName + " " +
             startInterfaceName),replace_index);
         this.vConnectionEnd.setElementAt(new String(endDeviceName + " " +
             endInterfaceName),replace_index);
       }else {
         this.vConnectionBegin.addElement(new String(startDeviceName + " " +
             startInterfaceName));
         this.vConnectionEnd.addElement(new String(endDeviceName + " " +
             endInterfaceName));
       }

       repaint();
       this.dispose();
//--------------- End Connect Device -----------------------------------------------
      }catch (Exception buttonException) {
        JOptionPane.showMessageDialog(null,"Cannot connect","Error",JOptionPane.ERROR_MESSAGE);
        buttonException.printStackTrace();
      }// end try catch

      }//end if is ip
    }//end else

  }//end Button Connect

  void jButtonCancle_actionPerformed(ActionEvent e) {
    this.dispose();
  }//end Button Cancle


//----------- check ip function -------------------------------
  static boolean isIp(String s){
      boolean chk_ip = true;
      StringTokenizer st = new StringTokenizer(s, ".");
      for (int i = 0; i < 4; i++) {
        if (st.hasMoreTokens()) {
          String tmp = st.nextToken();
          try {
            int ip = Integer.parseInt(tmp);
            if ( (ip < 0) || (ip > 255)) {
              chk_ip = false;
            }
          }catch (NumberFormatException exp) {chk_ip = false;}
        }//end if
        else {
          chk_ip = false;
        }//end else
      }//end for
      return chk_ip;
    }///end chk isIp

//--------- Method cut str  --------------------------------------------
    static String cutString(String CMD,int index,String symbol) {
    Vector cutStr = new Vector();
      cutStr.removeAllElements();
      StringTokenizer subStr = new StringTokenizer(CMD,symbol);
      while (subStr.hasMoreTokens()){
        String str = subStr.nextToken();
        cutStr.addElement(str);
      }//end while
      return cutStr.elementAt(index).toString();
    }//end cutInput


//Overridden so we can exit when window is closed
    protected void processWindowEvent(WindowEvent e) {
      super.processWindowEvent(e);
      if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        this.dispose();
      }
    }//end override//*/
//*/
}//end Class Connections