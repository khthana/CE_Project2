package netsimulator;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;

import java.util.*;
import java.lang.Double;

import javax.swing.JOptionPane;
import javax.swing.border.*;
import javax.swing.JScrollPane;
import javax.swing.*;

public class Frame1 extends JFrame {

  NetDesignPanel designPanel = new NetDesignPanel(); //for add designPanel

  static Vector vRouter = new Vector();
  private int maxRouter = 15;

  static Vector vSwitch = new Vector();
  private int maxSwitch = 20;

  static Vector vHost = new Vector();
  private int numHost = 0;

//  static Vector vWire = new Vector();

  private GridLayout gridLayout1 = new GridLayout(1,10,10,0); // jToolBar
  private GridLayout gridLayout2 = new GridLayout(10,1,0,10); // devicePane

  private JMenuBar jMenuBar = new JMenuBar();

  private JToolBar jToolBar = new JToolBar();

  private JPanel contentPane = new JPanel();
  private JPanel devicePanel = new JPanel();

  static JTextArea jTextArea = new JTextArea();

  private Border borderEmpty = new EmptyBorder(10,10,10,10);
  private Border borderTitleDevice = new TitledBorder(" - = D e v i c e = -");
  private Border borderTitleDetail = new TitledBorder(" - = D e t a i l = -");
  private Border borderTitleView = new TitledBorder(" - = N e t w o r k  D e s i g n = -");
  private Border borderEtched = new EtchedBorder();

  private Dimension screenSize  = Toolkit.getDefaultToolkit().getScreenSize(); //get windows size;
  private int winHigh = screenSize.height-27; //care taskbar
  private int winWide = screenSize.width;
  private Dimension winSize = new Dimension(winWide,winHigh);

  private Rectangle boundToolBar = new Rectangle(new Point(1, 1),new Dimension(winWide,52));
  private Rectangle boundDevice = new Rectangle(new Point(1, boundToolBar.height+2),new Dimension(110, winHigh-boundToolBar.height-48));
  private Rectangle boundDetail = new Rectangle(new Point(winWide-220,boundToolBar.height+2),new Dimension(215, winHigh-boundToolBar.height-48));
  private Rectangle boundScroll = new Rectangle(new Point(boundDevice.width+2,boundToolBar.height+2),new Dimension(winWide-boundDetail.width-boundDevice.width,winHigh-boundToolBar.height-48));

/*  private Rectangle boundContent = new Rectangle(5, 456, 127, 238);
  private Rectangle boundToolBar = new Rectangle(1, 1, 1014, 58);
  private Rectangle boundDevice = new Rectangle(1, 60, 110, 660);
  private Rectangle boundScroll = new Rectangle(112, 60, 840, 660);*/

  private JScrollPane jScrollPane = new JScrollPane(); //for draw
  private JScrollPane jScrollPaneDetail = new JScrollPane();

  private JButton jOpen = new JButton();  //Button open in toolbar
  private JButton jLoad = new JButton();
  private JButton jSave = new JButton();
//  private JButton jDelete = new JButton();

  private JButton jR01 = new JButton();  //Button Router 2501
  private JButton jR02 = new JButton();  //Button Custom Router

  private JButton jS01 = new JButton();  //Button Switch 2950
  private JButton jS02 = new JButton();  //Button Custom Switch

  private JButton jHost = new JButton(); //Button Host

//  private JButton jWSerial = new JButton(); //Wire Serial
//  private JButton jWEthernet = new JButton(); // Wire Ethernet

  // Picture setting
  ImageIcon imageOpen = new ImageIcon(Frame1.class.getResource("open.png"));
  ImageIcon imageLoad = new ImageIcon(Frame1.class.getResource("load.png"));
  ImageIcon imageSave = new ImageIcon(Frame1.class.getResource("save.png"));
  ImageIcon imageDelete = new ImageIcon(Frame1.class.getResource("delete.png"));

  ImageIcon imageR01 = new ImageIcon(Frame1.class.getResource("router01.gif"));//"bluerouter.gif"));
  ImageIcon imageR02 = new ImageIcon(Frame1.class.getResource("router02.gif"));

  ImageIcon imageS01 = new ImageIcon(Frame1.class.getResource("switch01.gif"));//2950-12-n.jpg"));
  ImageIcon imageS02 = new ImageIcon(Frame1.class.getResource("switch02.gif"));

  ImageIcon imageHost = new ImageIcon(Frame1.class.getResource("host.gif"));
//  ImageIcon imageWSerial = new ImageIcon(Frame1.class.getResource("ser.gif"));//Wire Serial
//  ImageIcon imageWEthernet = new ImageIcon(Frame1.class.getResource("eth.gif"));

  //-------------------------Frame1---------------------------------------------
  public Frame1() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }// end Constructor Frame1

  //-------------------------jbInit---------------------------------------------
  private void jbInit() {
    super.setDefaultCloseOperation(EXIT_ON_CLOSE); //-- close operation
    super.setSize(winSize);
    super.setResizable(true);
    super.setTitle(" I S A G  : R o u t e r  &  S w i t c h  S i m u l a t o r  E d i t i o n  :  2 0 0 3  -  2 0 0 4 ");
    super.setVisible(true);

    //Menu Bar
    JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('F');
        JMenuItem openMenuItem = new JMenuItem("Open");
        openMenuItem.setMnemonic('O');
        openMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               openMenuItem_actionPerformed(e);
             }
        });

        JMenuItem saveMenuItem = new JMenuItem("Save");
        saveMenuItem.setMnemonic('S');
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               saveMenuItem_actionPerformed(e);
             }
        });

        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.setMnemonic('x');
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               exitMenuItem_actionPerformed(e);
             }
        });

    JMenu editMenu = new JMenu("Edit");
    editMenu.setMnemonic('E');
        JMenuItem addMenuItem = new JMenuItem("Add");
        addMenuItem.setMnemonic('A');
        addMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               addMenuItem_actionPerformed(e);
             }
        });

        JMenuItem delMenuItem = new JMenuItem("Delete");
        delMenuItem.setMnemonic('D');
        delMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               delMenuItem_actionPerformed(e);
             }
        });

    JMenu helpMenu = new JMenu("Help");
    helpMenu.setMnemonic('H');
        JMenuItem topicMenuItem = new JMenuItem("Help Topics");
        topicMenuItem.setMnemonic('e');
        topicMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               topicMenuItem_actionPerformed(e);
             }
        });

        JMenuItem aboutMenuItem = new JMenuItem("About NetSim");
        aboutMenuItem.setMnemonic('A');
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(ActionEvent e) {
               aboutMenuItem_actionPerformed(e);
             }
        });

    // add MenuItem

    fileMenu.add(openMenuItem);
    fileMenu.add(saveMenuItem);
    fileMenu.addSeparator();
    fileMenu.add(exitMenuItem);
    editMenu.add(addMenuItem);
    editMenu.add(delMenuItem);
    helpMenu.add(topicMenuItem);
    helpMenu.addSeparator();
    helpMenu.add(aboutMenuItem);

    // add Menu
    setJMenuBar(jMenuBar);
    jMenuBar.add(fileMenu);
    jMenuBar.add(editMenu);
    jMenuBar.add(helpMenu);

    // contentPane setting of Windows
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
//    contentPane.setBounds(boundContent);
    contentPane.setBackground(UIManager.getColor("ToolBar.floatingBackground"));
    contentPane.setEnabled(true);

    // contentPane add
    contentPane.add(jToolBar);
    contentPane.add(devicePanel);
    contentPane.add(jScrollPaneDetail);
    contentPane.add(jScrollPane);

    // ScrollPane setting
    jScrollPane.setBorder(borderTitleView);
    jScrollPane.setBounds(boundScroll);
    jScrollPane.setBackground(Color.white);
    jScrollPane.setForeground(Color.white);
    jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    jScrollPane.setPreferredSize(new Dimension(24,24));
    jScrollPane.setAutoscrolls(true);
    jScrollPane.getViewport().add(designPanel, null);

    // ScrollPaneDetail setting
    jTextArea.setBackground(Color.DARK_GRAY);
    jTextArea.setForeground(Color.WHITE);
    jTextArea.setLineWrap(false);
    jTextArea.setWrapStyleWord(false);
    jTextArea.setText("");
    jTextArea.setEditable(false);
    jTextArea.setCaretPosition(0);

    jScrollPaneDetail.setBorder(borderTitleDetail);
    jScrollPaneDetail.setBounds(boundDetail);
    jScrollPaneDetail.setBackground(Color.white);
    jScrollPaneDetail.setForeground(Color.white);
    jScrollPaneDetail.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    jScrollPaneDetail.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    jScrollPaneDetail.setAutoscrolls(true);
    jScrollPaneDetail.getViewport().add(jTextArea, null);

    // Sub ToolBar Setting in contentPane
    jToolBar.setLayout(gridLayout1);
    jToolBar.setBounds(boundToolBar);
    jToolBar.setBorder(borderEtched);
    jToolBar.setEnabled(true);
    jToolBar.setBackground(Color.white);

    // Toolbar add
    jToolBar.add(jOpen,null);
    jToolBar.add(jLoad,null);
    jToolBar.add(jSave,null);
//    jToolBar.add(jDelete,null);
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null); //for blank
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null);
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null);
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null);
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null);
    jToolBar.add(new JLabel(""),null);jToolBar.add(new JLabel(""),null);

    // set view of toolbar
    jOpen.setIcon(imageOpen);
    jOpen.setBorder(borderEmpty);
    jOpen.setToolTipText("open Diagram");
    jOpen.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jOpen.setVerticalTextPosition(AbstractButton.BOTTOM);
    jOpen.setHorizontalTextPosition(SwingConstants.CENTER);
    jOpen.setText("Open");
    jOpen.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
    jOpen.setFocusPainted(false);
    jOpen.setContentAreaFilled(false);
    jOpen.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jOpen_actionPerformed(e);
          }
    });

    jLoad.setIcon(imageLoad);
    jLoad.setBorder(borderEmpty);
    jLoad.setToolTipText("Load Diagram");
    jLoad.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jLoad.setVerticalTextPosition(AbstractButton.BOTTOM);
    jLoad.setHorizontalTextPosition(AbstractButton.CENTER);
    jLoad.setText("Load");
    jLoad.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
    jLoad.setFocusPainted(false);
    jLoad.setContentAreaFilled(false);
    jLoad.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jLoad_actionPerformed(e);
          }
    });

    jSave.setIcon(imageSave);
    jSave.setBorder(borderEmpty);
    jSave.setToolTipText("Save Diagram");
    jSave.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jSave.setVerticalTextPosition(AbstractButton.BOTTOM);
    jSave.setHorizontalTextPosition(AbstractButton.CENTER);
    jSave.setText("Save");
    jSave.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
    jSave.setFocusPainted(false);
    jSave.setContentAreaFilled(false);
    jSave.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jSave_actionPerformed(e);
          }
    });

/*    jDelete.setIcon(imageDelete);
    jDelete.setBorder(borderEmpty);
    jDelete.setToolTipText("Delete");
    jDelete.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jDelete.setVerticalTextPosition(AbstractButton.BOTTOM);
    jDelete.setHorizontalTextPosition(AbstractButton.CENTER);
    jDelete.setText("Delete");
    jDelete.setCursor( new Cursor( Cursor.HAND_CURSOR ) );
    jDelete.setFocusPainted(false);
    jDelete.setContentAreaFilled(false);
    jDelete.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jDelete_actionPerformed(e);
          }
    });*/

    // devicePanel Setting : Sub Pane in contentPane
    devicePanel.setLayout(gridLayout2);
    devicePanel.setBounds(boundDevice);
    devicePanel.setEnabled(true);
    devicePanel.setBorder(borderTitleDevice);
    devicePanel.setBackground(Color.white);

    // devicePanel add
    devicePanel.add(jR01, null);
    devicePanel.add(jR02, null);

    devicePanel.add(jS01, null);
    devicePanel.add(jS02, null);

    devicePanel.add(jHost,null);
//    devicePanel.add(jWSerial,null);
//    devicePanel.add(jWEthernet,null);

    // set view of router
    jR01.setIcon(imageR01);
    jR01.setBorder(borderEmpty);
    jR01.setVerticalTextPosition(AbstractButton.BOTTOM);
    jR01.setHorizontalTextPosition(AbstractButton.CENTER);
    jR01.setText(" Cisco 1760");
    jR01.setToolTipText("Cisco Router series 2501");
    jR01.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jR01.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jR01.setFocusPainted(false);
    jR01.setContentAreaFilled(false);
    jR01.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jR01_actionPerformed(e);
          }
    });

    jR02.setIcon(imageR02);
    jR02.setBorder(borderEmpty);
    jR02.setVerticalTextPosition(AbstractButton.BOTTOM);
    jR02.setHorizontalTextPosition(AbstractButton.CENTER);
    jR02.setText(" Custom Router ");
    jR02.setToolTipText("Create new router");
    jR02.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jR02.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jR02.setFocusPainted(false);
    jR02.setContentAreaFilled(false);
    jR02.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jR02_actionPerformed(e);
          }
    });

    // set view of switch
    jS01.setIcon(imageS01);
    jS01.setBorder(borderEmpty);//165*30 -- 169 85
    jS01.setVerticalTextPosition(AbstractButton.BOTTOM);
    jS01.setHorizontalTextPosition(AbstractButton.CENTER);
    jS01.setText(" Cisco 2950 ");
    jS01.setToolTipText("Cisco Switch series 2950");
    jS01.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jS01.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jS01.setFocusPainted(false);
    jS01.setContentAreaFilled(false);
    jS01.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jS01_actionPerformed(e);
          }
    });

    jS02.setIcon(imageS02);
    jS02.setBorder(borderEmpty);//165*30 -- 169 85
    jS02.setVerticalTextPosition(AbstractButton.BOTTOM);
    jS02.setHorizontalTextPosition(AbstractButton.CENTER);
    jS02.setText(" Custom Switch ");
    jS02.setToolTipText("Create new switch");
    jS02.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jS02.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jS02.setFocusPainted(false);
    jS02.setContentAreaFilled(false);
    jS02.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jS02_actionPerformed(e);
          }
    });

    // set view of host
    jHost.setIcon(imageHost);
    jHost.setBorder(borderEmpty);
    jHost.setVerticalTextPosition(AbstractButton.BOTTOM);
    jHost.setHorizontalTextPosition(AbstractButton.CENTER);
    jHost.setText(" Host ");
    jHost.setToolTipText("Create Host");
    jHost.setFont(new Font("Tahoma", Font.PLAIN, 10));
    jHost.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jHost.setFocusPainted(false);
    jHost.setContentAreaFilled(false);
    jHost.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jHost_actionPerformed(e);
          }
    });

    // set view of wire
/*    jWSerial.setIcon(imageWSerial);
    jWSerial.setBorder(borderEmpty);
    jWSerial.setToolTipText("Serial");
    jWSerial.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jWSerial.setFocusPainted(false);
    jWSerial.setContentAreaFilled(false);
    jWSerial.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jWSerial_actionPerformed(e);
          }
    });

    jWEthernet.setIcon(imageWEthernet);
    jWEthernet.setBorder(borderEmpty);
    jWEthernet.setToolTipText("Ethernet");
    jWEthernet.setCursor(new Cursor(Cursor.HAND_CURSOR));
    jWEthernet.setFocusPainted(false);
    jWEthernet.setContentAreaFilled(false);
    jWEthernet.addActionListener(new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e) {
            jWEthernet_actionPerformed(e);
          }
    });
*/
  }// end jbInit

//---------Implement Listenner ------------------------------------------------------
  // Menu Listener
  void openMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("openMenuItem pressed");
  }
  void saveMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("saveMenuItem pressed");
  }
  void exitMenuItem_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  void addMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("addMenuItem pressed");
  }
  void delMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("delMenuItem pressed");
  }
  void topicMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("topicMenuItem pressed");
  }
  void aboutMenuItem_actionPerformed(ActionEvent e) {
    System.out.println("aboutMenuItem pressed");
  }

  // Toolbar Listener
  void jOpen_actionPerformed(ActionEvent e) {//    Series= 1;//    CreateRouter(Series);
    System.out.println("jOpen pressed");
  }

  void jSave_actionPerformed(ActionEvent e) {
    System.out.println("jSave pressed");
  }

  void jLoad_actionPerformed(ActionEvent e) {
    System.out.println("jLoad pressed");
  }

/*  void jDelete_actionPerformed(ActionEvent e) {
    System.out.println("jDelete pressed");
    if (vRouter.size() > 0){
      designPanel.Delete_Router();
    }
  }*/

  // Device Listener
  void jR01_actionPerformed(ActionEvent e) {
    System.out.println("Create New Router : Button Press");
    if (vRouter.size() <= maxRouter){
      Router1760 r1 = new Router1760("Router1");
      vRouter.addElement(r1);
      RouterImg rImg = new RouterImg(1760);
      rImg.setIdRouterImg(r1.getRouterID());

      NetDesignPanel.vRouterImg.addElement(rImg);
      RouterConsole routerConsole = new RouterConsole(r1,r1.getRouterName());
      RouterConsole.vRouterConsole.addElement(routerConsole);
      repaint();
   }
    else System.out.println("Router is max 15");

    System.out.println("vRouter.size = " + Frame1.vRouter.size());
  }//end button jR01

  void jR02_actionPerformed(ActionEvent e) {
    System.out.println("Create New Router : Button Press");
    if (vRouter.size() <= maxRouter){
      DialogCustomRouter dialogCustomRouter = new DialogCustomRouter();

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = dialogCustomRouter.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      dialogCustomRouter.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
      dialogCustomRouter.setVisible(true);

      Router rc1 = new Router("Router1",dialogCustomRouter.getNumSerial(),dialogCustomRouter.getNumEthernet(),0);
      vRouter.addElement(rc1);
      RouterImg rImg = new RouterImg(0000);
      rImg.setIdRouterImg(rc1.getRouterID());

      NetDesignPanel.vRouterImg.addElement(rImg);
      RouterConsole routerConsole = new RouterConsole(rc1,rc1.getRouterName());
      RouterConsole.vRouterConsole.addElement(routerConsole);
      repaint();
    }
    else System.out.println("Router is max 15");

    System.out.println("vRouter.size = " + Frame1.vRouter.size());

  }//end button jR02

  void jS01_actionPerformed(ActionEvent e) {
    System.out.println("Create New Switch : Button Press");
    if (vSwitch.size() <= maxSwitch){
      Switch2950 s1 = new Switch2950("Switch1");
      vSwitch.addElement(s1);
      SwitchImg sImg = new SwitchImg(2950);
      sImg.setIdSwitchImg(s1.getSwitchID());

      NetDesignPanel.vSwitchImg.add(sImg);
      SwitchConsole switchConsole = new SwitchConsole(s1,s1.getSwitchName());
      SwitchConsole.vSwitchConsole.addElement(switchConsole);
      repaint();
   }
    else System.out.println("Switch is max 20");

    System.out.println("vSwitch.size = " + Frame1.vSwitch.size());

  }//end button jS01

  void jS02_actionPerformed(ActionEvent e){
    System.out.println("Create New Switch : Button Press");
    if (vSwitch.size() <= maxSwitch){
      DialogCustomSwitch dialogCustomSwitch = new DialogCustomSwitch();

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = dialogCustomSwitch.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      dialogCustomSwitch.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
      dialogCustomSwitch.setVisible(true);

      Switch s1 = new Switch("Switch",0,dialogCustomSwitch.getNumEthernet(),0);
      vSwitch.addElement(s1);
      SwitchImg sImg = new SwitchImg(0000);
      sImg.setIdSwitchImg(s1.getSwitchID());

      NetDesignPanel.vSwitchImg.addElement(sImg);
      SwitchConsole switchConsole = new SwitchConsole(s1,s1.getSwitchName());
      SwitchConsole.vSwitchConsole.addElement(switchConsole);
      repaint();
    }
  }//end button jS02

  void jHost_actionPerformed(ActionEvent e) {
    System.out.println("Host : Button Press");
    Host h1 = new Host(0);
    vHost.addElement(h1);
    HostImg hImg = new HostImg();
    hImg.setIdHostImg(h1.getHostID());
    String hostIP = "";

    do {
      hostIP = JOptionPane.showInputDialog(null, "Set IP Address",
                                           "Host",
                                           JOptionPane.INFORMATION_MESSAGE);
    }while (!RouterIOS120.isIp(hostIP));

    h1.setHostIPAddress(hostIP);
    NetDesignPanel.vHostImg.add(hImg);
    //add console
    repaint();
  }//end button host

/*  void jWSerial_actionPerformed(ActionEvent e) {
    System.out.println("Wire Serial : Button Press");
    Create_Wire(1);
  }

  void jWEthernet_actionPerformed(ActionEvent e) {
    System.out.println("Wire Ethernet : Button Press");
    Create_Wire(2);
  }
*/
//--------------- Function & Method ------------------------------//
/*  public void Create_Wire(int wireType){
    Wire w1 = new Wire();
    vWire.addElement(w1);
    WireImage wimg1 = new WireImage(wireType);
    NetDesignPanel.vWireImg.addElement(wimg1);
    repaint();
  }//end create_wire
*/

//--------------- Function set properties --------------------------//
  static void setTextProperty(Router rt){
    String text = "";
    text += " - = Router = - \n";
    text += "Router name : "+rt.getRouterName()+"\n"+
            "Mac Address : "+rt.getRouterMacAddress()+"\n"+
            "  - Max seriel port : "+rt.getSport().size()+"\n"+
            "  - Max fast ehernet port : "+rt.getEport().size()+"\n"+
            "\n"+
            "- = Serial Port = -";

    for (int count = 0; count < rt.getSport().size();count++){
      IntSerial intS = (IntSerial)rt.getSport().elementAt(count);
      text += "\n"+
          "- "+intS.getSname()+"\n"+
          "  - IP address : "+intS.getIPAddress()+"\n"+
          "  - Connection with : "+intS.getConnectionWith()+"\n"+
          "  - Network address : "+intS.getNetworkAddress()+"\n"+
          "  - Status : "+intS.getMyStatusString()+"\n";
    }//end serial

    text += "\n - = Ethernet Port = - ";
    for (int count = 0; count < rt.getEport().size();count++){
      IntEthernet intE = (IntEthernet)rt.getEport().elementAt(count);
      text += "\n"+
          "- "+intE.getEname()+"\n"+
          "  - Connection with : "+intE.getConnectionWith()+"\n"+
          "  - Network address : "+intE.getNetworkAddress()+"\n"+
          "  - VLAN number : "+intE.getVLAN()+"\n";
    }//end ethernet

    jTextArea.setText(text);
    jTextArea.setCaretPosition(0);

  }//end setTextProperty(Router)

  static void setTextProperty(Switch sw){
    String text = "";

    text += " - = Switch = - \n";
    text += "Switch name : "+sw.getSwitchName()+"\n"+
            "Mac Address : "+sw.getSwitchMacAddress()+"\n"+
            "  - Max fast ehernet port : "+sw.getEport().size()+"\n";

    text += "\n - = Ethernet Port = - ";
    for (int count = 0; count < sw.getEport().size();count++){
      IntEthernet intE = (IntEthernet)sw.getEport().elementAt(count);
      text += "\n"+
          "- "+intE.getEname()+"\n"+
          "  - Connection with : "+intE.getConnectionWith()+"\n"+
          "  - Network address : "+intE.getNetworkAddress()+"\n"+
          "  - VLAN number : "+intE.getVLAN()+"\n";
    }//end ethernet

    jTextArea.setText(text);
    jTextArea.setCaretPosition(0);
  }//end setTextProperty(Router)




}// End Class Frame1