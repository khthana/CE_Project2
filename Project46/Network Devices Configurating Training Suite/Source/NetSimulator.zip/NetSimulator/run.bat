set path=C:\JBuilder8\jdk1.4\bin
java -jar NetSimulator.jar