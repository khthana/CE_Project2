﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0051)http://www.dotnetbips.com/displayarticle.aspx?id=75 -->
<HTML><HEAD><TITLE>DotNetBips - .Net Simplified</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<META content=".Net Articles, tutorials, source code, demos and more" 
name=description>
<META content=".Net,ASP.NET,VB.NET,C#,ADO.NET,Web Service,XML,COM,Remoting" 
name=keywords><LINK href="displayarticle_files/styles.css" type=text/css 
rel=stylesheet>
<META content="MSHTML 6.00.2600.0" name=GENERATOR></HEAD>
<BODY><!-- main table start -->
<TABLE class=base cellPadding=10 align=center border=0>
  <TBODY>
  <TR>
    <TD class=bottombordercell vAlign=top width="100%" colSpan=3><!-- header table start --><SPAN 
      style="VERTICAL-ALIGN: super; WIDTH: 50%; TEXT-ALIGN: left" 
      align="left"><A href="http://www.dotnetbips.com/index.aspx"><IMG 
      src="displayarticle_files/dotnetbipsbanner.gif" border=0> </A></SPAN><SPAN 
      style="WIDTH: 50%; TEXT-ALIGN: right" align="right"><IMG 
      src="displayarticle_files/dotnetbipsslogan1.gif">&nbsp;&nbsp; <BR><IMG 
      src="displayarticle_files/dotnetbipsslogan2.gif"> </SPAN><!-- top menu start -->
      <TABLE class=topmenu cellSpacing=0 cellPadding=0 width="100%">
        <TBODY>
        <TR>
          <TD align=middle><A 
            href="http://www.dotnetbips.com/index.aspx">Home</A> </TD>
          <TD align=middle><A 
            href="http://www.dotnetbips.com/about.aspx">About</A> </TD>
          <TD align=middle><A 
            href="http://www.dotnetbips.com/search.aspx">Search</A> </TD>
          <TD align=middle><A 
            href="http://www.dotnetbips.com/contact.aspx">Contact</A> </TD>
          <TD noWrap align=middle><A 
            href="http://www.dotnetbips.com/linkexchange.aspx">Link Exchange</A> 
          </TD>
          <TD align=middle><A 
            href="http://www.dotnetbips.com/guestbook.aspx">Guestbook</A> </TD>
          <TD noWrap align=middle><A 
            href="http://www.dotnetbips.com/tellfriends.aspx">Tell Your 
            Friends</A> </TD></TR></TBODY></TABLE><!-- top menu table end --><!-- header table end --></TD></TR>
  <TR><!-- lhs column start -->
    <TD class=rightbordercell vAlign=top width="10%" height=800><!-- lhs menu start -->
      <TABLE cellSpacing=0 cellPadding=0 width=125 border=0><!--<tr>
				<th class="topbottombordercell">
					Site Search</th>
			</tr>
			<tr>
				<td align="middle">
					<form name="frmsearch" action="/search.aspx" method="get">
						Search DotNetBips:<br>
						<br>
						<input name="criteria" type="text" class="textbox" size="10">&nbsp; <input type="submit" class="button" value="Go"><br>
						<br>
						<a href='/search.aspx'>Advanced Search</a>
					</form>
				</td>
			</tr>
			-->
        <TBODY>
        <TR>
          <TD align=middle><IFRAME marginWidth=0 marginHeight=0 
            src="displayarticle_files/displayad.aspx" frameBorder=0 width=125 
            scrolling=no 
            height=125><script language="javascript" src="http://ads.aspalliance.com/displayad.aspx?t=6&m=1&target=_parent&js=1"></script></IFRAME><BR><BR></TD></TR>
        <TR>
          <TH class=topbottombordercell noWrap>Sections </TH></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=framework">.NET 
            Framework</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=aspnetgeneral">ASP.NET 
            General</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=webform">Web 
            Forms</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=webcontrol">Web 
            Controls</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=aspnetcustomcontrol">Custom 
            Controls</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=webservice">Web 
            Services</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=aspnetconfig">ASP.NET 
            Config</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=aspnetsecurity">ASP.NET 
            Security</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=winform">Windows 
            Forms</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=adonet">ADO.NET</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=remoting">Remoting</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=comp">Components</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=vbnet">VB.NET</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=cs">C#</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=xml">XML</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=tools">Products 
            &amp; Tools</A></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/toc.aspx?technology=com">COM/DCOM</A><BR><BR></TD></TR>
        <TR>
          <TH class=topbottombordercell noWrap>Community</TH></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/links.aspx?category=sites">Web 
            Sites</A><BR></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/links.aspx?category=lists">Mailing 
            Lists</A><BR></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/newsgroups.aspx">Newsgroups</A><BR></TD></TR>
        <TR>
          <TD class=rightaligncell noWrap><A 
            href="http://www.dotnetbips.com/usergroups.aspx">User 
            Groups</A><BR><BR></TD></TR>
        <TR>
          <TH class=topbottombordercell noWrap>Hosted By</TH></TR>
        <TR>
          <TD noWrap align=middle><BR><A href="http://www.securewebs.com/" 
            target=_blank><IMG src="displayarticle_files/securewebs.gif" 
            border=0></A><BR><BR><BR></TD></TR>
        <TR>
          <TD align=middle><IFRAME marginWidth=0 marginHeight=0 
            src="C:\Documents and Settings\bank\My Documents\My Web\Changing Target Web Service At Runtime_files\displayarticle_files\displayad(1).aspx" 
            frameBorder=0 width=125 scrolling=no 
            height=125>
						<script language="javascript" src="http://ads.aspalliance.com/displayad.aspx?t=5&m=1&target=_parent&js=1"></script>
					</IFRAME><BR><BR></TD></TR>
        <TR>
          <TD align=middle><IFRAME marginWidth=0 marginHeight=0 
            src="C:\Documents and Settings\bank\My Documents\My Web\Changing Target Web Service At Runtime_files\displayarticle_files\displayad(1).aspx" 
            frameBorder=0 width=125 scrolling=no 
            height=125>
						<script language="javascript" src="http://ads.aspalliance.com/displayad.aspx?t=5&m=1&target=_parent&js=1"></script>
					</IFRAME></TD></TR></TBODY></TABLE><!-- lhs menu end --></TD>
    <TD vAlign=top width="70%">
      <FORM id=form1 name=form1 action=displayarticle.aspx?id=75 
      method=post><INPUT type=hidden 
      value=dDwtMTI3MjAzOTU3NDt0PDtsPGk8ND47PjtsPHQ8O2w8aTwwPjtpPDI+Oz47bDx0PDtsPGk8Mz47aTw3PjtpPDExPjtpPDEzPjs+O2w8dDxwPHA8bDxUZXh0Oz47bDxCaXBpbiBKb3NoaTs+Pjs+Ozs+O3Q8cDxwPGw8VGV4dDtOYXZpZ2F0ZVVybDs+O2w8d2VibWFzdGVyQGRvdG5ldGJpcHMuY29tO21haWx0bzp3ZWJtYXN0ZXJAZG90bmV0Ymlwcy5jb207Pj47Pjs7Pjt0PHA8cDxsPFRleHQ7PjtsPEJpcGluIEpvc2hpIC0gdGhlIGNyZWF0b3IgYW5kIG93bmVyIG9mIERvdE5ldEJpcHMgLSBpcyBhIE1pY3Jvc29mdCBNVlAsIFNvZnR3YXJlIERldmVsb3BlciBhbmQgQXV0aG9yLiBIZSBoYXMgd3JpdHRlbiBkb3plbnMgb2YgYXJ0aWNsZXMgZm9yIERvdE5ldEJpcHMgYW5kIG90aGVyIHdlYiBzaXRlcy4gS25vdyBtb3JlIGFib3V0IGhpbSBhbmQgRG90TmV0QmlwcyBcPGEgaHJlZj1hYm91dC5hc3B4XD5oZXJlXDwvYVw+Ljs+Pjs+Ozs+O3Q8cDxwPGw8VGV4dDs+O2w8MTE3Oz4+Oz47Oz47Pj47dDw7bDxpPDM+Oz47bDx0PEAwPHA8cDxsPFBhZ2VDb3VudDtfIUl0ZW1Db3VudDtfIURhdGFTb3VyY2VJdGVtQ291bnQ7RGF0YUtleXM7PjtsPGk8MT47aTwyPjtpPDI+O2w8Pjs+Pjs+Ozs7Ozs7Ozs7Oz47bDxpPDA+Oz47bDx0PDtsPGk8MT47aTwyPjs+O2w8dDw7bDxpPDA+Oz47bDx0PDtsPGk8MD47PjtsPHQ8QDw0MDtPdmVybG9hZGluZyBXZWIgTWV0aG9kcyBJbiBBIFdlYiBTZXJ2aWNlOz47Oz47Pj47Pj47dDw7bDxpPDA+Oz47bDx0PDtsPGk8MD47PjtsPHQ8QDw0MTtDcmVhdGluZyBXZWIgU2VydmljZXMgaW4gQVNQLk5FVDs+Ozs+Oz4+Oz4+Oz4+Oz4+Oz4+Oz4+Oz4+O2w8UmF0ZWFydGljbGUxOlJhZGlvQnV0dG9uMTtSYXRlYXJ0aWNsZTE6UmFkaW9CdXR0b24xO1JhdGVhcnRpY2xlMTpSYWRpb0J1dHRvbjI7UmF0ZWFydGljbGUxOlJhZGlvQnV0dG9uMjtSYXRlYXJ0aWNsZTE6UmFkaW9CdXR0b24zO1JhdGVhcnRpY2xlMTpSYWRpb0J1dHRvbjM7UmF0ZWFydGljbGUxOlJhZGlvQnV0dG9uNDtSYXRlYXJ0aWNsZTE6UmFkaW9CdXR0b240O1JhdGVhcnRpY2xlMTpSYWRpb0J1dHRvbjU7Pj4/J7MmwN/y4kVV755Ncuj9kBiRXw== 
      name=__VIEWSTATE> 
      <H3>Changing Target Web Service At Runtime</H3>
      <H4>Introduction</H4>
      <P>While developing clients for web services, we typically add a web 
      reference to the web service by specifying URL of the .asmx file. Adding a 
      web service in VS.NET generates required proxy object. However, it may 
      happen that after adding the web reference the web service is moved to 
      some other location. In such cases the most easy way is to recreate the 
      proxy object. But what if the same thing happens after you deploy your web 
      service client. It would be nice to allow configurable URL so that even if 
      original web service is moved your clients need not be recompiled. In this 
      article we will see how to do just that. </P>
      <H4>Creating the web service</H4>
      <P>For our example we will develop a simple web service that has only one 
      method. Following steps will show you how to proceed. </P>
      <UL>
        <LI>Create a new C# web service project in VS.NET. 
        <LI>Open the default .asmx file and add following code to it. </LI></UL><PRE>using System;
using System.Web.Services;

namespace HelloWorldWS
{
public class CHelloWorld : 
System.Web.Services.WebService
{
	[WebMethod]
	public string GetHelloWorld()
	{
		return "Hello World From CHelloWorld";
	}	
}
}
</PRE>
      <UL>
        <LI>As shown above this web service class (CHelloWorld) contains a 
        single method called GetHelloWorld() that returns a string. 
        <LI>Add another .asmx file to the project. 
        <LI>Open the file and modify it as shown below. </LI></UL><PRE>using System;
using System.Web.Services;

namespace HelloWorldWS
{
public class CHelloWorldBackup : 
System.Web.Services.WebService
{
	[WebMethod]
	public string GetHelloWorld()
	{
		return "Hello World From CHelloWorldBackup";
	}
}
}
</PRE>
      <UL>
        <LI>This class is similar to previous one but its name is 
        CHelloWorldBackup. Also, it returns different string from 
        GetHelloWorld() method so that you can identify the method call 
        <LI>Now, that we have both the web services ready compile the project. 
        </LI></UL>
      <H4>Creating web service client</H4>
      <P>Let us build a simple web client for our web service.</P>
      <UL>
        <LI>Create a new ASP.NET web application in VS.NET. 
        <LI>The application will have a default web form. Before writing any 
        code we need to add a web reference to our web service. Right click on 
        the references node and select Add web reference. Follow the same 
        procedure as you would have while developing normal web services. 
        Adding&nbsp; a web reference will generate code for proxy web service 
        object. 
        <LI>Place a button on the web form and add following code in the Click 
        event of the button: </LI></UL><PRE>private void Button1_Click
(object sender, System.EventArgs e)
{
localhost.CHelloWorld proxy=new localhost.CHelloWorld;
Response.Write(proxy.GetHelloWorld());
}
</PRE>
      <UL>
        <LI>Above code shows how you will normally call a web service. The web 
        reference contains information about the location of the web service. 
        <LI>If you move the .asmx file after you depoly this client, it is bound 
        to get an error. To avoid such situation, modify above code as shown 
        below: </LI></UL><PRE>private void Button1_Click
(object sender, System.EventArgs e)
{
localhost.CHelloWorld proxy=new localhost.CHelloWorld;
proxy.Url="http://localhost/webserviceurlandtimeout<BR>/HelloWorld.asmx";
Response.Write(proxy.GetHelloWorld());
}
</PRE>
      <UL>
        <LI>In above code we have explicitly set Url property of the proxy class 
        to the required .asmx file. You can easily store this URL in 
        &lt;appSettings&gt; section of web.config file and retrieve it at run 
        time. Now, even if you move your web service, all you need to do is 
        change its URL in the web.config. 
        <LI>Following code shows this: </LI></UL><PRE>private void Button1_Click(object sender, System.EventArgs e)
{
localhost.CHelloWorld proxy=new localhost.CHelloWorld;
proxy.Url=GetURL();
Response.Write(proxy.GetHelloWorld());
}
</PRE><PRE>public string GetURL()
{
   return ConfigurationSettings.AppSettings["webserviceurl"];
}
</PRE>
      <UL>
        <LI>The web.config looks like this: </LI></UL><PRE>&lt;appSettings&gt;
&lt;add 
key="webserviceurl" 
value="http://localhost/webserviceurlandtimeout
/HelloWorldBackup.asmx" /&gt;
&lt;/appSettings&gt;    
</PRE>
      <P>Note that in order to work above code correctly, both the web service 
      should have exactly same web method signatures.</P>
      <P>I hope you must have got some idea about how to change target web 
      service at run time.</P>
      <P>Keep Coding!</P>
      <H4>About the author</H4>
      <TABLE id=Table1 cellSpacing=1 cellPadding=3 width="100%" bgColor=linen 
      border=0>
        <TBODY>
        <TR>
          <TD vAlign=top align=middle width="20%">
            <P align=right><SPAN id=Authorinfo1_Label1>Name :</SPAN></P></TD>
          <TD align=middle>
            <P align=left><SPAN id=Authorinfo1_lblAuthorName 
            style="WIDTH: 100%">Bipin Joshi</SPAN></P></TD></TR>
        <TR>
          <TD vAlign=top align=middle width="20%">
            <P align=right><SPAN id=Authorinfo1_Label2>Email :</SPAN></P></TD>
          <TD align=middle>
            <P align=left><A id=Authorinfo1_lnkEmail style="WIDTH: 100%" 
            href="mailto:webmaster@dotnetbips.com">webmaster@dotnetbips.com</A></P></TD></TR>
        <TR>
          <TD vAlign=top align=middle width="20%">
            <P align=right><SPAN id=Authorinfo1_Label3>Profile :</SPAN></P></TD>
          <TD align=middle>
            <P align=left><SPAN id=Authorinfo1_lblProfile 
            style="WIDTH: 100%">Bipin Joshi - the creator and owner of 
            DotNetBips - is a Microsoft MVP, Software Developer and Author. He 
            has written dozens of articles for DotNetBips and other web sites. 
            Know more about him and DotNetBips <A 
            href="http://www.dotnetbips.com/about.aspx">here</A>.</SPAN></P></TD></TR><!--
	<TR>
		<TD vAlign="top" align="middle" width="20%">
			Article&nbsp;Count :</TD>
		<TD align="middle">
			<P align="left">
				<span id="Authorinfo1_lblArtCount">117</span></P>
		</TD>
	</TR>
	--></TBODY></TABLE>
      <P></P>
      <P>
      <DIV align=center>
      <TABLE class=ratingtable id=Table1 cellSpacing=1 cellPadding=1 width="50%" 
      align=center border=0>
        <TBODY>
        <TR>
          <TD align=middle colSpan=5>Rate this article<BR>(1 being poor and 5 
            being excellent)</TD></TR>
        <TR>
          <TD align=middle><INPUT id=Ratearticle1_RadioButton1 type=radio 
            value=RadioButton1 name=Ratearticle1:rating><LABEL 
            for=Ratearticle1_RadioButton1>1</LABEL></TD>
          <TD align=middle><INPUT id=Ratearticle1_RadioButton2 type=radio 
            value=RadioButton2 name=Ratearticle1:rating><LABEL 
            for=Ratearticle1_RadioButton2>2</LABEL></TD>
          <TD align=middle><INPUT id=Ratearticle1_RadioButton3 type=radio 
            value=RadioButton3 name=Ratearticle1:rating><LABEL 
            for=Ratearticle1_RadioButton3>3</LABEL></TD>
          <TD align=middle><INPUT id=Ratearticle1_RadioButton4 type=radio 
            value=RadioButton4 name=Ratearticle1:rating><LABEL 
            for=Ratearticle1_RadioButton4>4</LABEL></TD>
          <TD align=middle><INPUT id=Ratearticle1_RadioButton5 type=radio 
            CHECKED value=RadioButton5 name=Ratearticle1:rating><LABEL 
            for=Ratearticle1_RadioButton5>5</LABEL></TD></TR>
        <TR>
          <TD align=middle colSpan=5><INPUT class=button id=Ratearticle1_Button1 type=submit value=Submit name=Ratearticle1:Button1><BR><BR></TD></TR></TBODY></TABLE></DIV>
      <P>
      <DIV align=center>
      <H4><SPAN id=Relatedcontent1_Label1>Have You Read These Related 
      Article?</SPAN></H4></DIV>
      <TABLE id=Relatedcontent1_Datagrid2 
      style="WIDTH: 100%; BORDER-COLLAPSE: collapse" cellSpacing=0 rules=all 
      border=0>
        <TBODY>
        <TR>
          <TD>
            <LI><A 
            href="http://www.dotnetbips.com/displayarticle.aspx?id=40">Overloading 
            Web Methods In A Web Service </A></LI></TD></TR>
        <TR>
          <TD>
            <LI><A 
            href="http://www.dotnetbips.com/displayarticle.aspx?id=41">Creating 
            Web Services in ASP.NET </A></LI></TD></TR></TBODY></TABLE>
      <P></P>
  <TR>
    <TD align=middle colSpan=3><IFRAME marginWidth=0 marginHeight=0 
      src="C:\Documents and Settings\bank\My Documents\My Web\Changing Target Web Service At Runtime_files\displayarticle_files\displayad(2).aspx" 
      frameBorder=0 width=468 scrolling=no 
      height=60><script language="javascript" src="http://ads.aspalliance.com/displayad.aspx?t=1&m=1&target=_parent&js=1"></script></IFRAME></TD></TR>
  <TR>
    <TD class=topbordercell vAlign=top align=middle width="100%" 
      colSpan=3>Copyright ©&nbsp;2000-2002 DotNetBips.com. All rights reserved. 
      <BR><A 
      href="mailto:webmaster@dotnetbips.com">mailto:webmaster@dotnetbips.com</A><BR><A 
      href="http://www.dotnetbips.com/legal.aspx">Read Terms Of Use</A> 
  </TD></TR></TBODY></TABLE></FORM></BODY></HTML>
