// Mouseover effects shamelessly stolen from MS.com

var sOffBackColor		= "#FF9900";
var sOffTextColor		= "#000000";
var sOffBorderColor	= "#FF9900";
var sOffPadding		= "1px";
var sOffOffset		= "0";

var sOverBackColor	= "#F9DE87";
var sOverTextColor	= "blue";
var sOverBorderColor	= "darkblue";	// "#FFFFCC #993300 #993300 #FFFFCC";
var sOverPadding		= "1px";
var sOverOffset		= "-1px";

var sDownBackColor	= "#FFBA75";
var sDownTextColor	= "#000000";
var sDownBorderColor	= "purple";	// "#993300 #FFFFCC #FFFFCC #993300";
var sDownPadding		= "1px";	// "3px 1px 1px 3px";
var sDownOffset		= "0";

var bMouseDidIt		= false;

function button_over(eButton)
{
	// If we're just mousing about _within_ eButton, then bail
	if (window.event && eButton.contains(window.event.fromElement) && 
		eButton.contains(window.event.toElement)) 
		return false;

	// Otherwise, do the effects
	eButton.style.backgroundColor = sOverBackColor;
	eButton.style.color = sOverTextColor;
	eButton.style.top = sOverOffset;
	eButton.style.left = sOverOffset;
	eButton.style.position = "relative";

	if (eActiveButton != eButton)
	{
		eButton.style.borderColor = sOverBorderColor;
//		eButton.rows[0].cells[0].children[0].children[0].src 
//			= sImgPath + eButton.id.replace(/tbl(.*)Button/,"$1") + "_over.gif";
	}

}

function button_out(eButton)
{
	if (window.event && eButton.contains(window.event.fromElement) && 
		eButton.contains(window.event.toElement)) 
		return false;

	if (eActiveButton != eButton)
	{
		eButton.style.backgroundColor = sOffBackColor;
		eButton.style.borderColor = sOffBorderColor;
		eButton.style.color = sOffTextColor;
		eButton.style.top = sOffOffset;
		eButton.style.left = sOffOffset;
		eButton.rows[0].cells[0].style.padding = sOffPadding;
		if (typeof(eButton.rows[0].cells[1])!="undefined")
			eButton.rows[0].cells[1].style.padding = sOffPadding;
//		eButton.rows[0].cells[0].children[0].children[0].src
//			 = sImgPath + eButton.id.replace(/tbl(.*)Button/,"$1") + "_off.gif";
	}
	else
	{
		eButton.style.backgroundColor = sDownBackColor;
		eButton.style.borderColor = sDownBorderColor;
		eButton.style.color = sDownTextColor;
		eButton.style.top = sDownOffset;
		eButton.style.left = sDownOffset;
	}
}


function button_down(eButton)
{
	eButton.style.backgroundColor = sDownBackColor;
	eButton.style.color = sDownTextColor;
	eButton.style.borderColor = sDownBorderColor;
	eButton.style.top = sDownOffset;
	eButton.style.left = sDownOffset;
	eButton.rows[0].cells[0].style.padding = sDownPadding;
	if (typeof(eButton.rows[0].cells[1])!="undefined")
		eButton.rows[0].cells[1].style.padding = sDownPadding;
}

function button_click(eButton)
{
	if (null != eActiveButton && eButton != eActiveButton)  // RESET OTHER ACTIVE BUTTON
	{
		eActiveButton.style.backgroundColor = sOffBackColor;
		eActiveButton.style.borderColor = sOffBorderColor;
		eActiveButton.style.color = sOffTextColor;
		eActiveButton.style.top = sOffOffset;
		eActiveButton.style.left = sOffOffset;
//		eActiveButton.rows[0].cells[0].children[0].children[0].src
//			 = sImgPath + eActiveButton.id.replace(/tbl(.*)Button/,"$1") + "_off.gif";
		eActiveButton.rows[0].cells[0].style.padding = sOffPadding;
		if (typeof(eActiveButton.rows[0].cells[1])!="undefined")
			eActiveButton.rows[0].cells[1].style.padding = sOffPadding;
		eActiveButton = null;
	}

	if (eButton != eActiveButton)  // MAKE HOVERED BUTTON ACTIVE
	{
		eActiveButton = eButton;
		eActiveButton.style.backgroundColor = sDownBackColor;
		eActiveButton.style.borderColor = sDownBorderColor;
		eActiveButton.style.color = sDownTextColor;
		eActiveButton.style.top = sDownOffset;
		eActiveButton.style.left = sDownOffset;
		eActiveButton.rows[0].cells[0].style.padding = sDownPadding;
		if (typeof(eActiveButton.rows[0].cells[1])!="undefined")
			eActiveButton.rows[0].cells[1].style.padding = sDownPadding;
	}

	else  // RESET HOVERED BUTTON
	{
		eActiveButton.style.backgroundColor = sOverBackColor;
		eActiveButton.style.borderColor = sOverBorderColor;
		eActiveButton.style.color = sOverTextColor;
		eActiveButton.style.top = sOverOffset;
		eActiveButton.style.left = sOverOffset;
		eActiveButton.rows[0].cells[0].style.padding = sOverPadding;
		if (typeof(eActiveButton.rows[0].cells[1])!="undefined")
			eActiveButton.rows[0].cells[1].style.padding = sOverPadding;
		eActiveButton = null;
	}
}