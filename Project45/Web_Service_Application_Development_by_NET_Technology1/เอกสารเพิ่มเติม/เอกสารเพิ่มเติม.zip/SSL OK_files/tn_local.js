var ToolBar_Supported = ToolBar_Supported ;
if (ToolBar_Supported != null && ToolBar_Supported == true)
{
	//To Turn on/off Frame support, set Frame_Supported = true/false.
	/* Code added below to test to see if this should be treated as being in a frameset or not (copied from a-peterh)*/
	//strQueryString = document.location.search;
	//strQueryString = strQueryString.toUpperCase();
	//if (strQueryString.indexOf("?FR=1") != -1 || strQueryString.indexOf("&FR=1") != -1)
		//Frame_Supported = true;
	//else
		Frame_Supported = false;

	// Customize default ICP menu color - bgColor, fontColor, mouseoverColor
	setDefaultICPMenuColor("#003399", "#FFFFFF", "#FF3300")

	// Customize toolbar background color
	setToolbarBGColor("#003399");
	// setToolbarBGColor("#000000");
	
	// Customize toolbar width
	

	// display ICP Banner
	setICPBanner("/library/images/support/en-us/tn250x60.gif","/isapi/gomscom.asp?target=/technet/","TechNet Online") ;
    setMSBanner("mslogo_003399.gif","/isapi/gomscom.asp?target=/","microsoft.com Home") ;

	//***** Add ICP menus *****
	addICPMenu("Menu0", "TechNet Home", "", "http://support.microsoft.com/isapi/gomscom.asp?target=/technet/default.asp");
	addICPMenu("Menu1", "Downloads", "", "http://support.microsoft.com/isapi/gomscom.asp?target=/technet/downloads/default.asp");
	addICPMenu("Menu2", "Site Map", "", "http://support.microsoft.com/isapi/gomscom.asp?target=/technet/usingtn/sitemap/default.asp");
	addICPMenu("Menu3", "TechNet Worldwide", "", "http://support.microsoft.com/isapi/gomscom.asp?target=/technet/worldwide/default.asp");
}