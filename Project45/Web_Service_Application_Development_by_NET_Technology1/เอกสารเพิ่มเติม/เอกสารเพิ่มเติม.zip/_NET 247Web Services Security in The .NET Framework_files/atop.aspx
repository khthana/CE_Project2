﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0087)http://dotnet247.com/247reference/atop.aspx?u=http://www.15seconds.com/issue/020312.htm -->
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=utf-8"><LINK 
href="atop_files/style.css" type=text/css rel=stylesheet>
<META content="MSHTML 6.00.2600.0" name=GENERATOR></HEAD>
<BODY leftMargin=0 topMargin=0 margintop="0" marginleft="0">
<TABLE height="100%" cellSpacing=0 cellPadding=0 width="100%" bgColor=#dfff0c 
border=0>
  <TBODY>
  <TR>
    <TD class=bodytext>&nbsp;&nbsp;<B>Original URL: </B><A 
      href="http://www.15seconds.com/issue/020312.htm" 
      target=_top>http://www.15seconds.com/issue/020312.htm</A></TD>
    <TD class=bodytext align=right><B><A 
      style="COLOR: #000000; TEXT-DECORATION: none; text-height: 12pt" 
      href="http://www.dotnet247.com/" target=_top>.NET 
    247</A></B>&nbsp;&nbsp;</TD></TR></TBODY></TABLE></BODY></HTML>
