<%@ WebService Language="c#" Codebehind="Service1.asmx.cs" Class="msmq_webservices.Service1" %>
