<%@ Application Codebehind="Global.asax.cs" Inherits="msmq_webservices.Global" %>
