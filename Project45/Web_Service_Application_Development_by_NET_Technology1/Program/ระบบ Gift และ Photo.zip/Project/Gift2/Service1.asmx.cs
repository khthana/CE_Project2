using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace Gift
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class GiftInfo
	{
		string type_id;
		string type_name;
		string subtype_id;
		string subtype_name;
		string subtype_detail;
		string pic_url;
		double price;
	}
	public class TotalPrice
	{
		string contact_number;
		string[] job_id;
		double[] jobtotalprice;
		double totalprice;
		DateTime deadline_confirm;

		public TotalPrice(int number_job,DateTime deadline)
		{
			job_id = new string[number_job];
			jobtotalprice = new double[number_job];
			deadline_confirm = new DateTime();
			deadline_confirm=deadline;
		}
	}
	public class OrderInfo
	{
		string username;
		string type_id;
		string subtype_id;
		string subtype_detail;
		string label;
		DateTime recievedate;
		//		DateTime recievetime;
		string address;
		int quantity;
		DateTime deadline_confirm;		

		public OrderInfo(DateTime recieve,DateTime deadline)
		{
			recievedate = new DateTime();
			recievedate=recieve;
			deadline_confirm = new DateTime();
			deadline_confirm=deadline;
		}
	}


	
	
	public class Gifts : System.Web.Services.WebService
	{
		public Gifts()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5
		//-- 0. Test Fnction --
		[WebMethod]
		public string test()
		{
			return "bank";
		}
		//-- 1. Gift_Detail --
		[WebMethod]
//		public GiftInfo gift_detail (string type_id,string style,double max_price,double min_price)
		//test 
		public DataSet gift_detail (string type_id,string style,double max_price,double min_price)
		{	string tablename="tbl_giftinfo";
//			string SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
			string SqlString ="select * from gift_order";
			DbComponent.Gift db = new DbComponent.Gift();
			DataSet myDataSet=db.Query(SqlString,tablename);
			return myDataSet;

			// + 
			//			return "Address of Gift Shop place";
		}

		
		//-- 2. Place_detail --
		[WebMethod]
		public string place_detail()
		{	
			// + change address
			return "Address of Gift Shop place";
		}

	}
}
