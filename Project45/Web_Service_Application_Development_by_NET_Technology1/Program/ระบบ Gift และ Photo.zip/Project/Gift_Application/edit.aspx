<%@ Page language="c#" Codebehind="edit.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.edit" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>edit</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="edit" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 159px; POSITION: absolute; TOP: 33px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Width="338px" Height="40px">
					<asp:TableRow>
						<asp:TableCell Text=" ���͡ Contact name ����ͧ���¡��ԡ��������¹�ŧ "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 102; LEFT: 108px; POSITION: absolute; TOP: 112px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" GridLines="Vertical" DataSource="<%# dataSet1 %>" ForeColor="Black" CellPadding="4" BorderWidth="1px">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid>
				<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 181px; POSITION: absolute; TOP: 314px" runat="server" BorderColor="Yellow" BackColor="#FFE0C0" Width="340px" Height="70px" ForeColor="DarkGoldenrod" Font-Size="Larger">�ҡ��ͧ���¡��ԡ��� contact ��顴��� cancel ���ҵ�ͧ���������䢧ҹ,����¡��ԡ�ҹ ��顴��� edit �����������͡�٨ҡ�ҹ������������ contact ���</asp:Label></FONT>
		</form>
	</body>
</HTML>
