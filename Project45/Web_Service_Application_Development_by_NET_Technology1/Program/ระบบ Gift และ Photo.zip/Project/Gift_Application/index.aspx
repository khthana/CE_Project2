<%@ Page language="c#" Codebehind="index.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.WebForm1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<FRAMESET border="0" frameSpacing="0" frameBorder="0" cols="19%,*">
			<FRAME name="fr_left" marginWidth="5" marginHeight="4" src="" noResize scrolling="no">
			<FRAME name="fr_right" marginWidth="5" marginHeight="4" src="" noResize>
		</FRAMESET>
		<noframes>
		</noframes>
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma"></FONT>
		</form>
	</body>
</HTML>
