<%@ Page language="c#" Codebehind="left_customer.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.left_customer" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>left_customer</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="left_customer" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table2" style="Z-INDEX: 103; LEFT: 10px; POSITION: absolute; TOP: 25px" runat="server" Height="40px" Width="167px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White"></asp:table><asp:imagebutton id="ImageButton1" style="Z-INDEX: 102; LEFT: 17px; POSITION: absolute; TOP: 300px" runat="server" Height="141px" Width="152px"></asp:imagebutton><asp:datagrid id=DataGrid1 style="Z-INDEX: 104; LEFT: 15px; POSITION: absolute; TOP: 92px" runat="server" Height="68px" Width="158px" BorderStyle="None" BackColor="White" BorderColor="#CC9966" ShowHeader="False" CellPadding="4" BorderWidth="1px" DataSource="<%# dataTable1 %>">
					<SelectedItemStyle Font-Bold="True" ForeColor="#663399" BackColor="#FFFF33"></SelectedItemStyle>
					<AlternatingItemStyle ForeColor="#3399FF" BackColor="#FFCCFF"></AlternatingItemStyle>
					<ItemStyle ForeColor="DarkRed" BackColor="AntiqueWhite"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="#FFFFCC" BackColor="#990000"></HeaderStyle>
					<FooterStyle ForeColor="#330099" BackColor="#FFFFCC"></FooterStyle>
					<PagerStyle HorizontalAlign="Center" ForeColor="#330099" BackColor="#FFFFCC"></PagerStyle>
				</asp:datagrid></FONT></form>
	</body>
</HTML>
