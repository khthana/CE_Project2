<%@ Page language="c#" Codebehind="show3.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.show3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>show3</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="show3" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 150px; POSITION: absolute; TOP: 46px" runat="server" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White" Height="40px" Width="249px">
					<asp:TableRow>
						<asp:TableCell Text=" ��������´�����觫����Թ��Ңͧ�س "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 32px; POSITION: absolute; TOP: 120px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" DataSource="<%# dataTable1 %>" BorderWidth="1px" CellPadding="4" ForeColor="Black" GridLines="Vertical" Width="664px">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></FONT>
		</form>
	</body>
</HTML>
