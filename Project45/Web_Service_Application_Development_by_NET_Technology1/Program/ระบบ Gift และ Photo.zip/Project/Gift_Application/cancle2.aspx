<%@ Page language="c#" Codebehind="cancle2.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.cancle2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>cancle2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="cancle2" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 141px; POSITION: absolute; TOP: 163px" runat="server" ForeColor="Red" Width="225px" Height="28px"></asp:Label>
				<asp:table id="Table1" style="Z-INDEX: 103; LEFT: 177px; POSITION: absolute; TOP: 64px" runat="server" Width="167px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text=" ¡��ԡ�����觫����Թ��� "></asp:TableCell>
					</asp:TableRow>
				</asp:table></FONT>
		</form>
	</body>
</HTML>
