<%@ Page language="c#" Codebehind="order2.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.order2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>order2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="order2" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 115px; POSITION: absolute; TOP: 111px" runat="server" BorderWidth="1px" CellPadding="4" ForeColor="Black" DataSource="<%# dataSet1 %>" GridLines="Vertical" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid>
				<asp:Table id="Table2" style="Z-INDEX: 103; LEFT: 251px; POSITION: absolute; TOP: 43px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Width="191px" Height="40px"></asp:Table></FONT>
		</form>
	</body>
</HTML>
